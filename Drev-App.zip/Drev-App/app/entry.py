# -*- coding: utf-8 -*-
"""PyInstaller 진입점: Drev.exe → watcher.cli.main

콘솔이 cp949여도 죽지 않도록 출력 스트림을 관용 모드로 재구성한다.
(한글은 cp949로 정상 표시되고, 인코딩 불가 문자만 '?'로 대체)
"""

import sys

# 창 모드(콘솔 없음, 2026-08-29): stdout/stderr가 없으면 print가 죽는다 —
# 로그 파일(watcher.log)로 돌려 진행·경고 기록을 남긴다
if sys.stdout is None or sys.stderr is None:
    import os
    _base = (os.path.dirname(sys.executable)
             if getattr(sys, "frozen", False) else os.getcwd())
    _path = os.path.join(_base, "watcher.log")
    try:      # 상한이 없어 몇 년 쓴 설치본이 수백 MB가 됐다 (2026-09-09 검토 중간 2)
        from watcher.logfile import rotate
        rotate(__import__("pathlib").Path(_path))
    except Exception:
        pass
    try:
        _log = open(_path, "a", encoding="utf-8", errors="replace", buffering=1)
    except OSError:
        # 읽기 전용 속성·권한(Program Files에 푼 포터블, 백신 잠금)이면 예약 검사가 스캔 전에
        # 조용히 죽었다 (검토21 운영 4) — 임시 폴더로 돌리고, 그마저 안 되면 버린다
        try:
            _alt = os.path.join(os.environ.get("TEMP", _base), "Drev")
            os.makedirs(_alt, exist_ok=True)
            _log = open(os.path.join(_alt, "watcher.log"), "a", encoding="utf-8",
                        errors="replace", buffering=1)
            _log.write(f"(원래 로그 {_path}에 쓸 수 없어 여기에 기록합니다)\n")
        except OSError:
            _log = open(os.devnull, "w", encoding="utf-8")
    sys.stdout = sys.stderr = _log
    # 한 달치 로그에서 어느 날 일인지 알 수 있게 — 실행마다 구분선 한 줄 (검토21 운영 3)
    import time as _time
    _log.write(f"=== {_time.strftime('%Y-%m-%d %H:%M:%S')} {' '.join(sys.argv[1:]) or '(창)'} ===\n")

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass

from watcher.cli import main  # noqa: E402  (스트림 설정 후 임포트)

if __name__ == "__main__":
    sys.exit(main())
