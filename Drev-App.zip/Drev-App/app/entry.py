# -*- coding: utf-8 -*-
"""PyInstaller 진입점: Drev.exe → watcher.cli.main

콘솔이 cp949여도 죽지 않도록 출력 스트림을 관용 모드로 재구성한다.
(한글은 cp949로 정상 표시되고, 인코딩 불가 문자만 '?'로 대체)
"""

import sys

# 창 모드(콘솔 없음, 2026-08-29): stdout/stderr가 없으면 print가 죽는다 —
# 로그 파일(watcher.log)로 돌려 진행·경고 기록을 남긴다
if sys.stdout is None or sys.stderr is None:
    import os
    _base = (os.path.dirname(sys.executable)
             if getattr(sys, "frozen", False) else os.getcwd())
    _path = os.path.join(_base, "watcher.log")
    try:      # 상한이 없어 몇 년 쓴 설치본이 수백 MB가 됐다 (2026-09-09 검토 중간 2)
        from watcher.logfile import rotate
        rotate(__import__("pathlib").Path(_path))
    except Exception:
        pass
    try:
        _log = open(_path, "a", encoding="utf-8", errors="replace", buffering=1)
    except OSError:
        # 읽기 전용 속성·권한(Program Files에 푼 포터블, 백신 잠금)이면 예약 검사가 스캔 전에
        # 조용히 죽었다 (검토21 운영 4) — 임시 폴더로 돌리고, 그마저 안 되면 버린다
        try:
            _alt = os.path.join(os.environ.get("TEMP", _base), "Drev")
            os.makedirs(_alt, exist_ok=True)
            _log = open(os.path.join(_alt, "watcher.log"), "a", encoding="utf-8",
                        errors="replace", buffering=1)
            _log.write(f"(원래 로그 {_path}에 쓸 수 없어 여기에 기록합니다)\n")
        except OSError:
            _log = open(os.devnull, "w", encoding="utf-8")
    sys.stdout = sys.stderr = _log
    # 한 달치 로그에서 어느 날 일인지 알 수 있게 — 실행마다 구분선 한 줄 (검토21 운영 3)
    import time as _time
    _log.write(f"=== {_time.strftime('%Y-%m-%d %H:%M:%S')} {' '.join(sys.argv[1:]) or '(창)'} ===\n")

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass

# 프로그램 파일이 빠졌으면(백신 격리·동기화 도구) 로그에 이유를 남기고 끝낸다 — 예약 검사가 이유 없이 죽지 않게
# (구매자 평가 P2). 점검 모듈이 없는 실행 형태(개발·PyInstaller)는 건너뛴다
try:
    import os as _os
    import drev_check as _dc
    if not _dc.check(_os.path.dirname(_os.path.abspath(__file__)), interactive=False):
        sys.exit(2)
except ImportError:
    pass

def _restore_interrupted_update() -> bool:
    """업데이트 교체가 정전·강제 종료로 끊겨 app/이 반쯤 복사된 채면 watcher를 읽지도 못한다 — 예약 검사가 매일 ImportError로
    죽고 메일이 끊겼다 (검토66 D1). watcher 없이 옛 판(app.old-drev 등)을 제자리로 되돌린다. 교체 프로세스가 살아 있으면 건드리지 않는다."""
    import os
    import shutil
    import time
    app = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(app)
    mark = os.path.join(root, "UPDATE_APPLYING")
    if not os.path.exists(mark):
        return False
    try:
        pid = int(open(mark, encoding="utf-8", errors="replace").read().strip() or 0)
        age = time.time() - os.path.getmtime(mark)
    except (OSError, ValueError):
        pid, age = 0, 1e9
    alive = False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, int(pid)) if pid else 0
        if h:
            alive = k.WaitForSingleObject(h, 0) != 0
            k.CloseHandle(h)
    except Exception:
        alive = False
    if alive and age < 1800:
        return False
    try:
        os.chdir(root)          # 작업 폴더가 app/이면 그 폴더를 치울 수 없다
    except OSError:
        pass
    done, failed = [], []
    for name in sorted(os.listdir(root)):
        if not name.endswith(".old-drev"):
            continue
        d = os.path.join(root, name[:-len(".old-drev")])
        try:
            if os.path.isdir(d):
                shutil.rmtree(d, ignore_errors=True)
            elif os.path.exists(d):
                os.remove(d)
            os.rename(os.path.join(root, name), d)
            done.append(os.path.basename(d))
        except OSError:
            failed.append(name)
    if not failed:              # 못 되돌린 것이 있으면 표식을 남겨 창의 정리가 옛 판을 지우지 않게 한다
        try:
            os.remove(mark)
        except OSError:
            pass
    print(f"끝나지 않은 업데이트 교체를 되돌렸습니다: {', '.join(done) or '없음'} — 다음 예약 검사 뒤 다시 업데이트합니다")
    return bool(done)


try:
    from watcher.cli import main  # noqa: E402  (스트림 설정 후 임포트)
except ImportError:
    # 반쯤 교체된 app/ — 옛 판을 되살리고 이번 실행은 끝낸다(다음 실행부터 옛 판으로 정상)
    if _restore_interrupted_update():
        sys.exit(3)
    raise

if __name__ == "__main__":
    sys.exit(main())
