# -*- coding: utf-8 -*-
"""포터블·설치판 진입점: Drev.exe(서명된 pythonw 사본) / python\\pythonw.exe app\\entry.py run → watcher.cli.main

(release.py의 PyInstaller 빌드도 이 파일을 쓰지만, 그 exe의 자동 교체 경로는 2026-11-02에 없앴다 — 기능 검토 S)

콘솔이 cp949여도 죽지 않도록 출력 스트림을 관용 모드로 재구성한다.
(한글은 cp949로 정상 표시되고, 인코딩 불가 문자만 '?'로 대체)
"""

import sys

# 창 모드(콘솔 없음, 2026-08-29): stdout/stderr가 없으면 print가 죽는다 —
# 로그 파일(watcher.log)로 돌려 진행·경고 기록을 남긴다
if sys.stdout is None or sys.stderr is None:
    import os
    _base = (os.path.dirname(sys.executable)
             if getattr(sys, "frozen", False) else os.getcwd())
    _path = os.path.join(_base, "watcher.log")
    try:      # 상한이 없어 몇 년 쓴 설치본이 수백 MB가 됐다 (2026-09-09 검토 중간 2)
        from watcher.logfile import rotate
        rotate(__import__("pathlib").Path(_path))
    except Exception:
        pass
    try:
        _log = open(_path, "a", encoding="utf-8", errors="replace", buffering=1)
    except OSError:
        # 읽기 전용 속성·권한(Program Files에 푼 포터블, 백신 잠금)이면 예약 검사가 스캔 전에
        # 조용히 죽었다 (검토21 운영 4) — 임시 폴더로 돌리고, 그마저 안 되면 버린다
        try:
            _alt = os.path.join(os.environ.get("TEMP", _base), "Drev")
            os.makedirs(_alt, exist_ok=True)
            _log = open(os.path.join(_alt, "watcher.log"), "a", encoding="utf-8",
                        errors="replace", buffering=1)
            _log.write(f"(원래 로그 {_path}에 쓸 수 없어 여기에 기록합니다)\n")
        except OSError:
            _log = open(os.devnull, "w", encoding="utf-8")
    sys.stdout = sys.stderr = _log
    # 한 달치 로그에서 어느 날 일인지 알 수 있게 — 실행마다 구분선 한 줄 (검토21 운영 3)
    import time as _time
    _log.write(f"=== {_time.strftime('%Y-%m-%d %H:%M:%S')} {' '.join(sys.argv[1:]) or '(창)'} ===\n")

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass


def _pid_alive(pid: int) -> bool:
    """그 pid의 프로세스가 아직 살아 있나 (Windows). 모르면 False."""
    if not pid:
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, int(pid))     # SYNCHRONIZE
        if not h:
            return False
        alive = k.WaitForSingleObject(h, 0) != 0
        k.CloseHandle(h)
        return alive
    except Exception:
        return False


def _restore_interrupted_update() -> bool:
    """업데이트 교체가 정전·강제 종료로 끊겨 app/이 반쯤 복사된 채면 watcher를 읽지도 못한다 — 예약 검사가 매일 ImportError로
    죽고 메일이 끊겼다 (검토66 D1). watcher 없이 옛 판(app.old-drev 등)을 제자리로 되돌린다. 교체 프로세스가 살아 있으면 건드리지 않는다."""
    import os
    import shutil
    app = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(app)
    mark = os.path.join(root, "UPDATE_APPLYING")
    if not os.path.exists(mark):
        return False
    import time
    if os.environ.get("DREV_SWAP_VERIFY"):
        return False            # 교체의 검증 실행 — 여기서 되살리면 원복할 재료가 사라져 app이 통째로 지워진다 (re_GS RG1)
    try:
        pid = int(open(mark, encoding="utf-8", errors="replace").read().strip() or 0)
        age = time.time() - os.path.getmtime(mark)
    except (OSError, ValueError):
        pid, age = 0, 1e9
    # 살아 있는 교체 프로세스: 30분 안이거나 옛 판 updater의 검증(--version 하나뿐)이면 건드리지 않는다. 30분 넘은 예약
    # 검사는 예전처럼 되살린다 — 강제 종료된 교체의 pid를 다른 장수 프로세스가 받으면 반쪽 app으로 매일 죽었다
    if _pid_alive(pid) and (age < 1800 or sys.argv[1:] == ["--version"]):
        return False
    try:
        os.chdir(root)          # 작업 폴더가 app/이면 그 폴더를 치울 수 없다
    except OSError:
        pass
    done, failed = [], []
    for name in sorted(os.listdir(root)):
        if not name.endswith(".old-drev"):
            continue
        d = os.path.join(root, name[:-len(".old-drev")])
        aside = d + ".broken-drev"
        moved = False
        try:
            # 지우지 않고 비켜 둔다 — rmtree(ignore_errors)는 잡힌 파일(백신·실행 중인 DLL)만 남기고 반쯤 지워
            # 옛 판을 못 옮기고 새 판도 망가뜨렸다. 이름 바꾸기는 잡힌 파일이 있으면 통째로 실패한다 (rvall D2)
            if os.path.lexists(d):
                if os.path.isdir(aside):
                    shutil.rmtree(aside, ignore_errors=True)
                elif os.path.lexists(aside):
                    os.remove(aside)
                os.rename(d, aside)
                moved = True
            os.rename(os.path.join(root, name), d)
            done.append(os.path.basename(d))
        except OSError:
            if moved and not os.path.lexists(d):
                try:
                    os.rename(aside, d)
                except OSError:
                    pass
            failed.append(name)
    for name in os.listdir(root):
        if name.endswith(".broken-drev"):
            shutil.rmtree(os.path.join(root, name), ignore_errors=True)
    if not failed:              # 못 되돌린 것이 있으면 표식을 남겨 창의 정리가 옛 판을 지우지 않게 한다
        try:
            os.remove(mark)
        except OSError:
            pass
    if done or failed:
        print(f"끝나지 않은 업데이트 교체를 되돌렸습니다: {', '.join(done) or '없음'}"
              + (f" (못 되돌림: {', '.join(failed)} — 다음 실행에서 다시)" if failed else "")
              + " — 다음 예약 검사 뒤 다시 업데이트합니다")
    return bool(done)


def _undo_unverified_swap() -> bool:
    """교체가 이름 바꾸기 둘째(새 판 → app)까지 끝내고 **검증 전에** 끊겼으면(정전·강제 종료) 옛 판을 먼저 되살린다.

    app/entry.py가 멀쩡하니 app 밖 되살리기(drev_recover)도, 아래 ImportError 길도 타지 않아 다음 예약 검사가
    검증 안 된 새 판으로 돌고, 그 뒤 창이 옛 판으로 되돌려 판이 널뛰었다 (rvall D2). 원복이 막힌 교체(원복 불완전 —
    교체 프로세스가 pid 0 표식을 남긴다)도 같은 길로 마저 되돌린다 (rvall D1).

    되살리는 범위는 **app만 바뀐 교체(App.zip)** 다. 전체판 교체(python·libs도 *.old-drev)는 이 실행이 그 python·libs로
    돌고 있어 바꿀 수 없다 — restore_interrupted가 '이름 바꾸기가 끝난 새 판'을 그대로 확정하고(고침 전과 같다, 창도 같다),
    이때는 옛 판으로 돌아가지 않는다 (re_GS RG3).

    건드리지 않는 경우: 교체 표식이 없거나 *.old-drev가 없다 / 표식의 교체 프로세스가 살아 있다(**나이와 무관** — 잠금
    대기·느린 복사로 30분이 넘은 교체의 검증이 옛 판을 되살려 '교체 완료'인데 옛 판이 남고 새 판이 지워졌다, re_GS RG1.
    pid가 다른 프로세스에 재사용됐으면 되살리기를 거를 뿐 — 고침 전처럼 새 판으로 돌고 창이 30분 규칙으로 정리한다) /
    교체가 부르는 검증 실행(DREV_SWAP_VERIFY, 또는 인자가 --version 하나뿐). 옛 판(app)을 되살렸으면 True."""
    import os
    app = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(app)
    mark = os.path.join(root, "UPDATE_APPLYING")
    if os.environ.get("DREV_SWAP_VERIFY") or sys.argv[1:] == ["--version"]:
        return False                # 교체의 검증(verify_tree)·판 확인 — 되살리기는 예약 검사·창의 몫
    try:
        if not os.path.exists(mark) or not any(n.endswith(".old-drev") for n in os.listdir(root)):
            return False
        pid = int(open(mark, encoding="utf-8", errors="replace").read().strip() or 0)
    except (OSError, ValueError):
        return False
    if _pid_alive(pid):
        return False                # 교체가 일하는 중
    cwd0 = os.getcwd()
    try:
        os.chdir(root)              # 작업 폴더가 app/이면 그 폴더를 비켜 둘 수 없다
    except OSError:
        pass
    restored = False
    try:
        from pathlib import Path
        from watcher import selfupdate as _su
        before = sorted(n for n in os.listdir(root) if n.endswith(".old-drev"))
        _su.applying_pid(Path(root))        # 죽은 표식 → restore_interrupted → 다 되돌렸으면 표식을 지운다
        after = sorted(n for n in os.listdir(root) if n.endswith(".old-drev"))
        gone = [n for n in before if n not in after]
        if gone:
            print("검증 전에 끊긴 업데이트 교체를 되돌렸습니다: "
                  + ", ".join(n[:-len(".old-drev")] for n in gone) + " — 옛 판으로 이번 실행을 다시 시작합니다")
        restored = "app.old-drev" in gone
    except Exception:
        restored = _restore_interrupted_update()
    if not restored:
        try:
            os.chdir(cwd0)          # 되살리지 않았으면 작업 폴더를 원래대로 (re_GS RG4)
        except OSError:
            pass
    return restored


# 검증 전에 끊긴 교체면 옛 판을 되살리고, 이번 실행은 되살린 옛 판으로 처음부터 다시 돈다 — 이미 읽은 watcher는 새 판이라
# 그대로 이어 가면 섞인다. 되살린 뒤엔 표식이 없어 다시 돈 실행은 여기를 지나친다 (rvall D2). 아래 파일 점검보다 먼저 —
# 검증 전 새 판이 백신에 격리된 채면 점검이 매일 '파일이 없어졌습니다'로 끝내 옛 판을 되살릴 기회가 없었다
if __name__ == "__main__":
    import os as _os
    _entry_file = _os.path.abspath(__file__)
    _cwd0 = _os.getcwd()
    if _undo_unverified_swap():
        if not _os.path.isfile(_entry_file):
            sys.exit(3)             # 되살린 옛 판에 진입점이 없다 — 이번 실행은 끝낸다(아래 ImportError 길과 같다)
        import subprocess as _sp
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        except Exception:
            pass
        # 같은 실행 옵션(-I·-X utf8 …)과 인자 그대로 — 스크립트 경로는 처음 작업 폴더 기준이다
        _argv = list(getattr(sys, "orig_argv", None) or [sys.executable, _entry_file] + sys.argv[1:])
        sys.exit(_sp.call([sys.executable] + _argv[1:], cwd=_cwd0))

# 프로그램 파일이 빠졌으면(백신 격리·동기화 도구) 로그에 이유를 남기고 끝낸다 — 예약 검사가 이유 없이 죽지 않게
# (구매자 평가 P2). 점검 모듈이 없는 실행 형태(개발·PyInstaller)는 건너뛴다
try:
    import os as _os
    import drev_check as _dc
    if not _dc.check(_os.path.dirname(_os.path.abspath(__file__)), interactive=False):
        sys.exit(2)
except ImportError:
    pass

try:
    from watcher.cli import main  # noqa: E402  (스트림 설정 후 임포트)
except ImportError:
    # 반쯤 교체된 app/ — 옛 판을 되살리고 이번 실행은 끝낸다(다음 실행부터 옛 판으로 정상)
    if _restore_interrupted_update():
        sys.exit(3)
    raise

if __name__ == "__main__":
    sys.exit(main())
