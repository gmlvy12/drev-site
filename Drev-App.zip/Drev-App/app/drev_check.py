# -*- coding: utf-8 -*-
"""Drev 프로그램 파일 자기 점검 — 표준 라이브러리만 쓴다(watcher 패키지가 깨져도 돌아야 한다).

포터블·설치판의 app/MANIFEST.txt(조립 때 만든 '지문  상대 경로' 목록)와 실제 파일을 대조한다. 백신 격리·동기화 도구가
app/ 안의 .py를 지우면 프로그램이 이유 없이 안 뜨거나 일부 화면만 죽었다 — 압축을 푼 직후 .py 12개가 사라진 일이 실제로
있었다 (구매자 평가 P2). 빠진 파일이 있으면 창으로 알리고 끝낸다. 내용만 다른 파일은 기록만 남긴다(직접 고친 경우)."""
import hashlib
import os
import sys

MANIFEST = "MANIFEST.txt"


def _sha(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def problems(app_dir: str) -> tuple[list, list]:
    """(빠진 파일들, 내용이 다른 파일들). 목록이 없으면 ([], [])."""
    mf = os.path.join(app_dir, MANIFEST)
    if not os.path.isfile(mf):
        return [], []
    missing, changed = [], []
    with open(mf, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "  " not in line:
                continue
            digest, rel = line.split("  ", 1)
            p = os.path.join(app_dir, *rel.split("/"))
            if not os.path.isfile(p):
                missing.append(rel)
            else:
                try:
                    if _sha(p) != digest:
                        changed.append(rel)
                except OSError:
                    missing.append(rel)
    return missing, changed


def check(app_dir: str, interactive: bool = False) -> bool:
    """빠진 파일이 없으면 True. 있으면 로그(표준 오류)에 남기고, interactive면 창으로도 알린 뒤 False."""
    try:
        missing, changed = problems(app_dir)
    except Exception as e:                      # 점검 자체의 실패로 프로그램을 막지 않는다
        print(f"[점검] 프로그램 파일 점검을 건너뜁니다: {e}", file=sys.stderr)
        return True
    if changed:
        print(f"[점검] 조립 때와 내용이 다른 프로그램 파일 {len(changed)}개: {', '.join(changed[:5])}", file=sys.stderr)
    if not missing:
        return True
    msg = (f"Drev 프로그램 파일 {len(missing)}개가 없어졌습니다:\n" + "\n".join(missing[:8])
           + ("\n…" if len(missing) > 8 else "")
           + "\n\n백신 프로그램의 격리 목록이나, 이 폴더가 OneDrive 같은 동기화 폴더 안에 있는지 확인하세요.\n"
             "그 뒤 같은 판을 다시 내려받아 이 폴더에 덮어 풀면 이력·설정은 그대로 이어집니다.")
    print("[점검] " + msg.replace("\n", " "), file=sys.stderr)
    if interactive:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "Drev — 프로그램 파일이 없어졌습니다", 0x10)
        except Exception:
            pass
    return False


def write_manifest(app_dir: str) -> int:
    """조립 때 app/ 아래 .py와 진입 파일의 지문 목록을 쓴다. 돌려주는 값: 적은 파일 수."""
    rows = []
    for base, dirs, files in os.walk(app_dir):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in files:
            if not fn.endswith(".py"):
                continue
            p = os.path.join(base, fn)
            rel = os.path.relpath(p, app_dir).replace(os.sep, "/")
            rows.append(f"{_sha(p)}  {rel}")
    rows.sort(key=lambda r: r.split("  ", 1)[1])
    with open(os.path.join(app_dir, MANIFEST), "w", encoding="utf-8", newline="\n") as f:
        f.write("# Drev 프로그램 파일 목록 — 시작할 때 빠진 파일이 없는지 대조한다 (지우거나 고치지 마세요)\n")
        f.write("\n".join(rows) + "\n")
    return len(rows)
