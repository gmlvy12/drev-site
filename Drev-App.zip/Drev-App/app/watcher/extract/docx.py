# -*- coding: utf-8 -*-
"""DOCX(Word)·HWPX(한글) 추출기 — 표준 라이브러리만 (2026-09-02).

배경: .docx는 검사 대상이면서 내용 추출이 없어, 워드로 된 사양서·견적서·계약서가
파일명에 단서가 없으면 전부 "문서"로 떨어졌다 (회사 실사용: "문서, 사양서, 견적서
등등 제대로 구분이 안 되는 거 같아"). 둘 다 zip 안의 XML이라 zipfile + ElementTree로
읽는다. 읽기 전용 (PRINCIPLE 2).

- 문단 → TextLine("문단 N")   - 표 → Row(첫 행이 머리글)   - 머리말의 '라벨: 값' → Field
- .hwp(구형 바이너리)는 지원하지 않는다 — 파일 수준 감지만. notes에 남기지 않는다
  (추출기가 호출되지 않으므로).
"""
from __future__ import annotations

import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from watcher.extract.base import Document, Field, Row, TextLine, date_qualified

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"
_MC_FALLBACK = "{http://schemas.openxmlformats.org/markup-compatibility/2006}Fallback"

# 머리말의 표제 항목 — PDF 추출기와 같은 라벨 집합의 부분집합
_FIELD_RE = re.compile(
    r"^\s*(PROJECT|프로젝트|DOC[ ._]?NO|문서번호|REV(?:ISION)?|리비전|개정|DATE|일자|작성일)"
    r"\s*[:：]\s*(.+?)\s*$", re.I)
_CANON = {"PROJECT": "PROJECT", "프로젝트": "PROJECT",
          "DOC NO": "DOC_NO", "DOCNO": "DOC_NO", "DOC.NO": "DOC_NO", "문서번호": "DOC_NO",
          "REV": "REV", "REVISION": "REV", "리비전": "REV", "개정": "REV",
          "DATE": "DATE", "일자": "DATE", "작성일": "DATE"}
_MAX_PARAS = 4000          # 수백 쪽 문서도 상한 안에서 — 비교는 초안이면 된다
# 한 줄에 여럿: 'DOC NO: SPEC-E-3901    REV: 0' — 첫 라벨만 잡으면 REV가 문서번호 값에 삼켜져 개정해도
# '문서번호 변경'으로 보고되고 Rev 검사가 없었다 (검토38 R4-D)
_LABEL_AT = re.compile(r"(?:(?<=\s)|^)(PROJECT|프로젝트|DOC[ ._]?NO|문서번호|REV(?:ISION)?|리비전|개정|DATE|일자|작성일)"
                       r"\s*[:：]\s*", re.I)
_DATE_HEAD = re.compile(r"^\d{2,4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}\s*일?(?:\s*\d{1,2}:\d{2})?")
_SHORT_REV = re.compile(r"^(?:[A-Za-z0-9][A-Za-z0-9.\-]{0,5}|제?\s*\d{1,2}\s*[차판])$")   # '1차'·'제2판' (검토40 A 중간 4)


def _label_matches(txt: str) -> list:
    """줄의 '라벨:' 자리 — 'DUE DATE:'·'납기 일자:'처럼 꾸밈말이 붙은 날짜 라벨은 라벨이 아니다(값의 일부로 본문에 남는다).
    바닥글 'DOC NO: … DUE DATE: …'의 납기가 표제 DATE 칸이 되어 납기 변경이 '일자만 갱신'으로 접혔다 (검토45 B 차단 Q39·Q41)."""
    return [m for m in _LABEL_AT.finditer(txt)
            if not (_canon(m.group(1)) == "DATE" and date_qualified(txt[:m.start()]))]


def _line_fields(txt: str, anywhere: bool = False) -> list[tuple[str, str]]:
    """줄이 라벨로 시작하면 [(정규 이름, 값)] — 한 줄의 여러 '라벨: 값'을 나눈다. 아니면 [].
    anywhere: 머리글·바닥글처럼 라벨이 줄 가운데 와도 읽는다('SPEC-86  REV: 0' — 검토47 B H58)."""
    ms = _label_matches(txt)
    if not ms or (not anywhere and ms[0].start() != len(txt) - len(txt.lstrip())):
        return []
    out = []
    for k, m in enumerate(ms):
        end = ms[k + 1].start() if k + 1 < len(ms) else len(txt)
        seg = txt[m.end():end]
        # 모르는 라벨('담당: 이름')이 뒤에 오면 값은 그 앞까지 — 'REV: 0   담당: 이름'에서 REV가 담당 칸까지 삼켜 이름만
        # 바뀌어도 거짓 'Rev만 갱신'이 났다 (검토42 A 중간 6). 나머지는 본문으로(_line_rest)
        cut = re.search(r"\s+[A-Za-z가-힣][\w .]{0,24}\s*[:：]", seg)   # 긴 꾸밈말 라벨('DELIVERY DATE:')도 끊는다 (검토46 B 차단)
        canon, val = _canon(m.group(1)), (seg[:cut.start()] if cut else seg).strip()
        if canon == "DATE":
            dm = _DATE_HEAD.match(val)
            if not dm:
                continue                     # 날짜 꼴이 아니면 DATE가 아니다 (검토42 B 차단 2)
            val = dm.group(0).strip()
        if not canon or not val:
            continue
        if canon == "REV":
            # 바닥글 'REV: A  Page 1'의 값은 첫 토큰까지 — 'A  Page 1'로 삼켜 'Rev가 A  Page 1→B  Page 1로'라 했다 (검토51 B 낮음 D07)
            _rv = re.match(r"(\S{1,6})(?=\s{2,}|\s+(?:PAGE|P\.|SHEET|쪽|페이지)\b)", val, re.I)
            if _rv:
                val = _rv.group(1)
        if canon == "REV" and re.search(r"[가-힣]", m.group(1)) and not _SHORT_REV.match(val):
            continue        # 한글 '개정'은 본문 낱말이기도 하다 — '개정: 사양 변경'은 REV가 아니다 (검토39 F2 ①)
        out.append((canon, val))
    return out


def _line_rest(txt: str, taken: set | None = None) -> str:
    """필드로 읽힌 '라벨: 값'을 뺀 나머지('담당: 이름') — 본문 줄로 남겨 그 변경도 보이게.
    taken: 이 줄에서 실제로 필드가 된 이름 — 앞 문단이 이미 차지해 버린 칸('REV: 1')은 본문에 남긴다. 전에는 그 조각까지
    지워 바닥글 REV만 바뀐 변경이 항목 0건이 됐다 (검토45 A 중간 2)."""
    ms = _label_matches(txt)
    if not ms:
        return txt
    parts = [txt[:ms[0].start()]]
    for k, m in enumerate(ms):
        end = ms[k + 1].start() if k + 1 < len(ms) else len(txt)
        seg = txt[m.end():end]
        cut = re.search(r"\s+[A-Za-z가-힣][\w .]{0,24}\s*[:：]", seg)   # 긴 꾸밈말 라벨('DELIVERY DATE:')도 끊는다 (검토46 B 차단)
        head = seg[:cut.start()] if cut else seg
        if taken is not None and _canon(m.group(1)) not in taken:
            parts.append(f"{m.group(0)}{head}")
        elif _canon(m.group(1)) == "DATE":
            dm = _DATE_HEAD.match(head.strip())
            parts.append(head.strip()[dm.end():] if dm else f"{m.group(0)}{head}")   # 날짜 뒤 글자 / 날짜 아님
        if cut:
            parts.append(seg[cut.start():])
    return " ".join(" ".join(parts).split())


def _canon(label: str) -> str | None:
    return _CANON.get(re.sub(r"[ ._]+", " ", label.upper()).strip())


def _docx_parts(z: zipfile.ZipFile):
    """(문단 텍스트 목록, 표 목록) — 표는 [[셀텍스트, ...], ...]."""
    root = ET.fromstring(z.read("word/document.xml"))
    body = root.find(f"{_W}body")
    paras, tables = [], []
    if body is None:
        return paras, tables

    def ptext(p) -> str:
        """문단 자신의 글자 — 안에 든 글상자(w:txbxContent)와 호환용 사본(mc:Fallback)은 빼고. 둘 다 세면 글상자 글자 한 번
        바뀐 것이 바깥 문단 두 번 + 안쪽 문단 두 번, 4건으로 보고됐다 (검토51 B 중간 3)."""
        out: list = []

        def walk(el):
            for ch in el:
                if ch.tag in (f"{_W}txbxContent", _MC_FALLBACK):
                    continue
                if ch.tag == f"{_W}t":
                    out.append(ch.text or "")
                walk(ch)
        walk(p)
        return "".join(out).strip()

    parent = {c: p for p in body.iter() for c in p}

    def in_fallback(el) -> bool:
        q = parent.get(el)
        while q is not None:
            if q.tag == _MC_FALLBACK:
                return True
            q = parent.get(q)
        return False

    def in_textbox(el) -> bool:
        q = parent.get(el)
        while q is not None:
            if q.tag == f"{_W}txbxContent":
                return True
            q = parent.get(q)
        return False

    def in_table(el) -> bool:
        q = parent.get(el)
        while q is not None:
            if q.tag == f"{_W}tbl":
                return True
            q = parent.get(q)
        return False

    # 문단은 어디 있든(표지의 내용 컨트롤 w:sdt 포함) 문서 순서대로 — 단, 표 안
    # 문단은 rows로 가므로 본문에서 뺀다 (양쪽에 있으면 같은 변경이 두 번 잡힌다,
    # 2026-09-02 재검토)
    for p in body.iter(f"{_W}p"):
        if in_table(p) or in_fallback(p):
            continue
        t = ptext(p)
        if t:
            paras.append(f"[글상자] {t}" if in_textbox(p) else t)
    # 표는 모두(중첩 표 포함) 각각 — 바깥 칸의 글자는 안쪽 표의 글자를 뺀다 (안 빼면 안쪽 표의
    # 값 변경이 바깥 칸 변경으로 한 번 더 잡힌다, 2026-09-06 블라인드 3차 31·37)
    def depth(el) -> int:
        d, q = 0, parent.get(el)
        while q is not None:
            if q.tag == f"{_W}tbl":
                d += 1
            q = parent.get(q)
        return d

    def own_ps(tc):
        """칸의 직속 문단(안쪽 표 속 문단 제외)."""
        out = []
        for p in tc.iter(f"{_W}p"):
            q, inner = parent.get(p), False
            while q is not None and q is not tc:
                if q.tag == f"{_W}tbl":
                    inner = True; break
                q = parent.get(q)
            if not inner:
                out.append(p)
        return out
    for tbl in sorted(body.iter(f"{_W}tbl"), key=depth):
        rows = []
        for ri, tr in enumerate(tbl.findall(f"{_W}tr")):
            cells = []
            for tc in tr.findall(f"{_W}tc"):
                txt = " ".join(ptext(p) for p in own_ps(tc)).strip()
                # 가로 병합(w:gridSpan)은 칸 수만큼 펼친다 — 안 펼치면 병합 머리글 'MOTOR(2칸)|RATING(2칸)|REMARK'
                # 아래 값이 열 이름과 어긋나 'kW 3.7→5.5'가 'REMARK: 3.7 → 5.5'로 보고됐다 (검토38 R4-E).
                # 머리글 줄(첫 행)은 같은 이름을 채우고, 값 줄은 빈칸으로 채운다
                span = 1
                pr = tc.find(f"{_W}tcPr")
                gs = pr.find(f"{_W}gridSpan") if pr is not None else None
                if gs is not None:
                    try:
                        span = max(1, min(64, int(gs.get(f"{_W}val") or 1)))
                    except ValueError:
                        span = 1
                cells.append(txt)
                cells.extend([txt if ri == 0 else ""] * (span - 1))
            rows.append(cells)
        tables.append(rows)
    # 머리글·바닥글 — 문서번호·개정·대외비 표시가 여기 있다 (2026-09-06 블라인드 3차 34·38)
    for name in sorted(z.namelist()):
        if name.startswith("word/header") or name.startswith("word/footer"):
            try:
                hf = ET.fromstring(z.read(name))
            except ET.ParseError:
                continue
            kind = "머리글" if "header" in name else "바닥글"
            for p in hf.iter(f"{_W}p"):
                t = ptext(p)
                if t:
                    paras.append(f"[{kind}] {t}")
    # 각주·미주 — 읽지 않아 각주만 고친 날 '내용 변경 없음 — 다시 저장되기만'이라 단언했다 (검토51 B 중간 2, 원칙 4·5).
    # 구분선(separator)·이어짐 표시는 글자가 없어 저절로 빠진다
    for name, kind in (("word/footnotes.xml", "각주"), ("word/endnotes.xml", "미주")):
        if name not in z.namelist():
            continue
        try:
            fe = ET.fromstring(z.read(name))
        except ET.ParseError:
            continue
        for note in fe:
            if str(note.get(f"{_W}type") or "") in ("separator", "continuationSeparator", "continuationNotice"):
                continue
            t = " ".join(x for x in (ptext(p) for p in note.iter(f"{_W}p")) if x)
            if t:
                paras.append(f"[{kind}] {t}")
    return paras, tables


def _hwpx_parts(z: zipfile.ZipFile):
    paras, tables = [], []
    names = sorted(n for n in z.namelist()
                   if n.startswith("Contents/section") and n.endswith(".xml"))
    for n in names:
        root = ET.fromstring(z.read(n))
        # 표 안 문단은 표(Row)로 읽으므로 본문에서 뺀다 — 표 값 하나가 행 변경과 글자 변경 두 번
        # 보고되던 것 (2026-09-06 블라인드 양식 시험 48)
        # (HWPX는 표가 문단 안에 들어간다 — 바깥 문단의 글자를 모을 때 표 안 글자는 뺀다)
        in_tbl: set = set()
        tbl_text: set = set()
        for tbl in root.iter(f"{_HP}tbl"):
            for p in tbl.iter(f"{_HP}p"):
                in_tbl.add(id(p))
            for t in tbl.iter(f"{_HP}t"):
                tbl_text.add(id(t))
        # 머리글·바닥글(hp:header/hp:footer 안 subList)은 따로 표시하고 바깥 문단에서 뺀다
        hf_ps: dict = {}
        hf_text: set = set()
        for kind, tag in (("머리글", f"{_HP}header"), ("바닥글", f"{_HP}footer")):
            for h in root.iter(tag):
                for p in h.iter(f"{_HP}p"):
                    hf_ps[id(p)] = kind
                for t in h.iter(f"{_HP}t"):
                    hf_text.add(id(t))
        for p in root.iter(f"{_HP}p"):
            if id(p) in in_tbl:
                continue
            if id(p) in hf_ps:
                txt = "".join(t.text or "" for t in p.iter(f"{_HP}t")).strip()
                if txt:
                    paras.append(f"[{hf_ps[id(p)]}] {txt}")
                continue
            txt = "".join(t.text or "" for t in p.iter(f"{_HP}t")
                          if id(t) not in tbl_text and id(t) not in hf_text).strip()
            if txt:
                paras.append(txt)
        # 표(중첩 포함) — 칸의 글자는 안쪽 표 글자를 뺀다 (2026-09-06 블라인드 3차 45)
        parent = {c: p for p in root.iter() for c in p}

        def cell_text(tc) -> str:
            inner_t: set = set()
            for tb2 in tc.iter(f"{_HP}tbl"):
                for t in tb2.iter(f"{_HP}t"):
                    inner_t.add(id(t))
            return " ".join(
                "".join(t.text or "" for t in p.iter(f"{_HP}t") if id(t) not in inner_t).strip()
                for p in tc.iter(f"{_HP}p")).strip()
        for tbl in root.iter(f"{_HP}tbl"):
            rows = []
            for tr in tbl.iter(f"{_HP}tr"):
                # 직계 행만 — 안쪽 표의 행이 바깥 표 행으로 섞이지 않게
                q = parent.get(tr)
                while q is not None and q.tag != f"{_HP}tbl":
                    q = parent.get(q)
                if q is not tbl:
                    continue
                cells = []
                for tc in tr.iter(f"{_HP}tc"):
                    q2 = parent.get(tc)
                    while q2 is not None and q2.tag != f"{_HP}tr":
                        q2 = parent.get(q2)
                    if q2 is not tr:
                        continue
                    cells.append(cell_text(tc))
                rows.append(cells)
            tables.append(rows)
    return paras, tables


def _header_of(tbl: list) -> tuple[list, int]:
    """(열 이름 목록, 값이 시작하는 행 번호). 병합 머리글(첫 행에 같은 이름이 이웃해 되풀이 — gridSpan을 펼친
    것)이고 둘째 행이 숫자 없는 짧은 이름들이면 두 줄 머리글이다 — 'RATING kW'처럼 합친다. 같은 이름이 남으면
    뒤의 것에 번호를 붙인다(안 붙이면 값이 한 열로 덮였다) (검토38 R4-E)."""
    top = [h or "" for h in tbl[0]]
    merged = any(top[i] and top[i] == top[i + 1] for i in range(len(top) - 1))
    start = 1
    names = list(top)
    if merged and len(tbl) >= 3:
        sub = [c or "" for c in tbl[1]] + [""] * max(0, len(top) - len(tbl[1]))
        # 하위 이름은 대부분 병합 그룹 아래에 놓인다 — 숫자 없는 짧은 첫 데이터 행('PUMP|ABB|-')을 머리글로 삼켜 그 행이
        # 사라지고 열 이름이 'MOTOR PUMP'가 됐다 (검토41 S4 중간 4·S2 중간 2). XLSX와 같은 규칙
        under = sum(1 for j, c in enumerate(sub) if c and j < len(top)
                    and ((j > 0 and top[j - 1] == top[j]) or (j + 1 < len(top) and top[j + 1] == top[j])))
        # 병합 안 된 열(세로로 합친 'REMARK') 아래는 비어 있어야 한다 — '-'·값이 있으면 데이터 행
        lone_filled = any(c for j, c in enumerate(sub) if j < len(top)
                          and not ((j > 0 and top[j - 1] == top[j]) or (j + 1 < len(top) and top[j + 1] == top[j])))
        if any(sub) and all(len(c) <= 20 and not re.search(r"\d", c) for c in sub if c) \
                and under >= 0.6 * sum(1 for c in sub if c) and not lone_filled:
            names = [(f"{t} {s}" if t and s and t != s else (s or t)) for t, s in zip(top, sub)]
            start = 2
    out, seen = [], {}
    for ci, h in enumerate(names):
        h = h or f"열{ci + 1}"
        seen[h] = seen.get(h, 0) + 1
        out.append(h if seen[h] == 1 else f"{h} #{seen[h]}")
    return out, start


def _saved_by(path: Path) -> str | None:
    """docProps/core.xml의 마지막 저장자(cp:lastModifiedBy) — 읽기 전용으로 연다."""
    try:
        with zipfile.ZipFile(path) as z:
            root = ET.fromstring(z.read("docProps/core.xml"))
    except (KeyError, OSError, zipfile.BadZipFile, ET.ParseError):
        return None
    for el in root.iter():
        if el.tag.endswith("}lastModifiedBy") and (el.text or "").strip():
            return el.text.strip()[:60]
    return None


def extract(path: Path) -> Document:
    path = Path(path)
    ext = path.suffix.lower()
    with zipfile.ZipFile(path) as z:            # 읽기 전용 열기
        if ext == ".hwpx":
            paras, tables = _hwpx_parts(z)
            doc_type = "hwpx"
        else:
            paras, tables = _docx_parts(z)
            doc_type = "docx"

    fields: dict[str, Field] = {}
    body: list[TextLine] = []
    # 본문 문단을 먼저, 머리글·바닥글을 뒤에 — HWPX는 머리글·바닥글이 본문보다 앞에 나와 둘째 칸 규칙(REV#2)이 거꾸로
    # 되어 표지 REV만 올린 날 거짓 'Rev 미갱신'이 났다 (검토47 A 중간 6). 문단 번호는 원래 자리 그대로
    _order = sorted(enumerate(paras[:_MAX_PARAS], start=1),
                    key=lambda it: bool(re.match(r"^\[(?:머리글|바닥글)\]", it[1] or "")))
    for i, txt in _order:
        if not txt:
            continue
        where = f"문단 {i}"
        # 머리글·바닥글 줄은 '[바닥글] ' 머리표를 떼고 본다 — 'DOC NO: … REV: 0 DATE: …' 바닥글 한 줄의 Rev를 못 읽어
        # 본문을 고쳐도 'Rev 미갱신'이 없었다(같은 꼴 PDF는 읽음) (검토44 B X06c)
        _hf = re.match(r"^\[(?:머리글|바닥글)\]\s*", txt)
        core = txt[_hf.end():] if _hf else txt
        pairs = [(c, v) for c, v in _line_fields(core) if c not in fields]
        if _hf:
            # 머리글·바닥글 줄은 앞 문단이 이미 차지한 칸도 **둘째 칸**(REV#2)으로 읽는다 — 본문 글자로 남기면 표지와 바닥글 Rev를
            # 함께 올린 정상 개정에서 'Rev만 갱신'이 사라지고, 바닥글만 올리면 '내용 변경 → Rev 미갱신'이 됐다 (검토46 A 중간 2)
            pairs = []
            for c, v in _line_fields(core, anywhere=True):
                k, n = c, 2
                while k in fields:
                    k, n = f"{c}#{n}", n + 1
                pairs.append((k, v))
        if pairs:
            for c, v in pairs:
                # 바닥글·머리글에서 읽은 칸은 그 자리로 — 바닥글 REV 근거가 '머리말(문단 8)'로 나왔다 (검토46 C 중간 3)
                _place = ("바닥글" if "바닥글" in txt[:_hf.end()] else "머리글") if _hf else "머리말"
                fields[c] = Field(c.split("#", 1)[0] if "#" not in c else c, v, f"{_place}({where})")
            rest = _line_rest(core, {c.split("#", 1)[0] for c, _v in pairs})
            if re.search(r"[A-Za-z가-힣0-9]{2,}", rest):
                body.append(TextLine((txt[:_hf.end()] if _hf else "") + rest, where))
        else:
            body.append(TextLine(txt, where))

    rows: list[Row] = []
    for ti, tbl in enumerate(tables, start=1):
        if len(tbl) < 2:
            continue
        # 두 칸짜리 표(회의록 머리: '일시 | 2026-09-04 14:00')는 첫 칸이 항목 이름 — 첫 행을
        # 머리글로 보면 값이 열 이름이 되어 엉킨다 (2026-09-06 블라인드 2차 29)
        first = [c or "" for c in tbl[0]] + ["", ""]
        headerish = (len(first[0]) <= 12 and len(first[1]) <= 12
                     and not any(ch.isdigit() for ch in first[0] + first[1]))
        if (all(len([c for c in r if c]) <= 2 for r in tbl) and max(len(r) for r in tbl) == 2
                and not headerish):
            for ri, cells in enumerate(tbl, start=1):
                if not any(cells):
                    continue
                k = "".join((cells[0] or "").split()) or f"{ti}-{ri}"
                rows.append(Row(k, {"값": cells[1] if len(cells) > 1 else ""}, f"표{ti} 행{ri}"))
            continue
        header, start = _header_of(tbl)
        for ri, cells in enumerate(tbl[start:], start=start + 1):
            if not any(cells):
                continue
            values = {header[ci]: c for ci, c in enumerate(cells) if ci < len(header)}
            key = cells[0] if cells and cells[0] else f"{ti}-{ri}"
            rows.append(Row(key, values, f"표{ti} 행{ri}"))

    notes: list[str] = []
    if not body and not rows:
        notes.append("본문 텍스트가 없습니다 — 그림·개체로만 된 문서이거나 빈 문서입니다. "
                     "파일 수준(해시) 변경만 감지합니다.")
    return Document(doc_type=doc_type, path=str(path), fields=fields, rows=rows,
                    raw_texts=body, notes=notes, saved_by=_saved_by(path) if doc_type == "docx" else None)
