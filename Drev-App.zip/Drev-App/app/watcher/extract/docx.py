# -*- coding: utf-8 -*-
"""DOCX(Word)·HWPX(한글) 추출기 — 표준 라이브러리만 (2026-09-02).

배경: .docx는 검사 대상이면서 내용 추출이 없어, 워드로 된 사양서·견적서·계약서가
파일명에 단서가 없으면 전부 "문서"로 떨어졌다 (회사 실사용: "문서, 사양서, 견적서
등등 제대로 구분이 안 되는 거 같아"). 둘 다 zip 안의 XML이라 zipfile + ElementTree로
읽는다. 읽기 전용 (PRINCIPLE 2).

- 문단 → TextLine("문단 N")   - 표 → Row(첫 행이 머리글)   - 머리말의 '라벨: 값' → Field
- .hwp(구형 바이너리)는 지원하지 않는다 — 파일 수준 감지만. notes에 남기지 않는다
  (추출기가 호출되지 않으므로).
"""
from __future__ import annotations

import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from watcher.extract.base import Document, Field, Row, TextLine, date_qualified

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"
_MC_FALLBACK = "{http://schemas.openxmlformats.org/markup-compatibility/2006}Fallback"
# 워드 수식(m:oMath) — 식 글자(m:t)를 안 읽어 계산서의 식 변경이 '내용 변경 없음'이 됐다 (재검토 2026-10-28 R1-10)
_M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"

# 머리말의 표제 항목 — PDF 추출기와 같은 라벨 집합의 부분집합
_FIELD_RE = re.compile(
    r"^\s*(PROJECT|프로젝트|DOC[ ._]?NO|문서번호|REV(?:ISION)?|리비전|개정|DATE|일자|작성일)"
    r"\s*[:：]\s*(.+?)\s*$", re.I)
_CANON = {"PROJECT": "PROJECT", "프로젝트": "PROJECT",
          "DOC NO": "DOC_NO", "DOCNO": "DOC_NO", "DOC.NO": "DOC_NO", "문서번호": "DOC_NO",
          "REV": "REV", "REVISION": "REV", "리비전": "REV", "개정": "REV",
          "DATE": "DATE", "일자": "DATE", "작성일": "DATE"}
_MAX_PARAS = 4000          # 수백 쪽 문서도 상한 안에서 — 비교는 초안이면 된다
# 한 줄에 여럿: 'DOC NO: SPEC-E-3901    REV: 0' — 첫 라벨만 잡으면 REV가 문서번호 값에 삼켜져 개정해도
# '문서번호 변경'으로 보고되고 Rev 검사가 없었다 (검토38 R4-D)
_LABEL_AT = re.compile(r"(?:(?<=\s)|^)(PROJECT|프로젝트|DOC[ ._]?NO|문서번호|REV(?:ISION)?|리비전|개정|DATE|일자|작성일)"
                       r"\s*[:：]\s*", re.I)
_DATE_HEAD = re.compile(r"^\d{2,4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}\s*일?(?:\s*\d{1,2}:\d{2})?")
_SHORT_REV = re.compile(r"^(?:[A-Za-z0-9][A-Za-z0-9.\-]{0,5}|제?\s*\d{1,2}\s*[차판])$")   # '1차'·'제2판' (검토40 A 중간 4)


_HDR_LABEL = re.compile(r"^\s*(PROJECT|프로젝트|DOC[ ._]?NO\.?|문서번호|REV(?:ISION)?\.?|리비전|개정|DATE|일자|작성일)"
                        r"\s*[:：]?\s*$", re.I)
# 머리글·바닥글의 콜론 없는 Rev('SPEC-E-071  Rev. A', 'Rev B | Page 1') — PDF 바닥글은 검토52 C에서 받았는데 문서류는
# 콜론이 있어야만 읽어, 본문을 고쳐도 Rev 미갱신이 없었다 (경우100 B11). 값은 짧은 토큰 하나, 뒤는 끝·두 칸 공백·쪽 표식
_COLONLESS_REV = re.compile(
    r"(?:(?<=\s)|^)(REV(?:ISION)?)\.?\s+([A-Z0-9]{1,3})(?=\s*$|\s{2,}|\s*[|/]|\s+(?:PAGE|P\.|SHEET|쪽|페이지)\b)", re.I)
# 머리글·바닥글의 '버전 1.1'·'Version 2.0'·'Ver. 3' — 개정이력 표의 '버전' 칸은 Rev로 읽는데 머리글 줄은 글자로 남아, 버전만 올린
# 날 머리글 글자 변경이 '내용 변경'이 되어 거꾸로 'Rev 미갱신'이 났다 (대량 시험 DOC C3, 2026-10-20). 머리글·바닥글에서만(본문의
# '펌웨어 버전: 1.2'는 사양 값이다), 값은 숫자 버전 꼴 하나, 뒤는 끝·두 칸 공백·쪽 표식
_VERSION_HF = re.compile(
    r"(?:(?<=\s)|^)(버전|VERSION|VER\.?)\s*[:：]?\s*([Vv]?\d{1,2}(?:\.\d{1,2}){0,2})"
    r"(?=\s*$|\s{2,}|\s*[|/]|\s+(?:PAGE|P\.|SHEET|쪽|페이지)\b)", re.I)


# 머리글 표의 '칸 이름'다운 것 — 아는 라벨 + 쪽·제목·작성자 같은 흔한 칸 (2칸 표를 가로로 읽을지 가를 때)
_HDR_LABEL_X = re.compile(r"^\s*(PROJECT|프로젝트|DOC[ ._]?NO\.?|문서번호|REV(?:ISION)?\.?|리비전|개정|DATE|일자|작성일|"
                          r"PAGE|SHEET|쪽|페이지|TITLE|제목|문서명|작성자?|검토자?|승인자?|DRAWN|CHECKED|APPROVED)\s*[:：]?\s*$", re.I)
# 콜론 없는 Rev 앞에 이런 표지가 있으면 문서 Rev가 아니라 양식·규격의 개정이다 — 'Form QP-07 Rev 3'·'IEC 60204-1 Rev 1'
# (검토53 A 중간 4)
_FORM_REV_BEFORE = re.compile(r"(?i)(?:^|[\s(\[])(?:FORM|양식|서식|QP-?\d*|F-\d+|IEC|ISO|KS|EN|ASTM|JIS|DIN|ANSI|IEEE|NFPA|UL)"
                              r"(?=[\s\-:.]|$)|(?<![\d\-])\d{5}-\d")   # 'IEC 60204-1'의 번호 꼴 (4자리는 연도라 아님, 검토53 I)


def _header_table_line(grid: list) -> str:
    """머리글 표 → '라벨: 값  라벨: 값' 한 줄. 위 행이 라벨·아래 행이 값인 표, 또는 '라벨 | 값' 두 칸 행.
    아는 라벨(REV·DOC NO·DATE…)이 하나도 없으면 ''(평소대로 칸마다 문단)."""
    grid = [r for r in grid if any(r)]
    pairs: list = []

    def label_row(r) -> bool:
        return any(_HDR_LABEL.match(c or "") for c in r) and all(c and len(c) <= 20 and not re.search(r"\d", c) for c in r)
    two_col = bool(grid) and all(len(r) == 2 and all(r) for r in grid)
    top_all_labels = any(len(r) >= 2 and all(_HDR_LABEL.match(c or "") for c in r) for r in grid)   # 'DOC NO | REV' 행
    # 세로('라벨 | 값') 읽기는 첫 칸이 (2행이면 둘 다, 더 많으면 거의 다) 라벨일 때만 — 2행 표 'REV | PAGE / B | 1'이 세로로
    # 읽혀 REV='PAGE'가 됐다 (검토53 E 중간 6)
    # 2칸 표: 둘째 칸 가운데 라벨(PAGE·제목·작성자 포함)이 있으면 가로('REV | PAGE / B | 1'), 없으면 세로('REV | B / PAGE | 1')
    # — 첫 칸이 모두 아는 라벨이어야 세로로 읽게 했더니 'REV | B / PAGE | 1'이 REV='PAGE'가 됐다 (검토53 I 중간 2)
    if two_col and not top_all_labels and not any(_HDR_LABEL_X.match(r[1]) for r in grid) \
            and sum(1 for r in grid if _HDR_LABEL.match(r[0])) >= 1:
        pairs = [(r[0], r[1]) for r in grid]          # '라벨 | 값' 행들 (첫 칸이 거의 다 라벨)
    else:
        # 라벨 행과 바로 아래 값 행 — 위에 병합 제목 행('장비 사양서')이 있어도 (검토53 B D03: 3행 표의 REV를 못 읽어
        # Rev 미갱신이 꺼졌다)
        for i in range(len(grid) - 1):
            if len(grid[i]) == len(grid[i + 1]) and label_row(grid[i]) and not label_row(grid[i + 1]):
                pairs = [(a, b) for a, b in zip(grid[i], grid[i + 1]) if a and b]
                break
    # 값 칸이 또 라벨이면(빈 양식의 'REV | DATE' 두 줄) 짝이 아니다 (검토53 A 낮음 8)
    pairs = [(a, b) for a, b in pairs if not _HDR_LABEL.match(b)
             and not (_canon(re.sub(r"[:：.]+$", "", a.strip())) == "REV" and not _SHORT_REV.match(b.strip()))]
    if not pairs or not any(_HDR_LABEL.match(a) for a, _b in pairs):
        return ""
    return "  ".join(f"{re.sub(r'[:：.]+$', '', a.strip())}: {b.strip()}" for a, b in pairs)


def _label_matches(txt: str) -> list:
    """줄의 '라벨:' 자리 — 'DUE DATE:'·'납기 일자:'처럼 꾸밈말이 붙은 날짜 라벨은 라벨이 아니다(값의 일부로 본문에 남는다).
    바닥글 'DOC NO: … DUE DATE: …'의 납기가 표제 DATE 칸이 되어 납기 변경이 '일자만 갱신'으로 접혔다 (검토45 B 차단 Q39·Q41)."""
    return [m for m in _LABEL_AT.finditer(txt)
            if not (_canon(m.group(1)) == "DATE" and date_qualified(txt[:m.start()]))]


def _line_fields(txt: str, anywhere: bool = False) -> list[tuple[str, str]]:
    """줄이 라벨로 시작하면 [(정규 이름, 값)] — 한 줄의 여러 '라벨: 값'을 나눈다. 아니면 [].
    anywhere: 머리글·바닥글처럼 라벨이 줄 가운데 와도 읽는다('SPEC-86  REV: 0' — 검토47 B H58)."""
    ms = _label_matches(txt)
    if not ms or (not anywhere and ms[0].start() != len(txt) - len(txt.lstrip())):
        return []
    out = []
    for k, m in enumerate(ms):
        end = ms[k + 1].start() if k + 1 < len(ms) else len(txt)
        seg = txt[m.end():end]
        # 모르는 라벨('담당: 이름')이 뒤에 오면 값은 그 앞까지 — 'REV: 0   담당: 이름'에서 REV가 담당 칸까지 삼켜 이름만
        # 바뀌어도 거짓 'Rev만 갱신'이 났다 (검토42 A 중간 6). 나머지는 본문으로(_line_rest)
        cut = re.search(r"\s+[A-Za-z가-힣][\w .]{0,24}\s*[:：]", seg)   # 긴 꾸밈말 라벨('DELIVERY DATE:')도 끊는다 (검토46 B 차단)
        canon, val = _canon(m.group(1)), (seg[:cut.start()] if cut else seg).strip()
        # '|' 뒤는 다른 칸이다 — 'REV: B | Page 1'의 Rev가 'B | Page 1', 'DOC NO: SPEC-1 | REV'의 번호가 'SPEC-1 |'이
        # 됐다 (검토53 A 중간 3·B D05). Rev는 ' / Sheet 1'도
        val = re.split(r"\s*\|", val, maxsplit=1)[0].strip()
        if canon == "REV":
            val = re.split(r"\s+/\s*", val, maxsplit=1)[0].strip()
        if canon == "DATE":
            dm = _DATE_HEAD.match(val)
            if not dm:
                continue                     # 날짜 꼴이 아니면 DATE가 아니다 (검토42 B 차단 2)
            val = dm.group(0).strip()
        if not canon or not val:
            continue
        if canon == "REV":
            # 바닥글 'REV: A  Page 1'의 값은 첫 토큰까지 — 'A  Page 1'로 삼켜 'Rev가 A  Page 1→B  Page 1로'라 했다 (검토51 B 낮음 D07)
            _rv = re.match(r"(\S{1,6})(?=\s{2,}|\s+(?:PAGE|P\.|SHEET|쪽|페이지)\b)", val, re.I)
            if _rv:
                val = _rv.group(1)
        if canon == "REV" and re.search(r"[가-힣]", m.group(1)) and not _SHORT_REV.match(val):
            continue        # 한글 '개정'은 본문 낱말이기도 하다 — '개정: 사양 변경'은 REV가 아니다 (검토39 F2 ①)
        out.append((canon, val))
    return out


def _line_rest(txt: str, taken: set | None = None) -> str:
    """필드로 읽힌 '라벨: 값'을 뺀 나머지('담당: 이름') — 본문 줄로 남겨 그 변경도 보이게.
    taken: 이 줄에서 실제로 필드가 된 이름 — 앞 문단이 이미 차지해 버린 칸('REV: 1')은 본문에 남긴다. 전에는 그 조각까지
    지워 바닥글 REV만 바뀐 변경이 항목 0건이 됐다 (검토45 A 중간 2)."""
    ms = _label_matches(txt)
    if not ms:
        return txt
    parts = [txt[:ms[0].start()]]
    for k, m in enumerate(ms):
        end = ms[k + 1].start() if k + 1 < len(ms) else len(txt)
        seg = txt[m.end():end]
        cut = re.search(r"\s+[A-Za-z가-힣][\w .]{0,24}\s*[:：]", seg)   # 긴 꾸밈말 라벨('DELIVERY DATE:')도 끊는다 (검토46 B 차단)
        head = seg[:cut.start()] if cut else seg
        if taken is not None and _canon(m.group(1)) not in taken:
            parts.append(f"{m.group(0)}{head}")
        elif _canon(m.group(1)) == "DATE":
            dm = _DATE_HEAD.match(head.strip())
            parts.append(head.strip()[dm.end():] if dm else f"{m.group(0)}{head}")   # 날짜 뒤 글자 / 날짜 아님
        if cut:
            parts.append(seg[cut.start():])
    return " ".join(" ".join(parts).split())


def _canon(label: str) -> str | None:
    return _CANON.get(re.sub(r"[ ._]+", " ", label.upper()).strip())


_STRICT_NS = ((rb"http://purl.oclc.org/ooxml/wordprocessingml/main", rb"http://schemas.openxmlformats.org/wordprocessingml/2006/main"),
              (rb"http://purl.oclc.org/ooxml/officeDocument/relationships",
               rb"http://schemas.openxmlformats.org/officeDocument/2006/relationships"),
              (rb"http://purl.oclc.org/ooxml/officeDocument/math", rb"http://schemas.openxmlformats.org/officeDocument/2006/math"))


def _wxml(z: zipfile.ZipFile, name: str):
    """워드 XML 한 부분 — 'Strict Open XML'로 저장한 문서는 이름공간이 달라 본문이 통째로 안 읽혀 '빈 문서'로 비교됐다
    (검토66 C8). 같은 뜻의 일반 이름공간으로 맞춰 읽는다."""
    data = z.read(name)
    for strict, normal in _STRICT_NS:
        data = re.sub(re.escape(strict), normal, data)
    return ET.fromstring(data)


_HF_TYPE = {"default": "기본", "even": "짝수 쪽", "first": "첫 쪽"}


def _hf_types(z: zipfile.ZipFile, root) -> dict:
    """머리글·바닥글 부품 → 쪽 종류('기본'·'짝수 쪽'·'첫 쪽') — 종류가 둘 이상일 때만. 기본 머리글만 Rev를 올리고 짝수 쪽은 A로
    남긴 문서가 'Rev B' 하나로만 보였다 (검토71 R4 중간 7)."""
    out = _hf_refs(z, root)
    kinds = {v for k, v in out.items() if "header" in k} | {v for k, v in out.items() if "footer" in k}
    return out if len(kinds) > 1 else {}


def _hf_zones(z: zipfile.ZipFile, root) -> dict:
    """{'머리글': [쪽 종류…], '바닥글': [쪽 종류…]} — 문서가 참조하는 머리글·바닥글 부품의 종류 (뒤흔들기 DOC C7)."""
    out = _hf_refs(z, root)
    return {zone: sorted({v for k, v in out.items() if part in k}) for zone, part in (("머리글", "header"), ("바닥글", "footer"))}


def _hf_refs(z: zipfile.ZipFile, root) -> dict:
    """머리글·바닥글 부품 이름 → 쪽 종류 — 본문(sectPr)이 참조하는 것 모두."""
    try:
        rels = ET.fromstring(z.read("word/_rels/document.xml.rels"))
    except (KeyError, ET.ParseError):
        return {}
    tgt = {r.get("Id"): "word/" + re.sub(r"^/?(?:word/)?", "", str(r.get("Target") or "")) for r in rels}
    out: dict = {}
    _R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    for tag in ("headerReference", "footerReference"):
        for ref in root.iter(f"{_W}{tag}"):
            t, rid = ref.get(f"{_W}type"), ref.get(f"{_R}id")
            if t in _HF_TYPE and rid in tgt:
                out.setdefault(tgt[rid], _HF_TYPE[t])
    return out


def _grid_text_like(widths: list) -> bool:
    """행마다 칸 수 목록 → 한 행짜리이거나 모든 행이 한 칸인 표인가 (뒤흔들기 DOC C2·C3)."""
    widths = [w for w in widths if w > 0]
    return bool(widths) and (len(widths) == 1 or max(widths) == 1)


def _text_like_table(tbl) -> bool:
    """DOCX 표(w:tbl)가 글처럼 읽을 표인가 — 직속 행·칸만 센다(안쪽 표는 따로)."""
    return _grid_text_like([len(tr.findall(f"{_W}tc")) for tr in tbl.findall(f"{_W}tr")])


def _docx_parts(z: zipfile.ZipFile, hf_kinds: dict | None = None, zones: dict | None = None):
    """(문단 텍스트 목록, 표 목록) — 표는 [[셀텍스트, ...], ...]. hf_kinds를 주면 {문단 번호(0부터): 쪽 종류}를, zones를 주면
    머리글·바닥글 사본 종류(_hf_zones)를 채운다."""
    root = _wxml(z, "word/document.xml")
    if zones is not None:
        zones.update(_hf_zones(z, root))
    body = root.find(f"{_W}body")
    paras, tables = [], []
    if body is None:
        return paras, tables

    def ptext(p) -> str:
        """문단 자신의 글자 — 안에 든 글상자(w:txbxContent)와 호환용 사본(mc:Fallback)은 빼고. 둘 다 세면 글상자 글자 한 번
        바뀐 것이 바깥 문단 두 번 + 안쪽 문단 두 번, 4건으로 보고됐다 (검토51 B 중간 3)."""
        out: list = []

        def walk(el):
            for ch in el:
                # 변경 추적의 '옮겨 간 원래 자리'(w:moveFrom)는 지워진 글자다 — 읽으면 이동을 승인만 하고 저장한 문서가 '문단 삭제'와
                # 거짓 Rev 미갱신이 됐다 (검토66 C5). w:del 안은 w:delText라 원래 안 읽힌다
                if ch.tag in (f"{_W}txbxContent", _MC_FALLBACK, f"{_W}moveFrom"):
                    continue
                if ch.tag in (f"{_W}t", f"{_M}t"):
                    out.append(ch.text or "")
                elif ch.tag == f"{_M}oMath":
                    out.append(" ")      # 식은 앞뒤 글과 띄어 제자리에 — 끝의 띄어쓰기는 아래에서 하나로 접힌다
                    walk(ch)
                    out.append(" ")
                    continue
                elif ch.tag in (f"{_W}br", f"{_W}cr", f"{_W}tab"):
                    out.append(" ")      # 줄바꿈·탭이 빠져 '서울 공장' + '납기: …'가 '서울 공장납기:'로 붙었다 (검토61 D37)
                walk(ch)
        walk(p)
        return re.sub(r" {2,}", " ", "".join(out)).strip()

    parent = {c: p for p in body.iter() for c in p}

    def in_fallback(el) -> bool:
        q = parent.get(el)
        while q is not None:
            if q.tag == _MC_FALLBACK:
                return True
            q = parent.get(q)
        return False

    def in_textbox(el) -> bool:
        q = parent.get(el)
        while q is not None:
            if q.tag == f"{_W}txbxContent":
                return True
            q = parent.get(q)
        return False

    # 한 행짜리 표·한 열짜리 표는 표가 아니라 글이다 — 문단을 1칸 표 안에 넣으면 그 글이 '삭제'로만 보였고(1행 표는 통째로
    # 버렸다), 그 칸 글을 고쳐도 못 잡았다(원칙 5). 이웃 두 문단을 2행 1열 표로 묶으면 '문단 삭제 2 + 표 행 추가'로 갈렸다
    # (뒤흔들기 DOC C2·C3, 2026-10-20). 그런 표의 칸 문단은 제자리 문단으로 읽는다
    text_tbls = {t for t in body.iter(f"{_W}tbl") if not in_fallback(t) and _text_like_table(t)}

    def _nearest_tbl(el):
        """위로 올라가며 글상자보다 먼저 만나는 표 — 없으면 None(본문 문단·글상자 문단). 표 칸 속 글상자 문단은 None(본문
        '[글상자]'), 글상자 속 표의 문단은 그 표(표가 맡는다)."""
        q = parent.get(el)
        while q is not None:
            if q.tag == f"{_W}txbxContent":
                return None
            if q.tag == f"{_W}tbl":
                return q
            q = parent.get(q)
        return None

    # 문단은 어디 있든(표지의 내용 컨트롤 w:sdt 포함) 문서 순서대로 — 단, 표 안
    # 문단은 rows로 가므로 본문에서 뺀다 (양쪽에 있으면 같은 변경이 두 번 잡힌다,
    # 2026-09-02 재검토)
    for p in body.iter(f"{_W}p"):
        # 표 안이라도 글상자 문단은 본문 '[글상자]'로 — 칸 글자에서는 빼므로 여기서 안 받으면 사라진다 (검토52 C 중간 5)
        _nt = _nearest_tbl(p)
        if (_nt is not None and _nt not in text_tbls) or in_fallback(p):
            continue
        t = ptext(p)
        if t:
            # 글처럼 읽는 표의 칸 문단은 그 표가 글상자 안에 있어도 머리표 없이 — 표를 글상자에 넣는 것은 자리 옮김이다(보통 표의
            # 행도 글상자 표시가 없다). 붙이면 1칸 표를 글상자로 옮기기만 해도 '글자 변경'이 됐다 (뒤흔들기 DOC, 2026-10-20)
            paras.append(f"[글상자] {t}" if in_textbox(p) and _nt is None else t)
    # 표는 모두(중첩 표 포함) 각각 — 바깥 칸의 글자는 안쪽 표의 글자를 뺀다 (안 빼면 안쪽 표의
    # 값 변경이 바깥 칸 변경으로 한 번 더 잡힌다, 2026-09-06 블라인드 3차 31·37)
    def depth(el) -> int:
        d, q = 0, parent.get(el)
        while q is not None:
            if q.tag == f"{_W}tbl":
                d += 1
            q = parent.get(q)
        return d

    def own_ps(tc):
        """칸의 직속 문단(안쪽 표 속 문단 제외). 칸 속 글상자(와 그 호환 사본) 문단도 뺀다 — 칸 글자에 두 번 붙어
        '24VDC ※ 예비 1개 포함 ※ 예비 1개 포함'이 됐다 (검토52 C 중간 5)."""
        out = []
        for p in tc.iter(f"{_W}p"):
            q, inner = parent.get(p), False
            while q is not None and q is not tc:
                if q.tag in (f"{_W}tbl", f"{_W}txbxContent", _MC_FALLBACK):
                    inner = True; break
                q = parent.get(q)
            if not inner:
                out.append(p)
        return out
    for tbl in sorted(body.iter(f"{_W}tbl"), key=depth):
        if in_fallback(tbl) or tbl in text_tbls:
            continue                 # 글상자 속 표의 호환 사본 — 같은 표가 표1·표2로 두 번 잡혔다 (검토52 C 중간 5)
        rows = []
        for ri, tr in enumerate(tbl.findall(f"{_W}tr")):
            cells = []
            for tc in tr.findall(f"{_W}tc"):
                txt = " ".join(ptext(p) for p in own_ps(tc)).strip()
                # 가로 병합(w:gridSpan)은 칸 수만큼 펼친다 — 안 펼치면 병합 머리글 'MOTOR(2칸)|RATING(2칸)|REMARK'
                # 아래 값이 열 이름과 어긋나 'kW 3.7→5.5'가 'REMARK: 3.7 → 5.5'로 보고됐다 (검토38 R4-E).
                # 머리글 줄(첫 행)은 같은 이름을 채우고, 값 줄은 빈칸으로 채운다
                span = 1
                pr = tc.find(f"{_W}tcPr")
                gs = pr.find(f"{_W}gridSpan") if pr is not None else None
                if gs is not None:
                    try:
                        span = max(1, min(64, int(gs.get(f"{_W}val") or 1)))
                    except ValueError:
                        span = 1
                cells.append(txt)
                cells.extend([txt if ri == 0 else ""] * (span - 1))
            rows.append(cells)
        tables.append(rows)
    # 머리글·바닥글 — 문서번호·개정·대외비 표시가 여기 있다 (2026-09-06 블라인드 3차 34·38)
    _types = _hf_types(z, root)
    for name in sorted(z.namelist()):
        if name.startswith("word/header") or name.startswith("word/footer"):
            _n0 = len(paras)
            try:
                hf = _wxml(z, name)
            except ET.ParseError:
                continue
            kind = "머리글" if "header" in name else "바닥글"
            # 머리글 속 글상자의 호환 사본 문단은 뺀다 — 같은 글자가 '외 1곳'으로 두 번 읽혔다 (검토52 C 낮음 F06)
            hf_parent = {c: p for p in hf.iter() for c in p}

            def _hf_fb(el):
                q = hf_parent.get(el)
                while q is not None:
                    if q.tag == _MC_FALLBACK:
                        return True
                    q = hf_parent.get(q)
                return False
            # 머리글 **표**('DOC NO | REV | PAGE' 위, 값 아래 — 또는 '라벨 | 값' 두 칸 행)는 칸마다 라벨 없는 문단으로 흩어져
            # REV를 못 읽었다 — 본문만 고친 날 Rev 미갱신이 없고, 개정하면 '[머리글] A → B' 글자 변경이 됐다 (경우100 B16).
            # 라벨과 값을 짝지어 '라벨: 값' 한 줄로 싣는다
            done_p: set = set()
            for tbl in hf.iter(f"{_W}tbl"):
                if _hf_fb(tbl):
                    continue
                grid = [[" ".join(t for t in (ptext(p) for p in tc.iter(f"{_W}p")) if t).strip()
                         for tc in tr.findall(f"{_W}tc")] for tr in tbl.findall(f"{_W}tr")]
                line = _header_table_line(grid)
                if line:
                    paras.append(f"[{kind}] {line}")
                    done_p.update(tbl.iter(f"{_W}p"))
            for p in hf.iter(f"{_W}p"):
                if _hf_fb(p) or p in done_p:
                    continue
                t = ptext(p)
                if t:
                    paras.append(f"[{kind}] {t}")
            if hf_kinds is not None and _types.get(name):
                for _ix in range(_n0, len(paras)):
                    hf_kinds[_ix] = _types[name]
    # 각주·미주 — 읽지 않아 각주만 고친 날 '내용 변경 없음 — 다시 저장되기만'이라 단언했다 (검토51 B 중간 2, 원칙 4·5).
    # 구분선(separator)·이어짐 표시는 글자가 없어 저절로 빠진다
    for name, kind in (("word/footnotes.xml", "각주"), ("word/endnotes.xml", "미주")):
        if name not in z.namelist():
            continue
        try:
            fe = _wxml(z, name)
        except ET.ParseError:
            continue
        for note in fe:
            if str(note.get(f"{_W}type") or "") in ("separator", "continuationSeparator", "continuationNotice"):
                continue
            t = " ".join(x for x in (ptext(p) for p in note.iter(f"{_W}p")) if x)
            if t:
                paras.append(f"[{kind}] {t}")
    return paras, tables


# hp:t 안에 드는 자식 — 탭·줄바꿈·붙임 빈칸·전각 빈칸은 띄어쓰기, 형광펜·제목 표시는 글자 없음. 뒤 글자는 그 자식의 tail이다
_HP_T_SPACE = {f"{_HP}tab", f"{_HP}lineBreak", f"{_HP}nbSpace", f"{_HP}fwSpace"}


# 글자를 담는 요소 — hp:t와 수식 개체의 식(hp:equation > hp:script). 식을 안 읽어 계산서의 식 변경이 '변경 없음'이 됐다
# (재검토 2026-10-28 R1-10). 식은 앞뒤 띄어쓰기로 글줄 안 제자리에
_HP_TXT = {f"{_HP}t", f"{_HP}script"}


def _hp_ts(el):
    """el 아래 글자 요소(hp:t·hp:script)를 문서 순서대로."""
    return (x for x in el.iter() if x.tag in _HP_TXT)


def _hp_text(t) -> str:
    """hp:t 한 개의 글자 — 자식 요소 뒤 글자(tail)까지. t.text만 읽어 '전원<탭>AC 380V'의 값, Shift+Enter 뒤 줄, 형광펜 뒤 글자가
    통째로 사라져 그 값만 바꾼 사양서가 '내용 변경 없음'이 됐다 (재검토 2026-10-28 R1-6). 변경 추적의 지운 구간
    (deleteBegin~deleteEnd)은 지워진 글자라 뺀다 — DOCX가 w:delText를 안 읽는 것과 같게."""
    if t.tag == f"{_HP}script":
        return f" {t.text or ''} "
    out = [t.text or ""]
    deleted = False
    for ch in t:
        tag = ch.tag
        if tag == f"{_HP}deleteBegin":
            deleted = True
        elif tag == f"{_HP}deleteEnd":
            deleted = False
        elif not deleted:
            if tag in _HP_T_SPACE:
                out.append(" ")
            elif tag == f"{_HP}hyphen":
                out.append("-")
        if not deleted:
            out.append(ch.tail or "")
    return "".join(out)


def _hwpx_parts(z: zipfile.ZipFile):
    paras, tables = [], []
    names = sorted(n for n in z.namelist()
                   if n.startswith("Contents/section") and n.endswith(".xml"))
    if not names:
        # 확장자만 .hwpx인 다른 zip(엑셀·zip으로 싼 문서)이 '본문 없는 빈 문서'로 읽혀, 고친 판이 그 빈 판과 비교되지 못했다
        # (검토63 D-F7) — 한글 문서 본체가 없다고 말하고 읽기 실패로 둔다
        raise ValueError("한글(HWPX) 문서 본체(Contents/section)가 없는 파일 — 확장자와 내용이 다른 파일일 수 있습니다")
    for n in names:
        root = ET.fromstring(z.read(n))
        parent = {c: p for p in root.iter() for c in p}

        def _up(el, tag):
            q = parent.get(el)
            while q is not None and q.tag != tag:
                q = parent.get(q)
            return q

        def _direct_cells(tbl):
            """직계 행마다 직계 칸 목록 — 안쪽 표의 행·칸이 바깥 표로 섞이지 않게."""
            return [[tc for tc in tr.iter(f"{_HP}tc") if _up(tc, f"{_HP}tr") is tr]
                    for tr in tbl.iter(f"{_HP}tr") if _up(tr, f"{_HP}tbl") is tbl]
        # 한 행짜리·한 열짜리 본문 표는 글이다 — 칸 문단을 제자리 문단으로 (DOCX와 같은 규칙, 뒤흔들기 DOC C2·C3). 머리글·바닥글
        # 속 표는 따로 다룬다
        hf_tbls = {id(tb) for tag in (f"{_HP}header", f"{_HP}footer") for h in root.iter(tag) for tb in h.iter(f"{_HP}tbl")}
        text_tbls = {id(tb) for tb in root.iter(f"{_HP}tbl")
                     if id(tb) not in hf_tbls and _grid_text_like([len(r) for r in _direct_cells(tb)])}
        # 표 안 문단은 표(Row)로 읽으므로 본문에서 뺀다 — 표 값 하나가 행 변경과 글자 변경 두 번
        # 보고되던 것 (2026-09-06 블라인드 양식 시험 48)
        # (HWPX는 표가 문단 안에 들어간다 — 바깥 문단의 글자를 모을 때 표 안 글자는 뺀다)
        in_tbl: set = set()
        in_text_tbl: set = set()
        tbl_text: set = set()
        for tbl in root.iter(f"{_HP}tbl"):
            for p in tbl.iter(f"{_HP}p"):
                near = _up(p, f"{_HP}tbl")
                (in_text_tbl if near is not None and id(near) in text_tbls else in_tbl).add(id(p))
            for t in _hp_ts(tbl):
                tbl_text.add(id(t))
        # 머리글·바닥글(hp:header/hp:footer 안 subList)은 따로 표시하고 바깥 문단에서 뺀다
        hf_ps: dict = {}
        hf_text: set = set()
        for kind, tag in (("머리글", f"{_HP}header"), ("바닥글", f"{_HP}footer")):
            for h in root.iter(tag):
                for p in h.iter(f"{_HP}p"):
                    hf_ps[id(p)] = kind
                for t in _hp_ts(h):
                    hf_text.add(id(t))
        # 머리글 표('문서번호 | REV' 위·값 아래) — 칸 글자가 바깥 문단에 붙어 '문서번호SPEC-E-071REVA' 한 줄이 되고 표는
        # 본문 표1로 빠져 REV를 못 읽었다 (검토53 B D07·D08). DOCX와 같은 규칙으로 '라벨: 값' 한 줄
        hdr_tbls: set = set()
        hf_tbl_text: set = set()
        for kind, tag in (("머리글", f"{_HP}header"), ("바닥글", f"{_HP}footer")):
            for h in root.iter(tag):
                for tb in h.iter(f"{_HP}tbl"):
                    grid = [[" ".join("".join(_hp_text(t) for t in _hp_ts(p)).strip()
                                      for p in tc.iter(f"{_HP}p")).strip() for tc in tr.findall(f"{_HP}tc")]
                            for tr in tb.findall(f"{_HP}tr")]
                    line = _header_table_line(grid)
                    if line:
                        paras.append(f"[{kind}] {line}")
                        hdr_tbls.add(id(tb))
                        hf_tbl_text.update(id(t) for t in _hp_ts(tb))
        # 각주·미주·글상자(hp:footNote·hp:endNote·도형 hp:drawText)는 문단 **안**에 든다 — 바깥 문단 끝에 그 글자가 붙고 안쪽
        # 문단으로 또 읽혀 각주 하나 고친 것이 2건, 글상자는 '외 1곳'이 됐다 (검토68 D3·D5). 바깥에서 빼고 '[각주]'·'[글상자]'로 한 번
        note_ps: dict = {}
        note_text: set = set()
        for kind, tag in (("각주", f"{_HP}footNote"), ("미주", f"{_HP}endNote"), ("글상자", f"{_HP}drawText")):
            for el in root.iter(tag):
                for p in el.iter(f"{_HP}p"):
                    note_ps.setdefault(id(p), kind)
                for t in _hp_ts(el):
                    note_text.add(id(t))
        for p in root.iter(f"{_HP}p"):
            if id(p) in in_tbl:
                continue
            if id(p) in in_text_tbl:
                # 글처럼 읽는 표의 칸 문단 — 제 글자만(그 안에 든 표·각주·글상자 글자는 그쪽이 맡는다)
                inner = {id(t) for el in p.iter() if el is not p and el.tag in (f"{_HP}tbl", f"{_HP}footNote", f"{_HP}endNote",
                                                                                f"{_HP}drawText")
                         for t in _hp_ts(el)}
                txt = " ".join("".join(_hp_text(t) for t in _hp_ts(p) if id(t) not in inner).split())
                if txt:
                    # 글상자 속 표라도 머리표 없이(DOCX와 같게) — 각주·미주 속이면 그 표시는 남긴다
                    paras.append(f"[{note_ps[id(p)]}] {txt}" if note_ps.get(id(p)) in ("각주", "미주") else txt)
                continue
            if id(p) in hf_ps:
                txt = "".join(_hp_text(t) for t in _hp_ts(p) if id(t) not in hf_tbl_text).strip()
                if txt:
                    paras.append(f"[{hf_ps[id(p)]}] {txt}")
                continue
            if id(p) in note_ps:
                # 안쪽 문단 자신의 글자만(더 안쪽 표 글자는 표가 맡는다)
                txt = " ".join("".join(_hp_text(t) for t in _hp_ts(p) if id(t) not in tbl_text).split())
                if txt:
                    paras.append(f"[{note_ps[id(p)]}] {txt}")
                continue
            # 연속 띄어쓰기는 하나로 — 워드(DOCX)는 접는데 한글은 안 접어, 띄어쓰기 두 칸이 '값 변경 + Rev 미갱신'이 되고
            # 화면에서는 전후가 똑같이 보였다 (검토62 B7)
            txt = " ".join("".join(_hp_text(t) for t in _hp_ts(p)
                                   if id(t) not in tbl_text and id(t) not in hf_text and id(t) not in note_text).split())
            if txt:
                paras.append(txt)
        # 표(중첩 포함) — 칸의 글자는 안쪽 표 글자를 뺀다 (2026-09-06 블라인드 3차 45)
        def cell_text(tc) -> str:
            inner_t: set = set()
            for tb2 in tc.iter(f"{_HP}tbl"):
                for t in _hp_ts(tb2):
                    inner_t.add(id(t))
            return " ".join(w for p in tc.iter(f"{_HP}p")
                            for w in "".join(_hp_text(t) for t in _hp_ts(p) if id(t) not in inner_t).split())
        for tbl in root.iter(f"{_HP}tbl"):
            if id(tbl) in hdr_tbls or id(tbl) in text_tbls:
                continue                      # 머리글 표는 위에서 '라벨: 값' 한 줄로, 글 같은 표는 문단으로 읽었다
            rows = []
            for tcs in _direct_cells(tbl):
                cells = []
                for tc in tcs:
                    # 칸 자리(cellAddr colAddr)·가로 병합(cellSpan colSpan)을 DOCX(gridSpan)처럼 펼친다 — 표 위 병합 제목 행
                    # ('주요 사양' 4칸 병합)이 한 칸으로 읽혀 열 이름이 하나뿐이 되고, 둘째 열부터 값이 통째로 사라져 칸 값
                    # 변경이 '다시 저장만'으로 메일에서 빠졌다 (대량 시험 DOC C1, 2026-10-20). 위 칸의 세로 병합(rowSpan)에
                    # 덮인 칸은 한글이 아예 적지 않는다 — 빈칸으로 메워 열이 왼쪽으로 밀리지 않게(DOCX vMerge 빈칸과 같게)
                    span, col = 1, None
                    cs, ca = tc.find(f"{_HP}cellSpan"), tc.find(f"{_HP}cellAddr")
                    try:
                        span = max(1, min(64, int(cs.get("colSpan") or 1))) if cs is not None else 1
                    except ValueError:
                        span = 1
                    try:
                        col = int(ca.get("colAddr")) if ca is not None and ca.get("colAddr") is not None else None
                    except ValueError:
                        col = None
                    if col is not None and len(cells) < col <= 256:
                        cells.extend([""] * (col - len(cells)))
                    txt = cell_text(tc)
                    cells.append(txt)
                    cells.extend([txt if not rows else ""] * (span - 1))
                rows.append(cells)
            tables.append(rows)
    return paras, tables


_REVLOG_REV_COL = re.compile(r"^(REV(ISION)?\.?\s*(NO\.?)?|개정\s*(번호|차수)?|판|버전|VER(SION)?)$", re.I)
# 버전 꼴 '1.0'·'1.1'·'2.0.1'도 — '버전' 칸의 1.1을 Rev로 못 읽어 본문만 고치고 버전·개정이력을 그대로 둔 사양서에 'Rev 미갱신'이
# 없었다 (구매 평가 2차 P2 day9). 순서는 scan.rev_key가 조각별로 본다
_REVLOG_REV_VAL = re.compile(r"^(?:(?:REV\.?\s*)?[A-Z0-9]{1,3}|[Vv]?\d{1,2}(?:\.\d{1,2}){1,2})$", re.I)
_REVLOG_NOT_REV = re.compile(r"(일자|날짜|DATE|내용|사유|비고|자|DESC)", re.I)
_REVLOG_DATE_COL = re.compile(r"(DATE|일자|날짜|개정일)", re.I)
_REVLOG_DATE_VAL = re.compile(r"(\d{4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}|^'?\d{2}[-./]\d{1,2}[-./]\d{1,2}$|^\d{1,2}/\d{1,2}/\d{4}$)")
# 도면 목록·자재 표는 Rev·일자 칸이 있어도 개정이력이 아니다 (consistency._NOT_REVLOG_COLS와 같은 뜻)
_REVLOG_EXCLUDE = {"DWGNO", "DRAWINGNO", "DWG", "도면번호", "TITLE", "제목", "도면명", "품번", "PARTNO", "PN", "TAG",
                   "SHEET", "QTY", "수량"}


def _is_revlog_table(header: list, body: list) -> bool:
    """Rev 칸과 날짜 칸이 있고 날짜 칸에 실제 날짜가 든 표 — 문서의 개정이력 표 (검토68 D4)."""
    names = [str(h or "").strip() for h in header]
    if any(re.sub(r"[\s._/]", "", n).upper() in _REVLOG_EXCLUDE for n in names):
        return False
    rev_i = [i for i, n in enumerate(names) if _REVLOG_REV_COL.match(n) and not _REVLOG_NOT_REV.search(n)]
    date_i = [i for i, n in enumerate(names) if _REVLOG_DATE_COL.search(n)]
    if not rev_i or not date_i:
        return False
    vals = [str(r[date_i[0]] or "").strip() for r in body if r and date_i[0] < len(r) and any(r)]
    return bool(vals) and sum(1 for v in vals if _REVLOG_DATE_VAL.search(v)) * 2 >= len(vals)


def _title_row(tbl: list) -> str | None:
    """표 첫 행이 병합 제목 행이면 그 글 — 칸이 둘 이상이고 비지 않은 칸이 모두 같은 글이면서 전 열을 덮거나(펼친 병합),
    셋 이상 칸에서 첫 칸만 찼을 때(병합을 푼 제목). 아래에 머리글(찬 칸 둘 이상) + 값 행이 있어야 한다 (뒤흔들기 DOC C5)."""
    if len(tbl) < 3:
        return None
    top = [str(c or "").strip() for c in tbl[0]]
    filled = [c for c in top if c]
    if len(top) < 2 or not filled or len(set(filled)) != 1:
        return None
    if not (len(filled) == len(top) or (len(top) >= 3 and len(filled) == 1 and top[0])):
        return None
    if sum(1 for c in tbl[1] if str(c or "").strip()) < 2:
        return None
    return filled[0]


def _header_of(tbl: list) -> tuple[list, int]:
    """(열 이름 목록, 값이 시작하는 행 번호). 병합 머리글(첫 행에 같은 이름이 이웃해 되풀이 — gridSpan을 펼친
    것)이고 둘째 행이 숫자 없는 짧은 이름들이면 두 줄 머리글이다 — 'RATING kW'처럼 합친다. 같은 이름이 남으면
    뒤의 것에 번호를 붙인다(안 붙이면 값이 한 열로 덮였다) (검토38 R4-E)."""
    top = [h or "" for h in tbl[0]]
    merged = any(top[i] and top[i] == top[i + 1] for i in range(len(top) - 1))
    start = 1
    names = list(top)
    if merged and len(tbl) >= 3:
        sub = [c or "" for c in tbl[1]] + [""] * max(0, len(top) - len(tbl[1]))
        # 하위 이름은 대부분 병합 그룹 아래에 놓인다 — 숫자 없는 짧은 첫 데이터 행('PUMP|ABB|-')을 머리글로 삼켜 그 행이
        # 사라지고 열 이름이 'MOTOR PUMP'가 됐다 (검토41 S4 중간 4·S2 중간 2). XLSX와 같은 규칙
        under = sum(1 for j, c in enumerate(sub) if c and j < len(top)
                    and ((j > 0 and top[j - 1] == top[j]) or (j + 1 < len(top) and top[j + 1] == top[j])))
        # 병합 안 된 열(세로로 합친 'REMARK') 아래는 비어 있어야 한다 — '-'·값이 있으면 데이터 행
        lone_filled = any(c for j, c in enumerate(sub) if j < len(top)
                          and not ((j > 0 and top[j - 1] == top[j]) or (j + 1 < len(top) and top[j + 1] == top[j])))
        if any(sub) and all(len(c) <= 20 and not re.search(r"\d", c) for c in sub if c) \
                and under >= 0.6 * sum(1 for c in sub if c) and not lone_filled:
            names = [(f"{t} {s}" if t and s and t != s else (s or t)) for t, s in zip(top, sub)]
            start = 2
    out, seen = [], {}
    for ci, h in enumerate(names):
        h = h or f"열{ci + 1}"
        seen[h] = seen.get(h, 0) + 1
        out.append(h if seen[h] == 1 else f"{h} #{seen[h]}")
    return out, start


def _saved_by(path: Path) -> str | None:
    """docProps/core.xml의 마지막 저장자(cp:lastModifiedBy) — 읽기 전용으로 연다."""
    try:
        with zipfile.ZipFile(path) as z:
            root = ET.fromstring(z.read("docProps/core.xml"))
    except (KeyError, OSError, zipfile.BadZipFile, ET.ParseError):
        return None
    for el in root.iter():
        if el.tag.endswith("}lastModifiedBy") and (el.text or "").strip():
            return el.text.strip()[:60]
    return None


_KO_ORD = ("첫째", "둘째", "셋째", "넷째", "다섯째", "여섯째", "일곱째", "여덟째", "아홉째", "열째")


def _ko_ordinal(n: int) -> str:
    return _KO_ORD[n - 1] if 1 <= n <= len(_KO_ORD) else f"{n}번째"


def extract(path: Path) -> Document:
    path = Path(path)
    ext = path.suffix.lower()
    _kinds: dict = {}
    _zones: dict = {}
    with zipfile.ZipFile(path) as z:            # 읽기 전용 열기
        if ext == ".hwpx":
            paras, tables = _hwpx_parts(z)
            doc_type = "hwpx"
        else:
            paras, tables = _docx_parts(z, _kinds, _zones)
            doc_type = "docx"

    fields: dict[str, Field] = {}
    body: list[TextLine] = []
    # 본문 문단을 먼저, 머리글·바닥글을 뒤에 — HWPX는 머리글·바닥글이 본문보다 앞에 나와 둘째 칸 규칙(REV#2)이 거꾸로
    # 되어 표지 REV만 올린 날 거짓 'Rev 미갱신'이 났다 (검토47 A 중간 6). 문단 번호는 원래 자리 그대로
    _order = sorted(enumerate(paras[:_MAX_PARAS], start=1),
                    key=lambda it: bool(re.match(r"^\[(?:머리글|바닥글)\]", it[1] or "")))
    _hf_n: dict = {}
    for i, txt in _order:
        if not txt:
            continue
        where = f"문단 {i}"
        # 머리글·바닥글 줄은 본문 문단 번호가 아니라 그 안의 순번으로 — 머리글 뒤에 본문 문단 수가 붙어 '머리글(문단 9)'를 보고
        # 본문 9번 문단을 찾았고, 본문에 문단을 하나 더하면 같은 머리글이 '문단 10'이 됐다 (검토62 A-D)
        _hfm = re.match(r"^\[(머리글|바닥글)\]", txt)
        if _hfm:
            _hf_n[_hfm.group(1)] = _hf_n.get(_hfm.group(1), 0) + 1
            where = f"{_ko_ordinal(_hf_n[_hfm.group(1)])} 줄"     # '1째 줄'이 아니라 '첫째 줄' (검토71 R4 중간 4)
            if _kinds.get(i - 1):
                where += f" · {_kinds[i - 1]}"                   # 짝수 쪽·첫 쪽 사본 (검토71 R4 중간 7)
        where_b = f"{_hfm.group(1)} {where}" if _hfm else where
        # 머리글·바닥글 줄은 '[바닥글] ' 머리표를 떼고 본다 — 'DOC NO: … REV: 0 DATE: …' 바닥글 한 줄의 Rev를 못 읽어
        # 본문을 고쳐도 'Rev 미갱신'이 없었다(같은 꼴 PDF는 읽음) (검토44 B X06c)
        _hf = re.match(r"^\[(?:머리글|바닥글)\]\s*", txt)
        core = txt[_hf.end():] if _hf else txt
        if _hf and not any(_canon(m.group(1)) == "REV" for m in _label_matches(core)):
            # 앞에 낱말이 없거나 문서번호 하나('SPEC-E-071  Rev. A')일 때만 — 'Form QP-07 Rev 3'·'IEC 60204-1 Rev 1'
            # (양식·규격의 개정)이 문서 Rev가 되어 거짓 'Rev 미갱신'이 났다 (검토53 A 중간 4)
            # 앞 글자의 개수가 아니라 꼴로 가른다 — 낱말 수로 막았더니 'SPEC-E-050 전기사양서  Rev. A'·'DOC SPEC-E-071
            # REV C'·'장비 사양서  Rev. B'(제목+Rev)까지 못 읽어 Rev 미갱신이 꺼지고 거짓 경고가 났다 (검토53 E 중간 4·F 퇴행)
            mr = _COLONLESS_REV.search(core)
            _rv = mr.group(2) if mr else None
            if mr is None:
                mr = _VERSION_HF.search(core)
                _rv = mr.group(2).lstrip("Vv") if mr else None      # 'V1.1' — 개정이력 '버전' 칸 1.1과 같게
            if mr and not _FORM_REV_BEFORE.search(core[:mr.start()]):
                core = core[:mr.start()] + f"REV: {_rv}" + core[mr.end():]
        pairs = [(c, v) for c, v in _line_fields(core) if c not in fields]
        if _hf:
            # 머리글·바닥글 줄은 앞 문단이 이미 차지한 칸도 **둘째 칸**(REV#2)으로 읽는다 — 본문 글자로 남기면 표지와 바닥글 Rev를
            # 함께 올린 정상 개정에서 'Rev만 갱신'이 사라지고, 바닥글만 올리면 '내용 변경 → Rev 미갱신'이 됐다 (검토46 A 중간 2)
            pairs = []
            for c, v in _line_fields(core, anywhere=True):
                k, n = c, 2
                while k in fields:
                    k, n = f"{c}#{n}", n + 1
                pairs.append((k, v))
        if pairs:
            for c, v in pairs:
                # 바닥글·머리글에서 읽은 칸은 그 자리로 — 바닥글 REV 근거가 '머리말(문단 8)'로 나왔다 (검토46 C 중간 3)
                _place = ("바닥글" if "바닥글" in txt[:_hf.end()] else "머리글") if _hf else "머리말"
                # '머리글(1째 줄)'을 근거 줄이 또 괄호로 싸 '(머리글(1째 줄))'이 됐다 — 괄호 없이 '머리글 첫째 줄' (검토71 R4 중간 4)
                fields[c] = Field(c.split("#", 1)[0] if "#" not in c else c, v,
                                  f"{_place} {where}" if _hf else f"{_place}({where})")
            rest = _line_rest(core, {c.split("#", 1)[0] for c, _v in pairs})
            if re.search(r"[A-Za-z가-힣0-9]{2,}", rest):
                body.append(TextLine(rest, where_b))
        else:
            # 머리글·바닥글 줄의 글자에는 '[머리글] ' 머리표를 붙이지 않는다 — 자리는 where('머리글 첫째 줄')가 말한다. 글자에 붙이면
            # 같은 줄을 머리글↔바닥글·본문으로 옮기기만 해도 '글자 변경' + 거짓 Rev 미갱신이 됐다 (뒤흔들기 DOC C6·C16, 2026-10-20)
            body.append(TextLine(txt[_hf.end():] if _hf else txt, where_b))

    rows: list[Row] = []
    for ti, tbl in enumerate(tables, start=1):
        # 표 위 병합 제목 행('주요 사양' 전 열 병합 — 펼치면 모든 칸이 같은 글, 병합을 풀면 첫 칸만)은 열 이름이 아니라 표 제목
        # 글이다 — 머리글로 받으면 진짜 머리글이 '두 줄 머리글'로 합쳐져 열 이름이 전부 '주요 사양 항목'으로 바뀌고, 열 이름 바뀜·값
        # 이동 연쇄에 진짜 행 추가·칸 값 변경이 묻혔다 (뒤흔들기 DOC C5, 2026-10-20). 제목은 글줄로 두고 다음 행부터 표로 읽는다 —
        # 행 번호도 제목을 뺀 표 기준(제목을 넣거나 빼도 행 자리가 그대로)
        _title = _title_row(tbl)
        if _title:
            body.append(TextLine(_title, f"표{ti} 제목"))
            tbl = tbl[1:]
        if len(tbl) < 2:
            continue
        # 두 칸짜리 표(회의록 머리: '일시 | 2026-09-04 14:00')는 첫 칸이 항목 이름 — 첫 행을
        # 머리글로 보면 값이 열 이름이 되어 엉킨다 (2026-09-06 블라인드 2차 29)
        first = [c or "" for c in tbl[0]] + ["", ""]
        headerish = (len(first[0]) <= 12 and len(first[1]) <= 12
                     and not any(ch.isdigit() for ch in first[0] + first[1]))
        if (all(len([c for c in r if c]) <= 2 for r in tbl) and max(len(r) for r in tbl) == 2
                and not headerish):
            for ri, cells in enumerate(tbl, start=1):
                if not any(cells):
                    continue
                k = "".join((cells[0] or "").split()) or f"{ti}-{ri}"
                rows.append(Row(k, {"값": cells[1] if len(cells) > 1 else ""}, f"표{ti} 행{ri}"))
            continue
        header, start = _header_of(tbl)
        _rl_where = " (개정이력)" if _is_revlog_table(header, tbl[start:]) else ""
        # 첫 칸이 순번(NO·번호)이면 행 이름이 아니다 — 가운데 행을 지우고 번호를 다시 매기면 아래 행이 전부 '값 변경'이 되고
        # 엉뚱한 마지막 행이 '삭제'됐다 (검토62 A-A). 엑셀처럼 위치 키로 두어 비교가 내용으로 행을 맞추게 한다
        _ordinal = bool(header) and bool(re.match(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", str(header[0] or "").strip(), re.I))
        _kc = None
        if _ordinal:
            from watcher.diff import strip_leading_no
            from watcher.extract.xlsx import _pick_key_col
            _kc = _pick_key_col([{h: c for h, c in zip(header[1:], cells[1:]) if h}
                                 for cells in tbl[start:] if any(cells)])
        for ri, cells in enumerate(tbl[start:], start=start + 1):
            if not any(cells):
                continue
            values = {header[ci]: c for ci, c in enumerate(cells) if ci < len(header)}
            if _ordinal:
                # 품명이 겹치면 품명·규격 조합으로 (엑셀과 같은 규칙), 없으면 위치 키
                _parts = ([strip_leading_no(values.get(c)) for c in _kc if values.get(c)] if isinstance(_kc, tuple)
                          else [strip_leading_no(values.get(_kc))] if _kc and values.get(_kc) else [])
                key = (" ".join(_parts) if _parts and (not isinstance(_kc, tuple) or len(_parts) == len(_kc))
                       else f"표{ti}!행{ri}")
            else:
                key = cells[0] if cells and cells[0] else f"{ti}-{ri}"
            rows.append(Row(key, values, f"표{ti} 행{ri}{_rl_where}"))

    # Rev가 개정이력 표에만 있는 문서 — 머리글·바닥글에 REV가 없으면 표의 가장 높은 Rev를 문서 Rev로 둔다(엑셀 개정이력 시트와
    # 같은 규칙). 없으면 본문을 고치고 이력 행을 안 적어도 Rev 검사 자체가 없었다 (검토68 D4). 행은 그대로 표 행으로 비교한다
    if "REV" not in fields:
        best = None
        for r in rows:
            if not r.where.endswith("(개정이력)"):
                continue
            rv = next((str(v).strip() for k, v in r.values.items() if _REVLOG_REV_COL.match(str(k).strip())
                       and not _REVLOG_NOT_REV.search(str(k)) and str(v or "").strip()), None)
            if not rv or not _REVLOG_REV_VAL.match(rv):
                continue
            rv = re.sub(r"(?i)^REV\.?\s*", "", rv)
            if re.fullmatch(r"[Vv]?\d{1,2}(?:\.\d{1,2}){1,2}", rv):
                k_ = (2, tuple(int(x) for x in rv.lstrip("Vv").split(".")), "")
            else:
                k_ = (0, int(rv), "") if rv.isdigit() else (1, len(rv), rv.upper())
            if best is None or k_ > best[0]:
                best = (k_, rv, r.where)
        if best:
            fields["REV"] = Field("REV", best[1], best[2])

    notes: list[str] = []
    if not body and not rows:
        notes.append("본문 텍스트가 없습니다 — 그림·개체로만 된 문서이거나 빈 문서입니다. "
                     "파일 수준(해시) 변경만 감지합니다.")
    return Document(doc_type=doc_type, path=str(path), fields=fields, rows=rows,
                    raw_texts=body, notes=notes, saved_by=_saved_by(path) if doc_type == "docx" else None,
                    hf_kinds=_zones if doc_type == "docx" else None)
