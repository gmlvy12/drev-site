# -*- coding: utf-8 -*-
"""DOCX(Word)·HWPX(한글) 추출기 — 표준 라이브러리만 (2026-09-02).

배경: .docx는 검사 대상이면서 내용 추출이 없어, 워드로 된 사양서·견적서·계약서가
파일명에 단서가 없으면 전부 "문서"로 떨어졌다 (회사 실사용: "문서, 사양서, 견적서
등등 제대로 구분이 안 되는 거 같아"). 둘 다 zip 안의 XML이라 zipfile + ElementTree로
읽는다. 읽기 전용 (PRINCIPLE 2).

- 문단 → TextLine("문단 N")   - 표 → Row(첫 행이 머리글)   - 머리말의 '라벨: 값' → Field
- .hwp(구형 바이너리)는 지원하지 않는다 — 파일 수준 감지만. notes에 남기지 않는다
  (추출기가 호출되지 않으므로).
"""
from __future__ import annotations

import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from watcher.extract.base import Document, Field, Row, TextLine

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"

# 머리말의 표제 항목 — PDF 추출기와 같은 라벨 집합의 부분집합
_FIELD_RE = re.compile(
    r"^\s*(PROJECT|프로젝트|DOC[ ._]?NO|문서번호|REV(?:ISION)?|리비전|개정|DATE|일자|작성일)"
    r"\s*[:：]\s*(.+?)\s*$", re.I)
_CANON = {"PROJECT": "PROJECT", "프로젝트": "PROJECT",
          "DOC NO": "DOC_NO", "DOCNO": "DOC_NO", "DOC.NO": "DOC_NO", "문서번호": "DOC_NO",
          "REV": "REV", "REVISION": "REV", "리비전": "REV", "개정": "REV",
          "DATE": "DATE", "일자": "DATE", "작성일": "DATE"}
_MAX_PARAS = 4000          # 수백 쪽 문서도 상한 안에서 — 비교는 초안이면 된다


def _canon(label: str) -> str | None:
    return _CANON.get(re.sub(r"[ ._]+", " ", label.upper()).strip())


def _docx_parts(z: zipfile.ZipFile):
    """(문단 텍스트 목록, 표 목록) — 표는 [[셀텍스트, ...], ...]."""
    root = ET.fromstring(z.read("word/document.xml"))
    body = root.find(f"{_W}body")
    paras, tables = [], []
    if body is None:
        return paras, tables

    def ptext(p) -> str:
        return "".join(t.text or "" for t in p.iter(f"{_W}t")).strip()

    parent = {c: p for p in body.iter() for c in p}

    def in_table(el) -> bool:
        q = parent.get(el)
        while q is not None:
            if q.tag == f"{_W}tbl":
                return True
            q = parent.get(q)
        return False

    # 문단은 어디 있든(표지의 내용 컨트롤 w:sdt 포함) 문서 순서대로 — 단, 표 안
    # 문단은 rows로 가므로 본문에서 뺀다 (양쪽에 있으면 같은 변경이 두 번 잡힌다,
    # 2026-09-02 재검토)
    for p in body.iter(f"{_W}p"):
        if in_table(p):
            continue
        t = ptext(p)
        if t:
            paras.append(t)
    # 표는 모두(중첩 표 포함) 각각 — 바깥 칸의 글자는 안쪽 표의 글자를 뺀다 (안 빼면 안쪽 표의
    # 값 변경이 바깥 칸 변경으로 한 번 더 잡힌다, 2026-09-06 블라인드 3차 31·37)
    def depth(el) -> int:
        d, q = 0, parent.get(el)
        while q is not None:
            if q.tag == f"{_W}tbl":
                d += 1
            q = parent.get(q)
        return d

    def own_ps(tc):
        """칸의 직속 문단(안쪽 표 속 문단 제외)."""
        out = []
        for p in tc.iter(f"{_W}p"):
            q, inner = parent.get(p), False
            while q is not None and q is not tc:
                if q.tag == f"{_W}tbl":
                    inner = True; break
                q = parent.get(q)
            if not inner:
                out.append(p)
        return out
    for tbl in sorted(body.iter(f"{_W}tbl"), key=depth):
        rows = []
        for tr in tbl.findall(f"{_W}tr"):
            rows.append([" ".join(ptext(p) for p in own_ps(tc)).strip()
                         for tc in tr.findall(f"{_W}tc")])
        tables.append(rows)
    # 머리글·바닥글 — 문서번호·개정·대외비 표시가 여기 있다 (2026-09-06 블라인드 3차 34·38)
    for name in sorted(z.namelist()):
        if name.startswith("word/header") or name.startswith("word/footer"):
            try:
                hf = ET.fromstring(z.read(name))
            except ET.ParseError:
                continue
            kind = "머리글" if "header" in name else "바닥글"
            for p in hf.iter(f"{_W}p"):
                t = ptext(p)
                if t:
                    paras.append(f"[{kind}] {t}")
    return paras, tables


def _hwpx_parts(z: zipfile.ZipFile):
    paras, tables = [], []
    names = sorted(n for n in z.namelist()
                   if n.startswith("Contents/section") and n.endswith(".xml"))
    for n in names:
        root = ET.fromstring(z.read(n))
        # 표 안 문단은 표(Row)로 읽으므로 본문에서 뺀다 — 표 값 하나가 행 변경과 글자 변경 두 번
        # 보고되던 것 (2026-09-06 블라인드 양식 시험 48)
        # (HWPX는 표가 문단 안에 들어간다 — 바깥 문단의 글자를 모을 때 표 안 글자는 뺀다)
        in_tbl: set = set()
        tbl_text: set = set()
        for tbl in root.iter(f"{_HP}tbl"):
            for p in tbl.iter(f"{_HP}p"):
                in_tbl.add(id(p))
            for t in tbl.iter(f"{_HP}t"):
                tbl_text.add(id(t))
        # 머리글·바닥글(hp:header/hp:footer 안 subList)은 따로 표시하고 바깥 문단에서 뺀다
        hf_ps: dict = {}
        hf_text: set = set()
        for kind, tag in (("머리글", f"{_HP}header"), ("바닥글", f"{_HP}footer")):
            for h in root.iter(tag):
                for p in h.iter(f"{_HP}p"):
                    hf_ps[id(p)] = kind
                for t in h.iter(f"{_HP}t"):
                    hf_text.add(id(t))
        for p in root.iter(f"{_HP}p"):
            if id(p) in in_tbl:
                continue
            if id(p) in hf_ps:
                txt = "".join(t.text or "" for t in p.iter(f"{_HP}t")).strip()
                if txt:
                    paras.append(f"[{hf_ps[id(p)]}] {txt}")
                continue
            txt = "".join(t.text or "" for t in p.iter(f"{_HP}t")
                          if id(t) not in tbl_text and id(t) not in hf_text).strip()
            if txt:
                paras.append(txt)
        # 표(중첩 포함) — 칸의 글자는 안쪽 표 글자를 뺀다 (2026-09-06 블라인드 3차 45)
        parent = {c: p for p in root.iter() for c in p}

        def cell_text(tc) -> str:
            inner_t: set = set()
            for tb2 in tc.iter(f"{_HP}tbl"):
                for t in tb2.iter(f"{_HP}t"):
                    inner_t.add(id(t))
            return " ".join(
                "".join(t.text or "" for t in p.iter(f"{_HP}t") if id(t) not in inner_t).strip()
                for p in tc.iter(f"{_HP}p")).strip()
        for tbl in root.iter(f"{_HP}tbl"):
            rows = []
            for tr in tbl.iter(f"{_HP}tr"):
                # 직계 행만 — 안쪽 표의 행이 바깥 표 행으로 섞이지 않게
                q = parent.get(tr)
                while q is not None and q.tag != f"{_HP}tbl":
                    q = parent.get(q)
                if q is not tbl:
                    continue
                cells = []
                for tc in tr.iter(f"{_HP}tc"):
                    q2 = parent.get(tc)
                    while q2 is not None and q2.tag != f"{_HP}tr":
                        q2 = parent.get(q2)
                    if q2 is not tr:
                        continue
                    cells.append(cell_text(tc))
                rows.append(cells)
            tables.append(rows)
    return paras, tables


def extract(path: Path) -> Document:
    path = Path(path)
    ext = path.suffix.lower()
    with zipfile.ZipFile(path) as z:            # 읽기 전용 열기
        if ext == ".hwpx":
            paras, tables = _hwpx_parts(z)
            doc_type = "hwpx"
        else:
            paras, tables = _docx_parts(z)
            doc_type = "docx"

    fields: dict[str, Field] = {}
    body: list[TextLine] = []
    for i, txt in enumerate(paras[:_MAX_PARAS], start=1):
        if not txt:
            continue
        where = f"문단 {i}"
        m = _FIELD_RE.match(txt)
        canon = _canon(m.group(1)) if m else None
        if canon and canon not in fields:
            fields[canon] = Field(canon, m.group(2), f"머리말({where})")
        else:
            body.append(TextLine(txt, where))

    rows: list[Row] = []
    for ti, tbl in enumerate(tables, start=1):
        if len(tbl) < 2:
            continue
        # 두 칸짜리 표(회의록 머리: '일시 | 2026-09-04 14:00')는 첫 칸이 항목 이름 — 첫 행을
        # 머리글로 보면 값이 열 이름이 되어 엉킨다 (2026-09-06 블라인드 2차 29)
        first = [c or "" for c in tbl[0]] + ["", ""]
        headerish = (len(first[0]) <= 12 and len(first[1]) <= 12
                     and not any(ch.isdigit() for ch in first[0] + first[1]))
        if (all(len([c for c in r if c]) <= 2 for r in tbl) and max(len(r) for r in tbl) == 2
                and not headerish):
            for ri, cells in enumerate(tbl, start=1):
                if not any(cells):
                    continue
                k = "".join((cells[0] or "").split()) or f"{ti}-{ri}"
                rows.append(Row(k, {"값": cells[1] if len(cells) > 1 else ""}, f"표{ti} 행{ri}"))
            continue
        header = [h or f"열{ci + 1}" for ci, h in enumerate(tbl[0])]
        for ri, cells in enumerate(tbl[1:], start=2):
            if not any(cells):
                continue
            values = {header[ci]: c for ci, c in enumerate(cells) if ci < len(header)}
            key = cells[0] if cells and cells[0] else f"{ti}-{ri}"
            rows.append(Row(key, values, f"표{ti} 행{ri}"))

    notes: list[str] = []
    if not body and not rows:
        notes.append("본문 텍스트가 없습니다 — 그림·개체로만 된 문서이거나 빈 문서입니다. "
                     "파일 수준(해시) 변경만 감지합니다.")
    return Document(doc_type=doc_type, path=str(path), fields=fields, rows=rows,
                    raw_texts=body, notes=notes)
