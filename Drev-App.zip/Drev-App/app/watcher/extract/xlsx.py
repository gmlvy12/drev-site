# -*- coding: utf-8 -*-
"""XLSX 추출기: BOM·발주서·자재표 행 → Row 목록.

전 시트를 순회한다 — wb.active(저장 당시 열려 있던 시트) 하나만 읽으면 담당자가
어느 시트를 보다 저장했는지에 따라 감시 대상이 조용히 바뀐다 (2026-08-26 설계
엔지니어 검토, PRINCIPLE 5 위반이라 최우선 수정). 실무 BOM은 표지/전장품/케이블/
예비품/개정이력이 한 파일에 시트로 나뉜다.

행 key는 TAG 열 우선, 없으면 '시트명!행N'. 병합 셀은 앵커 값을 전파하고,
소계/합계 행은 비교에서 제외하며, 개정이력 시트는 revision_history로 분류한다.
"""

from __future__ import annotations

import datetime

import re
from collections import Counter
from pathlib import Path

import openpyxl

from watcher.extract.base import BOM_SPEC_HEADS, Document, Field, Row, TextLine, bom_head, rowkey_tag_head

# 표 머리글에 흔한 열 이름 — 이 중 하나라도 있으면 열 2개짜리 표도 머리글로 인정
_KNOWN_HEADER = {"TAG", "SPEC", "품명", "부품명", "자재명", "명칭", "품번", "규격",
                 "수량", "QTY", "DESCRIPTION", "MODEL", "형식", "단위", "UNIT"}

# 개정이력 시트로 취급할 시트명 (revision_history로 분류 — Rev 검사 근거로 쓰임)
# "BOM_rev2"처럼 이름에 rev가 섞였을 뿐인 시트가 개정이력으로 분류되던 것 (2026-09-06 양식 시험)
_REV_SHEET = re.compile(
    r"^\s*(?:(?:개정|변경|수정)\s*(?:이력|내역|기록)?\s*(?:표|시트)?|이력\s*(?:표|시트)?|리비전|"
    r"rev(?:ision)?s?(?:\s*(?:history|list|table))?|revision\s*history|history)\s*$",
    re.IGNORECASE)

# 소계/합계 행 — 위 행이 하나 늘면 같이 밀려 '변경'으로 잡히는 소음원이라 제외
_TOTAL_ROW = re.compile(r"^(소\s*계|합\s*계|총\s*계|계|SUB\s*TOTAL|TOTAL|G\.?\s*TOTAL)$",
                        re.IGNORECASE)

# 머리글 후보 칸이 '값'처럼 보이는가 — 날짜, 번호 코드, 숫자 (2026-09-06)
_VALUEISH = re.compile(
    r"\d{4}[-./]\d{1,2}[-./]\d{1,2}|^[A-Z]{1,4}-\d{2,}|^\d+([.,]\d+)?$"
    r"|^\d+\s*(일|식|개|매|장|대|명|EA|SET|PCS)$|\d+\s*(일|식)$"
    r"|^\d+(\.\d+)?\s*[a-zA-Z%℃Ω]{1,4}$|^(OK|NG|PASS|FAIL|합격|불합격)$", re.IGNORECASE)

# 정보 행의 칸 — '수신: OO사'(라벨:값), 'B'(한 글자 값), '발 주 서'(띄어 쓴 제목)는 열 이름이 아니다 (리뷰10 차단-1)
_INFOISH = re.compile(r"^.$|[:：]\s*\S|^(?:\S\s+){2,}\S$")
# 정보 행에서 값 앞에 오는 라벨 — '설비 | 1호기', '작성 | 김철수', '구분 | 양산' (리뷰11 차단-D)
_INFO_LABELS = {"설비", "라인", "구분", "작성", "검토", "승인", "결재", "업체", "고객", "수신", "참조", "제목", "건명",
                "프로젝트", "호기", "작성자", "검토자", "승인자", "REV", "PROJECT", "DRAWN", "CHECKED", "APPROVED",
                "CUSTOMER", "LINE", "MACHINE"}
# ('담당'·'NO'·'일자'·'공정'처럼 표 머리글로도 흔한 낱말은 넣지 않는다 — 회의록 머리글 'NO | 안건 | … | 담당 | 기한'이
#  정보 행으로 몰려 데이터 행에 머리글을 빼앗겼다, 리뷰11 재채점 review7/15)


def _label_value_pairs(cells: list[str]) -> int:
    """'라벨 | 값 | 라벨 | 값' 행의 쌍 수 — 쌍이 둘 이상이고 칸의 60% 이상을 덮을 때만, 아니면 0.
    값 칸이 열 이름다운 낱말('일자'·'비고')이면 쌍이 아니다 — '담당 | 일자 | 구분 | 비고' 머리글 보호."""
    pairs = 0
    j = 0
    nonempty = sum(1 for c in cells if c)
    while j + 1 < len(cells):
        lab, val = cells[j], cells[j + 1]
        if lab and val and not _headerish(val) and val.upper() not in _INFO_LABELS and lab.upper() in _INFO_LABELS:
            pairs += 1
            j += 2
        else:
            j += 1
    return pairs if pairs >= 2 and pairs * 2 >= 0.6 * max(1, nonempty) else 0


def _base_header_score(cells: list[str]) -> float:
    """차용 없이 행 자체만 본 머리글 점수 — 위 후보가 이 행의 아래 데이터를 빌려도 되는지 가를 때."""
    names = [c for j, c in enumerate(cells) if c and not (j > 0 and cells[j - 1] == c)]
    singles = sum(1 for c in names if len(c) == 1)
    valueish = sum(1 for c in names if _VALUEISH.search(c)
                   or (_INFOISH.search(c) and not (len(c) == 1 and singles >= 2)))
    valueish += _label_value_pairs(cells)
    plain = sum(1 for c in names if len(c) <= 12 and not any(ch.isdigit() for ch in c)) / max(1, len(names))
    return float(len(names) - 2 * valueish + plain)

# 순번 성격 열 — 행 식별자로 승격하면 안 됨 (삽입 시 전부 밀림)
_ORDINAL = re.compile(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", re.IGNORECASE)

# 식별자 성격의 열 이름 — 점수 가산으로 두 판이 같은 키 열을 고르게 고정
_IDENTITY_HINT = ("품번", "자재번호", "부품번호", "코드", "설명", "내용", "조건", "항목",
                  "명칭", "품명", "DESCRIPTION", "ITEM", "CODE", "ID", "NO", "번호", "PART")
_PERSON_COLS = {"담당", "담당자", "담당부서", "부서", "작성자", "작성", "성명", "이름", "검토자", "승인자", "OWNER", "PIC", "RESPONSIBLE"}
_STEP_COLS = {"공정", "공정명", "공종", "작업", "작업명", "작업 내용", "TASK", "ACTIVITY", "STEP", "PROCESS"}
# 숫자가 하나는 있어야 — 쉼표만 든 칸(','·'-,')이 숫자로 잡혀 float('')가 시트 통째로 추출을 죽였다 (검토60 ③)
_NUM_VAL = re.compile(r"^\s*-?\d[\d,]*(\.\d+)?\s*$")
# 행을 가르는 번호 열의 머리글 — 병합 숫자 칸을 비울 때도 이 열은 남긴다 (검토52 B 낮음 3)
_NAMEISH_HDR = re.compile(r"(?i)품명|명칭|품목|자재명|부품명|내용|NAME|DESC|ITEM(?!\s*NO)")   # 이름 열 (검토52 C)
_KEYISH_HDR = re.compile(r"(?i)품번|자재\s*번호|자재\s*코드|부품\s*번호|코드|PART|P/N|ITEM\s*NO|CODE|TAG|기기\s*번호")
_DATE_VAL = re.compile(r"^\s*(\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{2}[-./]\d{1,2}[-./]\d{1,2}|\d{1,2}/\d{1,2})\s*$")
_CODE_LIKE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-_./]{0,24}$")


def code_ratio(vals) -> float:
    """값 가운데 '코드'(영숫자·하이픈, 공백 없음) 모양의 비율 — 품번·태그 열 우대용."""
    vals = [str(v) for v in vals if v]
    if not vals:
        return 0.0
    return sum(1 for v in vals if _CODE_LIKE.match(v) and any(ch.isdigit() for ch in v)) / len(vals)
_VALUE_COLS = {"규격", "사양", "SPEC", "SPECIFICATION", "단가", "금액", "수량", "QTY",
               "PRICE", "AMOUNT", "UNIT PRICE", "납기", "단위", "UNIT", "DELIVERY", "비고", "REMARK",
               "REMARKS", "NOTE", "날짜", "일자", "DATE", "결과", "판정", "RESULT"}


# 회사 양식의 행 식별 열 이름 — 설정 `key_columns`에서 온다 (2026-09-06 정밀화).
# 자동 선택(_pick_key_col)이 양식마다 다른 열을 잡아 "행 5개 삭제 + 5개 추가"로 보이던 것
USER_KEY_COLS: tuple = ()


def _user_key_col(header) -> str | None:
    """머리글 가운데 사용자가 정한 키 열 이름과 같은 것 (대소문자·공백 무시). 앞에 적은 것 우선."""
    norm = {"".join(str(h).split()).upper(): h for h in header if h}
    for u in USER_KEY_COLS:
        h = norm.get("".join(str(u).split()).upper())
        if h:
            return h
    return None


def _hint_in(col: str, hint: str) -> bool:
    """열 이름에 식별 힌트가 '낱말'로 들어 있나. NO가 NOTE·NOMINAL에 걸리면 비고 열이
    행 키가 되어 메모 한 글자에 행이 신규+삭제로 갈린다 (2026-09-02 재검토)."""
    return re.search(r"(?<![A-Z])" + re.escape(hint) + r"(?![A-Z])", col.upper()) is not None


def _pick_key_combo(row_values: list[dict]):
    """단일 열로는 행을 못 가르는 표(병합된 도면번호 + 시트 + 항목) — 글자 열 두세 개의 조합이
    거의 고유하면 그 조합을 키로 (2026-09-06 블라인드 3차 29). 돌려주는 값: 열 이름 튜플 또는 None."""
    from itertools import combinations
    n = len(row_values)
    if n < 2:
        return None
    cols: list = []
    for v in row_values:
        for c in v:
            if c not in cols:
                cols.append(c)
    cand = []
    for c in cols:
        if _ORDINAL.match(c.strip()) or c.strip().upper() in _VALUE_COLS or c.strip().upper() in _PERSON_COLS:
            continue
        vals = [v[c] for v in row_values if v.get(c)]
        if len(vals) < n * 0.9:
            continue
        if sum(1 for x in vals if _NUM_VAL.match(x)) >= len(vals) * 0.8:
            continue                        # 숫자 열은 값이지 이름표가 아니다 ('1/2' 같은 시트 번호는 조합의 일부가 된다)
        cand.append(c)
        if len(cand) >= 5:
            break
    for size in (2, 3):
        for combo in combinations(cand, size):
            keys = [tuple(v.get(c, "") for c in combo) for v in row_values]
            if len(set(keys)) >= len(keys) * 0.95:
                return combo
    return None


def _pick_key_col(row_values: list[dict]):
    """TAG 열이 없을 때 행 식별자로 쓸 열 자동 선택(없으면 열 조합) — 채움률·고유율이 높은
    텍스트 열(설명·품번류). 인터락시트처럼 행 삭제가 잦은 표를 행번호(위치)로
    짝지으면 삭제 이후 전부 어긋나 셀 변경 수천 건 오탐이 된다 (2026-08-27 실사용).
    적합한 열이 없으면 None → 기존 행번호 방식."""
    if not row_values:
        return None
    n = len(row_values)
    best, best_score = None, 0.0
    # 머리글 순서(왼쪽부터)를 지킨다 — 동점이면 왼쪽 열. 순서는 두 판에서 같으므로 결정적이다
    # (set 정렬은 이름순이라 '기준' 열이 '점검 항목'을 이기던 것, 2026-09-06 양식 시험)
    cols: list = []
    for v in row_values:
        for c in v:
            if c not in cols:
                cols.append(c)
    for c in cols:
        if _ORDINAL.match(c.strip()):
            continue
        vals = [v[c] for v in row_values if v.get(c)]
        if len(vals) < n * 0.9:          # 거의 모든 행에 있어야
            continue
        if sum(1 for x in vals if str(x).startswith("=")) >= len(vals) * 0.5:
            continue                      # 수식 열(=AVERAGE(...))은 값이지 이름표가 아니다 (3차 06)
        uniq = len(set(vals)) / len(vals)
        if uniq < 0.9:                    # 거의 고유해야 (구역명 반복 열 배제)
            continue
        avg = sum(len(v) for v in vals) / len(vals)
        codes = code_ratio(vals)
        if avg < 2:                                          # X/O 마크 열 배제
            continue
        if sum(1 for v in vals if _NUM_VAL.match(v)) >= len(vals) * 0.8:
            continue                                         # 숫자만인 열(생산량·금액)은 값이지 이름표가 아니다
        is_date = sum(1 for v in vals if _DATE_VAL.match(v)) >= len(vals) * 0.8
        score = uniq * min(avg, 40)       # 고유하고 서술적인 열 우대
        if is_date:
            score -= 30                   # 날짜는 다른 후보가 없을 때만 (일별 기록표의 '일자')
            codes = 0.0                   # 날짜 모양은 코드가 아니다
        if codes >= 0.9:
            score += 60                   # 품번·태그 모양이면 설명 열보다 앞 (설명은 고쳐지는 칸)
        if any(_hint_in(c, h) for h in _IDENTITY_HINT):
            score += 100  # 알려진 식별 열 이름 우선 — 두 판의 키 열 선택을 고정
        # 일정표의 행 이름은 '공정'이지 '담당'(부서·사람)이 아니다 — 담당 열이 글자가 길어 이겨 '생산관리 시작: …'처럼
        # 어느 공정이 밀렸는지 안 보였다 (검토55 ④4). 사람·부서 열은 이름표에서 내리고, 공정·작업 이름은 올린다
        _cu = c.strip().upper()
        if _cu in _PERSON_COLS:
            score -= 50
        elif _cu in _STEP_COLS:
            score += 100
        if c.strip().upper() in _VALUE_COLS:
            # 규격·단가는 '바뀌는 값'이지 행의 이름표가 아니다 — 규격을 고치면
            # 신규+삭제 두 줄로 갈려 구매가 새 품목으로 오해 (2026-09-02 검토)
            score -= 1000
        if score > best_score:
            best, best_score = c, score
    return best if best is not None else _pick_key_combo(row_values)


_REV_COL = re.compile(r"^(REV(ISION)?|개정|판|버전|VER)", re.IGNORECASE)
_REV_COL_NOT = re.compile(r"(일자|날짜|DATE|내용|사유|비고|자|DESC)", re.IGNORECASE)


def _rev_key_col(row_values: list[dict]) -> str | None:
    """개정이력 표의 REV 열(REV·REVISION·개정·판·VER — 일자·내용·작성자 열 아님) — 거의 모든 행에 있고 거의 고유하면 그 이름."""
    n = len(row_values)
    if n < 1:
        return None
    cols: list = []
    for v in row_values:
        for c in v:
            if c not in cols:
                cols.append(c)
    for c in cols:
        cs = str(c).strip()
        if not _REV_COL.match(cs) or _REV_COL_NOT.search(cs):
            continue
        vals = [str(v[c]).strip() for v in row_values if str(v.get(c) or "").strip()]
        # 고유성은 절반만 넘으면 된다 — 사람이 같은 Rev를 두 행에 적은 날(A·B·B) 0.9에서 떨어져 키가 내용 열로 바뀌고 옛 행
        # 전부가 지움+추가로 나갔다 (ux20 buy 6). 같은 Rev 여러 행은 diff가 값이 같은 행끼리 먼저 짝짓는다(_keyed_pair)
        if len(vals) < n * 0.9 or len(set(vals)) < len(vals) * 0.5:
            continue
        if any(len(x) > 12 for x in vals):
            continue
        return c
    return None


_HEADERISH = {"항목", "결과", "판정", "비고", "구분", "내용", "일자", "수량", "코드", "LOT", "NO", "번호", "순번",
              "이름", "성명", "담당", "부서", "규격", "사양", "단가", "금액", "합계", "기준", "측정", "위치",
              "ITEM", "RESULT", "REMARK", "REMARKS", "QTY", "DATE", "CODE", "DESCRIPTION", "SPEC", "NAME"}


def _headerish(name: str) -> bool:
    """열 이름다운가 — 알려진 이름이거나 그 낱말을 품거나(측정 항목·LOT NO) 열 이름 꼴 접미(…명·…번호·…량·…값)."""
    u = str(name).upper()
    toks = {t for t in re.split(r"[\s·/()\[\]:_-]+", u) if t}
    if u.strip() in _KNOWN_HEADER or toks & (_KNOWN_HEADER | _HEADERISH):
        return True
    if any(_hint_in(u, h) for h in _IDENTITY_HINT):
        return True
    return re.search(r"(명|번호|수량|중량|용량|일자|일|값|율|률|명칭|위치|업체|담당|비고|여부)$", u.strip()) is not None


def _type_sig(cells: list) -> tuple:
    """칸마다 'n'(숫자·날짜) / 't'(글자) / ''(빈 칸) — 뒤쪽 빈 칸은 뗀다."""
    sig = ["n" if (_NUM_VAL.match(c) or _DATE_VAL.match(c)) else "t" if c else "" for c in cells]
    while sig and not sig[-1]:
        sig.pop()
    return tuple(sig)


def _majority_sig(rows: list) -> tuple:
    """데이터 행들의 다수 유형 서명 — 행이 없으면 빈 튜플."""
    rows = [r for r in rows if any(r)]
    if not rows:
        return ()
    width = max(len(r) for r in rows)
    # 칸 유형은 행마다 한 번만 — 열마다 앞부분을 다시 재어 행×열² 정규식이 돌았고, 2만 행×200 열 BOM이 300초 상한에
    # 걸려 매일 비교가 빠졌다 (검토58 F6 F3). 결과는 같다(빈 칸·행 밖은 '')
    sigs = [["n" if (_NUM_VAL.match(c) or _DATE_VAL.match(c)) else "t" if c else "" for c in r] for r in rows]
    out = []
    for j in range(width):
        c = Counter(s[j] if j < len(s) else "" for s in sigs)
        out.append(c.most_common(1)[0][0])
    while out and not out[-1]:
        out.pop()
    return tuple(out)


def _unique_header(names: list) -> list:
    """같은 이름의 열이 여럿이면(병합 '측정값' 아래 세 칸) 뒤 것에 #2·#3 — 사전에서 마지막 칸만 남아
    값 변경이 사라지던 것 (리뷰11 차단-C)."""
    seen: Counter = Counter()
    out = []
    for h in names:
        if h:
            seen[h] += 1
            out.append(h if seen[h] == 1 else f"{h}#{seen[h]}")
        else:
            out.append(h)
    return out


def _small_int(c: str) -> bool:
    return bool(_NUM_VAL.match(c)) and 0 <= float("".join(c.split(","))) <= 99 \
        and float("".join(c.split(","))).is_integer()


def _two_col_header(cells: list[str], nxt) -> bool:
    """두 칸짜리 표('항목 | 금액')의 머리글 — 짧은 글자 둘(숫자 없음) 아래에 숫자·날짜 값이 오면.
    알려진 열 이름이 아니어도 인정한다 (2026-09-06: 견적 요약·명세서 소형 표가 세로 양식으로 오인)."""
    texts = [(j, c) for j, c in enumerate(cells) if c]
    if len(texts) != 2 or not nxt:
        return False
    if any(len(c) > 12 or any(ch.isdigit() for ch in c) for _, c in texts):
        return False
    # 표지의 'REV | B', 'DATE | 날짜'는 머리글이 아니라 표제 칸(라벨 | 값)이다 — 머리글로 삼켜 REV를 못 읽고 Rev 올림이
    # '열 이름 변경 B→C'로 나왔다 (검토62 A-C)
    if _head_canon(texts[0][1]):
        return False
    j2 = texts[1][0]
    v = nxt[j2] if j2 < len(nxt) else ""
    return bool(v) and bool(_NUM_VAL.match(v) or _DATE_VAL.match(v) or _VALUEISH.search(v))


def _looks_like_header(cells: list[str]) -> bool:
    """머리글 후보: 문자 셀이 3개 이상이고 숫자 위주가 아님.
    실무 BOM은 위에 빈 행·제목 행이 있는 경우가 많다 (2026-08-23 실사용 발견).
    열이 2개뿐인 표는 알려진 열 이름(TAG·품명 등)이 있을 때만 인정
    (2026-08-26 — 제목 행 오인 방지와 소형 표 지원의 절충)."""
    texts = [c for c in cells if c]
    if len(texts) < 2:
        return False
    if len(texts) < 3 and not any(t.upper().strip() in _KNOWN_HEADER for t in texts):
        return False

    def is_num(s: str) -> bool:
        try:
            float(s)
            return True
        except ValueError:
            return False

    numeric = sum(1 for c in texts if is_num(c))
    # 샘플 번호 열(1 2 3 4 5)처럼 작은 정수가 이어지면 열 이름이다 (2026-09-06 수입검사 성적서)
    ints = [int(float(c)) for c in texts if is_num(c) and float(c) == int(float(c)) and 0 <= float(c) <= 99]
    if numeric and len(ints) == numeric and ints == sorted(ints) and len(set(ints)) == len(ints):
        return True
    return numeric <= len(texts) // 2


def _merged_anchor_map(ws) -> dict:
    """병합 범위의 모든 좌표 → 앵커(좌상단) 좌표. 병합 셀 값 전파용 —
    품명이 3~4행 병합된 실무 BOM에서 품명 없는 유령 행이 생기는 것 방지."""
    out: dict[tuple[int, int], tuple[int, int]] = {}
    # 표 범위 밖은 볼 일이 없다 — 시트 전체 병합(A1:XFD1048576) 하나가 좌표 170억 개를 만들려 했다 (검토63 D-F2)
    lim_r, lim_c = _real_extent(ws)
    try:
        for rng in ws.merged_cells.ranges:
            anchor = (rng.min_row, rng.min_col)
            for r in range(rng.min_row, min(rng.max_row, lim_r) + 1):
                for c in range(rng.min_col, min(rng.max_col, lim_c) + 1):
                    if (r, c) != anchor:
                        out[(r, c)] = anchor
    except Exception:
        pass
    return out


_GAP_ROWS, _GAP_COLS = 2000, 200


def _real_extent(ws) -> tuple[int, int]:
    """값이 있는 셀 기준의 (마지막 행, 마지막 열). 엑셀에서 서식을 넣었다 지운 흔적으로
    '사용 범위'가 30만 행×60열까지 부풀어 있으면 iter_rows가 1,800만 개의 빈 셀 객체를
    만들어 5GB·2분을 먹었다 (2026-09-04 검토 extract C-1).
    표에서 멀리 떨어진 외톨이 칸(XFD1048576에 메모 하나)은 범위에서 빼고 ws._drev_far에 남긴다 — 그 칸 하나 때문에
    100만 행×1만6천 열을 만들어 10~30GB·4분을 먹었다 (검토63 D-F2). 그 칸들은 글줄로 따로 비교한다."""
    cells = getattr(ws, "_cells", None)
    if not isinstance(cells, dict):
        return int(ws.max_row or 0), int(ws.max_column or 0)
    filled = [(r, c, cell.value) for (r, c), cell in cells.items()
              if not (cell.value is None or (isinstance(cell.value, str) and not cell.value.strip()))]
    if not filled:
        return 0, 0

    def _cut(vals, gap):
        last = 0
        for v in sorted(set(vals)):
            if last and v - last > gap:
                break
            last = v
        return last
    max_r = _cut([r for r, _c, _v in filled], _GAP_ROWS)
    max_c = _cut([c for _r, c, _v in filled], _GAP_COLS)
    far = [(r, c, v) for r, c, v in filled if r > max_r or c > max_c]
    try:
        ws._drev_far = far[:200]
    except Exception:
        pass
    return max_r, max_c


def _one_table_split(hdr: list, data_rows: list, left: tuple, right: tuple, left_names: set) -> bool:
    """머리글 행 하나를 빈 열 **하나**가 가른 두 조각이 사실은 한 표인가 — 두 조각이 같은 행들(3행 이상)을 채우면
    (90% 넘게 겹침) 그렇다. 오른쪽 조각에도 키 열다운 열(설명·SPEC)이 있다고 독립 표로 쪼개
    'BOM·DOC. NO.'·'BOM·REV' 가짜 시트 둘이 되어 열 삭제 6·시트 추가가 나고 그날의 셀 편집이 묻혔다 (뒤흔들기 XLSX X3,
    2026-10-20). 옆에 놓인 작은 표(행 수가 다름)는 그대로 따로"""
    l0, l1 = left
    r0, r1 = right
    if r0 - l1 != 1 or any(h in left_names for h in hdr[r0:r1] if h):
        return False
    # 합계·소계 행과 표 끝 아래 꼬리 행(한쪽 조각에만 '합계'·'부가세'·'총액' 라벨과 금액)은 세지 않는다
    body = [(i, cells) for i, cells in data_rows if not any(c and _TOTAL_ROW.match(c) for c in cells)]
    lrows = {i for i, cells in body if any(cells[l0:l1])}
    rrows = {i for i, cells in body if any(cells[r0:r1])}
    if lrows & rrows:
        last = max(lrows & rrows)
        tail_l, tail_r = {i for i in lrows if i > last}, {i for i in rrows if i > last}
        if len(tail_l) <= 3 and len(tail_r) <= 3:          # 꼬리(합계·부가세·총액)만 — 한쪽이 훨씬 긴 표는 그대로 센다
            lrows, rrows = lrows - tail_l, rrows - tail_r
    if len(lrows) < 3 or not rrows:
        return False
    both = len(lrows & rrows)
    return both >= 0.9 * len(lrows) and both >= 0.9 * len(rrows)


def _sheet_rows(ws, merged: dict, multi: bool = False,
                formulas: dict | None = None, title_cells: list | None = None,
                headers_out: dict | None = None, rev_sheet: bool = False,
                layout_out: list | None = None) -> tuple[list[Row], list[str], list[str]]:
    """한 시트의 데이터 행. 돌려주는 값: (rows, 머리글).

    머리글은 '첫 그럴듯한 행'이 아니라 **상위 10행 중 열 이름이 가장 많은 행**을
    고른다 — 인터락시트처럼 제목 행(3~4칸)이 위에 있고 진짜 머리글(장비별 열
    수십 개)이 아래 있는 양식에서, 제목을 머리글로 오인해 열이 1개로 붕괴되고
    매트릭스 전체가 버려지던 문제 (2026-08-27 실사용 발견)."""
    rows: list[Row] = []
    grid: dict[tuple[int, int], str] = {}

    def cell_text(r: int, c: int, raw) -> str:
        if raw is None and formulas:
            raw = formulas.get((r, c))            # '=SUM(E5:E10)' — 값이 없으면 수식이라도 (2026-09-06)
        if isinstance(raw, datetime.datetime) and (raw.hour, raw.minute, raw.second) == (0, 0, 0):
            raw = raw.date()                  # '2026-08-22 00:00:00' → '2026-08-22' (2026-09-06)
        elif isinstance(raw, datetime.datetime):
            # 시각이 있으면 분까지 한 덩어리로 — 'YYYY-MM-DD HH:MM:SS'의 ':SS'가 제목 칸 라벨·값 짝에서 떨어져 ':00' 글줄이
            # 거짓 변경으로 남았다 (검토60 ④)
            raw = raw.strftime("%Y-%m-%d %H:%M")
        v = "" if raw is None else str(raw).strip()
        if "  " in v:
            v = re.sub(r"(?<=\S) {2,}(?=\S)", " ", v)   # 값 안 띄어쓰기 두 칸은 화면에서 구별 안 된다 (검토62 B7)
        if not v and (r, c) in merged:
            v = grid.get(merged[(r, c)], "")
            if v:
                propagated.add((r, c))
        grid[(r, c)] = v
        return v

    propagated: set = set()       # 병합 앵커에서 채워 넣은 칸 — 숫자 칸은 행마다 되풀이하지 않는다 (검토51 B 중간 4)

    all_cells: list[tuple[int, list[str]]] = []
    max_r, max_c = _real_extent(ws)
    if max_r == 0:
        return [], [], []
    for i, raw in enumerate(ws.iter_rows(min_row=1, max_row=max_r, max_col=max_c,
                                         values_only=True), start=1):
        all_cells.append((i, [cell_text(i, j, v) for j, v in enumerate(raw, start=1)]))

    header_idx = None
    best = -1.0
    best_infoish = False
    by_idx = dict(all_cells)
    rank = 0                                   # 비어 있지 않은 행의 순번
    # 머리글 찾는 창은 **값 있는 행 30개** — 시트 1행부터 30행으로 잡았더니 위에 빈 행을 띄운 표(오프셋·표제 줄 합쳐 머리글이
    # 31행 아래)를 통째로 못 읽어 열 전부 삭제·'값' 열 추가·표제 칸 소실이 났고, 31행 아래 표의 셀 편집은 '행N.값' 통째 변경으로만
    # 보였다 (뒤흔들기 XLSX X1, 2026-10-20). 빈 행은 세지 않으니 예전 창(1~30행)을 언제나 품는다
    _win: list = []
    _ne = 0
    for _i, _cells in all_cells:
        if any(_cells):
            _ne += 1
            if _ne > 30:
                break
        _win.append((_i, _cells))
    for i, cells in _win:
        if any(cells):
            rank += 1
        # 두 칸 머리글은 표 첫머리(둘째 행까지)에서만 — 세로 양식 중간의 '통신 | Ethernet/IP'가
        # 머리글이 되지 않게
        if not _looks_like_header(cells) and not (rank <= 2 and _two_col_header(cells, by_idx.get(i + 1))):
            continue
        # 병합으로 옆 칸에 반복된 이름('1호기 | 1호기 | 1호기')은 하나로 센다 — 그룹 제목 행이
        # 진짜 머리글보다 넓어 보이던 것 (2026-09-06 블라인드 3차 28)
        names = [c for j, c in enumerate(cells) if c and not (j > 0 and cells[j - 1] == c)]
        # 날짜·코드·숫자처럼 '값'인 칸은 열 이름이 아니다 — 발주서의 정보 블록
        # ("발주번호 | PO-2026-014-01 | 발주일 | 2026-09-01")이 표 머리글을 빼앗던 것 (2026-09-06).
        # 단 '1 2 3 4 5'처럼 이어지는 작은 정수는 샘플 번호 열 이름이다 (수입검사 성적서)
        ints = [c for c in names if _NUM_VAL.match(c) and float("".join(c.split(","))) == int(float("".join(c.split(","))))
                and 0 <= float("".join(c.split(","))) <= 99]
        seq_names = set(ints) if len(ints) >= 3 and ints == sorted(ints, key=lambda s: float("".join(s.split(",")))) else set()
        singles = sum(1 for c in names if len(c) == 1)

        def _infoish(c: str) -> bool:                 # A|B|C 같은 연속 한 글자 열은 이름이다 (리뷰11 중간-E)
            return bool(_INFOISH.search(c)) and not (len(c) == 1 and singles >= 2)
        valueish = sum(1 for c in names if c not in seq_names and (_VALUEISH.search(c) or _infoish(c)))
        # '설비 | 1호기 | 라인 | A라인' '작성 | 김철수 | 검토 | 이영희' — 라벨과 값이 번갈아 오는 정보 행 (리뷰11 차단-D)
        valueish += _label_value_pairs(cells)
        # 이름 수는 중복 포함 — 옆으로 놓인 표 둘은 같은 열 이름을 두 번 쓴다 (3차 28). 숫자 없는 짧은
        # 이름 비율을 더해 '전원 투입 | 이상 없음 | OK' 같은 데이터 행이 머리글을 빼앗지 않게
        plain = sum(1 for c in names if len(c) <= 12 and not any(ch.isdigit() for ch in c)) / max(1, len(names))
        score = float(len(names) - 2 * valueish + plain)
        # 아래 두 행이 이 열들을 얼마나 채우나, 숫자가 얼마나 있나 — 진짜 머리글 밑에는 데이터가
        # 있고 데이터에는 숫자가 있다. 정보 블록(수신/견적번호/건명/유효기간) 밑에는 또 라벨이 온다
        # (2026-09-06 블라인드 2차 18·27: 정보 블록을 머리글로 잡아 NG 판정을 놓침)
        cols = [j for j, c in enumerate(cells) if c]
        fill, numeric = 0.0, 0.0
        # 바로 아래 행이 더 넓은 머리글 후보면 그 밑의 데이터는 이 행 것이 아니다 — 정보 행
        # ('수신: OO사 | 발주일 | B')이 진짜 머리글의 데이터 행을 빌려 점수를 받던 것 (리뷰10 차단-1)
        # 단 옆 칸에 같은 이름이 반복된 그룹 행('기준 | 기준 | 결과 | 결과')은 아래 줄이 하위 열 이름이니 예외.
        # 두 줄 아래까지 본다 — 정보 행이 두 줄 위에 있어도 진짜 머리글의 데이터를 빌리던 것 (리뷰11 차단-D)
        is_group = any(c and j > 0 and cells[j - 1] == c for j, c in enumerate(cells))
        base_score = score
        shadowed = False
        for k in (i + 1, i + 2):
            nxt = by_idx.get(k)
            if not nxt:
                continue
            nxt_names = [c for j, c in enumerate(nxt) if c and not (j > 0 and nxt[j - 1] == c)]
            # 아래 행이 더 넓거나, 아래 행에만 열 이름다운 낱말(품명·수량·UNIT)이 있을 때 — 이 행에도 그런 낱말이
            # 있으면(한글 머리글 아래 영문 머리글 줄) 그 줄은 하위 줄이지 경쟁자가 아니다
            if not is_group and _looks_like_header(nxt) and _base_header_score(nxt) >= base_score \
                    and (len(nxt_names) > len(names)
                         or (any(_headerish(c) for c in nxt_names) and not any(_headerish(c) for c in names))):
                shadowed = True              # 아래 행이 더 머리글답다('품명 | 수량 | 단위') — 그 밑 데이터는 이 행 것이 아니다
                break
            got = [nxt[j] for j in cols if j < len(nxt) and nxt[j]]
            fill = max(fill, len(got) / max(1, len(cols)))
            numeric = max(numeric, sum(1 for v in got if _VALUEISH.search(v) or _NUM_VAL.match(v))
                          / max(1, len(got)))
        score += 3 * fill + 2 * numeric
        # 이미 후보가 있으면 확실히 나을 때(+2)만 교체 — 머리글 아래의 텍스트가
        # 풍부한 데이터 행이 열 한두 개 차이로 머리글을 빼앗지 않게 (2026-08-27).
        # 단 앞 후보가 값 칸('B'·'수신: OO사'·날짜)을 품은 정보 행이거나 아래에 더 나은 머리글 후보가 있어
        # 차용을 못 받은 행이면 우대 없이 비교한다
        need = best + (0.5 if best_infoish else 2) if header_idx is not None else best + 0.5
        if score >= need:
            best, header_idx, best_infoish = score, i, (valueish >= 1 or shadowed)
    if header_idx is None:
        # 머리글 없는 세로 양식(사양 카드: '처리 속도 | 60 팩/분') — 첫 칸을 항목 이름(키)으로,
        # 나머지를 값으로 (2026-09-06 블라인드 2차 05·08: 항목 0건으로 비교가 통째로 빠짐)
        kv: list[Row] = []
        for i, cells in all_cells:
            texts = [c for c in cells if c]
            if len(texts) < 2 or not texts[0] or len(texts[0]) > 40:
                continue
            kv.append(Row(key="".join(texts[0].split()), values={"값": " | ".join(texts[1:])},
                          where=f"{ws.title}!행{i}"))
        return kv, ["항목", "값"], []
    header = [c.upper() for c in dict(all_cells)[header_idx]]
    top_header_idx = header_idx          # 여러 줄 머리글을 합치기 **전** 첫 머리글 행 (제목 칸은 그 위만)
    # 대분류/중분류/열 이름처럼 머리글이 여러 줄이면 아래 줄을 붙여 '기준 하한'·'결과 측정'으로 —
    # 그러지 않으면 둘째 줄이 데이터 행이 되어 값 변경이 엉뚱한 이름으로 나온다 (2026-09-06 3차 04)
    for extra in (header_idx + 1, header_idx + 2):
        nxt = by_idx.get(extra)
        after = by_idx.get(extra + 1)
        if not nxt or not after:
            break
        cells_n = [c for c in nxt if c]
        if not cells_n or any((any(ch.isdigit() for ch in c) and not _small_int(c)) or len(c) > 16 for c in cells_n):
            break
        if not any(_NUM_VAL.match(c) or _VALUEISH.search(c) for c in after if c):
            break
        # 아래 줄이 '하위 열 이름'인가 — 대부분 병합 그룹(옆 칸과 같은 이름) 아래에 놓여야 한다.
        # 데이터 행('전원 투입 | 이상 없음 | OK')은 고유한 이름 칸 아래에 오므로 합치지 않는다
        under_group = sum(1 for j, c in enumerate(nxt) if c and j < len(header)
                          and (not header[j] or (j > 0 and header[j - 1] == header[j])
                               or (j + 1 < len(header) and header[j + 1] == header[j])))
        if under_group < 0.6 * len(cells_n):
            break
        # 하위 열 이름은 서로 달라야 한다('양호 | 양호 | 양호'는 데이터). 그 값이 아래 행 같은 열에
        # 다시 나와도 데이터 (리뷰10 중간-1: 첫 데이터 행이 머리글로 합쳐져 값 변경을 삼킴)
        if len(set(cells_n)) < len(cells_n):
            break
        if any(j < len(after) and after[j] == c for j, c in enumerate(nxt) if c):
            break
        merged_names = []
        for j in range(max(len(header), len(nxt))):
            top = header[j] if j < len(header) else ""
            sub = nxt[j].upper() if j < len(nxt) else ""
            merged_names.append(f"{top} {sub}".strip() if sub and sub != top else top)
        header = merged_names
        header_idx = extra
    # 머리글 위의 제목 행("견 적 서", "수신: …") — 문서 유형의 가장 확실한 단서인데
    # 버려져 내용 판정이 머리글에만 기대던 것 (2026-09-03 재검토)
    titles = [" ".join(dict.fromkeys(c for c in cells if c))
              for i, cells in all_cells if i < header_idx and any(cells)][:10]
    if title_cells is not None:          # 칸 단위(빈 칸 포함, 자리 그대로) — 표제 칸('REV | A') 읽기용 (검토38 R4-C)
        # 합친 머리글의 윗줄('ITEM | RATING | REV | REMARK')은 제목이 아니다 — 그 줄에서 REV='REMARK'를 읽어
        # 셀 하나만 고쳐도 매번 'Rev 미갱신'이 났다 (검토40 A 차단 1)
        title_cells.extend(list(cells) for i, cells in all_cells if i < top_header_idx and any(cells))
        title_cells.append(("__HEADER__", *header))
    # 머리글 없는 열의 낱 셀(표 옆 메모·비고) — 버려져 "글자·표·그림 동일"로 단언됐다
    # (검토19 감지 ⑥). 글줄로 남겨 글자 비교가 본다
    stray: list[str] = []
    stray_rows: list = []          # (행 번호, 그 행의 값 사전, 머리글 없는 칸들)

    from watcher.diff import strip_leading_no

    def emit(hdr, data_rows, base_name, group_title_fn):
        """머리글 하나와 그 데이터 행들로 Row를 만든다. 옆으로 놓인 표는 빈 열로 나눈다."""
        ncol = len(hdr)
        gap = [not hdr[j] and all(j >= len(c) or not c[j] for _, c in data_rows) for j in range(ncol)]
        segments: list = []
        start = None
        for j in range(ncol + 1):
            if j < ncol and not gap[j]:
                if start is None:
                    start = j
            elif start is not None:
                if sum(1 for k in range(start, j) if hdr[k]) >= 2:
                    segments.append((start, j))
                start = None
        if len(segments) > 1:
            # 오른쪽 조각에 행을 가를 열(품번·항목·TAG…)이 없으면 빈 열 하나 끼어든 한 표다 —
            # '코드 품명 | (빈 열) | 납기 업체'가 표 둘로 갈려 무변경 파일에 시트 추가·삭제가 나던 것 (리뷰10)
            kept = [segments[0]]
            for c0, c1 in segments[1:]:
                sh = hdr[c0:c1]
                seg_rows = [r for r in ({h: v for h, v in zip(sh, cells[c0:c1]) if h and v} for _, cells in data_rows) if r]
                left_names = {h for h in hdr[kept[-1][0]:kept[-1][1]] if h}
                standalone = _user_key_col(sh) is not None or any(r.get("TAG") for r in seg_rows) \
                    or _pick_key_col(seg_rows) is not None \
                    or any(h in left_names for h in sh if h)      # 이름이 겹치면 합칠 수 없다 (리뷰11 차단-B)
                if standalone and _one_table_split(hdr, data_rows, kept[-1], (c0, c1), left_names):
                    standalone = False
                if standalone:
                    kept.append((c0, c1))
                else:
                    kept[-1] = (kept[-1][0], c1)
            segments = kept
        if len(segments) <= 1:
            segments = [(0, ncol)]
        for si, (c0, c1) in enumerate(segments, start=1):
            if len(segments) == 1:
                sname = base_name
            else:
                gtitle = group_title_fn(c0, c1)
                sname = f"{base_name}·{gtitle or f'표{si}'}"
            seg_header = _unique_header(hdr[c0:c1])
            if headers_out is not None:          # 표마다의 머리글 — 드문 열 삭제를 가르는 데 쓴다 (검토68 C3)
                headers_out[sname] = [h for h in seg_header if h]
            collected: list[tuple[int, dict]] = []
            totals: list[tuple[int, str, dict]] = []
            for i, cells in data_rows:
                seg = cells[c0:c1]
                if not any(seg):
                    continue
                tlabel = next((c for c in seg if c and _TOTAL_ROW.match(c)), None)
                if tlabel:
                    # 소계/합계 행은 위치가 밀려도 라벨('합계', '소계')을 키로 삼아 값만 비교한다 —
                    # 통째로 버렸더니 "단가는 바뀌었는데 합계는 그대로"로 읽혔다 (2026-09-06 블라인드 채점 1순위)
                    tv = {h: v for h, v in zip(seg_header, seg) if h and v and not _TOTAL_ROW.match(v)}
                    if tv:
                        totals.append((i, "".join(tlabel.split()), tv))
                    continue
                # 병합으로 채워 넣은 값만 있는 행은 앵커 행의 이어짐이다. 숫자 칸(수량·단가)의 병합 값은 앵커 행에만 둔다 —
                # 3행 병합된 수량 1→2가 '행2·행3·행4 수량' 3건으로 보고됐다 (검토51 B 중간 4). 이름 칸은 계속 채운다(키)
                if not any(v and (i, c0 + k + 1) not in propagated for k, v in enumerate(seg)):
                    continue
                # 숫자 품번·코드 열(키)은 비우지 않는다 — 이어짐 행에서 품번이 빠졌다 (검토52 B 낮음 3)
                # 숫자가 든 값('1 SET'·'₩4,500,000'·'=C2*D2')도 — 순수 숫자만 비워 2~3건 중복이 남았다 (검토52 C 중간 2).
                # 이름 열(품명·설명)은 숫자가 있어도('MCCB 100AF') 이어짐 행을 이름 붙이는 데 쓰므로 남긴다
                def _blank_prop(k, v):
                    h = str(seg_header[k] if k < len(seg_header) else "")
                    return (v and (i, c0 + k + 1) in propagated and re.search(r"\d", v)
                            and not _KEYISH_HDR.search(h) and not _NAMEISH_HDR.search(h))
                seg = [("" if _blank_prop(k, v) else v) for k, v in enumerate(seg)]
                # 머리글이 빈 열은 데이터로 취급하지 않는다 (수백 열짜리 양식 대응)
                values = {h: v for h, v in zip(seg_header, seg) if h and v}
                extras = [v for h, v in zip(seg_header, seg) if not h and v]
                if extras and len(stray_rows) < 200:
                    stray_rows.append((i, values, extras))
                if values:
                    collected.append((i, values))
            if layout_out is not None:           # 수식 참조를 열 이름·표 안 행 차례로 읽는 데 쓴다 (뒤흔들기 XLSX X2)
                layout_out.append(({c0 + k + 1: h for k, h in enumerate(seg_header) if h}, [i for i, _ in collected], sname))

            # 행 식별자: 사용자가 정한 키 열 > TAG 열 > 자동 선택된 식별 열(설명·품번류, 또는 두세 열의 조합) > 행번호
            key_col = None
            user_col = _user_key_col(seg_header)
            # 'TAG.'·'TAG NO.'·'TAG NAME'·'태그'·'태그번호'도 TAG 열 — 'TAG'만 보아 행 키가 품명(MOTOR)이 됐다 (검토20 r08 2)
            tag_col = rowkey_tag_head(seg_header) or "TAG"
            if user_col is None and not any(v.get(tag_col) for _, v in collected):
                key_col = _pick_key_col([v for _, v in collected])
                if rev_sheet:
                    # 개정이력 시트의 행 이름표는 REV 열이다 — 사유 열로 고르면 사유 빈칸 행 하나로 채움률이 90% 밑으로 떨어져
                    # 그날만 위치 키로 바뀌고, 옛 행 전부가 삭제+추가(재키잉)로 나가며 재추가된 옛 행의 사유가 'Rev만 갱신'
                    # 경고를 지웠다 (대량 시험 XLSX F4, 2026-10-20). 거의 모든 행에 있고 거의 고유할 때만
                    _rv = _rev_key_col([v for _, v in collected])
                    if _rv:
                        key_col = _rv

            # TAG 열이 있는 표의 TAG 빈 행(전선·단자대·소모품)은 행 번호가 아니라 품명+규격으로 — 맨 위에 한 행만 끼워도
            # 아래 빈 행이 전부 밀려 거짓 변경 10건이 났고, 그걸 피하려 diff가 품명 열로 갈아타면 태그 개명이 묻혔다
            # (검토53 A 차단 1·E 차단 1·중간 2·3). 같은 품명·규격이 여럿이면 diff가 #2·#3으로 가른다
            tagged = user_col is None and any(v.get(tag_col) for _, v in collected)
            _nm = [h for h in seg_header if h and h != tag_col and _NAMEISH_HDR.search(str(h))] if tagged else []
            # 품명·NAME·DESC가 ITEM(분류)·내용(코드)보다 먼저 — 앞 열이 '전장/배관' 분류면 키가 '전장 · ACRYL'이 됐다 (검토53 I 낮음 9)
            name_cols = sorted(_nm, key=lambda h: 0 if re.search(r"(?i)품명|명칭|자재명|부품명|NAME|DESC", str(h)) else 1)[:1]
            spec_cols = [h for h in seg_header if h and h not in name_cols
                         and (re.search(r"(?i)SPEC|규격|사양|형식|MODEL|RATING", str(h))
                              or bom_head([h], BOM_SPEC_HEADS))][:1] if tagged else []     # 대조기와 같은 이름(TYPE 등)

            def key_of(values) -> str | None:
                if user_col:
                    return strip_leading_no(values.get(user_col)) or None
                if values.get(tag_col):
                    return values[tag_col]
                if name_cols:
                    parts = [str(values.get(c)).strip() for c in name_cols + spec_cols if values.get(c)]
                    if parts and values.get(name_cols[0]):
                        return " · ".join(parts)
                if isinstance(key_col, tuple):
                    parts = [strip_leading_no(values.get(c)) for c in key_col if values.get(c)]
                    return " ".join(parts) if len(parts) == len(key_col) else None
                if key_col:
                    return strip_leading_no(values.get(key_col)) or None
                return None
            hdr_cols = [h for h in seg_header if h]
            prev_i = None
            for i, values in collected:
                gap = prev_i is not None and i > prev_i + 1      # 빈 줄 뒤에 떨어진 행만 (병합이 채운 품명 행은 아님)
                prev_i = i
                # 넓은 표(4칸 이상) 아래 앞 두 칸만 쓴 '라벨 | 값' 행('납기 | 2026-10-30')은 표의 한 행이 아니라 항목이다 —
                # 표 행으로 붙어 키가 날짜, 칸 이름이 '공정'이 되어 납기 2주 연기가 '2026-10-30 공정'으로 보였다 (검토54 ④17)
                filled = [(h, v) for h, v in values.items() if str(v or "").strip()]
                if (gap and len(hdr_cols) >= 4 and 1 <= len(filled) <= 2 and filled[0][0] == hdr_cols[0]
                        and (len(filled) == 1 or filled[1][0] == hdr_cols[1])):
                    lab = str(filled[0][1]).strip()
                    if 0 < len(lab) <= 16 and not re.search(r"\d", lab):
                        rows.append(Row(key=lab, values={"값": str(filled[1][1]).strip() if len(filled) == 2 else ""},
                                        where=f"{sname}!행{i}"))
                        continue
                rows.append(Row(key=key_of(values) or f"{sname}!행{i}", values=values, where=f"{sname}!행{i}"))
            # 머리글 없는 칸은 행 번호가 아니라 그 행의 키(품번·태그)로 이름 붙인다 — 행 하나를
            # 끼워 넣으면 아래 칸 전부가 "[비고 2행]→[비고 3행]" 변경으로 도배됐다 (검토19 2차 N4)
            for i, values, extras in stray_rows:
                k = (key_of(values) if values else None) or f"{i}행"
                stray.extend(f"[비고 {k}] {v}" for v in extras)
            seen_t: Counter = Counter()
            for i, tlabel, tv in totals:
                seen_t[tlabel] += 1
                key = f"{tlabel}#{seen_t[tlabel]}" if seen_t[tlabel] > 1 else tlabel
                if multi:
                    key = f"{sname} {key}"        # 시트마다 '합계'가 있으면 어느 시트인지
                rows.append(Row(key=key, values=tv, where=f"{sname}!행{i}"))

    def group_title(c0: int, c1: int) -> str:
        """옆으로 놓인 표의 이름 — 머리글 위 세 줄 안에서 그 표 자리에 적힌 제목"""
        for k in (1, 2, 3):
            row = by_idx.get(header_idx - k)
            if row and any(row[c0:c1]):
                return next(c for c in row[c0:c1] if c)
        return ""

    # 위아래로 놓인 표 여럿: 빈 행으로 나뉜 덩어리 가운데 첫 행이 머리글 같고 열 이름이 본 표와 다르면
    # 따로 읽는다 — LOT표·측정표·외관표가 위아래로 있는 성적서에서 첫 표가 '제목'으로 뭉개지던 것
    # (2026-09-06 블라인드 3차 03). 빈 행이 끼어든 한 표(열 이름이 이어지지 않음)는 나누지 않는다
    blocks: list = []
    cur: list = []
    for i, cells in all_cells:
        if any(cells):
            cur.append((i, cells))
        elif cur:
            blocks.append(cur); cur = []
    if cur:
        blocks.append(cur)
    main_names = {h for h in header if h}
    main_block = next((b for b in blocks if any(i == header_idx for i, _ in b)), [])
    main_sig = _majority_sig([cs for i, cs in main_block if i > header_idx])
    extra_blocks: list = []
    main_block_rows: set = set()
    for blk in blocks:
        rows_in = {i for i, _ in blk}
        if header_idx in rows_in:
            main_block_rows = rows_in
            continue
        first_i, first_cells = blk[0]
        if len(blk) < 2 or not _looks_like_header(first_cells):
            continue
        # 본 표 머리글 **위**의 덩어리는 표제 칸('P26-050 BOM | REV | A' / 'DOC NO | … | DATE | …')이지 표가 아니다 — 위아래
        # 표로 또 읽혀 REV 값이 열 이름이 되고 Rev를 올린 날 거짓 'DOC NO.A → ''' 행 변경 2건이 났다 (검토51 B 중간 5)
        # 단 위 덩어리가 **진짜 표**(4행 이상, 표제 라벨 없음)면 제외하지 않는다 — 12행짜리 '항목|값|비고' 표가 통째로 사라져
        # '내용 변경 없음'을 단언했다 (검토52 A 중간 3)
        if first_i < top_header_idx and (len(blk) <= 3 or any(
                re.search(r"(?i)\bREV|DOC\.?\s*NO|DATE|PROJECT|문서\s*번호|개정|일자|프로젝트", str(c)) for c in first_cells if c)):
            continue
        names = [c for j, c in enumerate(first_cells) if c and not (j > 0 and first_cells[j - 1] == c)]
        if len(names) < 2 or any(_VALUEISH.search(c) for c in names):
            continue
        inter = len(set(n.upper() for n in names) & main_names)
        # 같은 열 이름이라도 **다른 칸 자리**에 놓였으면(본 표 '품명'은 3열, 아래 작은 표 '품명'은 2열) 따로 선 표다 — 본 표 행으로
        # 읽혀 본 표 열 이름 아래 엉뚱한 칸('단위: 옵션 앵글')이 되고, 빈 열 하나만 끼워도 행 추가·삭제가 났다 (뒤흔들기 XLSX X7b,
        # 2026-10-20). 같은 자리에 되풀이된 머리글(다음 쪽 머리글)은 예전대로 같은 표의 조각
        _mpos = {h: j for j, h in enumerate(header) if h}
        _same_pos = [n for j, n in enumerate(first_cells) if n and n.upper() in _mpos and _mpos[n.upper()] == j]
        _filled = [j for j, n in enumerate(first_cells) if n]
        _contig = bool(_filled) and _filled[-1] - _filled[0] + 1 == len(_filled)   # 머리글 칸이 빈칸 없이 이어진 작은 표만
        if inter >= 0.5 * min(len(names), max(1, len(main_names))) and (len(_same_pos) >= 0.8 * inter or not _contig):
            continue                                  # 본 표와 같은 열 이름 — 같은 표의 조각
        # 열 값 유형 서명 — 첫 행이 본 표의 데이터 행과 같은 자리·같은 유형(숫자/글자)이면 이어지는 데이터다
        # ('설치 위치 | 2층 동편'); 첫 행은 글자뿐인데 둘째 행에 숫자가 서면 새 표의 머리글이다
        # ('재질 | 두께 | 폭 | 길이' 아래 'SS400 | 6 | 100 | 200') — 이름 사전은 양쪽으로 틀렸다 (리뷰11 중간-F)
        first_sig = _type_sig(first_cells)
        if main_sig and first_sig == main_sig:
            continue
        second_sig = _type_sig(blk[1][1]) if len(blk) >= 2 else ()
        header_shape = ("n" not in first_sig and any(
            b == "n" and a == "t" for a, b in zip(first_sig, second_sig)))
        if not header_shape and not any(_headerish(n) for n in names):
            continue
        # 그 행의 값이 다른 데이터 행에도 나오면 데이터 행이다
        other_vals = {c for i2, cs in all_cells if i2 > header_idx and i2 not in rows_in for c in cs if c}
        if sum(1 for n in names if n in other_vals) >= len(names) * 0.5:
            continue
        extra_blocks.append(blk)
    extra_rows: set = set()
    for blk in extra_blocks:
        extra_rows |= {i for i, _ in blk}
    main_data = [(i, cells) for i, cells in all_cells
                 if i > header_idx and any(cells) and i not in extra_rows]
    emit(header, main_data, ws.title, group_title)
    for blk in extra_blocks:
        h_i, h_cells = blk[0]
        hdr2 = [c.upper() for c in h_cells]
        name2 = f"{ws.title}·{next(c for c in h_cells if c)}"
        emit(hdr2, blk[1:], name2, lambda c0, c1: "")
    return rows, header, titles + stray


_HEAD_LABELS = {"REV": "REV", "REVISION": "REV", "REV NO": "REV", "개정": "REV", "개정번호": "REV", "리비전": "REV",
                "DWG NO": "DWG_NO", "DRAWING NO": "DWG_NO", "도면번호": "DWG_NO",
                "DOC NO": "DOC_NO", "DOCUMENT NO": "DOC_NO", "문서번호": "DOC_NO",
                "PROJECT": "PROJECT", "PROJECT NO": "PROJECT", "프로젝트": "PROJECT", "DATE": "DATE", "일자": "DATE",
                # 성적서·발주서의 일자 칸 — DATE가 아니면 일자만 고친 날 제목 글자 변경이 되어 거짓 'Rev 미갱신' (검토41 S2 중간 5)
                "작성일": "DATE", "검사일": "DATE", "발주일": "DATE", "발주일자": "DATE", "발주 일자": "DATE", "일시": "DATE"}
# 'Rev.: B'(콜론 앞 점)도 — 'DOC NO: X  Rev.: B' 한 칸 표제의 Rev를 못 읽었다 (대량 시험 XLSX 관찰, 2026-10-20)
_HEAD_INLINE = re.compile(r"(?:(?<=\s)|^)(REV(?:ISION)?\.?|개정(?:\s*번호)?|리비전|DWG\.?\s*NO\.?|DOC(?:UMENT)?\.?\s*NO\.?|"
                          r"도면\s*번호|문서\s*번호|PROJECT(?:\s*NO\.?)?|프로젝트|DATE|일자|작성일|검사일|발주\s*일자|발주일|일시)\s*[:：]\s*(\S+)", re.I)
# 연도('REV | 2026')는 Rev가 아니다 — 모든 내용 변경에 'Rev 2026 미갱신'이 났다 (검토41 S2 중간 3).
# '-'·'—'는 빈 Rev(첫 발행 전) — 필드로 두어야 'REV -→A' 첫 기재가 Rev 올림으로 잡힌다 (검토41 S2 중간 4)
_DATE_HEAD = re.compile(r"^\d{2,4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}\s*일?(?:\s*\d{1,2}:\d{2})?")
_REV_SHAPE = re.compile(r"^(?:(?!(?:19|20)\d\d$)[A-Za-z0-9][A-Za-z0-9.\-]{0,5}|제?\s*\d{1,2}\s*[차판]|[-–—])$")


def _head_canon(label: str) -> str | None:
    return _HEAD_LABELS.get(" ".join(re.sub(r"[._:：]", " ", label.upper()).split()))


def _title_fields(cell_rows: list, sheet: str) -> tuple[list, dict]:
    """표 위 제목 행에서 ([(정규 이름, 값, 위치)], {제목 줄 글자: 필드로 읽힌 칸을 뺀 글자}).
    ① 칸 하나가 라벨이고 **바로 오른쪽** 칸(병합으로 라벨이 되풀이되면 그 다음)이 값('REV | A')
    ② 한 칸 안의 '라벨: 값'(콜론 필수 — 'PROJECT MANAGEMENT PLAN' 같은 제목을 필드로 잡지 않게).
    REV 값은 Rev 꼴일 때만, 열 이름과 같은 값은 버린다. 마지막 원소 ('__HEADER__', 열 이름…)는 머리글."""
    header = set()
    if cell_rows and cell_rows[-1] and cell_rows[-1][0] == "__HEADER__":
        header = {str(h).upper() for h in cell_rows[-1][1:] if h}
        cell_rows = cell_rows[:-1]
    out, consumed = [], {}
    for ri, cells in enumerate(cell_rows, start=1):
        # 양식 개정번호('문서번호 | QF-701 | 개정 | 3', '서식 FORM-12 Rev 2')는 이 문서의 Rev가 아니다 — 수량을 고칠 때마다
        # '개정이력 Rev가 3 그대로'가 났다 (검토42 B 중간 4)
        # 번호 접두로는 QF(Form)만 — QP(절차서)·QR(기록)은 문서 자신의 번호라 그 Rev를 버리면 Rev 검사가 꺼졌다 (검토43 A 중간 2).
        # 'FORM'은 칸 머리의 라벨일 때만
        form_row = any(re.search(r"양식|서식|^\s*FORM\b|^QF-", str(c or ""), re.I) for c in cells)
        used: set = set()
        seen_cell: set = set()      # 병합으로 옆 칸에 되풀이된 같은 글자는 한 번만 — REV가 REV#2…#5로 실렸다 (검토41 S2 중간 1)
        partial: dict = {}          # 칸 글자 → 필드로 읽힌 조각을 뺀 나머지('DRAWING LIST')
        texts = [c for c in cells if c]
        for ci, c in enumerate(cells):
            if not c or c in used or c in seen_cell:
                continue
            seen_cell.add(c)
            canon = _head_canon(c)
            if canon == "DATE" and any(o_[0] == "DATE" for o_ in out):
                # 둘째 일자 칸이 첫 일자와 **같은 날**이면 그 칸도 필드로 읽힌 것으로 뺀다 — 위에 '작성일' 줄을 더하면 '발주일 | d'가 둘째
                # 라벨이 되어 글줄에 새로 끼어 거짓 글자 변경이 났다 (뒤흔들기 XLSX X13, 2026-10-20). 다른 날이면 예전대로 글줄에 남긴다
                j = ci + 1
                while j < len(cells) and cells[j] == c:
                    j += 1
                v2_ = (cells[j] or "").strip() if j < len(cells) else ""
                dm2 = _DATE_HEAD.match(v2_)
                first = next(o_[1] for o_ in out if o_[0] == "DATE")
                if dm2 and dm2.group(0).strip() == first and not v2_[dm2.end():].strip():
                    used.add(c)
                    used.add(v2_)
                continue
            if canon == "PROJECT" or (canon == "REV" and form_row):
                continue            # 귀속은 PROJECT 열로만 — 필드로 안 쓰니 글줄에 그대로 둔다 / 양식 개정번호 /
                                    # 둘째 일자 칸('작성일 | d1 | 검사일 | d2', 검토42 B X07)
            if canon:
                j = ci + 1
                while j < len(cells) and cells[j] == c:
                    j += 1                                   # 병합된 라벨 칸
                val = (cells[j] or "").strip() if j < len(cells) else ""
                raw_val = val
                if canon == "DATE" and val:
                    # 날짜 부분만 — '2026-09-30 (1차 불합격)'의 판정 변경이 '일자만 갱신'으로 접혔다 (검토42 B 차단 2)
                    dm = _DATE_HEAD.match(val)
                    if not dm:
                        continue
                    val, tail = dm.group(0).strip(), val[dm.end():].strip()
                    if tail:
                        partial[raw_val] = tail
                if val and _head_canon(val) is None and val.upper() not in header \
                        and (canon != "REV" or _REV_SHAPE.match(val)):
                    out.append((canon, val, f"{sheet}!제목 {ri}행 ('{c}' 칸)"))
                    used.add(c)
                    if raw_val not in partial:
                        used.add(raw_val)
                continue
            ms = list(_HEAD_INLINE.finditer(c))
            took = False
            if any(_head_canon(m.group(1)) == "PROJECT" for m in ms):
                ms = [m for m in ms if _head_canon(m.group(1)) != "PROJECT"]
                keep_cell = True
            else:
                keep_cell = False
            # 이미 DATE를 읽었으면 둘째 일자 라벨('작성일 … 검사일 …'의 검사일)은 글줄에 남긴다 — 필드는 첫 DATE만
            # 쓰는데 칸째 삼켜 검사일 변경이 '내용 변경 없음(재저장)'으로 단언됐다 (검토42 B X07)
            _dated = any(o_[0] == "DATE" for o_ in out)
            ms = [m for m in ms if not (_head_canon(m.group(1)) == "DATE"
                                        and (_dated or [_head_canon(x.group(1)) for x in ms].index("DATE") != ms.index(m)))]
            for m in ms:
                canon2, val = _head_canon(m.group(1)), m.group(2).strip()
                if canon2 and val and (canon2 != "REV" or _REV_SHAPE.match(val)):
                    out.append((canon2, val, f"{sheet}!제목 {ri}행"))
                    took = True
            if took and not keep_cell and not _HEAD_INLINE.sub("", c).strip():
                used.add(c)                                  # 칸 전체가 '라벨: 값'들뿐
            elif took:
                # 'DRAWING LIST  DOC NO: X  REV: A' — 제목 낱말은 남기고 필드로 읽힌 조각만 뺀다 (검토41 S2 중간 1)
                rest = c
                for m in ms:
                    canon3, v3 = _head_canon(m.group(1)), m.group(2).strip()
                    if canon3 and canon3 != "PROJECT" and (canon3 != "REV" or _REV_SHAPE.match(v3)):
                        rest = re.sub(re.escape(m.group(0)), " ", rest, count=1)
                partial[c] = " ".join(rest.split())
        if texts and (used or partial):
            # 필드로 읽힌 칸은 글줄에서 뺀다 — 같은 칸이 필드 변경과 '제목' 글자 변경으로 두 번 나와, DATE만 갱신한
            # 날이 '내용 변경, Rev 미갱신'이 되고 REV만 올린 날 'Rev만 갱신'이 안 나왔다 (검토40 A 낮음·B 중간 1)
            consumed[" ".join(dict.fromkeys(texts))] = " ".join(
                dict.fromkeys(partial.get(t, t) for t in texts if t not in used and partial.get(t, t)))
    return out, consumed


_HUGE_MERGE_CELLS = 2_000_000
_MERGE_REF = re.compile(rb'<(?:\w+:)?mergeCell\s+ref="([A-Z]{1,3})(\d+):([A-Z]{1,3})(\d+)"\s*/>')


def _col_no(letters: bytes) -> int:
    n = 0
    for ch in letters:
        n = n * 26 + (ch - 64)
    return n


_STRICT_NS = ((rb"http://purl.oclc.org/ooxml/spreadsheetml/main", rb"http://schemas.openxmlformats.org/spreadsheetml/2006/main"),
              (rb"http://purl.oclc.org/ooxml/officeDocument/relationships",
               rb"http://schemas.openxmlformats.org/officeDocument/2006/relationships"),
              (rb"http://purl.oclc.org/ooxml/drawingml/main", rb"http://schemas.openxmlformats.org/drawingml/2006/main"))


def _without_huge_merges(path: Path):
    """시트 전체 병합(A1:XFD1048576) 같은 거대한 병합이 있으면 그 병합만 뺀 사본(메모리)을 돌려준다 — openpyxl이 병합 칸마다
    객체를 만들어 5KB 파일 하나가 수 분·수십 GB를 먹었다 (검토63 D-F2). 없으면 경로 그대로."""
    import io
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.startswith("xl/worksheets/") and n.endswith(".xml")]
            bad = {}
            # 'Strict Open XML'로 저장한 통합 문서는 이름공간이 달라 openpyxl이 시트를 못 찾고 '값이 없는 빈 표'로 비교됐다
            # (검토66 C8) — 같은 뜻의 일반 이름공간으로 맞춘 사본을 읽는다
            for n in z.namelist():
                if n.endswith((".xml", ".rels")):
                    data = z.read(n)
                    if b"purl.oclc.org/ooxml" in data:
                        for strict, normal in _STRICT_NS:
                            data = re.sub(re.escape(strict), normal, data)
                        bad[n] = data
            for n in names:
                data = z.read(n)
                if b"mergeCell" not in data:
                    continue
                def _huge(m) -> bool:
                    return ((int(m.group(4)) - int(m.group(2)) + 1) * (_col_no(m.group(3)) - _col_no(m.group(1)) + 1)
                            > _HUGE_MERGE_CELLS)
                data = bad.get(n, data)
                if any(_huge(m) for m in _MERGE_REF.finditer(data)):
                    bad[n] = _MERGE_REF.sub(lambda m: b"" if _huge(m) else m.group(0), data)
            if not bad:
                return path
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as out:
                for info in z.infolist():
                    out.writestr(info, bad.get(info.filename) or z.read(info.filename))
            buf.seek(0)
            return buf
    except (zipfile.BadZipFile, OSError, ValueError):
        return path


_SS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_RNS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_PKG_R = "{http://schemas.openxmlformats.org/package/2006/relationships}"
_XDR = "{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}"
_DML = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
_MC_FB = "{http://schemas.openxmlformats.org/markup-compatibility/2006}Fallback"


def _sheet_shape_texts(src) -> dict:
    """시트 이름 → 그 시트 위 도형(글상자)의 글자 목록 — 읽기 전용. 셀만 읽어 엑셀로 그린 공정 배치도·판넬 배치의 메모
    ('비상정지 위치 변경')가 어디에도 없었고, 그 글자만 고친 날 '내용 변경 없음 — 다시 저장되기만'이라 단언했다
    (재검토 2026-10-28 R1-3, 원칙 4·5). 도형 하나가 한 글줄(문단은 띄어쓰기로), 호환용 사본(mc:Fallback)은 뺀다."""
    import posixpath
    import xml.etree.ElementTree as ET
    import zipfile
    out: dict = {}
    try:
        if hasattr(src, "seek"):
            src.seek(0)
        with zipfile.ZipFile(src) as z:
            names = set(z.namelist())

            def rels_of(part: str) -> list:
                d, b = posixpath.split(part)
                rp = posixpath.join(d, "_rels", b + ".rels")
                if rp not in names:
                    return []
                res = []
                for r in ET.fromstring(z.read(rp)).iter(f"{_PKG_R}Relationship"):
                    t = str(r.get("Target") or "")
                    if str(r.get("TargetMode") or "") == "External" or not t:
                        continue
                    full = t.lstrip("/") if t.startswith("/") else posixpath.normpath(posixpath.join(d, t))
                    res.append((r.get("Id"), str(r.get("Type") or ""), full))
                return res
            if "xl/workbook.xml" not in names:
                return out
            rid_tgt = {i: f for i, _t, f in rels_of("xl/workbook.xml")}
            for sh in ET.fromstring(z.read("xl/workbook.xml")).iter(f"{_SS}sheet"):
                sheet_part = rid_tgt.get(sh.get(f"{_RNS}id"))
                if not sheet_part:
                    continue
                texts: list = []

                def walk(el):
                    for ch in el:
                        if ch.tag == _MC_FB:
                            continue
                        if ch.tag == f"{_XDR}txBody":
                            paras = []
                            for ap in ch.iter(f"{_DML}p"):
                                seg = []
                                for x in ap.iter():
                                    if x.tag == f"{_DML}t":
                                        seg.append(x.text or "")
                                    elif x.tag == f"{_DML}br":
                                        seg.append(" ")
                                t = " ".join("".join(seg).split())
                                if t:
                                    paras.append(t)
                            if paras:
                                texts.append(" ".join(paras))
                            continue
                        walk(ch)
                for _i, typ, dpart in rels_of(sheet_part):
                    if not typ.endswith("/drawing") or dpart not in names:
                        continue
                    if z.getinfo(dpart).file_size > 16 * 1024 * 1024:
                        continue
                    walk(ET.fromstring(z.read(dpart)))
                if texts:
                    out[str(sh.get("name") or "")] = texts
    except Exception:          # 도형 부품이 깨진 파일 — 셀 내용 추출은 계속한다(그림 지문이 따로 본다)
        return out
    return out


# 인쇄 머리글·바닥글 코드 — 쪽 번호·날짜처럼 인쇄할 때 채워지는 자리는 이름으로, 글꼴·크기·밑줄 코드는 뺀다
_HF_CODES = {"P": "[쪽]", "N": "[쪽수]", "D": "[날짜]", "T": "[시각]", "F": "[파일 이름]", "A": "[시트 이름]",
             "Z": "[경로]", "G": "[그림]"}


def _hf_plain(t) -> str:
    t = re.sub(r'&"[^"]*"', "", str(t or ""))
    t = re.sub(r"&\d+", "", t)
    t = re.sub(r"&([PNDTFAZG])", lambda m: _HF_CODES[m.group(1)], t)
    t = re.sub(r"&&", "&", re.sub(r"&[BIUSXYEKO]", "", t))
    return " ".join(t.split())


def _print_hf_lines(ws) -> list:
    """시트의 인쇄용 머리글·바닥글 글자 → [(머리표, 글자)] — 회사 양식이 문서번호·Rev를 인쇄 머리글에 두는데 읽지 않아 그 글자가
    바뀌어도 비교에 없었다 (재검토 2026-10-28 R1-9). 홀수·짝수·첫 쪽 사본이 같으면 한 번."""
    out: list = []
    seen: set = set()
    for kind, names in (("인쇄 머리글", ("oddHeader", "evenHeader", "firstHeader")),
                        ("인쇄 바닥글", ("oddFooter", "evenFooter", "firstFooter"))):
        for nm in names:
            try:
                hf = getattr(ws, nm)
                parts = [_hf_plain(getattr(hf, side).text) for side in ("left", "center", "right")]
            except Exception:
                continue
            line = " | ".join(x for x in parts if x)
            if line and (kind, line) not in seen:
                seen.add((kind, line))
                out.append((kind, line[:500]))
    return out


def extract(path: Path) -> Document:
    # read_only가 아니어야 병합 범위를 알 수 있다. BOM류는 수 MB라 감당 가능
    src = _without_huge_merges(path)
    wb = openpyxl.load_workbook(src, read_only=False, data_only=True)
    # 엑셀이 아닌 도구가 저장한 파일은 수식 셀의 계산값이 비어 있다 — 그 칸만 수식 문자열로 채운다.
    # "합계를 수식 대신 상수로 덮어쓴" 실수도 '=SUM(…) → 1946800'으로 보인다 (2026-09-06)
    formulas_by_sheet: dict = {}
    wb_f = None
    try:
        if hasattr(src, "seek"):
            src.seek(0)
        wb_f = openpyxl.load_workbook(src, read_only=True, data_only=False)
        for wsf in wb_f.worksheets:
            try:
                wsf.reset_dimensions()      # 선언된 범위(100만 행)를 믿지 않는다 (검토63 D-F2)
            except Exception:
                pass
            fm: dict = {}
            for row in wsf.iter_rows():
                for cell in row:
                    v = cell.value
                    if isinstance(v, str) and v.startswith("="):
                        fm[(cell.row, cell.column)] = v
            if fm:
                formulas_by_sheet[wsf.title] = fm
    except Exception:
        formulas_by_sheet = {}
    finally:
        try:
            if wb_f is not None:
                wb_f.close()
        except Exception:
            pass
    shape_texts = _sheet_shape_texts(src)
    rows: list[Row] = []
    revision_history: list[Row] = []
    raw_texts: list[TextLine] = []
    head_fields: dict = {}               # 표 위 표제 칸에서 읽은 문서번호·일자 (검토38 R4-C)
    head_revs: list = []                 # 시트마다의 표제 칸 REV — 가장 높은 것이 문서 Rev (검토40 A 중간 2)
    headers: dict = {}                   # 표마다의 머리글 (검토68 C3)
    layouts: dict = {}                   # 시트 → [(열 번호→열 이름, 데이터 행 번호들)] — 수식 참조 정규화용 (뒤흔들기 XLSX X2)
    # 숨김 시트도 읽는다 — 단가 기준표를 숨겨 두고 요약 시트가 참조하는 양식에서 숨김 시트의 값
    # 변경이 진짜 변경이고, 숨김/표시 전환만은 변경이 아니다 (2026-09-06 블라인드 2차 08)
    for ws in wb.worksheets:
        merged = _merged_anchor_map(ws)
        tcells: list = []
        sheet_rows, _hdr_names, titles = _sheet_rows(ws, merged, multi=False,
                                            formulas=formulas_by_sheet.get(ws.title), title_cells=tcells,
                                            headers_out=None if _REV_SHEET.search(ws.title) else headers,
                                            rev_sheet=_REV_SHEET.search(ws.title) is not None,
                                            layout_out=layouts.setdefault(ws.title, []))
        # 표에서 멀리 떨어진 외톨이 칸은 표 대신 글줄로 — 그 칸의 값이 바뀌어도 보이게 (검토63 D-F2)
        for _r, _c, _v in getattr(ws, "_drev_far", None) or []:
            from openpyxl.utils import get_column_letter as _gcl
            _coord = f"{_gcl(_c)}{_r}"
            _tv = str(_v).strip()
            if _tv:
                raw_texts.append(TextLine(f"[{_coord}] {_tv[:500]}", f"{ws.title}!{_coord}"))
        if _hdr_names == ["항목", "값"] and not _REV_SHEET.search(ws.title):
            # 표지처럼 '항목 | 값'으로 읽힌 시트의 REV 행 — 이 경로는 제목 칸을 안 읽어 표지 REV를 올려도 'Rev 미갱신'이
            # 났다 (검토42 B 중간 4)
            _took: set = set()
            _lead = True          # 맨 위 표지 블록만 — 점검표 가운데 '작성일' 행은 행 그대로 비교한다
            for r_ in sheet_rows:
                v_ = str((r_.values or {}).get("값") or "").split("|")[0].strip()
                # 행 키는 띄어쓰기를 뺀 꼴('DOCNO') — 라벨 사전은 'DOC NO'로 찾는다
                _c = _head_canon(r_.key) or _head_canon(re.sub(r"(?i)^(DOC|DWG|DOCUMENT|DRAWING)\.?(NO)$", r"\1 \2", str(r_.key)))
                if _c not in ("REV", "DATE", "DOC_NO", "DWG_NO", "TITLE"):
                    _lead = False
                if _c == "REV" and v_ and _REV_SHAPE.match(v_) and "REV" not in {c for _s, c in head_fields} \
                        and not any(h[0] == ws.title for h in head_revs):
                    head_revs.append((ws.title, v_, f"{ws.title}!{r_.where.split('!')[-1]} ('REV' 행)"))
                    _took.add(id(r_))
                elif _lead and _c in ("DATE", "DOC_NO", "DWG_NO", "TITLE") and v_ and (ws.title, _c) not in head_fields:
                    # 표지 블록의 문서번호·일자도 표제 칸으로 — 행으로 두면 일자만 고친 날 'DATE 값 변경'이 내용이 되어 거짓
                    # 'Rev 미갱신'이 났고 문서번호를 잃었다 (검토63 A-1, 검토62 A-C의 부작용)
                    head_fields[(ws.title, _c)] = Field(_c, v_, f"{ws.title}!{r_.where.split('!')[-1]} ('{r_.key}' 행)")
                    _took.add(id(r_))
            if _took:
                sheet_rows = [r_ for r_ in sheet_rows if id(r_) not in _took]
        if not _REV_SHEET.search(ws.title):
            _hdr = [r for r in tcells if r and r[0] == "__HEADER__"]
            got, consumed = _title_fields([r for r in tcells if not (r and r[0] == "__HEADER__")][:10] + _hdr[-1:],
                                          ws.title)
            for canon, val, where in got:
                if canon == "PROJECT":       # 귀속은 예전 그대로(PROJECT 열) — 바뀌면 열린 이슈가 새로 태어난다
                    continue
                if canon == "REV":
                    head_revs.append((ws.title, val, where))
                else:
                    head_fields.setdefault((ws.title, canon), Field(canon, val, where))
            if consumed:
                # 필드로 다 읽힌 제목 줄('REV A')을 글줄로도 두면 Rev만 올린 날이 '내용 변경'이 되어
                # 'Rev만 갱신'이 영영 안 나오고 같은 변경이 두 번 보고됐다 (검토40 A 낮음)
                titles = [t2 for t2 in (consumed.get(t, t) for t in titles) if t2]
        raw_texts.extend(TextLine(tt, f"{ws.title}!{'비고' if tt.startswith('[비고 ') else '제목'}")
                         for tt in titles)
        for _k, _line in _print_hf_lines(ws):
            raw_texts.append(TextLine(f"[{_k}] {_line}", f"{ws.title}!{_k}"))
        for _t in shape_texts.get(ws.title, ()):
            raw_texts.append(TextLine(f"[도형] {_t[:500]}", f"{ws.title}!도형"))
        if _REV_SHEET.search(ws.title):
            revision_history.extend(sheet_rows)
        else:
            rows.extend(sheet_rows)
    wb.close()

    fields: dict[str, Field] = {}
    projects = Counter(r.values["PROJECT"] for r in rows if r.values.get("PROJECT"))
    if projects:
        top = projects.most_common(1)[0][0]
        fields["PROJECT"] = Field("PROJECT", top, "PROJECT 열 최빈값")
    # 개정이력 시트가 있으면 마지막 행의 Rev를 표제란 REV처럼 올린다 — 그래야 BOM 행이 바뀌었는데
    # 개정이력은 그대로인 것을 도면과 같은 'Rev 미갱신' 검사가 잡는다 (검토24 A-2: 실사용 day2b가
    # 정확히 그 경우였는데 아무 말이 없었다). 시트가 없으면 REV 없음 — 검사도 없다
    # 위가 최신인 양식(내림차순)이 흔하다 — 마지막 행이 아니라 **가장 높은 Rev**를 고른다 (검토25 감지 6-4)
    best = None
    for r in revision_history:
        rv = next((str(v).strip() for k, v in r.values.items()
                   if v not in (None, "") and re.match(r"^(REV(ISION)?|개정|판|버전|VER)", str(k).strip(), re.I)
                   and not re.search(r"(일자|날짜|DATE|내용|사유|비고|자|DESC)", str(k), re.I)), None)
        if not rv:
            continue
        key = (0, int(rv), "") if rv.isdigit() else (1, len(rv), rv.upper())
        if best is None or key > best[0]:
            best = (key, rv, r.where)
    if best:
        fields["REV"] = Field("REV", best[1], f"{best[2]} (개정이력)")
    # 개정이력 시트가 없으면 표 위의 표제 칸('REV | A', 'DOC NO: IO-3701  REV: A')을 표제란으로 — BOM·I/O
    # 리스트·인터락 시트에서 값이 바뀌고 Rev가 그대로여도 아무 말이 없었다 (검토38 R4-C). 개정이력이 있으면 그쪽이 앞선다
    # 시트 **이름** 순 — 탭 순서로 두면 시트 순서만 바꾼 날 REV A→B·REV#2 B→A·문서번호 변경·'Rev만 갱신'이 났다
    # (검토41 S4 중간 1, DXF 배치에서 검토36 F로 고친 것과 같은 결함)
    for (_sh, k), f in sorted(head_fields.items(), key=lambda kv: kv[0][0]):
        fields.setdefault(k, f)
    head_revs = [(v, w) for _sh, v, w in sorted(head_revs, key=lambda t: t[0])]
    if head_revs and "REV" not in fields:
        # 판넬별 시트마다 제 REV가 있는 통합 문서 — 시트마다 따로 싣는다(REV, REV#2 … DXF 둘째 표제란과 같은 꼴).
        # 첫 시트 것만 보면 시트2를 올린 날, 최고값 하나로 보면 낮은 Rev 시트를 올린 날 거짓 'Rev 미갱신'이 났다
        # (검토40 A 중간 2·재확인 2-b). 어느 시트든 올리면 Rev 올림이다
        for n_, (val, where) in enumerate(head_revs, start=1):
            key = "REV" if n_ == 1 else f"REV#{n_}"
            fields[key] = Field(key, val, where)
    notes: list[str] = []
    # 인쇄 머리글·바닥글('[쪽] / [쪽수]')만 있는 시트는 여전히 '읽을 내용 없음' — 그 고지가 '다시 저장되기만' 단언을 막는다
    if not rows and not [t for t in raw_texts if not str(t.where).endswith(("!인쇄 머리글", "!인쇄 바닥글"))]:
        # 표가 아닌 엑셀(공정 배치도·그림만 있는 시트)에서 아무것도 못 읽고도 고지가 없어,
        # 브리핑이 "내용 변경 없음 — 파일이 다시 저장되기만 했습니다"라고 **단언**했다.
        # 없는 알림보다 틀린 알림이 나쁘다 (2026-09-09 추출 검토 차단 4, 원칙 4·5)
        notes.append("표로 읽을 내용을 찾지 못했습니다 — 셀에 값이 없거나 그림·개체로만 된 "
                     "문서일 수 있습니다. 변경 사실과 그림만 비교합니다")
    try:
        _who = (str(wb.properties.lastModifiedBy or "").strip() or None) if wb.properties else None
    except Exception:          # 속성 영역이 깨진 파일 — 내용 추출은 계속한다
        _who = None
    return Document(doc_type="xlsx", path=str(path), fields=fields, rows=rows,
                    revision_history=revision_history, raw_texts=raw_texts, notes=notes,
                    saved_by=_who[:60] if _who else None,
                    formulas=_row_formula_counts(rows, formulas_by_sheet, wb, layouts), headers=headers or None)


_FREF = re.compile(r"(?<![A-Za-z_\d.])\$?([A-Z]{1,3})\$?(\d{1,7})(?![\d(A-Za-z_])")


def _norm_formula(text: str, r: int, c: int, layouts: list, idx_cache: dict | None = None) -> str | None:
    """수식 글자를 '열 이름·표 안 행 차례' 꼴로 — '=E6*G6'(6행) → '=[수량]d0*[단가]d0', '=SUM(G6:G17)'(표 첫 행~끝 행) →
    '=SUM([금액]^:[금액]$)'. 열을 섞거나 빈 행·열을 끼우거나 표를 옮겨 참조 글자만 바뀐 수식을 같은 수식으로 알아보려고
    (뒤흔들기 XLSX X2·X2b, 2026-10-20). 다른 시트 참조('Sheet2'!A1)·따옴표 글자가 든 수식은 None(글자 그대로 비교)."""
    if not layouts or "!" in text or '"' in text or "[" in text:
        return None
    from watcher.diff import _col_norm
    if idx_cache is None:                 # 표 행 차례 사전 — 시트마다 한 번만 만든다(수식 칸마다 만들면 1만 행 표가 O(N²))
        idx_cache = {}

    def _ix(rows) -> dict:
        k = id(rows)
        if k not in idx_cache:
            idx_cache[k] = {x: n for n, x in enumerate(rows)}
        return idx_cache[k]
    home = next((L for L in layouts if c in L[0] and r in _ix(L[1])), None) \
        or next((L for L in layouts if r in _ix(L[1])), None)

    def lay_of(col):
        if home and col in home[0]:
            return home
        return next((L for L in layouts if col in L[0]), None)

    def tok(m) -> str:
        col = 0
        for ch in m.group(1):
            col = col * 26 + (ord(ch) - 64)
        row = int(m.group(2))
        L = lay_of(col)
        name = L[0].get(col) if L else None
        # 열 이름은 짝짓기 열쇠 꼴로('단가\n(EA)'→'단가') — 머리글 꼴만 바꾼 판에서도 같은 수식으로 (diff._col_norm)
        ctok = f"[{_col_norm(name, unit=False)}]" if name else f"c{col - c}"
        rows = (L or home or ((), ()))[1]
        if row == r:
            return ctok + "d0"
        if rows:
            ix = _ix(rows)
            if row in ix:
                if row == rows[0]:
                    return ctok + "^"
                if row == rows[-1]:
                    return ctok + "$"
                if r in ix:
                    return ctok + f"d{ix[row] - ix[r]}"
                return ctok + f"i{ix[row]}"
        return ctok + f"r{row - r}"
    return _FREF.sub(tok, "".join(text.split()).upper())


def _row_formula_counts(rows, formulas_by_sheet: dict, wb=None, layouts: dict | None = None) -> dict:
    """행 키 → [수식 칸 수, 위치, 열 이름들]. 수식이 하나도 없는 행은 싣지 않는다 (검토61 C49).
    열 이름은 수식 칸 위쪽(30행 안)에서 처음 만나는 그 행의 열 이름 칸으로 찾는다(못 찾으면 빈 목록)."""
    per_row: dict = {}
    cols_at: dict = {}
    vals: dict = {}
    # 시트마다 표의 열 이름(띄어쓰기·대소문자 없이) — 30행 창 밖 수식 칸은 그 위에서 가장 가까운 열 이름 칸을 머리글로 본다.
    # 창 안에서만 찾았더니 머리글에서 30행 넘는 행(31행째부터)의 수식 열 이름이 비어, 계산값 있는 판↔없는 판 재저장이
    # '7600000 → =E31*G31' 값 변경 수천 건 + 거짓 Rev 미갱신이 됐다 (대량 시험 XLSX F3, 2026-10-20)
    names_by_sheet: dict = {}

    def _ws_of(name: str) -> str:
        """행 위치의 표 이름('발주·표2', '발주·문서번호') → 시트 이름('발주'). 한 시트에 표가 여럿이면 가짜 시트 이름이 붙어 그 표의
        수식 기록이 통째로 빠졌고, 표가 하나가 된 날 '값(상수)이 수식으로 바뀜'이 행마다 났다 (뒤흔들기 XLSX X7, 2026-10-20)."""
        if name in (formulas_by_sheet or {}):
            return name
        return max((s for s in (formulas_by_sheet or {}) if name.startswith(s + "·")), key=len, default=name)
    for row in rows or []:
        m0 = re.match(r"^(.+)!행(\d+)$", str(row.where or ""))
        if m0:
            names_by_sheet.setdefault(_ws_of(m0.group(1)), set()).update(
                "".join(str(h).split()).upper() for h in (row.values or {}))
    for sheet, fm in (formulas_by_sheet or {}).items():
        ws = None
        try:
            ws = wb[sheet] if wb is not None else None
        except Exception:
            ws = None
        cells = getattr(ws, "_cells", None) if ws is not None else None

        def _cv(rr, c):
            try:
                if isinstance(cells, dict):
                    cell = cells.get((rr, c))
                    return None if cell is None else cell.value
                return ws.cell(row=rr, column=c).value
            except Exception:
                return None
        far: dict = {}
        _idx: dict = {}                   # 이 시트 표들의 행 차례 사전 (_norm_formula)
        cand = names_by_sheet.get(sheet) or set()
        if ws is not None and cand:
            by_col: dict = {}
            for (r, c) in fm:
                if r > 30:
                    by_col.setdefault(c, set()).add(r)
            for c, rs in by_col.items():
                last = None
                for rr in range(1, max(rs) + 1):
                    if rr in rs:
                        far[(rr, c)] = last
                    v = _cv(rr, c)
                    if v is not None and str(v).strip() and "".join(str(v).split()).upper() in cand:
                        last = str(v).strip()
        for (r, c) in fm:
            per_row[(sheet, r)] = per_row.get((sheet, r), 0) + 1
            cols_at.setdefault((sheet, r), []).append(c)
            if ws is not None:
                heads = []
                for rr in range(r - 1, max(0, r - 30), -1):
                    v = _cv(rr, c)
                    if v is not None and str(v).strip():
                        heads.append(str(v).strip())
                if far.get((r, c)):
                    heads.append(far[(r, c)])
                vals.setdefault((sheet, r), []).append((heads, fm[(r, c)], _norm_formula(str(fm[(r, c)]), r, c,
                                                                                         (layouts or {}).get(sheet) or [],
                                                                                         _idx), c))
    out: dict = {}
    seen: Counter = Counter()
    _seg_rows: dict = {}
    for row in rows:
        seen[row.key] += 1
        k = row.key if seen[row.key] == 1 else f"{row.key}#{seen[row.key]}"
        m = re.match(r"^(.+)!행(\d+)$", str(row.where or ""))
        n = per_row.get((_ws_of(m.group(1)), int(m.group(2))), 0) if m else 0
        span = None
        if n:
            # 한 시트에 표가 여럿(옆 표)이면 그 행의 수식 칸은 **이 표의 열 범위 안**만 — 같은 행 번호의 본 표 금액 수식을 옆 표 행도
            # 제 것으로 세어, 표를 떼어 낸 날 '수식이 값으로 바뀜'이 났다 (뒤흔들기 XLSX X7, 2026-10-20)
            segs = (layouts or {}).get(_ws_of(m.group(1))) or []
            if len(segs) > 1:
                for x in segs:
                    if id(x[1]) not in _seg_rows:
                        _seg_rows[id(x[1])] = set(x[1])
                L = next((x for x in segs if len(x) > 2 and x[2] == m.group(1) and int(m.group(2)) in _seg_rows[id(x[1])]), None)
                if L and L[0]:
                    span = (min(L[0]), max(L[0]))
                    n = sum(1 for c in cols_at.get((_ws_of(m.group(1)), int(m.group(2))), []) if span[0] <= c <= span[1])
        if n:
            # 열 이름은 대문자로 바뀌어 있다('Amount'→'AMOUNT') — 원래 머리글과 띄어쓰기·대소문자 없이 견준다. 그대로 견주면
            # 소문자 머리글 표의 수식 열 이름이 비어 계산값 비교가 어긋났다 (검토68 C1)
            names = {"".join(str(h).split()).upper(): str(h) for h in (row.values or {})}
            cols, texts, norms = [], {}, {}
            for heads, ftext, fnorm, fc in vals.get((_ws_of(m.group(1)), int(m.group(2))), []):
                if span and not span[0] <= fc <= span[1]:
                    continue
                h = next((names["".join(x.split()).upper()] for x in heads if "".join(x.split()).upper() in names), None)
                if h and h not in cols:
                    cols.append(h)
                if h and h not in texts:
                    texts[h] = str(ftext)
                    if fnorm:
                        norms[h] = fnorm
            cols = cols[:3]
            # 칸별 수식 글자 — 수식이 같을 때만 계산값 차이를 저장 프로그램 탓으로 본다 (검토66 C3, c61 C50 퇴행 방지).
            # 다섯째는 열 이름·표 안 행 차례로 읽은 꼴 — 참조 글자만 밀린 수식을 같은 수식으로 (뒤흔들기 XLSX X2)
            out[k] = [n, row.where, cols, texts, norms]
    return out
