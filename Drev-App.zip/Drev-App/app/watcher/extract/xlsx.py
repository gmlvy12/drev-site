# -*- coding: utf-8 -*-
"""XLSX 추출기: BOM·발주서·자재표 행 → Row 목록.

전 시트를 순회한다 — wb.active(저장 당시 열려 있던 시트) 하나만 읽으면 담당자가
어느 시트를 보다 저장했는지에 따라 감시 대상이 조용히 바뀐다 (2026-08-26 설계
엔지니어 검토, PRINCIPLE 5 위반이라 최우선 수정). 실무 BOM은 표지/전장품/케이블/
예비품/개정이력이 한 파일에 시트로 나뉜다.

행 key는 TAG 열 우선, 없으면 '시트명!행N'. 병합 셀은 앵커 값을 전파하고,
소계/합계 행은 비교에서 제외하며, 개정이력 시트는 revision_history로 분류한다.
"""

from __future__ import annotations

import datetime

import re
from collections import Counter
from pathlib import Path

import openpyxl

from watcher.extract.base import Document, Field, Row, TextLine

# 표 머리글에 흔한 열 이름 — 이 중 하나라도 있으면 열 2개짜리 표도 머리글로 인정
_KNOWN_HEADER = {"TAG", "SPEC", "품명", "부품명", "자재명", "명칭", "품번", "규격",
                 "수량", "QTY", "DESCRIPTION", "MODEL", "형식", "단위", "UNIT"}

# 개정이력 시트로 취급할 시트명 (revision_history로 분류 — Rev 검사 근거로 쓰임)
# "BOM_rev2"처럼 이름에 rev가 섞였을 뿐인 시트가 개정이력으로 분류되던 것 (2026-09-06 양식 시험)
_REV_SHEET = re.compile(
    r"^\s*(?:(?:개정|변경|수정)\s*(?:이력|내역|기록)?\s*(?:표|시트)?|이력\s*(?:표|시트)?|리비전|"
    r"rev(?:ision)?s?(?:\s*(?:history|list|table))?|revision\s*history|history)\s*$",
    re.IGNORECASE)

# 소계/합계 행 — 위 행이 하나 늘면 같이 밀려 '변경'으로 잡히는 소음원이라 제외
_TOTAL_ROW = re.compile(r"^(소\s*계|합\s*계|총\s*계|계|SUB\s*TOTAL|TOTAL|G\.?\s*TOTAL)$",
                        re.IGNORECASE)

# 머리글 후보 칸이 '값'처럼 보이는가 — 날짜, 번호 코드, 숫자 (2026-09-06)
_VALUEISH = re.compile(
    r"\d{4}[-./]\d{1,2}[-./]\d{1,2}|^[A-Z]{1,4}-\d{2,}|^\d+([.,]\d+)?$"
    r"|^\d+\s*(일|식|개|매|장|대|명|EA|SET|PCS)$|\d+\s*(일|식)$"
    r"|^\d+(\.\d+)?\s*[a-zA-Z%℃Ω]{1,4}$|^(OK|NG|PASS|FAIL|합격|불합격)$", re.IGNORECASE)

# 정보 행의 칸 — '수신: OO사'(라벨:값), 'B'(한 글자 값), '발 주 서'(띄어 쓴 제목)는 열 이름이 아니다 (리뷰10 차단-1)
_INFOISH = re.compile(r"^.$|[:：]\s*\S|^(?:\S\s+){2,}\S$")
# 정보 행에서 값 앞에 오는 라벨 — '설비 | 1호기', '작성 | 김철수', '구분 | 양산' (리뷰11 차단-D)
_INFO_LABELS = {"설비", "라인", "구분", "작성", "검토", "승인", "결재", "업체", "고객", "수신", "참조", "제목", "건명",
                "프로젝트", "호기", "작성자", "검토자", "승인자", "REV", "PROJECT", "DRAWN", "CHECKED", "APPROVED",
                "CUSTOMER", "LINE", "MACHINE"}
# ('담당'·'NO'·'일자'·'공정'처럼 표 머리글로도 흔한 낱말은 넣지 않는다 — 회의록 머리글 'NO | 안건 | … | 담당 | 기한'이
#  정보 행으로 몰려 데이터 행에 머리글을 빼앗겼다, 리뷰11 재채점 review7/15)


def _label_value_pairs(cells: list[str]) -> int:
    """'라벨 | 값 | 라벨 | 값' 행의 쌍 수 — 쌍이 둘 이상이고 칸의 60% 이상을 덮을 때만, 아니면 0.
    값 칸이 열 이름다운 낱말('일자'·'비고')이면 쌍이 아니다 — '담당 | 일자 | 구분 | 비고' 머리글 보호."""
    pairs = 0
    j = 0
    nonempty = sum(1 for c in cells if c)
    while j + 1 < len(cells):
        lab, val = cells[j], cells[j + 1]
        if lab and val and not _headerish(val) and val.upper() not in _INFO_LABELS and lab.upper() in _INFO_LABELS:
            pairs += 1
            j += 2
        else:
            j += 1
    return pairs if pairs >= 2 and pairs * 2 >= 0.6 * max(1, nonempty) else 0


def _base_header_score(cells: list[str]) -> float:
    """차용 없이 행 자체만 본 머리글 점수 — 위 후보가 이 행의 아래 데이터를 빌려도 되는지 가를 때."""
    names = [c for j, c in enumerate(cells) if c and not (j > 0 and cells[j - 1] == c)]
    singles = sum(1 for c in names if len(c) == 1)
    valueish = sum(1 for c in names if _VALUEISH.search(c)
                   or (_INFOISH.search(c) and not (len(c) == 1 and singles >= 2)))
    valueish += _label_value_pairs(cells)
    plain = sum(1 for c in names if len(c) <= 12 and not any(ch.isdigit() for ch in c)) / max(1, len(names))
    return float(len(names) - 2 * valueish + plain)

# 순번 성격 열 — 행 식별자로 승격하면 안 됨 (삽입 시 전부 밀림)
_ORDINAL = re.compile(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", re.IGNORECASE)

# 식별자 성격의 열 이름 — 점수 가산으로 두 판이 같은 키 열을 고르게 고정
_IDENTITY_HINT = ("품번", "자재번호", "부품번호", "코드", "설명", "내용", "조건", "항목",
                  "명칭", "품명", "DESCRIPTION", "ITEM", "CODE", "ID", "NO", "번호", "PART")
_NUM_VAL = re.compile(r"^\s*-?[\d,]+(\.\d+)?\s*$")
_DATE_VAL = re.compile(r"^\s*(\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{2}[-./]\d{1,2}[-./]\d{1,2}|\d{1,2}/\d{1,2})\s*$")
_CODE_LIKE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-_./]{0,24}$")


def code_ratio(vals) -> float:
    """값 가운데 '코드'(영숫자·하이픈, 공백 없음) 모양의 비율 — 품번·태그 열 우대용."""
    vals = [str(v) for v in vals if v]
    if not vals:
        return 0.0
    return sum(1 for v in vals if _CODE_LIKE.match(v) and any(ch.isdigit() for ch in v)) / len(vals)
_VALUE_COLS = {"규격", "사양", "SPEC", "SPECIFICATION", "단가", "금액", "수량", "QTY",
               "PRICE", "AMOUNT", "UNIT PRICE", "납기", "단위", "UNIT", "DELIVERY", "비고", "REMARK",
               "REMARKS", "NOTE", "날짜", "일자", "DATE", "결과", "판정", "RESULT"}


# 회사 양식의 행 식별 열 이름 — 설정 `key_columns`에서 온다 (2026-09-06 정밀화).
# 자동 선택(_pick_key_col)이 양식마다 다른 열을 잡아 "행 5개 삭제 + 5개 추가"로 보이던 것
USER_KEY_COLS: tuple = ()


def _user_key_col(header) -> str | None:
    """머리글 가운데 사용자가 정한 키 열 이름과 같은 것 (대소문자·공백 무시). 앞에 적은 것 우선."""
    norm = {"".join(str(h).split()).upper(): h for h in header if h}
    for u in USER_KEY_COLS:
        h = norm.get("".join(str(u).split()).upper())
        if h:
            return h
    return None


def _hint_in(col: str, hint: str) -> bool:
    """열 이름에 식별 힌트가 '낱말'로 들어 있나. NO가 NOTE·NOMINAL에 걸리면 비고 열이
    행 키가 되어 메모 한 글자에 행이 신규+삭제로 갈린다 (2026-09-02 재검토)."""
    return re.search(r"(?<![A-Z])" + re.escape(hint) + r"(?![A-Z])", col.upper()) is not None


def _pick_key_combo(row_values: list[dict]):
    """단일 열로는 행을 못 가르는 표(병합된 도면번호 + 시트 + 항목) — 글자 열 두세 개의 조합이
    거의 고유하면 그 조합을 키로 (2026-09-06 블라인드 3차 29). 돌려주는 값: 열 이름 튜플 또는 None."""
    from itertools import combinations
    n = len(row_values)
    if n < 2:
        return None
    cols: list = []
    for v in row_values:
        for c in v:
            if c not in cols:
                cols.append(c)
    cand = []
    for c in cols:
        if _ORDINAL.match(c.strip()) or c.strip().upper() in _VALUE_COLS:
            continue
        vals = [v[c] for v in row_values if v.get(c)]
        if len(vals) < n * 0.9:
            continue
        if sum(1 for x in vals if _NUM_VAL.match(x)) >= len(vals) * 0.8:
            continue                        # 숫자 열은 값이지 이름표가 아니다 ('1/2' 같은 시트 번호는 조합의 일부가 된다)
        cand.append(c)
        if len(cand) >= 5:
            break
    for size in (2, 3):
        for combo in combinations(cand, size):
            keys = [tuple(v.get(c, "") for c in combo) for v in row_values]
            if len(set(keys)) >= len(keys) * 0.95:
                return combo
    return None


def _pick_key_col(row_values: list[dict]):
    """TAG 열이 없을 때 행 식별자로 쓸 열 자동 선택(없으면 열 조합) — 채움률·고유율이 높은
    텍스트 열(설명·품번류). 인터락시트처럼 행 삭제가 잦은 표를 행번호(위치)로
    짝지으면 삭제 이후 전부 어긋나 셀 변경 수천 건 오탐이 된다 (2026-08-27 실사용).
    적합한 열이 없으면 None → 기존 행번호 방식."""
    if not row_values:
        return None
    n = len(row_values)
    best, best_score = None, 0.0
    # 머리글 순서(왼쪽부터)를 지킨다 — 동점이면 왼쪽 열. 순서는 두 판에서 같으므로 결정적이다
    # (set 정렬은 이름순이라 '기준' 열이 '점검 항목'을 이기던 것, 2026-09-06 양식 시험)
    cols: list = []
    for v in row_values:
        for c in v:
            if c not in cols:
                cols.append(c)
    for c in cols:
        if _ORDINAL.match(c.strip()):
            continue
        vals = [v[c] for v in row_values if v.get(c)]
        if len(vals) < n * 0.9:          # 거의 모든 행에 있어야
            continue
        if sum(1 for x in vals if str(x).startswith("=")) >= len(vals) * 0.5:
            continue                      # 수식 열(=AVERAGE(...))은 값이지 이름표가 아니다 (3차 06)
        uniq = len(set(vals)) / len(vals)
        if uniq < 0.9:                    # 거의 고유해야 (구역명 반복 열 배제)
            continue
        avg = sum(len(v) for v in vals) / len(vals)
        codes = code_ratio(vals)
        if avg < 2:                                          # X/O 마크 열 배제
            continue
        if sum(1 for v in vals if _NUM_VAL.match(v)) >= len(vals) * 0.8:
            continue                                         # 숫자만인 열(생산량·금액)은 값이지 이름표가 아니다
        is_date = sum(1 for v in vals if _DATE_VAL.match(v)) >= len(vals) * 0.8
        score = uniq * min(avg, 40)       # 고유하고 서술적인 열 우대
        if is_date:
            score -= 30                   # 날짜는 다른 후보가 없을 때만 (일별 기록표의 '일자')
            codes = 0.0                   # 날짜 모양은 코드가 아니다
        if codes >= 0.9:
            score += 60                   # 품번·태그 모양이면 설명 열보다 앞 (설명은 고쳐지는 칸)
        if any(_hint_in(c, h) for h in _IDENTITY_HINT):
            score += 100  # 알려진 식별 열 이름 우선 — 두 판의 키 열 선택을 고정
        if c.strip().upper() in _VALUE_COLS:
            # 규격·단가는 '바뀌는 값'이지 행의 이름표가 아니다 — 규격을 고치면
            # 신규+삭제 두 줄로 갈려 구매가 새 품목으로 오해 (2026-09-02 검토)
            score -= 1000
        if score > best_score:
            best, best_score = c, score
    return best if best is not None else _pick_key_combo(row_values)


_HEADERISH = {"항목", "결과", "판정", "비고", "구분", "내용", "일자", "수량", "코드", "LOT", "NO", "번호", "순번",
              "이름", "성명", "담당", "부서", "규격", "사양", "단가", "금액", "합계", "기준", "측정", "위치",
              "ITEM", "RESULT", "REMARK", "REMARKS", "QTY", "DATE", "CODE", "DESCRIPTION", "SPEC", "NAME"}


def _headerish(name: str) -> bool:
    """열 이름다운가 — 알려진 이름이거나 그 낱말을 품거나(측정 항목·LOT NO) 열 이름 꼴 접미(…명·…번호·…량·…값)."""
    u = str(name).upper()
    toks = {t for t in re.split(r"[\s·/()\[\]:_-]+", u) if t}
    if u.strip() in _KNOWN_HEADER or toks & (_KNOWN_HEADER | _HEADERISH):
        return True
    if any(_hint_in(u, h) for h in _IDENTITY_HINT):
        return True
    return re.search(r"(명|번호|수량|중량|용량|일자|일|값|율|률|명칭|위치|업체|담당|비고|여부)$", u.strip()) is not None


def _type_sig(cells: list) -> tuple:
    """칸마다 'n'(숫자·날짜) / 't'(글자) / ''(빈 칸) — 뒤쪽 빈 칸은 뗀다."""
    sig = ["n" if (_NUM_VAL.match(c) or _DATE_VAL.match(c)) else "t" if c else "" for c in cells]
    while sig and not sig[-1]:
        sig.pop()
    return tuple(sig)


def _majority_sig(rows: list) -> tuple:
    """데이터 행들의 다수 유형 서명 — 행이 없으면 빈 튜플."""
    rows = [r for r in rows if any(r)]
    if not rows:
        return ()
    width = max(len(r) for r in rows)
    out = []
    for j in range(width):
        c = Counter(_type_sig(r[:j + 1])[j] if j < len(_type_sig(r[:j + 1])) else "" for r in rows)
        out.append(c.most_common(1)[0][0])
    while out and not out[-1]:
        out.pop()
    return tuple(out)


def _unique_header(names: list) -> list:
    """같은 이름의 열이 여럿이면(병합 '측정값' 아래 세 칸) 뒤 것에 #2·#3 — 사전에서 마지막 칸만 남아
    값 변경이 사라지던 것 (리뷰11 차단-C)."""
    seen: Counter = Counter()
    out = []
    for h in names:
        if h:
            seen[h] += 1
            out.append(h if seen[h] == 1 else f"{h}#{seen[h]}")
        else:
            out.append(h)
    return out


def _small_int(c: str) -> bool:
    return bool(_NUM_VAL.match(c)) and 0 <= float("".join(c.split(","))) <= 99 \
        and float("".join(c.split(","))).is_integer()


def _two_col_header(cells: list[str], nxt) -> bool:
    """두 칸짜리 표('항목 | 금액')의 머리글 — 짧은 글자 둘(숫자 없음) 아래에 숫자·날짜 값이 오면.
    알려진 열 이름이 아니어도 인정한다 (2026-09-06: 견적 요약·명세서 소형 표가 세로 양식으로 오인)."""
    texts = [(j, c) for j, c in enumerate(cells) if c]
    if len(texts) != 2 or not nxt:
        return False
    if any(len(c) > 12 or any(ch.isdigit() for ch in c) for _, c in texts):
        return False
    j2 = texts[1][0]
    v = nxt[j2] if j2 < len(nxt) else ""
    return bool(v) and bool(_NUM_VAL.match(v) or _DATE_VAL.match(v) or _VALUEISH.search(v))


def _looks_like_header(cells: list[str]) -> bool:
    """머리글 후보: 문자 셀이 3개 이상이고 숫자 위주가 아님.
    실무 BOM은 위에 빈 행·제목 행이 있는 경우가 많다 (2026-08-23 실사용 발견).
    열이 2개뿐인 표는 알려진 열 이름(TAG·품명 등)이 있을 때만 인정
    (2026-08-26 — 제목 행 오인 방지와 소형 표 지원의 절충)."""
    texts = [c for c in cells if c]
    if len(texts) < 2:
        return False
    if len(texts) < 3 and not any(t.upper().strip() in _KNOWN_HEADER for t in texts):
        return False

    def is_num(s: str) -> bool:
        try:
            float(s)
            return True
        except ValueError:
            return False

    numeric = sum(1 for c in texts if is_num(c))
    # 샘플 번호 열(1 2 3 4 5)처럼 작은 정수가 이어지면 열 이름이다 (2026-09-06 수입검사 성적서)
    ints = [int(float(c)) for c in texts if is_num(c) and float(c) == int(float(c)) and 0 <= float(c) <= 99]
    if numeric and len(ints) == numeric and ints == sorted(ints) and len(set(ints)) == len(ints):
        return True
    return numeric <= len(texts) // 2


def _merged_anchor_map(ws) -> dict:
    """병합 범위의 모든 좌표 → 앵커(좌상단) 좌표. 병합 셀 값 전파용 —
    품명이 3~4행 병합된 실무 BOM에서 품명 없는 유령 행이 생기는 것 방지."""
    out: dict[tuple[int, int], tuple[int, int]] = {}
    try:
        for rng in ws.merged_cells.ranges:
            anchor = (rng.min_row, rng.min_col)
            for r in range(rng.min_row, rng.max_row + 1):
                for c in range(rng.min_col, rng.max_col + 1):
                    if (r, c) != anchor:
                        out[(r, c)] = anchor
    except Exception:
        pass
    return out


def _real_extent(ws) -> tuple[int, int]:
    """값이 있는 셀 기준의 (마지막 행, 마지막 열). 엑셀에서 서식을 넣었다 지운 흔적으로
    '사용 범위'가 30만 행×60열까지 부풀어 있으면 iter_rows가 1,800만 개의 빈 셀 객체를
    만들어 5GB·2분을 먹었다 (2026-09-04 검토 extract C-1)."""
    cells = getattr(ws, "_cells", None)
    if not isinstance(cells, dict):
        return int(ws.max_row or 0), int(ws.max_column or 0)
    max_r = max_c = 0
    for (r, c), cell in cells.items():
        v = cell.value
        if v is None or (isinstance(v, str) and not v.strip()):
            continue
        if r > max_r:
            max_r = r
        if c > max_c:
            max_c = c
    return max_r, max_c


def _sheet_rows(ws, merged: dict, multi: bool = False,
                formulas: dict | None = None) -> tuple[list[Row], list[str], list[str]]:
    """한 시트의 데이터 행. 돌려주는 값: (rows, 머리글).

    머리글은 '첫 그럴듯한 행'이 아니라 **상위 10행 중 열 이름이 가장 많은 행**을
    고른다 — 인터락시트처럼 제목 행(3~4칸)이 위에 있고 진짜 머리글(장비별 열
    수십 개)이 아래 있는 양식에서, 제목을 머리글로 오인해 열이 1개로 붕괴되고
    매트릭스 전체가 버려지던 문제 (2026-08-27 실사용 발견)."""
    rows: list[Row] = []
    grid: dict[tuple[int, int], str] = {}

    def cell_text(r: int, c: int, raw) -> str:
        if raw is None and formulas:
            raw = formulas.get((r, c))            # '=SUM(E5:E10)' — 값이 없으면 수식이라도 (2026-09-06)
        if isinstance(raw, datetime.datetime) and (raw.hour, raw.minute, raw.second) == (0, 0, 0):
            raw = raw.date()                  # '2026-08-22 00:00:00' → '2026-08-22' (2026-09-06)
        v = "" if raw is None else str(raw).strip()
        if not v and (r, c) in merged:
            v = grid.get(merged[(r, c)], "")
        grid[(r, c)] = v
        return v

    all_cells: list[tuple[int, list[str]]] = []
    max_r, max_c = _real_extent(ws)
    if max_r == 0:
        return [], [], []
    for i, raw in enumerate(ws.iter_rows(min_row=1, max_row=max_r, max_col=max_c,
                                         values_only=True), start=1):
        all_cells.append((i, [cell_text(i, j, v) for j, v in enumerate(raw, start=1)]))

    header_idx = None
    best = -1.0
    best_infoish = False
    by_idx = dict(all_cells)
    rank = 0                                   # 비어 있지 않은 행의 순번
    for i, cells in all_cells[:30]:
        if any(cells):
            rank += 1
        # 두 칸 머리글은 표 첫머리(둘째 행까지)에서만 — 세로 양식 중간의 '통신 | Ethernet/IP'가
        # 머리글이 되지 않게
        if not _looks_like_header(cells) and not (rank <= 2 and _two_col_header(cells, by_idx.get(i + 1))):
            continue
        # 병합으로 옆 칸에 반복된 이름('1호기 | 1호기 | 1호기')은 하나로 센다 — 그룹 제목 행이
        # 진짜 머리글보다 넓어 보이던 것 (2026-09-06 블라인드 3차 28)
        names = [c for j, c in enumerate(cells) if c and not (j > 0 and cells[j - 1] == c)]
        # 날짜·코드·숫자처럼 '값'인 칸은 열 이름이 아니다 — 발주서의 정보 블록
        # ("발주번호 | PO-2026-014-01 | 발주일 | 2026-09-01")이 표 머리글을 빼앗던 것 (2026-09-06).
        # 단 '1 2 3 4 5'처럼 이어지는 작은 정수는 샘플 번호 열 이름이다 (수입검사 성적서)
        ints = [c for c in names if _NUM_VAL.match(c) and float("".join(c.split(","))) == int(float("".join(c.split(","))))
                and 0 <= float("".join(c.split(","))) <= 99]
        seq_names = set(ints) if len(ints) >= 3 and ints == sorted(ints, key=lambda s: float("".join(s.split(",")))) else set()
        singles = sum(1 for c in names if len(c) == 1)

        def _infoish(c: str) -> bool:                 # A|B|C 같은 연속 한 글자 열은 이름이다 (리뷰11 중간-E)
            return bool(_INFOISH.search(c)) and not (len(c) == 1 and singles >= 2)
        valueish = sum(1 for c in names if c not in seq_names and (_VALUEISH.search(c) or _infoish(c)))
        # '설비 | 1호기 | 라인 | A라인' '작성 | 김철수 | 검토 | 이영희' — 라벨과 값이 번갈아 오는 정보 행 (리뷰11 차단-D)
        valueish += _label_value_pairs(cells)
        # 이름 수는 중복 포함 — 옆으로 놓인 표 둘은 같은 열 이름을 두 번 쓴다 (3차 28). 숫자 없는 짧은
        # 이름 비율을 더해 '전원 투입 | 이상 없음 | OK' 같은 데이터 행이 머리글을 빼앗지 않게
        plain = sum(1 for c in names if len(c) <= 12 and not any(ch.isdigit() for ch in c)) / max(1, len(names))
        score = float(len(names) - 2 * valueish + plain)
        # 아래 두 행이 이 열들을 얼마나 채우나, 숫자가 얼마나 있나 — 진짜 머리글 밑에는 데이터가
        # 있고 데이터에는 숫자가 있다. 정보 블록(수신/견적번호/건명/유효기간) 밑에는 또 라벨이 온다
        # (2026-09-06 블라인드 2차 18·27: 정보 블록을 머리글로 잡아 NG 판정을 놓침)
        cols = [j for j, c in enumerate(cells) if c]
        fill, numeric = 0.0, 0.0
        # 바로 아래 행이 더 넓은 머리글 후보면 그 밑의 데이터는 이 행 것이 아니다 — 정보 행
        # ('수신: OO사 | 발주일 | B')이 진짜 머리글의 데이터 행을 빌려 점수를 받던 것 (리뷰10 차단-1)
        # 단 옆 칸에 같은 이름이 반복된 그룹 행('기준 | 기준 | 결과 | 결과')은 아래 줄이 하위 열 이름이니 예외.
        # 두 줄 아래까지 본다 — 정보 행이 두 줄 위에 있어도 진짜 머리글의 데이터를 빌리던 것 (리뷰11 차단-D)
        is_group = any(c and j > 0 and cells[j - 1] == c for j, c in enumerate(cells))
        base_score = score
        shadowed = False
        for k in (i + 1, i + 2):
            nxt = by_idx.get(k)
            if not nxt:
                continue
            nxt_names = [c for j, c in enumerate(nxt) if c and not (j > 0 and nxt[j - 1] == c)]
            # 아래 행이 더 넓거나, 아래 행에만 열 이름다운 낱말(품명·수량·UNIT)이 있을 때 — 이 행에도 그런 낱말이
            # 있으면(한글 머리글 아래 영문 머리글 줄) 그 줄은 하위 줄이지 경쟁자가 아니다
            if not is_group and _looks_like_header(nxt) and _base_header_score(nxt) >= base_score \
                    and (len(nxt_names) > len(names)
                         or (any(_headerish(c) for c in nxt_names) and not any(_headerish(c) for c in names))):
                shadowed = True              # 아래 행이 더 머리글답다('품명 | 수량 | 단위') — 그 밑 데이터는 이 행 것이 아니다
                break
            got = [nxt[j] for j in cols if j < len(nxt) and nxt[j]]
            fill = max(fill, len(got) / max(1, len(cols)))
            numeric = max(numeric, sum(1 for v in got if _VALUEISH.search(v) or _NUM_VAL.match(v))
                          / max(1, len(got)))
        score += 3 * fill + 2 * numeric
        # 이미 후보가 있으면 확실히 나을 때(+2)만 교체 — 머리글 아래의 텍스트가
        # 풍부한 데이터 행이 열 한두 개 차이로 머리글을 빼앗지 않게 (2026-08-27).
        # 단 앞 후보가 값 칸('B'·'수신: OO사'·날짜)을 품은 정보 행이거나 아래에 더 나은 머리글 후보가 있어
        # 차용을 못 받은 행이면 우대 없이 비교한다
        need = best + (0.5 if best_infoish else 2) if header_idx is not None else best + 0.5
        if score >= need:
            best, header_idx, best_infoish = score, i, (valueish >= 1 or shadowed)
    if header_idx is None:
        # 머리글 없는 세로 양식(사양 카드: '처리 속도 | 60 팩/분') — 첫 칸을 항목 이름(키)으로,
        # 나머지를 값으로 (2026-09-06 블라인드 2차 05·08: 항목 0건으로 비교가 통째로 빠짐)
        kv: list[Row] = []
        for i, cells in all_cells:
            texts = [c for c in cells if c]
            if len(texts) < 2 or not texts[0] or len(texts[0]) > 40:
                continue
            kv.append(Row(key="".join(texts[0].split()), values={"값": " | ".join(texts[1:])},
                          where=f"{ws.title}!행{i}"))
        return kv, ["항목", "값"], []
    header = [c.upper() for c in dict(all_cells)[header_idx]]
    # 대분류/중분류/열 이름처럼 머리글이 여러 줄이면 아래 줄을 붙여 '기준 하한'·'결과 측정'으로 —
    # 그러지 않으면 둘째 줄이 데이터 행이 되어 값 변경이 엉뚱한 이름으로 나온다 (2026-09-06 3차 04)
    for extra in (header_idx + 1, header_idx + 2):
        nxt = by_idx.get(extra)
        after = by_idx.get(extra + 1)
        if not nxt or not after:
            break
        cells_n = [c for c in nxt if c]
        if not cells_n or any((any(ch.isdigit() for ch in c) and not _small_int(c)) or len(c) > 16 for c in cells_n):
            break
        if not any(_NUM_VAL.match(c) or _VALUEISH.search(c) for c in after if c):
            break
        # 아래 줄이 '하위 열 이름'인가 — 대부분 병합 그룹(옆 칸과 같은 이름) 아래에 놓여야 한다.
        # 데이터 행('전원 투입 | 이상 없음 | OK')은 고유한 이름 칸 아래에 오므로 합치지 않는다
        under_group = sum(1 for j, c in enumerate(nxt) if c and j < len(header)
                          and (not header[j] or (j > 0 and header[j - 1] == header[j])
                               or (j + 1 < len(header) and header[j + 1] == header[j])))
        if under_group < 0.6 * len(cells_n):
            break
        # 하위 열 이름은 서로 달라야 한다('양호 | 양호 | 양호'는 데이터). 그 값이 아래 행 같은 열에
        # 다시 나와도 데이터 (리뷰10 중간-1: 첫 데이터 행이 머리글로 합쳐져 값 변경을 삼킴)
        if len(set(cells_n)) < len(cells_n):
            break
        if any(j < len(after) and after[j] == c for j, c in enumerate(nxt) if c):
            break
        merged_names = []
        for j in range(max(len(header), len(nxt))):
            top = header[j] if j < len(header) else ""
            sub = nxt[j].upper() if j < len(nxt) else ""
            merged_names.append(f"{top} {sub}".strip() if sub and sub != top else top)
        header = merged_names
        header_idx = extra
    # 머리글 위의 제목 행("견 적 서", "수신: …") — 문서 유형의 가장 확실한 단서인데
    # 버려져 내용 판정이 머리글에만 기대던 것 (2026-09-03 재검토)
    titles = [" ".join(dict.fromkeys(c for c in cells if c))
              for i, cells in all_cells if i < header_idx and any(cells)][:10]
    # 머리글 없는 열의 낱 셀(표 옆 메모·비고) — 버려져 "글자·표·그림 동일"로 단언됐다
    # (검토19 감지 ⑥). 글줄로 남겨 글자 비교가 본다
    stray: list[str] = []
    stray_rows: list = []          # (행 번호, 그 행의 값 사전, 머리글 없는 칸들)

    from watcher.diff import strip_leading_no

    def emit(hdr, data_rows, base_name, group_title_fn):
        """머리글 하나와 그 데이터 행들로 Row를 만든다. 옆으로 놓인 표는 빈 열로 나눈다."""
        ncol = len(hdr)
        gap = [not hdr[j] and all(j >= len(c) or not c[j] for _, c in data_rows) for j in range(ncol)]
        segments: list = []
        start = None
        for j in range(ncol + 1):
            if j < ncol and not gap[j]:
                if start is None:
                    start = j
            elif start is not None:
                if sum(1 for k in range(start, j) if hdr[k]) >= 2:
                    segments.append((start, j))
                start = None
        if len(segments) > 1:
            # 오른쪽 조각에 행을 가를 열(품번·항목·TAG…)이 없으면 빈 열 하나 끼어든 한 표다 —
            # '코드 품명 | (빈 열) | 납기 업체'가 표 둘로 갈려 무변경 파일에 시트 추가·삭제가 나던 것 (리뷰10)
            kept = [segments[0]]
            for c0, c1 in segments[1:]:
                sh = hdr[c0:c1]
                seg_rows = [r for r in ({h: v for h, v in zip(sh, cells[c0:c1]) if h and v} for _, cells in data_rows) if r]
                left_names = {h for h in hdr[kept[-1][0]:kept[-1][1]] if h}
                standalone = _user_key_col(sh) is not None or any(r.get("TAG") for r in seg_rows) \
                    or _pick_key_col(seg_rows) is not None \
                    or any(h in left_names for h in sh if h)      # 이름이 겹치면 합칠 수 없다 (리뷰11 차단-B)
                if standalone:
                    kept.append((c0, c1))
                else:
                    kept[-1] = (kept[-1][0], c1)
            segments = kept
        if len(segments) <= 1:
            segments = [(0, ncol)]
        for si, (c0, c1) in enumerate(segments, start=1):
            if len(segments) == 1:
                sname = base_name
            else:
                gtitle = group_title_fn(c0, c1)
                sname = f"{base_name}·{gtitle or f'표{si}'}"
            seg_header = _unique_header(hdr[c0:c1])
            collected: list[tuple[int, dict]] = []
            totals: list[tuple[int, str, dict]] = []
            for i, cells in data_rows:
                seg = cells[c0:c1]
                if not any(seg):
                    continue
                tlabel = next((c for c in seg if c and _TOTAL_ROW.match(c)), None)
                if tlabel:
                    # 소계/합계 행은 위치가 밀려도 라벨('합계', '소계')을 키로 삼아 값만 비교한다 —
                    # 통째로 버렸더니 "단가는 바뀌었는데 합계는 그대로"로 읽혔다 (2026-09-06 블라인드 채점 1순위)
                    tv = {h: v for h, v in zip(seg_header, seg) if h and v and not _TOTAL_ROW.match(v)}
                    if tv:
                        totals.append((i, "".join(tlabel.split()), tv))
                    continue
                # 머리글이 빈 열은 데이터로 취급하지 않는다 (수백 열짜리 양식 대응)
                values = {h: v for h, v in zip(seg_header, seg) if h and v}
                extras = [v for h, v in zip(seg_header, seg) if not h and v]
                if extras and len(stray_rows) < 200:
                    stray_rows.append((i, values, extras))
                if values:
                    collected.append((i, values))

            # 행 식별자: 사용자가 정한 키 열 > TAG 열 > 자동 선택된 식별 열(설명·품번류, 또는 두세 열의 조합) > 행번호
            key_col = None
            user_col = _user_key_col(seg_header)
            if user_col is None and not any(v.get("TAG") for _, v in collected):
                key_col = _pick_key_col([v for _, v in collected])

            def key_of(values) -> str | None:
                if user_col:
                    return strip_leading_no(values.get(user_col)) or None
                if values.get("TAG"):
                    return values["TAG"]
                if isinstance(key_col, tuple):
                    parts = [strip_leading_no(values.get(c)) for c in key_col if values.get(c)]
                    return " ".join(parts) if len(parts) == len(key_col) else None
                if key_col:
                    return strip_leading_no(values.get(key_col)) or None
                return None
            for i, values in collected:
                rows.append(Row(key=key_of(values) or f"{sname}!행{i}", values=values, where=f"{sname}!행{i}"))
            # 머리글 없는 칸은 행 번호가 아니라 그 행의 키(품번·태그)로 이름 붙인다 — 행 하나를
            # 끼워 넣으면 아래 칸 전부가 "[비고 2행]→[비고 3행]" 변경으로 도배됐다 (검토19 2차 N4)
            for i, values, extras in stray_rows:
                k = (key_of(values) if values else None) or f"{i}행"
                stray.extend(f"[비고 {k}] {v}" for v in extras)
            seen_t: Counter = Counter()
            for i, tlabel, tv in totals:
                seen_t[tlabel] += 1
                key = f"{tlabel}#{seen_t[tlabel]}" if seen_t[tlabel] > 1 else tlabel
                if multi:
                    key = f"{sname} {key}"        # 시트마다 '합계'가 있으면 어느 시트인지
                rows.append(Row(key=key, values=tv, where=f"{sname}!행{i}"))

    def group_title(c0: int, c1: int) -> str:
        """옆으로 놓인 표의 이름 — 머리글 위 세 줄 안에서 그 표 자리에 적힌 제목"""
        for k in (1, 2, 3):
            row = by_idx.get(header_idx - k)
            if row and any(row[c0:c1]):
                return next(c for c in row[c0:c1] if c)
        return ""

    # 위아래로 놓인 표 여럿: 빈 행으로 나뉜 덩어리 가운데 첫 행이 머리글 같고 열 이름이 본 표와 다르면
    # 따로 읽는다 — LOT표·측정표·외관표가 위아래로 있는 성적서에서 첫 표가 '제목'으로 뭉개지던 것
    # (2026-09-06 블라인드 3차 03). 빈 행이 끼어든 한 표(열 이름이 이어지지 않음)는 나누지 않는다
    blocks: list = []
    cur: list = []
    for i, cells in all_cells:
        if any(cells):
            cur.append((i, cells))
        elif cur:
            blocks.append(cur); cur = []
    if cur:
        blocks.append(cur)
    main_names = {h for h in header if h}
    main_block = next((b for b in blocks if any(i == header_idx for i, _ in b)), [])
    main_sig = _majority_sig([cs for i, cs in main_block if i > header_idx])
    extra_blocks: list = []
    main_block_rows: set = set()
    for blk in blocks:
        rows_in = {i for i, _ in blk}
        if header_idx in rows_in:
            main_block_rows = rows_in
            continue
        first_i, first_cells = blk[0]
        if len(blk) < 2 or not _looks_like_header(first_cells):
            continue
        names = [c for j, c in enumerate(first_cells) if c and not (j > 0 and first_cells[j - 1] == c)]
        if len(names) < 2 or any(_VALUEISH.search(c) for c in names):
            continue
        inter = len(set(n.upper() for n in names) & main_names)
        if inter >= 0.5 * min(len(names), max(1, len(main_names))):
            continue                                  # 본 표와 같은 열 이름 — 같은 표의 조각
        # 열 값 유형 서명 — 첫 행이 본 표의 데이터 행과 같은 자리·같은 유형(숫자/글자)이면 이어지는 데이터다
        # ('설치 위치 | 2층 동편'); 첫 행은 글자뿐인데 둘째 행에 숫자가 서면 새 표의 머리글이다
        # ('재질 | 두께 | 폭 | 길이' 아래 'SS400 | 6 | 100 | 200') — 이름 사전은 양쪽으로 틀렸다 (리뷰11 중간-F)
        first_sig = _type_sig(first_cells)
        if main_sig and first_sig == main_sig:
            continue
        second_sig = _type_sig(blk[1][1]) if len(blk) >= 2 else ()
        header_shape = ("n" not in first_sig and any(
            b == "n" and a == "t" for a, b in zip(first_sig, second_sig)))
        if not header_shape and not any(_headerish(n) for n in names):
            continue
        # 그 행의 값이 다른 데이터 행에도 나오면 데이터 행이다
        other_vals = {c for i2, cs in all_cells if i2 > header_idx and i2 not in rows_in for c in cs if c}
        if sum(1 for n in names if n in other_vals) >= len(names) * 0.5:
            continue
        extra_blocks.append(blk)
    extra_rows: set = set()
    for blk in extra_blocks:
        extra_rows |= {i for i, _ in blk}
    main_data = [(i, cells) for i, cells in all_cells
                 if i > header_idx and any(cells) and i not in extra_rows]
    emit(header, main_data, ws.title, group_title)
    for blk in extra_blocks:
        h_i, h_cells = blk[0]
        hdr2 = [c.upper() for c in h_cells]
        name2 = f"{ws.title}·{next(c for c in h_cells if c)}"
        emit(hdr2, blk[1:], name2, lambda c0, c1: "")
    return rows, header, titles + stray


def extract(path: Path) -> Document:
    # read_only가 아니어야 병합 범위를 알 수 있다. BOM류는 수 MB라 감당 가능
    wb = openpyxl.load_workbook(path, read_only=False, data_only=True)
    # 엑셀이 아닌 도구가 저장한 파일은 수식 셀의 계산값이 비어 있다 — 그 칸만 수식 문자열로 채운다.
    # "합계를 수식 대신 상수로 덮어쓴" 실수도 '=SUM(…) → 1946800'으로 보인다 (2026-09-06)
    formulas_by_sheet: dict = {}
    wb_f = None
    try:
        wb_f = openpyxl.load_workbook(path, read_only=True, data_only=False)
        for wsf in wb_f.worksheets:
            fm: dict = {}
            for row in wsf.iter_rows():
                for cell in row:
                    v = cell.value
                    if isinstance(v, str) and v.startswith("="):
                        fm[(cell.row, cell.column)] = v
            if fm:
                formulas_by_sheet[wsf.title] = fm
    except Exception:
        formulas_by_sheet = {}
    finally:
        try:
            if wb_f is not None:
                wb_f.close()
        except Exception:
            pass
    rows: list[Row] = []
    revision_history: list[Row] = []
    raw_texts: list[TextLine] = []
    # 숨김 시트도 읽는다 — 단가 기준표를 숨겨 두고 요약 시트가 참조하는 양식에서 숨김 시트의 값
    # 변경이 진짜 변경이고, 숨김/표시 전환만은 변경이 아니다 (2026-09-06 블라인드 2차 08)
    for ws in wb.worksheets:
        merged = _merged_anchor_map(ws)
        sheet_rows, _, titles = _sheet_rows(ws, merged, multi=False,
                                            formulas=formulas_by_sheet.get(ws.title))
        raw_texts.extend(TextLine(tt, f"{ws.title}!{'비고' if tt.startswith('[비고 ') else '제목'}")
                         for tt in titles)
        if _REV_SHEET.search(ws.title):
            revision_history.extend(sheet_rows)
        else:
            rows.extend(sheet_rows)
    wb.close()

    fields: dict[str, Field] = {}
    projects = Counter(r.values["PROJECT"] for r in rows if r.values.get("PROJECT"))
    if projects:
        top = projects.most_common(1)[0][0]
        fields["PROJECT"] = Field("PROJECT", top, "PROJECT 열 최빈값")
    # 개정이력 시트가 있으면 마지막 행의 Rev를 표제란 REV처럼 올린다 — 그래야 BOM 행이 바뀌었는데
    # 개정이력은 그대로인 것을 도면과 같은 'Rev 미갱신' 검사가 잡는다 (검토24 A-2: 실사용 day2b가
    # 정확히 그 경우였는데 아무 말이 없었다). 시트가 없으면 REV 없음 — 검사도 없다
    for r in reversed(revision_history):
        rv = next((str(v).strip() for k, v in r.values.items()
                   if v not in (None, "") and re.match(r"^(REV(ISION)?|개정|판|버전|VER)", str(k).strip(), re.I)
                   and not re.search(r"(일자|날짜|DATE|내용|사유|비고|자|DESC)", str(k), re.I)), None)
        if rv:
            fields["REV"] = Field("REV", rv, f"{r.where} (개정이력)")
            break
    notes: list[str] = []
    if not rows and not raw_texts:
        # 표가 아닌 엑셀(공정 배치도·그림만 있는 시트)에서 아무것도 못 읽고도 고지가 없어,
        # 브리핑이 "내용 변경 없음 — 파일이 다시 저장되기만 했습니다"라고 **단언**했다.
        # 없는 알림보다 틀린 알림이 나쁘다 (2026-09-09 추출 검토 차단 4, 원칙 4·5)
        notes.append("표로 읽을 내용을 찾지 못했습니다 — 셀에 값이 없거나 그림·개체로만 된 "
                     "문서일 수 있습니다. 변경 사실과 그림만 비교합니다")
    return Document(doc_type="xlsx", path=str(path), fields=fields, rows=rows,
                    revision_history=revision_history, raw_texts=raw_texts, notes=notes)
