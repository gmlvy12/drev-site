# -*- coding: utf-8 -*-
"""문서 유형 공통 모델. 모든 추출기는 이 모델로 수렴한다 (문서 유형 독립 원칙).

where 필드는 모든 값의 '근거 위치'다 — 근거 없는 값은 모델에 못 들어온다 (PRINCIPLE 4).
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

# 기기 태그 패턴: M-101, X-12, MCCB-01, 1M-1 ... (전장/P&ID 공통 관례).
# 앞에 영숫자·대시가 붙은 것(DWG-E-001의 E-001, 전화번호 등)은 태그가 아니다 —
# 부정 후방탐색으로 차단 (2026-08-26 설계 엔지니어 검토: 오탐이 태그 사전을 오염)
TAG_RE = re.compile(r"(?<![A-Z0-9-])\d?[A-Z]{1,6}-\d+[A-Z0-9]*\b")

# 태그로 오인하기 쉬운 접두 — 도면번호·시트 참조·문서 표기류 (전부 대문자)
TAG_EXCLUDE_PREFIX = {"DWG", "TEL", "FAX", "ISO", "NOTE", "SH", "SHT", "FIG",
                      "DOC", "PAGE", "REV", "NO", "P/N", "KS", "IEC", "JIS"}

_TAG_PREFIX_RE = re.compile(r"^\d?([A-Z]+)")


def set_tag_pattern(pattern: str) -> None:
    """회사별 태그 관례 재정의 (config tag_pattern) — 태그 표기는 회사·고객마다
    제각각이라 정규식 한 줄 커스터마이즈가 현실적이다 (2026-08-26)."""
    global TAG_RE
    TAG_RE = re.compile(pattern)


def is_tag(text: str) -> bool:
    """제외 접두(도면번호·전화 등)를 거른 최종 태그 판정."""
    m = _TAG_PREFIX_RE.match(text)
    return not (m and m.group(1) in TAG_EXCLUDE_PREFIX)


# 날짜 라벨 앞 꾸밈말 — 'DUE DATE'·'DELIVERY_DATE'·'납품 예정 일자'는 표제 일자가 아니라 **내용**(납기)이다. 고정 길이
# lookbehind로는 'DELIVERY  DATE'(두 칸)·밑줄 꼴이 빠져나갔고, PDF 한 줄 여러 칸에서는 'DUE DATE:'의 DATE가 표제 DATE 칸이
# 되어 납기 변경이 '일자만 갱신'으로 접혔다 (검토44 A 중간 1·B 차단 1·2). 일치 **앞 문맥**에 붙여 본다
DATE_QUAL = re.compile(
    r"(?:(?<![A-Za-z])(?:DELIVERY|DUE|SHIP(?:PING|MENT)?|START|END|EXPIRY|EXPIRATION|EFFECTIVE|ORDER|INVOICE|TARGET|"
    r"COMPLETION|PAYMENT|REQUIRED|LAST|ETA|ETD|ARRIVAL|CONTRACT|CLOSING|RECEIPT|RECEIVED|DISPATCH|REQUEST(?:ED)?|"
    r"PROMISED|PLANNED|ESTIMATED|DEADLINE|INSTALL(?:ATION)?|INSPECTION|TEST|FAT|SAT|COMMISSIONING|HANDOVER|BID|"
    r"QUOTE|QUOTATION|VALID(?:ITY)?|PRODUCTION|MANUFACTURING|PACKING|LOADING|DEPARTURE|PICKUP|OPENING|ACCEPTANCE)"
    r"|(?:납기|완료|만료|출하|입고|납품|지급|계약|준공|착공|도착|선적|마감|요청|희망|시작|종료|인도|결제|유효|검수|설치|"
    r"시운전|출고|반입|반출|견적|생산|제작|포장|인수|인계)"
    r"(?:\s*(?:예정|요청|희망|계획))?"
    r")[\s_\-.]*$", re.I)
# 밑줄·하이픈으로 붙은 영문 낱말('INSTALL_DATE'·'FAT-DATE')은 목록에 없어도 꾸밈말이다 — 표제 일자 칸 이름은 아래 낱말뿐
_TITLE_DATE_WORDS = {"REV", "REVISION", "REVISED", "ISSUE", "ISSUED", "DWG", "DRAWING", "PRINT", "PRINTED", "PLOT",
                     "PLOTTED", "CHECK", "CHECKED", "APPROVAL", "APPROVED", "DRAWN", "DESIGN", "DESIGNED", "CREATED",
                     "CREATION", "MODIFIED", "UPDATE", "UPDATED", "RELEASE", "RELEASED", "REVIEW", "REVIEWED", "SAVE",
                     "SAVED", "DOC", "DOCUMENT", "SHEET", "OUTPUT", "PUBLISH", "PUBLISHED", "DRAFT", "FILE", "TITLE"}


def date_qualified(prefix: str) -> bool:
    """날짜 라벨 바로 앞(prefix 끝)에 꾸밈말이 붙었나 — 그러면 그 날짜는 표제 일자가 아니라 내용이다."""
    if DATE_QUAL.search(prefix):
        return True
    m = re.search(r"([A-Za-z]{3,})[_\-]+$", prefix)
    return bool(m and m.group(1).upper() not in _TITLE_DATE_WORDS)


def find_tags(text: str) -> list[str]:
    """한 줄의 모든 태그 — 'M-101 5.5kW M-102 7.5kW'처럼 한 줄 두 기기 대응."""
    return [m.group() for m in TAG_RE.finditer(text) if is_tag(m.group())]


@dataclass(frozen=True)
class Field:
    """표제란(또는 머리말)의 이름-값 한 칸. box: OCR로 읽은 자리(x0,y0,x1,y1 pt) — 그림 비교 마스크·사진용."""
    name: str
    value: str
    where: str
    box: tuple | None = None

    def __post_init__(self):
        if self.box is not None and not isinstance(self.box, tuple):
            object.__setattr__(self, "box", tuple(self.box))   # JSON 복원분(list) — 해시 가능해야 한다 (리뷰13 치명-1)


@dataclass(frozen=True)
class Row:
    """표의 한 행 (BOM 행, 리비전 블록 행). key는 행 식별자 (TAG, Rev 등)."""
    key: str
    values: dict
    where: str


@dataclass(frozen=True)
class TextLine:
    """본문 텍스트 한 줄 (같은 줄에 있던 조각들은 추출기가 병합). box: OCR로 읽은 자리(pt)."""
    text: str
    where: str
    box: tuple | None = None

    def __post_init__(self):
        if self.box is not None and not isinstance(self.box, tuple):
            object.__setattr__(self, "box", tuple(self.box))


@dataclass
class Document:
    doc_type: str                                   # "dxf" | "pdf" | "xlsx" | ...
    path: str
    fields: dict = field(default_factory=dict)      # {name: Field} 표제란
    rows: list = field(default_factory=list)        # [Row] 표 데이터 (BOM 등)
    revision_history: list = field(default_factory=list)  # [Row] 리비전 블록
    raw_texts: list = field(default_factory=list)   # [TextLine] 본문
    notes: list = field(default_factory=list)       # [str] 추출 한계 고지 (예: 텍스트 층 없음)
    # 표제란 틀의 범위 [x0, y0, x1, y1] (DXF 도면 좌표) — 그 안의 그림 변경은 표제란 변경이지 '내용'이 아니다.
    # 모르면 None (검토39 P1 중간 1: 표제란 틀 교체가 'Rev 미갱신'이 됐다)
    title_box: list | None = None

    @property
    def revision(self) -> str | None:
        f = self.fields.get("REV")
        return f.value if f else None

    @property
    def project(self) -> str | None:
        f = self.fields.get("PROJECT")
        return f.value if f else None

    def tag_lines(self) -> dict:
        """본문에서 기기 태그가 있는 줄: {tag: TextLine} (첫 출현). 일관성 검사용."""
        out: dict[str, TextLine] = {}
        for line in self.raw_texts:
            for tag in find_tags(line.text):
                if tag not in out:
                    out[tag] = line
        return out

    def tag_occurrences(self) -> dict:
        """태그의 전 출현 줄: {tag: [TextLine, ...]}. 같은 태그가 심볼 옆과
        결선표에 두 번 나오는 도면에서 첫 줄만 보면 오탐이 난다 (2026-08-26)."""
        out: dict[str, list[TextLine]] = {}
        for line in self.raw_texts:
            for tag in find_tags(line.text):
                out.setdefault(tag, []).append(line)
        return out

    def to_dict(self) -> dict:
        return asdict(self)

    def sanitized(self) -> "Document":
        """추출 텍스트의 깨진 인코딩 정화본. 원본에 문제가 없으면 자기 자신."""
        d = self.to_dict()
        if not _has_surrogate(d):
            return self
        return Document.from_dict(clean_obj(d))

    @classmethod
    def from_dict(cls, d: dict) -> "Document":
        return cls(
            doc_type=d["doc_type"],
            path=d["path"],
            fields={k: Field(**v) for k, v in d["fields"].items()},
            rows=[Row(**r) for r in d["rows"]],
            revision_history=[Row(**r) for r in d["revision_history"]],
            raw_texts=[TextLine(**t) for t in d["raw_texts"]],
            notes=d.get("notes", []),  # 구버전 저장분(notes 없음) 호환
            title_box=d.get("title_box"),
        )


# ------------------------------------------------------------ 깨진 인코딩 정화
# 한국 CAD 실무 파일에는 코드페이지 정보가 틀려 cp949 원시 바이트가 서로게이트
# (\udc80~\udcff)로 섞여 나오는 텍스트가 흔하다. 이런 문자열은 sqlite 저장과
# utf-8 파일 쓰기를 UnicodeEncodeError로 죽여 검사 전체가 롤백되는 영구 실패가
# 된다 (2026-08-27 회사 서버 실파일에서 확인). 모든 추출 결과는 extract() 관문에서
# 이 정화를 거친다 — 복구 우선(cp949 재해석), 불가하면 대체 문자.

def _is_broken(ch: str) -> bool:
    return 0xD800 <= ord(ch) <= 0xDFFF


_NONASCII_RUN = re.compile(r"[^\x00-\x7f]+")


def clean_text(s: str) -> str:
    """서로게이트가 섞인 문자열을 저장 가능한 형태로. 정상 문자열은 그대로.

    cp949 바이트를 utf-8+surrogateescape로 읽으면 일부 바이트쌍이 우연히 유효한
    UTF-8로 디코딩돼 '가짜 문자 + 서로게이트'가 섞인다. 그래서 복구는 문자 단위가
    아니라 비ASCII 연속 구간 단위로: 서로게이트가 낀 구간 전체를 원시 바이트로
    되돌려 cp949로 재해석한다. 서로게이트 없는 구간(진짜 한글)은 손대지 않는다."""
    try:
        s.encode("utf-8")
        return s
    except UnicodeEncodeError:
        pass

    def fix_run(m: re.Match) -> str:
        run = m.group(0)
        try:
            run.encode("utf-8")
            return run                       # 정상 구간 보존
        except UnicodeEncodeError:
            pass
        try:                                 # 원시 바이트 복원 → cp949 재해석
            return run.encode("utf-8", "surrogateescape").decode("cp949")
        except (UnicodeEncodeError, UnicodeDecodeError):
            # 복구 불가(상위 서로게이트·타 인코딩): 깨진 문자만 대체 기호로
            return "".join("�" if _is_broken(c) else c for c in run)

    return _NONASCII_RUN.sub(fix_run, s)


def clean_obj(o):
    """dict/list 속 모든 문자열에 clean_text 적용 (키 포함)."""
    if isinstance(o, str):
        return clean_text(o)
    if isinstance(o, list):
        return [clean_obj(x) for x in o]
    if isinstance(o, dict):
        return {clean_obj(k): clean_obj(v) for k, v in o.items()}
    return o


def _has_surrogate(o) -> bool:
    if isinstance(o, str):
        return any(_is_broken(c) for c in o)
    if isinstance(o, list):
        return any(_has_surrogate(x) for x in o)
    if isinstance(o, dict):
        return any(_has_surrogate(k) or _has_surrogate(v) for k, v in o.items())
    return False
