# -*- coding: utf-8 -*-
"""문서 유형별 추출기. 공통 인터페이스: extract(path) -> Document | None.

유형 추가는 모듈 하나 추가 + 아래 분기 한 줄로 끝나야 한다 (CLAUDE.md 구조 원칙).
"""

from __future__ import annotations

from pathlib import Path

from watcher.extract.base import Document


# ── 형식 레지스트리 — 확장자에 관한 사실은 **여기 한 곳**에만 적는다 (검토19 원칙 ⑤).
# 전에는 읽기 가능 목록·크기 상한·유형 추정·화면 분류·그림 기록이 여섯 곳에 흩어져
# 있어 .xlsm을 넣을 때 셋을 빠뜨렸다. 아래 파생 상수만 다른 모듈이 쓴다.
#   read    : 내용(글자·표)을 읽어 비교하나. 아니면 파일 수준(바뀐 사실·크기·저장 시각)만
#   kind    : 이름·폴더에 단서가 없을 때의 기본 문서 유형
#   max_mb  : 이보다 크면 내용 비교를 생략(변경 사실만) — 병적 파일이 검사를 잡아먹지 않게
#   render  : 페이지 그림을 기록해 픽셀 비교하나 (.dwg는 미리보기 그림끼리 — 별도 경로)
FORMATS: dict[str, dict] = {
    ".dxf":  {"read": True,  "kind": "도면", "max_mb": 80,  "render": True},
    ".dwg":  {"read": False, "kind": "도면"},          # 변환기가 있을 때만 글자, 미리보기 그림 비교
    ".pdf":  {"read": True,  "kind": "도면", "max_mb": 120, "render": True},
    ".xlsx": {"read": True,  "kind": "표",   "max_mb": 40},
    ".xlsm": {"read": True,  "kind": "표",   "max_mb": 40},
    ".xls":  {"read": False, "kind": "표"},
    ".csv":  {"read": False, "kind": "표"},
    ".docx": {"read": True,  "kind": "문서", "max_mb": 40},
    ".hwpx": {"read": True,  "kind": "문서", "max_mb": 40},
    ".doc":  {"read": False, "kind": "문서"},
    ".hwp":  {"read": False, "kind": "문서"},
    ".txt":  {"read": False, "kind": "문서"},
    ".pptx": {"read": False, "kind": "문서"},
    ".ppt":  {"read": False, "kind": "문서"},
}
READABLE_EXTS = tuple(e for e, f in FORMATS.items() if f.get("read"))
EXTRACT_MAX_MB = {e: f["max_mb"] for e, f in FORMATS.items() if f.get("max_mb")}
RENDER_EXTS = tuple(e for e, f in FORMATS.items() if f.get("render"))


def kind_groups() -> tuple:
    """(유형, 확장자들) 순서 보존 — 이름·폴더 단서가 없을 때의 확장자 기본 유형."""
    out: dict[str, list] = {}
    for e, f in FORMATS.items():
        out.setdefault(f["kind"], []).append(e)
    return tuple((k, tuple(v)) for k, v in out.items())


def can_read_content(path) -> bool:
    """이 파일의 내용을 읽어 비교할 수 있나 (아니면 파일 수준 감시만)."""
    return Path(path).suffix.lower() in READABLE_EXTS


def extract(path: Path) -> Document | None:
    ext = Path(path).suffix.lower()
    if ext == ".dxf":
        from watcher.extract import dxf
        doc = dxf.extract(path)
    elif ext == ".pdf":
        from watcher.extract import pdf
        doc = pdf.extract(path)
    elif ext in (".xlsx", ".xlsm"):
        # .xlsm(매크로 포함 통합문서)도 같은 zip+XML 구조라 openpyxl로 읽힌다.
        # 분기에 빠져 있어 BOM을 .xlsm으로 관리하는 곳에서는 파일 수준 감시만
        # 되던 것 (2026-09-10, 읽을 수 있는 형식 재확인 중 발견)
        from watcher.extract import xlsx
        doc = xlsx.extract(path)
    elif ext in (".docx", ".hwpx"):
        # 워드·한글(hwpx)은 zip 안의 XML — 표준 라이브러리로 읽는다 (2026-09-02:
        # 사양서·견적서가 파일명에 단서가 없으면 전부 '문서'로 떨어지던 것)
        from watcher.extract import docx
        doc = docx.extract(path)
    else:
        # .dwg 바이너리, .hwp(구형 바이너리) 등: 파일 수준(해시) 감지만
        return None
    # 공통 관문: 깨진 인코딩(서로게이트) 정화 — 어떤 추출기 출신이든 여기서 걸러
    # sqlite 저장·브리핑 쓰기가 죽지 않게 보장한다 (2026-08-27 회사 실파일)
    return doc.sanitized() if doc is not None else None
