# -*- coding: utf-8 -*-
"""문서 유형별 추출기. 공통 인터페이스: extract(path) -> Document | None.

유형 추가는 모듈 하나 추가 + 아래 분기 한 줄로 끝나야 한다 (CLAUDE.md 구조 원칙).
"""

from __future__ import annotations

from pathlib import Path

from watcher.extract.base import Document


# ── 형식 레지스트리 — 확장자에 관한 사실은 **여기 한 곳**에만 적는다 (검토19 원칙 ⑤).
# 전에는 읽기 가능 목록·크기 상한·유형 추정·화면 분류·그림 기록이 여섯 곳에 흩어져
# 있어 .xlsm을 넣을 때 셋을 빠뜨렸다. 아래 파생 상수만 다른 모듈이 쓴다.
#   read    : 내용(글자·표)을 읽어 비교하나. 아니면 파일 수준(바뀐 사실·크기·저장 시각)만
#   kind    : 이름·폴더에 단서가 없을 때의 기본 문서 유형
#   max_mb  : 이보다 크면 내용 비교를 생략(변경 사실만) — 병적 파일이 검사를 잡아먹지 않게
#   render  : 페이지 그림을 기록해 픽셀 비교하나 (.dwg는 미리보기 그림끼리 — 별도 경로)
FORMATS: dict[str, dict] = {
    ".dxf":  {"read": True,  "kind": "도면", "max_mb": 80,  "render": True},
    ".dwg":  {"read": False, "kind": "도면"},          # 변환기가 있을 때만 글자, 미리보기 그림 비교
    ".pdf":  {"read": True,  "kind": "도면", "max_mb": 120, "render": True},
    ".xlsx": {"read": True,  "kind": "표",   "max_mb": 40},
    ".xlsm": {"read": True,  "kind": "표",   "max_mb": 40},
    ".xls":  {"read": False, "kind": "표"},
    ".csv":  {"read": False, "kind": "표"},
    ".docx": {"read": True,  "kind": "문서", "max_mb": 40},
    ".hwpx": {"read": True,  "kind": "문서", "max_mb": 40},
    ".doc":  {"read": False, "kind": "문서"},
    ".hwp":  {"read": False, "kind": "문서"},
    ".txt":  {"read": False, "kind": "문서"},
    ".pptx": {"read": False, "kind": "문서"},
    ".ppt":  {"read": False, "kind": "문서"},
}
READABLE_EXTS = tuple(e for e, f in FORMATS.items() if f.get("read"))
EXTRACT_MAX_MB = {e: f["max_mb"] for e, f in FORMATS.items() if f.get("max_mb")}
RENDER_EXTS = tuple(e for e, f in FORMATS.items() if f.get("render"))


def kind_groups() -> tuple:
    """(유형, 확장자들) 순서 보존 — 이름·폴더 단서가 없을 때의 확장자 기본 유형."""
    out: dict[str, list] = {}
    for e, f in FORMATS.items():
        out.setdefault(f["kind"], []).append(e)
    return tuple((k, tuple(v)) for k, v in out.items())


def can_read_content(path) -> bool:
    """이 파일의 내용을 읽어 비교할 수 있나 (아니면 파일 수준 감시만)."""
    return Path(path).suffix.lower() in READABLE_EXTS


# 압축을 풀었을 때의 상한 — 디스크 2MB·풀면 1GB인 압축 폭탄 XLSX·DOCX가 통째로 메모리에 올라 검사 PC의
# 메모리가 3.5GB까지 찼다 (검토38 R10). 실무 BOM·사양서는 수십 MB를 넘지 않는다
ZIP_UNPACKED_LIMIT = 512 * 1024 * 1024


class TooLargeToRead(ValueError):
    """풀면 너무 큰 문서 — 내용은 읽지 않고 바뀐 사실·크기·저장 시각만 관리한다."""


def _check_zip_size(path: Path) -> None:
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            total = sum(i.file_size for i in z.infolist())
    except (zipfile.BadZipFile, OSError):
        # 암호 건 Office 문서는 zip이 아니라 OLE 복합 문서(D0 CF 11 E0…)다 — 'File is not a zip file'을
        # '파일이 깨져 열 수 없음 — 저장 중 끊겼거나…'로 옮겨 멀쩡한 암호 문서를 손상으로 알렸다 (경우100 B17)
        try:
            with open(path, "rb") as f:
                head = f.read(8)
        except OSError:
            return
        if head == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            raise TooLargeToRead("암호가 걸린 문서(또는 확장자만 바뀐 옛 바이너리 형식)라 내용을 읽지 못합니다 — "
                                 "바뀐 사실·크기·저장 시각만 관리합니다")
        return                                   # 깨진 파일은 각 추출기가 사유를 말한다
    if total > ZIP_UNPACKED_LIMIT:
        raise TooLargeToRead(f"압축을 풀면 {total // (1024 * 1024):,}MB라 내용을 읽지 않습니다 — "
                             f"바뀐 사실·크기·저장 시각만 관리합니다")


# 문서 안 그림·개체 부품 — 넣은 그림(media·BinData), 들어간 OLE 개체(embeddings), 차트. 썸네일(docProps/thumbnail)은 저장할 때마다
# 다시 그려지므로 넣지 않는다 (검토71 R4)
_PART_RE = None


def _part_re():
    global _PART_RE
    if _PART_RE is None:
        import re
        _PART_RE = re.compile(r"(?i)^(?:(?:word|xl)/(?:media|embeddings)/[^/]+|(?:word|xl)/charts/chart\d*\.xml|"
                              r"xl/drawings/drawing\d*\.xml|BinData/[^/]+)$")
    return _PART_RE


def _chart_norm(raw: bytes) -> bytes:
    """차트 XML 지문용 정규화 — 데이터 참조 수식(<c:f>)의 **시트 이름**과 값 캐시(numCache·strCache)를 뺀다. 시트 이름만 바꿔도
    참조 글자('견적'!$D$2 → '견적_rev2'!$D$2)와 캐시가 달라져 '차트 교체' + 거짓 Rev 미갱신이 났다 (대량 시험 XLSX F7, 2026-10-20).
    값은 표 비교가 따로 보고, 차트 종류·계열 수·참조 범위·제목 변화는 남는다."""
    import re
    t = re.sub(rb"(?s)<((?:\w+:)?(?:numCache|strCache|multiLvlStrCache))\b[^>]*?(?:/>|>.*?</\1>)", b"", raw)

    def _ref(m):
        body = re.sub(rb"(?:'(?:[^']|'')*'|[^'!(),\s<>=:]+)!", b"", m.group(2))
        return b"<" + m.group(1) + b">" + body + b"</" + m.group(1) + b">"
    return re.sub(rb"(?s)<((?:\w+:)?f)>(.*?)</\1>", _ref, t)


def _drawing_norm(raw: bytes) -> bytes:
    """XLSX 도형 부품(xl/drawings/drawingN.xml) 지문용 정규화 — 도형 글 상자(<xdr:txBody> — 글자와 그 글꼴)와 확장 목록(a:extLst,
    저장 프로그램이 붙이는 식별 GUID)을 뺀다. 글자는 추출기가 '[도형] …' 글줄로 따로 비교하니 여기서 또 세면 한 번 고친 것이 두 건이 된다. 남는 것은
    도형의 자리·크기·모양·화살표 — 셀만 비교해 엑셀로 그린 배치도의 도형을 옮긴 날 '내용 변경 없음'이라 단언했다
    (재검토 2026-10-28 R1-3)."""
    import re
    t = re.sub(rb"(?s)<((?:\w+:)?extLst)\b[^>]*?(?:/>|>.*?</\1>)", b"", raw)
    return re.sub(rb"(?s)<((?:\w+:)?txBody)\b[^>]*?(?:/>|>.*?</\1>)", b"", t)


def embedded_parts(path: Path) -> dict | None:
    """zip 문서 안의 그림·개체 부품 {이름: [지문16, 바이트 수, 자리]} — 읽기 전용. 읽지 못하면(손상·암호) None (= 비교 못 함).
    자리는 DOCX에서 그 부품을 참조하는 쪽(머리글·바닥글이면 회사 로고 같은 양식 그림 — 본문 그림과 따로 센다)."""
    import hashlib
    import posixpath
    import re
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            names = [i.filename for i in z.infolist() if not i.is_dir() and _part_re().match(i.filename)]
            owner: dict = {}
            for rel in z.namelist():
                m = re.match(r"(?i)^word/_rels/((header|footer|document)\d*)\.xml\.rels$", rel)
                if not m:
                    continue
                place = {"header": "머리글", "footer": "바닥글"}.get(m.group(2).lower(), "본문")
                for t in re.findall(rb'Target="([^"]+)"', z.read(rel)):
                    tgt = posixpath.normpath(posixpath.join("word", t.decode("utf-8", "replace")))
                    # 본문이 앞선다 — 같은 그림을 본문과 머리글이 함께 쓰면 본문 그림이다
                    if owner.get(tgt) != "본문":
                        owner[tgt] = place
            out: dict = {}
            for n in names:
                h = hashlib.sha256()
                size = 0
                _chart = re.match(r"(?i)^xl/charts/chart\d*\.xml$", n)
                if (_chart or re.match(r"(?i)^xl/drawings/drawing\d*\.xml$", n)) and z.getinfo(n).file_size <= 16 * 1024 * 1024:
                    raw = z.read(n)
                    size = len(raw)
                    h.update(_chart_norm(raw) if _chart else _drawing_norm(raw))
                    out[n] = [h.hexdigest()[:16], size, owner.get(n, "")]
                    continue
                with z.open(n) as f:
                    while True:
                        b = f.read(1 << 20)
                        if not b:
                            break
                        size += len(b)
                        h.update(b)
                out[n] = [h.hexdigest()[:16], size, owner.get(n, "")]
            return out
    except (zipfile.BadZipFile, OSError, ValueError, RuntimeError, EOFError, NotImplementedError):
        return None


def extract(path: Path) -> Document | None:
    ext = Path(path).suffix.lower()
    if ext in (".xlsx", ".xlsm", ".docx", ".hwpx"):
        _check_zip_size(Path(path))
    if ext == ".dxf":
        from watcher.extract import dxf
        doc = dxf.extract(path)
    elif ext == ".pdf":
        from watcher.extract import pdf
        doc = pdf.extract(path)
    elif ext in (".xlsx", ".xlsm"):
        # .xlsm(매크로 포함 통합문서)도 같은 zip+XML 구조라 openpyxl로 읽힌다.
        # 분기에 빠져 있어 BOM을 .xlsm으로 관리하는 곳에서는 파일 수준 감시만
        # 되던 것 (2026-09-10, 읽을 수 있는 형식 재확인 중 발견)
        from watcher.extract import xlsx
        doc = xlsx.extract(path)
    elif ext in (".docx", ".hwpx"):
        # 워드·한글(hwpx)은 zip 안의 XML — 표준 라이브러리로 읽는다 (2026-09-02:
        # 사양서·견적서가 파일명에 단서가 없으면 전부 '문서'로 떨어지던 것)
        from watcher.extract import docx
        doc = docx.extract(path)
    else:
        # .dwg 바이너리, .hwp(구형 바이너리) 등: 파일 수준(해시) 감지만
        return None
    if doc is not None and ext in (".xlsx", ".xlsm", ".docx", ".hwpx"):
        doc.parts = embedded_parts(Path(path))
    # 공통 관문: 깨진 인코딩(서로게이트) 정화 — 어떤 추출기 출신이든 여기서 걸러
    # sqlite 저장·브리핑 쓰기가 죽지 않게 보장한다 (2026-08-27 회사 실파일)
    return doc.sanitized() if doc is not None else None
