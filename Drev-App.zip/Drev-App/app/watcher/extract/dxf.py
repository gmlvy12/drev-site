# -*- coding: utf-8 -*-
"""DXF 추출기: TEXT/MTEXT/ATTRIB → 표제란·리비전 블록·본문 분류.

식별 휴리스틱 (순서대로):
  1. 레이어 이름에 TITLE 포함 → 표제란 / REV 포함 → 리비전 블록
  2. 레이어 힌트가 없으면 위치로: 우하단(오른쪽 40% × 아래 25%) → 표제란,
     우상단(오른쪽 40% × 위 25%) → 리비전 블록
형상(선·도형)은 읽지 않는다 (PRINCIPLE 7).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import ezdxf

from watcher.extract.base import Document, Field, Row, TextLine

# ezdxf가 시스템 폰트 캐시를 만들며 한글 이름 폰트마다 "cannot open font ..."
# 경고를 쏟아낸다 — 감시 동작과 무관한 소음이라 오류만 남긴다 (2026-08-27 실PC)
logging.getLogger("ezdxf").setLevel(logging.ERROR)

# 표제란 라벨 별칭 → 정규 이름
_LABEL_ALIASES = {
    "DWG_NO": "DWG_NO", "DWG NO": "DWG_NO", "DWG.NO": "DWG_NO",
    "DRAWING NO": "DWG_NO", "도면번호": "DWG_NO",
    "PROJECT": "PROJECT", "PROJ": "PROJECT", "프로젝트": "PROJECT",
    "REV": "REV", "REVISION": "REV", "리비전": "REV",
    "REV NO": "REV", "REV. NO": "REV", "REV NO.": "REV", "REVISION NO": "REV",   # (검토33 C1)
    "DATE": "DATE", "일자": "DATE",
    # 도면명 — 표제란 메타로 취급해 버리던 것을 필드로. 도면명 변경이 글자 비교에서
    # 통째로 사라졌다 (검토19 2차 브리핑 ②)
    "TITLE": "TITLE", "DWG TITLE": "TITLE", "DWG.TITLE": "TITLE", "DRAWING TITLE": "TITLE",
    "도면명": "TITLE",
}

_Y_TOL = 3.0  # 같은 줄로 볼 y 허용 오차 (도면 단위) — 글자 높이를 알면 그 높이로 대체
_EXPAND_BUDGET = 200_000        # 블록 전개로 읽을 가상 엔티티 총량 상한
_TRUNCATED: set = set()         # 예산에 걸려 끝까지 못 읽은 파일 경로 (extract가 고지 후 지움)

# 표제란 블록의 속성 태그 — 라벨 글자 없이 태그만 있는 블록도 표제란으로 읽는다
_ATTR_TAGS = {"DWG_NO", "DWGNO", "DWG-NO", "DRAWING_NO", "DRAWINGNO", "도면번호",
              "PROJECT", "PROJ", "프로젝트", "REV", "REVISION", "리비전", "DATE", "일자"}
_ATTR_CANON = {"TITLE": "TITLE", "DWG_TITLE": "TITLE", "DWGTITLE": "TITLE", "DRAWING_TITLE": "TITLE",
               "도면명": "TITLE", "TITLE1": "TITLE", "NAME": "TITLE",
               "DWG_NO": "DWG_NO", "DWGNO": "DWG_NO", "DWG-NO": "DWG_NO",
               "DRAWING_NO": "DWG_NO", "DRAWINGNO": "DWG_NO", "도면번호": "DWG_NO",
               "PROJECT": "PROJECT", "PROJ": "PROJECT", "프로젝트": "PROJECT",
               "REV": "REV", "REVISION": "REV", "리비전": "REV", "DATE": "DATE", "일자": "DATE"}


def _decode(s: str) -> str:
    """DXF의 \\U+XXXX 이스케이프(ANSI 코드페이지로 저장된 한글)를 복원 (2026-09-04 검토)."""
    try:
        from ezdxf.lldxf.encoding import decode_dxf_unicode, has_dxf_unicode
        return decode_dxf_unicode(s) if has_dxf_unicode(s) else s
    except Exception:
        return s


def _collect_texts(path: Path, space: str = "model", doc=None) -> tuple[list, dict, list]:
    """((text, x, y, layer, height) 목록, 속성 태그로 읽은 표제란 값 {정규명: (값, 어디)}, 속성 블록 리비전 행).
    TEXT/MTEXT/ATTRIB + 블록(INSERT) 내부 텍스트.

    실무 도면은 표제란을 블록으로 삽입하는 경우가 많다 — virtual_entities()로
    삽입 위치·배율이 반영된 좌표의 내부 텍스트까지 읽는다 (실물 테스트에서 확인된 격차).
    space='paper'면 배치(레이아웃) 공간 — 표제란이 거기 있는 도면용 (2026-09-04 검토).
    """
    if doc is None:
        doc = ezdxf.readfile(path)
    out = []
    attr_fields: dict = {}
    # 블록 전개 예산 — 6단 전개는 심볼 라이브러리에서 지수로 는다(500 인서트×6단 = 170초,
    # 검토19 2차 감지 N1). 상한을 넘으면 거기서 멈추고 extract()가 고지한다
    budget = [_EXPAND_BUDGET]

    def take(e) -> None:
        budget[0] -= 1
        t = e.dxftype()
        if t == "TEXT":
            p = e.dxf.insert
            out.append((_decode(e.dxf.text).strip(), p.x, p.y, e.dxf.layer,
                        float(e.dxf.height or 0)))
        elif t == "MTEXT":
            p = e.dxf.insert
            out.append((_decode(e.plain_text()).strip(), p.x, p.y, e.dxf.layer,
                        float(e.dxf.char_height or 0)))
        elif t == "DIMENSION":
            # 치수 문자 — 덮어쓴 값('125')이 있으면 그것, 없으면 실측값. 치수만 고친 개정을
            # 잡기 위해 (2026-09-06 블라인드 2차 48·50)
            try:
                txt = str(e.dxf.text or "").strip()
                if txt in ("", "<>"):
                    m = e.get_measurement()
                    txt = f"{m:g}" if isinstance(m, (int, float)) else ""
                p = e.dxf.text_midpoint if e.dxf.hasattr("text_midpoint") else e.dxf.defpoint
                if txt:
                    out.append((f"치수 {txt}", p.x, p.y, e.dxf.layer, 0.0))
            except Exception:
                pass

    # 블록 삽입마다 속성을 모아 두고, 다 읽은 뒤 **어느 삽입이 표제란인지** 정한다 — 태그 이름만 보고
    # 정하면 기기 심볼의 NAME·REV, 도면 목록표 행의 REV·DATE가 모두 '표제란 속성'이 되어 비교에서
    # 통째로 사라지고 필드까지 차지했다 (검토36 A N3·N4)
    inserts: list[dict] = []

    def expand_insert(e, depth: int, where_sp: str) -> None:
        attrs = []
        for a in e.attribs:
            p = a.dxf.insert
            tag = str(getattr(a.dxf, "tag", "") or "").strip().upper()
            attrs.append((_decode(a.dxf.text).strip(), p.x, p.y, a.dxf.layer, float(a.dxf.height or 0), tag))
        if attrs:
            try:
                ip = e.dxf.insert
                at_xy = (float(ip.x), float(ip.y))
            except Exception:
                at_xy = (attrs[0][1], attrs[0][2])
            inserts.append({"sp": where_sp, "name": str(getattr(e.dxf, "name", "") or ""),
                            "layer": str(getattr(e.dxf, "layer", "") or ""), "attrs": attrs, "at": at_xy})
        if depth <= 0:
            return
        exhausted = budget[0] <= 0
        if exhausted:
            _TRUNCATED.add(str(path))
            # 예산이 다해도 이 블록의 **직접** 글자는 읽는다 — 무거운 라이브러리 뒤에 놓인
            # 표제란 블록의 REV가 잘려 나갔다 (검토19c N1b). 하위 블록만 건너뛴다
            depth = 1
        try:
            my_name = str(getattr(e.dxf, "name", "") or "")
            for ve in e.virtual_entities():
                budget[0] -= 1
                if budget[0] <= 0 and not exhausted:
                    _TRUNCATED.add(str(path))
                    exhausted = True
                    depth = 1
                if ve.dxftype() == "INSERT":
                    # 자기 자신을 다시 참조하는 블록만 막고 깊이는 넉넉히 — 심볼 라이브러리
                    # (단자대·기기 심볼 안의 하위 블록)는 3단이 흔한데 2단에서 끊어 글자가
                    # 통째로 비교에서 빠졌다 (검토19 감지 ⑤)
                    nm = str(getattr(ve.dxf, "name", "") or "")
                    if nm and nm == my_name:
                        continue
                    if depth - 1 <= 0:
                        continue            # 예산 소진 뒤에는 하위 블록을 열지 않는다
                    expand_insert(ve, depth - 1, where_sp)
                else:
                    take(ve)
        except Exception:
            pass  # 깨진 블록 참조 등 — 블록 하나 때문에 추출을 멈추지 않는다

    if space == "model":
        spaces = [doc.modelspace()]
    else:
        # 탭 순서로 — ezdxf는 배치 사전 순서(AutoCAD 저장본은 이름순)로 돌려, 시트 이름만 바꿔도 둘째 표제란
        # 번호가 밀렸다 (검토36 F 중간 1)
        spaces = sorted((lo for lo in doc.layouts if not lo.is_modelspace),
                        key=lambda lo: int(getattr(lo.dxf, "taborder", 0) or 0))
    for sp in spaces:
        sp_name = "" if space == "model" else str(getattr(sp, "name", "") or "")
        for e in sp:
            if e.dxftype() == "INSERT":
                expand_insert(e, 6, sp_name)
            else:
                take(e)
    attr_rows = _sort_attributes(inserts, out, attr_fields)
    return [t for t in out if t[0]], attr_fields, attr_rows


_CORE_TAGS = {"REV", "DWG_NO", "DATE", "PROJECT"}
_META_TAGS = {"DRAWNBY", "CHECKEDBY", "APPROVEDBY"}


def _sort_attributes(inserts: list[dict], out: list, attr_fields: dict) -> list:
    """삽입마다 모은 속성을 표제란·리비전 행·본문으로 나눈다. 돌려주는 값: 속성 블록 리비전 행.

    - **표제란다운 삽입**: 표의 행처럼 쌓인 것이 아니면서 REV·DWG_NO·DATE·PROJECT 가운데 둘 이상을
      가졌거나, 레이어·블록 이름에 TITLE·표제가 든 것. 첫째는 필드(REV·DATE…), 둘째부터는 번호 붙은 필드
      (REV#2…) — 배치 둘(시트 1·2) 도면에서 시트2의 Rev 올림이 사라지고 거꾸로 'Rev 미갱신'이 났다 (검토36 A N2).
      같은 표제란 블록을 한 공간의 틀 둘에 넣은 도면도 있다 — 여러 번 삽입이라고 다 빼면 표제란을 잃는다
    - **표의 행**: 같은 블록이 같은 x에 글자 높이 몇 배 간격으로 쌓인 것. REV·DATE가 있고 도면번호가 없으면
      개정이력 행으로, 도면번호가 있으면(도면 목록표) 본문 글자로
    - 그 밖(기기 심볼의 NAME·REV, 도면 목록표 행): 본문 글자 — 이름·Rev 변경이 글자로 보인다 (검토36 A N3)
    여섯째 칸 True = 블록 속성 값, 일곱째 칸 = 필드 이름(필드 전용)·'META'(비교 안 함)·None(본문)."""
    groups: dict = {}
    for r in inserts:
        groups.setdefault((r["sp"], r["name"]), []).append(r)
    stacked = set()
    for k, g in groups.items():
        if len(g) < 2:
            continue
        hs = sorted(a[4] for r in g for a in r["attrs"] if a[4] > 0)
        h = hs[len(hs) // 2] if hs else 1.0
        xs = [r["at"][0] for r in g]
        ys = sorted(r["at"][1] for r in g)
        gaps = [b - a for a, b in zip(ys, ys[1:])]
        if max(xs) - min(xs) <= 2 * h and gaps and max(gaps) <= 8 * h:
            stacked.add(k)
    rows: list = []

    def _titleish(r) -> bool:
        key = (r["sp"], r["name"])
        tags = {a[5] for a in r["attrs"]}
        core = {_ATTR_CANON.get(t) for t in tags} & _CORE_TAGS
        named = f"{r['layer']} {r['name']}".upper()
        if key in stacked or len(groups[key]) >= 3:
            # 같은 블록이 한 공간에 셋 이상이면 표제란이 아니다(틀 둘은 허용) — 개정 삼각 마커·참조 풍선이
            # 표제란 자리를 차지해 진짜 표제란이 #3·#4로 밀리고 도면번호·프로젝트를 잃었다 (검토36 F 중간 2)
            return False
        # 핵심 태그가 셋 이상이거나, REV와 도면번호가 같이 있으면 표제란. REV+DATE만(개정 마커·개정표 칸)과
        # 참조 표시(DWG_NO·PROJECT만)는 아니다 (검토36 A A6·F 중간 2).
        # REV 하나뿐이어도 서명·축척 칸이 같이 있으면 표제란이다 — 심볼의 NAME+REV와 가른다
        # TITLE 레이어·이름은 핵심 태그가 하나라도 있을 때만 — TITLE 레이어에 놓인 기기 심볼(TAG·SPEC)이
        # 첫 표제란 자리를 차지해 진짜 표제란이 REV#2가 됐다 (검토35 A D1)
        return (len(core) >= 3 or {"REV", "DWG_NO"} <= core
                or (bool(core) and ("TITLE" in named or "표제" in named))
                or ("REV" in core and any(t in _META_LABELS or t in _META_TAGS for t in tags)))

    titles = [r for r in inserts if _titleish(r)]
    # 도면번호를 가진 표제란이 첫째 — 귀속·도면번호·Rev 검사가 기대는 자리다 (검토36 F 중간 2)
    titles.sort(key=lambda r: not any(_ATTR_CANON.get(a[5]) == "DWG_NO" and a[0] for a in r["attrs"]))
    order = {id(r): i for i, r in enumerate(titles, 1)}
    for r in inserts:
        key = (r["sp"], r["name"])
        tags = {a[5] for a in r["attrs"]}
        core = {_ATTR_CANON.get(t) for t in tags} & _CORE_TAGS
        if id(r) in order:
            n_title = order[id(r)]
            suffix = "" if n_title == 1 else f"#{n_title}"
            # NAME은 같은 블록에 도면명 태그가 따로 없을 때만 도면명 — 있으면 작성자 이름이다 (검토36 A A13)
            has_title = any(_ATTR_CANON.get(t) == "TITLE" and t != "NAME" for t in tags)
            at = f"배치 {r['sp']} " if r["sp"] else ""
            # 번호는 근거 문구에 싣지 않는다 — 배치 안 번호와 파일 전체 번호가 어긋나 보였다 (검토36 F 낮음 5)
            label = "표제란" if n_title == 1 else "다른 표제란"
            for val, x, y, layer, h, tag in r["attrs"]:
                canon = _ATTR_CANON.get(tag)
                if tag == "NAME" and has_title:
                    canon = None
                meta = canon is None and (tag in _META_LABELS or tag in _META_TAGS or tag == "NAME")
                marker = (canon + suffix) if canon else ("META" if meta else None)
                out.append((val, x, y, layer, h, True, marker))
                where = f"{at}{label}(블록 속성 {tag}, x={x:.0f}, y={y:.0f})"
                if canon and val and (canon + suffix) not in attr_fields and val.upper() not in _LABEL_ALIASES:
                    attr_fields[canon + suffix] = (val, where)
                elif meta and val:
                    # 서명·축척은 비교하지 않지만 필드로 남겨 그림 비교가 그 자리의 픽셀 차이를 글자로 알게
                    # (리뷰11 중간-H: 글자 경로만 빼고 그림 경로가 잡아 'Rev 미갱신')
                    attr_fields.setdefault(f"META:{tag}", (val, where))
            continue
        vals = {_ATTR_CANON.get(a[5]): a[0] for a in r["attrs"] if _ATTR_CANON.get(a[5])}
        if key in stacked and {"REV", "DATE"} <= core and "DWG_NO" not in core \
                and vals.get("REV"):
            desc = " ".join(a[0] for a in r["attrs"]
                            if _ATTR_CANON.get(a[5]) not in ("REV", "DATE") and a[0])
            x0, y0 = r["attrs"][0][1], r["attrs"][0][2]
            rows.append(Row(key=vals["REV"], values={"DATE": vals.get("DATE", ""), "DESCRIPTION": desc},
                            where=f"리비전 블록(블록 속성, x={x0:.0f}, y={y0:.0f})"))
            for val, x, y, layer, h, tag in r["attrs"]:
                out.append((val, x, y, layer, h, True, "ROW"))     # 행으로 실었다 — 글줄로 또 싣지 않는다
            continue
        for val, x, y, layer, h, tag in r["attrs"]:
            out.append((val, x, y, layer, h, True, None))
    return rows


def _y_tol(texts) -> float:
    """같은 줄 허용 오차 — 글자 높이의 중앙값. 절대값 3.0은 미터 단위 도면(글자 0.003)에서
    줄 전체를 한 줄로 뭉갰다 (2026-09-04 검토 extract M-3)."""
    hs = sorted(h for t in texts if len(t) > 4 for h in [t[4]] if h and h > 0)
    if not hs:
        return _Y_TOL
    return max(hs[len(hs) // 2], 1e-9)


def _classify(texts):
    """텍스트를 title/revblock/body로 분류. 돌려주는 값: (title, revblock, body,
    위치 규칙으로만 title이 된 항목 집합) — 라벨·값으로 쓰이지 않은 것은 본문으로 돌려보낸다."""
    xs = [t[1] for t in texts]
    ys = [t[2] for t in texts]
    x_hi = min(xs) + (max(xs) - min(xs)) * 0.6 if xs else 0
    y_lo = min(ys) + (max(ys) - min(ys)) * 0.25 if ys else 0
    y_hi = min(ys) + (max(ys) - min(ys)) * 0.75 if ys else 0

    title, revblock, body = [], [], []
    by_position: set = set()
    for item in texts:
        _, x, y, layer = item[:4]
        lu = layer.upper()
        if len(item) > 5 and item[5]:
            if len(item) > 6 and item[6] == "META":
                continue                       # 작성·검토·승인·축척 — 비교 대상이 아니다
            if len(item) > 6 and item[6]:
                title.append(item)             # REV·DATE 같은 표제란 속성 — 필드로만 쓴다
            else:
                body.append(item)              # TITLE 같은 나머지 속성은 본문 글자
        elif "TITLE" in lu:
            title.append(item)
        elif "REV" in lu:
            revblock.append(item)
        elif x >= x_hi and y <= y_lo:
            title.append(item)
            by_position.add(id(item))
        elif x >= x_hi and y >= y_hi:
            revblock.append(item)
        else:
            body.append(item)
    return title, revblock, body, by_position


_INLINE_FIELD = re.compile(
    r"^\s*(DWG[ ._]?NO\.?|DRAWING NO\.?|도면번호|PROJECT|프로젝트|REV(?:ISION)?\.?(?:\s*NO\.?)?|리비전|DATE|일자)"
    r"\s*[:.]?\s+(\S{1,24})\s*$", re.IGNORECASE)
# 값 자리에 또 다른 라벨이 온 것('REV NO', 'REV HISTORY')은 값이 아니다 — pdf.py와 같은 집합.
# 'REV NO' 라벨 하나 때문에 REV='NO'가 되고 진짜 값 B→C가 어디에도 안 남았다 (검토33 C1)
_DXF_LABELISH = {"NO", "NO.", "HISTORY", "DESCRIPTION", "DATE", "NAME", "TITLE", "SHEET",
                 "BLOCK", "RECORD", "이력", "내역", "번호", "일자", "표"}


def _inline_field(text: str):
    """'REV A'·'DWG NO E-101' 꼴에서 (정규 라벨, 값). 값 자리가 또 다른 라벨이면 필드가 아니다."""
    m = _INLINE_FIELD.match(text)
    if not m:
        return None, None
    value = m.group(2).strip()
    if value.upper().rstrip(".") in {v.rstrip(".") for v in _DXF_LABELISH}:
        return None, None
    label = re.sub(r"\s+", " ", m.group(1).upper().strip())
    # 'REV.'·'REV. NO.'처럼 끝에 붙은 점은 별칭 표와 맞추기 전에 걷는다 (검토33 C1)
    return _LABEL_ALIASES.get(label) or _LABEL_ALIASES.get(label.rstrip(".")), value
# 도면명은 여러 낱말('배전반 단선도')이라 따로 — 구분자(: .)가 있을 때만
_INLINE_TITLE = re.compile(
    r"^\s*(DWG[ ._]?TITLE|DRAWING TITLE|TITLE|도면명)\s*[:.]\s*(.{1,60}?)\s*$", re.IGNORECASE)


def _parse_title(title, tol: float = _Y_TOL) -> tuple[dict, set]:
    """(표제란 필드, 라벨·값으로 쓰인 항목 id 집합)."""
    fields: dict[str, Field] = {}
    used_inline: set = set()
    # 'REV A' 'DWG NO E-101'처럼 라벨과 값이 한 글자 덩어리 — PDF 추출기와 같은 규칙
    # (2026-09-06 블라인드 양식 시험 49·50: Rev 변경이 글자 변경으로만 보고됨)
    for item in title:
        canon, value = _inline_field(item[0])
        if canon is None:
            mt = _INLINE_TITLE.match(item[0])
            if not mt:
                continue
            canon, value = _LABEL_ALIASES.get(mt.group(1).upper().strip()), mt.group(2)
        if canon and canon not in fields:
            fields[canon] = Field(canon, value, f"표제란(x={item[1]:.0f}, y={item[2]:.0f})")
            used_inline.add(id(item))
    used: set = set()
    for item in title:
        text, x, y, layer = item[:4]
        canon = _LABEL_ALIASES.get(text.upper())
        if not canon:
            continue
        # 값 = 같은 줄(y 허용 오차 내) 오른쪽에서 가장 가까운 비라벨 텍스트
        candidates = [
            (vx, vtext, id(vitem)) for vitem in title
            for vtext, vx, vy in [vitem[:3]]
            if abs(vy - y) <= tol and vx > x
            and vtext.upper() not in _LABEL_ALIASES
        ]
        used.add(id(item))
        if candidates:
            vx, vtext, vid = min(candidates)
            used.add(vid)
            if canon not in fields:
                fields[canon] = Field(canon, vtext,
                                      f"표제란(레이어 {layer}, x={vx:.0f}, y={y:.0f})")
    return fields, used | used_inline


def _merge_lines(items, tol: float = _Y_TOL) -> list:
    """같은 y의 텍스트 조각을 한 줄로 병합. 위→아래, 왼쪽→오른쪽 순."""
    groups: dict[float, list] = {}
    for item in items:
        text, x, y, layer = item[:4]
        key = next((k for k in groups if abs(k - y) <= tol), y)
        groups.setdefault(key, []).append((x, text, layer))
    lines = []
    for y in sorted(groups, reverse=True):
        parts = sorted(groups[y])
        text = " ".join(p[1] for p in parts)
        layer = parts[0][2]
        # 좌표(y=180)로 도면에서 찾는 사람은 없다 — 레이어만 (2026-09-02 처음 보는 사람 검토)
        lines.append(TextLine(text, f"레이어 {layer}"))
    return lines


_DATE_TOKEN = re.compile(r"\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{6,8}")


def _looks_like_rev_row(tokens: list[str]) -> bool:
    """Rev 행 검증: 첫 토큰이 짧은 개정 코드꼴 + 둘째 토큰이 날짜꼴.
    위치 휴리스틱이 우상단의 일반 텍스트(방 이름·치수)를 리비전으로 오인하는 것 방지
    (실물 도면 테스트에서 확인된 오탐)."""
    return (len(tokens) >= 2 and len(tokens[0]) <= 4 and tokens[0].isalnum()
            and bool(_DATE_TOKEN.search(tokens[1])))


def _parse_revblock(revblock, tol: float = _Y_TOL) -> tuple[list, list]:
    """(리비전 행들, 리비전이 아니어서 본문으로 돌려보낼 항목들)."""
    rows, leftover = [], []
    for line in _merge_lines(revblock, tol):
        tokens = line.text.split()
        if tokens and tokens[0].upper() == "REV":  # 헤더 행
            continue
        if _looks_like_rev_row(tokens):
            rows.append(Row(key=tokens[0],
                            values={"DATE": tokens[1],
                                    "DESCRIPTION": " ".join(tokens[2:])},
                            where=f"리비전 블록({line.where})"))
        else:
            leftover.append(line)
    return rows, leftover


# 표제란의 다른 칸 라벨 — 같은 줄의 글자(검토자 서명·SHEET 수·축척)는 표제란 메타라
# 본문으로 돌려보내지 않는다. 서명 기입은 Rev를 올리지 않는 정상 작업인데 '내용 변경 →
# Rev 미갱신'으로 잡혔다 (2026-09-04 재검토 ②-2)
_META_LABELS = {"DRAWN", "CHECKED", "APPROVED", "DESIGNED", "DRAWN BY", "CHECKED BY",
                "APPROVED BY", "SCALE", "SHEET", "SIZE", "UNIT",
                "작성", "검토", "승인", "설계", "축척", "단위", "용지", "매수"}


def _meta_line_ids(title, tol: float) -> set:
    ys = [it[2] for it in title if it[0].strip().upper().rstrip(":.") in _META_LABELS]
    return {id(it) for it in title if any(abs(it[2] - y) <= tol for y in ys)}


def _extract_space(path: Path, space: str, doc=None):
    texts, attr_fields, attr_rows = _collect_texts(Path(path), space, doc)
    tol = _y_tol(texts)
    if space == "paper":
        # 배치(레이아웃) 공간엔 보통 표제란 글자만 있다 — 위치 규칙을 매기면 그 글자들
        # 사이에서 사분면을 나눠 라벨이 본문으로 갔다 (2026-09-04 재검토 #11). 라벨 짝만
        # 라벨 짝으로 쓰이지 않은 배치공간 글자는 본문이다 — by_pos가 비어 있어 레이아웃 주석이 어디에도
        # 실리지 않았다 (검토21 감지 차단 1: 레이아웃 글자 변경을 "동일"이라 단언)
        title, revblock, body, by_pos = list(texts), [], [], {id(t) for t in texts}
    else:
        title, revblock, body, by_pos = _classify(texts)
    fields, used = _parse_title(title, tol)
    for canon, (val, where) in attr_fields.items():
        fields.setdefault(canon, Field(canon, val, where))
    # 구역(우하단) 밖에 있어도 'REV: A'처럼 라벨과 값이 한 덩이면 표제란 값으로 읽는다.
    #
    # 구역은 **글자들의 좌표 범위**로 잡는데, 본문 글자가 표제란보다 아래에 있으면
    # 표제란이 '아래 25%' 밖으로 밀려 통째로 본문이 됐다 — 그러면 Rev 추적도,
    # 'Rev 미갱신' 검사도 그 도면에서 영영 안 돈다 (2026-09-10 경우의 수 매트릭스에서
    # 재현: 본문 글자 하나를 더했더니 표제란을 못 읽었다). 라벨 규칙(_INLINE_FIELD)은
    # 'REV' + 24자 이하 값 한 개로 좁아서 본문 문장을 잘못 집지 않는다.
    if body:
        leftovers = []
        for item in body:
            canon, value = _inline_field(item[0])
            if canon and canon not in fields:
                fields[canon] = Field(canon, value,
                                      f"표제란 밖(x={item[1]:.0f}, y={item[2]:.0f})")
            else:
                leftovers.append(item)
        body = leftovers
    # 우상단(리비전 블록 사분면)에 놓인 표제란도 같다 — 'DWG NO: E-101'이 거기 있으면
    # 필드가 아니라 글줄로 잡혀 도면번호 변경이 추가/삭제로 나오고 귀속이 폴더로
    # 떨어졌다 (검토19 감지 ⑫). REV는 리비전 표 해석에 맡긴다
    if revblock:
        keep = []
        for item in revblock:
            canon, value = _inline_field(item[0])
            if canon and canon != "REV" and canon not in fields:
                fields[canon] = Field(canon, value,
                                      f"표제란(우상단, x={item[1]:.0f}, y={item[2]:.0f})")
            else:
                keep.append(item)
        revblock[:] = keep
    # 위치 규칙(우하단)으로 표제란이 됐지만 라벨·값으로 쓰이지 않은 글자는 본문이다 —
    # P&ID·배치도의 우하단 사분면은 정상 내용 자리인데 비교에서 통째로 빠졌다
    # (2026-09-04 검토 extract H-1). 단, 다른 표제란 칸(CHECKED·SHEET…) 줄은 제외
    meta_ids = _meta_line_ids(title, tol)
    # 위치 규칙(by_pos)뿐 아니라 **레이어 이름**으로 표제란이 된 글자도 본문으로 돌려보낸다 —
    # 회사명 변경, 한 파일에 놓인 둘째 도면 틀의 REV B→C가 통째로 사라졌다 (검토33 C2)
    # 블록 속성 값(여섯째 칸 True)은 필드 전용 — 본문으로 내보내면 표제란 DATE만 바뀐 일괄 재출력이
    # 장마다 '변경 + 거짓 Rev 미갱신'이 되고, 'Rev만 갱신' 검사가 침묵한다 (검토34 B 차단 2)
    # 필드로 **실제로 쓰인** 속성(태그별 첫 값)과 서명·축척(META)만 본문에서 뺀다. 속성이면 모두 빼던
    # v0.57.15는 모든 글자가 표제란인 배치 공간에서 CLIENT·도면명 2행 같은 속성 변경을 '글자·표·그림
    # 동일'로 접었고, 둘째 도면 틀의 REV 변경도 다시 사라졌다 (검토35 A 차단)
    # 최종(검토35 B): 표준 표제란 태그(REV·DATE·DWG_NO·PROJECT·TITLE — 일곱째 칸 marker)와 서명·축척(META)
    # 속성은 **모두** 빼고, 그 밖의 속성(CLIENT 등, marker 없음)만 본문으로. '필드로 쓰인 첫 값만' 빼면
    # 둘째 틀 DATE가 글줄로 남아 날짜 접기를 넓혀야 했고, 그 확장이 납기일 문서의 날짜 변경까지 '표제란
    # 일자만'으로 접었다. 한 파일 둘째 틀의 독립 REV 변경은 v0.57.13처럼 못 잡는다(알려진 한계)
    body = body + [it for it in title
                   if id(it) not in used and id(it) not in meta_ids
                   and not (len(it) > 6 and it[6])]
    rev_rows, not_rev = _parse_revblock(revblock, tol)
    return texts, fields, rev_rows + attr_rows, _merge_lines(body, tol) + not_rev


def extract(path: Path) -> Document:
    _TRUNCATED.discard(str(path))
    doc = ezdxf.readfile(path)                       # 한 번만 읽고 모델·배치 두 공간에 쓴다
    texts, fields, rev_rows, raw = _extract_space(path, "model", doc)
    notes: list = []
    if str(path) in _TRUNCATED:
        _TRUNCATED.discard(str(path))
        notes.append(f"블록이 너무 깊고 많아 {_EXPAND_BUDGET:,}개까지만 읽었습니다 — 그 너머의 "
                     f"블록 안 글자는 비교하지 못합니다 (심볼 라이브러리를 단순화하거나 문의)")
    # 배치(레이아웃) 공간은 **항상** 읽는다. 모델에 표제란이 있으면 배치는 아예 안 읽어, 레이아웃에
    # 둔 주석·표제란의 글자 변경을 놓치고도 "글자·표·그림 동일"이라 단언했다 (검토21 감지 차단 1).
    # 표제란·리비전 표는 모델 것이 우선, 배치 글줄은 '배치공간' 표시를 달아 본문에 더한다
    try:
        _t2, f2, rows2, raw2 = _extract_space(path, "paper", doc)
    except Exception:
        f2, rows2, raw2 = {}, [], []
    if not fields and f2:
        # 표제란이 배치(레이아웃) 공간에 있는 도면 — 모델 공간만 보면 Rev·도면번호를
        # 못 읽고도 고지가 없었다 (2026-09-04 검토 extract H-5)
        fields = f2
    elif f2:
        # 모델에도 배치에도 표제란이 있으면 배치 것을 버렸다 — 배치의 속성 표제란 REV B→C가 필드에도 글줄에도
        # 남지 않아 '재저장, 확인 대상 아님'으로 접혔다 (검토36 A N2). 모델에 없는 칸은 그대로, 겹치는 칸은
        # 번호를 붙여(REV#2) 싣는다 — 같은 구조의 두 판에서 번호가 같게 매겨진다
        for k, v in f2.items():
            if k.startswith("META:"):
                fields.setdefault(k, v)
                continue
            base = k.split("#", 1)[0]
            key, n = base, 1
            while key in fields:
                n += 1
                key = f"{base}#{n}"
            fields[key] = Field(key, v.value, v.where)
    if not rev_rows:
        rev_rows = rows2
    if raw2:
        raw = list(raw) + [TextLine(t.text, f"배치공간 {t.where}", t.box) for t in raw2 if t.text]
    if texts and not fields:
        notes.append("표제란을 인식하지 못함 — Rev·도면번호 검사에서 제외됩니다 "
                     "(같은 줄에 'REV'·'DWG NO' 라벨과 값이 있거나 블록 속성 태그가 REV·DWG_NO면 인식됩니다)")
    return Document(
        doc_type="dxf",
        path=str(path),
        fields=fields,
        revision_history=rev_rows,
        raw_texts=raw,
        notes=notes,
    )
