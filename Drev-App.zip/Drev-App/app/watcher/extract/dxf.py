# -*- coding: utf-8 -*-
"""DXF 추출기: TEXT/MTEXT/ATTRIB → 표제란·리비전 블록·본문 분류.

식별 휴리스틱 (순서대로):
  1. 레이어 이름에 TITLE 포함 → 표제란 / REV 포함 → 리비전 블록
  2. 레이어 힌트가 없으면 위치로: 우하단(오른쪽 40% × 아래 25%) → 표제란,
     우상단(오른쪽 40% × 위 25%) → 리비전 블록
형상(선·도형)은 읽지 않는다 (PRINCIPLE 7).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import ezdxf

from watcher.extract.base import Document, Field, Row, TextLine

# ezdxf가 시스템 폰트 캐시를 만들며 한글 이름 폰트마다 "cannot open font ..."
# 경고를 쏟아낸다 — 감시 동작과 무관한 소음이라 오류만 남긴다 (2026-08-27 실PC)
logging.getLogger("ezdxf").setLevel(logging.ERROR)

# 표제란 라벨 별칭 → 정규 이름
_LABEL_ALIASES = {
    "DWG_NO": "DWG_NO", "DWG NO": "DWG_NO", "DWG.NO": "DWG_NO",
    "DRAWING NO": "DWG_NO", "도면번호": "DWG_NO",
    "PROJECT": "PROJECT", "PROJ": "PROJECT", "프로젝트": "PROJECT",
    "PROJ NO": "PROJECT", "PROJECT NO": "PROJECT", "프로젝트번호": "PROJECT", "프로젝트 번호": "PROJECT",   # (검토68 A5)
    "REV": "REV", "REVISION": "REV", "리비전": "REV",
    "개정": "REV", "개정번호": "REV", "개정 번호": "REV",     # 한글 표제란 (검토38 R4-B)
    "REV NO": "REV", "REV. NO": "REV", "REV NO.": "REV", "REVISION NO": "REV",   # (검토33 C1)
    "DATE": "DATE", "일자": "DATE",
    "작성일": "DATE",          # 다른 회사 한글 표제란 — PDF _CANON과 같게 (검토71 R3 H-D15)
    # 도면명 — 표제란 메타로 취급해 버리던 것을 필드로. 도면명 변경이 글자 비교에서
    # 통째로 사라졌다 (검토19 2차 브리핑 ②)
    "TITLE": "TITLE", "DWG TITLE": "TITLE", "DWG.TITLE": "TITLE", "DRAWING TITLE": "TITLE",
    "도면명": "TITLE",
}

_Y_TOL = 3.0  # 같은 줄로 볼 y 허용 오차 (도면 단위) — 글자 높이를 알면 그 높이로 대체
_EXPAND_BUDGET = 200_000        # 블록 전개로 읽을 가상 엔티티 총량 상한
_TRUNCATED: set = set()         # 예산에 걸려 끝까지 못 읽은 파일 경로 (extract가 고지 후 지움)

# 표제란 블록의 속성 태그 — 라벨 글자 없이 태그만 있는 블록도 표제란으로 읽는다
_ATTR_TAGS = {"DWG_NO", "DWGNO", "DWG-NO", "DRAWING_NO", "DRAWINGNO", "도면번호",
              "PROJECT", "PROJ", "프로젝트", "REV", "REVISION", "리비전", "DATE", "일자"}
_ATTR_CANON = {"TITLE": "TITLE", "DWG_TITLE": "TITLE", "DWGTITLE": "TITLE", "DRAWING_TITLE": "TITLE",
               "도면명": "TITLE", "TITLE1": "TITLE", "NAME": "TITLE",
               "DWG_NO": "DWG_NO", "DWGNO": "DWG_NO", "DWG-NO": "DWG_NO",
               "DRAWING_NO": "DWG_NO", "DRAWINGNO": "DWG_NO", "도면번호": "DWG_NO",
               "PROJECT": "PROJECT", "PROJ": "PROJECT", "프로젝트": "PROJECT",
               "REV": "REV", "REVISION": "REV", "리비전": "REV", "DATE": "DATE", "일자": "DATE"}


def _label_canon(text: str):
    """표제란 라벨 글자 → 정규 이름(없으면 None). 점 찍은 'DWG. NO.'·'PROJ. NO.'(검토68 A5)와 한·영 겸기
    '도면번호 DWG NO'(표 꼴 표제란, 검토68 A1)도 — 두 쪽이 같은 이름을 가리킬 때만."""
    u = str(text or "").upper().strip()
    c = _LABEL_ALIASES.get(u) or _LABEL_ALIASES.get(u.rstrip(".:： ").strip())
    if c:
        return c
    k = re.sub(r"[\s.]+", " ", u).strip(" :：")
    c = _LABEL_ALIASES.get(k)
    if c or not k:
        return c
    kor = " ".join(re.findall(r"[가-힣]+(?:\s*[가-힣]+)*", k)).strip()
    eng = re.sub(r"\s+", " ", re.sub(r"[가-힣()/]+", " ", k)).strip(" :：")
    if kor and eng:
        ck, ce = _LABEL_ALIASES.get(kor), _LABEL_ALIASES.get(eng)
        if ck and ck == ce:
            return ck
    return None


def _decode(s: str) -> str:
    """DXF의 \\U+XXXX 이스케이프(ANSI 코드페이지로 저장된 한글)를 복원 (2026-09-04 검토). R12~R14 DXF가 아시아 글자를 적는
    MIF 꼴 \\M+cXXXX(c=코드페이지: 3 완성형 등)도 — 풀지 않아 'M-101 \\M+3B8F0\\M+3C5CD 5.5kW'가 그대로 비교·메일에 실리고, 같은
    도면을 R2000 이상으로 다시 저장하면 모든 줄이 '변경'이 됐다 (재검토 2026-10-28 R6-5)."""
    try:
        from ezdxf.lldxf.encoding import decode_dxf_unicode, decode_mif_to_unicode, has_dxf_unicode, has_mif_encoding
        if has_mif_encoding(s):
            s = decode_mif_to_unicode(s)
        return decode_dxf_unicode(s) if has_dxf_unicode(s) else s
    except Exception:
        return s


def _attrib_text(a) -> str:
    """블록 속성(ATTRIB) 값 — 여러 줄 속성(내장 MTEXT)이면 모든 줄을 띄어쓰기로 잇는다. 첫 줄(a.dxf.text)만 읽어 두 줄 도면명의
    둘째 줄 변경을 놓쳤다 (재검토 2026-10-28 R1-8)."""
    txt = None
    try:
        if a.has_embedded_mtext_entity:
            txt = " ".join(x.strip() for x in str(a.plain_mtext() or "").split("\n") if x.strip())
    except Exception:
        txt = None
    if not txt:
        txt = str(a.dxf.text or "")
    return _decode(txt).strip()


# 기하 공차(GDT 글꼴) 기호 글자 → 기호 — '{\Fgdt;j}'의 j는 위치도다
_GDT = {"a": "∠", "b": "⟂", "c": "⏥", "d": "⌓", "e": "○", "f": "∥", "g": "⌭", "h": "↗", "i": "⌯", "j": "⌖",
        "k": "⌒", "l": "Ⓛ", "m": "Ⓜ", "n": "Ø", "p": "Ⓟ", "r": "◎", "s": "Ⓢ", "t": "⌰", "u": "⏤"}


def _tolerance_text(content) -> str:
    """TOLERANCE 내용 코드 → 읽을 글자: 칸 나눔 '%%v'는 ' | ', 둘째 줄 '^J'는 ' / ', GDT 기호는 기호 글자."""
    from ezdxf.tools.text import plain_mtext
    s = re.sub(r"\{\\Fgdt;([^}]*)\}", lambda m: "".join(_GDT.get(c, c) for c in m.group(1)), str(content or ""))
    rows = []
    for line in s.split("^J"):
        cells = [" ".join(plain_mtext(c).split()) for c in re.split(r"%%[vV]", line)]
        cells = [c for c in cells if c]
        if cells:
            rows.append(" | ".join(cells))
    return _decode(" / ".join(rows)).strip()


class _Item(tuple):
    """글자 항목 튜플 + 왼쪽 끝 x(left)·첫 줄 가운데 높이(cy). MTEXT는 삽입점이 오른쪽·가운데일 수 있다 — 구역 나누기는 왼쪽
    끝으로. 위 맞춤 MTEXT의 삽입점은 글자 **윗변**이라 바탕선인 TEXT와 상자를 견줄 때 첫 줄 가운데를 쓴다 (_same_line)."""
    left: float
    cy: float


def _mtext_left(e, txt: str, x: float, h: float) -> float:
    """MTEXT 글자 덩이의 왼쪽 끝 x. 오른쪽 위 맞춤(삽입점 3·6·9) 주기는 삽입점이 덩이의 **오른쪽** 끝이라, 삽입점으로
    구역을 나누면 글자들의 x 범위가 표제란 쪽으로 좁아져 표제란 라벨이 '본문'이 되고 표제란을 통째로 못 읽었다
    (held69 D05 — Rev 검사가 꺼짐). 폭은 지정 폭과 글자 수 어림(글자 높이 × 0.6) 중 작은 것. 돌린 덩이는 삽입점 그대로."""
    try:
        ap = int(e.dxf.get("attachment_point", 1) or 1)
        col = (ap - 1) % 3                       # 0 왼쪽 · 1 가운데 · 2 오른쪽
        if not col or abs(float(e.dxf.get("rotation", 0) or 0)) > 1e-6:
            return x
        d = e.dxf.get("text_direction", None)
        if d is not None and (abs(float(d[1])) > 1e-6 or float(d[0]) < 0):
            return x
        est = max((len(s) for s in txt.split("\n")), default=0) * h * 0.6
        w = float(e.dxf.get("width", 0) or 0)
        w = min(w, est) if w > 0 else est
        return x - w * col / 2
    except Exception:
        return x


def _lx(item) -> float:
    return getattr(item, "left", item[1])


def wcs_insert(e):
    """TEXT·ATTRIB·ATTDEF 삽입점의 세계 좌표. 이 글자들의 삽입점은 OCS(돌출 방향 기준) 좌표라, 거울 삽입(xscale=-1)·돌출 -Z
    글자는 x 부호가 반대로 읽혔다 — 같은 카드에서 글자 근거는 x=-340, 그림 근거는 (340, 42)였고 표제란 틀을 못 찾았다
    (검토20 r03 5). 돌출이 +Z면 그대로. 추출기의 라벨·값 짝짓기는 OCS 좌표로 한다(거울 글자는 OCS에서 왼→오른쪽으로 읽힌다) —
    세계 좌표는 근거 위치·표제란 틀에만 쓴다 (_MIRRORED)."""
    p = e.dxf.insert
    try:
        ex = e.dxf.get("extrusion", None)
        if ex is not None and (abs(float(ex[0])) > 1e-9 or abs(float(ex[1])) > 1e-9 or float(ex[2]) < 0):
            return e.ocs().to_wcs(p)
    except Exception:
        pass
    return p


def const_attdefs(doc, ins, have_tags=()) -> list:
    """블록 정의의 상수 속성(ATTDEF CONSTANT) 글자를 이 삽입 자리로 — [(글자, x, y, 레이어, 높이, 회전각, 세계 x, 세계 y)]
    (x·y는 다른 글자처럼 OCS 좌표).
    AutoCAD는 상수 속성을 삽입에 ATTRIB 없이 ATTDEF 값으로 그리는데, ezdxf 블록 전개(virtual_entities)는 ATTDEF를 내지 않아
    회사명·양식번호를 바꿔도 '글자·표·그림 동일'이었다 (검토20 r03 2). 숨김 속성·삽입에 같은 태그 ATTRIB가 있는 것은 뺀다."""
    if doc is None:
        return []
    try:
        name = str(getattr(ins.dxf, "name", "") or "")
        blk = doc.blocks.get(name) if name else None
    except Exception:
        return []
    if blk is None:
        return []
    out = []
    try:
        defs = [a for a in blk.query("ATTDEF") if a.is_const and not a.is_invisible]
    except Exception:
        return []
    if not defs:
        return out
    try:
        m = ins.matrix44()
    except Exception:
        return out
    for ad in defs:
        tag = str(getattr(ad.dxf, "tag", "") or "").strip().upper()
        if tag and tag in have_tags:
            continue
        try:
            v = _attrib_text(ad)
            if not v:
                continue
            c = ad.copy()
            c.transform(m)
            o, p = c.dxf.insert, wcs_insert(c)
            out.append((v, float(o.x), float(o.y), str(c.dxf.layer), float(c.dxf.height or 0),
                        float(c.dxf.get("rotation", 0) or 0), float(p.x), float(p.y)))
        except Exception:
            continue
    return out


def dim_measure_text(e, m) -> str:
    """치수 실측값을 도면에 보이는 자리수로 — 치수 스타일(덮어쓰기 포함)의 소수 자리(dimdec, 각도는 dimadec)·반올림(dimrnd).
    f'{m:g}'로 적어 dimdec=0 도면에 안 보이는 소수(125.004→125.006)가 '치수 변경'·거짓 'Rev 미갱신'이 됐다 (검토20 r03 6).
    끝자리 0은 예전처럼 지운다(같은 값이 '125'·'125.00'으로 갈리지 않게). 스타일을 모르면 소수 2자리."""
    try:
        m = float(m)
    except (TypeError, ValueError):
        return ""
    dec, rnd = 2, 0.0
    try:
        ov = e.override()
        angular = (int(e.dxf.get("dimtype", 0) or 0) & 0x0F) in (2, 5)
        d_ = ov.get("dimadec" if angular else "dimdec", None)
        if d_ is not None and int(d_) >= 0:
            dec = min(int(d_), 8)
        r_ = ov.get("dimrnd", None)
        rnd = float(r_ or 0.0) if not angular else 0.0
    except Exception:
        pass
    if rnd > 0:
        m = round(m / rnd) * rnd
    s = f"{round(m, dec):.{dec}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


_MIRRORED: dict = {}            # 파일 → {(OCS x, y 반올림): 세계 x} — 거울 글자 근거 위치를 세계 좌표로 (extract가 쓰고 지움)
_ROTATED: dict = {}             # 글자 회전을 되돌려 읽은 파일 → 되돌린 각 (extract가 표제란 틀 범위를 원래 좌표로 돌리고 지움)


def _rot_xy(x: float, y: float, theta: float) -> tuple:
    """(x, y)를 원점 둘레로 -theta도 돌린다 — theta도 돌아간 글자를 가로로 되돌린 좌표."""
    import math
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return (x * c + y * s, -x * s + y * c)


def _unrotate(out: list, inserts: list, rots: list) -> tuple:
    """도면 전체를 돌린 판(글자 대부분이 같은 각으로 누움)이면 글자·속성 좌표를 그 각만큼 되돌린다 → (글자, 삽입, 되돌린 각 또는 0).

    줄 묶기·표제란 구역·라벨-값 짝이 모두 가로 글자의 y·x를 전제한다 — 90°·180°·임의 각으로 돌린 도면은 한 줄 글자가 세로로
    흩어져 필드가 통째로 사라지고 거짓 글자 변경 수십 개가 났다(뒤흔들기 DXF C1, 2026-10-23). 글자 회전각의 최빈값(0.5° 단위)이
    글자의 60% 이상이고 0°가 아닐 때만 — 세로 라벨 몇 개(90°)가 있는 보통 도면은 그대로다."""
    n = len(rots)
    if n < 3:
        return out, inserts, 0.0
    hist: dict = {}
    for r in rots:
        k = round((float(r) % 360.0) * 2) / 2 % 360.0
        hist[k] = hist.get(k, 0) + 1
    mode, cnt = max(hist.items(), key=lambda kv: kv[1])
    if cnt < 0.6 * n or min(mode, 360.0 - mode) <= 1.0:
        return out, inserts, 0.0
    theta = mode

    def _t(it):
        x, y = _rot_xy(float(it[1]), float(it[2]), theta)
        new = type(it)((it[0], x, y) + tuple(it[3:])) if not isinstance(it, _Item) else _Item((it[0], x, y) + tuple(it[3:]))
        if isinstance(it, _Item):
            new.left = x
            new.cy = y - (float(it[2]) - getattr(it, "cy", float(it[2])))
        return new
    out2 = [_t(it) for it in out]
    for r in inserts:
        r["attrs"] = [(a[0],) + _rot_xy(float(a[1]), float(a[2]), theta) + tuple(a[3:]) for a in r["attrs"]]
        r["at"] = _rot_xy(float(r["at"][0]), float(r["at"][1]), theta)
    return out2, inserts, theta


def _collect_texts(path: Path, space: str = "model", doc=None, layout=None) -> tuple[list, dict, list]:
    """((text, x, y, layer, height) 목록, 속성 태그로 읽은 표제란 값 {정규명: (값, 어디)}, 속성 블록 리비전 행).
    TEXT/MTEXT/ATTRIB + 블록(INSERT) 내부 텍스트.

    실무 도면은 표제란을 블록으로 삽입하는 경우가 많다 — virtual_entities()로
    삽입 위치·배율이 반영된 좌표의 내부 텍스트까지 읽는다 (실물 테스트에서 확인된 격차).
    space='paper'면 배치(레이아웃) 공간 — 표제란이 거기 있는 도면용 (2026-09-04 검토).
    """
    out, inserts = _unrotate(*_collect_raw(path, space, doc, layout))[:2]
    attr_fields: dict = {}
    attr_rows = _sort_attributes(inserts, out, attr_fields)
    return [t for t in out if t[0]], attr_fields, attr_rows


def _collect_raw(path: Path, space: str = "model", doc=None, layout=None) -> tuple[list, list, list]:
    """(글자 항목 목록, 속성 가진 블록 삽입 목록, 글자 회전각 목록) — 속성은 아직 표제란·행·본문으로 나누지 않은 채."""
    if doc is None:
        doc = ezdxf.readfile(path)
    out = []
    rots: list = []                 # TEXT·MTEXT·속성 글자의 회전각(도) — 도면 전체를 돌린 판을 되돌려 읽으려고
    # 블록 전개 예산 — 6단 전개는 심볼 라이브러리에서 지수로 는다(500 인서트×6단 = 170초,
    # 검토19 2차 감지 N1). 상한을 넘으면 거기서 멈추고 extract()가 고지한다
    budget = [_EXPAND_BUDGET]
    mirrored = _MIRRORED.setdefault(str(path), {})

    def _mirror_note(e, p) -> None:
        # 거울·돌출 -Z 글자의 OCS 자리 → 세계 x (근거 위치·표제란 틀용, 검토20 r03 5)
        try:
            w = wcs_insert(e)
            if abs(float(w[0]) - float(p[0])) > 1e-6:
                mirrored[(round(float(p[0])), round(float(p[1])))] = float(w[0])
        except Exception:
            pass

    def take(e) -> None:
        budget[0] -= 1
        t = e.dxftype()
        if t == "TEXT":
            p = e.dxf.insert
            _mirror_note(e, p)
            # %%c %%d %%p %%u 같은 제어 코드를 풀어 MTEXT와 같은 꼴로 — 'Ø25'가 TEXT면 '%%C25'로 보였다 (검토61 T07·T57)
            try:
                txt = e.plain_text()
            except Exception:
                txt = e.dxf.text
            out.append((_decode(txt).strip(), p.x, p.y, e.dxf.layer,
                        float(e.dxf.height or 0)))
            rots.append(float(e.dxf.get("rotation", 0) or 0))
        elif t == "MTEXT":
            p = e.dxf.insert
            raw = str(e.text or "")
            if "\\S" in raw and "^" in raw:
                # 공차 쌓기 '\S+0.1^ -0.1;'가 '+0.1^-0.1'로 남았다 — 위/아래를 '/'로 (검토61 T56). 한쪽이 빈 쌓기는 위첨자·
                # 아래첨자다 — '100m\S3^;'가 '100m3/'가 되어 같은 뜻의 TEXT '100m3'과 '변경'이 됐다 (재검토 2026-10-28 R6-11)
                from ezdxf.tools.text import plain_mtext

                def _stack(m) -> str:
                    up, low = m.group(1), m.group(2)
                    if not low.strip():
                        return up
                    if not up.strip():
                        return low
                    return f"\\S{up}/{low};"
                txt = plain_mtext(re.sub(r"\\S([^;^]*)\^ ?([^;]*);", _stack, raw))
            else:
                txt = e.plain_text()
            # 평문 풀기가 남기는 코드 — 붙임 빈칸 '\~', 밑줄·윗줄 켜기 '%%u'·'%%o', 퍼센트 '%%%'. TEXT는 풀리는데 MTEXT만 남아
            # 같은 뜻의 두 판이 '변경'이 됐다 (재검토 2026-10-28 R6-11)
            if "\\~" in txt or "%%" in txt:
                txt = re.sub(r"%%[uUoO]", "", re.sub(r"%%%", "%", re.sub(r"\\~", " ", txt)))
            txt = _decode(txt).strip()
            hgt = float(e.dxf.char_height or 0)
            item = _Item((txt, p.x, p.y, e.dxf.layer, hgt))
            item.left = _mtext_left(e, txt, float(p.x), hgt)
            try:
                _row = (int(e.dxf.get("attachment_point", 1) or 1) - 1) // 3      # 0 위 · 1 가운데 · 2 아래 맞춤
            except Exception:
                _row = 0
            item.cy = float(p.y) - hgt / 2 if _row == 0 else (float(p.y) if _row == 1 else float(p.y) + hgt / 2)
            out.append(item)
            try:
                rots.append(float(e.get_rotation()))
            except Exception:
                rots.append(float(e.dxf.get("rotation", 0) or 0))
        elif t == "ACAD_TABLE":
            # AutoCAD 표 엔티티의 칸 글자 — 통째로 버려져 표 칸 값 변경이 '그림 변경'으로만 보였다 (검토61 T58)
            try:
                for ve in e.virtual_entities():
                    if ve.dxftype() in ("TEXT", "MTEXT"):
                        take(ve)
            except Exception:
                pass
        elif t == "DIMENSION":
            # 치수 문자 — 덮어쓴 값('125')이 있으면 그것, 없으면 실측값. 치수만 고친 개정을
            # 잡기 위해 (2026-09-06 블라인드 2차 48·50)
            try:
                txt = str(e.dxf.text or "").strip()
                if txt in ("", "<>") or "<>" in txt:
                    # 접두·접미가 붙은 '<> TYP'·'2x<>'·'(<>)'·'%%c<>'도 실측값으로 — '<>'만 치환해 실측이 바뀌어도 글자 비교가 침묵하고
                    # 근거에 '<>'가 그대로 남았다 (검토20 r03 3). 실측을 못 읽으면 덮어쓴 글자 그대로
                    m = e.get_measurement()
                    mv = dim_measure_text(e, m) if isinstance(m, (int, float)) else ""
                    if txt in ("", "<>"):
                        txt = mv
                    elif mv:
                        txt = mv.join(txt.split("<>"))
                    if "%%" in txt:
                        txt = re.sub(r"%%[cC]", "Ø", re.sub(r"%%[dD]", "°", re.sub(r"%%[pP]", "±", txt)))
                p = e.dxf.text_midpoint if e.dxf.hasattr("text_midpoint") else e.dxf.defpoint
                if txt:
                    out.append((f"치수 {txt}", p.x, p.y, e.dxf.layer, 0.0))
            except Exception:
                pass
        elif t in ("MULTILEADER", "MLEADER"):
            # 다중 지시선의 글자('SEE NOTE 4')·풍선 블록 속성(번호 '17') — 읽지 않아 그 값만 고친 판이 글자 근거 없이 그림 변경
            # 사진만 남았다 (재검토 2026-10-28 R1-1). 글자는 MTEXT처럼, 블록 속성 값은 그 자리 본문 글자로
            try:
                for ve in e.virtual_entities():
                    vt = ve.dxftype()
                    if vt in ("TEXT", "MTEXT"):
                        take(ve)
                    elif vt == "INSERT":
                        for a in getattr(ve, "attribs", None) or []:
                            v = _attrib_text(a)
                            if v:
                                ap = a.dxf.insert
                                _mirror_note(a, ap)
                                out.append((v, ap.x, ap.y, e.dxf.layer, float(a.dxf.height or 0)))
                                rots.append(float(a.dxf.get("rotation", 0) or 0))
            except Exception:
                pass
        elif t == "TOLERANCE":
            # 기하 공차 틀의 내용(위치도 0.05 | A) — 그림 비교만 남아 공차 값 변경이 글자로 안 보였다 (재검토 2026-10-28 R1-7)
            try:
                txt = _tolerance_text(e.dxf.get("content", ""))
                if txt:
                    p = e.dxf.insert
                    out.append((f"공차 {txt}", p.x, p.y, e.dxf.layer, 0.0))
            except Exception:
                pass

    # 블록 삽입마다 속성을 모아 두고, 다 읽은 뒤 **어느 삽입이 표제란인지** 정한다 — 태그 이름만 보고
    # 정하면 기기 심볼의 NAME·REV, 도면 목록표 행의 REV·DATE가 모두 '표제란 속성'이 되어 비교에서
    # 통째로 사라지고 필드까지 차지했다 (검토36 A N3·N4)
    inserts: list[dict] = []

    def expand_insert(e, depth: int, where_sp: str) -> None:
        attrs = []
        for a in e.attribs:
            p = a.dxf.insert
            _mirror_note(a, p)
            tag = str(getattr(a.dxf, "tag", "") or "").strip().upper()
            attrs.append((_attrib_text(a), p.x, p.y, a.dxf.layer, float(a.dxf.height or 0), tag))
            rots.append(float(a.dxf.get("rotation", 0) or 0))
        for c in const_attdefs(doc, e, {a[5] for a in attrs}):
            out.append(c[:5])                   # 상수 속성 글자는 블록 안 글자처럼 본문으로 (검토20 r03 2)
            rots.append(c[5])
            if abs(c[1] - c[6]) > 1e-6:
                mirrored[(round(c[1]), round(c[2]))] = c[6]
        rec = None
        if attrs:
            try:
                ip = e.dxf.insert
                at_xy = (float(ip.x), float(ip.y))
            except Exception:
                at_xy = (attrs[0][1], attrs[0][2])
            rec = {"sp": where_sp, "name": str(getattr(e.dxf, "name", "") or ""),
                   "layer": str(getattr(e.dxf, "layer", "") or ""), "attrs": attrs, "at": at_xy, "ntext": 0}
            inserts.append(rec)
        if depth <= 0:
            return
        exhausted = budget[0] <= 0
        if exhausted:
            _TRUNCATED.add(str(path))
            # 예산이 다해도 이 블록의 **직접** 글자는 읽는다 — 무거운 라이브러리 뒤에 놓인
            # 표제란 블록의 REV가 잘려 나갔다 (검토19c N1b). 하위 블록만 건너뛴다
            depth = 1
        try:
            my_name = str(getattr(e.dxf, "name", "") or "")
            for ve in e.virtual_entities():
                budget[0] -= 1
                if budget[0] <= 0 and not exhausted:
                    _TRUNCATED.add(str(path))
                    exhausted = True
                    depth = 1
                if ve.dxftype() == "INSERT":
                    # 자기 자신을 다시 참조하는 블록만 막고 깊이는 넉넉히 — 심볼 라이브러리
                    # (단자대·기기 심볼 안의 하위 블록)는 3단이 흔한데 2단에서 끊어 글자가
                    # 통째로 비교에서 빠졌다 (검토19 감지 ⑤)
                    nm = str(getattr(ve.dxf, "name", "") or "")
                    if nm and nm == my_name:
                        continue
                    if depth - 1 <= 0:
                        continue            # 예산 소진 뒤에는 하위 블록을 열지 않는다
                    expand_insert(ve, depth - 1, where_sp)
                else:
                    if rec is not None and ve.dxftype() in ("TEXT", "MTEXT"):
                        rec["ntext"] += 1           # 블록 안 라벨 글자 — 표제란과 개정 마커를 가른다
                    take(ve)
        except Exception:
            pass  # 깨진 블록 참조 등 — 블록 하나 때문에 추출을 멈추지 않는다

    if layout is not None:
        spaces = [layout]                  # 배치 하나만 (검토38 R4-A)
    elif space == "model":
        spaces = [doc.modelspace()]
    else:
        # 탭 순서로 — ezdxf는 배치 사전 순서(AutoCAD 저장본은 이름순)로 돌려, 시트 이름만 바꿔도 둘째 표제란
        # 번호가 밀렸다 (검토36 F 중간 1)
        spaces = sorted((lo for lo in doc.layouts if not lo.is_modelspace),
                        key=lambda lo: int(getattr(lo.dxf, "taborder", 0) or 0))
    for sp in spaces:
        sp_name = "" if space == "model" else str(getattr(sp, "name", "") or "")
        for e in sp:
            if e.dxftype() == "INSERT":
                expand_insert(e, 6, sp_name)
            else:
                take(e)
    return out, inserts, rots


_CORE_TAGS = {"REV", "DWG_NO", "DATE", "PROJECT"}
# 기기 심볼·일람표의 칸 이름(**그대로 일치**) — 부분 일치로 두니 'DEPARTMENT'·'MODEL' 칸이 있는 표제란까지
# 본문으로 떨어졌다 (검토38 R5 중간 1). 표제란 판별에는 태그 칸만, 개정 행 판별에는 전부 쓴다
_TAG_TAGS = {"TAG", "TAG_NO", "TAGNO", "TAG-NO", "TAG NO", "기기번호", "태그"}
_SCHED_TAGS = _TAG_TAGS | {"SPEC", "SPECIFICATION", "QTY", "QUANTITY", "KW", "RATING", "MODEL_NO",
                           "사양", "규격", "수량", "품명", "용량"}
_META_TAGS = {"DRAWNBY", "CHECKEDBY", "APPROVEDBY"}
# 개정 행의 설명 칸 태그 (검토68 A6)
_DESC_TAGS = {"DESC", "DESC.", "DESCR", "DESCRIPTION", "REMARK", "REMARKS", "내용", "개정내용", "변경내용",
              "사유", "개정사유"}


def _sort_attributes(inserts: list[dict], out: list, attr_fields: dict) -> list:
    """삽입마다 모은 속성을 표제란·리비전 행·본문으로 나눈다. 돌려주는 값: 속성 블록 리비전 행.

    - **표제란다운 삽입**: 표의 행처럼 쌓인 것이 아니면서 REV·DWG_NO·DATE·PROJECT 가운데 둘 이상을
      가졌거나, 레이어·블록 이름에 TITLE·표제가 든 것. 첫째는 필드(REV·DATE…), 둘째부터는 번호 붙은 필드
      (REV#2…) — 배치 둘(시트 1·2) 도면에서 시트2의 Rev 올림이 사라지고 거꾸로 'Rev 미갱신'이 났다 (검토36 A N2).
      같은 표제란 블록을 한 공간의 틀 둘에 넣은 도면도 있다 — 여러 번 삽입이라고 다 빼면 표제란을 잃는다
    - **표의 행**: 같은 블록이 같은 x에 글자 높이 몇 배 간격으로 쌓인 것. REV·DATE가 있고 도면번호가 없으면
      개정이력 행으로, 도면번호가 있으면(도면 목록표) 본문 글자로
    - 그 밖(기기 심볼의 NAME·REV, 도면 목록표 행): 본문 글자 — 이름·Rev 변경이 글자로 보인다 (검토36 A N3)
    여섯째 칸 True = 블록 속성 값, 일곱째 칸 = 필드 이름(필드 전용)·'META'(비교 안 함)·None(본문)."""
    groups: dict = {}
    for r in inserts:
        groups.setdefault((r["sp"], r["name"]), []).append(r)
    stacked = set()
    for k, g in groups.items():
        if len(g) < 2:
            continue
        hs = sorted(a[4] for r in g for a in r["attrs"] if a[4] > 0)
        h = hs[len(hs) // 2] if hs else 1.0
        xs = [r["at"][0] for r in g]
        ys = sorted(r["at"][1] for r in g)
        gaps = [b - a for a, b in zip(ys, ys[1:])]
        # 간격 0(같은 자리에 두 번 삽입된 표제란)은 행이 아니다 — 표제란을 통째로 잃었다 (검토38 R5 중간 3)
        if max(xs) - min(xs) <= 2 * h and gaps and max(gaps) <= 8 * h and min(gaps) > 0.5 * h:
            stacked.add(k)
    rows: list = []

    def _titleish(r) -> bool:
        key = (r["sp"], r["name"])
        if key in stacked:
            return False
        tags = {a[5] for a in r["attrs"]}
        core = {_ATTR_CANON.get(t) for t in tags} & _CORE_TAGS
        named = f"{r['layer']} {r['name']}".upper()
        n = len(groups[key])
        has_meta = any(t in _META_LABELS or t in _META_TAGS for t in tags)
        has_title = any(_ATTR_CANON.get(t) == "TITLE" and t != "NAME" for t in tags)
        # 표제란다운 **꼴**: 핵심 태그 셋 이상 / REV+도면번호 / REV에 도면명·서명·축척 칸이 딸림 /
        # TITLE 레이어·이름이면서 핵심 태그. 도면번호가 블록 안 글자라 속성이 TITLE·REV·DATE뿐인 표제란도
        # 있다 — REV+DATE를 모두 빼니 그런 도면의 Rev·일자 필드가 사라졌다 (검토37 A 중간 3)
        # 기기 심볼·일람표 칸(TAG·SPEC…)이 있으면 핵심 태그 셋 이상이 아닌 한 표제란이 아니다 — TAG·TITLE·REV
        # 심볼이 표제란 자리를 차지했다 (검토38 R1 중간 1)
        if len(core) < 3 and tags & _TAG_TAGS:
            return False
        full = (len(core) >= 3 or {"REV", "DWG_NO"} <= core
                or ("REV" in core and (has_meta or has_title))
                or (bool(core) and ("TITLE" in named or "표제" in named)))
        if full:
            # 같은 틀이 셋 이상(부품도 틀 3~6개)도 표제란이다 — 셋 이상이면 모두 빼서 표제란을 통째로 잃었다
            # (검토37 A 중간 2). 다만 셋 이상은 핵심 태그 셋 이상일 때만 — 참조 풍선(DWG_NO·REV·SHEET)·참조 목록
            # (DWG_NO·TITLE·REV) 넷이 표제란 #1~#4를 차지해 진짜 표제란이 #5로 밀렸다 (검토38 R1 중간 1)
            return n < 3 or len(core) >= 3 or ((has_meta or has_title) and r.get("ntext", 0) >= 2)
        # REV+DATE 둘뿐: 한 번만 삽입됐고 블록 안에 라벨 글자가 있을 때만 표제란 — 개정 삼각 마커 하나·개정표
        # 첫 행(글자 없음)이 '다른 표제란'이 됐다 (검토38 R1 중간 6, 검토36 F 중간 2)
        return {"REV", "DATE"} <= core and n == 1 and r.get("ntext", 0) >= 2

    titles = [r for r in inserts if _titleish(r)]
    # 도면번호를 가진 표제란이 첫째 — 귀속·도면번호·Rev 검사가 기대는 자리다 (검토36 F 중간 2)
    titles.sort(key=lambda r: not any(_ATTR_CANON.get(a[5]) == "DWG_NO" and a[0] for a in r["attrs"]))
    order = {id(r): i for i, r in enumerate(titles, 1)}
    for r in inserts:
        key = (r["sp"], r["name"])
        tags = {a[5] for a in r["attrs"]}
        core = {_ATTR_CANON.get(t) for t in tags} & _CORE_TAGS
        if id(r) in order:
            n_title = order[id(r)]
            suffix = "" if n_title == 1 else f"#{n_title}"
            # NAME은 같은 블록에 도면명 태그가 따로 없을 때만 도면명 — 있으면 작성자 이름이다 (검토36 A A13)
            has_title = any(_ATTR_CANON.get(t) == "TITLE" and t != "NAME" for t in tags)
            at = f"배치 {r['sp']} " if r["sp"] else ""
            # 번호는 근거 문구에 싣지 않는다 — 배치 안 번호와 파일 전체 번호가 어긋나 보였다 (검토36 F 낮음 5)
            label = "표제란" if n_title == 1 else "다른 표제란"
            for val, x, y, layer, h, tag in r["attrs"]:
                canon = _ATTR_CANON.get(tag)
                if tag == "NAME" and has_title:
                    canon = None
                meta = canon is None and (tag in _META_LABELS or tag in _META_TAGS or tag == "NAME")
                marker = (canon + suffix) if canon else ("META" if meta else None)
                out.append((val, x, y, layer, h, True, marker))
                where = f"{at}{label}(블록 속성 {tag}, x={x:.0f}, y={y:.0f})"
                if canon and val and (canon + suffix) not in attr_fields and val.upper() not in _LABEL_ALIASES:
                    attr_fields[canon + suffix] = (val, where)
                elif meta and val:
                    # 서명·축척은 비교하지 않지만 필드로 남겨 그림 비교가 그 자리의 픽셀 차이를 글자로 알게
                    # (리뷰11 중간-H: 글자 경로만 빼고 그림 경로가 잡아 'Rev 미갱신')
                    attr_fields.setdefault(f"META:{tag}", (val, where))
            continue
        vals = {_ATTR_CANON.get(a[5]): a[0] for a in r["attrs"] if _ATTR_CANON.get(a[5])}
        # 개정이력 행은 REV·DATE와 **설명·서명 칸**뿐이다 — TAG·SPEC 같은 칸이 있으면 기기 일람표 행이다.
        # 일람표를 개정 행으로 보면 태그·사양이 본문에서 사라져 도면 간·BOM 불일치 검사가 그 도면에서 꺼졌다
        # (검토37 A 중간 4)
        # 허용 목록을 닫아 두니 ASME 개정표(REV·ZONE·DESCRIPTION·DATE·APPROVED)가 개정 행이 아니게 됐다
        # (검토38 R1 중간 2) — 일람표 칸이 **있을 때만** 뒤집는다
        revrow_like = not (tags & _SCHED_TAGS)
        # 한 행뿐인 개정 행 블록(REV·DATE·설명 칸)도 행이다 — 1행일 때는 글줄, 2행이 되자 행이 되어 '행 A·B 추가 +
        # 글줄 삭제'로 거짓 보고했다 (검토68 A6). 설명 칸이 있을 때만(개정 삼각 마커는 설명 칸이 없다)
        single_row = len(groups[key]) == 1 and bool(tags & _DESC_TAGS)
        if (key in stacked or single_row) and {"REV", "DATE"} <= core and "DWG_NO" not in core \
                and vals.get("REV") and revrow_like:
            desc = " ".join(a[0] for a in r["attrs"]
                            if _ATTR_CANON.get(a[5]) not in ("REV", "DATE") and a[0])
            x0, y0 = r["attrs"][0][1], r["attrs"][0][2]
            rows.append(Row(key=vals["REV"], values={"DATE": vals.get("DATE", ""), "DESCRIPTION": desc},
                            where=f"리비전 블록(블록 속성, x={x0:.0f}, y={y0:.0f})"))
            for val, x, y, layer, h, tag in r["attrs"]:
                out.append((val, x, y, layer, h, True, "ROW"))     # 행으로 실었다 — 글줄로 또 싣지 않는다
            continue
        for val, x, y, layer, h, tag in r["attrs"]:
            out.append((val, x, y, layer, h, True, None))
    return rows


def _y_tol(texts) -> float:
    """같은 줄 허용 오차 — 글자 높이의 중앙값. 절대값 3.0은 미터 단위 도면(글자 0.003)에서
    줄 전체를 한 줄로 뭉갰다 (2026-09-04 검토 extract M-3)."""
    hs = sorted(h for t in texts if len(t) > 4 for h in [t[4]] if h and h > 0)
    if not hs:
        return _Y_TOL
    return max(hs[len(hs) // 2], 1e-9)


_ZONE_CANONS = {"DWG_NO", "REV", "DATE", "PROJECT", "TITLE"}


def _text_w(item) -> float:
    """글자 덩이 폭 어림 — 한 줄에서 가장 긴 줄, 한글·한자는 글자 높이, 그 밖은 0.6배."""
    h = float(item[4]) if len(item) > 4 and item[4] else 0.0
    return max((sum(1.0 if ord(c) > 0x2E80 else 0.6 for c in s) for s in str(item[0]).split("\n")), default=0.0) * h


def _label_zone(texts, rects, x_hi: float, y_lo: float):
    """레이어·위치 규칙 밖에 놓인 표제란을 **라벨 밀도**로 찾은 범위 (x0, y0, x1, y1) — 없으면 None.

    TITLE 레이어가 아닌 글자 표제란(레이어 0·회사 레이어 'TB'·'A-ANNO-TTLB')을 왼쪽 아래·오른쪽 위·가운데로 옮기면 위치 규칙
    (오른쪽 40% × 아래 25%)이 버려 도면번호·REV·일자가 통째로 사라졌다(뒤흔들기 DXF C3, 2026-10-23 — 세로 시트의 왼쪽 아래 표제란은
    흔하다). 표제란 라벨(도면번호·REV·일자·프로젝트·도면명, '라벨: 값' 한 덩이 포함)이 가까이 모인 덩이 가운데 도면번호를 품고
    라벨 셋 이상인 것을 표제란으로 본다. 위치 규칙 구역에 이미 표제란 라벨 둘 이상이 있으면 그대로 둔다(위치 규칙이 이긴다 —
    도면 목록표 머리 'DWG NO·TITLE·REV·DATE'가 표제란을 빼앗지 않게). 범위는 덩이를 품는 가장 작은 닫힌 사각형(도면 틀의 35% 이하),
    없으면 덩이 상자를 넓힌 것."""
    tol = _y_tol(texts)
    labs = []
    for it in texts:
        if len(it) > 5 and it[5]:
            continue
        c = _title_canons(it[0]) & _ZONE_CANONS
        if c:
            labs.append((it, c))
    if not labs:
        return None
    pos = set()
    for it, c in labs:
        if _lx(it) >= x_hi and it[2] <= y_lo:
            pos |= c
    if len(pos) >= 2 and pos & {"DWG_NO", "PROJECT", "TITLE"}:      # 개정표 머리('REV·DATE')만 있는 자리는 표제란이 아니다
        return None
    n = len(labs)
    parent = list(range(n))

    def _find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i in range(n):
        for j in range(i + 1, n):
            a, b = labs[i][0], labs[j][0]
            if abs(_lx(a) - _lx(b)) <= 40 * tol and abs(a[2] - b[2]) <= 8 * tol:
                parent[_find(i)] = _find(j)
    groups: dict = {}
    for i in range(n):
        groups.setdefault(_find(i), []).append(labs[i])
    best = None
    for g in groups.values():
        cs = set().union(*(c for _it, c in g))
        if "DWG_NO" in cs and len(cs) >= 3:
            k = (len(cs), len(g))
            if best is None or k > best[0]:
                best = (k, g)
    if best is None:
        return None
    items = [it for it, _c in best[1]]
    x0 = min(_lx(it) for it in items)
    x1 = max(_lx(it) + _text_w(it) for it in items)
    y0 = min(it[2] - (str(it[0]).count("\n") * float(it[4] or 0) * 5 / 3 if len(it) > 4 else 0) for it in items)
    y1 = max(it[2] + (float(it[4]) if len(it) > 4 and it[4] else tol) for it in items)
    if rects:
        biggest = max((r[2] - r[0]) * (r[3] - r[1]) for r in rects)
        hold = [r for r in rects if r[0] - tol <= x0 and r[1] - tol <= y0 and x1 <= r[2] + 15 * tol and y1 <= r[3] + tol
                and (r[2] - r[0]) * (r[3] - r[1]) <= 0.35 * biggest]
        if hold:
            r = min(hold, key=lambda q: (q[2] - q[0]) * (q[3] - q[1]))
            return (r[0] - tol, r[1] - tol, r[2] + tol, r[3] + tol)
    return (x0 - 2 * tol, y0 - 4 * tol, x1 + 15 * tol, y1 + 2 * tol)


def _classify(texts, rects=None):
    """텍스트를 title/revblock/body로 분류. 돌려주는 값: (title, revblock, body,
    위치 규칙으로만 title이 된 항목 집합) — 라벨·값으로 쓰이지 않은 것은 본문으로 돌려보낸다."""
    xs = [_lx(t) for t in texts]        # MTEXT는 왼쪽 끝 (held69 D05)
    ys = [t[2] for t in texts]
    x_hi = min(xs) + (max(xs) - min(xs)) * 0.6 if xs else 0
    y_lo = min(ys) + (max(ys) - min(ys)) * 0.25 if ys else 0
    y_hi = min(ys) + (max(ys) - min(ys)) * 0.75 if ys else 0
    # TITLE 레이어 표제란이 없으면 라벨 밀도로 찾은 표제란 범위가 위치 규칙을 대신한다 (뒤흔들기 DXF C3)
    zone = None
    if xs and not any("TITLE" in str(t[3]).upper() and not (len(t) > 5 and t[5]) for t in texts):
        zone = _label_zone(texts, rects, x_hi, y_lo)

    title, revblock, body = [], [], []
    by_position: set = set()
    for item in texts:
        if zone is not None and not (len(item) > 5 and item[5]) and "REV" not in str(item[3]).upper():
            if zone[0] <= _lx(item) <= zone[2] and zone[1] <= item[2] <= zone[3]:
                title.append(item)
                by_position.add(id(item))
            elif _lx(item) >= x_hi and y_hi <= item[2]:
                revblock.append(item)
            else:
                body.append(item)
            continue
        _, _x, y, layer = item[:4]
        x = _lx(item)
        lu = layer.upper()
        if len(item) > 5 and item[5]:
            if len(item) > 6 and item[6] == "META":
                continue                       # 작성·검토·승인·축척 — 비교 대상이 아니다
            if len(item) > 6 and item[6]:
                title.append(item)             # REV·DATE 같은 표제란 속성 — 필드로만 쓴다
            else:
                body.append(item)              # TITLE 같은 나머지 속성은 본문 글자
        elif "TITLE" in lu:
            title.append(item)
        elif "REV" in lu:
            revblock.append(item)
        elif x >= x_hi and y <= y_lo:
            title.append(item)
            by_position.add(id(item))
        elif x >= x_hi and y >= y_hi:
            revblock.append(item)
        else:
            body.append(item)
    # 위치 규칙 경계(오른쪽 60%)에 걸친 표제란 — 세로 용지에서는 표제란 왼쪽 라벨 칸('도면번호'·'프로젝트')이 경계 바로 왼쪽에
    # 놓여 REV·DATE만 읽히고 도면번호·프로젝트를 잃었다 (대량 시험 DXF C8, 2026-10-20). 위치로 표제란이 된 글자와 **같은 줄**이고
    # 경계에서 폭의 15% 안이며 그 줄 조각에 표제란 라벨이 있을 때만 그 줄 조각을 표제란으로 — 쓰이지 않으면 본문으로 돌아간다
    if by_position and xs and zone is None:
        tol = _y_tol(texts)
        x_ext = x_hi - (max(xs) - min(xs)) * 0.15
        pos_ys = [t[2] for t in title if id(t) in by_position]
        near = [it for it in body
                if not (len(it) > 5 and it[5]) and it[2] <= y_lo and x_ext <= _lx(it) < x_hi
                and any(abs(it[2] - py) <= tol for py in pos_ys)]
        take: set = set()
        for it in near:
            if _label_canon(it[0]):
                take.update(id(o) for o in near if abs(o[2] - it[2]) <= tol)
        if take:
            title += [it for it in body if id(it) in take]
            by_position.update(take)
            body = [it for it in body if id(it) not in take]
    return title, revblock, body, by_position


_INLINE_FIELD = re.compile(
    r"^\s*(DWG(?:\.\s?|[ _])?NO\.?|DRAWING NO\.?|도면번호|PROJ(?:ECT|\.)?(?:\s*NO\.?)?|프로젝트|REV(?:ISION)?\.?(?:\s*NO\.?)?|리비전|개정\s*번호|개정|DATE|일자)"
    r"\s*[:.]?\s+(\S{1,24})\s*$", re.IGNORECASE)
# 값 자리에 또 다른 라벨이 온 것('REV NO', 'REV HISTORY')은 값이 아니다 — pdf.py와 같은 집합.
# 'REV NO' 라벨 하나 때문에 REV='NO'가 되고 진짜 값 B→C가 어디에도 안 남았다 (검토33 C1)
_DXF_LABELISH = {"NO", "NO.", "HISTORY", "DESCRIPTION", "DATE", "NAME", "TITLE", "SHEET",
                 "BLOCK", "RECORD", "이력", "내역", "번호", "일자", "표"}


def _inline_field(text: str):
    """'REV A'·'DWG NO E-101' 꼴에서 (정규 라벨, 값). 값 자리가 또 다른 라벨이면 필드가 아니다."""
    m = _INLINE_FIELD.match(text)
    if not m:
        return None, None
    value = m.group(2).strip()
    if value.upper().rstrip(".") in {v.rstrip(".") for v in _DXF_LABELISH}:
        return None, None
    label = re.sub(r"\s+", " ", m.group(1).upper().strip())
    # 'REV.'·'REV. NO.'처럼 끝에 붙은 점은 별칭 표와 맞추기 전에 걷는다 (검토33 C1)
    canon = _LABEL_ALIASES.get(label) or _LABEL_ALIASES.get(label.rstrip(".")) or _label_canon(label)
    if canon == "REV" and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.\-]{0,5}|제?\s*\d{1,2}\s*[차판]", value):
        # 표제란 REV가 빈 도면의 본문 '개정 2026.09.01'·'개정 사양변경'이 REV를 차지했다 — PDF와 같이 Rev 꼴만 (검토41 S4 중간 3)
        return None, None
    return canon, value
# 도면명은 여러 낱말('배전반 단선도')이라 따로 — 구분자(: .)가 있을 때만
_INLINE_TITLE = re.compile(
    r"^\s*(DWG[ ._]?TITLE|DRAWING TITLE|TITLE|도면명)\s*[:.]\s*(.{1,60}?)\s*$", re.IGNORECASE)


# 서명·축척 칸 라벨 + 값 한 덩이 ('DRAWN BY: LSY', '작성 CHW', 'SCALE 1:50') — 긴 라벨부터
_META_INLINE = re.compile(
    r"^\s*(DRAWN BY|CHECKED BY|APPROVED BY|DRAWN|CHECKED|APPROVED|DESIGNED|SCALE|SHEET|SIZE|UNIT|작성|검토|승인|설계|축척|단위|용지|매수)"
    r"(?![A-Za-z가-힣])\s*[:：.]?\s*(\S.{0,40})$", re.IGNORECASE)
# 콜론 없는 도면명 한 덩이 ('도면명 감지기 배치도', 'TITLE LIFTER ASSY') — 표제란 자리 글자에서만
_INLINE_TITLE_BARE = re.compile(r"^\s*(DWG[ ._]?TITLE|DRAWING TITLE|TITLE|도면명)\s+(\S.{0,59}?)\s*$", re.IGNORECASE)


def _same_line(a, b, tol: float) -> bool:
    """두 글자가 같은 줄인가 — 보통은 바탕선 차이가 허용 오차(글자 높이 중앙값) 안. 글자 높이가 1.5배 넘게 다르면(작은 칸 라벨 +
    큰 값) 글자 상자가 세로로 겹칠 때만: 큰 값 글자 하나가 중앙값을 끌어올려 아래 칸 라벨 'SCALE'이 위 칸 REV 값 'A'를 같은 줄로
    집었다(뒤흔들기 DXF C13, 2026-10-23)."""
    ha = float(a[4]) if len(a) > 4 and a[4] else 0.0
    hb = float(b[4]) if len(b) > 4 and b[4] else 0.0
    if ha > 0 and hb > 0 and max(ha, hb) > 1.5 * min(ha, hb):
        ca, cb = getattr(a, "cy", a[2] + ha / 2), getattr(b, "cy", b[2] + hb / 2)      # TEXT는 바탕선 + 높이 절반
        lo, hi = max(ca - ha / 2, cb - hb / 2), min(ca + ha / 2, cb + hb / 2)
        return hi - lo > 0.1 * min(ha, hb)
    return abs(a[2] - b[2]) <= tol


def _parse_title(title, tol: float = _Y_TOL) -> tuple[dict, set]:
    """(표제란 필드, 라벨·값으로 쓰인 항목 id 집합)."""
    fields: dict[str, Field] = {}
    used_inline: set = set()
    # 개정 행으로 실은 속성 값(일곱째 칸 'ROW')은 표제란 라벨·값이 아니다 — 행 설명 'REV UP'이 'REV' + 'UP'으로
    # 읽혀 표제란 REV를 빼앗았다 (검토68 A3)
    title = [it for it in title if not (len(it) > 6 and it[6] == "ROW")]

    def _row_like_line(item) -> bool:
        # 그 글자가 놓인 줄이 개정 행 꼴('B 2026.10.13 REV UP KJH')인가 (검토68 A3)
        same = sorted((t for t in title if abs(t[2] - item[2]) <= tol), key=lambda t: t[1])
        return _looks_like_rev_row(" ".join(str(t[0]) for t in same).split())

    # 'REV A' 'DWG NO E-101'처럼 라벨과 값이 한 글자 덩어리 — PDF 추출기와 같은 규칙
    # (2026-09-06 블라인드 양식 시험 49·50: Rev 변경이 글자 변경으로만 보고됨)
    for item in title:
        # 여러 줄 MTEXT 한 덩이 표제란('DWG NO: …⏎PROJECT: …⏎REV: A')은 줄마다 읽는다 — 통째로는 라벨 꼴이 아니라
        # '표제란을 인식하지 못함'이 되고 REV 변경이 글자 변경으로만 나왔다 (검토68 A8)
        lines_ = str(item[0]).split("\n")
        parts = [p for p in lines_ if p.strip()]
        n_hit, n_meta = 0, 0
        # 여러 줄이면 칸마다 줄 높이(글자 높이 × 5/3)만큼 내려 적는다 — 근거 위치와 표제란 틀 범위가 덩이 전체를 덮게
        hgt = float(item[4]) if len(item) > 4 and item[4] else 0.0
        for li, part in enumerate(lines_):
            if not part.strip():
                continue
            py = item[2] - li * hgt * 5 / 3 if len(parts) > 1 else item[2]
            canon, value = _inline_field(part)
            if canon is None:
                mt = _INLINE_TITLE.match(part)
                if not mt:
                    if len(parts) > 1:
                        ms = re.match(r"^\s*(SCALE|축척)(?![A-Za-z가-힣])\s*[:：.]?\s*(\S.*)$", part, re.I)
                        if ms and "META:SCALE" not in fields:
                            fields["META:SCALE"] = Field("META:SCALE", ms.group(2).strip(),
                                                         f"표제란(x={item[1]:.0f}, y={py:.0f})")
                        lab = re.match(r"^\s*([^:：]+?)\s*[:：]\s*(.*)$", part)
                        if lab and lab.group(1).upper().strip() in _META_LABELS:
                            n_meta += 1
                        elif lab and not lab.group(2).strip() and _label_canon(lab.group(1)):
                            # 값이 빈 표제란 칸('PROJECT: ') — 덩이를 본문으로 남기면 REV·DATE 변경이 글자 변경으로도
                            # 실리고 'Rev만 갱신' 판정이 사라졌다 (대량 시험 DXF C2, 2026-10-20)
                            n_meta += 1
                        elif lab and lab.group(2).strip() and len(lab.group(2).strip()) <= 60:
                            # 낱말 여럿인 칸 값('PROJECT: Delta Engineering') — 한 낱말 꼴(_INLINE_FIELD)이 못 읽어 덩이가 본문으로
                            # 남고 REV·DATE 변경이 글자 변경으로도 실렸다 (대량 시험 DXF C2 나머지). 그 칸 값으로 읽는다(REV는 Rev 꼴만)
                            c_ = _label_canon(lab.group(1))
                            if c_ and c_ != "REV":
                                n_hit += 1
                                if c_ not in fields:
                                    fields[c_] = Field(c_, lab.group(2).strip(), f"표제란(x={item[1]:.0f}, y={py:.0f})")
                    else:
                        # 한 덩이로 쓴 서명·축척 칸('DRAWN BY: LSY'·'작성 CHW'·'SCALE 1:50')은 표제란 칸이다 — 본문 '글자 추가'로 남아
                        # 거짓 'Rev 미갱신'이 났다(뒤흔들기 DXF C11, 2026-10-23). 콜론 없는 도면명('도면명 감지기 배치도')은 도면명 칸
                        mm_ = _META_INLINE.match(part)
                        if mm_:
                            used_inline.add(id(item))
                            # 서명 칸은 필드(META:…)로 남겨 그림 비교가 그 자리의 픽셀 차이를 글자로 알게 — 블록 속성 서명과 같다
                            # (리뷰11 중간-H). 축척은 아래 축척 규칙이 값만 읽는다
                            lab_ = re.sub(r"\s+", " ", mm_.group(1).upper())
                            if lab_ not in ("SCALE", "축척"):
                                fields.setdefault(f"META:{lab_}", Field(f"META:{lab_}", part.strip(),
                                                                        f"표제란(x={item[1]:.0f}, y={py:.0f})"))
                        else:
                            mt2 = _INLINE_TITLE_BARE.match(part)
                            if mt2 and "TITLE" not in fields and not _label_canon(mt2.group(2))                                     and mt2.group(2).upper().split()[0] not in _DXF_LABELISH:
                                fields["TITLE"] = Field("TITLE", mt2.group(2), f"표제란(x={item[1]:.0f}, y={py:.0f})")
                                used_inline.add(id(item))
                    continue
                canon, value = _LABEL_ALIASES.get(mt.group(1).upper().strip()), mt.group(2)
            if canon == "REV" and len(parts) == 1 and _row_like_line(item):
                continue
            if canon:
                n_hit += 1
                if canon not in fields:
                    fields[canon] = Field(canon, value, f"표제란(x={item[1]:.0f}, y={py:.0f})")
                    if len(parts) == 1:
                        used_inline.add(id(item))
        # 여러 줄 덩이는 모든 줄이 표제란 칸일 때만 본문에서 뺀다 — 다른 줄(회사명 등)의 변경을 잃지 않게
        if len(parts) > 1 and n_hit >= 2 and n_hit + n_meta == len(parts):
            used_inline.add(id(item))
    used: set = set()
    # 라벨 글자(표제란 칸 이름·서명·축척 칸) — 값 후보가 아니고, 같은 줄에서 오른쪽 라벨 너머는 그 라벨의 값이다
    labels = [it for it in title
              if _label_canon(it[0]) or str(it[0]).upper().rstrip(".:： ").strip() in _META_LABELS]
    label_ids = {id(it) for it in labels}

    def _not_label(vitem) -> bool:
        vt = str(vitem[0]).upper().rstrip(".:： ").strip()
        # 라벨+값 한 덩이('일자 2026/10/16'·'작성 CHW')도 옆 칸의 값이 아니다 — 빈 PROJECT 칸이 옆 '일자 …'를 값으로 집었다 (뒤흔들기 DXF C11)
        return (id(vitem) not in label_ids and vt not in _LABEL_ALIASES and vt not in _DXF_LABELISH
                and id(vitem) not in used_inline and not _META_INLINE.match(str(vitem[0])))

    for item in labels:
        text, x, y, layer = item[:4]
        canon = _label_canon(text)
        # 서명·축척 칸 라벨은 표 꼴(아래 값)일 때만 — 한 줄 꼴은 아래 메타 줄 규칙이 그대로 맡는다
        meta = None if canon else str(text).upper().rstrip(".:： ").strip()
        # 같은 줄 오른쪽 다음 라벨까지가 이 칸 — PROJECT 칸이 비면 같은 줄 DATE 값을, 표 꼴에서는 옆 라벨 'SCALE'을
        # 프로젝트로 읽었다 (검토68 A1·A2)
        nxt = min((lb[1] for lb in labels if lb is not item and _same_line(lb, item, tol) and lb[1] > x),
                  default=float("inf"))

        def _rev_ok(vtext: str) -> bool:
            return (canon != "REV" or not re.search(r"[가-힣]", text)
                    or bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.\-]{0,5}|제?\s*\d{1,2}\s*[차판]", vtext.strip())))

        # 값 = 같은 줄(y 허용 오차 내) 오른쪽에서 가장 가까운 비라벨 텍스트
        candidates = [
            (vx, vtext, id(vitem)) for vitem in title
            for vtext, vx, vy in [vitem[:3]]
            if _same_line(vitem, item, tol) and x < vx < nxt
            and _not_label(vitem)      # '개정' '번호' 'B' (검토39 F2 ①)
            and _rev_ok(vtext)
        ]
        if meta and candidates:
            # 한 줄 꼴 서명·SHEET·UNIT·SIZE 칸의 값('SHEET' 옆 '1 OF 3') — 줄은 메타 줄 규칙이 본문에서 빼지만 값을 필드로도 안 남겨
            # SHEET 수·단위·용지·작성자 변경이 추출 결과 어디에도 없었다 (재검토 2026-10-28 R1-2). 블록 속성 서명처럼 META:…로
            if meta not in ("SCALE", "축척"):
                vx_, vtext_, _vid = min(candidates)
                mk_ = "META:" + " ".join(meta.split())
                fields.setdefault(mk_, Field(mk_, str(vtext_).strip(), f"표제란(x={vx_:.0f}, y={y:.0f})"))
            continue
        if not candidates and all(id(t) in label_ids for t in title if _same_line(t, item, tol)):
            # 표 꼴 표제란(ISO 7200식 칸: 라벨 위·값 아래) — 줄 전체가 라벨뿐이면 바로 아래 같은 칸의 값을 읽는다.
            # 그 값 줄에 자기 라벨이 왼쪽에 있으면 그 라벨의 값이다(한 줄 꼴 표제란의 빈 칸이 아랫줄 값을 집지 않게) (검토68 A1)
            hl = float(item[4]) if len(item) > 4 and item[4] else 0.0
            # 칸 높이 — 바로 아래 라벨 줄까지(없으면 바로 위 라벨 줄까지의 간격). 칸 12에 글자 2.0이면 라벨-값 거리 7이
            # 글자 높이 3배(6.6)를 넘어 표제란 전체를 못 읽었다 (대량 시험 DXF C1, 2026-10-20). 값은 아래 라벨 줄보다 위,
            # 글자 높이 8배 안에서만 — 빈 칸 라벨이 아래 칸 값을 집지 않게
            lab_below = [lb[2] for lb in labels if lb[2] < y - tol]
            lab_above = [lb[2] for lb in labels if lb[2] > y + tol]
            if lab_below:
                cell = y - max(lab_below) - 0.5 * tol
            elif lab_above:
                cell = 0.8 * (min(lab_above) - y)
            else:
                cell = 0.0
            below = []
            for vitem in title:
                vtext, vx, vy = vitem[:3]
                hv = float(vitem[4]) if len(vitem) > 4 and vitem[4] else 0.0
                hmax = max(tol, hl, hv)
                reach = max(3 * hmax, min(cell, 8 * hmax))
                # 가운데·오른쪽 맞춤 칸 값은 라벨 왼쪽 끝보다 왼쪽에서 시작할 수 있다 — 값 글자 폭이 라벨 자리에 걸치면 같은 칸
                # (뒤흔들기 DXF 정렬 흔들기, 2026-10-23: 칸표 도면번호가 옆 칸 REV 값 '1'이 됐다)
                if not (0 < y - vy <= reach and vx < nxt and (x - tol <= vx or vx + _text_w(vitem) > x + tol)):
                    continue
                if id(vitem) in used or not _not_label(vitem) or not _rev_ok(vtext):
                    continue
                if any(_same_line(lb, vitem, tol) and lb[1] <= vx for lb in labels):
                    continue
                below.append((-vy, vx, vtext, id(vitem)))
            if below:
                _ny, vx, vtext, vid = min(below)
                candidates = [(vx, vtext, vid)]
                y = -_ny
        if meta and not candidates:
            continue
        used.add(id(item))
        if candidates:
            vx, vtext, vid = min(candidates)
            used.add(vid)
            if meta:
                if meta in ("SCALE", "축척"):
                    fields.setdefault("META:SCALE", Field("META:SCALE", vtext, f"표제란(x={vx:.0f}, y={y:.0f})"))
                # (표 꼴 서명 칸의 아래 값은 필드로 싣지 않는다 — 속성 표제란에서는 값이 속성이라 아래 칸 라벨('DRAWNBY')을
                #  값으로 집었다. 속성 값은 META:…로 따로 실린다)
            elif canon not in fields:
                fields[canon] = Field(canon, vtext,
                                      f"표제란(레이어 {layer}, x={vx:.0f}, y={y:.0f})")
    return fields, used | used_inline


# 줄 바꿈으로 다음 줄에 넘어간 사양 값('5.5kW', '100AF/75AT', '24VDC') — 낱말 하나하나가 숫자로 시작하고 단위 글자가 붙은 꼴
_WRAP_VAL = re.compile(r"^\d[\d.,]*[A-Za-zΩ℃°%μ㎾]+(?:/\d[\d.,]*[A-Za-zΩ℃°%μ㎾]+)*$")
# 숫자와 단위를 띄어 쓴 값('5.5 kW') — 잇기 판정에서만 붙여 본다 (held69 D10). 글줄 자체는 그대로 둔다
_UNIT_GAP = re.compile(r"(?<![\w.,])(\d[\d.,]*)\s+([A-Za-zΩ℃°%μ㎾]{1,4})(?![\w])")
# 값 낱말에 딸린 숫자+한글 꾸밈말('4극'·'3상'·'2대') — 값 낱말이 하나 이상 있을 때만 (held69 D12). 숫자 없는 한글 낱말
# ('24VDC 코일'의 '코일')은 값이 아니라 이름이라 잇지 않는다 (test_bench_doc 좁은 잇기)
_WRAP_MOD = re.compile(r"\d{1,2}[가-힣]{1,2}")


def _glue_units(text: str) -> str:
    return _UNIT_GAP.sub(r"\1\2", str(text))


def _wrap_value_line(text: str) -> bool:
    """태그 줄이 넘긴 사양 값만 든 줄인가 — 낱말 셋 이하, 값 낱말('5.5kW') 하나 이상, 나머지는 값이거나 숫자+한글 꾸밈말."""
    toks = _glue_units(text).split()
    if not toks or len(toks) > 3 or not any(_WRAP_VAL.match(t) for t in toks):
        return False
    return all(_WRAP_VAL.match(t) or _WRAP_MOD.fullmatch(t) for t in toks)


def _next_tag_aligned(rows: list, ri: int, hh: float, find_tags) -> bool:
    """들여 쓴 값 줄 바로 아래 줄이 그 값 줄과 같은 왼쪽 끝에서 시작하는 태그 줄인가 — 그러면 값은 아래 기기의 것이다
    (값을 이름표 위에 적는 배치). 들여 쓴 값을 위 태그 줄에 잇지 않는다."""
    if ri + 1 >= len(rows):
        return False
    r, n = rows[ri], rows[ri + 1]
    return 0 < r[2] - n[2] <= 2.5 * hh and abs(n[3] - r[3]) <= 0.5 * hh and bool(find_tags(n[0]))


def _far_segments(parts: list, tol: float) -> list:
    """한 줄 조각들(왼쪽→오른쪽, (x, 글자, 레이어, 높이, 왼쪽 끝 x))을 멀리 떨어진 곳에서 끊는다 — 앞 조각 끝(폭 어림)에서 다음 조각
    시작까지 틈이 글자 높이 8배를 넘고 레이어가 다르면 다른 덩어리다. 같은 높이에 놓인 다른 표의 글자가 한 줄로 붙어 개정표 행·
    부품표 행·태그 줄이 엉뚱한 글과 섞였다(뒤흔들기 DXF C8·C18, 2026-10-23 — PDF 글줄 2026-10-20과 같은 생각). 태그('M-101', 레이어
    TAG)와 바로 옆 사양('MOTOR 5.5kW', 레이어 TEXT)처럼 가까운 조각은 레이어가 달라도 한 줄이다. 같은 레이어는 멀어도 끊지 않는다 —
    개정표 설명 칸이 짧으면('재발행') 서명 칸까지 글자 높이 40배가 넘게 비어 행이 갈라졌다(틀 둘은 _sheet_frames가 가른다)."""
    segs = [[parts[0]]] if parts else []
    for p in parts[1:]:
        q = segs[-1][-1]
        hh = max(q[3], p[3]) or tol
        qw = max((sum(1.0 if ord(c) > 0x2E80 else 0.6 for c in ln) for ln in str(q[1]).split("\n")), default=0.0) * (q[3] or tol)
        gap = p[4] - (q[4] + qw)
        if gap > 8 * hh and p[2] != q[2]:
            segs.append([p])
        else:
            segs[-1].append(p)
    return segs


def _merge_lines(items, tol: float = _Y_TOL, join_wrapped: bool = False) -> list:
    """같은 y의 텍스트 조각을 한 줄로 병합. 위→아래, 왼쪽→오른쪽 순.

    join_wrapped(본문만): 태그 줄('M-101 MOTOR') 바로 아래, 같은 왼쪽 끝·같은 레이어에 사양 값만 든 줄('5.5kW')이 있으면
    태그 줄이 넘긴 값으로 보고 한 줄로 잇는다 — 따로 두면 그 태그의 사양이 없는 줄이 되어 도면-BOM 불일치를 못 냈다
    (고정 벤치마크 fmt66 D21). 태그 줄에 이미 값이 있거나, 아래 줄에 태그·값 아닌 낱말이 있으면 잇지 않는다."""
    groups: dict[float, list] = {}
    for item in items:
        text, x, y, layer = item[:4]
        h = item[4] if len(item) > 4 and item[4] else 0.0
        key = next((k for k in groups if abs(k - y) <= tol), y)
        groups.setdefault(key, []).append((x, text, layer, h, _lx(item)))
    rows = []
    for y in sorted(groups, reverse=True):
        for parts in _far_segments(sorted(groups[y]), tol):
            rows.append([" ".join(str(p[1]) for p in parts), parts[0][2], y, parts[0][0], max(p[3] for p in parts)])
    if join_wrapped and len(rows) > 1:
        from watcher.extract.base import find_tags
        out = [rows[0]]
        for ri, r in enumerate(rows[1:], 1):
            prev = out[-1]
            hh = max(prev[4], r[4], tol)
            ptags = find_tags(prev[0])
            dx = r[3] - prev[3]
            if (_wrap_value_line(r[0]) and not find_tags(r[0])
                    and ptags and r[1] == prev[1] and -hh <= dx <= 2 * hh
                    and (dx <= hh or not _next_tag_aligned(rows, ri, hh, find_tags))
                    and 0 < prev[2] - r[2] <= 2.5 * hh
                    and not any(_WRAP_VAL.match(t) for t in _glue_units(prev[0]).split())):
                out[-1] = [prev[0] + " " + r[0], prev[1], r[2], prev[3], hh]
                continue
            out.append(r)
        rows = out
    # 좌표(y=180)로 도면에서 찾는 사람은 없다 — 레이어만 (2026-09-02 처음 보는 사람 검토)
    return [TextLine(r[0], f"레이어 {r[1]}") for r in rows]


_DATE_TOKEN = re.compile(r"\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{6,8}")


def _looks_like_rev_row(tokens: list[str]) -> bool:
    """Rev 행 검증: 첫 토큰이 짧은 개정 코드꼴 + 둘째 토큰이 날짜꼴.
    위치 휴리스틱이 우상단의 일반 텍스트(방 이름·치수)를 리비전으로 오인하는 것 방지
    (실물 도면 테스트에서 확인된 오탐)."""
    return (len(tokens) >= 2 and len(tokens[0]) <= 4 and tokens[0].isalnum()
            and bool(_DATE_TOKEN.search(tokens[1])))


_REV_HDR_FIRST = {"REV", "REV.", "REVISION", "개정", "리비전"}
_REV_HDR_DESC = {"DESCRIPTION", "DESC", "DESC.", "DESCR", "REMARK", "REMARKS", "내용", "개정내용", "변경내용", "사유",
                 "개정사유"}


def _split_rev_table(title, tol: float) -> tuple[list, list]:
    """표제란 자리(레이어 0·위치 규칙)에 놓인 개정 표를 떼어 낸다 — (나머지, 개정 표 글자).

    ISO 꼴 개정 표는 표제란 바로 위에 아래에서 위로 쌓이고 레이어도 0이라, 위치 규칙으로 표제란이 되어 행이 글줄로만
    나왔다(행 추가가 '글자 추가') (검토68 A7). 머리 줄('REV … DESCRIPTION …')이 있고, 그 바로 위·아래로 이어진 줄이
    개정 행 꼴('B 2026.10.13 …')일 때만 — 표제란 칸 줄은 개정 행 꼴이 아니라 끊긴다."""
    cand = [it for it in title if not (len(it) > 5 and it[5])]

    def _lines(items):
        groups: list = []
        for it in sorted(items, key=lambda t: -t[2]):
            for g in groups:
                if abs(g[0] - it[2]) <= tol:
                    g[1].append(it)
                    break
            else:
                groups.append((it[2], [it]))
        # 같은 높이의 다른 레이어 먼 글자(본문 태그 줄)와는 다른 줄 — 개정표를 본문 높이로 옮기면 머리 줄 첫 낱말이 태그가 되어
        # 개정표를 못 찾았다 (뒤흔들기 DXF C8, _far_segments와 같은 끊기)
        out = []
        for y, g in groups:
            g = sorted(g, key=lambda t: t[1])
            parts = [(t[1], str(t[0]), t[3], (t[4] if len(t) > 4 and t[4] else 0.0), _lx(t), t) for t in g]
            out += [(y, [p[5] for p in seg]) for seg in _far_segments(parts, tol)]
        return out

    taken: set = set()
    for _hy, hdr in _lines(cand):
        toks = " ".join(str(t[0]) for t in hdr).split()
        if not toks or toks[0].upper() not in _REV_HDR_FIRST or not any(t.upper() in _REV_HDR_DESC for t in toks):
            continue
        hx0, hx1 = min(t[1] for t in hdr), max(t[1] for t in hdr)
        col = [it for it in cand if hx0 - 3 * tol <= it[1] <= hx1 + 3 * tol and id(it) not in taken]
        lines = _lines(col)
        hi = next((i for i, (_y, g) in enumerate(lines) if any(t is hdr[0] for t in g)), None)
        if hi is None:
            continue
        rows: list = []
        late = _rev_header_date_late(toks)        # 'REV | DESCRIPTION | DATE' 순서 머리 (held69 D06)
        late = None if late is None else {late}

        def _ps(g):
            return [(t[1], str(t[0]), t[4] if len(t) > 4 and t[4] else 0.0) for t in g]
        dcol = _hdr_date_col(_ps(hdr)) if late else None      # 뒤 칸이 빈 새 행 (검토71 R3 D71-04)
        for step in (1, -1):                      # 아래로(보통 꼴)·위로(ISO 꼴) 이어진 행
            i, prev_y = hi + step, lines[hi][0]
            while 0 <= i < len(lines):
                y, g = lines[i]
                rtoks = " ".join(str(t[0]) for t in g).split()
                if abs(prev_y - y) > 4 * tol or not (_looks_like_rev_row(rtoks)
                                                      or (late and _late_date_index(rtoks, late))
                                                      or (dcol and _date_in_col(_ps(g), rtoks, [dcol]))):
                    break
                rows += g
                prev_y = y
                i += step
        if rows:
            taken |= {id(t) for t in rows} | {id(t) for t in lines[hi][1]}
    if not taken:
        return title, []
    return [it for it in title if id(it) not in taken], [it for it in title if id(it) in taken]


def _bare_rev_rows(items, tol: float) -> list:
    """머리 줄 없는 개정 행 글자(배치 공간) — 개정 행 꼴('B 2026-04-14 주기 추가 PSJ') 줄이 둘 이상 잇달아(행 간격 글자 높이 4배
    안) 있으면 그 글자들. 속성 블록 개정 행(머리 줄 없음)을 글자로 풀어 배치 공간에 둔 도면은 모든 글자가 표제란 후보라 행이
    글줄로만 나와 '행 삭제 + 글자 추가'가 됐다(뒤흔들기 DXF 속성→글자, 2026-10-23)."""
    cand = [it for it in items if not (len(it) > 5 and it[5])]
    groups: list = []
    for it in sorted(cand, key=lambda t: -t[2]):
        for g in groups:
            if abs(g[0] - it[2]) <= tol:
                g[1].append(it)
                break
        else:
            groups.append((it[2], [it]))
    out: list = []
    run: list = []
    prev_y = None
    for y, g in groups:
        toks = " ".join(str(t[0]) for t in sorted(g, key=lambda t: t[1])).split()
        ok = _looks_like_rev_row(toks) and (prev_y is None or not run or abs(prev_y - y) <= 4 * tol)
        if ok:
            run.append(g)
            prev_y = y
            continue
        if len(run) >= 2:
            out += [t for gg in run for t in gg]
        run = [g] if _looks_like_rev_row(toks) else []
        prev_y = y if run else None
    if len(run) >= 2:
        out += [t for gg in run for t in gg]
    return out


_ROW_KEY = re.compile(r"[A-Za-z]{1,2}\d{0,2}|\d{1,3}|REV\.?|개정|리비전", re.IGNORECASE)


def _row_snap(items, tol: float) -> tuple:
    """개정표 글자의 행 높이 맞추기 {id: 그 행 Rev 칸의 y}. 맨 왼쪽 칸(Rev 칸·머리 'REV')이 둘 이상이고 행 간격이 글자 높이보다
    넓을 때만, 다른 칸 글자를 가장 가까운 Rev 칸 행(행 간격 0.6배 안)의 높이로 본다. 손으로 놓은 개정표 칸이 행 간격(글자 높이
    1.6배)의 절반 가까이 어긋나면 한 행 칸이 윗행·아랫행과 한 줄로 묶여 행이 통째로 바뀌었다(뒤흔들기 DXF C13·C3·C8 흔들림). 반듯한
    개정표는 모든 칸이 이미 제 행 높이라 그대로다. 돌려주는 값: (맞춘 높이, 줄 묶기 허용 오차 — 가장 가까운 두 행 간격의 0.45배)."""
    if len(items) < 4:
        return {}, tol
    hs = sorted(float(t[4]) for t in items if len(t) > 4 and t[4])
    h = hs[len(hs) // 2] if hs else tol
    x0 = min(_lx(t) for t in items)
    keys = sorted((t for t in items if _lx(t) <= x0 + 2 * h and _ROW_KEY.fullmatch(str(t[0]).strip())),
                  key=lambda t: -t[2])
    if len(keys) < 2:
        return {}, tol
    gaps = sorted(a[2] - b[2] for a, b in zip(keys, keys[1:]))
    pitch = gaps[len(gaps) // 2]
    if pitch < 1.2 * h or pitch > 4 * h or gaps[0] < 0.8 * h:        # 표 행 간격만 — 테두리 구역 글자(A·B·C 띄엄띄엄)는 아님
        return {}, tol
    kid = {id(k) for k in keys}
    out = {}
    for t in items:
        if id(t) in kid:
            continue
        k = min(keys, key=lambda k_: abs(k_[2] - t[2]))
        if abs(k[2] - t[2]) <= 0.6 * pitch and k[2] != t[2]:
            out[id(t)] = k[2]
    return out, min(tol, 0.45 * gaps[0])


def _parse_revblock(revblock, tol: float = _Y_TOL) -> tuple[list, list]:
    """(리비전 행들, 리비전이 아니어서 본문으로 돌려보낼 항목들)."""
    rows, leftover = [], []
    snap, rtol = _row_snap(revblock, tol)
    if snap:
        tol = rtol
        def _sy(t):
            if id(t) not in snap:
                return t
            n = (t[0], t[1], snap[id(t)]) + tuple(t[3:])
            if isinstance(t, _Item):
                n = _Item(n)
                n.left = t.left
                if hasattr(t, "cy"):
                    n.cy = t.cy + snap[id(t)] - t[2]
            return n
        revblock = [_sy(t) for t in revblock]
    lines = _merge_lines(revblock, tol)
    # 머리 줄의 일자 칸이 둘째가 아닌 표('REV | DESCRIPTION | DATE | APPD') — 행의 일자도 둘째 낱말이 아니다. 둘째만 보면
    # 새 행이 개정 행이 아니라 '글자 추가'로 남았다 (held69 D06). 그런 머리 줄이 있을 때만 일자 칸 자리를 가리지 않는다
    loose = {_rev_header_date_late(ln.text.split()) for ln in lines} - {None}
    parts_of = _line_parts(revblock, tol)
    cols = [c for ln, ps in zip(lines, parts_of) if _rev_header_date_late(ln.text.split()) is not None
            for c in [_hdr_date_col(ps)] if c] if loose and len(parts_of) == len(lines) else []
    for li, line in enumerate(lines):
        tokens = line.text.split()
        if tokens and tokens[0].upper() == "REV":  # 헤더 행
            continue
        di = None
        if _looks_like_rev_row(tokens):
            rows.append(Row(key=tokens[0],
                            values={"DATE": tokens[1],
                                    "DESCRIPTION": " ".join(tokens[2:])},
                            where=f"리비전 블록({line.where})"))
        elif loose and ((di := _late_date_index(tokens, loose))
                        or (cols and (di := _date_in_col(parts_of[li], tokens, cols)))):
            rows.append(Row(key=tokens[0],
                            values={"DATE": tokens[di],
                                    "DESCRIPTION": " ".join(tokens[1:di] + tokens[di + 1:])},
                            where=f"리비전 블록({line.where})"))
        else:
            leftover.append(line)
    return rows, leftover


_REV_HDR_DATE = {"DATE", "DATE.", "일자", "날짜"}


def _line_parts(items, tol: float) -> list:
    """_merge_lines와 같은 묶음·순서로 줄마다 [(x, 글자, 높이)] (왼쪽→오른쪽) — 칸 자리를 보려고."""
    groups: dict[float, list] = {}
    for item in items:
        text, x, y = item[0], item[1], item[2]
        h = item[4] if len(item) > 4 and item[4] else 0.0
        key = next((k for k in groups if abs(k - y) <= tol), y)
        groups.setdefault(key, []).append((x, str(text), item[3], h, _lx(item)))
    # _merge_lines와 같은 끊기(먼 조각은 다른 줄)로 — 줄 수가 같아야 칸 자리를 맞춰 본다
    return [[(p[0], p[1], p[3]) for p in seg] for y in sorted(groups, reverse=True)
            for seg in _far_segments(sorted(groups[y]), tol)]


def _hdr_date_col(parts) -> tuple | None:
    """머리 줄 칸 조각에서 일자 칸의 가로 범위 (x0, 다음 칸 x) — 칸마다 따로 쓴 글자일 때만."""
    for k, (x, t, h) in enumerate(parts):
        if t.strip().upper().rstrip(":") in _REV_HDR_DATE:
            nx = parts[k + 1][0] if k + 1 < len(parts) else float("inf")
            return (x - 2 * max(h, 1.0), nx)
    return None


def _date_in_col(parts, tokens: list[str], cols) -> int | None:
    """행 줄에서 머리 'DATE' 칸 가로 범위 안에 놓인 통째 날짜 조각의 낱말 자리 — 뒤 칸(검토·승인)이 빈 새 행은 끝에서의 자리가
    머리 줄과 달라 개정 행으로 못 읽혀 '표제란 ≠ 개정표'를 놓쳤다 (검토71 R3 D71-04). 첫 낱말은 개정 코드 꼴, 날짜는 셋째 이후."""
    if len(tokens) < 3 or not re.fullmatch(r"[A-Za-z]{1,2}\d{0,2}|\d{1,3}", tokens[0]):
        return None
    k = 0
    for x, t, _h in parts:
        n = len(t.split())
        if n == 1 and _DATE_TOKEN.fullmatch(t.strip()) and k >= 2 and any(x0 <= x < x1 for x0, x1 in cols):
            return k
        k += n
    return None


def _rev_header_date_late(tokens: list[str]) -> int | None:
    """개정표 머리 줄('REV DESCRIPTION DATE APPD')이고 일자 칸이 설명 칸 뒤에 오면, 일자 칸이 끝에서 몇째인지(0=맨 끝).
    아니면 None."""
    up = [t.upper().rstrip(":") for t in tokens]
    if not up or up[0] not in _REV_HDR_FIRST:
        return None
    di = next((i for i, t in enumerate(up) if t in _REV_HDR_DATE), None)
    de = next((i for i, t in enumerate(up) if t in _REV_HDR_DESC), None)
    if di is None or de is None or de > di:
        return None
    return len(up) - 1 - di


def _late_date_index(tokens: list[str], tails) -> int | None:
    """개정 행 꼴에서 셋째 이후 낱말 중 **통째로** 날짜이고, 끝에서의 자리가 머리 줄 일자 칸과 같은 것의 자리.
    첫 낱말은 개정 코드 꼴(A·B1·12)만 — 'NOTE'·'ZONE' 같은 낱말 줄은 행이 아니다. 끝 자리를 맞춰 보는 것은 개정표 근처
    주기('Z1 구역 인계 2026-10-20')가 행이 되어 거짓 '개정표 불일치'를 내지 않게."""
    if len(tokens) < 3 or not re.fullmatch(r"[A-Za-z]{1,2}\d{0,2}|\d{1,3}", tokens[0]):
        return None
    return next((i for i in range(2, len(tokens))
                 if _DATE_TOKEN.fullmatch(tokens[i]) and len(tokens) - 1 - i in tails), None)


# 표제란의 다른 칸 라벨 — 같은 줄의 글자(검토자 서명·SHEET 수·축척)는 표제란 메타라
# 본문으로 돌려보내지 않는다. 서명 기입은 Rev를 올리지 않는 정상 작업인데 '내용 변경 →
# Rev 미갱신'으로 잡혔다 (2026-09-04 재검토 ②-2)
_META_LABELS = {"DRAWN", "CHECKED", "APPROVED", "DESIGNED", "DRAWN BY", "CHECKED BY",
                "APPROVED BY", "SCALE", "SHEET", "SIZE", "UNIT",
                "작성", "검토", "승인", "설계", "축척", "단위", "용지", "매수"}


def _meta_line_ids(title, tol: float) -> set:
    ys = [it[2] for it in title if it[0].strip().upper().rstrip(":.") in _META_LABELS]
    return {id(it) for it in title if any(abs(it[2] - y) <= tol for y in ys)}


def _rect_of(e, theta: float = 0.0) -> tuple | None:
    """닫힌 LWPOLYLINE이 (거의) 축에 나란한 사각형이면 (x0, y0, x1, y1). 꼭짓점이 사각형 변에서 짧은 변의 2% 안이면 사각형."""
    try:
        vs = [(float(v[0]), float(v[1])) for v in e.get_points("xy")]
    except Exception:
        return None
    if theta:
        vs = [_rot_xy(x, y, theta) for x, y in vs]
    if len(vs) == 5 and vs[0] == vs[-1]:
        vs = vs[:4]
    if len(vs) != 4 or not (e.closed or len(vs) == 4):
        return None
    xs, ys = [v[0] for v in vs], [v[1] for v in vs]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    w, h = x1 - x0, y1 - y0
    if w <= 0 or h <= 0:
        return None
    eps = 0.02 * min(w, h)
    if not all((abs(x - x0) <= eps or abs(x - x1) <= eps) and (abs(y - y0) <= eps or abs(y - y1) <= eps) for x, y in vs):
        return None
    return (x0, y0, x1, y1)


def _title_canons(text: str) -> set:
    """글자(여러 줄이면 줄마다)가 표제란 라벨이거나 '라벨 값' 한 덩이면 그 정규 이름들."""
    got = set()
    for part in str(text or "").split("\n"):
        c = _label_canon(part) or _inline_field(part)[0]
        if not c:
            m = re.match(r"^\s*([^:：]{1,20}?)\s*[:：]", part)
            c = _label_canon(m.group(1)) if m else None
        if c:
            got.add(c)
    return got


def _model_rects(doc, theta: float = 0.0) -> list:
    """모델 공간의 닫힌 사각형(축에 나란한 LWPOLYLINE) 범위 목록 — 겹치는 것은 하나로. theta: 글자를 되돌린 각(도) — 꼭짓점도 같이 돌린다."""
    seen: set = set()
    rects = []
    try:
        for e in doc.modelspace().query("LWPOLYLINE"):
            r = _rect_of(e, theta)
            if r and r not in seen:
                seen.add(r)
                rects.append(r)
    except Exception:
        return []
    return rects


def _sheet_frames(rects: list, out: list, inserts: list) -> list | None:
    """모델 공간에 도면 틀(닫힌 큰 사각형)이 둘 이상 나란히 있고 틀마다 제 표제란(도면번호·REV 라벨 또는 표제란 속성)이 있으면
    틀마다 [(글자 항목, 블록 삽입)] — 위 줄부터, 줄 안은 왼쪽부터. 아니면 None.

    같은 도면 두 장을 한 파일에 나란히 그린 모델 공간은 흔한데, 한 공간으로 읽으면 같은 높이의 두 틀 글자가 한 줄로 붙고
    (태그 둘이 한 줄 — 도면 간 불일치 놓침), 위치 규칙(오른쪽 40%·아래 25%)이 두 틀 전체로 계산돼 오른쪽 틀만 표제란이 되어
    왼쪽 틀의 Rev 변경이 글자 변경이 됐다(뒤흔들기 DXF C4, 2026-10-23). 표제란 없는 사각형 둘(기기 외곽선 등)은 틀이 아니다."""
    if len(rects) < 2:
        return None

    def _area(r):
        return (r[2] - r[0]) * (r[3] - r[1])

    def _inside(a, b, pad):           # a가 b 안
        return a[0] >= b[0] - pad and a[1] >= b[1] - pad and a[2] <= b[2] + pad and a[3] <= b[3] + pad

    big = max(_area(r) for r in rects)
    pad0 = 1e-6 * max(1.0, big ** 0.5)
    maximal = [r for r in rects if not any(o != r and _inside(r, o, pad0) for o in rects)]
    cands = [r for r in maximal if _area(r) >= 0.25 * big]
    if not 2 <= len(cands) <= 12:
        return None
    for i, a in enumerate(cands):
        for b in cands[i + 1:]:
            ix = min(a[2], b[2]) - max(a[0], b[0])
            iy = min(a[3], b[3]) - max(a[1], b[1])
            if ix > 0 and iy > 0:
                return None
    pad = 0.01 * max(max(r[2] - r[0], r[3] - r[1]) for r in cands)

    def _where(x, y):
        for k, r in enumerate(cands):
            if r[0] - pad <= x <= r[2] + pad and r[1] - pad <= y <= r[3] + pad:
                return k
        return None

    def _nearest(x, y):
        return min(range(len(cands)), key=lambda k: max(cands[k][0] - x, 0, x - cands[k][2]) ** 2
                   + max(cands[k][1] - y, 0, y - cands[k][3]) ** 2)
    groups = [([], []) for _ in cands]
    inside = 0
    for it in out:
        k = _where(_lx(it), it[2])
        if k is not None:
            inside += 1
        groups[k if k is not None else _nearest(_lx(it), it[2])][0].append(it)
    for r in inserts:
        x, y = r["at"]
        k = _where(x, y)
        groups[k if k is not None else _nearest(x, y)][1].append(r)
    if not out or inside < 0.6 * len(out):
        return None
    for (items, ins) in groups:
        canons: set = set()
        for it in items:
            canons |= _title_canons(it[0])
        for r in ins:
            canons |= {_ATTR_CANON.get(a[5]) for a in r["attrs"]} & _CORE_TAGS
        if not ({"DWG_NO", "REV"} <= canons or len(canons & _CORE_TAGS) >= 3):
            return None
    # 위 줄부터(세로 범위가 겹치는 틀은 한 줄), 줄 안은 왼쪽부터 — 같은 구조의 두 판에서 차례가 같게
    order = sorted(range(len(cands)), key=lambda k: -cands[k][3])
    rows: list = []
    for k in order:
        for row in rows:
            r0 = cands[row[0]]
            if min(r0[3], cands[k][3]) - max(r0[1], cands[k][1]) > 0:
                row.append(k)
                break
        else:
            rows.append([k])
    seq = [k for row in rows for k in sorted(row, key=lambda q: cands[q][0])]
    return [groups[k] for k in seq]


def _extract_space(path: Path, space: str, doc=None, layout=None):
    out, inserts, theta = _unrotate(*_collect_raw(Path(path), space, doc, layout))
    if theta and space == "model":
        _ROTATED[str(path)] = theta
    rects = _model_rects(doc, theta) if space == "model" and layout is None and doc is not None else []
    frames = _sheet_frames(rects, out, inserts) if rects else None
    if not frames:
        attr_fields: dict = {}
        attr_rows = _sort_attributes(inserts, out, attr_fields)
        texts = [t for t in out if t[0]]
        return (texts,) + _extract_items(texts, attr_fields, attr_rows, space, rects)
    # 틀마다 따로 읽어 합친다 — 첫 틀(위·왼쪽)의 칸은 그대로, 다음 틀의 겹치는 칸은 번호를 붙여(REV#2) 싣는다(배치 여럿과 같게).
    # 개정표 행은 첫 틀 것이 개정표, 다음 틀 행은 글줄로(바뀌면 보이게)
    all_texts, fields, rows, lines = [], {}, [], []
    for k, (items, ins) in enumerate(frames):
        af: dict = {}
        ar = _sort_attributes(ins, items, af)
        tx = [t for t in items if t[0]]
        f_, r_, l_ = _extract_items(tx, af, ar, space, rects)
        all_texts += tx
        if k == 0:
            # 개정표가 첫 틀 것임을 위치에 적는다 — 둘째 틀 REV#2가 개정표 최신 행과 같다고 첫 틀의 '표제란 ≠ 개정표'를 말하지 않았다
            fields, rows = dict(f_), [Row(key=r.key, values=r.values, where=f"첫 틀 {r.where}") for r in r_]
        else:
            for key, v in f_.items():
                _merge_field(fields, key, v)
            lines += [TextLine(" ".join(x for x in (r.key, r.values.get("DATE", ""), r.values.get("DESCRIPTION", "")) if x),
                               f"틀 {k + 1} {r.where}") for r in r_]
        lines += l_
    _FRAMED.add(str(path))
    return all_texts, fields, rows, lines


_FRAMED: set = set()            # 틀 여럿으로 나눠 읽은 파일 (extract가 표제란 틀 범위를 첫 틀 칸으로만 잡고 지움)


def _extract_items(texts: list, attr_fields: dict, attr_rows: list, space: str, rects=None):
    tol = _y_tol(texts)
    if space == "paper":
        # 배치(레이아웃) 공간엔 보통 표제란 글자만 있다 — 위치 규칙을 매기면 그 글자들
        # 사이에서 사분면을 나눠 라벨이 본문으로 갔다 (2026-09-04 재검토 #11). 라벨 짝만
        # 라벨 짝으로 쓰이지 않은 배치공간 글자는 본문이다 — by_pos가 비어 있어 레이아웃 주석이 어디에도
        # 실리지 않았다 (검토21 감지 차단 1: 레이아웃 글자 변경을 "동일"이라 단언)
        title, revblock, body, by_pos = list(texts), [], [], {id(t) for t in texts}
    else:
        title, revblock, body, by_pos = _classify(texts, rects)
    # 표제란 자리에 놓인 ISO 꼴 개정 표는 리비전 블록으로 (검토68 A7). 표가 위치 규칙 구역 경계에 걸쳐 칸 일부가
    # 본문이 되기도 해 본문 글자도 함께 본다
    # 위치 규칙 리비전 블록(우상단) 글자도 — 개정표가 구역 경계에 걸치면 REV 칸('A'·'B')만 본문이 되어 행을 통째로 잃었다
    # (뒤흔들기 DXF, 레이어 이름에서 REV를 지운 세로 시트, 2026-10-23)
    # REV 레이어 글자는 이미 개정표다(_parse_revblock) — 위치로만 리비전 블록이 된 글자만 함께 본다. REV 레이어 개정표까지 넣으면
    # 그 머리 줄 바로 위 다른 레이어 주기('N1 앵커 재시공 2026-10-20 …')가 위로 쌓인 행으로 붙었다 (adv71 D71-06)
    _rest, _rt = _split_rev_table(title + body + [t for t in revblock if "REV" not in str(t[3]).upper()], tol)
    if _rt:
        _taken = {id(t) for t in _rt}
        title = [t for t in title if id(t) not in _taken]
        body = [t for t in body if id(t) not in _taken]
        revblock = [t for t in revblock if id(t) not in _taken]
    elif space == "paper":
        _rt = _bare_rev_rows(title, tol)
        if _rt:
            _taken = {id(t) for t in _rt}
            title = [t for t in title if id(t) not in _taken]
    fields, used = _parse_title(title, tol)
    for canon, (val, where) in attr_fields.items():
        fields.setdefault(canon, Field(canon, val, where))
    # 구역(우하단) 밖에 있어도 'REV: A'처럼 라벨과 값이 한 덩이면 표제란 값으로 읽는다.
    #
    # 구역은 **글자들의 좌표 범위**로 잡는데, 본문 글자가 표제란보다 아래에 있으면
    # 표제란이 '아래 25%' 밖으로 밀려 통째로 본문이 됐다 — 그러면 Rev 추적도,
    # 'Rev 미갱신' 검사도 그 도면에서 영영 안 돈다 (2026-09-10 경우의 수 매트릭스에서
    # 재현: 본문 글자 하나를 더했더니 표제란을 못 읽었다). 라벨 규칙(_INLINE_FIELD)은
    # 'REV' + 24자 이하 값 한 개로 좁아서 본문 문장을 잘못 집지 않는다.
    if body:
        leftovers = []
        for item in body:
            canon, value = _inline_field(item[0])
            if canon and canon not in fields:
                fields[canon] = Field(canon, value,
                                      f"표제란 밖(x={item[1]:.0f}, y={item[2]:.0f})")
            else:
                leftovers.append(item)
        body = leftovers
    # 우상단(리비전 블록 사분면)에 놓인 표제란도 같다 — 'DWG NO: E-101'이 거기 있으면
    # 필드가 아니라 글줄로 잡혀 도면번호 변경이 추가/삭제로 나오고 귀속이 폴더로
    # 떨어졌다 (검토19 감지 ⑫). REV는 리비전 표 해석에 맡긴다
    if revblock:
        keep = []
        for item in revblock:
            canon, value = _inline_field(item[0])
            if canon and canon != "REV" and canon not in fields:
                fields[canon] = Field(canon, value,
                                      f"표제란(우상단, x={item[1]:.0f}, y={item[2]:.0f})")
            else:
                keep.append(item)
        revblock[:] = keep
    revblock = revblock + _rt        # 떼어 낸 개정 표는 표제란 칸 읽기 없이 행으로만 (검토68 A7)
    # 위치 규칙(우하단)으로 표제란이 됐지만 라벨·값으로 쓰이지 않은 글자는 본문이다 —
    # P&ID·배치도의 우하단 사분면은 정상 내용 자리인데 비교에서 통째로 빠졌다
    # (2026-09-04 검토 extract H-1). 단, 다른 표제란 칸(CHECKED·SHEET…) 줄은 제외
    meta_ids = _meta_line_ids(title, tol)
    # 글자 표제란의 축척 칸('SCALE | 1:50', 'SCALE: 1:50') — 메타 줄로 본문에서 빠져 척도를 1:50→1:100으로 바꿔도 어디에도
    # 안 남았다 (검토42 B T04). 필드(META:SCALE)로 남겨 diff가 축척 변경으로 알린다
    if "META:SCALE" not in fields:
        for it in title:
            m_ = re.match(r"^\s*(SCALE|축척)(?![A-Za-z가-힣])\s*[:：.]?\s*(\S.*)?$", str(it[0]), re.I)   # '축척1:50' 붙여 쓴 꼴도 (검토44 A 낮음 3)
            if not m_:
                continue
            val_ = (m_.group(2) or "").strip()
            if not val_:
                right = sorted((x for x in title if x is not it and abs(x[2] - it[2]) <= tol and x[1] > it[1]),
                               key=lambda x: x[1])
                val_ = str(right[0][0]).strip() if right else ""
                # 축척 칸이 비어 오른쪽 이웃이 다른 표제란 라벨('SHEET')이면 값이 아니다 (검토43 A 낮음 1)
                if val_.upper().rstrip(":.") in _META_LABELS or val_.upper().rstrip(":.") in _LABEL_ALIASES:
                    val_ = ""
            if val_:
                fields["META:SCALE"] = Field("META:SCALE", val_, f"표제란(x={it[1]:.0f}, y={it[2]:.0f})")
                # 한 덩어리('SCALE 1:50')면 그 글자는 축척 칸이다 — 본문에도 남아 '글자 변경'으로 한 번 더 나오고 그것이
                # 'Rev 미갱신' 근거가 됐다(축척은 Rev 근거가 아닌데, 검토43 C 중간 6)
                meta_ids.add(id(it))
                break
    # 위치 규칙(by_pos)뿐 아니라 **레이어 이름**으로 표제란이 된 글자도 본문으로 돌려보낸다 —
    # 회사명 변경, 한 파일에 놓인 둘째 도면 틀의 REV B→C가 통째로 사라졌다 (검토33 C2)
    # 블록 속성 값(여섯째 칸 True)은 필드 전용 — 본문으로 내보내면 표제란 DATE만 바뀐 일괄 재출력이
    # 장마다 '변경 + 거짓 Rev 미갱신'이 되고, 'Rev만 갱신' 검사가 침묵한다 (검토34 B 차단 2)
    # 필드로 **실제로 쓰인** 속성(태그별 첫 값)과 서명·축척(META)만 본문에서 뺀다. 속성이면 모두 빼던
    # v0.57.15는 모든 글자가 표제란인 배치 공간에서 CLIENT·도면명 2행 같은 속성 변경을 '글자·표·그림
    # 동일'로 접었고, 둘째 도면 틀의 REV 변경도 다시 사라졌다 (검토35 A 차단)
    # 최종(검토35 B): 표준 표제란 태그(REV·DATE·DWG_NO·PROJECT·TITLE — 일곱째 칸 marker)와 서명·축척(META)
    # 속성은 **모두** 빼고, 그 밖의 속성(CLIENT 등, marker 없음)만 본문으로. '필드로 쓰인 첫 값만' 빼면
    # 둘째 틀 DATE가 글줄로 남아 날짜 접기를 넓혀야 했고, 그 확장이 납기일 문서의 날짜 변경까지 '표제란
    # 일자만'으로 접었다. 한 파일 둘째 틀의 독립 REV 변경은 v0.57.13처럼 못 잡는다(알려진 한계)
    body = body + [it for it in title
                   if id(it) not in used and id(it) not in meta_ids
                   and not (len(it) > 6 and it[6])]
    rev_rows, not_rev = _parse_revblock(revblock, tol)
    return fields, rev_rows + attr_rows, _merge_lines(body, tol, join_wrapped=True) + not_rev
    # 본문 MTEXT 여러 문단은 한 덩이 그대로 둔다 — 문단마다 쪼개면 같은 높이의 다른 TEXT와 한 줄로 붙고('…한다. 1500'),
    # 'M-101\PPUMP 7.5kW'의 태그가 사양을 잃어 도면-BOM 불일치가 사라졌다 (검토69 차단 1). TEXT 여러 줄 ↔ MTEXT 한 덩이
    # 대응(fmt66 D14)은 diff 쪽(_split_block_lines)에서 줄 단위로 맞춘다


def _merge_field(dst: dict, k: str, v: Field) -> None:
    """겹치는 칸은 번호를 붙여(REV#2) 싣는다 — 같은 구조의 두 판에서 번호가 같게 매겨진다. 서명·축척은 처음 것."""
    if k.startswith("META:"):
        dst.setdefault(k, v)
        return
    base = k.split("#", 1)[0]
    key, n = base, 1
    while key in dst:
        n += 1
        key = f"{base}#{n}"
    dst[key] = Field(key, v.value, v.where)


_XY_RE = re.compile(r"x=(-?\d+(?:\.\d+)?), y=(-?\d+(?:\.\d+)?)")


def _world_where(fields: dict, mirrored: dict | None) -> dict:
    """거울 삽입·돌출 -Z 글자로 읽은 칸의 근거 위치 x를 세계 좌표로 — 짝짓기는 OCS 좌표로 하지만 사람이 CAD에서 찾아갈 위치와
    표제란 틀(세계 좌표 블록 범위)은 세계 좌표다 (검토20 r03 5: 글자 근거 x=-340, 그림 근거 (340, 42)·틀 못 찾음)."""
    if not mirrored or not fields:
        return fields
    out = {}
    for k, f in fields.items():
        w = str(f.where or "")
        m = _XY_RE.search(w)
        if m:
            key = (round(float(m.group(1))), round(float(m.group(2))))
            wx = mirrored.get(key)
            if wx is not None:
                w = w[:m.start()] + f"x={wx:.0f}, y={m.group(2)}" + w[m.end():]
                f = Field(f.name, f.value, w, f.box)
        out[k] = f
    return out


def _title_box(doc, model_fields: dict, theta: float = 0.0) -> list | None:
    """모델 공간 표제란 칸들을 모두 감싸는 가장 작은 틀(닫힌 사각 폴리선 또는 속성 블록)의 범위.

    그 안의 그림 변경은 표제란 변경이다 — 회사 표준 표제란 블록으로 틀만 바꿨는데 틀 자리의 픽셀 차이가
    '그림 변경 3곳'이 되어 'Rev 미갱신'으로 팀장 메일에 올랐다 (검토39 P1 중간 1). 도면 테두리처럼 큰
    틀(가장 큰 틀의 35% 넘음)은 표제란이 아니다 — 모르면 None(그림 변경을 빼지 않는다)."""
    pts = []
    for f in model_fields.values():
        if f.name.startswith("META:"):
            continue
        m = _XY_RE.search(str(f.where))
        if m:
            pts.append(_rot_xy(float(m.group(1)), float(m.group(2)), -theta) if theta else (float(m.group(1)), float(m.group(2))))
    if len(pts) < 2:
        return None
    span = max(max(p[0] for p in pts) - min(p[0] for p in pts), max(p[1] for p in pts) - min(p[1] for p in pts))
    tol = max(1.0, span * 0.02)
    try:
        msp = doc.modelspace()
        rects = _frame_rects(msp, pts, tol, nested=False)
        got = _pick_title_rect(rects, pts, tol)
        if got is None:
            # 표제란 블록이 틀 블록 안에 중첩(A3 틀 블록 → 그 안 표제란 블록)이면 최상위에 닫힌 사각형도 속성 블록도 없어 틀을
            # 못 찾았다 — 일자만 고친 재발행의 표제란 칸 그림 차이가 '내용'이 되어 거짓 'Rev 미갱신', Rev만 올린 날은 'Rev만 갱신'이
            # 침묵했다 (검토20 r03 1). 최상위에서 못 찾을 때만 블록 안(3단까지)의 닫힌 사각형·속성 블록을 함께 본다
            got = _pick_title_rect(_frame_rects(msp, pts, tol, nested=True), pts, tol)
        return got
    except Exception:
        return None


_NESTED_FRAME_BUDGET = 20_000      # 표제란 틀 찾기에서 블록 안을 펼쳐 볼 가상 엔티티 수 상한


def _frame_rects(msp, pts: list, tol: float, nested: bool) -> list:
    """표제란 틀 후보 사각형 — 닫힌 폴리선과 표제란 칸 점 둘 이상 가까이 속성을 가진 블록 삽입의 범위.
    nested면 최상위 블록 삽입 안(3단까지)의 닫힌 폴리선·속성 블록도."""
    from ezdxf import bbox as _bbox
    rects: list = []

    def _poly(e) -> None:
        try:
            vs = [(float(v[0]), float(v[1])) for v in e.get_points("xy")]
            ex = e.dxf.get("extrusion", None)
            if ex is not None and (abs(float(ex[0])) > 1e-9 or abs(float(ex[1])) > 1e-9 or float(ex[2]) < 0):
                ocs = e.ocs()            # 거울 삽입 블록 안 폴리선의 꼭짓점은 OCS 좌표 (검토20 r03 5)
                vs = [(float(w[0]), float(w[1])) for w in (ocs.to_wcs((x, y, 0.0)) for x, y in vs)]
        except Exception:
            return
        if len(vs) >= 4 and (e.closed or vs[0] == vs[-1]):
            xs, ys = [v[0] for v in vs], [v[1] for v in vs]
            rects.append((min(xs), min(ys), max(xs), max(ys)))

    n = [0]

    def _attr_block(ins) -> None:
        atts = list(getattr(ins, "attribs", []) or [])
        if len(atts) < 2 or n[0] >= 20:
            return
        near = 0
        for a in atts:
            ap = wcs_insert(a)
            near += sum(1 for (x, y) in pts if abs(float(ap[0]) - x) <= tol and abs(float(ap[1]) - y) <= tol)
        if near < 2:
            return
        n[0] += 1
        ext = _bbox.extents(ins.virtual_entities(), fast=True)
        if ext.has_data:
            rects.append((ext.extmin.x, ext.extmin.y, ext.extmax.x, ext.extmax.y))

    if not nested:
        for e in msp.query("LWPOLYLINE"):
            _poly(e)
        for ins in msp.query("INSERT"):
            _attr_block(ins)
        return rects
    budget = [_NESTED_FRAME_BUDGET]

    def _walk(ins, depth: int) -> None:
        if depth <= 0 or budget[0] <= 0:
            return
        try:
            for ve in ins.virtual_entities():
                budget[0] -= 1
                if budget[0] <= 0:
                    return
                t = ve.dxftype()
                if t == "LWPOLYLINE":
                    _poly(ve)
                elif t == "INSERT":
                    _attr_block(ve)
                    _walk(ve, depth - 1)
        except Exception:
            return
    for e in msp.query("LWPOLYLINE"):
        _poly(e)
    for ins in msp.query("INSERT"):
        _attr_block(ins)
        _walk(ins, 3)
    return rects


def _pick_title_rect(rects: list, pts: list, tol: float) -> list | None:
    if not rects:
        return None

    def _area(r):
        return max(0.0, r[2] - r[0]) * max(0.0, r[3] - r[1])

    biggest = max(_area(r) for r in rects)
    big_h = max((r[3] - r[1] for r in rects if _area(r) == biggest), default=0.0)
    holding = [r for r in rects
               if all(r[0] - tol <= x <= r[2] + tol and r[1] - tol <= y <= r[3] + tol for x, y in pts)]
    if not holding or biggest <= 0:
        return None
    best = min(holding, key=_area)
    if _area(best) > 0.35 * biggest:
        return None
    # 도면 높이의 40%를 넘는 틀은 표제란 밖(본문 주기 띠 등)까지 품는다 — 그 안의 그림 변경이 '표제란 자리'로
    # Rev 근거에서 빠졌다 (검토40 A 중간 6). 칸 퍼짐 기준(×4)은 도면명·서명 칸까지 있는 실제 회사 표제란을 모두
    # 떨어뜨려 고침이 꺼졌다 (검토40 A 재확인 2-a). 세로로 긴 표제란은 모름(None)으로 — 그림 변경을 빼지 않는다
    if big_h > 0 and best[3] - best[1] > 0.4 * big_h:
        return None
    # 틀이 표제란 칸 위로 범례·주기까지 품으면(한 닫힌 틀) 그 자리 그림 변경이 '표제란 자리'로 빠졌다 — 세로 범위를
    # 칸 점 분포(+틀 높이 15% 여유)로 자른다 (검토42 B 중간 6). 칸이 없는 띠가 틀 높이의 30%를 넘을 때만 — 보통
    # 표제란(맨 위 칸 위 20% 여백)의 윗변까지 잘라 틀 교체가 본문 변경이 됐다
    ys = [y for _x, y in pts]
    h = best[3] - best[1]
    y0 = best[1] if min(ys) - best[1] <= 0.3 * h else max(best[1], min(ys) - 0.15 * h)
    y1 = best[3] if best[3] - max(ys) <= 0.3 * h else min(best[3], max(ys) + 0.15 * h)
    return [round(v, 1) for v in (best[0], y0, best[2], y1)]


_NON_ASCII = re.compile(r"[^\x00-\x7f]+")
_SINGLE_BYTE_CP = {"cp1250", "cp1251", "cp1252", "cp1253", "cp1254", "cp1255", "cp1256", "cp1257", "cp1258", "cp874"}


def _codepage_mismatch(doc) -> str | None:
    """$DWGCODEPAGE 머리말과 실제 글자 바이트가 다른 R2004 이하 DXF면 바른 인코딩 이름, 아니면 None.

    cp949 바이트에 ANSI_1252 머리말이면 '¸ðÅÍ 5.5kW', UTF-8 바이트에 ANSI_949 머리말이면 '紐⑦꽣 5.5kW'로 읽혀 모지바케가 그대로
    비교·메일에 실렸다 — 구형 ZWCAD·CADian·스크립트 산출 (재검토 2026-10-28 R6-6). 안전할 때만: 파일의 비ASCII 글자 덩이가
    **모두** 다른 인코딩으로 깨끗이 다시 풀리고, 풀린 글자 절반 이상이 한글 음절일 때. 서유럽 글자('Ø25'·'±0.1'·'45°')는 한
    글자 덩이라 cp949 두 바이트 꼴이 안 되어 그대로 남고, 진짜 cp949 한글은 UTF-8로 풀리지 않는다."""
    try:
        if str(doc.dxfversion) >= "AC1021":          # R2007 이상은 늘 UTF-8 — 머리말을 안 본다
            return None
        enc = re.sub(r"[-_]", "", str(getattr(doc, "encoding", "") or "").lower())
        if enc in _SINGLE_BYTE_CP:
            want = "cp949"
        elif enc in ("cp949", "cp936", "cp950", "cp932", "gbk", "big5", "shiftjis"):
            want = "utf8"
        else:
            return None
        runs: list = []
        for e in doc.entitydb.values():
            t = e.dxftype()
            if t in ("TEXT", "ATTRIB", "ATTDEF"):
                s = str(e.dxf.get("text", "") or "")
            elif t == "MTEXT":
                s = str(getattr(e, "text", "") or "")
            else:
                continue
            runs.extend(_NON_ASCII.findall(s))
            if len(runs) >= 400:
                break
        if not runs:
            return None
        out = []
        for r in runs:
            out.append(r.encode(enc, errors="surrogateescape").decode(want))
        got = "".join(out)
        hangul = sum(1 for c in got if "가" <= c <= "힣")
        return want if hangul and hangul * 2 >= len(re.sub(r"\s", "", got)) else None
    except (UnicodeError, LookupError, ValueError, AttributeError, TypeError):
        return None


def extract(path: Path) -> Document:
    _TRUNCATED.discard(str(path))
    _FRAMED.discard(str(path))
    _ROTATED.pop(str(path), None)
    _MIRRORED.pop(str(path), None)
    doc = ezdxf.readfile(path)                       # 한 번만 읽고 모델·배치 두 공간에 쓴다
    _enc = _codepage_mismatch(doc)
    if _enc:
        try:
            doc = ezdxf.readfile(path, encoding=_enc)    # 머리말이 틀린 파일 — 실제 바이트의 코드페이지로 다시 읽는다
        except Exception:
            pass
    texts, fields, rev_rows, raw = _extract_space(path, "model", doc)
    fields = _world_where(fields, _MIRRORED.get(str(path)))
    framed = str(path) in _FRAMED
    theta = _ROTATED.pop(str(path), 0.0)
    _FRAMED.discard(str(path))
    try:
        # 틀 여럿이면 첫 틀 칸으로만 — 두 틀 칸을 다 품는 사각형은 없다. 돌린 도면은 칸 좌표(되돌린 좌표)를 원래 자리로 돌려 찾는다
        tbox = _title_box(doc, {k: v for k, v in fields.items() if "#" not in k} if framed else fields, theta)
    except Exception:
        tbox = None
    notes: list = []
    if str(path) in _TRUNCATED:
        _TRUNCATED.discard(str(path))
        notes.append(f"블록이 너무 깊고 많아 {_EXPAND_BUDGET:,}개까지만 읽었습니다 — 그 너머의 "
                     f"블록 안 글자는 비교하지 못합니다 (심볼 라이브러리를 단순화하거나 문의)")
    # 배치(레이아웃) 공간은 **항상** 읽는다. 모델에 표제란이 있으면 배치는 아예 안 읽어, 레이아웃에
    # 둔 주석·표제란의 글자 변경을 놓치고도 "글자·표·그림 동일"이라 단언했다 (검토21 감지 차단 1).
    # 표제란·리비전 표는 모델 것이 우선, 배치 글줄은 '배치공간' 표시를 달아 본문에 더한다
    # 배치마다 **따로** 읽는다 — 한 목록에 섞으면 시트마다 있는 글자 표제란의 'REV A'·'REV B'가 한 줄로 붙고
    # 라벨·값 짝이 엇갈려 거짓 'Rev 미갱신'이 났다 (검토38 R4-A). 탭 순서로, 겹치는 칸은 번호를 붙여 합친다
    f2, rows2, raw2 = {}, [], []
    try:
        layouts = sorted((lo for lo in doc.layouts if not lo.is_modelspace),
                         key=lambda lo: int(getattr(lo.dxf, "taborder", 0) or 0))
    except Exception:
        layouts = []
    for lo in layouts:
        try:
            _t, fl, rl, rawl = _extract_space(path, "paper", doc, layout=lo)
        except Exception:
            continue
        name = str(getattr(lo, "name", "") or "")
        for k, v in fl.items():
            where = v.where if "배치 " in str(v.where) else f"배치 {name} {v.where}"
            _merge_field(f2, k, Field(k, v.value, where))
        if not rows2:
            rows2 = rl
        raw2 += [TextLine(t.text, f"{name} {t.where}", t.box) for t in rawl if t.text]
    f2 = _world_where(f2, _MIRRORED.pop(str(path), None))
    if not fields and f2:
        # 표제란이 배치(레이아웃) 공간에 있는 도면 — 모델 공간만 보면 Rev·도면번호를
        # 못 읽고도 고지가 없었다 (2026-09-04 검토 extract H-5)
        fields = f2
    elif f2:
        # 모델에도 배치에도 표제란이 있으면 배치 것을 버렸다 — 배치의 속성 표제란 REV B→C가 필드에도 글줄에도
        # 남지 않아 '재저장, 확인 대상 아님'으로 접혔다 (검토36 A N2). 모델에 없는 칸은 그대로, 겹치는 칸은
        # 번호를 붙여(REV#2) 싣는다 — 같은 구조의 두 판에서 번호가 같게 매겨진다
        for k, v in f2.items():
            _merge_field(fields, k, v)
    if not rev_rows:
        rev_rows = rows2
    if raw2:
        raw = list(raw) + [TextLine(t.text, f"배치공간 {t.where}", t.box) for t in raw2 if t.text]
    if texts and not fields:
        notes.append("표제란을 인식하지 못함 — Rev·도면번호 검사에서 제외됩니다 "
                     "(같은 줄에 'REV'·'DWG NO' 라벨과 값이 있거나 블록 속성 태그가 REV·DWG_NO면 인식됩니다)")
    try:
        _who = str(doc.header.get("$LASTSAVEDBY", "") or "").strip() or None
    except Exception:
        _who = None
    return Document(
        doc_type="dxf",
        path=str(path),
        fields=fields,
        revision_history=rev_rows,
        raw_texts=raw,
        notes=notes,
        title_box=tbox,
        saved_by=_who[:60] if _who else None,
    )
