# -*- coding: utf-8 -*-
"""PDF 추출기: 텍스트 추출 → 표제란 키워드(REV, DWG NO, PROJECT, DATE) 파싱.

도면이 DXF가 아니라 PDF로만 도는 현장 대비 (LOG 2026-08-21 결정).
엔진: pypdfium2 (구글 PDFium, BSD/Apache) — 판매 제품에 AGPL(PyMuPDF)을
쓸 수 없어 교체 (2026-08-26 결정, 원래 스택 원칙인 허용적 라이선스로 복귀).
"""

from __future__ import annotations

import re
from pathlib import Path

from watcher.extract.base import Document, Field, TextLine, date_qualified

# "DWG NO: DWG-P-301" / "REV : A" 꼴의 표제란 줄
_MULTI_FIELD_RE = re.compile(
    r"(?<![A-Za-z0-9가-힣_])(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|DOC\.?[ ._]*NO\.?|문서\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?\s*NO\.?|REV(?:ISION)?\.?|리비전|개정\s*번호|개정|DATE|일자|작성일|검사일|발주일)\s*[:：]\s*"
    r"(.+?)(?=\s+[A-Za-z가-힣][\w .()/-]{0,20}?\s*[:：]|\s*$)",
    re.IGNORECASE)
_FIELD_RE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|DOC\.?[ ._]*NO\.?|문서\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?\s*NO\.?|REV(?:ISION)?\.?|리비전|개정\s*번호|개정|DATE|일자|작성일|검사일|발주일)"
    r"\s*[:：.\-]\s*(.+?)\s*$",           # 'REV.A'·'REV-A'도 표제란 (검토31 B11)
    re.IGNORECASE,
)
# 칸이 나뉜 표제란(CAD 출력 PDF 대부분)은 콜론 없이 "REV   B", "DWG NO   E-001"처럼
# 라벨과 값이 같은 줄에 온다 — 값이 짧은 한 토큰일 때만 필드로 본다 (2026-09-04 검토 H-6)
_FIELD_NOCOLON_RE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|DOC\.?[ ._]*NO\.?|문서\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?\s*NO\.?|REV(?:ISION)?\.?|리비전|개정\s*번호|개정|DATE|일자|작성일|검사일|발주일)"
    r"\.?\s{1,}(\S{1,24})\s*$",
    re.IGNORECASE,
)
_CANON = {
    "DWG NO": "DWG_NO", "DWGNO": "DWG_NO", "DRAWING NO": "DWG_NO", "도면번호": "DWG_NO", "도면 번호": "DWG_NO",
    # 사양서·문서의 문서번호 — 'DOC NO: SPEC-E-1501  REV: 1' 한 줄이 통째로 본문이 되어 Rev 검사가 없었다 (검토38 R4-D)
    "DOC NO": "DOC_NO", "DOCNO": "DOC_NO", "문서번호": "DOC_NO", "문서 번호": "DOC_NO",
    "PROJECT": "PROJECT", "프로젝트": "PROJECT",
    "REV": "REV", "REVISION": "REV", "리비전": "REV",
    "REV NO": "REV", "REVISION NO": "REV",                     # 'REV. NO: 2' 검사성적서 (검토41 S2)
    "작성일": "DATE", "검사일": "DATE", "발주일": "DATE",
    "개정": "REV", "개정번호": "REV", "개정 번호": "REV",     # 한글 표제란 (검토38 R4-B)
    "DATE": "DATE", "일자": "DATE",
}

# PDFium 페이지 객체 유형 상수 (FPDF_PAGEOBJ_*)
_OBJ_TEXT, _OBJ_PATH, _OBJ_IMAGE = 1, 2, 3

# 페이지에 그림·이미지는 있는데 추출된 글자가 이보다 적으면 '텍스트 빈약 페이지'.
# CAD가 SHX 글꼴을 선(벡터)으로 변환해 출력한 PDF, 스캔본이 여기 해당한다.
_POOR_PAGE_CHARS = 40
_MIN_CONTENT_OBJS_WITH_TEXT = 50    # 글자를 조금 읽은 쪽은 선이 이만큼 넘어야(도면 본체·SHX 글자) 못 읽은 쪽 (검토65)
# 이 말머리로 시작하는 고지는 **비교를 막지 않는다** (cli._PARTIAL_NOTES와 짝)
PARTIAL_READ_NOTE = "일부 페이지의 글자만 읽었습니다"
# 표제란 칸 라벨(DWG NO·REV…)만 든 줄은 있는데 값과 짝짓지 못해 필드가 0개인 판 — 말머리는 cli._PARTIAL_NOTES(비교를 막지 않음).
# 소리 없이 Rev 검사가 꺼지던 것을 내용이 바뀐 날 '참고'로 알린다 (검토20 r07 1)
REV_UNPAIRED_NOTE = ("표제란을 인식하지 못함 — 표제란 칸 라벨(DWG NO·REV 등)은 있는데 값과 짝짓지 못해 "
                     "Rev 검사를 하지 못했습니다")
# 글자 없는 그림 쪽의 표지 줄 — 쪽 번호는 위치(where)에만 둔다. 글자에 넣으면 앞에 쪽이 끼어든 날 '3페이지→4페이지' 글자
# 변경이 됐다 (검토52 C 낮음 Q13). diff가 이 글자로 '그림이 된 쪽'을 알아본다
_BLANK_MARK = "[글자 없음 — 그림(스캔·벡터)이라 글자를 읽지 못함]"
_MIN_CONTENT_OBJS = 5  # 텍스트 외 객체(선·이미지)가 이보다 적으면 빈 페이지로 본다


# 콜론 없는 짝에서 값이 될 수 없는 낱말 — "REVISION HISTORY" 제목이 REV 값 'HISTORY'로
# 잡혀 Rev 미갱신 오탐을 만들던 것 (2026-09-04 재검토 ②-1)
_LABELISH = {"HISTORY", "DESCRIPTION", "TABLE", "LIST", "NO", "NO.", "DATE", "NAME", "BLOCK",
             "RECORD", "SHEET", "TITLE", "이력", "내역", "번호", "일자", "표",
             # 개정표 머리의 칸 이름 — 'REV DESCRIPTION DATE BY' 머리를 뒤섞어 그리면 'REV'·'BY'가 한 줄이 되어 표제란 REV가 'BY'로
             # 읽혀 거짓 'Rev 거꾸로'·'Rev 미갱신(BY 그대로)'이 났다 (2026-10-20 PDF 대량 시험 N1)
             "BY", "APPD", "APPD.", "APPR", "APPR.", "APP", "APP.", "APPROVED", "CHK", "CHK.", "CHKD", "CHECKED", "DRAWN",
             "DRN", "DSN", "DESIGNED", "REMARK", "REMARKS", "DESC", "DESC.", "작성", "검토", "승인", "확인", "담당"}
_SHORT_REV = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.\-]{0,5}$")
_KO_REV = re.compile(r"^제?\s*\d{1,2}\s*[차판]$")      # 한글 라벨의 '1차'·'제2판' (검토40 A 중간 4)


GARBLE_CHECK = True     # 시험용 끔 스위치
_GARBLE_RATIO = 0.2     # 쪽 글자 가운데 제어 문자·사용자 영역(PUA) 글자가 이 비율을 넘으면 '글자 못 읽은 쪽'
_GARBLE_MIN = 10        # 이보다 적은 글자의 쪽은 판정하지 않는다


def _garbled(text: str) -> bool:
    """ToUnicode 없는 내장 글꼴처럼 글자 코드가 문자로 풀리지 않은 쪽 — 제어 문자(U+0000–001F, 줄바꿈·탭 빼고)·사용자 영역
    글자가 20%를 넘는다. 그런 쪽의 '\\x10\\x14\\x13…'을 정상 글자로 비교·보고했고, 표제란까지 깨지면 Rev 검사·프로젝트 귀속이
    소리 없이 꺼졌다 (검토20 r07 2)."""
    s = [c for c in str(text or "") if c not in " \t\r\n"]
    if len(s) < _GARBLE_MIN:
        return False
    def _bad(c) -> bool:
        return ord(c) < 0x20 or 0xE000 <= ord(c) <= 0xF8FF or c in "�￾\x7f"
    if sum(1 for c in s if _bad(c)) > _GARBLE_RATIO * len(s):
        return True
    # 글꼴 하나(한글 서브셋 등)만 깨진 쪽 — 쪽 전체 비율은 낮아도 그 글꼴로 쓴 줄들이 통째로 제어 문자다. 깨진 줄이 둘 이상이고
    # 글줄의 4분의 1을 넘으면 같은 쪽으로 본다 (검토20 r07 2 C05)
    lines = [ln for ln in str(text or "").splitlines() if ln.strip()]
    broken = 0
    for ln in lines:
        cs = [c for c in ln if c not in " \t\r"]
        if len(cs) >= 4 and sum(1 for c in cs if _bad(c)) > 0.3 * len(cs):
            broken += 1
    return broken >= 2 and broken * 4 >= len(lines)


def _nocolon_value_ok(canon: str | None, value: str) -> bool:
    if canon is None or value.upper() in _LABELISH:
        return False
    if canon == "REV":
        return bool(_SHORT_REV.match(value))
    return True


def _canon_label(label: str) -> str | None:
    return _CANON.get(re.sub(r"[ ._]+", " ", label.upper()).strip().rstrip(". "))


# 글자가 없는 페이지(스캔본·SHX 출력)를 Windows OCR로 읽을지 — config `ocr` (기본 켬). 자식 프로세스에는
# config 요청으로 전달된다. OCR 글줄의 위치 표기는 'N페이지 OCR M행'이라 화면·브리핑이 추정값임을 안다
OCR_ENABLED = True
OCR_MAX_PAGES = 30             # 긴 스캔 매뉴얼은 앞 30쪽만 — 그림 기록 상한과 같다
import threading as _threading
_ctx = _threading.local()      # 미리보기(웹 스레드)만 쪽 상한을 낮춘다 — 전역을 건드리면 검사 스레드가 3쪽만 읽는다


def ocr_page_cap() -> int:
    return int(getattr(_ctx, "max_pages", OCR_MAX_PAGES))
_WORDISH = re.compile(r"^[A-Za-z가-힣]{3,}[.:,]?$")   # NOTE·PLATE·프레임 — 방향이 맞을 때만 나오는 낱말


_DATE_HEAD = re.compile(r"^\d{2,4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}\s*일?(?:\s*\d{1,2}:\d{2})?")   # 날짜 칸 값 (검토42 B 차단 2)


def _date_split(canon, val):
    """DATE 칸이면 (날짜 부분, 나머지) — 날짜 꼴이 아니면 (None, 값). 다른 칸은 (값, '')."""
    if canon != "DATE":
        return val, ""
    m = _DATE_HEAD.match(str(val or "").strip())
    if not m:
        return None, str(val or "")
    return m.group(0).strip(), str(val).strip()[m.end():].strip()


def _rest_to_body(line: str, pairs, where: str, body: list, box=None) -> None:
    """필드로 읽힌 '라벨: 값' 조각을 뺀 나머지가 글자면 본문 줄로 — 안 그러면 라벨 집합에 없는 칸('담당: 김')이나
    필드로 못 쓴 칸의 변경이 어디에도 안 남아 '내용 변경 없음'을 단언했다 (검토41 S2 차단 1)."""
    rest = line
    for lab, val in pairs:
        rest = re.sub(re.escape(lab) + r"\s*[:：]\s*" + re.escape(val), " ", rest, count=1, flags=re.I)
    # 표제 줄의 다른 일자 칸('APPROVED: 2026-09-01'·'DATE: …')도 본문에 둔다 — 날짜만 바뀐 글줄은 diff.is_title_date_text가
    # 일자 변경으로 접는다(검토42 A 중간 1). 여기서 버리면 바닥글 DATE만 고친 날 글자 근거가 사라져 픽셀 변경만 남아
    # 거짓 'Rev 미갱신'이 났고, '납기: 2026-10-05' 같은 내용 날짜까지 없어졌다 (검토42 B P01)
    rest = " ".join(rest.split())
    if re.search(r"[A-Za-z가-힣0-9]{2,}", rest):
        body.append(TextLine(rest, where, box))


_REVROW_LINE = re.compile(r"(?:DESCRIPTION|DESC\.|REMARKS?|내용|사유|비고)\s*[:：]", re.I)


def _take_line(line: str, where: str, fields: dict, body: list, box=None) -> str | None:
    """글줄 하나를 표제란 필드 또는 본문으로 — 진짜 글자와 OCR 글자가 같은 규칙을 탄다."""
    # 단, 도면번호·문서번호·프로젝트 칸이 같은 줄에 있으면 표제 줄이다 — 'DWG NO: … REV: B DESCRIPTION: 도면명'의 REV·DWG_NO가
    # 통째로 사라져 Rev 검사가 꺼졌다 (검토43 A 중간 1)
    # 표제 칸 판정은 **설명 라벨 앞부분**의 '라벨:' 꼴만 본다 — 설명에 '프로젝트 착수 발행'·'ISSUED FOR PROJECT REVIEW'가 있는
    # 개정표 행이 표제 줄로 오인돼 REV 0이 가로채졌다 (검토44 A 중간 2)
    _rr = _REVROW_LINE.search(line)
    if _rr and re.search(r"(?i)\bREV(?:ISION)?\b|개정", line) \
            and not re.search(r"(?i)(?:\b(?:DWG|DOC(?:UMENT)?|DRAWING)\.?\s*NO|도면\s*번호|문서\s*번호|\bPROJECT(?:\s*NO)?|프로젝트)"
                              r"\.?\s*[:：]", line[:_rr.start()]):
        # 개정표 행 — 표제란 REV로 가로채면 오래된 행이 위에 있는 개정표에서 'REV 3→4' 발행이 'Rev 0 그대로'로
        # 거꾸로 보고됐다 (검토42 B 중간 3). 본문 줄로 둔다(개정표 비교는 따로 한다)
        body.append(TextLine(line, where, box))
        return
    # 'DUE DATE:'·'DELIVERY DATE:'의 DATE는 표제 일자 칸이 아니다 — 납기가 표제 DATE가 되어 납기 변경이 '일자만 갱신'으로
    # 접혔다 (검토44 B 차단 1). 그 조각은 본문에 남는다(_rest_to_body)
    pairs = [m.groups() for m in _MULTI_FIELD_RE.finditer(line)
             if not (_canon_label(m.group(1)) == "DATE" and date_qualified(line[:m.start()]))]
    if len(pairs) >= 2 and MULTI_KEEP_GOOD:
        # 한 쌍이 꼴에 안 맞아도(REV 값 'A DATE. 2026-09-01' — 다음 라벨을 OCR이 'DATE.'로 읽음) 나머지 쌍은 살린다. 전에는 여러 쌍
        # 분기가 통째로 떨어져 _FIELD_RE가 띠 한 줄 전체를 DWG_NO 값으로 잡아 재스캔마다 거짓 표제란 변경 4건이 났다 (검토20 r07 3).
        # REV 값은 첫 토큰이 Rev 꼴이면 그것만(나머지는 본문)
        fixed = []
        for lab, val in pairs:
            if _canon_label(lab) == "REV" and not (_SHORT_REV.match(val) or _KO_REV.match(val)):
                tok = val.split()[0] if val.split() else ""
                if tok and _SHORT_REV.match(tok):
                    val = tok
            fixed.append((lab, val))
        good = [(lab, val) for lab, val in fixed
                if _canon_label(lab) and (_canon_label(lab) != "REV" or _SHORT_REV.match(val) or _KO_REV.match(val))]
        if len(good) >= 2:
            pairs = good
    if len(pairs) == 1 and _canon_label(pairs[0][0]) and _canon_label(pairs[0][0]) not in fields \
            and re.match(r"\s*" + re.escape(pairs[0][0]), line, re.I) \
            and (_canon_label(pairs[0][0]) != "REV" or _SHORT_REV.match(pairs[0][1]) or _KO_REV.match(pairs[0][1])) \
            and re.search(r"\s+[A-Za-z가-힣][\w .()/-]{0,20}?\s*[:：]", line[len(pairs[0][0]):]):
        # 'REV: B SCALE: 1:10', 'DATE: 2026-09-01 DRAWN: KIM' — 뒤에 다른 라벨이 이어지면 값은 그 앞까지 (리뷰12 낮음-E)
        canon1 = _canon_label(pairs[0][0])
        v1, tail1 = _date_split(canon1, pairs[0][1])
        if v1 is not None:
            fields[canon1] = Field(canon1, v1, f"표제란({where})", box)
            _rest_to_body(line, pairs[:1], where, body, box)       # 뒤의 다른 칸은 본문으로 (검토41 S2 차단 1)
            if tail1:
                body.append(TextLine(tail1, where, box))            # 날짜 뒤 글자('판정 합격')도 본문 (검토42 B 차단 2)
            return
    if len(pairs) >= 2 and all(_canon_label(lab)
                               and (_canon_label(lab) != "REV" or _SHORT_REV.match(val) or _KO_REV.match(val))
                               for lab, val in pairs) \
            and any(_canon_label(lab) not in fields for lab, val in pairs):
        # 'REV: A DATE: 2026-08-10'처럼 한 줄에 둘 이상 — 새 항목만 필드로 (2026-09-06 3차 42·43). 표지의 'DOC NO: X'가
        # 먼저 잡혀 있으면 뒤 쪽 'DOC NO: X  REV: A  DATE: d'의 REV·DATE까지 버려 Rev 검사가 없었다 (검토41 S2 차단 2).
        # 이미 있던 항목이 섞인 줄은 본문에도 두어 쪽별 변경이 보이게
        fresh = [(lab, val) for lab, val in pairs if _canon_label(lab) not in fields]
        # 이미 있던 항목 가운데 값이 같은 것(표지의 DOC NO가 바닥글에 되풀이)은 필드와 같은 말이다 — 줄째 본문에
        # 두면 일자만 고친 날 '글자 변경'이 한 번 더 잡혀 거짓 'Rev 미갱신'이 났다 (검토41 S2 재채점 P12).
        # 값이 **다른** 항목(세트 PDF의 쪽별 표제란)만 본문에 남겨 쪽별 변경이 보이게
        same = [(lab, val) for lab, val in pairs if (lab, val) not in fresh
                and str(fields[_canon_label(lab)].value).strip() == str(val).strip()]
        tails = []
        for lab, val in fresh:
            canon2 = _canon_label(lab)
            v2, tail2 = _date_split(canon2, val)
            if v2 is None:
                tails.append(f"{lab}: {val}")
                continue
            fields[canon2] = Field(canon2, v2, f"표제란({where})", box)
            if tail2:
                tails.append(tail2)
        _rest_to_body(line, fresh + same, where, body, box)
        for t in tails:
            body.append(TextLine(t, where, box))
        return
    # 사양서 바닥글 'SPEC-E-3902  REV: A  Page 1' — REV 라벨이 줄 첫머리가 아니고 값 뒤에 쪽 번호가 붙어 REV로 읽히지 않았다.
    # 그 문서는 Rev 미갱신·되돌림 검사가 영영 꺼졌다 (검토51 B 중간 1). 값은 첫 토큰(두 칸 이상·'Page' 앞)까지만
    # **바닥글 꼴일 때만** — 값 뒤에 쪽 표식이 있거나 라벨 앞에 문서번호 같은 글자가 있을 때. 홀로 선 'REV: A' 줄(세트 PDF의 쪽별
    # 표제란)까지 잡아 뒤 쪽의 REV 줄이 본문에서 빠졌고, 3쪽만 Rev를 올리면 'REV: B'가 글자 추가가 되어 거짓 'Rev 미갱신'이 났다
    # (검토52 B 중간 1)
    # 줄 가운데 외톨이 'ISSUED FOR CONSTRUCTION REV: 0'·'REFER TO DWG E-100 REV: B'는 바닥글이 아니다 — 앞 글자가 낱말 여럿이면
    # 표제란 REV를 가로챘다 (검토52 A 중간 1). 그래서 **쪽 표식**('Page 1'·'P.1'·'1/3'·'1쪽'·'Sheet 2')이 있거나, 앞이 문서번호
    # **한 토큰**('SPEC-E-3902')일 때만. 콜론 없는 'REV A'·'REV.A'·한글 '개정 A'·'|' 구분 꼴도 받는다 (검토52 C 중간 1)
    _fm = re.search(r"(?i)(?<![A-Za-z가-힣])(REV(?:ISION)?\.?|개정)\s*[:：.]?\s*([A-Za-z0-9]{1,3})(?![A-Za-z0-9가-힣])", line)
    _page_mark = re.search(r"(?i)(?:PAGE|P\.|SHEET)\s*\d|\d\s*(?:쪽|페이지)|(?:^|[\s|])\d+\s*/\s*\d+\s*$", line)
    _lead = line[:_fm.start()].strip(" |/") if _fm else ""
    _lead_ok = bool(re.fullmatch(r"[A-Za-z0-9][\w.\-/]*\d[\w.\-/]*", _lead))
    if _fm and (_page_mark or _lead_ok) and not re.search(r"(?i)HISTORY|DESCRIPTION|이력", line):
        _rv = _fm
        if _rv:
            tok = _rv.group(2)
            stripped = " ".join(re.sub(r"\|", " ", line[:_fm.start()] + " " + line[_fm.end():]).split())
            if "REV" not in fields:
                fields["REV"] = Field("REV", tok, f"표제란({where})", box)
                if re.search(r"[A-Za-z가-힣0-9]{2,}", stripped):
                    body.append(TextLine(stripped, where, box))
                return "footer_rev"           # 부르는 쪽이 줄째 본문에 또 넣지 않게
            if str(fields["REV"].value).strip() == tok:
                # 다음 쪽의 같은 바닥글 — REV를 빼고 둔다(쪽마다 같은 REV 올림이 '글자 변경'으로 겹치지 않게)
                if re.search(r"[A-Za-z가-힣0-9]{2,}", stripped):
                    body.append(TextLine(stripped, where, box))
                return
    m = _FIELD_RE.match(line)
    if m is None:
        m = _FIELD_NOCOLON_RE.match(line)
        if m is not None and not _nocolon_value_ok(_canon_label(m.group(1)), m.group(2)):
            m = None
    canon = _canon_label(m.group(1)) if m else None
    if canon == "REV" and re.search(r"[가-힣]", m.group(1)) and not _SHORT_REV.match(m.group(2).strip()) \
            and not _KO_REV.match(m.group(2).strip()):
        # 한글 '개정'은 본문 낱말이기도 해 값이 Rev 꼴(짧은 영숫자)일 때만 표제란 REV다 —
        # '개정 : 2026.09.01'·'개정: 사양 변경'이 REV를 가로채 거짓 'Rev 미갱신'이 났다 (검토39 F2 ①).
        # 영어 'REV: B (2026-09-01)'은 예전처럼 REV
        canon = None
    if canon == "DATE":
        v3, tail3 = _date_split(canon, m.group(2))
        if v3 is None:
            canon = None                     # '검사일: 재검사 예정' — 날짜가 아니면 본문
    if canon and canon not in fields:
        if canon == "DATE":
            fields[canon] = Field(canon, v3, f"표제란({where})", box)
            if tail3:
                body.append(TextLine(tail3, where, box))
        else:
            fields[canon] = Field(canon, m.group(2), f"표제란({where})", box)
    else:
        body.append(TextLine(line, where, box))


MULTI_KEEP_GOOD = True     # 시험용 끔 스위치 (검토20 r07 3)
# OCR이 라벨 뒤 콜론을 마침표·쉼표로 읽은 꼴('DATE. 2026-09-01') — 콜론으로 되돌린다. 값과 빈칸으로 떨어진 경우만 (검토20 r07 3)
_OCR_LABEL_DOT = re.compile(r"(?i)(?<![A-Za-z가-힣])(DWG\s*NO|DRAWING\s*NO|DOC\s*NO|REV(?:ISION)?|DATE|PROJECT|도면\s*번호|"
                            r"문서\s*번호|개정|일자)\s*[.,;]\s+(?=\S)")


def _ocr_label_fix(text: str) -> str:
    return _OCR_LABEL_DOT.sub(lambda m: f"{m.group(1)}: ", text) if MULTI_KEEP_GOOD else text


_OCR_SPLIT_DATE = re.compile(r"(\d{4})\s?([-./])\s?(\d{1,2})\s?([-./])\s?(\d)\s(\d)(?!\d)")


def _ocr_date_fix(text: str) -> str:
    """OCR이 좁은 숫자('11')를 '1 1'로 띄워 읽는 날짜를 붙인다 — 'DATE 2026-10-1 1'이 일자로 안 읽혀, 일자만 바꾼 스캔 재출력이
    '내용 변경, Rev 미갱신'이 됐다 (검토64 dry-week day9). 날짜 꼴 안의 띄어쓰기만."""
    # 달이 '1 1'로 띄워 읽힌 꼴('2026-1 1-01')도 — 11월 1일 재출력이 일자 칸을 잃어 '일자 삭제 + 글자 추가 → Rev 미갱신'이 됐다
    # (검토20 r07 3 작업 중 고정 벤치 dog10 day9가 11월에 실측). 달을 먼저 붙여야 '2026-1 1-1 1'의 날도 붙는다
    text = _OCR_SPLIT_MONTH.sub(lambda m: f"{m.group(1)}{m.group(2)}{m.group(3)}{m.group(4)}{m.group(5)}{m.group(6)}", text)
    return _OCR_SPLIT_DATE.sub(lambda m: f"{m.group(1)}{m.group(2)}{m.group(3)}{m.group(4)}{m.group(5)}{m.group(6)}", text)


_OCR_SPLIT_MONTH = re.compile(r"(\d{4})\s?([-./])\s?(1)\s([0-2])\s?([-./])\s?(\d{1,2})(?!\d)")


def _ocr_label_only(text: str) -> str | None:
    """OCR 글줄이 표제란 라벨 하나뿐인가('DWG NO'·'REV'·'일자') — 그러면 정규 라벨 이름."""
    t = " ".join(str(text or "").split()).strip(" :：")
    if not t or len(t) > 16:
        return None
    return _canon_label(t)


def _ocr_join_cells(lines: list) -> tuple[list, list, list]:
    """칸표 표제란을 OCR이 라벨 칸('DWG NO')과 값 칸('M-3101')을 따로 읽은 것을 같은 줄로 붙인다 — 따로 두면 표제란 필드를
    하나도 못 읽어 Rev 검사가 꺼졌다 (검토68 B2). 같은 행(세로 중심이 글자 높이 0.6배 안)·오른쪽·200pt 안의 가장 가까운
    값 줄만. 돌려주는 값: (붙인 글줄 목록, 짝 없는 라벨 줄 목록, 붙인 짝의 (라벨 x, 값 x) 목록)."""
    from watcher.ocr import OcrLine
    used: set = set()
    joined: dict = {}
    lone: list = []
    cols: list = []
    for i, lb in enumerate(lines):
        if _ocr_label_only(lb.text) is None:
            continue
        cy = lb.y + lb.h / 2
        best = None
        for j, v in enumerate(lines):
            if j == i or j in used or _ocr_label_only(v.text) is not None:
                continue
            if abs((v.y + v.h / 2) - cy) > 0.6 * max(lb.h, v.h) or v.x < lb.x + lb.w - 1 or v.x - (lb.x + lb.w) > 200:
                continue
            if best is None or v.x < lines[best].x:
                best = j
        if best is None:
            lone.append(lb)
            continue
        v = lines[best]
        used.add(best)
        cols.append((lb.x, v.x))
        top = min(lb.y, v.y)
        x1, y1 = max(lb.x + lb.w, v.x + v.w), max(lb.y + lb.h, v.y + v.h)
        joined[i] = OcrLine(f"{lb.text} {v.text}", lb.x, top, x1 - lb.x, y1 - top)
    out = [joined.get(i, ln) for i, ln in enumerate(lines) if i not in used]
    return out, lone, cols


def _ocr_lone_rev(page, label, cols: list):
    """값 칸이 한 글자('A')라 OCR이 버린 REV 칸 — Windows OCR은 홀로 선 한 글자를 읽지 않는다. 같은 표의 다른 값 칸이 시작하는
    x(값 열)에서 그 행의 값 글자를 잘라 라벨 글자 바로 뒤에 붙인 그림을 다시 읽어 'REV A'를 얻는다 (검토68 B2). 그림은 메모리에만."""
    if _canon_label(" ".join(label.text.split()).strip(" :：")) != "REV":
        return None
    # 같은 표 = 라벨 왼쪽 끝이 같은 열인 짝들 — 그 값 열의 x
    xs = sorted(vx for lx, vx in cols if abs(lx - label.x) <= max(2.0, label.h))
    if not xs:
        return None
    vx = xs[len(xs) // 2]
    try:
        from PIL import Image, ImageChops, ImageOps

        from watcher import ocr as _ocr
        from watcher.render import bitmap_pil
    except Exception:
        return None

    def _trim(im):
        bb = ImageChops.invert(im).point(lambda v: 255 if v > 60 else 0).getbbox()
        return im.crop(bb) if bb else None
    cy, hh = label.y + label.h / 2, label.h
    for dpi in (300, 250, 360):
        s = dpi / 72.0
        try:
            img = bitmap_pil(page.render(scale=s, grayscale=True)).convert("L")
        except Exception:
            return None
        lab = _trim(img.crop((int((label.x - 1) * s), int((cy - 0.9 * hh) * s),
                              int((label.x + label.w + 1) * s), int((cy + 0.9 * hh) * s))))
        val = _trim(img.crop((int((vx - 1) * s), int((cy - 0.9 * hh) * s),
                              int((vx + 8 * hh) * s), int((cy + 0.9 * hh) * s))))
        if lab is None or val is None or val.height > 2 * lab.height or val.width > 4 * lab.width:
            return None
        h = max(lab.height, val.height)
        for gk in (0.5, 0.7, 0.35):
            gap = max(2, int(h * gk))
            g = Image.new("L", (lab.width + gap + val.width, h), 255)
            g.paste(lab, (0, h - lab.height))
            g.paste(val, (lab.width + gap, h - val.height))
            g = ImageOps.expand(g, border=h, fill=255)
            try:
                got = _ocr.recognize_gray(g.tobytes(), g.width, g.height, s)
            except Exception:
                return None
            for ln in got:
                m = re.fullmatch(r"(?i)(REV(?:ISION)?\.?|개정|리비전)\s*([A-Za-z0-9]{1,2})", " ".join(ln.text.split()))
                if m:
                    return m.group(2).upper() if m.group(2).isalpha() else m.group(2)
    return None


def _ocr_page(page, pno: int, fields: dict, body: list) -> bool:
    """글자 없는 페이지를 OCR로 읽어 같은 규칙으로 넣는다. 읽은 글자가 40자 이상이거나 표제란 필드가 하나라도
    나오면 성공. 미달이면 뒤집힌·옆으로 누운 스캔일 수 있어 180°·90°·270°로 다시 읽어 가장 많이 읽힌 방향을
    쓴다 (리뷰12 중간-A: 뒤집힌 스캔이 쓰레기 글줄로 '읽힌 문서'가 되던 것)."""
    try:
        from watcher import ocr as _ocr
    except Exception:
        return False
    best_lines, best_words, best_fields, best_rot = [], 0, {}, 0
    best_lone, best_cols = [], []
    for rot in (0, 180, 90, 270):
        try:
            lines = _ocr.recognize_pdf_page(page, rotation=rot)
        except OSError:
            raise                        # 엔진 오류(WinRT) — 일시적일 수 있어 '비교 불가'로 캐시하지 않고 다음 검사에 다시 (리뷰12 운영 중간-1)
        except Exception:
            lines = []
        lines = [ln for ln in lines if len(ln.text) >= 2]      # 점·선을 글자로 읽은 한 글자 조각 제외
        # 칸표 표제란의 라벨 칸·값 칸을 한 줄로 (검토68 B2)
        lines, lone, cols = _ocr_join_cells(lines)
        f_try: dict = {}
        b_try: list = []
        for k, ln in enumerate(lines, start=1):
            _take_line(_ocr_label_fix(_ocr_date_fix(ln.text)), f"{pno}페이지 OCR {k}행", f_try, b_try)
        # 뒤집힌 스캔은 글자 수는 많아도 '낱말다운 토큰'(글자만 3자 이상)이 거의 없다 (리뷰13 ④-3)
        words = sum(1 for ln in lines for tok in ln.text.split() if _WORDISH.match(tok))
        if (f_try and not best_fields) or (bool(f_try) == bool(best_fields) and words > best_words):
            best_lines, best_words, best_fields, best_rot = lines, words, f_try, rot
            best_lone, best_cols = lone, cols
        if best_fields or best_words >= 8:
            break
    if not best_fields and best_words < 3:
        return False
    if best_rot == 0 and "REV" not in best_fields and best_lone and best_cols:
        # 한 글자 Rev 값('A')은 OCR이 버린다 — 값 칸을 라벨 뒤에 붙여 다시 읽는다 (검토68 B2)
        from watcher.ocr import OcrLine
        for lb in best_lone:
            rv = _ocr_lone_rev(page, lb, best_cols)
            if rv:
                best_lines = [OcrLine(f"{ln.text} {rv}", ln.x, ln.y, ln.w, ln.h) if ln is lb else ln for ln in best_lines]
                break
    for k, ln in enumerate(best_lines, start=1):
        # 자리는 돌리지 않고 읽었을 때만 — 돌린 좌표는 원래 페이지 좌표와 다르다
        box = (round(ln.x, 1), round(ln.y, 1), round(ln.x + ln.w, 1), round(ln.y + ln.h, 1)) if best_rot == 0 else None
        _take_line(_ocr_label_fix(_ocr_date_fix(ln.text)), f"{pno}페이지 OCR {k}행", fields, body, box)
    return True


# 내장 TrueType 글꼴의 cmap이 하이픈 글리프를 U+00AD(soft hyphen)·U+2010·U+2011로, 빈칸을 U+00A0으로 이어 둔 출력 —
# 같은 'E-101'이 'E\xad101'로 읽혀 글줄 삭제+추가·표제란 값 변경·거짓 'Rev 미갱신'이 났다 (2026-10-23 뒤흔들기 C9 40건).
# 보이는 글자가 같은 것만 추출 단계에서 하나로: 하이픈 꼴 → '-', 붙임 빈칸 꼴 → ' ', 합자(ﬁ·ﬂ…) → 풀어 쓴 글자.
# 빼기 기호(U+2212)·전각 글자는 그대로 — 다른 글자다(폭 바꿈은 diff._width_only가 따로 본다)
CHAR_NORM = True
_CHAR_MAP = {"­": "-", "‐": "-", "‑": "-", " ": " ", " ": " ", " ": " ",
             "ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl", "ﬅ": "st", "ﬆ": "st"}
_CHAR_TBL = str.maketrans(_CHAR_MAP)


def _norm_text(s: str) -> str:
    return s.translate(_CHAR_TBL) if CHAR_NORM and s else s


def _page_textpage(page):
    """쪽의 글자판. /Rotate 90·270 쪽인데 글자가 그리는 좌표에서 가로(각도 0·π)이면 회전을 잠시 0으로 두고 읽는다 —
    PDFium이 표시 방향으로 줄을 묶어 'REV'·'A'를 떼어 'REVA'로 붙이고 칸표 표제란 필드를 모두 놓쳤다 (검토68 B1).
    메모리 안 문서의 회전값만 잠시 바꾸고 곧바로 되돌린다(파일은 손대지 않음)."""
    textpage = page.get_textpage()
    try:
        rot = int(page.get_rotation() or 0) % 360
    except Exception:
        rot = 0
    if rot not in (90, 270):
        return textpage
    try:
        import math
        import pypdfium2.raw as _raw
        n = textpage.count_chars()
        horiz = 0
        for i in range(n):
            a = _raw.FPDFText_GetCharAngle(textpage.raw, i)
            if a >= 0 and min(abs(a), abs(a - math.pi), abs(a - 2 * math.pi)) < 0.2:
                horiz += 1
        if n == 0 or horiz * 2 <= n:
            return textpage                 # 그리는 좌표에서 이미 돌려 쓴 글자 — 표시 방향 읽기가 맞다
        textpage.close()
        page.set_rotation(0)
        try:
            return page.get_textpage()
        finally:
            page.set_rotation(rot)
    except Exception:
        return page.get_textpage()


def _page_text(textpage) -> str:
    """쪽 글자 (아래 _page_text_raw) — 하이픈·빈칸 꼴을 맞춘 것 (_norm_text)."""
    return _norm_text(_page_text_raw(textpage))


def _page_text_raw(textpage) -> str:
    """쪽 글자. 세로(90°·270°)로 쓴 글줄은 PDFium 영역 읽기(get_text_bounded)가 줄바꿈을 빼고 붙인다 — 표제란을 90° 돌린
    도면의 'DWG NO: E-101PROJECT: P66-P04REV: ADATE: …'가 한 줄이 되어 REV·PROJECT를 못 읽고 Rev 검사가 꺼졌다 (검토66
    P04·P13). 그 쪽에 세로 글자가 있고, 글자 순서 읽기(get_text_range)가 **줄바꿈만** 더 넣은 같은 글자일 때만 그것을 쓴다
    (쪽 밖 글자가 끼어드는 일 없이 — 공백을 뺀 글자가 똑같아야 한다)."""
    raw_b = textpage.get_text_bounded() or ""
    try:
        import math
        import pypdfium2.raw as _raw
        n = textpage.count_chars()
        vert = False
        for i in range(n):
            if _raw.FPDFText_IsGenerated(textpage.raw, i):
                continue
            a = _raw.FPDFText_GetCharAngle(textpage.raw, i)
            if a >= 0 and min(abs(a - math.pi / 2), abs(a - 3 * math.pi / 2)) < 0.2:
                vert = True
                break
        if not vert:
            return raw_b
        raw_r = textpage.get_text_range() or ""
    except Exception:
        return raw_b
    if raw_r != raw_b and re.sub(r"\s+", "", raw_r) == re.sub(r"\s+", "", raw_b) \
            and raw_r.count("\n") > raw_b.count("\n"):
        raw_b = raw_r
    split = _vertical_gap_split(textpage, raw_r)
    if split is not None and re.sub(r"\s+", "", split) == re.sub(r"\s+", "", raw_b) \
            and split.count("\n") > raw_b.count("\n") and _fields_kept(raw_b, split):
        return split
    return raw_b


def _vertical_gap_split(textpage, raw_r: str) -> str | None:
    """세로 글자의 칸 나누기 — 세로 띠 표제란의 '도면번호: …'·'개정: A'·'도면명: …'이 같은 세로 줄에 떨어져 놓이면 PDFium이
    한 줄로 이어 '도면번호: S-2501 프로젝트: … 도면명: 배수 계통'이 됐고, 칸 이름이 아닌 '도면명'이 섞여 그 줄이 Rev만 올린 날
    본문 글자 변경으로 남아 'Rev만 갱신'을 놓쳤다 (검토70 B, held69 P15). PDFium이 끼운 빈칸(생성 글자) 양옆이 같은 세로 열의
    같은 방향 글자이고, 둘 사이 빈 거리가 글자 크기(가로 폭 중앙값)의 2배를 넘으면 그 빈칸을 줄바꿈으로. 글자 순서 읽기와 글자가
    한 글자라도 다르면 쓰지 않는다."""
    import ctypes
    import math
    import statistics

    import pypdfium2.raw as _raw
    tp = textpage.raw
    n = textpage.count_chars()
    if n <= 0 or n > 200_000:
        return None
    chars, gen, ang, ox, box = [], [], [], [], []
    l_, r_, b_, t_ = (ctypes.c_double() for _ in range(4))
    x_, y_ = ctypes.c_double(), ctypes.c_double()
    for i in range(n):
        u = _raw.FPDFText_GetUnicode(tp, i)
        chars.append(chr(u) if 0 < u < 0x110000 else "�")
        g = bool(_raw.FPDFText_IsGenerated(tp, i))
        gen.append(g)
        a = _raw.FPDFText_GetCharAngle(tp, i)
        ang.append(a)
        _raw.FPDFText_GetCharOrigin(tp, i, ctypes.byref(x_), ctypes.byref(y_))
        _raw.FPDFText_GetCharBox(tp, i, ctypes.byref(l_), ctypes.byref(r_), ctypes.byref(b_), ctypes.byref(t_))
        ox.append(x_.value)
        box.append((l_.value, r_.value, b_.value, t_.value))
    if "".join(chars) != raw_r:
        return None

    def vert(i) -> bool:
        a = ang[i]
        return not gen[i] and a >= 0 and min(abs(a - math.pi / 2), abs(a - 3 * math.pi / 2)) < 0.2

    widths = [box[i][1] - box[i][0] for i in range(n) if vert(i) and box[i][1] - box[i][0] > 0.5]
    if not widths:
        return None
    size = statistics.median(widths)
    out = list(chars)
    changed = False
    for i in range(n):
        if not gen[i] or chars[i] != " ":
            continue
        p = i - 1
        while p >= 0 and gen[p]:
            p -= 1
        q = i + 1
        while q < n and gen[q]:
            q += 1
        if p < 0 or q >= n or not vert(p) or not vert(q) or abs(ang[p] - ang[q]) > 0.2 or abs(ox[p] - ox[q]) > size:
            continue
        gap = max(box[p][2] - box[q][3], box[q][2] - box[p][3])
        if gap > 2 * size:
            out[i] = "\n"
            changed = True
    return "".join(out) if changed else None


def _fields_kept(before: str, after: str) -> bool:
    """칸 나누기 뒤에도 표제란 칸을 하나도 잃지 않는가 — 칸표('REV' 칸과 'A' 칸이 떨어진 세로 표제란)를 나누면 라벨과 값이 다른 줄이
    되어 REV를 못 읽는다. 그런 쪽은 나누지 않는다 (검토70 B)."""
    def parse(txt):
        f: dict = {}
        for ln in txt.splitlines():
            if ln.strip():
                _take_line(ln.strip(), "0페이지 0행", f, [])
        return {k: str(v.value) for k, v in f.items()}
    a, b = parse(before), parse(after)
    return all(b.get(k) == v for k, v in a.items())


# ── 그리는 순서와 상관없는 줄 묶기 (2026-10-20 PDF 대량 시험 N11·N7) ─────────────────────────────────────────────
# PDFium 영역 읽기(get_text_bounded)는 글자를 **그린 순서대로** 줄로 묶는다 — 같은 내용을 다른 순서(뒤섞임·크기순·역순)로 다시
# 출력하면 표 칸이 낱줄로 쪼개지거나('REV'·'A'·'2026-08-01'이 따로) 이웃 행과 합쳐져(BOM 여러 행이 한 줄) 무변경 재출력이 거짓
# 변경이 되고, 개정표 행·표제란 칸을 못 읽었다(대량 시험 2,500건 N11 46건·N7 42건). 글자 상자 자리로 줄을 다시 짓는다:
#   ① 같은 방향 글자를 바탕선으로 묶고(행) 행 안은 읽는 방향 순서, 글자 사이가 띄어쓰기 폭이면 빈칸, 글자 높이 2배 넘는 틈은 칸
#   ② 가로 행의 칸은 한 줄로 잇되, 넓은 틈(글자 높이 8배 초과) 양쪽 칸이 **다른 덩어리**일 때만 다른 줄 — 한쪽만 위아래 이웃
#      행(표)이 있고 다른 쪽은 그 이웃 행에 칸이 없으면(왼쪽 주기 글과 오른쪽 BOM 행이 우연히 같은 바탕선) 따로. 개정표 행처럼
#      양쪽 칸이 같은 이웃 행에 함께 있으면 틈이 넓어도 한 줄. 40배 넘게 떨어지면 언제나 따로.
#      세로 글줄은 칸마다 따로(세로 띠 표제란 칸 — 검토70 B `_vertical_gap_split`과 같은 기준)
#   ③ 줄 차례는 덩어리(가로 범위가 겹치고 세로로 붙은 줄들 — 표 하나) 단위로 위→아래·왼→오른, 덩어리 안은 위→아래.
#      개정표 행이 머리 줄 바로 아래(위)에 이어져야 diff가 행으로 읽는다
#   ④ 칸 라벨만 든 행('TITLE  DRAWING NO.  REV.' — ISO 표제란 라벨 행)은 라벨마다 한 줄, 바로 아래 값 행은 라벨 열 경계(글자를
#      따로 그린 경계 가운데 가장 가까운 곳)에서 나눠 `_regroup_label_lines`가 라벨·값을 짝짓게
# 글자(공백 뺀 다중집합)가 PDFium 영역 읽기와 하나라도 다르면 쓰지 않고 예전 읽기로 (쪽 밖 글자 등).
LAYOUT_ENABLED = True
_LAYOUT_MAX_CHARS = 60_000
_LAYOUT_SPACE = 0.12        # 글자 높이 대비 이 폭 넘는 틈은 빈칸
_LAYOUT_PHRASE = 2.0        # 글자 높이 대비 이 폭 넘는 틈은 다른 칸(세로 글줄은 다른 줄)
_LAYOUT_JOIN = 8.0          # 가로 행: 이 폭까지의 칸 틈은 언제나 한 줄
_LAYOUT_FAR = 40.0          # 가로 행: 이 폭 넘게 떨어진 칸은 언제나 다른 줄


def _layout_chars(textpage, page):
    """글자 목록 [(글자, 방향 키, 각도, 느슨한 상자 (l, b, r, t), 원점 (x, y), 꼭 맞는 상자 (l, b, r, t), 글자 개체 번호, 글자 차례)] —
    PDF 좌표(y 위로). 각도는 읽는 방향(반시계)."""
    import ctypes
    import math

    import pypdfium2.raw as _raw
    tp = textpage.raw
    n = textpage.count_chars()
    if n <= 0 or n > _LAYOUT_MAX_CHARS:
        return None
    rc = _raw.FS_RECTF()
    l_, r_, b_, t_ = (ctypes.c_double() for _ in range(4))
    x_, y_ = ctypes.c_double(), ctypes.c_double()
    out = []
    q = math.pi / 2
    objs: dict = {}
    for i in range(n):
        if _raw.FPDFText_IsGenerated(tp, i):
            continue
        u = _raw.FPDFText_GetUnicode(tp, i)
        ch = _norm_text(chr(u)) if 0 < u < 0x110000 else ""
        if not ch or ch.isspace():
            continue
        a = float(_raw.FPDFText_GetCharAngle(tp, i))
        # PDFium 각도는 시계 방향(쪽 y 아래로) — 읽는 방향 각도(반시계)로
        a = 0.0 if a < 0 else (2 * math.pi - a) % (2 * math.pi)
        k = round(a / q)
        if abs(a - k * q) < 0.1:
            # 방향 키는 네 방향으로 누르되 각도는 실제 값(살짝 기운 출력 — 2026-10-23 뒤흔들기 C1)을 남긴다.
            # LAYOUT_TILT가 꺼져 있으면 예전처럼 눌러 쓴 각도
            key = k % 4
            a = (k % 4) * q + (a - k * q) if LAYOUT_TILT else (k % 4) * q
        else:
            key = round(a, 2)
            a = key
        if not _raw.FPDFText_GetLooseCharBox(tp, i, ctypes.byref(rc)):
            return None
        _raw.FPDFText_GetCharOrigin(tp, i, ctypes.byref(x_), ctypes.byref(y_))
        _raw.FPDFText_GetCharBox(tp, i, ctypes.byref(l_), ctypes.byref(r_), ctypes.byref(b_), ctypes.byref(t_))
        lb = (float(rc.left), min(rc.bottom, rc.top), float(rc.right), max(rc.bottom, rc.top))
        if lb[2] - lb[0] <= 0 and lb[3] - lb[1] <= 0:
            lb = (l_.value, b_.value, r_.value, t_.value)
        try:
            ov = ctypes.cast(_raw.FPDFText_GetTextObject(tp, i), ctypes.c_void_p).value or 0
        except Exception:
            ov = 0
        oid = objs.setdefault(ov, len(objs))
        out.append((ch, key, a, lb, (x_.value, y_.value), (l_.value, b_.value, r_.value, t_.value), oid, i))
    return out


LAYOUT_TILT = True          # 살짝 기운 글자는 실제 각도 축으로 바탕선을 잰다 (2026-10-23 뒤흔들기 C1)
_TILT_GAP = 0.004           # 같은 방향 키 안에서 실제 각도가 이만큼(rad, 약 0.23°) 넘게 벌어지면 다른 무리


def _tilt_groups(groups: dict):
    """방향 키별 글자를 실제 각도 무리로 나눠 [(키, 글자들, 바탕선 축 각도)] — 내용을 0.5~3° 돌려 그린 출력은 글자 각도가
    0이 아니라 0.01~0.05 rad다. 예전에는 0으로 눌러 놓고 그 축의 바탕선 차(글자 높이 0.3배)로 행을 묶어, 긴 글줄 끝이 아래 행과
    섞이거나 조각으로 쪼개졌다('토출 압력 (bar) 6.0 ± 0.' + '3', 'R' + 'EV DATE…' — 뒤흔들기 C1 211건). 무리마다 실제 각도의
    가운뎃값을 축으로 쓴다. 무리 경계는 정렬한 각도의 틈(_TILT_GAP)."""
    import math
    import statistics
    q = math.pi / 2
    for key, cs in groups.items():
        if not isinstance(key, int):
            yield key, cs, cs[0][2]
            continue
        base = key * q
        devs = sorted(((math.remainder(c[2] - base, 2 * math.pi)), n) for n, c in enumerate(cs))
        runs = [[devs[0]]]
        for p, d in zip(devs, devs[1:]):
            if d[0] - p[0] > _TILT_GAP:
                runs.append([d])
            else:
                runs[-1].append(d)
        for run in runs:
            dev = statistics.median(d for d, _n in run)
            yield key, [cs[n] for _d, n in sorted(run, key=lambda t: t[1])], base + (dev if abs(dev) > 1e-6 else 0.0)


LAYOUT_TRACKING = True      # 자간을 넓힌 글줄은 그 줄 글자 틈의 아래 사분위를 자간으로 보고 낱말 틈을 잰다 (2026-10-23 뒤흔들기 C3)
_TRACK_MIN = 0.05           # 글자 높이 대비 이보다 작은 자간은 자간 없음(예전 그대로)
_TRACK_MAX = 0.2            # 이보다 넓은 '자간'은 자간이 아니라 한 글자 낱말 사이 빈칸('A 1 B 2' — 빈칸 폭 ≈ 높이 0.25배)


def _row_gaps(row: list) -> list:
    """행 안 글자 사이 틈 [(틈 pt, 두 글자 높이 큰 쪽)] — 칸 틈(높이 2배 넘음)은 뺀다."""
    out = []
    for p, r in zip(row, row[1:]):
        hh = max(p["h"], r["h"])
        g = r["u0"] - p["u1"]
        if g <= _LAYOUT_PHRASE * hh:
            out.append((g, hh))
    return out


def _row_tracking(row: list, page_t: float = 0.0) -> float:
    """한 행(읽는 방향 차례로 정렬된 글자)의 자간(pt) — 글자 사이 틈(칸 틈 제외) 3개 이상의 아래 사분위가 글자 높이 0.05~0.2배일
    때만 그 값, 아니면 0. 자간(Tc 0.8~1.5pt)·낱말 간격(Tw)을 넓힌 출력은 모든 글자 틈이 빈칸 기준(높이 0.12배)을 넘어
    'V O L T A G E'·'D W G N O'가 되어 표제란 필드·글줄을 모두 잃었다(뒤흔들기 C3 51건). 자간은 줄 전체에 고르게 붙으므로 가장
    흔한(작은 쪽) 틈이 자간이고, 낱말 틈은 그보다 빈칸 폭만큼 더 넓다. 평범한 글줄은 아래 사분위가 0 근처라 바뀌지 않는다.
    PDF 자간(Tc)은 글자 크기와 상관없는 같은 길이라, 쪽 대부분의 행이 같은 자간(page_t)을 넓혔으면 틈이 3개 안 되는 짧은 행('REV 2')·
    작은 글자 행(높이 대비 0.2배를 넘는 라벨 행)도 가장 좁은 틈이 그 길이와 같을 때(±15%) 그 자간을 쓴다."""
    if not LAYOUT_TRACKING or len(row) < 2:
        return 0.0
    gaps = sorted(_row_gaps(row))
    if not gaps:
        return 0.0
    g, hh = gaps[len(gaps) // 4] if len(gaps) >= 3 else gaps[0]
    if len(gaps) >= 3 and _TRACK_MIN * hh < g < _TRACK_MAX * hh:
        return g
    if page_t and abs(g - page_t) <= 0.15 * page_t:
        return page_t
    return 0.0


def _page_tracking(rows: list) -> float:
    """쪽(같은 방향 무리)의 자간(pt) — 틈 3개 이상인 행의 절반 넘게 자간이 있고 그 길이가 고르면(가운뎃값 ±15% 안이 대부분)
    그 가운뎃값, 아니면 0."""
    if not LAYOUT_TRACKING:
        return 0.0
    n, ts = 0, []
    for row in rows:
        gaps = sorted(_row_gaps(row))
        if len(gaps) >= 3:
            n += 1
            g, hh = gaps[len(gaps) // 4]
            if _TRACK_MIN * hh < g < _TRACK_MAX * hh:
                ts.append(g)
    if n < 2 or len(ts) * 2 <= n:
        return 0.0
    ts.sort()
    t = ts[len(ts) // 2]
    if sum(1 for x in ts if abs(x - t) <= 0.15 * t) * 2 <= len(ts):
        return 0.0
    return t


LAYOUT_ROT_MAIN = True      # 내용을 통째로 90·180·270° 돌려 그린 쪽은 글자 다수 방향을 가로로 본다 (2026-10-23 뒤흔들기 C4)


class _LayLine(tuple):
    """(글줄, 쪽 자리) — fbox: 내용을 통째로 돌려 그린 쪽의 읽는 방향 좌표 자리(짝짓기용), 아니면 None."""
    fbox = None


def _main_key(groups: dict) -> int:
    """쪽 글자 다수의 방향 키(0·1·2·3) — 0이 아닌 방향이 쪽 글자의 70% 넘을 때만 그 키, 아니면 0. 내용을 CTM으로 90·270° 돌려 그린
    도면은 모든 글줄이 '세로 글줄'이라 칸마다 따로 끊겨 표 행·표제란 칸이 낱칸 줄이 됐다(뒤흔들기 C4 24건). 그 방향을 가로처럼
    칸을 잇고 줄 차례도 그 방향으로 매긴다(그 방향 행이 넷 이상일 때 — 세로 띠 표제란 한 줄뿐인 쪽은 예전처럼 칸마다 따로).
    0(가로) 글줄은 언제나 가로 규칙 그대로."""
    if not LAYOUT_ROT_MAIN:
        return 0
    cnt = {k: len(v) for k, v in groups.items() if isinstance(k, int)}
    tot = sum(len(v) for v in groups.values())
    if not cnt or not tot:
        return 0
    k = max(cnt, key=lambda q: cnt[q])
    return k if k and cnt[k] > 0.7 * tot else 0


LAYOUT_TABLE_SPLIT = True   # 같은 바탕선의 라벨 행 토막·값 행 토막만 ISO 짝짓기에 (2026-10-23 뒤흔들기 C19)
LAYOUT_CHAR_WORDS = True    # 글자마다 따로 그린 값 행은 붙은 글자를 낱말로 먼저 묶는다 (2026-10-23 뒤흔들기 C2)


def _label_run(phs: list, sps: list, text_of):
    """행의 칸 가운데 라벨만 든 칸이 둘 이상 이어진 토막 (시작, 끝) — 행 전체가 라벨이면 (0, n). 행 일부만이면 그 토막 양옆의 다른
    칸과 칸 잇기 폭(글자 높이 8배) 넘게 떨어져 있을 때만(같은 바탕선에 우연히 놓인 다른 표 조각 — 개정표·부품표 머리). 없으면 None."""
    n = len(phs)
    if n < 2:
        return None
    labs = [bool(_label_only(text_of(ph))) for ph in phs]
    if all(labs):
        return 0, n
    if not LAYOUT_TABLE_SPLIT:
        return None
    best = None
    k = 0
    while k < n:
        if not labs[k]:
            k += 1
            continue
        e = k
        while e < n and labs[e]:
            e += 1
        if e - k >= 2 and (best is None or e - k > best[1] - best[0]):
            best = (k, e)
        k = e
    if best is None:
        return None
    # 개정표 머리('REV  DATE  DESCRIPTION')는 라벨 토막(REV·DATE)이 있어도 표 머리 한 줄이다
    try:
        from watcher.diff import _REVTABLE_HEAD, _revtable_cols
        whole = " ".join(text_of(ph) for ph in phs)
        if _REVTABLE_HEAD.match(whole) or _revtable_cols(whole):
            return None
    except Exception:
        return None
    r0, r1 = best
    hh = max(sps[q][4] for q in range(max(0, r0 - 1), min(n, r1 + 1)))
    if r0 > 0 and sps[r0][0] - sps[r0 - 1][1] <= _LAYOUT_JOIN * hh:
        return None
    if r1 < n and sps[r1][0] - sps[r1 - 1][1] <= _LAYOUT_JOIN * hh:
        return None
    return best


def _value_pieces(val_phs: list) -> list:
    """ISO 값 행을 라벨 열에 나눌 조각 — 글 덩어리(글자 개체)마다, 한 개체 안이라도 칸 하나 넘게 떨어지면 따로. 글자마다 따로 그린
    출력(개체 대부분이 한 글자)은 개체가 낱말을 말해 주지 않아 칸을 넘친 값 'COOLING WATER ISO'의 'O'가 이웃 칸으로 가 'IO-1959'가
    됐다(뒤흔들기 C2) — 그때는 빈칸 없이 붙은(겹치지 않은) 글자를 낱말로 묶는다."""
    chars = [r for ph in val_phs for r in ph]
    objs: dict = {}
    for r in chars:
        objs.setdefault(r["c"][6], []).append(r)
    pieces = []
    if LAYOUT_CHAR_WORDS and len(chars) >= 2 and len(objs) >= 0.8 * len(chars):
        def adjoin(p, r):
            hh = max(p["h"], r["h"])
            g = r["u0"] - p["u1"]
            return -0.15 * hh <= g <= _LAYOUT_SPACE * hh + max(p.get("t", 0.0), r.get("t", 0.0))
        # ① 그린 차례로 이어 그린 붙은 글자(차례대로 그린 출력이면 낱말 — 겹친 이웃 칸 값과 섞이지 않는다)
        runs: list = []
        for r in sorted(chars, key=lambda r: r["c"][7]):
            if runs and r["u0"] >= runs[-1][-1]["u0"] and adjoin(runs[-1][-1], r):
                runs[-1].append(r)
            else:
                runs.append([r])
        # ② 자리로 붙은 조각끼리 한 낱말로(차례를 뒤섞어 그린 출력) — 끝 글자가 이 조각 첫 글자에 가장 꼭 붙는 낱말에.
        # 바로 앞 조각만 보면 이웃 칸 값('M-5174')이 넘친 값 끝('DIAGRA|M')과 겹칠 때 'M'이 이웃 칸으로 갔다
        runs.sort(key=lambda w: (w[0]["u0"], w[0]["u1"]))
        for w in runs:
            cand = [pc for pc in pieces if adjoin(pc[-1], w[0])]
            if cand:
                min(cand, key=lambda pc: abs(w[0]["u0"] - pc[-1]["u1"])).extend(w)
            else:
                pieces.append(list(w))
        return pieces
    for grp in objs.values():
        grp.sort(key=lambda r: (r["u0"], r["u1"]))
        wd = [grp[0]]
        for p, r in zip(grp, grp[1:]):
            if r["u0"] - p["u1"] > _LAYOUT_PHRASE * max(p["h"], r["h"]):
                pieces.append(wd)            # 한 개체 안이라도 칸 하나 넘게 떨어지면 따로
                wd = [r]
            else:
                wd.append(r)
        pieces.append(wd)
    return pieces


def _layout_lines(textpage, page):
    """그리는 순서와 상관없는 쪽 글줄 [(글줄, 자리 (x0, y0, x1, y1) 쪽 왼쪽 위 원점)] — 못 지으면 None (위 설명)."""
    import math
    import statistics
    try:
        chars = _layout_chars(textpage, page)
    except Exception:
        return None
    if not chars:
        return None
    # 자리는 돌리기 전 쪽(글자 좌표계)의 왼쪽 위 원점 — /Rotate 90·270 쪽은 보이는 너비가 돌리기 전 높이
    try:
        _rot = int(page.get_rotation() or 0) % 360
    except Exception:
        _rot = 0
    H = float(page.get_width() if _rot in (90, 270) else page.get_height())

    def text_of(rs):
        s = rs[0]["c"][0]
        for p, r in zip(rs, rs[1:]):
            if r["u0"] - p["u1"] > _LAYOUT_SPACE * max(p["h"], r["h"]) + max(p.get("t", 0.0), r.get("t", 0.0)):
                s += " "
            s += r["c"][0]
        return s

    def box_of(rs):
        x0 = min(r["c"][5][0] for r in rs)
        x1 = max(r["c"][5][2] for r in rs)
        y0 = H - max(r["c"][5][3] for r in rs)
        y1 = H - min(r["c"][5][1] for r in rs)
        return (round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1))

    def span(rs):
        return (min(r["u0"] for r in rs), max(r["u1"] for r in rs), min(r["v0"] for r in rs), max(r["v1"] for r in rs),
                max(r["h"] for r in rs))

    groups: dict = {}
    for c in chars:
        groups.setdefault(c[1], []).append(c)
    main_key = _main_key(groups)
    lines = []          # dict(key, rs=[글자…], segs=[[글자…] 칸…]) — 칸은 ' '로 잇는다
    for key, cs, a in _tilt_groups(groups):
        ca, sa = math.cos(a), math.sin(a)

        def uv(x, y, ca=ca, sa=sa):
            return x * ca + y * sa, x * sa - y * ca
        recs = []
        for c in cs:
            l, b, r, t = c[3]
            pts = [uv(l, b), uv(r, b), uv(l, t), uv(r, t)]
            us, vs = [p[0] for p in pts], [p[1] for p in pts]
            recs.append(dict(c=c, u0=min(us), u1=max(us), v0=min(vs), v1=max(vs), vb=uv(*c[4])[1],
                             h=max(0.5, max(vs) - min(vs))))
        recs.sort(key=lambda r: (r["vb"], r["u0"]))
        rows: list = []
        for r in recs:
            if rows and abs(r["vb"] - rows[-1][0]["vb"]) <= 0.3 * max(r["h"], rows[-1][0]["h"]) \
                    and abs(r["vb"] - rows[-1][-1]["vb"]) <= 0.3 * max(r["h"], rows[-1][-1]["h"]):
                rows[-1].append(r)
            else:
                rows.append([r])
        # 행마다 칸(틈 > 글자 높이 2배)
        R = []
        for row in rows:
            row.sort(key=lambda r: (r["u0"], r["u1"]))
        _pr = _page_tracking(rows)
        for row in rows:
            t_ = _row_tracking(row, _pr)
            if t_:
                for r in row:
                    r["t"] = t_
            phs = [[row[0]]]
            end = row[0]["u1"]
            for p, r in zip(row, row[1:]):
                if r["u0"] - end > _LAYOUT_PHRASE * max(p["h"], r["h"]) + t_:
                    phs.append([r])
                else:
                    phs[-1].append(r)
                end = max(end, r["u1"])
            sp = span(row)
            R.append(dict(phs=phs, sp=[span(ph) for ph in phs], u0=sp[0], u1=sp[1], v0=sp[2], v1=sp[3], h=sp[4],
                          vb=statistics.median(r["vb"] for r in row)))
        R.sort(key=lambda x: x["v0"])
        # 위아래 이웃 행 (세로 틈이 글자 높이 1.6배 안)
        nb: list = [[] for _ in R]
        for i, ri in enumerate(R):
            for j in range(i + 1, len(R)):
                rj = R[j]
                g = rj["v0"] - ri["v1"]
                if g > 1.6 * max(ri["h"], 40.0):
                    break
                if g <= 1.6 * max(ri["h"], rj["h"]) and abs(rj["vb"] - ri["vb"]) > 0.3 * max(ri["h"], rj["h"]):
                    nb[i].append(j)
                    nb[j].append(i)

        def users(i, s0, s1, hh):
            """이웃 행 가운데 [s0, s1] 가로 범위에 칸이 있는 행 번호."""
            got = set()
            for j in nb[i]:
                if any(min(s1, q[1]) - max(s0, q[0]) > -0.5 * hh for q in R[j]["sp"]):
                    got.add(j)
            return got

        done: set = set()
        for i, ri in enumerate(R):
            if i in done:
                continue
            phs = ri["phs"]
            # ④ ISO 표제란 라벨 행 — 라벨만 든 칸이 둘 이상 이어진 토막(행 전체, 또는 같은 바탕선의 다른 표 조각과 칸 잇기 폭 넘게
            # 떨어진 토막 — 2026-10-23 뒤흔들기 C19)
            run = _label_run(phs, ri["sp"], text_of)
            if run is not None:
                r0, r1 = run
                lab_phs = phs[r0:r1]
                rest_l, rest_r = phs[:r0], phs[r1:]
                below, below_sel = None, None
                L0 = lab_phs[0][0]["u0"]
                steps = [b[0]["u0"] - a[0]["u0"] for a, b in zip(lab_phs, lab_phs[1:])]
                L1 = lab_phs[-1][0]["u0"] + max(steps + [3 * ri["h"]])
                for j in nb[i]:
                    rj = R[j]
                    if j in done or rj["vb"] <= ri["vb"] or rj["v0"] - ri["v1"] > 1.5 * max(ri["h"], rj["h"]):
                        continue
                    if LAYOUT_TABLE_SPLIT:
                        sel = [k for k, ph in enumerate(rj["phs"]) if L0 - 3 * rj["h"] <= ph[0]["u0"] < L1]
                    else:
                        sel = list(range(len(rj["phs"]))) if rj["u0"] >= L0 - 3 * rj["h"] else []
                    if not sel or all(_label_only(text_of(rj["phs"][k])) for k in sel):
                        continue
                    if below is None or rj["v0"] < R[below]["v0"]:
                        below, below_sel = j, sel
                for ph in lab_phs:
                    lines.append(dict(key=key, rs=ph, segs=[ph]))
                for rest in (rest_l, rest_r):
                    if rest:
                        lines.append(dict(key=key, rs=[r for ph in rest for r in ph], segs=rest))
                done.add(i)
                if below is not None:
                    # 값 행은 따로 그린 글 덩어리(글자 개체 — 낱말로 쪼개 그린 출력이면 낱말)마다 첫 글자 자리로 라벨 열에 넣는다.
                    # 칸을 넘친 값('SINGLE LINE DIAGRAM'의 끝)이 이웃 칸 값('I-9651')과 겹쳐도 섞이지 않게
                    cuts = [ph[0]["u0"] - 0.5 * ph[0]["h"] for ph in lab_phs[1:]]
                    rb = R[below]
                    val_phs = [rb["phs"][k] for k in below_sel]
                    pieces = _value_pieces(val_phs)
                    segs: list = [[] for _ in range(len(lab_phs))]
                    for pc in sorted(pieces, key=lambda w: (w[0]["u0"], w[0]["u1"])):
                        segs[sum(1 for cu in cuts if pc[0]["u0"] >= cu)].append(pc)
                    for sg in segs:
                        if sg:
                            rs_ = [r for pc in sg for r in pc]
                            lines.append(dict(key=key, rs=rs_, segs=[rs_]))
                    left = [ph for k, ph in enumerate(rb["phs"]) if k not in below_sel]
                    if left:
                        # 같은 바탕선의 다른 표 조각(개정표 머리 등)은 따로 남겨 ② 칸 잇기로
                        sp_ = span([r for ph in left for r in ph])
                        rb.update(phs=left, sp=[span(ph) for ph in left], u0=sp_[0], u1=sp_[1], v0=sp_[2], v1=sp_[3], h=sp_[4])
                    else:
                        done.add(below)
                continue
            # ② 칸 잇기
            cur = [phs[0]]
            for k in range(1, len(phs)):
                A, B = ri["sp"][k - 1], ri["sp"][k]
                hh = max(A[4], B[4])
                gap = B[0] - A[1]
                join = True
                if key != 0 and not (key == main_key and len(R) >= 4):
                    # 세로 글줄은 칸마다 따로 — 단 라벨만 든 칸('REV')과 바로 다음 값 칸('A')은 한 줄(세로 띠 칸표, adv69 B70_V2)
                    _lab = _label_only(text_of(phs[k - 1]))
                    join = bool(_lab and _lab != "META" and gap <= _LAYOUT_JOIN * hh
                                and _label_value_ok(_lab, text_of(phs[k])))
                elif gap > _LAYOUT_FAR * hh:
                    join = False
                elif gap > _LAYOUT_JOIN * hh:
                    ua, ub = users(i, A[0], A[1], hh), users(i, B[0], B[1], hh)
                    join = (not ua and not ub) or bool(ua & ub)
                if join:
                    cur.append(phs[k])
                else:
                    lines.append(dict(key=key, rs=[r for ph in cur for r in ph], segs=cur))
                    cur = [phs[k]]
            lines.append(dict(key=key, rs=[r for ph in cur for r in ph], segs=cur))
            done.add(i)
    for ln in lines:
        sp = span(ln["rs"])
        ln["u0"], ln["u1"], ln["v0"], ln["v1"], _hmax = sp
        ln["vb"] = statistics.median(r["vb"] for r in ln["rs"])
        ln["h"] = statistics.median(r["h"] for r in ln["rs"])
        ln["box"] = box_of(ln["rs"])
        ln["text"] = " ".join(text_of(sg) for sg in ln["segs"])
    # ③ 덩어리: 같은 방향·가로 범위 겹침·세로로 붙은 줄 (표 하나)
    m = len(lines)
    par = list(range(m))

    def find(i):
        while par[i] != i:
            par[i] = par[par[i]]
            i = par[i]
        return i
    order = sorted(range(m), key=lambda i: (str(lines[i]["key"]), lines[i]["v0"]))
    for oi, i in enumerate(order):
        a = lines[i]
        for j in order[oi + 1:]:
            b = lines[j]
            if b["key"] != a["key"] or b["v0"] - a["v1"] > 1.6 * max(a["h"], 40.0):
                break
            hh = max(a["h"], b["h"])
            if b["v0"] - a["v1"] <= 1.6 * hh and min(a["u1"], b["u1"]) - max(a["u0"], b["u0"]) > -0.5 * hh:
                par[find(i)] = find(j)
    blocks: dict = {}
    for i in range(m):
        blocks.setdefault(find(i), []).append(i)
    blist = []
    if main_key:
        # 내용 전체를 90·180·270° 돌려 그린 쪽 — 덩어리 차례는 그 방향(읽는 방향)의 위→아래·왼→오른
        _am = main_key * (math.pi / 2)
        _ca, _sa = math.cos(_am), math.sin(_am)
        for ln in lines:
            pts = [(x, y) for r in ln["rs"] for x in (r["c"][5][0], r["c"][5][2]) for y in (r["c"][5][1], r["c"][5][3])]
            ln["ftop"] = min(x * _sa - y * _ca for x, y in pts)
            ln["fleft"] = min(x * _ca + y * _sa for x, y in pts)
    for idx in blocks.values():
        idx.sort(key=lambda i: (round(lines[i]["vb"], 1), lines[i]["u0"]))
        if main_key:
            top = min(lines[i]["ftop"] for i in idx)
            left = min(lines[i]["fleft"] for i in idx)
        else:
            top = min(lines[i]["box"][1] for i in idx)
            left = min(lines[i]["box"][0] for i in idx)
        blist.append((round(top / 2), round(left / 2), top, left, idx))
    blist.sort(key=lambda b: b[:4])
    out = []
    for *_k, idx in blist:
        for i in idx:
            ll = _LayLine((lines[i]["text"], lines[i]["box"]))
            if main_key:
                ln = lines[i]
                pts = [(x, y) for r in ln["rs"] for x in (r["c"][5][0], r["c"][5][2]) for y in (r["c"][5][1], r["c"][5][3])]
                us = [x * _ca + y * _sa for x, y in pts]
                vs = [x * _sa - y * _ca for x, y in pts]
                ll.fbox = (round(min(us), 1), round(min(vs), 1), round(max(us), 1), round(max(vs), 1))
            out.append(ll)
    return out


def _layout_text_ok(lay: list, raw_b: str) -> bool:
    """새로 지은 글줄이 PDFium 영역 읽기와 같은 글자(공백 뺀 다중집합)인가."""
    from collections import Counter
    a = Counter(ch for t, _b in lay for ch in t if not ch.isspace())
    b = Counter(ch for ch in raw_b if not ch.isspace())
    return a == b


def page_text_lines(textpage, page) -> list | None:
    """추출기가 쓰는 쪽 글줄과 자리 [(글줄, (x0, y0, x1, y1) 돌리기 전 쪽 왼쪽 위 원점)] — 그림 비교가 바뀐 글줄 자리를 가릴 때
    PDFium 글자 찾기(그린 순서 글)로는 따로 그린 '개정'·'1' 칸을 '개정 1'로 못 찾아 Rev 올림 칸이 덤 '그림 변경'이 되고
    'Rev만 갱신'이 침묵했다 (2026-10-20 PDF 대량 시험 N7·N10). 새 줄 묶기를 못 쓰는 쪽은 None."""
    if not LAYOUT_ENABLED:
        return None
    lay = _layout_lines(textpage, page)
    if lay is None or not _layout_text_ok(lay, _page_text(textpage)):
        return None
    strip = [t.strip() for t, _b in lay]
    boxes = [b for _t, b in lay]
    if any(_label_only(s) for s in strip):
        rg = _regroup_label_lines(strip, boxes, [getattr(x, "fbox", None) or x[1] for x in lay])
        if rg is not None:
            return [(t, b) for t, b in rg]
    return list(zip(strip, boxes))


def _revtable_page(lines: list) -> bool:
    """쪽에 개정표 머리 줄('REV DATE DESCRIPTION'·'NO. DATE REVISION' 꼴)이 있는가 — 그런 쪽만 글줄 자리를 남긴다."""
    try:
        from watcher.diff import _REVTABLE_HEAD, _revtable_cols
    except Exception:
        return False
    return any(_REVTABLE_HEAD.match(s) or _revtable_cols(s) for s in lines if s)


def _line_boxes(textpage, page, lines: list) -> list:
    """글줄마다 자리 (x0, y0, x1, y1 — 쪽 왼쪽 위 원점 pt), 글자 상자로 못 맞춘 줄은 None. 개정표 행 묶음을 글 흐름 이웃으로만 모아
    쪽 왼쪽 위에 따로 선 일정 행('1 2026-11-15 FAT TEST')이 개정표 행이 되어 거짓 '표제란 ≠ 개정표'가 났다 (검토71 R3 B71-04) —
    diff가 머리 줄과 같은 열·행 높이 안의 줄만 묶도록 자리를 준다. PDFium 글자 순서와 글줄 글자를 앞에서부터 맞춘다."""
    out: list = [None] * len(lines)
    try:
        import pypdfium2.raw as _raw
        n = textpage.count_chars()
        if n <= 0 or n > 200_000:
            return out
        h = float(page.get_height())
        stream = []
        for i in range(n):
            if _raw.FPDFText_IsGenerated(textpage.raw, i):
                continue
            u = _raw.FPDFText_GetUnicode(textpage.raw, i)
            ch = _norm_text(chr(u)) if 0 < u < 0x110000 else ""
            if not ch or ch.isspace():
                continue
            stream.extend((c_, i) for c_ in ch)
    except Exception:
        return out
    cur = 0
    for li, line in enumerate(lines):
        chars = [c for c in line if not c.isspace()]
        if not chars:
            continue
        pos, k = [], cur
        for c in chars:
            j = k
            while j < len(stream) and j - k <= 8 and stream[j][0] != c:
                j += 1
            if j >= len(stream) or stream[j][0] != c:
                pos = None
                break
            pos.append(stream[j][1])
            k = j + 1
        if not pos:
            continue
        cur = k
        try:
            bs = [textpage.get_charbox(i) for i in pos]
        except Exception:
            continue
        x0, x1 = min(b[0] for b in bs), max(b[2] for b in bs)
        y0, y1 = h - max(b[3] for b in bs), h - min(b[1] for b in bs)
        if x1 > x0 and y1 > y0:
            out[li] = (round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1))
    return out


_TB_META_LABELS = {"TITLE", "DWG TITLE", "DRAWING TITLE", "SCALE", "SHEET", "DRAWN", "CHECKED", "APPROVED", "DESIGNED",
                   "도면명", "축척", "설계", "검토", "승인", "작성"}


def _label_only(text: str) -> str | None:
    """글줄이 표제란 칸 라벨 하나뿐인가 — 표제 칸이면 정규 이름, 다른 표제란 칸(TITLE·SCALE…)이면 'META', 아니면 None."""
    t = " ".join(str(text or "").split()).strip(" :：")
    if not t or len(t) > 16:
        return None
    c = _canon_label(t)
    if c:
        return c
    return "META" if t.upper().rstrip(". ") in _TB_META_LABELS else None


def _label_value_ok(canon: str, text: str) -> bool:
    v = " ".join(str(text or "").split())
    if not v or _label_only(v) is not None or len(v) > 40:
        return False
    if canon == "META":
        return True
    if " " in v or len(v) > 24 or not _nocolon_value_ok(canon, v):
        return False
    if canon == "REV":
        return bool(_SHORT_REV.match(v) or _KO_REV.match(v))
    if canon == "DATE":
        return bool(_DATE_HEAD.fullmatch(v))
    return bool(re.search(r"\d", v))           # 도면번호·문서번호·프로젝트 번호는 숫자가 든 한 토큰


_STACK_GAP = 3.0        # 라벨 위·값 아래 칸에서 라벨 아랫변과 값 윗변 사이 허용(글자 높이 배수)


def _regroup_label_lines(lines: list, boxes: list, geo: list | None = None) -> list | None:
    """칸 라벨만 든 줄과 그 값 줄을 한 줄로 — (a) 같은 바탕선 오른쪽(라벨을 먼저 다 그리고 값을 나중에 그린 재출력은 PDFium이
    'DWG NO'와 'E-5003'을 다른 줄로 떼어 표제란 필드를 모두 잃었다, held71 C-03) (b) 바로 아래 같은 칸(라벨 위·값 아래 ISO 칸,
    held71 H-P06 — 필드가 하나도 없어 Rev 검사가 꺼졌다). 자리를 아는 줄끼리만, 값 칸 아래에 같은 열의 줄이 또 이어지면(개정표
    열) 짝짓지 않는다. 바뀐 것이 없으면 None. 돌려주는 것: [(글줄, 자리)].
    geo: 짝짓기에 쓸 자리(내용을 통째로 돌려 그린 쪽은 읽는 방향 좌표 — 2026-10-23 뒤흔들기 C4). 없으면 boxes."""
    n = len(lines)
    out_boxes = boxes
    if geo is not None:
        boxes = [g if (g and b) else None for g, b in zip(geo, boxes)]
    lab = [_label_only(s) if boxes[i] else None for i, s in enumerate(lines)]
    if not any(lab):
        return None
    used: set = set()
    pair: dict = {}

    def hgt(b):
        return b[3] - b[1]
    for i in range(n):
        c, lb = lab[i], boxes[i]
        if not c or i in used:
            continue
        best, bscore = None, None
        for j in range(n):
            vb = boxes[j]
            if j == i or j in used or j in pair or not vb or lab[j] or not _label_value_ok(c, lines[j]):
                continue
            hh = max(hgt(lb), hgt(vb))
            if abs(lb[3] - vb[3]) <= 0.3 * hh and vb[0] >= lb[2] - 1 and vb[0] - lb[2] <= 200:
                score = vb[0] - lb[2]                                       # (a) 같은 바탕선 오른쪽
            elif -0.3 * hh <= vb[1] - lb[3] <= _STACK_GAP * hh and abs(vb[0] - lb[0]) <= 3 * hh:
                # 칸 높이가 글자 높이의 2배를 넘는 칸표(칸 8~10mm·글자 2.5mm가 보통)는 라벨과 값 사이가 1.5배를 넘어 필드가 0개가 되고
                # Rev 검사가 소리 없이 꺼졌다 (검토20 r07 1). 아래 같은 열 줄(개정표 열) 가드도 그 간격만큼 넓힌다
                gap = max(0.0, vb[1] - lb[3])
                below = any(k not in (i, j) and boxes[k] and not lab[k] and abs(boxes[k][0] - vb[0]) <= 2 * hh
                            and 0 < boxes[k][1] - vb[3] <= 1.5 * hh for k in range(n))
                if not below and gap > 1.5 * hh:
                    # 넓힌 간격에서는 값 아래에 그 열을 가로지르는 줄(한 줄로 묶인 표 행 '2 P&ID 2026-09-25 B')이 이어져도 표의 열이다 —
                    # 송부서 표 머리 'DATE'가 첫 행 날짜를 표제란 일자로 가로챘다 (adv71 B71-02)
                    below = any(k not in (i, j) and boxes[k] and not lab[k]
                                and min(boxes[k][2], vb[2]) - max(boxes[k][0], vb[0]) > 0
                                and 0 < boxes[k][1] - vb[3] <= gap + 1.5 * hh for k in range(n))
                if below:
                    continue
                score = 1000 + (vb[1] - lb[3])                              # (b) 바로 아래
            else:
                continue
            if bscore is None or score < bscore:
                best, bscore = j, score
        if best is not None:
            pair[i] = best
            used |= {i, best}
    if not pair:
        return None
    out = []
    for i in range(n):
        if i in pair:
            j = pair[i]
            a, b = out_boxes[i], out_boxes[j]
            out.append((f"{lines[i]} {lines[j]}", (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))))
        elif i not in used and lines[i]:
            out.append((lines[i], out_boxes[i]))
    return out


def _annot_lines(page, pno: int, form) -> list:
    """쪽 위 자유 글자 주석(FreeText — 타자기·검토 의견)의 글자와 양식 입력 칸(AcroForm)의 값 → 글줄. 쪽 글자(textpage)는
    주석 겉모양을 안 읽어, 점검표 PDF 양식의 입력 값이 바뀌어도 글자 근거 없이 그림 변경 사진만 남았다 (재검토 2026-10-28 R1-11).
    메모 주석(Text·풍선 쪽지)은 문서 내용이 아니라 뺀다(셀 메모·워드 검토 메모와 같게). 누름 단추·서명 칸도 뺀다."""
    import ctypes
    import pypdfium2.raw as R
    out: list = []

    def _wstr(fn, *args) -> str:
        n = int(fn(*args, None, 0) or 0)
        if n <= 2:
            return ""
        buf = ctypes.create_string_buffer(n)
        fn(*args, ctypes.cast(buf, ctypes.POINTER(ctypes.c_ushort)), n)
        return buf.raw[:n - 2].decode("utf-16-le", "replace")

    try:
        cnt = int(R.FPDFPage_GetAnnotCount(page.raw) or 0)
    except Exception:
        return out
    seen: set = set()
    for i in range(min(cnt, 2000)):
        a = R.FPDFPage_GetAnnot(page.raw, i)
        if not a:
            continue
        try:
            sub = R.FPDFAnnot_GetSubtype(a)
            if sub == R.FPDF_ANNOT_FREETEXT:
                t = " ".join(_wstr(R.FPDFAnnot_GetStringValue, a, b"Contents").split())
                line = f"[주석] {t}" if t else ""
            elif sub == R.FPDF_ANNOT_WIDGET and form is not None:
                ft = R.FPDFAnnot_GetFormFieldType(form, a)
                if ft in (R.FPDF_FORMFIELD_PUSHBUTTON, R.FPDF_FORMFIELD_SIGNATURE, R.FPDF_FORMFIELD_UNKNOWN):
                    continue
                name = " ".join(_wstr(R.FPDFAnnot_GetFormFieldName, form, a).split())
                if ft in (R.FPDF_FORMFIELD_CHECKBOX, R.FPDF_FORMFIELD_RADIOBUTTON):
                    if not R.FPDFAnnot_IsChecked(form, a):
                        continue                  # 고른 것만 — 단추 묶음의 고르지 않은 단추마다 줄이 생기지 않게
                    val = " ".join(_wstr(R.FPDFAnnot_GetFormFieldExportValue, form, a).split()) or "선택"
                else:
                    val = " ".join(_wstr(R.FPDFAnnot_GetFormFieldValue, form, a).split())
                line = f"[입력칸] {name}: {val}" if name else (f"[입력칸] {val}" if val else "")
            else:
                line = ""
        except Exception:
            line = ""
        finally:
            R.FPDFPage_CloseAnnot(a)
        if line and line not in seen:
            seen.add(line)
            out.append(TextLine(line[:500], f"{pno}페이지 주석"))
    return out


def extract(path: Path) -> Document:
    # 쓸 때 읽는다 — 백신이 pdfium.dll 하나만 격리해도 모듈 맨 위 import가 프로그램 전체(DXF·엑셀·메일까지)를 ImportError로
    # 멈췄다 (검토67 A2). 이제 PDF만 '읽기 실패'로 남는다
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path.read_bytes())  # 핸들 즉시 반납 (탐색기 간섭 방지)
    form = None
    try:
        # 양식 입력 칸 값은 양식 환경으로 읽는다 — 쪽을 열기 전에 (AcroForm 문서만)
        import pypdfium2.raw as _R
        if pdf.get_formtype() == _R.FORMTYPE_ACRO_FORM and pdf.init_forms() is not False and pdf.formenv:
            form = pdf.formenv.raw
    except Exception:
        form = None
    fields: dict[str, Field] = {}
    body: list[TextLine] = []
    poor_pages, imaged = 0, False
    poor_list: list[int] = []
    ocr_pages: list[int] = []
    garbled_read: list[int] = []       # 글자 코드가 깨져 OCR로 읽은 쪽 (검토20 r07 2)
    garbled_unread: list[int] = []
    label_core = False                 # 표제란 칸 라벨만 든 줄이 있었나 (검토20 r07 1)
    page_count = len(pdf)
    try:
        for pno in range(1, page_count + 1):
            page = pdf[pno - 1]
            textpage = _page_textpage(page)
            raw_all = _page_text(textpage)
            page_chars = 0
            if GARBLE_CHECK and _garbled(raw_all):
                # 글꼴에 ToUnicode가 없어 글자가 제어 문자로 읽힌 쪽 — 그 글자를 비교하지 않고 OCR로 읽는다(못 읽으면 표지 줄 +
                # 고지). 그림 비교는 그대로 (검토20 r07 2)
                body.extend(_annot_lines(page, pno, form))
                _read = bool(OCR_ENABLED and len(ocr_pages) + len(garbled_read) < ocr_page_cap()
                             and _ocr_page(page, pno, fields, body))
                (garbled_read if _read else garbled_unread).append(pno)
                if not _read:
                    body.append(TextLine(_BLANK_MARK, f"{pno}페이지 0행"))
                textpage.close()
                page.close()
                continue
            if not label_core:
                label_core = any(_label_only(s) not in (None, "META") for s in raw_all.splitlines()[:400])
            # 그리는 순서와 상관없는 줄 묶기 (2026-10-20 대량 시험 N11·N7) — 글자가 영역 읽기와 같을 때만
            _lay = _layout_lines(textpage, page) if LAYOUT_ENABLED else None
            if _lay is not None and not _layout_text_ok(_lay, raw_all):
                _lay = None
            if _lay is not None:
                _rawl = [t for t, _b in _lay]
                _geo = [getattr(x, "fbox", None) or x[1] for x in _lay]
                _strip = [r.strip() for r in _rawl]
                _need_box = _revtable_page(_strip)
                _has_lab = any(_label_only(s) for s in _strip)
                _boxes = [b for _t, b in _lay]
            else:
                _rawl = raw_all.splitlines()
                _geo = None
                _strip = [r.strip() for r in _rawl]
                # 개정표 머리가 있는 쪽·칸 라벨만 든 줄이 있는 쪽만 글줄 자리를 본다 (검토71 R3 B71-04·C-03·H-P06) — 다른 쪽은 예전 그대로
                _need_box = _revtable_page(_strip)
                _has_lab = any(_label_only(s) for s in _strip)
                _boxes = _line_boxes(textpage, page, _strip) if (_need_box or _has_lab) else [None] * len(_rawl)
            if _has_lab:
                _rg = _regroup_label_lines(_strip, _boxes, _geo)
                if _rg is not None:
                    _rawl = [t for t, _b in _rg]
                    _boxes = [b for _t, b in _rg]
            if not _need_box:
                _boxes = [None] * len(_rawl)      # 자리는 개정표 쪽만 남긴다 (추출 기록 크기·다른 쪽 결과 그대로)
            for lno, raw in enumerate(_rawl, start=1):
                line = raw.strip()
                if not line:
                    continue
                page_chars += len(line)
                n_before = len(fields)
                _bx = _boxes[lno - 1]
                _how = _take_line(line, f"{pno}페이지 {lno}행", fields, body, _bx)
                if len(fields) > n_before and _how != "footer_rev":
                    # 표제란 줄도 본문에 둔다 — 첫 쪽의 라벨 줄만 필드로 빼면, 앞에 표지 한 쪽이 끼어들 때 옛 첫 쪽의
                    # 표제란 4줄이 새 2쪽 '본문'으로 내려와 전부 '글자 추가'가 됐다 (검토21 감지 차단 3). 한 쪽짜리도 —
                    # 세트에서 앞 쪽을 지워 한 쪽이 되면 남은 쪽의 표제란 4줄이 '글자 삭제'가 되고 그 쪽의 Rev 올림이
                    # 사라졌다 (검토62 B3). 필드와 겹치는 글자 변경은 diff_documents가 걸러 낸다
                    body.append(TextLine(line, f"{pno}페이지 {lno}행", _bx))
            body.extend(_annot_lines(page, pno, form))      # 쪽 글자 수(page_chars)에는 안 센다 — 스캔 쪽 OCR 판정 그대로
            if page_chars < _POOR_PAGE_CHARS:
                # 벡터 변환 페이지는 객체가 수만 개 — 판정에 필요한 만큼만 보고 중단
                has_image, nontext = False, 0
                # 글자를 조금이라도 읽은 쪽(라벨 몇 줄의 상세도)은 선이 몇 개 있다고 '글자 없는 그림'이 아니다 — 'BOLT M12 x
                # 4EA' 변경을 보여 주면서 같은 쪽을 '글자를 읽지 못했습니다'라 해 결과를 못 믿게 했다 (검토65 A1·B14).
                # 글자가 선으로 그려진(SHX) 쪽은 선이 수백 개라 그대로 잡힌다.
                # 다만 OCR 시도는 예전처럼 선 몇 개부터 — 글자 34자 + 벡터 글자 35개 쪽의 'M-101 5.5kW → 7.5kW'를 OCR이 읽던 것을
                # 기준을 올려 끄자 그림 변경 사진만 남고 도면-BOM 대조에서도 빠졌다 (검토66 A2). OCR이 못 읽었을 때만 고지를 가린다
                _quiet = page_chars >= 15
                _scan_to = _MIN_CONTENT_OBJS_WITH_TEXT if _quiet else _MIN_CONTENT_OBJS
                for o in page.get_objects(max_depth=2):
                    if o.type == _OBJ_IMAGE:
                        has_image = True
                        break
                    if o.type != _OBJ_TEXT:
                        nontext += 1
                        if nontext >= _scan_to:
                            break
                if has_image or nontext >= _MIN_CONTENT_OBJS:
                    # 스캔본·SHX 출력 — Windows OCR이 있으면 읽는다 (2026-09-06). 추정값이라 위치 표기에 'OCR'
                    _read = bool(OCR_ENABLED and len(ocr_pages) < ocr_page_cap() and _ocr_page(page, pno, fields, body))
                    if _read or has_image or not _quiet or nontext >= _MIN_CONTENT_OBJS_WITH_TEXT:
                        poor_pages += 1  # 내용은 그려져 있는데 글자만 못 읽는 페이지
                        poor_list.append(pno)
                        imaged = imaged or has_image
                        if _read:
                            ocr_pages.append(pno)
            textpage.close()
            page.close()
    finally:
        pdf.close()

    notes: list[str] = []
    # OCR로 읽은 페이지는 '비교 불가'가 아니다 — 고지(notes)는 비교를 막는 신호라 남기지 않고, 위치 표기의
    # 'OCR'로 추정값임을 알린다. 절반 넘게 못 읽었을 때만 예전처럼 비교 불가 고지
    poor_pages -= len(ocr_pages)
    if ocr_pages and poor_pages:
        # 앞 30쪽만 OCR한 긴 스캔본 — 읽은 만큼은 비교하고, 못 읽은 뒤쪽은 그림 비교만 (리뷰12 낮음-D).
        # 다만 **못 읽었다는 사실**은 남긴다 — 예전에는 0으로 지워 고지가 사라졌고, 31쪽 이후 변경이
        # "글자·표·그림 동일, 확인 대상 아님"으로 접혔다 (검토33 C4, 원칙 5)
        # 말머리는 PARTIAL_READ_NOTE — 이 말머리가 아니면 cli가 '비교 불가'로 읽어 읽은 쪽의 변경까지
        # 통째로 건너뛴다 (검토34 B 차단 1: 2쪽 스캔에서 REV A→B가 사라졌다)
        notes.append(f"{PARTIAL_READ_NOTE}: 글자 없는 쪽 가운데 {len(ocr_pages)}쪽은 OCR로 읽었고 "
                     f"{poor_pages}쪽은 읽지 못해 글자 비교를 하지 못했습니다 (그 쪽의 변경은 보고되지 않을 수 "
                     f"있습니다)")
        # OCR도 못 읽은 쪽에 표지 — 지우기만 해서 그 쪽이 '쪽 삭제'로 보고됐다 (검토52 A 낮음 4a)
        for p_ in poor_list:
            if p_ not in ocr_pages:
                body.append(TextLine(_BLANK_MARK, f"{p_}페이지 0행"))
        poor_pages = 0
    if poor_pages and poor_pages * 2 < page_count:
        # 몇 쪽만 그림(스캔·서명 쪽)이면 — 절반 규칙에 걸려 고지가 없었고, 글자가 사라진 쪽을 '쪽 삭제'라 했다 (검토51 B 중간 6).
        # 그 쪽에 고정 표지 줄을 두어 쪽이 있다는 것을 남기고, 일부만 읽었다고 고지한다
        _unread = [p_ for p_ in poor_list if p_ not in ocr_pages]
        for p_ in _unread:
            body.append(TextLine(_BLANK_MARK, f"{p_}페이지 0행"))
        if _unread:
            notes.append(f"{PARTIAL_READ_NOTE}: {page_count}페이지 중 {', '.join(map(str, _unread))}페이지는 글자가 없는 "
                         f"그림(스캔·벡터)이라 글자 비교를 하지 못했습니다 — 그 쪽은 그림 비교로만 봅니다")
    elif poor_pages and poor_pages * 2 >= page_count:
        if imaged:
            reason = "스캔본(이미지) PDF로 보입니다"
            fix = "원본 CAD·문서에서 텍스트가 포함된 PDF로 다시 출력해야 비교할 수 있습니다"
        else:
            reason = "글자가 선(벡터)으로 변환된 출력으로 보입니다 (CAD SHX 글꼴 등)"
            fix = "CAD에서 TrueType 글꼴을 사용해 PDF로 출력하면 비교할 수 있습니다"
        try:
            from watcher import ocr as _ocr
            if not OCR_ENABLED:
                fix += " (설정에서 OCR이 꺼져 있습니다 — 켜면 Windows OCR로 글자를 읽습니다)"
            else:
                ok_, why_ = _ocr.status()
                fix += (f" ({why_})" if not ok_ else
                        " (Windows OCR로도 글자를 알아보지 못했습니다 — 해상도가 낮거나 손글씨·도장일 수 있습니다)")
        except Exception:
            pass
        # 표제란은 글자인데 도면 본체만 벡터인 PDF가 흔하다 — 그런 파일은 필드를
        # 멀쩡히 읽고도 "비교가 불가능합니다"라고 고지하고 **Rev 변경을 통째로
        # 빠뜨렸다**. 같은 폴더의 같은 도면 8장이 OCR이 그 장을 우연히 읽었는지에
        # 따라 셋으로 갈렸다 (2026-09-09 배포 후 검토 차단 2 실증, 원칙 5).
        # 읽은 것이 있으면 '일부만 읽음'으로 고지하고 비교는 그대로 한다.
        if fields or len(body) >= 2:
            got = ", ".join(sorted(fields)[:4]) or f"본문 {len(body)}줄"
            notes.append(
                f"{PARTIAL_READ_NOTE}: {page_count}페이지 중 {poor_pages}페이지의 글자를"
                f" 읽지 못했습니다 — {reason}. 읽은 것({got})은 그대로 비교하고,"
                f" 못 읽은 부분은 그림 비교로만 봅니다. {fix}.")
            # 절반 이상이 그림이어도 글자 쪽이 남아 있으면 그림 쪽에 표지를 둔다 — 4쪽 중 2쪽이 그림이 된 날 '쪽 삭제'가 났다
            # (검토52 C 중간 4)
            if poor_pages < page_count:
                for p_ in poor_list:
                    if p_ not in ocr_pages:
                        body.append(TextLine(_BLANK_MARK, f"{p_}페이지 0행"))
        else:
            notes.append(
                f"{page_count}페이지 중 {poor_pages}페이지에서 텍스트가 거의 추출되지 않았습니다"
                f" — {reason}. 이 파일은 텍스트 기반 내용 비교가 불가능합니다. {fix}.")
    if garbled_read or garbled_unread:
        _gp = sorted(garbled_read + garbled_unread)
        notes.append(f"{PARTIAL_READ_NOTE}: {', '.join(map(str, _gp[:10]))}페이지는 글꼴에 글자 대응표(ToUnicode)가 없어 "
                     f"글자를 바로 읽지 못했습니다 — "
                     + ("OCR로 읽어 비교했습니다" if not garbled_unread else
                        f"{', '.join(map(str, garbled_unread[:10]))}페이지는 OCR로도 읽지 못해 그림 비교로만 봅니다"))
    if label_core and not fields:
        notes.append(REV_UNPAIRED_NOTE)
    return Document(doc_type="pdf", path=str(path), fields=fields,
                    raw_texts=body, notes=notes)
