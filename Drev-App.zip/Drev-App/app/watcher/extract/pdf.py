# -*- coding: utf-8 -*-
"""PDF 추출기: 텍스트 추출 → 표제란 키워드(REV, DWG NO, PROJECT, DATE) 파싱.

도면이 DXF가 아니라 PDF로만 도는 현장 대비 (LOG 2026-08-21 결정).
엔진: pypdfium2 (구글 PDFium, BSD/Apache) — 판매 제품에 AGPL(PyMuPDF)을
쓸 수 없어 교체 (2026-08-26 결정, 원래 스택 원칙인 허용적 라이선스로 복귀).
"""

from __future__ import annotations

import re
from pathlib import Path

from watcher.extract.base import Document, Field, TextLine, date_qualified

# "DWG NO: DWG-P-301" / "REV : A" 꼴의 표제란 줄
_MULTI_FIELD_RE = re.compile(
    r"(?<![A-Za-z0-9가-힣_])(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|DOC\.?[ ._]*NO\.?|문서\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?\s*NO\.?|REV(?:ISION)?\.?|리비전|개정\s*번호|개정|DATE|일자|작성일|검사일|발주일)\s*[:：]\s*"
    r"(.+?)(?=\s+[A-Za-z가-힣][\w .()/-]{0,20}?\s*[:：]|\s*$)",
    re.IGNORECASE)
_FIELD_RE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|DOC\.?[ ._]*NO\.?|문서\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?\s*NO\.?|REV(?:ISION)?\.?|리비전|개정\s*번호|개정|DATE|일자|작성일|검사일|발주일)"
    r"\s*[:：.\-]\s*(.+?)\s*$",           # 'REV.A'·'REV-A'도 표제란 (검토31 B11)
    re.IGNORECASE,
)
# 칸이 나뉜 표제란(CAD 출력 PDF 대부분)은 콜론 없이 "REV   B", "DWG NO   E-001"처럼
# 라벨과 값이 같은 줄에 온다 — 값이 짧은 한 토큰일 때만 필드로 본다 (2026-09-04 검토 H-6)
_FIELD_NOCOLON_RE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|DOC\.?[ ._]*NO\.?|문서\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?\s*NO\.?|REV(?:ISION)?\.?|리비전|개정\s*번호|개정|DATE|일자|작성일|검사일|발주일)"
    r"\.?\s{1,}(\S{1,24})\s*$",
    re.IGNORECASE,
)
_CANON = {
    "DWG NO": "DWG_NO", "DWGNO": "DWG_NO", "DRAWING NO": "DWG_NO", "도면번호": "DWG_NO", "도면 번호": "DWG_NO",
    # 사양서·문서의 문서번호 — 'DOC NO: SPEC-E-1501  REV: 1' 한 줄이 통째로 본문이 되어 Rev 검사가 없었다 (검토38 R4-D)
    "DOC NO": "DOC_NO", "DOCNO": "DOC_NO", "문서번호": "DOC_NO", "문서 번호": "DOC_NO",
    "PROJECT": "PROJECT", "프로젝트": "PROJECT",
    "REV": "REV", "REVISION": "REV", "리비전": "REV",
    "REV NO": "REV", "REVISION NO": "REV",                     # 'REV. NO: 2' 검사성적서 (검토41 S2)
    "작성일": "DATE", "검사일": "DATE", "발주일": "DATE",
    "개정": "REV", "개정번호": "REV", "개정 번호": "REV",     # 한글 표제란 (검토38 R4-B)
    "DATE": "DATE", "일자": "DATE",
}

# PDFium 페이지 객체 유형 상수 (FPDF_PAGEOBJ_*)
_OBJ_TEXT, _OBJ_PATH, _OBJ_IMAGE = 1, 2, 3

# 페이지에 그림·이미지는 있는데 추출된 글자가 이보다 적으면 '텍스트 빈약 페이지'.
# CAD가 SHX 글꼴을 선(벡터)으로 변환해 출력한 PDF, 스캔본이 여기 해당한다.
_POOR_PAGE_CHARS = 40
_MIN_CONTENT_OBJS_WITH_TEXT = 50    # 글자를 조금 읽은 쪽은 선이 이만큼 넘어야(도면 본체·SHX 글자) 못 읽은 쪽 (검토65)
# 이 말머리로 시작하는 고지는 **비교를 막지 않는다** (cli._PARTIAL_NOTES와 짝)
PARTIAL_READ_NOTE = "일부 페이지의 글자만 읽었습니다"
# 글자 없는 그림 쪽의 표지 줄 — 쪽 번호는 위치(where)에만 둔다. 글자에 넣으면 앞에 쪽이 끼어든 날 '3페이지→4페이지' 글자
# 변경이 됐다 (검토52 C 낮음 Q13). diff가 이 글자로 '그림이 된 쪽'을 알아본다
_BLANK_MARK = "[글자 없음 — 그림(스캔·벡터)이라 글자를 읽지 못함]"
_MIN_CONTENT_OBJS = 5  # 텍스트 외 객체(선·이미지)가 이보다 적으면 빈 페이지로 본다


# 콜론 없는 짝에서 값이 될 수 없는 낱말 — "REVISION HISTORY" 제목이 REV 값 'HISTORY'로
# 잡혀 Rev 미갱신 오탐을 만들던 것 (2026-09-04 재검토 ②-1)
_LABELISH = {"HISTORY", "DESCRIPTION", "TABLE", "LIST", "NO", "NO.", "DATE", "NAME", "BLOCK",
             "RECORD", "SHEET", "TITLE", "이력", "내역", "번호", "일자", "표"}
_SHORT_REV = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.\-]{0,5}$")
_KO_REV = re.compile(r"^제?\s*\d{1,2}\s*[차판]$")      # 한글 라벨의 '1차'·'제2판' (검토40 A 중간 4)


def _nocolon_value_ok(canon: str | None, value: str) -> bool:
    if canon is None or value.upper() in _LABELISH:
        return False
    if canon == "REV":
        return bool(_SHORT_REV.match(value))
    return True


def _canon_label(label: str) -> str | None:
    return _CANON.get(re.sub(r"[ ._]+", " ", label.upper()).strip().rstrip(". "))


# 글자가 없는 페이지(스캔본·SHX 출력)를 Windows OCR로 읽을지 — config `ocr` (기본 켬). 자식 프로세스에는
# config 요청으로 전달된다. OCR 글줄의 위치 표기는 'N페이지 OCR M행'이라 화면·브리핑이 추정값임을 안다
OCR_ENABLED = True
OCR_MAX_PAGES = 30             # 긴 스캔 매뉴얼은 앞 30쪽만 — 그림 기록 상한과 같다
import threading as _threading
_ctx = _threading.local()      # 미리보기(웹 스레드)만 쪽 상한을 낮춘다 — 전역을 건드리면 검사 스레드가 3쪽만 읽는다


def ocr_page_cap() -> int:
    return int(getattr(_ctx, "max_pages", OCR_MAX_PAGES))
_WORDISH = re.compile(r"^[A-Za-z가-힣]{3,}[.:,]?$")   # NOTE·PLATE·프레임 — 방향이 맞을 때만 나오는 낱말


_DATE_HEAD = re.compile(r"^\d{2,4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}\s*일?(?:\s*\d{1,2}:\d{2})?")   # 날짜 칸 값 (검토42 B 차단 2)


def _date_split(canon, val):
    """DATE 칸이면 (날짜 부분, 나머지) — 날짜 꼴이 아니면 (None, 값). 다른 칸은 (값, '')."""
    if canon != "DATE":
        return val, ""
    m = _DATE_HEAD.match(str(val or "").strip())
    if not m:
        return None, str(val or "")
    return m.group(0).strip(), str(val).strip()[m.end():].strip()


def _rest_to_body(line: str, pairs, where: str, body: list, box=None) -> None:
    """필드로 읽힌 '라벨: 값' 조각을 뺀 나머지가 글자면 본문 줄로 — 안 그러면 라벨 집합에 없는 칸('담당: 김')이나
    필드로 못 쓴 칸의 변경이 어디에도 안 남아 '내용 변경 없음'을 단언했다 (검토41 S2 차단 1)."""
    rest = line
    for lab, val in pairs:
        rest = re.sub(re.escape(lab) + r"\s*[:：]\s*" + re.escape(val), " ", rest, count=1, flags=re.I)
    # 표제 줄의 다른 일자 칸('APPROVED: 2026-09-01'·'DATE: …')도 본문에 둔다 — 날짜만 바뀐 글줄은 diff.is_title_date_text가
    # 일자 변경으로 접는다(검토42 A 중간 1). 여기서 버리면 바닥글 DATE만 고친 날 글자 근거가 사라져 픽셀 변경만 남아
    # 거짓 'Rev 미갱신'이 났고, '납기: 2026-10-05' 같은 내용 날짜까지 없어졌다 (검토42 B P01)
    rest = " ".join(rest.split())
    if re.search(r"[A-Za-z가-힣0-9]{2,}", rest):
        body.append(TextLine(rest, where, box))


_REVROW_LINE = re.compile(r"(?:DESCRIPTION|DESC\.|REMARKS?|내용|사유|비고)\s*[:：]", re.I)


def _take_line(line: str, where: str, fields: dict, body: list, box=None) -> str | None:
    """글줄 하나를 표제란 필드 또는 본문으로 — 진짜 글자와 OCR 글자가 같은 규칙을 탄다."""
    # 단, 도면번호·문서번호·프로젝트 칸이 같은 줄에 있으면 표제 줄이다 — 'DWG NO: … REV: B DESCRIPTION: 도면명'의 REV·DWG_NO가
    # 통째로 사라져 Rev 검사가 꺼졌다 (검토43 A 중간 1)
    # 표제 칸 판정은 **설명 라벨 앞부분**의 '라벨:' 꼴만 본다 — 설명에 '프로젝트 착수 발행'·'ISSUED FOR PROJECT REVIEW'가 있는
    # 개정표 행이 표제 줄로 오인돼 REV 0이 가로채졌다 (검토44 A 중간 2)
    _rr = _REVROW_LINE.search(line)
    if _rr and re.search(r"(?i)\bREV(?:ISION)?\b|개정", line) \
            and not re.search(r"(?i)(?:\b(?:DWG|DOC(?:UMENT)?|DRAWING)\.?\s*NO|도면\s*번호|문서\s*번호|\bPROJECT(?:\s*NO)?|프로젝트)"
                              r"\.?\s*[:：]", line[:_rr.start()]):
        # 개정표 행 — 표제란 REV로 가로채면 오래된 행이 위에 있는 개정표에서 'REV 3→4' 발행이 'Rev 0 그대로'로
        # 거꾸로 보고됐다 (검토42 B 중간 3). 본문 줄로 둔다(개정표 비교는 따로 한다)
        body.append(TextLine(line, where, box))
        return
    # 'DUE DATE:'·'DELIVERY DATE:'의 DATE는 표제 일자 칸이 아니다 — 납기가 표제 DATE가 되어 납기 변경이 '일자만 갱신'으로
    # 접혔다 (검토44 B 차단 1). 그 조각은 본문에 남는다(_rest_to_body)
    pairs = [m.groups() for m in _MULTI_FIELD_RE.finditer(line)
             if not (_canon_label(m.group(1)) == "DATE" and date_qualified(line[:m.start()]))]
    if len(pairs) == 1 and _canon_label(pairs[0][0]) and _canon_label(pairs[0][0]) not in fields \
            and re.match(r"\s*" + re.escape(pairs[0][0]), line, re.I) \
            and (_canon_label(pairs[0][0]) != "REV" or _SHORT_REV.match(pairs[0][1]) or _KO_REV.match(pairs[0][1])) \
            and re.search(r"\s+[A-Za-z가-힣][\w .()/-]{0,20}?\s*[:：]", line[len(pairs[0][0]):]):
        # 'REV: B SCALE: 1:10', 'DATE: 2026-09-01 DRAWN: KIM' — 뒤에 다른 라벨이 이어지면 값은 그 앞까지 (리뷰12 낮음-E)
        canon1 = _canon_label(pairs[0][0])
        v1, tail1 = _date_split(canon1, pairs[0][1])
        if v1 is not None:
            fields[canon1] = Field(canon1, v1, f"표제란({where})", box)
            _rest_to_body(line, pairs[:1], where, body, box)       # 뒤의 다른 칸은 본문으로 (검토41 S2 차단 1)
            if tail1:
                body.append(TextLine(tail1, where, box))            # 날짜 뒤 글자('판정 합격')도 본문 (검토42 B 차단 2)
            return
    if len(pairs) >= 2 and all(_canon_label(lab)
                               and (_canon_label(lab) != "REV" or _SHORT_REV.match(val) or _KO_REV.match(val))
                               for lab, val in pairs) \
            and any(_canon_label(lab) not in fields for lab, val in pairs):
        # 'REV: A DATE: 2026-08-10'처럼 한 줄에 둘 이상 — 새 항목만 필드로 (2026-09-06 3차 42·43). 표지의 'DOC NO: X'가
        # 먼저 잡혀 있으면 뒤 쪽 'DOC NO: X  REV: A  DATE: d'의 REV·DATE까지 버려 Rev 검사가 없었다 (검토41 S2 차단 2).
        # 이미 있던 항목이 섞인 줄은 본문에도 두어 쪽별 변경이 보이게
        fresh = [(lab, val) for lab, val in pairs if _canon_label(lab) not in fields]
        # 이미 있던 항목 가운데 값이 같은 것(표지의 DOC NO가 바닥글에 되풀이)은 필드와 같은 말이다 — 줄째 본문에
        # 두면 일자만 고친 날 '글자 변경'이 한 번 더 잡혀 거짓 'Rev 미갱신'이 났다 (검토41 S2 재채점 P12).
        # 값이 **다른** 항목(세트 PDF의 쪽별 표제란)만 본문에 남겨 쪽별 변경이 보이게
        same = [(lab, val) for lab, val in pairs if (lab, val) not in fresh
                and str(fields[_canon_label(lab)].value).strip() == str(val).strip()]
        tails = []
        for lab, val in fresh:
            canon2 = _canon_label(lab)
            v2, tail2 = _date_split(canon2, val)
            if v2 is None:
                tails.append(f"{lab}: {val}")
                continue
            fields[canon2] = Field(canon2, v2, f"표제란({where})", box)
            if tail2:
                tails.append(tail2)
        _rest_to_body(line, fresh + same, where, body, box)
        for t in tails:
            body.append(TextLine(t, where, box))
        return
    # 사양서 바닥글 'SPEC-E-3902  REV: A  Page 1' — REV 라벨이 줄 첫머리가 아니고 값 뒤에 쪽 번호가 붙어 REV로 읽히지 않았다.
    # 그 문서는 Rev 미갱신·되돌림 검사가 영영 꺼졌다 (검토51 B 중간 1). 값은 첫 토큰(두 칸 이상·'Page' 앞)까지만
    # **바닥글 꼴일 때만** — 값 뒤에 쪽 표식이 있거나 라벨 앞에 문서번호 같은 글자가 있을 때. 홀로 선 'REV: A' 줄(세트 PDF의 쪽별
    # 표제란)까지 잡아 뒤 쪽의 REV 줄이 본문에서 빠졌고, 3쪽만 Rev를 올리면 'REV: B'가 글자 추가가 되어 거짓 'Rev 미갱신'이 났다
    # (검토52 B 중간 1)
    # 줄 가운데 외톨이 'ISSUED FOR CONSTRUCTION REV: 0'·'REFER TO DWG E-100 REV: B'는 바닥글이 아니다 — 앞 글자가 낱말 여럿이면
    # 표제란 REV를 가로챘다 (검토52 A 중간 1). 그래서 **쪽 표식**('Page 1'·'P.1'·'1/3'·'1쪽'·'Sheet 2')이 있거나, 앞이 문서번호
    # **한 토큰**('SPEC-E-3902')일 때만. 콜론 없는 'REV A'·'REV.A'·한글 '개정 A'·'|' 구분 꼴도 받는다 (검토52 C 중간 1)
    _fm = re.search(r"(?i)(?<![A-Za-z가-힣])(REV(?:ISION)?\.?|개정)\s*[:：.]?\s*([A-Za-z0-9]{1,3})(?![A-Za-z0-9가-힣])", line)
    _page_mark = re.search(r"(?i)(?:PAGE|P\.|SHEET)\s*\d|\d\s*(?:쪽|페이지)|(?:^|[\s|])\d+\s*/\s*\d+\s*$", line)
    _lead = line[:_fm.start()].strip(" |/") if _fm else ""
    _lead_ok = bool(re.fullmatch(r"[A-Za-z0-9][\w.\-/]*\d[\w.\-/]*", _lead))
    if _fm and (_page_mark or _lead_ok) and not re.search(r"(?i)HISTORY|DESCRIPTION|이력", line):
        _rv = _fm
        if _rv:
            tok = _rv.group(2)
            stripped = " ".join(re.sub(r"\|", " ", line[:_fm.start()] + " " + line[_fm.end():]).split())
            if "REV" not in fields:
                fields["REV"] = Field("REV", tok, f"표제란({where})", box)
                if re.search(r"[A-Za-z가-힣0-9]{2,}", stripped):
                    body.append(TextLine(stripped, where, box))
                return "footer_rev"           # 부르는 쪽이 줄째 본문에 또 넣지 않게
            if str(fields["REV"].value).strip() == tok:
                # 다음 쪽의 같은 바닥글 — REV를 빼고 둔다(쪽마다 같은 REV 올림이 '글자 변경'으로 겹치지 않게)
                if re.search(r"[A-Za-z가-힣0-9]{2,}", stripped):
                    body.append(TextLine(stripped, where, box))
                return
    m = _FIELD_RE.match(line)
    if m is None:
        m = _FIELD_NOCOLON_RE.match(line)
        if m is not None and not _nocolon_value_ok(_canon_label(m.group(1)), m.group(2)):
            m = None
    canon = _canon_label(m.group(1)) if m else None
    if canon == "REV" and re.search(r"[가-힣]", m.group(1)) and not _SHORT_REV.match(m.group(2).strip()) \
            and not _KO_REV.match(m.group(2).strip()):
        # 한글 '개정'은 본문 낱말이기도 해 값이 Rev 꼴(짧은 영숫자)일 때만 표제란 REV다 —
        # '개정 : 2026.09.01'·'개정: 사양 변경'이 REV를 가로채 거짓 'Rev 미갱신'이 났다 (검토39 F2 ①).
        # 영어 'REV: B (2026-09-01)'은 예전처럼 REV
        canon = None
    if canon == "DATE":
        v3, tail3 = _date_split(canon, m.group(2))
        if v3 is None:
            canon = None                     # '검사일: 재검사 예정' — 날짜가 아니면 본문
    if canon and canon not in fields:
        if canon == "DATE":
            fields[canon] = Field(canon, v3, f"표제란({where})", box)
            if tail3:
                body.append(TextLine(tail3, where, box))
        else:
            fields[canon] = Field(canon, m.group(2), f"표제란({where})", box)
    else:
        body.append(TextLine(line, where, box))


_OCR_SPLIT_DATE = re.compile(r"(\d{4})\s?([-./])\s?(\d{1,2})\s?([-./])\s?(\d)\s(\d)(?!\d)")


def _ocr_date_fix(text: str) -> str:
    """OCR이 좁은 숫자('11')를 '1 1'로 띄워 읽는 날짜를 붙인다 — 'DATE 2026-10-1 1'이 일자로 안 읽혀, 일자만 바꾼 스캔 재출력이
    '내용 변경, Rev 미갱신'이 됐다 (검토64 dry-week day9). 날짜 꼴 안의 띄어쓰기만."""
    return _OCR_SPLIT_DATE.sub(lambda m: f"{m.group(1)}{m.group(2)}{m.group(3)}{m.group(4)}{m.group(5)}{m.group(6)}", text)


def _ocr_label_only(text: str) -> str | None:
    """OCR 글줄이 표제란 라벨 하나뿐인가('DWG NO'·'REV'·'일자') — 그러면 정규 라벨 이름."""
    t = " ".join(str(text or "").split()).strip(" :：")
    if not t or len(t) > 16:
        return None
    return _canon_label(t)


def _ocr_join_cells(lines: list) -> tuple[list, list, list]:
    """칸표 표제란을 OCR이 라벨 칸('DWG NO')과 값 칸('M-3101')을 따로 읽은 것을 같은 줄로 붙인다 — 따로 두면 표제란 필드를
    하나도 못 읽어 Rev 검사가 꺼졌다 (검토68 B2). 같은 행(세로 중심이 글자 높이 0.6배 안)·오른쪽·200pt 안의 가장 가까운
    값 줄만. 돌려주는 값: (붙인 글줄 목록, 짝 없는 라벨 줄 목록, 붙인 짝의 (라벨 x, 값 x) 목록)."""
    from watcher.ocr import OcrLine
    used: set = set()
    joined: dict = {}
    lone: list = []
    cols: list = []
    for i, lb in enumerate(lines):
        if _ocr_label_only(lb.text) is None:
            continue
        cy = lb.y + lb.h / 2
        best = None
        for j, v in enumerate(lines):
            if j == i or j in used or _ocr_label_only(v.text) is not None:
                continue
            if abs((v.y + v.h / 2) - cy) > 0.6 * max(lb.h, v.h) or v.x < lb.x + lb.w - 1 or v.x - (lb.x + lb.w) > 200:
                continue
            if best is None or v.x < lines[best].x:
                best = j
        if best is None:
            lone.append(lb)
            continue
        v = lines[best]
        used.add(best)
        cols.append((lb.x, v.x))
        top = min(lb.y, v.y)
        x1, y1 = max(lb.x + lb.w, v.x + v.w), max(lb.y + lb.h, v.y + v.h)
        joined[i] = OcrLine(f"{lb.text} {v.text}", lb.x, top, x1 - lb.x, y1 - top)
    out = [joined.get(i, ln) for i, ln in enumerate(lines) if i not in used]
    return out, lone, cols


def _ocr_lone_rev(page, label, cols: list):
    """값 칸이 한 글자('A')라 OCR이 버린 REV 칸 — Windows OCR은 홀로 선 한 글자를 읽지 않는다. 같은 표의 다른 값 칸이 시작하는
    x(값 열)에서 그 행의 값 글자를 잘라 라벨 글자 바로 뒤에 붙인 그림을 다시 읽어 'REV A'를 얻는다 (검토68 B2). 그림은 메모리에만."""
    if _canon_label(" ".join(label.text.split()).strip(" :：")) != "REV":
        return None
    # 같은 표 = 라벨 왼쪽 끝이 같은 열인 짝들 — 그 값 열의 x
    xs = sorted(vx for lx, vx in cols if abs(lx - label.x) <= max(2.0, label.h))
    if not xs:
        return None
    vx = xs[len(xs) // 2]
    try:
        from PIL import Image, ImageChops, ImageOps

        from watcher import ocr as _ocr
        from watcher.render import bitmap_pil
    except Exception:
        return None

    def _trim(im):
        bb = ImageChops.invert(im).point(lambda v: 255 if v > 60 else 0).getbbox()
        return im.crop(bb) if bb else None
    cy, hh = label.y + label.h / 2, label.h
    for dpi in (300, 250, 360):
        s = dpi / 72.0
        try:
            img = bitmap_pil(page.render(scale=s, grayscale=True)).convert("L")
        except Exception:
            return None
        lab = _trim(img.crop((int((label.x - 1) * s), int((cy - 0.9 * hh) * s),
                              int((label.x + label.w + 1) * s), int((cy + 0.9 * hh) * s))))
        val = _trim(img.crop((int((vx - 1) * s), int((cy - 0.9 * hh) * s),
                              int((vx + 8 * hh) * s), int((cy + 0.9 * hh) * s))))
        if lab is None or val is None or val.height > 2 * lab.height or val.width > 4 * lab.width:
            return None
        h = max(lab.height, val.height)
        for gk in (0.5, 0.7, 0.35):
            gap = max(2, int(h * gk))
            g = Image.new("L", (lab.width + gap + val.width, h), 255)
            g.paste(lab, (0, h - lab.height))
            g.paste(val, (lab.width + gap, h - val.height))
            g = ImageOps.expand(g, border=h, fill=255)
            try:
                got = _ocr.recognize_gray(g.tobytes(), g.width, g.height, s)
            except Exception:
                return None
            for ln in got:
                m = re.fullmatch(r"(?i)(REV(?:ISION)?\.?|개정|리비전)\s*([A-Za-z0-9]{1,2})", " ".join(ln.text.split()))
                if m:
                    return m.group(2).upper() if m.group(2).isalpha() else m.group(2)
    return None


def _ocr_page(page, pno: int, fields: dict, body: list) -> bool:
    """글자 없는 페이지를 OCR로 읽어 같은 규칙으로 넣는다. 읽은 글자가 40자 이상이거나 표제란 필드가 하나라도
    나오면 성공. 미달이면 뒤집힌·옆으로 누운 스캔일 수 있어 180°·90°·270°로 다시 읽어 가장 많이 읽힌 방향을
    쓴다 (리뷰12 중간-A: 뒤집힌 스캔이 쓰레기 글줄로 '읽힌 문서'가 되던 것)."""
    try:
        from watcher import ocr as _ocr
    except Exception:
        return False
    best_lines, best_words, best_fields, best_rot = [], 0, {}, 0
    best_lone, best_cols = [], []
    for rot in (0, 180, 90, 270):
        try:
            lines = _ocr.recognize_pdf_page(page, rotation=rot)
        except OSError:
            raise                        # 엔진 오류(WinRT) — 일시적일 수 있어 '비교 불가'로 캐시하지 않고 다음 검사에 다시 (리뷰12 운영 중간-1)
        except Exception:
            lines = []
        lines = [ln for ln in lines if len(ln.text) >= 2]      # 점·선을 글자로 읽은 한 글자 조각 제외
        # 칸표 표제란의 라벨 칸·값 칸을 한 줄로 (검토68 B2)
        lines, lone, cols = _ocr_join_cells(lines)
        f_try: dict = {}
        b_try: list = []
        for k, ln in enumerate(lines, start=1):
            _take_line(_ocr_date_fix(ln.text), f"{pno}페이지 OCR {k}행", f_try, b_try)
        # 뒤집힌 스캔은 글자 수는 많아도 '낱말다운 토큰'(글자만 3자 이상)이 거의 없다 (리뷰13 ④-3)
        words = sum(1 for ln in lines for tok in ln.text.split() if _WORDISH.match(tok))
        if (f_try and not best_fields) or (bool(f_try) == bool(best_fields) and words > best_words):
            best_lines, best_words, best_fields, best_rot = lines, words, f_try, rot
            best_lone, best_cols = lone, cols
        if best_fields or best_words >= 8:
            break
    if not best_fields and best_words < 3:
        return False
    if best_rot == 0 and "REV" not in best_fields and best_lone and best_cols:
        # 한 글자 Rev 값('A')은 OCR이 버린다 — 값 칸을 라벨 뒤에 붙여 다시 읽는다 (검토68 B2)
        from watcher.ocr import OcrLine
        for lb in best_lone:
            rv = _ocr_lone_rev(page, lb, best_cols)
            if rv:
                best_lines = [OcrLine(f"{ln.text} {rv}", ln.x, ln.y, ln.w, ln.h) if ln is lb else ln for ln in best_lines]
                break
    for k, ln in enumerate(best_lines, start=1):
        # 자리는 돌리지 않고 읽었을 때만 — 돌린 좌표는 원래 페이지 좌표와 다르다
        box = (round(ln.x, 1), round(ln.y, 1), round(ln.x + ln.w, 1), round(ln.y + ln.h, 1)) if best_rot == 0 else None
        _take_line(_ocr_date_fix(ln.text), f"{pno}페이지 OCR {k}행", fields, body, box)
    return True


def _page_textpage(page):
    """쪽의 글자판. /Rotate 90·270 쪽인데 글자가 그리는 좌표에서 가로(각도 0·π)이면 회전을 잠시 0으로 두고 읽는다 —
    PDFium이 표시 방향으로 줄을 묶어 'REV'·'A'를 떼어 'REVA'로 붙이고 칸표 표제란 필드를 모두 놓쳤다 (검토68 B1).
    메모리 안 문서의 회전값만 잠시 바꾸고 곧바로 되돌린다(파일은 손대지 않음)."""
    textpage = page.get_textpage()
    try:
        rot = int(page.get_rotation() or 0) % 360
    except Exception:
        rot = 0
    if rot not in (90, 270):
        return textpage
    try:
        import math
        import pypdfium2.raw as _raw
        n = textpage.count_chars()
        horiz = 0
        for i in range(n):
            a = _raw.FPDFText_GetCharAngle(textpage.raw, i)
            if a >= 0 and min(abs(a), abs(a - math.pi), abs(a - 2 * math.pi)) < 0.2:
                horiz += 1
        if n == 0 or horiz * 2 <= n:
            return textpage                 # 그리는 좌표에서 이미 돌려 쓴 글자 — 표시 방향 읽기가 맞다
        textpage.close()
        page.set_rotation(0)
        try:
            return page.get_textpage()
        finally:
            page.set_rotation(rot)
    except Exception:
        return page.get_textpage()


def _page_text(textpage) -> str:
    """쪽 글자. 세로(90°·270°)로 쓴 글줄은 PDFium 영역 읽기(get_text_bounded)가 줄바꿈을 빼고 붙인다 — 표제란을 90° 돌린
    도면의 'DWG NO: E-101PROJECT: P66-P04REV: ADATE: …'가 한 줄이 되어 REV·PROJECT를 못 읽고 Rev 검사가 꺼졌다 (검토66
    P04·P13). 그 쪽에 세로 글자가 있고, 글자 순서 읽기(get_text_range)가 **줄바꿈만** 더 넣은 같은 글자일 때만 그것을 쓴다
    (쪽 밖 글자가 끼어드는 일 없이 — 공백을 뺀 글자가 똑같아야 한다)."""
    raw_b = textpage.get_text_bounded() or ""
    try:
        import math
        import pypdfium2.raw as _raw
        n = textpage.count_chars()
        vert = False
        for i in range(n):
            if _raw.FPDFText_IsGenerated(textpage.raw, i):
                continue
            a = _raw.FPDFText_GetCharAngle(textpage.raw, i)
            if a >= 0 and min(abs(a - math.pi / 2), abs(a - 3 * math.pi / 2)) < 0.2:
                vert = True
                break
        if not vert:
            return raw_b
        raw_r = textpage.get_text_range() or ""
    except Exception:
        return raw_b
    if raw_r != raw_b and re.sub(r"\s+", "", raw_r) == re.sub(r"\s+", "", raw_b) \
            and raw_r.count("\n") > raw_b.count("\n"):
        raw_b = raw_r
    split = _vertical_gap_split(textpage, raw_r)
    if split is not None and re.sub(r"\s+", "", split) == re.sub(r"\s+", "", raw_b) \
            and split.count("\n") > raw_b.count("\n") and _fields_kept(raw_b, split):
        return split
    return raw_b


def _vertical_gap_split(textpage, raw_r: str) -> str | None:
    """세로 글자의 칸 나누기 — 세로 띠 표제란의 '도면번호: …'·'개정: A'·'도면명: …'이 같은 세로 줄에 떨어져 놓이면 PDFium이
    한 줄로 이어 '도면번호: S-2501 프로젝트: … 도면명: 배수 계통'이 됐고, 칸 이름이 아닌 '도면명'이 섞여 그 줄이 Rev만 올린 날
    본문 글자 변경으로 남아 'Rev만 갱신'을 놓쳤다 (검토70 B, held69 P15). PDFium이 끼운 빈칸(생성 글자) 양옆이 같은 세로 열의
    같은 방향 글자이고, 둘 사이 빈 거리가 글자 크기(가로 폭 중앙값)의 2배를 넘으면 그 빈칸을 줄바꿈으로. 글자 순서 읽기와 글자가
    한 글자라도 다르면 쓰지 않는다."""
    import ctypes
    import math
    import statistics

    import pypdfium2.raw as _raw
    tp = textpage.raw
    n = textpage.count_chars()
    if n <= 0 or n > 200_000:
        return None
    chars, gen, ang, ox, box = [], [], [], [], []
    l_, r_, b_, t_ = (ctypes.c_double() for _ in range(4))
    x_, y_ = ctypes.c_double(), ctypes.c_double()
    for i in range(n):
        u = _raw.FPDFText_GetUnicode(tp, i)
        chars.append(chr(u) if 0 < u < 0x110000 else "�")
        g = bool(_raw.FPDFText_IsGenerated(tp, i))
        gen.append(g)
        a = _raw.FPDFText_GetCharAngle(tp, i)
        ang.append(a)
        _raw.FPDFText_GetCharOrigin(tp, i, ctypes.byref(x_), ctypes.byref(y_))
        _raw.FPDFText_GetCharBox(tp, i, ctypes.byref(l_), ctypes.byref(r_), ctypes.byref(b_), ctypes.byref(t_))
        ox.append(x_.value)
        box.append((l_.value, r_.value, b_.value, t_.value))
    if "".join(chars) != raw_r:
        return None

    def vert(i) -> bool:
        a = ang[i]
        return not gen[i] and a >= 0 and min(abs(a - math.pi / 2), abs(a - 3 * math.pi / 2)) < 0.2

    widths = [box[i][1] - box[i][0] for i in range(n) if vert(i) and box[i][1] - box[i][0] > 0.5]
    if not widths:
        return None
    size = statistics.median(widths)
    out = list(chars)
    changed = False
    for i in range(n):
        if not gen[i] or chars[i] != " ":
            continue
        p = i - 1
        while p >= 0 and gen[p]:
            p -= 1
        q = i + 1
        while q < n and gen[q]:
            q += 1
        if p < 0 or q >= n or not vert(p) or not vert(q) or abs(ang[p] - ang[q]) > 0.2 or abs(ox[p] - ox[q]) > size:
            continue
        gap = max(box[p][2] - box[q][3], box[q][2] - box[p][3])
        if gap > 2 * size:
            out[i] = "\n"
            changed = True
    return "".join(out) if changed else None


def _fields_kept(before: str, after: str) -> bool:
    """칸 나누기 뒤에도 표제란 칸을 하나도 잃지 않는가 — 칸표('REV' 칸과 'A' 칸이 떨어진 세로 표제란)를 나누면 라벨과 값이 다른 줄이
    되어 REV를 못 읽는다. 그런 쪽은 나누지 않는다 (검토70 B)."""
    def parse(txt):
        f: dict = {}
        for ln in txt.splitlines():
            if ln.strip():
                _take_line(ln.strip(), "0페이지 0행", f, [])
        return {k: str(v.value) for k, v in f.items()}
    a, b = parse(before), parse(after)
    return all(b.get(k) == v for k, v in a.items())


def extract(path: Path) -> Document:
    # 쓸 때 읽는다 — 백신이 pdfium.dll 하나만 격리해도 모듈 맨 위 import가 프로그램 전체(DXF·엑셀·메일까지)를 ImportError로
    # 멈췄다 (검토67 A2). 이제 PDF만 '읽기 실패'로 남는다
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path.read_bytes())  # 핸들 즉시 반납 (탐색기 간섭 방지)
    fields: dict[str, Field] = {}
    body: list[TextLine] = []
    poor_pages, imaged = 0, False
    poor_list: list[int] = []
    ocr_pages: list[int] = []
    page_count = len(pdf)
    try:
        for pno in range(1, page_count + 1):
            page = pdf[pno - 1]
            textpage = _page_textpage(page)
            raw_all = _page_text(textpage)
            page_chars = 0
            for lno, raw in enumerate(raw_all.splitlines(), start=1):
                line = raw.strip()
                if not line:
                    continue
                page_chars += len(line)
                n_before = len(fields)
                _how = _take_line(line, f"{pno}페이지 {lno}행", fields, body)
                if len(fields) > n_before and _how != "footer_rev":
                    # 표제란 줄도 본문에 둔다 — 첫 쪽의 라벨 줄만 필드로 빼면, 앞에 표지 한 쪽이 끼어들 때 옛 첫 쪽의
                    # 표제란 4줄이 새 2쪽 '본문'으로 내려와 전부 '글자 추가'가 됐다 (검토21 감지 차단 3). 한 쪽짜리도 —
                    # 세트에서 앞 쪽을 지워 한 쪽이 되면 남은 쪽의 표제란 4줄이 '글자 삭제'가 되고 그 쪽의 Rev 올림이
                    # 사라졌다 (검토62 B3). 필드와 겹치는 글자 변경은 diff_documents가 걸러 낸다
                    body.append(TextLine(line, f"{pno}페이지 {lno}행"))
            if page_chars < _POOR_PAGE_CHARS:
                # 벡터 변환 페이지는 객체가 수만 개 — 판정에 필요한 만큼만 보고 중단
                has_image, nontext = False, 0
                # 글자를 조금이라도 읽은 쪽(라벨 몇 줄의 상세도)은 선이 몇 개 있다고 '글자 없는 그림'이 아니다 — 'BOLT M12 x
                # 4EA' 변경을 보여 주면서 같은 쪽을 '글자를 읽지 못했습니다'라 해 결과를 못 믿게 했다 (검토65 A1·B14).
                # 글자가 선으로 그려진(SHX) 쪽은 선이 수백 개라 그대로 잡힌다.
                # 다만 OCR 시도는 예전처럼 선 몇 개부터 — 글자 34자 + 벡터 글자 35개 쪽의 'M-101 5.5kW → 7.5kW'를 OCR이 읽던 것을
                # 기준을 올려 끄자 그림 변경 사진만 남고 도면-BOM 대조에서도 빠졌다 (검토66 A2). OCR이 못 읽었을 때만 고지를 가린다
                _quiet = page_chars >= 15
                _scan_to = _MIN_CONTENT_OBJS_WITH_TEXT if _quiet else _MIN_CONTENT_OBJS
                for o in page.get_objects(max_depth=2):
                    if o.type == _OBJ_IMAGE:
                        has_image = True
                        break
                    if o.type != _OBJ_TEXT:
                        nontext += 1
                        if nontext >= _scan_to:
                            break
                if has_image or nontext >= _MIN_CONTENT_OBJS:
                    # 스캔본·SHX 출력 — Windows OCR이 있으면 읽는다 (2026-09-06). 추정값이라 위치 표기에 'OCR'
                    _read = bool(OCR_ENABLED and len(ocr_pages) < ocr_page_cap() and _ocr_page(page, pno, fields, body))
                    if _read or has_image or not _quiet or nontext >= _MIN_CONTENT_OBJS_WITH_TEXT:
                        poor_pages += 1  # 내용은 그려져 있는데 글자만 못 읽는 페이지
                        poor_list.append(pno)
                        imaged = imaged or has_image
                        if _read:
                            ocr_pages.append(pno)
            textpage.close()
            page.close()
    finally:
        pdf.close()

    notes: list[str] = []
    # OCR로 읽은 페이지는 '비교 불가'가 아니다 — 고지(notes)는 비교를 막는 신호라 남기지 않고, 위치 표기의
    # 'OCR'로 추정값임을 알린다. 절반 넘게 못 읽었을 때만 예전처럼 비교 불가 고지
    poor_pages -= len(ocr_pages)
    if ocr_pages and poor_pages:
        # 앞 30쪽만 OCR한 긴 스캔본 — 읽은 만큼은 비교하고, 못 읽은 뒤쪽은 그림 비교만 (리뷰12 낮음-D).
        # 다만 **못 읽었다는 사실**은 남긴다 — 예전에는 0으로 지워 고지가 사라졌고, 31쪽 이후 변경이
        # "글자·표·그림 동일, 확인 대상 아님"으로 접혔다 (검토33 C4, 원칙 5)
        # 말머리는 PARTIAL_READ_NOTE — 이 말머리가 아니면 cli가 '비교 불가'로 읽어 읽은 쪽의 변경까지
        # 통째로 건너뛴다 (검토34 B 차단 1: 2쪽 스캔에서 REV A→B가 사라졌다)
        notes.append(f"{PARTIAL_READ_NOTE}: 글자 없는 쪽 가운데 {len(ocr_pages)}쪽은 OCR로 읽었고 "
                     f"{poor_pages}쪽은 읽지 못해 글자 비교를 하지 못했습니다 (그 쪽의 변경은 보고되지 않을 수 "
                     f"있습니다)")
        # OCR도 못 읽은 쪽에 표지 — 지우기만 해서 그 쪽이 '쪽 삭제'로 보고됐다 (검토52 A 낮음 4a)
        for p_ in poor_list:
            if p_ not in ocr_pages:
                body.append(TextLine(_BLANK_MARK, f"{p_}페이지 0행"))
        poor_pages = 0
    if poor_pages and poor_pages * 2 < page_count:
        # 몇 쪽만 그림(스캔·서명 쪽)이면 — 절반 규칙에 걸려 고지가 없었고, 글자가 사라진 쪽을 '쪽 삭제'라 했다 (검토51 B 중간 6).
        # 그 쪽에 고정 표지 줄을 두어 쪽이 있다는 것을 남기고, 일부만 읽었다고 고지한다
        _unread = [p_ for p_ in poor_list if p_ not in ocr_pages]
        for p_ in _unread:
            body.append(TextLine(_BLANK_MARK, f"{p_}페이지 0행"))
        if _unread:
            notes.append(f"{PARTIAL_READ_NOTE}: {page_count}페이지 중 {', '.join(map(str, _unread))}페이지는 글자가 없는 "
                         f"그림(스캔·벡터)이라 글자 비교를 하지 못했습니다 — 그 쪽은 그림 비교로만 봅니다")
    elif poor_pages and poor_pages * 2 >= page_count:
        if imaged:
            reason = "스캔본(이미지) PDF로 보입니다"
            fix = "원본 CAD·문서에서 텍스트가 포함된 PDF로 다시 출력해야 비교할 수 있습니다"
        else:
            reason = "글자가 선(벡터)으로 변환된 출력으로 보입니다 (CAD SHX 글꼴 등)"
            fix = "CAD에서 TrueType 글꼴을 사용해 PDF로 출력하면 비교할 수 있습니다"
        try:
            from watcher import ocr as _ocr
            if not OCR_ENABLED:
                fix += " (설정에서 OCR이 꺼져 있습니다 — 켜면 Windows OCR로 글자를 읽습니다)"
            else:
                ok_, why_ = _ocr.status()
                fix += (f" ({why_})" if not ok_ else
                        " (Windows OCR로도 글자를 알아보지 못했습니다 — 해상도가 낮거나 손글씨·도장일 수 있습니다)")
        except Exception:
            pass
        # 표제란은 글자인데 도면 본체만 벡터인 PDF가 흔하다 — 그런 파일은 필드를
        # 멀쩡히 읽고도 "비교가 불가능합니다"라고 고지하고 **Rev 변경을 통째로
        # 빠뜨렸다**. 같은 폴더의 같은 도면 8장이 OCR이 그 장을 우연히 읽었는지에
        # 따라 셋으로 갈렸다 (2026-09-09 배포 후 검토 차단 2 실증, 원칙 5).
        # 읽은 것이 있으면 '일부만 읽음'으로 고지하고 비교는 그대로 한다.
        if fields or len(body) >= 2:
            got = ", ".join(sorted(fields)[:4]) or f"본문 {len(body)}줄"
            notes.append(
                f"{PARTIAL_READ_NOTE}: {page_count}페이지 중 {poor_pages}페이지의 글자를"
                f" 읽지 못했습니다 — {reason}. 읽은 것({got})은 그대로 비교하고,"
                f" 못 읽은 부분은 그림 비교로만 봅니다. {fix}.")
            # 절반 이상이 그림이어도 글자 쪽이 남아 있으면 그림 쪽에 표지를 둔다 — 4쪽 중 2쪽이 그림이 된 날 '쪽 삭제'가 났다
            # (검토52 C 중간 4)
            if poor_pages < page_count:
                for p_ in poor_list:
                    if p_ not in ocr_pages:
                        body.append(TextLine(_BLANK_MARK, f"{p_}페이지 0행"))
        else:
            notes.append(
                f"{page_count}페이지 중 {poor_pages}페이지에서 텍스트가 거의 추출되지 않았습니다"
                f" — {reason}. 이 파일은 텍스트 기반 내용 비교가 불가능합니다. {fix}.")
    return Document(doc_type="pdf", path=str(path), fields=fields,
                    raw_texts=body, notes=notes)
