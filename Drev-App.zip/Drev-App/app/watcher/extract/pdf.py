# -*- coding: utf-8 -*-
"""PDF 추출기: 텍스트 추출 → 표제란 키워드(REV, DWG NO, PROJECT, DATE) 파싱.

도면이 DXF가 아니라 PDF로만 도는 현장 대비 (LOG 2026-08-21 결정).
엔진: pypdfium2 (구글 PDFium, BSD/Apache) — 판매 제품에 AGPL(PyMuPDF)을
쓸 수 없어 교체 (2026-08-26 결정, 원래 스택 원칙인 허용적 라이선스로 복귀).
"""

from __future__ import annotations

import re
from pathlib import Path

import pypdfium2 as pdfium

from watcher.extract.base import Document, Field, TextLine

# "DWG NO: DWG-P-301" / "REV : A" 꼴의 표제란 줄
_MULTI_FIELD_RE = re.compile(
    r"(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?|리비전|DATE|일자)\s*[:：]\s*"
    r"(.+?)(?=\s+[A-Za-z가-힣][\w .()/-]{0,20}?\s*[:：]|\s*$)",
    re.IGNORECASE)
_FIELD_RE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?|리비전|DATE|일자)"
    r"\s*[:：.\-]\s*(.+?)\s*$",           # 'REV.A'·'REV-A'도 표제란 (검토31 B11)
    re.IGNORECASE,
)
# 칸이 나뉜 표제란(CAD 출력 PDF 대부분)은 콜론 없이 "REV   B", "DWG NO   E-001"처럼
# 라벨과 값이 같은 줄에 온다 — 값이 짧은 한 토큰일 때만 필드로 본다 (2026-09-04 검토 H-6)
_FIELD_NOCOLON_RE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?|리비전|DATE|일자)"
    r"\.?\s{1,}(\S{1,24})\s*$",
    re.IGNORECASE,
)
_CANON = {
    "DWG NO": "DWG_NO", "DWGNO": "DWG_NO", "DRAWING NO": "DWG_NO", "도면번호": "DWG_NO", "도면 번호": "DWG_NO",
    "PROJECT": "PROJECT", "프로젝트": "PROJECT",
    "REV": "REV", "REVISION": "REV", "리비전": "REV",
    "DATE": "DATE", "일자": "DATE",
}

# PDFium 페이지 객체 유형 상수 (FPDF_PAGEOBJ_*)
_OBJ_TEXT, _OBJ_PATH, _OBJ_IMAGE = 1, 2, 3

# 페이지에 그림·이미지는 있는데 추출된 글자가 이보다 적으면 '텍스트 빈약 페이지'.
# CAD가 SHX 글꼴을 선(벡터)으로 변환해 출력한 PDF, 스캔본이 여기 해당한다.
_POOR_PAGE_CHARS = 40
# 이 말머리로 시작하는 고지는 **비교를 막지 않는다** (cli._PARTIAL_NOTES와 짝)
PARTIAL_READ_NOTE = "일부 페이지의 글자만 읽었습니다"
_MIN_CONTENT_OBJS = 5  # 텍스트 외 객체(선·이미지)가 이보다 적으면 빈 페이지로 본다


# 콜론 없는 짝에서 값이 될 수 없는 낱말 — "REVISION HISTORY" 제목이 REV 값 'HISTORY'로
# 잡혀 Rev 미갱신 오탐을 만들던 것 (2026-09-04 재검토 ②-1)
_LABELISH = {"HISTORY", "DESCRIPTION", "TABLE", "LIST", "NO", "NO.", "DATE", "NAME", "BLOCK",
             "RECORD", "SHEET", "TITLE", "이력", "내역", "번호", "일자", "표"}
_SHORT_REV = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.\-]{0,5}$")


def _nocolon_value_ok(canon: str | None, value: str) -> bool:
    if canon is None or value.upper() in _LABELISH:
        return False
    if canon == "REV":
        return bool(_SHORT_REV.match(value))
    return True


def _canon_label(label: str) -> str | None:
    return _CANON.get(re.sub(r"[ ._]+", " ", label.upper()).strip().rstrip(". "))


# 글자가 없는 페이지(스캔본·SHX 출력)를 Windows OCR로 읽을지 — config `ocr` (기본 켬). 자식 프로세스에는
# config 요청으로 전달된다. OCR 글줄의 위치 표기는 'N페이지 OCR M행'이라 화면·브리핑이 추정값임을 안다
OCR_ENABLED = True
OCR_MAX_PAGES = 30             # 긴 스캔 매뉴얼은 앞 30쪽만 — 그림 기록 상한과 같다
import threading as _threading
_ctx = _threading.local()      # 미리보기(웹 스레드)만 쪽 상한을 낮춘다 — 전역을 건드리면 검사 스레드가 3쪽만 읽는다


def ocr_page_cap() -> int:
    return int(getattr(_ctx, "max_pages", OCR_MAX_PAGES))
_WORDISH = re.compile(r"^[A-Za-z가-힣]{3,}[.:,]?$")   # NOTE·PLATE·프레임 — 방향이 맞을 때만 나오는 낱말


def _take_line(line: str, where: str, fields: dict, body: list, box=None) -> None:
    """글줄 하나를 표제란 필드 또는 본문으로 — 진짜 글자와 OCR 글자가 같은 규칙을 탄다."""
    pairs = _MULTI_FIELD_RE.findall(line)
    if len(pairs) == 1 and _canon_label(pairs[0][0]) and _canon_label(pairs[0][0]) not in fields \
            and re.match(r"\s*" + re.escape(pairs[0][0]), line, re.I) \
            and (_canon_label(pairs[0][0]) != "REV" or _SHORT_REV.match(pairs[0][1])) \
            and re.search(r"\s+[A-Za-z가-힣][\w .()/-]{0,20}?\s*[:：]", line[len(pairs[0][0]):]):
        # 'REV: B SCALE: 1:10', 'DATE: 2026-09-01 DRAWN: KIM' — 뒤에 다른 라벨이 이어지면 값은 그 앞까지 (리뷰12 낮음-E)
        canon1 = _canon_label(pairs[0][0])
        fields[canon1] = Field(canon1, pairs[0][1], f"표제란({where})", box)
        return
    if len(pairs) >= 2 and all(_canon_label(lab) and _canon_label(lab) not in fields
                               and (_canon_label(lab) != "REV" or _SHORT_REV.match(val))
                               for lab, val in pairs):
        # 'REV: A DATE: 2026-08-10'처럼 한 줄에 둘 이상 — 각각 필드로 (2026-09-06 3차 42·43).
        # 도면 세트의 뒤 페이지처럼 이미 있는 항목이면 본문 줄로 두어 페이지별 변경이 보이게
        for lab, val in pairs:
            canon2 = _canon_label(lab)
            fields[canon2] = Field(canon2, val, f"표제란({where})", box)
        return
    m = _FIELD_RE.match(line)
    if m is None:
        m = _FIELD_NOCOLON_RE.match(line)
        if m is not None and not _nocolon_value_ok(_canon_label(m.group(1)), m.group(2)):
            m = None
    canon = _canon_label(m.group(1)) if m else None
    if canon and canon not in fields:
        fields[canon] = Field(canon, m.group(2), f"표제란({where})", box)
    else:
        body.append(TextLine(line, where, box))


def _ocr_page(page, pno: int, fields: dict, body: list) -> bool:
    """글자 없는 페이지를 OCR로 읽어 같은 규칙으로 넣는다. 읽은 글자가 40자 이상이거나 표제란 필드가 하나라도
    나오면 성공. 미달이면 뒤집힌·옆으로 누운 스캔일 수 있어 180°·90°·270°로 다시 읽어 가장 많이 읽힌 방향을
    쓴다 (리뷰12 중간-A: 뒤집힌 스캔이 쓰레기 글줄로 '읽힌 문서'가 되던 것)."""
    try:
        from watcher import ocr as _ocr
    except Exception:
        return False
    best_lines, best_words, best_fields, best_rot = [], 0, {}, 0
    for rot in (0, 180, 90, 270):
        try:
            lines = _ocr.recognize_pdf_page(page, rotation=rot)
        except OSError:
            raise                        # 엔진 오류(WinRT) — 일시적일 수 있어 '비교 불가'로 캐시하지 않고 다음 검사에 다시 (리뷰12 운영 중간-1)
        except Exception:
            lines = []
        lines = [ln for ln in lines if len(ln.text) >= 2]      # 점·선을 글자로 읽은 한 글자 조각 제외
        f_try: dict = {}
        b_try: list = []
        for k, ln in enumerate(lines, start=1):
            _take_line(ln.text, f"{pno}페이지 OCR {k}행", f_try, b_try)
        # 뒤집힌 스캔은 글자 수는 많아도 '낱말다운 토큰'(글자만 3자 이상)이 거의 없다 (리뷰13 ④-3)
        words = sum(1 for ln in lines for tok in ln.text.split() if _WORDISH.match(tok))
        if (f_try and not best_fields) or (bool(f_try) == bool(best_fields) and words > best_words):
            best_lines, best_words, best_fields, best_rot = lines, words, f_try, rot
        if best_fields or best_words >= 8:
            break
    if not best_fields and best_words < 3:
        return False
    for k, ln in enumerate(best_lines, start=1):
        # 자리는 돌리지 않고 읽었을 때만 — 돌린 좌표는 원래 페이지 좌표와 다르다
        box = (round(ln.x, 1), round(ln.y, 1), round(ln.x + ln.w, 1), round(ln.y + ln.h, 1)) if best_rot == 0 else None
        _take_line(ln.text, f"{pno}페이지 OCR {k}행", fields, body, box)
    return True


def extract(path: Path) -> Document:
    pdf = pdfium.PdfDocument(path.read_bytes())  # 핸들 즉시 반납 (탐색기 간섭 방지)
    fields: dict[str, Field] = {}
    body: list[TextLine] = []
    poor_pages, imaged = 0, False
    ocr_pages: list[int] = []
    page_count = len(pdf)
    try:
        for pno in range(1, page_count + 1):
            page = pdf[pno - 1]
            textpage = page.get_textpage()
            raw_all = textpage.get_text_bounded() or ""
            page_chars = 0
            for lno, raw in enumerate(raw_all.splitlines(), start=1):
                line = raw.strip()
                if not line:
                    continue
                page_chars += len(line)
                n_before = len(fields)
                _take_line(line, f"{pno}페이지 {lno}행", fields, body)
                if page_count > 1 and len(fields) > n_before:
                    # 도면 세트(여러 쪽)에서는 표제란 줄도 본문에 둔다 — 첫 쪽의 라벨 줄만 필드로 빼면,
                    # 앞에 표지 한 쪽이 끼어들 때 옛 첫 쪽의 표제란 4줄이 새 2쪽 '본문'으로 내려와
                    # 전부 '글자 추가'가 됐다 (검토21 감지 차단 3). 필드와 겹치는 글자 변경은
                    # diff_documents가 걸러 낸다
                    body.append(TextLine(line, f"{pno}페이지 {lno}행"))
            if page_chars < _POOR_PAGE_CHARS:
                # 벡터 변환 페이지는 객체가 수만 개 — 판정에 필요한 만큼만 보고 중단
                has_image, nontext = False, 0
                for o in page.get_objects(max_depth=2):
                    if o.type == _OBJ_IMAGE:
                        has_image = True
                        break
                    if o.type != _OBJ_TEXT:
                        nontext += 1
                        if nontext >= _MIN_CONTENT_OBJS:
                            break
                if has_image or nontext >= _MIN_CONTENT_OBJS:
                    poor_pages += 1  # 내용은 그려져 있는데 글자만 못 읽는 페이지
                    imaged = imaged or has_image
                    # 스캔본·SHX 출력 — Windows OCR이 있으면 읽는다 (2026-09-06). 추정값이라 위치 표기에 'OCR'
                    if OCR_ENABLED and len(ocr_pages) < ocr_page_cap() and _ocr_page(page, pno, fields, body):
                        ocr_pages.append(pno)
            textpage.close()
            page.close()
    finally:
        pdf.close()

    notes: list[str] = []
    # OCR로 읽은 페이지는 '비교 불가'가 아니다 — 고지(notes)는 비교를 막는 신호라 남기지 않고, 위치 표기의
    # 'OCR'로 추정값임을 알린다. 절반 넘게 못 읽었을 때만 예전처럼 비교 불가 고지
    poor_pages -= len(ocr_pages)
    if ocr_pages and poor_pages:
        # 앞 30쪽만 OCR한 긴 스캔본 — 읽은 만큼은 비교하고, 못 읽은 뒤쪽은 그림 비교만 (리뷰12 낮음-D).
        # 다만 **못 읽었다는 사실**은 남긴다 — 예전에는 0으로 지워 고지가 사라졌고, 31쪽 이후 변경이
        # "글자·표·그림 동일, 확인 대상 아님"으로 접혔다 (검토33 C4, 원칙 5)
        notes.append(f"긴 스캔본이라 앞 {len(ocr_pages)}쪽만 글자를 읽었습니다 — "
                     f"{len(ocr_pages) + 1}쪽 이후 {poor_pages}쪽은 글자 비교를 하지 못했습니다")
        poor_pages = 0
    if poor_pages and poor_pages * 2 >= page_count:
        if imaged:
            reason = "스캔본(이미지) PDF로 보입니다"
            fix = "원본 CAD·문서에서 텍스트가 포함된 PDF로 다시 출력해야 비교할 수 있습니다"
        else:
            reason = "글자가 선(벡터)으로 변환된 출력으로 보입니다 (CAD SHX 글꼴 등)"
            fix = "CAD에서 TrueType 글꼴을 사용해 PDF로 출력하면 비교할 수 있습니다"
        try:
            from watcher import ocr as _ocr
            if not OCR_ENABLED:
                fix += " (설정에서 OCR이 꺼져 있습니다 — 켜면 Windows OCR로 글자를 읽습니다)"
            else:
                ok_, why_ = _ocr.status()
                fix += (f" ({why_})" if not ok_ else
                        " (Windows OCR로도 글자를 알아보지 못했습니다 — 해상도가 낮거나 손글씨·도장일 수 있습니다)")
        except Exception:
            pass
        # 표제란은 글자인데 도면 본체만 벡터인 PDF가 흔하다 — 그런 파일은 필드를
        # 멀쩡히 읽고도 "비교가 불가능합니다"라고 고지하고 **Rev 변경을 통째로
        # 빠뜨렸다**. 같은 폴더의 같은 도면 8장이 OCR이 그 장을 우연히 읽었는지에
        # 따라 셋으로 갈렸다 (2026-09-09 배포 후 검토 차단 2 실증, 원칙 5).
        # 읽은 것이 있으면 '일부만 읽음'으로 고지하고 비교는 그대로 한다.
        if fields or len(body) >= 2:
            got = ", ".join(sorted(fields)[:4]) or f"본문 {len(body)}줄"
            notes.append(
                f"{PARTIAL_READ_NOTE}: {page_count}페이지 중 {poor_pages}페이지의 글자를"
                f" 읽지 못했습니다 — {reason}. 읽은 것({got})은 그대로 비교하고,"
                f" 못 읽은 부분은 그림 비교로만 봅니다. {fix}.")
        else:
            notes.append(
                f"{page_count}페이지 중 {poor_pages}페이지에서 텍스트가 거의 추출되지 않았습니다"
                f" — {reason}. 이 파일은 텍스트 기반 내용 비교가 불가능합니다. {fix}.")
    return Document(doc_type="pdf", path=str(path), fields=fields,
                    raw_texts=body, notes=notes)
