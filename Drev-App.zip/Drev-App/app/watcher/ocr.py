# -*- coding: utf-8 -*-
"""Windows 내장 OCR — 글자가 없는 PDF(스캔본, CAD가 SHX 글꼴을 선으로 바꿔 출력한 도면)를 읽는다 (2026-09-06).

엔진은 Windows 10/11에 들어 있는 Windows.Media.Ocr이고 PC 밖으로 아무것도 나가지 않는다(원칙 1).
파이썬에서는 PyWinRT 투영(winrt-Windows.Media.Ocr, MIT)으로 부른다. 없는 PC(언어팩 없음·다른 OS·
패키지 없음)에서는 `available()`이 False고 추출기는 예전처럼 '읽지 못함' 고지를 남긴다.

이 모듈은 메모리 안의 픽셀만 다룬다 — 파일을 쓰지 않는다(원칙 2). 결과는 '추정값'이라 호출자가
그 표시를 남긴다(원칙 5: 최종 판단은 사람).
"""

from __future__ import annotations

import asyncio
import threading
from dataclasses import dataclass

OCR_DPI = 300                  # 표제란 글자(2~3mm)가 30px 안팎으로 보이는 해상도 — 이 아래면 0/O·1/I 오인이 는다
_MAX_SIDE = 9000               # 엔진 상한(10,000px) 아래로 — A1 도면은 배율을 낮춰 맞춘다
_LANGS = ("ko", "en")          # 국내 PC는 ko 팩이 기본이고 그 안에서 영문·숫자도 읽는다

_engine = None
_engine_tried = False
_lock = threading.Lock()


@dataclass
class OcrLine:
    text: str
    x: float                   # 왼쪽 위 (pt, 72dpi 기준 — PDF 좌표계와 같다)
    y: float
    w: float
    h: float


def _make_engine():
    from winrt.windows.globalization import Language
    from winrt.windows.media.ocr import OcrEngine
    for tag in _LANGS:
        try:
            eng = OcrEngine.try_create_from_language(Language(tag))
        except Exception:
            eng = None
        if eng is not None:
            return eng
    try:
        return OcrEngine.try_create_from_user_profile_languages()
    except Exception:
        return None


def engine():
    """엔진 하나를 오래 쓴다(만드는 데 수십 ms). 못 만들면 None — 다시 시도하지 않는다."""
    global _engine, _engine_tried
    with _lock:
        if not _engine_tried:
            _engine_tried = True
            try:
                _engine = _make_engine()
            except Exception:
                _engine = None
        return _engine


def available() -> bool:
    return engine() is not None


def status() -> tuple[bool, str]:
    """(쓸 수 있나, 못 쓰는 이유) — '언어팩 없음'과 '패키지 없음'을 가른다 (리뷰12 낮음-G)."""
    if engine() is not None:
        return True, ""
    try:
        import winrt.windows.media.ocr  # noqa: F401
    except Exception as e:
        return False, f"OCR 구성요소(winrt)를 불러오지 못했습니다 ({type(e).__name__})"
    return False, "이 PC에 Windows OCR 언어팩(한국어·영어)이 없습니다 — Windows 설정 › 시간 및 언어 › 언어에서 한국어를 추가하세요"


_CONFUSABLE = str.maketrans({"O": "0", "o": "0", "I": "1", "l": "1", "|": "1", "S": "5", "s": "5", "B": "8",
                             "Z": "2", "z": "2", "G": "6", "Q": "0", "D": "0"})


def normalize(text: str) -> str:
    """OCR 글줄끼리 비교할 때의 정규화 — 재스캔(기울기·밝기)에서 흔들리는 혼동 문자(O/0·I/1·S/5·B/8)와
    구두점·공백을 지운다. 같으면 '같은 글자'로 본다 (리뷰12 중간-B·C). 표시용이 아니다."""
    s = "X".join(str(text or "").upper().split(")("))      # ')('는 x의 오인
    s = s.translate(_CONFUSABLE)
    return "".join(ch for ch in s if ch.isalnum())


def language() -> str:
    eng = engine()
    try:
        return str(eng.recognizer_language.language_tag) if eng is not None else ""
    except Exception:
        return ""


_loop = None
_loop_thread = None
_rec_lock = threading.Lock()      # 엔진은 RecognizeAsync를 하나씩만 받는다 — 동시 호출은 예외 (리뷰12 운영 중간-1)


def _get_loop():
    """모듈 상주 이벤트 루프(데몬 스레드) — 쪽마다 asyncio.run으로 루프·self-pipe를 새로 만들지 않는다.
    루프가 멈췄거나 스레드가 죽었으면 새로 띄운다 (리뷰13 낮음-3: 멈춘 루프에 호출마다 120초 대기)."""
    global _loop, _loop_thread
    with _lock:
        if _loop is None or _loop.is_closed() or _loop_thread is None or not _loop_thread.is_alive():
            loop = asyncio.new_event_loop()
            th = threading.Thread(target=loop.run_forever, daemon=True, name="drev-ocr-loop")
            th.start()
            _loop, _loop_thread = loop, th
        return _loop


def _run(coro):
    """동기 호출 — 어느 스레드에서 불러도(웹 화면·검사·자식) 상주 루프에 넘기고 결과를 기다린다.
    응답이 없으면 그 작업을 취소하고 OSError(일시적 오류로 취급되어 캐시되지 않는다)."""
    import concurrent.futures as _cf
    with _rec_lock:
        fut = asyncio.run_coroutine_threadsafe(coro, _get_loop())
        try:
            return fut.result(timeout=120)
        except _cf.TimeoutError:
            fut.cancel()
            raise OSError("OCR 엔진이 120초 안에 응답하지 않았습니다")


async def _recognize_async(gray: bytes, width: int, height: int):
    from winrt.windows.graphics.imaging import BitmapPixelFormat, SoftwareBitmap
    eng = engine()
    if eng is None:
        return None
    bmp = SoftwareBitmap.create_copy_from_buffer(gray, BitmapPixelFormat.GRAY8, width, height)
    return await eng.recognize_async(bmp)


def recognize_gray(gray: bytes, width: int, height: int, scale: float = 1.0) -> list[OcrLine]:
    """8비트 그레이 픽셀(행 우선, 폭×높이)에서 글줄을 읽는다. scale = px/pt (좌표를 pt로 되돌리는 데 쓴다).
    엔진이 없으면 빈 목록."""
    if not gray or width <= 0 or height <= 0 or len(gray) < width * height:
        return []
    res = _run(_recognize_async(gray, width, height))
    if res is None:
        return []
    out: list[OcrLine] = []
    for line in res.lines:
        text = " ".join(str(line.text).split())
        if not text:
            continue
        words = list(line.words)
        if words:
            x0 = min(w.bounding_rect.x for w in words)
            y0 = min(w.bounding_rect.y for w in words)
            x1 = max(w.bounding_rect.x + w.bounding_rect.width for w in words)
            y1 = max(w.bounding_rect.y + w.bounding_rect.height for w in words)
        else:
            x0 = y0 = x1 = y1 = 0.0
        out.append(OcrLine(text, x0 / scale, y0 / scale, (x1 - x0) / scale, (y1 - y0) / scale))
    return out


def recognize_pdf_page(page, dpi: int = OCR_DPI, rotation: int = 0) -> list[OcrLine]:
    """pypdfium2 페이지 하나를 그려서 읽는다 — 파일은 이미 열려 있고 여기서는 메모리 그림만 만든다.
    rotation: 0·90·180·270 — 뒤집히거나 옆으로 누운 스캔은 바로 세워 다시 읽는다 (리뷰12 중간-A)."""
    if engine() is None:
        return []
    w_pt, h_pt = page.get_size()
    scale = dpi / 72.0
    longest = max(w_pt, h_pt) * scale
    if longest > _MAX_SIDE:
        scale = _MAX_SIDE / max(w_pt, h_pt)
    img = page.render(scale=scale, grayscale=True, rotation=rotation).to_pil()
    if img.mode != "L":
        img = img.convert("L")
    w, h = img.width, img.height
    raw = img.tobytes()
    del img                              # A0 30쪽에서 쪽당 100MB 넘게 겹치던 것 (리뷰12 운영 낮음-5)
    return recognize_gray(raw, w, h, scale)


def recognize_png(png: bytes, scale: float = 1.0) -> list[OcrLine]:
    """기록해 둔 페이지 그림(PNG 바이트)을 읽는다 — 시험·미리보기용."""
    import io
    from PIL import Image
    decode = Image.open          # 메모리 버퍼(BytesIO)의 PNG 해독 — 파일을 열지 않는다
    img = decode(io.BytesIO(png)).convert("L")
    img.load()
    return recognize_gray(img.tobytes(), img.width, img.height, scale)
