# -*- coding: utf-8 -*-
"""변경 목록 → 일일 브리핑 HTML.

Stage 2: 파일 수준 변경(추가/수정/삭제)만 담는다.
Stage 3에서 "확인 필요 M건 + 근거" 섹션이 추가된다 (build_brief의 구조는 그걸 수용하게 잡아둠).
메일 클라이언트 호환을 위해 인라인 스타일의 단순 테이블만 쓴다.
"""

from __future__ import annotations

import html
import re
from collections import Counter
from datetime import datetime
from pathlib import PurePosixPath

from watcher.rowkey import split_row_cell
from watcher.state import KIND_LABEL as _KIND_LABEL
from watcher.state import Change

_KIND_COLOR = {"added": "#1a7f37", "modified": "#9a6700", "removed": "#cf222e"}
# 사양 단위를 품은 값 — 목차에서 접지 않을 '중요한' 글자 변경의 표식
# 전장·기구 사양 단위 — AT·AF(차단기 정격)·mA·kVA·m/min·MP·Nm·W가 빠져 'MCCB 100AT→125AT'가 "글자 변경
# 1건"으로만 보이고 Rev만 올린 도면 아래로 깔렸다 (검토21 브리핑 중간 6)
_UNIT_RE = re.compile(r"\d\s*(?:kW|KW|kw|㎾|kVA|kVAR|kvar|HP|mA|AT|AF|A|V|VDC|VAC|Hz|W|Nm|N·m|mm|㎜|MM|m/min|mm/s|"
                      r"SQ|㎟|rpm|RPM|bar|MPa|kPa|kg|EA|MP|℃|°C|Ø|φ)(?![A-Za-z])")

_STYLE_TABLE = "border-collapse:collapse;width:100%;font-size:14px"
# 확인 기록 켬/끔 (config ack_tracking, 기본 켬) — 끄면 브리핑에서 확인 열·회신 안내·미확인 동선을 뺀다 (기능 검토 2026-11-02 M5).
# 검사 한 회분 동안만 cli가 세운다(contextvars — 화면 스레드와 섞이지 않게)
import contextvars as _cv
ACK_ON: "_cv.ContextVar[bool]" = _cv.ContextVar("drev_ack_on", default=True)


def _ack_td(inner: str) -> str:
    return f'<td style="{_STYLE_TD}">{inner}</td>' if ACK_ON.get() else ""
_STYLE_TH = ("text-align:left;padding:6px 10px;border-bottom:2px solid #d0d7de;"
             "background:#f6f8fa;color:#57606a;white-space:nowrap")   # 머리는 짧다 — '구/분'·'수/정'으로 쪼개졌다 (검토44 C 낮음 1)
# 칸 안에서 긴 낱말도 접히게 — 메일 앱이 <style>(480px 미디어쿼리)을 버리면 폰(375px)에서 표가 478px로 넘쳤다
# (검토43 C 중간 7). 인라인이라야 살아남는다
_STYLE_TD = "padding:6px 10px;border-bottom:1px solid #d0d7de;overflow-wrap:anywhere;word-break:keep-all"  # 한글 낱말 안에서 꺾지 않게 (검토63 C3)


def human_ev(s: str) -> str:
    """근거 줄의 내부 표기를 사람 말로 — 저장 형식(재발 판정이 읽는다)은 그대로 두고 보일 때만. 'SPEC=125AT'·'BOM!행4'는
    구매 담당이 못 읽었다 (검토49 C 중간 8). 값·파일 이름·경로는 원본 그대로 — 일상어는 plain_words가 고른 위치 표기에만 (ux22 A)."""
    s = _EV_OLD_HEAD.sub(r"\1개정표", str(s or ""))     # 옛 머리 '리비전 블록 최신 행:'도 새 이름으로 (검토71 R4 중간 4)
    return _map_places(s, lambda t: _SPEC_WORD.sub("규격 ", t))


# ── 이전/지금 두 줄 (2026-11-21) — 문장·근거 줄의 화살표 ──────────────────────────────────────────────────────────
# 값 사이 화살표(→)를 메일·사내망 어디에도 남기지 않는다(세부 점검표 A10). 저장된 문구·근거는 그대로 두고 보일 때만 바꾼다:
#  - 근거 줄 '표제란 REV: A → B (표제란(도면 층 TITLE))' → (바뀐 곳, 이전, 지금, 위치) — 부르는 쪽이 이름표 두 줄로 그린다(ev_pair)
#  - 문장 'Rev가 A→B로 거꾸로 갔습니다'·'Rev A→B로 올렸지만' → 'Rev가 A에서 B로 …'·'Rev를 A에서 B로 올렸지만', 출도·발주 '바뀐 값'
#    자리의 붙은 값 '50→60AT' → '60AT(이전 50AT)' (unarrow)
#  - 검토 Y2(2026-11-22): 저장 한 줄 글을 다시 쪼개면 값 속 쉼표·쌍점·화살표에서 이전 값이 바뀌었다 — 항목이 있는 자리는 항목에서 바로
#    (summary.was_line·headline(was=True)), 근거 줄은 확실할 때만(ev_parts), 아니면 원문 그대로
_SENTENCE = re.compile(r"[,;.]\s|습니다|니다|[가-힣]다\b")


def is_tag_word(w: str) -> bool:
    """낱말 하나가 진짜 태그('M-302'·'MCCB-104')인가 — 바뀐 곳으로 떼는 규칙 한 곳(extract.base.find_tags). 숫자가 든 낱말('3P'·'1'·
    '2026-10-01')은 태그가 아니다 — 감시 화면 _arrow_split이 '숫자 든 첫 낱말'을 떼어 '3P 100AT → 3P 125AT'의 이전 값이 '100AT'로
    보였다 (검토 Y2 M2)."""
    if not w:
        return False
    from watcher.extract.base import find_tags
    return find_tags(w) == [w]


# 끝 괄호가 위치 꼴인가 — 추출기 위치('레이어 E'·'표제란(…)'·'BOM!행5')와 화면 말('도면 층 E'·'BOM 시트 5행')·경로·좌표.
# 아니면 값의 일부다: 'PUMP (A) → PUMP (B)'의 '(B)'를 위치로 떼어 지금 값이 'PUMP'로 보였다 (검토 Y2 H2)
_EV_WHERE_WORD = re.compile(r"레이어 |도면 층 |표제란|개정표|리비전 블록|개정이력|머리글|바닥글|머리말|꼬리말|시트 \d+행|!행\d+|"
                            r"(?<![\w])[xy]=-?\d|좌표 \(|변경 전후 동일|블록 속성|배치공간|첫 틀|틀 \d|\d+\s*(?:쪽|페이지)|본문|문단 \d|"
                            r"\.(?:dxf|dwg|pdf|xlsx?|xlsm|docx?|hwpx?)\b|^내용 비교$|^발주 대조$", re.I)


def _ev_tail(s: str) -> tuple[str, str]:
    """'값 (위치)' → (값, 위치) — 끝 괄호(짝 맞춤)가 위치 꼴이거나 빈 '()'(위치 없는 항목)일 때만. ' · 위치 …' 꼬리도. 아니면 (s, '')."""
    s = s.rstrip()
    a, sep, b = s.rpartition(" · 위치 ")
    if sep and a.strip():
        return a.rstrip(), b.strip()
    if not s.endswith(")"):
        return s, ""
    depth = 0
    for i in range(len(s) - 1, -1, -1):
        if s[i] == ")":
            depth += 1
        elif s[i] == "(":
            depth -= 1
            if depth == 0:
                if i == 0 or not s[i - 1].isspace():
                    return s, ""
                inner = s[i + 1:-1]
                if not inner.strip() or _EV_WHERE_WORD.search(inner):
                    return s[:i].rstrip(), inner.strip()
                return s, ""
    return s, ""


def _ev_tail_pair(left: str, right0: str) -> tuple[str, str]:
    """지금 값 끝의 위치 꼬리를 뗀다(_ev_tail) — 단, 이전 값도 같은 괄호로 끝나고 떼고 난 지금 값은 그 괄호로 끝나지 않으면 그 괄호는
    값의 일부다('CV 2.5SQ (도면 층 변경) → CV 4SQ (도면 층 변경)'·'상세 A (3쪽) → 상세 B (3쪽)'). 위치는 언제나 지금 값 뒤에만
    붙는다 — 이전 값에 같은 괄호가 있으면 위치가 아니라 두 값이 함께 가진 글이다 (검토 Z1 M1: 지금 값 끝이 잘려 보였다)."""
    right, w = _ev_tail(right0)
    r0 = right0.rstrip()
    if w and right != r0:
        tail = r0[len(right):].strip()
        if tail.startswith("(") and left.rstrip().endswith(tail) and not right.endswith(tail):
            return r0, ""
    return right, w


def ev_cut_where(v) -> tuple[str, str]:
    """근거 값 '이전 → 지금 (위치)'의 끝 위치 꼬리 → ('이전 → 지금', '위치') — 끝 괄호가 위치 꼴일 때만(_ev_tail_pair). 아니면 (값, '').
    감시 화면이 경로 없는 줄에서 꼴과 관계없이 끝 괄호를 위치로 떼어 'PUMP (A) → PUMP (B)'가 지금 'PUMP'·위치 'B'였다 (검토 Z1)."""
    s = str(v or "").rstrip()
    left, sep, right0 = s.rpartition(" → ")
    if not sep:                                       # 붙여 쓴 화살표만('A→B (레이어 E)') — 위치 꼴 꼬리만
        body, w = _ev_tail(s)
        return (body, w) if (w and body != s) else (s, "")
    right, w = _ev_tail_pair(left, right0)
    if right == right0.rstrip():
        return s, ""
    return f"{left}{sep}{right}", w


def ev_parts(line, keyless: bool = True, placed: bool = False) -> tuple | None:
    """근거 줄 하나 → (머리, 바뀐 곳, 이전, 지금, 위치) — **확실할 때만**, 아니면 None(부르는 쪽은 원문 그대로 보인다 — 틀린 값보다
    원문이 낫다, 원칙 4). 글자는 고치지 않고 자르기만 한다 (검토 Y2 H2·M2·M3, 2026-11-22):
    - 띄운 화살표(' → ')가 정확히 하나: 근거 줄의 가름 화살표는 언제나 ' → '라, 하나뿐이면 값 속 화살표('FLOW→TANK')는 붙어 쓴 것이고
      가름 자리가 하나로 정해진다. 둘 이상이면(MTEXT 덩이 'NOTE 1. … → 단자대 …') 어디서 갈라야 할지 모른다
    - 끝 괄호는 위치 꼴일 때만 위치('PUMP (A) → PUMP (B)'의 '(B)'는 값)
    - 머리 꼴 '머리: 이전 → 지금': 양쪽 값의 쌍점 수가 같게 머리를 정한다('H-511 HEATER 2kW: 220V → H-511 HEATER 3kW: 380V'는 머리가
      아니라 태그 줄), 양쪽이 같은 머리로 시작하면('X-12 IN: 3 → X-12 IN: 4') 그것이 머리
    - 머리 없는 줄(keyless): 한쪽이 '—'(없던·없어진 글)이면 그대로, 양쪽 첫 낱말이 같은 태그면 바뀐 곳으로 떼고, 아니면 양쪽 낱말 수가
      같은 짧은 값일 때만 — 이름표('표제란 일자 2026-10-01 → 2026-09-01')를 이전 값에 넣지 않게 (M3)"""
    s = " ".join(str(line or "").split())
    if s.count(" → ") != 1:
        return None
    left, right0 = s.split(" → ")
    if placed:
        # 부르는 쪽이 위치를 이미 뗐다 — 또 떼면 값 끝 괄호('CV 4SQ (도면 층 변경)')가 위치로 잘린다 (검토 Z1 M1)
        right, w = right0.rstrip(), ""
    else:
        right, w = _ev_tail_pair(left, right0)
        placed = right != right0.rstrip()            # 위치 꼬리(빈 '()' 포함)를 뗐다 — 추출기 항목 줄
    left, right = left.strip(), right.strip()
    if not left or not right:
        return None
    lp = left.split(": ")
    rc = right.count(": ")
    lt, rt = left.split(" "), right.split(" ")
    # 양쪽이 같은 태그로 시작하는 태그 줄 — 이전 값에만 쌍점이 있어도('H-819 2kW: 220V → H-819 3kW') 머리가 아니라 태그가 바뀐 곳.
    # 쌍점 수 맞추기로 남는 앞을 머리로 떼면 이전 '220V'·지금 'H-819 3kW'로 없는 값이 보였다 (검토 Z1 H1)
    same_tag = len(lt) > 1 and len(rt) > 1 and lt[0] == rt[0] and is_tag_word(lt[0])
    if len(lp) > 1:
        hk = lp[0]
        if right.startswith(hk + ": ") and "→" not in hk:
            o, n = left[len(hk) + 2:].strip(), right[len(hk) + 2:].strip()
            if o and n and o.count(": ") == n.count(": "):
                return hk, "", o, n, w
        cut = len(lp) - 1 - rc                       # 이전 값이 지금 값과 같은 수의 쌍점을 갖게 — 남는 앞이 머리
        if cut >= 1 and not same_tag:
            head = ": ".join(lp[:cut]).strip()
            o = ": ".join(lp[cut:]).strip()
            if head and o and "→" not in head and len(head) <= 120:
                return head, "", o, right, w
    if not keyless:
        return None
    if left == "—" or right == "—":
        return "", "", left, right, w
    if same_tag:
        return "", lt[0], " ".join(lt[1:]), " ".join(rt[1:]), w
    if left.count(": ") != rc:
        return None
    if placed:
        # 위치 꼴 괄호가 붙은 머리 없는 줄은 추출기 항목 줄('이전 → 지금 (위치)', consistency._fmt_item) — 바뀐 곳 칸이 없는 꼴이라
        # 왼쪽 전체가 이전 값, 오른쪽 전체가 지금 값이다(가름 화살표도 하나로 정해졌다). 따옴표·긴 문장 값도 그대로
        return "", "", left, right, w
    if (len(lt) == len(rt) and len(left) <= 60 and len(right) <= 60 and not _SENTENCE.search(f"{left} {right}")
            and not any(x in f"{left} {right}" for x in (" — ", "'", '"'))):    # '띄어쓰기만 바뀜 — 'a' → 'b''는 문장(따옴표 규칙이 맡는다)
        return "", "", left, right, w
    return None


def ev_pair(line, keyless: bool = False) -> tuple | None:
    """근거 줄 '바뀐 곳: 이전 → 지금 (위치)' → (바뀐 곳, 이전, 지금, 위치). 꼴이 아니거나 확실하지 않으면 None. 글자는 그대로.
    keyless: 바뀐 곳 없는 줄 'M-302 MOTOR 3.7kW → M-302 MOTOR 5.5kW (위치)'도 — 두 값의 같은 첫 낱말이 태그면 바뀐 곳으로 뗀다(앞머리
    떼기, 메일 _m_text_rows와 같은 규칙: 바뀐 곳 M-302, 값 MOTOR 3.7kW / MOTOR 5.5kW). 규칙은 ev_parts 한 곳 (2026-11-21 L, Y2 2026-11-22)."""
    p = ev_parts(line, keyless)
    if not p:
        return None
    head, key, o, n, w = p
    return (head or key), o, n, w


def ev_none(v: str, keyed: bool) -> str:
    """근거 줄의 빈 값 표기 '—'를 두 줄 칸에 보일 말로 — 머리·바뀐 곳 없는 줄(글자 추가·삭제)은 '없음'(없던·없어진 글), 머리 있는 줄
    (표 칸·표제란 칸)은 '(빈칸)'. '—'가 값인지 없음인지 모호했다 (검토 Y2 M4·M1)."""
    if v != "—":
        return v
    return "(빈칸)" if keyed else "없음"


_SAME_MARK = "변경 전후 동일"           # 검사가 근거 줄 위치 괄호 앞에 다는 표지 — 'DATE: X → X (변경 전후 동일, 위치)'


def same_value_text(lead: str, v: str, w: str = "") -> str:
    """이전·지금이 같은 값인 근거 한 줄 — '표제란 DATE: 2026-09-01 (그대로, 위치)'. 같은 값을 '2026-09-01(이전 2026-09-01)'·
    '이전 X · 지금 X'로 짝지어 보여 바뀐 값처럼 읽혔다 (검토 Z1 낮음, Y1 2026-11-22). 위치 괄호의 '변경 전후 동일' 표지는 '그대로'와
    같은 말이라 한 번만 — 위치는 그대로 둔다(원칙 4). 감시 변경 상세 상자·대장·사내망 xlsx·화면 두 줄 칸이 이 함수 하나를 쓴다."""
    rest = str(w or "").strip()
    if rest.startswith(_SAME_MARK):
        rest = rest[len(_SAME_MARK):].lstrip(" ,").strip()
    return (f"{lead}: " if lead else "") + f"{v} (그대로" + (f", {rest}" if rest else "") + ")"


def _ev_fmt(p: tuple, style: str = "was") -> str:
    """ev_parts 결과 → 한 줄. style 'was': '바뀐 곳: 지금(이전 …) (위치)', 'pair': '바뀐 곳: 이전 A · 지금 B (위치)'(알림 상자).
    없던·없어진 글('— → 밸브 닫힘')은 짝이 아니라 '글자 추가: 밸브 닫힘'·'글자 삭제: …', 머리 있는 줄의 빈 값은 '(빈칸)' (Y2 M4).
    이전·지금이 같은 값이면 짝 대신 '값 (그대로, 위치)' (same_value_text)."""
    head, key, o, n, w = p
    tail = f" ({w})" if w else ""
    lead = head or key
    if o == n and o != "—":
        return same_value_text(lead, n, w)
    if not head and not key and (o == "—") != (n == "—"):
        return (f"글자 추가: {n}" if o == "—" else f"글자 삭제: {o}") + tail
    o2, n2 = ("(빈칸)" if o == "—" else o), ("(빈칸)" if n == "—" else n)
    if style == "pair":
        return (f"{lead}: " if lead else "") + f"이전 {o2} · 지금 {n2}" + tail
    from watcher.summary import was_pair
    return (f"{lead}: " if lead else "") + was_pair(o2, n2) + tail


def _looks_ev(s: str) -> bool:
    """값이 실린 근거 줄 꼴('… → … (위치)')인가 — 이런 줄은 갈라지지 않으면 원문 그대로 둔다(문장 규칙을 돌리지 않는다, Y2 H4)."""
    if " → " not in s:
        return False
    body, w = _ev_tail(s)
    return bool(w) or body != s.rstrip() or s.rstrip().endswith("()")


_SP_PAREN = re.compile(r"(바뀐 값\()([^()]*→[^()]*)(\))")                 # issued: '원본에서 바뀐 값(100→125AT 외 1건)이 …'
_SP_COLON = re.compile(r"(바뀐 값: )([^\n]*?→[^\n]*?)(?= \(| — |$)")       # 사실 한 줄 '… 뒤 바뀐 값: 100→125AT' · 발주 대조 표지
_SP_NUM = re.compile(r"([-+]?\d[\d.,/]*)")
_SP_NUM_U = re.compile(r"([-+]?\d[\d.,/]*)([A-Za-z%㎾㎟℃°Ω]+)")
_DATE = r"\d{4}[-./]\d{1,2}[-./]\d{1,2}(?: \d{1,2}:\d{2}(?::\d{2})?)?"
_DATE_PAIR = re.compile(rf"({_DATE}|없음) ?→ ?({_DATE}|없음)")            # 표제란 일자·저장 시각 '2026-10-01 → 2026-09-01'


_QUOTE_PAIR = re.compile(r"('[^'\n]*'|\(없음\)) ?→ ?('[^'\n]*'|\(없음\))")


def _q_none(v: str) -> str:
    return "없음" if v == "(없음)" else v


_SQUARE_TR = str.maketrans("()", "[]")          # issued._SQUARE와 같은 바꿈 — 저장 문구의 값 괄호는 [] (대조 키에서 값 자리를 지키려고)
_POST_EV = re.compile(r"^(?:(?P<name>.+?): )?출도본 (?P<iv>.*?) → 원본 지금 (?P<rest>.*)$")


def post_pairs(evidence) -> list:
    """'출도 후 변경' 근거 줄('M-1: 출도본 100 → 원본 지금 125AT (위치)')의 (출도본 값, 원본 지금 값) — 저장 문구의 short_pair 글은
    '100→125AT'가 '100AT→125AT'인지 '100→125AT'인지 글만으로 구별되지 않아(검토 Y2 H3) 보일 때 이 값으로 다시 만든다."""
    out = []
    for e in evidence or ():
        m = _POST_EV.match(" ".join(str(e or "").split()))
        if not m:
            continue
        nv, _w = _ev_tail(m.group("rest"))
        iv = m.group("iv")
        out.append(("" if iv == "—" else iv, "" if nv == "—" else nv))
    return out


def _sp_from_pairs(part: str, pairs) -> str | None:
    """short_pair 꼴 조각 하나를 근거 값 짝에서 다시 — 같은 short_pair 글을 내는 짝이 있으면 short_pair(was=True), 없으면 None."""
    for iv, nv in pairs or ():
        try:
            a = short_pair(iv, nv, 30)
        except Exception:      # noqa: BLE001 — 모르는 값은 글 규칙으로
            continue
        if part in (a, a.translate(_SQUARE_TR)):
            return short_pair(iv, nv, 30, was=True)
    return None


def _sp_unarrow(t: str, pairs=None) -> str:
    """short_pair 꼴 값 짝 → '지금(이전 …)': '100→125AT' → '125AT(이전 100AT)', 'SUS304→SUS316' → 'SUS316(이전 SUS304)',
    ', '로 이은 여럿은 조각마다, ' 외 N건' 꼬리는 그대로. 화살표가 하나가 아닌 조각은 손대지 않는다 (검토 Y2 H3, 2026-11-22):
    - pairs(출도본 근거의 값 짝, post_pairs)가 있으면 그 값으로 다시 만든다 — 글만으로는 단위가 양쪽에 있었는지 모른다
    - ', '로 나누는 것은 조각마다 화살표가 정확히 하나일 때만('0.5, 1.0MPa→0.8, 1.6MPa'는 한 짝)
    - 앞 숫자에 단위를 붙이는 것은 붙여도 지금 값과 같아지지 않을 때만('100→100AT'는 단위가 지금 값에만 있던 것)"""
    body, sep, tail = str(t).partition(" 외 ")
    pieces = body.split(", ")
    if len(pieces) > 1 and any(p.count("→") != 1 for p in pieces):
        pieces = [body]
    out = []
    for part in pieces:
        got = _sp_from_pairs(part, pairs) if pairs else None
        if got is not None:
            part = got
        elif part.count("→") == 1:
            a, b = (x.strip() for x in part.split("→"))
            mu = _SP_NUM_U.fullmatch(b)
            if mu and _SP_NUM.fullmatch(a) and a + mu.group(2) != b:
                a += mu.group(2)              # '100→125AT'의 앞 값에도 단위
            at, bt = a.split(" "), b.split(" ")
            if len(at) > len(bt) and "→ " in part:
                # 'MCCB-104 50AT → 60AT' — 앞 값이 더 길면 남는 앞 낱말이 바뀐 곳(태그): 'MCCB-104 60AT(이전 50AT)'
                key, a = " ".join(at[:len(at) - len(bt)]), " ".join(at[len(at) - len(bt):])
                part = f"{key} {b}(이전 {a})"
            else:
                part = f"{b}(이전 {a})"
        out.append(part)
    return ", ".join(out) + (sep + tail if sep else "")


def _ro(w: str) -> str:
    """조사 '로/으로' — 받침 있는 말(ㄹ 받침 빼고) 뒤는 '으로': 'Rev가 2에서 3으로' (Y2 L3). 숫자·영문은 읽는 소리로."""
    s = str(w or "").rstrip()
    if not s:
        return "로"
    ch = s[-1]
    if "가" <= ch <= "힣":
        jong = (ord(ch) - 0xAC00) % 28
        return "으로" if jong and jong != 8 else "로"
    if ch.isdigit():
        return "으로" if ch in "036" else "로"      # 영·삼·육은 받침(ㅇ·ㅁ·ㄱ), 일·칠·팔은 ㄹ
    if ch.isalpha() and ch.isascii():
        return "으로" if ch.upper() in "MN" else "로"   # 엠·엔
    return "로"


_REV_PAIR = r"([^\s→]+?) ?→ ?([^\s→]+?)"     # Rev 문구의 값 짝 — 값 속 화살표가 있으면(Rev 'A→B'→'B→C') 맞지 않는다(원문 그대로, Y2 L1)


def _headers(s: str, pairs=None) -> str:
    """프로그램이 붙인 머리·자리의 화살표만 말로 — 쪽 이동('이전 판 2페이지 → 새 판 3페이지'), 출도·발주 '바뀐 값' 자리(short_pair 꼴),
    펼친 근거 머리('(출도본 값 → 원본 지금 값, 위치)'·'원본 직전 값 → 지금 값'). 값이 실린 근거 줄에도 안전하다(값을 건드리지 않는다)."""
    s = _PAGE_MOVE.sub(r"새 판 \3\4(이전 판 \1\2)", str(s or ""))
    # 출도 후 변경·발주 대조 문구의 '바뀐 값' 자리는 short_pair 꼴('100→125AT'·'SUS304→SUS316'·'MCCB-104 50AT → 60AT'·', '로
    # 여럿·' 외 N건') — 조각마다 통째로 '지금(이전 …)'. 근거 줄 꼴 판정보다 먼저(출도 후 변경 사실 한 줄 '… 뒤 바뀐 값: A → B'를
    # 바뀐 곳 '… 뒤 바뀐 값'으로 읽지 않게 — 구현자 M 지적)
    s = _SP_PAREN.sub(lambda m: m.group(1) + _sp_unarrow(m.group(2), pairs) + m.group(3), s)
    s = _SP_COLON.sub(lambda m: m.group(1) + _sp_unarrow(m.group(2), pairs), s)
    s = re.sub(r"\(출도본 값 → 원본 지금 값, 위치\)", "(이전 = 출도본 값, 지금 = 원본 지금 값, 위치)", s)
    return re.sub(r"원본 직전 값 → 지금 값", "원본 직전 값과 지금 값", s)


def ev_text(line, style: str = "was", pairs=None) -> str:
    """근거 줄 **한 줄 자리**(대장 근거 칸·디스크 브리핑 '예:'·메일·사내망의 못 가른 근거 줄) — 확실히 갈리면 '바뀐 곳: 지금(이전 …)
    (위치)'(style 'pair'면 '이전 A · 지금 B'), 아니면 **원문 그대로**. 근거 줄은 도면 원문 값이 실린 줄이라 문장 규칙(붙은 숫자·날짜·
    따옴표 짝)을 돌리지 않는다 — '결선 3→4P 변경'이 '결선 4P(이전 3P) 변경'으로 도면에 없는 글자가 됐다 (검토 Y2 H4)."""
    s = _headers(line, pairs)
    p = ev_parts(s)
    return _ev_fmt(p, style) if p else s


def was_text(s, pairs=None) -> str:
    """한 줄 자리(엑셀 칸·툴팁·평문 한 줄)의 값 짝을 '지금(이전 …)'으로 — 근거 줄 꼴('바뀐 곳: 이전 → 지금 (위치)', 바뀐 곳 없는
    줄도)은 '바뀐 곳: 지금(이전 …) (위치)'(ev_parts가 확실할 때만), 값이 실린 근거 줄인데 못 가르면 원문 그대로, 나머지 문장은
    unarrow (이전/지금 2026-11-21 L, Y2 2026-11-22). 저장 글은 그대로, 보일 때만."""
    s = _headers(s, pairs)
    p = ev_parts(s)
    if p:
        return _ev_fmt(p, "was")
    if _looks_ev(s):
        return s
    return unarrow(s, ev=False, pairs=pairs)


def unarrow(s, ev: bool = True, pairs=None) -> str:
    """문장 안 값 사이 화살표를 말로 — 'Rev가 A→B로' → 'Rev가 A에서 B로', '출도 뒤 바뀐 값: 50→60AT' → '… 60AT(이전 50AT)'.
    ev: 근거 줄 꼴('바뀐 곳: 이전 → 지금 (위치)', 바뀐 곳 없는 'A → B (위치)'도)은 '바뀐 곳: 이전 A · 지금 B (위치)' — 두 줄로 그릴 수
    없는 한 줄 자리(알림 상자)용. 확실히 못 가르는 근거 줄은 원문 그대로(Y2 H2·H4). 따옴표 값 ''a' → 'b''·'문단 3개 → 5개'·
    '이전 판 2페이지 → 새 판 3페이지'(검사 참고 문구)도 '지금(이전 …)'.
    문장 규칙은 프로그램 문구 꼴에만 건다: 'Rev' 문구·날짜 짝·따옴표 짝·'N개'. 붙은 숫자 짝('50→60AT')은 출도·발주 '바뀐 값' 자리에서만
    (_headers) — 도면 글자 '결선 3→4P 변경'·'2→3차 수정'·'12→24VDC 전원'을 값 짝으로 읽어 글자 자체를 바꿔 보였다 (Y2 H4).
    pairs: 출도 후 변경 근거의 값 짝(post_pairs) — '바뀐 값' 자리를 그 값으로 다시 만든다(H3)."""
    s = _headers(s, pairs)
    if ev:
        p = ev_parts(s)
        if p:
            return _ev_fmt(p, "pair")
    if _looks_ev(s):
        return s
    # Rev 문구 — 값 속 화살표가 있으면(Rev 'A→B'→'B→C') 어디까지가 값인지 몰라 손대지 않는다 (Y2 L1). 조사는 받침대로 (L3)
    s = re.sub(rf"Rev가 {_REV_PAIR}로(?![^\s,.])", lambda m: f"Rev가 {m.group(1)}에서 {m.group(2)}{_ro(m.group(2))}", s)
    s = re.sub(rf"Rev {_REV_PAIR}[로를] 올", lambda m: f"Rev를 {m.group(1)}에서 {m.group(2)}{_ro(m.group(2))} 올", s)
    s = _DATE_PAIR.sub(r"\2(이전 \1)", s)
    s = re.sub(r"Rev([만는]?) ([^\s→]+?) ?→ ?([^\s,.()→]+)(?!→)",
               lambda m: m.group(0) if "rev" in (m.group(2).lower(), m.group(3).lower())      # 'Rev C→Rev B' — 값에 'Rev'가 들었다
               else f"Rev{m.group(1)} {m.group(3)}(이전 {m.group(2)})", s)
    # 따옴표 값(서명·띄어쓰기·표기 참고 문구) — "'홍길동' → '김철수'", "(없음) → '김철수'"
    s = _QUOTE_PAIR.sub(lambda m: f"{_q_none(m.group(2))}(이전 {_q_none(m.group(1))})", s)
    s = re.sub(r"(\d[\d,]*)개 ?→ ?(\d[\d,]*)개", r"\2개(이전 \1개)", s)
    return s


_SUM_CUT = re.compile(r"(, |: | · | — | 외 \d+[건곳])")
# 요약 조각으로 보이는 꼴(값 짝이 아닌 것) — 이웃 조각이 이 꼴이 아니면 쉼표·줄표가 값 속에 있던 것일 수 있다(아래 _unarrow_summary_safe)
_PIECE_WORD = re.compile(r"^(?:\[[^\]]{1,12}\] )?(?:글자 (?:추가|삭제|변경)|그림 변경|개정표|내용 |표시할 변경|Rev |이전 판|페이지|문단 이동|"
                         r"열 |시트 |행 순서|축척|크기|저장 시각|표제란|도면번호|문서번호|제목|프로젝트|첫 등록|새 파일|파일이|이름·위치|"
                         r"같은 내용|변경 사실|.*\d+(?:건|곳|쪽|개)(?: \(.*\))?$|.* 행 (?:추가|삭제|변경)(?: \(.*\))?$|.*Rev 미갱신|"
                         r".*내용 변경 없음|.*\(이전 )")


def _summary_frag_was(p: str) -> str | None:
    """요약 조각 하나(이웃이 확인된)의 '지금(이전 …)' — 확실한 꼴만, 아니면 None(원문 그대로):
    화살표가 정확히 하나, 값에 괄호·쌍점이 없고 바뀐 곳이 정해질 때 — 양쪽 낱말 수가 같으면 바뀐 곳 없음, 앞이 한 낱말 더 길고 그것이
    태그면 그 태그, 앞이 두 낱말 더 길고 첫 낱말이 태그이며 두 값이 숫자면 '태그 칸'(표 행), 양쪽이 같은 태그로 시작하면 같은 앞머리."""
    if p.count("→") != 1 or any(c in p for c in "()"):
        return None
    if " → " in p:
        left, right = p.split(" → ")
        lt, rt = left.split(" "), right.split(" ")
        if not left or not right:
            return None
        if len(lt) > 1 and len(rt) > 1 and lt[0] == rt[0] and is_tag_word(lt[0]):
            k = 0
            while k < len(lt) - 1 and k < len(rt) - 1 and lt[k] == rt[k]:
                k += 1
            from watcher.summary import was_pair
            return was_pair(" ".join(lt[k:]), " ".join(rt[k:]), " ".join(lt[:k]))
        from watcher.summary import was_pair
        if len(lt) == len(rt):
            # 앞이 태그로 시작하고 뒤는 아니면 '태그 이전 → 지금'(태그를 한 번만 쓴 조각)일 수도 있어 확실하지 않다 — 'L-517 없음 → LAMP 24V'
            return None if (is_tag_word(lt[0]) and lt[0] != rt[0]) else was_pair(left, right)
        if len(lt) == len(rt) + 1 and is_tag_word(lt[0]):
            return was_pair(" ".join(lt[1:]), right, lt[0])
        if (len(lt) == len(rt) + 2 == 3 and is_tag_word(lt[0]) and re.fullmatch(r"[-+]?\d[\d,.]*", lt[2])
                and re.fullmatch(r"[-+]?\d[\d,.]*", right)):
            return was_pair(lt[2], right, " ".join(lt[:2]))
        return None
    # 붙여 쓴 요약 조각 '열 이름 수량→QTY'·'축척 1:50→1:100'·'시트 이름 변경 BOM→BOM_최종' — 화살표 양옆 낱말 하나씩이 값
    m = re.fullmatch(r"(.*?)(\S+)→(\S+)", p, re.S)
    if m:
        return f"{m.group(1)}{m.group(3)}(이전 {m.group(2)})"
    return None


def _unarrow_summary_safe(s) -> str:
    """항목 없이 한 줄 요약을 화살표 없이 — **확실한 조각만** 바꾸고 나머지는 원문 그대로 (검토 Y2 H1, 2026-11-22).
    요약 조각은 ', '·': '·' — '·' · '로 이어지는데 값 속에도 같은 글자가 들 수 있다('0.5, 1.0MPa'·'HEATER 2kW: 220V'·'TANK — 10m3').
    그래서 화살표 든 조각은 ① 뒤가 ': '가 아니고(값이 쌍점 뒤로 이어짐) ② ', '·' — '·' · '로 붙은 이웃 조각이 요약 조각 꼴(값 짝·
    '글자 추가: …'·'… N건' 등)일 때만, ③ 그 조각이 _summary_frag_was의 확실한 꼴일 때만 바꾼다. '글자 추가: OUT→IN'은 짝이 아니다."""
    s = unarrow(str(s or ""), ev=False)
    toks = _SUM_CUT.split(s)
    frags, seps = toks[0::2], toks[1::2]

    def _like(j: int) -> bool:
        q = frags[j]
        return (q.count(" → ") == 1 and q.count("→") == 1) or bool(_PIECE_WORD.match(q))
    out = list(toks)
    for i, p in enumerate(frags):
        if "→" not in p:
            continue
        before = seps[i - 1] if i > 0 else None
        after = seps[i] if i < len(seps) else None
        if after == ": ":
            continue
        if before == ": " and frags[i - 1].endswith(("글자 추가", "글자 삭제")):
            continue
        if before in (", ", " — ", " · ") and not _like(i - 1):
            continue
        if after in (", ", " — ", " · ") and not _like(i + 1):
            continue
        got = _summary_frag_was(p)
        if got is not None:
            out[2 * i] = got
    return "".join(out)


def unarrow_summary(s, items=None) -> str:
    """기록의 한 줄 요약('[도면] E-101 (P): M-101 MOTOR 5.5kW → MOTOR 7.5kW, Rev A → B')을 보일 때만 화살표 없이 —
    'M-101 MOTOR 7.5kW(이전 MOTOR 5.5kW)'. items(그 변경의 항목)를 주면 항목에서 만든 조각과 글자까지 같은 곳만 바꾼다(summary.was_line —
    다시 쪼개 짐작하지 않는다, 검토 Y2 H1). 없으면 확실한 꼴만, 나머지는 원문 그대로. 저장된 요약 글은 그대로(기록은 고치지 않는다)."""
    from watcher.summary import was_line
    return was_line(s, items)


# 위치 표기의 일상어 — 메일·대장·사내망·감시 화면이 한 규칙 (ux21 daily 5·mail 8·10). 저장 문구(재발 판정·지문·캐시 키)는 그대로, 보일 때만.
# 위치 칸(plain_where)은 글 전체가 위치라 모두 바꾼다. 근거 줄(plain_words·human_ev)은 값·파일 이름·경로가 섞여 있어 — '위치, x=120, y=340 참조'가
# 'x=130'으로 바뀐 값이 사라졌고 '레이어 표준.dxf'가 '도면 층 표준.dxf'가 됐다(ux22 judge 1·web 2, 원칙 4) — 위치 꼴인 괄호와 '· 위치 …' 꼬리만 바꾼다
_SPEC_WORD = re.compile(r"(?<![\w/\\])SPEC=")
# 옛 판이 저장한 머리('리비전 블록 기재:'·'리비전 블록에 C 행을'·'Rev를 C로 올리면서 리비전 블록에') — 열린 옛 건·처리됨 목록에 남는다 (ux22 vx-check 5)
_EV_OLD_HEAD = re.compile(r"^((?:Rev를 \S+로 올리면서 )?)리비전 블록(?= (?:REV|Rev|최신)| 기재:|에 이번에|에 \S+ 행을|에서 )")
_SHEET_ROW_WORD = re.compile(r"(?<![\w/\\])([^\s(,!/\\]+)!행(\d+)")
# 키 없는 행의 줄 머리 'Sheet1!행5 수량: 1 → 2'·'Sheet1!행5: — → 품명=볼트'·'자재 목록!행5 수량: …' (ux22 vx-check 6·vy-check 3) — '항목: 값' 꼴만, 값 'BOM!행5 참조'는 그대로
# 시트 이름의 쉼표는 콜론·대괄호 없는 머리에서만 — Excel 시트 이름에 못 드는 글자라, '도면 E-101 [Rev A, 2026-07-10]: Sheet1!행5: 참조' 같은 값 줄을 머리로 읽지 않는다 (ux23 a 7)
_HEAD_ROW_WORD = re.compile(r"^([^,!/\\]{1,60}?|[^!/\\:?*\[\]]{1,60}?)!행(\d+)(?=:| [^:]{1,40}: )")
_LAYER_WORD_KO = re.compile(r"(?<![\w가-힣])레이어 (?=[^\s,()])")
_XY_NUM = r"-?\d+(?:\.\d+)?"
_COORD = rf",\s*x={_XY_NUM},\s*y={_XY_NUM}|,\s*좌표 \({_XY_NUM}, {_XY_NUM}\)"
# DXF 표제란 칸 좌표('표제란(레이어 TITLE, x=330, y=9)')·사진 설명 좌표('레이어 EQUIPMENT, 좌표 (140, 260)') — 위치 이름은 남기고 숫자만 뺀다
_XY_WORD = re.compile(rf",\s*x={_XY_NUM},\s*y={_XY_NUM}|(?<=[^\s,(]),\s*좌표 \({_XY_NUM}, {_XY_NUM}\)")
_DOC_NAME = re.compile(r"\.(?:dxf|dwg|pdf|xlsx?|xlsm|docx?|hwpx?)$", re.I)
_PLACE_AT = r"(?:(?:배치공간|배치) [^,()]+? |첫 틀 |틀 \d+ )?"     # 추출기가 위치 앞에 붙이는 말 — '배치공간 SHEET-2 레이어 EQUIP'·'틀 2 레이어 T'
_PLACE_LAYER_XY = re.compile(rf"{_PLACE_AT}레이어 [^,()]+(?:{_COORD})")
_PLACE_LAYER = re.compile(rf"{_PLACE_AT}레이어 [^\s,()]+")
_PLACE_BOX = re.compile(r"[^()]*(?:표제란|리비전 블록|개정표)[^()]*\([^()]*\)")   # '표제란(레이어 TITLE, x=330, y=9)'·'리비전 블록(블록 속성, x=1, y=2)'
_PLACE_ROW = re.compile(r".*!행\d+(?:\s*\(개정이력\))?")
_PLACE_OLD = re.compile(r".*\(개정이력\)|리비전 블록|(?:머리글|바닥글)[ (]\d+째 줄\)?")
_PLACE_MAX = 300                  # 위치 표기는 이보다 짧다 — 긴 글은 값으로 본다('개정표 '가 수만 번 든 값에서 _PLACE_BOX가 제곱 시간, ux22 vx-check 8)
_NOT_PATH_HEAD = re.compile(rf"[xy]={_XY_NUM}|좌표 \(")


def _is_place(w: str) -> bool:
    """글이 추출기가 만드는 위치 표기 꼴인가 — 아니면 값으로 보고 손대지 않는다."""
    w = w.strip()
    if len(w) > _PLACE_MAX:
        return False
    return bool(_PLACE_LAYER_XY.fullmatch(w) or (_PLACE_LAYER.fullmatch(w) and not _DOC_NAME.search(w))
                or _PLACE_BOX.fullmatch(w) or _PLACE_ROW.fullmatch(w) or _PLACE_OLD.fullmatch(w))


def _paren_spans(s: str) -> list:
    """짝이 맞는 가장 바깥 괄호들의 (여는 자리, 닫는 자리) — 값 속 짝 없는 괄호는 그 뒤 위치 괄호를 삼키지 않는다."""
    stack, pairs = [], []
    for k, ch in enumerate(s):
        if ch == "(":
            stack.append(k)
        elif ch == ")" and stack:
            pairs.append((stack.pop(), k))
    pairs.sort()
    out = []
    for a, b in pairs:
        if not out or a > out[-1][1]:
            out.append((a, b))
    return out


def _place_group(inner: str) -> str:
    """괄호 속 '위치'·'위치, 경로'·'변경 전후 동일, 위치' — 위치 조각만 일상어로, 경로는 원본 그대로."""
    pre = "변경 전후 동일, " if inner.startswith("변경 전후 동일, ") else ""
    inner = inner[len(pre):]
    # 앞에서부터 — 경로·파일 이름에 ', '가 들어도 위치 조각만 뗀다(뒤에서 자르면 경로 속 '레이어 표준'까지 바뀌었다, ux22 vx-check 4). 좌표는 위치의 일부
    for m in re.finditer(", ", inner):
        k = m.start()
        if k > _PLACE_MAX:
            break
        w, tail = inner[:k], inner[k + 2:]
        if ("/" in tail or "\\" in tail) and not _NOT_PATH_HEAD.match(tail) and w.count("(") == w.count(")") \
                and (_is_place(w) or w.startswith("레이어 ")):    # 경로 앞이면 위치 — 띄어 쓴 레이어 이름도
            return pre + plain_where(w) + ", " + tail
    return pre + (plain_where(inner) if _is_place(inner) else inner)


def _map_places(s: str, outside=None) -> str:
    """근거 줄 한 줄에서 위치 꼴 괄호와 끝의 '· 위치 …'만 바꾼다. outside: 괄호 바깥 글자에 걸 말 바꾸기(SPEC=)."""
    keep = outside or (lambda t: t)
    tail = ""
    s = _HEAD_ROW_WORD.sub(r"\1 시트 \2행", s)
    k = s.rfind(" · 위치 ")
    if k >= 0 and _is_place(s[k + 6:]):
        s, tail = s[:k], s[k:k + 6] + plain_where(s[k + 6:])
    out, pos = [], 0
    for a, b in _paren_spans(s):
        out += [keep(s[pos:a]), "(", _place_group(s[a + 1:b]), ")"]
        pos = b + 1
    return "".join(out) + keep(s[pos:]) + tail


def plain_words(s) -> str:
    """근거·안내 **줄**의 위치 표기만 일상어로: '… (BOM!행5, 서버/P/BOM.xlsx)'→'… (BOM 시트 5행, 서버/P/BOM.xlsx)',
    '(표제란(레이어 TITLE, x=330, y=9))'→'(표제란(도면 층 TITLE))'. 값·파일 이름·경로는 그대로. 여러 번 거쳐도 같다."""
    return _map_places(str(s or ""))


def plain_where(w) -> str:
    """메일·대장·사내망·화면의 위치 칸·사진 설명 — 글 전체가 위치: human_where(새 이름) + 시트 행·좌표·레이어 일상어."""
    s = _SHEET_ROW_WORD.sub(r"\1 시트 \2행", human_where(w))
    s = _PAGE_MOVE.sub(r"새 판 \3\4(이전 판 \1\2)", s)     # 쪽 순서 바뀜 자리 — 화살표 대신 '지금(이전 …)' (이전/지금 2026-11-21 L)
    return _LAYER_WORD_KO.sub("도면 층 ", _XY_WORD.sub("", s))


_PAGE_MOVE = re.compile(r"이전 판 (\d+)(페이지|쪽) ?→ ?새 판 (\d+)(페이지|쪽)")


PO_MARK_KEY = "발주 후 변경"        # issued.PO_MARK_KEY와 같은 글 (순환 가져오기를 피해 따로 둔다)
PO_MARK_LABEL = "발주 대조"
PO_MARK_TAIL = "발주서와 대조한 표시입니다. 업체 통보·재발주 여부는 구매 담당이 판단합니다"
PO_MAIL_MARKS = 3                  # 메일 한 변경에 싣는 표지 줄 — 나머지는 '외 N건'으로 수만. 변경 상세·대장·사내망은 전부 (ux25 E1)
_PO_MARK_MORE = re.compile(r"외 \d+건 — ")   # 옛 판이 상세에 남긴 '외 N건' 줄 — 표지가 아니라 수 안내


def _is_po_mark(i) -> bool:
    return getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == PO_MARK_KEY


def item_kind_label(it) -> str:
    """변경 항목 구분 이름 — 발주 후 변경 표지(CHECK_SKIPPED)는 공용 '검사 한계'가 아니라 '발주 대조' (ux21 mail 1, ux20 남김).
    메일·대장·사내망이 같이 쓴다."""
    kind = str(getattr(it, "kind", "") or "")
    if kind == "CHECK_SKIPPED" and str(getattr(it, "key", "") or "") == PO_MARK_KEY:
        return PO_MARK_LABEL
    return _ITEM_KIND.get(kind, (kind,))[0]


# 사내망 변경 확인 주소 (갈래 N, 2026-11-02 — FORMS.md 11절). 양식함이 켜져 있고 사내망 주소가 있을 때만 cli가 검사 시작 때
# set_lan_base로 정한다. 비어 있으면 브리핑은 지금과 같다(링크 없음 — 벤치·옛 메일 그대로)
LAN_BASE = ""


def set_lan_base(url) -> None:
    global LAN_BASE
    s = str(url or "").strip().rstrip("/")
    LAN_BASE = s if re.match(r"^https?://[^\s/\"'<>]+$", s) else ""


def lan_url(change_id=None, issue_path: str | None = None) -> str:
    """[사내망에서 보기·확인] 주소를 만드는 한 곳 — 변경은 /changes/<번호>, 검토 필요는 /changes/issues?f=<경로>. 기준 주소가 없으면 ''."""
    if not LAN_BASE:
        return ""
    if change_id is not None:
        try:
            return f"{LAN_BASE}/changes/{int(change_id)}"
        except (TypeError, ValueError):
            return ""
    if issue_path:
        from urllib.parse import quote as _q
        return f"{LAN_BASE}/changes/issues?f={_q(str(issue_path), safe='')}"
    return ""


def record_link_base(cfg: dict | None) -> str:
    """메일 두 꼴(2026-11-17 R4)을 가르는 한 곳 — 사내망 기록 열람을 메일 받는 사람이 열 수 있으면 그 기준 주소, 아니면 ''.
    지금은 forms.enabled + 바깥에서 열 주소(forms/settings.base_url — 0.0.0.0이면 이 PC의 사내망 주소, 127.0.0.1만이면 '')로만
    판단한다. 주소가 있으면 링크형 메일(건수 + 확인 필요 먼저 + 한 줄 요약 + 기록 링크), 없으면 근거형 메일(구/신/위치).
    # R3 합칠 자리: '기록 열람만 켜기' 설정 키(forms/settings.py, 예: forms.boxes: false — 양식 끔·기록 열람은 켬)와
    #   기록 열람 자체를 끄는 키가 생기면 여기서 함께 본다 — 기록 열람이 꺼져 있으면 ''를 돌려 근거형으로.
    #   양식(boxes)만 끈 것은 기록 열람과 무관하니 그대로 주소를 돌려준다.
    V3-4 (2026-11-17 독립 검토): 설정값만 보면 공인 주소(서버가 열리지 않음)·열람 계정이 하나도 없는 집도 링크형이 돼, 근거 표·사진이
    빠진 메일에 아무도 못 여는 링크만 남았다(원칙 4). 그래서 둘 다 볼 때만 링크형 —
      ① 주소가 서버 바인드 검사(check_bind_host — 공인 주소 거부)를 통과하고 사내망 주소가 있음(lan_changes_base)
      ② 사내망에서 기록을 볼 수 있는 직원 계정(관리자 아님·정지 아님·열람 범위 있음)이 forms.db에 하나라도 있음 — **읽기만**,
         forms.db가 없거나 못 읽으면 근거형. 서버가 지금 도는지는 묻지 않는다(배치 시점 연결 시도 없음)."""
    try:
        from watcher.forms.settings import lan_changes_base
        base = lan_changes_base(cfg)
        if not base:
            return ""
        from watcher.forms.changes import lan_viewer_count
        from pathlib import Path
        from watcher.forms.store import DB_NAME
        sdb = (cfg or {}).get("state_db")
        if not sdb:
            return ""
        return base if lan_viewer_count(Path(str(sdb)).resolve().parent / DB_NAME) > 0 else ""
    except Exception:                       # noqa: BLE001 — 판단 실패면 근거형(링크 없음)이 안전하다(원칙 4)
        return ""


def link_mail() -> bool:
    """이번 검사의 메일이 링크형인가 — 검사 시작 때 cli가 record_link_base로 정한 LAN_BASE가 있으면."""
    return bool(LAN_BASE)


def lan_project_url(project) -> str:
    """사내망 프로젝트 기록(타임라인) 주소 — forms/changes.py의 /changes?p=<프로젝트>. 기준 주소가 없으면 ''."""
    if not LAN_BASE or not project:
        return ""
    from urllib.parse import quote as _q
    return f"{LAN_BASE}/changes?p={_q(str(project), safe='')}"


def is_shared_project(name) -> bool:
    """이름이 공용·공통 폴더인 '프로젝트'(00_공통·공용 등) — 메일 초안은 따로 만들지 않지만 그날 변경은 프로젝트 메일 끝 한 줄과
    주간 요약 행으로 알린다 (pv2 B-4: 표준도면 변경이 메일·주간 요약 어디에도 없었다)."""
    from watcher.project import QUIET_PROJECT_RE
    m = QUIET_PROJECT_RE.search(str(name or ""))
    return bool(m and (m.group(1) or "") in ("공용", "공통"))


def _lan_link(change_id=None, issue_path: str | None = None) -> str:
    u = lan_url(change_id, issue_path)
    # 확인 기록을 끈 집은 '보기'만 — 확인 단추가 없는 화면으로 가는 링크다 (재검토 rr066 mail 5)
    return (f'<a href="{_esc(u)}" style="color:#0969da;font-size:12.5px;white-space:nowrap">'
            f'{"사내망에서 보기·확인" if ACK_ON.get() else "사내망에서 보기"}</a>' if u else "")


# 메일 판 머리의 안내 한 줄 — 하루 한 통(digest_brief)이 프로젝트마다 반복되는 것을 맨 위 한 번으로 모으려고 이름을 붙인다 (rr066 mail 2)
# 메일 3판(2026-11-20): 설명 문단은 맨 아래 작은 글 한 줄로 — 머리에서 내렸다
REPLY_LINE = ('<div style="font-size:13px;color:#4A5363;margin:0"><b style="color:#2B3341">확인했으면 이 메일에 회신해 주세요</b>'
              ' — 변경마다 붙은 #번호를 적어 주시면 담당자가 확인으로 기록합니다.</div>')
LAN_ACK_LINE = ('<div style="font-size:13px;color:#4A5363;margin:0"><b style="color:#2B3341">확인은 각 줄의 [보기 ›]에서</b>'
                ' — 사내망 계정으로 근거·전/후 사진을 보고 [확인함]을 누르면 기록됩니다 (사내망 PC에서만 열립니다).</div>')
LAN_VIEW_LINE = ('<div style="font-size:13px;color:#4A5363;margin:0"><b style="color:#2B3341">근거·전/후 사진은 각 줄의 [보기 ›]에서</b>'
                 ' — 사내망 계정으로 엽니다 (사내망 PC에서만 열립니다).</div>')


def _loopback(base: str | None) -> bool:
    """확인 링크 주소가 감시 PC 자신(127.0.0.1·localhost)인가 — 그러면 수신자 PC에서는 열리지 않는다."""
    return bool(re.match(r"^\s*https?://(127\.\d+\.\d+\.\d+|localhost|\[::1\])(?::\d+)?(/|$)", str(base or ""), re.I))


# 양방향 제어문자 — 파일 이름 속 U+202E가 화면·브리핑·메일에서 글자 순서를 뒤집어 'x\u202efdp.exe'가 'xexe.pdf'로 보였다
# (보안 감사 2026-10-26). 표시할 때만 보이는 대체 문자 U+FFFD로 바꾼다 — 저장된 경로·키는 그대로
_BIDI = re.compile("[\u202a-\u202e\u2066-\u2069\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
# \uc81c\uc5b4 \ubb38\uc790(U+0000\u2013001F, \uc904\ubc14\uafc8\u00b7\ud0ed \ube7c\uace0)\ub3c4 \uac19\uc740 \ub300\uccb4 \ubb38\uc790\ub85c \u2014 ToUnicode \uc5c6\ub294 \ub0b4\uc7a5 \uae00\uaf34 PDF\uc758 \uae00\uc790\uac00 '\x10\x14\x13\u2026'\ub85c \uc77d\ud600
# \ube0c\ub9ac\ud551 \uba38\ub9ac\uc904\u00b7\uadfc\uac70\uc5d0 \uadf8\ub300\ub85c \uc2e4\ub838\ub2e4 (\uac80\ud1a020 r07 2, \uc6d0\uce59 4: \uc77d\uc744 \uc218 \uc788\ub294 \uadfc\uac70). \ube44\uad50\u00b7\uc800\uc7a5 \uac12\uc740 \uadf8\ub300\ub85c
BIDI_MARK = "\ufffd"


def no_bidi(s) -> str:
    """표시용 — 양방향 제어문자를 보이는 대체 문자(U+FFFD)로."""
    s = str(s)
    return _BIDI.sub(BIDI_MARK, s) if _BIDI.search(s) else s


def _esc(s: str) -> str:
    return html.escape(no_bidi(s), quote=True)


def num_prefix(path: str) -> str:
    """번호 앞말 — 도면 파일이면 '도면 ', 문서·BOM이면 '' (번호만). BOM·엑셀까지 '도면 P26-042-BOM-001'로 불러
    구매가 도면을 찾았다 (검토41 S6 중간 3)."""
    ext = PurePosixPath(str(path)).suffix.lower()
    if ext in (".dxf", ".dwg"):
        return "도면 "
    if ext in (".xlsx", ".xlsm", ".xls", ".docx", ".hwpx", ".hwp", ".doc"):
        return ""
    try:
        from watcher.doctype import kind_of
        return "도면 " if kind_of(str(path)) == "도면" else ""
    except Exception:
        return ""


# 오늘 꼭 봐야 할 변경이 아닌 알림(이동·복사본·재저장·빈 파일) — 화면과 메일이 같은 규칙으로
# 접는다 (2026-09-05 재검토: 화면 24건 / 메일 30행으로 숫자가 달랐다)
_QUIET_WORDS = ("이름·위치만", "옮겨짐", "복사본", "내용 변경 없음", "빈 파일", "재저장", "일자만 갱신", "표제란 틀만", "구판 정리", "순서만 바뀜",
                "배치만 바뀜")
_MOVE_MARK = "이름·위치만 바뀜 — 이전: "


def is_quiet(note: str) -> bool:
    """옮겨지며 내용도 바뀐 파일은 진짜 변경이라 접지 않는다 (2026-09-05 재검토 회귀)."""
    if not note:
        return False
    if "내용도 바뀜" in note or "그 판과 비교" in note or "(이름·폴더 변경)" in note:
        return False
    return any(w in note for w in _QUIET_WORDS)


_ORD_KO = ("첫째", "둘째", "셋째", "넷째", "다섯째", "여섯째", "일곱째", "여덟째", "아홉째", "열째")


def human_where(w) -> str:
    """사람에게 보이는 위치 문구 — 옛 기록(v0.57.46까지)의 '리비전 블록(…)'·'(개정이력)'·'머리글(1째 줄)'도 새 이름으로
    ('개정표'·'머리글 첫째 줄', 검토71 R4 중간 4). 판정은 원래 문구로 하므로 보여 줄 때만 바꾼다."""
    s = str(w or "")
    if not s:
        return s
    s = re.sub(r"리비전 블록", "개정표", s)
    s = re.sub(r"\(개정이력\)", "(개정표)", s)

    def _o(m):
        n = int(m.group(2))
        return f"{m.group(1)} {_ORD_KO[n - 1] if 1 <= n <= len(_ORD_KO) else f'{n}번째'} 줄"
    return re.sub(r"(머리글|바닥글)[ (](\d+)째 줄\)?", _o, s)


_SILENT_RESAVE = "내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표·그림 동일)"


RESAVED_MAIL_LINE = "다시 저장만 된 파일"     # 메일 한 줄 요약의 머리 (벤치 하네스가 이 줄을 '변경으로 실림'에서 뺀다)


def is_silent_resave(note: str) -> bool:
    """글자·표·그림을 모두 비교해 같았던 재저장인가 — 메일에서 뺀다(기록만). 일부만 읽은 쪽(·고지)이나 그림을 비교하지 않는
    형식('그림·개체는 비교하지 않습니다')은 아니다."""
    n = str(note or "")
    return n.startswith(_SILENT_RESAVE) and " · " not in n[len(_SILENT_RESAVE):]


# '비교하지 않습니다'는 v0.57.46까지의 기록 문구 — 화면 이력에 남은 옛 줄도 같은 뜻으로 읽는다. 새 문구는 메일과 같은 '비교하지 못함'
# (검토71 R4 낮음 12)
_UNCOMPARED_RESAVES = ("내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표 동일 — 그림·개체는 비교하지 못함",
                       "내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표 동일 — 그림·개체는 비교하지 않습니다")
_UNCOMPARED_RESAVE = _UNCOMPARED_RESAVES[0]


def is_uncompared_resave(note: str) -> bool:
    """글자·표는 같지만 그림·개체 부품을 읽지 못한(손상·옛 기록) 재저장인가 — 문서 안 그림만 바꾼 날일 수 있다.
    파일이 바뀐 사실은 메일에 한 줄 남긴다 (원칙 5, 검토69 B M2b). 부품까지 비교해 같으면 is_silent_resave다 (검토71 R4)."""
    n = str(note or "")
    return any(n.startswith(h) and " · " not in n[len(h):] for h in _UNCOMPARED_RESAVES)


def uncompared_resaves(changes, details: dict | None, details_by_id: dict | None = None) -> list:
    """그림·개체를 비교하지 못한 재저장(is_uncompared_resave) 변경들 — 그것뿐인 프로젝트도 메일 한 통을 낸다 (cli)."""
    _main, quiet, _moved = arrange_changes(changes, details, details_by_id)
    return [c for c in quiet if is_uncompared_resave(note_of(items_for(c, details, details_by_id)))]


def _unread_label(reason: str) -> str:
    """목차의 '못 읽음' 꼬리표를 사유대로 — 스캔본(OCR 꺼짐)·0바이트 뒤 처음 읽은 판까지 '손상·잘림 가능'이라 불러
    멀쩡한 파일을 깨진 줄 알게 했다 (경우100 B05·B09)."""
    if "OCR" in reason or "스캔" in reason or "글자 없는" in reason:
        return "스캔본(글자 없음)"
    if "암호" in reason:
        return "암호 걸림 — 읽지 못함"
    if "구버전 형식" in reason or "다른 프로그램 판의 형식" in reason:
        return "이전 판 기록이 다른 프로그램 판 형식 — 이번 판부터 비교"
    if "추출본 없음" in reason or "기록이 없" in reason:
        return "이전 판 기록 없음 — 이번 판부터 비교"
    if "잠겨" in reason or "권한" in reason:
        return "잠김·권한 — 다음 검사에서 다시"
    if "깨져" in reason or "읽을 수 없음" in reason or "끊겼" in reason:
        return "읽지 못함(손상·잘림 가능)"
    return "읽지 못함"


REV_DATE_NOTICE = "확인 필요"       # cli.REV_DATE_KEY와 같은 이름표 — Rev를 올렸는데 일자는 그대로 (J7)


def notice_text(i, full: bool = False) -> str:
    """안내 띠 글 — '확인 필요'(Rev 올림·일자 그대로)는 한 줄로: 'Rev A→B로 올렸지만 표제란 일자는 그대로입니다 (2026-09-01) —
    일자 칸을 새 Rev의 날짜로 고쳤는지 확인하세요'. 저장된 글에는 같은 일자를 두 번(DATE: x → x)과 레이어·좌표가 붙어 묶음 메일에서
    여섯 번 길게 반복됐다 (ux20 mail 4). 앞 문장에 그 일자(이전=새 값)와 자리(표제란 일자 칸·개정표 최신 행)가 있다(원칙 4) —
    전체 근거는 감시 PC 화면의 변경 상세에 그대로. full=True(대장·사내망)는 줄이지 않고 전문 — 메일용 요약이 기록까지 번지면 안 된다 (ux22 judge 4)."""
    t = str(getattr(i, "new", "") or "")
    if _is_po_mark(i):
        # 발주 후 변경 — 할 일을 지시하지 않고 누가 판단하는지만 (원칙 6). 신입 구매가 '그래서 뭘 하라는 건지' 몰랐다 (ux21 mail 1)
        # 옛 판의 '외 N건' 줄은 표지가 아니라 수 안내 — 꼬리말이 그 줄까지 따라붙었다 (ux25 E1)
        return plain_words(t) + ("" if _PO_MARK_MORE.match(t) else " — " + PO_MARK_TAIL)
    if full or getattr(i, "key", "") != REV_DATE_NOTICE or " — " not in t:
        return plain_words(t)
    head, _, rest = t.partition(" — ")
    act = rest.rsplit(" · ", 1)[-1].strip() if " · " in rest else ""
    return head.rstrip(". ") + (f" — {act}" if act.endswith("확인하세요") else "")


def rev_date_count(changes, details: dict | None, details_by_id: dict | None = None) -> int:
    """'확인 필요'(Rev 올림·일자 그대로) 표지가 붙은 변경 수 — 프로젝트 머리에 한 번 센다 (ux20 mail 4)."""
    return sum(1 for c in changes or () if any(getattr(it, "kind", "") == "CHECK_SKIPPED" and getattr(it, "key", "") == REV_DATE_NOTICE
                                               for it in items_for(c, details, details_by_id)))


def same_name_folder(path: str, all_paths) -> str:
    """같은 이름의 파일이 같은 프로젝트(감시 폴더 아래 맨 위 폴더) 안에 또 있으면 이 파일의 부모 폴더 이름, 아니면 '' (ux20 daily 1).
    '작업중_사본/E-101.dxf'만 바뀐 날 메일 머리 한 줄이 'E-101 …'이라 원본 도면이 바뀐 줄 알았다 — 화면(web.py)도 같은 함수를 쓴다.
    all_paths: 지금 감시 중인 파일 경로들(감시 폴더 이름표부터, '/' 구분)."""
    pp = PurePosixPath(str(path or ""))
    name = pp.name.casefold()
    if not name or len(pp.parts) < 2:
        return ""
    top = pp.parts[:2] if len(pp.parts) > 2 else pp.parts[:1]
    for o in all_paths or ():
        op = PurePosixPath(str(o))
        if op.name.casefold() == name and op != pp and op.parts[:len(top)] == top and op.parent != pp.parent:
            return pp.parent.name
    return ""


def note_of(items) -> str:
    """변경 상세의 '참고' 문구(복사본·이동·빈 파일 …) — 없으면 빈 문자열."""
    for it in items or []:
        if getattr(it, "kind", None) == "CHECK_SKIPPED" and getattr(it, "key", None) == "참고":
            return str(it.new or "")
    return ""


def items_for(c, details: dict | None, details_by_id: dict | None = None):
    """변경 한 건의 상세 — 같은 파일이 하루에 두 번이면 변경 id별 상세가 우선.
    경로 키만 쓰면 나중 변경의 '재저장' 참고가 앞선 진짜 변경에 붙었다 (파일럿 모의 ①)."""
    if details_by_id and c.id is not None and c.id in details_by_id:
        return details_by_id[c.id]
    return (details or {}).get(c.path, [])


def change_summary(c, items, issues=(), summaries: dict | None = None) -> str:
    """메일에 싣는 변경 한 줄 요약 — 화면·기록과 같은 문장. cli가 넘긴 기록의 요약(State.record_summaries)이 있으면 그것, 없으면
    (시험·옛 호출) 같은 규칙(watcher.summary.summarize)으로 이 상세 항목과 이 파일의 검토 필요에서 만든다. 값은 ChangeItem 그대로."""
    if summaries and c.id is not None and summaries.get(c.id):
        return str(summaries[c.id])
    from dataclasses import asdict, is_dataclass
    from watcher.summary import summarize
    its = [asdict(i) if is_dataclass(i) else i for i in items or ()]
    iss = [{"code": i.code, "message": i.message, "evidence": list(i.evidence or ())}
           for i in issues or () if getattr(i, "path", None) == c.path]
    return summarize(c.kind, c.path, getattr(c, "project", None), its, iss)


def change_weight(items) -> int:
    """변경의 무게 — 사양값(kW·A·mm…)이나 표 행 > Rev > 다른 글자·그림 > 날짜만.
    팀장은 위에서부터 읽는다 (파일럿 모의 ④: Rev만 오른 도면이 MCCB 변경보다 위에)."""
    has_row = any(it.kind.startswith("ROW_") and it.kind != "ROW_MOVED" for it in items)   # 순서만은 행 변경 아님
    has_unit = any(it.kind.startswith("TEXT_") and _UNIT_RE.search(
        str(it.old or "") + " " + str(it.new or "")) for it in items)
    if has_row or has_unit:
        return 0
    from watcher.diff import field_base, is_rev_field
    if any(is_rev_field(it) for it in items):
        return 1
    if any(it.kind.startswith(("TEXT_", "PAGE_VISUAL", "ROW_", "REVROW", "SHEET"))
           or (it.kind == "FIELD_CHANGED" and field_base(it.key) not in ("DATE",)) for it in items):
        return 2
    return 3


def arrange_changes(changes, details: dict | None, details_by_id: dict | None = None):
    """브리핑 순서를 정한다 → (주요 변경, 그 밖의 알림, {id(변경): 이전 경로}).

    같은 지문의 '삭제 + 추가'(이름·위치 변경)는 추가 쪽 한 행으로 접고(이동), 복사본·재저장·
    빈 파일·이동은 '그 밖의 알림'으로 뒤에 둔다. 주요 변경은 수정 → 추가 → 삭제, 그 안에서
    변경의 무게(사양·표 > Rev > 글자·그림 > 날짜) → 유형 중요도 → 경로 순."""
    from watcher.doctype import doc_rank, kind_of
    details = details or {}
    notes = {id(c): note_of(items_for(c, details, details_by_id)) for c in changes}
    # 변경 **한 건** 단위 — 경로로 잡으면 아침에 옮긴 파일을 오후에 고친 그 수정(같은 경로, 다른 변경)까지 '이동'으로
    # 접혀 메일에서 사라졌다. 퍼즈 두 시드에서 269건, Rev 올림·BOM 행·사양 변경 모두 (검토59 F4b-1·F5 F1 차단)
    moved: dict[int, str] = {}
    hide: set = set()
    removed_by_path: dict[str, list] = {}
    for c in changes:
        if c.kind == "removed":
            removed_by_path.setdefault(c.path, []).append(c)
    for c in changes:
        n = notes.get(id(c), "")
        if c.kind == "added" and _MOVE_MARK in n:
            prev = n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
            for x in removed_by_path.get(prev, []):
                if id(x) not in hide:
                    hide.add(id(x))
                    moved[id(c)] = prev
                    break
    # 옮겨지며 내용도 바뀐 파일(이름 짝)은 '추가' 쪽에 비교가 실린다 — 삭제 행까지 두면 한 파일이
    # "변경 2건"에 빨간 삭제 라벨로 나왔다 (검토21 브리핑 차단 3). 삭제 쪽은 접는다
    added_paths = {c.path for c in changes if c.kind == "added"}
    for c in changes:
        n = notes.get(id(c), "")
        if c.kind == "removed" and "옮겨지며 내용도 바뀜" in n:
            tgt = n.split("(으)로 옮겨지며", 1)[0].strip()
            if tgt in added_paths:
                hide.add(id(c))
    kept = [c for c in changes if id(c) not in hide]
    quiet = [c for c in kept if id(c) in moved or is_quiet(notes.get(id(c), ""))]
    qids = {id(c) for c in quiet}
    order = {"modified": 0, "added": 1, "removed": 2}

    def _rank(c):
        try:
            r = doc_rank(kind_of(c.path, None))
        except Exception:
            r = 50
        # 같은 파일이 하루에 두 번이면 시간순(변경 id) — 최신이 위에 오면 A→B가 B→C 아래에 놓였다
        return (order.get(c.kind, 3), change_weight(items_for(c, details, details_by_id)),
                r, c.path.lower(), c.id or 0)
    main = sorted((c for c in kept if id(c) not in qids), key=_rank)
    return main, quiet, moved


def brief_counts(changes, details: dict | None, details_by_id: dict | None = None) -> tuple[int, int]:
    """(주요 변경 수, 그 밖의 알림 수) — 제목·메일 제목이 화면과 같은 수를 말하게."""
    main, quiet, _ = arrange_changes(changes, details, details_by_id)
    return len(main), len(quiet)


def _change_row(c: Change, ack_base: str | None, ack_tokens: dict | None,
                info: dict | None = None, baseline: bool = False,
                moved_from: str | None = None, note: str = "",
                acked_by: dict | None = None) -> str:
    p = PurePosixPath(c.path)
    old = (c.old_sha256 or "없음")[:12]
    new = (c.new_sha256 or "없음")[:12]
    color = "#57606a" if moved_from else _KIND_COLOR[c.kind]
    kind_label = ("이동" if moved_from else
                  "첫 등록" if (baseline and c.kind == "added") else _KIND_LABEL[c.kind])
    token = (ack_tokens or {}).get(c.id)
    if c.id and (acked_by or {}).get(c.id):
        ack = f'<span style="color:#1a7f37">확인됨 — {_esc(str(acked_by[c.id]))}</span>'
    elif ack_base and c.id and token and not baseline and not moved_from and not is_quiet(note or ""):
        # 이동·재저장·복사본은 확인 대상이 아니다(화면도 미확인에서 뺀다) — 행마다 링크가 있어
        # "확인만 하면 됩니다"로 읽혔다 (검토30 C 1-2)
        # 화면은 감시 PC에서만 열린다 — 다른 PC의 수신자에게는 매일 죽은 링크였다.
        # 링크 글에 그 사실을 붙인다 (검토19 브리핑 ⑬). 기준선(등록)에는 확인이 필요 없다
        ack = (f'<a href="{_esc(ack_base)}/ack?id={c.id}&amp;t={_esc(token)}" '
               f'style="color:#0969da">확인했음 기록</a>'
               f'<span style="color:#57606a;font-size:11px"> (감시 PC에서)</span>')
        if _loopback(ack_base):
            # 127.0.0.1 링크는 수신자 PC에서 '연결할 수 없음'이다 — 메일의 유일한 행동 단추가 죽은 파란 링크였다 (검토49 C
            # 차단 3). 사내 주소를 설정했을 때만 링크, 아니면 감시 PC에서 찾아갈 곳을 글로
            # 두 줄(회색 11px)이 눈에 안 띄었다 — 한 줄 링크로, 감시 PC에서만 열린다는 말은 머리 안내 한 번 (검토54 ③15)
            # 파란 '#번호 확인'은 다시 다른 PC에서 누르는 죽은 링크가 됐다 — 번호는 글로, 링크는 '감시 PC에서'라고 밝힌 작은 회색으로 (검토55 ⑤25 퇴행)
            ack = (f'<span style="color:#57606a;font-size:13px;white-space:nowrap">#{c.id}</span> '
                   f'<a href="{_esc(ack_base)}/ack?id={c.id}&amp;t={_esc(token)}" '
                   f'style="color:#57606a;font-size:12px;white-space:nowrap">감시 PC에서 확인</a>')
    else:
        ack = "—"
    _ln = _lan_link(c.id) if (c.id and not baseline and not moved_from and not is_quiet(note or "")) else ""
    if _ln:                                       # 사내망 변경 확인 (갈래 N) — 양식함이 켜져 있고 사내망 주소가 있을 때만
        ack = _ln if ack == "—" else f"{ack}<br>{_ln}"
    _ln_file = "" if ACK_ON.get() else _ln        # 확인 칸이 없는 집은 파일 칸에 (rr066 mail 5)
    # 실무 언어는 파일명이 아니라 도면번호·Rev — 표제란 값이 있으면 앞세운다
    # (설계 10년차 검토 반영, 2026-08-28)
    if info and info.get("dwg"):
        rev = f' Rev {_esc(info["rev"])}' if info.get("rev") else ""
        file_cell = (f'<strong>{num_prefix(c.path)}{_esc(info["dwg"])}</strong>{rev}'
                     f'<br><span style="color:#57606a;font-size:12px">'
                     f'{_esc(p.name)}</span>')
    else:
        file_cell = _esc(p.name)
    if moved_from:
        # 옛 자리 [이전] / 새 자리 [지금] 두 줄 (이전/지금 2026-11-21 L — 파일 이름·위치 바뀜 줄도 두 줄, 세부 점검표 A10)
        file_cell += '<div style="font-size:13px;margin-top:4px">' + _m_pv(_esc(moved_from), _esc(c.path)) + '</div>'
    elif note:
        file_cell += f'<br><span style="color:#57606a;font-size:12px">{_esc(note)}</span>'
    if info and info.get("mtime"):
        # 문서를 언제 고쳤나 — 검사 시각(머리글)과 별개 (2026-09-17 사용자 요청)
        try:
            _saved = saved_stamp(info["mtime"])
            _who = f" · 저장자 {_esc(info['who'])}" if info.get("who") else ""     # 누가 저장했나 (구매자 평가 P1·P4)
            file_cell += f'<br><span style="color:#57606a;font-size:12px">저장 {_saved}{_who}</span>'
        except (TypeError, ValueError, OSError, OverflowError):
            pass
    if _ln_file:
        file_cell += f"<br>{_ln_file}"
    # 파일 지문(해시)은 화면·DB에 있다 — 브리핑에서는 근거로 읽히지 않아 뺀다
    # (2026-09-05 전체 검토: "모든 행의 지문 e3a9… → 9745…는 설계팀장에게 근거가 아니다")
    return (
        f'<tr valign="top">'          # 이동 행의 두 줄 칸 옆 글이 가운데로 뜨지 않게 (세부 점검표 A9)
        f'<td class="k" style="{_STYLE_TD}"><strong style="color:{color}">{kind_label}</strong></td>'
        f'<td style="{_STYLE_TD}" title="지문 {new}(이전 {old})">{file_cell}</td>'
        f'<td style="{_STYLE_TD}">{_esc(str(p.parent))}</td>'
        + _ack_td(ack) +
        f'</tr>'
    )


def saved_stamp(mtime, now: float | None = None) -> str:
    """파일 저장 시각 표기 — 올해면 '10-27 09:50', 다른 해면 연도까지. 3000년 저장 시각이 '01-01 09:00'으로만 찍혀
    미래인지 알 수 없었다 (재검토 2026-10-28 R8-5). 이 PC 시계보다 하루 넘게 앞서면 그렇다고 붙인다(사실만)."""
    import time as _time
    ts = float(mtime)
    d = datetime.fromtimestamp(ts)
    now = _time.time() if now is None else now
    fmt = "%m-%d %H:%M" if d.year == datetime.fromtimestamp(now).year else "%Y-%m-%d %H:%M"
    return d.strftime(fmt) + (" (이 PC 시계보다 미래)" if ts > now + 86400 else "")


def _kdate(iso) -> str:
    """ISO 시각 → 'MM-DD'(이 PC 시간대). 못 읽으면 앞 10자."""
    try:
        return datetime.fromisoformat(str(iso)).astimezone().strftime("%m-%d")
    except (TypeError, ValueError, OSError, OverflowError):
        return str(iso or "")[:10]


def _card_ev(i) -> str:
    """묶음 카드의 파일별 한 줄 — 'REV: A (변경 전후 동일)'·'이번 변경:' 머리 말고 **무엇이 바뀌었는지** (검토45 C 낮음 1)."""
    evs = [str(e) for e in (i.evidence or ())]
    body = next((e for e in evs if "(변경 전후 동일)" not in e and not e.rstrip().endswith(("예시:", "이번 변경:"))), None)
    return body or (evs[0] if evs else i.message)


def _short(t: str, n: int) -> str:
    t = " ".join(str(t or "").split())
    return t if len(t) <= n else t[:n - 1] + "…"


def _folders_of(doc_info) -> dict:
    """{경로: 같은 이름 파일이 프로젝트에 또 있을 때의 부모 폴더 이름} — cli가 doc_info[경로]['folder']로 넘긴다 (ux20 daily 1)."""
    return {k: v["folder"] for k, v in (doc_info or {}).items()
            if isinstance(k, str) and isinstance(v, dict) and v.get("folder")}


def card_ev(evs) -> list:
    """카드 근거 줄 — 머리 '이번 변경:'만 든 줄은 다음 줄(그 한 건)과 한 줄로. 빈 글머리 뒤에 값이 다음 글머리로 떨어져
    읽혔다 (ux21 mail 11). 저장 근거는 그대로, 보일 때만."""
    out = []
    evs = [str(e) for e in (evs or ())]
    k = 0
    while k < len(evs):
        e = evs[k]
        if e.rstrip().endswith("이번 변경:") and k + 1 < len(evs) and not evs[k + 1].startswith("── ") \
                and not evs[k + 1].rstrip().endswith(":"):
            out.append(f"{e.rstrip()} {evs[k + 1].strip()}")
            k += 2
            continue
        out.append(e)
        k += 1
    return out


def _name_tail(path: str, folders: dict | None) -> str:
    """메일 카드의 파일 이름 + 같은 이름 폴더 꼬리 — '작업중_사본' 파일 카드가 원본과 같은 이름으로만 보였다 (ux21 mail 3)."""
    f_ = (folders or {}).get(path)
    return PurePosixPath(path).name + (f" ({f_} 폴더)" if f_ else "")


def _issues_section(issues, ack_base: str | None = None, project: str | None = None,
                    recurred: dict | None = None, folders: dict | None = None, details: dict | None = None) -> str:
    """디스크 브리핑의 확인 필요 카드. 근거는 메일과 같은 _m_issue_cells(이전/지금 두 줄 2026-11-21 L): 도면·BOM 다름은 대상(굵게) +
    [도면]/[BOM] 두 줄 + 파일·위치, Rev 안 올림은 사실 한 줄 아래 바뀐 값 두 줄(details의 ChangeItem — 앞 5곳), 근거 줄 '바뀐 곳: 이전 →
    지금 (위치)'은 두 줄, 나머지 글 줄은 자르지 않고. 같은 종류 5장 이상 묶음 카드의 파일별 한 줄은 '이전 A · 지금 B'(unarrow)."""
    from watcher.consistency import CODE_LABEL
    blocks = []
    if ack_base and _loopback(ack_base):
        # 127.0.0.1 링크는 수신자 PC에서 열리지 않는다 — 글로만 (검토50 B 중간 5)
        blocks.append('<p style="color:#57606a;font-size:12px;margin:0 0 6px">감시 PC 화면 › 확인 필요에서 '
                      '[처리함]·전/후 비교를 할 수 있습니다.</p>')
    elif ack_base:
        # 변경 행에는 [확인했음 기록] 링크가 있는데 검토 필요 블록에는 동선이 없었다 (검토24 C-1)
        from urllib.parse import quote as _q
        blocks.append(
            f'<p style="color:#57606a;font-size:12px;margin:0 0 6px">감시 PC 화면의 '
            f'<a href="{_esc(ack_base)}/issues{("?p=" + _q(project)) if project else ""}" '
            f'style="color:#0969da">확인 필요 목록</a>에서 [처리함]·전/후 비교를 할 수 있습니다.</p>')
    # 같은 종류가 5장 이상이면 한 장으로 — 백업을 되돌린 날 'Rev가 거꾸로 감' 카드 12장이 똑같이 이어졌다 (검토43 C 중간 5).
    # 묶은 카드에도 파일마다 근거 첫 줄을 싣는다 — '예:' 한 줄만으로는 나머지 파일의 구/신 값이 메일에 없었다 (검토44 A 낮음 4)
    from collections import Counter as _Cn
    _n = _Cn(i.code for i in issues)
    _many = {c for c, k in _n.items() if k >= 5 and c in ("REV_REGRESSED", "CONTENT_CHANGED_REV_SAME", "REV_CHANGED_CONTENT_SAME")}
    for code in sorted(_many):
        grp = [i for i in issues if i.code == code]
        names = ", ".join(PurePosixPath(i.path).name for i in grp[:8]) + (f" 외 {len(grp) - 8}개" if len(grp) > 8 else "")
        blocks.append(f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 10px;background:#fff5f5">
    <strong style="color:#cf222e">{_esc(CODE_LABEL[code])} {len(grp)}건</strong>
    <div style="margin:4px 0 2px">{_esc(names)}</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px"><li style="color:#57606a">예: {_esc(unarrow(_iss_card_text(grp[0])[0]))}</li>
    {"".join(f'<li style="color:#57606a">{_esc(PurePosixPath(i.path).name)} — {_esc(_short(unarrow(human_ev(_card_ev(i))), 110))}</li>' for i in grp[:15])}
    {f'<li style="color:#57606a">외 {len(grp) - 15}개 — 감시 PC 화면의 확인 필요 목록에 모두 있습니다</li>' if len(grp) > 15 else ''}</ul>
  </div>""")
    for iss in issues:
        if iss.code in _many:
            continue
        _was = (recurred or {}).get((iss.code, iss.path, iss.message))
        _again = (f'&nbsp;<span style="background:#ffebe9;color:#a40e26;border-radius:4px;padding:1px 6px;font-size:12px">'
                  f'다시 생김 — {_esc(_kdate(_was))}에 해소됐던 같은 문제</span>') if _was else ""
        # 화면 v2 (2026-11-18): 문구 틀 대신 사실 한 줄 + 근거 + 회색 '자세히' 한 줄 — 감시 화면과 같은 함수(consistency.issue_text)
        _fact, _shown, _notes = _iss_card_text(iss)
        _target, _ev = _m_issue_cells(iss, (details or {}).get(iss.path, []), 99, None, k_vals=5, ev_cut=2000)
        _head = (_m_place_line(f"<b>{_target}</b>", 2) if (_target and iss.code == "BOM_MISMATCH") else "")
        blocks.append(f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 10px;background:#fff5f5">
    <strong style="color:#cf222e">{_esc(CODE_LABEL[iss.code])}</strong>{_again}
    &nbsp;<code>{_esc(iss.path)}</code>{(" " + _lan_link(issue_path=iss.path)) if LAN_BASE else ""}
    <div style="margin:4px 0 2px;font-size:14px;color:#2B3341">{_head}{_ev}</div>{_iss_note_mail(_notes)}
  </div>""")
    return "\n".join(blocks)


def _iss_card_text(iss) -> tuple:
    """메일 카드의 (사실 한 줄, 근거 줄들, 자세히 문장들) — 감시 화면과 같은 함수. 저장 문구·근거는 그대로 두고 보일 때만 나눈다."""
    from watcher.consistency import issue_detail, issue_text
    fact, _d = issue_text(iss.code, iss.message, iss.path, evidence=iss.evidence or ())
    shown, notes = issue_detail(iss.code, iss.message, iss.evidence or (), iss.path)
    return fact, shown, notes


def _iss_note_mail(notes) -> str:
    """메일 카드 끝의 회색 '자세히' 한 줄 — 메일에는 접기가 없어 작은 글 한 줄로."""
    notes = [n for n in (notes or []) if n]
    return (f'<div style="color:#57606a;font-size:12.5px;margin:4px 0 0">자세히: {_esc(" ".join(notes))}</div>'
            if notes else "")


def _fmt_row_values(s: str | None) -> str:
    """diff가 str(dict)로 남긴 행 값을 'TAG=.., SPEC=..' 꼴로 정리."""
    import ast
    try:
        d = ast.literal_eval(s or "")
        return ", ".join(f"{k}={_group_digits(str(v))}" for k, v in d.items() if str(v).strip())   # 행 추가·삭제도 천 단위 (검토55 ④1)
    except (ValueError, SyntaxError):
        return s or ""


def row_dot(s: str | None, keep: int = 5, cut: int = 60) -> str:
    """행 추가·삭제의 값 한 줄 — 앞 keep칸 값을 ' · '로 ('M-105 · MOTOR 7.5kW · QTY 2', 2026-11-21 세부 점검표 B13), 나머지는
    '외 N칸'. 숫자뿐인 값은 칸 이름을 앞에(무엇의 2인지). 감시 화면 web._row_join과 같은 규칙(값 60자까지) — 메일·사내망·화면이
    같은 말. 못 읽으면 _fmt_row_values 그대로. cut=0이면 값을 자르지 않는다(디스크 브리핑 — 기록이라 모든 칸 전부)."""
    import ast
    try:
        d = ast.literal_eval(s or "")
        if not isinstance(d, dict):
            raise ValueError
    except (ValueError, SyntaxError):
        return _fmt_row_values(s)
    vals = [(str(k), str(v)) for k, v in d.items() if str(v).strip()]
    out = []
    for k, v in vals[:keep]:
        sv = _group_digits(" ".join(v.split()))
        sv = sv[:cut] if cut else sv
        out.append(f"{k} {sv}".strip() if (k and re.fullmatch(r"[\d.,+\-]+", sv)) else sv)
    return " · ".join(out) + (f" 외 {len(vals) - keep}칸" if len(vals) > keep else "")


def delta_num(d: float) -> str:
    """증감 숫자 — 금액이 '+1.3e+06'으로 나왔다, 영업·경리는 읽을 수 없다 (검토54 ⑤ 차단). 정수는 천 단위, 소수는 4자리까지.
    화면도 같은 함수를 쓴다 — 메일만 고쳐 화면은 '+1e+06'이 남았다 (검토55 ⑤21)."""
    return f"{int(round(d)):,}" if abs(d - round(d)) < 1e-9 else f"{d:,.4f}".rstrip("0").rstrip(".")


def _delta_badge(old: str | None, new: str | None) -> str:
    """수량처럼 숫자인 값의 증감 배지 (+2 초록 / -1 빨강) — Odoo BOM 비교 규칙."""
    try:
        d = float(new) - float(old)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return ""
    if d == 0:
        return ""
    color = "#1a7f37" if d > 0 else "#cf222e"
    sign = "+" if d > 0 else ""
    num = delta_num(d)
    return (f' <span style="color:{color};font-weight:700;white-space:nowrap">'
            f"({sign}{num})</span>")


def sheet_kind(path: str, cfg: dict | None = None) -> str:
    """표 문서의 성격 — 분류 규칙(watcher.doctype)에 위임한다.
    회사마다 양식·명칭이 달라 규칙을 데이터로 뺐다 (2026-08-31)."""
    from watcher.doctype import UNKNOWN, kind_of
    k = kind_of(path, cfg)
    return "" if k in (UNKNOWN, "표", "문서", "도면") else k


_IMPACT_KINDS = ("BOM", "발주서", "견적서", "자재표", "구매")


def impact_label(path: str, cfg: dict | None = None) -> str:
    """행 변경 요약 줄의 이름 — 구매로 이어지는 표(BOM·발주서·견적서·자재표)만 '발주 영향', 도면목록·성적서·
    개정이력 같은 표는 '변경 요약' (2026-09-06 사용성 3차 ④-7)."""
    from watcher.doctype import canonical, kind_of
    k = canonical(sheet_kind(path, cfg) or "")
    if "견적" in k:
        return "견적 영향"          # 견적은 발주가 아니다 — 고객 제시 단가·합계·납기 (검토54 ⑤21)
    if any(w in k for w in _IMPACT_KINDS):
        return "발주 영향"
    # 도면(pdf·dxf·dwg) 위의 부품표는 BOM이다 — 엑셀 '도면목록'은 아니다
    if PurePosixPath(path).suffix.lower() in (".pdf", ".dxf", ".dwg") and canonical(kind_of(path, cfg)) == "도면":
        return "발주 영향"
    return "변경 요약"


def table_label(path: str, cfg: dict | None = None) -> str:
    """화면·메일에 쓰는 표 변경 이름표: '표(인터락)' / '표(BOM)' / '표'."""
    kind = sheet_kind(path, cfg)
    return f"표({kind})" if kind else "표"


# 조각이 제 이름을 달고 있다 — 'CABLE: CV 4SQ x 4C'·'비고: …'. 이런 글줄에 가장 가까운 태그 이름표를 붙이면 'INV-11: CABLE: CV 4SQ
# x 4C → …'처럼 이웃 기기의 사양처럼 읽혔다 (재검토 2026-10-26 D3)
_SELF_NAMED = re.compile(r"^\s*[A-Za-z가-힣][A-Za-z가-힣 .()/_&]{0,20}?\s*[:：]\s*\S")


def pair_label(i) -> str:
    """diff.pair_label에서 제 이름을 단 조각(이웃 태그가 이름이 아닌 것)을 뺀 이름표. 다 빠지면 빈 문자열 → 글줄 그대로."""
    from watcher.diff import pair_label as _raw
    lab = _raw(i)
    if not lab:
        return ""
    from watcher.extract.base import find_tags
    keep = []
    for part in lab.split("; "):
        _tag, sep, rest = part.partition(": ")
        if sep and _SELF_NAMED.match(rest) and not find_tags(rest.split(":", 1)[0].split("：", 1)[0]):
            continue
        keep.append(part)
    return "; ".join(keep)


def _flabel(i) -> str:
    """항목 이름 칸 — 표제란 필드의 내부 번호(REV#2)는 '다른 표제란'으로 보인다 (검토36 F 낮음 5).
    DXF 글줄에 사양-태그 짝 이름표가 있으면 그것 — 'M-102: 2.2kW 4P 380V → 3.7kW 4P 380V' (구매 평가 2차 F2)."""
    from watcher.diff import field_label
    if getattr(i, "kind", "") == "FIELD_CHANGED":
        return field_label(i.key)
    return pair_label(i) or text_key_label(i)


def text_key_label(i) -> str:
    """글줄 항목의 이름 — 키가 글줄 앞 30자 토막이면 낱말 중간('…제어전원은 D')에서 끊겨 항목 이름처럼 읽혔다 (검토62 D1-2).
    낱말 경계에서 자르고 말줄임표를 붙인다."""
    k = str(getattr(i, "key", "") or "")
    if str(getattr(i, "kind", "")).startswith("REVROW_"):
        # 같은 Rev 둘째 행의 내부 키 'B#2' → 'B (2번째)' — 표시만, 키(캐시·지문)는 그대로 (ux21 buy 6)
        m = re.fullmatch(r"(.+)#(\d+)", k)
        return f"{m.group(1)} ({m.group(2)}번째)" if m else k
    if not str(getattr(i, "kind", "")).startswith("TEXT_"):
        return k
    if k and len(k) < 20:
        # 키가 문장 **속** 도면번호·태그면 항목 이름이 아니다 — 사양서 '2-1. 구동 모터를 7.5kW로 상향 (E-101 Rev.B 반영)'이
        # '글자 추가 E-101'로 보였다 (재검토 2026-10-26 D3). 태그 앞에 낱말이 셋 이상이면 글줄 앞머리를 이름으로
        from watcher.extract.base import find_tags
        txt = next((str(v) for v in (getattr(i, "new", None), getattr(i, "old", None)) if v and k in str(v)), "")
        pos = txt.find(k)
        if pos > 0 and find_tags(k) == [k] and len(txt[:pos].split()) >= 3:
            head = " ".join(txt.split())
            if len(head) <= 30:
                return head
            cut = head.rfind(" ", 0, 30)
            return (head[:cut] if cut >= 10 else head[:30]).rstrip(" ,.:;(") + "…"
        return k
    if len(k) < 20:
        return k
    full = next((str(v) for v in (getattr(i, "old", None), getattr(i, "new", None))
                 if v and str(v).startswith(k) and len(str(v)) > len(k)), None)
    if full is None:
        return k
    cut = k.rfind(" ")
    return (k[:cut] if cut >= 10 else k).rstrip(" ,.:;") + "…"


_RM_OPEN = '<span style="text-decoration:line-through">'      # 행 삭제의 [이전] 값 — 삭제 = 빨강 바탕 + 취소선 (Odoo BOM 비교 규칙 그대로)


def _row_diff_table(items, extra_cell=None) -> str:
    """BOM 등 표 변경을 색상 표로: 추가=파랑, 삭제=빨강 취소선, 변경=앰버+델타.
    extra_cell: 항목→HTML 콜백 — 웹 상세가 [오탐 삭제] 버튼 칸을 붙일 때 사용
    (브리핑 메일에는 없음)."""
    # 이전/지금 두 줄 (2026-11-21 L): '행 | 내용(칸: 이전 → 지금) | 위치' → '행(굵게, 아래 품명·위치 작게) | 이전 / 지금(이름표 두 줄)'.
    # 행 추가는 [이전] 없음 / [지금] 칸 값을 ' · '로(모든 칸, 자르지 않음 — 기록), 행 삭제는 [지금] 없음, 한 칸 변경은 바뀐 곳 'M-105 · 수량'
    trs = []
    def _x(i):
        return f'<td style="{_STYLE_TD_TOP}">{extra_cell(i)}</td>' if extra_cell else ""

    def _sub(i, label: bool = True) -> str:
        bits = [x for x in ((str(getattr(i, "label", "") or "") if label else ""),
                            plain_where(i.where) if getattr(i, "where", "") else "") if x]
        return "".join(f'<div style="font-size:12.5px;color:#57606a;margin-top:2px">{_esc(b)}</div>' for b in bits)
    for i in items:
        if i.kind == "ROW_MOVED":
            # 행 순서만 바뀐 것 — 전에는 그리지 않아 '표 변경 N건'인데 근거가 0줄이었다 (검토39 P3 중간 1)
            trs.append(f'<tr valign="top" style="background:#f6f8fa;color:#57606a">'
                       f'<td style="{_STYLE_TD_TOP}">행 순서</td>'
                       f'<td style="{_STYLE_TD_TOP}" colspan="2">{_esc(i.new or "")}'
                       f'{(" — " + _esc(plain_where(i.where))) if i.where else ""}</td>{_x(i)}</tr>')
            continue
        if i.kind == "ROW_ADDED":
            trs.append(f'<tr valign="top" style="background:#dbeafe;color:#1f2328">'
                       f'<td class="k" style="{_STYLE_TD_TOP};color:#1d4ed8;font-weight:700">행 추가</td>'
                       f'<td style="{_STYLE_TD_TOP}"><b style="color:#111827">{_esc(i.key)}</b>{_sub(i)}</td>'
                       f'<td style="{_STYLE_TD_TOP}">{_m_pv("없음", _esc(row_dot(i.new, keep=999, cut=0)))}</td>{_x(i)}</tr>')
        elif i.kind == "ROW_REMOVED":
            trs.append(f'<tr valign="top" style="background:#fee2e2;color:#1f2328">'
                       f'<td class="k" style="{_STYLE_TD_TOP};color:#cf222e;font-weight:700">행 삭제</td>'
                       f'<td style="{_STYLE_TD_TOP}"><b style="color:#111827">{_esc(i.key)}</b>{_sub(i)}</td>'
                       f'<td style="{_STYLE_TD_TOP}">{_m_pv(_RM_OPEN + _esc(row_dot(i.old, keep=999, cut=0)) + "</span>", "없음")}'
                       f'</td>{_x(i)}</tr>')
        elif i.kind == "ROW_CHANGED":
            key, sep, col = split_row_cell(i.key)
            head = f"{key} · {col}" if (sep and key and col) else str(i.key)
            o, n = _d_pair(i.old, i.new, True)
            o = o if str(i.old or "").strip() else "(빈칸)"
            n = n if str(i.new or "").strip() else "(빈칸)"
            trs.append(f'<tr valign="top" style="background:#fef3c7;color:#1f2328">'
                       f'<td class="k" style="{_STYLE_TD_TOP};color:#9a6700;font-weight:700">값 변경</td>'
                       f'<td style="{_STYLE_TD_TOP}"><b style="color:#111827">{_esc(head)}</b>{_sub(i)}</td>'
                       f'<td style="{_STYLE_TD_TOP}">{_m_pv(o, n + _delta_badge(i.old, i.new))}</td>{_x(i)}</tr>')
    if not trs:
        return ""
    return (f'<table style="{_STYLE_TABLE};margin:6px 0 8px">'
            f'<tr><th style="{_STYLE_TH};width:15%">구분</th><th style="{_STYLE_TH};width:30%">행</th>'
            f'<th style="{_STYLE_TH}">이전 / 지금</th>'
            + (f'<th style="{_STYLE_TH}"></th>' if extra_cell else '') + '</tr>'
            + "".join(trs) + "</table>")


# 행 추가·삭제 값(dict repr)의 '칸': 숫자' 짝 — 칸이 수량인지는 issued.qty_head 하나로 본다 (rv0676 JG4: '수량(EA)'·'QTY(EA)'·'수 량'을 못 셌다)
# 값 뒤 단위 꼬리('4 EA'·'2SET')는 숫자만 센다 — 옛 _QTY_IN_REPR이 4로 세던 것을 빠뜨렸다 (rv0676 RJ3). 꼬리는 글자 단위만:
# '1~2'·'3/4'·'10,000'·'2026-11-09'는 수량 하나가 아니라 세지 않는다(첫 숫자만 셌다, rv0676 re2). 따옴표로 열었으면 같은 따옴표로 닫혀야
_REPR_NUM = r"(-?\d+(?:\.\d+)?)(?:\s*[A-Za-z가-힣]+)?"
_REPR_PAIR = re.compile(r"""(?:'([^']*)'|"([^"]*)")\s*:\s*(?:'""" + _REPR_NUM + r"""'|\"""" + _REPR_NUM
                        + r"""\"|(-?\d+(?:\.\d+)?)(?![\d.]))\s*[,}]""")


def _repr_num(m) -> float:
    return float(next(g for g in m.groups()[2:] if g is not None))


def _qty_col(name) -> bool:
    from watcher.extract.base import head_key
    from watcher.issued import qty_head
    return qty_head(head_key(name))


def bom_impact(items) -> tuple[int, int, int, float | None]:
    """행 변경의 발주 영향 요약: (신규 행, 삭제 행, 값 변경 건, 수량 증감 합계).
    수량 열을 못 찾으면 합계는 None. 구매 전달용 한 줄 (설계 10년차 검토)."""
    added = sum(1 for i in items if i.kind == "ROW_ADDED")
    removed = sum(1 for i in items if i.kind == "ROW_REMOVED")
    changed = sum(1 for i in items if i.kind == "ROW_CHANGED")
    delta, seen = 0.0, False
    for i in items:
        if i.kind == "ROW_CHANGED":
            if _qty_col(split_row_cell(i.key)[2]):
                try:
                    delta += float(i.new) - float(i.old)
                    seen = True
                except (TypeError, ValueError):
                    pass
        elif i.kind in ("ROW_ADDED", "ROW_REMOVED"):
            m = next((m for m in _REPR_PAIR.finditer(str(i.new or i.old or "")) if _qty_col(m.group(1) or m.group(2))), None)
            if m:
                seen = True
                delta += _repr_num(m) * (1 if i.kind == "ROW_ADDED" else -1)
    return added, removed, changed, (delta if seen else None)


def bom_impact_line(items, web: bool = False, label: str = "발주 영향") -> str:
    """행 변경 표 위 한 줄 요약. 행 변경이 없으면 빈 문자열.

    web=True면 화면용 테마 색을 쓴다 — 메일용 고정 색(#1f2328)이 다크 화면에서
    배경과 겹쳐 "발주 영향:" 글자가 사라졌다 (2026-08-31).
    label: 표 성격에 맞는 이름 (BOM류는 '발주 영향', 그 외는 '변경 요약')."""
    a, r, c, d = bom_impact(items)
    if not (a or r or c):
        return ""
    # 화면은 굵은 글자색 하나 — 파랑·빨강·노랑 세 색이 한 줄에 섞였다 (2026-11-17 화면 정리 A: 색은 강조 하나). 메일은 그대로
    add, rm, ch, base = (("var(--text)", "var(--text)", "var(--text)", "var(--text)")
                         if web else ("#1d4ed8", "#cf222e", "#9a6700", "#1f2328"))
    parts = []
    if a:
        parts.append(f'<b style="color:{add}">신규 {a}행</b>')
    if r:
        parts.append(f'<b style="color:{rm}">삭제 {r}행</b>')
    if c:
        parts.append(f'<b style="color:{ch}">값 변경 {c}건</b>')
    # 금액 합계(d)는 일부러 쓰지 않는다 — 품목 불문 합계는 발주에 쓸 수 없다
    # (2026-09-02 처음 보는 사람 검토). 인자는 호출부 호환을 위해 남겨 둔다
    return (f'<div style="font-size:13px;margin:2px 0 6px;color:{base}">'
            f'{label}: {" / ".join(parts)}</div>')


# 개별 변경 항목의 구분 라벨·색 (표 렌더용)
_ITEM_KIND = {
    "NEW_REVISION_OF": ("이전 판", "#57606a", "#f6f8fa"),
    "FIELD_CHANGED": ("값 변경", "#9a6700", "#fef3c7"),
    "FIELD_ADDED": ("값 추가", "#1d4ed8", "#dbeafe"),
    "FIELD_REMOVED": ("값 삭제", "#cf222e", "#fee2e2"),
    "TEXT_CHANGED": ("글자 변경", "#9a6700", "#fef3c7"),
    "TEXT_ADDED": ("글자 추가", "#1d4ed8", "#dbeafe"),
    "TEXT_REMOVED": ("글자 삭제", "#cf222e", "#fee2e2"),
    "PAGE_VISUAL_CHANGED": ("그림 변경", "#7c3aed", "#f3e8ff"),
    "EMBED_CHANGED": ("그림·개체 변경", "#7c3aed", "#f3e8ff"),
    "PAGE_ADDED": ("페이지 추가", "#1d4ed8", "#dbeafe"),
    "COL_RENAMED": ("열 이름 변경", "#57606a", "#f6f8fa"),
    "COL_ADDED": ("열 추가", "#1d4ed8", "#dbeafe"),
    "COL_REMOVED": ("열 삭제", "#cf222e", "#fee2e2"),
    "ROW_MOVED": ("행 이동", "#57606a", "#f6f8fa"),
    "COL_MOVED": ("열 이동", "#57606a", "#f6f8fa"),
    "PAGE_MOVED": ("페이지 순서", "#57606a", "#f6f8fa"),
    "TEXT_MOVED": ("문단 이동", "#57606a", "#f6f8fa"),
    "SHEET_ADDED": ("시트 추가", "#1d4ed8", "#dbeafe"),
    "SHEET_REMOVED": ("시트 삭제", "#cf222e", "#fee2e2"),
    "SHEET_RENAMED": ("시트 이름 변경", "#57606a", "#f6f8fa"),
    "PAGE_REMOVED": ("페이지 삭제", "#cf222e", "#fee2e2"),
    # 아래 셋이 빠져 있어 영문 코드가 그대로 표에 찍혔다 (2026-09-02 처음 보는 사람 검토)
    "REVROW_ADDED": ("개정표 행 추가", "#1d4ed8", "#dbeafe"),
    "REVROW_REMOVED": ("개정표 행 삭제", "#cf222e", "#fee2e2"),
    "REVROW_CHANGED": ("개정표 행 변경", "#9a6700", "#fef3c7"),
    # 표 행 셋 — 메일·화면은 행 표가 따로 그려 빠져 있었지만 설계 변경 대장·사내망 근거 칸에 'ROW_CHANGED'가 그대로 나갔다
    # (ux20 daily 5). 이름은 양식함 비교(forms/digest.KIND_TEXT)와 같은 말
    "ROW_CHANGED": ("행 값 변경", "#9a6700", "#fef3c7"),
    "ROW_ADDED": ("행 추가", "#1d4ed8", "#dbeafe"),
    "ROW_REMOVED": ("행 삭제", "#cf222e", "#fee2e2"),
    "NEW_REVISION_OF": ("이전 판", "#57606a", "#f6f8fa"),
    "CHECK_SKIPPED": ("검사 한계", "#57606a", "#f6f8fa"),
}


def fmt_val(v, group: bool = True) -> str:
    """항목 값을 사람 문장으로 — 리비전 행은 dict라 파이썬 표기가 그대로 찍혔다.
    저장을 거친 값은 dict의 문자열("{'DATE': …}")이라 그것도 되돌려 정돈한다 (2026-09-05)."""
    if v is None or v == "":
        return "—"
    if isinstance(v, str) and v.startswith("{") and v.endswith("}"):
        try:
            import ast
            parsed = ast.literal_eval(v)
            if isinstance(parsed, dict):
                v = parsed
        except Exception:
            pass
    if isinstance(v, dict):
        return " · ".join(f"{k}: {_group_digits(str(x))}" for k, x in v.items() if x not in (None, ""))
    if isinstance(v, (list, tuple)):
        return " · ".join(str(x) for x in v)
    # group=False: 도면 글줄·표제란 값은 적힌 그대로 — 치수 '12500'이 '12,500'으로 보였다 (검토61 B48). 표 칸(금액·수량)만 천 단위
    return _group_digits(str(v)) if group else str(v)


def _group_digits(s: str) -> str:
    """'12500000' → '12,500,000' — 금액·수량을 천 단위로 (검토54 ④·⑤). 품번·연도·날짜꼴(20261007)·앞자리 0은 그대로."""
    t = s.strip()
    if not re.fullmatch(r"-?[1-9]\d{4,}(?:\.\d+)?", t):
        return s
    if re.fullmatch(r"(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])", t):
        return s
    whole, dot, frac = t.partition(".")
    neg = whole.startswith("-")
    whole = f"{int(whole.lstrip('-')):,}"
    return ("-" if neg else "") + whole + (dot + frac if dot else "")


_W_DEL = 'style="background:#fee2e2;color:#991b1b;text-decoration:line-through"'
_W_INS = 'style="background:#dcfce7;color:#166534;font-weight:700"'


def word_diff_html(old, new, esc=_esc, del_attr: str = _W_DEL, ins_attr: str = _W_INS,
                   group: bool = True) -> tuple[str, str]:
    """두 문자열의 낱말 단위 차이 → (이전 HTML, 새 HTML). 바뀐 낱말만 표시한다 (2026-09-06 정밀화).
    낱말이 하나뿐인 긴 값(띄어쓰기 없는 문장·코드)은 글자 단위로 본다. 표시 불가(값이 아님)면
    그냥 이스케이프."""
    from difflib import SequenceMatcher
    o, n = fmt_val(old, group), fmt_val(new, group)
    if not isinstance(o, str) or not isinstance(n, str) or o == "—" or n == "—" or o == n:
        return esc(o), esc(n)
    ot, nt = o.split(), n.split()
    # 낱말 하나짜리 긴 값은 글자 단위 — 단 숫자가 든 값(날짜·코드 2026-07-10, PW-1009-A)은 통째로
    # 보여 준다: 자릿수만 색칠되면 통째보다 읽기 어렵다 (2026-09-06 사용성 3차 ④-9)
    char_mode = (len(ot) <= 1 and len(nt) <= 1 and max(len(o), len(n)) > 8
                 and not any(ch.isdigit() for ch in o + n))
    if char_mode:
        ot, nt, joiner = list(o), list(n), ""
    else:
        joiner = " "
    if len(ot) * len(nt) > 250000:
        return esc(o), esc(n)
    sm = SequenceMatcher(None, ot, nt, autojunk=False)
    oh, nh = [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            oh.append(esc(joiner.join(ot[i1:i2]))); nh.append(esc(joiner.join(nt[j1:j2])))
            continue
        if i2 > i1:
            oh.append(f"<span {del_attr}>{esc(joiner.join(ot[i1:i2]))}</span>")
        if j2 > j1:
            nh.append(f"<span {ins_attr}>{esc(joiner.join(nt[j1:j2]))}</span>")
    return joiner.join(oh), joiner.join(nh)


_WORD_KINDS = ("TEXT_CHANGED", "FIELD_CHANGED", "REVROW_CHANGED")
_LONG_LINES = 12            # 이보다 긴 여러 줄 글 덩이는 바뀐 문단 둘레만 보인다


def long_text_window(old, new, max_lines: int = _LONG_LINES, ctx: int = 1, hunks: int = 3):
    """여러 줄 글 덩이(300줄 MTEXT 주기 등)의 바뀐 문단 ±ctx줄만 — (보일 이전, 보일 새 값). 한 줄만 고쳐도 근거가 덩이 전체 × 2로
    브리핑 카드·'Rev 미갱신' 근거에 실렸다 (검토20 r03 7). 표시만 줄인다 — 비교 단위·저장 값은 그대로. 짧으면 그대로 돌려준다."""
    o, n = str(old if old is not None else ""), str(new if new is not None else "")
    ol, nl = o.split("\n"), n.split("\n")
    if max(len(ol), len(nl)) <= max_lines:
        return old, new
    from difflib import SequenceMatcher
    ops = [op for op in SequenceMatcher(None, ol, nl, autojunk=False).get_opcodes() if op[0] != "equal"]
    if not ops:
        return old, new

    def _cut(lines, spans, total):
        parts, last = [], 0
        for a, b in spans:
            a, b = max(0, a - ctx), min(len(lines), b + ctx)
            if a < last:
                a = last
            if a > last:
                parts.append("…")
            parts.extend(lines[a:b])
            last = b
        if last < len(lines):
            parts.append("…")
        return f"({total}줄 중) " + "\n".join(parts)
    shown = ops[:hunks]
    o_sp = [(i1, max(i2, i1 + 1) if i2 == i1 else i2) for _t, i1, i2, _j1, _j2 in shown]
    n_sp = [(j1, max(j2, j1 + 1) if j2 == j1 else j2) for _t, _i1, _i2, j1, j2 in shown]
    more = f"\n… 바뀐 곳 {len(ops) - hunks}곳 더" if len(ops) > hunks else ""
    return _cut(ol, o_sp, len(ol)) + more, _cut(nl, n_sp, len(nl)) + more


def item_diff_table(items, cap_of=None, extra_cell=None, budget=None, compact: bool = False) -> str:
    """개별 변경 항목(글자·값·그림)을 정렬된 표로 — 줄글 목록은 항목이 많으면
    읽기 불편하다는 피드백 반영 (2026-08-28). 전/후 사진은 해당 행 바로 아래
    전체 폭 행으로. extra_cell: 웹 상세의 [오탐 삭제] 버튼 칸 콜백.
    compact(메일 판): 사진 밑 설명 줄을 사진마다 되풀이하지 않는다 — 메일 머리에 한 번 (구매 평가 2차 F2)."""
    if not items:
        return ""
    # 이전/지금 두 줄 (2026-11-21 L): '항목 | 이전 | 새 값 | 위치' 네 칸 → '바뀐 곳(굵게, 아래 작은 위치) | 이전 / 지금(이름표 두 줄)'.
    # 묶인 사양 글줄은 태그마다 한 줄(메일 _m_text_rows와 같은 규칙), 사진은 그 항목 마지막 줄 바로 아래 전체 폭
    ncols = 3 + (1 if extra_cell else 0)
    trs = []
    for i in items:
        label, color, bg = _ITEM_KIND.get(i.kind, (i.kind, "#57606a", "#f6f8fa"))
        x = f'<td style="{_STYLE_TD_TOP}">{extra_cell(i)}</td>' if extra_cell else ""
        where = plain_where(i.where) if getattr(i, "where", "") else ""
        subs = _d_item_vals(i)
        for k, (place, o_html, n_html) in enumerate(subs):
            val = (_m_pv(o_html, n_html + (_delta_badge(i.old, i.new) if len(subs) == 1 else ""))
                   if n_html is not None else f'<span style="color:#4A5363">{o_html}</span>')
            trs.append(
                f'<tr valign="top" style="background:{bg};color:#1f2328">'
                f'<td class="k" style="{_STYLE_TD_TOP};color:{color};font-weight:700">{label}</td>'
                f'<td style="{_STYLE_TD_TOP}"><b style="color:#111827">{_esc(place)}</b>'
                + (f'<div style="font-size:12.5px;color:#57606a;margin-top:2px">{_esc(where)}</div>' if where else "")
                + f'</td><td style="{_STYLE_TD_TOP}">{val}</td>{x if k == 0 else ("<td></td>" if x else "")}</tr>')
        cap = cap_of(i) if cap_of else None
        if cap:
            block = render_capture(cap, budget, compact=compact)
            if block:
                trs.append(f'<tr><td colspan="{ncols}" style="{_STYLE_TD}">'
                           f'{block}</td></tr>')
    return (f'<table style="{_STYLE_TABLE};margin:6px 0 8px">'
            f'<tr><th style="{_STYLE_TH};width:15%">구분</th><th style="{_STYLE_TH};width:30%">바뀐 곳</th>'
            f'<th style="{_STYLE_TH}">이전 / 지금</th>'
            + (f'<th style="{_STYLE_TH}"></th>' if extra_cell else '')
            + '</tr>' + "".join(trs) + '</table>')


_STYLE_TD_TOP = _STYLE_TD + ";vertical-align:top"       # 두 줄 칸 옆 다른 칸 글이 가운데로 뜨지 않게 (세부 점검표 A9)
_D_SPAN_KINDS = ("PAGE_VISUAL_CHANGED", "EMBED_CHANGED", "PAGE_ADDED", "PAGE_REMOVED", "PAGE_MOVED", "TEXT_MOVED",
                 "COL_ADDED", "COL_REMOVED", "COL_MOVED", "SHEET_ADDED", "SHEET_REMOVED")


def _d_item_vals(i) -> list:
    """디스크 브리핑 표 한 항목 → [(바뀐 곳, 이전 HTML, 지금 HTML)]. 지금 HTML이 None이면 이전 HTML이 한 줄 글(값 짝이 없는 그림·쪽 변경).
    없던 것은 [이전] 없음, 없어진 것은 [지금] 없음 (규칙 4). 태그 줄은 태그를 바뀐 곳으로 한 번만(앞머리 떼기 — 메일과 같은 _m_text_rows)."""
    from watcher.diff import field_label
    g = not i.kind.startswith(("TEXT_", "FIELD_"))
    if i.kind == "TEXT_CHANGED":
        return [(lab, *_d_pair(*long_text_window(o, n), g)) for lab, o, n in _m_text_rows(i)]
    if i.kind in ("TEXT_ADDED", "TEXT_REMOVED"):
        lab = _m_text_cells(i)[0]
        return [(lab, "없음", _esc(fmt_val(i.new, g))) if i.kind == "TEXT_ADDED" else (lab, _esc(fmt_val(i.old, g)), "없음")]
    lab = field_label(i.key) if i.kind == "FIELD_CHANGED" else (text_key_label(i) or _ITEM_KIND.get(i.kind, (i.kind,))[0])
    oe, ne = i.old in (None, ""), i.new in (None, "")
    if i.kind in _D_SPAN_KINDS and (oe or ne):
        vals = " · ".join(_esc(unarrow(fmt_val(v, False), ev=False)) for v in (i.old, i.new) if v not in (None, ""))
        what = "선·도형 바뀜" if i.kind == "PAGE_VISUAL_CHANGED" else ""
        return [(lab, " · ".join(x for x in (what, vals) if x) or "—", None)]
    if oe and ne:
        return [(lab, "—", None)]
    o, n = _d_pair(i.old, i.new, g)
    return [(lab, "없음" if oe else o, "없음" if ne else n)]


def _d_pair(o, n, group: bool = False) -> tuple:
    """디스크 브리핑의 (이전 HTML, 지금 HTML) — 낱말이 둘 이상인 값은 바뀐 낱말만 칠한다(기록이라 메일보다 한 단계 촘촘히 — 메일
    _m_pair는 셋 이상). 낱말 하나뿐인 값('100AT'·'B')은 두 줄 자체가 차이라 칠하지 않는다. 값은 ChangeItem 그대로."""
    so, sn = fmt_val(o, group), fmt_val(n, group)
    if so != "—" and sn != "—" and so != sn and (len(so.split()) >= 2 or len(sn.split()) >= 2):
        return word_diff_html(o, n, del_attr=_MW_DEL, ins_attr=_MW_INS, group=group)
    return _esc(so), _esc(sn)


# 메일 한 통에 실을 사진의 총량(바이트, base64 기준). 사진 한 장의 픽셀 상한
# (capture._MAIL_MAX_SIDE)만으로는 파일 수십 개가 바뀐 날 한 통이 수십 MB가 된다.
# 사내 SMTP가 보통 10~25MB에서 막고, 막히면 그날 브리핑이 통째로 사라진다
# (2026-09-09 브리핑 검토 차단 4). 넘치는 자리는 글로 남기고 화면으로 보낸다.
_MAIL_PHOTO_BUDGET = 6 * 1024 * 1024
# 메일 한 통에 싣는 전/후 사진 장수 상한 (2026-11-13 결정) — 도면 80장 개정일 메일에 사진 80장(4.7MB)이 실렸다 (파일럿 시나리오 E10).
# 용량 예산(_MAIL_PHOTO_BUDGET)과 함께 건다. 검토 필요 걸린 파일 → 도면 → 그 밖 순으로 싣는다. 디스크 브리핑(화면용)은 상한 없음
_MAIL_PHOTO_MAX = 20


class PhotoBudget:
    """메일 한 통 동안 살아 있는 사진 총량 예산(용량 + 장수). 웹 화면은 쓰지 않는다(무제한)."""

    def __init__(self, limit: int = _MAIL_PHOTO_BUDGET, photos: int | None = None):
        self.left = limit
        self.skipped = 0
        self.photos = _MAIL_PHOTO_MAX if photos is None else photos     # 남은 장수(변경 한 건 = 전/후 한 쌍 = 한 장)

    def take(self, nbytes: int) -> bool:
        if nbytes > self.left:
            self.skipped += 1
            return False
        self.left -= nbytes
        return True

    def portion(self, n_left: int) -> "PhotoBudget":
        """여러 프로젝트가 한 통의 예산을 나눌 때 한 곳의 몫 — 남은 예산 ÷ 남은 곳 수. 다 못 쓴 몫은 settle 뒤 다음 곳으로
        이월된다. 앞 프로젝트가 선착으로 다 써 뒤 프로젝트는 사진이 0장이었다 (재검토 rr066 mail 4)."""
        # 장수는 올림으로 나눈다 — 내림이면 곳이 상한보다 많은 통에서 앞 프로젝트들이 0장이었다
        sub = PhotoBudget(max(0, self.left) // max(1, int(n_left)), photos=-(-max(0, self.photos) // max(1, int(n_left))))
        sub.given = sub.left
        sub.photos_given = sub.photos
        return sub

    def settle(self, sub: "PhotoBudget") -> None:
        """portion으로 내준 몫에서 실제로 쓴 만큼만 뺀다."""
        self.left -= max(0, getattr(sub, "given", sub.left) - sub.left)
        self.photos -= max(0, getattr(sub, "photos_given", sub.photos) - sub.photos)
        self.skipped += sub.skipped


def _cap_bytes(cap: dict) -> int:
    return sum(len(x.get("b64") or "") for x in (cap.get("before"), cap.get("after")) if x)


def _one_img(cap: dict, label: str, border: str, width: int = 400, bare: bool = False) -> str:
    if bare:
        # 메일 판: 사진 위 '변경 전/후' 머리·아래 좌표 설명 없이 (대체 글자 alt에는 그대로) — 좌표·레이어는 기술 문구라 표의 위치 칸에
        # 있다. 전/후 순서는 메일 머리에 한 번 (구매 평가 2차 F2)
        return (f'<td valign="top" style="padding:0 6px 0 0">'
                f'<img src="data:{cap["mime"]};base64,{cap["b64"]}" width="{width}" '
                f'alt="{_esc(label)} — {_esc(plain_where(cap["caption"]))}" '
                f'style="width:100%;max-width:{width}px;height:auto;border:1px solid {border};border-radius:6px;display:block"></td>')
    # 표 칸 + width 속성 — Outlook(Word 엔진)은 flex를 모르고 max-width도 무시해
    # 1600px 원본 폭으로 그려 가로 스크롤이 났다 (검토19 브리핑 ⑥)
    # width 속성은 Outlook용 고정 폭, style은 폰(390px)에서 줄어들게 — 고정 style 폭은
    # 폰에서 가로로 넘쳤다 (검토19 2차 브리핑 ④)
    return (f'<td valign="top" style="padding:0 6px 0 0">'
            f'<div style="font-size:12px;font-weight:700;color:{border};margin-bottom:3px">'
            f'{label}</div>'
            # alt이 없으면 메일 프로그램이 그림을 막았을 때 아무 글자도 남지 않는다
            # (2026-09-09 브리핑 검토 차단 3). 설명(caption)을 그대로 대체 글로 쓴다
            f'<img src="data:{cap["mime"]};base64,{cap["b64"]}" width="{width}" '
            f'alt="{_esc(label)} — {_esc(plain_where(cap["caption"]))}" '
            f'style="width:100%;max-width:{width}px;height:auto;border:1px solid {border};border-radius:6px;display:block">'
            f'<span style="color:#57606a;font-size:11.5px">{_esc(plain_where(cap["caption"]))}</span></td>')


def _missing_img(label: str) -> str:
    return (f'<div style="display:inline-block;vertical-align:top;margin:4px 8px 4px 0;'
            f'padding:18px 14px;border:1px dashed #d0d7de;border-radius:6px;color:#57606a;'
            f'font-size:12px">{_esc(label)}: 이 판에는 없는 페이지</div>')


def render_capture(cap: dict, budget=None, compact: bool = False) -> str:
    """전/후 캡처 렌더. 전 사진이 있으면 나란히, 없으면 후만 (덮어쓰기라 구버전 없음).
    budget(PhotoBudget)을 주면 총량을 넘는 사진은 글 한 줄로 대신한다 — 메일용.
    compact: 사진 밑 '빨간 박스…' 설명을 싣지 않는다 (메일 머리에 한 번)."""
    if not cap:
        return ""
    # 구형(단일) 캡처 호환: after/before 키가 없으면 통째로 after로 취급
    after = cap.get("after") if "after" in cap or "before" in cap else cap
    before = cap.get("before")
    if after is None and not before:
        return ""
    if budget is not None and not budget.take(_cap_bytes(
            {"before": before, "after": after})):
        where = (after or before or {}).get("caption", "")
        return (f'<!--drev-photo--><div style="color:#57606a;font-size:12.5px;margin:4px 0">'
                f'전/후 사진 생략 — 이 메일의 사진 용량 상한을 넘었습니다'
                f'{(" (" + _esc(str(where)) + ")") if where else ""}. '
                f'감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div><!--/drev-photo-->')
    inner = ""
    w = 400 if (before and after) else 640
    if before:
        inner += _one_img(before, "변경 전", "#57606a", w, bare=compact)
    if after:
        inner += _one_img(after, "변경 후", "#dc2626", w, bare=compact)
    if before and after:
        note = "빨간 박스(왼쪽 위 네모 표시)가 변경된 자리 · 좌: 이전 판, 우: 새 판"
    elif after:
        # "이전 판 파일이 없어"는 바로 위 그림 변경 행에 전 사진이 있는 화면에서 서로를
        # 부정했다 — 글자 항목은 원래 새 판 자리만 그린다 (검토19 브리핑 ⑤)
        note = ("이전 판에 없던 페이지 (추가)" if "이전 판에 없음" in str(after.get("caption", ""))
                else "빨간 박스(왼쪽 위 네모 표시)가 변경된 자리 (글자·값 변경은 새 판의 그 자리만 표시)")
    else:
        note = "이 페이지는 새 판에 없습니다 (삭제) — 뒤 페이지 번호가 하나씩 당겨졌을 수 있습니다"
    # 폭을 주어야 사진의 width:100%가 셀 폭으로 풀린다 — 폰(360px)에서 사진이 화면 밖으로 나갔다 (검토41 S6 중간 1)
    # 표식(<!--drev-photo-->)은 메일 설정 images: false가 이 묶음을 통째로 글 한 줄로 바꾸는 자리 (mail.mail_view, 2026-10-19)
    if compact and note.startswith("빨간 박스"):      # 쪽 추가·삭제 같은 뜻 있는 설명은 남긴다
        return (f'<!--drev-photo--><table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
                f'style="margin:6px 0 4px;width:100%;max-width:100%"><tr>{inner}</tr></table><!--/drev-photo-->')
    return (f'<!--drev-photo--><table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
            f'style="margin:6px 0 4px;width:100%;max-width:100%"><tr>{inner}</tr></table>'
            f'<div style="color:#57606a;font-size:12px;margin-bottom:8px">{note}</div><!--/drev-photo-->')


_DETAIL_CAP = 40  # 항목이 수백 개면(대형 도면 재출력 등) 읽을 수 없다 — 상위만 표시


def _cap_of(captures: dict | None, path: str, item, cid=None):
    """항목의 캡처. 신형 키(kind|key — 같은 key끼리 덮어쓰기 방지)를 먼저,
    구형 저장분(key만)은 폴백으로 찾는다.

    cid(변경 id)를 주면 그 키를 먼저 본다 — 같은 파일이 하루에 두 번 바뀐 날
    경로 키만으로는 아침 사진이 오후 것에 덮였다 (2026-09-09 브리핑 검토 차단 2)."""
    if not captures:
        return None
    # 같은 kind|key가 한 파일에 여럿(25쪽에 같은 NOTE 줄이 추가)이면 자리(where)까지 붙인
    # 키가 따로 있다 — 전에는 전부 마지막 쪽 사진 하나를 가리켰다 (검토19 브리핑 ④)
    k3 = f"{item.kind}|{item.key}|{item.where}"
    k2 = f"{item.kind}|{item.key}"
    if cid is not None:
        hit = (captures.get((cid, k3)) or captures.get((cid, k2))
               or captures.get((cid, item.key)))
        if hit:
            return hit
    return captures.get((path, k3)) or captures.get((path, k2)) \
        or captures.get((path, item.key))


def _is_common_item(i) -> bool:
    """전 페이지 반복(표제란·양식) 변경 — 개별 변경과 분리해 접어 보인다."""
    return i.key.startswith("공통위치") or "전 페이지 공통" in i.where


def split_display_items(items, cap_lookup, plain_cap: int, cap_photos: bool = False):
    """상세 항목의 표시용 분류 — 브리핑과 웹 상세가 공용한다
    (같은 로직을 두 곳에 두었다가 같은 버그를 두 번 고친 자리, 2026-08-26 통합).
    캡처(전/후 사진)가 붙은 항목은 표시 캡에서 자르지 않는다.
    돌려주는 값: (안내문, 개별 변경, 전 페이지 공통, 표 행, 생략 수)"""
    row_items = [i for i in items if i.kind.startswith("ROW_")]
    others, plain_shown, omitted = [], 0, 0
    for i in items:
        if i.kind.startswith("ROW_"):
            continue
        # cap_photos: 메일 크기를 줄이는 중이면 사진 붙은 항목도 상한에 넣는다 — 빼면 40→12→4로 줄여도 도면 글자 변경이 전부
        # 실려 '4건까지만' 고지가 거짓이 됐다 (검토52 D 중간 3)
        # 발주 후 변경 표지는 상한에 넣지 않는다 — 표지를 접는 곳은 메일 판뿐이다 (ux25 E1)
        if (cap_lookup(i) and not cap_photos) or _is_po_mark(i):
            others.append(i)
        elif plain_shown < plain_cap:
            others.append(i)
            plain_shown += 1
        else:
            omitted += 1
    omitted += max(0, len(row_items) - plain_cap)
    notices = [i for i in others if i.kind == "CHECK_SKIPPED"]
    commons = [i for i in others if i.kind != "CHECK_SKIPPED" and _is_common_item(i)]
    regular = [i for i in others
               if i.kind != "CHECK_SKIPPED" and not _is_common_item(i)]
    # 진짜 바뀐 글자·그림 먼저, 표제란 칸·개정이력 행은 뒤 — 화면만 고쳐 메일은 첫 사진이 늘 표제란 'B' 박스였다 (검토56 ③12)
    regular.sort(key=lambda i: 1 if (i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_")) else 0)
    return notices, regular, commons, row_items[:plain_cap], omitted


_PHOTO_PER_FILE = 10
_DISK_PHOTO_MAX = 60          # 디스크 브리핑(화면 '브리핑' 원본) 한 장의 사진 장수 — 넘으면 '사진은 화면에서', 값·근거 줄은 그대로 (검토 Y3 L7)


FILE_LEVEL_KEYS = ("파일 크기", "저장 시각")      # cli._file_level_items가 만드는 파일 수준 칸 — 표제란 칸이 아니다


def _titleish(i) -> bool:
    """표제란 칸·개정표 행·표제 일자 글줄 — 메일 판에서 한 줄로 접고 사진을 붙이지 않는다 (구매 평가 2차 F2)."""
    from watcher.diff import is_title_date_text
    return i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_") or is_title_date_text(i)


def _details_rows(path: str, items, captures: dict | None = None,
                  info: dict | None = None, budget=None, cid=None, disk: dict | None = None) -> str:
    # 한 파일의 사진은 앞 _PHOTO_PER_FILE장까지 — 같은 도면 글줄 35곳이 거의 같은 사진 35장(6.3MB, 폭 800에서 14,000px)이
    # 되어 아침 메일을 끝까지 못 읽었다 (검토63 C2). 나머지는 글로만 싣고(표시 상한에 들어간다) 사진은 화면에서
    # disk: 디스크 브리핑 한 장의 남은 사진 장수({"left": N}) — 도면 300장이 바뀐 날 원본이 사진 300장 7.6MB였다 (검토 Y3 L7).
    # 넘은 파일은 사진만 빼고 값·근거 줄은 그대로
    _with_cap = [i for i in items if _cap_of(captures, path, i, cid)]
    _keep = _with_cap[:_PHOTO_PER_FILE]
    _disk_cut = 0
    if disk is not None:
        _n = max(0, min(len(_keep), int(disk.get("left", 0))))
        _disk_cut = len(_keep) - _n
        _keep = _keep[:_n]
        disk["left"] = int(disk.get("left", 0)) - _n
        disk["cut"] = int(disk.get("cut", 0)) + _disk_cut
    _photo_ok = {id(i) for i in _keep}
    _photo_cut = len(_with_cap) - len(_photo_ok) - _disk_cut

    def _cap(i):  # 변경 위치 캡처 — 비교 결과를 도면 위에 '표시'만 한다
        return _cap_of(captures, path, i, cid) if id(i) in _photo_ok else None

    notices, regular, commons, row_items, omitted = split_display_items(
        items, _cap, _DETAIL_CAP, cap_photos=_DETAIL_CAP < 40)

    inner = ""
    if any("OCR" in str(getattr(i, "where", "") or "") for i in items):
        # 스캔본·SHX 출력 PDF의 글자는 Windows OCR로 읽은 추정값 — 0/O·1/I 오인이 있을 수 있다 (2026-09-06)
        # 사진이 있을 때만 사진을 가리킨다 — 도면이 아닌 스캔 문서는 그림을 남기지 않는데 '사진이 있으면'이 없는 사진을 찾게 했다 (검토56 ④18)
        _has_cap = any(_cap(i) for i in items)
        inner += ('<div style="border:1px solid #9a6700;border-left:5px solid #9a6700;border-radius:6px;'
                  'padding:8px 12px;margin:6px 0;background:#fff8e5;font-size:13px"><strong>OCR 추정값</strong> — '
                  '이 파일의 글자는 그림에서 읽은 것이라 O/0·I/1처럼 틀릴 수 있습니다. '
                  + ('아래 전/후 사진으로 확인하세요.' if _has_cap else
                     f'원본 파일(<code>{_esc(path)}</code>)을 열어 확인하세요.') + '</div>')
    # 설계자가 리비전 블록에 남긴 공식 개정 사유 — "왜 바뀌었나"가 한 줄로
    if info and info.get("note"):
        inner += (f'<div style="border:1px solid #d0d7de;border-left:5px solid '
                  f'#1d4ed8;border-radius:6px;padding:8px 12px;margin:6px 0;'
                  f'background:#f6f8fa;font-size:13px;color:#1f2328;overflow-wrap:anywhere">'
                  f'개정 사유(개정표): <strong>{_esc(info["note"])}</strong>'
                  f'</div>')
    # 검사 한계 고지는 값 변경(→) 표가 아니라 안내 박스로 (2026-08-25 UX 검토)
    for i in notices:
        inner += (f'<div style="border:1px solid #9a6700;border-left:5px solid #9a6700;'
                  f'border-radius:6px;padding:8px 12px;margin:6px 0;background:#fff8e5;'
                  f'font-size:13px"><strong>{_esc(i.key)}</strong> — {_esc(unarrow(notice_text(i)))}</div>')
    # 표 문서(BOM·사양서)는 행 표가 진짜 내용인데 표제란 REV·개정이력 행 뒤에 붙었다 — 글자·그림 → 행 표 → 표제란·개정이력
    # (검토57 ③12)
    _tb = [i for i in regular if i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_")]
    _content = [i for i in regular if i not in _tb]
    if _content:
        inner += item_diff_table(_content, cap_of=_cap, budget=budget)
    # 요약 줄은 잘리기 전 전체 행으로 센다 — 200건 바뀐 날 표 상한(40)만큼 '값 변경 40건'이라 했다 (검토61 C37)
    inner += bom_impact_line([i for i in items if i.kind.startswith("ROW_")], label=impact_label(path)) + _row_diff_table(row_items)
    if _tb:
        inner += item_diff_table(_tb, cap_of=_cap, budget=budget)
    if commons:
        # <details>는 Outlook·Gmail에서 접히지 않거나 아예 안 보인다 — 제목 줄 + 표로 (검토19 브리핑 ⑥)
        inner += (f'<div style="margin:6px 0;font-size:13px;color:#57606a">'
                  f'전 페이지 공통 변경(표제란·양식류) {len(commons)}건</div>'
                  f'{item_diff_table(commons, cap_of=_cap, budget=budget)}')
    if omitted:
        inner += (f'<div style="color:#57606a;font-size:12.5px;margin-top:4px">'
                  f"외 {omitted}건 생략 — 변경이 매우 많은 문서라 위 {_DETAIL_CAP}건만 "
                  f"표시했습니다. 전체는 감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div>")
    if _photo_cut > 0:
        inner += (f'<div style="color:#57606a;font-size:12.5px;margin-top:4px">'
                  f"전/후 사진은 이 파일에서 앞 {_PHOTO_PER_FILE}곳만 실었습니다 — 나머지 {_photo_cut}곳의 사진은 "
                  f"감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div>")
    if _disk_cut > 0:
        inner += (f'<div style="color:#57606a;font-size:12.5px;margin-top:4px">'
                  f"전/후 사진은 화면에서 — 이 브리핑에는 사진을 {_DISK_PHOTO_MAX}장까지만 실었습니다 "
                  f"(이 파일 {_disk_cut}곳). 감시 PC 화면의 변경 상세에 있습니다.</div>")
    return (f'<tr><td colspan="5" style="{_STYLE_TD};background:#fafbfc">'
            f"{inner}</td></tr>")


_SCAN_ERR_MAX = 50
# 따옴표 안이 **경로 모양**(C:\…·\\서버·/…)일 때만 — '시트를 찾을 수 없음: '개정이력''의 사유까지 잘랐다 (검토36 E 낮음 3)
_ERR_PATH_TAIL = re.compile(r"""\s*:\s*(['"])(?:[A-Za-z]:[\\/]|\\\\|/).*?\1\s*$""")


def scan_error_rows(scan_errors) -> list[tuple[str, str]]:
    """읽지 못한 파일 목록을 (표시 이름, 오류) 줄로 — 같은 폴더·같은 오류는 한 줄. 메일과 화면이 같이 쓴다.
    같은 폴더의 오류는 한 줄로 묶는다 — 공유 폴더 하나가 끊긴 날 파일마다 한 줄씩 상한 없이
    실려, 그 폴더와 무관한 프로젝트 메일까지 770KB·2,000줄이 됐다(4만 파일이면 사내 메일 크기 제한에 걸려
    그날 메일이 모두 실패할 수 있다, 검토35 B 중간 4)"""
    from collections import OrderedDict
    groups: "OrderedDict[tuple, list]" = OrderedDict()
    for p, err in scan_errors:
        sp = str(p)
        folder = sp if sp.endswith("/") or "/" not in sp else sp.rsplit("/", 1)[0] + "/"
        # OSError 문구 끝의 파일 경로(": 'C:\\…'")를 걷는다 — 경로가 파일마다 달라 묶음이 한 번도 안
        # 됐고, 메일에 감시 PC의 절대 경로가 실렸다 (검토36 B 중간 1)
        err = _ERR_PATH_TAIL.sub("", str(err)).strip() or str(err)
        groups.setdefault((folder, err), []).append(sp)
    rows = []
    for (folder, err), paths in groups.items():
        if len(paths) == 1:
            rows.append((paths[0], err))
        else:
            rows.append((f"{folder} 안 파일 {len(paths)}개", err))
    return rows


# 삭제 알림 보류 표식 — 검사 본체가 scan_errors 꼬리에 이 머리로 넣는다. '읽지 못한 파일'이 아니라 **사라진 파일**의 알림이라
# 따로 센다: 파일 79개가 사라진 날 제목이 '변경 0건 — 알림 1건', 본문 첫 상자가 '읽지 못한 파일 1건(잠김·권한…)'이었다
# (재검토 2026-10-28 R5-2)
HOLD_MARKS = ("(대량 삭제 보류)", "(감시 폴더 비어 있음)")


def is_hold_note(p) -> bool:
    return str(p).startswith(HOLD_MARKS)


def split_hold_notes(scan_errors) -> tuple[list, list]:
    """(삭제 보류 알림, 진짜 읽기 오류)."""
    holds = [(p, e) for p, e in (scan_errors or []) if is_hold_note(p)]
    errs = [(p, e) for p, e in (scan_errors or []) if not is_hold_note(p)]
    return holds, errs


def hold_file_count(holds) -> int:
    """보류 중인 파일 수 — 대량 삭제 알림의 수(전체), 없으면 빈 감시 폴더 알림들의 합."""
    def _n(msg):
        m = re.search(r"파일\s*([\d,]+)\s*개", str(msg))
        return int(re.sub(",", "", m.group(1))) if m else 0     # str.replace는 읽기 전용 검사(test_readonly)가 막는다
    mass = [_n(e) for p, e in holds if str(p).startswith(HOLD_MARKS[0])]
    return max(mass) if mass else sum(_n(e) for _p, e in holds)


def _hold_section(holds) -> str:
    n = hold_file_count(holds)
    lis = "".join(f'<li>{_esc(_hold_label(p))} — <span style="color:#57606a">{_esc(err)}</span></li>' for p, err in holds)
    return f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 12px;background:#ffebe9">
    <strong style="color:#cf222e">{f'파일 {n}개가 한꺼번에 사라져' if n else '파일이 한꺼번에 사라져'} 삭제 알림 보류 중</strong>
    <div style="font-size:13px;margin-top:4px">서버·네트워크 드라이브 연결이 끊긴 것일 수 있어 이 파일들을 아직 삭제로 기록하지
    않았습니다. 파일이 돌아오면 저절로 풀립니다. 정말 지운 것이면 감시 PC 화면에서 [삭제로 기록]을 누르세요.</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}</ul>
  </div>"""


def _hold_label(p) -> str:
    s = str(p)
    for m in HOLD_MARKS:
        if s.startswith(m):
            rest = s[len(m):].strip()
            return rest or m.strip("()")
    return s


def _scan_errors_section(scan_errors) -> str:
    holds, scan_errors = split_hold_notes(scan_errors)
    out = _hold_section(holds) if holds else ""
    if not scan_errors:
        return out
    # 50줄에서 자른다 (검토35 B 중간 4)
    rows = scan_error_rows(scan_errors)
    more = len(rows) - _SCAN_ERR_MAX
    lis = "".join(f'<li>{_esc(p)} — <span style="color:#57606a">{_esc(err)}</span></li>'
                  for p, err in rows[:_SCAN_ERR_MAX])
    if more > 0:
        lis += f'<li style="color:#57606a">외 {more}건 — 감시 PC의 watcher.log에 전부 남아 있습니다</li>'
    return out + f"""
  <div style="border:1px solid #9a6700;border-left:6px solid #9a6700;border-radius:6px;
              padding:10px 14px;margin:0 0 12px;background:#fff8e5">
    <strong style="color:#9a6700">읽지 못한 {'폴더·파일' if any(str(p).endswith('/') for p, _ in scan_errors) else '파일'} {len(scan_errors)}건</strong>
    <div style="font-size:13px;margin-top:4px">잠김·권한·연결 문제로 이번 실행에서 확인하지
    못했습니다. 감시 폴더 자체가 안 열린 경우 그 폴더의 프로젝트는 이 통에 없습니다. 다음 성공 시 변경 감지가 재개됩니다.</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}</ul>
  </div>"""


def _toc_entries(changes, details: dict, doc_info: dict | None = None,
                 baseline: bool = False, details_by_id: dict | None = None, plain: dict | None = None,
                 was_out: dict | None = None) -> list:
    """목차 줄 재료 [(번호, 이름, 요약, 접지 말 것)] — 목차와 메일 압축이 같은 요약을 쓴다.
    plain: 주면 {번호: 값 짝(이전 → 지금)을 뺀 요약 조각들}을 채운다 — 디스크 브리핑 목차가 값 짝은 이름표 두 줄로 따로 그리고
    '글자 변경 3건'·'표(BOM) 변경 4건' 같은 건수만 이름 옆에 싣는다 (이전/지금 두 줄 2026-11-21 L). 요약 글 자체는 그대로.
    was_out: 주면 {번호: 같은 요약의 '지금(이전 …)' 꼴}을 채운다 — 값 짝을 만드는 자리에서 같은 값으로 함께 만든다(요약 글을 다시 쪼개면
    값 속 쉼표·쌍점에서 이전 값이 바뀌었다, 검토 Y2 H1). 한 줄 자리(목차·메일 제목·머리 한 줄)는 이것을 쓴다."""
    lis = []
    for i, c in enumerate(changes):
        items = (details_by_id or {}).get(c.id)
        if items is None:
            items = details.get(c.path, [])
        vis = 0
        for it in items:
            if it.kind != "PAGE_VISUAL_CHANGED":
                continue
            m = re.search(r"(\d+)개 페이지 반복", str(it.where or ""))
            vis += int(m.group(1)) if m else 1     # 공통 위치 1건 = 여러 쪽 (검토19 2차 ⑧)
        txt = sum(1 for it in items if it.kind.startswith("TEXT_") and it.kind != "TEXT_MOVED")
        _tk = {it.kind for it in items if it.kind.startswith("TEXT_") and it.kind != "TEXT_MOVED"}
        # 전부 추가면 '추가', 전부 삭제면 '삭제' — 문단이 새로 붙은 사양서를 '글자 변경'이라 했다 (검토33 A 낮음 2)
        _txt_word = ("글자 추가" if _tk == {"TEXT_ADDED"} else "글자 삭제" if _tk == {"TEXT_REMOVED"} else "글자 변경")
        row = sum(1 for it in items if it.kind.startswith("ROW_") and it.kind != "ROW_MOVED")
        from watcher.diff import is_rev_field
        rev = next((it for it in items if is_rev_field(it)), None)
        parts = []

        def _short(v) -> str:
            return " ".join(str(v or "").split())[:36]

        def _pair(o, n) -> tuple:
            # 긴 값은 앞 36자가 같아 머리줄이 '… 조정 → … 조정'처럼 같은 글로 보였다 — 처음 다른 곳 앞뒤를 보인다 (검토61 C32)
            o, n = " ".join(str(o or "").split()), " ".join(str(n or "").split())
            if len(o) <= 36 and len(n) <= 36:
                return o, n
            k = 0
            while k < min(len(o), len(n)) and o[k] == n[k]:
                k += 1
            st = max(0, k - 12)
            if st and " " in o[st:k]:
                st = st + o[st:k].index(" ") + 1
            cut = lambda v: ("…" if st else "") + v[st:st + 36] + ("…" if len(v) > st + 36 else "")  # noqa: E731
            return cut(o), cut(n)
        # '지금(이전 …)' 꼴 — 화살표 조각을 만드는 자리에서 같은 값으로 함께 만든다(만든 글을 다시 쪼개지 않는다, 검토 Y2 H1)
        _wmap: dict = {}

        def _reg(a: str, w: str) -> str:
            _wmap[a] = w
            return a

        def _tpair(o, n) -> str:
            po, pn = _pair(o, n)
            from watcher.summary import was_pair
            lt, rt = po.split(" "), pn.split(" ")
            if len(lt) > 1 and len(rt) > 1 and lt[0] == rt[0] and is_tag_word(lt[0]):
                w = was_pair(" ".join(lt[1:]), " ".join(rt[1:]), lt[0])     # 태그 줄은 태그를 바뀐 곳으로 한 번 (항목 값에서)
            else:
                w = was_pair(po, pn)
            return _reg(" → ".join((po, pn)), w)

        def _spair(lead: str, o, n) -> str:
            """붙여 쓴 조각 '열 이름 수량→QTY'·'Rev A→B'·'크기 1,234→2,345'와 그 '지금(이전 …)'."""
            from watcher.summary import was_pair
            return _reg(f"{lead} {o}→{n}".strip(), was_pair(o, n, lead))

        # 첫 줄에 "무엇이 어떻게" — 건수만 있으면 팀장이 열어 봐야 알았다 (파일럿 모의 2차 조건 2)
        def _row_head_of(it) -> str:
            rk, sep, col = split_row_cell(it.key)         # 'X-11.수량' → 'X-11 수량'
            head = f"{rk} {col}".strip() if sep else str(it.key)
            _o, _n = _pair(_group_digits(str(it.old)), _group_digits(str(it.new)))
            from watcher.summary import was_pair
            return _reg(f"{_short(head)}: {_o} → {_n}", f"{_short(head)}: {was_pair(_o, _n)}")   # 머리줄도 천 단위 (검토55 ④1)
        row_head = next((_row_head_of(it) for it in items
                         if it.kind == "ROW_CHANGED" and it.old and it.new), None)
        # DXF 사양 글자를 가장 가까운 태그와 짝지은 이름표가 있으면 그것 — '3.7kW 4P 380V 2.2kW…→5.5kW…' 대신
        # 'M-101: 3.7kW 4P 380V → 5.5kW 4P 380V' (구매 평가 2차 F2)
        _pl = pair_label
        _labs = list(dict.fromkeys(_pl(it) for it in items if _pl(it)))
        if _labs:
            # 짝 이름표 'M-101: 3.7kW → 5.5kW'는 근거 줄 꼴 — 확실할 때만 '지금(이전 …)', 아니면 그 조각 그대로
            _reg("; ".join(_labs), "; ".join(ev_text(x) for x in _labs))
        txt_head = "; ".join(_labs) if _labs else next((_tpair(it.old, it.new)
                                                        for it in items if it.kind == "TEXT_CHANGED" and it.old and it.new
                                                        and _UNIT_RE.search(str(it.old) + " " + str(it.new))), None)
        # 단위 없는 글자 변경도 무엇이 바뀌었는지 — 문단마다 다른 낱말을 고친 사양서 14장이 모두 '글자 변경 1건'이라
        # 목차가 '외 11건이 같은 내용'으로 접었다 (검토61 D B1). 값이 같은 것끼리만 접힌다
        if txt_head is None:
            # 표제 일자 글줄('DATE: 09-26 DRAWN: …')은 요약 머리가 아니다 — 출도 PDF 줄이 날짜 줄로 시작해 진짜 변경(태그 추가)이
            # '글자 변경 4건'에 묻혔다 (구매 평가 2차 P2 day5). 다른 글줄이 없을 때만
            from watcher.diff import is_title_date_text as _itd
            _tc = [it for it in items if it.kind == "TEXT_CHANGED" and it.old and it.new]
            txt_head = next((_tpair(it.old, it.new) for it in _tc if not _itd(it)), None) if any(
                not _itd(it) for it in items if it.kind.startswith("TEXT_")) else next(
                (_tpair(it.old, it.new) for it in _tc), None)
        if txt_head:
            parts.append(txt_head)
        if vis:
            parts.append(f"그림 변경 위치 {vis}곳")
        if txt and not txt_head:
            parts.append(f"{_txt_word} {txt}건")
        elif txt > 1 and txt_head:
            # '글자 변경 외 1건'은 '글자 변경 말고 다른 무엇 1건'으로 읽혔다 — 모두 몇 건인지 (검토71 R4 낮음 10)
            parts.append(f"{_txt_word} {txt}건")
        if row:
            _row_plain = f"{table_label(c.path)} 변경 {row}건"
            parts.append(_row_plain + (f" ({row_head})" if row_head else ""))
        # 페이지·순서·표제란 칸·리비전 행은 목차에 요약이 없어 '— 수정'으로만 보였다 (검토61 B13·B14·T15·T25)
        _cnt = Counter(it.kind for it in items)
        # 단위를 붙인다 — '페이지 삭제 1'과 '글자 변경 2건'이 한 줄에 섞였다 (검토71 R4 낮음 10)
        if _cnt.get("PAGE_ADDED"):
            parts.append(f"페이지 추가 {_cnt['PAGE_ADDED']}쪽")
        if _cnt.get("PAGE_REMOVED"):
            parts.append(f"페이지 삭제 {_cnt['PAGE_REMOVED']}쪽")
        # 문서 안 그림·개체 — 그림만 바꾼 사양서가 목차·제목에서 '— 수정'으로만 보였다 (검토71 R4 차단 1)
        _emb: dict = {}
        for it in items:
            if it.kind == "EMBED_CHANGED":
                _emb[str(it.key)] = _emb.get(str(it.key), 0) + 1
        for _ek, _en in _emb.items():
            _base, _, _verb = _ek.rpartition(" ")
            parts.append(f"{_base} {_en}개 {'바뀜' if _verb == '교체' else _verb}" if _base else f"{_ek} {_en}개")
        if _cnt.get("PAGE_MOVED"):
            parts.append("페이지 순서 바뀜")
        if _cnt.get("TEXT_MOVED"):
            parts.append(f"문단 이동 {_cnt['TEXT_MOVED']}건")
        if _cnt.get("ROW_MOVED") and not row:
            parts.append("행 순서 바뀜")
        # 열·시트 단위 변경도 — 열 삭제·시트 추가만 있는 표가 목차·'오늘 확인할 것'에서 '— 수정'으로만 보였다 (검토68 C5)
        _names = lambda kind: ", ".join(dict.fromkeys(_short(it.key) for it in items if it.kind == kind)) if _cnt.get(kind) else ""  # noqa: E731
        for _k, _w in (("COL_ADDED", "열 추가"), ("COL_REMOVED", "열 삭제"), ("SHEET_ADDED", "시트 추가"), ("SHEET_REMOVED", "시트 삭제")):
            if _cnt.get(_k):
                parts.append(f"{_w} {_names(_k)}")
        for it in items:
            if it.kind == "COL_RENAMED" and it.old and it.new:
                parts.append(_spair("열 이름", _short(it.old), _short(it.new)))
            elif it.kind == "SHEET_RENAMED" and it.old and it.new:
                parts.append(_spair(it.label or "시트 이름 변경", _short(it.old), _short(it.new)))
        if _cnt.get("COL_MOVED"):
            parts.append("열 순서 바뀜")
        _idf = next((it for it in items if it.kind == "FIELD_CHANGED" and it.old and it.new
                     and it.key in ("DWG_NO", "DOC_NO", "TITLE", "PROJECT")), None)
        if _idf:
            _fl = {"DWG_NO": "도면번호", "DOC_NO": "문서번호", "TITLE": "제목", "PROJECT": "프로젝트"}[_idf.key]
            _ip = _pair(_idf.old, _idf.new)
            from watcher.summary import was_pair as _wp
            parts.append(_reg(f"{_fl} {' → '.join(_ip)}", _wp(_ip[0], _ip[1], _fl)))
        _rr = sum(1 for it in items if it.kind.startswith("REVROW_"))
        if _rr and not rev:
            parts.append(f"개정표 행 {'추가' if {it.kind for it in items if it.kind.startswith('REVROW_')} == {'REVROW_ADDED'} else '변경'} {_rr}건")
        if rev:
            from watcher.diff import _blank_rev
            # 첫 발행은 'Rev None→A'가 아니라 첫 기재 (검토38 R1 중간 3·R3 중간 6)
            parts.append(f"Rev {rev.new} 첫 기재" if _blank_rev(rev.old) else _spair("Rev", rev.old, rev.new))
        # 축척 — 목차에 '글자 변경 1건'으로만 묻혔다 (검토43 C 중간 6)
        sc = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "SCALE" and it.old and it.new), None)
        if sc:
            parts.append(_spair("축척", _short(sc.old), _short(sc.new)))
        # 표제란 칸이 지워진 것(PROJECT → 없음)은 목차에 없었다 (검토21 브리핑 중간 9)
        fdel = next((it for it in items if it.kind == "FIELD_CHANGED" and it.old
                     and not it.new and it.key not in ("파일 크기", "저장 시각")), None)
        if fdel:
            from watcher.diff import field_label
            parts.append(f"표제란 {field_label(fdel.key)} 칸 삭제 ({_short(fdel.old)})")
        dt = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "DATE"), None)
        if dt and not parts:
            parts.append(_spair("표제란 일자", dt.old, dt.new))
        # 내용을 못 읽는 파일 — 크기·저장 시각이 유일한 근거인데 목차는 "수정"뿐이었다 (검토19 브리핑 ⑮)
        sz = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "파일 크기"), None)
        # 형식은 읽는데 이번 판을 못 읽었으면(손상·잘림) 그것부터 — 제목엔 '[읽지 못함 1]'인데 목차는 바이트 수만 말했다 (검토50 B 중간 8)
        # 항목 이름은 '내용 추출 실패' 또는 '내용 비교'(값 '수행 못 함: …') — 앞의 것만 보아 목차가 바이트 수만 말했다 (검토52 D 낮음 13)
        _unread = next((it for it in items if it.kind == "CHECK_SKIPPED" and (
            "추출 실패" in str(it.key or "") or (str(it.key or "") == "내용 비교" and "수행 못 함" in str(it.new or "")))), None)
        if _unread and not parts:
            parts.append(_unread_label(str(_unread.new or "")))
        if sz and not parts:
            parts.append(_spair("크기", sz.old, sz.new))
        elif sz and _unread and len(parts) == 1:
            parts.append(_spair("크기", sz.old, sz.new))
        elif not parts:
            tm = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "저장 시각"), None)
            if tm:
                parts.append(f"저장 시각 {tm.new}")
        note = next((it for it in items
                     if it.kind == "CHECK_SKIPPED" and it.key == "참고"), None)
        if note and not parts:
            # 구판 '대체됨' 같은 참고 — 목차만 보는 사람이 삭제로 오해하지 않게
            # (2026-09-02 재검토)
            parts.append(str(note.new).split(" — ")[0])
        name = PurePosixPath(c.path).name if "/" in c.path else c.path
        info = ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path))
        if info and info.get("dwg"):  # 실무 언어: 도면번호가 파일명보다 먼저
            name = f'{num_prefix(c.path)}{info["dwg"]} — {name}'
        if info and info.get("folder"):
            # 같은 이름 파일이 프로젝트 안에 또 있으면 어느 폴더 것인지 — 메일 머리 한 줄만 고쳐지고 '오늘 확인할 것'은 원본과
            # 같은 줄이었다 (ux21 mail 3)
            name += f' ({info["folder"]} 폴더)'
        summary = ", ".join(parts) or ("첫 등록" if baseline and c.kind == "added" else KIND_LABEL_TEXT(c))
        # 사양값(kW·A·V·mm…)이 바뀐 줄이나 표 행 변경은 접히지 않는다 — 10장 중 한 장의
        # 모터 kW 변경이 "외 7건이 같은 내용"에 묻혔다 (검토19 2차 브리핑 ⑦)
        salient = bool(row) or bool(_emb) or any(
            it.kind.startswith("TEXT_") and _UNIT_RE.search(str(it.old or "") + " " + str(it.new or ""))
            for it in items)
        _rp = (_row_plain + f" ({row_head})") if (row and row_head) else None
        if plain is not None:
            # 값 짝(화살표가 든 조각)은 빼고, 표 행 조각은 괄호 속 첫 값 짝만 뗀다
            plain[i] = [(_row_plain if (_rp and p_ == _rp) else p_) for p_ in parts if (_rp and p_ == _rp) or "→" not in p_]
        if was_out is not None:
            # 같은 조각의 '지금(이전 …)' 꼴 — 만든 자리에서 함께 만든 것만(모르는 조각은 그대로)
            was_out[i] = (", ".join((f"{_row_plain} ({_wmap.get(row_head, row_head)})" if (_rp and p_ == _rp) else _wmap.get(p_, p_))
                                    for p_ in parts) or summary)
        lis.append((i, name, summary, salient))
    return lis


ADDED_FOLD_MIN = 5          # 같은 폴더·같은 형식의 '추가'가 이만큼 넘으면 한 행으로 (기능 검토 2026-11-02 J5)
_SHEET_EXTS = (".pdf", ".dxf", ".dwg", ".tif", ".tiff", ".jpg", ".jpeg", ".png")


def added_folds(main: list, details: dict | None, details_by_id: dict | None = None, skip=()) -> dict:
    """{id(변경): (대표 변경, 폴더, 확장자, [같은 묶음 변경들])} — 같은 폴더에 같은 형식 파일이 ADDED_FOLD_MIN개 넘게 새로 들어온 날
    파일마다 한 행(이름·폴더·확인 링크)이 이어져 진짜 변경이 아래로 밀렸다(watch B5). 비교가 실린 추가(이전 판과 짝지은 새 판)는
    접지 않는다 — 그건 수정이다. 폴더 이동 ≥3 접기와 같은 방식."""
    groups: dict = {}
    for c in main:
        if c.kind != "added" or id(c) in skip:
            continue
        its = items_for(c, details, details_by_id)
        if any(getattr(i, "kind", "") != "CHECK_SKIPPED" for i in its or ()):
            continue
        pp = PurePosixPath(c.path)
        groups.setdefault((str(pp.parent), pp.suffix.lower()), []).append(c)
    out: dict = {}
    for (folder, ext), cs in groups.items():
        if len(cs) >= ADDED_FOLD_MIN:
            for c in cs:
                out[id(c)] = (cs[0], folder, ext, cs)
    return out


def added_fold_text(folder: str, ext: str, n: int) -> str:
    unit = "장" if ext in _SHEET_EXTS else "개"
    return f"폴더 {folder}에 {(ext.lstrip('.') or '확장자 없는').upper()} {n}{unit} 추가"


def _added_fold_row(lead, folder: str, ext: str, cs: list) -> str:
    names = ", ".join(_esc(PurePosixPath(c.path).name) for c in cs)
    return (f'<tr><td class="k" style="{_STYLE_TD}"><strong style="color:{_KIND_COLOR["added"]}">추가</strong></td>'
            f'<td style="{_STYLE_TD}" colspan="2"><b>{_esc(added_fold_text(folder, ext, len(cs)))}</b>'
            f'<details style="margin-top:4px;font-size:12.5px;color:#57606a"><summary style="cursor:pointer">'
            f'파일 이름 {len(cs)}개 보기</summary>{names}</details></td>'
            f'<td style="{_STYLE_TD};color:#57606a;font-size:12.5px">감시 PC 화면에서 한꺼번에 확인</td></tr>')


def _summary_toc(changes, details: dict, doc_info: dict | None = None,
                 baseline: bool = False, details_by_id: dict | None = None, companions: dict | None = None,
                 folds: dict | None = None) -> str:
    """상단 요약 목차: 파일별로 무엇이 몇 건인지 한눈에 (2026-08-25 UX 검토 —
    '변경 1건' 헤더 아래 항목 수백 개가 예고 없이 이어지던 문제).

    같은 파일이 하루에 두 번 바뀐 날은 **변경 id별** 상세를 쓴다 — 경로 키만 보면
    두 줄 모두에 최신 건수가 붙어 아래 근거표와 숫자가 달랐다
    (2026-09-09 배포 후 검토 중간 1)."""
    if not changes:
        return ""
    plain: dict = {}
    was_of: dict = {}           # 같은 요약의 '지금(이전 …)' 꼴 — 만든 자리에서 함께 (Y2 H1)
    lis = _toc_entries(changes, details, doc_info, baseline, details_by_id, plain=plain, was_out=was_of)
    was_by_sum = {}
    for i_, _n, sm_, _s in lis:
        was_by_sum.setdefault(sm_, was_of.get(i_, sm_))
    if companions:
        # 메일 판: 같은 도면의 출도 PDF는 DXF 줄에 붙인다 — 그 PDF도 아래 표에 제 한 줄이 있다 (구매 평가 2차 F2)
        by_cad: dict = {}
        for k, c in enumerate(changes):
            if id(c) in companions:
                by_cad.setdefault(id(companions[id(c)]), []).append(PurePosixPath(c.path).name)
        lis = [(i, name + "".join(f" + {n}" for n in by_cad.get(id(changes[i]), [])), summary, salient)
               for i, name, summary, salient in lis if id(changes[i]) not in companions]
    if folds:
        # 같은 폴더·형식의 추가 묶음은 대표 한 줄 (J5)
        _fl = []
        for i, name, summary, salient in lis:
            f_ = folds.get(id(changes[i]))
            if f_ is None:
                _fl.append((i, name, summary, salient))
            elif f_[0] is changes[i]:
                _fl.append((i, added_fold_text(f_[1], f_[2], len(f_[3])), "이름 목록은 아래 행에 접어 둠", True))
        lis = _fl
    # 같은 요약이 여덟 줄 넘게 반복되면 접는다 — 도면 60장이 전부 "Rev A→B, 글자 1건"인 날
    # 팀장은 60줄을 지나야 첫 상세를 봤다 (검토19 브리핑 ⑧). 상세는 그대로 전부 싣는다
    from collections import Counter as _Counter
    counts = _Counter(s for _, _, s, sal in lis if not sal)
    shown: dict = {}
    out_li = []

    def _li(i, name, summary) -> str:
        # 이전/지금 두 줄 (2026-11-21 L): 이름 옆에는 건수 조각만('글자 변경 3건'), 값 짝은 아래에 바뀐 곳 줄 + 이름표 두 줄
        # (앞 _M_LINK_PARTS곳, 덩이 사이 점선, 나머지 '외 N곳'). 값 짝을 그릴 항목이 없으면 요약을 화살표 없이 한 줄로
        c = changes[i]
        pv = "" if (baseline or id(c) in (folds or {})) else _toc_pairs_html(
            c, items_for(c, details, details_by_id), (doc_info or {}).get(c.id) or (doc_info or {}).get(c.path))
        txt = ", ".join(plain.get(i, [])) if pv else was_by_sum.get(summary, summary)
        return (f'<li style="margin:3px 0"><a href="#chg{i}" style="color:#1d4ed8">{_esc(name)}</a>'
                + (f'<span style="color:#57606a"> — {_esc(txt)}</span>' if txt else "")
                + (f'<div style="margin:4px 0 10px">{pv}</div>' if pv else "") + '</li>')
    for i, name, summary, salient in lis:
        if salient:
            out_li.append(_li(i, name, summary))
            continue
        k = shown.get(summary, 0)
        if counts[summary] > 8 and k >= 3:
            shown[summary] = k + 1
            continue
        shown[summary] = k + 1
        out_li.append(_li(i, name, summary))
    for summary, n in counts.items():
        if n > 8:
            out_li.append(f'<li style="margin:3px 0;color:#57606a">… 외 {n - 3}건이 같은 내용'
                          f'({_esc(was_by_sum.get(summary, summary))}) — 아래 상세에 전부 있습니다</li>')
    # 기준선 통에는 '확인할 것'이 없다 — 등록 목록이다 (검토21 브리핑 중간 10)
    return ('<div style="border:1px solid #d0d7de;border-radius:6px;'
            'padding:10px 14px;margin:0 0 14px;background:#f6f8fa">'
            f'<strong>{"등록된 산출물 (요약)" if baseline else "오늘 확인할 것"}</strong>'
            f'<ul style="margin:6px 0 0;padding-left:20px">{"".join(out_li)}</ul></div>')


def _d_blocks(blocks: list) -> str:
    """덩이 여러 개를 위아래로 — 덩이 사이 옅은 점선 1px·위 10px (규칙 3, 메일 _m_issue_values와 같은 꼴)."""
    return "".join(b if k == 0 else f'<div style="border-top:1px dashed #E3E6EC;margin-top:10px;padding-top:4px">{b}</div>'
                   for k, b in enumerate(blocks))


def _toc_pairs_html(c, items, info) -> str:
    """디스크 브리핑 목차('오늘 확인할 것') 한 변경의 값 — 바뀐 곳(굵게) 한 줄 + [이전]/[지금] 두 줄 + 위치(작게), 덩이 사이 점선.
    고르는 곳은 메일 링크형·공용 줄과 같은 _m_item_rows(무게순 앞 _M_LINK_PARTS곳, Rev는 늘 앞) — 나머지는 '외 N곳'(아래 상세에 전부).
    값은 ChangeItem 그대로(원칙 4). 그릴 값 짝이 없으면(새 파일·삭제·이동·안내만) 빈 글 — 부르는 쪽이 요약 한 줄로."""
    try:
        rows = _m_item_rows(c, list(items or ()), info, link=True, split_where=True)
    except Exception:                       # noqa: BLE001 — 목차 덤이 브리핑을 막지 않게(아래 상세는 그대로)
        return ""
    if not any(r[0] == "pair" for r in rows):
        return ""
    blocks, tail = [], ""
    for r in rows:
        if r[0] == "note":
            tail = (f'<div style="font-size:13px;color:#57606a;margin-top:4px">'
                    f'{str(r[1]).split(" — ")[0]} — 아래 상세에 모두 있습니다</div>')
            continue
        lab, _s, where = str(r[1]).partition("\x1f")
        body = _m_pv(r[2], r[3]) if r[0] == "pair" else f'<div style="margin-top:2px">{r[2]}</div>'
        blocks.append(_m_place_line(lab, 0) + body + _m_where(where))
    return _d_blocks(blocks) + tail


def _one_details(c, details: dict, details_by_id: dict | None, captures,
                 doc_info: dict | None, budget, disk: dict | None = None) -> str:
    """변경 한 건의 상세 — 같은 파일이 하루에 두 번 바뀐 날은 변경 id별 상세를 쓴다. disk: 디스크 브리핑 사진 장수(_details_rows)."""
    items = (details_by_id or {}).get(c.id)
    if items is None:
        items = details.get(c.path)
    if not items:
        return ""
    return _details_rows(c.path, items, captures, ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)),
                         budget=budget, cid=c.id, disk=disk)


def KIND_LABEL_TEXT(c) -> str:
    return _KIND_LABEL.get(c.kind, c.kind)


def _short_roots(root: str) -> str:
    """머리말의 감시 폴더는 마지막 폴더 이름만 — 전체 서버 경로가 고객에게 전달되는 통에
    그대로 실렸다 (검토19 2차 브리핑 ⑫). 전체는 title로 남긴다."""
    raw = "\n".join("\n".join(str(root or "").split(" · ")).split(", "))   # replace()는 읽기 전용 가드가 막는다
    parts = [p.strip() for p in raw.splitlines() if p.strip()]
    names = []
    for p in parts:
        q = "/".join(p.split("\\")).rstrip("/")
        names.append(q.rsplit("/", 1)[-1] or q)
    return " · ".join(names) if names else str(root)


# ── 메일 두 꼴 (2026-11-17 R4, DECISIONS 같은 날) ──────────────────────────────────────────────────────────────
# 사내망 기록 열람이 켜져 있으면 링크형: 건수 + 확인 필요 먼저 + 변경마다 한 줄 요약 + 기록 링크(사진 없음 — 기록 화면에 있다).
# 원칙 4: 링크형도 줄마다 값(구값 → 신값)이 든 요약이다 — 요약은 ChangeItem 값 그대로(watcher.summary). 근거 없는 줄은 만들지 않는다
# (파일 추가·삭제는 그 사실이 근거). 꺼져 있으면 근거형(구/신/위치 표 + 맨 앞 줄 요약).

SHARED_MAIL_MAX = 10          # 메일 끝 '공용 폴더 변경' 줄에 싣는 변경 수 — 나머지는 수만(링크형이면 그 폴더 기록 링크)
LINK_LINES_MAX = 40           # 링크형 한 통의 변경 상한 — 메일 3판(2026-11-20)은 변경마다 표 줄(앞 3곳)이라 300줄이면 Gmail 잘림
                              # 한도(102KB)를 넘는다. 넘으면 '외 N건 — 프로젝트 기록에 모두 있습니다'
_MAIL_BODY_BUDGET = 86_000    # 근거형 한 통 본문(사진 빼고)의 바이트 몫 — 넘으면 뒤 변경은 '외 N건' 한 줄(검토 X M2). 변경마다 근거 줄
                              # 수가 달라(1줄~수십 줄) 건수가 아니라 크기로 끊는다. Gmail 잘림 한도 102KB(cli.GMAIL_CLIP_BYTES 95KB) 안
_EV_ROWS_MIN = 20_000         # 확인 필요가 아주 많아도 바뀐 내용 줄에 남기는 최소 몫
_LINK_ISS_BUDGET = 34_000     # 링크형 확인 필요 줄의 바이트 몫(약 12줄) — 나머지는 바뀐 내용 줄 몫. 넘으면 '외 N건 — 사내망 확인 필요 목록 ›'
                              # (검토 Y3 M2: 확인 필요 15줄 40KB + 변경 40줄 85KB = 127KB로 Gmail 잘림 한도를 넘었다)
_EV_CUT_NAMES = 300           # 접은 변경의 파일 이름을 싣는 수 — 이름만 한 줄(원칙 5), 넘으면 수만


def shared_block(shared: list | None, shared_issues: list | None = None) -> str:
    """메일 끝 '공용 폴더 변경 N건' 카드 — 공용·공통 폴더는 메일 초안을 따로 만들지 않아 그 변경(표준도면 Rev 올림 등)이 메일
    어디에도 없었다 (pv2 B-4). [(폴더 이름, Change, 한 줄 요약)]. 표식(<!--drev-shared-->)은 하루 묶음이 맨 아래 한 번만 싣는 자리.
    shared_issues: 그 공용 폴더들의 오늘 검토 필요(Rev 미갱신 등) — 머리에 수를 함께 (V3-8: 줄에는 [확인 필요]인데 수에는 없었다).
    메일 3판(2026-11-20): 줄마다 폴더(회색 표시) · 요약(= 기록의 요약, 구값 → 신값 — 원칙 4) · 사내망 기록 '보기 ›'."""
    if not shared:
        return ""
    n_si = len(shared_issues or ())
    folders: dict = {}
    for ent in shared:
        name, c, line = ent[0], ent[1], ent[2]
        its = ent[3] if len(ent) > 3 else None          # 변경 항목(있으면 값을 이전/지금 두 줄로 — 2026-11-21)
        folders.setdefault(str(name or "공용"), []).append((c, line, its))
    rows = []
    shown = 0
    for name, ents in folders.items():
        for c, line, its in ents:
            if shown >= SHARED_MAIL_MAX:
                break
            shown += 1
            url = lan_url(c.id) if (LAN_BASE and getattr(c, "id", None)) else ""
            rows.append('<tr valign="top" class="dm-r1">' + _m_td(_mtag("gray", name, wrap=True), extra=_M_EDGE_L)
                        + _m_td(_m_shared_cell(c, line, its), extra=("" if url else _M_EDGE_R))
                        + (_m_td(_m_go(url), extra=_M_EDGE_R + ";text-align:right") if url else "") + "</tr>")
    rest = len(shared) - shown
    tl = " · ".join(f'<a href="{_esc(lan_project_url(nm))}" style="color:#2F3EC2;font-weight:700;text-decoration:none">'
                    f'{_esc(nm)} 기록 ›</a>' for nm in folders if lan_project_url(nm))
    link = any("<a " in r for r in rows)
    if rest > 0:
        rows.append(f'<tr><td colspan="{3 if link else 2}" style="{_M_TD};{_M_EDGE_L};font-size:14px;color:#4A5363">외 {rest}건 — '
                    + ("위 폴더 기록에 모두 있습니다" if tl else "감시 PC 화면의 그 폴더 기록에 모두 있습니다") + '</td></tr>')
    count = _m_count(len(shared)) + (f'<span style="color:#A15C00"> · 확인 필요 {n_si}건</span>' if n_si else "")
    heads = [("폴더", "width:96px"), ("바뀐 내용", "")] + ([("", "width:52px")] if link else [])
    card = _m_card(_m_card_head("공용 폴더 변경", count, sub="프로젝트가 아닌 공용·공통 폴더", right=tl), _m_table(heads, rows, stack=True))
    return f"<!--drev-shared-->{card}<!--/drev-shared-->"


def _m_shared_cell(c, line: str, its) -> str:
    """공용 폴더 줄의 '바뀐 내용' 칸 — 항목이 있으면 파일 이름(굵게) + 바뀐 곳마다 이름 / 이전·지금 두 줄(앞 3곳, 링크형 줄과 같은
    _m_item_rows), 확인 필요 머리는 그 앞에 한 줄. 값이 없는 줄(새 파일·삭제·이동)·항목을 못 받은 옛 호출은 기록 요약 그대로."""
    from watcher.summary import CONFIRM
    pairs = []
    if its and getattr(c, "kind", "") == "modified":
        try:
            pairs = [r for r in _m_item_rows(c, list(its), None, link=True) if r[0] in ("pair", "span", "note")]
        except Exception:                   # noqa: BLE001 — 덤 줄이 메일을 막지 않게
            pairs = []
    if not any(r[0] == "pair" for r in pairs):
        return _esc(unarrow_summary(line, its))        # 항목에서 만든 조각만 바꾼다 (Y2 H1)
    head = ""
    s = str(line or "")
    if s.startswith(CONFIRM):
        h = s[len(CONFIRM):].split(" — ", 1)[0]
        head = f'<div style="margin-top:2px">{_mtag("amber" if "Rev" in h else "red", "확인 필요", wrap=True)} {_esc(h)}</div>'
    out = [_m_name(PurePosixPath(c.path).name) + head]
    for k, r in enumerate(pairs):
        dash = "" if k == 0 else "border-top:1px dashed #E3E6EC;padding-top:10px;margin-top:10px;"
        if r[0] == "pair":
            out.append(f'<div style="margin-top:6px;{dash}">{_m_place_line(r[1], 0)}{_m_pv(r[2], r[3])}</div>')
        elif r[0] == "span":
            out.append(f'<div style="margin-top:6px;{dash}">{_m_place_line(r[1] + " " + r[2], 0)}</div>')
        else:
            out.append(_m_sub(r[1]))
    return "".join(out)


SHARED_ONLY_LABEL = "공용 폴더"       # 공용 줄만 실은 통의 이름 — 제목 '[Drev] [공용 폴더] …'·하루 묶음 목차


def shared_only_brief(shared: list, shared_issues: list | None, run_at: datetime, root: str, *,
                      scanned_count: int | None = None, since: str | None = None) -> str:
    """프로젝트 통이 하나도 없는 날(또는 공용 줄을 아직 못 받은 받는 사람)의 '공용 폴더 변경'만 실은 통 (V3-1).
    공용 폴더는 메일 초안을 따로 만들지 않고 프로젝트 통 끝에 한 줄로 싣는데(pv2 B-4), 그날 프로젝트 변경이 없으면 표준도면 Rev 올림·
    공용 도면 Rev 미갱신이 메일 어디에도 없었다. 줄은 프로젝트 통 끝 칸과 같다(요약 = 기록의 요약, 구값 → 신값 — 원칙 4).
    머리 띠·요약·검사 시각 줄·꼬리말은 프로젝트 통과 같은 꼴(메일 3판) — 하루 묶음(digest_brief)이 그대로 엮는다."""
    date_str = run_at.strftime("%Y-%m-%d %H:%M")
    n_si = len(shared_issues or ())
    scanned_note = f" · 파일 {scanned_count}개 검사함" if scanned_count is not None else ""
    since_note = f" · 비교 기준: 직전 검사 {since}" if since else ""
    top = ((LAN_ACK_LINE if ACK_ON.get() else LAN_VIEW_LINE) if LAN_BASE else "")
    rows = (_m_summary(n_si, len(shared), [], "오늘은 프로젝트 폴더의 변경이 없고, 프로젝트가 아닌 공용·공통 폴더만 바뀌었습니다.")
            + shared_block(shared, shared_issues) + _m_foot(date_str, root, scanned_note, since_note, None, top))
    left = (f'<span style="font-size:18px;color:#CDD2DC;vertical-align:middle"> &nbsp;·&nbsp; </span>'
            f'<span style="font-size:18px;font-weight:800;color:#111827;vertical-align:middle">{SHARED_ONLY_LABEL}</span>')
    return _mail_doc(_m_head_band(left, _esc(_m_when(run_at))), rows, date_str, (n_si, len(shared)))


# ══════════════════════════════════ 메일 3판 (2026-11-20 화면 3판 재설계) ══════════════════════════════════
# 사장·팀장이 아침에 가장 먼저 보는 것이 이 메일이다 — 감시 화면 시안(최근 변경)과 같은 제품으로 보이게, 칸 이름이 있는 표로 바꾼다.
#   머리 띠(Drev · 프로젝트 · 날짜) → 요약(확인 필요 N건 · 바뀐 파일 N개) → '확인 필요' 표(문제 · 대상 · 근거 · 파일)
#   → '바뀐 내용' 표(문서 · 파일 · 바뀐 곳 · 이전 · 지금 · 상태) → 전/후 사진(표 아래 두 칸) → 기록 버튼(링크형) → 맨 아래 작은 글
# 메일 앱(Outlook·Gmail·네이버)용: 표 틀 + 인라인 스타일만(외부 CSS·웹폰트·스크립트 없음), 폭 680 가운데, 글자 15~16px(가장 작은 13px),
# 회색 글자는 흰 바탕 대비 7:1 이상(#4A5363). 표시 색은 시안의 네 가지(빨강 확인 필요·노랑 Rev 관련·초록 확인함·회색 종류)만.
# 메일 판(photo_budget)만 이 꼴이다 — 디스크 브리핑(기록·화면 '브리핑')은 그대로. 값·근거(구/신/위치)는 표 칸에 그대로(원칙 4).
# 글자 크기·색·줄바꿈 규칙은 표(table)에 한 번 — 칸마다 되풀이하면 30건 메일이 Gmail 잘림 한도(102KB)를 넘었다.
_MC_FONT = "'Malgun Gothic','Apple SD Gothic Neo','Segoe UI',sans-serif"
_MC_TAG = {"red": ("#FDF1F0", "#F4C7C3", "#C8281E"), "amber": ("#FFF7E6", "#F3D9A4", "#A15C00"),
           "green": ("#EAF7EF", "#B7E3C8", "#0E7A43"), "gray": ("#F1F3F6", "#DDE1E8", "#2B3341")}
_MC_BOX = {"warn": ("#FFF7E6", "#F3D9A4", "#5C3B00"), "bad": ("#FDF1F0", "#F4C7C3", "#8A1C14"),
           "info": ("#EEF0FE", "#C9CEF5", "#1F2A8A"), "ok": ("#EAF7EF", "#B7E3C8", "#0A5530")}
# 줄바꿈은 낱말 단위(break-word) — 'anywhere'면 표가 칸 폭을 정할 때 값 칸을 글자 하나 폭까지 줄여 'MOT/OR 2.2k/W'로 쪼갰다.
# 공백 없는 긴 파일 이름만 아무 데서나 꺾는다(_m_name). 폰 폭(540px 이하)은 아래 미디어 규칙이 모든 칸을 꺾는다.
# 칸 폭은 머리 줄 폭 그대로(table-layout:fixed) — 띄어쓰기 없는 긴 파일 이름('E-399_컨베이어구동부전장결선도_최종.dxf')이 표를 777px로
# 밀어 760 폭 창에서 상태 칸이 잘렸다 (검토 X M1). 고정이면 칸이 늘지 않고, 넘는 낱말만 그 칸 안에서 꺾인다
_M_TBL = ("width:100%;border-collapse:collapse;table-layout:fixed;font-size:15px;line-height:1.45;color:#2B3341;"
          "word-break:keep-all;overflow-wrap:break-word")
_M_TH = ("padding:9px 8px;background:#F8F9FB;border-top:1px solid #E3E6EC;border-bottom:1px solid #E3E6EC;"
         "font-size:13.5px;font-weight:700;color:#4A5363;text-align:left;white-space:nowrap")
_M_TD = "padding:11px 8px 9px;border-top:1px solid #E3E6EC"          # 세로 맞춤은 줄(<tr valign="top">)에 한 번
_M_TD2 = "padding:1px 8px 9px"              # 같은 변경의 둘째 줄부터 — 줄 사이 선 없이
_M_SUB = "font-size:13.5px;color:#4A5363"
_M_EDGE_L, _M_EDGE_R = "padding-left:16px", "padding-right:16px"
_MW_DEL = 'style="background:#FDF1F0;color:#C8281E;text-decoration:line-through"'
_MW_INS = 'style="background:#EAF7EF;color:#0E7A43"'
_MAIL_CSS = ("@media (max-width:540px){.dm-wrap{padding:8px 4px!important}.dm-t td,.dm-t th{padding-left:4px!important;"
             "padding-right:4px!important;font-size:13.5px!important;overflow-wrap:anywhere!important;white-space:normal!important;"
             "width:auto!important}.dm-t span{white-space:normal!important}.dm-h{display:none!important}"
             ".dm-band td{display:block!important;text-align:left!important;white-space:normal!important}"
             ".dm-band td+td{padding-top:0!important}.dm-num{font-size:24px!important}"
             "img{max-width:100%!important;height:auto!important}"
             # 줄 쌓기(dm-s) — 폰 폭(375)에서 칸을 나란히 두면 칸마다 몇 글자씩 세로로 꺾여 읽을 수 없었다(2026-11-21 사진).
             # 바뀐 내용·확인 필요·공용 폴더 표는 줄마다 칸을 위아래로: 파일 → 바뀐 곳 → 이전/지금 두 줄 → 상태. 칸 이름 줄은 숨긴다
             ".dm-s,.dm-s tbody,.dm-s tr,.dm-s td{display:block!important}"
             ".dm-s th,.dm-s td:empty{display:none!important}.dm-s td{border-top:0!important;padding:3px 14px!important}"
             ".dm-r1{border-top:1px solid #E3E6EC;padding:9px 0 6px}.dm-r2{border-top:1px dashed #E3E6EC;margin:0 14px;"
             "padding-top:4px}.dm-r2 td{padding:3px 0!important}}")
_M_LINK_PARTS = 3              # 링크형 한 변경의 줄 — 기록 요약과 같은 앞 3곳(무게순), 나머지는 '외 N곳'(기록 화면에 전부)

# 확인 필요 종류의 '문제' 칸 이름·색은 화면과 한 곳(consistency.short_label·label_tone — 빨강 = 서로 다름·거꾸로, 노랑 = Rev 표기,
# 회색 = 읽기 한계·참고). 아래는 메일 '바뀐 내용' 표의 그 파일 쪽 '상태' 칸 말 — 비면 상태 칸에 싣지 않는다(회색 종류).
# 판정·원래 이름(CODE_LABEL)은 그대로 — 보일 때만 짧은 이름
_M_STATUS = {
    "BOM_MISMATCH": "BOM과 다름", "TAG_MISMATCH_ACROSS_DRAWINGS": "도면끼리 다름", "CONTENT_CHANGED_REV_SAME": "Rev 안 올림",
    "REV_BLOCK_MISMATCH": "Rev 표기 다름", "REV_ROW_DUPLICATE": "개정표 Rev 중복", "REV_REGRESSED": "Rev 거꾸로",
    "POST_ISSUE_CHANGE": "출도 후 변경",
}
_M_MANY = ("REV_REGRESSED", "CONTENT_CHANGED_REV_SAME", "REV_CHANGED_CONTENT_SAME")   # 같은 종류가 많으면 앞 15줄만


def _mtag(color: str, text: str, wrap: bool = False) -> str:
    """표시 하나. wrap: 칸이 좁으면 꺾인다(상태 칸 — 칸 폭이 고정이라 '도면·BOM 다름'·'확인함 · 이름'이 옆 칸으로 넘치지 않게)."""
    bg, bd, fg = _MC_TAG[color]
    return (f'<span style="display:inline-block;font-size:13px;font-weight:700;padding:1px 7px;border:1px solid {bd};'
            f'border-radius:6px;background:{bg};color:{fg};{"max-width:100%;box-sizing:border-box" if wrap else "white-space:nowrap"}">'
            f'{_esc(text)}</span>')


def _m_issue_kind(code) -> tuple:
    """(문제 칸 이름, 색, 상태 칸 말) — 이름·색은 화면과 같은 consistency.short_label·label_tone."""
    from watcher.consistency import label_tone, short_label
    return short_label(code), label_tone(code), _M_STATUS.get(str(code or ""), "")


def _m_row(inner: str, pad: str = "0 0 16px") -> str:
    return f'<tr><td style="padding:{pad}">{inner}</td></tr>'


_M_CARD = ('<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
           'style="width:100%;background:#FFFFFF;border:1px solid #E3E6EC;border-radius:12px;border-collapse:separate">')


def _m_card(head: str, body: str) -> str:
    """흰 카드 한 장 — 머리(구역 제목 18px) + 몸(표). 카드 사이 16px."""
    return _m_row(f"{_M_CARD}{head}{body}</table>")


def _m_card_head(title: str, count: str = "", sub: str = "", right: str = "") -> str:
    """카드 머리 — '확인 필요 3건'처럼 제목 + 수 + 회색 덧말 + 오른쪽 링크."""
    return ('<tr><td style="padding:14px 16px 12px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
            'border="0"><tr><td style="vertical-align:middle">'
            f'<h2 style="margin:0;font-size:18px;line-height:1.35;font-weight:800;color:#111827">{title}{count}'
            + (f'<span style="font-size:14.5px;font-weight:400;color:#4A5363"> &nbsp;{sub}</span>' if sub else "")
            + '</h2></td>'
            + (f'<td align="right" style="vertical-align:middle;white-space:nowrap;font-size:15px">{right}</td>' if right else "")
            + '</tr></table></td></tr>')


def _m_count(n: int, red: bool = False) -> str:
    return f'<span style="color:{"#C8281E" if red else "#111827"}"> {n}건</span>'


def _m_box(kind: str, head: str, lines=()) -> str:
    """안전에 필요한 알림·덧붙임 한 묶음 — 시안의 ds-alert(warn·bad·info·ok). head는 이미 HTML(굵은 머리 + 한 줄), lines는 HTML 줄들."""
    bg, bd, fg = _MC_BOX[kind]
    body = "".join(f'<div style="font-size:13.5px;margin-top:3px">{x}</div>' for x in lines)
    return _m_row('<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
                  f'style="width:100%;background:{bg};border:1px solid {bd};border-radius:10px;border-collapse:separate">'
                  f'<tr><td style="padding:12px 16px;font-size:15px;line-height:1.5;color:{fg};word-break:keep-all;'
                  f'overflow-wrap:anywhere">{head}{body}</td></tr></table>')


def _m_table(heads: list, rows: list, hide=(), stack: bool = False) -> str:
    """데이터 표 — heads: [(칸 이름, 폭 style)], rows: 이미 만든 <tr>들. 첫·끝 칸은 16px 안쪽 여백(시안 ds-t).
    hide: 폰 폭에서 숨길 칸 번호(그 칸의 td에도 class="dm-h"). stack: 폰 폭에서 줄마다 칸을 위아래로 쌓는다(dm-s — _MAIL_CSS)."""
    n = len(heads)
    ths = []
    for k, (lab, w) in enumerate(heads):
        edge = (";" + _M_EDGE_L if k == 0 else "") + (";" + _M_EDGE_R if k == n - 1 else "")
        cls = ' class="dm-h"' if k in hide else ""
        ths.append(f'<th{cls} style="{_M_TH}{edge}{(";" + w) if w else ""}">{lab}</th>')
    return (f'<tr><td style="padding:0"><table role="presentation" class="dm-t{" dm-s" if stack else ""}" width="100%" '
            'cellpadding="0" cellspacing="0" '
            f'border="0" style="{_M_TBL}"><tr>{"".join(ths)}</tr>'
            + "".join(('<tr valign="top">' + r[4:]) if r.startswith("<tr>") else r for r in rows) + '</table></td></tr>')


def _m_td(inner: str, first: bool = True, extra: str = "", attrs: str = "") -> str:
    return f'<td{attrs} style="{_M_TD if first else _M_TD2}{(";" + extra) if extra else ""}">{inner}</td>'


def _m_go(url: str, text: str = "보기") -> str:
    """사내망 기록으로 가는 줄 끝 링크 — 시안의 '›' 칸. 주소 규칙은 lan_url 그대로."""
    return (f'<a href="{_esc(url)}" style="color:#2F3EC2;font-weight:700;font-size:14px;text-decoration:none;'
            f'white-space:nowrap">{text}&nbsp;›</a>') if url else ""


def _m_name(name: str) -> str:
    # 띄어쓰기 없는 긴 이름은 아무 데서나 꺾는다 — 표를 밀어 넘치게 하지 않게 (검토 X M1)
    return f'<b style="color:#111827;overflow-wrap:anywhere">{_esc(name)}</b>'


# ── 이전 / 지금 두 줄 (2026-11-21 사용자 "바뀌기 전·바뀐 부분 글씨는 행을 바꿔서 — 화살표 빼고는 구분도 잘 안 되고 읽기도 어렵다") ──
# 한 변경의 이전 값·지금 값을 이름표 붙은 두 줄로: [이전] 옅은 글자·보통 굵기 / [지금] 진한 글자·굵게. 화살표(→)를 쓰지 않는다.
# 서로 다른 두 출처를 견주는 근거(도면·BOM 다름 등)는 같은 꼴에 이름표만 [도면] / [BOM] — 둘 다 진한 글자, 이름표 회색.
# 태그를 걷은 글이 줄마다 '이전 50AT' / '지금 60AT'(이름표와 값 사이 공백 하나)가 되게 — 평문 메일(mail.plain_text_of)과
# 벤치 채점기(basic61 _PAIR_LINES)가 이 꼴을 읽는다. 줄마다 class="dm-pl"(평문이 줄을 나누는 표식), 덩이는 class="dm-pv".
# 모양은 시안(mk3.py .pv)을 인라인 style로 그대로 (2026-11-21 세부 점검표 A): 이름표 12.5px·굵기 800·둥근 5px·안쪽 1px 7px·
# 줄 높이 1.5·가운데·폭 = 두 이름표 중 넓은 쪽(최소 40px) → 두 줄의 값이 같은 x에서 시작. 이름표와 값 사이 10px(여백 6px + 빈칸),
# 두 줄 사이 4px. 값이 꺾이면 값 첫 글자 자리에서 이어진다(매달린 들여쓰기). [이전] 이름표 회색·값 #5B6475 15px 보통 /
# [지금] 이름표 옅은 파랑·파란 글자, 값 진한 글자 800·15.5px / 출처 견주기는 두 이름표 회색(#2B3341)·두 값 진하게 800.
_M_PV_LAB = ("display:inline-block;box-sizing:border-box;text-align:center;font-size:12.5px;font-weight:800;line-height:1.5;"
             "padding:1px 7px;border-radius:5px;white-space:nowrap;text-indent:0;margin-right:6px;")
_M_PV_TONE = {"o": ("background:#EEF0F3;color:#4A5363", "color:#5B6475;font-size:15px;font-weight:400"),
              "n": ("background:#EEF0FE;color:#2F3EC2", "color:#111827;font-size:15.5px;font-weight:800"),
              "s": ("background:#EEF0F3;color:#2B3341", "color:#111827;font-size:15.5px;font-weight:800")}


def _m_lab_w(*labels) -> int:
    """이름표 폭(px) — 두 이름표 중 넓은 쪽, 최소 40. 12.5px 굵은 글자 어림(한글 13 · 대문자 8.8 · 그 밖 7.6) + 안쪽 14."""
    def w(s):
        return sum(13 if ord(ch) > 0x2E80 else 8.8 if ch.isupper() else 7.6 for ch in str(s)) + 14
    return int(max(40, min(150, max(w(x) for x in labels))) + 0.999)


def _m_pv(o_html: str, n_html: str, labels: tuple = ("이전", "지금"), side: bool = False) -> str:
    """이전/지금(또는 도면/BOM) 두 줄 — 값은 이미 HTML(이스케이프된 것). 평문·채점기는 줄마다 '이전 X' / '지금 Y'로 읽는다."""
    lo, ln = labels
    lw = _m_lab_w(lo, ln)
    ind = lw + 10

    def line(lab, tone, v, top):
        lab_s, val_s = _M_PV_TONE[tone]
        return (f'<div class="dm-pl" style="padding-left:{ind}px;text-indent:-{ind}px{top}">'
                f'<span style="{_M_PV_LAB}width:{lw}px;{lab_s}">{_esc(lab)}</span> <span style="{val_s}">{v}</span></div>')
    return (f'<div class="dm-pv">{line(lo, "s" if side else "o", o_html, "")}'
            f'{line(ln, "s" if side else "n", n_html, ";margin-top:4px")}</div>')


def _m_where(text: str) -> str:
    """두 줄 아래 작은 회색 한 줄 — 위치(도면 층·시트·행)·파일 (원칙 4의 '위치'). 평문에서도 제 줄(dm-pl)."""
    return f'<div class="dm-pl" style="font-size:13.5px;color:#4A5363;margin-top:4px">{text}</div>' if text else ""


def _m_place_line(lab_html: str, top: int = 6) -> str:
    """두 줄 위 '바뀐 곳' 한 줄(굵게) — 한 칸에 이름과 두 줄을 함께 싣는 곳(확인 필요 근거·공용 폴더 줄). 평문에서도 제 줄."""
    return f'<div class="dm-pl" style="margin-top:{top}px;color:#111827">{lab_html}</div>'


def _m_sub(text: str) -> str:
    return f'<div style="{_M_SUB}">{text}</div>'


def _m_bold_fact(fact: str) -> str:
    """사실 한 줄의 핵심 값만 굵게 — 'Rev는 B 그대로'·'Rev만 A → B'·'최신 행 A'. 값 사이 화살표는 말로(unarrow, 2026-11-21)."""
    s = _esc(unarrow(fact))
    b = '<span style="font-weight:700;color:#111827">'
    s = re.sub(r"(Rev(?:는|가|만)? (?:[^\s,·]+ → )?[^\s,·]+(?: 그대로)?)", b + r"\1</span>", s)
    return re.sub(r"(최신 행 )([^\s,·]+)", r"\1" + b + r"\2</span>", s)


_M_EV_TAIL = re.compile(r"\s\(([^()]*),\s*([^(),]+\.[A-Za-z0-9]{2,5})\)\s*$")


def _m_ev_place(ev: str) -> tuple:
    """근거 줄 끝 괄호 '(위치, 파일)' → (위치, 파일). 못 읽으면 ('', '')."""
    m = _M_EV_TAIL.search(ev)
    return (m.group(1).strip(), m.group(2).strip()) if m else ("", "")


_M_REVBLK = (re.compile(r"\(([^()·]{1,20}?) (\S+) · 개정표 (\S+)\)\.?\s*$"),
             re.compile(r"개정표에 Rev (\S+) 행이 추가됐는데 (\S+(?: 머리)?) Rev는 (\S+) 그대로"))
_M_VS = re.compile(r"\(([^()]+?) vs ([^()]+?)\)")


def _m_side_pair(iss, evs: list) -> tuple:
    """서로 다른 두 출처를 견주는 확인 필요 → (두 줄 HTML, 쓴 근거 줄들) — [표제란]/[개정표]·[E-101]/[E-102] (2026-11-21 규칙 5).
    문구의 값 그대로만(원칙 4) — 못 읽으면 ('', [])."""
    msg = str(iss.message or "")
    if iss.code == "REV_BLOCK_MISMATCH":
        m = _M_REVBLK[0].search(msg)
        if m:
            return _m_pv(_esc(m.group(2)), _esc(m.group(3)), (m.group(1).strip(), "개정표"), side=True), []
        m = _M_REVBLK[1].search(msg)
        if m:
            return _m_pv(_esc(m.group(3)), _esc(m.group(1)), (m.group(2), "개정표"), side=True), []
    if iss.code == "TAG_MISMATCH_ACROSS_DRAWINGS":
        m = _M_VS.search(msg)
        if m:
            names = []
            for e in evs:
                f = _m_ev_place(e)[1]
                if f and PurePosixPath(f).stem not in names:
                    names.append(PurePosixPath(f).stem)
            labs = tuple(cut_words(x, 12) for x in names[:2]) if len(names) >= 2 else ("한 도면", "다른 도면")
            return _m_pv(_esc(m.group(1).strip()), _esc(m.group(2).strip()), labs, side=True), []
    return "", []


def _m_issue_values(iss, items, k: int) -> tuple:
    """'Rev 안 올림' 같은 사실 한 줄 아래에 그 변경의 값 — (HTML, 다 싣지 못한 곳 수). 바뀐 곳(굵게) / 이전·지금 두 줄 / 위치(작게).
    값은 ChangeItem 그대로(_m_item_rows — 메일 표와 같은 이름·차례)."""
    from types import SimpleNamespace
    its = [i for i in (items or ()) if hasattr(i, "kind")]
    if not its:
        return "", 0
    rows = [r for r in _m_item_rows(SimpleNamespace(path=iss.path, id=None), its, None, link=True, split_where=True)
            if r[0] == "pair"]
    out = []
    for j, r in enumerate(rows[:k]):
        lab, _sep, where = r[1].partition("\x1f")
        blk = _m_place_line(lab) + _m_pv(r[2], r[3]) + _m_where(where)
        # 덩이 사이 옅은 점선 (2026-11-21 규칙 3)
        out.append(blk if j == 0 else f'<div style="border-top:1px dashed #E3E6EC;margin-top:10px;padding-top:4px">{blk}</div>')
    return "".join(out), max(0, len(rows) - k)


def _m_issue_cells(iss, items, n_lines: int, recurred: dict | None, k_vals: int | None = None, ev_cut: int = 160) -> tuple:
    """확인 필요 한 줄 → (대상 HTML, 근거 HTML). 근거 = 핵심 값 + 근거 줄(값·위치·파일 — 원칙 4).
    이전/지금 두 줄(2026-11-21): 도면·BOM 다름은 [도면] / [BOM] 두 줄 + 파일·위치 작은 줄, 표제란·개정표 다름·도면끼리 다름도 같은 꼴,
    Rev 안 올림은 사실 한 줄(문장 그대로) 아래에 바뀐 값을 [이전] / [지금] 두 줄로.
    k_vals: Rev 안 올림 아래 값 덩이 수(기본은 메일 몫 1·2), ev_cut: 글 근거 줄 자르는 길이 — 디스크 브리핑(기록)은 넉넉히 (L)."""
    from watcher.summary import _mismatch_bits
    fact, shown, _notes = _iss_card_text(iss)
    evs = [(short_paths(human_ev(e)) if ev_cut <= 160 else human_ev(e)) for e in card_ev(shown)]   # 기록(디스크)은 경로 그대로
    m = re.search(r"\]\s*(?:태그\s+)?([^\s:\]]+?)(?::|의 사양)", str(iss.message or ""))
    target = m.group(1) if (m and iss.code in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS")) else ""
    lead, rest = "", list(evs)
    place_line = ""
    if iss.code == "BOM_MISMATCH":
        bits = _mismatch_bits(iss.message or "", list(iss.evidence or ()))
        if bits:
            target = target or bits[0]
            lead = _m_pv(_esc(bits[1]), _esc(bits[2]), ("도면", "BOM"), side=True)
            # 'BOM: … (BOM 시트 9행, BOM.xlsx)'·'도면 [Rev A, …]: … (도면 층 EQUIPMENT, E-104.dxf)' → 두 줄 아래 작은 한 줄
            # '도면 파일 · 위치 ↔ BOM 파일 · 위치'
            b_ev = next((e for e in rest if e.startswith("BOM:")), "")
            d_ev = next((e for e in rest if e.startswith(("도면", "문서", "출도본"))), "")
            (bp, bf), (dp, df) = _m_ev_place(b_ev), _m_ev_place(d_ev)
            if bf and df:
                rv = re.search(r"\[(Rev [^,\]]+)", d_ev)
                place_line = f"{df}{(' ' + rv.group(1)) if rv else ''} · {dp} ↔ {bf} · {bp}"
                rest = [e for e in rest if e not in (b_ev, d_ev)]
    elif iss.code in ("REV_BLOCK_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS"):
        lead, _used = _m_side_pair(iss, rest)
        if lead:
            lead = f'<div style="margin-bottom:4px">{_m_bold_fact(fact)}</div>' + lead
    vals_html, vals_more = "", 0
    if not lead:
        lead = _m_bold_fact(fact)
        if iss.code == "CONTENT_CHANGED_REV_SAME":
            # Rev 그대로 무엇이 바뀌었나 — 그 변경의 값(ChangeItem)을 두 줄로 (V3-9). 링크형도 값이 보이게 — 근거 줄 한 줄만 싣던 때는
            # 머리 '이번 변경 2건 중 예시:'만 남고 값이 '외 근거 2줄'로 접혔다 (검토 X L5)
            vals_html, vals_more = _m_issue_values(iss, items, k_vals or (1 if n_lines <= 1 else 2))
            if vals_html:
                lead = f"<div>{lead}</div>"          # 사실 한 줄은 제 줄 — 아래 바뀐 곳 이름과 붙지 않게
                # 근거의 '이번 변경' 머리와 그 아래 예시 줄은 위 두 줄과 같은 값 — 머리 앞 줄만 남긴다('(변경 전후 동일)' 줄은 사실 한 줄에)
                cut = next((k for k, e in enumerate(rest) if e.lstrip().startswith("이번 변경")), len(rest))
                rest = [e for e in rest[:cut] if "(변경 전후 동일)" not in e]
            else:
                # 오늘 변경이 없는 날(유예가 끝난 날) — 근거 줄의 '이번 변경' 머리와 그 다음 한 건을 한 줄로
                pick = [e for e in rest if e.lstrip().startswith("이번 변경")]
                rest = pick + [e for e in rest if e not in pick and "(변경 전후 동일)" not in e]
                if pick and rest[:1] == pick[:1] and rest[0].rstrip().endswith(":") and len(rest) > 1:
                    rest = [f"{rest[0].rstrip()} {rest[1].strip()}"] + rest[2:]
                lead = f"<div>{lead}</div>"          # 사실 한 줄은 제 줄 (L)
    was = (recurred or {}).get((iss.code, iss.path, iss.message))
    n_eff = max(0, n_lines - (1 if (place_line or vals_html) else 0))     # 두 줄 아래 위치 줄·값 덩이가 근거 한 줄 몫
    # 근거 줄 — '바뀐 곳: 이전 → 지금 (위치)' 꼴은 이름표 두 줄로(바뀐 곳 위 · 위치 아래), 나머지는 작은 글(문장 속 화살표는 말로)
    lines = []
    for e in rest[:n_eff]:
        # 바뀐 곳 없는 예시 줄('M-302 MOTOR 3.7kW → M-302 MOTOR 5.5kW (위치)')도 두 줄로 — 첫 낱말이 같으면 그것이 바뀐 곳 (L)
        pr = ev_pair(e, keyless=True)
        if pr and pr[0].startswith("이번 변경"):
            # '이번 변경(2건 중 예시): M-302 MOTOR 3.7kW → M-302 MOTOR 5.5kW' — 머리 말 대신 값의 태그를 바뀐 곳으로(앞머리 떼기)
            pr2 = ev_pair(f"{pr[1]} → {pr[2]}", keyless=True)
            if pr2 and pr2[0]:
                pr = (pr2[0], pr2[1], pr2[2], pr[3])
        if pr:
            lines.append((_m_place_line(f"<b>{_esc(pr[0])}</b>") if pr[0] else '<div style="margin-top:6px"></div>')
                         + _m_pv(_esc(ev_none(pr[1], bool(pr[0]))), _esc(ev_none(pr[2], bool(pr[0])))) + _m_where(_esc(pr[3])))
        else:
            lines.append(_m_sub(_esc(_short(unarrow(e), ev_cut))))
    if len(rest) > n_eff:
        lines.append(_m_sub(f"외 근거 {len(rest) - n_eff}줄"))
    if vals_more:
        lines.append(_m_sub(f"외 {vals_more}곳"))
    if was:
        lines.append(_m_sub(f"다시 생김 · {_esc(_kdate(was))}에 해소됐던 같은 문제"))
    return (_esc(target) if target else ""), lead + _m_where(_esc(place_line)) + vals_html + "".join(lines)


def _m_issues_card(issues, details, *, link: bool, folders: dict | None, recurred: dict | None, n_lines: int,
                   tail: str = "", max_bytes: int | None = None, project: str | None = None) -> str:
    """'확인 필요 N건' 카드 — 문제 · 대상 · 근거 · 파일 (+ 링크형은 줄 끝 '보기 ›'). 종류 순: 도면·BOM > Rev 안 올림 > Rev만 > 그 밖.
    max_bytes(링크형): 줄들이 이 크기를 넘으면 뒤는 '외 N건 — 사내망 확인 필요 목록 ›' 한 줄 — 링크형 큰 날 통이 Gmail 잘림 한도를
    넘어 꼬리(확인 방법 안내)가 잘렸다 (검토 Y3 M2). 링크형의 같은 종류 15줄 넘침도 같은 한 줄로(감시 PC가 아니라 사내망 목록)."""
    from watcher.summary import _ISSUE_ORDER
    order = sorted(issues, key=lambda i: _ISSUE_ORDER.get(i.code, 9))
    per = Counter(i.code for i in order)
    shown_n: dict = {}
    rows = []
    used, cut = 0, 0
    for iss in order:
        if per[iss.code] >= 5 and iss.code in _M_MANY:
            shown_n[iss.code] = shown_n.get(iss.code, 0) + 1
            if shown_n[iss.code] > 15:
                continue
        if max_bytes is not None and rows and used > max_bytes:
            cut += 1
            continue
        lab, color, _st = _m_issue_kind(iss.code)
        target, ev = _m_issue_cells(iss, (details or {}).get(iss.path, []), n_lines, recurred)
        name = _name_tail(iss.path, folders)
        target = target or _esc(PurePosixPath(iss.path).stem or name)
        url = lan_url(issue_path=iss.path) if link else ""
        cells = [_m_td(_mtag(color, lab), extra=_M_EDGE_L),
                 _m_td(f"<b>{target}</b>", extra="color:#111827"),
                 _m_td(ev),
                 _m_td(_m_name(name), extra=("" if link else _M_EDGE_R), attrs=' class="dm-h"')]
        if link:
            cells.append(_m_td(_m_go(url), extra=_M_EDGE_R + ";text-align:right"))
        rows.append('<tr valign="top" class="dm-r1">' + "".join(cells) + "</tr>")
        used += len(rows[-1].encode("utf-8"))
    if link:
        more = cut + sum(k - 15 for k in shown_n.values() if k > 15)
        if more:
            from urllib.parse import quote
            href = f"{LAN_BASE}/changes/issues" + (f"?p={quote(str(project), safe='')}" if project else "")
            rows.append(f'<tr><td colspan="5" style="{_M_TD};{_M_EDGE_L};{_M_EDGE_R};font-size:14px;color:#4A5363">'
                        f'<b style="color:#111827">외 {more}건</b> — 사내망 확인 필요 목록에 모두 있습니다 '
                        f'<a href="{_esc(href)}" style="color:#2F3EC2;font-weight:700;text-decoration:none;white-space:nowrap">'
                        f'확인 필요 목록&nbsp;›</a></td></tr>')
    else:
        for code, k in shown_n.items():
            if k > 15:
                rows.append(f'<tr><td colspan="4" style="{_M_TD};{_M_EDGE_L};font-size:14px;color:#4A5363">'
                            f'{_esc(_m_issue_kind(code)[0])} 외 {k - 15}건 — 감시 PC 화면의 확인 필요 목록에 모두 있습니다</td></tr>')
    heads = ([("문제", "width:18%"), ("대상", "width:14%"), ("근거", ""), ("파일", "width:21%")]
             + ([("", "width:7%")] if link else []))
    body = _m_table(heads, rows, hide=(3,), stack=True)
    if tail:
        body += f'<tr><td style="padding:12px 16px;border-top:1px solid #E3E6EC;font-size:14px;color:#4A5363">{tail}</td></tr>'
    return _m_card(_m_card_head("확인 필요", _m_count(len(issues), red=True)), body)


def _m_pair(o, n, group: bool = False) -> tuple:
    """(이전 HTML, 지금 HTML) — 낱말이 셋 넘는 글(사양서 문단)만 바뀐 낱말을 칠한다. 값은 ChangeItem 그대로."""
    so, sn = fmt_val(o, group), fmt_val(n, group)
    if so != "—" and sn != "—" and (len(so.split()) >= 3 or len(sn.split()) >= 3):
        return word_diff_html(o, n, del_attr=_MW_DEL, ins_attr=_MW_INS, group=group)
    return _esc(so), _esc(sn)


def _m_revrow_txt(v) -> str:
    """개정표 행 값 — 설명(DESCRIPTION)이 사람 말이다: '설명, 날짜'."""
    s = fmt_val(v)
    d = re.search(r"(?:DESCRIPTION|DESC\.?|내용|개정 ?내용|개정 ?사유|사유|REMARKS?): ([^·]+)", s)
    dt = re.search(r"\d{4}[-./]\d{1,2}[-./]\d{1,2}", s)
    return (d.group(1).strip() + (f", {dt.group(0)}" if dt else "")) if d else s


def _m_text_cells(i) -> tuple:
    """글줄 변경 → (바뀐 곳, 이전 값, 지금 값) — 태그 줄('M-101 5.5kW' → 'M-101 7.5kW')은 태그를 바뀐 곳으로 한 번만."""
    return _m_text_rows(i)[0]


def _m_text_rows(i) -> list:
    """글줄 변경 → [(바뀐 곳, 이전 값, 지금 값)]. 사양-태그 짝 이름표('M-102: 2.2kW 4P 380V → 5.5kW 4P 380V; M-103: …')가 있으면
    태그마다 한 줄 — 묶인 사양 글줄('3.7kW 4P 380V 2.2kW 4P 380V') 통째로는 어느 태그 값인지 몰랐다 (구매 평가 2차 F2)."""
    key = " ".join(str(i.key or "").split())
    so, sn = " ".join(str(i.old or "").split()), " ".join(str(i.new or "").split())
    # 긴 여러 줄 덩이(300줄 MTEXT)는 줄을 접지 않는다 — 접으면 부르는 쪽의 long_text_window가 바뀐 문단 둘레를 못 골라 덩이 전체가
    # 실렸다(이전/지금 두 줄 2026-11-21 L). 그때는 아래 마지막 줄(원래 값 그대로)로
    _long = max(str(i.old or "").count("\n"), str(i.new or "").count("\n")) >= _LONG_LINES
    if i.kind == "TEXT_CHANGED" and key and not _long and so.startswith(key + " ") and sn.startswith(key + " "):
        return [(key, so[len(key):].strip(), sn[len(key):].strip())]
    lab = pair_label(i)
    parts = [x.partition(": ") for x in lab.split("; ")] if lab else []
    if parts and all(sep and " → " in rest for _t, sep, rest in parts):
        return [(t.strip(), *rest.split(" → ", 1)) for t, _sep, rest in parts]
    if parts and len(parts) == 1 and parts[0][1]:
        return [(parts[0][0].strip(), i.old, i.new)]
    return [(text_key_label(i) or _ITEM_KIND.get(i.kind, (i.kind,))[0], i.old, i.new)]


def _m_note_text(i, path: str) -> str:
    """안내 줄(검사 한계·참고·발주 대조·Rev 올림 일자 그대로) — 메일엔 앞 마디만. 전문은 감시 화면·사내망 상세에."""
    key, nt = str(i.key or ""), str(i.new or "")
    if key == "참고":
        if any(w in nt for w in ("옮겨", "같은 내용의 새 파일", _MOVE_MARK.strip())):
            from dataclasses import asdict
            from watcher.summary import _note_short
            return _note_short([asdict(i)], path) or plain_words(nt)
        segs = plain_words(nt).split(" — ")
        return cut_words(segs[0] + (" — " + re.split(r"\s*[(.]", segs[1])[0].strip() if len(segs) > 1 else ""), 90)
    return notice_text(i)


def _m_item_rows(c, its, info, link: bool = False, split_where: bool = False) -> list:
    """변경 한 건 → 표 줄 재료 [('pair', 바뀐 곳, 이전, 지금, 무게) | ('span', 바뀐 곳, 글, 무게) | ('note', 글)] — 모두 HTML.
    Rev → 내용(상한 _MAIL_ROWS_PER_CHANGE) → 표 행(상한 _DETAIL_CAP) → 표제란 칸·일자 글줄·개정표 → 파일 수준 칸 → 안내 줄.
    링크형은 기록 요약처럼 무게순 앞 _M_LINK_PARTS곳만 펴고 '외 N곳'(근거·전부는 사내망 기록 — 2026-11-17 R4).
    split_where: 바뀐 곳 HTML을 '이름\\x1f위치'로(확인 필요 칸이 위치를 두 줄 아래에 따로 싣는다 — _m_issue_values)."""
    from dataclasses import asdict
    from watcher.diff import field_label, is_rev_field, is_title_date_text
    from watcher.summary import _weight

    def _w(i) -> float:
        try:
            return _weight(asdict(i))
        except Exception:                   # noqa: BLE001
            return 2
    out: list = []
    impact = None
    notices = [i for i in its if i.kind == "CHECK_SKIPPED"]
    trows = [i for i in its if i.kind.startswith("ROW_")]
    rest = [i for i in its if i.kind != "CHECK_SKIPPED" and not i.kind.startswith("ROW_")]
    revs = [i for i in rest if is_rev_field(i)]
    _rv = {id(i) for i in revs}
    fields = [i for i in rest if i.kind == "FIELD_CHANGED" and id(i) not in _rv]
    revrows = [i for i in rest if i.kind.startswith("REVROW_")]
    tdates = [i for i in rest if i.kind.startswith("TEXT_") and is_title_date_text(i)]
    _skip = _rv | {id(i) for i in fields + revrows + tdates}
    content = [i for i in rest if id(i) not in _skip]
    # 줄 짝을 못 지어 '삭제 + 추가'로 갈린 한 변경(같은 짝 이름표)은 추가 쪽 한 줄로 — 이름표에 옛 값이 있다
    _labs = {pair_label(i) for i in content if i.kind == "TEXT_ADDED" and pair_label(i)}
    content = [i for i in content if not (i.kind == "TEXT_REMOVED" and pair_label(i) in _labs)]

    def _join(lab_html: str, w: str) -> str:
        if split_where:
            return lab_html + "\x1f" + (_esc(w) if w else "")
        return lab_html + (_m_sub(_esc(w)) if (w and not link) else "")

    def _place(lab: str, i=None) -> str:
        w = plain_where(i.where) if (i is not None and getattr(i, "where", "")) else ""
        return _join(f'<b>{_esc(lab)}</b>', w)
    for i in revs:
        o, n = _m_pair(i.old, i.new)
        lab = field_label(i.key)
        out.append(("pair", _place("Rev" if lab.upper() == "REV" else lab, i), o, n, _w(i)))
    cap = min(_MAIL_ROWS_PER_CHANGE, _DETAIL_CAP)
    for i in content[:cap]:
        g = not i.kind.startswith(("TEXT_", "FIELD_"))
        if i.kind == "TEXT_CHANGED":
            for lab, o, n in _m_text_rows(i):
                o, n = _m_pair(*long_text_window(o, n), g)
                out.append(("pair", _place(lab, i), o, n, _w(i)))
            continue
        elif i.kind in ("TEXT_ADDED", "TEXT_REMOVED"):
            # 이전/지금 두 줄(2026-11-21): 없던 것은 [이전] 없음, 없어진 것은 [지금] 없음
            lab, o, n = _m_text_cells(i)
            o, n = ("없음", _esc(fmt_val(i.new, g))) if i.kind == "TEXT_ADDED" else (_esc(fmt_val(i.old, g)), "없음")
        elif i.kind in ("PAGE_VISUAL_CHANGED", "EMBED_CHANGED", "PAGE_ADDED", "PAGE_REMOVED", "PAGE_MOVED", "TEXT_MOVED",
                        "COL_ADDED", "COL_REMOVED", "COL_MOVED", "SHEET_ADDED", "SHEET_REMOVED"):
            lab = _ITEM_KIND.get(i.kind, (i.kind,))[0]
            if i.kind == "PAGE_VISUAL_CHANGED":
                lab, what = "그림", f"선·도형 바뀜 ({_esc(plain_where(str(i.key)))})"
            else:
                # 무엇이(열·시트·쪽 이름 = key) + 값이 있으면 그 값 — '열 추가' 줄에 어느 열인지가 없었다 (벤치 basic61 C26)
                key_ = _esc(str(i.key or ""))
                if i.old not in (None, "") and i.new not in (None, ""):
                    # 이전·지금 값이 둘 다 있으면(이름 바뀜 등) 두 줄로 — 화살표 한 줄 대신 (2026-11-21)
                    plab = " ".join(x for x in (lab, str(i.key or "") if key_ and key_ != _esc(lab) else "") if x)
                    out.append(("pair", _place(plab, i), _esc(fmt_val(i.old, False)), _esc(fmt_val(i.new, False)), _w(i)))
                    continue
                vals = "".join(_esc(unarrow(fmt_val(v, False), ev=False)) for v in (i.old, i.new) if v not in (None, ""))
                what = " · ".join(x for x in (key_ if key_ and key_ != _esc(lab) else "", vals) if x) or key_
            out.append(("span", _place(lab, i), f'<span style="color:#4A5363">{what}</span>', _w(i)))
            continue
        else:
            lab = _ITEM_KIND.get(i.kind, (i.kind,))[0] + (f" {i.key}" if i.key else "")
            o, n = _m_pair(i.old, i.new, g)
        out.append(("pair", _place(lab, i), o, n, _w(i)))
    more = max(0, len(content) - cap)
    if trows:
        a, r, ch, _d = bom_impact(trows)
        if (a or r or ch) and not link:
            parts = [x for x in ((f"신규 {a}행" if a else ""), (f"삭제 {r}행" if r else ""), (f"값 변경 {ch}건" if ch else "")) if x]
            impact = ("note", f'<b>{_esc(impact_label(c.path))}</b> · {" · ".join(parts)}')
        for i in trows[:_DETAIL_CAP]:
            rk, sep, col = split_row_cell(i.key)
            head = f"{rk} · {col}" if (sep and i.kind == "ROW_CHANGED" and rk and col) else (rk if sep else str(i.key))
            sub = " · ".join(x for x in (str(getattr(i, "label", "") or ""), plain_where(i.where) if i.where else "") if x)
            lab_r = head if i.kind == "ROW_CHANGED" else f"{head} 행 {'추가' if i.kind == 'ROW_ADDED' else '삭제' if i.kind == 'ROW_REMOVED' else ''}"
            place = _join(f'<b>{_esc(lab_r.strip())}</b>', sub)
            if i.kind == "ROW_CHANGED":
                o = _esc(_group_digits(str(i.old))) if str(i.old or "").strip() else "(빈칸)"
                n = _esc(_group_digits(str(i.new))) if str(i.new or "").strip() else "(빈칸)"
                try:
                    d = float(i.new) - float(i.old)
                    n += (f' <span style="font-weight:400;color:#4A5363;white-space:nowrap">({"+" if d > 0 else ""}'
                          f'{delta_num(d)})</span>' if d else "")
                except (TypeError, ValueError):
                    pass
            elif i.kind == "ROW_ADDED":
                o, n = "없음", _esc(row_dot(i.new))
            elif i.kind == "ROW_REMOVED":
                o, n = _esc(row_dot(i.old)), "없음"
            else:                                   # ROW_MOVED — 순서만
                out.append(("span", place, f'<span style="color:#4A5363">행 순서 {_esc(str(i.new or ""))}</span>', 3))
                continue
            out.append(("pair", place, o, n, _w(i)))
        more += max(0, len(trows) - _DETAIL_CAP)
    if tdates:
        ex = next((i for i in tdates if i.kind == "TEXT_CHANGED"), tdates[0])
        o, n = _m_pair(ex.old, ex.new)
        out.append(("pair", _place(f"일자 글줄 {len(tdates)}곳" if len(tdates) > 1 else "일자 글줄", ex), o, n, 3))
    file_f = [i for i in fields if str(i.key or "") in FILE_LEVEL_KEYS]
    for i in [i for i in fields if i not in file_f] + file_f:
        o, n = _m_pair(i.old, i.new)
        out.append(("pair", _place(field_label(i.key) if i not in file_f else str(i.key), i), o, n, _w(i)))
    for i in revrows:
        if link and revs and i.kind == "REVROW_ADDED":
            continue                        # 기록 요약과 같이 — Rev 올림이 있으면 새 개정표 행은 그 Rev의 행이다(summary._part)
        # '개정표 행 추가 B' — 무슨 일(추가·삭제·변경)인지를 바뀐 곳 칸에 (옛 메일의 '표제란·개정표: 개정표 행 추가 B (…)'와 같은 말)
        verb = {"REVROW_ADDED": "추가", "REVROW_REMOVED": "삭제"}.get(i.kind, "변경")
        lab = f"개정표 행 {verb} {text_key_label(i)}"
        if i.kind == "REVROW_ADDED":
            o, n = "없음", _esc(cut_words(_m_revrow_txt(i.new), 80))
        elif i.kind == "REVROW_REMOVED":
            o, n = _esc(cut_words(fmt_val(i.old), 80)), "없음"
        else:
            o, n = _m_pair(i.old, i.new)
        out.append(("pair", _place(lab, i), o, n, 2.2))
    if link:
        vals = [x for x in out if x[0] != "note"]
        # Rev 올림은 늘 앞 3곳 안에 — 무게순만 보면 값 변경 셋에 밀려 '외 2곳'으로 숨었다 (검토 X L6). Rev 줄은 out 맨 앞 len(revs)개
        keep = sorted(range(len(vals)), key=lambda k: (0 if k < len(revs) else 1, vals[k][-1]))[:_M_LINK_PARTS]
        more += len(vals) - len(keep)
        out = [vals[k] for k in sorted(keep)]
        if more:
            out.append(("note", f"외 {more}곳 — 기록에 모두 있습니다"))
        return out
    if impact:
        out.append(impact)
    if more:
        out.append(("note", f"외 {more}건 — 감시 PC 화면의 변경 상세에 모두 있습니다"))
    # 안내 줄 — 발주 대조 표지(앞 PO_MAIL_MARKS줄, 나머지는 수만 — ux25 E1)·Rev 올림·일자 그대로·참고·검사 한계
    _po = [i for i in notices if _is_po_mark(i) and not _PO_MARK_MORE.match(str(i.new or ""))]
    _po_cut = {id(i) for i in _po[PO_MAIL_MARKS:]}
    _po_more = len(_po_cut)
    for i in notices:
        if id(i) in _po_cut:
            if _po_more:
                out.append(("note", f"<b>{_esc(PO_MARK_LABEL)}</b> 외 {_po_more}건 — 변경 상세에 모두 있습니다"))
                _po_more = 0
            continue
        key = str(i.key or "")
        lab = PO_MARK_LABEL if _is_po_mark(i) else "일자 그대로" if key == REV_DATE_NOTICE else key
        out.append(("note", f'<b>{_esc(lab)}</b> · {_esc(unarrow(_m_note_text(i, c.path)))}'))
    if info and info.get("note") and not any(i.kind == "REVROW_ADDED" for i in its):
        out.append(("note", f'<b>개정 사유</b> · {_esc(info["note"])}'))
    if any("OCR" in str(getattr(i, "where", "") or "") for i in its):
        out.append(("note", "<b>OCR 추정값</b> · 그림에서 읽은 글자라 O/0·I/1이 틀릴 수 있습니다. 원본을 열어 확인하세요."))
    return out


def _m_doc_kind(path: str) -> str:
    from watcher.summary import _kind_tag
    return _kind_tag(path)


def _m_status(c, its, issues, acked_by) -> str:
    """'상태' 칸 — 확인 필요 표시(빨강·노랑)와 확인함(초록)만. 종류(회색)는 '문서' 칸에.
    이름은 위 '확인 필요' 표의 문제 칸과 같은 짧은 이름(consistency.short_label) — 한 통 안에서 같은 문제가 '도면·BOM 다름'과
    'BOM과 다름' 두 이름으로 보였다 (검토 X L3). 어느 종류를 싣나는 _M_STATUS 그대로."""
    tags = []
    for iss in issues or ():
        if iss.path == c.path or any(c.path and c.path in str(e) for e in (iss.evidence or ())):
            lab, color, st = _m_issue_kind(iss.code)
            if st and color in ("red", "amber") and (color, lab) not in tags:
                tags.append((color, lab))
    if any(getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == REV_DATE_NOTICE for i in its):
        tags.append(("amber", "일자 그대로"))
    if any(_is_po_mark(i) for i in its) and ("red", "발주 후 변경") not in tags:
        tags.append(("red", "발주 후 변경"))
    done = (acked_by or {}).get(c.id) if c.id else None
    if done:
        tags.append(("green", f"확인함 · {done}"))
    tags.sort(key=lambda t: {"red": 0, "amber": 1}.get(t[0], 2))
    return "<br>".join(_mtag(col, t, wrap=True) for col, t in tags)


def _m_file_meta(c, info, doc: str) -> str:
    """변경 첫 줄의 '바뀐 곳' 칸 맨 아래 한 줄 — 문서 종류(회색 표시) · 도면번호 Rev · 폴더 · 저장 시각·저장자 (시안 ④에는 없는 칸이던
    파일 칸의 덧말을 옮긴 것 — 2026-11-21)."""
    p = PurePosixPath(c.path)
    bits = []
    if info and info.get("dwg") and _short_no(info["dwg"], None) != p.stem:
        # 문서 종류는 앞 표시에 있다 — '도면 도면 P-E-002'처럼 겹치지 않게 번호 앞말(num_prefix)은 뺀다
        bits.append(f'{_esc(info["dwg"])}' + (f' Rev {_esc(info["rev"])}' if info.get("rev") else ""))
    elif info and info.get("rev"):
        bits.append(f'Rev {_esc(info["rev"])}')
    if info and info.get("folder"):
        bits.append(f'{_esc(info["folder"])} 폴더')
    if info and info.get("mtime"):
        try:
            bits.append(f'<span style="white-space:nowrap">저장 {saved_stamp(info["mtime"])}</span>'
                        + (f" · {_esc(info['who'])}" if info.get("who") else ""))
        except (TypeError, ValueError, OSError, OverflowError):
            pass
    return (f'<div style="{_M_SUB};margin-top:4px">{_mtag("gray", doc)}'
            + (" " + " · ".join(bits) if bits else "") + "</div>")


def _m_file_cell(c, info, url: str = "") -> str:
    p = PurePosixPath(c.path)
    subs = []
    if info and info.get("dwg") and _short_no(info["dwg"], None) != p.stem:
        subs.append(f'{num_prefix(c.path)}{_esc(info["dwg"])}' + (f' Rev {_esc(info["rev"])}' if info.get("rev") else ""))
    elif info and info.get("rev"):
        subs.append(f'Rev {_esc(info["rev"])}')
    if info and info.get("folder"):
        subs.append(f'{_esc(info["folder"])} 폴더')
    if info and info.get("mtime"):
        try:
            subs.append(f'<span style="white-space:nowrap">저장 {saved_stamp(info["mtime"])}</span>'
                        + (f" · {_esc(info['who'])}" if info.get("who") else ""))
        except (TypeError, ValueError, OSError, OverflowError):
            pass
    return _m_name(p.name) + "".join(_m_sub(s) for s in subs)


def _m_ack_go(c, ack_base, ack_tokens, link: bool) -> str:
    """줄 끝 칸 — 링크형은 사내망 기록 '보기 ›', 근거형은 회신에 적을 #번호(감시 PC 주소) 또는 [확인했음 기록](사내 주소)."""
    if link:
        return _m_go(lan_url(c.id)) if c.id else ""
    if not (ACK_ON.get() and c.id):
        return ""
    token = (ack_tokens or {}).get(c.id)
    if not (ack_base and token):
        return ""
    if _loopback(ack_base):
        return f'<span style="font-size:13.5px;color:#4A5363;white-space:nowrap">#{c.id}</span>'
    return _m_go(f"{ack_base}/ack?id={c.id}&t={token}", "확인했음 기록")


def _m_change_rows(sub: list, *, fname: str, meta: str, status: str, go: str, go_col: bool) -> list:
    """변경 한 건의 <tr>들 — 시안 ④ 꼴(2026-11-21): '바뀐 곳' 칸 = 바뀐 곳 굵게 + 아래 작은 글 '파일 · 위치'(첫 줄은 그 아래 문서 종류·
    Rev·저장 한 줄), 가운데 '이전 / 지금' 칸 = 이름표 두 줄, 오른쪽 상태·끝 칸은 첫 줄 옆에 한 번(rowspan). 같은 변경의 둘째 항목부터는
    옅은 점선(덩이 사이 10px). 안내 줄(참고·발주 대조·외 N건)은 값 줄 아래 표 폭 전체.
    sub의 바뀐 곳 HTML은 '이름\\x1f위치'(_m_item_rows split_where) 또는 이름만. fname은 이스케이프된 파일 이름."""
    vals = [x for x in sub if x[0] != "note"] or [x for x in sub if x[0] == "note"][:1] or [("note", "—")]
    notes = [x for x in sub if x[0] == "note" and x not in vals]
    rv = f' rowspan="{len(vals)}"' if len(vals) > 1 else ""
    if go_col:
        right = _m_td(status, attrs=rv) + _m_td(go, extra=_M_EDGE_R + ";text-align:right", attrs=rv)
    else:
        right = _m_td(status, extra=_M_EDGE_R, attrs=rv)
    ncols = 4 if go_col else 3
    trs = []
    for k, it in enumerate(vals):
        first = k == 0
        dash = "" if first else "padding-top:10px;border-top:1px dashed #E3E6EC"     # 덩이 사이 옅은 점선 (규칙 3)
        if it[0] in ("pair", "span"):
            lab, _s, where = str(it[1]).partition("\x1f")
            key = (f'<div style="color:#111827">{lab}</div>'
                   + f'<div style="{_M_SUB};overflow-wrap:anywhere">{" · ".join(x for x in (fname, where) if x)}</div>' + (meta if first else ""))
            val = _m_pv(it[2], f"{it[3]}") if it[0] == "pair" else it[2]
            mid = (_m_td(key, first, ";".join(x for x in (_M_EDGE_L, dash) if x))
                   + _m_td(val, first, dash))
        else:
            mid = _m_td(f'{it[1]}' + _m_sub(fname) + (meta if first else ""), first,
                        ";".join(x for x in (_M_SUB, _M_EDGE_L, dash) if x), attrs=' colspan="2"')
        # dm-r1 = 변경 한 건의 첫 줄, dm-r2 = 같은 변경의 다음 항목 — 폰 폭에서 줄 쌓기(dm-s)가 실선·점선으로 나눈다
        trs.append(f'<tr valign="top" class="{"dm-r1" if first else "dm-r2"}">' + mid + (right if first else "") + "</tr>")
    for it in notes:
        trs.append("<tr>" + _m_td(it[1], False, f"{_M_SUB};{_M_EDGE_L};{_M_EDGE_R}", attrs=f' colspan="{ncols}"') + "</tr>")
    return trs


# 시안 ④ (2026-11-21): 바뀐 곳 | 이전 / 지금 | 상태 — 파일·위치는 바뀐 곳 아래 작은 글. 이전/지금 칸이 가장 넓다
_M_CHG_HEADS = [("바뀐 곳", "width:28%"), ("이전 / 지금", ""), ("상태", "width:20%")]


def _m_photo(cap: dict, budget, title: str) -> str:
    """전/후 사진 한 쌍 — 표 아래 두 칸(이전 | 지금). 표식(<!--drev-photo-->)은 메일 설정 images: false가 글 한 줄로 바꾸는 자리
    (mail.mail_view). 사진 총량(PhotoBudget)을 넘으면 사진 대신 글 한 줄. alt에 위치 설명(그림을 막은 메일 앱용)."""
    after = cap.get("after") if ("after" in cap or "before" in cap) else cap
    before = cap.get("before")
    if after is None and not before:
        return ""
    if budget is not None and not budget.take(_cap_bytes({"before": before, "after": after})):
        where = (after or before or {}).get("caption", "")
        return (f'<!--drev-photo--><div style="padding:10px 16px;border-top:1px solid #E3E6EC;font-size:13.5px;color:#4A5363">'
                f'{_esc(title)} — 전/후 사진 생략: 이 메일의 사진 용량 상한을 넘었습니다'
                f'{(" (" + _esc(plain_where(str(where))) + ")") if where else ""}. '
                f'감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div><!--/drev-photo-->')
    both = bool(before and after)
    w = 296 if both else 612

    def _one(x, lab, pad):
        return (f'<td valign="top" width="{"50%" if both else "100%"}" style="padding:{pad}">'
                f'<div style="font-size:13.5px;font-weight:700;color:#4A5363;margin:0 0 4px">{_esc(lab)}</div>'
                f'<img src="data:{x["mime"]};base64,{x["b64"]}" width="{w}" '
                f'alt="{_esc(lab)} — {_esc(plain_where(x.get("caption", "")))}" '
                f'style="width:100%;max-width:{w}px;height:auto;border:1px solid #E3E6EC;border-radius:8px;display:block"></td>')
    if both:
        cells = _one(before, "이전", "0 6px 14px 16px") + _one(after, "지금", "0 16px 14px 6px")
    elif after:
        added = "이전 판에 없음" in str(after.get("caption", ""))
        cells = _one(after, "지금 (이전 판에 없던 페이지)" if added else "지금", "0 16px 14px")
    else:
        cells = _one(before, "이전 (이 페이지는 새 판에 없음)", "0 16px 14px")
    return ('<!--drev-photo--><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            'style="width:100%">'
            f'<tr><td colspan="2" style="padding:12px 16px 8px;font-size:15px;font-weight:700;color:#111827;'
            f'border-top:1px solid #E3E6EC">{_esc(title)}</td></tr><tr>{cells}</tr></table><!--/drev-photo-->')


def _m_head_band(left: str, right: str) -> str:
    """머리 띠 — Drev 표지 + 프로젝트(또는 묶음) + 날짜. 표지 글자 'D'는 평문에 싣지 않는다(drev-nt)."""
    return ('<!--drev-head--><tr><td style="padding:0 0 16px">' + _M_CARD
            + '<tr class="dm-band"><td style="padding:14px 18px;vertical-align:middle">'
            '<!--drev-nt--><span style="display:inline-block;width:26px;height:26px;line-height:26px;text-align:center;'
            'background:#3A4BDB;color:#FFFFFF;border-radius:7px;font-weight:800;font-size:15px;vertical-align:middle">D</span>'
            '&nbsp;<!--/drev-nt-->'
            f'<span style="font-size:18px;font-weight:800;color:#111827;vertical-align:middle">Drev</span>{left}</td>'
            f'<td align="right" style="padding:14px 18px;vertical-align:middle;font-size:14.5px;color:#4A5363">'
            f'{right}</td></tr></table></td></tr><!--/drev-head-->')


def _m_band_title(text: str) -> str:
    return (f'<span style="font-size:18px;color:#CDD2DC;vertical-align:middle"> &nbsp;·&nbsp; </span>'
            f'<span style="font-size:18px;font-weight:800;color:#111827;vertical-align:middle">{_esc(text)}</span>')


_WD_KO = "월화수목금토일"


def _m_when(run_at: datetime) -> str:
    return f"{run_at.year}년 {run_at.month}월 {run_at.day}일 ({_WD_KO[run_at.weekday()]}) {run_at:%H:%M}"


def shared_more(n_sh: int) -> str:
    """확인 필요 수 옆 덧붙임 — '+ 공용 폴더 N건' (공용 폴더의 확인 필요는 이 통 맨 아래 공용 칸에 실린다)."""
    return f"+ {SHARED_ONLY_LABEL} {int(n_sh)}건" if n_sh else ""


def _m_summary(n_iss: int, n_chg: int, extras: list, head_txt: str, zero: str = "", n_sh: int = 0) -> str:
    """요약 카드 — 확인 필요 N건 · 바뀐 파일 N개(숫자 크게) + 덧붙임 수 + 머리 한 줄(사장·구매용, mail_headline).
    n_sh: 이 통 맨 아래 공용 칸의 확인 필요 — 큰 수(이 프로젝트 것 = 바로 아래 확인 필요 표의 수)에 섞지 않고 옆에 '+ 공용 폴더 N건'.
    한 화면에 제목 6 · 띠 5 · 표 4로 수가 셋이었다 (검토 Y3 L5)."""
    def _cell(lab, n, unit, red, edge, more=""):
        col = "#C8281E" if red else "#111827"
        return (f'<td width="50%" style="padding:14px 18px 12px;vertical-align:bottom;{edge}">'
                f'<span style="font-size:15px;font-weight:700;color:#4A5363">{lab}</span>&nbsp;&nbsp;'
                f'<span class="dm-num" style="font-size:30px;font-weight:800;line-height:1.1;color:{col}">{n}</span>'
                f'<span style="font-size:15px;font-weight:700;color:#2B3341">{unit}</span>'
                + (f'&nbsp;<span style="font-size:14px;font-weight:700;color:#4A5363;white-space:nowrap">{_esc(more)}</span>'
                   if more else "") + '</td>')
    rows = ("<tr>" + _cell("확인 필요", n_iss, "건", n_iss > 0, "", shared_more(n_sh))
            + _cell("바뀐 파일", n_chg, "개", False, "border-left:1px solid #E3E6EC") + "</tr>")
    if extras:
        rows += (f'<tr><td colspan="2" style="padding:0 18px 12px;font-size:14px;color:#4A5363">'
                 f'{" · ".join(_esc(x) for x in extras)}</td></tr>')
    if head_txt:
        rows += (f'<tr><td colspan="2" style="padding:12px 18px 14px;border-top:1px solid #E3E6EC;font-size:16px;'
                 f'font-weight:700;line-height:1.5;color:#111827">{_esc(head_txt)}</td></tr>')
    if zero:
        rows += f'<tr><td colspan="2" style="padding:12px 18px 14px;border-top:1px solid #E3E6EC">{zero}</td></tr>'
    return _m_row(f"{_M_CARD}{rows}</table>")


def _m_foot(date_str: str, root: str, scanned_note: str, since_note: str, merged_note: str | None, top: str) -> str:
    """맨 아래 작은 글 — 검사 시각·감시 폴더 한 줄, 합친 안내, 회신·사내망 안내 한 줄, 꼬리말(받는 사람 바꾸는 곳).
    표식은 하루 묶음(digest_brief)이 맨 아래 한 번으로 모으는 자리."""
    st = "padding:2px 4px 6px;font-size:13px;line-height:1.6;color:#4A5363"
    out = (f'<!--drev-stamp--><tr><td style="{st}">{_esc(date_str)} 기준 · 감시 폴더: '
           f'<span title="{_esc(root)}">{_esc(_short_roots(root))}</span>{_esc(scanned_note)}{_esc(since_note)}</td></tr>'
           '<!--/drev-stamp-->')
    if merged_note:
        out += f'<tr><td style="{st}">{_esc(merged_note)}</td></tr>'
    if top:
        out += f'<!--drev-top--><tr><td style="{st}">{top}</td></tr><!--/drev-top-->'
    out += (f'<!--drev-foot--><tr><td style="{st}">Drev — 읽기 전용 감시. 변경 \'사실\'의 기록이며 내용 판단은 담당자가 합니다.'
            f'{RECIPIENT_LINE}</td></tr><!--/drev-foot-->')
    return out


def _mail_doc(band: str, rows: str, date_str: str, count: tuple = (0, 0)) -> str:
    """메일 한 통의 틀 — 회색 바탕 + 가운데 680 폭. 표식(drev-mail3·drev-rows·drev-count)은 하루 묶음이 섹션을 떼어 가는 자리.
    count: (이 프로젝트 확인 필요, 바뀐 파일[, 이 통에 실은 공용 폴더 확인 필요])."""
    sh = int(count[2]) if len(count) > 2 else 0
    return f"""<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>산출물 변경 브리핑 {_esc(date_str)}</title>
<style>{_MAIL_CSS}</style></head>
<body bgcolor="#F4F5F7" style="margin:0;padding:0;background:#F4F5F7;color:#111827;font-family:{_MC_FONT};word-break:keep-all;overflow-wrap:anywhere">
<!--drev-mail3--><!--drev-count iss={int(count[0])} chg={int(count[1])}{f" sh={sh}" if sh else ""}-->
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#F4F5F7" style="width:100%;background:#F4F5F7">
<tr><td align="center" class="dm-wrap" style="padding:24px 12px">
<table role="presentation" width="680" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:680px;font-family:{_MC_FONT};text-align:left">
{band}
<!--drev-rows-->
{rows}
<!--/drev-rows-->
</table>
</td></tr></table>
</body>
</html>
"""


def _m_quiet_rows(quiet, moved, details, details_by_id, ncols: int, extra: int = 0) -> list:
    """그 밖의 알림(이동·복사본·재저장…) — 표 끝에 종류별 한 줄. 파일 이름은 하나도 빠지지 않는다(원칙 5). 폴더째 옮긴 셋 이상은
    '폴더 B (이전 A) (파일 N개)' 한 줄 (파일럿 모의 ⑩). extra: 이 머리 아래 따로 싣는 '다시 저장만 된 파일' 수 — 머리 수에 함께 센다
    (머리는 '1건'인데 아래 줄이 둘이고 콘솔은 '2건'이었다 — 검토 X L4)."""
    if not quiet and not extra:
        return []
    st = f"{_M_EDGE_L};{_M_EDGE_R};font-size:14px;color:#4A5363;background:#F8F9FB"
    head = [f'<tr><td colspan="{ncols}" style="{_M_TD};{st}"><b>그 밖의 알림 {len(quiet) + extra}건</b>'
            f' · 확인할 필요 없는 변경</td></tr>']
    if not quiet:
        return head
    pair_of = {}
    for c in quiet:
        if id(c) in moved:
            op = PurePosixPath(moved[id(c)]).parent.parts
            npn = PurePosixPath(c.path).parent.parts
            k = 0
            while k < min(len(op), len(npn)) and op[-1 - k] == npn[-1 - k]:
                k += 1
            if k > 0:
                k -= 1
            pair_of[id(c)] = ("/".join(op[:len(op) - k]) or ".", "/".join(npn[:len(npn) - k]) or ".")
    pair_n = Counter(pair_of.values())
    groups: dict = {}
    folded: list = []
    for c in quiet:
        pr = pair_of.get(id(c))
        if pr and pr[0] != pr[1] and pair_n[pr] >= 3:
            if pr not in folded:
                folded.append(pr)
            continue
        if id(c) in moved:
            groups.setdefault("이동·이름 변경 (내용 동일)", []).append(
                f"{PurePosixPath(c.path).name} (이전: {PurePosixPath(moved[id(c)]).name})")
        else:
            groups.setdefault(quiet_group(note_of(items_for(c, details, details_by_id))), []).append(PurePosixPath(c.path).name)
    rows = head
    for pr in folded:
        # 이전/지금(2026-11-21): 화살표 대신 '지금 폴더 (이전 폴더)'
        rows.append(f'<tr><td colspan="{ncols}" style="{_M_TD2};{st}">이동 · 폴더 <b>{_esc(pr[1])}</b> (이전 <b>{_esc(pr[0])}</b>) '
                    f'(파일 {pair_n[pr]}개 — 이름·위치만 바뀜, 내용 동일)</td></tr>')
    for lab, names in groups.items():
        shown = ", ".join(names[:12]) + (f" 외 {len(names) - 12}개" if len(names) > 12 else "")
        rows.append(f'<tr><td colspan="{ncols}" style="{_M_TD2};{st}"><b>{_esc(lab)} {len(names)}건</b>: '
                    f'{_esc(shown)}</td></tr>')
    return rows


def _m_resaved_rows(resaved, uncompared, ncols: int, link: bool) -> list:
    """다시 저장만 된 파일 — 메일에서 뺀 재저장도 이름은 한 줄 남긴다(검토69 B M6~M8, 원칙 5). 줄마다 따로(벤치 하네스가 이 줄을 뺀다)."""
    out = []
    for lst, why in ((resaved, "글자·표·그림 비교상 같음" + ("" if link else " — 상세는 감시 PC 화면")),
                     (uncompared, "글자·표는 같음 — 그림·개체는 비교하지 못함: 그림만 바뀌었을 수 있으니 파일을 열어 확인하세요")):
        if lst:
            names = [PurePosixPath(c.path).name for c in lst]
            shown = ", ".join(names[:10]) + (f" 외 {len(names) - 10}건" if len(names) > 10 else "")
            out.append(f'<tr><td colspan="{ncols}" style="{_M_TD};{_M_EDGE_L};{_M_EDGE_R};font-size:14px;color:#4A5363;'
                       f'background:#F8F9FB">{RESAVED_MAIL_LINE} {len(names)}건 ({why}): {_esc(shown)}</td></tr>')
    return out


def _m_lists(items: list, cap: int) -> list:
    return list(items[:cap]) + ([f"외 {len(items) - cap}건"] if len(items) > cap else [])


def _m_extra_boxes(*, scan_errors, rejudged, continued, still_open, resolved, clock_note, alias_note, gap_note,
                   rollback_note, wipe_txt) -> tuple:
    """(위 알림 묶음, 아래 덧붙임 묶음) — 시계·별칭·공백·되돌림·폴더 통째 삭제·읽지 못한 파일·보류·다시 판정은 위에 한 줄씩,
    이어진 검토·아직 열린 불일치(지금 근거)·해소된 것은 확인 필요 카드 아래에. 안전 경고는 지우지 않고 한 줄로(시안 ds-alert)."""
    from watcher.consistency import CODE_LABEL
    top = ""
    for kind, t, x in (("bad", "PC 시계 확인", clock_note), ("warn", "별칭 사전", alias_note),
                       ("warn", "검사 공백", None if clock_note else gap_note), ("bad", "옛 판으로 되돌아간 날", rollback_note),
                       ("bad", "폴더 삭제", wipe_txt)):
        if x:
            top += _m_box(kind, f"<b>{_esc(t)}</b> · {_esc(x)}")
    if scan_errors:
        holds, errs = split_hold_notes(scan_errors)
        if holds:
            n = hold_file_count(holds)
            top += _m_box("bad", f"<b>{f'파일 {n}개가 한꺼번에 사라져' if n else '파일이 한꺼번에 사라져'} 삭제 알림 보류 중</b> · "
                                 "서버 연결이 끊긴 것일 수 있어 아직 삭제로 기록하지 않았습니다. 정말 지운 것이면 감시 PC 화면에서 "
                                 "[삭제로 기록]을 누르세요",
                          [f"{_esc(_hold_label(p))} — {_esc(e)}" for p, e in holds])
        if errs:
            rows = scan_error_rows(errs)
            lines = [f"{_esc(p)} — {_esc(e)}" for p, e in rows[:_SCAN_ERR_MAX]]
            if len(rows) > _SCAN_ERR_MAX:
                lines.append(f"외 {len(rows) - _SCAN_ERR_MAX}건 — 감시 PC의 watcher.log에 전부 남아 있습니다")
            what = "폴더·파일" if any(str(p).endswith("/") for p, _ in errs) else "파일"
            top += _m_box("warn", f"<b>읽지 못한 {what} {len(errs)}건</b> · 잠김·권한·연결 문제로 이번에 확인하지 못했습니다. "
                                  "다음 성공 시 변경 감지가 재개됩니다", lines)
    if rejudged:
        top += _m_box("info", f"<b>{REJUDGED_HEAD} {len(rejudged)}건</b> · 파일 변경 아님 — 판정 규칙이 바뀌어 다시 본 결과",
                      _m_lists([f"{_esc(CODE_LABEL.get(i.code, i.code))}: {_esc(_short(unarrow(_iss_card_text(i)[0]), 140))}"
                                for i in rejudged], 30))
    low = ""
    if continued:
        lines = []
        for path, code, _proj, since in continued:
            try:
                d = datetime.fromisoformat(str(since)).astimezone().strftime("%m-%d")
            except (TypeError, ValueError):
                d = "앞서"
            lines.append(f"{_esc(PurePosixPath(path).name)} — {_esc(CODE_LABEL.get(code, code))} ({_esc(d)}부터 열림) — 오늘 또 바뀜")
        low += _m_box("warn", f"<b>이어진 검토 {len(continued)}건</b> · 열려 있던 경고의 파일이 오늘 또 바뀌었습니다",
                      _m_lists(lines, 8))
    if still_open:
        lines = [f"<b>{_esc(CODE_LABEL.get(code, code))}</b> — {_esc(msg)} ({_esc(_kdate(since))}부터 열림)"
                 + "".join(f"<br>{_esc(unarrow(short_paths(human_ev(e))))}" for e in ev)
                 for _proj, code, msg, ev, since in still_open[:6]]
        if len(still_open) > 6:
            lines.append(f"외 {len(still_open) - 6}건")
        low += _m_box("bad", f"<b>관련 파일이 바뀌었지만 아직 열린 불일치 {len(still_open)}건</b> · 지금 근거:", lines)
    if resolved:
        def _why(d):
            w = str(d.get("resolved_by") or "")
            w = w.split("자동 해소 — ", 1)[1] if w.startswith("자동 해소 — ") else ""
            return "" if (not w or w.startswith("다시 검사했을 때")) else f" ({_esc(w)})"
        low += _m_box("ok", f"<b>해소된 확인 필요 {len(resolved)}건</b> · 다시 검사했을 때 더 이상 나오지 않습니다",
                      _m_lists([f"{_esc(CODE_LABEL.get(d['code'], d['code']))} — {_esc(PurePosixPath(d['path']).name)}{_why(d)}"
                                for d in resolved], 5))
    return top, low


def _mail_brief(main, quiet, moved, resaved, uncompared, run_at, root, *, details, details_by_id, issues, project, doc_info,
                scanned_note, since_note, merged_note, scan_errors, errors_above, clock_note, gap_note, alias_note,
                rollback_note, rejudged, continued, still_open, open_backlog, resolved, wiped_folders, ordered_tags,
                summaries, shared, acked_by, shared_issues, captures, budget, ack_base, ack_tokens, recurred) -> str:
    """메일 3판 — 근거형·링크형 한 틀(2026-11-20). 링크형(사내망 기록 열람 주소 LAN_BASE가 있음)은 변경마다 기록 요약과 같은 앞 3곳 +
    줄 끝 '보기 ›' + 기록 버튼, 사진은 선·도형만 바뀐 변경에만(V3-3). 근거형은 근거(구/신/위치)와 전/후 사진을 메일 안에(원칙 4)."""
    link = bool(LAN_BASE)
    date_str = run_at.strftime("%Y-%m-%d %H:%M")
    n = len(main)
    folders = _folders_of(doc_info)

    def info_of(c):
        return (doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)
    _n_sh = len(shared_issues or ()) if shared else 0       # 공용 폴더의 확인 필요도 머리 수에 (V3-8)
    # 요약 카드의 큰 수 = 이 프로젝트 확인 필요(아래 표의 수), 공용 폴더 것은 옆에 '+ 공용 폴더 N건' — 제목은 둘의 합 (검토 Y3 L5)
    _n_rd = rev_date_count(main, details, details_by_id)
    # 머리 한 줄은 '60AT(이전 50AT)'처럼 — 화살표 한 줄('50→60AT')이 읽기 어렵다는 사용자 말 (2026-11-21). 제목·디스크 브리핑은 그대로
    head_txt = mail_headline(main, issues, details, doc_info, details_by_id, project, ordered_tags, was=True)[0]
    head_txt = "확인 필요".join(str(head_txt or "").split("검토 필요"))
    wipe_txt = wiped_line(wiped_folders)
    if wipe_txt and not head_txt:
        head_txt, wipe_txt = wipe_txt, ""
    extras = []
    if _n_rd:
        extras.append(f"Rev 올림·일자 그대로 {_n_rd}건")
    n_other = len(quiet) + len(resaved or ()) + len(uncompared or ())     # 아래 '그 밖의 알림' 머리·콘솔과 같은 수 (검토 X L4)
    if n_other:
        extras.append(f"그 밖의 알림 {n_other}건")
    zero = ""
    if not main and not quiet and not resaved and not uncompared and not issues:
        _h, _e = split_hold_notes(list(scan_errors or ()) + list(errors_above or ()))
        if _h or _e:
            _what = " · ".join(x for x in (("삭제 알림 보류" if _h else ""), ("읽지 못한 폴더·파일 알림" if _e else "")) if x)
            zero = (f'<span style="font-size:15px;color:#5C3B00">변경된 산출물이 없습니다 — 다만 {_what}을 확인하세요'
                    f'{_esc(scanned_note)}.</span>')
        else:
            zero = (f'<span style="font-size:15px;color:#0A5530">변경된 산출물이 없습니다 — 감시는 정상 동작 중입니다'
                    f'{_esc(scanned_note)}.</span>')
    # 회신·사내망 안내 한 줄은 맨 아래 작은 글로 (설명 문단 줄이기)
    if link and (main or issues):
        top = LAN_ACK_LINE if ACK_ON.get() else LAN_VIEW_LINE
    elif (main or issues) and (not ack_base or _loopback(ack_base)) and ACK_ON.get():
        top = REPLY_LINE
    else:
        top = ""
    boxes_top, boxes_low = _m_extra_boxes(scan_errors=scan_errors, rejudged=rejudged, continued=continued,
                                          still_open=still_open, resolved=resolved, clock_note=clock_note,
                                          alias_note=alias_note, gap_note=gap_note, rollback_note=rollback_note,
                                          wipe_txt=wipe_txt)

    # ── 확인 필요 카드 (+ 이 메일 밖에 열려 있는 누적 수 — 검토36 B 3·검토37 B 중간 1) ──
    backlog = ""
    if open_backlog and open_backlog[0] > len(issues):
        from urllib.parse import quote
        nb, days = open_backlog
        whose = "이 프로젝트의 " if project else ""
        age = f" · 가장 오래된 것 {days}일째" if 1 <= days <= 7 and not clock_note else ""
        if link:
            href = f"{LAN_BASE}/changes/issues" + (f"?p={quote(str(project), safe='')}" if project else "")
            where = f'<a href="{_esc(href)}" style="color:#2F3EC2;font-weight:700;text-decoration:none">사내망에서 모두 보기 ›</a>'
        elif ack_base and not _loopback(ack_base):
            href = f"{ack_base}/issues" + (f"?p={quote(str(project))}" if project else "")
            where = (f'<a href="{_esc(href)}" style="color:#2F3EC2;font-weight:700;text-decoration:none">감시 PC 화면의 확인 필요 '
                     f'목록</a>에서 봅니다')
        else:
            where = "감시 PC 화면의 '확인 필요 목록'에서 봅니다"
        note = "이 메일에는 새로 잡힌 것만 싣습니다" if issues else "오늘 새로 잡힌 확인 필요는 없습니다"
        backlog = f"{whose}열려 있는 확인 필요 누적 <b>{nb}건</b>{age} — {note}. 모두 {where}"
    iss_card = ""
    if issues:
        # 링크형은 확인 필요 줄도 크기 몫(_LINK_ISS_BUDGET)까지 — 넘으면 '외 N건 — 사내망 확인 필요 목록 ›' (검토 Y3 M2)
        iss_card = _m_issues_card(issues, details, link=link, folders=folders, recurred=recurred,
                                  n_lines=1 if link else 3, tail=backlog, max_bytes=_LINK_ISS_BUDGET if link else None,
                                  project=project)
    elif backlog:
        iss_card = _m_box("warn", backlog)

    # ── 바뀐 내용 카드 ──
    _was_ent: dict = {}
    _ent = _toc_entries(main, details, doc_info, False, details_by_id, was_out=_was_ent) if main else []
    _summ = {i: sm for i, _nm, sm, _sal in _ent}
    # 같은 요약·같은 값이 여덟 건 넘게 반복되면(발행일 Rev 일괄 올림) 앞 두 건만 줄을 펴고 나머지는 '위와 같은 내용' 한 줄 (구매자 평가 P3).
    # 요약 문구만 같고 값이 다르면 접지 않는다 (검토61 D B1)
    fold_ids: set = set()
    if main:
        def _vals(c):
            its = items_for(c, details, details_by_id)
            return tuple(sorted((it.kind, str(it.old or ""), str(it.new or "")) for it in its
                                if it.kind not in ("PAGE_VISUAL_CHANGED", "CHECK_SKIPPED")))
        _key = {i: (sm, _vals(main[i])) for i, _nm, sm, sal in _ent if not sal}
        _cnt = Counter(_key.values())
        _seen: dict = {}
        for i, _nm, sm, sal in _ent:
            if sal or _cnt[_key[i]] <= 8:
                continue
            _seen[_key[i]] = _seen.get(_key[i], 0) + 1
            if _seen[_key[i]] > 2:
                fold_ids.add(i)
    companions = drawing_companions(main, doc_info)
    afolds = added_folds(main, details, details_by_id, skip=set(companions))
    iss_paths = {getattr(x, "path", None) for x in issues}

    def _has_issue(c) -> bool:
        return any(x.path == c.path or any(c.path and c.path in str(e) for e in (x.evidence or ())) for x in issues)
    order = [k for k, c in enumerate(main) if id(c) not in companions and (id(c) not in afolds or afolds[id(c)][0] is c)]
    order.sort(key=lambda k: 0 if _has_issue(main[k]) else 1)       # 확인 필요가 걸린 변경을 위로 (그 안은 arrange_changes 순서)
    link_cut = max(0, len(order) - LINK_LINES_MAX) if link else 0       # 링크형 — 넘는 줄은 수만(기록에 전부, Gmail 잘림 한도)
    if link_cut:
        order = order[:LINK_LINES_MAX]

    # 사진 — 근거형: 확인 필요 걸린 파일 → 도면 → 그 밖 순으로 장수 상한(_MAIL_PHOTO_MAX)까지 변경마다 한 쌍 (E10).
    # 링크형: 선·도형만 바뀌어 줄에 값이 없는 변경에만(V3-3, 원칙 4)
    photo_of: dict = {}
    cands = []
    if budget is not None and captures:
        from watcher.doctype import canonical as _canon, kind_of as _kind
        for k in order:
            c = main[k]
            if k in fold_ids or id(c) in afolds or (link and c.kind != "modified"):
                continue
            its = list(items_for(c, details, details_by_id))
            if link:
                vis = [i for i in its if i.kind == "PAGE_VISUAL_CHANGED"]
                if not vis or any(i.kind not in ("PAGE_VISUAL_CHANGED", "CHECK_SKIPPED") and not _titleish(i) for i in its):
                    continue
                pick = next((i for i in vis if _cap_of(captures, c.path, i, c.id)), None)
            else:
                pick = next((i for i in its if not _titleish(i) and _cap_of(captures, c.path, i, c.id)), None)
            if pick is None:
                continue
            cands.append(((0 if c.path in iss_paths else 1, 0 if _canon(_kind(c.path, None)) == "도면" else 1, k), c, pick))
        cands.sort(key=lambda t: t[0])
        n_ok = min(len(cands), max(0, budget.photos))
        budget.photos -= n_ok
        for _o, c, pick in cands[:n_ok]:
            photo_of[id(c)] = pick
    photo_cut = len(cands) - len(photo_of)

    go_col = link or any(_m_ack_go(main[k], ack_base, ack_tokens, link) for k in order)
    ncols = len(_M_CHG_HEADS) + (1 if go_col else 0)       # 파일(+문서 종류) · 바뀐 곳 · 이전 / 지금 · 상태 (+ 줄 끝)
    trs: list = []
    photos: list = []
    rows_bytes, n_prev = 0, 0
    shown_ids: set = set()
    # 바뀐 내용 줄에 쓸 몫 = 본문 몫 - 이미 정해진 칸(확인 필요·알림 상자) - 사진 칸 어림(장당 700) - 머리·꼬리 어림
    rows_budget = max(_EV_ROWS_MIN, _MAIL_BODY_BUDGET - len((iss_card + boxes_top + boxes_low).encode("utf-8"))
                      - 700 * len(photo_of) - 8_000)
    for k in order:
        c = main[k]
        # 크기 상한 — 표 줄이 rows_budget을 넘으면 뒤 변경은 '외 N건' 한 줄로 (검토 X M2: 300건이면 491KB로 Gmail 102KB의
        # 4.8배였다). 근거형은 접은 파일 이름을 모두, 링크형은 수 + '프로젝트 기록 ›' — 링크형도 LINK_LINES_MAX 줄만으로는 줄마다 2KB라
        # 큰 날 통이 127KB로 Gmail 잘림을 넘었다 (검토 Y3 M2). 접은 것도 수와 볼 곳은 남긴다(원칙 4)
        rows_bytes += sum(len(x.encode("utf-8")) for x in trs[n_prev:])
        n_prev = len(trs)
        # 상한을 넘으면 접되 사진 몫을 받은 변경(장수 상한 _MAIL_PHOTO_MAX)은 싣는다 — 사진만 있고 그 줄이 없는 메일이 되지 않게
        if shown_ids and rows_bytes > rows_budget and id(c) not in photo_of:
            continue
        info = info_of(c)
        its = list(items_for(c, details, details_by_id))
        shown_ids.add(id(c))
        fname = _esc(PurePosixPath(c.path).name)
        meta = _m_file_meta(c, info, _m_doc_kind(c.path))
        if id(c) in afolds:
            _lead, folder, ext, cs = afolds[id(c)]
            shown_ids.update(id(x) for x in cs)
            # 근거형은 이름을 모두(원칙 5), 링크형은 앞 12개 + 수(기록에 전부)
            cap_n = 12 if link else len(cs)
            names = ", ".join(PurePosixPath(x.path).name for x in cs[:cap_n]) + (f" 외 {len(cs) - cap_n}개" if len(cs) > cap_n else "")
            sub = [("span", '<b>새 파일</b>',
                    f'<b>{_esc(added_fold_text(folder, ext, len(cs)))}</b>' + _m_sub(_esc(names)))]
            trs += _m_change_rows(sub, fname=f"{len(cs)}개 파일", meta=_m_file_meta(c, None, _m_doc_kind(c.path)),
                                  status="", go=_m_go(lan_project_url(project)) if link else "", go_col=go_col)
            continue
        if k in fold_ids:
            # 같은 값이 여덟 건 넘게 되풀이된 변경 — 앞 한 곳만 두 줄로 + '위와 같은 내용' (요약 문장의 화살표 대신, 2026-11-21)
            first_ = [x for x in _m_item_rows(c, its, info, link=True, split_where=True) if x[0] in ("pair", "span")][:1]
            sub = (first_ + [("note", "위와 같은 내용의 변경")] if first_ else
                   [("note", f"위와 같은 내용의 변경 — {_esc(_was_ent.get(k, unarrow_summary(_summ.get(k, ''))))}")])
        elif c.kind == "added" and not any(i.kind != "CHECK_SKIPPED" for i in its):
            # 새 문서 = [이전] 없음 / [지금] 추가, 지운 문서 = [이전] 있음 / [지금] 없음 (2026-11-21 규칙 4 — 화면과 같은 말)
            sub = [("pair", '<b>파일</b>', "없음", "추가", 0)]
            sub += [x for x in _m_item_rows(c, its, info, link) if x[0] == "note"]
        elif c.kind == "removed":
            sub = [("pair", '<b>파일</b>', "있음", "없음", 0)]
            sub += [x for x in _m_item_rows(c, its, info, link) if x[0] == "note"]
        else:
            sub = _m_item_rows(c, its, info, link, split_where=True)
        trs += _m_change_rows(sub, fname=fname, meta=meta, status=_m_status(c, its, issues, acked_by),
                              go=_m_ack_go(c, ack_base, ack_tokens, link), go_col=go_col)
        for p in (p for p in main if companions.get(id(p)) is c):
            # 같은 도면의 출도 PDF는 DXF 줄 밑에 — 그 PDF의 바뀐 값을 앞 3곳까지 두 줄로(요약 문장의 화살표 대신, 2026-11-21, 원칙 5)
            shown_ids.add(id(p))
            its_p = list(items_for(p, details, details_by_id))
            sub_p = [x for x in _m_item_rows(p, its_p, info_of(p), link=True, split_where=True) if x[0] in ("pair", "span", "note")]
            if not link:
                sub_p = [("note", x[1].split(" — ")[0] + " — 감시 PC 화면의 변경 상세에 모두 있습니다") if x[0] == "note" else x
                         for x in sub_p]
            if not any(x[0] != "note" for x in sub_p):
                _wp_: dict = {}
                ent = _toc_entries([p], details, doc_info, False, details_by_id, was_out=_wp_)
                sm = _wp_.get(0, ent[0][2]) if ent else KIND_LABEL_TEXT(p)       # '지금(이전 …)' 꼴은 만든 자리에서 (Y2 H1)
                sub_p = [("note", _esc(sm))]
            trs += _m_change_rows(sub_p, fname=_esc(PurePosixPath(p.path).name),
                                  meta=_m_file_meta(p, info_of(p), "출도 PDF")[:-6] + " · 같은 도면의 출도본</div>",
                                  status=_m_status(p, its_p, issues, acked_by),
                                  go=_m_ack_go(p, ack_base, ack_tokens, link), go_col=go_col)
        if id(c) in photo_of:
            pick = photo_of[id(c)]
            lab = (_m_text_cells(pick)[0] if pick.kind.startswith("TEXT_")
                   else f"그림 {plain_where(str(pick.key))}" if pick.kind == "PAGE_VISUAL_CHANGED" else _flabel(pick))
            photos.append(_m_photo(_cap_of(captures, c.path, pick, c.id), budget,
                                   f"{PurePosixPath(c.path).name} · {lab}" if lab else PurePosixPath(c.path).name))
    cut_cs = [c for c in main if id(c) not in shown_ids]
    ev_cut = len(cut_cs)
    if ev_cut:
        # 사진 몫을 받았지만 싣지 못한 변경의 장수는 돌려주고(하루 묶음의 다른 프로젝트가 쓴다) '나머지 N건' 수에 넣는다
        unused = sum(1 for c in cut_cs if id(c) in photo_of)
        if budget is not None and unused:
            budget.photos += unused
        photo_cut += unused
    if ev_cut and link:
        # 링크형 — 줄 상한(LINK_LINES_MAX)·크기 상한으로 접은 변경은 수 + 프로젝트 기록 링크 한 줄 (검토 Y3 M2)
        tl_ = lan_project_url(project) or (f"{LAN_BASE}/changes/recent" if LAN_BASE else "")
        go_ = (f' <a href="{_esc(tl_)}" style="color:#2F3EC2;font-weight:700;text-decoration:none;white-space:nowrap">'
               f'기록 보기&nbsp;›</a>') if tl_ else ""
        trs.append(f'<tr><td colspan="{ncols}" style="{_M_TD};{_M_EDGE_L};{_M_EDGE_R};font-size:14px;color:#4A5363">'
                   f'<b style="color:#111827">외 {ev_cut}건</b> — 프로젝트 기록에 모두 있습니다{go_}</td></tr>')
    elif ev_cut:
        # 접은 변경도 파일 이름은 모두 남긴다(원칙 5 — 바뀐 사실은 빠짐없이). 아주 많으면 앞 _EV_CUT_NAMES개 + 수
        nm = [PurePosixPath(c.path).name for c in cut_cs]
        names = ", ".join(nm[:_EV_CUT_NAMES]) + (f" 외 {len(nm) - _EV_CUT_NAMES}개" if len(nm) > _EV_CUT_NAMES else "")
        trs.append(f'<tr><td colspan="{ncols}" style="{_M_TD};{_M_EDGE_L};{_M_EDGE_R};font-size:14px;color:#4A5363">'
                   f'<b style="color:#111827">외 {ev_cut}건</b> — 메일이 너무 길어져 여기까지 실었습니다. '
                   f'감시 PC 화면의 변경 이력에 근거·사진과 함께 모두 있습니다: {_esc(names)}</td></tr>')
    if not main and (quiet or resaved or uncompared):
        trs.append(f'<tr><td colspan="{ncols}" style="{_M_TD};{_M_EDGE_L};color:#4A5363">내용이 바뀐 산출물은 없습니다</td></tr>')
    trs += _m_quiet_rows(quiet, moved, details, details_by_id, ncols, extra=len(resaved or ()) + len(uncompared or ()))
    trs += _m_resaved_rows(resaved, uncompared, ncols, link)
    chg_card = ""
    if trs:
        # 이전/지금 두 줄(2026-11-21): '이전 | → | 지금' 세 칸 대신 '이전 / 지금' 한 칸. 문서 종류는 파일 칸 위에
        heads = list(_M_CHG_HEADS) + ([("", "width:6%")] if go_col else [])
        tl = lan_project_url(project) if link else ""
        right = (f'<a href="{_esc(tl)}" style="color:#2F3EC2;font-weight:700;text-decoration:none">전체 기록 ›</a>'
                 if tl else "")
        chg_card = _m_card(_m_card_head("바뀐 내용", _m_count(n), right=right), _m_table(heads, trs, stack=True))
    photo_card = ""
    if photos or photo_cut:
        _shown = sum(1 for p in photos if "<img" in p)
        cut_txt = ""
        if photo_cut:
            _shared_budget = getattr(budget, "photos_given", _MAIL_PHOTO_MAX) < _MAIL_PHOTO_MAX
            if link:
                cut_txt = "전/후 사진 생략 — 이 메일의 사진 장수 상한을 넘었습니다. 링크한 사내망 기록에 있습니다."
            elif _shared_budget:
                cut_txt = (f"사진은 이 프로젝트에 {_shown}장만 실었습니다 — 나머지 {photo_cut}건은 Drev 화면에서 보세요 "
                           f"(메일 한 통의 사진 {_MAIL_PHOTO_MAX}장을 프로젝트 여러 곳이 나눠 씁니다).")
            else:
                cut_txt = f"사진은 {_shown}장까지만 실었습니다 — 나머지 {photo_cut}건은 Drev 화면에서 보세요."
        head = ('<!--drev-legend--><tr><td style="padding:14px 16px 4px"><h2 style="margin:0;font-size:18px;font-weight:800;'
                'color:#111827">전/후 사진<span style="font-size:14.5px;font-weight:400;color:#4A5363"> &nbsp;빨간 네모가 바뀐 자리'
                '</span></h2></td></tr><!--/drev-legend-->')
        body = f'<tr><td style="padding:0">{"".join(photos)}</td></tr>' if photos else ""
        if cut_txt:
            body += (f'<!--drev-legend--><tr><td style="padding:10px 16px 14px;border-top:1px solid #E3E6EC;font-size:14px;'
                     f'color:#4A5363">{_esc(cut_txt)}</td></tr><!--/drev-legend-->')
        photo_card = _m_card(head, body)
    button = ""
    tl_url = lan_project_url(project)
    if link and tl_url and (main or quiet or issues):
        button = ('<tr><td align="center" style="padding:4px 0 20px"><table role="presentation" cellpadding="0" cellspacing="0" '
                  'border="0"><tr><td bgcolor="#3A4BDB" style="background:#3A4BDB;border-radius:8px">'
                  f'<a href="{_esc(tl_url)}" style="display:inline-block;padding:12px 28px;font-size:16px;font-weight:700;'
                  f'color:#FFFFFF;text-decoration:none">기록에서 자세히 보기 →</a></td></tr></table></td></tr>')
    rows = (_m_summary(len(issues), n, extras, head_txt, zero, n_sh=_n_sh) + '<tr><td style="padding:0"><!--drev-note-at--></td></tr>'
            + boxes_top + iss_card + boxes_low + chg_card + photo_card + (shared_block(shared, shared_issues) if shared else "")
            + button + _m_foot(date_str, root, scanned_note, since_note, merged_note, top))
    return _mail_doc(_m_head_band(_m_band_title(project or "전체"), _esc(_m_when(run_at))), rows, date_str, (len(issues), n, _n_sh))


def build_brief(changes: list[Change], run_at: datetime, root: str,
                details: dict | None = None, issues: list | None = None,
                project: str | None = None, ack_base: str | None = None,
                ack_tokens: dict | None = None,
                scan_errors: list | None = None,
                errors_above: list | None = None,
                captures: dict | None = None,
                scanned_count: int | None = None,
                baseline: bool = False,
                doc_info: dict | None = None,
                merged_note: str | None = None,
                acked_by: dict | None = None,
                details_by_id: dict | None = None,
                since: str | None = None,
                photo_budget: bool = False,
                baseline_note: str | None = None,
                open_backlog: tuple | None = None,
                resolved: list | None = None,
                rollback_note: str | None = None,
                clock_note: str | None = None,
                gap_note: str | None = None,
                continued: list | None = None,
                recurred: dict | None = None,
                still_open: list | None = None,
                wiped_folders: list | None = None,
                alias_note: str | None = None,
                rejudged: list | None = None,
                ordered_tags: set | None = None,
                summaries: dict | None = None,
                shared: list | None = None,
                shared_issues: list | None = None) -> str:
    """브리핑 HTML 문서 전체를 돌려준다. 변경 0건이어도 문서는 만든다(기록용).
    summaries: {변경 id: 한 줄 요약} — 기록의 요약(State.record_summaries). 없으면 같은 규칙으로 만든다 (2026-11-17 R4)
    shared: [(공용·공통 폴더 이름, Change, 한 줄 요약)] — 그날 공용 폴더 변경. 메일 판 끝에 한 줄로 (pv2 B-4)
    shared_issues: 그 공용 폴더들의 오늘 검토 필요 — 공용 줄을 싣는 통의 머리 수에 함께 센다 (V3-8)
    메일 판(photo_budget)은 두 꼴 (2026-11-17 R4): 사내망 기록 열람 주소(LAN_BASE)가 있으면 링크형, 없으면 근거형 — 2026-11-20부터
    한 틀(_mail_brief, 메일 3판: 칸 이름이 있는 표).
    wiped_folders: [(폴더, 삭제 파일 수)] — 등록 파일이 하나도 안 남은 폴더 (R5-6, wiped_folders()가 만든다)

    details: {path: [ChangeItem]} 파일별 내용 변경 상세 (Stage 3)
    issues:  [Issue] 일관성 검사 결과 (Stage 3)
    project: 프로젝트별 브리핑이면 정규 프로젝트 번호 (Stage 4)
    scanned_count: 이번 검사에서 확인한 파일 수 — 0건 날의 '살아있음' 신호
    errors_above: 하루 묶음 맨 위에 한 번만 실은 안내 — 이 문서에는 안 싣지만 '정상 동작 중'이라고도 하지 않는다 (ux27 K3)
    open_backlog: (그 프로젝트의 열린 검토 필요 누적, 가장 오래된 것 며칠째) — 메일은 새로 잡힌 것만
                  싣기에, 이 메일 밖에 남은 것이 있으면 수만 한 줄로 알린다 (검토36 B 3)
    ordered_tags: 이 프로젝트 발주서에 오른 태그·품번(접은 꼴) — 머리 한 줄이 '발주 전 확인'이라 하지 않게 (ux24 RD1)
    """
    details = details or {}
    issues = issues or []
    date_str = run_at.strftime("%Y-%m-%d %H:%M")
    proj_label = f"[{project}] " if project else ""
    scanned_note = (f" · 파일 {scanned_count}개 검사함"
                    if scanned_count is not None else "")
    # PC가 며칠 꺼져 있다가 켜진 날은 6일치 변경이 "오늘 12건"으로 나가 받는 사람이
    # 어제 하루 일로 읽었다 — 무엇과 비교한 것인지 한 줄 밝힌다 (원칙 4, 2026-09-09
    # 자동 실행 검토 중간 8)
    # 합산본은 여러 검사분을 한 통에 담는다 — "직전 검사"라 쓰면 그 통의 절반에
    # 대해 거짓이 된다 (2026-09-09 배포 후 검토 중간 2)
    since_note = (f" · 비교 기준: 오늘 앞선 검사부터 (가장 최근 비교는 {since})"
                  if since and merged_note else
                  f" · 비교 기준: 직전 검사 {since}" if since else "")
    # 기준선은 전부 '첫 등록' — 접지 않고 그대로 나열
    resaved: list = []
    uncompared: list = []
    if baseline:
        main, quiet, moved = list(changes), [], {}
    else:
        main, quiet, moved = arrange_changes(changes, details, details_by_id)
        if photo_budget:
            # 메일 판에는 '글자·표·그림이 모두 같은 재저장'을 싣지 않는다 — 다른 프로그램으로 다시 뽑기만 한 PDF·재스캔이 날마다
            # 메일에 '그 밖의 알림'으로 실려, 받는 사람이 무엇이 바뀌었나 열어 보게 했다 (검토68 B05·B18·B25·B35·B42).
            # 디스크 브리핑·화면 이력에는 그대로 남는다(기록). 그림을 비교하지 않는 형식·일부만 읽은 쪽은 남긴다
            _rs = [c for c in quiet if is_silent_resave(note_of(items_for(c, details, details_by_id)))]
            # 그림·개체를 비교하지 못한 재저장(DOCX·XLSX)도 한 줄로 — 문서 안 그림만 바꾼 날 그 파일만 있는 프로젝트는 메일 자체가
            # 없었다 (검토69 B M2b, 원칙 5). 표 행 대신 한 줄에 '그림·개체는 비교 못 함'을 밝힌다
            _uc = [c for c in quiet if is_uncompared_resave(note_of(items_for(c, details, details_by_id)))]
            quiet = [c for c in quiet if not any(c is r for r in _rs + _uc)]
            resaved = _rs
            uncompared = _uc
    n = len(main)
    head_th = (f'<tr><th style="{_STYLE_TH}">구분</th><th style="{_STYLE_TH}">파일</th>'
               f'<th style="{_STYLE_TH}">폴더</th>' + (f'<th style="{_STYLE_TH}">확인</th>' if ACK_ON.get() else '') + '</tr>')
    # 메일 판 압축 (구매 평가 2차 F2) — 기준선 등록 통은 등록 목록이라 그대로
    compact = bool(photo_budget) and not baseline
    if compact:
        # 메일 3판 (2026-11-20) — 근거형·링크형 한 틀(_mail_brief). 링크형(LAN_BASE)은 근거·사진이 사내망 기록 화면에 있고 받는 사람이
        # 그 화면을 연다 (2026-11-17 R4). 아래는 디스크 브리핑(기록)과 기준선 통
        return _mail_brief(
            main, quiet, moved, resaved, uncompared, run_at, root, details=details, details_by_id=details_by_id,
            issues=issues, project=project, doc_info=doc_info, scanned_note=scanned_note, since_note=since_note,
            merged_note=merged_note, scan_errors=scan_errors, errors_above=errors_above, clock_note=clock_note,
            gap_note=gap_note, alias_note=alias_note, rollback_note=rollback_note, rejudged=rejudged,
            continued=continued, still_open=still_open, open_backlog=open_backlog, resolved=resolved,
            wiped_folders=wiped_folders, ordered_tags=ordered_tags, summaries=summaries, shared=shared,
            acked_by=acked_by, shared_issues=shared_issues, captures=captures,
            budget=photo_budget if isinstance(photo_budget, PhotoBudget) else PhotoBudget(),
            ack_base=ack_base, ack_tokens=ack_tokens, recurred=recurred)
    # 아래는 디스크 브리핑(기록 — 화면 '브리핑'이 여는 파일)과 기준선 통. 메일 판은 위 _mail_brief
    # 사진 총량은 **메일에만** 건다. 전에는 무조건 걸어서, 디스크에 남는 브리핑
    # 원본(화면이 여는 바로 그 파일)에서도 사진이 지워졌다 — 안내문은 "이 메일의
    # 상한"이라 말하고 "감시 PC 화면에서 보라"고 했는데, 보는 사람이 이미 그 화면이고
    # 그 상세는 보존 기간이 지나면 사라진다 (2026-09-09 배포 후 검토, 원칙 4). 기준선 메일 판만 예산이 있다
    _budget = photo_budget if isinstance(photo_budget, PhotoBudget) else (PhotoBudget() if photo_budget else None)
    _afolds = {} if baseline else added_folds(main, details, details_by_id)
    # 디스크 브리핑(메일 예산 없음)도 사진 장수는 상한 — 하루 7~8MB씩 쌓였다 (검토 Y3 L7). 메일 판·기준선 메일은 _budget이 정한다
    _disk = {"left": _DISK_PHOTO_MAX} if _budget is None else None
    if main:
        rows = "\n".join(
            (f'<tbody id="chg{i}">' + _added_fold_row(*_afolds[id(c)]) + "</tbody>" if id(c) in _afolds else
             f'<tbody id="chg{i}">'
             + _change_row(c, ack_base, ack_tokens, ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)), baseline,
                           acked_by=acked_by)
             + _one_details(c, details, details_by_id, captures, doc_info, _budget, _disk)
             + "</tbody>")
            for i, c in enumerate(main) if id(c) not in _afolds or _afolds[id(c)][0] is c)
        body = f"""
  {_summary_toc(main, details, doc_info, baseline=baseline, details_by_id=details_by_id, folds=_afolds)}
  <table style="{_STYLE_TABLE}">{head_th}
    {rows}
  </table>"""
    elif quiet:
        body = ('<p style="color:#57606a">내용이 바뀐 산출물은 없습니다 — 아래 '
                '그 밖의 알림만 있습니다.</p>')
    elif scan_errors or errors_above:
        # 읽지 못한 폴더·파일이 있는 날은 '정상 동작 중'이 아니다 — "파일 122개가 사라졌습니다" 바로
        # 아래 "정상 동작 중"이 서로 부정했다 (검토21 브리핑 차단 4)
        _h, _e = split_hold_notes(list(scan_errors or ()) + list(errors_above or ()))
        _what = " · ".join(x for x in (("삭제 알림 보류" if _h else ""), ("읽지 못한 폴더·파일 알림" if _e else "")) if x)
        body = (f'<p style="color:#9a6700">변경된 산출물이 없습니다 — 다만 위의 {_what}을 '
                f'확인하세요{_esc(scanned_note)}.</p>')
    else:
        body = (f'<p style="color:#1a7f37">변경된 산출물이 없습니다 — 감시는 정상'
                f' 동작 중입니다{_esc(scanned_note)}.</p>')
    if quiet:
        # 폴더 이름 변경·이동은 파일마다 한 행(6~20행)이 아니라 "폴더 A → B (파일 N개)" 한
        # 줄로 접는다 (파일럿 모의 ⑩). 셋 미만이면 파일별로 둔다
        from collections import Counter as _C
        pair_of = {}
        for c in quiet:
            if id(c) in moved:
                # 바뀐 가장 높은 조상끼리 묶는다 — 하위 폴더별(도면/·BOM/)로 따로 세면
                # "폴더 A → B (파일 20개)" 한 줄이 안 됐다 (파일럿 모의 2차 day10)
                op = PurePosixPath(moved[id(c)]).parent.parts
                npn = PurePosixPath(c.path).parent.parts
                k = 0
                while k < min(len(op), len(npn)) and op[-1 - k] == npn[-1 - k]:
                    k += 1
                # 공통 꼬리를 떼되 **옮겨진 폴더 이름은 남긴다** — '견적중_P26-034'를 통째로 떼어
                # "서버 → 서버/아카이브"라 적었다 (파일럿 모의 3차 ①). 꼬리를 뗐으면 한 마디 되살린다
                if k > 0:
                    k -= 1
                pair_of[id(c)] = ("/".join(op[:len(op) - k]) or ".", "/".join(npn[:len(npn) - k]) or ".")
        pair_n = _C(pair_of.values())
        folded_pairs: set = set()
        qparts = []
        for c in quiet:
            pr = pair_of.get(id(c))
            if pr and pr[0] != pr[1] and pair_n[pr] >= 3:
                if pr in folded_pairs:
                    continue
                folded_pairs.add(pr)
                # 폴더 이동도 두 줄 — 옛 폴더 [이전] / 새 폴더 [지금] (이전/지금 2026-11-21 L, 화살표 한 줄 대신)
                qparts.append(
                    f'<tr valign="top"><td style="{_STYLE_TD_TOP}"><strong style="color:#57606a">이동</strong></td>'
                    f'<td style="{_STYLE_TD_TOP}" colspan="2">'
                    + _m_place_line(f'<b>폴더 이동</b> · 파일 {pair_n[pr]}개 — 이름·위치만 바뀜, 내용 동일', 0)
                    + _m_pv(_esc(pr[0]), _esc(pr[1])) + '</td>'
                    + _ack_td("—") + '</tr>')
                continue
            qparts.append(_change_row(c, ack_base, ack_tokens, None, False,
                                      moved_from=moved.get(id(c)),
                                      note="" if id(c) in moved else note_of(items_for(c, details, details_by_id)),
                                      acked_by=acked_by))
        qrows = "\n".join(qparts)
        # 그날 있는 종류만 — 폴더 이름 하나 바꾼 날에도 일곱 가지를 다 나열했다 (검토44 C 낮음 6)
        _legend = ("이동·이름 변경 (내용 동일, 확인할 필요 없는 변경)" if all(id(c) in moved for c in quiet)
                   else "이동·복사본·재저장·빈 파일·일자만 갱신·표제란 틀 교체·구판 정리 (확인할 필요 없는 변경)")
        body += f"""
  <h3 style="margin:20px 0 6px;color:#57606a">그 밖의 알림 {len(quiet)}건
    <span style="font-weight:400;font-size:13px">— {_legend}</span></h3>
  <table style="{_STYLE_TABLE};color:#57606a">{head_th}
    {qrows}
  </table>"""
    quiet_head = f' <span style="color:#57606a;font-weight:400;font-size:15px">(+그 밖의 알림 {len(quiet)}건)</span>' if quiet else ""
    # 'Rev 올렸는데 일자 그대로' 표지는 검토 필요 카드가 아니라 변경 행의 띠 — 머리에서 수를 한 번 센다 (ux20 mail 4)
    _n_rd = 0 if baseline else rev_date_count(main, details, details_by_id)
    _rd_head = (f' <span style="color:#9a6700;font-size:15px">· 확인 필요 {_n_rd}건</span>' if _n_rd else "")
    # 맨 위 사장·구매용 한 줄 — 레이어·좌표·서버 경로 없이 무엇이 어떻게, 무엇을 할지 (구매 평가 2차 P1·P2)
    # 값 변화는 화살표 대신 '지금(이전 …)' — 메일 머리와 같은 꼴 'M-301 7.5kW(이전 5.5kW), Rev B(이전 A)' (이전/지금 2026-11-21 L)
    _head_txt = "" if baseline else mail_headline(main, issues, details, doc_info, details_by_id, project, ordered_tags,
                                                  was=True)[0]
    # 프로젝트 폴더가 통째로 사라진 날은 그 사실을 한 줄로 — 첫 파일 이름 '…pdf 삭제 외 25'만 보였다 (R5-6). 사실만 적는다(원칙 6)
    _wipe_txt = "" if baseline else wiped_line(wiped_folders)
    if _wipe_txt and not _head_txt:
        _head_txt, _wipe_txt = _wipe_txt, ""

    return f"""<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>산출물 변경 브리핑 {_esc(date_str)}</title>
<style>@media (max-width:480px){{body{{padding:10px!important;word-break:normal!important}}h2{{font-size:19px!important;word-break:keep-all!important}}td,th{{padding:4px 5px!important;font-size:13px!important;white-space:normal!important;word-break:keep-all;overflow-wrap:anywhere}}td.k{{white-space:nowrap!important}}th{{white-space:nowrap!important}}img{{max-width:100%!important;height:auto!important}}}}</style></head>
<body bgcolor="#ffffff" style="font-family:'Malgun Gothic',Segoe UI,sans-serif;color:#1f2328;
             background:#ffffff;max-width:860px;margin:0 auto;padding:24px;word-break:keep-all;overflow-wrap:anywhere">
  <h2 style="margin:0 0 4px">{_esc(proj_label)}산출물 변경 브리핑 — {'기준선 등록' if baseline else '변경'} {n}건{quiet_head}
    {f'/ <span style="color:#cf222e">확인 필요 {len(issues)}건</span>' if issues else ''}{_rd_head}</h2>
  {headline_html(_head_txt)}{headline_html(_wipe_txt)}
  {f'<p style="background:#fff1e5;border:1px solid #e3a341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>PC 시계 확인</b> — {_esc(clock_note)}</p>' if clock_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>별칭 사전</b> — {_esc(alias_note)}</p>' if alias_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>검사 공백</b> — {_esc(gap_note)}</p>' if (gap_note and not clock_note) else ''}
  {f'<p style="background:#fff1e5;border:1px solid #e3a341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>옛 판으로 되돌아간 날</b> — {_esc(rollback_note)}</p>' if rollback_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px">{_esc(baseline_note) if baseline_note else "첫 검사(기준선)입니다"} — 아래 파일들은 <b>변경이 아니라 감시 대상으로 등록</b>된 것입니다. 내일부터 달라진 것만 브리핑합니다.' + (' 확인 필요 항목은 지금 봐 둘 만합니다.' if issues else ' 이 메일은 보낼 필요가 없습니다.') + '</p>' if baseline else ''}
  {_scan_errors_section(scan_errors) if scan_errors else ''}
  {_rejudged_block(rejudged) if (rejudged and not baseline) else ''}
  {f'<h3 style="margin:16px 0 8px">확인 필요 {len(issues)}건</h3>{_issues_section(issues, ack_base, project, recurred, folders=_folders_of(doc_info), details=details)}'
   if issues else ''}
  {_continued_line(continued) if (continued and not baseline) else ''}
  {_still_open_line(still_open) if (still_open and not baseline) else ''}
  {_backlog_line(open_backlog, len(issues), ack_base, project, hide_age=bool(clock_note)) if (open_backlog and not baseline) else ''}
  {_resolved_line(resolved) if (resolved and not baseline) else ''}
  <h3 style="margin:16px 0 8px">변경 목록</h3>
  {'' if (baseline or not changes or not ack_base or '/ack?id=' not in body or not ACK_ON.get()) else
   ('<p style="color:#57606a;font-size:12px;margin:0 0 8px">감시 PC 화면 › 고급 › 변경 이력의 미확인 변경에서 한꺼번에 확인할 수 '
    '있습니다. 각 행의 #번호는 그 화면에서 찾는 번호입니다.</p>' if _loopback(ack_base) else
    f'<p style="color:#57606a;font-size:12px;margin:0 0 8px">감시 PC에서는 '
    f'<a href="{_esc(ack_base)}/history?ack=none" style="color:#0969da">미확인 변경 목록</a>'
    f'에서 한꺼번에 확인할 수 있습니다. 각 행의 [확인했음 기록]은 그 변경의 근거 화면으로 갑니다.</p>')}
  {body}
  <p style="color:#57606a;margin:24px 0 4px;font-size:13px">
    {_esc(date_str)} 기준 · 감시 폴더: <span title="{_esc(root)}">{_esc(_short_roots(root))}</span>{_esc(scanned_note)}{_esc(since_note)}</p>
  {f'<p style="color:#57606a;font-size:13px;margin:0 0 10px">{_esc(merged_note)}</p>' if merged_note else ''}
  {'' if (baseline or not (main or quiet) or not ACK_ON.get()) else ('<p style="color:#57606a;font-size:13px;margin:0 0 12px">휴대폰·다른 PC에서 보셨다면 의견은 이 메일에 <b>회신</b>으로 남겨 주세요. '
     '각 행의 [감시 PC에서 확인]은 감시 PC에서 Drev 창이 떠 있을 때만 열립니다.</p>' if _loopback(ack_base) else '')}
  <p style="color:#57606a;font-size:12px;margin-top:12px">
    Drev — 읽기 전용 감시. 이 메일은 변경 '사실'의 기록이며,
    내용 판단은 담당자가 합니다.{'' if (baseline or not changes or '/ack?id=' not in body or _loopback(ack_base)) else ' 각 변경의 [확인했음 기록] 링크는 감시 PC에서 그 변경의 상세 화면을 엽니다 — 거기서 [확인함]을 눌러야 기록됩니다.'}</p>
</body>
</html>
"""


REJUDGED_HEAD = "프로그램 업데이트로 다시 판정한 것"
# 메일 꼬리 — 왜 내가 받나·그만 받으려면 (ux20 mail 8). 받는 사람은 감시 PC 설정(전체·프로젝트별·구매·늘 받는 사람)이 정한다
RECIPIENT_LINE = (" 이 메일은 감시 PC 설정에서 정한 받는 사람(전체·프로젝트 담당·구매 담당)에게 갑니다 — "
                  "받는 사람을 바꾸거나 그만 받으려면 감시 PC 관리자에게 말씀하세요.")


def _rejudged_block(rejudged: list) -> str:
    """판 올림 뒤 파일 변경 없이 다시 판정한 검토 필요 한 묶음 (기능 검토 2026-11-02 J4) — '오늘 확인할 것'·'검토 필요'에서 빼고
    머리에 접어 둔다. 무엇인지는 펼치면 보이고, 근거는 감시 PC 화면의 검토 필요에 그대로 있다(원칙 4)."""
    from watcher.consistency import CODE_LABEL
    lis = "".join(f'<li style="margin:2px 0">{_esc(CODE_LABEL.get(i.code, i.code))}: {_esc(_short(_iss_card_text(i)[0], 140))}</li>'
                  for i in rejudged[:30])
    more = (f'<li style="margin:2px 0">… 외 {len(rejudged) - 30}건</li>' if len(rejudged) > 30 else "")
    return (f'<details style="border:1px solid #d0d7de;border-radius:6px;padding:8px 12px;margin:0 0 12px;'
            f'background:#f6f8fa;font-size:13px;color:#57606a"><summary style="cursor:pointer">'
            f'<b>{REJUDGED_HEAD} {len(rejudged)}건</b> (파일 변경 아님 — 판정 규칙이 바뀌어 다시 본 결과입니다. '
            f'근거는 감시 PC 화면의 확인 필요 목록에 있습니다)</summary>'
            f'<ul style="margin:6px 0 0;padding-left:20px">{lis}{more}</ul></details>')


def _resolved_line(resolved: list) -> str:
    """이번 검사에서 해소된 검토 필요 — 파일이 바뀌어 다시 검출되지 않은 것 (검토39 P2 중간 2). '고쳐짐'이라 단정하면
    서버를 백업에서 되돌린 날에도 그렇게 말했다 (검토42 D 낮음 1)."""
    from watcher.consistency import CODE_LABEL
    # 사유가 '재검출되지 않음'이 아니면 밝힌다 — 'Rev를 올림'·'편집이 되돌려짐'이 메일에 없었다 (검토47 C 중간 3)
    def _why(d):
        w = str(d.get("resolved_by") or "")
        w = w.split("자동 해소 — ", 1)[1] if w.startswith("자동 해소 — ") else ""
        return "" if (not w or w.startswith("다시 검사했을 때")) else f' <span style="color:#57606a">({_esc(w)})</span>'
    lis = "".join(
        f'<li>{_esc(CODE_LABEL.get(d["code"], d["code"]))} — <code>{_esc(PurePosixPath(d["path"]).name)}</code>{_why(d)}</li>'
        for d in resolved[:5])
    more = f'<li style="color:#57606a">외 {len(resolved) - 5}건</li>' if len(resolved) > 5 else ""
    return (f'<div style="border-left:4px solid #1a7f37;padding:6px 12px;margin:0 0 12px;background:#f0fff4">'
            f'<b style="color:#1a7f37">해소된 확인 필요 {len(resolved)}건</b>'
            f'<span style="color:#57606a;font-size:13px"> — 다시 검사했을 때 더 이상 나오지 않습니다 (파일이 바뀜 — 고친 것인지 옛 판으로 되돌아간 것인지는 아래 변경에서)</span>'
            f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}{more}</ul></div>')


def _still_open_line(still_open: list, compact: bool = False) -> str:
    """오늘 관련 파일을 고쳤는데도 아직 열린 불일치와 **지금** 근거 — 무엇이 남았는지 메일에서 바로 보이게 (구매자 평가 P3 차단 1).
    compact(메일 판): 근거 줄의 서버 경로는 파일 이름으로."""
    from watcher.consistency import CODE_LABEL
    lis = []
    for _proj, code, msg, ev, since in still_open[:6]:
        evs = "".join(f'<div style="color:#57606a">{_esc(short_paths(human_ev(e)) if compact else human_ev(e))}</div>' for e in ev)
        lis.append(f'<li><b>{_esc(CODE_LABEL.get(code, code))}</b> — {_esc(msg)}'
                   f'<span style="color:#57606a"> ({_esc(_kdate(since))}부터 열림)</span>{evs}</li>')
    more = f'<li style="color:#57606a">외 {len(still_open) - 6}건</li>' if len(still_open) > 6 else ""
    return (f'<div style="border-left:4px solid #cf222e;padding:6px 12px;margin:0 0 12px;background:#fff8f8">'
            f'<b style="color:#cf222e">관련 파일이 바뀌었지만 아직 열린 불일치 {len(still_open)}건</b>'   # 무관한 편집도 '고쳤는데'였다 (검토49 C 낮음 13)
            f'<span style="color:#57606a;font-size:13px"> — 오늘 관련 파일이 바뀌었지만 아직 어긋난 곳이 남았습니다. 지금 근거:</span>'
            f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px;overflow-wrap:anywhere">{"".join(lis)}{more}</ul></div>')


def _continued_line(continued: list) -> str:
    """열려 있던 경고의 파일이 오늘 또 바뀌었다 — 메일은 새로 잡힌 것만 실어, 발행 전에 Rev를 안 올린 채 이틀째 고치는
    신호가 메일에서 사라졌다 (검토43 C 중간 1). 근거는 화면의 그 경고에 날짜별로 쌓인다."""
    from watcher.consistency import CODE_LABEL
    lis = []
    for path, code, _proj, since in continued[:8]:
        try:
            d = datetime.fromisoformat(str(since)).astimezone().strftime("%m-%d")
        except (TypeError, ValueError):
            d = "앞서"
        lis.append(f'<li><code>{_esc(PurePosixPath(path).name)}</code> — {_esc(CODE_LABEL.get(code, code))} '
                   f'({_esc(d)}부터 열림) — 오늘 또 바뀜</li>')
    more = f'<li style="color:#57606a">외 {len(continued) - 8}건</li>' if len(continued) > 8 else ""
    return (f'<div style="border-left:4px solid #bf8700;padding:6px 12px;margin:0 0 12px;background:#fff8e5">'
            f'<b style="color:#9a6700">이어진 검토 {len(continued)}건</b>'
            f'<span style="color:#57606a;font-size:13px"> — 열려 있던 경고의 파일이 오늘 또 바뀌었습니다 '
            f'(근거는 화면의 그 경고에 날짜별로 쌓입니다)</span>'
            f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{"".join(lis)}{more}</ul></div>')


def _backlog_line(open_backlog, shown: int, ack_base: str | None, project: str | None = None,
                  hide_age: bool = False) -> str:
    """이 메일 밖에 열려 있는 검토 필요 — 오늘 실린 것만이 전부면 말하지 않는다.
    수는 **이 프로젝트** 것이다 — 문장에 없고 링크가 전체 목록(16건)으로 가 '9건'과 어긋났다 (검토37 B 중간 1)."""
    from urllib.parse import quote as _q
    n, days = open_backlog
    if n <= shown:
        return ""
    href = f"{ack_base}/issues" + (f"?p={_q(project)}" if project else "")
    where = (f'<a href="{_esc(href)}" style="color:#0969da">감시 PC 화면의 확인 필요 목록</a>'
             if (ack_base and not _loopback(ack_base)) else "감시 PC 화면의 '확인 필요 목록'")   # 검토50 B 중간 5
    # 시계가 튄 날은 'N일째'가 틀린다 (검토45 C 중간 2). 7일이 넘으면 매일 하나씩 커지는 숫자라 소음 — 주간 요약 첫 문장이 말한다
    # (구매 평가 2차 P2: '가장 오래된 것 14일째')
    age = f" · 가장 오래된 것 {days}일째" if 1 <= days <= 7 and not hide_age else ""
    whose = "이 프로젝트의 " if project else ""
    # 새로 실린 것이 없는 메일에 '새로 잡힌 것만 싣습니다'는 어색했다 (검토37 B 중간 3)
    note = ("이 메일에는 새로 잡힌 것만 싣습니다" if shown else "오늘 새로 잡힌 확인 필요는 없습니다")
    return (f'<p style="color:#9a6700;margin:0 0 12px">{whose}열려 있는 확인 필요 누적 <b>{n}건</b>{age}'
            f' — {note}. 모두 {where}에서 봅니다.</p>')


_BODY_RE = re.compile(r"<body[^>]*>(.*)</body>", re.S | re.I)


# 하루 한 통에서 프로젝트마다 똑같이 반복되던 문구 — 맨 위·아래에 한 번만 싣는다 (재검토 rr066 mail 2: 10곳이면 157KB로 Gmail 102KB를
# 넘어 7번째 프로젝트부터 잘렸다). 위: 회신·사내망 안내, 사진 범례, 확인 안내 / 아래: 검사 시각·감시 폴더 줄, 휴대폰 안내, 꼬리말
_DG_LEGEND = re.compile(r"<!--drev-legend-->.*?<!--/drev-legend-->", re.S)
_DG_ACKNOTE = re.compile(r'<p style="color:#57606a;font-size:12px;margin:0 0 8px">(?:감시 PC 화면 › 고급 › 변경 이력|감시 PC에서는 <a ).*?</p>', re.S)
_DG_STAMP = re.compile(r'<p style="color:#57606a;margin:24px 0 4px;font-size:13px">.*?</p>', re.S)
_DG_PHONE = re.compile(r'<p style="color:#57606a;font-size:13px;margin:0 0 12px">휴대폰·다른 PC에서 보셨다면.*?</p>', re.S)
_DG_LEGEND_PHOTO = re.compile(r"<!--drev-legend--><p[^>]*>사진의 빨간 네모가 바뀐 자리입니다.*?<!--/drev-legend-->", re.S)
_DG_SHARED = re.compile(r"<!--drev-shared-->.*?<!--/drev-shared-->", re.S)   # 공용 폴더 변경 줄 — 통 맨 아래 한 번 (pv2 B-4)
_DG_FOOTER = re.compile(r'<p style="color:#57606a;font-size:12px;margin-top:12px">\s*Drev — 읽기 전용 감시\..*?</p>', re.S)
# 반복 인라인 스타일 줄이기 — 칸마다 붙던 줄바꿈 규칙(상속되는 속성)은 섹션 상자 하나에, 머리 칸의 배경·색·정렬은 머리 줄(tr) 하나에
_STYLE_TD_SLIM = "padding:6px 10px;border-bottom:1px solid #d0d7de"
_STYLE_TH_SLIM = "padding:6px 10px;border-bottom:2px solid #d0d7de;white-space:nowrap"
_TH_ROW = re.compile(r'<tr>((?:<th style="' + re.escape(_STYLE_TH) + r'">[^<]*</th>)+)</tr>')


def _hoist(secs: list, rx, pick_longest: bool = False) -> tuple:
    """섹션들에서 rx에 맞는 조각을 빼고 한 번 실을 조각을 돌려준다. 모든 조각이 같을 때만(pick_longest면 가장 긴 것 —
    꼬리말처럼 한쪽이 다른 쪽을 품는 것). 섹션마다 다른 내용(합산 안내가 붙은 검사 시각 줄 등)은 제자리에 둔다."""
    found = [m.group(0) for s in secs for m in rx.finditer(s)]
    if not found:
        return secs, ""
    if len(set(found)) > 1 and not pick_longest:
        return secs, ""
    keep = max(found, key=len)
    return [rx.sub("", s) for s in secs], keep


def _slim_section(inner: str) -> str:
    inner = re.sub(r"\n\s*", "\n", inner)                       # 들여쓰기·빈 줄 (태그 사이 공백은 한 칸으로 남는다)
    # 글자 바꾸기는 split/join으로 — 읽기 전용 검사(test_readonly)가 .replace 호출(Path.replace와 같은 이름)을 막는다
    inner = _STYLE_TD_SLIM.join(inner.split(_STYLE_TD))
    inner = _TH_ROW.sub(lambda m: ('<tr style="text-align:left;background:#f6f8fa;color:#57606a">'
                                   + f'<th style="{_STYLE_TH_SLIM}">'.join(m.group(1).split(f'<th style="{_STYLE_TH}">'))
                                   + '</tr>'), inner)
    return inner


# 메일 3판 섹션 표식 — 프로젝트 통(_mail_doc)의 몸·수·맨 아래 작은 글. 하루 묶음은 몸만 떼어 엮고 맨 아래 글은 한 번만
_DG3_ROWS = re.compile(r"<!--drev-rows-->(.*?)<!--/drev-rows-->", re.S)
_DG3_COUNT = re.compile(r"<!--drev-count iss=(\d+) chg=(\d+)(?: sh=(\d+))?-->")
_DG3_STAMP = re.compile(r"<!--drev-stamp-->.*?<!--/drev-stamp-->", re.S)
_DG3_TOP = re.compile(r"<!--drev-top-->.*?<!--/drev-top-->", re.S)
_DG3_FOOT = re.compile(r"<!--drev-foot-->.*?<!--/drev-foot-->", re.S)


def _dg_row(html_: str) -> str:
    """옛 꼴 조각(<p>·<div>)을 메일 3판 틀의 한 줄로."""
    return f'<tr><td style="padding:2px 4px 6px;font-size:13px;color:#4A5363">{html_}</td></tr>' if html_ else ""


def digest_brief(parts: list, run_at: datetime, title: str, part: tuple | None = None, notes="") -> str:
    """하루 묶음 메일 — 프로젝트별 브리핑(문서 전체)을 한 통에 프로젝트 섹션으로 잇는다 (기능 검토 2026-11-02 M1).
    parts: [(프로젝트, 브리핑 HTML)]. 메일 3판(2026-11-20): 머리 띠 한 번 → 프로젝트 목차 카드(확인 필요·바뀐 파일 수) → 프로젝트마다
    제목 + 그 통의 몸(요약·확인 필요·바뀐 내용·사진) → 공용 폴더 카드 한 번 → 맨 아래 작은 글 한 번. 섹션마다 반복되던 안내·꼬리말은
    한 번만 (rr066 mail 2). 기준선 통처럼 옛 꼴로 만든 섹션은 흰 상자에 그대로 싣고 반복 인라인 스타일만 줄인다.
    part=(k, n): 한 통이 커서 n통으로 나눈 k번째. notes: 한 프로젝트 것이 아닌 읽지 못한 파일 안내 — 목차 바로 아래 한 번 (ux27 K3).
    [(경로, 오류)] 목록이면 메일 3판 알림으로, 글(HTML)이면 그대로."""
    toc, secs, new3 = [], [], []
    for k, (proj, doc) in enumerate(parts):
        doc = doc or ""
        if "<!--drev-mail3-->" in doc:
            m = _DG3_ROWS.search(doc)
            cm = _DG3_COUNT.search(doc)
            secs.append(m.group(1) if m else "")
            new3.append(True)
            toc.append((k, str(proj or "미분류"), (int(cm.group(1)), int(cm.group(2)), int(cm.group(3) or 0)) if cm else None))
            continue
        m = _BODY_RE.search(doc)
        inner = m.group(1) if m else doc
        # 프로젝트마다 목차 고리(#chg0…)가 같은 이름이라 둘째 프로젝트 목차가 첫 프로젝트로 뛰었다 — 섹션마다 앞에 붙인다
        inner = re.sub(r'(id="|href="#)(chg\d)', lambda mm: f"{mm.group(1)}dg{k}{mm.group(2)}", inner)
        h = re.search(r"<h2[^>]*>(.*?)</h2>", inner, re.S)
        label = " ".join(re.sub(r"<[^>]+>", "", h.group(1)).split()) if h else str(proj or "미분류")
        toc.append((k, html.unescape(label), None))
        secs.append(_slim_section(inner))
        new3.append(False)

    def _sub(want_new: bool, rx, pick_longest: bool = False) -> str:
        idx = [k for k, n3 in enumerate(new3) if n3 == want_new]
        got, keep = _hoist([secs[k] for k in idx], rx, pick_longest)
        for k, s_ in zip(idx, got):
            secs[k] = s_
        return keep
    top3 = _sub(True, _DG3_TOP)
    stamp3 = _sub(True, _DG3_STAMP)
    foot3 = _sub(True, _DG3_FOOT, pick_longest=True)
    top = []
    for line in (REPLY_LINE, LAN_ACK_LINE, LAN_VIEW_LINE):
        if any(line in secs[k] for k in range(len(secs)) if not new3[k]):
            for k in range(len(secs)):
                if not new3[k]:
                    secs[k] = "".join(secs[k].split(line))
            if line not in top3:
                top.append(line)
    legend = _sub(False, _DG_LEGEND)
    if not legend:
        # 한 곳에만 '사진은 N장만 실었습니다'가 붙은 날도 프로젝트마다 같은 사진 설명은 한 번 (2026-11-17 R4 — 반복 안내 줄이기)
        legend = _sub(False, _DG_LEGEND_PHOTO)
    acknote = _sub(False, _DG_ACKNOTE)
    stamp = _sub(False, _DG_STAMP)
    phone = _sub(False, _DG_PHONE)
    footer = _sub(False, _DG_FOOTER, pick_longest=True)
    secs, shared = _hoist(secs, _DG_SHARED)

    left = (f'<span style="font-size:18px;color:#CDD2DC;vertical-align:middle"> &nbsp;·&nbsp; </span>'
            f'<span style="font-size:18px;font-weight:800;color:#111827;vertical-align:middle">프로젝트 {len(parts)}곳</span>')
    toc_rows = []
    for k, label, cnt in toc:
        nm = f'<a href="#dg{k}" style="color:#111827;font-weight:700;text-decoration:none">{_esc(label)}</a>'
        if cnt is None:
            toc_rows.append("<tr>" + _m_td(nm, extra=_M_EDGE_L + ";" + _M_EDGE_R, attrs=' colspan="3"') + "</tr>")
            continue
        n_iss, n_chg, n_sh = cnt
        # 공용 폴더 확인 필요는 그 프로젝트 수에 섞지 않고 '+ 공용 폴더 N건' — 요약 카드와 같은 수 (검토 Y3 L5)
        more = (f'<div style="font-size:13px;color:#4A5363;font-weight:700">{_esc(shared_more(n_sh))}</div>' if n_sh else "")
        toc_rows.append("<tr>" + _m_td(nm, extra=_M_EDGE_L)
                        + _m_td(f'<span style="color:{"#C8281E" if n_iss else "#4A5363"};font-weight:700">{n_iss}건</span>{more}')
                        + _m_td(f'<span style="color:#2B3341;font-weight:700">{n_chg}개</span>', extra=_M_EDGE_R) + "</tr>")
    toc_card = _m_card(_m_card_head("오늘 바뀐 프로젝트", f' <span style="color:#111827">{len(parts)}곳</span>'),
                       _m_table([("프로젝트", ""), ("확인 필요", "width:96px"), ("바뀐 파일", "width:96px")], toc_rows))
    if isinstance(notes, (list, tuple)):
        notes_html = _m_extra_boxes(scan_errors=list(notes), rejudged=None, continued=None, still_open=None, resolved=None,
                                    clock_note=None, alias_note=None, gap_note=None, rollback_note=None, wipe_txt="")[0]
    else:
        notes_html = _m_row(notes) if notes else ""
    body = []
    for k, s_ in enumerate(secs):
        if new3[k]:
            body.append(f'<tr><td id="dg{k}" style="padding:10px 2px 12px"><h2 style="margin:0;font-size:22px;font-weight:800;'
                        f'color:#111827;line-height:1.3">{_esc(toc[k][1])}</h2></td></tr>{s_}')
        else:
            body.append(_m_row(f'<div id="dg{k}" style="background:#FFFFFF;border:1px solid #E3E6EC;border-radius:12px;'
                               f'padding:18px 20px;font-family:{_MC_FONT};color:#1f2328;overflow-wrap:anywhere;'
                               f'word-break:keep-all">{s_}</div>'))
    _rest = (" 나머지 프로젝트는 같은 제목의 다른 통에 있습니다(한 통이 커서 메일 앱이 뒤쪽을 자르지 않게 나눴습니다)."
             if part else "")
    _part = f" part={part[0]}/{part[1]}" if part else ""
    tail = (_dg_row(legend) + _dg_row(acknote) + shared + stamp3 + _dg_row(stamp) + _dg_row(phone)
            + top3 + "".join(_dg_row(x) for x in top)
            + _dg_row(f'{_esc(run_at.strftime("%Y-%m-%d %H:%M"))} 검사 — 프로젝트 {len(parts)}곳을 한 통에 모았습니다. 프로젝트별 '
                      f'담당이 정해진 프로젝트와, BOM·발주서가 바뀌어 구매 담당도 받는 날의 프로젝트는 따로 갑니다.{_rest}')
            + foot3 + _dg_row(footer))
    doc = _mail_doc(_m_head_band(left, _esc(_m_when(run_at))), notes_html + toc_card + "\n".join(body) + tail,
                    run_at.strftime("%Y-%m-%d %H:%M"))
    # 머리: 묶음 표식(앞 200자 안)·문서 제목은 메일 제목. 프로젝트 통 표식(drev-mail3·drev-count)은 묶음에 다시 싣지 않는다
    doc = "".join(doc.split("<!--drev-mail3--><!--drev-count iss=0 chg=0-->"))       # 묶음 틀은 count=(0, 0) — sh 없음
    doc = re.sub(r"<title>.*?</title>", lambda _m: f"<title>{_esc(title)}</title>", doc, count=1)
    return f"<!DOCTYPE html>\n<!--drev-digest n={len(parts)}{_part}-->\n" + doc[len("<!DOCTYPE html>\n"):]


def brief_filename(run_at: datetime, project: str | None = None,
                   baseline: bool = False) -> str:
    # 표제란에서 온 프로젝트 문자열이 그대로 들어온다 — 경로 구분자·Windows 금지
    # 문자를 소독하지 않으면 파일 생성이 죽거나 brief_dir 밖에 쓰게 된다
    if project:
        # 띄어쓰기는 그대로 — 제목 '[PJ-2604 재저장]'과 파일 이름 'PJ-2604_재저장'이 따로 놀았다 (검토71 R4 낮음 12)
        safe = re.sub(r'[\\/:*?"<>|.]+', "_", project)
        safe = re.sub(r"\s+", " ", safe).strip("_ ") or "무명"
        suffix = f"_{safe}"
    else:
        suffix = ""
    # 기준선(첫 검사) 브리핑은 이름을 따로 둔다 — 같은 날 실제 변경 브리핑이 그 날 파일을
    # 쓰고, 재검사 때 합쳐 갱신할 수 있게 (2026-09-05 재검토)
    if baseline:
        suffix += "_기준선"
    return f"brief_{run_at.strftime('%Y%m%d')}{suffix}.html"


# ── 메일 압축·머리 한 줄 (구매 평가 2차 F2, 2026-10-19) ─────────────────────────────────────────────────────────────
# 설계팀장 2주 평가(P2)가 메일을 '팀원이 2주 뒤 버릴 것'으로 봤다: 변경 5건 메일이 136~156줄·사진 18장·7,000px 스크롤, 같은 도면의
# DXF와 출도 PDF가 같은 변경을 두 번 싣고, 표제란 DATE·REV 칸마다 사진, 사진마다 같은 설명 줄. 메일 판(photo_budget)만 줄인다 —
# 디스크 브리핑·화면은 그대로 전부(기록). 어떤 변경도 메일에서 빠지지 않는다: 줄인 것은 **한 줄**로 남긴다(원칙 5).
_MAIL_PHOTOS_PER_CHANGE = 1          # 변경 한 건당 사진(전/후 한 쌍) — 나머지는 화면
_MAIL_ROWS_PER_CHANGE = 12           # 변경 한 건의 글자·그림 표 줄 상한 — 나머지는 '외 N건'(표 행은 _DETAIL_CAP 그대로)
REVSAME_HINT = "(발행 전 작업본이면 무시하세요 — 발행 시 Rev를 올리면 해소됩니다)"


def _ntok(s) -> list:
    return " ".join(str(s or "").split()).split()


_VAL_UNIT = re.compile(r"^([-+]?\d[\d.,]*)([A-Za-z㎾㎟℃°%/Ωμ][A-Za-z0-9㎾㎟℃°%/Ωμ.]*)$")


def short_pair(old, new, limit: int = 40, was: bool = False) -> str:
    """'100AF 75AT 3P'→'100AF 100AT 3P' ⇒ '75→100AT', '3.7kW 4P 380V'→'5.5kW 4P 380V' ⇒ '3.7→5.5kW' — 바뀐 낱말만.
    사장·구매가 읽는 머리 한 줄·제목용. 바뀐 곳이 여러 군데면 앞뒤 전체(길면 낱말 경계에서 자름).
    was: 화살표 대신 '지금(이전 …)' — '100AT(이전 75AT)'·'5.5kW(이전 3.7kW)' (메일 머리 한 줄, 2026-11-21 사용자 '화살표 빼고는 구분이 안 된다')."""
    from difflib import SequenceMatcher
    ot, nt = _ntok(old), _ntok(new)
    if not ot or not nt:
        return cut_words(" ".join(nt or ot), limit)
    ops = [op for op in SequenceMatcher(None, ot, nt, autojunk=False).get_opcodes() if op[0] != "equal"]

    def _pv(a, b):
        return f"{b}(이전 {a})" if was else f"{a}→{b}"

    def _one(i1, i2, j1, j2):
        a, b = " ".join(ot[i1:i2]).strip(",;"), " ".join(nt[j1:j2]).strip(",;")
        ma, mb = _VAL_UNIT.match(a), _VAL_UNIT.match(b)
        if ma and mb and ma.group(2) == mb.group(2):
            u = ma.group(2)
            return _pv(ma.group(1) + u, mb.group(1) + u) if was else f"{ma.group(1)}→{mb.group(1)}{u}"
        # 단위가 따로 선 값('56 rpm'→'45 rpm')은 바뀐 숫자 뒤에 같은 단위를 붙인다
        if re.fullmatch(r"[-+]?\d[\d.,/]*", a) and re.fullmatch(r"[-+]?\d[\d.,/]*", b) and j2 < len(nt) \
                and i2 < len(ot) and ot[i2] == nt[j2] and re.fullmatch(r"[A-Za-z㎾%℃°]{1,5}", nt[j2].strip(",;")):
            u = nt[j2].strip(',;')
            return _pv(f"{a}{u}", f"{b}{u}") if was else f"{a}→{b}{u}"
        return _pv(a, b)
    if ops and len(ops) <= 3 and all(op[0] == "replace" for op in ops):
        s = ", ".join(_one(i1, i2, j1, j2) for _t, i1, i2, j1, j2 in ops)
        if len(s) <= limit + (12 if was else 0):
            return s
    return _pv(cut_words(" ".join(ot), limit // 2), cut_words(" ".join(nt), limit // 2))


def cut_words(s: str, n: int) -> str:
    """n자 안에서 **낱말 경계**로 자른다 — '3.7kW 4…'·'M-1…'처럼 낱말 가운데서 끊겨 엉뚱한 값으로 읽혔다 (P2 제목)."""
    s = " ".join(str(s or "").split())
    if len(s) <= n:
        return s
    cut = s.rfind(" ", 0, n)
    if cut < max(4, n // 3):
        return s[:n - 1].rstrip(" ,;·—-") + "…"
    return s[:cut].rstrip(" ,;·—-") + "…"


def _short_no(dwg: str | None, project: str | None) -> str:
    """도면번호에서 프로젝트 앞말을 뗀 짧은 이름 — 'HB26-003-E-002' → 'E-002' (제목·머리 한 줄용)."""
    d = str(dwg or "").split(" (")[0].strip()
    p = str(project or "").split()[0] if project else ""
    if p and d.upper().startswith((p.upper() + "-", p.upper() + "_")) and len(d) > len(p) + 1:
        return d[len(p) + 1:]
    return d


def _facts_of(c, items) -> list:
    """변경 한 건에서 사람에게 말할 값 변화 [(태그|None, 짧은 변화, 무게, 짧은 변화 '지금(이전 …)' 꼴)] — 짝 이름표 > 단위 든 글줄 > 표 행.
    둘째 칸(화살표 꼴)은 같은 변화 묶기·발주 표지 대조에 그대로 쓰고, 넷째 칸은 메일 머리 한 줄에 보일 때만 (2026-11-21)."""
    out, seen = [], set()
    for it in items:
        lab = pair_label(it)
        if lab:
            for part in lab.split("; "):
                if part in seen:
                    continue
                seen.add(part)
                tag, _, rest = part.partition(": ")
                if " → " in rest:
                    o, n = rest.split(" → ", 1)
                    out.append((tag, short_pair(o, n), 0, short_pair(o, n, was=True)))
                elif rest.endswith("(새로)"):
                    t = cut_words(rest[:-4].strip(), 24) + " 새로"
                    out.append((tag, t, 1, t))
                elif part.endswith("태그 추가"):
                    out.append((part[:-6].strip(), "태그 추가", 1, "태그 추가"))
    for it in items:
        if pair_label(it):
            continue
        if it.kind == "TEXT_CHANGED" and it.old and it.new and _UNIT_RE.search(f"{it.old} {it.new}"):
            from watcher.extract.base import find_tags
            tg = find_tags(str(it.new))
            out.append((tg[0] if len(tg) == 1 else None, short_pair(it.old, it.new), 0, short_pair(it.old, it.new, was=True)))
        elif it.kind == "ROW_CHANGED" and it.old is not None and it.new is not None:
            rk, sep, col = split_row_cell(it.key)
            # 사양 칸(규격·SPEC)은 칸 이름 없이 — 도면의 같은 값 변화와 한 줄로 묶이게 ('E-002·BOM M-102 2.2→3.7kW')
            _spec_col = bool(re.fullmatch(r"(?i)\s*(규격|사양|SPEC\.?|SPECIFICATION|RATING|정격|용량|MODEL|형식)\s*", col or ""))
            pre = "" if (_spec_col or not sep) else f"{col} "
            o_, n_ = _group_digits(str(it.old)), _group_digits(str(it.new))
            out.append((rk if sep else str(it.key), pre + short_pair(o_, n_), 0, pre + short_pair(o_, n_, was=True)))
    return out


def _rev_of(items, was: bool = False) -> str:
    from watcher.diff import _blank_rev, is_rev_field
    rv = next((it for it in items if is_rev_field(it)), None)
    if rv is None:
        return ""
    if _blank_rev(rv.old):
        return f"Rev {rv.new} 첫 기재"
    return f"Rev {rv.new}(이전 {rv.old})" if was else f"Rev {rv.old}→{rv.new}"


def mail_headline(main: list, issues: list, details: dict | None, doc_info: dict | None,
                  details_by_id: dict | None = None, project: str | None = None,
                  ordered_tags: set | None = None, was: bool = False) -> tuple[str, str]:
    """메일 맨 위 사장·구매용 한 줄과 제목용 짧은 말 — (문장, 짧은 말). 할 말이 없으면 ("", "").
    레이어·좌표·서버 경로 같은 기술 문구는 넣지 않는다(아래 근거에 있다). 예: 'E-101 M-101 7.5→11kW, Rev 안 올림, BOM은 아직
    7.5kW — 발주 전 확인' (구매 평가 2차 P1·P2).
    ordered_tags: 이 프로젝트 발주서에 오른 태그·품번(접은 꼴). None이면 모름 — 그때는 변경에 달린 표지만 본다.
    was: 값 변화를 화살표 대신 '지금(이전 …)'으로 — 'M-101 11kW(이전 7.5kW)', 'Rev B(이전 A)' (2026-11-21). 사람 눈에 닿는 곳은 모두
    was=True로 부른다: 메일 3판 요약 카드·디스크 브리핑 머리 한 줄(build_brief)·메일 제목의 짧은 말(cli — 'M-301 7.5kW(이전 5.5kW), BOM
    그대로', 구현자 L). 기본값(화살표 꼴)은 같은 변화 묶기 등 내부 대조와 옛 호출용."""
    details = details or {}

    def info_of(c):
        return (doc_info or {}).get(c.id) or (doc_info or {}).get(c.path) or {}

    def _folder_tail(c) -> str:
        # 같은 이름 파일이 프로젝트 안에 또 있으면(작업중_사본/·구판/) 어느 폴더 것인지 — 원본이 바뀐 줄 알았다 (ux20 daily 1)
        f_ = ((doc_info or {}).get(c.id) or {}).get("folder") or ((doc_info or {}).get(c.path) or {}).get("folder")
        return f" ({f_} 폴더)" if f_ else ""

    def _base_name(c):
        return (_short_no(info_of(c).get("dwg"), project) or _short_no(PurePosixPath(c.path).stem, project)) + _folder_tail(c)

    def _doc_word(c, nm: str) -> str:
        # '도면 E-101'처럼 문서 종류를 앞에 — 'E-101 M-101 …'이 도면번호와 태그가 붙어 오타처럼 읽혔다 (ux20 mail 5)
        try:
            from watcher.doctype import canonical as _can, kind_of as _ko
            k = _can(_ko(c.path, None) or "")
        except Exception:               # noqa: BLE001
            k = ""
        if k == "도면" and not info_of(c).get("dwg") and PurePosixPath(c.path).suffix.lower() not in (".dxf", ".dwg"):
            return nm                    # 도면번호 없는 PDF는 사양서·보고서일 수 있다 — 종류를 짐작해 붙이지 않는다
        return f"{k} {nm}" if k and k not in ("기타", "문서") and k.casefold() not in nm.casefold() else nm

    def name_of(c):
        # 같은 도면번호의 DXF와 PDF가 함께 바뀐 날은 어느 쪽인지 — 'E-9040'만으로는 Rev를 안 올린 쪽이 출도 PDF인지 몰랐다
        nm = _base_name(c)
        if any(o is not c and _base_name(o) == nm and PurePosixPath(o.path).suffix.lower() != PurePosixPath(c.path).suffix.lower()
               for o in main):
            nm += f"({PurePosixPath(c.path).suffix.lstrip('.').upper()})"
        return nm
    facts = []           # (태그, 변화, 무게, 변경, 보일 변화) — 보일 변화는 was면 '지금(이전 …)' 꼴
    for c in main:
        for tag, ch, w, chw in _facts_of(c, items_for(c, details, details_by_id)):
            facts.append((tag, ch, w, c, chw if was else ch))
    rev_same = {i.path for i in issues if i.code == "CONTENT_CHANGED_REV_SAME"}

    def _rev_state(c) -> str:
        if c.path in rev_same:
            return "Rev 안 올림"
        return _rev_of(items_for(c, details, details_by_id), was)

    def _fact_phrase(tag) -> tuple[str, str]:
        hit = [f for f in facts if f[0] == tag]
        if not hit:
            return "", ""
        ch = hit[0][1]
        shown = hit[0][4]
        _hc = list(dict.fromkeys(id(f[3]) for f in hit if f[1] == ch))
        _cs = {id(f[3]): f[3] for f in hit}
        docs = list(dict.fromkeys(_base_name(_cs[k]) for k in _hc))
        revs = list(dict.fromkeys(r for r in (_rev_state(f[3]) for f in hit if f[1] == ch) if r))
        if len(revs) > 1 and "Rev 안 올림" not in revs:
            revs = ["Rev 올림"]            # 문서마다 다른 'Rev B→C·Rev A→B'는 한 말로
        where = "·".join(docs[:3]) + (" 외" if len(docs) > 3 else "")
        if docs:                         # 첫 문서에 종류 낱말 — '도면 E-101·BOM_전장: M-101 5.5→7.5kW' (ux20 mail 5)
            where = _doc_word(_cs[_hc[0]], docs[0]) + where[len(docs[0]):]
        # 문서 이름과 태그 사이에 ':' — 'E-101·BOM_전장 M-101 5.5→7.5kW'가 한 낱말처럼 붙어 읽혔다
        return f"{where}: {tag} {shown}" + (f", {'·'.join(revs[:2])}" if revs else ""), f"{tag} {shown}"

    def _po_close(tag, fact=None, before: str = "발주 전 확인") -> str:
        """머리 한 줄의 끝말 — 이미 발주된 품목에 '발주 전 확인'이라 했다. 같은 메일 아래에는 '발주 후 변경' 표지가 있었다 (ux24 RD1).
        표지 판정은 다시 하지 않고 검사(issued.po_mark_changes)가 변경에 남긴 표지를 읽는다. 한 변경에 태그가 여럿이면 표지가 어느
        태그 것인지 가린다 — 표지의 태그(label)가 그 태그이거나 표지 줄에 그 값 변화가 있어야 그 태그의 표지다. 발주서에 있다는 것만으로는
        아니다: M-101은 발주서 값으로 돌아왔고 표지는 같은 변경의 MCCB-11 것인데 '발주 후 변경'이라 했다 (ux25 E4). 발주서에는 있는데
        그 태그의 표지가 없으면(발주서 값과 같아진 변경, 값 변화가 오늘 없는 불일치) '발주 후 변경'은 아니지만 '발주 전'도 아니다."""
        from watcher.issued import _fold
        key = re.sub(r"\s+", "", _fold(tag)) if tag else ""
        on_po = bool(key) and key in (ordered_tags or ())
        hits = [f for f in facts if key and f[0] and re.sub(r"\s+", "", _fold(f[0])) == key] or ([fact] if fact else [])
        for f in hits:
            for it in items_for(f[3], details, details_by_id):
                if _is_po_mark(it) and (not key or re.sub(r"\s+", "", _fold(getattr(it, "label", ""))) == key
                                        or f[1] in str(getattr(it, "new", ""))):
                    return "발주 후 변경 — 업체 확인"
        return "이미 발주된 품목, 발주서 확인" if on_po else before

    tail = f" (확인 필요 {len(issues)}건)" if len(issues) > 1 else ""
    order = ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS", "CONTENT_CHANGED_REV_SAME", "REV_BLOCK_MISMATCH",
             "REV_REGRESSED", "REV_CHANGED_CONTENT_SAME")
    top = next((i for code in order for i in issues if i.code == code), None)
    if top is not None:
        if top.code in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS"):
            m = re.search(r"\]\s*(?:태그\s+)?([^\s:]+?)(?::|의 사양)", top.message)
            tag = m.group(1) if m else ""
            long_, short = _fact_phrase(tag) if tag else ("", "")
            if top.code == "BOM_MISMATCH":
                spec = next((mm.group(1) for e in top.evidence for mm in [re.match(r"BOM: \S+ SPEC=(.*?) \(", str(e))] if mm), "")
                bom_changed = any(f[0] == tag and PurePosixPath(f[3].path).suffix.lower() in (".xlsx", ".xlsm", ".xls")
                                  for f in facts)
                _close = _po_close(tag)
                if long_ and not bom_changed:
                    return (f"{long_}, BOM은 아직 {cut_words(spec, 24)} — {_close}{tail}",
                            f"{short}, BOM 그대로")
                if long_:
                    return f"{long_.strip()} — BOM이 도면 기재와 다름, {_close}{tail}", f"BOM {short}, 도면과 다름"
                return (f"{tag}: 도면과 BOM 사양이 다름 (BOM {cut_words(spec, 24)}) — {_close}{tail}",
                        f"{tag} 도면·BOM 사양 다름")
            vals = re.search(r"\(([^()]*vs[^()]*)\)", top.message)
            vs = vals.group(1) if vals else ""
            if long_:
                return f"{long_} — 다른 도면과 사양이 다름({vs}), 확인{tail}", f"{short}, 도면끼리 다름"
            return f"{tag} 도면끼리 사양이 다름 ({vs}) — 어느 쪽이 맞는지 확인{tail}", f"{tag} 도면끼리 사양 다름"
        c = next((c for c in main if c.path == top.path), None)
        nm = name_of(c) if c is not None else PurePosixPath(top.path).stem
        if top.code == "CONTENT_CHANGED_REV_SAME":
            f = next((f for f in facts if f[3] is c), None)
            what = (f"{f[0]} {f[4]}" if f[0] else f[4]) if f else ""
            if not what and c is not None:
                _wc_: dict = {}
                ent = _toc_entries([c], details, doc_info, False, details_by_id, was_out=_wc_)
                what = cut_words(_wc_.get(0, ent[0][2]) if was else ent[0][2], 36) if ent else ""
            # 이 Rev의 출도본이 있으면(문구에서 작업본 안내가 빠졌다 — cli._issued_rev_same) '출도 전'이 아니다 (ux24 RD6)
            _close = _po_close(f[0] if f else None, f, "출도·발주 전 확인" if "작업본" in top.message else "발주 전 확인")
            # 유예가 끝난 날에는 그 파일이 오늘 변경에 없어 what이 빈다 — 'E-101 단선도: , Rev 안 올림'의 빈 구두점 (ux26 WK2)
            _lead, _say = (f"{what}, Rev 안 올림", f" Rev 안 올림: {what}") if what else ("Rev 안 올림", " Rev 안 올림")
            return (" ".join(f"{_doc_word(c, nm) if c is not None else nm}: {_lead} — {_close}{tail}".split()),
                    " ".join(f"{nm}{_say}".split()))
        if top.code == "REV_BLOCK_MISMATCH":
            return f"{nm}: 표제란 Rev와 개정표가 다름 — 어느 쪽이 맞는지 확인{tail}", f"{nm} 표제란·개정표 Rev 다름"
        m = re.search(r"Rev가 (\S+?)→(\S+?)로", top.message)
        rv = ((f"Rev {m.group(2)}(이전 {m.group(1)})" if was else f"Rev {m.group(1)}→{m.group(2)}") if m else "Rev")
        if top.code == "REV_REGRESSED":
            return f"{nm}: {rv} 거꾸로 감 — 옛 판으로 덮어썼는지 확인{tail}", f"{nm} {rv} 거꾸로"
        return f"{nm}: {rv} 올렸는데 글자 변경 없음 — 그림만 고쳤는지 확인{tail}", f"{nm} {rv}, 글자 변경 없음"
    # 검토 필요가 없으면 가장 무거운 값 변화 하나 — 같은 값 변화가 여러 문서(DXF·PDF·BOM)에 있으면 한 줄로. 여러 문서에 걸친
    # 태그(도면·BOM이 함께 바뀐 모터)를 앞에
    _ndocs = Counter()
    for f in facts:
        if f[0]:
            _ndocs[f[0]] += 1
    best = sorted(facts, key=lambda f: (f[2], -_ndocs.get(f[0], 0) if f[0] else 0))
    if best:
        tag, _ch_key, _w, c, ch = best[0]
        if tag:
            long_, short = _fact_phrase(tag)
            # 같은 값 변화를 태그 없이 적은 출도 PDF·사양서는 '그 밖'이 아니다
            n_other = len({id(f[3]) for f in facts if f[0] != tag and not (f[0] is None and f[1] == _ch_key)})
            return (long_ + (f" (그 밖의 값 변화 {n_other}건)" if n_other else ""), short)
        rs = _rev_state(c)
        return f"{_doc_word(c, name_of(c))}: {ch}" + (f", {rs}" if rs else ""), f"{name_of(c)} {ch}"
    return "", ""


def wiped_folders(main: list, present_dirs, min_files: int = 3) -> list:
    """오늘 삭제된 파일 가운데, 등록 파일이 **하나도 안 남은** 가장 높은 폴더별 [(폴더, 삭제 수)] — 셋 이상만.
    present_dirs: 지금 스냅샷(이월 포함) 파일들의 모든 조상 폴더 (감시 폴더 자체는 세지 않는다 — 그건 대량 삭제 보류가 본다)."""
    out: dict = {}
    for c in main or []:
        if getattr(c, "kind", "") != "removed":
            continue
        parts = PurePosixPath(c.path).parent.parts
        for k in range(2, len(parts) + 1):          # parts[0]은 감시 폴더 이름표
            d = "/".join(parts[:k])
            if d not in present_dirs:
                out[d] = out.get(d, 0) + 1
                break
    return sorted(((d, n) for d, n in out.items() if n >= min_files), key=lambda x: (-x[1], x[0]))


def wiped_line(wiped: list | None) -> str:
    """'폴더 P26-031 컨베이어 전체(파일 26개)가 삭제됨' — 폴더가 여럿이면 앞 둘 + 외 N."""
    if not wiped:
        return ""
    parts = [f"폴더 '{PurePosixPath(d).name}' 전체(파일 {n}개)" for d, n in wiped[:2]]
    more = f" 외 폴더 {len(wiped) - 2}개" if len(wiped) > 2 else ""
    return f"{', '.join(parts)}{more}가 삭제됨"


def headline_html(text: str) -> str:
    """머리 한 줄 — 확인할 것이 있으면 붉은 띠, 아니면 회색 띠."""
    if not text:
        return ""
    act = "확인" in text
    return (f'<p style="font-size:16px;font-weight:700;margin:0 0 10px;padding:8px 12px;border-radius:6px;'
            f'background:{"#fff1e5" if act else "#f6f8fa"};border-left:5px solid {"#cf222e" if act else "#1d4ed8"}">'
            f'{_esc(text)}</p>')


def drawing_companions(main: list, doc_info: dict | None) -> dict:
    """같은 도면(같은 도면번호·같은 Rev·같은 변경 종류)의 DXF·DWG 변경과 출도 PDF 변경 짝 — {id(PDF 변경): DXF 변경}. 메일에서 PDF는
    DXF 밑에 한 줄로 붙인다(P2: 같은 변경이 DXF·PDF로 두 번, 사진 두 벌). 한쪽만 바뀌었으면 짝이 없다 — PDF가 그대로면 PDF 변경 자체가
    없고, DXF만 그대로면 PDF는 제 행으로 남는다."""
    def _key(c):
        i = (doc_info or {}).get(c.id) or (doc_info or {}).get(c.path) or {}
        d = str(i.get("dwg") or "").split(" (")[0].strip().upper()
        r = str(i.get("rev") or "").strip().upper()
        return (d, r, c.kind) if d and r else None
    cad: dict = {}
    for c in main:
        if PurePosixPath(c.path).suffix.lower() in (".dxf", ".dwg") and c.kind in ("modified", "added"):
            k = _key(c)
            if k is not None:
                cad.setdefault(k, []).append(c)
    out = {}
    for c in main:
        if PurePosixPath(c.path).suffix.lower() == ".pdf" and c.kind in ("modified", "added"):
            k = _key(c)
            if k is not None and len(cad.get(k, [])) == 1:
                out[id(c)] = cad[k][0]
    return out


_QUIET_GROUPS = (("복사본 정리", "복사본 정리 (원본은 그대로)"), ("구판 정리", "구판 정리 (현행은 그대로)"),
                 ("복사본", "복사본"), ("일자만 갱신", "표제란 일자만 갱신 (재출력)"),
                 ("표제란 틀만", "표제란 틀만 교체"), ("빈 파일", "빈 파일(0바이트)"), ("순서만 바뀜", "순서만 바뀜"),
                 ("재저장", "다시 저장 (내용 동일)"), ("내용 변경 없음", "다시 저장 (내용 동일)"))


def quiet_group(note: str) -> str:
    """'그 밖의 알림'을 메일에서 종류별 한 줄로 묶는 이름."""
    n = str(note or "")
    return next((lab for w, lab in _QUIET_GROUPS if w in n), cut_words(n.split(" — ")[0], 30) or "그 밖의 알림")


def short_paths(s: str) -> str:
    """근거 줄 괄호 안의 서버 경로 → 파일 이름 ('(BOM 시트 11행, 설계서버/…/03_BOM/HB26-003_BOM.xlsx)' →
    '(BOM 시트 11행, HB26-003_BOM.xlsx)'). 폴더 이름에 띄어쓰기·쉼표가 없다고 보지 않고, 괄호 안 쉼표 조각마다 마지막 '/' 뒤만
    남긴다 — 메일 판만 (디스크 브리핑·화면은 전체)."""
    # 괄호 끝(또는 쉼표 뒤)의 '폴더/…/파일.확장자)' — 폴더 이름에 괄호('02_출도(PDF)')·띄어쓰기가 있어도 마지막 '/' 뒤만.
    # 파일 이름(확장자)으로 끝나는 것만 — '감속비 1/25'·'2026/10/09'는 경로가 아니다
    return _EV_PATH.sub(r"\1\3)", str(s or ""))


_EV_PATH = re.compile(r"(, |\()([^,]*/)([^/,()]+\.[A-Za-z0-9]{2,5})\)")
