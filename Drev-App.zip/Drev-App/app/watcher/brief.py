# -*- coding: utf-8 -*-
"""변경 목록 → 일일 브리핑 HTML.

Stage 2: 파일 수준 변경(추가/수정/삭제)만 담는다.
Stage 3에서 "확인 필요 M건 + 근거" 섹션이 추가된다 (build_brief의 구조는 그걸 수용하게 잡아둠).
메일 클라이언트 호환을 위해 인라인 스타일의 단순 테이블만 쓴다.
"""

from __future__ import annotations

import html
import re
from datetime import datetime
from pathlib import PurePosixPath

from watcher.state import KIND_LABEL as _KIND_LABEL
from watcher.state import Change

_KIND_COLOR = {"added": "#1a7f37", "modified": "#9a6700", "removed": "#cf222e"}
# 사양 단위를 품은 값 — 목차에서 접지 않을 '중요한' 글자 변경의 표식
# 전장·기구 사양 단위 — AT·AF(차단기 정격)·mA·kVA·m/min·MP·Nm·W가 빠져 'MCCB 100AT→125AT'가 "글자 변경
# 1건"으로만 보이고 Rev만 올린 도면 아래로 깔렸다 (검토21 브리핑 중간 6)
_UNIT_RE = re.compile(r"\d\s*(?:kW|KW|kw|㎾|kVA|kVAR|kvar|HP|mA|AT|AF|A|V|VDC|VAC|Hz|W|Nm|N·m|mm|㎜|MM|m/min|mm/s|"
                      r"SQ|㎟|rpm|RPM|bar|MPa|kPa|kg|EA|MP|℃|°C|Ø|φ)(?![A-Za-z])")

_STYLE_TABLE = "border-collapse:collapse;width:100%;font-size:14px"
_STYLE_TH = ("text-align:left;padding:6px 10px;border-bottom:2px solid #d0d7de;"
             "background:#f6f8fa;color:#57606a")
_STYLE_TD = "padding:6px 10px;border-bottom:1px solid #d0d7de"


def _esc(s: str) -> str:
    return html.escape(s, quote=True)


# 오늘 꼭 봐야 할 변경이 아닌 알림(이동·복사본·재저장·빈 파일) — 화면과 메일이 같은 규칙으로
# 접는다 (2026-09-05 재검토: 화면 24건 / 메일 30행으로 숫자가 달랐다)
_QUIET_WORDS = ("이름·위치만", "옮겨짐", "복사본", "내용 변경 없음", "빈 파일", "재저장", "일자만 갱신")
_MOVE_MARK = "이름·위치만 바뀜 — 이전: "


def is_quiet(note: str) -> bool:
    """옮겨지며 내용도 바뀐 파일은 진짜 변경이라 접지 않는다 (2026-09-05 재검토 회귀)."""
    if not note:
        return False
    if "내용도 바뀜" in note or "그 판과 비교" in note or "(이름·폴더 변경)" in note:
        return False
    return any(w in note for w in _QUIET_WORDS)


def note_of(items) -> str:
    """변경 상세의 '참고' 문구(복사본·이동·빈 파일 …) — 없으면 빈 문자열."""
    for it in items or []:
        if getattr(it, "kind", None) == "CHECK_SKIPPED" and getattr(it, "key", None) == "참고":
            return str(it.new or "")
    return ""


def items_for(c, details: dict | None, details_by_id: dict | None = None):
    """변경 한 건의 상세 — 같은 파일이 하루에 두 번이면 변경 id별 상세가 우선.
    경로 키만 쓰면 나중 변경의 '재저장' 참고가 앞선 진짜 변경에 붙었다 (파일럿 모의 ①)."""
    if details_by_id and c.id is not None and c.id in details_by_id:
        return details_by_id[c.id]
    return (details or {}).get(c.path, [])


def change_weight(items) -> int:
    """변경의 무게 — 사양값(kW·A·mm…)이나 표 행 > Rev > 다른 글자·그림 > 날짜만.
    팀장은 위에서부터 읽는다 (파일럿 모의 ④: Rev만 오른 도면이 MCCB 변경보다 위에)."""
    has_row = any(it.kind.startswith("ROW_") for it in items)
    has_unit = any(it.kind.startswith("TEXT_") and _UNIT_RE.search(
        str(it.old or "") + " " + str(it.new or "")) for it in items)
    if has_row or has_unit:
        return 0
    if any(it.kind == "FIELD_CHANGED" and it.key == "REV" for it in items):
        return 1
    if any(it.kind.startswith(("TEXT_", "PAGE_VISUAL", "ROW_", "REVROW", "SHEET"))
           or (it.kind == "FIELD_CHANGED" and it.key not in ("DATE",)) for it in items):
        return 2
    return 3


def arrange_changes(changes, details: dict | None, details_by_id: dict | None = None):
    """브리핑 순서를 정한다 → (주요 변경, 그 밖의 알림, {경로: 이전 경로}).

    같은 지문의 '삭제 + 추가'(이름·위치 변경)는 추가 쪽 한 행으로 접고(이동), 복사본·재저장·
    빈 파일·이동은 '그 밖의 알림'으로 뒤에 둔다. 주요 변경은 수정 → 추가 → 삭제, 그 안에서
    변경의 무게(사양·표 > Rev > 글자·그림 > 날짜) → 유형 중요도 → 경로 순."""
    from watcher.doctype import doc_rank, kind_of
    details = details or {}
    notes = {id(c): note_of(items_for(c, details, details_by_id)) for c in changes}
    moved: dict[str, str] = {}
    hide: set = set()
    removed_by_path: dict[str, list] = {}
    for c in changes:
        if c.kind == "removed":
            removed_by_path.setdefault(c.path, []).append(c)
    for c in changes:
        n = notes.get(id(c), "")
        if c.kind == "added" and _MOVE_MARK in n:
            prev = n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
            for x in removed_by_path.get(prev, []):
                if id(x) not in hide:
                    hide.add(id(x))
                    moved[c.path] = prev
                    break
    # 옮겨지며 내용도 바뀐 파일(이름 짝)은 '추가' 쪽에 비교가 실린다 — 삭제 행까지 두면 한 파일이
    # "변경 2건"에 빨간 삭제 라벨로 나왔다 (검토21 브리핑 차단 3). 삭제 쪽은 접는다
    added_paths = {c.path for c in changes if c.kind == "added"}
    for c in changes:
        n = notes.get(id(c), "")
        if c.kind == "removed" and "옮겨지며 내용도 바뀜" in n:
            tgt = n.split("(으)로 옮겨지며", 1)[0].strip()
            if tgt in added_paths:
                hide.add(id(c))
    kept = [c for c in changes if id(c) not in hide]
    quiet = [c for c in kept if c.path in moved or is_quiet(notes.get(id(c), ""))]
    qids = {id(c) for c in quiet}
    order = {"modified": 0, "added": 1, "removed": 2}

    def _rank(c):
        try:
            r = doc_rank(kind_of(c.path, None))
        except Exception:
            r = 50
        # 같은 파일이 하루에 두 번이면 시간순(변경 id) — 최신이 위에 오면 A→B가 B→C 아래에 놓였다
        return (order.get(c.kind, 3), change_weight(items_for(c, details, details_by_id)),
                r, c.path.lower(), c.id or 0)
    main = sorted((c for c in kept if id(c) not in qids), key=_rank)
    return main, quiet, moved


def brief_counts(changes, details: dict | None, details_by_id: dict | None = None) -> tuple[int, int]:
    """(주요 변경 수, 그 밖의 알림 수) — 제목·메일 제목이 화면과 같은 수를 말하게."""
    main, quiet, _ = arrange_changes(changes, details, details_by_id)
    return len(main), len(quiet)


def _change_row(c: Change, ack_base: str | None, ack_tokens: dict | None,
                info: dict | None = None, baseline: bool = False,
                moved_from: str | None = None, note: str = "",
                acked_by: dict | None = None) -> str:
    p = PurePosixPath(c.path)
    old = (c.old_sha256 or "—")[:12]
    new = (c.new_sha256 or "—")[:12]
    color = "#57606a" if moved_from else _KIND_COLOR[c.kind]
    kind_label = ("이동" if moved_from else
                  "첫 등록" if (baseline and c.kind == "added") else _KIND_LABEL[c.kind])
    token = (ack_tokens or {}).get(c.id)
    if c.id and (acked_by or {}).get(c.id):
        ack = f'<span style="color:#1a7f37">확인됨 — {_esc(str(acked_by[c.id]))}</span>'
    elif ack_base and c.id and token and not baseline and not moved_from and not is_quiet(note or ""):
        # 이동·재저장·복사본은 확인 대상이 아니다(화면도 미확인에서 뺀다) — 행마다 링크가 있어
        # "확인만 하면 됩니다"로 읽혔다 (검토30 C 1-2)
        # 화면은 감시 PC에서만 열린다 — 다른 PC의 수신자에게는 매일 죽은 링크였다.
        # 링크 글에 그 사실을 붙인다 (검토19 브리핑 ⑬). 기준선(등록)에는 확인이 필요 없다
        ack = (f'<a href="{_esc(ack_base)}/ack?id={c.id}&amp;t={_esc(token)}" '
               f'style="color:#0969da">확인했음 기록</a>'
               f'<span style="color:#8c959f;font-size:11px"> (감시 PC에서)</span>')
    else:
        ack = "—"
    # 실무 언어는 파일명이 아니라 도면번호·Rev — 표제란 값이 있으면 앞세운다
    # (설계 10년차 검토 반영, 2026-08-28)
    if info and info.get("dwg"):
        rev = f' Rev {_esc(info["rev"])}' if info.get("rev") else ""
        file_cell = (f'<strong>도면 {_esc(info["dwg"])}</strong>{rev}'
                     f'<br><span style="color:#8c959f;font-size:12px">'
                     f'{_esc(p.name)}</span>')
    else:
        file_cell = _esc(p.name)
    if moved_from:
        file_cell += (f'<br><span style="color:#8c959f;font-size:12px">이전: '
                      f'{_esc(moved_from)}</span>')
    elif note:
        file_cell += f'<br><span style="color:#8c959f;font-size:12px">{_esc(note)}</span>'
    if info and info.get("mtime"):
        # 문서를 언제 고쳤나 — 검사 시각(머리글)과 별개 (2026-09-17 사용자 요청)
        try:
            from datetime import datetime as _dt
            _saved = _dt.fromtimestamp(float(info["mtime"])).strftime("%m-%d %H:%M")
            file_cell += f'<br><span style="color:#8c959f;font-size:12px">저장 {_saved}</span>'
        except (TypeError, ValueError, OSError, OverflowError):
            pass
    # 파일 지문(해시)은 화면·DB에 있다 — 브리핑에서는 근거로 읽히지 않아 뺀다
    # (2026-09-05 전체 검토: "모든 행의 지문 e3a9… → 9745…는 설계팀장에게 근거가 아니다")
    return (
        f'<tr>'
        f'<td style="{_STYLE_TD}"><strong style="color:{color}">{kind_label}</strong></td>'
        f'<td style="{_STYLE_TD}" title="지문 {old} → {new}">{file_cell}</td>'
        f'<td style="{_STYLE_TD}">{_esc(str(p.parent))}</td>'
        f'<td style="{_STYLE_TD}">{ack}</td>'
        f'</tr>'
    )


def _issues_section(issues, ack_base: str | None = None, project: str | None = None) -> str:
    from watcher.consistency import CODE_LABEL
    blocks = []
    if ack_base:
        # 변경 행에는 [확인했음 기록] 링크가 있는데 검토 필요 블록에는 동선이 없었다 (검토24 C-1)
        from urllib.parse import quote as _q
        blocks.append(
            f'<p style="color:#57606a;font-size:12px;margin:0 0 6px">감시 PC 화면의 '
            f'<a href="{_esc(ack_base)}/issues{("?p=" + _q(project)) if project else ""}" '
            f'style="color:#0969da">검토 필요 목록</a>에서 [처리함]·전/후 비교를 할 수 있습니다.</p>')
    for iss in issues:
        evidence = "".join(
            f'<li style="color:#57606a">{_esc(ev)}</li>' for ev in iss.evidence)
        blocks.append(f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 10px;background:#fff5f5">
    <strong style="color:#cf222e">{_esc(CODE_LABEL[iss.code])}</strong>
    &nbsp;<code>{_esc(iss.path)}</code>
    <div style="margin:4px 0 2px">{_esc(iss.message)}</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{evidence}</ul>
  </div>""")
    return "\n".join(blocks)


def _fmt_row_values(s: str | None) -> str:
    """diff가 str(dict)로 남긴 행 값을 'TAG=.., SPEC=..' 꼴로 정리."""
    import ast
    try:
        d = ast.literal_eval(s or "")
        return ", ".join(f"{k}={v}" for k, v in d.items() if str(v).strip())
    except (ValueError, SyntaxError):
        return s or ""


def _delta_badge(old: str | None, new: str | None) -> str:
    """수량처럼 숫자인 값의 증감 배지 (+2 초록 / -1 빨강) — Odoo BOM 비교 규칙."""
    try:
        d = float(new) - float(old)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return ""
    if d == 0:
        return ""
    color = "#1a7f37" if d > 0 else "#cf222e"
    sign = "+" if d > 0 else ""
    num = f"{d:g}"
    return (f' <span style="color:{color};font-weight:700">'
            f"({sign}{num})</span>")


def sheet_kind(path: str, cfg: dict | None = None) -> str:
    """표 문서의 성격 — 분류 규칙(watcher.doctype)에 위임한다.
    회사마다 양식·명칭이 달라 규칙을 데이터로 뺐다 (2026-08-31)."""
    from watcher.doctype import UNKNOWN, kind_of
    k = kind_of(path, cfg)
    return "" if k in (UNKNOWN, "표", "문서", "도면") else k


_IMPACT_KINDS = ("BOM", "발주서", "견적서", "자재표", "구매")


def impact_label(path: str, cfg: dict | None = None) -> str:
    """행 변경 요약 줄의 이름 — 구매로 이어지는 표(BOM·발주서·견적서·자재표)만 '발주 영향', 도면목록·성적서·
    개정이력 같은 표는 '변경 요약' (2026-09-06 사용성 3차 ④-7)."""
    from watcher.doctype import canonical, kind_of
    k = canonical(sheet_kind(path, cfg) or "")
    if any(w in k for w in _IMPACT_KINDS):
        return "발주 영향"
    # 도면(pdf·dxf·dwg) 위의 부품표는 BOM이다 — 엑셀 '도면목록'은 아니다
    if PurePosixPath(path).suffix.lower() in (".pdf", ".dxf", ".dwg") and canonical(kind_of(path, cfg)) == "도면":
        return "발주 영향"
    return "변경 요약"


def table_label(path: str, cfg: dict | None = None) -> str:
    """화면·메일에 쓰는 표 변경 이름표: '표(인터락)' / '표(BOM)' / '표'."""
    kind = sheet_kind(path, cfg)
    return f"표({kind})" if kind else "표"


def _row_key_cell(i) -> str:
    """행 식별 칸: 키 + 품명·규격 (어떤 부품인지 열어보지 않아도 알게 — 2026-08-25 요청)."""
    label = f'<br><span style="color:#57606a;font-size:12px">{_esc(i.label)}</span>' \
        if getattr(i, "label", None) else ""
    return f'<code>{_esc(i.key)}</code>{label}'


def _row_diff_table(items, extra_cell=None) -> str:
    """BOM 등 표 변경을 색상 표로: 추가=파랑, 삭제=빨강 취소선, 변경=앰버+델타.
    extra_cell: 항목→HTML 콜백 — 웹 상세가 [오탐 삭제] 버튼 칸을 붙일 때 사용
    (브리핑 메일에는 없음)."""
    trs = []
    def _x(i):
        return f'<td style="{_STYLE_TD}">{extra_cell(i)}</td>' if extra_cell else ""
    for i in items:
        if i.kind == "ROW_ADDED":
            trs.append(f'<tr style="background:#dbeafe;color:#1f2328">'
                       f'<td style="{_STYLE_TD};color:#1d4ed8;font-weight:700">행 추가</td>'
                       f'<td style="{_STYLE_TD}">{_row_key_cell(i)}</td>'
                       f'<td style="{_STYLE_TD}">{_esc(_fmt_row_values(i.new))}</td>'
                       f'<td style="{_STYLE_TD};color:#8c959f">{_esc(i.where)}</td>{_x(i)}</tr>')
        elif i.kind == "ROW_REMOVED":
            trs.append(f'<tr style="background:#fee2e2;color:#1f2328">'
                       f'<td style="{_STYLE_TD};color:#cf222e;font-weight:700">행 삭제</td>'
                       f'<td style="{_STYLE_TD}">{_row_key_cell(i)}</td>'
                       f'<td style="{_STYLE_TD};text-decoration:line-through;color:#57606a">'
                       f'{_esc(_fmt_row_values(i.old))}</td>'
                       f'<td style="{_STYLE_TD};color:#8c959f">{_esc(i.where)}</td>{_x(i)}</tr>')
        elif i.kind == "ROW_CHANGED":
            key, _, col = i.key.rpartition(".")
            label = (f'<br><span style="color:#57606a;font-size:12px">'
                     f'{_esc(i.label)}</span>') if getattr(i, "label", None) else ""
            trs.append(f'<tr style="background:#fef3c7;color:#1f2328">'
                       f'<td style="{_STYLE_TD};color:#9a6700;font-weight:700">값 변경</td>'
                       f'<td style="{_STYLE_TD}"><code>{_esc(key or i.key)}</code>{label}</td>'
                       f'<td style="{_STYLE_TD}">{_esc(col)}: {word_diff_html(i.old, i.new)[0]} '
                       f'&rarr; <strong>{word_diff_html(i.old, i.new)[1]}</strong>'
                       f'{_delta_badge(i.old, i.new)}</td>'
                       f'<td style="{_STYLE_TD};color:#8c959f">{_esc(i.where)}</td>{_x(i)}</tr>')
    if not trs:
        return ""
    return (f'<table style="{_STYLE_TABLE};margin:6px 0 8px">'
            f'<tr><th style="{_STYLE_TH}">구분</th><th style="{_STYLE_TH}">행</th>'
            f'<th style="{_STYLE_TH}">내용</th><th style="{_STYLE_TH}">위치</th>'
            + (f'<th style="{_STYLE_TH}"></th>' if extra_cell else '') + '</tr>'
            + "".join(trs) + "</table>")


# 수량 성격의 열 이름 — BOM 발주 영향 합계 계산용
_QTY_COL = re.compile(r"(수량|QTY|Q'TY|Q-TY|EA)\s*$", re.IGNORECASE)
_QTY_IN_REPR = re.compile(r"'(?:수량|QTY|Q'TY|EA)'\s*:\s*'?(-?\d+(?:\.\d+)?)",
                          re.IGNORECASE)


def bom_impact(items) -> tuple[int, int, int, float | None]:
    """행 변경의 발주 영향 요약: (신규 행, 삭제 행, 값 변경 건, 수량 증감 합계).
    수량 열을 못 찾으면 합계는 None. 구매 전달용 한 줄 (설계 10년차 검토)."""
    added = sum(1 for i in items if i.kind == "ROW_ADDED")
    removed = sum(1 for i in items if i.kind == "ROW_REMOVED")
    changed = sum(1 for i in items if i.kind == "ROW_CHANGED")
    delta, seen = 0.0, False
    for i in items:
        if i.kind == "ROW_CHANGED":
            if _QTY_COL.search(i.key.rpartition(".")[2]):
                try:
                    delta += float(i.new) - float(i.old)
                    seen = True
                except (TypeError, ValueError):
                    pass
        elif i.kind in ("ROW_ADDED", "ROW_REMOVED"):
            m = _QTY_IN_REPR.search(i.new or i.old or "")
            if m:
                seen = True
                delta += float(m.group(1)) * (1 if i.kind == "ROW_ADDED" else -1)
    return added, removed, changed, (delta if seen else None)


def bom_impact_line(items, web: bool = False, label: str = "발주 영향") -> str:
    """행 변경 표 위 한 줄 요약. 행 변경이 없으면 빈 문자열.

    web=True면 화면용 테마 색을 쓴다 — 메일용 고정 색(#1f2328)이 다크 화면에서
    배경과 겹쳐 "발주 영향:" 글자가 사라졌다 (2026-08-31).
    label: 표 성격에 맞는 이름 (BOM류는 '발주 영향', 그 외는 '변경 요약')."""
    a, r, c, d = bom_impact(items)
    if not (a or r or c):
        return ""
    add, rm, ch, base = (("var(--link)", "var(--bad)", "var(--warn)", "var(--text)")
                         if web else ("#1d4ed8", "#cf222e", "#9a6700", "#1f2328"))
    parts = []
    if a:
        parts.append(f'<b style="color:{add}">신규 {a}행</b>')
    if r:
        parts.append(f'<b style="color:{rm}">삭제 {r}행</b>')
    if c:
        parts.append(f'<b style="color:{ch}">값 변경 {c}건</b>')
    # 금액 합계(d)는 일부러 쓰지 않는다 — 품목 불문 합계는 발주에 쓸 수 없다
    # (2026-09-02 처음 보는 사람 검토). 인자는 호출부 호환을 위해 남겨 둔다
    return (f'<div style="font-size:13px;margin:2px 0 6px;color:{base}">'
            f'{label}: {" / ".join(parts)}</div>')


# 개별 변경 항목의 구분 라벨·색 (표 렌더용)
_ITEM_KIND = {
    "NEW_REVISION_OF": ("이전 판", "#57606a", "#f6f8fa"),
    "FIELD_CHANGED": ("값 변경", "#9a6700", "#fef3c7"),
    "FIELD_ADDED": ("값 추가", "#1d4ed8", "#dbeafe"),
    "FIELD_REMOVED": ("값 삭제", "#cf222e", "#fee2e2"),
    "TEXT_CHANGED": ("글자 변경", "#9a6700", "#fef3c7"),
    "TEXT_ADDED": ("글자 추가", "#1d4ed8", "#dbeafe"),
    "TEXT_REMOVED": ("글자 삭제", "#cf222e", "#fee2e2"),
    "PAGE_VISUAL_CHANGED": ("그림 변경", "#7c3aed", "#f3e8ff"),
    "PAGE_ADDED": ("페이지 추가", "#1d4ed8", "#dbeafe"),
    "COL_RENAMED": ("열 이름 변경", "#57606a", "#f6f8fa"),
    "COL_ADDED": ("열 추가", "#1d4ed8", "#dbeafe"),
    "COL_REMOVED": ("열 삭제", "#cf222e", "#fee2e2"),
    "ROW_MOVED": ("행 이동", "#57606a", "#f6f8fa"),
    "COL_MOVED": ("열 이동", "#57606a", "#f6f8fa"),
    "PAGE_MOVED": ("페이지 순서", "#57606a", "#f6f8fa"),
    "TEXT_MOVED": ("문단 이동", "#57606a", "#f6f8fa"),
    "SHEET_ADDED": ("시트 추가", "#1d4ed8", "#dbeafe"),
    "SHEET_REMOVED": ("시트 삭제", "#cf222e", "#fee2e2"),
    "SHEET_RENAMED": ("시트 이름 변경", "#57606a", "#f6f8fa"),
    "PAGE_REMOVED": ("페이지 삭제", "#cf222e", "#fee2e2"),
    # 아래 셋이 빠져 있어 영문 코드가 그대로 표에 찍혔다 (2026-09-02 처음 보는 사람 검토)
    "REVROW_ADDED": ("리비전 행 추가", "#1d4ed8", "#dbeafe"),
    "REVROW_REMOVED": ("리비전 행 삭제", "#cf222e", "#fee2e2"),
    "REVROW_CHANGED": ("리비전 행 변경", "#9a6700", "#fef3c7"),
    "NEW_REVISION_OF": ("이전 판", "#57606a", "#f6f8fa"),
    "CHECK_SKIPPED": ("검사 한계", "#57606a", "#f6f8fa"),
}


def fmt_val(v) -> str:
    """항목 값을 사람 문장으로 — 리비전 행은 dict라 파이썬 표기가 그대로 찍혔다.
    저장을 거친 값은 dict의 문자열("{'DATE': …}")이라 그것도 되돌려 정돈한다 (2026-09-05)."""
    if v is None or v == "":
        return "—"
    if isinstance(v, str) and v.startswith("{") and v.endswith("}"):
        try:
            import ast
            parsed = ast.literal_eval(v)
            if isinstance(parsed, dict):
                v = parsed
        except Exception:
            pass
    if isinstance(v, dict):
        return " · ".join(f"{k}: {x}" for k, x in v.items() if x not in (None, ""))
    if isinstance(v, (list, tuple)):
        return " · ".join(str(x) for x in v)
    return str(v)


_W_DEL = 'style="background:#fee2e2;color:#991b1b;text-decoration:line-through"'
_W_INS = 'style="background:#dcfce7;color:#166534;font-weight:700"'


def word_diff_html(old, new, esc=_esc, del_attr: str = _W_DEL, ins_attr: str = _W_INS) -> tuple[str, str]:
    """두 문자열의 낱말 단위 차이 → (이전 HTML, 새 HTML). 바뀐 낱말만 표시한다 (2026-09-06 정밀화).
    낱말이 하나뿐인 긴 값(띄어쓰기 없는 문장·코드)은 글자 단위로 본다. 표시 불가(값이 아님)면
    그냥 이스케이프."""
    from difflib import SequenceMatcher
    o, n = fmt_val(old), fmt_val(new)
    if not isinstance(o, str) or not isinstance(n, str) or o == "—" or n == "—" or o == n:
        return esc(o), esc(n)
    ot, nt = o.split(), n.split()
    # 낱말 하나짜리 긴 값은 글자 단위 — 단 숫자가 든 값(날짜·코드 2026-07-10, PW-1009-A)은 통째로
    # 보여 준다: 자릿수만 색칠되면 통째보다 읽기 어렵다 (2026-09-06 사용성 3차 ④-9)
    char_mode = (len(ot) <= 1 and len(nt) <= 1 and max(len(o), len(n)) > 8
                 and not any(ch.isdigit() for ch in o + n))
    if char_mode:
        ot, nt, joiner = list(o), list(n), ""
    else:
        joiner = " "
    if len(ot) * len(nt) > 250000:
        return esc(o), esc(n)
    sm = SequenceMatcher(None, ot, nt, autojunk=False)
    oh, nh = [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            oh.append(esc(joiner.join(ot[i1:i2]))); nh.append(esc(joiner.join(nt[j1:j2])))
            continue
        if i2 > i1:
            oh.append(f"<span {del_attr}>{esc(joiner.join(ot[i1:i2]))}</span>")
        if j2 > j1:
            nh.append(f"<span {ins_attr}>{esc(joiner.join(nt[j1:j2]))}</span>")
    return joiner.join(oh), joiner.join(nh)


_WORD_KINDS = ("TEXT_CHANGED", "FIELD_CHANGED", "REVROW_CHANGED")


def item_diff_table(items, cap_of=None, extra_cell=None, budget=None) -> str:
    """개별 변경 항목(글자·값·그림)을 정렬된 표로 — 줄글 목록은 항목이 많으면
    읽기 불편하다는 피드백 반영 (2026-08-28). 전/후 사진은 해당 행 바로 아래
    전체 폭 행으로. extra_cell: 웹 상세의 [오탐 삭제] 버튼 칸 콜백."""
    if not items:
        return ""
    ncols = 5 + (1 if extra_cell else 0)
    trs = []
    for i in items:
        label, color, bg = _ITEM_KIND.get(i.kind, (i.kind, "#57606a", "#f6f8fa"))
        x = f'<td style="{_STYLE_TD}">{extra_cell(i)}</td>' if extra_cell else ""
        if i.kind in _WORD_KINDS:
            o_html, n_html = word_diff_html(i.old, i.new)
        else:
            o_html, n_html = _esc(fmt_val(i.old)), _esc(fmt_val(i.new))
        trs.append(
            f'<tr style="background:{bg};color:#1f2328">'
            f'<td style="{_STYLE_TD};color:{color};font-weight:700;'
            f'white-space:nowrap">{label}</td>'
            f'<td style="{_STYLE_TD}"><code>{_esc(i.key)}</code></td>'
            f'<td style="{_STYLE_TD};color:#57606a">{o_html}</td>'
            f'<td style="{_STYLE_TD}"><strong>{n_html}</strong>'
            f'{_delta_badge(i.old, i.new)}</td>'
            f'<td style="{_STYLE_TD};color:#8c959f">{_esc(i.where)}</td>{x}</tr>')
        cap = cap_of(i) if cap_of else None
        if cap:
            block = render_capture(cap, budget)
            if block:
                trs.append(f'<tr><td colspan="{ncols}" style="{_STYLE_TD}">'
                           f'{block}</td></tr>')
    return (f'<table style="{_STYLE_TABLE};margin:6px 0 8px">'
            f'<tr><th style="{_STYLE_TH}">구분</th><th style="{_STYLE_TH}">항목</th>'
            f'<th style="{_STYLE_TH}">이전</th><th style="{_STYLE_TH}">새 값</th>'
            f'<th style="{_STYLE_TH}">위치</th>'
            + (f'<th style="{_STYLE_TH}"></th>' if extra_cell else '')
            + '</tr>' + "".join(trs) + '</table>')


# 메일 한 통에 실을 사진의 총량(바이트, base64 기준). 사진 한 장의 픽셀 상한
# (capture._MAIL_MAX_SIDE)만으로는 파일 수십 개가 바뀐 날 한 통이 수십 MB가 된다.
# 사내 SMTP가 보통 10~25MB에서 막고, 막히면 그날 브리핑이 통째로 사라진다
# (2026-09-09 브리핑 검토 차단 4). 넘치는 자리는 글로 남기고 화면으로 보낸다.
_MAIL_PHOTO_BUDGET = 6 * 1024 * 1024


class PhotoBudget:
    """메일 한 통 동안 살아 있는 사진 총량 예산. 웹 화면은 쓰지 않는다(무제한)."""

    def __init__(self, limit: int = _MAIL_PHOTO_BUDGET):
        self.left = limit
        self.skipped = 0

    def take(self, nbytes: int) -> bool:
        if nbytes > self.left:
            self.skipped += 1
            return False
        self.left -= nbytes
        return True


def _cap_bytes(cap: dict) -> int:
    return sum(len(x.get("b64") or "") for x in (cap.get("before"), cap.get("after")) if x)


def _one_img(cap: dict, label: str, border: str, width: int = 400) -> str:
    # 표 칸 + width 속성 — Outlook(Word 엔진)은 flex를 모르고 max-width도 무시해
    # 1600px 원본 폭으로 그려 가로 스크롤이 났다 (검토19 브리핑 ⑥)
    # width 속성은 Outlook용 고정 폭, style은 폰(390px)에서 줄어들게 — 고정 style 폭은
    # 폰에서 가로로 넘쳤다 (검토19 2차 브리핑 ④)
    return (f'<td valign="top" style="padding:0 6px 0 0">'
            f'<div style="font-size:12px;font-weight:700;color:{border};margin-bottom:3px">'
            f'{label}</div>'
            # alt이 없으면 메일 프로그램이 그림을 막았을 때 아무 글자도 남지 않는다
            # (2026-09-09 브리핑 검토 차단 3). 설명(caption)을 그대로 대체 글로 쓴다
            f'<img src="data:{cap["mime"]};base64,{cap["b64"]}" width="{width}" '
            f'alt="{_esc(label)} — {_esc(cap["caption"])}" '
            f'style="width:100%;max-width:{width}px;height:auto;border:1px solid {border};border-radius:6px;display:block">'
            f'<span style="color:#8c959f;font-size:11.5px">{_esc(cap["caption"])}</span></td>')


def _missing_img(label: str) -> str:
    return (f'<div style="display:inline-block;vertical-align:top;margin:4px 8px 4px 0;'
            f'padding:18px 14px;border:1px dashed #d0d7de;border-radius:6px;color:#8c959f;'
            f'font-size:12px">{_esc(label)}: 이 판에는 없는 페이지</div>')


def render_capture(cap: dict, budget=None) -> str:
    """전/후 캡처 렌더. 전 사진이 있으면 나란히, 없으면 후만 (덮어쓰기라 구버전 없음).
    budget(PhotoBudget)을 주면 총량을 넘는 사진은 글 한 줄로 대신한다 — 메일용."""
    if not cap:
        return ""
    # 구형(단일) 캡처 호환: after/before 키가 없으면 통째로 after로 취급
    after = cap.get("after") if "after" in cap or "before" in cap else cap
    before = cap.get("before")
    if after is None and not before:
        return ""
    if budget is not None and not budget.take(_cap_bytes(
            {"before": before, "after": after})):
        where = (after or before or {}).get("caption", "")
        return (f'<div style="color:#8c959f;font-size:12.5px;margin:4px 0">'
                f'전/후 사진 생략 — 이 메일의 사진 용량 상한을 넘었습니다'
                f'{(" (" + _esc(str(where)) + ")") if where else ""}. '
                f'감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div>')
    inner = ""
    w = 400 if (before and after) else 640
    if before:
        inner += _one_img(before, "변경 전", "#8c959f", w)
    if after:
        inner += _one_img(after, "변경 후", "#dc2626", w)
    if before and after:
        note = "빨간 박스가 변경된 자리 · 좌: 이전 판, 우: 새 판"
    elif after:
        # "이전 판 파일이 없어"는 바로 위 그림 변경 행에 전 사진이 있는 화면에서 서로를
        # 부정했다 — 글자 항목은 원래 새 판 자리만 그린다 (검토19 브리핑 ⑤)
        note = ("이전 판에 없던 페이지 (추가)" if "이전 판에 없음" in str(after.get("caption", ""))
                else "빨간 박스가 변경된 자리 (글자·값 변경은 새 판의 그 자리만 표시)")
    else:
        note = "이 페이지는 새 판에 없습니다 (삭제) — 뒤 페이지 번호가 하나씩 당겨졌을 수 있습니다"
    return (f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
            f'style="margin:6px 0 4px"><tr>{inner}</tr></table>'
            f'<div style="color:#8c959f;font-size:12px;margin-bottom:8px">{note}</div>')


_DETAIL_CAP = 40  # 항목이 수백 개면(대형 도면 재출력 등) 읽을 수 없다 — 상위만 표시


def _cap_of(captures: dict | None, path: str, item, cid=None):
    """항목의 캡처. 신형 키(kind|key — 같은 key끼리 덮어쓰기 방지)를 먼저,
    구형 저장분(key만)은 폴백으로 찾는다.

    cid(변경 id)를 주면 그 키를 먼저 본다 — 같은 파일이 하루에 두 번 바뀐 날
    경로 키만으로는 아침 사진이 오후 것에 덮였다 (2026-09-09 브리핑 검토 차단 2)."""
    if not captures:
        return None
    # 같은 kind|key가 한 파일에 여럿(25쪽에 같은 NOTE 줄이 추가)이면 자리(where)까지 붙인
    # 키가 따로 있다 — 전에는 전부 마지막 쪽 사진 하나를 가리켰다 (검토19 브리핑 ④)
    k3 = f"{item.kind}|{item.key}|{item.where}"
    k2 = f"{item.kind}|{item.key}"
    if cid is not None:
        hit = (captures.get((cid, k3)) or captures.get((cid, k2))
               or captures.get((cid, item.key)))
        if hit:
            return hit
    return captures.get((path, k3)) or captures.get((path, k2)) \
        or captures.get((path, item.key))


def _is_common_item(i) -> bool:
    """전 페이지 반복(표제란·양식) 변경 — 개별 변경과 분리해 접어 보인다."""
    return i.key.startswith("공통위치") or "전 페이지 공통" in i.where


def split_display_items(items, cap_lookup, plain_cap: int):
    """상세 항목의 표시용 분류 — 브리핑과 웹 상세가 공용한다
    (같은 로직을 두 곳에 두었다가 같은 버그를 두 번 고친 자리, 2026-08-26 통합).
    캡처(전/후 사진)가 붙은 항목은 표시 캡에서 자르지 않는다.
    돌려주는 값: (안내문, 개별 변경, 전 페이지 공통, 표 행, 생략 수)"""
    row_items = [i for i in items if i.kind.startswith("ROW_")]
    others, plain_shown, omitted = [], 0, 0
    for i in items:
        if i.kind.startswith("ROW_"):
            continue
        if cap_lookup(i):
            others.append(i)
        elif plain_shown < plain_cap:
            others.append(i)
            plain_shown += 1
        else:
            omitted += 1
    omitted += max(0, len(row_items) - plain_cap)
    notices = [i for i in others if i.kind == "CHECK_SKIPPED"]
    commons = [i for i in others if i.kind != "CHECK_SKIPPED" and _is_common_item(i)]
    regular = [i for i in others
               if i.kind != "CHECK_SKIPPED" and not _is_common_item(i)]
    return notices, regular, commons, row_items[:plain_cap], omitted


def _details_rows(path: str, items, captures: dict | None = None,
                  info: dict | None = None, budget=None, cid=None) -> str:
    notices, regular, commons, row_items, omitted = split_display_items(
        items, lambda i: _cap_of(captures, path, i, cid), _DETAIL_CAP)

    def _cap(i):  # 변경 위치 캡처 — 비교 결과를 도면 위에 '표시'만 한다
        return _cap_of(captures, path, i, cid)

    inner = ""
    if any("OCR" in str(getattr(i, "where", "") or "") for i in items):
        # 스캔본·SHX 출력 PDF의 글자는 Windows OCR로 읽은 추정값 — 0/O·1/I 오인이 있을 수 있다 (2026-09-06)
        inner += ('<div style="border:1px solid #9a6700;border-left:5px solid #9a6700;border-radius:6px;'
                  'padding:8px 12px;margin:6px 0;background:#fff8e5;font-size:13px"><strong>OCR 추정값</strong> — '
                  '이 파일의 글자는 그림에서 읽은 것이라 O/0·I/1처럼 틀릴 수 있습니다. 전/후 사진으로 확인하세요.</div>')
    # 설계자가 리비전 블록에 남긴 공식 개정 사유 — "왜 바뀌었나"가 한 줄로
    if info and info.get("note"):
        inner += (f'<div style="border:1px solid #d0d7de;border-left:5px solid '
                  f'#1d4ed8;border-radius:6px;padding:8px 12px;margin:6px 0;'
                  f'background:#f6f8fa;font-size:13px;color:#1f2328">'
                  f'개정 사유(리비전 블록): <strong>{_esc(info["note"])}</strong>'
                  f'</div>')
    # 검사 한계 고지는 값 변경(→) 표가 아니라 안내 박스로 (2026-08-25 UX 검토)
    for i in notices:
        inner += (f'<div style="border:1px solid #9a6700;border-left:5px solid #9a6700;'
                  f'border-radius:6px;padding:8px 12px;margin:6px 0;background:#fff8e5;'
                  f'font-size:13px"><strong>{_esc(i.key)}</strong> — {_esc(i.new or "")}</div>')
    if regular:
        inner += item_diff_table(regular, cap_of=_cap, budget=budget)
    if commons:
        # <details>는 Outlook·Gmail에서 접히지 않거나 아예 안 보인다 — 제목 줄 + 표로 (검토19 브리핑 ⑥)
        inner += (f'<div style="margin:6px 0;font-size:13px;color:#57606a">'
                  f'전 페이지 공통 변경(표제란·양식류) {len(commons)}건</div>'
                  f'{item_diff_table(commons, cap_of=_cap, budget=budget)}')
    inner += bom_impact_line(row_items, label=impact_label(path)) + _row_diff_table(row_items)
    if omitted:
        inner += (f'<div style="color:#8c959f;font-size:12.5px;margin-top:4px">'
                  f"외 {omitted}건 생략 — 변경이 매우 많은 문서라 위 {_DETAIL_CAP}건만 "
                  f"표시했습니다. 전체는 감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div>")
    return (f'<tr><td colspan="5" style="{_STYLE_TD};background:#fafbfc">'
            f"{inner}</td></tr>")


def _scan_errors_section(scan_errors) -> str:
    lis = "".join(f'<li>{_esc(p)} — <span style="color:#57606a">{_esc(err)}</span></li>'
                  for p, err in scan_errors)
    return f"""
  <div style="border:1px solid #9a6700;border-left:6px solid #9a6700;border-radius:6px;
              padding:10px 14px;margin:0 0 12px;background:#fff8e5">
    <strong style="color:#9a6700">읽지 못한 {'폴더·파일' if any(str(p).endswith('/') for p, _ in scan_errors) else '파일'} {len(scan_errors)}건</strong>
    <div style="font-size:13px;margin-top:4px">잠김·권한·연결 문제로 이번 실행에서 확인하지
    못했습니다. 감시 폴더 자체가 안 열린 경우 그 폴더의 프로젝트는 이 통에 없습니다. 다음 성공 시 변경 감지가 재개됩니다.</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}</ul>
  </div>"""


def _summary_toc(changes, details: dict, doc_info: dict | None = None,
                 baseline: bool = False, details_by_id: dict | None = None) -> str:
    """상단 요약 목차: 파일별로 무엇이 몇 건인지 한눈에 (2026-08-25 UX 검토 —
    '변경 1건' 헤더 아래 항목 수백 개가 예고 없이 이어지던 문제).

    같은 파일이 하루에 두 번 바뀐 날은 **변경 id별** 상세를 쓴다 — 경로 키만 보면
    두 줄 모두에 최신 건수가 붙어 아래 근거표와 숫자가 달랐다
    (2026-09-09 배포 후 검토 중간 1)."""
    if not changes:
        return ""
    lis = []
    for i, c in enumerate(changes):
        items = (details_by_id or {}).get(c.id)
        if items is None:
            items = details.get(c.path, [])
        vis = 0
        for it in items:
            if it.kind != "PAGE_VISUAL_CHANGED":
                continue
            m = re.search(r"(\d+)개 페이지 반복", str(it.where or ""))
            vis += int(m.group(1)) if m else 1     # 공통 위치 1건 = 여러 쪽 (검토19 2차 ⑧)
        txt = sum(1 for it in items if it.kind.startswith("TEXT_"))
        row = sum(1 for it in items if it.kind.startswith("ROW_"))
        rev = next((it for it in items
                    if it.kind == "FIELD_CHANGED" and it.key == "REV"), None)
        parts = []

        def _short(v) -> str:
            return " ".join(str(v or "").split())[:36]
        # 첫 줄에 "무엇이 어떻게" — 건수만 있으면 팀장이 열어 봐야 알았다 (파일럿 모의 2차 조건 2)
        def _row_head_of(it) -> str:
            rk, sep, col = str(it.key).rpartition(".")         # 'X-11.수량' → 'X-11 수량'
            head = f"{rk} {col}".strip() if sep else str(it.key)
            return f"{_short(head)}: {_short(it.old)} → {_short(it.new)}"
        row_head = next((_row_head_of(it) for it in items
                         if it.kind == "ROW_CHANGED" and it.old and it.new), None)
        txt_head = next((f"{_short(it.old)} → {_short(it.new)}"
                         for it in items if it.kind == "TEXT_CHANGED" and it.old and it.new
                         and _UNIT_RE.search(str(it.old) + " " + str(it.new))), None)
        if txt_head:
            parts.append(txt_head)
        if vis:
            parts.append(f"그림 변경 위치 {vis}곳")
        if txt and not txt_head:
            parts.append(f"글자 변경 {txt}건")
        elif txt > 1 and txt_head:
            parts.append(f"글자 변경 외 {txt - 1}건")
        if row:
            parts.append(f"{table_label(c.path)} 변경 {row}건" + (f" ({row_head})" if row_head else ""))
        if rev:
            parts.append(f"Rev {rev.old}→{rev.new}")
        # 표제란 칸이 지워진 것(PROJECT → 없음)은 목차에 없었다 (검토21 브리핑 중간 9)
        fdel = next((it for it in items if it.kind == "FIELD_CHANGED" and it.old
                     and not it.new and it.key not in ("파일 크기", "저장 시각")), None)
        if fdel:
            parts.append(f"표제란 {fdel.key} 칸 삭제 ({_short(fdel.old)})")
        dt = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "DATE"), None)
        if dt and not parts:
            parts.append(f"표제란 일자 {dt.old}→{dt.new}")
        # 내용을 못 읽는 파일 — 크기·저장 시각이 유일한 근거인데 목차는 "수정"뿐이었다 (검토19 브리핑 ⑮)
        sz = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "파일 크기"), None)
        if sz and not parts:
            parts.append(f"크기 {sz.old}→{sz.new}")
        elif not parts:
            tm = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "저장 시각"), None)
            if tm:
                parts.append(f"저장 시각 {tm.new}")
        note = next((it for it in items
                     if it.kind == "CHECK_SKIPPED" and it.key == "참고"), None)
        if note and not parts:
            # 구판 '대체됨' 같은 참고 — 목차만 보는 사람이 삭제로 오해하지 않게
            # (2026-09-02 재검토)
            parts.append(str(note.new).split(" — ")[0])
        name = PurePosixPath(c.path).name if "/" in c.path else c.path
        info = ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path))
        if info and info.get("dwg"):  # 실무 언어: 도면번호가 파일명보다 먼저
            name = f'도면 {info["dwg"]} — {name}'
        summary = ", ".join(parts) or ("첫 등록" if baseline and c.kind == "added" else KIND_LABEL_TEXT(c))
        # 사양값(kW·A·V·mm…)이 바뀐 줄이나 표 행 변경은 접히지 않는다 — 10장 중 한 장의
        # 모터 kW 변경이 "외 7건이 같은 내용"에 묻혔다 (검토19 2차 브리핑 ⑦)
        salient = bool(row) or any(
            it.kind.startswith("TEXT_") and _UNIT_RE.search(str(it.old or "") + " " + str(it.new or ""))
            for it in items)
        lis.append((i, name, summary, salient))
    # 같은 요약이 여덟 줄 넘게 반복되면 접는다 — 도면 60장이 전부 "Rev A→B, 글자 1건"인 날
    # 팀장은 60줄을 지나야 첫 상세를 봤다 (검토19 브리핑 ⑧). 상세는 그대로 전부 싣는다
    from collections import Counter as _Counter
    counts = _Counter(s for _, _, s, sal in lis if not sal)
    shown: dict = {}
    out_li = []
    for i, name, summary, salient in lis:
        if salient:
            out_li.append(f'<li style="margin:3px 0"><a href="#chg{i}" '
                          f'style="color:#1d4ed8">{_esc(name)}</a>'
                          f'<span style="color:#57606a"> — {_esc(summary)}</span></li>')
            continue
        k = shown.get(summary, 0)
        if counts[summary] > 8 and k >= 3:
            shown[summary] = k + 1
            continue
        shown[summary] = k + 1
        out_li.append(f'<li style="margin:3px 0"><a href="#chg{i}" '
                      f'style="color:#1d4ed8">{_esc(name)}</a>'
                      f'<span style="color:#57606a"> — {_esc(summary)}</span></li>')
    for summary, n in counts.items():
        if n > 8:
            out_li.append(f'<li style="margin:3px 0;color:#57606a">… 외 {n - 3}건이 같은 내용'
                          f'({_esc(summary)}) — 아래 상세에 전부 있습니다</li>')
    # 기준선 통에는 '확인할 것'이 없다 — 등록 목록이다 (검토21 브리핑 중간 10)
    return ('<div style="border:1px solid #d0d7de;border-radius:6px;'
            'padding:10px 14px;margin:0 0 14px;background:#f6f8fa">'
            f'<strong>{"등록된 산출물 (요약)" if baseline else "오늘 확인할 것"}</strong>'
            f'<ul style="margin:6px 0 0;padding-left:20px">{"".join(out_li)}</ul></div>')


def _one_details(c, details: dict, details_by_id: dict | None, captures,
                 doc_info: dict | None, budget) -> str:
    """변경 한 건의 상세 — 같은 파일이 하루에 두 번 바뀐 날은 변경 id별 상세를 쓴다."""
    items = (details_by_id or {}).get(c.id)
    if items is None:
        items = details.get(c.path)
    if not items:
        return ""
    return _details_rows(c.path, items, captures, ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)),
                         budget=budget, cid=c.id)


def KIND_LABEL_TEXT(c) -> str:
    return _KIND_LABEL.get(c.kind, c.kind)


def _short_roots(root: str) -> str:
    """머리말의 감시 폴더는 마지막 폴더 이름만 — 전체 서버 경로가 고객에게 전달되는 통에
    그대로 실렸다 (검토19 2차 브리핑 ⑫). 전체는 title로 남긴다."""
    raw = "\n".join("\n".join(str(root or "").split(" · ")).split(", "))   # replace()는 읽기 전용 가드가 막는다
    parts = [p.strip() for p in raw.splitlines() if p.strip()]
    names = []
    for p in parts:
        q = "/".join(p.split("\\")).rstrip("/")
        names.append(q.rsplit("/", 1)[-1] or q)
    return " · ".join(names) if names else str(root)


def build_brief(changes: list[Change], run_at: datetime, root: str,
                details: dict | None = None, issues: list | None = None,
                project: str | None = None, ack_base: str | None = None,
                ack_tokens: dict | None = None,
                scan_errors: list | None = None,
                captures: dict | None = None,
                scanned_count: int | None = None,
                baseline: bool = False,
                doc_info: dict | None = None,
                merged_note: str | None = None,
                acked_by: dict | None = None,
                details_by_id: dict | None = None,
                since: str | None = None,
                photo_budget: bool = False,
                baseline_note: str | None = None) -> str:
    """브리핑 HTML 문서 전체를 돌려준다. 변경 0건이어도 문서는 만든다(기록용).

    details: {path: [ChangeItem]} 파일별 내용 변경 상세 (Stage 3)
    issues:  [Issue] 일관성 검사 결과 (Stage 3)
    project: 프로젝트별 브리핑이면 정규 프로젝트 번호 (Stage 4)
    scanned_count: 이번 검사에서 확인한 파일 수 — 0건 날의 '살아있음' 신호
    """
    details = details or {}
    issues = issues or []
    date_str = run_at.strftime("%Y-%m-%d %H:%M")
    proj_label = f"[{project}] " if project else ""
    scanned_note = (f" · 파일 {scanned_count}개 검사함"
                    if scanned_count is not None else "")
    # PC가 며칠 꺼져 있다가 켜진 날은 6일치 변경이 "오늘 12건"으로 나가 받는 사람이
    # 어제 하루 일로 읽었다 — 무엇과 비교한 것인지 한 줄 밝힌다 (원칙 4, 2026-09-09
    # 자동 실행 검토 중간 8)
    # 합산본은 여러 검사분을 한 통에 담는다 — "직전 검사"라 쓰면 그 통의 절반에
    # 대해 거짓이 된다 (2026-09-09 배포 후 검토 중간 2)
    since_note = (f" · 비교 기준: 오늘 앞선 검사부터 (가장 최근 비교는 {since})"
                  if since and merged_note else
                  f" · 비교 기준: 직전 검사 {since}" if since else "")
    # 기준선은 전부 '첫 등록' — 접지 않고 그대로 나열
    if baseline:
        main, quiet, moved = list(changes), [], {}
    else:
        main, quiet, moved = arrange_changes(changes, details, details_by_id)
    n = len(main)
    head_th = f"""
    <tr>
      <th style="{_STYLE_TH}">구분</th>
      <th style="{_STYLE_TH}">파일</th>
      <th style="{_STYLE_TH}">폴더</th>
      <th style="{_STYLE_TH}">확인</th>
    </tr>"""

    # 사진 총량은 **메일에만** 건다. 전에는 무조건 걸어서, 디스크에 남는 브리핑
    # 원본(화면이 여는 바로 그 파일)에서도 사진이 지워졌다 — 안내문은 "이 메일의
    # 상한"이라 말하고 "감시 PC 화면에서 보라"고 했는데, 보는 사람이 이미 그 화면이고
    # 그 상세는 보존 기간이 지나면 사라진다 (2026-09-09 배포 후 검토, 원칙 4)
    _budget = PhotoBudget() if photo_budget else None
    if main:
        rows = "\n".join(
            f'<tbody id="chg{i}">'
            + _change_row(c, ack_base, ack_tokens, ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)), baseline,
                          acked_by=acked_by)
            + _one_details(c, details, details_by_id, captures, doc_info, _budget)
            + "</tbody>"
            for i, c in enumerate(main))
        body = f"""
  {_summary_toc(main, details, doc_info, baseline=baseline,
                details_by_id=details_by_id)}
  <table style="{_STYLE_TABLE}">{head_th}
    {rows}
  </table>"""
    elif quiet:
        body = ('<p style="color:#57606a">내용이 바뀐 산출물은 없습니다 — 아래 '
                '그 밖의 알림만 있습니다.</p>')
    elif scan_errors:
        # 읽지 못한 폴더·파일이 있는 날은 '정상 동작 중'이 아니다 — "파일 122개가 사라졌습니다" 바로
        # 아래 "정상 동작 중"이 서로 부정했다 (검토21 브리핑 차단 4)
        body = (f'<p style="color:#9a6700">변경된 산출물이 없습니다 — 다만 위의 읽지 못한 '
                f'폴더·파일 알림을 확인하세요{_esc(scanned_note)}.</p>')
    else:
        body = (f'<p style="color:#1a7f37">변경된 산출물이 없습니다 — 감시는 정상'
                f' 동작 중입니다{_esc(scanned_note)}.</p>')
    if quiet:
        # 폴더 이름 변경·이동은 파일마다 한 행(6~20행)이 아니라 "폴더 A → B (파일 N개)" 한
        # 줄로 접는다 (파일럿 모의 ⑩). 셋 미만이면 파일별로 둔다
        from collections import Counter as _C
        pair_of = {}
        for c in quiet:
            if c.path in moved:
                # 바뀐 가장 높은 조상끼리 묶는다 — 하위 폴더별(도면/·BOM/)로 따로 세면
                # "폴더 A → B (파일 20개)" 한 줄이 안 됐다 (파일럿 모의 2차 day10)
                op = PurePosixPath(moved[c.path]).parent.parts
                npn = PurePosixPath(c.path).parent.parts
                k = 0
                while k < min(len(op), len(npn)) and op[-1 - k] == npn[-1 - k]:
                    k += 1
                # 공통 꼬리를 떼되 **옮겨진 폴더 이름은 남긴다** — '견적중_P26-034'를 통째로 떼어
                # "서버 → 서버/아카이브"라 적었다 (파일럿 모의 3차 ①). 꼬리를 뗐으면 한 마디 되살린다
                if k > 0:
                    k -= 1
                pair_of[id(c)] = ("/".join(op[:len(op) - k]) or ".", "/".join(npn[:len(npn) - k]) or ".")
        pair_n = _C(pair_of.values())
        folded_pairs: set = set()
        qparts = []
        for c in quiet:
            pr = pair_of.get(id(c))
            if pr and pr[0] != pr[1] and pair_n[pr] >= 3:
                if pr in folded_pairs:
                    continue
                folded_pairs.add(pr)
                qparts.append(
                    f'<tr><td style="{_STYLE_TD}"><strong style="color:#57606a">이동</strong></td>'
                    f'<td style="{_STYLE_TD}" colspan="2">폴더 <b>{_esc(pr[0])}</b> → <b>{_esc(pr[1])}</b> '
                    f'(파일 {pair_n[pr]}개 — 이름·위치만 바뀜, 내용 동일)</td>'
                    f'<td style="{_STYLE_TD}">—</td></tr>')
                continue
            qparts.append(_change_row(c, ack_base, ack_tokens, None, False,
                                      moved_from=moved.get(c.path),
                                      note="" if c.path in moved else note_of(items_for(c, details, details_by_id)),
                                      acked_by=acked_by))
        qrows = "\n".join(qparts)
        body += f"""
  <h3 style="margin:20px 0 6px;color:#57606a">그 밖의 알림 {len(quiet)}건
    <span style="font-weight:400;font-size:13px">— 이동·복사본·재저장·빈 파일 (내용 변경 아님)</span></h3>
  <table style="{_STYLE_TABLE};color:#57606a">{head_th}
    {qrows}
  </table>"""
    quiet_head = f' <span style="color:#57606a;font-weight:400;font-size:15px">(+그 밖의 알림 {len(quiet)}건)</span>' if quiet else ""

    return f"""<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>산출물 변경 브리핑 {_esc(date_str)}</title></head>
<body bgcolor="#ffffff" style="font-family:'Malgun Gothic',Segoe UI,sans-serif;color:#1f2328;
             background:#ffffff;max-width:860px;margin:0 auto;padding:24px;word-break:keep-all">
  <h2 style="margin:0 0 4px">{_esc(proj_label)}산출물 변경 브리핑 — {'기준선 등록' if baseline else '변경'} {n}건{quiet_head}
    {f'/ <span style="color:#cf222e">검토 필요 {len(issues)}건</span>' if issues else ''}</h2>
  {f'<p style="background:#eef2ff;border:1px solid #c7d2fe;padding:8px 12px;border-radius:6px;margin:0 0 12px">{_esc(merged_note)}</p>' if merged_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px">{_esc(baseline_note) if baseline_note else "첫 검사(기준선)입니다"} — 아래 파일들은 <b>변경이 아니라 감시 대상으로 등록</b>된 것입니다. 내일부터 달라진 것만 브리핑합니다.' + (' 검토 필요 항목은 지금 봐 둘 만합니다.' if issues else ' 이 메일은 보낼 필요가 없습니다.') + '</p>' if baseline else ''}
  <p style="color:#57606a;margin:0 0 16px">
    {_esc(date_str)} 기준 · 감시 폴더: <span title="{_esc(root)}">{_esc(_short_roots(root))}</span>{_esc(scanned_note)}{_esc(since_note)}</p>
  {_scan_errors_section(scan_errors) if scan_errors else ''}
  {f'<h3 style="margin:16px 0 8px">검토 필요 {len(issues)}건</h3>{_issues_section(issues, ack_base, project)}'
   if issues else ''}
  <h3 style="margin:16px 0 8px">변경 목록</h3>
  {'' if (baseline or not changes or not ack_base or '/ack?id=' not in body) else
   f'<p style="color:#57606a;font-size:12px;margin:0 0 8px">감시 PC에서는 '
   f'<a href="{_esc(ack_base)}/history?ack=none" style="color:#0969da">미확인 변경 목록</a>'
   f'에서 한꺼번에 확인할 수 있습니다. 각 행의 [확인했음 기록]은 그 변경의 근거 화면으로 갑니다.</p>'}
  {body}
  <p style="color:#8c959f;font-size:12px;margin-top:24px">
    Drev — 읽기 전용 감시. 이 메일은 변경 '사실'의 기록이며,
    내용 판단은 담당자가 합니다.{'' if (baseline or not changes or '/ack?id=' not in body) else ' 각 변경의 [확인했음 기록] 링크는 감시 PC에서 누르면 확인 이력으로 저장됩니다.'}</p>
</body>
</html>
"""


def brief_filename(run_at: datetime, project: str | None = None,
                   baseline: bool = False) -> str:
    # 표제란에서 온 프로젝트 문자열이 그대로 들어온다 — 경로 구분자·Windows 금지
    # 문자를 소독하지 않으면 파일 생성이 죽거나 brief_dir 밖에 쓰게 된다
    if project:
        safe = re.sub(r'[\\/:*?"<>|\s.]+', "_", project).strip("_") or "무명"
        suffix = f"_{safe}"
    else:
        suffix = ""
    # 기준선(첫 검사) 브리핑은 이름을 따로 둔다 — 같은 날 실제 변경 브리핑이 그 날 파일을
    # 쓰고, 재검사 때 합쳐 갱신할 수 있게 (2026-09-05 재검토)
    if baseline:
        suffix += "_기준선"
    return f"brief_{run_at.strftime('%Y%m%d')}{suffix}.html"
