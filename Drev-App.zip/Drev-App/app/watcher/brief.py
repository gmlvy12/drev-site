# -*- coding: utf-8 -*-
"""변경 목록 → 일일 브리핑 HTML.

Stage 2: 파일 수준 변경(추가/수정/삭제)만 담는다.
Stage 3에서 "확인 필요 M건 + 근거" 섹션이 추가된다 (build_brief의 구조는 그걸 수용하게 잡아둠).
메일 클라이언트 호환을 위해 인라인 스타일의 단순 테이블만 쓴다.
"""

from __future__ import annotations

import html
import re
from collections import Counter
from datetime import datetime
from pathlib import PurePosixPath

from watcher.state import KIND_LABEL as _KIND_LABEL
from watcher.state import Change

_KIND_COLOR = {"added": "#1a7f37", "modified": "#9a6700", "removed": "#cf222e"}
# 사양 단위를 품은 값 — 목차에서 접지 않을 '중요한' 글자 변경의 표식
# 전장·기구 사양 단위 — AT·AF(차단기 정격)·mA·kVA·m/min·MP·Nm·W가 빠져 'MCCB 100AT→125AT'가 "글자 변경
# 1건"으로만 보이고 Rev만 올린 도면 아래로 깔렸다 (검토21 브리핑 중간 6)
_UNIT_RE = re.compile(r"\d\s*(?:kW|KW|kw|㎾|kVA|kVAR|kvar|HP|mA|AT|AF|A|V|VDC|VAC|Hz|W|Nm|N·m|mm|㎜|MM|m/min|mm/s|"
                      r"SQ|㎟|rpm|RPM|bar|MPa|kPa|kg|EA|MP|℃|°C|Ø|φ)(?![A-Za-z])")

_STYLE_TABLE = "border-collapse:collapse;width:100%;font-size:14px"
# 확인 기록 켬/끔 (config ack_tracking, 기본 켬) — 끄면 브리핑에서 확인 열·회신 안내·미확인 동선을 뺀다 (기능 검토 2026-11-02 M5).
# 검사 한 회분 동안만 cli가 세운다(contextvars — 화면 스레드와 섞이지 않게)
import contextvars as _cv
ACK_ON: "_cv.ContextVar[bool]" = _cv.ContextVar("drev_ack_on", default=True)


def _ack_td(inner: str) -> str:
    return f'<td style="{_STYLE_TD}">{inner}</td>' if ACK_ON.get() else ""
_STYLE_TH = ("text-align:left;padding:6px 10px;border-bottom:2px solid #d0d7de;"
             "background:#f6f8fa;color:#57606a;white-space:nowrap")   # 머리는 짧다 — '구/분'·'수/정'으로 쪼개졌다 (검토44 C 낮음 1)
# 칸 안에서 긴 낱말도 접히게 — 메일 앱이 <style>(480px 미디어쿼리)을 버리면 폰(375px)에서 표가 478px로 넘쳤다
# (검토43 C 중간 7). 인라인이라야 살아남는다
_STYLE_TD = "padding:6px 10px;border-bottom:1px solid #d0d7de;overflow-wrap:anywhere;word-break:keep-all"  # 한글 낱말 안에서 꺾지 않게 (검토63 C3)


def human_ev(s: str) -> str:
    """근거 줄의 내부 표기를 사람 말로 — 저장 형식(재발 판정이 읽는다)은 그대로 두고 보일 때만. 'SPEC=125AT'·'BOM!행4'는
    구매 담당이 못 읽었다 (검토49 C 중간 8). 값·파일 이름·경로는 원본 그대로 — 일상어는 plain_words가 고른 위치 표기에만 (ux22 A)."""
    s = _EV_OLD_HEAD.sub(r"\1개정표", str(s or ""))     # 옛 머리 '리비전 블록 최신 행:'도 새 이름으로 (검토71 R4 중간 4)
    return _map_places(s, lambda t: _SPEC_WORD.sub("규격 ", t))


# 위치 표기의 일상어 — 메일·대장·사내망·감시 화면이 한 규칙 (ux21 daily 5·mail 8·10). 저장 문구(재발 판정·지문·캐시 키)는 그대로, 보일 때만.
# 위치 칸(plain_where)은 글 전체가 위치라 모두 바꾼다. 근거 줄(plain_words·human_ev)은 값·파일 이름·경로가 섞여 있어 — '위치, x=120, y=340 참조'가
# 'x=130'으로 바뀐 값이 사라졌고 '레이어 표준.dxf'가 '도면 층 표준.dxf'가 됐다(ux22 judge 1·web 2, 원칙 4) — 위치 꼴인 괄호와 '· 위치 …' 꼬리만 바꾼다
_SPEC_WORD = re.compile(r"(?<![\w/\\])SPEC=")
# 옛 판이 저장한 머리('리비전 블록 기재:'·'리비전 블록에 C 행을'·'Rev를 C로 올리면서 리비전 블록에') — 열린 옛 건·처리됨 목록에 남는다 (ux22 vx-check 5)
_EV_OLD_HEAD = re.compile(r"^((?:Rev를 \S+로 올리면서 )?)리비전 블록(?= (?:REV|Rev|최신)| 기재:|에 이번에|에 \S+ 행을|에서 )")
_SHEET_ROW_WORD = re.compile(r"(?<![\w/\\])([^\s(,!/\\]+)!행(\d+)")
# 키 없는 행의 줄 머리 'Sheet1!행5 수량: 1 → 2'·'Sheet1!행5: — → 품명=볼트'·'자재 목록!행5 수량: …' (ux22 vx-check 6·vy-check 3) — '항목: 값' 꼴만, 값 'BOM!행5 참조'는 그대로
# 시트 이름의 쉼표는 콜론·대괄호 없는 머리에서만 — Excel 시트 이름에 못 드는 글자라, '도면 E-101 [Rev A, 2026-07-10]: Sheet1!행5: 참조' 같은 값 줄을 머리로 읽지 않는다 (ux23 a 7)
_HEAD_ROW_WORD = re.compile(r"^([^,!/\\]{1,60}?|[^!/\\:?*\[\]]{1,60}?)!행(\d+)(?=:| [^:]{1,40}: )")
_LAYER_WORD_KO = re.compile(r"(?<![\w가-힣])레이어 (?=[^\s,()])")
_XY_NUM = r"-?\d+(?:\.\d+)?"
_COORD = rf",\s*x={_XY_NUM},\s*y={_XY_NUM}|,\s*좌표 \({_XY_NUM}, {_XY_NUM}\)"
# DXF 표제란 칸 좌표('표제란(레이어 TITLE, x=330, y=9)')·사진 설명 좌표('레이어 EQUIPMENT, 좌표 (140, 260)') — 위치 이름은 남기고 숫자만 뺀다
_XY_WORD = re.compile(rf",\s*x={_XY_NUM},\s*y={_XY_NUM}|(?<=[^\s,(]),\s*좌표 \({_XY_NUM}, {_XY_NUM}\)")
_DOC_NAME = re.compile(r"\.(?:dxf|dwg|pdf|xlsx?|xlsm|docx?|hwpx?)$", re.I)
_PLACE_AT = r"(?:(?:배치공간|배치) [^,()]+? |첫 틀 |틀 \d+ )?"     # 추출기가 위치 앞에 붙이는 말 — '배치공간 SHEET-2 레이어 EQUIP'·'틀 2 레이어 T'
_PLACE_LAYER_XY = re.compile(rf"{_PLACE_AT}레이어 [^,()]+(?:{_COORD})")
_PLACE_LAYER = re.compile(rf"{_PLACE_AT}레이어 [^\s,()]+")
_PLACE_BOX = re.compile(r"[^()]*(?:표제란|리비전 블록|개정표)[^()]*\([^()]*\)")   # '표제란(레이어 TITLE, x=330, y=9)'·'리비전 블록(블록 속성, x=1, y=2)'
_PLACE_ROW = re.compile(r".*!행\d+(?:\s*\(개정이력\))?")
_PLACE_OLD = re.compile(r".*\(개정이력\)|리비전 블록|(?:머리글|바닥글)[ (]\d+째 줄\)?")
_PLACE_MAX = 300                  # 위치 표기는 이보다 짧다 — 긴 글은 값으로 본다('개정표 '가 수만 번 든 값에서 _PLACE_BOX가 제곱 시간, ux22 vx-check 8)
_NOT_PATH_HEAD = re.compile(rf"[xy]={_XY_NUM}|좌표 \(")


def _is_place(w: str) -> bool:
    """글이 추출기가 만드는 위치 표기 꼴인가 — 아니면 값으로 보고 손대지 않는다."""
    w = w.strip()
    if len(w) > _PLACE_MAX:
        return False
    return bool(_PLACE_LAYER_XY.fullmatch(w) or (_PLACE_LAYER.fullmatch(w) and not _DOC_NAME.search(w))
                or _PLACE_BOX.fullmatch(w) or _PLACE_ROW.fullmatch(w) or _PLACE_OLD.fullmatch(w))


def _paren_spans(s: str) -> list:
    """짝이 맞는 가장 바깥 괄호들의 (여는 자리, 닫는 자리) — 값 속 짝 없는 괄호는 그 뒤 위치 괄호를 삼키지 않는다."""
    stack, pairs = [], []
    for k, ch in enumerate(s):
        if ch == "(":
            stack.append(k)
        elif ch == ")" and stack:
            pairs.append((stack.pop(), k))
    pairs.sort()
    out = []
    for a, b in pairs:
        if not out or a > out[-1][1]:
            out.append((a, b))
    return out


def _place_group(inner: str) -> str:
    """괄호 속 '위치'·'위치, 경로'·'변경 전후 동일, 위치' — 위치 조각만 일상어로, 경로는 원본 그대로."""
    pre = "변경 전후 동일, " if inner.startswith("변경 전후 동일, ") else ""
    inner = inner[len(pre):]
    # 앞에서부터 — 경로·파일 이름에 ', '가 들어도 위치 조각만 뗀다(뒤에서 자르면 경로 속 '레이어 표준'까지 바뀌었다, ux22 vx-check 4). 좌표는 위치의 일부
    for m in re.finditer(", ", inner):
        k = m.start()
        if k > _PLACE_MAX:
            break
        w, tail = inner[:k], inner[k + 2:]
        if ("/" in tail or "\\" in tail) and not _NOT_PATH_HEAD.match(tail) and w.count("(") == w.count(")") \
                and (_is_place(w) or w.startswith("레이어 ")):    # 경로 앞이면 위치 — 띄어 쓴 레이어 이름도
            return pre + plain_where(w) + ", " + tail
    return pre + (plain_where(inner) if _is_place(inner) else inner)


def _map_places(s: str, outside=None) -> str:
    """근거 줄 한 줄에서 위치 꼴 괄호와 끝의 '· 위치 …'만 바꾼다. outside: 괄호 바깥 글자에 걸 말 바꾸기(SPEC=)."""
    keep = outside or (lambda t: t)
    tail = ""
    s = _HEAD_ROW_WORD.sub(r"\1 시트 \2행", s)
    k = s.rfind(" · 위치 ")
    if k >= 0 and _is_place(s[k + 6:]):
        s, tail = s[:k], s[k:k + 6] + plain_where(s[k + 6:])
    out, pos = [], 0
    for a, b in _paren_spans(s):
        out += [keep(s[pos:a]), "(", _place_group(s[a + 1:b]), ")"]
        pos = b + 1
    return "".join(out) + keep(s[pos:]) + tail


def plain_words(s) -> str:
    """근거·안내 **줄**의 위치 표기만 일상어로: '… (BOM!행5, 서버/P/BOM.xlsx)'→'… (BOM 시트 5행, 서버/P/BOM.xlsx)',
    '(표제란(레이어 TITLE, x=330, y=9))'→'(표제란(도면 층 TITLE))'. 값·파일 이름·경로는 그대로. 여러 번 거쳐도 같다."""
    return _map_places(str(s or ""))


def plain_where(w) -> str:
    """메일·대장·사내망·화면의 위치 칸·사진 설명 — 글 전체가 위치: human_where(새 이름) + 시트 행·좌표·레이어 일상어."""
    s = _SHEET_ROW_WORD.sub(r"\1 시트 \2행", human_where(w))
    return _LAYER_WORD_KO.sub("도면 층 ", _XY_WORD.sub("", s))


PO_MARK_KEY = "발주 후 변경"        # issued.PO_MARK_KEY와 같은 글 (순환 가져오기를 피해 따로 둔다)
PO_MARK_LABEL = "발주 대조"
PO_MARK_TAIL = "발주서와 대조한 표시입니다. 업체 통보·재발주 여부는 구매 담당이 판단합니다"


def item_kind_label(it) -> str:
    """변경 항목 구분 이름 — 발주 후 변경 표지(CHECK_SKIPPED)는 공용 '검사 한계'가 아니라 '발주 대조' (ux21 mail 1, ux20 남김).
    메일·대장·사내망이 같이 쓴다."""
    kind = str(getattr(it, "kind", "") or "")
    if kind == "CHECK_SKIPPED" and str(getattr(it, "key", "") or "") == PO_MARK_KEY:
        return PO_MARK_LABEL
    return _ITEM_KIND.get(kind, (kind,))[0]


# 사내망 변경 확인 주소 (갈래 N, 2026-11-02 — FORMS.md 11절). 양식함이 켜져 있고 사내망 주소가 있을 때만 cli가 검사 시작 때
# set_lan_base로 정한다. 비어 있으면 브리핑은 지금과 같다(링크 없음 — 벤치·옛 메일 그대로)
LAN_BASE = ""


def set_lan_base(url) -> None:
    global LAN_BASE
    s = str(url or "").strip().rstrip("/")
    LAN_BASE = s if re.match(r"^https?://[^\s/\"'<>]+$", s) else ""


def lan_url(change_id=None, issue_path: str | None = None) -> str:
    """[사내망에서 보기·확인] 주소를 만드는 한 곳 — 변경은 /changes/<번호>, 검토 필요는 /changes/issues?f=<경로>. 기준 주소가 없으면 ''."""
    if not LAN_BASE:
        return ""
    if change_id is not None:
        try:
            return f"{LAN_BASE}/changes/{int(change_id)}"
        except (TypeError, ValueError):
            return ""
    if issue_path:
        from urllib.parse import quote as _q
        return f"{LAN_BASE}/changes/issues?f={_q(str(issue_path), safe='')}"
    return ""


def _lan_link(change_id=None, issue_path: str | None = None) -> str:
    u = lan_url(change_id, issue_path)
    # 확인 기록을 끈 집은 '보기'만 — 확인 단추가 없는 화면으로 가는 링크다 (재검토 rr066 mail 5)
    return (f'<a href="{_esc(u)}" style="color:#0969da;font-size:12.5px;white-space:nowrap">'
            f'{"사내망에서 보기·확인" if ACK_ON.get() else "사내망에서 보기"}</a>' if u else "")


# 메일 판 머리의 안내 한 줄 — 하루 한 통(digest_brief)이 프로젝트마다 반복되는 것을 맨 위 한 번으로 모으려고 이름을 붙인다 (rr066 mail 2)
REPLY_LINE = ('<p style="font-size:13.5px;margin:0 0 10px;color:#1f2328"><b>확인했으면 이 메일에 회신해 주세요</b> — '
              '회신하면 담당자가 확인으로 기록합니다 (변경마다 붙은 #번호를 적어 주시면 됩니다).</p>')
LAN_ACK_LINE = ('<p style="font-size:13.5px;margin:0 0 10px;color:#1f2328"><b>확인은 각 변경의 [사내망에서 보기·확인]에서</b> — '
                '양식함 계정으로 근거·전/후 사진을 보고 [확인함]을 누르면 기록됩니다 (사내망 PC에서만 열립니다).</p>')
LAN_VIEW_LINE = ('<p style="font-size:13.5px;margin:0 0 10px;color:#1f2328"><b>근거·전/후 사진은 각 변경의 [사내망에서 보기]에서</b> — '
                 '양식함 계정으로 엽니다 (사내망 PC에서만 열립니다).</p>')


def _loopback(base: str | None) -> bool:
    """확인 링크 주소가 감시 PC 자신(127.0.0.1·localhost)인가 — 그러면 수신자 PC에서는 열리지 않는다."""
    return bool(re.match(r"^\s*https?://(127\.\d+\.\d+\.\d+|localhost|\[::1\])(?::\d+)?(/|$)", str(base or ""), re.I))


# 양방향 제어문자 — 파일 이름 속 U+202E가 화면·브리핑·메일에서 글자 순서를 뒤집어 'x\u202efdp.exe'가 'xexe.pdf'로 보였다
# (보안 감사 2026-10-26). 표시할 때만 보이는 대체 문자 U+FFFD로 바꾼다 — 저장된 경로·키는 그대로
_BIDI = re.compile("[\u202a-\u202e\u2066-\u2069\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
# \uc81c\uc5b4 \ubb38\uc790(U+0000\u2013001F, \uc904\ubc14\uafc8\u00b7\ud0ed \ube7c\uace0)\ub3c4 \uac19\uc740 \ub300\uccb4 \ubb38\uc790\ub85c \u2014 ToUnicode \uc5c6\ub294 \ub0b4\uc7a5 \uae00\uaf34 PDF\uc758 \uae00\uc790\uac00 '\x10\x14\x13\u2026'\ub85c \uc77d\ud600
# \ube0c\ub9ac\ud551 \uba38\ub9ac\uc904\u00b7\uadfc\uac70\uc5d0 \uadf8\ub300\ub85c \uc2e4\ub838\ub2e4 (\uac80\ud1a020 r07 2, \uc6d0\uce59 4: \uc77d\uc744 \uc218 \uc788\ub294 \uadfc\uac70). \ube44\uad50\u00b7\uc800\uc7a5 \uac12\uc740 \uadf8\ub300\ub85c
BIDI_MARK = "\ufffd"


def no_bidi(s) -> str:
    """표시용 — 양방향 제어문자를 보이는 대체 문자(U+FFFD)로."""
    s = str(s)
    return _BIDI.sub(BIDI_MARK, s) if _BIDI.search(s) else s


def _esc(s: str) -> str:
    return html.escape(no_bidi(s), quote=True)


def num_prefix(path: str) -> str:
    """번호 앞말 — 도면 파일이면 '도면 ', 문서·BOM이면 '' (번호만). BOM·엑셀까지 '도면 P26-042-BOM-001'로 불러
    구매가 도면을 찾았다 (검토41 S6 중간 3)."""
    ext = PurePosixPath(str(path)).suffix.lower()
    if ext in (".dxf", ".dwg"):
        return "도면 "
    if ext in (".xlsx", ".xlsm", ".xls", ".docx", ".hwpx", ".hwp", ".doc"):
        return ""
    try:
        from watcher.doctype import kind_of
        return "도면 " if kind_of(str(path)) == "도면" else ""
    except Exception:
        return ""


# 오늘 꼭 봐야 할 변경이 아닌 알림(이동·복사본·재저장·빈 파일) — 화면과 메일이 같은 규칙으로
# 접는다 (2026-09-05 재검토: 화면 24건 / 메일 30행으로 숫자가 달랐다)
_QUIET_WORDS = ("이름·위치만", "옮겨짐", "복사본", "내용 변경 없음", "빈 파일", "재저장", "일자만 갱신", "표제란 틀만", "구판 정리", "순서만 바뀜",
                "배치만 바뀜")
_MOVE_MARK = "이름·위치만 바뀜 — 이전: "


def is_quiet(note: str) -> bool:
    """옮겨지며 내용도 바뀐 파일은 진짜 변경이라 접지 않는다 (2026-09-05 재검토 회귀)."""
    if not note:
        return False
    if "내용도 바뀜" in note or "그 판과 비교" in note or "(이름·폴더 변경)" in note:
        return False
    return any(w in note for w in _QUIET_WORDS)


_ORD_KO = ("첫째", "둘째", "셋째", "넷째", "다섯째", "여섯째", "일곱째", "여덟째", "아홉째", "열째")


def human_where(w) -> str:
    """사람에게 보이는 위치 문구 — 옛 기록(v0.57.46까지)의 '리비전 블록(…)'·'(개정이력)'·'머리글(1째 줄)'도 새 이름으로
    ('개정표'·'머리글 첫째 줄', 검토71 R4 중간 4). 판정은 원래 문구로 하므로 보여 줄 때만 바꾼다."""
    s = str(w or "")
    if not s:
        return s
    s = re.sub(r"리비전 블록", "개정표", s)
    s = re.sub(r"\(개정이력\)", "(개정표)", s)

    def _o(m):
        n = int(m.group(2))
        return f"{m.group(1)} {_ORD_KO[n - 1] if 1 <= n <= len(_ORD_KO) else f'{n}번째'} 줄"
    return re.sub(r"(머리글|바닥글)[ (](\d+)째 줄\)?", _o, s)


_SILENT_RESAVE = "내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표·그림 동일)"


RESAVED_MAIL_LINE = "다시 저장만 된 파일"     # 메일 한 줄 요약의 머리 (벤치 하네스가 이 줄을 '변경으로 실림'에서 뺀다)


def is_silent_resave(note: str) -> bool:
    """글자·표·그림을 모두 비교해 같았던 재저장인가 — 메일에서 뺀다(기록만). 일부만 읽은 쪽(·고지)이나 그림을 비교하지 않는
    형식('그림·개체는 비교하지 않습니다')은 아니다."""
    n = str(note or "")
    return n.startswith(_SILENT_RESAVE) and " · " not in n[len(_SILENT_RESAVE):]


# '비교하지 않습니다'는 v0.57.46까지의 기록 문구 — 화면 이력에 남은 옛 줄도 같은 뜻으로 읽는다. 새 문구는 메일과 같은 '비교하지 못함'
# (검토71 R4 낮음 12)
_UNCOMPARED_RESAVES = ("내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표 동일 — 그림·개체는 비교하지 못함",
                       "내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표 동일 — 그림·개체는 비교하지 않습니다")
_UNCOMPARED_RESAVE = _UNCOMPARED_RESAVES[0]


def is_uncompared_resave(note: str) -> bool:
    """글자·표는 같지만 그림·개체 부품을 읽지 못한(손상·옛 기록) 재저장인가 — 문서 안 그림만 바꾼 날일 수 있다.
    파일이 바뀐 사실은 메일에 한 줄 남긴다 (원칙 5, 검토69 B M2b). 부품까지 비교해 같으면 is_silent_resave다 (검토71 R4)."""
    n = str(note or "")
    return any(n.startswith(h) and " · " not in n[len(h):] for h in _UNCOMPARED_RESAVES)


def uncompared_resaves(changes, details: dict | None, details_by_id: dict | None = None) -> list:
    """그림·개체를 비교하지 못한 재저장(is_uncompared_resave) 변경들 — 그것뿐인 프로젝트도 메일 한 통을 낸다 (cli)."""
    _main, quiet, _moved = arrange_changes(changes, details, details_by_id)
    return [c for c in quiet if is_uncompared_resave(note_of(items_for(c, details, details_by_id)))]


def _unread_label(reason: str) -> str:
    """목차의 '못 읽음' 꼬리표를 사유대로 — 스캔본(OCR 꺼짐)·0바이트 뒤 처음 읽은 판까지 '손상·잘림 가능'이라 불러
    멀쩡한 파일을 깨진 줄 알게 했다 (경우100 B05·B09)."""
    if "OCR" in reason or "스캔" in reason or "글자 없는" in reason:
        return "스캔본(글자 없음)"
    if "암호" in reason:
        return "암호 걸림 — 읽지 못함"
    if "구버전 형식" in reason or "다른 프로그램 판의 형식" in reason:
        return "이전 판 기록이 다른 프로그램 판 형식 — 이번 판부터 비교"
    if "추출본 없음" in reason or "기록이 없" in reason:
        return "이전 판 기록 없음 — 이번 판부터 비교"
    if "잠겨" in reason or "권한" in reason:
        return "잠김·권한 — 다음 검사에서 다시"
    if "깨져" in reason or "읽을 수 없음" in reason or "끊겼" in reason:
        return "읽지 못함(손상·잘림 가능)"
    return "읽지 못함"


REV_DATE_NOTICE = "확인 필요"       # cli.REV_DATE_KEY와 같은 이름표 — Rev를 올렸는데 일자는 그대로 (J7)


def notice_text(i, full: bool = False) -> str:
    """안내 띠 글 — '확인 필요'(Rev 올림·일자 그대로)는 한 줄로: 'Rev A→B로 올렸지만 표제란 일자는 그대로입니다 (2026-09-01) —
    일자 칸을 새 Rev의 날짜로 고쳤는지 확인하세요'. 저장된 글에는 같은 일자를 두 번(DATE: x → x)과 레이어·좌표가 붙어 묶음 메일에서
    여섯 번 길게 반복됐다 (ux20 mail 4). 앞 문장에 그 일자(이전=새 값)와 자리(표제란 일자 칸·개정표 최신 행)가 있다(원칙 4) —
    전체 근거는 감시 PC 화면의 변경 상세에 그대로. full=True(대장·사내망)는 줄이지 않고 전문 — 메일용 요약이 기록까지 번지면 안 된다 (ux22 judge 4)."""
    t = str(getattr(i, "new", "") or "")
    if getattr(i, "key", "") == PO_MARK_KEY and getattr(i, "kind", "") == "CHECK_SKIPPED":
        # 발주 후 변경 — 할 일을 지시하지 않고 누가 판단하는지만 (원칙 6). 신입 구매가 '그래서 뭘 하라는 건지' 몰랐다 (ux21 mail 1)
        return plain_words(t) + " — " + PO_MARK_TAIL
    if full or getattr(i, "key", "") != REV_DATE_NOTICE or " — " not in t:
        return plain_words(t)
    head, _, rest = t.partition(" — ")
    act = rest.rsplit(" · ", 1)[-1].strip() if " · " in rest else ""
    return head.rstrip(". ") + (f" — {act}" if act.endswith("확인하세요") else "")


def rev_date_count(changes, details: dict | None, details_by_id: dict | None = None) -> int:
    """'확인 필요'(Rev 올림·일자 그대로) 표지가 붙은 변경 수 — 프로젝트 머리에 한 번 센다 (ux20 mail 4)."""
    return sum(1 for c in changes or () if any(getattr(it, "kind", "") == "CHECK_SKIPPED" and getattr(it, "key", "") == REV_DATE_NOTICE
                                               for it in items_for(c, details, details_by_id)))


def same_name_folder(path: str, all_paths) -> str:
    """같은 이름의 파일이 같은 프로젝트(감시 폴더 아래 맨 위 폴더) 안에 또 있으면 이 파일의 부모 폴더 이름, 아니면 '' (ux20 daily 1).
    '작업중_사본/E-101.dxf'만 바뀐 날 메일 머리 한 줄이 'E-101 …'이라 원본 도면이 바뀐 줄 알았다 — 화면(web.py)도 같은 함수를 쓴다.
    all_paths: 지금 감시 중인 파일 경로들(감시 폴더 이름표부터, '/' 구분)."""
    pp = PurePosixPath(str(path or ""))
    name = pp.name.casefold()
    if not name or len(pp.parts) < 2:
        return ""
    top = pp.parts[:2] if len(pp.parts) > 2 else pp.parts[:1]
    for o in all_paths or ():
        op = PurePosixPath(str(o))
        if op.name.casefold() == name and op != pp and op.parts[:len(top)] == top and op.parent != pp.parent:
            return pp.parent.name
    return ""


def note_of(items) -> str:
    """변경 상세의 '참고' 문구(복사본·이동·빈 파일 …) — 없으면 빈 문자열."""
    for it in items or []:
        if getattr(it, "kind", None) == "CHECK_SKIPPED" and getattr(it, "key", None) == "참고":
            return str(it.new or "")
    return ""


def items_for(c, details: dict | None, details_by_id: dict | None = None):
    """변경 한 건의 상세 — 같은 파일이 하루에 두 번이면 변경 id별 상세가 우선.
    경로 키만 쓰면 나중 변경의 '재저장' 참고가 앞선 진짜 변경에 붙었다 (파일럿 모의 ①)."""
    if details_by_id and c.id is not None and c.id in details_by_id:
        return details_by_id[c.id]
    return (details or {}).get(c.path, [])


def change_weight(items) -> int:
    """변경의 무게 — 사양값(kW·A·mm…)이나 표 행 > Rev > 다른 글자·그림 > 날짜만.
    팀장은 위에서부터 읽는다 (파일럿 모의 ④: Rev만 오른 도면이 MCCB 변경보다 위에)."""
    has_row = any(it.kind.startswith("ROW_") and it.kind != "ROW_MOVED" for it in items)   # 순서만은 행 변경 아님
    has_unit = any(it.kind.startswith("TEXT_") and _UNIT_RE.search(
        str(it.old or "") + " " + str(it.new or "")) for it in items)
    if has_row or has_unit:
        return 0
    from watcher.diff import field_base, is_rev_field
    if any(is_rev_field(it) for it in items):
        return 1
    if any(it.kind.startswith(("TEXT_", "PAGE_VISUAL", "ROW_", "REVROW", "SHEET"))
           or (it.kind == "FIELD_CHANGED" and field_base(it.key) not in ("DATE",)) for it in items):
        return 2
    return 3


def arrange_changes(changes, details: dict | None, details_by_id: dict | None = None):
    """브리핑 순서를 정한다 → (주요 변경, 그 밖의 알림, {id(변경): 이전 경로}).

    같은 지문의 '삭제 + 추가'(이름·위치 변경)는 추가 쪽 한 행으로 접고(이동), 복사본·재저장·
    빈 파일·이동은 '그 밖의 알림'으로 뒤에 둔다. 주요 변경은 수정 → 추가 → 삭제, 그 안에서
    변경의 무게(사양·표 > Rev > 글자·그림 > 날짜) → 유형 중요도 → 경로 순."""
    from watcher.doctype import doc_rank, kind_of
    details = details or {}
    notes = {id(c): note_of(items_for(c, details, details_by_id)) for c in changes}
    # 변경 **한 건** 단위 — 경로로 잡으면 아침에 옮긴 파일을 오후에 고친 그 수정(같은 경로, 다른 변경)까지 '이동'으로
    # 접혀 메일에서 사라졌다. 퍼즈 두 시드에서 269건, Rev 올림·BOM 행·사양 변경 모두 (검토59 F4b-1·F5 F1 차단)
    moved: dict[int, str] = {}
    hide: set = set()
    removed_by_path: dict[str, list] = {}
    for c in changes:
        if c.kind == "removed":
            removed_by_path.setdefault(c.path, []).append(c)
    for c in changes:
        n = notes.get(id(c), "")
        if c.kind == "added" and _MOVE_MARK in n:
            prev = n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
            for x in removed_by_path.get(prev, []):
                if id(x) not in hide:
                    hide.add(id(x))
                    moved[id(c)] = prev
                    break
    # 옮겨지며 내용도 바뀐 파일(이름 짝)은 '추가' 쪽에 비교가 실린다 — 삭제 행까지 두면 한 파일이
    # "변경 2건"에 빨간 삭제 라벨로 나왔다 (검토21 브리핑 차단 3). 삭제 쪽은 접는다
    added_paths = {c.path for c in changes if c.kind == "added"}
    for c in changes:
        n = notes.get(id(c), "")
        if c.kind == "removed" and "옮겨지며 내용도 바뀜" in n:
            tgt = n.split("(으)로 옮겨지며", 1)[0].strip()
            if tgt in added_paths:
                hide.add(id(c))
    kept = [c for c in changes if id(c) not in hide]
    quiet = [c for c in kept if id(c) in moved or is_quiet(notes.get(id(c), ""))]
    qids = {id(c) for c in quiet}
    order = {"modified": 0, "added": 1, "removed": 2}

    def _rank(c):
        try:
            r = doc_rank(kind_of(c.path, None))
        except Exception:
            r = 50
        # 같은 파일이 하루에 두 번이면 시간순(변경 id) — 최신이 위에 오면 A→B가 B→C 아래에 놓였다
        return (order.get(c.kind, 3), change_weight(items_for(c, details, details_by_id)),
                r, c.path.lower(), c.id or 0)
    main = sorted((c for c in kept if id(c) not in qids), key=_rank)
    return main, quiet, moved


def brief_counts(changes, details: dict | None, details_by_id: dict | None = None) -> tuple[int, int]:
    """(주요 변경 수, 그 밖의 알림 수) — 제목·메일 제목이 화면과 같은 수를 말하게."""
    main, quiet, _ = arrange_changes(changes, details, details_by_id)
    return len(main), len(quiet)


def _change_row(c: Change, ack_base: str | None, ack_tokens: dict | None,
                info: dict | None = None, baseline: bool = False,
                moved_from: str | None = None, note: str = "",
                acked_by: dict | None = None, compact: bool = False) -> str:
    if compact and not moved_from and not note and not baseline:
        return _change_row_mail(c, ack_base, ack_tokens, info, acked_by)
    p = PurePosixPath(c.path)
    old = (c.old_sha256 or "—")[:12]
    new = (c.new_sha256 or "—")[:12]
    color = "#57606a" if moved_from else _KIND_COLOR[c.kind]
    kind_label = ("이동" if moved_from else
                  "첫 등록" if (baseline and c.kind == "added") else _KIND_LABEL[c.kind])
    token = (ack_tokens or {}).get(c.id)
    if c.id and (acked_by or {}).get(c.id):
        ack = f'<span style="color:#1a7f37">확인됨 — {_esc(str(acked_by[c.id]))}</span>'
    elif ack_base and c.id and token and not baseline and not moved_from and not is_quiet(note or ""):
        # 이동·재저장·복사본은 확인 대상이 아니다(화면도 미확인에서 뺀다) — 행마다 링크가 있어
        # "확인만 하면 됩니다"로 읽혔다 (검토30 C 1-2)
        # 화면은 감시 PC에서만 열린다 — 다른 PC의 수신자에게는 매일 죽은 링크였다.
        # 링크 글에 그 사실을 붙인다 (검토19 브리핑 ⑬). 기준선(등록)에는 확인이 필요 없다
        ack = (f'<a href="{_esc(ack_base)}/ack?id={c.id}&amp;t={_esc(token)}" '
               f'style="color:#0969da">확인했음 기록</a>'
               f'<span style="color:#57606a;font-size:11px"> (감시 PC에서)</span>')
        if _loopback(ack_base):
            # 127.0.0.1 링크는 수신자 PC에서 '연결할 수 없음'이다 — 메일의 유일한 행동 단추가 죽은 파란 링크였다 (검토49 C
            # 차단 3). 사내 주소를 설정했을 때만 링크, 아니면 감시 PC에서 찾아갈 곳을 글로
            # 두 줄(회색 11px)이 눈에 안 띄었다 — 한 줄 링크로, 감시 PC에서만 열린다는 말은 머리 안내 한 번 (검토54 ③15)
            # 파란 '#번호 확인'은 다시 다른 PC에서 누르는 죽은 링크가 됐다 — 번호는 글로, 링크는 '감시 PC에서'라고 밝힌 작은 회색으로 (검토55 ⑤25 퇴행)
            ack = (f'<span style="color:#57606a;font-size:13px;white-space:nowrap">#{c.id}</span> '
                   f'<a href="{_esc(ack_base)}/ack?id={c.id}&amp;t={_esc(token)}" '
                   f'style="color:#57606a;font-size:12px;white-space:nowrap">감시 PC에서 확인</a>')
    else:
        ack = "—"
    _ln = _lan_link(c.id) if (c.id and not baseline and not moved_from and not is_quiet(note or "")) else ""
    if _ln:                                       # 사내망 변경 확인 (갈래 N) — 양식함이 켜져 있고 사내망 주소가 있을 때만
        ack = _ln if ack == "—" else f"{ack}<br>{_ln}"
    _ln_file = "" if ACK_ON.get() else _ln        # 확인 칸이 없는 집은 파일 칸에 (rr066 mail 5)
    # 실무 언어는 파일명이 아니라 도면번호·Rev — 표제란 값이 있으면 앞세운다
    # (설계 10년차 검토 반영, 2026-08-28)
    if info and info.get("dwg"):
        rev = f' Rev {_esc(info["rev"])}' if info.get("rev") else ""
        file_cell = (f'<strong>{num_prefix(c.path)}{_esc(info["dwg"])}</strong>{rev}'
                     f'<br><span style="color:#57606a;font-size:12px">'
                     f'{_esc(p.name)}</span>')
    else:
        file_cell = _esc(p.name)
    if moved_from:
        file_cell += (f'<br><span style="color:#57606a;font-size:12px">이전: '
                      f'{_esc(moved_from)}</span>')
    elif note:
        file_cell += f'<br><span style="color:#57606a;font-size:12px">{_esc(note)}</span>'
    if info and info.get("mtime"):
        # 문서를 언제 고쳤나 — 검사 시각(머리글)과 별개 (2026-09-17 사용자 요청)
        try:
            _saved = saved_stamp(info["mtime"])
            _who = f" · 저장자 {_esc(info['who'])}" if info.get("who") else ""     # 누가 저장했나 (구매자 평가 P1·P4)
            file_cell += f'<br><span style="color:#57606a;font-size:12px">저장 {_saved}{_who}</span>'
        except (TypeError, ValueError, OSError, OverflowError):
            pass
    if _ln_file:
        file_cell += f"<br>{_ln_file}"
    # 파일 지문(해시)은 화면·DB에 있다 — 브리핑에서는 근거로 읽히지 않아 뺀다
    # (2026-09-05 전체 검토: "모든 행의 지문 e3a9… → 9745…는 설계팀장에게 근거가 아니다")
    return (
        f'<tr>'
        f'<td class="k" style="{_STYLE_TD}"><strong style="color:{color}">{kind_label}</strong></td>'
        f'<td style="{_STYLE_TD}" title="지문 {old} → {new}">{file_cell}</td>'
        f'<td style="{_STYLE_TD}">{_esc(str(p.parent))}</td>'
        + _ack_td(ack) +
        f'</tr>'
    )


def saved_stamp(mtime, now: float | None = None) -> str:
    """파일 저장 시각 표기 — 올해면 '10-27 09:50', 다른 해면 연도까지. 3000년 저장 시각이 '01-01 09:00'으로만 찍혀
    미래인지 알 수 없었다 (재검토 2026-10-28 R8-5). 이 PC 시계보다 하루 넘게 앞서면 그렇다고 붙인다(사실만)."""
    import time as _time
    ts = float(mtime)
    d = datetime.fromtimestamp(ts)
    now = _time.time() if now is None else now
    fmt = "%m-%d %H:%M" if d.year == datetime.fromtimestamp(now).year else "%Y-%m-%d %H:%M"
    return d.strftime(fmt) + (" (이 PC 시계보다 미래)" if ts > now + 86400 else "")


def _ack_cell_mail(c, ack_base, ack_tokens, acked_by) -> str:
    """메일 판의 확인 칸 — 감시 PC 주소(127.0.0.1)면 받는 사람 PC에서 열리지 않는 링크 대신 #번호만(회신 안내는 머리에 한 번).
    사내 주소를 설정했으면 링크. 양식함 사내망 주소가 있으면 [사내망에서 보기·확인]을 덧붙인다 (갈래 N)."""
    _ln = _lan_link(c.id) if c.id else ""
    if c.id and (acked_by or {}).get(c.id):
        return f'<span style="color:#1a7f37">확인됨 — {_esc(str(acked_by[c.id]))}</span>' + (f"<br>{_ln}" if _ln else "")
    token = (ack_tokens or {}).get(c.id)
    if not (ack_base and c.id and token):
        return _ln or "—"
    if _loopback(ack_base):
        return f'<span style="color:#57606a;font-size:13px;white-space:nowrap">#{c.id}</span>' + (f"<br>{_ln}" if _ln else "")
    return (f'<a href="{_esc(ack_base)}/ack?id={c.id}&amp;t={_esc(token)}" style="color:#0969da;white-space:nowrap">'
            f'확인했음 기록</a>') + (f"<br>{_ln}" if _ln else "")


def _change_row_mail(c, ack_base, ack_tokens, info, acked_by) -> str:
    """메일 판의 변경 행 — 도면번호·Rev, 파일 이름·저장(한 줄), 마지막 폴더 이름(전체 경로는 title), #번호."""
    p = PurePosixPath(c.path)
    color = _KIND_COLOR[c.kind]
    sub = [_esc(p.name)]
    if info and info.get("mtime"):
        try:
            _saved = saved_stamp(info["mtime"])
            sub.append(f"저장 {_saved}" + (f" · {_esc(info['who'])}" if info.get("who") else ""))
        except (TypeError, ValueError, OSError, OverflowError):
            pass
    if info and info.get("dwg"):
        rev = f' Rev {_esc(info["rev"])}' if info.get("rev") else ""
        head = f'<strong>{num_prefix(c.path)}{_esc(info["dwg"])}</strong>{rev}<br>'
    else:
        head = ""
    file_cell = f'{head}<span style="color:#57606a;font-size:12px">{" · ".join(sub)}</span>' if head else \
        f'{_esc(p.name)}<span style="color:#57606a;font-size:12px">{(" · " + sub[1]) if len(sub) > 1 else ""}</span>'
    if not ACK_ON.get() and c.id:
        # 확인 기록을 끄면 확인 칸(_ack_td)이 통째로 빠져 그 안의 [사내망에서 보기]도 사라졌다 — 열람 링크는 파일 칸에 (rr066 mail 5)
        _ln = _lan_link(c.id)
        file_cell += f"<br>{_ln}" if _ln else ""
    return (f'<tr><td class="k" style="{_STYLE_TD}"><strong style="color:{color}">{_KIND_LABEL[c.kind]}</strong></td>'
            f'<td style="{_STYLE_TD}">{file_cell}</td>'
            f'<td style="{_STYLE_TD};color:#57606a;font-size:12px" title="{_esc(str(p.parent))}">{_esc(p.parent.name)}</td>'
            + _ack_td(_ack_cell_mail(c, ack_base, ack_tokens, acked_by)) + '</tr>')


def _companion_row(c, summary: str, ack_base, ack_tokens, acked_by) -> str:
    """같은 도면의 출도 PDF — DXF 행 밑에 한 줄 (그 PDF의 바뀐 내용 요약 + 이름, 상세·사진은 화면)."""
    p = PurePosixPath(c.path)
    return (f'<tr><td class="k" style="{_STYLE_TD}"><span style="color:{_KIND_COLOR[c.kind]};font-size:13px">'
            f'출도 PDF</span></td>'
            f'<td style="{_STYLE_TD};font-size:13px" colspan="2">{_esc(p.name)} — {_esc(summary)}'
            f'<span style="color:#57606a;font-size:12px"> (같은 도면의 출도본 · 상세·사진은 화면)</span>'
            + ("" if (ACK_ON.get() or not c.id or not _lan_link(c.id)) else f"<br>{_lan_link(c.id)}") + '</td>'
            + _ack_td(_ack_cell_mail(c, ack_base, ack_tokens, acked_by)) + '</tr>')


def _kdate(iso) -> str:
    """ISO 시각 → 'MM-DD'(이 PC 시간대). 못 읽으면 앞 10자."""
    try:
        return datetime.fromisoformat(str(iso)).astimezone().strftime("%m-%d")
    except (TypeError, ValueError, OSError, OverflowError):
        return str(iso or "")[:10]


def _card_ev(i) -> str:
    """묶음 카드의 파일별 한 줄 — 'REV: A (변경 전후 동일)'·'이번 변경:' 머리 말고 **무엇이 바뀌었는지** (검토45 C 낮음 1)."""
    evs = [str(e) for e in (i.evidence or ())]
    body = next((e for e in evs if "(변경 전후 동일)" not in e and not e.rstrip().endswith(("예시:", "이번 변경:"))), None)
    return body or (evs[0] if evs else i.message)


def _short(t: str, n: int) -> str:
    t = " ".join(str(t or "").split())
    return t if len(t) <= n else t[:n - 1] + "…"


def _folders_of(doc_info) -> dict:
    """{경로: 같은 이름 파일이 프로젝트에 또 있을 때의 부모 폴더 이름} — cli가 doc_info[경로]['folder']로 넘긴다 (ux20 daily 1)."""
    return {k: v["folder"] for k, v in (doc_info or {}).items()
            if isinstance(k, str) and isinstance(v, dict) and v.get("folder")}


def card_ev(evs) -> list:
    """카드 근거 줄 — 머리 '이번 변경:'만 든 줄은 다음 줄(그 한 건)과 한 줄로. 빈 글머리 뒤에 값이 다음 글머리로 떨어져
    읽혔다 (ux21 mail 11). 저장 근거는 그대로, 보일 때만."""
    out = []
    evs = [str(e) for e in (evs or ())]
    k = 0
    while k < len(evs):
        e = evs[k]
        if e.rstrip().endswith("이번 변경:") and k + 1 < len(evs) and not evs[k + 1].startswith("── ") \
                and not evs[k + 1].rstrip().endswith(":"):
            out.append(f"{e.rstrip()} {evs[k + 1].strip()}")
            k += 2
            continue
        out.append(e)
        k += 1
    return out


def _name_tail(path: str, folders: dict | None) -> str:
    """메일 카드의 파일 이름 + 같은 이름 폴더 꼬리 — '작업중_사본' 파일 카드가 원본과 같은 이름으로만 보였다 (ux21 mail 3)."""
    f_ = (folders or {}).get(path)
    return PurePosixPath(path).name + (f" ({f_} 폴더)" if f_ else "")


def _issues_section(issues, ack_base: str | None = None, project: str | None = None,
                    recurred: dict | None = None, compact: bool = False, folders: dict | None = None) -> str:
    from watcher.consistency import CODE_LABEL
    blocks = []
    if compact:
        return _issues_section_mail(issues, recurred, folders)
    if ack_base and _loopback(ack_base):
        # 127.0.0.1 링크는 수신자 PC에서 열리지 않는다 — 글로만 (검토50 B 중간 5)
        blocks.append('<p style="color:#57606a;font-size:12px;margin:0 0 6px">감시 PC 화면 › 검토 필요에서 '
                      '[처리함]·전/후 비교를 할 수 있습니다.</p>')
    elif ack_base:
        # 변경 행에는 [확인했음 기록] 링크가 있는데 검토 필요 블록에는 동선이 없었다 (검토24 C-1)
        from urllib.parse import quote as _q
        blocks.append(
            f'<p style="color:#57606a;font-size:12px;margin:0 0 6px">감시 PC 화면의 '
            f'<a href="{_esc(ack_base)}/issues{("?p=" + _q(project)) if project else ""}" '
            f'style="color:#0969da">검토 필요 목록</a>에서 [처리함]·전/후 비교를 할 수 있습니다.</p>')
    # 같은 종류가 5장 이상이면 한 장으로 — 백업을 되돌린 날 'Rev가 거꾸로 감' 카드 12장이 똑같이 이어졌다 (검토43 C 중간 5).
    # 묶은 카드에도 파일마다 근거 첫 줄을 싣는다 — '예:' 한 줄만으로는 나머지 파일의 구/신 값이 메일에 없었다 (검토44 A 낮음 4)
    from collections import Counter as _Cn
    _n = _Cn(i.code for i in issues)
    _many = {c for c, k in _n.items() if k >= 5 and c in ("REV_REGRESSED", "CONTENT_CHANGED_REV_SAME", "REV_CHANGED_CONTENT_SAME")}
    for code in sorted(_many):
        grp = [i for i in issues if i.code == code]
        names = ", ".join(PurePosixPath(i.path).name for i in grp[:8]) + (f" 외 {len(grp) - 8}개" if len(grp) > 8 else "")
        blocks.append(f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 10px;background:#fff5f5">
    <strong style="color:#cf222e">{_esc(CODE_LABEL[code])} {len(grp)}건</strong>
    <div style="margin:4px 0 2px">{_esc(names)}</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px"><li style="color:#57606a">예: {_esc(grp[0].message)}</li>
    {"".join(f'<li style="color:#57606a">{_esc(PurePosixPath(i.path).name)} — {_esc(_short(human_ev(_card_ev(i)), 90))}</li>' for i in grp[:15])}
    {f'<li style="color:#57606a">외 {len(grp) - 15}개 — 감시 PC 화면의 검토 필요 목록에 모두 있습니다</li>' if len(grp) > 15 else ''}</ul>
  </div>""")
    for iss in issues:
        if iss.code in _many:
            continue
        _was = (recurred or {}).get((iss.code, iss.path, iss.message))
        _again = (f'&nbsp;<span style="background:#ffebe9;color:#a40e26;border-radius:4px;padding:1px 6px;font-size:12px">'
                  f'다시 생김 — {_esc(_kdate(_was))}에 해소됐던 같은 문제</span>') if _was else ""
        evidence = "".join(
            f'<li style="color:#57606a">{_esc(human_ev(ev))}</li>' for ev in card_ev(iss.evidence))
        blocks.append(f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 10px;background:#fff5f5">
    <strong style="color:#cf222e">{_esc(CODE_LABEL[iss.code])}</strong>{_again}
    &nbsp;<code>{_esc(iss.path)}</code>{(" " + _lan_link(issue_path=iss.path)) if LAN_BASE else ""}
    <div style="margin:4px 0 2px">{_esc(iss.message)}</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{evidence}</ul>
  </div>""")
    return "\n".join(blocks)


def _issues_section_mail(issues, recurred: dict | None = None, folders: dict | None = None) -> str:
    """메일 판 검토 필요 — 카드마다 파일 이름(전체 경로는 title), 근거 줄의 서버 경로는 파일 이름으로, 'Rev 미갱신' 카드마다 붙던
    '(발행 전 작업본이면 무시하세요 — …)'는 끝에 한 번 (구매 평가 2차 F2). 같은 종류 5장 이상은 화면과 같이 한 장으로."""
    from watcher.consistency import CODE_LABEL
    blocks = []
    _n = Counter(i.code for i in issues)
    _many = {c for c, k in _n.items() if k >= 5 and c in ("REV_REGRESSED", "CONTENT_CHANGED_REV_SAME", "REV_CHANGED_CONTENT_SAME")}
    hint = False
    box = ('border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;padding:8px 12px;margin:0 0 8px;'
           'background:#fff5f5')
    for code in sorted(_many):
        grp = [i for i in issues if i.code == code]
        hint = hint or any(REVSAME_HINT in i.message for i in grp)
        lis = "".join(f'<li>{_esc(_name_tail(i.path, folders))} — {_esc(_short(short_paths(human_ev(_card_ev(i))), 90))}</li>'
                      for i in grp[:15])
        if len(grp) > 15:
            lis += f'<li>외 {len(grp) - 15}개 — 감시 PC 화면의 검토 필요 목록에 모두 있습니다</li>'
        blocks.append(f'<div style="{box}"><strong style="color:#cf222e">{_esc(CODE_LABEL[code])} {len(grp)}건</strong>'
                      f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px;color:#57606a">{lis}</ul></div>')
    for iss in issues:
        if iss.code in _many:
            continue
        msg = iss.message
        if REVSAME_HINT in msg:
            hint = True
            msg = " ".join(" ".join(msg.split(REVSAME_HINT)).split())     # replace()는 읽기 전용 가드가 막는다
        _was = (recurred or {}).get((iss.code, iss.path, iss.message))
        _again = (f' <span style="background:#ffebe9;color:#a40e26;border-radius:4px;padding:1px 6px;font-size:12px">'
                  f'다시 생김 — {_esc(_kdate(_was))}에 해소됐던 같은 문제</span>') if _was else ""
        # 근거는 네 줄까지 — 그림 변경 '위치1·위치2·위치3·외 7곳'이 카드마다 그대로 이어졌다(같은 것이 아래 변경 상세에 있다)
        _ev = card_ev(iss.evidence)
        evs = "".join(f'<li>{_esc(short_paths(human_ev(ev)))}</li>' for ev in _ev[:4])
        if len(_ev) > 4:
            evs += f'<li>외 {len(_ev) - 4}줄 — 아래 변경 상세·감시 PC 화면</li>'
        blocks.append(f'<div style="{box}"><strong style="color:#cf222e">{_esc(CODE_LABEL[iss.code])}</strong>{_again}'
                      f' <span style="color:#57606a;font-size:12px" title="{_esc(iss.path)}">{_esc(_name_tail(iss.path, folders))}</span>'
                      + ((" " + _lan_link(issue_path=iss.path)) if LAN_BASE else "")      # 사내망 (갈래 N)
                      + f'<div style="margin:3px 0 2px">{_esc(msg)}</div>'
                      f'<ul style="margin:2px 0 0;padding-left:20px;font-size:13px;color:#57606a">{evs}</ul></div>')
    if hint:
        blocks.append('<p style="color:#57606a;font-size:12.5px;margin:0 0 8px">\'Rev 미갱신\'은 발행 전 작업본이면 무시해도 '
                      '됩니다 — 발행 때 Rev를 올리면 저절로 풀립니다.</p>')
    return "".join(blocks)


def _fmt_row_values(s: str | None) -> str:
    """diff가 str(dict)로 남긴 행 값을 'TAG=.., SPEC=..' 꼴로 정리."""
    import ast
    try:
        d = ast.literal_eval(s or "")
        return ", ".join(f"{k}={_group_digits(str(v))}" for k, v in d.items() if str(v).strip())   # 행 추가·삭제도 천 단위 (검토55 ④1)
    except (ValueError, SyntaxError):
        return s or ""


def delta_num(d: float) -> str:
    """증감 숫자 — 금액이 '+1.3e+06'으로 나왔다, 영업·경리는 읽을 수 없다 (검토54 ⑤ 차단). 정수는 천 단위, 소수는 4자리까지.
    화면도 같은 함수를 쓴다 — 메일만 고쳐 화면은 '+1e+06'이 남았다 (검토55 ⑤21)."""
    return f"{int(round(d)):,}" if abs(d - round(d)) < 1e-9 else f"{d:,.4f}".rstrip("0").rstrip(".")


def _delta_badge(old: str | None, new: str | None) -> str:
    """수량처럼 숫자인 값의 증감 배지 (+2 초록 / -1 빨강) — Odoo BOM 비교 규칙."""
    try:
        d = float(new) - float(old)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return ""
    if d == 0:
        return ""
    color = "#1a7f37" if d > 0 else "#cf222e"
    sign = "+" if d > 0 else ""
    num = delta_num(d)
    return (f' <span style="color:{color};font-weight:700;white-space:nowrap">'
            f"({sign}{num})</span>")


def sheet_kind(path: str, cfg: dict | None = None) -> str:
    """표 문서의 성격 — 분류 규칙(watcher.doctype)에 위임한다.
    회사마다 양식·명칭이 달라 규칙을 데이터로 뺐다 (2026-08-31)."""
    from watcher.doctype import UNKNOWN, kind_of
    k = kind_of(path, cfg)
    return "" if k in (UNKNOWN, "표", "문서", "도면") else k


_IMPACT_KINDS = ("BOM", "발주서", "견적서", "자재표", "구매")


def impact_label(path: str, cfg: dict | None = None) -> str:
    """행 변경 요약 줄의 이름 — 구매로 이어지는 표(BOM·발주서·견적서·자재표)만 '발주 영향', 도면목록·성적서·
    개정이력 같은 표는 '변경 요약' (2026-09-06 사용성 3차 ④-7)."""
    from watcher.doctype import canonical, kind_of
    k = canonical(sheet_kind(path, cfg) or "")
    if "견적" in k:
        return "견적 영향"          # 견적은 발주가 아니다 — 고객 제시 단가·합계·납기 (검토54 ⑤21)
    if any(w in k for w in _IMPACT_KINDS):
        return "발주 영향"
    # 도면(pdf·dxf·dwg) 위의 부품표는 BOM이다 — 엑셀 '도면목록'은 아니다
    if PurePosixPath(path).suffix.lower() in (".pdf", ".dxf", ".dwg") and canonical(kind_of(path, cfg)) == "도면":
        return "발주 영향"
    return "변경 요약"


def table_label(path: str, cfg: dict | None = None) -> str:
    """화면·메일에 쓰는 표 변경 이름표: '표(인터락)' / '표(BOM)' / '표'."""
    kind = sheet_kind(path, cfg)
    return f"표({kind})" if kind else "표"


# 조각이 제 이름을 달고 있다 — 'CABLE: CV 4SQ x 4C'·'비고: …'. 이런 글줄에 가장 가까운 태그 이름표를 붙이면 'INV-11: CABLE: CV 4SQ
# x 4C → …'처럼 이웃 기기의 사양처럼 읽혔다 (재검토 2026-10-26 D3)
_SELF_NAMED = re.compile(r"^\s*[A-Za-z가-힣][A-Za-z가-힣 .()/_&]{0,20}?\s*[:：]\s*\S")


def pair_label(i) -> str:
    """diff.pair_label에서 제 이름을 단 조각(이웃 태그가 이름이 아닌 것)을 뺀 이름표. 다 빠지면 빈 문자열 → 글줄 그대로."""
    from watcher.diff import pair_label as _raw
    lab = _raw(i)
    if not lab:
        return ""
    from watcher.extract.base import find_tags
    keep = []
    for part in lab.split("; "):
        _tag, sep, rest = part.partition(": ")
        if sep and _SELF_NAMED.match(rest) and not find_tags(rest.split(":", 1)[0].split("：", 1)[0]):
            continue
        keep.append(part)
    return "; ".join(keep)


def _flabel(i) -> str:
    """항목 이름 칸 — 표제란 필드의 내부 번호(REV#2)는 '다른 표제란'으로 보인다 (검토36 F 낮음 5).
    DXF 글줄에 사양-태그 짝 이름표가 있으면 그것 — 'M-102: 2.2kW 4P 380V → 3.7kW 4P 380V' (구매 평가 2차 F2)."""
    from watcher.diff import field_label
    if getattr(i, "kind", "") == "FIELD_CHANGED":
        return field_label(i.key)
    return pair_label(i) or text_key_label(i)


def text_key_label(i) -> str:
    """글줄 항목의 이름 — 키가 글줄 앞 30자 토막이면 낱말 중간('…제어전원은 D')에서 끊겨 항목 이름처럼 읽혔다 (검토62 D1-2).
    낱말 경계에서 자르고 말줄임표를 붙인다."""
    k = str(getattr(i, "key", "") or "")
    if str(getattr(i, "kind", "")).startswith("REVROW_"):
        # 같은 Rev 둘째 행의 내부 키 'B#2' → 'B (2번째)' — 표시만, 키(캐시·지문)는 그대로 (ux21 buy 6)
        m = re.fullmatch(r"(.+)#(\d+)", k)
        return f"{m.group(1)} ({m.group(2)}번째)" if m else k
    if not str(getattr(i, "kind", "")).startswith("TEXT_"):
        return k
    if k and len(k) < 20:
        # 키가 문장 **속** 도면번호·태그면 항목 이름이 아니다 — 사양서 '2-1. 구동 모터를 7.5kW로 상향 (E-101 Rev.B 반영)'이
        # '글자 추가 E-101'로 보였다 (재검토 2026-10-26 D3). 태그 앞에 낱말이 셋 이상이면 글줄 앞머리를 이름으로
        from watcher.extract.base import find_tags
        txt = next((str(v) for v in (getattr(i, "new", None), getattr(i, "old", None)) if v and k in str(v)), "")
        pos = txt.find(k)
        if pos > 0 and find_tags(k) == [k] and len(txt[:pos].split()) >= 3:
            head = " ".join(txt.split())
            if len(head) <= 30:
                return head
            cut = head.rfind(" ", 0, 30)
            return (head[:cut] if cut >= 10 else head[:30]).rstrip(" ,.:;(") + "…"
        return k
    if len(k) < 20:
        return k
    full = next((str(v) for v in (getattr(i, "old", None), getattr(i, "new", None))
                 if v and str(v).startswith(k) and len(str(v)) > len(k)), None)
    if full is None:
        return k
    cut = k.rfind(" ")
    return (k[:cut] if cut >= 10 else k).rstrip(" ,.:;") + "…"


def _row_key_cell(i) -> str:
    """행 식별 칸: 키 + 품명·규격 (어떤 부품인지 열어보지 않아도 알게 — 2026-08-25 요청)."""
    label = f'<br><span style="color:#57606a;font-size:12px">{_esc(i.label)}</span>' \
        if getattr(i, "label", None) else ""
    return f'<code>{_esc(i.key)}</code>{label}'


def _row_diff_table(items, extra_cell=None) -> str:
    """BOM 등 표 변경을 색상 표로: 추가=파랑, 삭제=빨강 취소선, 변경=앰버+델타.
    extra_cell: 항목→HTML 콜백 — 웹 상세가 [오탐 삭제] 버튼 칸을 붙일 때 사용
    (브리핑 메일에는 없음)."""
    trs = []
    def _x(i):
        return f'<td style="{_STYLE_TD}">{extra_cell(i)}</td>' if extra_cell else ""
    for i in items:
        if i.kind == "ROW_MOVED":
            # 행 순서만 바뀐 것 — 전에는 그리지 않아 '표 변경 N건'인데 근거가 0줄이었다 (검토39 P3 중간 1)
            trs.append(f'<tr style="background:#f6f8fa;color:#57606a">'
                       f'<td style="{_STYLE_TD}">행 순서</td>'
                       f'<td style="{_STYLE_TD}" colspan="3">{_esc(i.new or "")}'
                       f'{(" — " + _esc(plain_where(i.where))) if i.where else ""}</td>{_x(i)}</tr>')
            continue
        if i.kind == "ROW_ADDED":
            trs.append(f'<tr style="background:#dbeafe;color:#1f2328">'
                       f'<td class="k" style="{_STYLE_TD};color:#1d4ed8;font-weight:700">행 추가</td>'
                       f'<td style="{_STYLE_TD}">{_row_key_cell(i)}</td>'
                       f'<td style="{_STYLE_TD}">{_esc(_fmt_row_values(i.new))}</td>'
                       f'<td style="{_STYLE_TD};color:#57606a">{_esc(plain_where(i.where))}</td>{_x(i)}</tr>')
        elif i.kind == "ROW_REMOVED":
            trs.append(f'<tr style="background:#fee2e2;color:#1f2328">'
                       f'<td class="k" style="{_STYLE_TD};color:#cf222e;font-weight:700">행 삭제</td>'
                       f'<td style="{_STYLE_TD}">{_row_key_cell(i)}</td>'
                       f'<td style="{_STYLE_TD};text-decoration:line-through;color:#57606a">'
                       f'{_esc(_fmt_row_values(i.old))}</td>'
                       f'<td style="{_STYLE_TD};color:#57606a">{_esc(plain_where(i.where))}</td>{_x(i)}</tr>')
        elif i.kind == "ROW_CHANGED":
            key, _, col = i.key.rpartition(".")
            label = (f'<br><span style="color:#57606a;font-size:12px">'
                     f'{_esc(i.label)}</span>') if getattr(i, "label", None) else ""
            trs.append(f'<tr style="background:#fef3c7;color:#1f2328">'
                       f'<td class="k" style="{_STYLE_TD};color:#9a6700;font-weight:700">값 변경</td>'
                       f'<td style="{_STYLE_TD}"><code>{_esc(key or i.key)}</code>{label}</td>'
                       f'<td style="{_STYLE_TD}">{_esc(col)}: {word_diff_html(i.old, i.new)[0]} '
                       f'&rarr; <strong>{word_diff_html(i.old, i.new)[1]}</strong>'
                       f'{_delta_badge(i.old, i.new)}</td>'
                       f'<td style="{_STYLE_TD};color:#57606a">{_esc(plain_where(i.where))}</td>{_x(i)}</tr>')
    if not trs:
        return ""
    return (f'<table style="{_STYLE_TABLE};margin:6px 0 8px">'
            f'<tr><th style="{_STYLE_TH}">구분</th><th style="{_STYLE_TH}">행</th>'
            f'<th style="{_STYLE_TH}">내용</th><th style="{_STYLE_TH}">위치</th>'
            + (f'<th style="{_STYLE_TH}"></th>' if extra_cell else '') + '</tr>'
            + "".join(trs) + "</table>")


# 수량 성격의 열 이름 — BOM 발주 영향 합계 계산용
_QTY_COL = re.compile(r"(수량|QTY|Q'TY|Q-TY|EA)\s*$", re.IGNORECASE)
_QTY_IN_REPR = re.compile(r"'(?:수량|QTY|Q'TY|EA)'\s*:\s*'?(-?\d+(?:\.\d+)?)",
                          re.IGNORECASE)


def bom_impact(items) -> tuple[int, int, int, float | None]:
    """행 변경의 발주 영향 요약: (신규 행, 삭제 행, 값 변경 건, 수량 증감 합계).
    수량 열을 못 찾으면 합계는 None. 구매 전달용 한 줄 (설계 10년차 검토)."""
    added = sum(1 for i in items if i.kind == "ROW_ADDED")
    removed = sum(1 for i in items if i.kind == "ROW_REMOVED")
    changed = sum(1 for i in items if i.kind == "ROW_CHANGED")
    delta, seen = 0.0, False
    for i in items:
        if i.kind == "ROW_CHANGED":
            if _QTY_COL.search(i.key.rpartition(".")[2]):
                try:
                    delta += float(i.new) - float(i.old)
                    seen = True
                except (TypeError, ValueError):
                    pass
        elif i.kind in ("ROW_ADDED", "ROW_REMOVED"):
            m = _QTY_IN_REPR.search(i.new or i.old or "")
            if m:
                seen = True
                delta += float(m.group(1)) * (1 if i.kind == "ROW_ADDED" else -1)
    return added, removed, changed, (delta if seen else None)


def bom_impact_line(items, web: bool = False, label: str = "발주 영향") -> str:
    """행 변경 표 위 한 줄 요약. 행 변경이 없으면 빈 문자열.

    web=True면 화면용 테마 색을 쓴다 — 메일용 고정 색(#1f2328)이 다크 화면에서
    배경과 겹쳐 "발주 영향:" 글자가 사라졌다 (2026-08-31).
    label: 표 성격에 맞는 이름 (BOM류는 '발주 영향', 그 외는 '변경 요약')."""
    a, r, c, d = bom_impact(items)
    if not (a or r or c):
        return ""
    add, rm, ch, base = (("var(--link)", "var(--bad)", "var(--warn3)", "var(--text)")
                         if web else ("#1d4ed8", "#cf222e", "#9a6700", "#1f2328"))
    parts = []
    if a:
        parts.append(f'<b style="color:{add}">신규 {a}행</b>')
    if r:
        parts.append(f'<b style="color:{rm}">삭제 {r}행</b>')
    if c:
        parts.append(f'<b style="color:{ch}">값 변경 {c}건</b>')
    # 금액 합계(d)는 일부러 쓰지 않는다 — 품목 불문 합계는 발주에 쓸 수 없다
    # (2026-09-02 처음 보는 사람 검토). 인자는 호출부 호환을 위해 남겨 둔다
    return (f'<div style="font-size:13px;margin:2px 0 6px;color:{base}">'
            f'{label}: {" / ".join(parts)}</div>')


# 개별 변경 항목의 구분 라벨·색 (표 렌더용)
_ITEM_KIND = {
    "NEW_REVISION_OF": ("이전 판", "#57606a", "#f6f8fa"),
    "FIELD_CHANGED": ("값 변경", "#9a6700", "#fef3c7"),
    "FIELD_ADDED": ("값 추가", "#1d4ed8", "#dbeafe"),
    "FIELD_REMOVED": ("값 삭제", "#cf222e", "#fee2e2"),
    "TEXT_CHANGED": ("글자 변경", "#9a6700", "#fef3c7"),
    "TEXT_ADDED": ("글자 추가", "#1d4ed8", "#dbeafe"),
    "TEXT_REMOVED": ("글자 삭제", "#cf222e", "#fee2e2"),
    "PAGE_VISUAL_CHANGED": ("그림 변경", "#7c3aed", "#f3e8ff"),
    "EMBED_CHANGED": ("그림·개체 변경", "#7c3aed", "#f3e8ff"),
    "PAGE_ADDED": ("페이지 추가", "#1d4ed8", "#dbeafe"),
    "COL_RENAMED": ("열 이름 변경", "#57606a", "#f6f8fa"),
    "COL_ADDED": ("열 추가", "#1d4ed8", "#dbeafe"),
    "COL_REMOVED": ("열 삭제", "#cf222e", "#fee2e2"),
    "ROW_MOVED": ("행 이동", "#57606a", "#f6f8fa"),
    "COL_MOVED": ("열 이동", "#57606a", "#f6f8fa"),
    "PAGE_MOVED": ("페이지 순서", "#57606a", "#f6f8fa"),
    "TEXT_MOVED": ("문단 이동", "#57606a", "#f6f8fa"),
    "SHEET_ADDED": ("시트 추가", "#1d4ed8", "#dbeafe"),
    "SHEET_REMOVED": ("시트 삭제", "#cf222e", "#fee2e2"),
    "SHEET_RENAMED": ("시트 이름 변경", "#57606a", "#f6f8fa"),
    "PAGE_REMOVED": ("페이지 삭제", "#cf222e", "#fee2e2"),
    # 아래 셋이 빠져 있어 영문 코드가 그대로 표에 찍혔다 (2026-09-02 처음 보는 사람 검토)
    "REVROW_ADDED": ("개정표 행 추가", "#1d4ed8", "#dbeafe"),
    "REVROW_REMOVED": ("개정표 행 삭제", "#cf222e", "#fee2e2"),
    "REVROW_CHANGED": ("개정표 행 변경", "#9a6700", "#fef3c7"),
    # 표 행 셋 — 메일·화면은 행 표가 따로 그려 빠져 있었지만 설계 변경 대장·사내망 근거 칸에 'ROW_CHANGED'가 그대로 나갔다
    # (ux20 daily 5). 이름은 양식함 비교(forms/digest.KIND_TEXT)와 같은 말
    "ROW_CHANGED": ("행 값 변경", "#9a6700", "#fef3c7"),
    "ROW_ADDED": ("행 추가", "#1d4ed8", "#dbeafe"),
    "ROW_REMOVED": ("행 삭제", "#cf222e", "#fee2e2"),
    "NEW_REVISION_OF": ("이전 판", "#57606a", "#f6f8fa"),
    "CHECK_SKIPPED": ("검사 한계", "#57606a", "#f6f8fa"),
}


def fmt_val(v, group: bool = True) -> str:
    """항목 값을 사람 문장으로 — 리비전 행은 dict라 파이썬 표기가 그대로 찍혔다.
    저장을 거친 값은 dict의 문자열("{'DATE': …}")이라 그것도 되돌려 정돈한다 (2026-09-05)."""
    if v is None or v == "":
        return "—"
    if isinstance(v, str) and v.startswith("{") and v.endswith("}"):
        try:
            import ast
            parsed = ast.literal_eval(v)
            if isinstance(parsed, dict):
                v = parsed
        except Exception:
            pass
    if isinstance(v, dict):
        return " · ".join(f"{k}: {_group_digits(str(x))}" for k, x in v.items() if x not in (None, ""))
    if isinstance(v, (list, tuple)):
        return " · ".join(str(x) for x in v)
    # group=False: 도면 글줄·표제란 값은 적힌 그대로 — 치수 '12500'이 '12,500'으로 보였다 (검토61 B48). 표 칸(금액·수량)만 천 단위
    return _group_digits(str(v)) if group else str(v)


def _group_digits(s: str) -> str:
    """'12500000' → '12,500,000' — 금액·수량을 천 단위로 (검토54 ④·⑤). 품번·연도·날짜꼴(20261007)·앞자리 0은 그대로."""
    t = s.strip()
    if not re.fullmatch(r"-?[1-9]\d{4,}(?:\.\d+)?", t):
        return s
    if re.fullmatch(r"(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])", t):
        return s
    whole, dot, frac = t.partition(".")
    neg = whole.startswith("-")
    whole = f"{int(whole.lstrip('-')):,}"
    return ("-" if neg else "") + whole + (dot + frac if dot else "")


_W_DEL = 'style="background:#fee2e2;color:#991b1b;text-decoration:line-through"'
_W_INS = 'style="background:#dcfce7;color:#166534;font-weight:700"'


def word_diff_html(old, new, esc=_esc, del_attr: str = _W_DEL, ins_attr: str = _W_INS,
                   group: bool = True) -> tuple[str, str]:
    """두 문자열의 낱말 단위 차이 → (이전 HTML, 새 HTML). 바뀐 낱말만 표시한다 (2026-09-06 정밀화).
    낱말이 하나뿐인 긴 값(띄어쓰기 없는 문장·코드)은 글자 단위로 본다. 표시 불가(값이 아님)면
    그냥 이스케이프."""
    from difflib import SequenceMatcher
    o, n = fmt_val(old, group), fmt_val(new, group)
    if not isinstance(o, str) or not isinstance(n, str) or o == "—" or n == "—" or o == n:
        return esc(o), esc(n)
    ot, nt = o.split(), n.split()
    # 낱말 하나짜리 긴 값은 글자 단위 — 단 숫자가 든 값(날짜·코드 2026-07-10, PW-1009-A)은 통째로
    # 보여 준다: 자릿수만 색칠되면 통째보다 읽기 어렵다 (2026-09-06 사용성 3차 ④-9)
    char_mode = (len(ot) <= 1 and len(nt) <= 1 and max(len(o), len(n)) > 8
                 and not any(ch.isdigit() for ch in o + n))
    if char_mode:
        ot, nt, joiner = list(o), list(n), ""
    else:
        joiner = " "
    if len(ot) * len(nt) > 250000:
        return esc(o), esc(n)
    sm = SequenceMatcher(None, ot, nt, autojunk=False)
    oh, nh = [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            oh.append(esc(joiner.join(ot[i1:i2]))); nh.append(esc(joiner.join(nt[j1:j2])))
            continue
        if i2 > i1:
            oh.append(f"<span {del_attr}>{esc(joiner.join(ot[i1:i2]))}</span>")
        if j2 > j1:
            nh.append(f"<span {ins_attr}>{esc(joiner.join(nt[j1:j2]))}</span>")
    return joiner.join(oh), joiner.join(nh)


_WORD_KINDS = ("TEXT_CHANGED", "FIELD_CHANGED", "REVROW_CHANGED")
_LONG_LINES = 12            # 이보다 긴 여러 줄 글 덩이는 바뀐 문단 둘레만 보인다


def long_text_window(old, new, max_lines: int = _LONG_LINES, ctx: int = 1, hunks: int = 3):
    """여러 줄 글 덩이(300줄 MTEXT 주기 등)의 바뀐 문단 ±ctx줄만 — (보일 이전, 보일 새 값). 한 줄만 고쳐도 근거가 덩이 전체 × 2로
    브리핑 카드·'Rev 미갱신' 근거에 실렸다 (검토20 r03 7). 표시만 줄인다 — 비교 단위·저장 값은 그대로. 짧으면 그대로 돌려준다."""
    o, n = str(old if old is not None else ""), str(new if new is not None else "")
    ol, nl = o.split("\n"), n.split("\n")
    if max(len(ol), len(nl)) <= max_lines:
        return old, new
    from difflib import SequenceMatcher
    ops = [op for op in SequenceMatcher(None, ol, nl, autojunk=False).get_opcodes() if op[0] != "equal"]
    if not ops:
        return old, new

    def _cut(lines, spans, total):
        parts, last = [], 0
        for a, b in spans:
            a, b = max(0, a - ctx), min(len(lines), b + ctx)
            if a < last:
                a = last
            if a > last:
                parts.append("…")
            parts.extend(lines[a:b])
            last = b
        if last < len(lines):
            parts.append("…")
        return f"({total}줄 중) " + "\n".join(parts)
    shown = ops[:hunks]
    o_sp = [(i1, max(i2, i1 + 1) if i2 == i1 else i2) for _t, i1, i2, _j1, _j2 in shown]
    n_sp = [(j1, max(j2, j1 + 1) if j2 == j1 else j2) for _t, _i1, _i2, j1, j2 in shown]
    more = f"\n… 바뀐 곳 {len(ops) - hunks}곳 더" if len(ops) > hunks else ""
    return _cut(ol, o_sp, len(ol)) + more, _cut(nl, n_sp, len(nl)) + more


def item_diff_table(items, cap_of=None, extra_cell=None, budget=None, compact: bool = False) -> str:
    """개별 변경 항목(글자·값·그림)을 정렬된 표로 — 줄글 목록은 항목이 많으면
    읽기 불편하다는 피드백 반영 (2026-08-28). 전/후 사진은 해당 행 바로 아래
    전체 폭 행으로. extra_cell: 웹 상세의 [오탐 삭제] 버튼 칸 콜백.
    compact(메일 판): 사진 밑 설명 줄을 사진마다 되풀이하지 않는다 — 메일 머리에 한 번 (구매 평가 2차 F2)."""
    if not items:
        return ""
    ncols = 5 + (1 if extra_cell else 0)
    trs = []
    for i in items:
        label, color, bg = _ITEM_KIND.get(i.kind, (i.kind, "#57606a", "#f6f8fa"))
        x = f'<td style="{_STYLE_TD}">{extra_cell(i)}</td>' if extra_cell else ""
        _g = not i.kind.startswith(("TEXT_", "FIELD_"))
        if i.kind == "TEXT_CHANGED":
            _o, _n = long_text_window(i.old, i.new)
            o_html, n_html = word_diff_html(_o, _n, group=_g)
        elif i.kind in _WORD_KINDS:
            o_html, n_html = word_diff_html(i.old, i.new, group=_g)
        else:
            o_html, n_html = _esc(fmt_val(i.old, _g)), _esc(fmt_val(i.new, _g))
        trs.append(
            f'<tr style="background:{bg};color:#1f2328">'
            f'<td class="k" style="{_STYLE_TD};color:{color};font-weight:700">{label}</td>'
            f'<td style="{_STYLE_TD}"><code>{_esc(_flabel(i))}</code></td>'
            f'<td style="{_STYLE_TD};color:#57606a">{o_html}</td>'
            f'<td style="{_STYLE_TD}"><strong>{n_html}</strong>'
            f'{_delta_badge(i.old, i.new)}</td>'
            f'<td style="{_STYLE_TD};color:#57606a;width:22%">{_esc(plain_where(i.where))}</td>{x}</tr>')
        cap = cap_of(i) if cap_of else None
        if cap:
            block = render_capture(cap, budget, compact=compact)
            if block:
                trs.append(f'<tr><td colspan="{ncols}" style="{_STYLE_TD}">'
                           f'{block}</td></tr>')
    return (f'<table style="{_STYLE_TABLE};margin:6px 0 8px">'
            f'<tr><th style="{_STYLE_TH}">구분</th><th style="{_STYLE_TH}">항목</th>'
            f'<th style="{_STYLE_TH}">이전</th><th style="{_STYLE_TH}">새 값</th>'
            f'<th style="{_STYLE_TH}">위치</th>'
            + (f'<th style="{_STYLE_TH}"></th>' if extra_cell else '')
            + '</tr>' + "".join(trs) + '</table>')


# 메일 한 통에 실을 사진의 총량(바이트, base64 기준). 사진 한 장의 픽셀 상한
# (capture._MAIL_MAX_SIDE)만으로는 파일 수십 개가 바뀐 날 한 통이 수십 MB가 된다.
# 사내 SMTP가 보통 10~25MB에서 막고, 막히면 그날 브리핑이 통째로 사라진다
# (2026-09-09 브리핑 검토 차단 4). 넘치는 자리는 글로 남기고 화면으로 보낸다.
_MAIL_PHOTO_BUDGET = 6 * 1024 * 1024


class PhotoBudget:
    """메일 한 통 동안 살아 있는 사진 총량 예산. 웹 화면은 쓰지 않는다(무제한)."""

    def __init__(self, limit: int = _MAIL_PHOTO_BUDGET):
        self.left = limit
        self.skipped = 0

    def take(self, nbytes: int) -> bool:
        if nbytes > self.left:
            self.skipped += 1
            return False
        self.left -= nbytes
        return True

    def portion(self, n_left: int) -> "PhotoBudget":
        """여러 프로젝트가 한 통의 예산을 나눌 때 한 곳의 몫 — 남은 예산 ÷ 남은 곳 수. 다 못 쓴 몫은 settle 뒤 다음 곳으로
        이월된다. 앞 프로젝트가 선착으로 다 써 뒤 프로젝트는 사진이 0장이었다 (재검토 rr066 mail 4)."""
        sub = PhotoBudget(max(0, self.left) // max(1, int(n_left)))
        sub.given = sub.left
        return sub

    def settle(self, sub: "PhotoBudget") -> None:
        """portion으로 내준 몫에서 실제로 쓴 만큼만 뺀다."""
        self.left -= max(0, getattr(sub, "given", sub.left) - sub.left)
        self.skipped += sub.skipped


def _cap_bytes(cap: dict) -> int:
    return sum(len(x.get("b64") or "") for x in (cap.get("before"), cap.get("after")) if x)


def _one_img(cap: dict, label: str, border: str, width: int = 400, bare: bool = False) -> str:
    if bare:
        # 메일 판: 사진 위 '변경 전/후' 머리·아래 좌표 설명 없이 (대체 글자 alt에는 그대로) — 좌표·레이어는 기술 문구라 표의 위치 칸에
        # 있다. 전/후 순서는 메일 머리에 한 번 (구매 평가 2차 F2)
        return (f'<td valign="top" style="padding:0 6px 0 0">'
                f'<img src="data:{cap["mime"]};base64,{cap["b64"]}" width="{width}" '
                f'alt="{_esc(label)} — {_esc(plain_where(cap["caption"]))}" '
                f'style="width:100%;max-width:{width}px;height:auto;border:1px solid {border};border-radius:6px;display:block"></td>')
    # 표 칸 + width 속성 — Outlook(Word 엔진)은 flex를 모르고 max-width도 무시해
    # 1600px 원본 폭으로 그려 가로 스크롤이 났다 (검토19 브리핑 ⑥)
    # width 속성은 Outlook용 고정 폭, style은 폰(390px)에서 줄어들게 — 고정 style 폭은
    # 폰에서 가로로 넘쳤다 (검토19 2차 브리핑 ④)
    return (f'<td valign="top" style="padding:0 6px 0 0">'
            f'<div style="font-size:12px;font-weight:700;color:{border};margin-bottom:3px">'
            f'{label}</div>'
            # alt이 없으면 메일 프로그램이 그림을 막았을 때 아무 글자도 남지 않는다
            # (2026-09-09 브리핑 검토 차단 3). 설명(caption)을 그대로 대체 글로 쓴다
            f'<img src="data:{cap["mime"]};base64,{cap["b64"]}" width="{width}" '
            f'alt="{_esc(label)} — {_esc(plain_where(cap["caption"]))}" '
            f'style="width:100%;max-width:{width}px;height:auto;border:1px solid {border};border-radius:6px;display:block">'
            f'<span style="color:#57606a;font-size:11.5px">{_esc(plain_where(cap["caption"]))}</span></td>')


def _missing_img(label: str) -> str:
    return (f'<div style="display:inline-block;vertical-align:top;margin:4px 8px 4px 0;'
            f'padding:18px 14px;border:1px dashed #d0d7de;border-radius:6px;color:#57606a;'
            f'font-size:12px">{_esc(label)}: 이 판에는 없는 페이지</div>')


def render_capture(cap: dict, budget=None, compact: bool = False) -> str:
    """전/후 캡처 렌더. 전 사진이 있으면 나란히, 없으면 후만 (덮어쓰기라 구버전 없음).
    budget(PhotoBudget)을 주면 총량을 넘는 사진은 글 한 줄로 대신한다 — 메일용.
    compact: 사진 밑 '빨간 박스…' 설명을 싣지 않는다 (메일 머리에 한 번)."""
    if not cap:
        return ""
    # 구형(단일) 캡처 호환: after/before 키가 없으면 통째로 after로 취급
    after = cap.get("after") if "after" in cap or "before" in cap else cap
    before = cap.get("before")
    if after is None and not before:
        return ""
    if budget is not None and not budget.take(_cap_bytes(
            {"before": before, "after": after})):
        where = (after or before or {}).get("caption", "")
        return (f'<!--drev-photo--><div style="color:#57606a;font-size:12.5px;margin:4px 0">'
                f'전/후 사진 생략 — 이 메일의 사진 용량 상한을 넘었습니다'
                f'{(" (" + _esc(str(where)) + ")") if where else ""}. '
                f'감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div><!--/drev-photo-->')
    inner = ""
    w = 400 if (before and after) else 640
    if before:
        inner += _one_img(before, "변경 전", "#57606a", w, bare=compact)
    if after:
        inner += _one_img(after, "변경 후", "#dc2626", w, bare=compact)
    if before and after:
        note = "빨간 박스(왼쪽 위 네모 표시)가 변경된 자리 · 좌: 이전 판, 우: 새 판"
    elif after:
        # "이전 판 파일이 없어"는 바로 위 그림 변경 행에 전 사진이 있는 화면에서 서로를
        # 부정했다 — 글자 항목은 원래 새 판 자리만 그린다 (검토19 브리핑 ⑤)
        note = ("이전 판에 없던 페이지 (추가)" if "이전 판에 없음" in str(after.get("caption", ""))
                else "빨간 박스(왼쪽 위 네모 표시)가 변경된 자리 (글자·값 변경은 새 판의 그 자리만 표시)")
    else:
        note = "이 페이지는 새 판에 없습니다 (삭제) — 뒤 페이지 번호가 하나씩 당겨졌을 수 있습니다"
    # 폭을 주어야 사진의 width:100%가 셀 폭으로 풀린다 — 폰(360px)에서 사진이 화면 밖으로 나갔다 (검토41 S6 중간 1)
    # 표식(<!--drev-photo-->)은 메일 설정 images: false가 이 묶음을 통째로 글 한 줄로 바꾸는 자리 (mail.mail_view, 2026-10-19)
    if compact and note.startswith("빨간 박스"):      # 쪽 추가·삭제 같은 뜻 있는 설명은 남긴다
        return (f'<!--drev-photo--><table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
                f'style="margin:6px 0 4px;width:100%;max-width:100%"><tr>{inner}</tr></table><!--/drev-photo-->')
    return (f'<!--drev-photo--><table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" '
            f'style="margin:6px 0 4px;width:100%;max-width:100%"><tr>{inner}</tr></table>'
            f'<div style="color:#57606a;font-size:12px;margin-bottom:8px">{note}</div><!--/drev-photo-->')


_DETAIL_CAP = 40  # 항목이 수백 개면(대형 도면 재출력 등) 읽을 수 없다 — 상위만 표시


def _cap_of(captures: dict | None, path: str, item, cid=None):
    """항목의 캡처. 신형 키(kind|key — 같은 key끼리 덮어쓰기 방지)를 먼저,
    구형 저장분(key만)은 폴백으로 찾는다.

    cid(변경 id)를 주면 그 키를 먼저 본다 — 같은 파일이 하루에 두 번 바뀐 날
    경로 키만으로는 아침 사진이 오후 것에 덮였다 (2026-09-09 브리핑 검토 차단 2)."""
    if not captures:
        return None
    # 같은 kind|key가 한 파일에 여럿(25쪽에 같은 NOTE 줄이 추가)이면 자리(where)까지 붙인
    # 키가 따로 있다 — 전에는 전부 마지막 쪽 사진 하나를 가리켰다 (검토19 브리핑 ④)
    k3 = f"{item.kind}|{item.key}|{item.where}"
    k2 = f"{item.kind}|{item.key}"
    if cid is not None:
        hit = (captures.get((cid, k3)) or captures.get((cid, k2))
               or captures.get((cid, item.key)))
        if hit:
            return hit
    return captures.get((path, k3)) or captures.get((path, k2)) \
        or captures.get((path, item.key))


def _is_common_item(i) -> bool:
    """전 페이지 반복(표제란·양식) 변경 — 개별 변경과 분리해 접어 보인다."""
    return i.key.startswith("공통위치") or "전 페이지 공통" in i.where


def split_display_items(items, cap_lookup, plain_cap: int, cap_photos: bool = False):
    """상세 항목의 표시용 분류 — 브리핑과 웹 상세가 공용한다
    (같은 로직을 두 곳에 두었다가 같은 버그를 두 번 고친 자리, 2026-08-26 통합).
    캡처(전/후 사진)가 붙은 항목은 표시 캡에서 자르지 않는다.
    돌려주는 값: (안내문, 개별 변경, 전 페이지 공통, 표 행, 생략 수)"""
    row_items = [i for i in items if i.kind.startswith("ROW_")]
    others, plain_shown, omitted = [], 0, 0
    for i in items:
        if i.kind.startswith("ROW_"):
            continue
        # cap_photos: 메일 크기를 줄이는 중이면 사진 붙은 항목도 상한에 넣는다 — 빼면 40→12→4로 줄여도 도면 글자 변경이 전부
        # 실려 '4건까지만' 고지가 거짓이 됐다 (검토52 D 중간 3)
        if cap_lookup(i) and not cap_photos:
            others.append(i)
        elif plain_shown < plain_cap:
            others.append(i)
            plain_shown += 1
        else:
            omitted += 1
    omitted += max(0, len(row_items) - plain_cap)
    notices = [i for i in others if i.kind == "CHECK_SKIPPED"]
    commons = [i for i in others if i.kind != "CHECK_SKIPPED" and _is_common_item(i)]
    regular = [i for i in others
               if i.kind != "CHECK_SKIPPED" and not _is_common_item(i)]
    # 진짜 바뀐 글자·그림 먼저, 표제란 칸·개정이력 행은 뒤 — 화면만 고쳐 메일은 첫 사진이 늘 표제란 'B' 박스였다 (검토56 ③12)
    regular.sort(key=lambda i: 1 if (i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_")) else 0)
    return notices, regular, commons, row_items[:plain_cap], omitted


_PHOTO_PER_FILE = 10


def _titleish(i) -> bool:
    """표제란 칸·개정표 행·표제 일자 글줄 — 메일 판에서 한 줄로 접고 사진을 붙이지 않는다 (구매 평가 2차 F2)."""
    from watcher.diff import is_title_date_text
    return i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_") or is_title_date_text(i)


def title_line(items) -> str:
    """표제란·개정표 변경을 한 줄로 — 'REV A→B · DATE 2026-09-26→2026-10-09 · 일자 글줄 2곳 · 개정표 B행 추가 (…)'.
    메일 판에서 표제란 칸마다 표 줄·사진이 붙어 한 도면이 화면 한 장을 차지했다 (P2 day5). 칸 하나도 빠지지 않는다."""
    from watcher.diff import field_label, is_title_date_text
    parts = []
    for i in items:
        if i.kind == "FIELD_CHANGED":
            parts.append(f"{field_label(i.key)} {fmt_val(i.old, False)}→{fmt_val(i.new, False)}")
    dt = [i for i in items if is_title_date_text(i) and i.kind != "FIELD_CHANGED"]
    if dt:
        ex = dt[0]
        parts.append(f"일자 글줄 {len(dt)}곳"
                     + (f" ({short_pair(ex.old, ex.new, 30)})" if ex.kind == "TEXT_CHANGED" else ""))
    def _row_txt(v) -> str:
        # 개정표 행은 설명(DESCRIPTION)이 사람 말이다 — 'DATE: … · DESCRIPTION: …' 꼴이면 '설명 (날짜)'로
        s = fmt_val(v)
        d = re.search(r"(?:DESCRIPTION|DESC\.?|내용|개정 ?내용|개정 ?사유|사유|REMARKS?): ([^·]+)", s)
        dt = re.search(r"\d{4}[-./]\d{1,2}[-./]\d{1,2}", s)
        return f"{d.group(1).strip()}" + (f", {dt.group(0)}" if dt else "") if d else s
    for i in items:
        if i.kind == "REVROW_ADDED":
            parts.append(f"개정표 행 추가 {i.key} ({cut_words(_row_txt(i.new), 70)})")
        elif i.kind == "REVROW_REMOVED":
            parts.append(f"개정표 행 삭제 {i.key} ({cut_words(fmt_val(i.old), 50)})")
        elif i.kind == "REVROW_CHANGED":
            parts.append(f"개정표 행 변경 {i.key} ({cut_words(short_pair(fmt_val(i.old), fmt_val(i.new), 50), 60)})")
    return " · ".join(parts)


def _details_rows(path: str, items, captures: dict | None = None,
                  info: dict | None = None, budget=None, cid=None, compact: bool = False) -> str:
    # 한 파일의 사진은 앞 _PHOTO_PER_FILE장까지 — 같은 도면 글줄 35곳이 거의 같은 사진 35장(6.3MB, 폭 800에서 14,000px)이
    # 되어 아침 메일을 끝까지 못 읽었다 (검토63 C2). 나머지는 글로만 싣고(표시 상한에 들어간다) 사진은 화면에서
    _with_cap = [i for i in items if _cap_of(captures, path, i, cid)]
    if compact:
        return _details_rows_mail(path, items, captures, info, budget, cid, _with_cap)
    _photo_ok = {id(i) for i in _with_cap[:_PHOTO_PER_FILE]}
    _photo_cut = len(_with_cap) - len(_photo_ok)

    def _cap(i):  # 변경 위치 캡처 — 비교 결과를 도면 위에 '표시'만 한다
        return _cap_of(captures, path, i, cid) if id(i) in _photo_ok else None

    notices, regular, commons, row_items, omitted = split_display_items(
        items, _cap, _DETAIL_CAP, cap_photos=_DETAIL_CAP < 40)

    inner = ""
    if any("OCR" in str(getattr(i, "where", "") or "") for i in items):
        # 스캔본·SHX 출력 PDF의 글자는 Windows OCR로 읽은 추정값 — 0/O·1/I 오인이 있을 수 있다 (2026-09-06)
        # 사진이 있을 때만 사진을 가리킨다 — 도면이 아닌 스캔 문서는 그림을 남기지 않는데 '사진이 있으면'이 없는 사진을 찾게 했다 (검토56 ④18)
        _has_cap = any(_cap(i) for i in items)
        inner += ('<div style="border:1px solid #9a6700;border-left:5px solid #9a6700;border-radius:6px;'
                  'padding:8px 12px;margin:6px 0;background:#fff8e5;font-size:13px"><strong>OCR 추정값</strong> — '
                  '이 파일의 글자는 그림에서 읽은 것이라 O/0·I/1처럼 틀릴 수 있습니다. '
                  + ('아래 전/후 사진으로 확인하세요.' if _has_cap else
                     f'원본 파일(<code>{_esc(path)}</code>)을 열어 확인하세요.') + '</div>')
    # 설계자가 리비전 블록에 남긴 공식 개정 사유 — "왜 바뀌었나"가 한 줄로
    if info and info.get("note"):
        inner += (f'<div style="border:1px solid #d0d7de;border-left:5px solid '
                  f'#1d4ed8;border-radius:6px;padding:8px 12px;margin:6px 0;'
                  f'background:#f6f8fa;font-size:13px;color:#1f2328;overflow-wrap:anywhere">'
                  f'개정 사유(개정표): <strong>{_esc(info["note"])}</strong>'
                  f'</div>')
    # 검사 한계 고지는 값 변경(→) 표가 아니라 안내 박스로 (2026-08-25 UX 검토)
    for i in notices:
        inner += (f'<div style="border:1px solid #9a6700;border-left:5px solid #9a6700;'
                  f'border-radius:6px;padding:8px 12px;margin:6px 0;background:#fff8e5;'
                  f'font-size:13px"><strong>{_esc(i.key)}</strong> — {_esc(notice_text(i))}</div>')
    # 표 문서(BOM·사양서)는 행 표가 진짜 내용인데 표제란 REV·개정이력 행 뒤에 붙었다 — 글자·그림 → 행 표 → 표제란·개정이력
    # (검토57 ③12)
    _tb = [i for i in regular if i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_")]
    _content = [i for i in regular if i not in _tb]
    if _content:
        inner += item_diff_table(_content, cap_of=_cap, budget=budget)
    # 요약 줄은 잘리기 전 전체 행으로 센다 — 200건 바뀐 날 표 상한(40)만큼 '값 변경 40건'이라 했다 (검토61 C37)
    inner += bom_impact_line([i for i in items if i.kind.startswith("ROW_")], label=impact_label(path)) + _row_diff_table(row_items)
    if _tb:
        inner += item_diff_table(_tb, cap_of=_cap, budget=budget)
    if commons:
        # <details>는 Outlook·Gmail에서 접히지 않거나 아예 안 보인다 — 제목 줄 + 표로 (검토19 브리핑 ⑥)
        inner += (f'<div style="margin:6px 0;font-size:13px;color:#57606a">'
                  f'전 페이지 공통 변경(표제란·양식류) {len(commons)}건</div>'
                  f'{item_diff_table(commons, cap_of=_cap, budget=budget)}')
    if omitted:
        inner += (f'<div style="color:#57606a;font-size:12.5px;margin-top:4px">'
                  f"외 {omitted}건 생략 — 변경이 매우 많은 문서라 위 {_DETAIL_CAP}건만 "
                  f"표시했습니다. 전체는 감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div>")
    if _photo_cut > 0:
        inner += (f'<div style="color:#57606a;font-size:12.5px;margin-top:4px">'
                  f"전/후 사진은 이 파일에서 앞 {_PHOTO_PER_FILE}곳만 실었습니다 — 나머지 {_photo_cut}곳의 사진은 "
                  f"감시 PC 화면의 변경 상세에서 볼 수 있습니다.</div>")
    return (f'<tr><td colspan="5" style="{_STYLE_TD};background:#fafbfc">'
            f"{inner}</td></tr>")


def _details_rows_mail(path: str, items, captures, info, budget, cid, with_cap) -> str:
    """메일 판 변경 상세 — 내용 표(상한 _MAIL_ROWS_PER_CHANGE) + 사진 한 장 + 표제란·개정표 한 줄. 나머지는 '외 N건'으로 수만
    남기고 화면으로. 근거(구/신 값·위치)는 그대로 표에 있다 (원칙 4)."""
    pref = [i for i in with_cap if not _titleish(i)]
    _photo_ok = {id(i) for i in pref[:_MAIL_PHOTOS_PER_CHANGE]}

    def _cap(i):
        return _cap_of(captures, path, i, cid) if id(i) in _photo_ok else None
    notices = [i for i in items if i.kind == "CHECK_SKIPPED"]
    rows = [i for i in items if i.kind.startswith("ROW_")]
    tb = [i for i in items if i.kind != "CHECK_SKIPPED" and not i.kind.startswith("ROW_") and _titleish(i)]
    content = [i for i in items if i.kind != "CHECK_SKIPPED" and not i.kind.startswith("ROW_") and not _titleish(i)]
    # 줄 짝을 못 지어 '삭제 + 추가'로 갈린 한 변경(같은 짝 이름표)은 추가 쪽 한 줄로 — 이름표에 옛 값이 있다
    _added_labs = {pair_label(i) for i in content if i.kind == "TEXT_ADDED" and pair_label(i)}
    content = [i for i in content if not (i.kind == "TEXT_REMOVED" and pair_label(i) in _added_labs)]
    inner = ""
    if any("OCR" in str(getattr(i, "where", "") or "") for i in items):
        inner += ('<div style="border-left:4px solid #9a6700;padding:4px 10px;margin:4px 0;background:#fff8e5;font-size:13px">'
                  '<strong>OCR 추정값</strong> — 그림에서 읽은 글자라 O/0·I/1이 틀릴 수 있습니다. 원본을 열어 확인하세요.</div>')
    for i in notices:
        inner += (f'<div style="border-left:4px solid #9a6700;padding:4px 10px;margin:4px 0;background:#fff8e5;font-size:13px">'
                  f'<strong>{_esc(i.key)}</strong> — {_esc(notice_text(i))}</div>')
    # 개정 사유는 개정표 줄에 함께 있다 — 개정표 행이 없을 때만 따로
    if info and info.get("note") and not any(i.kind == "REVROW_ADDED" for i in items):
        inner += (f'<div style="font-size:13px;margin:4px 0">개정 사유(개정표): <strong>{_esc(info["note"])}</strong></div>')
    if content:
        inner += item_diff_table(content[:_MAIL_ROWS_PER_CHANGE], cap_of=_cap, budget=budget, compact=True)
    if rows:
        # 표 행(BOM·발주서)은 구매가 행마다 본다 — 줄 상한을 줄이지 않는다(디스크 브리핑과 같은 40행). 30행 수량 변경 BOM의
        # 뒤 행이 메일에서 빠지면 그 발주를 놓친다 (basic61 C36)
        inner += bom_impact_line(rows, label=impact_label(path)) + _row_diff_table(rows[:_DETAIL_CAP])
    more = max(0, len(content) - _MAIL_ROWS_PER_CHANGE) + max(0, len(rows) - _DETAIL_CAP)
    if more:
        inner += (f'<div style="color:#57606a;font-size:12.5px;margin:2px 0">외 {more}건 — 감시 PC 화면의 변경 상세에 '
                  f'모두 있습니다.</div>')
    tl = title_line(tb)
    if tl:
        inner += f'<div style="font-size:13px;color:#57606a;margin:4px 0">표제란·개정표: {_esc(tl)}</div>'
    if not inner:
        return ""
    return f'<tr><td colspan="5" style="{_STYLE_TD};background:#fafbfc">{inner}</td></tr>'


_SCAN_ERR_MAX = 50
# 따옴표 안이 **경로 모양**(C:\…·\\서버·/…)일 때만 — '시트를 찾을 수 없음: '개정이력''의 사유까지 잘랐다 (검토36 E 낮음 3)
_ERR_PATH_TAIL = re.compile(r"""\s*:\s*(['"])(?:[A-Za-z]:[\\/]|\\\\|/).*?\1\s*$""")


def scan_error_rows(scan_errors) -> list[tuple[str, str]]:
    """읽지 못한 파일 목록을 (표시 이름, 오류) 줄로 — 같은 폴더·같은 오류는 한 줄. 메일과 화면이 같이 쓴다.
    같은 폴더의 오류는 한 줄로 묶는다 — 공유 폴더 하나가 끊긴 날 파일마다 한 줄씩 상한 없이
    실려, 그 폴더와 무관한 프로젝트 메일까지 770KB·2,000줄이 됐다(4만 파일이면 사내 메일 크기 제한에 걸려
    그날 메일이 모두 실패할 수 있다, 검토35 B 중간 4)"""
    from collections import OrderedDict
    groups: "OrderedDict[tuple, list]" = OrderedDict()
    for p, err in scan_errors:
        sp = str(p)
        folder = sp if sp.endswith("/") or "/" not in sp else sp.rsplit("/", 1)[0] + "/"
        # OSError 문구 끝의 파일 경로(": 'C:\\…'")를 걷는다 — 경로가 파일마다 달라 묶음이 한 번도 안
        # 됐고, 메일에 감시 PC의 절대 경로가 실렸다 (검토36 B 중간 1)
        err = _ERR_PATH_TAIL.sub("", str(err)).strip() or str(err)
        groups.setdefault((folder, err), []).append(sp)
    rows = []
    for (folder, err), paths in groups.items():
        if len(paths) == 1:
            rows.append((paths[0], err))
        else:
            rows.append((f"{folder} 안 파일 {len(paths)}개", err))
    return rows


# 삭제 알림 보류 표식 — 검사 본체가 scan_errors 꼬리에 이 머리로 넣는다. '읽지 못한 파일'이 아니라 **사라진 파일**의 알림이라
# 따로 센다: 파일 79개가 사라진 날 제목이 '변경 0건 — 알림 1건', 본문 첫 상자가 '읽지 못한 파일 1건(잠김·권한…)'이었다
# (재검토 2026-10-28 R5-2)
HOLD_MARKS = ("(대량 삭제 보류)", "(감시 폴더 비어 있음)")


def is_hold_note(p) -> bool:
    return str(p).startswith(HOLD_MARKS)


def split_hold_notes(scan_errors) -> tuple[list, list]:
    """(삭제 보류 알림, 진짜 읽기 오류)."""
    holds = [(p, e) for p, e in (scan_errors or []) if is_hold_note(p)]
    errs = [(p, e) for p, e in (scan_errors or []) if not is_hold_note(p)]
    return holds, errs


def hold_file_count(holds) -> int:
    """보류 중인 파일 수 — 대량 삭제 알림의 수(전체), 없으면 빈 감시 폴더 알림들의 합."""
    def _n(msg):
        m = re.search(r"파일\s*([\d,]+)\s*개", str(msg))
        return int(re.sub(",", "", m.group(1))) if m else 0     # str.replace는 읽기 전용 검사(test_readonly)가 막는다
    mass = [_n(e) for p, e in holds if str(p).startswith(HOLD_MARKS[0])]
    return max(mass) if mass else sum(_n(e) for _p, e in holds)


def _hold_section(holds) -> str:
    n = hold_file_count(holds)
    lis = "".join(f'<li>{_esc(_hold_label(p))} — <span style="color:#57606a">{_esc(err)}</span></li>' for p, err in holds)
    return f"""
  <div style="border:1px solid #cf222e;border-left:6px solid #cf222e;border-radius:6px;
              padding:10px 14px;margin:0 0 12px;background:#ffebe9">
    <strong style="color:#cf222e">{f'파일 {n}개가 한꺼번에 사라져' if n else '파일이 한꺼번에 사라져'} 삭제 알림 보류 중</strong>
    <div style="font-size:13px;margin-top:4px">서버·네트워크 드라이브 연결이 끊긴 것일 수 있어 이 파일들을 아직 삭제로 기록하지
    않았습니다. 파일이 돌아오면 저절로 풀립니다. 정말 지운 것이면 감시 PC 화면에서 [삭제로 기록]을 누르세요.</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}</ul>
  </div>"""


def _hold_label(p) -> str:
    s = str(p)
    for m in HOLD_MARKS:
        if s.startswith(m):
            rest = s[len(m):].strip()
            return rest or m.strip("()")
    return s


def _scan_errors_section(scan_errors) -> str:
    holds, scan_errors = split_hold_notes(scan_errors)
    out = _hold_section(holds) if holds else ""
    if not scan_errors:
        return out
    # 50줄에서 자른다 (검토35 B 중간 4)
    rows = scan_error_rows(scan_errors)
    more = len(rows) - _SCAN_ERR_MAX
    lis = "".join(f'<li>{_esc(p)} — <span style="color:#57606a">{_esc(err)}</span></li>'
                  for p, err in rows[:_SCAN_ERR_MAX])
    if more > 0:
        lis += f'<li style="color:#57606a">외 {more}건 — 감시 PC의 watcher.log에 전부 남아 있습니다</li>'
    return out + f"""
  <div style="border:1px solid #9a6700;border-left:6px solid #9a6700;border-radius:6px;
              padding:10px 14px;margin:0 0 12px;background:#fff8e5">
    <strong style="color:#9a6700">읽지 못한 {'폴더·파일' if any(str(p).endswith('/') for p, _ in scan_errors) else '파일'} {len(scan_errors)}건</strong>
    <div style="font-size:13px;margin-top:4px">잠김·권한·연결 문제로 이번 실행에서 확인하지
    못했습니다. 감시 폴더 자체가 안 열린 경우 그 폴더의 프로젝트는 이 통에 없습니다. 다음 성공 시 변경 감지가 재개됩니다.</div>
    <ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}</ul>
  </div>"""


def _toc_entries(changes, details: dict, doc_info: dict | None = None,
                 baseline: bool = False, details_by_id: dict | None = None) -> list:
    """목차 줄 재료 [(번호, 이름, 요약, 접지 말 것)] — 목차와 메일 압축이 같은 요약을 쓴다."""
    lis = []
    for i, c in enumerate(changes):
        items = (details_by_id or {}).get(c.id)
        if items is None:
            items = details.get(c.path, [])
        vis = 0
        for it in items:
            if it.kind != "PAGE_VISUAL_CHANGED":
                continue
            m = re.search(r"(\d+)개 페이지 반복", str(it.where or ""))
            vis += int(m.group(1)) if m else 1     # 공통 위치 1건 = 여러 쪽 (검토19 2차 ⑧)
        txt = sum(1 for it in items if it.kind.startswith("TEXT_") and it.kind != "TEXT_MOVED")
        _tk = {it.kind for it in items if it.kind.startswith("TEXT_") and it.kind != "TEXT_MOVED"}
        # 전부 추가면 '추가', 전부 삭제면 '삭제' — 문단이 새로 붙은 사양서를 '글자 변경'이라 했다 (검토33 A 낮음 2)
        _txt_word = ("글자 추가" if _tk == {"TEXT_ADDED"} else "글자 삭제" if _tk == {"TEXT_REMOVED"} else "글자 변경")
        row = sum(1 for it in items if it.kind.startswith("ROW_") and it.kind != "ROW_MOVED")
        from watcher.diff import is_rev_field
        rev = next((it for it in items if is_rev_field(it)), None)
        parts = []

        def _short(v) -> str:
            return " ".join(str(v or "").split())[:36]

        def _pair(o, n) -> tuple:
            # 긴 값은 앞 36자가 같아 머리줄이 '… 조정 → … 조정'처럼 같은 글로 보였다 — 처음 다른 곳 앞뒤를 보인다 (검토61 C32)
            o, n = " ".join(str(o or "").split()), " ".join(str(n or "").split())
            if len(o) <= 36 and len(n) <= 36:
                return o, n
            k = 0
            while k < min(len(o), len(n)) and o[k] == n[k]:
                k += 1
            st = max(0, k - 12)
            if st and " " in o[st:k]:
                st = st + o[st:k].index(" ") + 1
            cut = lambda v: ("…" if st else "") + v[st:st + 36] + ("…" if len(v) > st + 36 else "")  # noqa: E731
            return cut(o), cut(n)
        # 첫 줄에 "무엇이 어떻게" — 건수만 있으면 팀장이 열어 봐야 알았다 (파일럿 모의 2차 조건 2)
        def _row_head_of(it) -> str:
            rk, sep, col = str(it.key).rpartition(".")         # 'X-11.수량' → 'X-11 수량'
            head = f"{rk} {col}".strip() if sep else str(it.key)
            _o, _n = _pair(_group_digits(str(it.old)), _group_digits(str(it.new)))
            return f"{_short(head)}: {_o} → {_n}"   # 머리줄도 천 단위 (검토55 ④1)
        row_head = next((_row_head_of(it) for it in items
                         if it.kind == "ROW_CHANGED" and it.old and it.new), None)
        # DXF 사양 글자를 가장 가까운 태그와 짝지은 이름표가 있으면 그것 — '3.7kW 4P 380V 2.2kW…→5.5kW…' 대신
        # 'M-101: 3.7kW 4P 380V → 5.5kW 4P 380V' (구매 평가 2차 F2)
        _pl = pair_label
        _labs = list(dict.fromkeys(_pl(it) for it in items if _pl(it)))
        txt_head = "; ".join(_labs) if _labs else next((" → ".join(_pair(it.old, it.new))
                                                        for it in items if it.kind == "TEXT_CHANGED" and it.old and it.new
                                                        and _UNIT_RE.search(str(it.old) + " " + str(it.new))), None)
        # 단위 없는 글자 변경도 무엇이 바뀌었는지 — 문단마다 다른 낱말을 고친 사양서 14장이 모두 '글자 변경 1건'이라
        # 목차가 '외 11건이 같은 내용'으로 접었다 (검토61 D B1). 값이 같은 것끼리만 접힌다
        if txt_head is None:
            # 표제 일자 글줄('DATE: 09-26 DRAWN: …')은 요약 머리가 아니다 — 출도 PDF 줄이 날짜 줄로 시작해 진짜 변경(태그 추가)이
            # '글자 변경 4건'에 묻혔다 (구매 평가 2차 P2 day5). 다른 글줄이 없을 때만
            from watcher.diff import is_title_date_text as _itd
            _tc = [it for it in items if it.kind == "TEXT_CHANGED" and it.old and it.new]
            txt_head = next((" → ".join(_pair(it.old, it.new)) for it in _tc if not _itd(it)), None) if any(
                not _itd(it) for it in items if it.kind.startswith("TEXT_")) else next(
                (" → ".join(_pair(it.old, it.new)) for it in _tc), None)
        if txt_head:
            parts.append(txt_head)
        if vis:
            parts.append(f"그림 변경 위치 {vis}곳")
        if txt and not txt_head:
            parts.append(f"{_txt_word} {txt}건")
        elif txt > 1 and txt_head:
            # '글자 변경 외 1건'은 '글자 변경 말고 다른 무엇 1건'으로 읽혔다 — 모두 몇 건인지 (검토71 R4 낮음 10)
            parts.append(f"{_txt_word} {txt}건")
        if row:
            parts.append(f"{table_label(c.path)} 변경 {row}건" + (f" ({row_head})" if row_head else ""))
        # 페이지·순서·표제란 칸·리비전 행은 목차에 요약이 없어 '— 수정'으로만 보였다 (검토61 B13·B14·T15·T25)
        _cnt = Counter(it.kind for it in items)
        # 단위를 붙인다 — '페이지 삭제 1'과 '글자 변경 2건'이 한 줄에 섞였다 (검토71 R4 낮음 10)
        if _cnt.get("PAGE_ADDED"):
            parts.append(f"페이지 추가 {_cnt['PAGE_ADDED']}쪽")
        if _cnt.get("PAGE_REMOVED"):
            parts.append(f"페이지 삭제 {_cnt['PAGE_REMOVED']}쪽")
        # 문서 안 그림·개체 — 그림만 바꾼 사양서가 목차·제목에서 '— 수정'으로만 보였다 (검토71 R4 차단 1)
        _emb: dict = {}
        for it in items:
            if it.kind == "EMBED_CHANGED":
                _emb[str(it.key)] = _emb.get(str(it.key), 0) + 1
        for _ek, _en in _emb.items():
            _base, _, _verb = _ek.rpartition(" ")
            parts.append(f"{_base} {_en}개 {'바뀜' if _verb == '교체' else _verb}" if _base else f"{_ek} {_en}개")
        if _cnt.get("PAGE_MOVED"):
            parts.append("페이지 순서 바뀜")
        if _cnt.get("TEXT_MOVED"):
            parts.append(f"문단 이동 {_cnt['TEXT_MOVED']}건")
        if _cnt.get("ROW_MOVED") and not row:
            parts.append("행 순서 바뀜")
        # 열·시트 단위 변경도 — 열 삭제·시트 추가만 있는 표가 목차·'오늘 확인할 것'에서 '— 수정'으로만 보였다 (검토68 C5)
        _names = lambda kind: ", ".join(dict.fromkeys(_short(it.key) for it in items if it.kind == kind)) if _cnt.get(kind) else ""  # noqa: E731
        for _k, _w in (("COL_ADDED", "열 추가"), ("COL_REMOVED", "열 삭제"), ("SHEET_ADDED", "시트 추가"), ("SHEET_REMOVED", "시트 삭제")):
            if _cnt.get(_k):
                parts.append(f"{_w} {_names(_k)}")
        for it in items:
            if it.kind == "COL_RENAMED" and it.old and it.new:
                parts.append(f"열 이름 {_short(it.old)}→{_short(it.new)}")
            elif it.kind == "SHEET_RENAMED" and it.old and it.new:
                parts.append(f"{it.label or '시트 이름 변경'} {_short(it.old)}→{_short(it.new)}")
        if _cnt.get("COL_MOVED"):
            parts.append("열 순서 바뀜")
        _idf = next((it for it in items if it.kind == "FIELD_CHANGED" and it.old and it.new
                     and it.key in ("DWG_NO", "DOC_NO", "TITLE", "PROJECT")), None)
        if _idf:
            _fl = {"DWG_NO": "도면번호", "DOC_NO": "문서번호", "TITLE": "제목", "PROJECT": "프로젝트"}[_idf.key]
            parts.append(f"{_fl} {' → '.join(_pair(_idf.old, _idf.new))}")
        _rr = sum(1 for it in items if it.kind.startswith("REVROW_"))
        if _rr and not rev:
            parts.append(f"개정표 행 {'추가' if {it.kind for it in items if it.kind.startswith('REVROW_')} == {'REVROW_ADDED'} else '변경'} {_rr}건")
        if rev:
            from watcher.diff import _blank_rev
            # 첫 발행은 'Rev None→A'가 아니라 첫 기재 (검토38 R1 중간 3·R3 중간 6)
            parts.append(f"Rev {rev.new} 첫 기재" if _blank_rev(rev.old) else f"Rev {rev.old}→{rev.new}")
        # 축척 — 목차에 '글자 변경 1건'으로만 묻혔다 (검토43 C 중간 6)
        sc = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "SCALE" and it.old and it.new), None)
        if sc:
            parts.append(f"축척 {_short(sc.old)}→{_short(sc.new)}")
        # 표제란 칸이 지워진 것(PROJECT → 없음)은 목차에 없었다 (검토21 브리핑 중간 9)
        fdel = next((it for it in items if it.kind == "FIELD_CHANGED" and it.old
                     and not it.new and it.key not in ("파일 크기", "저장 시각")), None)
        if fdel:
            from watcher.diff import field_label
            parts.append(f"표제란 {field_label(fdel.key)} 칸 삭제 ({_short(fdel.old)})")
        dt = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "DATE"), None)
        if dt and not parts:
            parts.append(f"표제란 일자 {dt.old}→{dt.new}")
        # 내용을 못 읽는 파일 — 크기·저장 시각이 유일한 근거인데 목차는 "수정"뿐이었다 (검토19 브리핑 ⑮)
        sz = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "파일 크기"), None)
        # 형식은 읽는데 이번 판을 못 읽었으면(손상·잘림) 그것부터 — 제목엔 '[읽지 못함 1]'인데 목차는 바이트 수만 말했다 (검토50 B 중간 8)
        # 항목 이름은 '내용 추출 실패' 또는 '내용 비교'(값 '수행 못 함: …') — 앞의 것만 보아 목차가 바이트 수만 말했다 (검토52 D 낮음 13)
        _unread = next((it for it in items if it.kind == "CHECK_SKIPPED" and (
            "추출 실패" in str(it.key or "") or (str(it.key or "") == "내용 비교" and "수행 못 함" in str(it.new or "")))), None)
        if _unread and not parts:
            parts.append(_unread_label(str(_unread.new or "")))
        if sz and not parts:
            parts.append(f"크기 {sz.old}→{sz.new}")
        elif sz and _unread and len(parts) == 1:
            parts.append(f"크기 {sz.old}→{sz.new}")
        elif not parts:
            tm = next((it for it in items if it.kind == "FIELD_CHANGED" and it.key == "저장 시각"), None)
            if tm:
                parts.append(f"저장 시각 {tm.new}")
        note = next((it for it in items
                     if it.kind == "CHECK_SKIPPED" and it.key == "참고"), None)
        if note and not parts:
            # 구판 '대체됨' 같은 참고 — 목차만 보는 사람이 삭제로 오해하지 않게
            # (2026-09-02 재검토)
            parts.append(str(note.new).split(" — ")[0])
        name = PurePosixPath(c.path).name if "/" in c.path else c.path
        info = ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path))
        if info and info.get("dwg"):  # 실무 언어: 도면번호가 파일명보다 먼저
            name = f'{num_prefix(c.path)}{info["dwg"]} — {name}'
        if info and info.get("folder"):
            # 같은 이름 파일이 프로젝트 안에 또 있으면 어느 폴더 것인지 — 메일 머리 한 줄만 고쳐지고 '오늘 확인할 것'은 원본과
            # 같은 줄이었다 (ux21 mail 3)
            name += f' ({info["folder"]} 폴더)'
        summary = ", ".join(parts) or ("첫 등록" if baseline and c.kind == "added" else KIND_LABEL_TEXT(c))
        # 사양값(kW·A·V·mm…)이 바뀐 줄이나 표 행 변경은 접히지 않는다 — 10장 중 한 장의
        # 모터 kW 변경이 "외 7건이 같은 내용"에 묻혔다 (검토19 2차 브리핑 ⑦)
        salient = bool(row) or bool(_emb) or any(
            it.kind.startswith("TEXT_") and _UNIT_RE.search(str(it.old or "") + " " + str(it.new or ""))
            for it in items)
        lis.append((i, name, summary, salient))
    return lis


ADDED_FOLD_MIN = 5          # 같은 폴더·같은 형식의 '추가'가 이만큼 넘으면 한 행으로 (기능 검토 2026-11-02 J5)
_SHEET_EXTS = (".pdf", ".dxf", ".dwg", ".tif", ".tiff", ".jpg", ".jpeg", ".png")


def added_folds(main: list, details: dict | None, details_by_id: dict | None = None, skip=()) -> dict:
    """{id(변경): (대표 변경, 폴더, 확장자, [같은 묶음 변경들])} — 같은 폴더에 같은 형식 파일이 ADDED_FOLD_MIN개 넘게 새로 들어온 날
    파일마다 한 행(이름·폴더·확인 링크)이 이어져 진짜 변경이 아래로 밀렸다(watch B5). 비교가 실린 추가(이전 판과 짝지은 새 판)는
    접지 않는다 — 그건 수정이다. 폴더 이동 ≥3 접기와 같은 방식."""
    groups: dict = {}
    for c in main:
        if c.kind != "added" or id(c) in skip:
            continue
        its = items_for(c, details, details_by_id)
        if any(getattr(i, "kind", "") != "CHECK_SKIPPED" for i in its or ()):
            continue
        pp = PurePosixPath(c.path)
        groups.setdefault((str(pp.parent), pp.suffix.lower()), []).append(c)
    out: dict = {}
    for (folder, ext), cs in groups.items():
        if len(cs) >= ADDED_FOLD_MIN:
            for c in cs:
                out[id(c)] = (cs[0], folder, ext, cs)
    return out


def added_fold_text(folder: str, ext: str, n: int) -> str:
    unit = "장" if ext in _SHEET_EXTS else "개"
    return f"폴더 {folder}에 {(ext.lstrip('.') or '확장자 없는').upper()} {n}{unit} 추가"


def _added_fold_row(lead, folder: str, ext: str, cs: list) -> str:
    names = ", ".join(_esc(PurePosixPath(c.path).name) for c in cs)
    return (f'<tr><td class="k" style="{_STYLE_TD}"><strong style="color:{_KIND_COLOR["added"]}">추가</strong></td>'
            f'<td style="{_STYLE_TD}" colspan="2"><b>{_esc(added_fold_text(folder, ext, len(cs)))}</b>'
            f'<details style="margin-top:4px;font-size:12.5px;color:#57606a"><summary style="cursor:pointer">'
            f'파일 이름 {len(cs)}개 보기</summary>{names}</details></td>'
            f'<td style="{_STYLE_TD};color:#57606a;font-size:12.5px">감시 PC 화면에서 한꺼번에 확인</td></tr>')


def _summary_toc(changes, details: dict, doc_info: dict | None = None,
                 baseline: bool = False, details_by_id: dict | None = None, companions: dict | None = None,
                 folds: dict | None = None) -> str:
    """상단 요약 목차: 파일별로 무엇이 몇 건인지 한눈에 (2026-08-25 UX 검토 —
    '변경 1건' 헤더 아래 항목 수백 개가 예고 없이 이어지던 문제).

    같은 파일이 하루에 두 번 바뀐 날은 **변경 id별** 상세를 쓴다 — 경로 키만 보면
    두 줄 모두에 최신 건수가 붙어 아래 근거표와 숫자가 달랐다
    (2026-09-09 배포 후 검토 중간 1)."""
    if not changes:
        return ""
    lis = _toc_entries(changes, details, doc_info, baseline, details_by_id)
    if companions:
        # 메일 판: 같은 도면의 출도 PDF는 DXF 줄에 붙인다 — 그 PDF도 아래 표에 제 한 줄이 있다 (구매 평가 2차 F2)
        by_cad: dict = {}
        for k, c in enumerate(changes):
            if id(c) in companions:
                by_cad.setdefault(id(companions[id(c)]), []).append(PurePosixPath(c.path).name)
        lis = [(i, name + "".join(f" + {n}" for n in by_cad.get(id(changes[i]), [])), summary, salient)
               for i, name, summary, salient in lis if id(changes[i]) not in companions]
    if folds:
        # 같은 폴더·형식의 추가 묶음은 대표 한 줄 (J5)
        _fl = []
        for i, name, summary, salient in lis:
            f_ = folds.get(id(changes[i]))
            if f_ is None:
                _fl.append((i, name, summary, salient))
            elif f_[0] is changes[i]:
                _fl.append((i, added_fold_text(f_[1], f_[2], len(f_[3])), "이름 목록은 아래 행에 접어 둠", True))
        lis = _fl
    # 같은 요약이 여덟 줄 넘게 반복되면 접는다 — 도면 60장이 전부 "Rev A→B, 글자 1건"인 날
    # 팀장은 60줄을 지나야 첫 상세를 봤다 (검토19 브리핑 ⑧). 상세는 그대로 전부 싣는다
    from collections import Counter as _Counter
    counts = _Counter(s for _, _, s, sal in lis if not sal)
    shown: dict = {}
    out_li = []
    for i, name, summary, salient in lis:
        if salient:
            out_li.append(f'<li style="margin:3px 0"><a href="#chg{i}" '
                          f'style="color:#1d4ed8">{_esc(name)}</a>'
                          f'<span style="color:#57606a"> — {_esc(summary)}</span></li>')
            continue
        k = shown.get(summary, 0)
        if counts[summary] > 8 and k >= 3:
            shown[summary] = k + 1
            continue
        shown[summary] = k + 1
        out_li.append(f'<li style="margin:3px 0"><a href="#chg{i}" '
                      f'style="color:#1d4ed8">{_esc(name)}</a>'
                      f'<span style="color:#57606a"> — {_esc(summary)}</span></li>')
    for summary, n in counts.items():
        if n > 8:
            out_li.append(f'<li style="margin:3px 0;color:#57606a">… 외 {n - 3}건이 같은 내용'
                          f'({_esc(summary)}) — 아래 상세에 전부 있습니다</li>')
    # 기준선 통에는 '확인할 것'이 없다 — 등록 목록이다 (검토21 브리핑 중간 10)
    return ('<div style="border:1px solid #d0d7de;border-radius:6px;'
            'padding:10px 14px;margin:0 0 14px;background:#f6f8fa">'
            f'<strong>{"등록된 산출물 (요약)" if baseline else "오늘 확인할 것"}</strong>'
            f'<ul style="margin:6px 0 0;padding-left:20px">{"".join(out_li)}</ul></div>')


def _one_details(c, details: dict, details_by_id: dict | None, captures,
                 doc_info: dict | None, budget, compact: bool = False) -> str:
    """변경 한 건의 상세 — 같은 파일이 하루에 두 번 바뀐 날은 변경 id별 상세를 쓴다."""
    items = (details_by_id or {}).get(c.id)
    if items is None:
        items = details.get(c.path)
    if not items:
        return ""
    return _details_rows(c.path, items, captures, ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)),
                         budget=budget, cid=c.id, compact=compact)


def KIND_LABEL_TEXT(c) -> str:
    return _KIND_LABEL.get(c.kind, c.kind)


def _short_roots(root: str) -> str:
    """머리말의 감시 폴더는 마지막 폴더 이름만 — 전체 서버 경로가 고객에게 전달되는 통에
    그대로 실렸다 (검토19 2차 브리핑 ⑫). 전체는 title로 남긴다."""
    raw = "\n".join("\n".join(str(root or "").split(" · ")).split(", "))   # replace()는 읽기 전용 가드가 막는다
    parts = [p.strip() for p in raw.splitlines() if p.strip()]
    names = []
    for p in parts:
        q = "/".join(p.split("\\")).rstrip("/")
        names.append(q.rsplit("/", 1)[-1] or q)
    return " · ".join(names) if names else str(root)


def build_brief(changes: list[Change], run_at: datetime, root: str,
                details: dict | None = None, issues: list | None = None,
                project: str | None = None, ack_base: str | None = None,
                ack_tokens: dict | None = None,
                scan_errors: list | None = None,
                captures: dict | None = None,
                scanned_count: int | None = None,
                baseline: bool = False,
                doc_info: dict | None = None,
                merged_note: str | None = None,
                acked_by: dict | None = None,
                details_by_id: dict | None = None,
                since: str | None = None,
                photo_budget: bool = False,
                baseline_note: str | None = None,
                open_backlog: tuple | None = None,
                resolved: list | None = None,
                rollback_note: str | None = None,
                clock_note: str | None = None,
                gap_note: str | None = None,
                continued: list | None = None,
                recurred: dict | None = None,
                still_open: list | None = None,
                wiped_folders: list | None = None,
                alias_note: str | None = None,
                rejudged: list | None = None) -> str:
    """브리핑 HTML 문서 전체를 돌려준다. 변경 0건이어도 문서는 만든다(기록용).
    wiped_folders: [(폴더, 삭제 파일 수)] — 등록 파일이 하나도 안 남은 폴더 (R5-6, wiped_folders()가 만든다)

    details: {path: [ChangeItem]} 파일별 내용 변경 상세 (Stage 3)
    issues:  [Issue] 일관성 검사 결과 (Stage 3)
    project: 프로젝트별 브리핑이면 정규 프로젝트 번호 (Stage 4)
    scanned_count: 이번 검사에서 확인한 파일 수 — 0건 날의 '살아있음' 신호
    open_backlog: (그 프로젝트의 열린 검토 필요 누적, 가장 오래된 것 며칠째) — 메일은 새로 잡힌 것만
                  싣기에, 이 메일 밖에 남은 것이 있으면 수만 한 줄로 알린다 (검토36 B 3)
    """
    details = details or {}
    issues = issues or []
    date_str = run_at.strftime("%Y-%m-%d %H:%M")
    proj_label = f"[{project}] " if project else ""
    scanned_note = (f" · 파일 {scanned_count}개 검사함"
                    if scanned_count is not None else "")
    # PC가 며칠 꺼져 있다가 켜진 날은 6일치 변경이 "오늘 12건"으로 나가 받는 사람이
    # 어제 하루 일로 읽었다 — 무엇과 비교한 것인지 한 줄 밝힌다 (원칙 4, 2026-09-09
    # 자동 실행 검토 중간 8)
    # 합산본은 여러 검사분을 한 통에 담는다 — "직전 검사"라 쓰면 그 통의 절반에
    # 대해 거짓이 된다 (2026-09-09 배포 후 검토 중간 2)
    since_note = (f" · 비교 기준: 오늘 앞선 검사부터 (가장 최근 비교는 {since})"
                  if since and merged_note else
                  f" · 비교 기준: 직전 검사 {since}" if since else "")
    # 기준선은 전부 '첫 등록' — 접지 않고 그대로 나열
    resaved: list = []
    uncompared: list = []
    if baseline:
        main, quiet, moved = list(changes), [], {}
    else:
        main, quiet, moved = arrange_changes(changes, details, details_by_id)
        if photo_budget:
            # 메일 판에는 '글자·표·그림이 모두 같은 재저장'을 싣지 않는다 — 다른 프로그램으로 다시 뽑기만 한 PDF·재스캔이 날마다
            # 메일에 '그 밖의 알림'으로 실려, 받는 사람이 무엇이 바뀌었나 열어 보게 했다 (검토68 B05·B18·B25·B35·B42).
            # 디스크 브리핑·화면 이력에는 그대로 남는다(기록). 그림을 비교하지 않는 형식·일부만 읽은 쪽은 남긴다
            _rs = [c for c in quiet if is_silent_resave(note_of(items_for(c, details, details_by_id)))]
            # 그림·개체를 비교하지 못한 재저장(DOCX·XLSX)도 한 줄로 — 문서 안 그림만 바꾼 날 그 파일만 있는 프로젝트는 메일 자체가
            # 없었다 (검토69 B M2b, 원칙 5). 표 행 대신 한 줄에 '그림·개체는 비교 못 함'을 밝힌다
            _uc = [c for c in quiet if is_uncompared_resave(note_of(items_for(c, details, details_by_id)))]
            quiet = [c for c in quiet if not any(c is r for r in _rs + _uc)]
            resaved = _rs
            uncompared = _uc
    n = len(main)
    head_th = (f'<tr><th style="{_STYLE_TH}">구분</th><th style="{_STYLE_TH}">파일</th>'
               f'<th style="{_STYLE_TH}">폴더</th>' + (f'<th style="{_STYLE_TH}">확인</th>' if ACK_ON.get() else '') + '</tr>')
    # 메일 판 압축 (구매 평가 2차 F2) — 기준선 등록 통은 등록 목록이라 그대로
    compact = bool(photo_budget) and not baseline
    companions = drawing_companions(main, doc_info) if compact else {}

    # 사진 총량은 **메일에만** 건다. 전에는 무조건 걸어서, 디스크에 남는 브리핑
    # 원본(화면이 여는 바로 그 파일)에서도 사진이 지워졌다 — 안내문은 "이 메일의
    # 상한"이라 말하고 "감시 PC 화면에서 보라"고 했는데, 보는 사람이 이미 그 화면이고
    # 그 상세는 보존 기간이 지나면 사라진다 (2026-09-09 배포 후 검토, 원칙 4)
    # 하루 묶음 메일은 여러 프로젝트가 예산 하나를 나눠 쓴다 — 예산 객체를 그대로 받는다 (기능 검토 2026-11-02 M1)
    _budget = photo_budget if isinstance(photo_budget, PhotoBudget) else (PhotoBudget() if photo_budget else None)
    # 메일에서는 같은 요약이 여덟 장 넘게 반복되면(발행일 Rev 일괄 올림) 앞 두 장만 상세·사진을 싣고 나머지는 한 줄로 — 발행일 메일이
    # 749KB·사진 80장이 되어 아침 5분 안에 못 읽었다 (구매자 평가 P3 차단 2). 디스크의 브리핑 원본은 전부 싣는다
    _fold_ids: set = set()
    if photo_budget and main and not baseline:
        from collections import Counter as _Cf
        _ent = _toc_entries(main, details, doc_info, baseline, details_by_id)

        def _vals(c):
            # 요약 문구만 같고 값이 다른 편집(문단마다 다른 낱말)을 '위와 같은 내용'이라 접어 새 값이 메일 어디에도 없었다
            # (검토61 D B1) — 구/신 값까지 같은 것만 접는다(발행일 Rev 일괄 올림은 그대로 접힌다)
            its = (details_by_id or {}).get(c.id)
            if its is None:
                its = details.get(c.path, [])
            return tuple(sorted((it.kind, str(it.old or ""), str(it.new or "")) for it in its
                                if it.kind not in ("PAGE_VISUAL_CHANGED", "CHECK_SKIPPED")))
        _key = {_i: (sm, _vals(main[_i])) for _i, _n, sm, sal in _ent if not sal}
        _cnt = _Cf(_key.values())
        _seen: dict = {}
        for _i, _n, sm, sal in _ent:
            if sal or _cnt[_key[_i]] <= 8:
                continue
            _seen[_key[_i]] = _seen.get(_key[_i], 0) + 1
            if _seen[_key[_i]] > 2:
                _fold_ids.add(_i)

    def _detail_or_note(i, c):
        if i in _fold_ids:
            if c.kind in ("removed", "added"):
                # 삭제·추가에는 상세도 사진도 없다 — 삭제 행마다 '상세·사진은 감시 PC 화면에'가 24번 반복됐다 (재검토 2026-10-28 R5-6)
                return ""
            return (f'<tr><td colspan="4" style="{_STYLE_TD};color:#57606a;font-size:12.5px">'
                    f'위와 같은 내용의 변경 — 상세·사진은 감시 PC 화면과 브리핑 원본에 있습니다</td></tr>')
        return _one_details(c, details, details_by_id, captures, doc_info, _budget, compact=compact)

    def _companions_of(c) -> str:
        # 같은 도면의 출도 PDF는 DXF 행 밑에 한 줄 — 그 PDF의 바뀐 내용 요약을 그대로 싣는다(원칙 5)
        out = ""
        for k, p in enumerate(main):
            if companions.get(id(p)) is c:
                ent = _toc_entries([p], details, doc_info, False, details_by_id)
                out += _companion_row(p, ent[0][2] if ent else KIND_LABEL_TEXT(p), ack_base, ack_tokens, acked_by)
        return out
    _afolds = {} if baseline else added_folds(main, details, details_by_id, skip=set(companions))
    if main:
        rows = "\n".join(
            (f'<tbody id="chg{i}">' + _added_fold_row(*_afolds[id(c)]) + "</tbody>" if id(c) in _afolds else
             f'<tbody id="chg{i}">'
             + _change_row(c, ack_base, ack_tokens, ((doc_info or {}).get(c.id) or (doc_info or {}).get(c.path)), baseline,
                           acked_by=acked_by, compact=compact)
             + _detail_or_note(i, c)
             + (_companions_of(c) if companions else "")
             + "</tbody>")
            for i, c in enumerate(main) if id(c) not in companions
            and (id(c) not in _afolds or _afolds[id(c)][0] is c))
        _legend_ph = ""
        if compact and "<img" in rows:
            # 표식(<!--drev-legend-->) — 메일 설정 images: false면 mail.mail_view가 사진과 함께 지운다
            _legend_ph = ('<!--drev-legend--><p style="color:#57606a;font-size:12px;margin:0 0 6px">사진의 빨간 네모가 바뀐 자리입니다 '
                          '(두 장이면 왼쪽이 이전 판). 사진은 변경마다 한 장 — 나머지 사진·전체 상세는 감시 PC 화면에 있습니다.</p>'
                          '<!--/drev-legend-->')
        body = f"""
  {_summary_toc(main, details, doc_info, baseline=baseline,
                details_by_id=details_by_id, companions=companions, folds=_afolds)}{_legend_ph}
  <table style="{_STYLE_TABLE}">{head_th}
    {rows}
  </table>"""
    elif quiet:
        body = ('<p style="color:#57606a">내용이 바뀐 산출물은 없습니다 — 아래 '
                '그 밖의 알림만 있습니다.</p>')
    elif scan_errors:
        # 읽지 못한 폴더·파일이 있는 날은 '정상 동작 중'이 아니다 — "파일 122개가 사라졌습니다" 바로
        # 아래 "정상 동작 중"이 서로 부정했다 (검토21 브리핑 차단 4)
        _h, _e = split_hold_notes(scan_errors)
        _what = " · ".join(x for x in (("삭제 알림 보류" if _h else ""), ("읽지 못한 폴더·파일 알림" if _e else "")) if x)
        body = (f'<p style="color:#9a6700">변경된 산출물이 없습니다 — 다만 위의 {_what}을 '
                f'확인하세요{_esc(scanned_note)}.</p>')
    else:
        body = (f'<p style="color:#1a7f37">변경된 산출물이 없습니다 — 감시는 정상'
                f' 동작 중입니다{_esc(scanned_note)}.</p>')
    if quiet:
        # 폴더 이름 변경·이동은 파일마다 한 행(6~20행)이 아니라 "폴더 A → B (파일 N개)" 한
        # 줄로 접는다 (파일럿 모의 ⑩). 셋 미만이면 파일별로 둔다
        from collections import Counter as _C
        pair_of = {}
        for c in quiet:
            if id(c) in moved:
                # 바뀐 가장 높은 조상끼리 묶는다 — 하위 폴더별(도면/·BOM/)로 따로 세면
                # "폴더 A → B (파일 20개)" 한 줄이 안 됐다 (파일럿 모의 2차 day10)
                op = PurePosixPath(moved[id(c)]).parent.parts
                npn = PurePosixPath(c.path).parent.parts
                k = 0
                while k < min(len(op), len(npn)) and op[-1 - k] == npn[-1 - k]:
                    k += 1
                # 공통 꼬리를 떼되 **옮겨진 폴더 이름은 남긴다** — '견적중_P26-034'를 통째로 떼어
                # "서버 → 서버/아카이브"라 적었다 (파일럿 모의 3차 ①). 꼬리를 뗐으면 한 마디 되살린다
                if k > 0:
                    k -= 1
                pair_of[id(c)] = ("/".join(op[:len(op) - k]) or ".", "/".join(npn[:len(npn) - k]) or ".")
        pair_n = _C(pair_of.values())
        folded_pairs: set = set()
        qparts = []
        qgroups: dict = {}
        for c in quiet:
            pr = pair_of.get(id(c))
            if compact and not (pr and pr[0] != pr[1] and pair_n[pr] >= 3):
                # 메일 판: 종류별 한 줄 — 파일마다 행(이름 + 긴 참고 문구)이 붙어 '일자만 갱신' 셋이 9줄이었다 (P2 day5).
                # 파일 이름은 하나도 빠지지 않는다 (원칙 5)
                if id(c) in moved:
                    qgroups.setdefault("이동·이름 변경 (내용 동일)", []).append(
                        f"{PurePosixPath(c.path).name} (이전: {PurePosixPath(moved[id(c)]).name})")
                else:
                    qgroups.setdefault(quiet_group(note_of(items_for(c, details, details_by_id))), []).append(
                        PurePosixPath(c.path).name)
                continue
            if pr and pr[0] != pr[1] and pair_n[pr] >= 3:
                if pr in folded_pairs:
                    continue
                folded_pairs.add(pr)
                qparts.append(
                    f'<tr><td style="{_STYLE_TD}"><strong style="color:#57606a">이동</strong></td>'
                    f'<td style="{_STYLE_TD}" colspan="2">폴더 <b>{_esc(pr[0])}</b> → <b>{_esc(pr[1])}</b> '
                    f'(파일 {pair_n[pr]}개 — 이름·위치만 바뀜, 내용 동일)</td>'
                    + _ack_td("—") + '</tr>')
                continue
            qparts.append(_change_row(c, ack_base, ack_tokens, None, False,
                                      moved_from=moved.get(id(c)),
                                      note="" if id(c) in moved else note_of(items_for(c, details, details_by_id)),
                                      acked_by=acked_by))
        for lab, names in qgroups.items():
            shown = ", ".join(names[:12]) + (f" 외 {len(names) - 12}개" if len(names) > 12 else "")
            qparts.append(f'<tr><td style="{_STYLE_TD}" colspan="4"><b>{_esc(lab)} {len(names)}건</b>: {_esc(shown)}</td></tr>')
        qrows = "".join(qparts) if compact else "\n".join(qparts)
        # 그날 있는 종류만 — 폴더 이름 하나 바꾼 날에도 일곱 가지를 다 나열했다 (검토44 C 낮음 6)
        _legend = ("이동·이름 변경 (내용 동일, 확인할 필요 없는 변경)" if all(id(c) in moved for c in quiet)
                   else "이동·복사본·재저장·빈 파일·일자만 갱신·표제란 틀 교체·구판 정리 (확인할 필요 없는 변경)")
        if compact:
            body += (f'\n  <h3 style="margin:18px 0 4px;color:#57606a;font-size:15px">그 밖의 알림 {len(quiet)}건 '
                     f'<span style="font-weight:400;font-size:12.5px">— 확인할 필요 없는 변경</span></h3>'
                     f'<table style="{_STYLE_TABLE};color:#57606a;font-size:13px">{qrows}</table>')
        else:
            body += f"""
  <h3 style="margin:20px 0 6px;color:#57606a">그 밖의 알림 {len(quiet)}건
    <span style="font-weight:400;font-size:13px">— {_legend}</span></h3>
  <table style="{_STYLE_TABLE};color:#57606a">{head_th}
    {qrows}
  </table>"""
    if resaved:
        # 메일에서 뺀 재저장 파일도 이름은 한 줄 남긴다 — 감지가 놓친 진짜 변경(번호 주기 맞바꿈·글줄 위 취소선)일 수 있는데 그 파일이
        # 메일에서 통째로 사라졌다 (검토69 B M6·M7·M8, 원칙 5). 상세는 감시 PC 화면·디스크 브리핑에 그대로 있다
        _names = [PurePosixPath(c.path).name for c in resaved]
        _shown = ", ".join(_names[:10]) + (f" 외 {len(_names) - 10}건" if len(_names) > 10 else "")
        body += (f'\n  <p style="color:#57606a;font-size:13px;margin:14px 0 0">{RESAVED_MAIL_LINE} {len(_names)}건'
                 f' (글자·표·그림 비교상 같음 — 상세는 감시 PC 화면): {_esc(_shown)}</p>')
    if uncompared:
        _names = [PurePosixPath(c.path).name for c in uncompared]
        _shown = ", ".join(_names[:10]) + (f" 외 {len(_names) - 10}건" if len(_names) > 10 else "")
        body += (f'\n  <p style="color:#57606a;font-size:13px;margin:14px 0 0">{RESAVED_MAIL_LINE} {len(_names)}건'
                 f' (글자·표는 같음 — 그림·개체는 비교하지 못함: 그림만 바뀌었을 수 있으니 파일을 열어 확인하세요):'
                 f' {_esc(_shown)}</p>')
    quiet_head = f' <span style="color:#57606a;font-weight:400;font-size:15px">(+그 밖의 알림 {len(quiet)}건)</span>' if quiet else ""
    # 'Rev 올렸는데 일자 그대로' 표지는 검토 필요 카드가 아니라 변경 행의 띠 — 머리에서 수를 한 번 센다 (ux20 mail 4)
    _n_rd = 0 if baseline else rev_date_count(main, details, details_by_id)
    _rd_head = (f' <span style="color:#9a6700;font-size:15px">· 확인 필요 {_n_rd}건</span>' if _n_rd else "")
    # 맨 위 사장·구매용 한 줄 — 레이어·좌표·서버 경로 없이 무엇이 어떻게, 무엇을 할지 (구매 평가 2차 P1·P2)
    _head_txt = "" if baseline else mail_headline(main, issues, details, doc_info, details_by_id, project)[0]
    # 프로젝트 폴더가 통째로 사라진 날은 그 사실을 한 줄로 — 첫 파일 이름 '…pdf 삭제 외 25'만 보였다 (R5-6). 사실만 적는다(원칙 6)
    _wipe_txt = "" if baseline else wiped_line(wiped_folders)
    if _wipe_txt and not _head_txt:
        _head_txt, _wipe_txt = _wipe_txt, ""
    # 받는 사람은 감시 PC 화면을 못 연다 — 링크 안내 대신 회신 한 줄 (메일 판, 감시 PC 주소일 때)
    _reply = (REPLY_LINE if (compact and (main or issues) and (not ack_base or _loopback(ack_base)) and ACK_ON.get()) else "")
    if _reply and LAN_BASE and not baseline:     # 사내망 양식함이 켜져 있으면 회신 대신 링크 (갈래 N)
        _reply = LAN_ACK_LINE
    elif compact and (main or issues) and LAN_BASE and not baseline and not ACK_ON.get():
        _reply = LAN_VIEW_LINE                   # 확인 기록을 꺼도 사내망 열람 안내는 남긴다 (rr066 mail 5)

    return f"""<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>산출물 변경 브리핑 {_esc(date_str)}</title>
<style>@media (max-width:480px){{body{{padding:10px!important;word-break:normal!important}}h2{{font-size:19px!important;word-break:keep-all!important}}td,th{{padding:4px 5px!important;font-size:13px!important;white-space:normal!important;word-break:keep-all;overflow-wrap:anywhere}}td.k{{white-space:nowrap!important}}th{{white-space:nowrap!important}}img{{max-width:100%!important;height:auto!important}}}}</style></head>
<body bgcolor="#ffffff" style="font-family:'Malgun Gothic',Segoe UI,sans-serif;color:#1f2328;
             background:#ffffff;max-width:860px;margin:0 auto;padding:24px;word-break:keep-all;overflow-wrap:anywhere">
  <h2 style="margin:0 0 4px">{_esc(proj_label)}산출물 변경 브리핑 — {'기준선 등록' if baseline else '변경'} {n}건{quiet_head}
    {f'/ <span style="color:#cf222e">검토 필요 {len(issues)}건</span>' if issues else ''}{_rd_head}</h2>
  {headline_html(_head_txt)}{headline_html(_wipe_txt)}{_reply}
  {f'<p style="background:#fff1e5;border:1px solid #e3a341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>PC 시계 확인</b> — {_esc(clock_note)}</p>' if clock_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>별칭 사전</b> — {_esc(alias_note)}</p>' if alias_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>검사 공백</b> — {_esc(gap_note)}</p>' if (gap_note and not clock_note) else ''}
  {f'<p style="background:#fff1e5;border:1px solid #e3a341;padding:8px 12px;border-radius:6px;margin:0 0 12px"><b>옛 판으로 되돌아간 날</b> — {_esc(rollback_note)}</p>' if rollback_note else ''}
  {f'<p style="background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px">{_esc(baseline_note) if baseline_note else "첫 검사(기준선)입니다"} — 아래 파일들은 <b>변경이 아니라 감시 대상으로 등록</b>된 것입니다. 내일부터 달라진 것만 브리핑합니다.' + (' 검토 필요 항목은 지금 봐 둘 만합니다.' if issues else ' 이 메일은 보낼 필요가 없습니다.') + '</p>' if baseline else ''}
  {_scan_errors_section(scan_errors) if scan_errors else ''}
  {_rejudged_block(rejudged) if (rejudged and not baseline) else ''}
  {f'<h3 style="margin:16px 0 8px">검토 필요 {len(issues)}건</h3>{_issues_section(issues, ack_base, project, recurred, compact=compact, folders=_folders_of(doc_info))}'
   if issues else ''}
  {_continued_line(continued) if (continued and not baseline) else ''}
  {_still_open_line(still_open, compact) if (still_open and not baseline) else ''}
  {_backlog_line(open_backlog, len(issues), ack_base, project, hide_age=bool(clock_note)) if (open_backlog and not baseline) else ''}
  {_resolved_line(resolved) if (resolved and not baseline) else ''}
  <h3 style="margin:16px 0 8px">변경 목록</h3>
  {'' if (baseline or not changes or not ack_base or '/ack?id=' not in body or (compact and _loopback(ack_base)) or not ACK_ON.get()) else
   ('<p style="color:#57606a;font-size:12px;margin:0 0 8px">감시 PC 화면 › 전체 이력 › 미확인에서 한꺼번에 확인할 수 '
    '있습니다. 각 행의 #번호는 그 화면에서 찾는 번호입니다.</p>' if _loopback(ack_base) else
    f'<p style="color:#57606a;font-size:12px;margin:0 0 8px">감시 PC에서는 '
    f'<a href="{_esc(ack_base)}/history?ack=none" style="color:#0969da">미확인 변경 목록</a>'
    f'에서 한꺼번에 확인할 수 있습니다. 각 행의 [확인했음 기록]은 그 변경의 근거 화면으로 갑니다.</p>')}
  {body}
  <p style="color:#57606a;margin:24px 0 4px;font-size:13px">
    {_esc(date_str)} 기준 · 감시 폴더: <span title="{_esc(root)}">{_esc(_short_roots(root))}</span>{_esc(scanned_note)}{_esc(since_note)}</p>
  {f'<p style="color:#57606a;font-size:13px;margin:0 0 10px">{_esc(merged_note)}</p>' if merged_note else ''}
  {'' if (baseline or not (main or quiet) or _reply or not ACK_ON.get()) else ('<p style="color:#57606a;font-size:13px;margin:0 0 12px">휴대폰·다른 PC에서 보셨다면 의견은 이 메일에 <b>회신</b>으로 남겨 주세요. '
     '각 행의 [감시 PC에서 확인]은 감시 PC에서 Drev 창이 떠 있을 때만 열립니다.</p>' if _loopback(ack_base) else '')}
  <p style="color:#57606a;font-size:12px;margin-top:12px">
    Drev — 읽기 전용 감시. 이 메일은 변경 '사실'의 기록이며,
    내용 판단은 담당자가 합니다.{'' if (baseline or not changes or '/ack?id=' not in body or _loopback(ack_base)) else ' 각 변경의 [확인했음 기록] 링크는 감시 PC에서 그 변경의 상세 화면을 엽니다 — 거기서 [확인함]을 눌러야 기록됩니다.'}{RECIPIENT_LINE if compact else ''}</p>
</body>
</html>
"""


REJUDGED_HEAD = "프로그램 업데이트로 다시 판정한 것"
# 메일 꼬리 — 왜 내가 받나·그만 받으려면 (ux20 mail 8). 받는 사람은 감시 PC 설정(전체·프로젝트별·구매·늘 받는 사람)이 정한다
RECIPIENT_LINE = (" 이 메일은 감시 PC 설정에서 정한 받는 사람(전체·프로젝트 담당·구매 담당)에게 갑니다 — "
                  "받는 사람을 바꾸거나 그만 받으려면 감시 PC 관리자에게 말씀하세요.")


def _rejudged_block(rejudged: list) -> str:
    """판 올림 뒤 파일 변경 없이 다시 판정한 검토 필요 한 묶음 (기능 검토 2026-11-02 J4) — '오늘 확인할 것'·'검토 필요'에서 빼고
    머리에 접어 둔다. 무엇인지는 펼치면 보이고, 근거는 감시 PC 화면의 검토 필요에 그대로 있다(원칙 4)."""
    from watcher.consistency import CODE_LABEL
    lis = "".join(f'<li style="margin:2px 0">{_esc(CODE_LABEL.get(i.code, i.code))} — {_esc(_short(i.message, 140))}</li>'
                  for i in rejudged[:30])
    more = (f'<li style="margin:2px 0">… 외 {len(rejudged) - 30}건</li>' if len(rejudged) > 30 else "")
    return (f'<details style="border:1px solid #d0d7de;border-radius:6px;padding:8px 12px;margin:0 0 12px;'
            f'background:#f6f8fa;font-size:13px;color:#57606a"><summary style="cursor:pointer">'
            f'<b>{REJUDGED_HEAD} {len(rejudged)}건</b> (파일 변경 아님 — 판정 규칙이 바뀌어 다시 본 결과입니다. '
            f'근거는 감시 PC 화면의 검토 필요에 있습니다)</summary>'
            f'<ul style="margin:6px 0 0;padding-left:20px">{lis}{more}</ul></details>')


def _resolved_line(resolved: list) -> str:
    """이번 검사에서 해소된 검토 필요 — 파일이 바뀌어 다시 검출되지 않은 것 (검토39 P2 중간 2). '고쳐짐'이라 단정하면
    서버를 백업에서 되돌린 날에도 그렇게 말했다 (검토42 D 낮음 1)."""
    from watcher.consistency import CODE_LABEL
    # 사유가 '재검출되지 않음'이 아니면 밝힌다 — 'Rev를 올림'·'편집이 되돌려짐'이 메일에 없었다 (검토47 C 중간 3)
    def _why(d):
        w = str(d.get("resolved_by") or "")
        w = w.split("자동 해소 — ", 1)[1] if w.startswith("자동 해소 — ") else ""
        return "" if (not w or w.startswith("다시 검사했을 때")) else f' <span style="color:#57606a">({_esc(w)})</span>'
    lis = "".join(
        f'<li>{_esc(CODE_LABEL.get(d["code"], d["code"]))} — <code>{_esc(PurePosixPath(d["path"]).name)}</code>{_why(d)}</li>'
        for d in resolved[:5])
    more = f'<li style="color:#57606a">외 {len(resolved) - 5}건</li>' if len(resolved) > 5 else ""
    return (f'<div style="border-left:4px solid #1a7f37;padding:6px 12px;margin:0 0 12px;background:#f0fff4">'
            f'<b style="color:#1a7f37">해소된 검토 필요 {len(resolved)}건</b>'
            f'<span style="color:#57606a;font-size:13px"> — 다시 검사했을 때 더 이상 나오지 않습니다 (파일이 바뀜 — 고친 것인지 옛 판으로 되돌아간 것인지는 아래 변경에서)</span>'
            f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{lis}{more}</ul></div>')


def _still_open_line(still_open: list, compact: bool = False) -> str:
    """오늘 관련 파일을 고쳤는데도 아직 열린 불일치와 **지금** 근거 — 무엇이 남았는지 메일에서 바로 보이게 (구매자 평가 P3 차단 1).
    compact(메일 판): 근거 줄의 서버 경로는 파일 이름으로."""
    from watcher.consistency import CODE_LABEL
    lis = []
    for _proj, code, msg, ev, since in still_open[:6]:
        evs = "".join(f'<div style="color:#57606a">{_esc(short_paths(human_ev(e)) if compact else human_ev(e))}</div>' for e in ev)
        lis.append(f'<li><b>{_esc(CODE_LABEL.get(code, code))}</b> — {_esc(msg)}'
                   f'<span style="color:#57606a"> ({_esc(_kdate(since))}부터 열림)</span>{evs}</li>')
    more = f'<li style="color:#57606a">외 {len(still_open) - 6}건</li>' if len(still_open) > 6 else ""
    return (f'<div style="border-left:4px solid #cf222e;padding:6px 12px;margin:0 0 12px;background:#fff8f8">'
            f'<b style="color:#cf222e">관련 파일이 바뀌었지만 아직 열린 불일치 {len(still_open)}건</b>'   # 무관한 편집도 '고쳤는데'였다 (검토49 C 낮음 13)
            f'<span style="color:#57606a;font-size:13px"> — 오늘 관련 파일이 바뀌었지만 아직 어긋난 곳이 남았습니다. 지금 근거:</span>'
            f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px;overflow-wrap:anywhere">{"".join(lis)}{more}</ul></div>')


def _continued_line(continued: list) -> str:
    """열려 있던 경고의 파일이 오늘 또 바뀌었다 — 메일은 새로 잡힌 것만 실어, 발행 전에 Rev를 안 올린 채 이틀째 고치는
    신호가 메일에서 사라졌다 (검토43 C 중간 1). 근거는 화면의 그 경고에 날짜별로 쌓인다."""
    from watcher.consistency import CODE_LABEL
    lis = []
    for path, code, _proj, since in continued[:8]:
        try:
            d = datetime.fromisoformat(str(since)).astimezone().strftime("%m-%d")
        except (TypeError, ValueError):
            d = "앞서"
        lis.append(f'<li><code>{_esc(PurePosixPath(path).name)}</code> — {_esc(CODE_LABEL.get(code, code))} '
                   f'({_esc(d)}부터 열림) — 오늘 또 바뀜</li>')
    more = f'<li style="color:#57606a">외 {len(continued) - 8}건</li>' if len(continued) > 8 else ""
    return (f'<div style="border-left:4px solid #bf8700;padding:6px 12px;margin:0 0 12px;background:#fff8e5">'
            f'<b style="color:#9a6700">이어진 검토 {len(continued)}건</b>'
            f'<span style="color:#57606a;font-size:13px"> — 열려 있던 경고의 파일이 오늘 또 바뀌었습니다 '
            f'(근거는 화면의 그 경고에 날짜별로 쌓입니다)</span>'
            f'<ul style="margin:4px 0 0;padding-left:20px;font-size:13px">{"".join(lis)}{more}</ul></div>')


def _backlog_line(open_backlog, shown: int, ack_base: str | None, project: str | None = None,
                  hide_age: bool = False) -> str:
    """이 메일 밖에 열려 있는 검토 필요 — 오늘 실린 것만이 전부면 말하지 않는다.
    수는 **이 프로젝트** 것이다 — 문장에 없고 링크가 전체 목록(16건)으로 가 '9건'과 어긋났다 (검토37 B 중간 1)."""
    from urllib.parse import quote as _q
    n, days = open_backlog
    if n <= shown:
        return ""
    href = f"{ack_base}/issues" + (f"?p={_q(project)}" if project else "")
    where = (f'<a href="{_esc(href)}" style="color:#0969da">감시 PC 화면의 검토 필요</a>'
             if (ack_base and not _loopback(ack_base)) else "감시 PC 화면의 '검토 필요'")   # 검토50 B 중간 5
    # 시계가 튄 날은 'N일째'가 틀린다 (검토45 C 중간 2). 7일이 넘으면 매일 하나씩 커지는 숫자라 소음 — 주간 요약 첫 문장이 말한다
    # (구매 평가 2차 P2: '가장 오래된 것 14일째')
    age = f" · 가장 오래된 것 {days}일째" if 1 <= days <= 7 and not hide_age else ""
    whose = "이 프로젝트의 " if project else ""
    # 새로 실린 것이 없는 메일에 '새로 잡힌 것만 싣습니다'는 어색했다 (검토37 B 중간 3)
    note = ("이 메일에는 새로 잡힌 것만 싣습니다" if shown else "오늘 새로 잡힌 검토 필요는 없습니다")
    return (f'<p style="color:#9a6700;margin:0 0 12px">{whose}열려 있는 검토 필요 누적 <b>{n}건</b>{age}'
            f' — {note}. 모두 {where}에서 봅니다.</p>')


_BODY_RE = re.compile(r"<body[^>]*>(.*)</body>", re.S | re.I)


# 하루 한 통에서 프로젝트마다 똑같이 반복되던 문구 — 맨 위·아래에 한 번만 싣는다 (재검토 rr066 mail 2: 10곳이면 157KB로 Gmail 102KB를
# 넘어 7번째 프로젝트부터 잘렸다). 위: 회신·사내망 안내, 사진 범례, 확인 안내 / 아래: 검사 시각·감시 폴더 줄, 휴대폰 안내, 꼬리말
_DG_LEGEND = re.compile(r"<!--drev-legend-->.*?<!--/drev-legend-->", re.S)
_DG_ACKNOTE = re.compile(r'<p style="color:#57606a;font-size:12px;margin:0 0 8px">(?:감시 PC 화면 › 전체 이력|감시 PC에서는 <a ).*?</p>', re.S)
_DG_STAMP = re.compile(r'<p style="color:#57606a;margin:24px 0 4px;font-size:13px">.*?</p>', re.S)
_DG_PHONE = re.compile(r'<p style="color:#57606a;font-size:13px;margin:0 0 12px">휴대폰·다른 PC에서 보셨다면.*?</p>', re.S)
_DG_FOOTER = re.compile(r'<p style="color:#57606a;font-size:12px;margin-top:12px">\s*Drev — 읽기 전용 감시\..*?</p>', re.S)
# 반복 인라인 스타일 줄이기 — 칸마다 붙던 줄바꿈 규칙(상속되는 속성)은 섹션 상자 하나에, 머리 칸의 배경·색·정렬은 머리 줄(tr) 하나에
_STYLE_TD_SLIM = "padding:6px 10px;border-bottom:1px solid #d0d7de"
_STYLE_TH_SLIM = "padding:6px 10px;border-bottom:2px solid #d0d7de;white-space:nowrap"
_TH_ROW = re.compile(r'<tr>((?:<th style="' + re.escape(_STYLE_TH) + r'">[^<]*</th>)+)</tr>')


def _hoist(secs: list, rx, pick_longest: bool = False) -> tuple:
    """섹션들에서 rx에 맞는 조각을 빼고 한 번 실을 조각을 돌려준다. 모든 조각이 같을 때만(pick_longest면 가장 긴 것 —
    꼬리말처럼 한쪽이 다른 쪽을 품는 것). 섹션마다 다른 내용(합산 안내가 붙은 검사 시각 줄 등)은 제자리에 둔다."""
    found = [m.group(0) for s in secs for m in rx.finditer(s)]
    if not found:
        return secs, ""
    if len(set(found)) > 1 and not pick_longest:
        return secs, ""
    keep = max(found, key=len)
    return [rx.sub("", s) for s in secs], keep


def _slim_section(inner: str) -> str:
    inner = re.sub(r"\n\s*", "\n", inner)                       # 들여쓰기·빈 줄 (태그 사이 공백은 한 칸으로 남는다)
    # 글자 바꾸기는 split/join으로 — 읽기 전용 검사(test_readonly)가 .replace 호출(Path.replace와 같은 이름)을 막는다
    inner = _STYLE_TD_SLIM.join(inner.split(_STYLE_TD))
    inner = _TH_ROW.sub(lambda m: ('<tr style="text-align:left;background:#f6f8fa;color:#57606a">'
                                   + f'<th style="{_STYLE_TH_SLIM}">'.join(m.group(1).split(f'<th style="{_STYLE_TH}">'))
                                   + '</tr>'), inner)
    return inner


def digest_brief(parts: list, run_at: datetime, title: str, part: tuple | None = None) -> str:
    """하루 묶음 메일 — 프로젝트별 브리핑(문서 전체)을 한 통에 프로젝트 섹션으로 잇는다 (기능 검토 2026-11-02 M1).
    parts: [(프로젝트, 브리핑 HTML)]. 각 브리핑의 본문을 싣고, 맨 위에 프로젝트 목차를 둔다. 섹션마다 반복되던 안내·범례·꼬리말은
    맨 위·아래 한 번만, 반복 인라인 스타일은 줄인다 (rr066 mail 2). part=(k, n): 한 통이 커서 n통으로 나눈 k번째."""
    toc, secs = [], []
    for k, (proj, doc) in enumerate(parts):
        m = _BODY_RE.search(doc or "")
        inner = m.group(1) if m else (doc or "")
        # 프로젝트마다 목차 고리(#chg0…)가 같은 이름이라 둘째 프로젝트 목차가 첫 프로젝트로 뛰었다 — 섹션마다 앞에 붙인다
        inner = re.sub(r'(id="|href="#)(chg\d)', lambda mm: f"{mm.group(1)}dg{k}{mm.group(2)}", inner)
        h = re.search(r"<h2[^>]*>(.*?)</h2>", inner, re.S)
        label = " ".join(re.sub(r"<[^>]+>", "", h.group(1)).split()) if h else str(proj or "미분류")
        toc.append(f'<li><a href="#dg{k}" style="color:#0969da">{_esc(label)}</a></li>')
        secs.append(_slim_section(inner))
    top = []
    for line in (REPLY_LINE, LAN_ACK_LINE, LAN_VIEW_LINE):
        if any(line in s for s in secs):
            secs = ["".join(s.split(line)) for s in secs]
            top.append(line)
    secs, legend = _hoist(secs, _DG_LEGEND)
    secs, acknote = _hoist(secs, _DG_ACKNOTE)
    secs, stamp = _hoist(secs, _DG_STAMP)
    secs, phone = _hoist(secs, _DG_PHONE)
    secs, footer = _hoist(secs, _DG_FOOTER, pick_longest=True)
    secs = [f'<div id="dg{k}" style="border-top:3px solid #d0d7de;margin:18px 0 0;padding-top:14px;'
            f'overflow-wrap:anywhere;word-break:keep-all">{s}</div>' for k, s in enumerate(secs)]
    head = re.search(r"<head>.*?</head>", parts[0][1], re.S) if parts else None
    _part = f" part={part[0]}/{part[1]}" if part else ""
    _rest = (" 나머지 프로젝트는 같은 제목의 다른 통에 있습니다(한 통이 커서 메일 앱이 뒤쪽을 자르지 않게 나눴습니다)."
             if part else "")
    return (f'<!DOCTYPE html>\n<!--drev-digest n={len(parts)}{_part}-->\n<html lang="ko">\n'
            f'{head.group(0) if head else "<head><meta charset=utf-8></head>"}\n'
            f'<body bgcolor="#ffffff" style="font-family:\'Malgun Gothic\',Segoe UI,sans-serif;color:#1f2328;'
            f'background:#ffffff;max-width:860px;margin:0 auto;padding:24px;word-break:keep-all;overflow-wrap:anywhere">\n'
            f'<h2 style="margin:0 0 6px">{_esc(title)}</h2>\n'
            f'<p style="color:#57606a;font-size:13px;margin:0 0 6px">{_esc(run_at.strftime("%Y-%m-%d %H:%M"))} 검사 — '
            f'프로젝트 {len(parts)}곳을 한 통에 모았습니다. 프로젝트별 담당이 정해진 프로젝트와, BOM·발주서가 바뀌어 '
            f'구매 담당도 받는 날의 프로젝트는 따로 갑니다.'
            f'{_rest}</p>\n'
            f'<ul style="margin:0 0 10px;padding-left:20px;font-size:14px">{"".join(toc)}</ul>\n'
            + "".join(top) + legend + acknote + "\n"
            + "\n".join(secs) + "\n" + stamp + phone + footer + "\n</body>\n</html>\n")


def brief_filename(run_at: datetime, project: str | None = None,
                   baseline: bool = False) -> str:
    # 표제란에서 온 프로젝트 문자열이 그대로 들어온다 — 경로 구분자·Windows 금지
    # 문자를 소독하지 않으면 파일 생성이 죽거나 brief_dir 밖에 쓰게 된다
    if project:
        # 띄어쓰기는 그대로 — 제목 '[PJ-2604 재저장]'과 파일 이름 'PJ-2604_재저장'이 따로 놀았다 (검토71 R4 낮음 12)
        safe = re.sub(r'[\\/:*?"<>|.]+', "_", project)
        safe = re.sub(r"\s+", " ", safe).strip("_ ") or "무명"
        suffix = f"_{safe}"
    else:
        suffix = ""
    # 기준선(첫 검사) 브리핑은 이름을 따로 둔다 — 같은 날 실제 변경 브리핑이 그 날 파일을
    # 쓰고, 재검사 때 합쳐 갱신할 수 있게 (2026-09-05 재검토)
    if baseline:
        suffix += "_기준선"
    return f"brief_{run_at.strftime('%Y%m%d')}{suffix}.html"


# ── 메일 압축·머리 한 줄 (구매 평가 2차 F2, 2026-10-19) ─────────────────────────────────────────────────────────────
# 설계팀장 2주 평가(P2)가 메일을 '팀원이 2주 뒤 버릴 것'으로 봤다: 변경 5건 메일이 136~156줄·사진 18장·7,000px 스크롤, 같은 도면의
# DXF와 출도 PDF가 같은 변경을 두 번 싣고, 표제란 DATE·REV 칸마다 사진, 사진마다 같은 설명 줄. 메일 판(photo_budget)만 줄인다 —
# 디스크 브리핑·화면은 그대로 전부(기록). 어떤 변경도 메일에서 빠지지 않는다: 줄인 것은 **한 줄**로 남긴다(원칙 5).
_MAIL_PHOTOS_PER_CHANGE = 1          # 변경 한 건당 사진(전/후 한 쌍) — 나머지는 화면
_MAIL_ROWS_PER_CHANGE = 12           # 변경 한 건의 글자·그림 표 줄 상한 — 나머지는 '외 N건'(표 행은 _DETAIL_CAP 그대로)
REVSAME_HINT = "(발행 전 작업본이면 무시하세요 — 발행 시 Rev를 올리면 해소됩니다)"


def _ntok(s) -> list:
    return " ".join(str(s or "").split()).split()


_VAL_UNIT = re.compile(r"^([-+]?\d[\d.,]*)([A-Za-z㎾㎟℃°%/Ωμ][A-Za-z0-9㎾㎟℃°%/Ωμ.]*)$")


def short_pair(old, new, limit: int = 40) -> str:
    """'100AF 75AT 3P'→'100AF 100AT 3P' ⇒ '75→100AT', '3.7kW 4P 380V'→'5.5kW 4P 380V' ⇒ '3.7→5.5kW' — 바뀐 낱말만.
    사장·구매가 읽는 머리 한 줄·제목용. 바뀐 곳이 여러 군데면 앞뒤 전체(길면 낱말 경계에서 자름)."""
    from difflib import SequenceMatcher
    ot, nt = _ntok(old), _ntok(new)
    if not ot or not nt:
        return cut_words(" ".join(nt or ot), limit)
    ops = [op for op in SequenceMatcher(None, ot, nt, autojunk=False).get_opcodes() if op[0] != "equal"]

    def _one(i1, i2, j1, j2):
        a, b = " ".join(ot[i1:i2]).strip(",;"), " ".join(nt[j1:j2]).strip(",;")
        ma, mb = _VAL_UNIT.match(a), _VAL_UNIT.match(b)
        if ma and mb and ma.group(2) == mb.group(2):
            return f"{ma.group(1)}→{mb.group(1)}{ma.group(2)}"
        # 단위가 따로 선 값('56 rpm'→'45 rpm')은 바뀐 숫자 뒤에 같은 단위를 붙인다
        if re.fullmatch(r"[-+]?\d[\d.,/]*", a) and re.fullmatch(r"[-+]?\d[\d.,/]*", b) and j2 < len(nt) \
                and i2 < len(ot) and ot[i2] == nt[j2] and re.fullmatch(r"[A-Za-z㎾%℃°]{1,5}", nt[j2].strip(",;")):
            return f"{a}→{b}{nt[j2].strip(',;')}"
        return f"{a}→{b}"
    if ops and len(ops) <= 3 and all(op[0] == "replace" for op in ops):
        s = ", ".join(_one(i1, i2, j1, j2) for _t, i1, i2, j1, j2 in ops)
        if len(s) <= limit:
            return s
    return cut_words(" ".join(ot), limit // 2) + "→" + cut_words(" ".join(nt), limit // 2)


def cut_words(s: str, n: int) -> str:
    """n자 안에서 **낱말 경계**로 자른다 — '3.7kW 4…'·'M-1…'처럼 낱말 가운데서 끊겨 엉뚱한 값으로 읽혔다 (P2 제목)."""
    s = " ".join(str(s or "").split())
    if len(s) <= n:
        return s
    cut = s.rfind(" ", 0, n)
    if cut < max(4, n // 3):
        return s[:n - 1].rstrip(" ,;·—-") + "…"
    return s[:cut].rstrip(" ,;·—-") + "…"


def _short_no(dwg: str | None, project: str | None) -> str:
    """도면번호에서 프로젝트 앞말을 뗀 짧은 이름 — 'HB26-003-E-002' → 'E-002' (제목·머리 한 줄용)."""
    d = str(dwg or "").split(" (")[0].strip()
    p = str(project or "").split()[0] if project else ""
    if p and d.upper().startswith((p.upper() + "-", p.upper() + "_")) and len(d) > len(p) + 1:
        return d[len(p) + 1:]
    return d


def _facts_of(c, items) -> list:
    """변경 한 건에서 사람에게 말할 값 변화 [(태그|None, 짧은 변화, 무게)] — 짝 이름표 > 단위 든 글줄 > 표 행."""
    out, seen = [], set()
    for it in items:
        lab = pair_label(it)
        if lab:
            for part in lab.split("; "):
                if part in seen:
                    continue
                seen.add(part)
                tag, _, rest = part.partition(": ")
                if " → " in rest:
                    o, n = rest.split(" → ", 1)
                    out.append((tag, short_pair(o, n), 0))
                elif rest.endswith("(새로)"):
                    out.append((tag, cut_words(rest[:-4].strip(), 24) + " 새로", 1))
                elif part.endswith("태그 추가"):
                    out.append((part[:-6].strip(), "태그 추가", 1))
    for it in items:
        if pair_label(it):
            continue
        if it.kind == "TEXT_CHANGED" and it.old and it.new and _UNIT_RE.search(f"{it.old} {it.new}"):
            from watcher.extract.base import find_tags
            tg = find_tags(str(it.new))
            out.append((tg[0] if len(tg) == 1 else None, short_pair(it.old, it.new), 0))
        elif it.kind == "ROW_CHANGED" and it.old is not None and it.new is not None:
            rk, sep, col = str(it.key).rpartition(".")
            # 사양 칸(규격·SPEC)은 칸 이름 없이 — 도면의 같은 값 변화와 한 줄로 묶이게 ('E-002·BOM M-102 2.2→3.7kW')
            _spec_col = bool(re.fullmatch(r"(?i)\s*(규격|사양|SPEC\.?|SPECIFICATION|RATING|정격|용량|MODEL|형식)\s*", col or ""))
            out.append((rk if sep else str(it.key), ("" if (_spec_col or not sep) else f"{col} ") + short_pair(
                _group_digits(str(it.old)), _group_digits(str(it.new))), 0))
    return out


def _rev_of(items) -> str:
    from watcher.diff import _blank_rev, is_rev_field
    rv = next((it for it in items if is_rev_field(it)), None)
    if rv is None:
        return ""
    return f"Rev {rv.new} 첫 기재" if _blank_rev(rv.old) else f"Rev {rv.old}→{rv.new}"


def mail_headline(main: list, issues: list, details: dict | None, doc_info: dict | None,
                  details_by_id: dict | None = None, project: str | None = None) -> tuple[str, str]:
    """메일 맨 위 사장·구매용 한 줄과 제목용 짧은 말 — (문장, 짧은 말). 할 말이 없으면 ("", "").
    레이어·좌표·서버 경로 같은 기술 문구는 넣지 않는다(아래 근거에 있다). 예: 'E-101 M-101 7.5→11kW, Rev 안 올림, BOM은 아직
    7.5kW — 발주 전 확인' (구매 평가 2차 P1·P2)."""
    details = details or {}

    def info_of(c):
        return (doc_info or {}).get(c.id) or (doc_info or {}).get(c.path) or {}

    def _folder_tail(c) -> str:
        # 같은 이름 파일이 프로젝트 안에 또 있으면(작업중_사본/·구판/) 어느 폴더 것인지 — 원본이 바뀐 줄 알았다 (ux20 daily 1)
        f_ = ((doc_info or {}).get(c.id) or {}).get("folder") or ((doc_info or {}).get(c.path) or {}).get("folder")
        return f" ({f_} 폴더)" if f_ else ""

    def _base_name(c):
        return (_short_no(info_of(c).get("dwg"), project) or _short_no(PurePosixPath(c.path).stem, project)) + _folder_tail(c)

    def _doc_word(c, nm: str) -> str:
        # '도면 E-101'처럼 문서 종류를 앞에 — 'E-101 M-101 …'이 도면번호와 태그가 붙어 오타처럼 읽혔다 (ux20 mail 5)
        try:
            from watcher.doctype import canonical as _can, kind_of as _ko
            k = _can(_ko(c.path, None) or "")
        except Exception:               # noqa: BLE001
            k = ""
        if k == "도면" and not info_of(c).get("dwg") and PurePosixPath(c.path).suffix.lower() not in (".dxf", ".dwg"):
            return nm                    # 도면번호 없는 PDF는 사양서·보고서일 수 있다 — 종류를 짐작해 붙이지 않는다
        return f"{k} {nm}" if k and k not in ("기타", "문서") and k.casefold() not in nm.casefold() else nm

    def name_of(c):
        # 같은 도면번호의 DXF와 PDF가 함께 바뀐 날은 어느 쪽인지 — 'E-9040'만으로는 Rev를 안 올린 쪽이 출도 PDF인지 몰랐다
        nm = _base_name(c)
        if any(o is not c and _base_name(o) == nm and PurePosixPath(o.path).suffix.lower() != PurePosixPath(c.path).suffix.lower()
               for o in main):
            nm += f"({PurePosixPath(c.path).suffix.lstrip('.').upper()})"
        return nm
    facts = []           # (태그, 변화, 무게, 변경)
    for c in main:
        for tag, ch, w in _facts_of(c, items_for(c, details, details_by_id)):
            facts.append((tag, ch, w, c))
    rev_same = {i.path for i in issues if i.code == "CONTENT_CHANGED_REV_SAME"}

    def _rev_state(c) -> str:
        if c.path in rev_same:
            return "Rev 안 올림"
        return _rev_of(items_for(c, details, details_by_id))

    def _fact_phrase(tag) -> tuple[str, str]:
        hit = [f for f in facts if f[0] == tag]
        if not hit:
            return "", ""
        ch = hit[0][1]
        _hc = list(dict.fromkeys(id(f[3]) for f in hit if f[1] == ch))
        _cs = {id(f[3]): f[3] for f in hit}
        docs = list(dict.fromkeys(_base_name(_cs[k]) for k in _hc))
        revs = list(dict.fromkeys(r for r in (_rev_state(f[3]) for f in hit if f[1] == ch) if r))
        if len(revs) > 1 and "Rev 안 올림" not in revs:
            revs = ["Rev 올림"]            # 문서마다 다른 'Rev B→C·Rev A→B'는 한 말로
        where = "·".join(docs[:3]) + (" 외" if len(docs) > 3 else "")
        if docs:                         # 첫 문서에 종류 낱말 — '도면 E-101·BOM_전장: M-101 5.5→7.5kW' (ux20 mail 5)
            where = _doc_word(_cs[_hc[0]], docs[0]) + where[len(docs[0]):]
        # 문서 이름과 태그 사이에 ':' — 'E-101·BOM_전장 M-101 5.5→7.5kW'가 한 낱말처럼 붙어 읽혔다
        return f"{where}: {tag} {ch}" + (f", {'·'.join(revs[:2])}" if revs else ""), f"{tag} {ch}"

    tail = f" (검토 필요 {len(issues)}건)" if len(issues) > 1 else ""
    order = ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS", "CONTENT_CHANGED_REV_SAME", "REV_BLOCK_MISMATCH",
             "REV_REGRESSED", "REV_CHANGED_CONTENT_SAME")
    top = next((i for code in order for i in issues if i.code == code), None)
    if top is not None:
        if top.code in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS"):
            m = re.search(r"\]\s*(?:태그\s+)?([^\s:]+?)(?::|의 사양)", top.message)
            tag = m.group(1) if m else ""
            long_, short = _fact_phrase(tag) if tag else ("", "")
            if top.code == "BOM_MISMATCH":
                spec = next((mm.group(1) for e in top.evidence for mm in [re.match(r"BOM: \S+ SPEC=(.*?) \(", str(e))] if mm), "")
                bom_changed = any(f[0] == tag and PurePosixPath(f[3].path).suffix.lower() in (".xlsx", ".xlsm", ".xls")
                                  for f in facts)
                if long_ and not bom_changed:
                    return (f"{long_}, BOM은 아직 {cut_words(spec, 24)} — 발주 전 확인{tail}",
                            f"{short}, BOM 그대로")
                if long_:
                    return f"{long_.strip()} — BOM이 도면 기재와 다름, 발주 전 확인{tail}", f"BOM {short}, 도면과 다름"
                return (f"{tag}: 도면과 BOM 사양이 다름 (BOM {cut_words(spec, 24)}) — 발주 전 확인{tail}",
                        f"{tag} 도면·BOM 사양 다름")
            vals = re.search(r"\(([^()]*vs[^()]*)\)", top.message)
            vs = vals.group(1) if vals else ""
            if long_:
                return f"{long_} — 다른 도면과 사양이 다름({vs}), 확인{tail}", f"{short}, 도면끼리 다름"
            return f"{tag} 도면끼리 사양이 다름 ({vs}) — 어느 쪽이 맞는지 확인{tail}", f"{tag} 도면끼리 사양 다름"
        c = next((c for c in main if c.path == top.path), None)
        nm = name_of(c) if c is not None else PurePosixPath(top.path).stem
        if top.code == "CONTENT_CHANGED_REV_SAME":
            f = next((f for f in facts if f[3] is c), None)
            what = (f"{f[0]} {f[1]}" if f[0] else f[1]) if f else ""
            if not what and c is not None:
                ent = _toc_entries([c], details, doc_info, False, details_by_id)
                what = cut_words(ent[0][2], 36) if ent else ""
            return (" ".join(f"{_doc_word(c, nm) if c is not None else nm}: {what}, Rev 안 올림 — 출도·발주 전 확인{tail}".split()),
                    " ".join(f"{nm} Rev 안 올림: {what}".split()))
        if top.code == "REV_BLOCK_MISMATCH":
            return f"{nm}: 표제란 Rev와 개정표가 다름 — 어느 쪽이 맞는지 확인{tail}", f"{nm} 표제란·개정표 Rev 다름"
        m = re.search(r"Rev가 (\S+?)→(\S+?)로", top.message)
        rv = f"Rev {m.group(1)}→{m.group(2)}" if m else "Rev"
        if top.code == "REV_REGRESSED":
            return f"{nm}: {rv} 거꾸로 감 — 옛 판으로 덮어썼는지 확인{tail}", f"{nm} {rv} 거꾸로"
        return f"{nm}: {rv} 올렸는데 글자 변경 없음 — 그림만 고쳤는지 확인{tail}", f"{nm} {rv}, 글자 변경 없음"
    # 검토 필요가 없으면 가장 무거운 값 변화 하나 — 같은 값 변화가 여러 문서(DXF·PDF·BOM)에 있으면 한 줄로. 여러 문서에 걸친
    # 태그(도면·BOM이 함께 바뀐 모터)를 앞에
    _ndocs = Counter()
    for f in facts:
        if f[0]:
            _ndocs[f[0]] += 1
    best = sorted(facts, key=lambda f: (f[2], -_ndocs.get(f[0], 0) if f[0] else 0))
    if best:
        tag, ch, _w, c = best[0]
        if tag:
            long_, short = _fact_phrase(tag)
            # 같은 값 변화를 태그 없이 적은 출도 PDF·사양서는 '그 밖'이 아니다
            n_other = len({id(f[3]) for f in facts if f[0] != tag and not (f[0] is None and f[1] == ch)})
            return (long_ + (f" (그 밖의 값 변화 {n_other}건)" if n_other else ""), short)
        rs = _rev_state(c)
        return f"{_doc_word(c, name_of(c))}: {ch}" + (f", {rs}" if rs else ""), f"{name_of(c)} {ch}"
    return "", ""


def wiped_folders(main: list, present_dirs, min_files: int = 3) -> list:
    """오늘 삭제된 파일 가운데, 등록 파일이 **하나도 안 남은** 가장 높은 폴더별 [(폴더, 삭제 수)] — 셋 이상만.
    present_dirs: 지금 스냅샷(이월 포함) 파일들의 모든 조상 폴더 (감시 폴더 자체는 세지 않는다 — 그건 대량 삭제 보류가 본다)."""
    out: dict = {}
    for c in main or []:
        if getattr(c, "kind", "") != "removed":
            continue
        parts = PurePosixPath(c.path).parent.parts
        for k in range(2, len(parts) + 1):          # parts[0]은 감시 폴더 이름표
            d = "/".join(parts[:k])
            if d not in present_dirs:
                out[d] = out.get(d, 0) + 1
                break
    return sorted(((d, n) for d, n in out.items() if n >= min_files), key=lambda x: (-x[1], x[0]))


def wiped_line(wiped: list | None) -> str:
    """'폴더 P26-031 컨베이어 전체(파일 26개)가 삭제됨' — 폴더가 여럿이면 앞 둘 + 외 N."""
    if not wiped:
        return ""
    parts = [f"폴더 '{PurePosixPath(d).name}' 전체(파일 {n}개)" for d, n in wiped[:2]]
    more = f" 외 폴더 {len(wiped) - 2}개" if len(wiped) > 2 else ""
    return f"{', '.join(parts)}{more}가 삭제됨"


def headline_html(text: str) -> str:
    """머리 한 줄 — 확인할 것이 있으면 붉은 띠, 아니면 회색 띠."""
    if not text:
        return ""
    act = "확인" in text
    return (f'<p style="font-size:16px;font-weight:700;margin:0 0 10px;padding:8px 12px;border-radius:6px;'
            f'background:{"#fff1e5" if act else "#f6f8fa"};border-left:5px solid {"#cf222e" if act else "#1d4ed8"}">'
            f'{_esc(text)}</p>')


def drawing_companions(main: list, doc_info: dict | None) -> dict:
    """같은 도면(같은 도면번호·같은 Rev·같은 변경 종류)의 DXF·DWG 변경과 출도 PDF 변경 짝 — {id(PDF 변경): DXF 변경}. 메일에서 PDF는
    DXF 밑에 한 줄로 붙인다(P2: 같은 변경이 DXF·PDF로 두 번, 사진 두 벌). 한쪽만 바뀌었으면 짝이 없다 — PDF가 그대로면 PDF 변경 자체가
    없고, DXF만 그대로면 PDF는 제 행으로 남는다."""
    def _key(c):
        i = (doc_info or {}).get(c.id) or (doc_info or {}).get(c.path) or {}
        d = str(i.get("dwg") or "").split(" (")[0].strip().upper()
        r = str(i.get("rev") or "").strip().upper()
        return (d, r, c.kind) if d and r else None
    cad: dict = {}
    for c in main:
        if PurePosixPath(c.path).suffix.lower() in (".dxf", ".dwg") and c.kind in ("modified", "added"):
            k = _key(c)
            if k is not None:
                cad.setdefault(k, []).append(c)
    out = {}
    for c in main:
        if PurePosixPath(c.path).suffix.lower() == ".pdf" and c.kind in ("modified", "added"):
            k = _key(c)
            if k is not None and len(cad.get(k, [])) == 1:
                out[id(c)] = cad[k][0]
    return out


_QUIET_GROUPS = (("복사본 정리", "복사본 정리 (원본은 그대로)"), ("구판 정리", "구판 정리 (현행은 그대로)"),
                 ("복사본", "복사본"), ("일자만 갱신", "표제란 일자만 갱신 (재출력)"),
                 ("표제란 틀만", "표제란 틀만 교체"), ("빈 파일", "빈 파일(0바이트)"), ("순서만 바뀜", "순서만 바뀜"),
                 ("재저장", "다시 저장 (내용 동일)"), ("내용 변경 없음", "다시 저장 (내용 동일)"))


def quiet_group(note: str) -> str:
    """'그 밖의 알림'을 메일에서 종류별 한 줄로 묶는 이름."""
    n = str(note or "")
    return next((lab for w, lab in _QUIET_GROUPS if w in n), cut_words(n.split(" — ")[0], 30) or "그 밖의 알림")


def short_paths(s: str) -> str:
    """근거 줄 괄호 안의 서버 경로 → 파일 이름 ('(BOM 시트 11행, 설계서버/…/03_BOM/HB26-003_BOM.xlsx)' →
    '(BOM 시트 11행, HB26-003_BOM.xlsx)'). 폴더 이름에 띄어쓰기·쉼표가 없다고 보지 않고, 괄호 안 쉼표 조각마다 마지막 '/' 뒤만
    남긴다 — 메일 판만 (디스크 브리핑·화면은 전체)."""
    # 괄호 끝(또는 쉼표 뒤)의 '폴더/…/파일.확장자)' — 폴더 이름에 괄호('02_출도(PDF)')·띄어쓰기가 있어도 마지막 '/' 뒤만.
    # 파일 이름(확장자)으로 끝나는 것만 — '감속비 1/25'·'2026/10/09'는 경로가 아니다
    return _EV_PATH.sub(r"\1\3)", str(s or ""))


_EV_PATH = re.compile(r"(, |\()([^,]*/)([^/,()]+\.[A-Za-z0-9]{2,5})\)")
