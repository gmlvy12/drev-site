# -*- coding: utf-8 -*-
"""문서 유형 분류 (2026-08-31).

배경: 확장자만 보고 xlsx를 전부 "BOM"이라 불렀더니 인터락 시트가 BOM으로
표시됐다. 더 근본적으로는 **회사마다 양식과 부르는 이름이 다르다** — 우리가
아는 이름을 코드에 박아두면 영원히 어긋난다. 그래서 규칙을 데이터로 빼고
사용자가 [설정]에서 직접 만들 수 있게 한다.

판별 순서:
  ① **폴더 지정**(config의 doc_folders) — 실무에서 유형별로 폴더를 나눠 저장하는
     경우가 가장 많다(2026-08-31 사용자). 가장 구체적인(긴) 폴더가 이긴다.
  ② 사용자 키워드 규칙(doc_types) — 파일명 먼저, 그다음 폴더명
  ③ 내장 기본 규칙 — 흔한 이름들(도면·BOM·인터락·발주서 …)
  ④ 확장자 기본 — 도면/표/문서
어디에도 안 걸리면 "기타"다. 억지로 이름 붙이지 않는다 (틀린 이름표보다 낫다).

매칭 대상은 **파일명 + 상위 폴더명**이다. 회사들이 유형을 폴더로 나누는 일이
흔하기 때문(예: 03_인터락/…​.xlsx).
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath

UNKNOWN = "기타"

# 내장 기본 규칙 — 사용자 규칙이 우선한다.
# (이름, 키워드들, 해당 확장자, 영문 이름)
# 영문 이름: 파일·폴더 이름이 영어로 적혀 있으면 그 표기를 그대로 쓴다
# (2026-09-01 사용자: "인터락은 영어니까 영어로 표현해도 돼"). 회사가 쓰는
# 말을 화면이 따라가는 편이 찾기 쉽다. 한글로 적혀 있으면 한글 이름 그대로.
BUILTIN = [
    ("인터락", ("인터락", "인터록", "INTERLOCK"), None, "Interlock"),
    ("발주서", ("발주", "구매", "PURCHASE", "ORDER", "PO"), None, "Purchase Order"),
    ("견적서", ("견적", "QUOTATION", "QUOTE"), None, "Quotation"),
    ("배선표", ("배선", "결선", "CABLE SCHEDULE", "WIRING LIST", "WIRING", "CABLE", "케이블"),
     None, "Cable List"),
    ("점검표", ("점검", "CHECKLIST", "CHECK LIST", "체크리스트", "체크"), None, "Checklist"),
    ("사양서", ("사양", "규격", "SPEC", "SPECIFICATION"), None, "Spec"),
    ("시퀀스", ("시퀀스", "SEQUENCE", "SEQ"), None, "Sequence"),
    ("거래명세서", ("거래명세", "세금계산서", "INVOICE"), None, "Invoice"),
    ("납품서", ("납품서", "납품확인서", "납품", "DELIVERY NOTE", "DELIVERY"), None, "Delivery Note"),
    ("시험성적서", ("성적서", "TESTREPORT", "TEST REPORT"), None, "Test Report"),
    ("설계변경", ("설계변경", "ECN", "ECO", "변경통지"), None, "ECN"),
    ("I/O 리스트", ("IOLIST", "IO LIST", "I/O", "입출력"), None, "I/O List"),
    ("매뉴얼", ("매뉴얼", "설명서", "MANUAL", "작업표준", "작업지침"), None, "Manual"),
    ("일정표", ("일정표", "공정표", "SCHEDULE"), None, "Schedule"),
    ("회의록", ("회의록", "MINUTES"), None, "Minutes"),
    ("계약서", ("계약서", "계약", "CONTRACT", "AGREEMENT"), None, "Contract"),
    ("BOM", ("BOM", "자재", "부품", "PARTS", "PARTLIST", "자재표"), None, "BOM"),
    # 카탈로그·데이터시트·매뉴얼은 남의 문서 — 도면·발주서로 잡히면 안 된다 (2026-09-03 검토)
    ("참고자료", ("카탈로그", "CATALOG", "CATALOGUE", "데이터시트", "DATASHEET", "매뉴얼",
              "MANUAL", "사용설명서"), None, "Reference"),
    ("요청서", ("요청서",), None, "Request"),
    ("기준서", ("기준서",), None, "Standard"),
    ("도면", ("도면", "DWG", "DRAWING", "DRAWINGS"), None, "Drawing"),
]

# 확장자로만 정하는 최후의 기본값
from watcher.extract import kind_groups as _kind_groups  # noqa: E402

EXT_FALLBACK = _kind_groups()      # 형식 레지스트리(watcher/extract/__init__.py)에서 파생

# 한글·영문 표기는 같은 종류다 — 메뉴·필터는 하나로 묶는다 (2026-09-01)
CANON = {}
for _ko, _kws, _exts, _en in BUILTIN:
    CANON[_ko] = _ko
    if _en:
        CANON[_en] = _ko


def canonical(label: str) -> str:
    """표기가 달라도 같은 종류면 같은 값을 돌려준다 (예: Drawing → 도면)."""
    return CANON.get(label, label)


# 돈·납기·규격이 걸린 유형이 앞에 온다 — 회의록·참고자료는 뒤. 화면 '오늘 확인할 것',
# 메일 브리핑, 사이드바 메뉴가 같은 순서를 쓴다 (2026-09-05 사용성 재검토)
DOC_RANK = {"도면": 0, "BOM": 1, "발주서": 2, "계약서": 3, "사양서": 4, "견적서": 5,
            "설계변경": 6, "I/O 리스트": 7, "인터락": 8, "배선표": 9, "표": 12,
            "매뉴얼": 55, "회의록": 60, "참고자료": 60}


def doc_rank(label: str) -> int:
    return DOC_RANK.get(canonical(label), 50)


def same_kind(a: str, b: str) -> bool:
    return canonical(a) == canonical(b)


# ── 내용 단서 (2026-09-02) — 검사 때 추출한 내용에서 유형을 읽는다
# 제목 낱말: 본문·표제란 어디에든 있으면 그 유형. 표 머리글: 돈 열이 2개 이상이면
# 견적서(발주 낱말이 함께 있으면 발주서), 자재 열이 2개 이상이면 BOM.
_TITLE_WORDS = [
    ("견적서", ("견적서", "QUOTATION", "QUOTE", "ESTIMATE"), "Quotation"),
    ("발주서", ("발주서", "PURCHASE ORDER", "P/O", "PO NO"), "Purchase Order"),
    ("거래명세서", ("거래명세서", "거래명세", "세금계산서", "INVOICE"), "Invoice"),
    ("납품서", ("납품서", "납품확인서", "납품명세", "DELIVERY NOTE"), "Delivery Note"),
    ("시험성적서", ("시험성적서", "검사성적서", "성적서", "TEST REPORT",
                "INSPECTION REPORT"), "Test Report"),
    ("설계변경", ("설계변경", "변경통지", "ECN", "CHANGE NOTICE"), "ECN"),
    ("배선표", ("CABLE SCHEDULE", "케이블 스케줄", "배선표", "결선표", "WIRING LIST",
              "CABLE LIST"), "Cable List"),
    ("I/O 리스트", ("I/O LIST", "IO LIST", "I/O 리스트", "IO 리스트", "입출력 리스트"),
     "I/O List"),
    ("점검표", ("점검표", "CHECKLIST", "CHECK LIST", "체크리스트", "점검 리스트"),
     "Checklist"),
    ("회의록", ("회의록", "MEETING MINUTES", "회의 록"), "Minutes"),
    ("계약서", ("계약서", "AGREEMENT"), "Contract"),      # CONTRACT는 contractor에 걸린다
    ("매뉴얼", ("매뉴얼", "취급설명서", "사용설명서", "작업표준", "작업지침",
             "OPERATION MANUAL", "USER MANUAL", "INSTRUCTION MANUAL"), "Manual"),
    ("일정표", ("일정표", "공정표", "PROJECT SCHEDULE", "MASTER SCHEDULE", "GANTT"),
     "Schedule"),
    ("인터락", ("인터락", "인터록", "INTERLOCK"), "Interlock"),
    ("사양서", ("사양서", "SPECIFICATION"), "Spec"),
]
# 계약서는 조항 구조(제1조·제2조)로도 알아본다 — 제목이 '기본계약'처럼 변형돼도
_CLAUSE_RE = re.compile(r"제\s?\d{1,3}\s?조")
_MONEY_HEADERS = ("단가", "금액", "합계", "공급가액", "부가세", "총액", "소계",
                  "UNIT PRICE", "AMOUNT", "TOTAL", "PRICE", "VAT")
_BOM_HEADERS = ("TAG", "SPEC", "품번", "품명", "부품명", "자재명", "QTY", "수량",
                "PART NO", "PARTNO", "규격", "MAKER", "제조사")
# 양식에만 있는 머리글 조합 — (유형, 영문, 머리글들, 최소 개수). 위에서부터 본다
_HEADER_SETS = (
    ("I/O 리스트", "I/O List",
     ("ADDRESS", "DI", "DO", "AI", "AO", "신호명", "SIGNAL", "PLC", "접점", "채널",
      "CHANNEL", "I/O"), 2),
    ("배선표", "Cable List",
     ("FROM", "TO", "CABLE", "케이블", "길이", "LENGTH", "CORE", "SQ", "굵기", "선번",
      "CABLE NO"), 3),                          # FROM·TO는 흔해서 3개
    ("점검표", "Checklist",
     ("점검항목", "점검 항목", "판정", "OK", "NG", "합격", "불합격", "확인자", "점검일",
      "RESULT", "PASS", "FAIL"), 2),
    ("인터락", "Interlock",
     ("조건", "동작", "출력", "입력", "트립", "TRIP", "INTERLOCK", "CONDITION",
      "ACTION"), 3),
)

class _Hints(dict):
    """검사 때 저장된 내용 단서 {경로: (유형, 근거)} — 화면·검사가 같은 것을 본다.

    바뀌면 version을 올려 분류 캐시(_CLS_CACHE)를 무르게 한다. 평범한 dict로 두고
    호출부가 clear()/update()를 직접 하던 구조라, 자리를 그대로 두고 여기서 센다."""

    version = 0

    def _bump(self) -> None:
        _Hints.version += 1

    def clear(self):
        super().clear()
        self._bump()

    def update(self, *a, **k):
        super().update(*a, **k)
        self._bump()

    def __setitem__(self, k, v):
        super().__setitem__(k, v)
        self._bump()

    def __delitem__(self, k):
        super().__delitem__(k)
        self._bump()

    def pop(self, *a):
        out = super().pop(*a)
        self._bump()
        return out


HINTS: dict = _Hints()


def _doc_parts(doc) -> tuple[list, list]:
    """(제목 후보 문자열들, 표 머리글들). Document든 to_dict() 결과든 받는다."""
    if isinstance(doc, dict):
        fields = doc.get("fields") or {}
        rows = doc.get("rows") or []
        texts = [t.get("text", "") if isinstance(t, dict) else str(t)
                 for t in (doc.get("raw_texts") or [])]
        fvals = [str(v.get("name", "")) + " " + str(v.get("value", ""))
                 if isinstance(v, dict) else str(v) for v in fields.values()]
        heads = set()
        for r in rows[:50]:
            vals = r.get("values") if isinstance(r, dict) else getattr(r, "values", {})
            heads.update(str(k) for k in (vals or {}).keys())
    else:
        texts = [t.text for t in getattr(doc, "raw_texts", [])]
        fvals = [f"{f.name} {f.value}" for f in getattr(doc, "fields", {}).values()]
        heads = set()
        for r in getattr(doc, "rows", [])[:50]:
            heads.update(str(k) for k in (r.values or {}).keys())
    return fvals + texts[:80], sorted(heads)


def content_hint(doc) -> tuple[str, str] | None:
    """추출된 내용에서 (유형, 근거). 단서가 없으면 None — 억지로 붙이지 않는다."""
    titles, heads = _doc_parts(doc)
    blob = " ".join(titles).upper()
    tight = "".join(blob.split())         # "견 적 서"처럼 띄어 쓴 제목 (2026-09-03 검토)
    for name, words, en in _TITLE_WORDS:
        for w in words:
            wu = w.upper()
            # 영문은 낱말 경계로 — ECO⊂RECORD, QUOTE⊂QUOTED 같은 부분일치 오탐 방지
            # (2026-09-02 검토). 한글은 붙여쓰기가 흔해 부분일치 유지(단독형은 뺐다)
            if (re.search(r"(?<![A-Z0-9])" + re.escape(wu) + r"(?![A-Z0-9])", blob)
                    if wu.isascii() else (wu in blob or wu in tight)):
                label = en if (w.isascii() and en) else name
                return label, f"내용 ('{w}')"
    if len(_CLAUSE_RE.findall(" ".join(titles))) >= 2:  # 제1조 … 제2조 …
        return "계약서", "내용 (조항 구조 '제N조')"
    up_heads = {h.upper().strip() for h in heads}
    money = [h for h in _MONEY_HEADERS if h.upper() in up_heads]
    bom = [h for h in _BOM_HEADERS if h.upper() in up_heads]
    # TAG(기기 태그) 열이 있으면 단가가 붙어 있어도 BOM이다 — 견적서에는 태그 열이 없다
    if "TAG" in up_heads and len(bom) >= 2:
        return "BOM", f"내용 (표 머리글 {'·'.join(bom[:3])})"
    if len(money) >= 2:
        return "견적서", f"내용 (표 머리글 {'·'.join(money[:3])})"
    if len(bom) >= 2:
        return "BOM", f"내용 (표 머리글 {'·'.join(bom[:3])})"
    for name, en, hs, need in _HEADER_SETS:
        got = [h for h in hs if h.upper() in up_heads]
        if len(got) >= need:
            # 머리글이 영어로만 적혔으면 영어 표기 (회사가 쓰는 말 그대로)
            label = en if all(g.isascii() for g in got) else name
            return label, f"내용 (표 머리글 {'·'.join(got[:3])})"
    return None


_SPLIT = re.compile(r"[^0-9A-Z가-힣&]+")


_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def _camel(text: str) -> str:
    """붙여 쓴 영문(DeliveryNote, IoList)을 낱말로 — 한 토큰이면 어떤 키워드에도
    안 걸린다 (2026-09-02 재검토)."""
    return _CAMEL.sub(" ", text)


def _tokens(text: str) -> set[str]:
    return {t for t in _SPLIT.split(_camel(text).upper()) if t}


def _matches(hay_upper: str, tokens: set[str], keyword: str) -> bool:
    """키워드 하나가 걸리는지. 한글은 붙여쓰기가 흔해 부분 일치, 영문은 낱말
    일치(짧은 영문이 다른 단어 속에서 잘못 걸리는 것을 막는다)."""
    k = keyword.strip().upper()
    if not k:
        return False
    if not k.isascii():
        # '발주'가 '발주처(고객)'·'구매'가 '구매처'에 걸려 고객 자료 폴더의 사진이 전부 발주서가
        # 됐다 (파일럿 모의 4차). 상대방을 뜻하는 꼬리(처·자·원)가 붙은 자리는 세지 않는다
        return re.search(re.escape(k) + r"(?![처자원])", hay_upper) is not None
    if "/" in k:                       # 'I/O' — 구분자가 낱말의 일부
        return k in hay_upper
    if " " in k:                       # 'IO LIST' — 파일명은 IO_LIST·IO-LIST로 적힌다
        norm = " ".join(t for t in _SPLIT.split(hay_upper) if t)
        return re.search(r"(?:^| )" + re.escape(k) + r"(?: |$)", norm) is not None
    if k in tokens:
        return True
    if len(k) >= 5:
        # 부분일치는 '키워드+한 글자'(DRAWINGS, PARTLISTS)까지만 — CONTRACTOR가
        # CONTRACT에 걸리던 것 (2026-09-02 재검토)
        return any(t.startswith(k) and len(t) - len(k) <= 1 for t in tokens)
    return False


def user_rules(cfg: dict | None) -> list[dict]:
    """설정의 사용자 규칙 — [{name, keywords:[...], exts:[...]}] 형태로 정규화."""
    out = []
    for r in (cfg or {}).get("doc_types") or []:
        if isinstance(r, dict):
            name = str(r.get("name", "")).strip()
            kws = r.get("keywords") or []
            exts = r.get("exts") or r.get("ext") or []
        else:                                  # "이름: 키워드,키워드" 형태 허용
            name, _, rest = str(r).partition(":")
            name, kws, exts = name.strip(), rest.split(","), []
        kws = [str(k).strip() for k in kws if str(k).strip()]
        exts = [str(e).strip().lower() for e in exts if str(e).strip()]
        exts = [e if e.startswith(".") else "." + e for e in exts]
        if name and (kws or exts):
            out.append({"name": name, "keywords": kws, "exts": exts})
    return out


def folder_rules(cfg: dict | None) -> list[tuple[str, str]]:
    """폴더 지정 규칙 — [(폴더경로, 유형)], 긴 경로부터."""
    out = []
    for r in (cfg or {}).get("doc_folders") or []:
        if isinstance(r, dict):
            path, name = str(r.get("path", "")), str(r.get("name", ""))
        else:
            path, _, name = str(r).partition("=")
        # 백슬래시 입력도 수용. (str.replace는 읽기전용 가드가 파일 이동 API로
        # 오인하므로 split/join을 쓴다 — 코드베이스 관례)
        path = "/".join(path.strip().split("\\")).strip("/")
        name = name.strip()
        if path and name:
            out.append((path, name))
    return sorted(out, key=lambda x: -len(x[0]))


def folder_hit(path: str, cfg: dict | None) -> tuple[str, str] | None:
    """이 파일이 속한 지정 폴더가 있으면 (유형, 근거)."""
    rel = str(PurePosixPath(path).parent).strip("/")
    for folder, name in folder_rules(cfg):
        if rel == folder or rel.startswith(folder + "/"):
            return name, f"폴더 지정 ({folder})"
    return None


_WEAK_NAME_WORDS = ("자재", "부품", "PARTS")


# 경로 → (유형, 근거) 캐시. 같은 경로를 화면 한 장에서 수십 번 분류한다 —
# 이력 10만 건의 /cat 화면이 14.0초, 엑셀 내보내기가 26.9초였고, 그 중 46초가
# _matches 1,493만 번이었다 (2026-09-09 웹 검토 차단 2). 규칙·내용 단서가 바뀌면 버린다.
_CLS_CACHE: dict[str, tuple[str, str]] = {}
_CLS_TOKEN: tuple | None = None
_CLS_CACHE_MAX = 100_000


def _cls_token(cfg: dict | None) -> tuple:
    """분류 결과를 좌우하는 것들의 지문 — 규칙 수는 한 줌이라 매번 만들어도 싸다."""
    return (tuple((r["name"], tuple(r["keywords"]), tuple(r["exts"]))
                  for r in user_rules(cfg)),
            tuple(folder_rules(cfg)), _Hints.version)


def classify(path: str, cfg: dict | None = None) -> tuple[str, str]:
    global _CLS_TOKEN
    tok = _cls_token(cfg)
    if tok != _CLS_TOKEN:
        _CLS_CACHE.clear()
        _CLS_TOKEN = tok
    got = _CLS_CACHE.get(path)
    if got is not None:
        return got
    got = _classify(path, cfg)
    if len(_CLS_CACHE) >= _CLS_CACHE_MAX:
        _CLS_CACHE.clear()                  # 한없이 키우지 않는다 — 비우고 다시 채운다
    _CLS_CACHE[path] = got
    return got


def _classify(path: str, cfg: dict | None = None) -> tuple[str, str]:
    """(유형, 근거)를 돌려준다. 근거는 왜 그렇게 분류됐는지 화면에 보여주려는 것.

    파일명이 폴더명보다 우선한다 — 구매/BOM_전장.xlsx가 폴더('구매') 때문에
    발주서로 잡히던 문제 (2026-08-31). 폴더는 파일명에 단서가 없을 때만 본다."""
    pp = PurePosixPath(path)
    ext = pp.suffix.lower()
    fh = folder_hit(path, cfg)          # ① 폴더 지정이 가장 강하다
    if fh:
        return fh
    rules = user_rules(cfg)

    def hit(text: str, where: str, builtin: bool = True) -> tuple[str, str] | None:
        up, toks = _camel(text).upper(), _tokens(text)
        for r in rules:                       # ① 내 규칙이 언제나 먼저
            if r["exts"] and ext in r["exts"] and not r["keywords"]:
                return r["name"], f"내 규칙 (확장자 {ext})"
            for k in r["keywords"]:
                if _matches(up, toks, k) and (not r["exts"] or ext in r["exts"]):
                    return r["name"], f"내 규칙 ('{k}' — {where})"
        if not builtin:
            return None
        best = None                            # (끝 위치, 순번, 결과)
        for order, (name, kws, exts, en) in enumerate(BUILTIN):   # ② 내장 기본
            if exts and ext not in exts:
                continue
            for k in kws:
                if _matches(up, toks, k):
                    # 영어로 적힌 이름이면 영어 표기를 쓴다 (회사가 쓰는 말 그대로)
                    label = en if (k.isascii() and en) else name
                    pos = up.rfind(k.upper())
                    end = pos + len(k) if pos >= 0 else 0
                    # 여러 유형이 걸리면 뒤에 오는 낱말이 머리 명사다: '납품도면'→도면,
                    # '검사성적서'→성적서 (2026-09-02 재검토). 같은 위치면 목록 순서
                    # 순위: 더 구체적인(긴) 키워드 > 뒤에 오는 낱말 > 목록 순서.
                    # 'Cable_Schedule'은 CABLE SCHEDULE(배선표)이지 SCHEDULE(일정표)이 아니다
                    cand = (len(k), end, -order, (label, f"기본 규칙 ('{k}' — {where})"))
                    if best is None or cand[:3] > best[:3]:
                        best = cand
                    break
        return best[3] if best else None

    # 순서 (2026-09-02): 내 규칙(파일명·폴더명) > 내장 파일명 키워드 > 내용 단서 >
    # 내장 폴더명 키워드 > 확장자. 폴더명은 짐작일 뿐이라 내용보다 약하다 —
    # '구매' 폴더 안의 견적서가 전부 발주서로 잡히던 것. 파일명에 적힌 이름표는
    # 사람이 붙인 것이라 내용보다 강하다.
    name_txt, dir_txt = pp.name, pp.parent.name
    got = hit(name_txt, "파일명", builtin=False) if name_txt else None
    got = got or (hit(dir_txt, "폴더명", builtin=False) if dir_txt else None)
    got = got or (hit(name_txt, "파일명") if name_txt else None)
    if got:
        # '자재'·'부품' 같은 짧은 낱말은 견적서 파일명(전기자재_한빛)에도 흔하다 —
        # 내용에서 읽은 단서(돈 열 머리글 등)가 있으면 그쪽이 맞다 (2026-09-03 검토)
        h = HINTS.get(path)
        if h and h[0] == "견적서" and "머리글" not in h[1] \
                and any(f"('{k}'" in got[1] for k in _WEAK_NAME_WORDS):
            # 제목 '견적서'가 본문에 있을 때만 — 단가·금액 열만으로 원가 BOM을 뒤집지 않는다
            # (2026-09-03 재검토)
            return h[0], h[1] + " — 파일명의 낱말보다 내용 우선"
        return got
    h = HINTS.get(path)                       # ③ 내용 단서 — 파일명에 이름이 없을 때
    if h:
        return h[0], h[1]
    got = hit(dir_txt, "폴더명") if dir_txt else None
    if got:
        return got
    for name, exts in EXT_FALLBACK:           # ④ 확장자 기본
        if ext in exts:
            return name, f"확장자 {ext}"
    return UNKNOWN, "규칙 없음"


def looks_like_doctype_folder(name: str, cfg: dict | None = None) -> bool:
    """폴더 이름이 문서 종류(도면·구매·인터락·사양서…)를 뜻하는가.

    감시 폴더 바로 아래가 이런 이름들이면 그 감시 폴더는 프로젝트 하나다
    (2026-09-02). 사용자 규칙·내장 키워드를 그대로 쓴다 — 확장자가 아무것도
    아닌 가짜 파일을 붙여 폴더명 규칙만 타게 한다."""
    if not name:
        return False
    core = re.sub(r"^[\s\d_.\-]+", "", name).strip().upper()
    if core in _FOLDER_WORDS:
        return True
    label, why = classify(f"{name}/x.zzz", cfg)
    return "폴더명" in why


# 문서 종류를 뜻하는 폴더 이름 — 파일명 규칙에서 뺀 짧은 낱말(납품·계약·검사·일정)도
# 폴더 이름으로는 종류다 (2026-09-02 재검토: '하나/여럿' 추천이 흔들리던 것)
_FOLDER_WORDS = {"납품", "계약", "검사", "일정", "회의", "회의록", "견적", "발주", "구매",
                 "도면", "DRAWINGS", "DRAWING", "BOM", "사양", "사양서", "자재", "인터락",
                 "점검", "배선", "시퀀스", "성적서", "매뉴얼", "설명서", "일정표", "공정표",
                 "문서", "자료", "사진", "PHOTO", "SPEC", "DOC", "DOCS"}


def kind_of(path: str, cfg: dict | None = None) -> str:
    return classify(path, cfg)[0]


def summarize(paths, cfg: dict | None = None) -> tuple[dict, list]:
    """감시 중 파일들의 유형별 개수와, 규칙에 안 걸린 파일 목록을 돌려준다.

    "우리가 모르는 양식"을 사용자가 발견해 규칙으로 만들 수 있게 하는 게 목적."""
    counts: dict[str, int] = {}
    unknown = []
    for p in paths:
        name, _why = classify(p, cfg)
        counts[name] = counts.get(name, 0) + 1
        if name == UNKNOWN:
            unknown.append(p)
    return counts, unknown
