# -*- coding: utf-8 -*-
"""포터블판을 '설치된 프로그램'으로 만들기 (2026-08-31).

배경: 설치판(Drev-Setup.exe)은 서명이 없어 스마트 앱 컨트롤이 켜진 PC에서
실행이 막힐 수 있다(회사 PC는 대개 정상, 개인 PC에서 차단 — 실측). 그런데
설치판의 실질적 가치는 마법사가 아니라 ①고정 위치 ②시작 메뉴·바탕화면 아이콘
③제거 목록 등록 세 가지다. 이 셋은 **서명된 파이썬으로 도는 포터블**에서도
그대로 만들 수 있다 — 그래서 어느 PC에서든 같은 경험을 준다.

원칙:
- 감시 대상 파일에는 접근하지 않는다. 이 모듈은 **프로그램 자신의 폴더**와
  바로가기·레지스트리(HKCU)만 다룬다.
- 제거는 바로가기·등록만 지운다. **이력(state.db)은 지우지 않는다** — 폴더를
  통째로 지울지는 사람이 판단한다.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

APP_NAME = "Drev"
REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\Drev"
SKIP = {".update"}                      # 옮기지 않는 작업 폴더
OLD_MARK = ".old-drev"


def default_target() -> Path:
    """설치 위치 — 관리자 권한이 필요 없는 사용자 폴더."""
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / APP_NAME


def is_installed_at(root: Path, target: Path | None = None) -> bool:
    """지금 실행 중인 폴더가 설치 위치인가."""
    target = target or default_target()
    try:
        return root.resolve() == target.resolve()
    except OSError:
        return False


PROGRAM_DIRS = ("app", "libs", "python")
KEEP_IF_EXISTS = ("config.yaml", "state.db", "aliases.yaml")


def _copy_db(src_db: Path, dst_db: Path) -> bool:
    """쓰는 중인 이력 DB를 안전하게 복사 — sqlite 백업 API (WAL도 정합)."""
    import sqlite3
    try:
        with sqlite3.connect(f"file:{src_db}?mode=ro", uri=True) as s, \
                sqlite3.connect(dst_db) as d:
            s.backup(d)
        return True
    except Exception:
        return False


def copy_program(src: Path, target: Path) -> None:
    """프로그램과 데이터를 설치 위치로 복사한다.

    프로그램 파일은 반드시 옮기고(실패하면 예외), 데이터는 최선을 다해 옮긴다 —
    설치를 누르는 순간에도 앱이 돌고 있어 로그처럼 열려 있는 파일이 있다
    (2026-08-31 실측: watcher.log 복사에서 PermissionError). 그런 파일 하나
    때문에 설치가 통째로 실패하면 안 된다. 기존 설정·이력은 덮지 않는다."""
    target.mkdir(parents=True, exist_ok=True)
    for item in sorted(src.iterdir()):
        name = item.name
        if name in SKIP or name.endswith(OLD_MARK) or name.endswith(".log"):
            continue
        dst = target / name
        program = name in PROGRAM_DIRS or (
            item.is_file() and (name.lower().endswith((".exe", ".dll", "._pth"))
                                or name.startswith("python3")))
        if item.is_dir():
            if name in PROGRAM_DIRS:
                shutil.rmtree(dst, ignore_errors=True)   # 프로그램은 새 것으로
                shutil.copytree(item, dst)
            elif not dst.exists():                        # 데이터 폴더는 보존
                try:
                    shutil.copytree(item, dst)
                except OSError:
                    pass
            continue
        if dst.exists() and name in KEEP_IF_EXISTS:
            continue                                      # 쓰던 설정·이력 보존
        if name == "state.db":
            if not _copy_db(item, dst):                   # 잠겨 있으면 통짜 복사
                try:
                    shutil.copy2(item, dst)
                except OSError:
                    pass
            continue
        try:
            shutil.copy2(item, dst)
        except OSError:
            if program:
                raise                                     # 프로그램은 필수



def make_shortcut(link: Path, target_exe: Path, workdir: Path) -> bool:
    """바로가기(.lnk) 하나 만들기 — 서명된 powershell의 COM을 빌린다."""
    ico = Path(target_exe).parent / "app" / "watcher" / "assets" / "drev.ico"
    icon_line = f"$s.IconLocation='{ico},0';" if ico.is_file() else ""
    ps = (f"$s=(New-Object -COM WScript.Shell).CreateShortcut('{link}');"
          f"$s.TargetPath='{target_exe}';$s.WorkingDirectory='{workdir}';{icon_line}"
          f"$s.Description='Drev - 산출물 변경 감시';$s.Save()")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive",
                            "-Command", ps], capture_output=True, text=True,
                           timeout=60, stdin=subprocess.DEVNULL,
                           creationflags=0x08000000)
        return r.returncode == 0 and link.exists()
    except Exception:
        return False


def shortcut_paths() -> tuple[Path, Path]:
    """(바탕화면, 시작 메뉴) 바로가기 경로."""
    home = Path.home()
    desktop = Path(os.environ.get("USERPROFILE", home)) / "Desktop"
    if not desktop.is_dir():
        desktop = home / "Desktop"
    start = (Path(os.environ.get("APPDATA", home))
             / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    return desktop / f"{APP_NAME}.lnk", start / f"{APP_NAME}.lnk"


def register_uninstall(target: Path, version: str) -> bool:
    """제어판 '프로그램 추가/제거' 목록에 등록 (HKCU — 관리자 권한 불필요)."""
    try:
        import winreg
    except ImportError:
        return False
    exe = target / "Drev.exe"
    py = target / "python" / "python.exe"
    entry = target / "app" / "entry.py"
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_KEY) as k:
            for name, val in (
                ("DisplayName", "Drev - 산출물 변경 감시"),
                ("DisplayVersion", version),
                ("Publisher", "Drev"),
                ("InstallLocation", str(target)),
                ("DisplayIcon", str(exe)),
                ("UninstallString", f'"{py}" "{entry}" uninstall'),
                ("NoModify", 1), ("NoRepair", 1),
            ):
                if isinstance(val, int):
                    winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, val)
                else:
                    winreg.SetValueEx(k, name, 0, winreg.REG_SZ, val)
        return True
    except OSError:
        return False


def unregister() -> bool:
    try:
        import winreg
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, REG_KEY)
        return True
    except (ImportError, OSError):
        return False


def install(src: Path, version: str, target: Path | None = None,
            copier=copy_program, shortcut=make_shortcut,
            register=register_uninstall) -> dict:
    """설치 실행 — 복사 + 바로가기 + 제거 등록. 결과를 dict로 알려준다.

    이미 설치 위치에서 돌고 있으면 복사는 건너뛰고 바로가기만 다시 만든다."""
    target = target or default_target()
    moved = not is_installed_at(src, target)
    if moved:
        copier(src, target)
    exe = target / "Drev.exe"
    desktop, start = shortcut_paths()
    start.parent.mkdir(parents=True, exist_ok=True)
    ok_d = shortcut(desktop, exe, target)
    ok_s = shortcut(start, exe, target)
    ok_r = register(target, version)
    return {"target": target, "moved": moved, "desktop": ok_d,
            "startmenu": ok_s, "registered": ok_r}


def remove_shortcuts() -> int:
    n = 0
    for p in shortcut_paths():
        try:
            if p.exists():
                p.unlink()
                n += 1
        except OSError:
            pass
    return n


def uninstall() -> dict:
    """바로가기·제거 등록만 정리한다. **이력·설정 파일은 건드리지 않는다** —
    폴더째 지울지는 사람이 판단할 몫 (원칙 5: 최종 판단은 사람)."""
    return {"shortcuts": remove_shortcuts(), "registry": unregister(),
            "folder": str(default_target())}
