# -*- coding: utf-8 -*-
"""watcher.log 관리 — 회전과 끝부분만 읽기 (2026-09-09 자동 실행 검토 중간 2).

왜 있나: 로그에 상한이 없었고, 화면·업데이트 진단은 시작마다 그 파일을 **통째로**
읽어 마지막 400줄만 썼다. 52.7MB(70만 줄)에서 0.70초·최대 메모리 232MB였다 —
몇 년 돌린 설치본은 "켜면 한참 멈춘다"가 되고 끝내 MemoryError로 못 켜진다.
게다가 감시 경로와 구/신 값이 평문으로 무기한 쌓인다(원칙 1 관점에서도 상한이 필요).
"""

from __future__ import annotations

import os
from pathlib import Path

MAX_BYTES = 5 * 1024 * 1024      # 이보다 커지면 한 번 밀어낸다
TAIL_BYTES = 256 * 1024          # 진단이 읽는 끝부분 크기 (400줄에 넉넉하다)


def rotate(path: Path, max_bytes: int = MAX_BYTES) -> bool:
    """로그가 너무 크면 `.old`로 밀어낸다 (이전 .old는 버린다). 밀어냈으면 True.

    파일 하나만 남긴다 — 진단에 필요한 것은 최근 기록이고, 오래된 줄에는 감시 경로가
    들어 있어 오히려 줄이는 편이 낫다."""
    try:
        if not path.exists() or path.stat().st_size <= max_bytes:
            return False
        # 원본을 **먼저** 비울 수 있는지 본다. cmd.exe가 `>> run_daily.log`로 잡고 있는
        # 파일은 비울 수 없는데, 전에는 .old를 다 쓴 **뒤에** 실패해서 회전은 안 되고
        # 매 검사마다 로그 전체를 복사만 했다 (2026-09-09 배포 후 검토 중간 3)
        with path.open("r+b"):
            pass
        old = path.with_suffix(path.suffix + ".old")
        # 읽기 전용 보호 장치가 os.replace/rename을 막으므로(원칙 2) 내용을 옮겨 적고
        # 원본을 0바이트로 비운다 — 다른 프로세스가 열어 둔 핸들도 그대로 쓸 수 있다.
        # 통째로 읽으면 302MB 로그에서 최대 메모리 1.5GB를 썼다 — 조각으로 옮긴다
        with path.open("rb") as src, old.open("wb") as dst:
            while True:
                chunk = src.read(1 << 20)
                if not chunk:
                    break
                dst.write(chunk)
        with path.open("w", encoding="utf-8"):
            pass
        return True
    except OSError:
        return False


def tail_lines(path: Path, max_lines: int = 400,
               tail_bytes: int = TAIL_BYTES) -> list[str]:
    """파일 끝에서 max_lines 줄만 읽는다 — 크기와 무관하게 일정한 비용."""
    try:
        size = path.stat().st_size
        with path.open("rb") as f:
            if size > tail_bytes:
                f.seek(size - tail_bytes, os.SEEK_SET)
                f.readline()              # 잘린 첫 줄은 버린다
            raw = f.read()
    except OSError:
        return []
    return raw.decode("utf-8", errors="replace").splitlines()[-max_lines:]
