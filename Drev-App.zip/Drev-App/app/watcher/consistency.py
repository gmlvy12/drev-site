# -*- coding: utf-8 -*-
"""일관성 검사. 의미(옳다/그르다)는 판단하지 않는다 — 서로 안 맞는 것만 찾는다 (PRINCIPLE 6).

검사 4종:
  CONTENT_CHANGED_REV_SAME       내용이 바뀌었는데 표제란 Rev 그대로 (실수1)
  REV_CHANGED_CONTENT_SAME       Rev만 올라가고 내용 동일 (실수2)
  TAG_MISMATCH_ACROSS_DRAWINGS   같은 프로젝트 내 도면 간 같은 태그의 사양 불일치
  BOM_MISMATCH                   도면 태그 사양 ↔ BOM SPEC 불일치
모든 Issue는 근거(evidence: 구값/신값/위치) 없이는 만들 수 없다 (PRINCIPLE 4).
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath
from dataclasses import dataclass, field
from typing import NamedTuple

from watcher.diff import ChangeItem, content_items
from watcher.extract import base as _base
from watcher.extract.base import find_tags, Document

CODE_LABEL = {
    "CONTENT_CHANGED_REV_SAME": "내용 변경, Rev 미갱신",
    "REV_CHANGED_CONTENT_SAME": "Rev만 갱신, 내용 동일",
    "TAG_MISMATCH_ACROSS_DRAWINGS": "도면 간 태그 사양 불일치",
    "BOM_MISMATCH": "도면-BOM 불일치",
    "TAG_PATTERN_UNRECOGNIZED": "태그 표기 인식 불가",
}


@dataclass(frozen=True)
class Issue:
    code: str
    path: str          # 대상 파일 (프로젝트 수준이면 대표 경로)
    message: str
    evidence: tuple = field(default_factory=tuple)  # 근거 문자열들

    def __post_init__(self):
        # "근거 없이는 만들 수 없다"를 타입으로 강제 (원칙 4, 검토19 원칙 ⑩)
        if not self.evidence:
            raise ValueError(f"근거 없는 검토 항목은 만들 수 없습니다: {self.code} {self.path}")


def _fmt_item(i: ChangeItem) -> str:
    return f"{i.key}: {i.old or '—'} → {i.new or '—'} ({i.where})"


def check_revision(path: str, old: Document, new: Document,
                   items: list[ChangeItem], visual_checked: bool = True) -> list[Issue]:
    """한 파일의 구/신 쌍에 대한 Rev 일관성.

    visual_checked=False면 그림 비교를 하지 않은 짝이다 — 글자 변경이 없다고 해서
    '내용 동일'이라 단정하지 않는다 (2026-09-02 재검토: 원칙 4·5)."""
    issues = []
    rev_change = next((i for i in items if i.kind == "FIELD_CHANGED" and i.key == "REV"), None)
    content = content_items(items)
    # 표제란이 OCR 유래고 혼동 문자만 다르면(B↔8) Rev가 바뀐 게 아니다 — `_diff_fields`와 같은 규칙 (리뷰12 중간-C)
    from watcher.diff import same_ocr_value
    if rev_change is not None and same_ocr_value(old.fields.get("REV"), new.fields.get("REV")):
        rev_change = None

    if content and rev_change is None and new.revision is not None:
        # 메시지에 건수를 넣지 않는다 — 발행 전 작업본을 매일 저장하는 동안
        # 건수만 바뀐 같은 경고가 날마다 재알림되던 문제 (2026-08-26 설계 검토:
        # 같은 내용은 30일 중복 억제에 걸려 브리핑에 1회만 실린다)
        ev = [f"표제란 REV: {new.revision} (변경 전후 동일)",
              f"이번 변경 {len(content)}건 중 예시:"]
        ev += [_fmt_item(i) for i in content[:5]]
        issues.append(Issue(
            "CONTENT_CHANGED_REV_SAME", path,
            f"내용이 바뀌었는데 표제란 Rev가 {new.revision} 그대로입니다. "
            f"(발행 전 작업본이면 무시하세요 — 발행 시 Rev를 올리면 해소됩니다)",
            tuple(ev)))

    # 페이지 전체가 어긋난 재스캔은 그 쪽의 그림 비교가 무의미해 접었다 — 그걸 '내용 동일'의
    # 근거로 쓰면 안 된다. 1pt 밀린 재스캔에 표를 하나 더해도 "Rev만 갱신, 내용 동일"이 났다
    # (2026-09-09 비교 검토). 접힌 쪽이 있으면 이 판정은 하지 않는다.
    folded = any(i.kind == "PAGE_VISUAL_CHANGED" and "전체가 살짝 어긋남" in str(i.where or "")
                 for i in items)
    if rev_change is not None and not content and visual_checked and not folded:
        ev = [f"표제란 REV: {rev_change.old} → {rev_change.new} ({rev_change.where})",
              "글자·표 변경: 0건 — 형상(선·도형)만 바뀐 정상 개정일 수 있습니다"
              " (그림 변경은 텍스트 비교에 잡히지 않습니다)"]
        claimed = [i for i in items if i.kind == "REVROW_ADDED"]
        ev += [f"리비전 블록 기재: {_fmt_item(i)}" for i in claimed[:2]]
        issues.append(Issue(
            "REV_CHANGED_CONTENT_SAME", path,
            f"Rev가 {rev_change.old}→{rev_change.new}로 올라갔는데 글자 변경이 없습니다.",
            tuple(ev)))
    return issues


class _Occ(NamedTuple):
    """한 도면에서 태그가 등장한 지점 (사양 토큰 + 근거)."""
    spec: str
    text: str
    path: str
    where: str
    dwg_no: str


# 구분자만 있는 토큰 — 사양값이 아니다 ('M-302 : 15kW'의 ':')
_SEP_TOKENS = {":", "-", "=", "·", "|", "/", "→", ","}
# 모델명·태그 꼴 토큰의 글자 접두 (GMC-22 → GMC, 3P-100 → P)
_MODEL_RE = re.compile(r"^\d?([A-Za-z]{1,6})-\d+[A-Za-z0-9]*$")

# 표기 차이를 흡수하는 정규화: 소문자화 + 공백/구분자 제거 + 단위 동의어
# ('5.5kW' vs '5.5 KW' vs '5.5㎾'가 전부 경보가 되던 문제 — 2026-08-26 검토)
_UNIT_SYNONYM = (("㎾", "kw"), ("㎟", "sq"), ("ø", "d"), ("Φ", "d"), ("φ", "d"))


_TRAIL_ZERO = re.compile(r"(\d+)\.(\d*?)0+(?=[^\d]|$)")   # 5.50 → 5.5, 10.0 → 10.
_BARE_DOT = re.compile(r"(\d+)\.(?=[^\d]|$)")             # 10. → 10


def _norm_numbers(s: str) -> str:
    """수치 표기 차이를 흡수 — '5.50kW'와 '5.5kW'는 같은 값이다. 소수점 뒤 0만 지우고
    ('5.50'→'5.5', '10.0'→'10'), 정수부·단위는 건드리지 않는다 (검토21 감지 차단 2:
    같은 값에 '도면 간 사양 불일치'·'도면-BOM 불일치' 경보가 났다)."""
    out = _TRAIL_ZERO.sub(lambda m: m.group(1) + ("." + m.group(2) if m.group(2) else "."), s)
    return _BARE_DOT.sub(r"\1", out)


def _norm(s: str) -> str:
    out = s.lower()
    for a, b in _UNIT_SYNONYM:
        out = b.join(out.split(a))
    out = _norm_numbers(out)
    return "".join(ch for ch in out if ch not in " \t:·|,")


_NUM = re.compile(r"^[\d.,]+$")
_UNIT = re.compile(r"^[A-Za-z%Ω℃°]{1,6}$")


def _spec_token(line_text: str, tag: str) -> str:
    """태그 다음의 첫 '값' 토큰 = 사양값 (예: 'M-302 : 15kW DOL' → '15kW').

    줄 전체를 비교하면 문서 유형별 표기 차이('11kW' vs '11kW INVERTER DRIVEN')가
    전부 오탐이 된다. 값 토큰 하나만 비교하되, 구분자 토큰(':' 등)은 건너뛴다.
    태그는 낱말 경계로 찾는다(M-10이 M-101 안에서 걸리지 않게), 숫자 뒤에 단위가
    따로 오면('15 kW') 붙여서 한 값으로 본다 (2026-09-02 재검토)."""
    m = re.search(r"(?<![\w-])" + re.escape(tag) + r"(?![\w-])", line_text)
    if m is None:
        return ""
    toks = [t for t in line_text[m.end():].split() if t not in _SEP_TOKENS]
    if not toks:
        return ""
    # 가장 흔한 표기 'M-101 MOTOR 5.5kW'에서 첫 토큰은 종류(MOTOR)지 값이 아니다 — 그래서
    # 도면 간 사양 불일치를 통째로 못 봤고, 'M-101 5.5kW'와 비교하면 (MOTOR vs 5.5kW)
    # 헛경보를 냈다 (검토19 감지 ②). BOM 검사(_spec_like)처럼 숫자를 품은 첫 토큰을 값으로
    for i, t in enumerate(toks):
        if any(ch.isdigit() for ch in t):
            if _NUM.match(t) and i + 1 < len(toks) and _UNIT.match(toks[i + 1]):
                return t + toks[i + 1]
            return t
    return toks[0]


_VAL_UNIT = re.compile(r"^(\d+(?:[.,]\d+)?)\s*([A-Za-z%Ω℃°㎾㎟]{0,6})$")
_OLD_FOLDER = re.compile(r"(^|/)(old|구버전|구판|backup|백업|아카이브|archive|보관|지난)(/|$)", re.IGNORECASE)


def _num_set(line_text: str, tag: str) -> frozenset:
    """태그 뒤의 숫자 품은 값 토큰들(정규화) — 다른 태그 꼴 토큰(→ CP-01)은 뺀다."""
    return frozenset(v for vals in _num_units(line_text, tag).values() for v in vals)


def _num_units(line_text: str, tag: str) -> dict[str, frozenset]:
    """태그 뒤의 값을 **단위별로** 묶는다 {단위: {값}} — '100AT 3P'와 '125AT 3P'는 3P가 겹쳐도
    AT가 다르니 불일치다. 집합 교집합 하나로 보면 부속 숫자(3P·4P·380V) 하나 때문에
    5.5kW↔7.5kW를 못 봤다 (파일럿 모의 2차 N1). 단위 없는 숫자는 '' 단위."""
    m = re.search(r"(?<![\w-])" + re.escape(tag) + r"(?![\w-])", line_text)
    if m is None:
        return {}
    out: dict[str, set] = {}
    toks = [t for t in re.split(r"[\s/;]+", line_text[m.end():]) if t and t not in _SEP_TOKENS]
    i = 0
    while i < len(toks):
        t = toks[i]
        # '5.5 kW'처럼 숫자와 단위가 떨어진 표기는 붙인다 — 안 붙이면 '5.5KW'와 헛경보 (검토19c ⑥)
        if _NUM.match(t) and i + 1 < len(toks) and _UNIT.match(toks[i + 1]):
            t = t + toks[i + 1]
            i += 1
        i += 1
        if not any(ch.isdigit() for ch in t):
            continue
        if re.match(r"^[A-Za-z]{1,4}-\d+[A-Za-z0-9]*$", t):      # 상대 태그(CP-01)는 값이 아니다
            continue
        t = ".".join(t.split(",")) if re.match(r"^\d+,\d+", t) else t   # 5,5kW = 5.5kW (replace는 가드가 막는다)
        mm = _VAL_UNIT.match(t)
        unit = _norm(mm.group(2)) if mm else "?"                  # 'CV4SQ3C' 같은 덩어리는 '?'
        out.setdefault(unit, set()).add(_norm(t))
    return {u: frozenset(v) for u, v in out.items()}


def _units_conflict(a: dict, b: dict) -> bool:
    """같은 단위가 양쪽에 있는데 값 집합이 서로소인 단위가 하나라도 있으면 불일치."""
    for u, va in a.items():
        vb = b.get(u)
        if vb and not (va & vb):
            return True
    return False


def _line_has_spec(nspec: str, text: str) -> bool:
    """줄 안에 사양값이 **값 단위로** 있는가 — 부분문자열이면 5.5kW가 15.5kW에
    들어 있다고 보고 불일치를 놓친다 (2026-09-02 재검토)."""
    # 공백과 '/ , ;'로 쪼갠 조각들의 연속 구간(최대 4개)을 값 후보로 — '15 kW',
    # '5.5kW 4P'(여러 토큰 사양), '5.5kW/380V'(슬래시 묶음)까지 잡되, 5.5kW가
    # 15.5kW 안에서 걸리는 부분문자열 일치는 생기지 않는다
    parts = [p for p in re.split(r"[\s/,;]+", text) if p and p not in _SEP_TOKENS]
    for i in range(len(parts)):
        for j in range(i + 1, min(i + 5, len(parts) + 1)):
            if _norm("".join(parts[i:j])) == nspec:
                return True
    return False


# BOM 머리글은 회사마다 다르다 — 영문 SPEC/TAG만 보면 한글 BOM('규격')은 검사가
# 통째로 침묵한다 (2026-09-03 합성 서버 검토: 도면-BOM 불일치 0/5)
_TAG_COLS = ("TAG", "태그", "TAG NO", "TAG_NO", "TAGNO", "기기번호", "기기 번호", "기기TAG")
_SPEC_COLS = ("SPEC", "규격", "사양", "SPECIFICATION", "SPEC.", "MODEL", "모델")


def _col(row, names) -> str:
    """행에서 이름 후보 중 첫 값 — 머리글 표기(대소문자·공백)가 회사마다 다르다."""
    up = {str(k).strip().upper(): v for k, v in row.values.items()}
    for n in names:
        v = up.get(n.upper())
        if v not in (None, ""):
            return str(v)
    return ""


def _spec_pieces(spec: str) -> set[str]:
    """BOM 사양('5.5kW 4P 380V', '15 kW')을 값 조각 집합으로 — 도면은 첫 값만 적는다."""
    parts = [x for x in re.split(r"[\s/,;]+", spec) if x and x not in _SEP_TOKENS]
    out: set[str] = set()
    for i in range(len(parts)):
        for j in range(i + 1, min(i + 5, len(parts) + 1)):
            out.add(_norm("".join(parts[i:j])))
    return out


def _tokens_after(tag: str, text: str) -> list[str]:
    m = re.search(r"(?<![\w-])" + re.escape(tag) + r"(?![\w-])", text)
    if m is None:
        return []
    return [x for x in re.split(r"[\s/,;]+", text[m.end():]) if x and x not in _SEP_TOKENS]


def _spec_like(tok: str, known_tags=frozenset()) -> bool:
    """사양값처럼 생긴 토큰 — 숫자를 품고, 이 프로젝트의 기기 태그는 아닌 것 (5.5kW,
    MY4N, 125AT, GMC-22). 'MAIN MOTOR', 'U V W' 같은 설명 낱말과 "M-101 → CP-01"의
    상대 태그는 비교 대상이 아니다. 모델명(GMC-22)은 태그처럼 생겼지만 도면·BOM 어디에도
    태그로 등장하지 않으므로 값으로 본다 (2026-09-03 재검토)."""
    return any(ch.isdigit() for ch in tok) and tok not in known_tags


def _rev_stamp(d: Document) -> str:
    """근거 줄에 붙일 ' [Rev B, 2026-09-01]' — 표제란에 있는 것만."""
    rev = d.revision
    date = d.fields["DATE"].value if "DATE" in d.fields else ""
    parts = [f"Rev {rev}" if rev else "", date]
    inner = ", ".join(x for x in parts if x)
    return f" [{inner}]" if inner else ""


def _canon_project(name: str) -> str:
    """교차 검사의 묶음 키 — 표제란 원문이 아니라 프로젝트 번호로. 'P24-031'과
    'P24-031 (2차)'가 다른 묶음이 되어 검사가 통째로 빠지던 것 (2026-09-02 재검토)."""
    from watcher.project import PLACEHOLDER_PROJECTS, PROJECT_NO_RE
    name = (name or "").strip()
    if name.upper() in PLACEHOLDER_PROJECTS:
        return ""
    m = PROJECT_NO_RE.search(name)
    if m:
        return m.group()
    # 문자 접두 없는 번호("26-033", "…(26-033)")도 같은 묶음 (2026-09-03 검토)
    m = re.search(r"(?<![\w-])(\d{2}-\d{3})(?![\w-])", name)
    return m.group(1) if m else name


def check_project_consistency(docs: list[tuple[str, Document]],
                              project_of=None) -> list[Issue]:
    """프로젝트 단위 교차 검사: 도면 간 태그 불일치 + 도면-BOM 불일치.

    project_of(path, doc) → 프로젝트: 검사가 쓰는 귀속기(표제란 > 파일명 > 폴더).
    없으면 표제란만 — PROJECT 열이 없는 BOM은 묶음에 못 들어가 검사가 빠졌다
    (2026-09-03 검토)."""
    issues = []
    by_project: dict[str, list[tuple[str, Document]]] = {}
    for path, doc in docs:
        raw = project_of(path, doc) if project_of else doc.project
        proj = _canon_project(raw) if raw else None
        if proj:
            by_project.setdefault(proj, []).append((path, doc))

    for proj, members in sorted(by_project.items()):
        drawings = [(p, d) for p, d in members if d.doc_type in ("dxf", "pdf")]
        boms = [(p, d) for p, d in members if d.doc_type == "xlsx" and d.rows]

        # 도면별 태그→줄 사전은 1회만 계산해 재사용 — BOM 행마다 재계산하면
        # (BOM 1,000행 × 도면 30장 = 3만 번 전체 스캔) 프로젝트당 수 초가 걸린다
        # (2026-08-25 확장성 검토: 7.9초 → 캐시 후 밀리초)
        # 태그의 전 출현 줄 — 첫 줄만 보면 심볼 옆/결선표 두 곳에 나오는
        # 태그에서 엉뚱한 줄과 비교하게 된다 (2026-08-26)
        tag_map = {path: d.tag_occurrences() for path, d in drawings}
        # 근거에 도면의 Rev·날짜를 싣는다 — 어느 쪽이 더 최근 판인지 도면을 못 읽는
        # 사람도 알 수 있게 (2026-09-02 처음 보는 사람 검토: 구매 담당)
        stamp = {path: _rev_stamp(d) for path, d in drawings}

        # 도면 간: 같은 태그의 사양값 토큰이 다르게 등장 (도면 번호가 다른 것끼리만).
        # 전 출현을 모은 뒤 비교한다 — 첫 출현과만 비교하면 사양 없는 줄(태그가 줄 끝)이
        # 먼저 나올 때 이후 도면들 간의 실제 불일치가 가려진다.
        occurrences: dict[str, list[_Occ]] = {}
        for path, d in drawings:
            dwg_no = d.fields["DWG_NO"].value if "DWG_NO" in d.fields else path
            for tag, lines in tag_map[path].items():
                for line in lines:
                    spec = _spec_token(line.text, tag)
                    if spec:  # 사양 없는 출현은 비교 대상이 아니고, 다른 출현을 가리지도 않는다
                        occurrences.setdefault(tag, []).append(
                            _Occ(spec, line.text, path, line.where, dwg_no))
        for tag, occs in sorted(occurrences.items()):
            # 숫자를 품은 값 토큰 **집합**끼리 견준다 — 첫 토큰만 보면 'M-101 5.5kW 4P' vs
            # 'M-101 4P 5.5kW'(순서), 'CV 4SQ 3C' vs 'CV 3C 4SQ'가 헛경보였다. 한쪽에 숫자
            # 토큰이 없으면(P&ID의 'CONVEYOR MOTOR') 비교하지 않는다 (검토19 2차 감지 N5)
            base = next((o for o in occs if _num_units(o.text, tag)), None)
            if base is None:
                continue
            bunits = _num_units(base.text, tag)
            conflicts = []
            seen_no: set = set()
            for o in occs:
                if o.dwg_no == base.dwg_no or o.dwg_no in seen_no:
                    continue
                ounits = _num_units(o.text, tag)
                if ounits and _units_conflict(bunits, ounits):
                    conflicts.append(o)
                    seen_no.add(o.dwg_no)
            if conflicts:
                # 충돌 도면을 **전부** 근거에 싣는다 — 하나만 보고하면 그걸 고친 뒤 다음 것이
                # 새 경고로 떠 두더지 잡기가 됐다 (검토19 2차 감지 N6)
                first = conflicts[0]
                # 기준값과 같은 도면도 센다 — "관련 파일 2개"가 실제 31개였다 (검토21 파일럿 중간 3)
                same_no = {o.dwg_no for o in occs
                           if o.dwg_no != base.dwg_no and o.dwg_no not in seen_no
                           and _num_units(o.text, tag) and not _units_conflict(bunits, _num_units(o.text, tag))}
                ev = [f"{base.dwg_no}{stamp[base.path]}: {base.text} ({base.where}, {base.path})"]
                ev += [f"{o.dwg_no}{stamp[o.path]}: {o.text} ({o.where}, {o.path})"
                       for o in conflicts[:6]]
                ev.append(f"{base.spec}와 같은 도면 {1 + len(same_no)}장 · 다른 값 도면 {len(conflicts)}장"
                          + (f" (위에 6장까지 표시)" if len(conflicts) > 6 else ""))
                # 메시지에 장수를 넣지 않는다 — 장수가 바뀌면 다른 이슈로 보여 옛 것은 '자동 해소',
                # 새 것은 새 날짜로 재등록돼 문제 발생일이 초기화됐다 (검토21 파일럿 중간 4)
                issues.append(Issue(
                    "TAG_MISMATCH_ACROSS_DRAWINGS", first.path,
                    f"[{proj}] 태그 {tag}의 사양이 도면 간에 다릅니다"
                    f" ({base.spec} vs {first.spec}).", tuple(ev)))

        # 도면-BOM: BOM SPEC 값이 해당 태그의 도면 줄에 없으면 불일치.
        # 같은 태그가 도면 30장에 있으면 30건이 아니라 **태그당 1건**만 —
        # 대형 프로젝트에서 이슈 수천 건으로 화면·브리핑이 마비되는 것 방지
        # (2026-08-25 확장성 검토: 시나리오 1,493건 → 태그당 1건)
        known_tags: set = set()
        for path in tag_map:
            known_tags |= set(tag_map[path].keys())
        for bom_path, bom in boms:
            known_tags |= {_col(r, _TAG_COLS) for r in bom.rows} - {""}
            # 대시 없는 태그(M4201, X422)는 인식 패턴에 맞지 않아 도면 간·도면-BOM 대조가 이 프로젝트에서
            # 통째로 침묵했고 아무도 몰랐다 (검토21 파일럿 중간 7) — 표기가 패턴과 다르면 한 번 알린다
            vals = [v for v in (_col(r, _TAG_COLS) for r in bom.rows) if v]
            odd = sorted({v for v in vals
                          if not _base.TAG_RE.fullmatch(v) and re.search(r"\d", v) and re.search(r"[A-Za-z]", v)})
            if len(vals) >= 3 and len(odd) * 2 >= len(vals):
                issues.append(Issue(
                    "TAG_PATTERN_UNRECOGNIZED", bom_path,
                    f"[{proj}] BOM의 태그 표기(예: {odd[0]})가 인식 패턴과 달라 도면-BOM·도면 간 대조를 "
                    f"하지 못했습니다 — config.yaml의 tag_pattern으로 표기 규칙을 알려 주세요.",
                    (f"BOM TAG 열 예: {', '.join(odd[:5])} ({bom_path})",
                     "인식 패턴 기본값: 'M-101', '1M-1', 'MCCB-01' 꼴 (글자-숫자 사이 대시)")))
        # BOM 사양 칸의 모델명(GMC-32)은 태그 꼴이라 도면의 GMC-22가 '태그'로 제외돼 모델명
        # 불일치를 통째로 못 봤다 (2026-09-04 사용자 관점 검토 #3). 사양 칸에 태그 꼴로
        # 나오는 계열(글자 접두 GMC)은 태그가 아니라 값으로 본다 — BOM TAG 열에 실제로
        # 있는 것만 예외. "M-101 → CP-01" 같은 상대 태그(CP 계열은 사양 칸에 없음)는 그대로
        bom_tags: set = set()
        model_prefixes: set = set()
        for bom_path, bom in boms:
            for r in bom.rows:
                bom_tags.add(_col(r, _TAG_COLS))
                sp = _col(r, _SPEC_COLS)
                for piece in (re.split(r"[\s/,;]+", sp) if sp else ()):
                    m = _MODEL_RE.match(piece)
                    if m:
                        model_prefixes.add(m.group(1).upper())
        # 어느 도면에서든 줄의 첫 태그 자리에 나오는 것(CP-01 24VDC)은 태그로 남긴다 —
        # 다른 태그 뒤에만 나오는 것(MC-02 GMC-22의 GMC-22)만 값으로 강등 (재검토 ②-5)
        leading: set = set()
        for path, d in drawings:
            for ln in d.raw_texts:
                first = find_tags(ln.text)[:1]
                if first:
                    leading.add(first[0])
        known_tags = {tg for tg in known_tags
                      if tg in bom_tags or tg in leading or not (
                          _MODEL_RE.match(tg) and _MODEL_RE.match(tg).group(1).upper()
                          in model_prefixes)}
        # 같은 도면번호가 여럿(old/ 구판·복사본)이면 최고 Rev 한 장만 BOM과 대조한다 —
        # 구판의 3.7kW 때문에 BOM 3파일이 전부 불일치로 남았다 (검토19 2차 감지 N7)
        best_by_no: dict = {}
        for path, d in drawings:
            no = d.fields["DWG_NO"].value if "DWG_NO" in d.fields else None
            if not no:
                continue
            rev = str(d.revision or "")
            # old/·구버전/ 안의 판은 Rev가 더 높아 보여도(현행이 Rev 빈칸) 현행에 밀린다 (검토19c N7f)
            key = (not _OLD_FOLDER.search(path), len(rev), rev.upper())
            if no not in best_by_no or key > best_by_no[no][0]:
                best_by_no[no] = (key, path)
        drawings_for_bom = [(p, d) for p, d in drawings
                            if not (("DWG_NO" in d.fields) and d.fields["DWG_NO"].value
                                    and best_by_no.get(d.fields["DWG_NO"].value, (None, p))[1] != p)]
        for bom_path, bom in boms:
            seen_tags: set[str] = set()
            for row in bom.rows:
                tag = _col(row, _TAG_COLS)
                spec = _col(row, _SPEC_COLS)
                if not tag or not spec or tag in seen_tags:
                    continue
                nspec = _norm(spec)
                pieces = _spec_pieces(spec)

                def _mismatch(lines):
                    # 도면 줄의 **첫 사양값 토큰**(숫자를 품은 것)이 BOM 사양의 조각과 맞아야
                    # 일치. 도면은 "M-101 5.5kW"처럼 첫 값만 적으므로 BOM 사양 전체가 줄에
                    # 있어야 한다고 보면 오탐이 8건씩 나고, 아무 토큰이나 맞으면 '4P·380V'
                    # 같은 공통 조각 때문에 5.5→7.5 변경을 놓친다 (2026-09-03 검토·재검토).
                    # 값 토큰이 없는 줄(태그만·설명만 적힌 줄)은 비교 대상이 아니다.
                    # 돌려주는 값: 불일치면 비교한 줄, 일치·비교 불가면 None
                    first_bad = None
                    for ln in lines:
                        toks = [x for x in _tokens_after(tag, ln.text) if _spec_like(x, known_tags)]
                        if not toks:
                            continue
                        if _line_has_spec(nspec, ln.text) or _norm(toks[0]) in pieces:
                            return None
                        if first_bad is None:
                            first_bad = ln
                    return first_bad

                for path, d in drawings_for_bom:
                    lines = tag_map[path].get(tag)
                    bad = _mismatch(lines) if lines else None
                    if bad is not None:
                        n_more = sum(
                            1 for p2, _ in drawings_for_bom
                            if p2 != path and tag_map[p2].get(tag)
                            and _mismatch(tag_map[p2][tag]) is not None)
                        extra = f" (외 도면 {n_more}장에서도 불일치)" if n_more else ""
                        # BOM과 **같은** 값의 도면도 근거에 — 옛 도면 하나만 인용하면 구매가
                        # "도면이 맞고 BOM이 틀렸다"로 거꾸로 읽는다 (검토24 A-1)
                        agree = [p2 for p2, _ in drawings_for_bom
                                 if p2 != path and tag_map[p2].get(tag)
                                 and _mismatch(tag_map[p2][tag]) is None
                                 and any(_spec_like(x, known_tags)
                                         for ln in tag_map[p2][tag]
                                         for x in _tokens_after(tag, ln.text))]
                        ev = [f"BOM: {tag} SPEC={spec} ({row.where}, {bom_path})",
                              f"도면{stamp[path]}: {bad.text} ({bad.where}, {path})"]
                        if agree:
                            ev.append("BOM과 같은 값의 도면 " + f"{len(agree)}장: "
                                      + ", ".join(f"{PurePosixPath(p2).name}{stamp[p2]}" for p2 in agree[:4])
                                      + (" 외" if len(agree) > 4 else "")
                                      + " — 어느 쪽이 최신인지 확인하세요")
                        issues.append(Issue(
                            "BOM_MISMATCH", bom_path,
                            f"[{proj}] {tag}: BOM 사양과 도면 기재가 다릅니다.{extra}",
                            tuple(ev)))
                        seen_tags.add(tag)
                        break
    return issues
