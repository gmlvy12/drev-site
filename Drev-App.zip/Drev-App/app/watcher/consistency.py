# -*- coding: utf-8 -*-
"""일관성 검사. 의미(옳다/그르다)는 판단하지 않는다 — 서로 안 맞는 것만 찾는다 (PRINCIPLE 6).

검사 4종:
  CONTENT_CHANGED_REV_SAME       내용이 바뀌었는데 표제란 Rev 그대로 (실수1)
  REV_CHANGED_CONTENT_SAME       Rev만 올라가고 내용 동일 (실수2)
  TAG_MISMATCH_ACROSS_DRAWINGS   같은 프로젝트 내 도면 간 같은 태그의 사양 불일치
  BOM_MISMATCH                   도면 태그 사양 ↔ BOM SPEC 불일치
모든 Issue는 근거(evidence: 구값/신값/위치) 없이는 만들 수 없다 (PRINCIPLE 4).
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath
from dataclasses import dataclass, field
from typing import NamedTuple

from watcher.diff import ChangeItem, content_items
from watcher.extract import base as _base
from watcher.extract.base import find_tags, Document

CODE_LABEL = {
    "CONTENT_CHANGED_REV_SAME": "내용 변경, Rev 미갱신",
    "REV_CHANGED_CONTENT_SAME": "Rev만 갱신, 내용 동일",
    "TAG_MISMATCH_ACROSS_DRAWINGS": "도면 간 태그 사양 불일치",
    "BOM_MISMATCH": "도면-BOM 불일치",
    "TAG_PATTERN_UNRECOGNIZED": "태그 표기 인식 불가",
    "REV_REGRESSED": "Rev가 거꾸로 감",
}


@dataclass(frozen=True)
class Issue:
    code: str
    path: str          # 대상 파일 (프로젝트 수준이면 대표 경로)
    message: str
    evidence: tuple = field(default_factory=tuple)  # 근거 문자열들

    def __post_init__(self):
        # "근거 없이는 만들 수 없다"를 타입으로 강제 (원칙 4, 검토19 원칙 ⑩)
        if not self.evidence:
            raise ValueError(f"근거 없는 검토 항목은 만들 수 없습니다: {self.code} {self.path}")


def _fmt_item(i: ChangeItem) -> str:
    return f"{i.key}: {i.old or '—'} → {i.new or '—'} ({i.where})"


def check_revision(path: str, old: Document, new: Document,
                   items: list[ChangeItem], visual_checked: bool = True) -> list[Issue]:
    """한 파일의 구/신 쌍에 대한 Rev 일관성.

    visual_checked=False면 그림 비교를 하지 않은 짝이다 — 글자 변경이 없다고 해서
    '내용 동일'이라 단정하지 않는다 (2026-09-02 재검토: 원칙 4·5)."""
    issues = []
    from watcher.diff import is_rev_field
    # 둘째 표제란(배치 시트2 등)의 REV#2 올림도 Rev 올림이다 — 모르면 시트2만 개정한 날 거꾸로 'Rev 미갱신'을
    # 냈다 (검토36 A N2). 첫 표제란 REV가 있으면 그것이 앞선다(필드 이름순)
    rev_change = next((i for i in items if is_rev_field(i)), None)
    content = content_items(items)
    # 세트 PDF(쪽마다 표제란)에서 1쪽이 아닌 쪽만 개정하면 그 쪽의 'REV: A → REV: B' 줄이 본문 변경으로
    # 남아, 'Rev 미갱신'을 내며 그 줄을 근거로 인용했다 (2회차 B8). 표제란 REV 줄의 변경은 Rev 올림이다
    # 콜론 없는 'REV   B'(칸이 나뉜 CAD 출력 PDF 대부분)도 — 줄 전체가 REV 라벨+값뿐일 때 (3회차 A3)
    _fr = new.fields["REV"].value if "REV" in new.fields else None
    title_rev = [i for i in content
                 if is_page_rev_bump(i.kind, i.old, i.new, getattr(i, "where", ""), getattr(new, "doc_type", "pdf"),
                                     field_rev=_fr)]
    if rev_change is None and title_rev:
        rev_change = title_rev[-1]
        content = [i for i in content if i not in title_rev]
    # 표제란이 OCR 유래고 혼동 문자만 다르면(B↔8) Rev가 바뀐 게 아니다 — `_diff_fields`와 같은 규칙 (리뷰12 중간-C)
    from watcher.diff import same_ocr_value
    # 세트 PDF 쪽 REV 줄에서 온 Rev 올림(old≠new가 확인된 TEXT 항목)에는 이 가드를 대지 않는다 — 1쪽 필드
    # A=A로 참이 되어 스캔 세트의 2쪽 개정이 거짓 'Rev 미갱신'이 됐다 (검토30 B 5-B)
    if rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" \
            and same_ocr_value(old.fields.get(rev_change.key), new.fields.get(rev_change.key)):
        rev_change = None

    from watcher.diff import _blank_rev as _blank
    # Rev가 아직 '-'(첫 발행 전)이면 올릴 Rev가 없다 — 작업본을 고칠 때마다 'Rev가 - 그대로'가 났다 (검토41 S2 중간 4)
    # 시트마다 REV가 있는 통합 문서(REV·REV#2)는 **모두** 비어 있을 때만 '첫 발행 전' — 이름순 첫 시트가 '-'라고 다른
    # 시트(REV B)의 내용 변경에 경고가 사라졌다 (검토42 A 중간 4)
    _revs = [f.value for k, f in (new.fields or {}).items() if str(k).split("#", 1)[0] == "REV"]
    if content and rev_change is None and new.revision is not None and not all(_blank(v) for v in _revs):
        # 메시지에 건수를 넣지 않는다 — 발행 전 작업본을 매일 저장하는 동안
        # 건수만 바뀐 같은 경고가 날마다 재알림되던 문제 (2026-08-26 설계 검토:
        # 같은 내용은 30일 중복 억제에 걸려 브리핑에 1회만 실린다)
        # 문서류(xlsx·docx)의 Rev는 개정이력 시트/표에서 온다 — "표제란"이라 부르면 구매가 BOM 어디를
        # 봐야 할지 몰랐다 (검토25 브리핑 B-1)
        # Rev가 어디서 왔는지 그대로 — 표 위 표제 칸·머리말에서 읽은 Rev까지 '개정이력'이라 불러 없는 시트를 찾게 했다
        # (검토41 S6·검토42 낮음). 보여 줄 Rev는 비지 않은 것 (시트별 REV 가운데)
        _rf = new.fields.get("REV")
        where_ = ("개정이력" if _rf is not None and "개정이력" in str(_rf.where or "")
                  else "표제란" if new.doc_type not in ("xlsx", "docx", "hwpx") else "문서 머리")
        _shown = next((v for v in _revs if not _blank(v)), new.revision)
        ev = [f"{where_} REV: {_shown} (변경 전후 동일)",
              (f"이번 변경 {len(content)}건 중 예시:" if len(content) > 1 else "이번 변경:")]
        ev += [_fmt_item(i) for i in content[:5]]
        issues.append(Issue(
            "CONTENT_CHANGED_REV_SAME", path,
            # 문구는 예전 그대로(이슈 대조 키가 문구 뼈대라, 바꾸면 판 교체 날 열린 이슈가 닫혔다 새로 태어난다 — 2026-09-14)
            f"내용이 바뀌었는데 {'개정이력' if new.doc_type in ('xlsx', 'docx', 'hwpx') else '표제란'} Rev가 {_shown} 그대로입니다. "
            f"(발행 전 작업본이면 무시하세요 — 발행 시 Rev를 올리면 해소됩니다)",
            tuple(ev)))

    # 페이지 전체가 어긋난 재스캔은 그 쪽의 그림 비교가 무의미해 접었다 — 그걸 '내용 동일'의
    # 근거로 쓰면 안 된다. 1pt 밀린 재스캔에 표를 하나 더해도 "Rev만 갱신, 내용 동일"이 났다
    # (2026-09-09 비교 검토). 접힌 쪽이 있으면 이 판정은 하지 않는다.
    folded = any(i.kind == "PAGE_VISUAL_CHANGED" and "전체가 살짝 어긋남" in str(i.where or "")
                 for i in items)
    from watcher.diff import _blank_rev
    # 빈칸·'-' → A만 채운 날(첫 발행)은 'Rev만 올라갔는데 글자 변경 없음'이 아니다 (검토38 R1 중간 3)
    first_issue = rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" \
        and _blank_rev(rev_change.old)
    # 도면명(표제란 TITLE 칸)이 바뀌었으면 '글자 변경 없음'이 아니다 — 개정하며 도면명을 고친 도면에 거짓
    # 'Rev만 갱신' (검토38 R4 08)
    from watcher.diff import field_base
    title_changed = any(getattr(i, "kind", "") == "FIELD_CHANGED" and field_base(getattr(i, "key", "")) in ("TITLE", "SCALE")
                        for i in items)          # 축척을 바꾼 개정도 '글자 변경 없음'이 아니다 (검토42 B T04)
    # Rev가 **거꾸로** 갔다(B→A) — 옛 판으로 덮어쓴 흔적이다. 같은 모양의 Rev끼리만 견준다(P1→A 같은 예비→발행은
    # 모양이 달라 여기 안 걸린다). 서버를 통째로 되돌린 날 Rev B→A인 파일 5개에 아무 말이 없었다 (검토42 D 중간 1)
    regressed = False
    if rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" and not first_issue:
        from watcher.scan import rev_key, rev_shape
        ro, rn = str(rev_change.old or "").strip(), str(rev_change.new or "").strip()
        if ro and rn and not _blank(ro) and not _blank(rn) and rev_shape(ro) and rev_shape(ro) == rev_shape(rn) \
                and rev_key(rn) < rev_key(ro):
            regressed = True
            issues.append(Issue(
                "REV_REGRESSED", path,
                f"Rev가 {ro}→{rn}로 거꾸로 갔습니다. 옛 판으로 덮어썼는지 확인하세요.",
                (f"표제란 REV: {ro} → {rn} ({rev_change.where})",
                 f"이번 변경 {len(content)}건" if content else "글자·표 변경 없음 — 옛 판 파일을 그대로 되살렸을 수 있습니다")))
    if rev_change is not None and not content and visual_checked and not folded and not first_issue \
            and not title_changed and not regressed:
        ev = [f"표제란 REV: {rev_change.old} → {rev_change.new} ({rev_change.where})",
              ("행·셀 변경: 0건 — 개정이력 기재만 추가된 것이면 정상입니다"
               if new.doc_type in ("xlsx", "docx", "hwpx") else
               "글자·표 변경: 0건 — 형상(선·도형)만 바뀐 정상 개정일 수 있습니다"
               " (그림 변경은 텍스트 비교에 잡히지 않습니다)")]
        claimed = [i for i in items if i.kind == "REVROW_ADDED"]
        ev += [f"리비전 블록 기재: {_fmt_item(i)}" for i in claimed[:2]]
        issues.append(Issue(
            "REV_CHANGED_CONTENT_SAME", path,
            f"Rev가 {rev_change.old}→{rev_change.new}로 올라갔는데 글자 변경이 없습니다.",
            tuple(ev)))
    return issues


class _Occ(NamedTuple):
    """한 도면에서 태그가 등장한 지점 (사양 토큰 + 근거)."""
    spec: str
    text: str
    path: str
    where: str
    dwg_no: str


# 구분자만 있는 토큰 — 사양값이 아니다 ('M-302 : 15kW'의 ':')
_SEP_TOKENS = {":", "-", "=", "·", "|", "/", "→", ","}
# 모델명·태그 꼴 토큰의 글자 접두 (GMC-22 → GMC, 3P-100 → P)
_MODEL_RE = re.compile(r"^\d?([A-Za-z]{1,6})-\d+[A-Za-z0-9]*$")

# 표기 차이를 흡수하는 정규화: 소문자화 + 공백/구분자 제거 + 단위 동의어
# ('5.5kW' vs '5.5 KW' vs '5.5㎾'가 전부 경보가 되던 문제 — 2026-08-26 검토)
_UNIT_SYNONYM = (("㎾", "kw"), ("㎟", "sq"), ("ø", "d"), ("Φ", "d"), ("φ", "d"))


_TRAIL_ZERO = re.compile(r"(\d+)\.(\d*?)0+(?=[^\d]|$)")   # 5.50 → 5.5, 10.0 → 10.
_BARE_DOT = re.compile(r"(\d+)\.(?=[^\d]|$)")             # 10. → 10


def _norm_numbers(s: str) -> str:
    """수치 표기 차이를 흡수 — '5.50kW'와 '5.5kW'는 같은 값이다. 소수점 뒤 0만 지우고
    ('5.50'→'5.5', '10.0'→'10'), 정수부·단위는 건드리지 않는다 (검토21 감지 차단 2:
    같은 값에 '도면 간 사양 불일치'·'도면-BOM 불일치' 경보가 났다)."""
    out = _TRAIL_ZERO.sub(lambda m: m.group(1) + ("." + m.group(2) if m.group(2) else "."), s)
    return _BARE_DOT.sub(r"\1", out)


def _norm(s: str) -> str:
    out = s.lower()
    for a, b in _UNIT_SYNONYM:
        out = b.join(out.split(a))
    out = _norm_numbers(out)
    return "".join(ch for ch in out if ch not in " \t:·|,")


_NUM = re.compile(r"^[\d.,]+$")
_UNIT = re.compile(r"^[A-Za-z%Ω℃°]{1,6}$")


def _spec_token(line_text: str, tag: str) -> str:
    """태그 다음의 첫 '값' 토큰 = 사양값 (예: 'M-302 : 15kW DOL' → '15kW').

    줄 전체를 비교하면 문서 유형별 표기 차이('11kW' vs '11kW INVERTER DRIVEN')가
    전부 오탐이 된다. 값 토큰 하나만 비교하되, 구분자 토큰(':' 등)은 건너뛴다.
    태그는 낱말 경계로 찾는다(M-10이 M-101 안에서 걸리지 않게), 숫자 뒤에 단위가
    따로 오면('15 kW') 붙여서 한 값으로 본다 (2026-09-02 재검토)."""
    m = _tag_re(tag).search(line_text)
    if m is None:
        return ""
    toks = [t for t in line_text[m.end():].split() if t not in _SEP_TOKENS]
    if not toks:
        return ""
    # 가장 흔한 표기 'M-101 MOTOR 5.5kW'에서 첫 토큰은 종류(MOTOR)지 값이 아니다 — 그래서
    # 도면 간 사양 불일치를 통째로 못 봤고, 'M-101 5.5kW'와 비교하면 (MOTOR vs 5.5kW)
    # 헛경보를 냈다 (검토19 감지 ②). BOM 검사(_spec_like)처럼 숫자를 품은 첫 토큰을 값으로
    for i, t in enumerate(toks):
        if any(ch.isdigit() for ch in t):
            if _NUM.match(t) and i + 1 < len(toks) and _UNIT.match(toks[i + 1]):
                return t + toks[i + 1]
            return t
    return toks[0]


_CHANGE_NOTE = re.compile(r"->|→|=>|⇒|➔")
# 양쪽이 모두 **숫자로 시작하는 값**(50AT·7.5kW·(0·1750rpm) — 'MCC-1' 같은 태그는 값이 아니다
# 왼쪽 값은 낱말 첫머리부터 — '2026-09-01 → 2026-09-05'의 '01'만 잡아 '2026-09-2026-09-05'가 됐다 (검토41 S4 낮음)
# 서로 배타인 사양 낱말 묶음 — 같은 묶음에서 도면과 BOM이 **다른** 낱말을 쓰면 불일치. 단위 값만 견주면
# 'PHOTO SENSOR NPN→PNP'·'220V RED→GREEN'이 조용히 지나갔다 (검토41 S3 중간 2). 낱말 통째로만 견준다
_EXCLUSIVE_WORDS = (
    frozenset({"NPN", "PNP"}),
    frozenset({"AC", "DC"}),
    frozenset({"RED", "GREEN", "YELLOW", "AMBER", "WHITE", "BLUE", "ORANGE", "BLACK",
               "적색", "녹색", "황색", "백색", "청색", "흑색", "주황색"}),
    frozenset({"SS400", "SS41", "SUS304", "SUS316", "STS304", "STS316", "SM45C", "SPCC", "AL6061", "A6061", "A5052"}),
)


# 같은 뜻의 다른 표기 — 녹색/GREEN, STS304/SUS304(KS·JIS), SS41/SS400(구 표기), A6061/AL6061을 서로 다른 값으로 보아
# 거짓 불일치가 났다 (검토42 B 중간 1)
_WORD_SAME = {"적색": "RED", "녹색": "GREEN", "GRN": "GREEN", "황색": "YELLOW", "AMBER": "YELLOW", "백색": "WHITE", "청색": "BLUE",
              "흑색": "BLACK", "주황색": "ORANGE", "STS304": "SUS304", "STS316": "SUS316", "SS41": "SS400",
              "A6061": "AL6061"}


def _spec_words(text: str) -> set:
    """낱말 집합 — 하이픈으로 이어진 낱말('AC-3' 사용 범주, 'DC-101' 태그)은 통째로라 조각(AC·DC)을 만들지 않는다."""
    return {_WORD_SAME.get(w, w) for w in re.findall(r"[A-Za-z0-9가-힣]+(?:-[A-Za-z0-9가-힣]+)*", str(text).upper())}


def _tag_segment(tag: str, text: str) -> str:
    """태그 뒤부터 다음 태그 앞까지 — 같은 줄의 다른 기기 사양('PL-21 RED 램프 아래')까지 모으지 않게."""
    m = _tag_re(tag).search(text)
    seg = text[m.end():] if m else text
    # 태그 사이가 구분자뿐이면('PL-21, PL-22 GREEN') 사양을 함께 쓰는 것 — 다음 태그 조각으로 넘어간다. 빈 조각으로 끊어
    # PL-21의 진짜 불일치를 놓쳤다 (검토43 B 중간 7)
    for _ in range(8):
        tags_ = [(seg.find(t), t) for t in find_tags(seg)]
        tags_ = sorted((k, t) for k, t in tags_ if k >= 0)
        if not tags_:
            return seg
        k, t = tags_[0]
        if re.sub(r"[\s,;/·&및와과+]+", "", seg[:k]):
            return seg[:k]
        seg = seg[k + len(t):]
    return seg


def _word_conflict(bom_text: str, line_text: str, tag: str = "") -> bool:
    b = _spec_words(bom_text)
    d = _spec_words(_tag_segment(tag, line_text) if tag else line_text)
    for cls in _EXCLUSIVE_WORDS:
        x, y = b & cls, d & cls
        if x and y and x.isdisjoint(y):
            return True
    return False


_VALUE_CHANGE = re.compile(r"(?<![\w\-./])(\(?\d[\w.,%㎾㎟Ω℃°\-/]*)\s*(?:->|→|=>|⇒|➔)\s*(\(?\d[\w.,%㎾㎟Ω℃°)\-/]*)")


def _current_values(text: str) -> str:
    """'50AT->75AT'·'5.5kW → 7.5kW'처럼 양쪽이 모두 값인 화살표는 옛 값→새 값 기술 — 새 값만 남긴다.
    'MOTOR 7.5kW -> MCC-1'처럼 한쪽이 값이 아니면(연결 표기) 그대로 둔다 (검토38 R3 차단 1·검토39 F2 ②)."""
    return _VALUE_CHANGE.sub(lambda m: m.group(2), text)
_VAL_UNIT = re.compile(r"^(\d+(?:[.,]\d+)?)\s*([A-Za-z%Ω℃°㎾㎟]{0,6})$")
# 표제란 REV 줄(콜론 있는 꼴·칸 나뉜 'REV   B') — 세트 PDF 쪽 표제란의 Rev 올림 판정과 36시간 유예가 같이 쓴다
REV_LINE_RE = re.compile(r"^\s*REV(ISION)?\.?\s*(?:[:：.\-]\s*\S{1,8}|\s+[A-Za-z]?\d{0,3}[A-Za-z]?)\s*$", re.I)
_REV_LINE_VALUE_RE = re.compile(
    r"^\s*REV(?:ISION)?\.?\s*[:：.\-]?\s*([A-Za-z0-9][A-Za-z0-9.\-]{0,5}|-)(?:\s*\([^)]{0,24}\))?\s*$", re.I)
_PAGE_2PLUS_RE = re.compile(r"^\s*(?:[2-9]|\d{2,})\s*(?:페이지|쪽|page)", re.I)
# 윈도우 사본은 '(2)'부터 생긴다 — '(1)'은 사본이 아니라 시트일 가능성이 높다 (검토31 S1-13)
# 이름 끝의 '_OLD'·'_구판'·'_백업'도 사본 표식 — 현장용 옛 판을 '_OLD'로 바꿔 두면 도면 간 거짓 불일치가
# 일주일 열려 있었다 (검토39 P4 중간 3)
_COPY_MARK_RE = re.compile(r"(\((?:[2-9]|\d{2,})\)|[-_\s]+복사본|[-_\s]+copy|[-_](?:old|구판|옛판))\s*$",
                           re.I)   # 'UPS BACKUP'·'비상전원 백업'은 도면 이름이다 (검토39 F2 ⑥)


def is_page_rev_bump(kind, old, new, where, doc_type: str = "pdf", field_rev=None) -> bool:
    """세트 PDF(쪽마다 표제란)의 **뒤 쪽** 표제란 REV 줄이 바뀐 것인가 — 'REV: A → REV: B'.
    모든 문서·TEXT_ADDED에 대면 본문의 개정 구름 글자 'REV 2'가 Rev 올림으로 승격돼 'Rev 미갱신'이 꺼지고
    36시간 유예까지 걸렸다 (검토31 B6). 조건: PDF · 2쪽 이상 · TEXT_CHANGED · 앞뒤 모두 REV 줄 · 값이
    표제란 REV 꼴(A/AB/1/12) · 값이 다름."""
    if str(doc_type or "pdf") != "pdf" or str(kind or "") != "TEXT_CHANGED":
        return False
    if not _PAGE_2PLUS_RE.match(str(where or "")):
        return False
    mo, mn = _REV_LINE_VALUE_RE.match(str(old or "")), _REV_LINE_VALUE_RE.match(str(new or ""))
    if not (mo and mn and mo.group(1).upper() != mn.group(1).upper()):
        return False
    vn, vo = mn.group(1), mo.group(1)
    if vn == "-":
        return False                         # 값이 없어진 것은 올림이 아니다
    # 1쪽 표제란 REV가 글자(A)인데 2쪽 줄이 '1→2'처럼 작은 숫자끼리면 본문의 개정 구름 글자다 (검토32 B3).
    # 'P1→0'(예비→발행)·'-→A'·'A1→A2'·'100→101'은 올림이다 (B4)
    if field_rev is not None:
        fr = str(field_rev or "")
        if fr and not fr[:1].isdigit() and vo.isdigit() and vn.isdigit() and len(vo) <= 2 and len(vn) <= 2:
            return False
    return True
# '00_구판'·'Backup_2025'·'_old'·'구판(2025)'·'99_백업'처럼 앞뒤가 붙은 이름도 (검토26 1회차 2)
# 폴더 조각(마지막 파일 이름 제외)만 보고, 낱말 뒤는 숫자·구분자·괄호만 — 'Backup NAS'·'구판 교체 공사'·
# 'old_E-101.dxf'까지 구판이 됐다 (2회차 A4)
_OLD_FOLDER = re.compile(
    r"(^|/)[\d_\-\s.]*(old|구버전|구판|backup|백업|아카이브|archive|보관함?|지난)"
    r"(?:[\s_\-]*(drawings?|dwgs?|files?|docs?|도면|파일|문서|자료|rev\.?[A-Za-z0-9]*))?[\d_\-\s.()]*/",
    re.IGNORECASE)


def _num_set(line_text: str, tag: str) -> frozenset:
    """태그 뒤의 숫자 품은 값 토큰들(정규화) — 다른 태그 꼴 토큰(→ CP-01)은 뺀다."""
    return frozenset(v for vals in _num_units(line_text, tag).values() for v in vals)


def _num_units(line_text: str, tag: str) -> dict[str, frozenset]:
    """태그 뒤의 값을 **단위별로** 묶는다 {단위: {값}} — '100AT 3P'와 '125AT 3P'는 3P가 겹쳐도
    AT가 다르니 불일치다. 집합 교집합 하나로 보면 부속 숫자(3P·4P·380V) 하나 때문에
    5.5kW↔7.5kW를 못 봤다 (파일럿 모의 2차 N1). 단위 없는 숫자는 '' 단위."""
    m = _tag_re(tag).search(line_text)
    if m is None:
        return {}
    out: dict[str, set] = {}
    # 태그 뒤부터 **다음 태그 앞까지만** — 같은 줄 다른 기기 값('M-101 7.5kW / M-102 5.5kW')이 섞여, M-102가 BOM 값과
    # 같아지자 M-101 불일치가 '일치'로 자동 해소됐다 (검토43 A 중간 5)
    toks = [t for t in re.split(r"[\s/;]+", _tag_segment(tag, line_text)) if t and t not in _SEP_TOKENS]
    i = 0
    while i < len(toks):
        t = toks[i]
        # '5.5 kW'처럼 숫자와 단위가 떨어진 표기는 붙인다 — 안 붙이면 '5.5KW'와 헛경보 (검토19c ⑥)
        if _NUM.match(t) and i + 1 < len(toks) and _UNIT.match(toks[i + 1]):
            t = t + toks[i + 1]
            i += 1
        i += 1
        if not any(ch.isdigit() for ch in t):
            continue
        if re.match(r"^[A-Za-z]{1,4}-\d+[A-Za-z0-9]*$", t):      # 상대 태그(CP-01)는 값이 아니다
            continue
        t = ".".join(t.split(",")) if re.match(r"^\d+,\d+", t) else t   # 5,5kW = 5.5kW (replace는 가드가 막는다)
        mm = _VAL_UNIT.match(t)
        unit = _norm(mm.group(2)) if mm else "?"                  # 'CV4SQ3C' 같은 덩어리는 '?'
        out.setdefault(unit, set()).add(_norm(t))
    return {u: frozenset(v) for u, v in out.items()}


def _conflict_vals(a: dict, b: dict) -> tuple[str, str]:
    """서로소인 단위의 값 — ('7.5kW', '11kW'). 없으면 ('', '')."""
    for u, va in a.items():
        vb = b.get(u)
        if vb and not (va & vb):
            _pretty = {"kw": "kW", "v": "V", "a": "A", "at": "AT", "af": "AF", "sq": "SQ", "hz": "Hz", "p": "P"}

            def _fmt(v):
                m = re.match(r"^([\d.,]+)([a-z]*)$", str(v))
                return f"{m.group(1)}{_pretty.get(m.group(2), m.group(2))}" if m else str(v).upper()
            return "/".join(_fmt(v) for v in sorted(va)), "/".join(_fmt(v) for v in sorted(vb))
    return "", ""


def _units_conflict(a: dict, b: dict) -> bool:
    """같은 단위가 양쪽에 있는데 값 집합이 서로소인 단위가 하나라도 있으면 불일치."""
    for u, va in a.items():
        vb = b.get(u)
        if vb and not (va & vb):
            return True
    return False


def _line_has_spec(nspec: str, text: str) -> bool:
    """줄 안에 사양값이 **값 단위로** 있는가 — 부분문자열이면 5.5kW가 15.5kW에
    들어 있다고 보고 불일치를 놓친다 (2026-09-02 재검토)."""
    # 공백과 '/ , ;'로 쪼갠 조각들의 연속 구간(최대 4개)을 값 후보로 — '15 kW',
    # '5.5kW 4P'(여러 토큰 사양), '5.5kW/380V'(슬래시 묶음)까지 잡되, 5.5kW가
    # 15.5kW 안에서 걸리는 부분문자열 일치는 생기지 않는다
    parts = [p for p in re.split(r"[\s/,;]+", text) if p and p not in _SEP_TOKENS]
    for i in range(len(parts)):
        for j in range(i + 1, min(i + 5, len(parts) + 1)):
            if _norm("".join(parts[i:j])) == nspec:
                return True
    return False


# BOM 머리글은 회사마다 다르다 — 영문 SPEC/TAG만 보면 한글 BOM('규격')은 검사가
# 통째로 침묵한다 (2026-09-03 합성 서버 검토: 도면-BOM 불일치 0/5)
_TAG_COLS = ("TAG", "태그", "TAG NO", "TAG_NO", "TAGNO", "기기번호", "기기 번호", "기기TAG")
_SPEC_COLS = ("SPEC", "규격", "사양", "SPECIFICATION", "SPEC.", "MODEL", "모델")


def _col(row, names) -> str:
    """행에서 이름 후보 중 첫 값 — 머리글 표기(대소문자·공백)가 회사마다 다르다."""
    up = {str(k).strip().upper(): v for k, v in row.values.items()}
    for n in names:
        v = up.get(n.upper())
        if v not in (None, ""):
            return str(v)
    return ""


def _spec_pieces(spec: str) -> set[str]:
    """BOM 사양('5.5kW 4P 380V', '15 kW')을 값 조각 집합으로 — 도면은 첫 값만 적는다."""
    parts = [x for x in re.split(r"[\s/,;]+", spec) if x and x not in _SEP_TOKENS]
    out: set[str] = set()
    for i in range(len(parts)):
        for j in range(i + 1, min(i + 5, len(parts) + 1)):
            out.add(_norm("".join(parts[i:j])))
    return out


import functools as _functools


@_functools.lru_cache(maxsize=8192)
def _tag_re(tag: str):
    """낱말 경계의 태그 패턴 — 태그마다 한 번 컴파일 (검토41 S5 중간 2)."""
    return re.compile(r"(?<![\w-])" + re.escape(tag) + r"(?![\w-])")


def _tokens_after(tag: str, text: str) -> list[str]:
    m = _tag_re(tag).search(text)
    if m is None:
        return []
    return [x for x in re.split(r"[\s/,;]+", text[m.end():]) if x and x not in _SEP_TOKENS]


def _spec_like(tok: str, known_tags=frozenset()) -> bool:
    """사양값처럼 생긴 토큰 — 숫자를 품고, 이 프로젝트의 기기 태그는 아닌 것 (5.5kW,
    MY4N, 125AT, GMC-22). 'MAIN MOTOR', 'U V W' 같은 설명 낱말과 "M-101 → CP-01"의
    상대 태그는 비교 대상이 아니다. 모델명(GMC-22)은 태그처럼 생겼지만 도면·BOM 어디에도
    태그로 등장하지 않으므로 값으로 본다 (2026-09-03 재검토)."""
    return any(ch.isdigit() for ch in tok) and tok not in known_tags


def _rev_stamp(d: Document) -> str:
    """근거 줄에 붙일 ' [Rev B, 2026-09-01]' — 표제란에 있는 것만."""
    rev = d.revision
    date = d.fields["DATE"].value if "DATE" in d.fields else ""
    parts = [f"Rev {rev}" if rev else "", date]
    inner = ", ".join(x for x in parts if x)
    return f" [{inner}]" if inner else ""


def _canon_project(name: str) -> str:
    """교차 검사의 묶음 키 — 표제란 원문이 아니라 프로젝트 번호로. 'P24-031'과
    'P24-031 (2차)'가 다른 묶음이 되어 검사가 통째로 빠지던 것 (2026-09-02 재검토)."""
    from watcher.project import PLACEHOLDER_PROJECTS, PROJECT_NO_RE
    name = (name or "").strip()
    if name.upper() in PLACEHOLDER_PROJECTS:
        return ""
    m = PROJECT_NO_RE.search(name)
    if m:
        return m.group()
    # 문자 접두 없는 번호("26-033", "…(26-033)")도 같은 묶음 (2026-09-03 검토)
    m = re.search(r"(?<![\w-])(\d{2}-\d{3})(?![\w-])", name)
    return m.group(1) if m else name


def check_project_consistency(docs: list[tuple[str, Document]],
                              project_of=None) -> list[Issue]:
    """프로젝트 단위 교차 검사: 도면 간 태그 불일치 + 도면-BOM 불일치.

    project_of(path, doc) → 프로젝트: 검사가 쓰는 귀속기(표제란 > 파일명 > 폴더).
    없으면 표제란만 — PROJECT 열이 없는 BOM은 묶음에 못 들어가 검사가 빠졌다
    (2026-09-03 검토)."""
    issues = []
    by_project: dict[str, list[tuple[str, Document]]] = {}
    for path, doc in docs:
        raw = project_of(path, doc) if project_of else doc.project
        proj = _canon_project(raw) if raw else None
        if proj:
            by_project.setdefault(proj, []).append((path, doc))

    for proj, members in sorted(by_project.items()):
        drawings = [(p, d) for p, d in members if d.doc_type in ("dxf", "pdf")]
        boms = [(p, d) for p, d in members if d.doc_type == "xlsx" and d.rows]

        # 도면별 태그→줄 사전은 1회만 계산해 재사용 — BOM 행마다 재계산하면
        # (BOM 1,000행 × 도면 30장 = 3만 번 전체 스캔) 프로젝트당 수 초가 걸린다
        # (2026-08-25 확장성 검토: 7.9초 → 캐시 후 밀리초)
        # 태그의 전 출현 줄 — 첫 줄만 보면 심볼 옆/결선표 두 곳에 나오는
        # 태그에서 엉뚱한 줄과 비교하게 된다 (2026-08-26)
        tag_map = {path: d.tag_occurrences() for path, d in drawings}
        # 근거에 도면의 Rev·날짜를 싣는다 — 어느 쪽이 더 최근 판인지 도면을 못 읽는
        # 사람도 알 수 있게 (2026-09-02 처음 보는 사람 검토: 구매 담당)
        stamp = {path: _rev_stamp(d) for path, d in drawings}

        # 도면 간: 같은 태그의 사양값 토큰이 다르게 등장 (도면 번호가 다른 것끼리만).
        # 전 출현을 모은 뒤 비교한다 — 첫 출현과만 비교하면 사양 없는 줄(태그가 줄 끝)이
        # 먼저 나올 때 이후 도면들 간의 실제 불일치가 가려진다.
        # 같은 도면번호가 여럿(old/·Backup/ 구판·복사본)이면 현행·최고 Rev 한 장만 — BOM 검사는 이미
        # 그랬는데 도면 간 검사는 구판이 정렬 순서에 따라 '기준'이 되어 현행 3장을 '다른 값'이라 했다
        # (검토25 감지 6-3)
        # 같은 도면번호의 여러 파일 가운데 **판 사본**(이름이 판 표기만 다르거나 구판 폴더·복사본)만 겨루고,
        # 이름이 다른 같은 번호 파일(시트 E-101_SH1/SH2/SH3)은 전부 남긴다 — 시트를 구판으로 보고 한 장만
        # 남겨 나머지 시트의 태그가 검사에서 조용히 빠졌다 (검토30 B 5-A). 동률은 무표기 이름 우선 (5-E)
        from watcher.scan import pair_key as _pk, ver_rank as _vr
        by_no: dict = {}
        for path, d in drawings:
            no = d.fields["DWG_NO"].value if "DWG_NO" in d.fields else None
            if no:
                by_no.setdefault(no, []).append((path, d))

        from watcher.cli import sheet_bases as _sb, is_copy_marked as _icm
        _sheets = _sb([p for p, _ in drawings])

        def _rival(a: str, b: str) -> bool:
            na, nb = PurePosixPath(a).name, PurePosixPath(b).name
            return (_pk(na) == _pk(nb) or _OLD_FOLDER.search(a) or _OLD_FOLDER.search(b)
                    or _icm(a, _sheets) or _icm(b, _sheets))

        from watcher.scan import rev_key as _rk, rev_shape as _rs

        def _mixed(files) -> bool:
            # cli._version_comparer와 같은 규칙 — Rev **모양**이 섞였으면 Rev로 겨루지 않는다 (검토36 A N1)
            return len({_rs(dd.revision) for _q, dd in files if str(dd.revision or "").strip()}) > 1

        def _beats(q, dq, p, d, use_rev: bool = True) -> bool:
            """q(dq)가 p(d)보다 현행인가 — cli._superseded_paths._cmp와 같은 순서.
            old/·구버전/ 안의 판은 Rev가 더 높아 보여도(현행이 Rev 빈칸) 현행에 밀린다 (검토19c N7f);
            사본 표식은 항상 진다(검토31 B5); '0' vs 'A'처럼 체계가 다른 Rev는 비교하지 않는다(B3)"""
            oq, op = bool(_OLD_FOLDER.search(q)), bool(_OLD_FOLDER.search(p))
            if oq != op:
                return op
            cq, cp = _icm(q, _sheets), _icm(p, _sheets)
            if cq != cp:
                return cp
            rq, rp = str(dq.revision or "").strip().upper(), str(d.revision or "").strip().upper()
            if use_rev and rq and rp and rq != rp and _rs(rq) == _rs(rp) and _rk(rq) != _rk(rp):
                return _rk(rq) > _rk(rp)
            vq, vp = _vr(PurePosixPath(q).name), _vr(PurePosixPath(p).name)
            uq, up = vq == (1, 0, ""), vp == (1, 0, "")
            if uq != up:
                return uq
            if vq[0] == 3 and vp[0] == 3 and vq != vp:
                # 이름 판 표기도 모양이 같을 때만 순서가 있다 — 다르면 어느 쪽도 이기지 않는다(둘 다 남김).
                # cli._version_comparer가 저장 시각으로 먼저 걸렀다 (검토36 A N1)
                if _rs(vq[2]) != _rs(vp[2]):
                    return False
                return _rk(vq[2]) > _rk(vp[2])
            return vq > vp
        superseded: set = set()
        for no, files in by_no.items():
            _use = not _mixed(files)          # 체계가 섞인 묶음은 Rev로 겨루지 않는다 (검토32 B2)
            for path, d in files:
                if any(_rival(path, q) and _beats(q, dq, path, d, _use) for q, dq in files if q != path):
                    superseded.add(path)
        drawings_cur = [(p, d) for p, d in drawings if p not in superseded]
        # 구판 폴더에만 남은 도면번호·DWG_NO 없는 구판은 위 규칙이 못 거른다 — 프로젝트에 구판 폴더 밖
        # 도면이 하나라도 있으면 구판 폴더는 통째로 뺀다(구판은 판 짝짓기용) (2회차 A4)
        if any(not _OLD_FOLDER.search(p) for p, _ in drawings):
            drawings_cur = [(p, d) for p, d in drawings_cur if not _OLD_FOLDER.search(p)]
        occurrences: dict[str, list[_Occ]] = {}
        for path, d in drawings_cur:
            dwg_no = d.fields["DWG_NO"].value if "DWG_NO" in d.fields else path
            for tag, lines in tag_map[path].items():
                for line in lines:
                    spec = _spec_token(line.text, tag)
                    if spec:  # 사양 없는 출현은 비교 대상이 아니고, 다른 출현을 가리지도 않는다
                        occurrences.setdefault(tag, []).append(
                            _Occ(spec, line.text, path, line.where, dwg_no))
        for tag, occs in sorted(occurrences.items()):
            # 숫자를 품은 값 토큰 **집합**끼리 견준다 — 첫 토큰만 보면 'M-101 5.5kW 4P' vs
            # 'M-101 4P 5.5kW'(순서), 'CV 4SQ 3C' vs 'CV 3C 4SQ'가 헛경보였다. 한쪽에 숫자
            # 토큰이 없으면(P&ID의 'CONVEYOR MOTOR') 비교하지 않는다 (검토19 2차 감지 N5)
            base = next((o for o in occs if _num_units(o.text, tag)), None)
            if base is None:
                continue
            bunits = _num_units(base.text, tag)
            conflicts = []
            seen_no: set = set()
            for o in occs:
                # 같은 파일만 건너뛴다 — 도면번호로 건너뛰면 같은 번호의 다른 시트가 비교에서 빠진다 (5-A)
                if o.path == base.path or o.path in seen_no:
                    continue
                # 판 순서를 가리지 못해 둘 다 남은 **같은 도면의 두 판**(같은 도면번호, 서로 판 사본)은 도면 간
                # 불일치가 아니다 — 형제 폴더(설계/·발행/)의 두 판을 매일 '7.5kW vs 5.5kW'로 불렀다 (검토36 E 중간 1)
                if o.dwg_no == base.dwg_no and _rival(o.path, base.path):
                    continue
                ounits = _num_units(o.text, tag)
                if ounits and _units_conflict(bunits, ounits):
                    conflicts.append(o)
                    seen_no.add(o.path)
            if conflicts:
                # 충돌 도면을 **전부** 근거에 싣는다 — 하나만 보고하면 그걸 고친 뒤 다음 것이
                # 새 경고로 떠 두더지 잡기가 됐다 (검토19 2차 감지 N6)
                first = conflicts[0]
                # 기준값과 같은 도면도 센다 — "관련 파일 2개"가 실제 31개였다 (검토21 파일럿 중간 3)
                same_no = {o.path for o in occs
                           if o.path != base.path and o.path not in seen_no
                           and _num_units(o.text, tag) and not _units_conflict(bunits, _num_units(o.text, tag))}
                ev = [f"{base.dwg_no}{stamp[base.path]}: {base.text} ({base.where}, {base.path})"]
                ev += [f"{o.dwg_no}{stamp[o.path]}: {o.text} ({o.where}, {o.path})"
                       for o in conflicts[:6]]
                # 실제로 어긋난 단위 값으로 쓴다 — 첫 숫자 조각(380V)을 인용해 '380V와 같은 도면 1장 · 다른 값 1장'처럼
                # 틀린 값을 근거로 댔다 (검토44 B G08). 문구(이슈 키)는 그대로 둔다
                _bv, _fv = _conflict_vals(bunits, _num_units(first.text, tag))
                if _bv:
                    ev.append(f"어긋난 값: {_bv} ↔ {_fv}")
                ev.append(f"{_bv or base.spec}와 같은 도면 {1 + len(same_no)}장 · 다른 값 도면 {len(conflicts)}장"
                          + (f" (위에 6장까지 표시)" if len(conflicts) > 6 else ""))
                # 메시지에 장수를 넣지 않는다 — 장수가 바뀌면 다른 이슈로 보여 옛 것은 '자동 해소',
                # 새 것은 새 날짜로 재등록돼 문제 발생일이 초기화됐다 (검토21 파일럿 중간 4)
                issues.append(Issue(
                    "TAG_MISMATCH_ACROSS_DRAWINGS", first.path,
                    f"[{proj}] 태그 {tag}의 사양이 도면 간에 다릅니다"
                    f" ({base.spec} vs {first.spec}).", tuple(ev)))

        # 도면-BOM: BOM SPEC 값이 해당 태그의 도면 줄에 없으면 불일치.
        # 같은 태그가 도면 30장에 있으면 30건이 아니라 **태그당 1건**만 —
        # 대형 프로젝트에서 이슈 수천 건으로 화면·브리핑이 마비되는 것 방지
        # (2026-08-25 확장성 검토: 시나리오 1,493건 → 태그당 1건)
        known_tags: set = set()
        for path in tag_map:
            known_tags |= set(tag_map[path].keys())
        for bom_path, bom in boms:
            known_tags |= {_col(r, _TAG_COLS) for r in bom.rows} - {""}
            # 대시 없는 태그(M4201, X422)는 인식 패턴에 맞지 않아 도면 간·도면-BOM 대조가 이 프로젝트에서
            # 통째로 침묵했고 아무도 몰랐다 (검토21 파일럿 중간 7) — 표기가 패턴과 다르면 한 번 알린다
            vals = [v for v in (_col(r, _TAG_COLS) for r in bom.rows) if v]
            odd = sorted({v for v in vals
                          if not _base.TAG_RE.fullmatch(v) and re.search(r"\d", v) and re.search(r"[A-Za-z]", v)})
            if len(vals) >= 3 and len(odd) * 2 >= len(vals):
                issues.append(Issue(
                    "TAG_PATTERN_UNRECOGNIZED", bom_path,
                    f"[{proj}] BOM의 태그 표기(예: {odd[0]})가 인식 패턴과 달라 도면-BOM·도면 간 대조를 "
                    f"하지 못했습니다 — config.yaml의 tag_pattern으로 표기 규칙을 알려 주세요.",
                    (f"BOM TAG 열 예: {', '.join(odd[:5])} ({bom_path})",
                     "인식 패턴 기본값: 'M-101', '1M-1', 'MCCB-01' 꼴 (글자-숫자 사이 대시)")))
        # BOM 사양 칸의 모델명(GMC-32)은 태그 꼴이라 도면의 GMC-22가 '태그'로 제외돼 모델명
        # 불일치를 통째로 못 봤다 (2026-09-04 사용자 관점 검토 #3). 사양 칸에 태그 꼴로
        # 나오는 계열(글자 접두 GMC)은 태그가 아니라 값으로 본다 — BOM TAG 열에 실제로
        # 있는 것만 예외. "M-101 → CP-01" 같은 상대 태그(CP 계열은 사양 칸에 없음)는 그대로
        bom_tags: set = set()
        model_prefixes: set = set()
        for bom_path, bom in boms:
            for r in bom.rows:
                bom_tags.add(_col(r, _TAG_COLS))
                sp = _col(r, _SPEC_COLS)
                for piece in (re.split(r"[\s/,;]+", sp) if sp else ()):
                    m = _MODEL_RE.match(piece)
                    if m:
                        model_prefixes.add(m.group(1).upper())
        # 어느 도면에서든 줄의 첫 태그 자리에 나오는 것(CP-01 24VDC)은 태그로 남긴다 —
        # 다른 태그 뒤에만 나오는 것(MC-02 GMC-22의 GMC-22)만 값으로 강등 (재검토 ②-5)
        leading: set = set()
        for path, d in drawings:
            for ln in d.raw_texts:
                first = find_tags(ln.text)[:1]
                if first:
                    leading.add(first[0])
        known_tags = {tg for tg in known_tags
                      if tg in bom_tags or tg in leading or not (
                          _MODEL_RE.match(tg) and _MODEL_RE.match(tg).group(1).upper()
                          in model_prefixes)}
        # 같은 도면번호가 여럿(old/ 구판·복사본)이면 최고 Rev 한 장만 BOM과 대조한다 —
        # 구판의 3.7kW 때문에 BOM 3파일이 전부 불일치로 남았다 (검토19 2차 감지 N7). 위 도면 간과 같은 목록
        # 대표 근거는 **도면**을 먼저 — 사양서 PDF가 앞에 와 '도면 [Rev 1]: … 사양서.pdf'로 인용됐다 (검토44 C 중간 3)
        from watcher.doctype import kind_of as _kind_of

        def _is_dwg(p_):
            return PurePosixPath(p_).suffix.lower() in (".dxf", ".dwg") or _kind_of(p_) == "도면"
        drawings_for_bom = sorted(drawings_cur, key=lambda pd: 0 if _is_dwg(pd[0]) else 1)
        for bom_path, bom in boms:
            seen_tags: set[str] = set()
            for row in bom.rows:
                tag = _col(row, _TAG_COLS)
                spec = _col(row, _SPEC_COLS)
                if not tag or not spec or tag in seen_tags:
                    continue
                nspec = _norm(spec)
                pieces = _spec_pieces(spec)

                bunits_bom = _num_units(f"{tag} {spec}", tag)

                def _mismatch(lines):
                    # 단위별 값(kW·A·SQ…)으로 견준다 — 도면 간 검사와 같은 규칙. 첫 토큰 규칙은
                    # 'M-101 4P 7.5kW' 순서면 '4P'가 맞아 5.5→7.5를 놓쳤다 (검토25 6-2·검토26 1회차 3).
                    # 단위 값이 없는 사양(PLC 형식 'FX5U-32M')은 예전 조각 규칙으로.
                    # 값 토큰이 없는 줄(태그만·설명만 적힌 줄)은 비교 대상이 아니다.
                    # 돌려주는 값: 불일치면 비교한 줄, 일치·비교 불가면 None
                    first_bad = None
                    for ln in lines:
                        # 'B 2026-10-13 MCCB-41 50AT->75AT'처럼 옛 값→새 값을 적은 줄(리비전 표 행)은 현재 사양이
                        # 아니다 — 옛 값 50AT로 '일치'가 나서 도면-BOM 불일치가 30일 내내 안 잡혔다 (검토38 R3 차단 1)
                        text = _current_values(ln.text)
                        if _word_conflict(spec, text, tag):        # 숫자 없는 사양 낱말(NPN·RED)도 (검토41 S3 중간 2)
                            if first_bad is None:
                                first_bad = ln
                            continue
                        toks = [x for x in _tokens_after(tag, text) if _spec_like(x, known_tags)]
                        if not toks:
                            continue
                        if _line_has_spec(nspec, text):
                            return None
                        if bunits_bom:
                            ou = _num_units(text, tag)
                            if not ou:
                                continue
                            if not _units_conflict(bunits_bom, ou):
                                return None
                        elif _norm(toks[0]) in pieces:
                            return None
                        if first_bad is None:
                            first_bad = ln
                    return first_bad

                for path, d in drawings_for_bom:
                    lines = tag_map[path].get(tag)
                    bad = _mismatch(lines) if lines else None
                    if bad is not None:
                        n_more = sum(
                            1 for p2, _ in drawings_for_bom
                            if p2 != path and tag_map[p2].get(tag)
                            and _mismatch(tag_map[p2][tag]) is not None)
                        extra = f" (외 도면 {n_more}장에서도 불일치)" if n_more else ""
                        # BOM과 **같은** 값의 도면도 근거에 — 옛 도면 하나만 인용하면 구매가
                        # "도면이 맞고 BOM이 틀렸다"로 거꾸로 읽는다 (검토24 A-1)
                        # 단위별 값(kW·A·SQ…)이 BOM과 충돌하지 않는 도면만 — 첫 토큰 규칙은 '4P'가
                        # 같다고 7.5kW 도면을 5.5kW BOM과 '같은 값'이라 했다 (검토25 감지 6-2)
                        bunits_ = _num_units(f"{tag} {spec}", tag)
                        # 같은 값으로 세려면 어떤 단위에서든 값이 실제로 겹쳐야 한다 — 부속만 적힌
                        # 'M-401 MOTOR 4P'가 같은 값 도면에 들어갔다 (2회차 A3)
                        agree = [p2 for p2, _ in drawings_for_bom
                                 if p2 != path and tag_map[p2].get(tag) and bunits_
                                 and any((lambda u: u and not _units_conflict(bunits_, u)
                                          and any(bunits_.get(k) and (bunits_[k] & v) for k, v in u.items()
                                                  if k.upper() not in ("P", "")))   # 극수·단위 없는 숫자는 부속 (3회차 A5)
                                         (_num_units(ln.text, tag))
                                         for ln in tag_map[p2][tag])]
                        ev = [f"BOM: {tag} SPEC={spec} ({row.where}, {bom_path})",
                              f"{'도면' if _is_dwg(path) else '문서'}{stamp[path]}: {bad.text} ({bad.where}, {path})"]
                        if agree:
                            # 사양서 같은 문서는 '도면'으로 세지 않는다 (검토45 C 낮음 2)
                            def _names(ps):
                                return (", ".join(f"{PurePosixPath(p2).name}{stamp[p2]}" for p2 in ps[:4])
                                        + (" 외" if len(ps) > 4 else ""))
                            a_d = [p2 for p2 in agree if _is_dwg(p2)]
                            a_o = [p2 for p2 in agree if not _is_dwg(p2)]
                            parts_ = ([f"도면 {len(a_d)}장: {_names(a_d)}"] if a_d else []) \
                                + ([f"문서 {len(a_o)}건: {_names(a_o)}"] if a_o else [])
                            ev.append("BOM과 같은 값의 " + " · ".join(parts_) + " — 어느 쪽이 최신인지 확인하세요")
                        issues.append(Issue(
                            "BOM_MISMATCH", bom_path,
                            f"[{proj}] {tag}: BOM 사양과 도면 기재가 다릅니다.{extra}",
                            tuple(ev)))
                        seen_tags.add(tag)
                        break
    return issues
