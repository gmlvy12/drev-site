# -*- coding: utf-8 -*-
"""일관성 검사. 의미(옳다/그르다)는 판단하지 않는다 — 서로 안 맞는 것만 찾는다 (PRINCIPLE 6).

검사 4종:
  CONTENT_CHANGED_REV_SAME       내용이 바뀌었는데 표제란 Rev 그대로 (실수1)
  REV_CHANGED_CONTENT_SAME       Rev만 올라가고 내용 동일 (실수2)
  TAG_MISMATCH_ACROSS_DRAWINGS   같은 프로젝트 내 도면 간 같은 태그의 사양 불일치
  BOM_MISMATCH                   도면 태그 사양 ↔ BOM SPEC 불일치
  REV_BLOCK_MISMATCH             표제란 Rev ≠ 리비전 블록 최신 행 (바뀐 파일만)
모든 Issue는 근거(evidence: 구값/신값/위치) 없이는 만들 수 없다 (PRINCIPLE 4).
"""

from __future__ import annotations

import functools
import re
from datetime import date, datetime
from pathlib import PurePosixPath
from dataclasses import dataclass, field
from typing import NamedTuple

from watcher.diff import PAGE_NO_LINE as _PAGE_NO_LINE  # 쪽 번호만 든 줄 (diff와 같은 규칙)
from watcher.diff import ChangeItem, content_items
from watcher.extract import base as _base
from watcher.extract.base import find_tags, Document

CODE_LABEL = {
    "CONTENT_CHANGED_REV_SAME": "내용 변경, Rev 미갱신",
    "REV_CHANGED_CONTENT_SAME": "Rev만 갱신, 내용 동일",
    "TAG_MISMATCH_ACROSS_DRAWINGS": "도면 간 태그 사양 불일치",
    "BOM_MISMATCH": "도면-BOM 불일치",
    "TAG_PATTERN_UNRECOGNIZED": "태그 표기 인식 불가",
    "BOM_SPEC_COLUMN_UNRECOGNIZED": "BOM 사양 열 인식 불가",
    "REV_REGRESSED": "Rev가 거꾸로 감",
    "REV_BLOCK_MISMATCH": "표제란 Rev ≠ 개정표",
    "REV_ROW_DUPLICATE": "개정표에 같은 Rev 두 행",       # ux20 buy 6 (2026-11-03)
    "POST_ISSUE_CHANGE": "출도 후 변경",                 # J2 — watcher.issued
}


@dataclass(frozen=True)
class Issue:
    code: str
    path: str          # 대상 파일 (프로젝트 수준이면 대표 경로)
    message: str
    evidence: tuple = field(default_factory=tuple)  # 근거 문자열들
    # 같은 사실의 둘째 카드를 합쳐 넣었으면 그 카드의 (code, path, message) — 업데이트 날 열린 옛 카드를 이 카드로 이어 붙이는 데
    # 쓴다(state.absorb_twins). 비교·해시에는 넣지 않는다 (기능 검토 2026-11-02 J3)
    absorbed: tuple = field(default=(), compare=False)

    def __post_init__(self):
        # "근거 없이는 만들 수 없다"를 타입으로 강제 (원칙 4, 검토19 원칙 ⑩)
        if not self.evidence:
            raise ValueError(f"근거 없는 검토 항목은 만들 수 없습니다: {self.code} {self.path}")


def _fmt_item(i: ChangeItem) -> str:
    # 행 값은 'REV=1, DATE=…'로 — 근거에 사전 원문 "{'REV': '1', …}"이 그대로 실렸다 (검토47 C 중간 2)
    def _v(x):
        sx = str(x or "")
        if sx.startswith("{") and sx.endswith("}"):
            from watcher.brief import _fmt_row_values
            return _fmt_row_values(sx) or "—"
        from watcher.brief import _group_digits
        if not sx:
            return "—"
        # 천 단위는 표 칸(금액·수량)만 — 도면 글줄 '12500'이 같은 메일 위 표에서는 그대로, 근거 줄에서만 '12,500'이었다 (검토63 A-4)
        return _group_digits(sx) if str(getattr(i, "kind", "")).startswith(("ROW_", "REVROW_")) else sx
    # 표 행은 '행 열'로, 금액은 천 단위 — 'Rev 미갱신' 근거만 '모터 7.5kW.금액: 2700000 → 4050000'이었다 (검토56 ⑤21)
    key = str(i.key)
    if i.kind in ("PAGE_ADDED", "PAGE_REMOVED"):      # 한쪽만 있는 항목에 '→ —'를 붙이지 않는다 (검토71 R4 낮음 10)
        return f"{key}: {_v(i.new if i.kind == 'PAGE_ADDED' else i.old)} ({i.where})"
    if i.kind.startswith("ROW_"):
        rk, sep, col = key.rpartition(".")
        key = f"{rk} {col}" if sep and rk and col else key
    # 키가 글줄 앞 토막이면 접두어로 붙이지 않는다 — '…제어전원은 D: 주전원은 …'처럼 잘린 글이 이름처럼 붙었다 (검토62 D1-2)
    if i.kind.startswith("TEXT_") and key and any(str(v or "").startswith(key) for v in (i.old, i.new)):
        if i.kind == "TEXT_CHANGED":
            # 긴 여러 줄 덩이는 바뀐 문단 둘레만 — 300줄 주기 한 줄 수정에 근거가 600줄이었다 (검토20 r03 7, 표시만)
            from watcher.brief import long_text_window
            _o, _n = long_text_window(i.old, i.new)
            return f"{_v(_o)} → {_v(_n)} ({i.where})"
        return f"{_v(i.old)} → {_v(i.new)} ({i.where})"
    return f"{key}: {_v(i.old)} → {_v(i.new)} ({i.where})"


def _revision_row_added(items) -> bool:
    """개정이력 표에 Rev 칸이 든 행이 새로 생겼나 — 문서류는 머리말 REV를 안 고치고 개정이력 표에 행만 더하는 개정이 많다.
    그날 'Rev 미갱신'을 내면 근거가 자기모순이었다 (검토47 C 중간 1)."""
    import ast
    for i in items:
        if getattr(i, "kind", "") != "ROW_ADDED":
            continue
        try:
            d = ast.literal_eval(str(i.new or ""))
        except (ValueError, SyntaxError):
            continue
        if isinstance(d, dict) and any(re.sub(r"[\s.]", "", str(k)).upper() in ("REV", "REVISION", "REVNO", "개정", "개정번호", "판")
                                       and str(v or "").strip() for k, v in d.items()):
            return True
    return False


# 세트 PDF 쪽의 도면번호 줄 — 'DWG NO: E-102'·'DWG NO   ISO-1201-04'(칸표)·'도면번호 H-404-2'
# 라벨은 표제란 추출기(extract/pdf.py _FIELD_RE)의 도면번호 라벨과 같은 꼴 + 자간 띄운 한글 '도 면 번 호' — 띄운 라벨을
# 시트로 못 봐 세트에 쪽(시트)을 더한 날 거짓 'Rev 미갱신'이 났다 (갈래 A 2026-10-16, held69 P09)
_DWG_LABEL = r"(?:DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도\s*면\s*번\s*호)"
_SHEET_NO_LINE = re.compile(rf"(?i)^\s*{_DWG_LABEL}\s*[:：.]?\s*([A-Za-z0-9][\w.\-/]*)")
# 'SHEET NO.: E-01' — 시트 번호 칸이 도면번호 노릇을 하는 세트(held69 P08·X04). 값이 글자와 숫자를 함께 가진 도면번호 꼴일
# 때만('SHEET NO. 1'·'1/3'은 같은 문서의 쪽 번호다), 그리고 그 쪽에 도면번호 줄이 없을 때만 쓴다
_SHEETNO_LINE = re.compile(r"(?i)^\s*SHEET\s*NO\.?\s*[:：.]?\s*([A-Za-z0-9][\w.\-/]*)")
# 라벨만 있는 줄(칸 위 라벨·아래 값 표제란 — 'DWG NO' 다음 줄 'E-4301-1', held69 X03)
_DWG_LABEL_ONLY = re.compile(rf"(?i)^\s*{_DWG_LABEL}\s*[:：.]?\s*$")
_SHEETNO_LABEL_ONLY = re.compile(r"(?i)^\s*SHEET\s*NO\.?\s*[:：.]?\s*$")
_REV_LABEL_ONLY = re.compile(r"(?i)^\s*(?:REV(?:ISION)?\.?(?:\s*NO\.?)?|개정|리비전)\s*[:：.]?\s*$")
_ID_VALUE = re.compile(r"^\s*([A-Za-z0-9][\w.\-/]*)\s*$")
_REV_VALUE_ONLY = re.compile(r"^\s*[A-Za-z0-9]{1,3}\s*$")
_PAGE_HEAD = re.compile(r"^(\d+)페이지")
# '리비전 A'(한글 표제란 라벨)도 — 그 라벨의 세트 쪽이 따로 선 시트로 안 보여 쪽 추가·삭제가 거짓 'Rev 미갱신'이 됐다
# (2026-10-20 PDF 대량 시험 N3, 9건)
_PAGE_REV_LINE = re.compile(r"(?i)(?<![A-Z])REV(?:ISION)?\.?(?:\s*NO\.?)?\s*[:：.]?\s*[A-Z0-9]{1,3}\b"
                            r"|(?:개정|리비전)\s*[:：]?\s*[A-Z0-9]{1,3}\b")


def _sheet_like(v: str) -> bool:
    """시트 번호 칸 값이 도면번호 꼴인가 — 글자와 숫자를 함께 ('E-01'·'S-03'). '1'·'01'·'A'는 쪽 번호."""
    return bool(re.search(r"[A-Za-z]", v) and re.search(r"\d", v))


def page_sheet_ids(doc: Document | None, need_rev: bool = False) -> dict[int, str]:
    """PDF 쪽마다 표제란 도면번호 {쪽: 도면번호} — 쪽 글줄에서 처음 나온 도면번호 줄. PDF가 아니거나 없으면 빈 사전."""
    if doc is None or getattr(doc, "doc_type", "") != "pdf":
        return {}
    # 한 쪽에 서로 다른 도면번호 줄이 여럿이면(표제란 'DWG NO E-503' + 본문 참조 'DWG NO: E-509 (REF.)') 어느 것이 그 쪽의
    # 번호인지 모른다 — 그 쪽은 따로 선 시트로 보지 않는다. 첫 줄만 믿어 이어지는 쪽 추가가 '독립 시트'가 되고 Rev 미갱신이
    # 꺼졌다 (검토69 B S4·C P20)
    # 그 쪽에 표제란 Rev 줄('REV A'·'개정: 0')도 있어야 그 쪽의 표제란이다 — 검사 성적서가 쪽마다 '도면번호: E-10n' 참조 줄을
    # 두면 쪽마다 다른 번호라 세트 시트로 보여 쪽 추가의 Rev 미갱신이 꺼졌다 (검토69 C P20)
    seen: dict[int, set] = {}
    sheet_no: dict[int, set] = {}
    has_rev: set = set()
    prev = None                         # 같은 쪽 바로 앞 줄 (라벨 위·값 아래 칸)
    for t in doc.raw_texts or []:
        m = _PAGE_HEAD.match(str(getattr(t, "where", "") or ""))
        if not m:
            prev = None
            continue
        pg = int(m.group(1))
        txt = str(t.text or "")
        if _PAGE_REV_LINE.search(txt):
            has_rev.add(pg)
        n = _SHEET_NO_LINE.match(txt)
        if n:
            seen.setdefault(pg, set()).add(n.group(1).upper())
        s = _SHEETNO_LINE.match(txt)
        if s and _sheet_like(s.group(1)):
            sheet_no.setdefault(pg, set()).add(s.group(1).upper())
        if prev is not None and prev[0] == pg:
            v = _ID_VALUE.match(txt)
            if v and re.search(r"\d", v.group(1)):
                if _DWG_LABEL_ONLY.match(prev[1]):
                    seen.setdefault(pg, set()).add(v.group(1).upper())
                elif _SHEETNO_LABEL_ONLY.match(prev[1]) and _sheet_like(v.group(1)):
                    sheet_no.setdefault(pg, set()).add(v.group(1).upper())
            if _REV_LABEL_ONLY.match(prev[1]) and _REV_VALUE_ONLY.match(txt):
                has_rev.add(pg)
        prev = (pg, txt)
    out: dict[int, str] = {}
    for p in sorted(set(seen) | set(sheet_no)):
        v = seen.get(p) or sheet_no.get(p)       # 도면번호 줄이 앞선다 — 같은 도면의 시트 번호(S-1·S-2)는 따로 선 도면이 아니다
        if len(v) == 1 and (p in has_rev or not need_rev):
            out[p] = next(iter(v))
    return out


def set_sheet_label(doc: Document | None, pno: int | None) -> str | None:
    """세트 PDF(쪽마다 다른 도면번호)의 그 쪽 이름 'E-702 (세트 2/2쪽)' — 2쪽만 바뀐 날 메일 제목·근거가 첫 시트 'E-701'·'문서'로
    불렀다 (검토71 R4 중간 6). 세트가 아니거나 그 쪽 번호를 모르면 None."""
    if doc is None or pno is None:
        return None
    ids = page_sheet_ids(doc)
    if len(set(ids.values())) < 2 or pno not in ids:
        return None
    pages = [int(m.group(1)) for t in (doc.raw_texts or []) for m in [_PAGE_HEAD.match(str(getattr(t, "where", "") or ""))] if m]
    return f"{ids[pno]} (세트 {pno}/{max(pages + [pno])}쪽)"


def _layout_sheet_ids(doc: Document) -> dict[str, str]:
    """DXF 배치(레이아웃)마다 표제란 도면번호 {배치 이름: 도면번호} — 모델 공간 표제란은 ''."""
    out: dict[str, str] = {}
    for k, f in (getattr(doc, "fields", None) or {}).items():
        if str(k).split("#", 1)[0] != "DWG_NO" or not str(f.value or "").strip():
            continue
        w = str(f.where or "")
        m = re.match(r"^배치 (.+?) (?:다른 )?표제란", w)
        out.setdefault(m.group(1) if m else ("" if not w.startswith("배치") else w), str(f.value).strip().upper())
    return out


def sheet_line_groups(doc: Document | None, lines: list) -> list[list]:
    """태그 줄들을 시트(따로 선 도면)별로 — PDF는 쪽 표제란 도면번호, DXF는 배치(레이아웃)마다의 표제란 도면번호.
    도면번호가 둘 이상 다를 때만 나누고, 아니면 한 묶음. 번호를 모르는 쪽·배치는 제 쪽·배치끼리 묶는다."""
    if not lines:
        return [lines]
    dt = getattr(doc, "doc_type", "") if doc is not None else ""
    groups: dict = {}
    if dt == "pdf":
        ids = page_sheet_ids(doc)
        if len(set(ids.values())) < 2:
            return [lines]
        for ln in lines:
            m = _PAGE_HEAD.match(str(getattr(ln, "where", "") or ""))
            pg_ = int(m.group(1)) if m else 0
            groups.setdefault(ids.get(pg_, f"#{pg_}"), []).append(ln)
        return list(groups.values())
    if dt == "dxf":
        # 배치 두 장(시트마다 표제란·도면번호)인 DXF — 1번 시트의 'M-101 5.5kW'가 BOM과 같다고 2번 시트의 7.5kW까지 일치로
        # 넘겼다 (갈래 A 2026-10-16, adv69 B5·held69 X13). 배치 글줄은 '배치공간 {배치 이름} …'
        ids = _layout_sheet_ids(doc)
        if len(set(ids.values())) < 2:
            return [lines]
        names = sorted((n for n in ids if n), key=len, reverse=True)
        for ln in lines:
            w = str(getattr(ln, "where", "") or "")
            if w.startswith("배치공간 "):
                rest = w[len("배치공간 "):]
                nm = next((n for n in names if rest.startswith(n + " ") or rest == n), None)
                key = ids[nm] if nm is not None else "#" + rest.split(" ", 1)[0]
            else:
                key = ids.get("", "#model")
            groups.setdefault(key, []).append(ln)
        return list(groups.values())
    return [lines]


def independent_sheet(doc: Document | None, pno: int | None) -> bool:
    """그 쪽이 세트 안의 따로 선 도면(시트)인가 — 그 쪽에 도면번호가 있고, 다른 쪽에도 도면번호가 있으며, 그 번호가 다른 쪽과
    겹치지 않을 때."""
    if not pno:
        return False
    ids = page_sheet_ids(doc, need_rev=True)
    if pno not in ids or len(ids) < 2:
        return False
    return ids[pno] not in {v for k, v in ids.items() if k != pno}


def _where_page(where) -> int | None:
    """'표제란(1페이지 13행)'·'2페이지 12행' → 쪽 번호."""
    m = re.search(r"(\d+)\s*페이지", str(where or ""))
    return int(m.group(1)) if m else None


_PG_REV_COLON = re.compile(r"(?<![A-Za-z])(?:REV(?:ISION)?\.?(?:\s*NO\.?)?|개정|리비전)\s*[:：]\s*([A-Za-z0-9]{1,3})(?![A-Za-z0-9])", re.I)


def _page_title_rev(doc: Document | None, page: int) -> str | None:
    """그 쪽 표제란의 Rev — 'PROJECT: HB25-101 REV: C'·'REV: C'·칸 나뉜 'REV   C'·라벨 줄 다음 값 줄. 하나로 정해지지 않으면 None."""
    vals: set = set()
    prev = None
    for t in (getattr(doc, "raw_texts", None) or []):
        m = _PAGE_HEAD.match(str(getattr(t, "where", "") or ""))
        if not m or int(m.group(1)) != page:
            prev = None
            continue
        txt = str(t.text or "")
        for mm in _PG_REV_COLON.finditer(txt):
            vals.add(_rev_norm(mm.group(1)))
        mv = _REV_LINE_VALUE_RE.match(txt)
        if mv and mv.group(1) != "-":
            vals.add(_rev_norm(mv.group(1)))
        if prev is not None and _REV_LABEL_ONLY.match(prev) and _REV_VALUE_ONLY.match(txt):
            vals.add(_rev_norm(txt))
        prev = txt
    return next(iter(vals)) if len(vals) == 1 else None


def _page_number_shift(item) -> bool:
    """쪽 번호 줄('- 3 -'·'Page 2 of 3')이 숫자만 바뀐 글자 변경인가."""
    if getattr(item, "kind", "") != "TEXT_CHANGED":
        return False
    o, n = str(getattr(item, "old", "") or ""), str(getattr(item, "new", "") or "")
    if _PAGE_NO_LINE.match(o) and _PAGE_NO_LINE.match(n) and re.sub(r"\d+", "#", o) == re.sub(r"\d+", "#", n):
        return True
    from watcher.diff import page_mark_norm
    po, pn = page_mark_norm(o), page_mark_norm(n)       # 'SPEC-9304 Page 2/4' → 'Page 4/4'
    return o != n and "#P#" in po and po == pn


_VIS_PT = re.compile(r"^(\d+)페이지 좌표 \((-?\d+(?:\.\d+)?), (-?\d+(?:\.\d+)?)\)")


def _revtable_zones(doc: Document | None, page: int) -> list:
    """그 쪽 개정표(머리 줄 + 붙은 행 줄)의 자리 [(x0, y0, x1, y1)] — 글줄 자리를 아는 PDF 개정표 쪽만."""
    if doc is None or getattr(doc, "doc_type", "") != "pdf":
        return []
    from watcher.diff import _REVTABLE_HEAD, _revtable_cols
    lines = [t for t in (doc.raw_texts or []) if _where_page(getattr(t, "where", "")) == page and getattr(t, "box", None)
             and "OCR" not in str(getattr(t, "where", "") or "")]
    out = []
    for hi, h in enumerate(lines):
        if not (_REVTABLE_HEAD.match(str(h.text or "")) or _revtable_cols(h.text)):
            continue
        hb = h.box
        ch = max(1.0, hb[3] - hb[1])
        x0, y0, x1, y1 = hb
        for step in (1, -1):
            k, prev = hi + step, hb
            while 0 <= k < len(lines):
                b = lines[k].box
                if not (hb[0] - 2 * ch <= b[0] <= hb[2]) or abs((b[1] + b[3]) / 2 - (prev[1] + prev[3]) / 2) > 3 * ch:
                    break
                x0, y0, x1, y1 = min(x0, b[0]), min(y0, b[1]), max(x1, b[2]), max(y1, b[3])
                prev = b
                k += step
        out.append((x0, y0, x1, y1, ch))
    return out


def _revtable_visual(item, items, old, new) -> bool:
    """개정표 행이 더해진 쪽에서 개정표 자리 곁(행 높이 4배·30pt 안)의 그림 변경인가."""
    if getattr(item, "kind", "") != "PAGE_VISUAL_CHANGED" or getattr(new, "doc_type", "") != "pdf":
        return False
    m = _VIS_PT.match(str(getattr(item, "where", "") or ""))
    if not m:
        return False
    pg, x, y = int(m.group(1)), float(m.group(2)), float(m.group(3))
    if not any(getattr(i, "kind", "") == "REVROW_ADDED" and _where_page(getattr(i, "where", "")) == pg for i in items):
        return False
    for x0, y0, x1, y1, ch in _revtable_zones(new, pg) + _revtable_zones(old, pg):
        pad = max(30.0, 4 * ch)
        if x0 - pad <= x <= x1 + pad and y0 - pad <= y <= y1 + pad:
            return True
    return False


def _key_page(item) -> int | None:
    m = re.match(r"^(\d+)페이지", str(getattr(item, "key", "") or ""))
    return int(m.group(1)) if m else None


FOLD_SIZE_CHANGE = True     # 시험용 끔 스위치 (2026-10-23 뒤흔들기 C17)


def check_revision(path: str, old: Document, new: Document,
                   items: list[ChangeItem], visual_checked: bool = True) -> list[Issue]:
    """한 파일의 구/신 쌍에 대한 Rev 일관성.

    visual_checked=False면 그림 비교를 하지 않은 짝이다 — 글자 변경이 없다고 해서
    '내용 동일'이라 단정하지 않는다 (2026-09-02 재검토: 원칙 4·5)."""
    issues = []
    from watcher.diff import is_rev_field
    # 둘째 표제란(배치 시트2 등)의 REV#2 올림도 Rev 올림이다 — 모르면 시트2만 개정한 날 거꾸로 'Rev 미갱신'을
    # 냈다 (검토36 A N2). 첫 표제란 REV가 있으면 그것이 앞선다(필드 이름순)
    rev_change = next((i for i in items if is_rev_field(i)), None)
    content = content_items(items)
    # 페이지 크기만 바뀐 것(같은 도면을 다른 PDF 프린터로 다시 뽑음)은 출력 설정이지 내용 변경이 아니다 — 글자·표제란이
    # 모두 같은데 'Rev 미갱신'이 났다 (검토60 ④). 그림 변경 항목은 그대로 남아 사람이 볼 수 있다
    content = [i for i in content
               if not (getattr(i, "kind", "") == "PAGE_VISUAL_CHANGED" and "페이지 크기 변경" in str(getattr(i, "where", "") or ""))]
    # 워드·한글 문단이 낱말 그대로 자리만 옮긴 것은 순서 변경이다 — 항목에는 '내용은 그대로, 자리만 이동'이라 쓰고 경고는 '내용이
    # 바뀌었는데'라 해 서로 모순이었다 (검토63 A-3, 경우100 B04·C06 결정: 순서만은 Rev 미갱신 근거가 아니다)
    # PDF도 — 줄 순서가 그리는 순서(스트림)라 다시 뽑기만 해도 바뀐다 (검토66 A1·C4). 모든 형식에서 순서만은 근거가 아니다
    content = [i for i in content if getattr(i, "kind", "") != "TEXT_MOVED"]
    # PDF 개정표에 행이 늘면 표 선(틀)이 함께 길어진다 — 그 그림 변경이 '내용 변경'으로 남아 Rev만 올린 날 'Rev만 갱신'이 침묵했다
    # (2026-10-20 PDF 대량 시험 N10). 개정표 행이 더해진 쪽에서 개정표(머리 줄 + 행) 자리 바로 곁의 그림 변경만 뺀다(항목은 남음)
    content = [i for i in content if not _revtable_visual(i, items, old, new)]
    # 쪽 순서를 바꾼 판의 쪽 번호 바닥글('- 3 -' → '- 2 -'·'Page 2 of 3')은 자리를 따라 바뀐 것이다 — 내용 변경으로 세어 순서만 바꾼
    # 판이 거짓 'Rev 미갱신'이 됐다 (2026-10-20 PDF 대량 시험 N5). 쪽 이동이 함께 잡혔을 때만, 숫자 말고는 같은 쪽 번호 줄만
    if any(getattr(i, "kind", "") == "PAGE_MOVED" for i in items):
        content = [i for i in content if not _page_number_shift(i)]
    # 세트 PDF에 **제 도면번호를 가진 쪽**(시트)이 통째로 들어오거나 나간 것은 다른 시트의 내용 변경이 아니다 — 그 쪽의 Rev는 그
    # 쪽 표제란의 것이고, 첫 쪽 표제란 Rev가 그대로인 건 당연하다. 3장 세트에 4번 장을 더한 날 '내용 변경, Rev 미갱신'이 났다
    # (검토68 B14·B15). 같은 문서번호를 쪽마다 되풀이하는 보고서·사양서의 쪽 추가·삭제는 그 문서의 내용 변경으로 둔다(B43·B44)
    content = [i for i in content
               if not (getattr(i, "kind", "") == "PAGE_ADDED" and independent_sheet(new, _key_page(i)))
               and not (getattr(i, "kind", "") == "PAGE_REMOVED" and independent_sheet(old, _key_page(i)))]
    # 세트 PDF(쪽마다 표제란)에서 1쪽이 아닌 쪽만 개정하면 그 쪽의 'REV: A → REV: B' 줄이 본문 변경으로
    # 남아, 'Rev 미갱신'을 내며 그 줄을 근거로 인용했다 (2회차 B8). 표제란 REV 줄의 변경은 Rev 올림이다
    # 콜론 없는 'REV   B'(칸이 나뉜 CAD 출력 PDF 대부분)도 — 줄 전체가 REV 라벨+값뿐일 때 (3회차 A3)
    _fr = new.fields["REV"].value if "REV" in new.fields else None
    title_rev = [i for i in content
                 if is_page_rev_bump(i.kind, i.old, i.new, getattr(i, "where", ""), getattr(new, "doc_type", "pdf"),
                                     field_rev=_fr)]
    if rev_change is None and title_rev:
        rev_change = title_rev[-1]
        content = [i for i in content if i not in title_rev]
    # 표제란이 OCR 유래고 혼동 문자만 다르면(B↔8) Rev가 바뀐 게 아니다 — `_diff_fields`와 같은 규칙 (리뷰12 중간-C)
    from watcher.diff import same_ocr_value
    # 세트 PDF 쪽 REV 줄에서 온 Rev 올림(old≠new가 확인된 TEXT 항목)에는 이 가드를 대지 않는다 — 1쪽 필드
    # A=A로 참이 되어 스캔 세트의 2쪽 개정이 거짓 'Rev 미갱신'이 됐다 (검토30 B 5-B)
    if rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" \
            and same_ocr_value(old.fields.get(rev_change.key), new.fields.get(rev_change.key)):
        rev_change = None

    from watcher.diff import _blank_rev as _blank
    # Rev가 아직 '-'(첫 발행 전)이면 올릴 Rev가 없다 — 작업본을 고칠 때마다 'Rev가 - 그대로'가 났다 (검토41 S2 중간 4)
    # 시트마다 REV가 있는 통합 문서(REV·REV#2)는 **모두** 비어 있을 때만 '첫 발행 전' — 이름순 첫 시트가 '-'라고 다른
    # 시트(REV B)의 내용 변경에 경고가 사라졌다 (검토42 A 중간 4)
    _revs = [f.value for k, f in (new.fields or {}).items() if str(k).split("#", 1)[0] == "REV"]
    if content and rev_change is None and new.revision is not None and not all(_blank(v) for v in _revs) \
            and not (new.doc_type in ("docx", "hwpx", "xlsx") and _revision_row_added(items)):
        # 메시지에 건수를 넣지 않는다 — 발행 전 작업본을 매일 저장하는 동안
        # 건수만 바뀐 같은 경고가 날마다 재알림되던 문제 (2026-08-26 설계 검토:
        # 같은 내용은 30일 중복 억제에 걸려 브리핑에 1회만 실린다)
        # 문서류(xlsx·docx)의 Rev는 개정이력 시트/표에서 온다 — "표제란"이라 부르면 구매가 BOM 어디를
        # 봐야 할지 몰랐다 (검토25 브리핑 B-1)
        # Rev가 어디서 왔는지 그대로 — 표 위 표제 칸·머리말에서 읽은 Rev까지 '개정이력'이라 불러 없는 시트를 찾게 했다
        # (검토41 S6·검토42 낮음). 보여 줄 Rev는 비지 않은 것 (시트별 REV 가운데)
        _rf = new.fields.get("REV")
        # 사람에게 보이는 이름은 '개정표'·'머리글 Rev'로 하나 — 개정이력·리비전 블록·리비전 행·머리글 REV가 섞였다 (검토71 R4 중간 4)
        where_ = ("개정표" if _rf is not None and "개정이력" in str(_rf.where or "")
                  else "바닥글" if _rf is not None and str(_rf.where or "").startswith("바닥글")   # 검토47 C 낮음
                  else "머리글" if _rf is not None and str(_rf.where or "").startswith("머리글")
                  else "표제란" if new.doc_type not in ("xlsx", "docx", "hwpx") else "문서 머리")
        _shown = next((v for v in _revs if not _blank(v)), new.revision)
        ev = [f"{where_} {'REV' if where_ == '표제란' else 'Rev'}: {_shown} (변경 전후 동일)",
              (f"이번 변경 {len(content)}건 중 예시:" if len(content) > 1 else "이번 변경:")]
        ev += [_fmt_item(i) for i in content[:5]]
        issues.append(Issue(
            "CONTENT_CHANGED_REV_SAME", path,
            # 문구는 예전 그대로(이슈 대조 키가 문구 뼈대라, 바꾸면 판 교체 날 열린 이슈가 닫혔다 새로 태어난다 — 2026-09-14)
            # 대조 키는 자리 낱말을 하나로 본다(state.issue_key) — 옛 '개정이력 Rev가' 이슈와 이어진다
            f"내용이 바뀌었는데 {where_ if new.doc_type in ('xlsx', 'docx', 'hwpx') else '표제란'} Rev가 {_shown} 그대로입니다. "
            f"(발행 전 작업본이면 무시하세요 — 발행 시 Rev를 올리면 해소됩니다)",
            tuple(ev)))

    # 페이지 전체가 어긋난 재스캔은 그 쪽의 그림 비교가 무의미해 접었다 — 그걸 '내용 동일'의
    # 근거로 쓰면 안 된다. 1pt 밀린 재스캔에 표를 하나 더해도 "Rev만 갱신, 내용 동일"이 났다
    # (2026-09-09 비교 검토). 접힌 쪽이 있으면 이 판정은 하지 않는다.
    # 쪽 크기가 바뀌어 그림을 겹쳐 비교하지 못한 쪽도 같다 — 그 쪽의 그림만 바뀐 편집을 못 보고 'Rev만 갱신(글자 변경 없음)'을
    # 단정했다 (2026-10-23 뒤흔들기 C17). 맞춰 비교할 수 있었던 쪽은 '페이지 크기 변경'이 나오지 않는다(capture 쪽 맞춤)
    # 도면 전체 이동·배율만 바뀐 DXF를 제 범위로 다시 그려 견준 것('제 범위로 다시 견줌')은 접은 게 아니라 비교한 것이다 (뒤흔들기 DXF C5)
    folded = any(i.kind == "PAGE_VISUAL_CHANGED"
                 and (("전체가 살짝 어긋남" in str(i.where or "") and "제 범위로 다시 견줌" not in str(i.where or ""))
                      or (FOLD_SIZE_CHANGE and "페이지 크기 변경" in str(i.where or "")))
                 for i in items)
    from watcher.diff import _blank_rev
    # 빈칸·'-' → A만 채운 날(첫 발행)은 'Rev만 올라갔는데 글자 변경 없음'이 아니다 (검토38 R1 중간 3)
    first_issue = rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" \
        and _blank_rev(rev_change.old)
    # 도면명(표제란 TITLE 칸)이 바뀌었으면 '글자 변경 없음'이 아니다 — 개정하며 도면명을 고친 도면에 거짓
    # 'Rev만 갱신' (검토38 R4 08)
    from watcher.diff import field_base
    title_changed = any(getattr(i, "kind", "") == "FIELD_CHANGED" and field_base(getattr(i, "key", "")) in ("TITLE", "SCALE", "SHEET", "UNIT", "SIZE")
                        for i in items)          # 축척을 바꾼 개정도 '글자 변경 없음'이 아니다 (검토42 B T04)
    # 매수·단위·용지(표제란 META 칸, 2026-10-28 B2부터 보고)도 축척과 같은 급이다
    # Rev가 **거꾸로** 갔다(B→A) — 옛 판으로 덮어쓴 흔적이다. 같은 모양의 Rev끼리만 견준다(P1→A 같은 예비→발행은
    # 모양이 달라 여기 안 걸린다). 서버를 통째로 되돌린 날 Rev B→A인 파일 5개에 아무 말이 없었다 (검토42 D 중간 1)
    regressed = False
    if rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" and not first_issue:
        from watcher.scan import rev_key, rev_shape
        ro, rn = str(rev_change.old or "").strip(), str(rev_change.new or "").strip()
        if ro and rn and not _blank(ro) and not _blank(rn) and rev_shape(ro) and rev_shape(ro) == rev_shape(rn) \
                and rev_key(rn) < rev_key(ro):
            regressed = True
            issues.append(Issue(
                "REV_REGRESSED", path,
                f"Rev가 {ro}→{rn}로 거꾸로 갔습니다. 옛 판으로 덮어썼는지 확인하세요.",
                (f"표제란 REV: {ro} → {rn} ({rev_change.where})",
                 f"이번 변경 {len(content)}건" if content else "글자·표 변경 없음 — 옛 판 파일을 그대로 되살렸을 수 있습니다")))
    # 쪽·행·열 순서만 바뀐 개정(도면 세트 시트 순서 정리 + Rev 올림)은 '글자 변경 0건'이 아니다 — 순서를 내용에서
    # 뺀 뒤 거짓 'Rev만 갱신' 경고가 새로 났다 (검토53 A 중간 5)
    from watcher.diff import ORDER_KINDS
    reordered = any(getattr(i, "kind", "") in ORDER_KINDS for i in items)
    # 예비 Rev → 발행(P1→A)은 체계가 바뀐 첫 발행이다 — 'Rev만 갱신'으로 경고했다 (검토58 F2 C05)
    shape_changed = False
    # 리비전 블록에 그 Rev 행이 **이미** 적혀 있으면(앞선 검사에서 행을 적고 이번에 표제란을 맞춤) 정상 개정이다 —
    # '표제란 Rev≠리비전 블록' 안내대로 표제란을 고친 날 'Rev만 갱신'이 새로 났다 (검토58 F2 D08)
    already_claimed = False
    if rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED":
        from watcher.scan import rev_shape as _rs
        _ro, _rn = str(rev_change.old or "").strip(), str(rev_change.new or "").strip()
        shape_changed = bool(_ro and _rn and _rs(_ro) and _rs(_rn) and _rs(_ro) != _rs(_rn))
        # 이번 변경에서 그 행을 함께 적은 것은 아니다 — 행만 더하고 내용은 그대로인 개정은 여전히 'Rev만 갱신'이다(stage3 실수2)
        _added_now = any((getattr(i, "kind", "") == "REVROW_ADDED"
                          or (getattr(i, "kind", "") == "ROW_ADDED" and str(getattr(i, "where", "") or "").endswith("(개정이력)")))
                         and _rev_norm(getattr(i, "key", "")) == _rev_norm(_rn)
                         for i in items)
        # PDF 개정표 행·워드/한글 '(개정이력)' 표 행도 — revision_history만 보아, 도구가 '개정표에 B 행을 적고 표제란 Rev를 올리지
        # 않았을 수 있습니다'라 한 다음 날 안내대로 표제란만 올리면 'Rev만 갱신'이 새로 났다 (검토20 r12 2)
        _claim_rows = list(new.revision_history or [])
        if new.doc_type in ("docx", "hwpx") and not _claim_rows:
            _claim_rows = _doc_revlog_rows(new)
        elif new.doc_type == "pdf":
            from watcher.diff import pdf_revtable_rows
            _claim_rows += [_base.Row(s, {"DESCRIPTION": rest}, w) for _pg, s, _d, rest, w in pdf_revtable_rows(new)]
        already_claimed = bool(_rn) and not _added_now and any(
            _rev_norm(r.key) == _rev_norm(_rn) and str((r.values or {}).get("DESCRIPTION") or "").strip()
            for r in _claim_rows)
    if rev_change is not None and not content and visual_checked and not folded and not first_issue \
            and not title_changed and not regressed and not reordered and not shape_changed and not already_claimed:
        _rw = str(rev_change.where or "")
        _rp = next((p_ for p_ in ("머리글", "바닥글", "머리말") if _rw.startswith(p_)), None)
        # 머리글에서 읽은 Rev를 '표제란 REV: A → B (머리글(1째 줄))'이라 불렀다 (검토71 R4 중간 4). 워드 본문 머리('머리말(문단 2)')도
        # '표제란'이 아니다 — 문서 머리 (검토20 r12 2 덤)
        _rpn = "문서 머리" if _rp == "머리말" else _rp
        ev = [(f"{_rpn} Rev: {rev_change.old} → {rev_change.new} ({_rw[len(_rp):].strip(' ()') or _rpn})" if _rp
               else f"표제란 REV: {rev_change.old} → {rev_change.new} ({_rw})")]
        # 워드·한글에 '행·셀 변경: 0건'은 엉뚱했다 — 메시지가 이미 '글자 변경이 없습니다'라 말한다 (검토71 R4 낮음 12)
        if new.doc_type == "xlsx":
            ev.append("행·셀 변경: 0건 — 개정표 기재만 추가된 것이면 정상입니다")
        elif new.doc_type not in ("docx", "hwpx"):
            ev.append("글자·표 변경: 0건 — 형상(선·도형)만 바뀐 정상 개정일 수 있습니다"
                      " (그림 변경은 텍스트 비교에 잡히지 않습니다)")
        # 워드·한글 개정이력 표의 새 행도 개정표 기재다(diff.content_items가 내용에서 뺌 — 대량 시험 DOC C2)
        claimed = [i for i in items if i.kind == "REVROW_ADDED"
                   or (i.kind == "ROW_ADDED" and str(i.where or "").endswith("(개정이력)"))]
        ev += [f"개정표 기재: {_fmt_item(i)}" for i in claimed[:2]]
        issues.append(Issue(
            "REV_CHANGED_CONTENT_SAME", path,
            f"Rev가 {rev_change.old}→{rev_change.new}로 올라갔는데 글자 변경이 없습니다.",
            tuple(ev)))
    blk = rev_block_mismatch(new, path)
    if blk is not None:
        issues.append(blk)
    issues += rev_rows_duplicate(new, path)
    # 문서류: 개정이력 표에 새 Rev 행(B)을 적고 머리글·표지 Rev(A)는 그대로 — 행 추가가 'Rev 미갱신'을 막아 아무 말도
    # 없었다 (검토53 B D09). 도면의 '표제란 Rev ≠ 리비전 블록'과 같은 경고로
    if blk is None and rev_change is None and new.doc_type in ("docx", "hwpx") and "REV" in (new.fields or {}):
        added = _revision_row_rev(items)
        cur = new.fields["REV"].value
        from watcher.scan import rev_key, rev_shape
        # 같은 모양이고 **더 새** Rev일 때만 — 도면 목록 표(DWG NO|TITLE|REV)에 Rev 0 행을 더한 것, 개정이력 가운데 옛 행을
        # 끼운 것까지 '머리글 Rev 그대로'라 했다 (검토53 E 중간 5)
        newer = bool(added) and not _blank(cur) and rev_shape(_rev_norm(added)) is not None \
            and rev_shape(_rev_norm(added)) == rev_shape(_rev_norm(cur)) \
            and rev_key(_rev_norm(added)) > rev_key(_rev_norm(cur))
        if newer:
            added = _rev_norm(added)
            _w = str(new.fields["REV"].where or "")
            place = "머리글" if _w.startswith("머리글") else "바닥글" if _w.startswith("바닥글") else "문서 머리"
            issues.append(Issue(
                "REV_BLOCK_MISMATCH", path,
                f"개정표에 Rev {added} 행이 추가됐는데 {place} Rev는 {cur} 그대로입니다.",
                (f"{place} Rev: {cur} ({_w[len(place):].strip(' ()') if _w.startswith(place) else _w})",
                 f"개정표 추가 행: Rev {added}")))
    # PDF 도면: 개정표에 새 Rev 행(B)을 적고 표제란 REV(A)는 그대로 — PDF는 개정표를 따로 읽지 않아(리비전 블록 없음) 위의
    # rev_block_mismatch가 늘 침묵했다 (검토68 B32). 이번에 더해진 개정표 행(REVROW_ADDED)의 Rev가 같은 모양에 **더 새** 것일 때만
    if blk is None and rev_change is None and new.doc_type == "pdf" and "REV" in (new.fields or {}):
        from watcher.scan import rev_key, rev_shape
        cur = _rev_norm(new.fields["REV"].value)
        added_rows = [i for i in items if getattr(i, "kind", "") == "REVROW_ADDED"]
        # 여러 쪽 세트 PDF는 쪽(시트)마다 표제란·개정표가 있다 — 2쪽 개정표에 B행을 더하고 2쪽 표제란을 B로 올린 정상 개정을
        # 1쪽 표제란 A와 견줘 거짓 '표제란 Rev ≠ 개정표'가 났다 (구매 평가 2차 P2 day6·9). 다른 쪽의 행은 그 쪽 표제란 Rev와만
        # 견주고, 그 쪽 Rev를 못 읽으면 말하지 않는다
        _fp = _where_page(new.fields["REV"].where)
        # 표제란이 1쪽에만 있는 여러 쪽 문서(개정표가 끝 쪽)는 예전처럼 문서 표제란과 견준다 — 세트(쪽마다 다른 도면번호)일 때만 침묵
        _pg_rev: dict = {}
        _is_set = len(set(page_sheet_ids(new).values())) >= 2
        for i in added_rows:
            _rp = _where_page(getattr(i, "where", ""))
            if _fp is not None and _rp is not None and _rp != _fp:
                _own = _page_title_rev(new, _rp)
                if _own is not None or _is_set:
                    _pg_rev[id(i)] = _own
        def _cur_of(i):
            return _pg_rev[id(i)] if id(i) in _pg_rev else cur
        newer = [i for i in added_rows
                 if _cur_of(i) and not _blank(_cur_of(i)) and rev_shape(_rev_norm(i.key)) is not None
                 and rev_shape(_rev_norm(i.key)) == rev_shape(_cur_of(i)) and rev_key(_rev_norm(i.key)) > rev_key(_cur_of(i))]
        if newer:
            top = max(newer, key=lambda i: rev_key(_rev_norm(i.key)))
            _w = str(new.fields["REV"].where or "")
            _tc = _cur_of(top)
            if id(top) in _pg_rev:
                _w = f"표제란({_where_page(top.where)}페이지)"
            issues.append(Issue(
                "REV_BLOCK_MISMATCH", path,
                f"표제란 Rev와 개정표의 최신 행이 다릅니다 (표제란 {_tc} · 개정표 {_rev_norm(top.key)}).",
                (f"표제란 REV: {_tc if id(top) in _pg_rev else new.fields['REV'].value} · 위치 {_w}",
                 f"개정표에 이번에 추가된 행: {top.new} · 위치 {top.where}",
                 f"개정표에 {_rev_norm(top.key)} 행을 적고 표제란 Rev를 올리지 않았을 수 있습니다")))
    # PDF 도면: 표제란 Rev만 올리고(B→C) 개정표에는 C 행이 없다 — DXF는 리비전 블록과 견줘 말하는데 PDF는 침묵해, 내용까지 바꾼
    # 날은 아무 말이 없었다 (검토20 r12 7). 개정표가 옛 표제란 Rev 행을 품을 때만(그래야 그 표가 이 표제란의 개정표다), 세트 PDF는 말하지 않는다
    # 내용까지 바꾼 날은 아직 말하지 않는다 — 고정 벤치 adv71 F71_12(열마다 그린 개정표 + 표제란 B→C + 본문 변경)가 이 경고를
    # 기대하지 않아 나빠짐이 됐다(벤치 기준값을 바꾸지 않는 원칙). 글자 변경 없는 날만('Rev만 갱신'과 함께 DXF와 같은 문구)
    if blk is None and rev_change is not None and getattr(rev_change, "kind", "") == "FIELD_CHANGED" and not content \
            and new.doc_type == "pdf" and not regressed and not first_issue and "REV" in (new.fields or {}) \
            and len(set(page_sheet_ids(new).values())) < 2:
        from watcher.diff import pdf_revtable_rows
        from watcher.scan import rev_key, rev_shape
        _ro, _rn = _rev_norm(rev_change.old), _rev_norm(rev_change.new)
        _fp = _where_page(new.fields["REV"].where)
        _rows = [r for r in pdf_revtable_rows(new) if _fp is None or _where_page(r[4]) in (None, _fp)]
        _syms = [r[1] for r in _rows]
        if _ro and _rn and not _blank(_rn) and _ro in _syms and _rn not in _syms and len(set(_syms)) == len(_syms) \
                and rev_shape(_rn) is not None:
            _same = [r for r in _rows if rev_shape(r[1]) == rev_shape(_rn)]
            if _same:
                _top = max(_same, key=lambda r: rev_key(r[1]))
                if rev_key(_rn) > rev_key(_top[1]):
                    issues.append(Issue(
                        "REV_BLOCK_MISMATCH", path,
                        f"표제란 Rev와 개정표의 최신 행이 다릅니다 (표제란 {_rn} · 개정표 {_top[1]}).",
                        (f"표제란 REV: {rev_change.old} → {rev_change.new} · 위치 {new.fields['REV'].where}",
                         f"개정표에서 읽은 최신 행: {_top[1]}"
                         + (f" · {_top[2]}" if _top[2] else "") + (f" · {_top[3]}" if _top[3] else "") + f" · 위치 {_top[4]}",
                         f"Rev를 {_rn}로 올리면서 개정표에 {_rn} 행을 적지 않았을 수 있습니다")))
    return issues


def _ymd(s) -> tuple | None:
    """일자 칸 글 → (년, 월, 일). 2026-10-01 · 2026.10.1 · 26.10.01 · 2026년 10월 1일 · 10/01/2026 · 20261001. 못 읽으면 None."""
    t = str(s or "").strip()
    m = re.search(r"(\d{4})\s*[-./년]\s*(\d{1,2})\s*[-./월]\s*(\d{1,2})", t)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    elif (m := re.search(r"(?<!\d)(\d{1,2})/(\d{1,2})/(\d{4})(?!\d)", t)):
        y, mo, d = int(m.group(3)), int(m.group(1)), int(m.group(2))
    elif (m := re.search(r"(?<!\d)'?(\d{2})[-./](\d{1,2})[-./](\d{1,2})(?!\d)", t)):
        y, mo, d = 2000 + int(m.group(1)), int(m.group(2)), int(m.group(3))
    elif (m := re.fullmatch(r"(\d{4})(\d{2})(\d{2})", t)):
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        return None
    return (y, mo, d) if 1950 <= y <= 2099 and 1 <= mo <= 12 and 1 <= d <= 31 else None


def _row_date(row) -> str:
    return next((str(v or "") for k, v in (getattr(row, "values", None) or {}).items()
                 if re.search(r"DATE|일자|날짜|개정일", str(k), re.I)), "")


def rev_date_unchanged(path: str, old: Document, new: Document, rev_change, items=()) -> Issue | None:
    """Rev를 올린 판에서 표제란 DATE(또는 개정표 최신 행의 일자)가 이전 판과 같으면 그 사실(문구 + 근거) — Rev만 고치고 일자를 안
    고친 출도본은 현장이 판을 날짜로 가릴 때 옛 판으로 읽힌다 (기능 검토 2026-11-02 J7). 검토 필요 카드가 아니라 그 Rev 올림 변경 행의
    '확인 필요' 표지로 싣는다(cli._revision_issues) — 표제란 DATE를 작성일로 두는 회사도 흔해, 카드로 쌓으면 소음이다. 의미 판단은
    없다(원칙 6): 일자 칸이 없거나 못 읽으면, 거꾸로 간 Rev·첫 발행이면, 일자가 오늘(같은 날 다시 낸 판)이면, 이번에 더한 개정표 행에
    다른 일자가 있으면 내지 않는다. 돌려주는 Issue는 문구·근거를 담는 그릇이다(코드 REV_DATE_SAME은 이슈로 저장하지 않는다)."""
    from watcher.diff import _blank_rev
    from watcher.scan import rev_key, rev_shape
    if rev_change is None or getattr(rev_change, "kind", "") != "FIELD_CHANGED":
        return None
    key = str(getattr(rev_change, "key", "") or "")
    base, sep, suf = key.partition("#")
    if base != "REV" or _blank_rev(rev_change.old) or _blank_rev(rev_change.new):
        return None
    ro, rn = _rev_norm(rev_change.old), _rev_norm(rev_change.new)
    if not ro or not rn or ro == rn:
        return None
    if rev_shape(ro) is not None and rev_shape(ro) == rev_shape(rn) and rev_key(rn) < rev_key(ro):
        return None                                   # 거꾸로 간 Rev는 'Rev가 거꾸로 감'이 말한다
    today = datetime.now().date()

    def _same_old_day(a, b) -> str | None:
        ya, yb = _ymd(a), _ymd(b)
        if ya is None or yb is None or ya != yb:
            return None
        try:
            if date(*yb) >= today:
                return None                           # 오늘(또는 앞날) 일자 — 같은 날 다시 낸 판일 수 있다
        except ValueError:
            return None
        return str(b).strip()
    dk = "DATE" + (sep + suf if sep else "")
    fo, fn = (old.fields or {}).get(dk), (new.fields or {}).get(dk)
    # 이번에 개정표에 새 행을 더했고 그 행에 이전 판과 다른 일자가 있으면 개정 일자는 고친 것이다 — 머리말 DATE는 작성일이라 그대로
    # 두는 사양서가 흔하다(고정 벤치 pdf68 B45·B48·B49: 바닥글 REV A→B, 개정표 'REV B · 2026-10-08', 머리 DATE 2026-09-15)
    _new_row_days = {_ymd(m.group(0)) for i in items or () if getattr(i, "kind", "") in ("REVROW_ADDED", "ROW_ADDED")
                     for m in [re.search(r"\d{4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}|'?\d{2}[-./]\d{1,2}[-./]\d{1,2}",
                                         str(getattr(i, "new", "") or ""))] if m} - {None}
    if fo is not None and fn is not None:
        d_ = _same_old_day(fo.value, fn.value)
        if d_ and _new_row_days and _ymd(fn.value) not in _new_row_days:
            return None
        if d_:
            return Issue("REV_DATE_SAME", path,
                         f"Rev {ro}→{rn}로 올렸지만 표제란 일자는 그대로입니다 ({d_}).",
                         (f"표제란 REV: {rev_change.old} → {rev_change.new} ({rev_change.where})",
                          f"표제란 DATE: {fo.value} → {fn.value} (변경 전후 동일, {fn.where})",
                          "일자 칸을 새 Rev의 날짜로 고쳤는지 확인하세요"))
        return None                                   # 표제란 일자가 있으면 그것이 기준이다
    # 표제란에 일자 칸이 없으면 개정표 최신 행의 일자 — 새 Rev 행을 더하며 앞 행의 일자를 그대로 둔 것

    def _latest(doc):
        rows = [r for r in (getattr(doc, "revision_history", None) or []) if _ymd(_row_date(r))]
        same = [r for r in rows if rev_shape(_rev_norm(r.key)) is not None and rev_shape(_rev_norm(r.key)) == rev_shape(rn)]
        return max(same, key=lambda r: rev_key(_rev_norm(r.key))) if same else None
    lo, ln = _latest(old), _latest(new)
    if lo is None or ln is None or _rev_norm(ln.key) != rn or _rev_norm(lo.key) == rn:
        return None
    d_ = _same_old_day(_row_date(lo), _row_date(ln))
    if not d_:
        return None
    return Issue("REV_DATE_SAME", path,
                 f"Rev {ro}→{rn}로 올렸지만 개정표 최신 행의 일자는 그대로입니다 ({d_}).",
                 (f"표제란 REV: {rev_change.old} → {rev_change.new} ({rev_change.where})",
                  f"개정표 최신 행: 이전 판 {_rev_norm(lo.key)} {_row_date(lo)} ({lo.where}) → 이번 판 {rn} {_row_date(ln)} ({ln.where})",
                  "새 Rev 행의 일자를 고쳤는지 확인하세요"))


# 개정이력 표의 날짜 칸 — ISO 말고도 국내에서 흔한 꼴: '26.10.01, 26.10.01, 2026년 10월 1일, 10/01/2026 (검토53 I 중간 4)
_RowDate = re.compile(r"^\s*(?:'?\d{2}[.\-/]\d{1,2}[.\-/]\d{1,2}|\d{4}\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일|\d{1,2}/\d{1,2}/\d{4})\s*$")


_NOT_REVLOG_COLS = {"DWGNO", "DRAWINGNO", "DWG", "도면번호", "TITLE", "제목", "도면명", "품번", "PARTNO", "PN", "TAG",
                    "SHEET", "QTY", "수량"}


def _revision_row_rev(items) -> str | None:
    """개정이력 표에 새로 생긴 행의 Rev 값 (여럿이면 마지막)."""
    import ast
    out = None
    for i in items:
        if getattr(i, "kind", "") != "ROW_ADDED":
            continue
        try:
            d = ast.literal_eval(str(i.new or ""))
        except (ValueError, SyntaxError):
            continue
        # 개정이력 행다운 것만 — 날짜 칸이 실제 날짜인 행. 도면 목록·자재 표(DWG NO·TITLE·품번·TAG 열)는 날짜 칸이 있어도
        # 아니다 (검토53 J 중간 3)
        if isinstance(d, dict) and any(re.sub(r"[\s._/]", "", str(k)).upper() in _NOT_REVLOG_COLS for k in d):
            continue
        if isinstance(d, dict) and any(_plausible_date(v) or _RowDate.search(str(v or "")) for v in d.values()):
            for k, v in d.items():
                if re.sub(r"[\s.]", "", str(k)).upper() in ("REV", "REVISION", "REVNO", "개정", "개정번호", "판") \
                        and str(v or "").strip():
                    out = str(v).strip()
    return out


def _plausible_date(s: str) -> bool:
    """리비전 행 날짜 칸이 실제 날짜인가 — 2026-10-01 · 2026.10.1 · 20261001 · 261001. 품번(12345678)·자리표(0000-00-00)는 아님."""
    s = str(s or "").strip()
    m = re.search(r"(\d{4})[-./](\d{1,2})[-./](\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.fullmatch(r"(\d{2}|\d{4})(\d{2})(\d{2})", s)
        if not m:
            return False
        y = int(m.group(1)) + (2000 if len(m.group(1)) == 2 else 0)
        mo, d = int(m.group(2)), int(m.group(3))
    return 1950 <= y <= 2099 and 1 <= mo <= 12 and 1 <= d <= 31


def _rev_norm(v) -> str:
    """'Rev.B'·'REV B'·'Ｂ' → 'B'. 비교용."""
    import unicodedata as _ud
    s = _ud.normalize("NFKC", str(v or "")).strip().upper()
    return re.sub(r"^REV(?:ISION)?[\s.:\-]*", "", s).strip().rstrip(".")   # 'B.' (검토48 B R07d)


def _doc_revlog_rows(doc: Document) -> list:
    """워드·한글 '(개정이력)' 표 행 → Row(Rev, {DATE, DESCRIPTION}) — 날짜 칸이 진짜 날짜인 행만."""
    def _col(r, pat):
        return next((str(v or "") for k, v in (r.values or {}).items() if re.search(pat, str(k), re.I)), "")
    _rl = [r for r in (doc.rows or []) if str(r.where or "").endswith("(개정이력)")]
    rows = [_base.Row(_col(r, r"^\s*(REV(ISION)?\.?\s*(NO\.?)?|개정\s*(번호|차수)?|판|버전|VER(SION)?)\s*$") or r.key,
                      {"DATE": _col(r, r"DATE|일자|날짜|개정일"), "DESCRIPTION": _col(r, r"DESC|내용|사유")}, r.where)
            for r in _rl]
    return [r for r in rows if _plausible_date(r.values["DATE"]) or _RowDate.search(r.values["DATE"])]


_REVLOG_IDENT = {"DWGNO", "DRAWINGNO", "DWG", "도면번호", "도면NO", "문서번호", "DOCNO", "DOCUMENTNO", "품번", "PARTNO", "PN",
                 "TAG", "SHEET", "SHEETNO", "시트", "TITLE", "제목", "도면명", "문서명"}


def rev_rows_duplicate(doc: Document, path: str | None = None) -> list:
    """엑셀 개정이력 시트에 같은 Rev가 **일자가 다른** 두 행 이상이면 Rev마다 Issue 하나 (ux20 buy 6, 2026-11-03).
    두 번째 개정 때 Rev를 올리지 않았거나 행을 잘못 적은 흔적이다 — 맞고 틀림은 사람이 본다(원칙 6), 근거는 두 행의 위치·값(원칙 4).
    같은 일자의 같은 Rev 여러 행은 한 개정의 설명을 여러 줄로 적은 흔한 양식이라 말하지 않는다. 일자를 못 읽는 행도 뺀다.
    도면(DXF·PDF)의 리비전 블록은 틀 여러 장이 한 목록으로 합쳐져 같은 Rev가 흔하므로 보지 않는다(rev_block_mismatch와 같은 이유)."""
    if getattr(doc, "doc_type", "") != "xlsx":
        return []
    from watcher.brief import _fmt_row_values
    from watcher.diff import _blank_rev
    from watcher.extract.xlsx import _REV_COL, _REV_COL_NOT
    groups: dict = {}
    for r in (doc.revision_history or []):
        vals = r.values or {}
        # Rev는 행 이름표(r.key)가 아니라 REV 열 값에서 — REV 열이 없어 키가 내용 열이면 '수량 변경' 두 행을 같은 Rev로 볼 뻔했다
        rv = _rev_norm(next((v for c, v in vals.items()
                             if _REV_COL.match(str(c).strip()) and not _REV_COL_NOT.search(str(c).strip())), ""))
        if not rv or _blank_rev(rv) or len(rv) > 12:
            continue
        day = _ymd(_row_date(r))
        if day is None:
            continue
        sheet = str(r.where or "").split("!", 1)[0]
        # 여러 도면·문서의 개정을 한 시트에 모은 이력(도면번호|REV|일자|내용)은 도면마다 Rev A가 있다 — 그 문서끼리만 견준다
        ident = tuple(str(v).strip() for c, v in vals.items() if re.sub(r"[\s._/]", "", str(c)).upper() in _REVLOG_IDENT)
        groups.setdefault((sheet, ident, rv), []).append((r, day))
    out = []
    for (sheet, _ident, rv), rs in groups.items():
        days = list(dict.fromkeys(d for _, d in rs))
        if len(rs) < 2 or len(days) < 2:
            continue
        shown = " · ".join(_row_date(r).strip() for r, _ in rs[:3])
        ev = [f"Rev {rv} 행: {_fmt_row_values(str(r.values)) or r.key} · 위치 {r.where}" for r, _ in rs[:4]]
        ev.append("뒤 개정 때 Rev를 올리지 않았거나 행을 잘못 적었을 수 있습니다")
        out.append(Issue("REV_ROW_DUPLICATE", path or doc.path,
                         f"개정표에 Rev {rv} 행이 {len(rs)}개 있고 일자가 다릅니다 ({shown}).",
                         tuple(ev)))
    return out


def rev_block_mismatch(doc: Document, path: str | None = None) -> Issue | None:
    """표제란 REV와 리비전 블록의 가장 높은 Rev가 다르면 Issue — Rev를 올리며 블록에 행을 안 적었거나, 블록에 행을
    적고 표제란을 안 고친 도면이다. 둘 다 출력본만 보는 현장이 옛 판 기준으로 일하게 만든다 (구매자 평가 2026-10-04 P3).
    같은 모양의 Rev끼리만 견준다(P1·P2 예비 행과 A 발행은 다른 체계). 개정이력 시트에서 REV를 올린 문서(xlsx)는
    같은 것을 두 번 보는 셈이라 제외."""
    f = (doc.fields or {}).get("REV")
    # 워드·한글은 개정이력 표를 표 행으로 비교하고(추출기가 '(개정이력)' 표시) 리비전 블록이 따로 없다 — 머리글 Rev만 C로 올리고
    # 이력 표 최신 행은 B 그대로여도 아무 말이 없었다 (검토68 D4). 칸 이름이 '개정·일자·개정 내용'이어도 읽는다
    docish = getattr(doc, "doc_type", "") in ("docx", "hwpx") and not doc.revision_history
    if docish:
        rows = _doc_revlog_rows(doc)
    else:
        # 글줄 리비전 행은 날짜가 진짜 날짜일 때만 — 우상단 부품표 '1 12345678 BOLT'가 위치 규칙으로 리비전 행이 되어 '최신 행 3 —
        # 34567890 WASHER'라는 거짓 근거가 났다. 자리표 '0000-00-00'도 (검토48 B R17·R15e). 블록 속성 행은 날짜 칸이 비어도 행이다
        rows = [r for r in (doc.revision_history or [])
                if ("블록 속성" in str(r.where or "") and any(str(v or "").strip() for v in (r.values or {}).values()))
                or _plausible_date(str((r.values or {}).get("DATE") or ""))]   # 속성 행도 날짜·설명이 빈 자리 행(미리 적힌 A~D)은 아님 (검토48 A 중간 3)
    if f is None or not rows:
        return None
    if re.search(r"개정이력|리비전|표제란 밖", str(f.where or "")):    # 본문 구름 글자 'REV 2'는 표제란이 아니다 (검토48 A 낮음 4)
        return None
    from watcher.diff import _blank_rev
    from watcher.scan import rev_key, rev_shape
    t = _rev_norm(f.value)
    sh = rev_shape(t)
    if _blank_rev(t) or sh is None:
        return None
    keys = [_rev_norm(r.key) for r in rows]
    # 같은 Rev 행이 둘 이상이면 블록 여러 개(배치 시트마다·한 모델에 틀 두 장)가 한 목록으로 합쳐진 것이다 — 첫 틀의 REV를 다른
    # 틀의 블록과 견줘 거짓 경고가 났다 (검토48 B R13·R16). 어느 행이 어느 틀 것인지 모르면 말하지 않는다
    if len(set(keys)) != len(keys):
        return None
    # 나란히 놓인 틀 두 장의 행이 한 줄로 붙으면 설명 칸에 'A 2026-09-01 FIRST ISSUE'가 또 들어 있다 — 둘째 틀의 표제란은 아예 안
    # 읽혀 첫 틀 REV A와 둘째 틀 블록 B를 견줬다 (검토48 B R16)
    if any(re.search(r"\d{4}[-./]\d{1,2}[-./]\d{1,2}", str((r.values or {}).get("DESCRIPTION") or "")) for r in rows):
        return None
    # 'B'와 'B1'처럼 표제란 Rev로 시작하는 다른 꼴 행이 있으면 체계가 섞인 블록이다 — 눈앞의 B1 행을 두고 'B 행을 적지 않았다'고
    # 했다 (검토48 B R08c)
    if any(k != t and k.startswith(t) for k in keys):
        return None
    same = [(r, k) for r, k in zip(rows, keys) if rev_shape(k) == sh]
    if not same:
        return None
    top_row, top = max(same, key=lambda rv: rev_key(rv[1]))
    # 시트마다 표제란이 있으면(REV·REV#2…) 어느 하나라도 블록 최신 행과 같으면 그 시트의 블록이다 (검토48 B R13)
    titles = {_rev_norm(v.value) for k_, v in (doc.fields or {}).items() if str(k_).split("#", 1)[0] == "REV"}
    # 틀마다 따로 읽은 도면(DXF 모델 공간 틀 여럿)의 개정표는 첫 틀 것이다 — 첫 틀 REV와만 견준다(뒤흔들기 DXF C4, 2026-10-23)
    if all(str(r.where or "").startswith("첫 틀 ") for r in rows):
        titles = {t}
    if rev_key(top) == rev_key(t) or any(rev_shape(x) == sh and rev_key(x) == rev_key(top) for x in titles):
        return None
    vals = top_row.values or {}
    desc = " ".join(str(vals.get(k) or "") for k in ("DATE", "DESCRIPTION")).strip()
    if docish:
        # 반대 방향(이력 행만 더하고 머리글 그대로)은 check_revision의 문서류 규칙이 그날의 행 추가로 말한다 — 여기선 머리글이
        # 더 새 Rev일 때만 (검토68 D4)
        if not rev_key(t) > rev_key(top):
            return None
        _w = str(f.where or "")
        place = "머리글" if _w.startswith("머리글") else "바닥글" if _w.startswith("바닥글") else "문서 머리"
        return Issue(
            "REV_BLOCK_MISMATCH", path or doc.path,
            f"{place} Rev와 개정표의 최신 행이 다릅니다 ({place} {t} · 개정표 {top}).",
            (f"{place} Rev: {f.value} · 위치 {_w}",
             f"개정표에서 읽은 최신 행: {top_row.key}{(' — ' + desc) if desc else ''} · 위치 {top_row.where}",
             f"Rev를 {t}로 올리면서 개정표에 {t} 행을 적지 않았을 수 있습니다"))
    hint = (f"Rev를 {t}로 올리면서 개정표에 {t} 행을 적지 않았을 수 있습니다"
            if rev_key(t) > rev_key(top) else
            f"개정표에 {top} 행을 적고 표제란 Rev를 올리지 않았을 수 있습니다")
    return Issue(
        "REV_BLOCK_MISMATCH", path or doc.path,   # 스냅샷 키 — doc.path는 추출 때의 절대 경로라 다음 검사에 '파일이 삭제됨'으로 닫혔다 (검토48 A 차단 1)
        # 값은 괄호 안 — 이슈 대조 키가 괄호 밖 문구만 본다(값이 바뀌어도 같은 이슈로 이어지게)
        f"표제란 Rev와 개정표의 최신 행이 다릅니다 (표제란 {t} · 개정표 {top}).",
        # 위치가 이미 '표제란(…)'이라 괄호로 또 싸면 '표제란 REV: B (표제란(레이어 …))'로 겹쳤다 (검토48 C 낮음 8)
        (f"표제란 REV: {f.value} · 위치 {f.where}",
         f"개정표에서 읽은 최신 행: {top_row.key}{(' — ' + desc) if desc else ''} · 위치 {top_row.where}",
         hint))


class _Occ(NamedTuple):
    """한 도면에서 태그가 등장한 지점 (사양 토큰 + 근거)."""
    spec: str
    text: str
    path: str
    where: str
    dwg_no: str
    shown: str = ""      # 근거에 싣는 원문 (금액·수량을 걷어 낸 비교용 글이 text와 다를 때)


# ── 금액·수량은 사양 값이 아니다 (구매 평가 2차 F1, 2026-10-19)
# 견적서 줄 '벨트컨베이어 CV-1 1 18,500,000 18,500,000'의 수량 1·금액 18,500,000을 사양 값으로 읽어 첫날 거짓 '도면 간 태그 사양
# 불일치 (1 vs W600)'·'도면-BOM 불일치'가 12건 났다. 줄 단위: 돈 줄(통화 표시·금액 머리 낱말·큰 금액)의 금액 꼴 토큰은 어느
# 문서에서든 뺀다. 문서 단위: 상거래 문서(doctype.commercial_kind)는 금액 꼴과 함께 맨 숫자(수량·단가)와 수량 단위 토큰
# (2EA·1식·3대)도 뺀다. 단위 붙은 사양 값(7.5kW·1000L·100AT)과 재질 낱말은 남겨 그대로 견준다 — 견적 사양이 도면과 다르면
# (견적 'M-101 7.5kW', 도면 11kW) 진짜 불일치다(구매가 틀린 모터를 산다). 도면의 부품표 수량 칸은 손대지 않는다(돈 줄이 아니면).
_TOK_MONEY = re.compile(r"^[(\[]?(?:₩|￦|\$|KRW|USD)?\d{1,3}(?:,\d{3})+(?:\.\d+)?(?:원|KRW|USD)?[)\]]?$", re.I)
_TOK_CURRENCY = re.compile(r"^(?:[₩￦$]\s*\d[\d,]*(?:\.\d+)?|\d[\d,]*(?:\.\d+)?(?:원|만원|천원|억원)|원|KRW|USD|[₩￦$])[)\].,]?$", re.I)
_TOK_BARE_NUM = re.compile(r"^[(\[]?\d+(?:[.,]\d+)?[)\]]?$")
_TOK_QTY = re.compile(r"^\d+(?:\.\d+)?(?:EA|SETS?|PCS?|LOTS?|식|式|대|개|본|조|세트|롯트|매|장|EA\.)$", re.I)
_QTY_WORD = re.compile(r"^(?:EA|SETS?|PCS?|LOTS?)\.?$", re.I)


def strip_commerce(text: str, commercial: bool = False) -> str:
    """사양 비교용 글 — 돈 줄의 금액 토큰(상거래 문서면 수량·단가 맨 숫자와 수량 단위까지)을 뺀다. 바뀐 게 없으면 원문 그대로."""
    from watcher.doctype import money_head_line, money_line
    s = str(text or "")
    money = commercial or money_line(s) or money_head_line(s)
    toks = s.split()
    keep = []
    for k, t in enumerate(toks):
        if _TOK_CURRENCY.match(t):
            continue
        if money and _TOK_MONEY.match(t):
            continue
        # '7.5 kW'처럼 단위가 떨어져 따라오는 수는 사양 값이다 — 맨 숫자로 지우지 않는다
        unit_next = k + 1 < len(toks) and _UNIT.match(toks[k + 1]) is not None \
            and not _QTY_WORD.match(toks[k + 1])
        if commercial and ((_TOK_BARE_NUM.match(t) and not unit_next) or _TOK_QTY.match(t) or _QTY_WORD.match(t)):
            continue
        keep.append(t)
    return s if len(keep) == len(toks) else " ".join(keep)


def _commerce_tag_map(occ: dict, commercial: bool) -> dict:
    """tag_occurrences()의 줄들을 비교용 글로 — 바뀐 줄은 새 TextLine(원문은 _raw 속성)."""
    out: dict = {}
    for tag, lines in occ.items():
        new_lines = []
        for ln in lines:
            t2 = strip_commerce(ln.text, commercial)
            if t2 != ln.text:
                nl = _base.TextLine(t2, ln.where, getattr(ln, "box", None))
                object.__setattr__(nl, "_raw", _raw_text(ln))      # 접은 줄이면 그 원문 (재검토 2026-10-28)
                ln = nl
            new_lines.append(ln)
        out[tag] = new_lines
    return out


_ROW_WHERE = re.compile(r"^(\d+)페이지 (\d+)행$")


def tag_lines_with_specs(doc: Document) -> dict:
    """tag_occurrences()에 PDF의 '태그만 든 줄 + 바로 아래 사양 줄' 짝을 한 줄로 — 출도 PDF가 'MCCB-04'(8행)·'100AF 100AT 3P'(9행)를
    따로 그리면 태그 줄에 값이 없어, 도면-BOM 불일치 근거의 도면 값이 개정표 행 문구('B 2026-10-09 MCCB-04 트립 100AT 상향')로
    나왔다 (구매 평가 2차 P2 day5·9). 짝은 좁게: 같은 쪽 바로 다음 행, 태그 줄은 태그 하나뿐, 다음 줄은 태그·콜론·날짜가 없고
    단위 붙은 값이 있을 때만. DXF는 글자 순서가 자리 순서가 아니라 하지 않는다."""
    occ = doc.tag_occurrences()
    if getattr(doc, "doc_type", "") != "pdf":
        return occ
    texts = list(doc.raw_texts or [])
    for k, ln in enumerate(texts[:-1]):
        tags = find_tags(ln.text)
        if len(tags) != 1 or ln.text.strip() != tags[0]:
            continue
        nx = texts[k + 1]
        a, b = _ROW_WHERE.match(str(ln.where or "")), _ROW_WHERE.match(str(nx.where or ""))
        if not (a and b and a.group(1) == b.group(1) and int(b.group(2)) == int(a.group(2)) + 1):
            continue
        nt = str(nx.text or "")
        if find_tags(nt) or ":" in nt or "：" in nt or _DATE_IN_TEXT.search(nt):
            continue
        joined = f"{tags[0]} {nt.strip()}"
        if not any(u not in ("?", "") for u in _num_units(joined, tags[0])):
            continue
        new_ln = _base.TextLine(joined, ln.where, getattr(ln, "box", None))
        if getattr(ln, "_raw", None) or getattr(nx, "_raw", None):
            object.__setattr__(new_ln, "_raw", f"{_raw_text(ln).strip()} {_raw_text(nx).strip()}")
        occ[tags[0]] = [new_ln if x is ln else x for x in occ.get(tags[0], [])]
    return occ


def _drop_stale_issue_pages(drawings, tag_map) -> None:
    """옛 Rev 출도 PDF 쪽의 줄을 교차 대조에서 뺀다 — 같은 도면번호의 CAD 원본(DXF·DWG)이 같은 모양의 **더 높은** Rev면 그 쪽은
    아직 다시 뽑지 않은 옛 출도본이다. DXF E-002를 Rev B(5.5kW)로 고치고 BOM도 맞춘 날, 아직 Rev A인 출도 PDF의 3.7kW로 거짓
    도면-BOM·도면 간 불일치가 났다 (구매 평가 2차 P2 day1·6 — 정답 '도면-BOM 일치 → 불일치 경고 없어야'). 쪽마다(세트 PDF는
    쪽 표제란 도면번호·Rev로) 본다. 다른 형식끼리만 — 같은 도면번호의 DXF 시트 둘(SH1 Rev B·SH2 Rev A)은 서로 빼지 않는다."""
    from watcher.scan import rev_key, rev_shape
    cad: dict = {}
    for p, d in drawings:
        if getattr(d, "doc_type", "") in ("dxf", "dwg") and "DWG_NO" in (d.fields or {}) and str(d.revision or "").strip():
            cad.setdefault(str(d.fields["DWG_NO"].value).strip().upper(), []).append(_rev_norm(d.revision))
    if not cad:
        return
    for p, d in drawings:
        if getattr(d, "doc_type", "") != "pdf":
            continue
        sheets = page_sheet_ids(d)
        doc_no = str(d.fields["DWG_NO"].value).strip().upper() if "DWG_NO" in (d.fields or {}) else ""
        stale: set = set()
        pages = {int(m.group(1)) for t in (d.raw_texts or []) for m in [_PAGE_HEAD.match(str(getattr(t, "where", "") or ""))] if m}
        for pg in pages:
            no = sheets.get(pg) or (doc_no if len(set(sheets.values())) < 2 else "")
            rv = _page_title_rev(d, pg) if len(set(sheets.values())) >= 2 else _rev_norm(d.revision or "")
            if not no or not rv or no not in cad:
                continue
            if any(rev_shape(c) is not None and rev_shape(c) == rev_shape(rv) and rev_key(c) > rev_key(rv) for c in cad[no]):
                stale.add(pg)
        if not stale:
            continue
        for tag in list(tag_map.get(p, {})):
            tag_map[p][tag] = [ln for ln in tag_map[p][tag]
                               if not ((m := _PAGE_HEAD.match(str(ln.where or ""))) and int(m.group(1)) in stale)]


def _raw_text(ln) -> str:
    return getattr(ln, "_raw", None) or ln.text


# 구분자만 있는 토큰 — 사양값이 아니다 ('M-302 : 15kW'의 ':')
_SEP_TOKENS = {":", "-", "=", "·", "|", "/", "→", ","}
# 모델명·태그 꼴 토큰의 글자 접두 (GMC-22 → GMC, 3P-100 → P)
_MODEL_RE = re.compile(r"^\d?([A-Za-z]{1,6})-\d+[A-Za-z0-9]*$")

# 표기 차이를 흡수하는 정규화: 소문자화 + 공백/구분자 제거 + 단위 동의어
# ('5.5kW' vs '5.5 KW' vs '5.5㎾'가 전부 경보가 되던 문제 — 2026-08-26 검토)
_UNIT_SYNONYM = (("㎾", "kw"), ("㎟", "sq"), ("ø", "d"), ("Φ", "d"), ("φ", "d"),
                 # 마이크로(μF ↔ uF)·옴(Ω ↔ ohm) — 호환 단위 글자를 NFKC로 푼 뒤의 꼴 (재검토 2026-10-28 R6-3)
                 ("μ", "u"), ("ohm", "ω"))

# 사양 비교용 접기 — project.fold_text(제로폭 제거·NFKC·대시 통일)에 사양 기호 몇 개를 더한다. 전각 '５.５kW'(R9-2), 호환 단위 글자
# ㎜·㎥·㎄·㎌·℃·Ω(R6-3 — 단위로 못 읽어 '?' 묶음에 떨어져 50㎜↔80mm를 놓쳤다), 치수 '×'(R6-4 — 600×400↔600x400 거짓 불일치),
# 물결 '∼'·'〜'(범위), 지름 '⌀', 제로폭(R6-8)이 대상이다 (재검토 2026-10-28). ㎟는 NFKC 'mm2'가 아니라 예전처럼 SQ로.
# 비교에만 쓴다 — 근거 줄은 원문(_raw)을 싣는다(원칙 4). 'O'↔'0'처럼 다른 글자는 건드리지 않는다
_SPEC_FOLD = {ord("×"): "x", ord("∼"): "~", ord("〜"): "~", ord("⌀"): "Ø", ord("㎟"): "SQ"}


def _fold(s) -> str:
    s = str(s or "")
    if s.isascii():
        return s
    from watcher.project import fold_text
    return fold_text(s.translate(_SPEC_FOLD))


_THOUSANDS = re.compile(r"^\d{1,3}(?:,\d{3})+(?!\d)")      # '1,500mm'·'12,000,000' — 쉼표 뒤 세 자리씩 (R6-2)
_TRAIL_ZERO = re.compile(r"(\d+)\.(\d*?)0+(?=[^\d]|$)")   # 5.50 → 5.5, 10.0 → 10.
_BARE_DOT = re.compile(r"(\d+)\.(?=[^\d]|$)")             # 10. → 10



# 날짜가 든 줄 가운데 옛 값 기록인 것 — 날짜가 줄 맨 앞(검토 기록 '2026-10-16 M-410 … 검토안 폐기'), 개정 행 꼴('B 2026-10-13 …'),
# 또는 이력 낱말(철거·폐기·변경 전·기존·시험…)이 든 줄. 'M-410 MOTOR 15kW (2026.10.20 교체 설치)'처럼 날짜가 든 현재 사양까지
# 빼서 도면-BOM 불일치를 놓쳤다 (검토71 R3 A71-12)
_HISTORY_WORDS = re.compile(
    r"철거|폐기|변경\s*전|기존|이전|구\s*사양|시험|검토안|취소|(?<![A-Za-z])(?:OLD|REMOVED|DELETED|SUPERSEDED|WAS|TEST(?:ED)?|"
    r"CANCEL(?:LED)?|VOID)(?![A-Za-z])", re.I)


def _dated_record_line(text: str) -> bool:
    m = _DATE_IN_TEXT.search(text)
    if not m:
        return False
    if not text[:m.start()].strip(" \t([") or re.match(r"^\s*(?:[A-Z]|\d{1,2})\s+(?:19|20)\d{2}[-./]", text):
        return True
    return bool(_HISTORY_WORDS.search(text))

def _norm_numbers(s: str) -> str:
    """수치 표기 차이를 흡수 — '5.50kW'와 '5.5kW'는 같은 값이다. 소수점 뒤 0만 지우고
    ('5.50'→'5.5', '10.0'→'10'), 정수부·단위는 건드리지 않는다 (검토21 감지 차단 2:
    같은 값에 '도면 간 사양 불일치'·'도면-BOM 불일치' 경보가 났다)."""
    out = _TRAIL_ZERO.sub(lambda m: m.group(1) + ("." + m.group(2) if m.group(2) else "."), s)
    return _BARE_DOT.sub(r"\1", out)


def _norm(s: str) -> str:
    out = _fold(s).lower()
    for a, b in _UNIT_SYNONYM:
        out = b.join(out.split(a))
    out = _norm_numbers(out)
    return "".join(ch for ch in out if ch not in " \t:·|,")


_NUM = re.compile(r"^[\d.,]+$")
_UNIT = re.compile(r"^[A-Za-z%Ω℃°μ]{1,6}$")
# 날짜 꼴 토큰 — 4자리 해 '2026-09-26'·'2026.09.26'·'2026/9/26'·'2026년 9월 26일'. 시험 기록 두 장의 시험일을 사양으로 읽어
# '태그 P-1301의 사양이 도면 간에 다릅니다 (2026-09-26 vs 2026-10-08)'가 났다 (갈래 A 2026-10-16, held69 X12). 같은 줄의
# 진짜 사양 값(5.5kW)은 그대로 견준다 — 날짜 조각만 뺀다
_DATE_IN_TEXT = re.compile(
    r"(?<![\w.\-/])((?:19|20)\d{2})([-./])(\d{1,2})\2(\d{1,2})(?![\w.\-/])"
    r"|((?:19|20)\d{2})\s*년\s*(\d{1,2})\s*월(?:\s*(\d{1,2})\s*일)?")


def _desc_words(seg: str) -> set:
    """줄 조각의 설명 낱말(숫자 없는 글자 토큰, 값 뒤 단위 낱말 제외) — 'MOTOR 7.5kW STARTER' → {MOTOR, STARTER}."""
    out: set = set()
    prev_num = False
    for t in re.split(r"[\s/,;:()\[\]]+", str(seg or "")):
        if not t:
            continue
        if any(ch.isdigit() for ch in t):
            prev_num = bool(_NUM.match(t))
            continue
        if prev_num and _UNIT.match(t):           # '7.5 kW'의 kW
            prev_num = False
            continue
        prev_num = False
        if t in _SEP_TOKENS or not re.search(r"[A-Za-z가-힣]", t):
            continue
        out.add(_WORD_SAME.get(t.upper(), t.upper()))
    return out


def _drop_dates(text: str) -> str:
    """날짜 꼴 조각(달 1~12·날 1~31)을 공백으로 — 사양 값 비교에서 뺀다."""
    def _sub(m):
        mo, d = (m.group(3), m.group(4)) if m.group(1) else (m.group(6), m.group(7) or "1")
        return " " if 1 <= int(mo) <= 12 and 1 <= int(d) <= 31 else m.group(0)
    return _DATE_IN_TEXT.sub(_sub, text)


def _spec_token(line_text: str, tag: str) -> str:
    """태그 다음의 첫 '값' 토큰 = 사양값 (예: 'M-302 : 15kW DOL' → '15kW').

    줄 전체를 비교하면 문서 유형별 표기 차이('11kW' vs '11kW INVERTER DRIVEN')가
    전부 오탐이 된다. 값 토큰 하나만 비교하되, 구분자 토큰(':' 등)은 건너뛴다.
    태그는 낱말 경계로 찾는다(M-10이 M-101 안에서 걸리지 않게), 숫자 뒤에 단위가
    따로 오면('15 kW') 붙여서 한 값으로 본다 (2026-09-02 재검토)."""
    m = _tag_re(tag).search(line_text)
    if m is None:
        return ""
    toks = [t for t in _drop_dates(line_text[m.end():]).split() if t not in _SEP_TOKENS]   # 날짜는 값이 아니다 (갈래 A)
    if not toks:
        return ""
    # 가장 흔한 표기 'M-101 MOTOR 5.5kW'에서 첫 토큰은 종류(MOTOR)지 값이 아니다 — 그래서
    # 도면 간 사양 불일치를 통째로 못 봤고, 'M-101 5.5kW'와 비교하면 (MOTOR vs 5.5kW)
    # 헛경보를 냈다 (검토19 감지 ②). BOM 검사(_spec_like)처럼 숫자를 품은 첫 토큰을 값으로
    for i, t in enumerate(toks):
        if any(ch.isdigit() for ch in t):
            if _NUM.match(t) and i + 1 < len(toks) and _UNIT.match(toks[i + 1]):
                return t + toks[i + 1]
            return t
    return toks[0]


_CHANGE_NOTE = re.compile(r"->|→|=>|⇒|➔")
# 양쪽이 모두 **숫자로 시작하는 값**(50AT·7.5kW·(0·1750rpm) — 'MCC-1' 같은 태그는 값이 아니다
# 왼쪽 값은 낱말 첫머리부터 — '2026-09-01 → 2026-09-05'의 '01'만 잡아 '2026-09-2026-09-05'가 됐다 (검토41 S4 낮음)
# 서로 배타인 사양 낱말 묶음 — 같은 묶음에서 도면과 BOM이 **다른** 낱말을 쓰면 불일치. 단위 값만 견주면
# 'PHOTO SENSOR NPN→PNP'·'220V RED→GREEN'이 조용히 지나갔다 (검토41 S3 중간 2). 낱말 통째로만 견준다
_EXCLUSIVE_WORDS = (
    frozenset({"NPN", "PNP"}),
    frozenset({"AC", "DC"}),
    frozenset({"RED", "GREEN", "YELLOW", "AMBER", "WHITE", "BLUE", "ORANGE", "BLACK",
               "적색", "녹색", "황색", "백색", "청색", "흑색", "주황색"}),
    frozenset({"SS400", "SS41", "SUS304", "SUS316", "STS304", "STS316", "SM45C", "SPCC", "AL6061", "A6061", "A5052"}),
)


# 같은 뜻의 다른 표기 — 녹색/GREEN, STS304/SUS304(KS·JIS), SS41/SS400(구 표기), A6061/AL6061을 서로 다른 값으로 보아
# 거짓 불일치가 났다 (검토42 B 중간 1)
_WORD_SAME = {"적색": "RED", "녹색": "GREEN", "GRN": "GREEN", "황색": "YELLOW", "AMBER": "YELLOW", "백색": "WHITE", "청색": "BLUE",
              "흑색": "BLACK", "주황색": "ORANGE", "STS304": "SUS304", "STS316": "SUS316", "SS41": "SS400",
              "A6061": "AL6061"}


def _material_norm(t: str) -> str:
    """같은 재질의 다른 표기를 한 꼴로 — 토큰 사전(STS304 등 넷)만으로는 STS304L·AL6061-T6·AL5052·SM45C가 거짓
    불일치였다 (검토59 F2-2). KS STS→JIS SUS, AL+4자리→A+4자리(질별 꼬리 보존), SS41→SS400, SM45C→S45C."""
    u = t.upper()
    u = re.sub(r"^STS(?=\d)", "SUS", u)
    u = re.sub(r"^AL(?=\d{4})", "A", u)
    u = re.sub(r"^SM(?=\d{2}C\b)", "S", u)
    if u == "SS41":
        u = "SS400"
    return _WORD_SAME.get(u, u) if u != t.upper() or u in _WORD_SAME else t


def _spec_words(text: str) -> set:
    """낱말 집합 — 하이픈으로 이어진 낱말('AC-3' 사용 범주, 'DC-101' 태그)은 통째로라 조각(AC·DC)을 만들지 않는다."""
    return {_WORD_SAME.get(w, w) for w in re.findall(r"[A-Za-z0-9가-힣]+(?:-[A-Za-z0-9가-힣]+)*", str(text).upper())}


# 도면 간 대조에서 **값으로 볼** 태그 꼴 토큰(모델번호 GMC-40) — 프로젝트마다 _check_project_consistency가 채우고 비운다.
# 'MC-991 GMC-40'의 GMC-40을 상대 태그로 보고 빼서 도면 간 'GMC-40→GMC-50' 불일치를 못 잡았다 (재검토 2026-10-26 D4)
_MODEL_TOKENS: frozenset = frozenset()
_CONN_TARGET = re.compile(r"(?:->|→|=>|⇒|➔)\s*([A-Za-z0-9][A-Za-z0-9\-]*)")


def _model_family(tok: str) -> str | None:
    m = _MODEL_RE.match(str(tok or ""))
    return m.group(1).upper() if m else None


def _model_tokens(drawings, tag_map, boms) -> frozenset:
    """이 프로젝트 도면에서 태그 꼴이지만 **기기 태그로는 한 번도 쓰이지 않는** 토큰 — 모델번호(GMC-40·MY4N-1).
    보수적으로: 어느 도면 줄의 첫 태그 자리에도 없고, 같은 글자 계열(GMC)의 태그도 첫 자리에 없고, BOM TAG 열에도 없을 때만."""
    leading: set = set()
    for _p, d in drawings:
        for ln in d.raw_texts:
            first = find_tags(ln.text)[:1]
            if first:
                leading.add(first[0])
    bom_tags = {v for _p, b_ in boms for v in (_col(r, _TAG_COLS) for r in b_.rows) if v}
    fams = {_model_family(t) for t in leading | bom_tags} - {None}
    seen: set = set()
    for path in tag_map:
        seen |= set(tag_map[path].keys())
    return frozenset(t for t in seen
                     if t not in leading and t not in bom_tags and _model_family(t) and _model_family(t) not in fams)


def _tag_segment(tag: str, text: str) -> str:
    """태그 뒤부터 다음 태그 앞까지 — 같은 줄의 다른 기기 사양('PL-21 RED 램프 아래')까지 모으지 않게."""
    m = _tag_re(tag).search(text)
    seg = text[m.end():] if m else text
    # 태그 사이가 구분자뿐이면('PL-21, PL-22 GREEN') 사양을 함께 쓰는 것 — 다음 태그 조각으로 넘어간다. 빈 조각으로 끊어
    # PL-21의 진짜 불일치를 놓쳤다 (검토43 B 중간 7)
    for _ in range(8):
        tags_ = [(seg.find(t), t) for t in find_tags(seg) if t not in _MODEL_TOKENS]
        tags_ = sorted((k, t) for k, t in tags_ if k >= 0)
        if not tags_:
            return seg
        k, t = tags_[0]
        if re.sub(r"[\s,;/·&및와과+]+", "", seg[:k]):
            return seg[:k]
        seg = seg[k + len(t):]
    return seg


def _word_conflict(bom_text: str, line_text: str, tag: str = "") -> bool:
    b = _spec_words(bom_text)
    d = _spec_words(_tag_segment(tag, line_text) if tag else line_text)
    for cls in _EXCLUSIVE_WORDS:
        x, y = b & cls, d & cls
        if x and y and x.isdisjoint(y):
            return True
    return False


_VALUE_CHANGE = re.compile(r"(?<![\w\-./])(\(?\d[\w.,%㎾㎟Ω℃°\-/]*)\s*(?:->|→|=>|⇒|➔)\s*(\(?\d[\w.,%㎾㎟Ω℃°)\-/]*)")


def _current_values(text: str) -> str:
    """'50AT->75AT'·'5.5kW → 7.5kW'처럼 양쪽이 모두 값인 화살표는 옛 값→새 값 기술 — 새 값만 남긴다.
    'MOTOR 7.5kW -> MCC-1'처럼 한쪽이 값이 아니면(연결 표기) 그대로 둔다 (검토38 R3 차단 1·검토39 F2 ②)."""
    return _VALUE_CHANGE.sub(lambda m: m.group(2), text)
# 단위 — 영문 단위, 제곱·세제곱 길이 단위(m3·mm2 — 숫자가 들어 '?'로 떨어지면 같은 줄 SUS304와 한 묶음이 되어 50m3↔30m3를
# 놓쳤다), 사양 꾸밈 한글 단위(1종·4극·3상 — BOM '1종'은 '?', 도면 '1 종'은 단위 없는 숫자라 서로 견주지 못했다)
# (대량 시험 DXF C4·C5, 2026-10-20)
_KOR_UNIT = re.compile(r"^(?:[종극상]|[mM]{1,2}[23]|[cC][mM][23])$")     # 띄어 쓴 값('1 종'·'100 m3')에 붙일 단위
_VAL_UNIT = re.compile(r"^(\d+(?:[.,]\d+)?)\s*([A-Za-z%Ω℃°㎾㎟μ]{0,6}|[mM]{1,2}[23]|[cC][mM][23]|[종극상])$")
# 글자 앞 치수 — 지름 D·길이 L·폭 W·높이 H·두께 T·반경 R(숫자 둘 이상이나 소수 — 'L1'·'T1'·'R1'은 상·단자 이름)·DN·PN·OD·ID
_DIM_PREFIX = re.compile(r"^(?:(DN|PN|OD|ID)\d+(?:\.\d+)?|([DLWHTR])(?:\d{2,}(?:\.\d+)?|\d\.\d+))$", re.I)
# 범위 값 '0-50m3'·'4~20mA'·'-10-60℃' — 단위에 숫자가 붙는 것(m3·mm2)도 (검토68 A4)
_RANGE_UNIT = re.compile(r"^-?\d+(?:[.,]\d+)?\s*[-~]\s*-?\d+(?:[.,]\d+)?\s*"
                         r"([A-Za-z%Ω℃°㎾㎟μ][A-Za-z0-9%Ω℃°㎾㎟μ]{0,5})?$")
# 표제란 REV 줄(콜론 있는 꼴·칸 나뉜 'REV   B') — 세트 PDF 쪽 표제란의 Rev 올림 판정과 36시간 유예가 같이 쓴다
# 한글 칸표 '개정 A'·'리비전 B'·'개정번호 1'도 — 2장 세트의 2쪽 '개정 A→B'를 쪽 Rev 올림으로 못 봐 거짓 'Rev 미갱신' (검토68 B4)
REV_LINE_RE = re.compile(r"^\s*(?:REV(ISION)?\.?|개정\s*번호|개정|리비전)\s*(?:[:：.\-]\s*\S{1,8}|\s+[A-Za-z]?\d{0,3}[A-Za-z]?)\s*$", re.I)
_REV_LINE_VALUE_RE = re.compile(
    r"^\s*(?:REV(?:ISION)?\.?|개정\s*번호|개정|리비전)\s*[:：.\-]?\s*([A-Za-z0-9][A-Za-z0-9.\-]{0,5}|-)(?:\s*\([^)]{0,24}\))?\s*$", re.I)
_PAGE_2PLUS_RE = re.compile(r"^\s*(?:[2-9]|\d{2,})\s*(?:페이지|쪽|page)", re.I)
# 윈도우 사본은 '(2)'부터 생긴다 — '(1)'은 사본이 아니라 시트일 가능성이 높다 (검토31 S1-13)
# 이름 끝의 '_OLD'·'_구판'·'_백업'도 사본 표식 — 현장용 옛 판을 '_OLD'로 바꿔 두면 도면 간 거짓 불일치가
# 일주일 열려 있었다 (검토39 P4 중간 3). '_superseded'·'_void'·'_obsolete'·'_폐기'도 — 같은 번호 Rev A·B 두 장이 도면 간·도면-BOM
# 불일치가 됐다 (검토20 r12 6)
_COPY_MARK_RE = re.compile(r"(\((?:[2-9]|\d{2,})\)|[-_\s]+복사본|[-_\s]+copy|[-_](?:old|구판|옛판|superseded|obsolete|void|폐기|폐기본)|\s*\([^()]*(?:충돌 사본|conflicted copy|-conflict-|conflict \d{4}-\d{2}-\d{2})[^()]*\))\s*$",
                           re.I)   # 'UPS BACKUP'·'비상전원 백업'은 도면 이름이다 (검토39 F2 ⑥)


_STRIP_DWG = re.compile(rf"(?i)(?<![A-Za-z]){_DWG_LABEL}\s*[:：]\s*([A-Za-z0-9][\w.\-/]*)")
_STRIP_DATE = re.compile(r"(?i)(?<![A-Za-z])(?:DATE|일자|작성일)\s*[:：]\s*\S+")


def _strip_rev(text):
    """띠 표제란 한 줄 'DWG NO: X-02  REV: 1  DATE: 2026.08.10  PROJECT: …' → (도면번호, REV 값, REV·일자 뺀 나머지) — 세트 뒤 쪽
    표제란이 한 줄이면 REV 줄 꼴(줄 전체가 REV)이 아니라 REV 올림을 못 알아봐 거짓 'Rev 미갱신'이 났다 (2026-10-20 PDF 대량 시험 N4,
    13건). 도면번호 칸과 콜론 있는 REV 칸이 하나씩 있을 때만."""
    t = str(text or "")
    d = _STRIP_DWG.search(t)
    rs = list(_PG_REV_COLON.finditer(t))
    if not d or len(rs) != 1 or len(_STRIP_DWG.findall(t)) != 1:
        return None
    rest = t[:rs[0].start(1)] + t[rs[0].end(1):]
    rest = " ".join(_STRIP_DATE.sub(" ", rest).split())
    return d.group(1).upper(), rs[0].group(1), rest


def is_page_rev_bump(kind, old, new, where, doc_type: str = "pdf", field_rev=None) -> bool:
    """세트 PDF(쪽마다 표제란)의 **뒤 쪽** 표제란 REV 줄이 바뀐 것인가 — 'REV: A → REV: B'.
    모든 문서·TEXT_ADDED에 대면 본문의 개정 구름 글자 'REV 2'가 Rev 올림으로 승격돼 'Rev 미갱신'이 꺼지고
    36시간 유예까지 걸렸다 (검토31 B6). 조건: PDF · 2쪽 이상 · TEXT_CHANGED · 앞뒤 모두 REV 줄 · 값이
    표제란 REV 꼴(A/AB/1/12) · 값이 다름."""
    if str(doc_type or "pdf") != "pdf" or str(kind or "") != "TEXT_CHANGED":
        return False
    mo, mn = _REV_LINE_VALUE_RE.match(str(old or "")), _REV_LINE_VALUE_RE.match(str(new or ""))
    if mo and mn:
        vo, vn = mo.group(1), mn.group(1)
    else:
        so, sn = _strip_rev(old), _strip_rev(new)
        if not (so and sn and so[0] == sn[0] and so[2] == sn[2]):
            return False
        vo, vn = so[1], sn[1]
    if vo.upper() == vn.upper():
        return False
    if not _PAGE_2PLUS_RE.match(str(where or "")):
        # 1쪽 줄은 보통 표제란 칸(FIELD_CHANGED)이 말한다. 다만 앞 쪽을 지우거나 쪽을 맞바꿔 칸 비교를 뺀 세트에서는
        # 그 줄이 유일한 근거 — 새 값이 문서의 표제란 REV와 같으면 그 표제란 줄이다 (검토62 B3·B4)
        if not (field_rev is not None and str(field_rev).strip().upper() == vn.upper()):
            return False
    if vn == "-":
        return False                         # 값이 없어진 것은 올림이 아니다
    # 1쪽 표제란 REV가 글자(A)인데 2쪽 줄이 '1→2'처럼 작은 숫자끼리면 본문의 개정 구름 글자다 (검토32 B3).
    # 'P1→0'(예비→발행)·'-→A'·'A1→A2'·'100→101'은 올림이다 (B4)
    if field_rev is not None:
        fr = str(field_rev or "")
        if fr and not fr[:1].isdigit() and vo.isdigit() and vn.isdigit() and len(vo) <= 2 and len(vn) <= 2:
            return False
    return True
# '00_구판'·'Backup_2025'·'_old'·'구판(2025)'·'99_백업'처럼 앞뒤가 붙은 이름도 (검토26 1회차 2)
# 폴더 조각(마지막 파일 이름 제외)만 보고, 낱말 뒤는 숫자·구분자·괄호만 — 'Backup NAS'·'구판 교체 공사'·
# 'old_E-101.dxf'까지 구판이 됐다 (2회차 A4)
_OLD_FOLDER = re.compile(
    r"(^|/)[\d_\-\s.]*(old|구버전|구판|backup|백업|아카이브|archive|보관함?|지난)"
    r"(?:[\s_\-]*(drawings?|dwgs?|files?|docs?|도면|파일|문서|자료|rev\.?[A-Za-z0-9]*))?[\d_\-\s.()]*/",
    re.IGNORECASE)


def _num_set(line_text: str, tag: str) -> frozenset:
    """태그 뒤의 숫자 품은 값 토큰들(정규화) — 다른 태그 꼴 토큰(→ CP-01)은 뺀다."""
    return frozenset(v for vals in _num_units(line_text, tag).values() for v in vals)


def _num_units(line_text: str, tag: str) -> dict[str, frozenset]:
    """태그 뒤의 값을 **단위별로** 묶는다 {단위: {값}} — '100AT 3P'와 '125AT 3P'는 3P가 겹쳐도
    AT가 다르니 불일치다. 집합 교집합 하나로 보면 부속 숫자(3P·4P·380V) 하나 때문에
    5.5kW↔7.5kW를 못 봤다 (파일럿 모의 2차 N1). 단위 없는 숫자는 '' 단위."""
    line_text, tag = _fold(line_text), _fold(tag)      # 전각·호환 단위·제로폭 (재검토 2026-10-28 R9-2·R6-3·R6-8)
    m = _tag_re(tag).search(line_text)
    if m is None:
        return {}
    out: dict[str, set] = {}
    # 태그 뒤부터 **다음 태그 앞까지만** — 같은 줄 다른 기기 값('M-101 7.5kW / M-102 5.5kW')이 섞여, M-102가 BOM 값과
    # 같아지자 M-101 불일치가 '일치'로 자동 해소됐다 (검토43 A 중간 5)
    seg = _tag_segment(tag, line_text)
    seg = _drop_dates(seg)           # 시험일·작성일은 사양이 아니다 (갈래 A 2026-10-16, held69 X12)
    # 'AC/DC24V'(겸용)·'0.6/1kV'(케이블 등급)는 '/'에서 갈리면 'DC24V'·'1kV'만 남아 전압 비교에서 거짓 불일치가 났다 — 한 덩어리로
    # 둔다 (검토50 A 낮음 4)
    seg = re.sub(r"(?i)\b(AC|DC)\s*/\s*(AC|DC)", r"\1\2", seg)
    seg = re.sub(r"(?i)(\dV)(AC|DC)\s*/\s*(AC|DC)\b", r"\1\2\3", seg)      # '24VAC/DC' 뒤 꼴 (검토52 A 낮음 6)
    seg = re.sub(r"(?i)(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)\s*kV\b", r"\1~\2kV", seg)
    # 'SUS 304'처럼 띄어 쓴 재질은 숫자만 떨어져 다른 강종(SUS316)과 견주지 못했다 — 붙인다 (검토59 F2-3)
    seg = re.sub(r"(?i)\b(SUS|STS|SS|AL|SM)[\s-]+(\d{2,4}[A-Z]?)\b", r"\1\2", seg)
    _conn = set(_CONN_TARGET.findall(seg)) if _MODEL_TOKENS else set()     # '→ CP-01'은 연결 표기 — 값이 아니다
    toks = [t for t in re.split(r"[\s/;]+", seg) if t and t not in _SEP_TOKENS]
    i = 0
    while i < len(toks):
        t = toks[i]
        # '5.5 kW'처럼 숫자와 단위가 떨어진 표기는 붙인다 — 안 붙이면 '5.5KW'와 헛경보 (검토19c ⑥)
        if _NUM.match(t) and i + 1 < len(toks) and (_UNIT.match(toks[i + 1]) or _KOR_UNIT.match(toks[i + 1])):
            t = t + toks[i + 1]
            i += 1
        i += 1
        if not any(ch.isdigit() for ch in t):
            continue
        if re.match(r"^[A-Za-z]{1,4}-\d+[A-Za-z0-9]*$", t):      # 상대 태그(CP-01)는 값이 아니다
            if t in _MODEL_TOKENS and t not in _conn:
                # 이 프로젝트에서 기기 태그로 쓰이지 않는 모델번호(GMC-40)는 값 — 글자 계열별 단위로 견준다 (D4)
                out.setdefault("@" + (_model_family(t) or "").lower(), set()).add(_norm(t))
            continue
        if _IO_ADDR.match(t):            # PLC I/O 주소(X0·Y1F·%I0.0)는 배선 자리지 사양이 아니다 (구매 평가 2차 P2)
            continue
        if _THOUSANDS.match(t):
            # 쉼표 뒤가 정확히 세 자리씩이면 천 단위 — '1,500mm'·'1,000rpm'을 소수 쉼표로 읽어 1.5mm·1rpm이 되고 BOM 1500mm와
            # 거짓 불일치가 났다 (재검토 2026-10-28 R6-2). diff._THOUSANDS와 같은 뜻
            t = "".join(t.split(","))
        elif re.match(r"^\d+,\d+", t):
            t = ".".join(t.split(","))       # 5,5kW = 5.5kW (replace는 가드가 막는다)
        # 숫자가 든 재질 표기(STS304·SS41·A6061)는 낱말 경로를 비켜 이리로 와 _WORD_SAME이 안 먹었다 — 도면 STS304와 BOM
        # SUS304가 불일치로 났다 (검토58 F2 F10·F23). 같은 뜻 표기로 맞춘다
        t = _material_norm(t)
        mm = _VAL_UNIT.match(t)
        unit = _norm(mm.group(2)) if mm else "?"                  # 'CV4SQ3C' 같은 덩어리는 '?'
        md = None if mm else _DIM_PREFIX.match(t)
        if md:
            # 글자 앞 치수(D250·L4000·W600·DN50)는 글자마다 따로 — 한 '?' 묶음이면 'SCREW D250 L4000'과 BOM 'D200 L4000'이
            # 길이 L4000이 같다고 지름 차이를 놓쳤다 (구매 평가 2차 P1 SC-1)
            unit = "#" + (md.group(1) or md.group(2)).lower()
        mr = None if mm else _RANGE_UNIT.match(t)
        if mr:
            # 범위 꼴('0-50m3'·'4-20mA')은 단위를 따로 읽는다 — 둘 다 '?'로 묶여 계기 범위와 신호를 견줘 거짓 도면 간
            # 불일치가 매일 났다 (검토68 A4). 단위 없는 범위는 '?'(견주지 않음)
            unit = ("~" + _norm(mr.group(1))) if mr.group(1) else "?"
        out.setdefault(unit, set()).add(_norm(t))
    return {u: frozenset(v) for u, v in out.items()}


def _conflict_vals(a: dict, b: dict) -> tuple[str, str]:
    """서로소인 단위의 값 — ('7.5kW', '11kW'). 없으면 ('', '')."""
    for u, va in a.items():
        vb = b.get(u)
        if vb and not (va & vb):
            _pretty = {"kw": "kW", "v": "V", "a": "A", "at": "AT", "af": "AF", "sq": "SQ", "hz": "Hz", "p": "P"}

            def _fmt(v):
                m = re.match(r"^([\d.,]+)([a-z]*)$", str(v))
                return f"{m.group(1)}{_pretty.get(m.group(2), m.group(2))}" if m else str(v).upper()
            return "/".join(_fmt(v) for v in sorted(va)), "/".join(_fmt(v) for v in sorted(vb))
    vc = _volt_conflict(a, b) or _scaled_conflict(a, b)
    return vc if vc else ("", "")


_VOLT_RE = re.compile(r"(acdc|dcac|ac|dc)?(\d+(?:\.\d+)?)(k?)v(acdc|dcac|ac|dc)?")   # acdc = 겸용 (검토51 A 낮음 4)


def _volts(units: dict) -> set:
    """전압 값들 {(볼트, 'ac'|'dc'|'', kV 표기였나, 원문)} — 24VDC·110VAC·AC220V·DC24V·0.4kV는 단위 이름이 달라 같은 단위 키로
    묶이지 않았다."""
    out = set()
    for vals in units.values():
        for v in vals:
            m = _VOLT_RE.fullmatch(str(v))
            if m:
                _k = m.group(1) or m.group(4) or ""
                out.add((float(m.group(2)) * (1000 if m.group(3) else 1), "" if _k in ("acdc", "dcac") else _k,
                         bool(m.group(3)), str(v)))
    return out


def _volt_same(x, y) -> bool:
    if x[1] != y[1] and "" not in (x[1], y[1]):
        return False
    if x[0] == y[0]:
        return True
    # 0.4kV급 표기와 정격 380V·440V는 같은 전압 등급이다 — 환산값 400V로 '불일치'라 했다 (검토50 A 낮음 4)
    return (x[2] or y[2]) and abs(x[0] - y[0]) <= 0.1 * max(x[0], y[0])


def _volt_conflict(a: dict, b: dict) -> tuple[str, str] | None:
    """양쪽에 전압이 있는데 하나도 맞지 않으면 (a 원문, b 원문). 종류(AC/DC)를 안 적은 쪽은 값만 견준다.
    릴레이·램프 코일 24VDC→110VAC가 도면-BOM·도면 간 모두 침묵했다 — 실무에서 가장 흔한 사양 변경이다 (검토49 B 중간 1).
    근거에는 도면·BOM에 적힌 **원문**을 싣는다 — 환산값 '400V'는 도면에서 찾을 수 없었다 (검토50 A 낮음 4)"""
    va, vb = _volts(a), _volts(b)
    if not va or not vb:
        return None
    if any(_volt_same(x, y) for x in va for y in vb):
        return None

    def _f(s):
        return "/".join(sorted({re.sub("KV", "kV", x[3].upper()) for x in s}))
    return _f(va), _f(vb)


def _units_conflict(a: dict, b: dict) -> bool:
    """같은 단위가 양쪽에 있는데 값 집합이 서로소인 단위가 하나라도 있으면 불일치. 전압은 단위 이름(V·VDC·VAC)이 달라도
    같은 계열로 견준다. 단위 모르는 덩어리('?': DN50·CV4SQ)끼리도 견준다 — 계기 범위·신호의 거짓 불일치는 범위 단위를 따로
    읽어 막았고(검토68 A4), '?'를 빼자 도면 DN50 ↔ BOM DN80 불일치를 놓쳤다 (검토68 재대조 C39)."""
    for u, va in a.items():
        vb = b.get(u)
        if vb and not (va & vb):
            return True
    return _volt_conflict(a, b) is not None or _scaled_conflict(a, b) is not None


# 접두가 붙는 단위 가족 — 단위 이름이 달라(W↔kW, mm↔m, A↔kA) 같은 키로 묶이지 않아 BOM '7500W' vs 도면 '11kW'가
# '일치'로 끝났다 (검토20 r12 3). 기본 단위로 환산해 **견주기만** 한다 — 저장 값·근거는 원문 그대로(원칙 4).
# mA는 넣지 않는다(4-20mA 신호와 50A 관 호칭이 같은 가족이 된다). 전압은 _volt_conflict가 따로 본다
_SCALED_UNITS = {"w": ("w", 1.0), "kw": ("w", 1e3),
                 "mm": ("m", 1e-3), "cm": ("m", 1e-2), "m": ("m", 1.0),
                 "a": ("a", 1.0), "ka": ("a", 1e3),
                 "hz": ("hz", 1.0), "khz": ("hz", 1e3),
                 "pa": ("pa", 1.0), "kpa": ("pa", 1e3), "mpa": ("pa", 1e6)}
_SCALED_VAL = re.compile(r"(\d+(?:\.\d+)?)([a-z]+)")


def _scaled(units: dict) -> dict:
    """{가족: {(기본 단위 값, 원문)}} — 단위 키가 가족에 든 값만."""
    out: dict = {}
    for u, vals in units.items():
        fam = _SCALED_UNITS.get(u)
        if not fam:
            continue
        for v in vals:
            m = _SCALED_VAL.fullmatch(str(v))
            if m and m.group(2) == u:
                out.setdefault(fam[0], set()).add((round(float(m.group(1)) * fam[1], 6), str(v)))
    return out


def _scaled_conflict(a: dict, b: dict) -> tuple[str, str] | None:
    """같은 가족 값이 양쪽에 있는데 **단위 이름이 달라** 위 같은-단위 비교가 못 본 경우만 — 환산값이 하나도 맞지 않으면 (a 원문, b 원문)."""
    sa, sb = _scaled(a), _scaled(b)
    for fam, xa in sa.items():
        xb = sb.get(fam)
        if not xb:
            continue
        ua = {u for u in a if _SCALED_UNITS.get(u, ("",))[0] == fam}
        ub = {u for u in b if _SCALED_UNITS.get(u, ("",))[0] == fam}
        if ua == ub:
            continue                       # 같은 단위끼리는 위에서 이미 견줬다
        if {x[0] for x in xa} & {x[0] for x in xb}:
            continue
        _pretty = {"kw": "kW", "w": "W", "hz": "Hz", "khz": "kHz", "ka": "kA", "a": "A", "kpa": "kPa", "mpa": "MPa", "pa": "Pa"}

        def _f(s):
            out = []
            for _v, raw in sorted(s):
                m = _SCALED_VAL.fullmatch(raw)
                out.append(f"{m.group(1)}{_pretty.get(m.group(2), m.group(2))}" if m else raw)
            return "/".join(dict.fromkeys(out))
        return _f(xa), _f(xb)
    return None


def _line_has_spec(nspec: str, text: str) -> bool:
    """줄 안에 사양값이 **값 단위로** 있는가 — 부분문자열이면 5.5kW가 15.5kW에
    들어 있다고 보고 불일치를 놓친다 (2026-09-02 재검토)."""
    # 공백과 '/ , ;'로 쪼갠 조각들의 연속 구간(최대 4개)을 값 후보로 — '15 kW',
    # '5.5kW 4P'(여러 토큰 사양), '5.5kW/380V'(슬래시 묶음)까지 잡되, 5.5kW가
    # 15.5kW 안에서 걸리는 부분문자열 일치는 생기지 않는다
    parts = [p for p in re.split(r"[\s/,;]+", text) if p and p not in _SEP_TOKENS]
    for i in range(len(parts)):
        for j in range(i + 1, min(i + 5, len(parts) + 1)):
            if _norm("".join(parts[i:j])) == nspec:
                return True
    return False


# BOM 머리글은 회사마다 다르다 — 영문 SPEC/TAG만 보면 한글 BOM('규격')은 검사가
# 통째로 침묵한다 (2026-09-03 합성 서버 검토: 도면-BOM 불일치 0/5)
# 'TAG NO.'(마침표)·'SYMBOL'·'기호'·'부품기호'면 대조가 조용히 꺼졌다 (검토67 A1) — 머리글은 공백·마침표·밑줄·하이픈을 걷고 견준다
# 머리글 이름 목록·견줌 규칙은 추출기와 함께 쓴다 (검토20 r08 1·2 — 'TAG NAME'·'태그번호'·'형식'·'TYPE'·'규격/형식'·'사양(SPEC)')
_TAG_COLS = _base.BOM_TAG_HEADS
# 장비표 머리글 'Rating'·'정격'·'용량'도 사양 칸 — 없으면 그 표의 도면-BOM 대조가 꺼졌다 (검토71 R3 H-X07). SPEC 칸이 있으면 그것이 먼저
_SPEC_COLS = _base.BOM_SPEC_HEADS


_SPECISH_VAL = re.compile(r"(?i)(?<![A-Za-z])\d+(?:[.,]\d+)?\s*(?:kW|W|kVA|VA|V|VAC|VDC|A|AF|AT|kA|mm|SQ|Hz|HP|㎾|㎟)(?![A-Za-z])")


def _spec_like_head(rows) -> str | None:
    """사양 열 이름으로 못 찾은 BOM에서 사양 같은 값(5.5kW·100AF·24VDC)이 태그 행 절반 넘게 든 열 — 안내 문구용 (검토20 r08 1)."""
    tagged = [r for r in rows if _col(r, _TAG_COLS)]
    if len(tagged) < 3:
        return None
    tag_keys = {_head_key(n) for n in _TAG_COLS}
    counts: dict = {}
    for r in tagged:
        for h, v in (r.values or {}).items():
            if not isinstance(v, str) or _head_key(h) in tag_keys:
                continue
            if _SPECISH_VAL.search(v):
                counts[h] = counts.get(h, 0) + 1
    best = max(counts.items(), key=lambda kv: kv[1], default=None)
    if best and best[1] * 2 >= len(tagged):
        return " ".join(str(best[0]).split())
    return None


_NO_COL = object()


def _col(row, names) -> str:
    """행에서 이름 후보 중 첫 값 — 머리글 표기(대소문자·공백)가 회사마다 다르다.
    머리글 키 표는 칸 이름 묶음마다 한 번만 만든다 — 행마다 칸마다 re.sub를 돌려 10만 파일 서버의 변경일에
    교차 검사 247초 가운데 132초가 여기였다(3,450만 회, 재검토 2026-10-28 R3-F2). 같은 머리글이 둘이면 뒤 칸 (예전과 같다)"""
    vals = row.values
    try:
        hmap = _head_map(tuple(vals))
    except TypeError:                     # 해시 안 되는 칸 이름 — 예전 방식 그대로
        hmap = {_head_key_raw(k): k for k in vals}
    for n in names:
        k = hmap.get(_head_key(n), _NO_COL)
        if k is _NO_COL:
            continue
        v = vals.get(k)
        if v not in (None, ""):
            return str(v)
    return ""


def _head_key_raw(name) -> str:
    return re.sub(r"[\s._\-]+", "", str(name or "")).upper()


@functools.lru_cache(maxsize=65536, typed=True)      # typed — 1과 True는 같은 해시지만 str()이 다르다
def _head_key(name) -> str:
    """머리글 견줌 키 — 대소문자·공백·마침표·밑줄·하이픈 무시 ('TAG NO.' = 'Tag_No' = 'TAGNO')."""
    return _head_key_raw(name)


@functools.lru_cache(maxsize=4096)
def _head_map(keys: tuple) -> dict:
    """칸 이름 묶음 → {머리글 키: 원래 칸 이름} (뒤 칸이 이긴다). 한 표의 행들은 같은 묶음이라 표마다 한 번 (R3-F2).
    돌려준 dict는 고치지 않는다(캐시 공유)."""
    out: dict = {}
    # '규격/형식'·'사양(SPEC)'·'규격⏎(SPEC)' — 조각 키로도 (정확히 같은 키가 있으면 그것이 이긴다, 검토20 r08 1)
    for k in keys:
        for pk in _base.head_pieces(k):
            out.setdefault(pk, k)
    exact = {}
    for k in keys:
        exact[_head_key(k)] = k
    out.update(exact)
    return out


def _spec_pieces(spec: str) -> set[str]:
    """BOM 사양('5.5kW 4P 380V', '15 kW')을 값 조각 집합으로 — 도면은 첫 값만 적는다."""
    parts = [x for x in re.split(r"[\s/,;]+", spec) if x and x not in _SEP_TOKENS]
    out: set[str] = set()
    for i in range(len(parts)):
        for j in range(i + 1, min(i + 5, len(parts) + 1)):
            out.add(_norm("".join(parts[i:j])))
    return out


import functools as _functools


@_functools.lru_cache(maxsize=8192)
def _tag_re(tag: str):
    """낱말 경계의 태그 패턴 — 태그마다 한 번 컴파일 (검토41 S5 중간 2)."""
    # '/숫자' 꼬리(M-101/1)는 다른 기기 — M-101의 줄로 읽지 않는다 (검토20 r12 1)
    return re.compile(r"(?<![\w-])" + re.escape(tag) + r"(?![\w-]|/\d)")


def _tokens_after(tag: str, text: str) -> list[str]:
    m = _tag_re(tag).search(text)
    if m is None:
        return []
    return [x for x in re.split(r"[\s/,;]+", text[m.end():]) if x and x not in _SEP_TOKENS]


def _spec_like(tok: str, known_tags=frozenset()) -> bool:
    """사양값처럼 생긴 토큰 — 숫자를 품고, 이 프로젝트의 기기 태그는 아닌 것 (5.5kW,
    MY4N, 125AT, GMC-22). 'MAIN MOTOR', 'U V W' 같은 설명 낱말과 "M-101 → CP-01"의
    상대 태그는 비교 대상이 아니다. 모델명(GMC-22)은 태그처럼 생겼지만 도면·BOM 어디에도
    태그로 등장하지 않으므로 값으로 본다 (2026-09-03 재검토)."""
    return any(ch.isdigit() for ch in tok) and tok not in known_tags and not _IO_ADDR.match(tok)


# PLC I/O 주소 — 미쓰비시 X0·Y1F(16진), IEC %I0.0·%QX0.1·%IW10, 지멘스 I0.0·Q1.7. 도면 'PLC-01 X0'의 X0을 사양으로 읽어 BOM
# 'FX5U-32MR'과 기준선부터 거짓 도면-BOM 불일치가 났다 (구매 평가 2차 P2 day0). 점이 없는 I·Q 꼴(I10)은 모델명일 수 있어 뺀다
_IO_ADDR = re.compile(r"^(?:[XY](?=[0-9A-F]*\d)[0-9A-F]{1,4}|%[IQM][XBWD]?\d+(?:\.\d+)?|[IQ]\d{1,3}\.[0-7])$")


_NUMBER_LABEL = re.compile(r"(?i)(?:(?<![A-Za-z])(?:DWG|DOC(?:UMENT)?|DRAWING)\.?[ ._]*NO\.?|도면\s*번호|문서\s*번호)\s*[:：.]?\s*$")


def _is_number_label(text: str, tag: str) -> bool:
    """그 줄에서 태그가 도면번호·문서번호 칸의 값인가 ('DOC NO: QI-6002')."""
    m = _tag_re(tag).search(str(text or ""))
    return bool(m and _NUMBER_LABEL.search(text[:m.start()]))


def _strip_number_label(text: str, tag: str) -> str:
    """'REF DOC NO: QI-6002 QI-6002 24VDC' → 'QI-6002 24VDC' — 번호 칸 라벨과 그 값(태그 첫 출현)까지 지운 나머지."""
    m = _tag_re(tag).search(text)
    if not m:
        return text
    return text[m.end():].strip()


def _rev_stamp(d: Document) -> str:
    """근거 줄에 붙일 ' [Rev B, 2026-09-01]' — 표제란에 있는 것만."""
    rev = d.revision
    date = d.fields["DATE"].value if "DATE" in d.fields else ""
    parts = [f"Rev {rev}" if rev else "", date]
    inner = ", ".join(x for x in parts if x)
    return f" [{inner}]" if inner else ""


def _canon_project(name: str) -> str:
    """교차 검사의 묶음 키 — 표제란 원문이 아니라 프로젝트 번호로. 'P24-031'과
    'P24-031 (2차)'가 다른 묶음이 되어 검사가 통째로 빠지던 것 (2026-09-02 재검토)."""
    from watcher.project import PLACEHOLDER_PROJECTS, PROJECT_NO_RE, fold_text
    # 소문자·전각·대시 변종('p25-007 제어반'·'P25－011'·'Ｐ２５-０１２')도 같은 번호 — 귀속기(ProjectResolver.canonical)와 같은 접기
    # (재검토 2026-10-28 R9-3·R6-10)
    name = fold_text(name).strip()
    up = name.upper()
    if up in PLACEHOLDER_PROJECTS:
        return ""
    m = PROJECT_NO_RE.search(up)
    if m:
        return m.group()
    from watcher.project import LEAD_NO_RE
    m = LEAD_NO_RE.match(up)              # 'HB25-101 컨베이어 라인 증설' = 'HB25-101' (구매 평가 2차 P2)
    if m:
        return m.group(1)
    # 문자 접두 없는 번호("26-033", "…(26-033)")도 같은 묶음 (2026-09-03 검토)
    m = re.search(r"(?<![\w-])(\d{2}-\d{3})(?![\w-])", name)
    return m.group(1) if m else name


def _fold_tag(v) -> str:
    """BOM TAG 칸 값의 비교 꼴 — 접고, 소문자 태그('m-101')는 대문자로 태그 꼴에 맞으면 대문자로 (재검토 2026-10-28 R6-9)."""
    t = _fold(v).strip()
    if t and not _base.TAG_RE.fullmatch(t) and _base.TAG_RE.fullmatch(t.upper()):
        return t.upper()
    return t


def _folded_doc(d: Document) -> Document:
    """일관성 비교용 사본 — 본문 줄과 BOM 칸 값을 _fold로 접는다. 원문은 줄의 _raw·행의 _raw_row에. 바뀔 게 없으면 그대로.
    도면 'M－101 7.5kW'(전각 하이픈)·BOM 태그 'm-101'·제로폭 낀 'M-101'은 도면 태그와 짝이 안 돼 5.5kW↔7.5kW를 놓쳤다
    (재검토 2026-10-28 R6-8·R6-9)."""
    import copy
    new_lines, ch = [], False
    for ln in (d.raw_texts or []):
        t = _fold(ln.text) if isinstance(ln.text, str) else ln.text
        if t != ln.text:
            nl = _base.TextLine(t, ln.where, getattr(ln, "box", None))
            object.__setattr__(nl, "_raw", _raw_text(ln))
            new_lines.append(nl)
            ch = True
        else:
            new_lines.append(ln)
    tag_heads = {_head_key(n) for n in _TAG_COLS}
    new_rows, rch = [], False
    for r in (d.rows or []):
        vals = dict(r.values or {})
        for k, v in vals.items():
            if isinstance(v, str):
                vals[k] = _fold_tag(v) if (_head_key(k) in tag_heads
                                           or any(pk in tag_heads for pk in _base.head_pieces(k))) else _fold(v)
        if vals != (r.values or {}):
            nr = _base.Row(r.key, vals, r.where)
            object.__setattr__(nr, "_raw_row", r)
            new_rows.append(nr)
            rch = True
        else:
            new_rows.append(r)
    if not ch and not rch:
        return d
    out = copy.copy(d)
    if ch:
        out.raw_texts = new_lines
    if rch:
        out.rows = new_rows
    return out


def _raw_col(row, names) -> str:
    """근거용 — 접기 전 원문 칸 값."""
    return _col(getattr(row, "_raw_row", row), names)


def check_project_consistency(docs: list[tuple[str, Document]],
                              project_of=None, cfg: dict | None = None) -> list[Issue]:
    """프로젝트 단위 교차 검사 — 프로젝트마다 채운 '대시 없는 꼴 허용 이름'을 끝나면 비운다.
    cfg는 발주서 판정(issued.is_po — 사용자 문서 유형 규칙)에만 쓴다."""
    try:
        return _check_project_consistency(docs, project_of, cfg)
    finally:
        global _MODEL_TOKENS
        _MODEL_TOKENS = frozenset()
        _base.set_nodash_allow(None)


# 이름에 BOM·부품표·자재표가 든 엑셀은 이름에 '발주'가 함께 있어도(부품표_발주.xlsx) 도면-BOM 대조에 남긴다 — 단가 칸 있는 BOM이
# 발주서로 빠지면 진짜 BOM 불일치를 잃는다 (ux20 daily 3 적대 사례)
_BOM_NAME = re.compile(r"BOM|B\.O\.M|부품\s*표|자재\s*(?:표|목록|명세)|PARTS?\s*LIST", re.IGNORECASE)


def _po_only(path: str, doc: Document, cfg: dict | None) -> bool:
    """발주서라서 도면-BOM 대조에서 빼는가 — '발주 후 변경' 표지(issued.record_po)와 **같은 판정**(is_po: 이름·내용 제목에 더해
    돈 칸·발주번호 같은 내용 근거)일 때만. 발주서를 BOM으로 대조해 '도면-BOM 불일치 … BOM: 발주 시트 7행 · PO-…발주서.xlsx'가
    같은 사실의 '발주 후 변경' 표지와 겹쳐 났다 (ux20 daily 3). 견적서·거래명세서·납품서는 그대로 대조한다 — 그 문서들은 발주 후
    변경 쪽에서 보지 않으므로 빼면 견적 사양과 도면이 다른 것(구매가 틀린 모터를 산다)을 잃는다."""
    if _BOM_NAME.search(PurePosixPath(str(path)).stem):
        return False
    try:
        from watcher.issued import is_po
        return is_po(path, doc, cfg)
    except Exception:
        return False


def _check_project_consistency(docs: list[tuple[str, Document]],
                               project_of=None, cfg: dict | None = None) -> list[Issue]:
    """프로젝트 단위 교차 검사: 도면 간 태그 불일치 + 도면-BOM 불일치.

    project_of(path, doc) → 프로젝트: 검사가 쓰는 귀속기(표제란 > 파일명 > 폴더).
    없으면 표제란만 — PROJECT 열이 없는 BOM은 묶음에 못 들어가 검사가 빠졌다
    (2026-09-03 검토)."""
    issues = []
    by_project: dict[str, list[tuple[str, Document]]] = {}
    for path, doc in docs:
        raw = project_of(path, doc) if project_of else doc.project
        proj = _canon_project(raw) if raw else None
        if proj:
            by_project.setdefault(proj, []).append((path, doc))

    _twin_drop: set = set()          # 도면-BOM 카드에 합친 도면 간 카드의 자리 (J3)
    for proj, members in sorted(by_project.items()):
        _tag_twin: dict = {}         # 태그 → (자리, 기준 출현, 첫 충돌 출현, 기준 값, 충돌 값, 인용 경로들)
        _bom_twin: dict = {}         # 태그 → (자리, 어긋난 도면 경로, BOM과 같은 값 도면이 있나)
        # 비교는 접은 사본으로 — 전각·제로폭·호환 단위·태그 표기 변종(R9-2·R6-3·R6-8·R6-9). 근거에는 원문을 싣는다
        members = [(p, _folded_doc(d)) for p, d in members]
        drawings = [(p, d) for p, d in members if d.doc_type in ("dxf", "pdf")]
        boms = [(p, d) for p, d in members if d.doc_type == "xlsx" and d.rows and not _po_only(p, d, cfg)]
        # 대시 없는 꼴(설정에서 켰을 때)은 이 프로젝트 BOM의 TAG 열 이름만 태그 (검토48 B 차단 1·2) — base.is_tag
        _base.set_nodash_allow(frozenset(v for _p, b_ in boms for v in (_col(r, _TAG_COLS) for r in b_.rows) if v))

        # 도면별 태그→줄 사전은 1회만 계산해 재사용 — BOM 행마다 재계산하면
        # (BOM 1,000행 × 도면 30장 = 3만 번 전체 스캔) 프로젝트당 수 초가 걸린다
        # (2026-08-25 확장성 검토: 7.9초 → 캐시 후 밀리초)
        # 태그의 전 출현 줄 — 첫 줄만 보면 심볼 옆/결선표 두 곳에 나오는
        # 태그에서 엉뚱한 줄과 비교하게 된다 (2026-08-26)
        # 금액·수량을 걷어 낸 비교용 줄 — 상거래 문서(견적서·발주서·송장·납품서)는 맨 숫자·수량 단위까지 (구매 평가 2차 F1)
        from watcher.doctype import commercial_kind as _ck
        tag_map = {path: _commerce_tag_map(tag_lines_with_specs(d), _ck(path, d) is not None) for path, d in drawings}
        _drop_stale_issue_pages(drawings, tag_map)
        # 근거에 도면의 Rev·날짜를 싣는다 — 어느 쪽이 더 최근 판인지 도면을 못 읽는
        # 사람도 알 수 있게 (2026-09-02 처음 보는 사람 검토: 구매 담당)
        stamp = {path: _rev_stamp(d) for path, d in drawings}

        # 도면 간: 같은 태그의 사양값 토큰이 다르게 등장 (도면 번호가 다른 것끼리만).
        # 전 출현을 모은 뒤 비교한다 — 첫 출현과만 비교하면 사양 없는 줄(태그가 줄 끝)이
        # 먼저 나올 때 이후 도면들 간의 실제 불일치가 가려진다.
        # 같은 도면번호가 여럿(old/·Backup/ 구판·복사본)이면 현행·최고 Rev 한 장만 — BOM 검사는 이미
        # 그랬는데 도면 간 검사는 구판이 정렬 순서에 따라 '기준'이 되어 현행 3장을 '다른 값'이라 했다
        # (검토25 감지 6-3)
        # 같은 도면번호의 여러 파일 가운데 **판 사본**(이름이 판 표기만 다르거나 구판 폴더·복사본)만 겨루고,
        # 이름이 다른 같은 번호 파일(시트 E-101_SH1/SH2/SH3)은 전부 남긴다 — 시트를 구판으로 보고 한 장만
        # 남겨 나머지 시트의 태그가 검사에서 조용히 빠졌다 (검토30 B 5-A). 동률은 무표기 이름 우선 (5-E)
        from watcher.scan import pair_key as _pk, ver_rank as _vr
        by_no: dict = {}
        for path, d in drawings:
            no = d.fields["DWG_NO"].value if "DWG_NO" in d.fields else None
            if no:
                by_no.setdefault(no, []).append((path, d))

        from watcher.cli import sheet_bases as _sb, is_copy_marked as _icm
        _sheets = _sb([p for p, _ in drawings])

        def _rival(a: str, b: str) -> bool:
            na, nb = PurePosixPath(a).name, PurePosixPath(b).name
            return (_pk(na) == _pk(nb) or _OLD_FOLDER.search(a) or _OLD_FOLDER.search(b)
                    or _icm(a, _sheets) or _icm(b, _sheets))

        from watcher.scan import rev_key as _rk, rev_shape as _rs

        def _mixed(files) -> bool:
            # cli._version_comparer와 같은 규칙 — Rev **모양**이 섞였으면 Rev로 겨루지 않는다 (검토36 A N1)
            return len({_rs(dd.revision) for _q, dd in files if str(dd.revision or "").strip()}) > 1

        def _beats(q, dq, p, d, use_rev: bool = True) -> bool:
            """q(dq)가 p(d)보다 현행인가 — cli._superseded_paths._cmp와 같은 순서.
            old/·구버전/ 안의 판은 Rev가 더 높아 보여도(현행이 Rev 빈칸) 현행에 밀린다 (검토19c N7f);
            사본 표식은 항상 진다(검토31 B5); '0' vs 'A'처럼 체계가 다른 Rev는 비교하지 않는다(B3)"""
            oq, op = bool(_OLD_FOLDER.search(q)), bool(_OLD_FOLDER.search(p))
            if oq != op:
                return op
            cq, cp = _icm(q, _sheets), _icm(p, _sheets)
            if cq != cp:
                return cp
            rq, rp = str(dq.revision or "").strip().upper(), str(d.revision or "").strip().upper()
            if use_rev and rq and rp and rq != rp and _rs(rq) == _rs(rp) and _rk(rq) != _rk(rp):
                return _rk(rq) > _rk(rp)
            vq, vp = _vr(PurePosixPath(q).name), _vr(PurePosixPath(p).name)
            uq, up = vq == (1, 0, ""), vp == (1, 0, "")
            if uq != up:
                return uq
            if vq[0] == 3 and vp[0] == 3 and vq != vp:
                # 이름 판 표기도 모양이 같을 때만 순서가 있다 — 다르면 어느 쪽도 이기지 않는다(둘 다 남김).
                # cli._version_comparer가 저장 시각으로 먼저 걸렀다 (검토36 A N1)
                if _rs(vq[2]) != _rs(vp[2]):
                    return False
                return _rk(vq[2]) > _rk(vp[2])
            return vq > vp
        superseded: set = set()
        for no, files in by_no.items():
            _use = not _mixed(files)          # 체계가 섞인 묶음은 Rev로 겨루지 않는다 (검토32 B2)
            for path, d in files:
                if any(_rival(path, q) and _beats(q, dq, path, d, _use) for q, dq in files if q != path):
                    superseded.add(path)
        drawings_cur = [(p, d) for p, d in drawings if p not in superseded]
        # 구판 폴더에만 남은 도면번호·DWG_NO 없는 구판은 위 규칙이 못 거른다 — 프로젝트에 구판 폴더 밖
        # 도면이 하나라도 있으면 구판 폴더는 통째로 뺀다(구판은 판 짝짓기용) (2회차 A4)
        if any(not _OLD_FOLDER.search(p) for p, _ in drawings):
            drawings_cur = [(p, d) for p, d in drawings_cur if not _OLD_FOLDER.search(p)]
        occurrences: dict[str, list[_Occ]] = {}
        for path, d in drawings_cur:
            dwg_no = d.fields["DWG_NO"].value if "DWG_NO" in d.fields else path
            for tag, lines in tag_map[path].items():
                for line in lines:
                    # 'DOC NO: QI-6002  REV: A  DATE: 2026-09-26'의 QI-6002는 기기 태그가 아니라 문서번호다 — 그 뒤 일자를 사양으로
                    # 읽어 '태그 QI-6002의 사양이 도면 간에 다릅니다 (2026-09-26 vs 2026-10-08)'가 났다 (검토68 B40)
                    _txt = line.text
                    if _is_number_label(_txt, tag):
                        # 같은 높이의 다른 글('QI-6002 24VDC')이 붙어 한 줄이 됐으면 번호 칸 조각만 지우고 나머지로 본다 — 줄을 통째로
                        # 건너뛰어 그 도면의 24VDC 사양이 비교에서 빠졌다 (검토69 B N3)
                        _txt = _strip_number_label(_txt, tag)
                        if not _txt or not _tag_re(tag).search(_txt):
                            continue
                    spec = _spec_token(_txt, tag)
                    if spec:  # 사양 없는 출현은 비교 대상이 아니고, 다른 출현을 가리지도 않는다
                        occurrences.setdefault(tag, []).append(
                            _Occ(spec, _txt, path, line.where, dwg_no, getattr(line, "_raw", None) or _txt))
        global _MODEL_TOKENS
        _MODEL_TOKENS = _model_tokens(drawings, tag_map, boms)
        for tag, occs in sorted(occurrences.items()):
            # 숫자를 품은 값 토큰 **집합**끼리 견준다 — 첫 토큰만 보면 'M-101 5.5kW 4P' vs
            # 'M-101 4P 5.5kW'(순서), 'CV 4SQ 3C' vs 'CV 3C 4SQ'가 헛경보였다. 한쪽에 숫자
            # 토큰이 없으면(P&ID의 'CONVEYOR MOTOR') 비교하지 않는다 (검토19 2차 감지 N5)
            base = next((o for o in occs if _num_units(o.text, tag)), None)
            if base is None:
                continue
            bunits = _num_units(base.text, tag)
            conflicts = []
            seen_no: set = set()
            for o in occs:
                # 같은 파일만 건너뛴다 — 도면번호로 건너뛰면 같은 번호의 다른 시트가 비교에서 빠진다 (5-A)
                if o.path == base.path or o.path in seen_no:
                    continue
                # 판 순서를 가리지 못해 둘 다 남은 **같은 도면의 두 판**(같은 도면번호, 서로 판 사본)은 도면 간
                # 불일치가 아니다 — 형제 폴더(설계/·발행/)의 두 판을 매일 '7.5kW vs 5.5kW'로 불렀다 (검토36 E 중간 1)
                if o.dwg_no == base.dwg_no and _rival(o.path, base.path):
                    continue
                ounits = _num_units(o.text, tag)
                if ounits and _units_conflict(bunits, ounits):
                    conflicts.append(o)
                    seen_no.add(o.path)
            if conflicts:
                # 충돌 도면을 **전부** 근거에 싣는다 — 하나만 보고하면 그걸 고친 뒤 다음 것이
                # 새 경고로 떠 두더지 잡기가 됐다 (검토19 2차 감지 N6)
                first = conflicts[0]
                # 기준값과 같은 도면도 센다 — "관련 파일 2개"가 실제 31개였다 (검토21 파일럿 중간 3)
                same_no = {o.path for o in occs
                           if o.path != base.path and o.path not in seen_no
                           and _num_units(o.text, tag) and not _units_conflict(bunits, _num_units(o.text, tag))}
                ev = [f"{base.dwg_no}{stamp[base.path]}: {base.shown or base.text} ({base.where}, {base.path})"]
                ev += [f"{o.dwg_no}{stamp[o.path]}: {o.shown or o.text} ({o.where}, {o.path})"
                       for o in conflicts[:6]]
                # 실제로 어긋난 단위 값으로 쓴다 — 첫 숫자 조각(380V)을 인용해 '380V와 같은 도면 1장 · 다른 값 1장'처럼
                # 틀린 값을 근거로 댔다 (검토44 B G08). 문구(이슈 키)는 그대로 둔다
                _bv, _fv = _conflict_vals(bunits, _num_units(first.text, tag))
                if _bv:
                    ev.append(f"어긋난 값: {_bv} ↔ {_fv}")
                _shown = list(dict.fromkeys([base.spec] + [o.spec for o in conflicts]))
                if len(_shown) < 2 and _bv:
                    # 첫 값 토큰(7.5kW)이 같고 다른 칸(30AT↔40AT)이 어긋나면 첫 토큰만 적어 '(7.5kW)' — 무엇이 다른지 없는 문구였다
                    # (검토68 B02·B30). 실제로 어긋난 값으로
                    _shown = list(dict.fromkeys([_bv] + [_conflict_vals(bunits, _num_units(o.text, tag))[1] or o.spec
                                                         for o in conflicts]))
                ev.append(f"{_bv or base.spec}와 같은 도면 {1 + len(same_no)}장 · 다른 값 도면 {len(conflicts)}장"
                          + (f" (위에 6장까지 표시)" if len(conflicts) > 6 else ""))
                # 메시지에 장수를 넣지 않는다 — 장수가 바뀌면 다른 이슈로 보여 옛 것은 '자동 해소',
                # 새 것은 새 날짜로 재등록돼 문제 발생일이 초기화됐다 (검토21 파일럿 중간 4)
                issues.append(Issue(
                    "TAG_MISMATCH_ACROSS_DRAWINGS", first.path,
                    f"[{proj}] 태그 {tag}의 사양이 도면 간에 다릅니다"
                    # 셋째 값(11kW)도 — 둘만 적어 구매가 두 값만 보고 넘어갔다 (검토48 C 중간 2). 괄호 안이라 이슈 키는 그대로
                    f" ({' vs '.join(_shown[:4])}).", tuple(ev)))
                _tag_twin[tag] = (len(issues) - 1, base, first, _bv or base.spec, _fv or first.spec,
                                  {base.path} | {o.path for o in conflicts} | set(same_no))

        _MODEL_TOKENS = frozenset()       # 모델번호를 값으로 보는 것은 도면 간 대조만 — 도면-BOM은 known_tags 규칙이 따로 있다
        # 도면-BOM: BOM SPEC 값이 해당 태그의 도면 줄에 없으면 불일치.
        # 같은 태그가 도면 30장에 있으면 30건이 아니라 **태그당 1건**만 —
        # 대형 프로젝트에서 이슈 수천 건으로 화면·브리핑이 마비되는 것 방지
        # (2026-08-25 확장성 검토: 시나리오 1,493건 → 태그당 1건)
        known_tags: set = set()
        for path in tag_map:
            known_tags |= set(tag_map[path].keys())
        for bom_path, bom in boms:
            known_tags |= {_col(r, _TAG_COLS) for r in bom.rows} - {""}
            # 대시 없는 태그(M4201, X422)는 인식 패턴에 맞지 않아 도면 간·도면-BOM 대조가 이 프로젝트에서
            # 통째로 침묵했고 아무도 몰랐다 (검토21 파일럿 중간 7) — 표기가 패턴과 다르면 한 번 알린다
            vals = [v for v in (_col(r, _TAG_COLS) for r in bom.rows) if v]
            odd = sorted({v for v in vals
                          if not _base.TAG_RE.fullmatch(v) and re.search(r"\d", v) and re.search(r"[A-Za-z]", v)})
            # 사양 칸이 없는 목록(PLC 태그 리스트 '주소 | 태그 | 설명')은 도면과 견줄 값이 애초에 없다 — 기준선부터 '태그
            # 표기 인식 불가'를 매일 띄웠다 (검토68 C4). 태그 행 절반 이상에 사양 값이 있을 때만 알린다
            specd = sum(1 for r in bom.rows if _col(r, _TAG_COLS) and _col(r, _SPEC_COLS))
            # 사양 열을 못 찾았는데(머리글 '형식'·'DESCRIPTION' 등) 다른 열에 사양 같은 값(5.5kW·100AF)이 있으면 대조가 꺼졌다는
            # 사실을 한 번 알린다 — 꺼졌다는 안내가 전혀 없었다 (검토20 r08 1). PLC 태그 목록('주소 | 태그 | 설명')은 값이 없어 조용
            rec = [v for v in vals if _base.TAG_RE.fullmatch(v)]
            if len(rec) >= 3 and specd == 0:
                _cand = _spec_like_head(bom.rows)
                if _cand:
                    issues.append(Issue(
                        "BOM_SPEC_COLUMN_UNRECOGNIZED", bom_path,
                        f"[{proj}] BOM에서 사양 열을 찾지 못해 도면-BOM 대조를 하지 않았습니다 (사양 같은 값이 든 열: {_cand}).",
                        (f"BOM 열 '{_cand}'에 사양 같은 값이 있지만 사양 열 이름이 아닙니다 ({bom_path})",
                         "열 이름을 '규격'·'사양'·'SPEC'·'형식' 중 하나로 하면 다음 검사부터 도면과 대조합니다")))
            if len(vals) >= 3 and len(odd) * 2 >= len(vals) and specd * 2 >= len(vals):
                # 인식된 태그가 있으면 그 태그들은 대조가 돈다 — '하지 못했습니다'가 같은 메일의 도면-BOM 경고와 어긋났다 (검토20 r12 4)
                _part = len(rec) > 0
                issues.append(Issue(
                    "TAG_PATTERN_UNRECOGNIZED", bom_path,
                    (f"[{proj}] BOM의 일부 태그 표기(예: {odd[0]})가 인식 패턴과 달라 그 태그들은 도면-BOM·도면 간 대조를 "
                     f"하지 못했습니다 — config.yaml의 tag_pattern으로 표기 규칙을 알려 주세요." if _part else
                     f"[{proj}] BOM의 태그 표기(예: {odd[0]})가 인식 패턴과 달라 도면-BOM·도면 간 대조를 "
                     f"하지 못했습니다 — config.yaml의 tag_pattern으로 표기 규칙을 알려 주세요."),
                    (f"BOM TAG 열 예: {', '.join(odd[:5])} ({bom_path})",
                     # 문구(이슈 키)는 그대로 두고 근거에서 고칠 곳을 알린다 — config.yaml 정규식은 IT 담당도 못 고쳤다
                     "설정 › 태그 표기에서 회사 꼴(대시 없는 꼴 등)을 켜면 다음 검사부터 대조합니다 "
                     "(기본: 'M-101', '1M-1', 'MCCB-01' 꼴 — 글자-숫자 사이 대시)")))
        # BOM 사양 칸의 모델명(GMC-32)은 태그 꼴이라 도면의 GMC-22가 '태그'로 제외돼 모델명
        # 불일치를 통째로 못 봤다 (2026-09-04 사용자 관점 검토 #3). 사양 칸에 태그 꼴로
        # 나오는 계열(글자 접두 GMC)은 태그가 아니라 값으로 본다 — BOM TAG 열에 실제로
        # 있는 것만 예외. "M-101 → CP-01" 같은 상대 태그(CP 계열은 사양 칸에 없음)는 그대로
        bom_tags: set = set()
        model_prefixes: set = set()
        for bom_path, bom in boms:
            for r in bom.rows:
                bom_tags.add(_col(r, _TAG_COLS))
                sp = _col(r, _SPEC_COLS)
                for piece in (re.split(r"[\s/,;]+", sp) if sp else ()):
                    m = _MODEL_RE.match(piece)
                    if m:
                        model_prefixes.add(m.group(1).upper())
        # 어느 도면에서든 줄의 첫 태그 자리에 나오는 것(CP-01 24VDC)은 태그로 남긴다 —
        # 다른 태그 뒤에만 나오는 것(MC-02 GMC-22의 GMC-22)만 값으로 강등 (재검토 ②-5)
        leading: set = set()
        for path, d in drawings:
            for ln in d.raw_texts:
                first = find_tags(ln.text)[:1]
                if first:
                    leading.add(first[0])
        known_tags = {tg for tg in known_tags
                      if tg in bom_tags or tg in leading or not (
                          _MODEL_RE.match(tg) and _MODEL_RE.match(tg).group(1).upper()
                          in model_prefixes)}
        # 같은 도면번호가 여럿(old/ 구판·복사본)이면 최고 Rev 한 장만 BOM과 대조한다 —
        # 구판의 3.7kW 때문에 BOM 3파일이 전부 불일치로 남았다 (검토19 2차 감지 N7). 위 도면 간과 같은 목록
        # 대표 근거는 **도면**을 먼저 — 사양서 PDF가 앞에 와 '도면 [Rev 1]: … 사양서.pdf'로 인용됐다 (검토44 C 중간 3)
        from watcher.doctype import kind_of as _kind_of

        def _is_dwg(p_):
            return PurePosixPath(p_).suffix.lower() in (".dxf", ".dwg") or _kind_of(p_) == "도면"
        drawings_for_bom = sorted(drawings_cur, key=lambda pd: 0 if _is_dwg(pd[0]) else 1)
        # 세트 PDF는 쪽(시트)마다 다른 도면이다 — 1쪽(E-101)의 'M-101 5.5kW'가 BOM과 같다고 2쪽(E-102)의 'M-101 7.5kW'까지
        # 일치로 넘겼다 (검토66 P16). 쪽마다 도면번호가 다르면 시트별로 따로 견준다. DXF 배치 시트도 (갈래 A 2026-10-16)
        _doc_of = dict(drawings_for_bom)

        def _sheet_groups(p_, lines):
            return sheet_line_groups(_doc_of.get(p_), lines)
        for bom_path, bom in boms:
            seen_tags: set[str] = set()
            for row in bom.rows:
                tag = _col(row, _TAG_COLS)
                spec = _col(row, _SPEC_COLS)
                if not tag or not spec or tag in seen_tags:
                    continue
                # 같은 태그의 둘째 행부터는 견주지 않는다 — 병합된 TAG가 채워진 이어짐 행('도장 7-tone')의 규격 조각이 도면
                # 기재와 달라 거짓 불일치 근거가 됐다 (검토52 B 낮음 2). 첫 행(앵커)이 그 태그의 사양이다
                seen_tags.add(tag)
                nspec = _norm(spec)
                pieces = _spec_pieces(spec)

                bunits_bom = _num_units(f"{tag} {spec}", tag)
                # BOM 사양의 주 값(첫 값)의 단위만 — '5.5kW 4P 380V'의 kW, '24VDC'의 전압. 단위 모르는 덩어리('?')·단위 없는 숫자·
                # 극수(P)·범위는 주 값으로 보지 않는다 (아래 '한 시트 안 다른 값' 규칙이 쓴다)
                _pu = next(iter(bunits_bom), None)
                prim = ({_pu: bunits_bom[_pu]} if _pu and _pu not in ("?", "p") and not _pu.startswith("~") else None)
                _row_words = set().union(*(_desc_words(str(v)) for v in (row.values or {}).values() if v not in (None, "")))

                def _mismatch(lines):
                    # 단위별 값(kW·A·SQ…)으로 견준다 — 도면 간 검사와 같은 규칙. 첫 토큰 규칙은
                    # 'M-101 4P 7.5kW' 순서면 '4P'가 맞아 5.5→7.5를 놓쳤다 (검토25 6-2·검토26 1회차 3).
                    # 단위 값이 없는 사양(PLC 형식 'FX5U-32M')은 예전 조각 규칙으로.
                    # 값 토큰이 없는 줄(태그만·설명만 적힌 줄)은 비교 대상이 아니다.
                    # 돌려주는 값: 불일치면 비교한 줄, 일치·비교 불가면 None
                    first_bad = None
                    bads: list = []
                    agreed = False
                    strong = []                  # (줄, 그 줄의 설명 낱말) — 주 값 단위로 BOM과 다른 값을 적은 줄
                    agree_words: set = set()
                    for ln in lines:
                        # 'B 2026-10-13 MCCB-41 50AT->75AT'처럼 옛 값→새 값을 적은 줄(리비전 표 행)은 현재 사양이
                        # 아니다 — 옛 값 50AT로 '일치'가 나서 도면-BOM 불일치가 30일 내내 안 잡혔다 (검토38 R3 차단 1)
                        text = _current_values(ln.text)
                        # 한 시트 안에 같은 태그가 두 번(일람표 5.5kW · 결선 표기 7.5kW) 나오면 BOM과 같은 줄 하나가 다른 줄의 다른
                        # 값을 덮어 '일치'였다 (갈래 A 2026-10-16, adv69 B4). BOM **주 값의 단위**로 다른 값을 적은 줄은 같은 줄이
                        # 따로 있어도 불일치다. 날짜가 든 줄(개정표 행·철거·시험 기록)은 옛 값 기록일 수 있어 이 규칙에서 뺀다.
                        # 그 줄이 같은 것을 같은 말로 적었을 때만 — 설명 낱말이 BOM 행이나 BOM과 맞는 줄에 다 있을 때. 'M-101 MOTOR 7.5kW
                        # STARTER'(기동기 정격)처럼 다른 부품을 이르는 줄은 아니다 (test_bench_pdf 한 도면 두 번)
                        if prim and not _dated_record_line(str(ln.text or "")):
                            _ou = _num_units(text, tag)
                            if _ou and _units_conflict(prim, _ou):
                                # 날짜 든 괄호 덧말('(2026.10.20 교체 설치)')은 설명 낱말이 아니다 (검토71 R3 A71-12)
                                _st = re.sub(r"\([^()]*\)", lambda m_: " " if _DATE_IN_TEXT.search(m_.group(0)) else m_.group(0),
                                             text)
                                strong.append((ln, _desc_words(_tag_segment(tag, _st))))
                        if _word_conflict(spec, text, tag):        # 숫자 없는 사양 낱말(NPN·RED)도 (검토41 S3 중간 2)
                            if first_bad is None:
                                first_bad = ln
                            bads.append(ln)
                            continue
                        toks = [x for x in _tokens_after(tag, text) if _spec_like(x, known_tags)]
                        if not toks:
                            continue
                        if _line_has_spec(nspec, text):
                            agreed = True
                            agree_words |= _desc_words(_tag_segment(tag, text))
                            continue
                        # 숫자 없는 사양('LAMP RED')은 낱말 순서만 달라도('RED LAMP 24V') 같은 사양이다 — 거짓 도면-BOM 불일치가
                        # 났다 (검토64 C-F4). 사양의 낱말이 모두 그 줄에 있으면 일치
                        _sw = [w.upper() for w in re.split(r"[\s/,;]+", str(spec)) if w]
                        if _sw and not any(ch.isdigit() for ch in str(spec)) and len(_sw) >= 2 \
                                and set(_sw) <= {w.upper() for w in re.split(r"[\s/,;]+", text) if w}:
                            agreed = True
                            agree_words |= _desc_words(_tag_segment(tag, text))
                            continue
                        if bunits_bom:
                            ou = _num_units(text, tag)
                            if not ou:
                                continue
                            if not _units_conflict(bunits_bom, ou):
                                agreed = True
                                agree_words |= _desc_words(_tag_segment(tag, text))
                                continue
                        elif _norm(toks[0]) in pieces:
                            agreed = True
                            agree_words |= _desc_words(_tag_segment(tag, text))
                            continue
                        if first_bad is None:
                            first_bad = ln
                        bads.append(ln)
                    _same = agree_words | _row_words
                    hit = next((ln for ln, w in strong if w <= _same), None)
                    if hit is not None:
                        return hit
                    if agreed or first_bad is None:
                        return None
                    # 근거로 내세울 줄은 사양 줄이 먼저 — 개정표 행 'B 2026-10-09 MCCB-04 트립 100AT 상향'이 사양 줄
                    # 'MCCB-04 100AF 100AT 3P'보다 앞에 그려져 근거의 도면 값이 개정 문구로 나왔다 (구매 평가 2차 P2 day5·9)
                    return next((b_ for b_ in bads if not _dated_record_line(_raw_text(b_))), first_bad)

                def _bad_of(p_):
                    lines_ = tag_map[p_].get(tag)
                    return next((b_ for g_ in _sheet_groups(p_, lines_) for b_ in [_mismatch(g_)] if b_ is not None),
                                None) if lines_ else None

                for path, d in drawings_for_bom:
                    bad = _bad_of(path)
                    if bad is not None:
                        n_more = sum(
                            1 for p2, _ in drawings_for_bom
                            if p2 != path and tag_map[p2].get(tag)
                            and _bad_of(p2) is not None)
                        extra = f" (외 도면 {n_more}장에서도 불일치)" if n_more else ""
                        # BOM과 **같은** 값의 도면도 근거에 — 옛 도면 하나만 인용하면 구매가
                        # "도면이 맞고 BOM이 틀렸다"로 거꾸로 읽는다 (검토24 A-1)
                        # 단위별 값(kW·A·SQ…)이 BOM과 충돌하지 않는 도면만 — 첫 토큰 규칙은 '4P'가
                        # 같다고 7.5kW 도면을 5.5kW BOM과 '같은 값'이라 했다 (검토25 감지 6-2)
                        bunits_ = _num_units(f"{tag} {spec}", tag)
                        # 같은 값으로 세려면 어떤 단위에서든 값이 실제로 겹쳐야 한다 — 부속만 적힌
                        # 'M-401 MOTOR 4P'가 같은 값 도면에 들어갔다 (2회차 A3)
                        # 그 도면 자신도 (다른 시트·다른 줄에서) BOM과 어긋나면 '같은 값의 도면'으로 세지 않는다 (갈래 A 2026-10-16)
                        agree = [p2 for p2, _ in drawings_for_bom
                                 if p2 != path and tag_map[p2].get(tag) and bunits_ and _bad_of(p2) is None
                                 and any((lambda u: u and not _units_conflict(bunits_, u)
                                          and any(bunits_.get(k) and (bunits_[k] & v) for k, v in u.items()
                                                  if k.upper() not in ("P", "")))   # 극수·단위 없는 숫자는 부속 (3회차 A5)
                                         (_num_units(ln.text, tag))
                                         for ln in tag_map[p2][tag])]
                        ev = [f"BOM: {_raw_col(row, _TAG_COLS) or tag} SPEC={_raw_col(row, _SPEC_COLS) or spec} ({row.where}, {bom_path})",
                              (f"도면 {_sl}{stamp[path]}: {_raw_text(bad)} ({bad.where}, {path})"
                               if (_sl := set_sheet_label(d, int(_pm.group(1)) if (_pm := _PAGE_HEAD.match(str(bad.where or ""))) else None))
                               else f"{'도면' if _is_dwg(path) else '문서'}{stamp[path]}: {_raw_text(bad)} ({bad.where}, {path})")]
                        if agree:
                            # 사양서 같은 문서는 '도면'으로 세지 않는다 (검토45 C 낮음 2)
                            def _names(ps):
                                return (", ".join(f"{PurePosixPath(p2).name}{stamp[p2]}" for p2 in ps[:4])
                                        + (" 외" if len(ps) > 4 else ""))
                            a_d = [p2 for p2 in agree if _is_dwg(p2)]
                            a_o = [p2 for p2 in agree if not _is_dwg(p2)]
                            parts_ = ([f"도면 {len(a_d)}장: {_names(a_d)}"] if a_d else []) \
                                + ([f"문서 {len(a_o)}건: {_names(a_o)}"] if a_o else [])
                            ev.append("BOM과 같은 값의 " + " · ".join(parts_) + " — 어느 쪽이 최신인지 확인하세요")
                        issues.append(Issue(
                            "BOM_MISMATCH", bom_path,
                            f"[{proj}] {tag}: BOM 사양과 도면 기재가 다릅니다.{extra}",
                            tuple(ev)))
                        _bom_twin.setdefault(tag, (len(issues) - 1, path, bool(agree)))
                        seen_tags.add(tag)
                        break
        _merge_twins(issues, _tag_twin, _bom_twin, _twin_drop)
    return [i for k, i in enumerate(issues) if k not in _twin_drop]


def _merge_twins(issues: list, tag_twin: dict, bom_twin: dict, drop: set) -> None:
    """같은 사실 두 카드 합치기 (기능 검토 2026-11-02 J3) — 도면 E-101·BOM이 7.5kW, 도면 E-104만 5.5kW면 '도면 간 태그 사양 불일치'와
    '도면-BOM 불일치'가 같은 태그·값 쌍을 두 번 말했다(알림 피로, 구매자 평가 B8·watch B3). 같은 프로젝트·같은 태그에서 BOM과
    어긋난 도면이 도면 간 충돌에 든 도면이고 BOM과 같은 값의 도면이 있을 때만 합친다. 남는 카드는 도면-BOM(구매 담당이 받는
    카드, 이슈 대조 키 그대로)이고 문구 괄호에 'E-101·BOM 7.5kW ↔ E-104 5.5kW', 근거에 두 카드의 근거를 모두 싣는다."""
    for tag, (bi, bad_path, has_agree) in bom_twin.items():
        t = tag_twin.get(tag)
        if t is None or not has_agree:
            continue
        ti, base, first, bv, fv, cited = t
        if bad_path not in cited or ti in drop:
            continue
        b_iss, t_iss = issues[bi], issues[ti]
        with_base = bad_path != base.path          # BOM이 기준 도면 쪽 값과 같다
        def _lbl(o):            # 도면번호가 없으면 dwg_no가 경로다 — 파일 이름만
            return PurePosixPath(str(o.dwg_no)).name if "/" in str(o.dwg_no) else o.dwg_no
        side = (f"{_lbl(base)}{'·BOM' if with_base else ''} {bv} ↔ "
                f"{_lbl(first)}{'' if with_base else '·BOM'} {fv}")
        # str.replace 이름은 읽기 전용 검사(test_readonly)가 막는다 — 나눠 잇는다
        msg = f"BOM 사양과 도면 기재가 다릅니다 ({side} · 도면 간에도 다름).".join(
            b_iss.message.split("BOM 사양과 도면 기재가 다릅니다.", 1))
        # 도면 간 근거는 '[도면 간]'을 붙여 싣는다 — '도면'으로 시작하는 줄은 도면-BOM 값 비교(state._mismatch_values)가 도면 줄로 읽는다
        ev = tuple(b_iss.evidence) + tuple(f"[도면 간] {e}" for e in t_iss.evidence)
        issues[bi] = Issue(b_iss.code, b_iss.path, msg, ev, absorbed=(t_iss.code, t_iss.path, t_iss.message))
        drop.add(ti)
