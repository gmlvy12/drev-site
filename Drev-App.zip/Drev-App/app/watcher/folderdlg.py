# -*- coding: utf-8 -*-
"""윈도우 폴더 선택 대화상자 (2026-08-31, 2026-09-01 개선).

사용자 요구:
- "찾아보기를 누르면 경로를 직접 넣어줘야 하네" → 탐색 창을 띄운다 (08-31)
- "위에 주소도 복사해서 넣을 수 있는 창으로" → 구식 트리 창(SHBrowseForFolder)
  대신 **탐색기와 같은 최신 대화상자(IFileDialog)** 를 쓴다 (09-01).
  이 창은 상단 주소 표시줄이 있고, 아래 '폴더' 칸에 `\\\\서버\\공유` 같은 경로를
  붙여넣어 바로 이동할 수 있다.

포터블판의 임베디드 파이썬에는 tkinter가 없으므로 윈도우 API를 ctypes로 직접
부른다(추가 의존성 없음). 최신 대화상자를 못 여는 환경에서는 구식 창으로 물러난다.
읽기 전용: 경로 문자열 하나를 돌려줄 뿐 파일을 만지지 않는다 (원칙 2).
"""

from __future__ import annotations

import os

WINDOW_TITLE = "Drev — 산출물 변경 감시"

# ---- 구식 창(폴백)용 플래그
BIF_RETURNONLYFSDIRS = 0x00000001
BIF_NEWDIALOGSTYLE = 0x00000040
BIF_EDITBOX = 0x00000010

# ---- IFileDialog(최신 창)용 상수
CLSID_FileOpenDialog = "{DC1C5A9C-E88A-4DDE-A5A1-60F82A20AEF7}"
IID_IFileOpenDialog = "{D57C7288-D4AD-4768-BE02-9D969532D960}"
FOS_PICKFOLDERS = 0x00000020
FOS_FORCEFILESYSTEM = 0x00000040
FOS_PATHMUSTEXIST = 0x00000800
SIGDN_FILESYSPATH = 0x80058000
CLSCTX_INPROC_SERVER = 1


def available() -> bool:
    """이 환경에서 대화상자를 띄울 수 있는가 (윈도우 데스크톱)."""
    return os.name == "nt"


def _owner_hwnd(ctypes) -> int:
    """앱 창을 소유자로 지정 — 대화상자가 창 뒤로 숨지 않게."""
    try:
        return ctypes.windll.user32.FindWindowW(None, WINDOW_TITLE) or 0
    except Exception:
        return 0


def _com_call(ptr, index, argtypes=(), *args):
    """COM 인터페이스의 vtable 메서드 호출 (ctypes만으로).

    인자 타입을 명시적으로 받는다 — byref()가 만드는 임시 객체는 타입 추론이
    되지 않아 호출이 실패했다 (2026-09-01)."""
    import ctypes
    vtbl = ctypes.cast(ptr, ctypes.POINTER(ctypes.c_void_p)).contents.value
    fn_ptr = ctypes.cast(vtbl, ctypes.POINTER(ctypes.c_void_p))[index]
    proto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, *argtypes)
    return proto(fn_ptr)(ptr, *args)


def _modern_dialog(title: str, start: str | None) -> str | None:
    """탐색기와 같은 최신 폴더 선택 창 — 주소 표시줄·경로 붙여넣기 지원."""
    import ctypes
    from ctypes import wintypes

    ole32 = ctypes.windll.ole32
    shell32 = ctypes.windll.shell32
    # GUID는 16바이트 구조체 포인터로 넘긴다 (문자열 포인터로 선언하면 호출 실패)
    ole32.CoCreateInstance.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                       ctypes.c_ulong, ctypes.c_void_p,
                                       ctypes.POINTER(ctypes.c_void_p)]
    shell32.SHCreateItemFromParsingName.argtypes = [
        ctypes.c_wchar_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p)]

    def guid(text: str):
        g = (ctypes.c_byte * 16)()
        if ole32.CLSIDFromString(ctypes.c_wchar_p(text), ctypes.byref(g)) != 0:
            raise OSError("GUID 변환 실패")
        return g

    pfd = ctypes.c_void_p()
    clsid, iid = guid(CLSID_FileOpenDialog), guid(IID_IFileOpenDialog)
    hr = ole32.CoCreateInstance(ctypes.byref(clsid), None,
                                CLSCTX_INPROC_SERVER, ctypes.byref(iid),
                                ctypes.byref(pfd))
    if hr != 0 or not pfd:
        raise OSError(f"대화상자를 만들지 못했습니다 (0x{hr & 0xFFFFFFFF:08X})")
    try:
        # vtable: 3 Show / 9 SetOptions / 12 SetFolder / 17 SetTitle / 20 GetResult
        _com_call(pfd, 9, (ctypes.c_ulong,),
                  FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST)
        _com_call(pfd, 17, (ctypes.c_wchar_p,), title)
        if start and os.path.isdir(start):      # 지난번 위치에서 시작
            item = ctypes.c_void_p()
            iid_item = guid("{43826D1E-E718-42EE-BC55-A1E261C37BFE}")
            shell32.SHCreateItemFromParsingName(
                start, None, ctypes.byref(iid_item), ctypes.byref(item))
            if item:
                _com_call(pfd, 12, (ctypes.c_void_p,), item)
                _com_call(item, 2)              # Release
        if _com_call(pfd, 3, (ctypes.c_void_p,), _owner_hwnd(ctypes)) != 0:
            return None                          # 사용자가 취소
        psi = ctypes.c_void_p()
        if _com_call(pfd, 20, (ctypes.POINTER(ctypes.c_void_p),),
                     ctypes.byref(psi)) != 0 or not psi:
            return None
        try:
            buf = ctypes.c_wchar_p()
            if _com_call(psi, 5, (ctypes.c_ulong,
                                  ctypes.POINTER(ctypes.c_wchar_p)),
                         SIGDN_FILESYSPATH, ctypes.byref(buf)) != 0:
                return None
            path = buf.value
            ole32.CoTaskMemFree(buf)
            return path
        finally:
            _com_call(psi, 2)                    # Release
    finally:
        _com_call(pfd, 2)                        # Release


def _legacy_dialog(title: str) -> str | None:
    """구식 트리 창 — 최신 창을 못 여는 환경에서만."""
    import ctypes
    from ctypes import wintypes

    class BROWSEINFO(ctypes.Structure):
        _fields_ = [("hwndOwner", wintypes.HWND),
                    ("pidlRoot", ctypes.c_void_p),
                    ("pszDisplayName", wintypes.LPWSTR),
                    ("lpszTitle", wintypes.LPCWSTR),
                    ("ulFlags", wintypes.UINT),
                    ("lpfn", ctypes.c_void_p),
                    ("lParam", wintypes.LPARAM),
                    ("iImage", ctypes.c_int)]

    shell32, ole32 = ctypes.windll.shell32, ctypes.windll.ole32
    shell32.SHBrowseForFolderW.restype = ctypes.c_void_p
    shell32.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, wintypes.LPWSTR]
    ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    buf = ctypes.create_unicode_buffer(1024)
    bi = BROWSEINFO()
    bi.hwndOwner = _owner_hwnd(ctypes)
    bi.pszDisplayName = ctypes.cast(buf, wintypes.LPWSTR)
    bi.lpszTitle = title
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_EDITBOX
    pidl = shell32.SHBrowseForFolderW(ctypes.byref(bi))
    if not pidl:
        return None
    path_buf = ctypes.create_unicode_buffer(1024)
    ok = shell32.SHGetPathFromIDListW(pidl, path_buf)
    ole32.CoTaskMemFree(pidl)
    return path_buf.value if ok and path_buf.value else None


def choose_folder(title: str = "감시할 폴더를 선택하세요",
                  start: str | None = None) -> str | None:
    """폴더 선택 창을 띄우고 고른 경로를 돌려준다. 취소·실패면 None.

    호출한 스레드에서 모달로 동작한다 (HTTP 처리 스레드에서 부르며, 그동안에도
    다른 화면 요청은 계속 처리된다 — ThreadingHTTPServer)."""
    if not available():
        return None
    import ctypes
    ole32 = ctypes.windll.ole32
    hr = ole32.CoInitialize(None)          # STA. 이미 초기화돼 있으면 그대로 사용
    try:
        try:
            return _modern_dialog(title, start)
        except Exception:
            return _legacy_dialog(title)   # 최신 창 실패 시 구식 창
    except Exception:
        return None
    finally:
        if hr in (0, 1):                   # 우리가 초기화했을 때만 해제
            ole32.CoUninitialize()
