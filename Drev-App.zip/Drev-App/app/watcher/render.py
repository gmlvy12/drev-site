# -*- coding: utf-8 -*-
"""페이지 그림 기록 — 도면(PDF·DXF)을 검사 때 흑백 그림으로 남긴다.

회사 도면은 대부분 같은 이름으로 덮어써진다. 그러면 이전 판 파일이 사라져
전/후 그림 비교를 할 수 없었고 "시각 비교 수행 못 함"만 남았다 (2026-09-02 실사용:
"도면 변경점을 거의 못 잡고 변경 부분 스샷도 없다"). 검사 때마다 도면의 페이지
그림을 state.db에 기록해 두면, 다음 덮어쓰기 때 그 기록이 '이전 판'이 된다.

- 원본 파일은 읽기만 한다 (원칙 2). 저장은 state.py가 한다
- PDF: pypdfium2 그레이 렌더 (capture의 감지 해상도와 동일 — 픽셀 단위로 비교 가능)
- DXF: ezdxf 렌더 프런트엔드가 만든 선·면을 Pillow로 직접 그린다 (모델 공간 1장).
  형상의 의미는 해석하지 않는다 (원칙 7) — 픽셀이 달라진 자리만 찾는다
- DWG: 변환 프로그램(convert.py)이 있으면 DXF로 바꿔 같은 방식, 없으면 파일 안의
  미리보기 그림(dwg.py, 저해상도)을 페이지 그림으로 기록한다 (2026-09-03)
"""
from __future__ import annotations

import io
import math
import re
from dataclasses import dataclass, field
from pathlib import Path

# 'SHEET 2 OF 4'의 숫자처럼 쪽이 밀리면 함께 바뀌는 낱말 — 페이지 짝짓기에 쓰지 않는다
PAGE_NUM_WORD = re.compile(r"^\d{1,3}(?:/\d{1,3})?$")


def page_words(page) -> list[str]:
    """pypdfium2 페이지의 낱말 목록(정렬, 중복 제거) — 기록 그림과 함께 저장해 같은 이름으로 덮어쓴
    도면도 내용으로 페이지를 짝짓게 (2026-09-06 사용성 4차: 덮어쓰기 케이스는 짝짓기가 아예 안 돌았다)."""
    try:
        tp = page.get_textpage()
        try:
            return sorted({w for w in tp.get_text_range().split() if not PAGE_NUM_WORD.match(w)})[:2000]
        finally:
            tp.close()
    except Exception:
        return []

def page_text_boxes(page, height_pt: float, cap: int = 3000) -> list:
    """pypdfium2 페이지의 글줄별 자리 [[글줄, x0, y0, x1, y1], …] (pt, 좌상단 원점) — 기록 그림과 함께
    저장해, 이 판이 '옛 판'이 된 뒤 지워진 글줄의 자리를 그림 비교에서 가릴 수 있게 (검토21 재검증 2차:
    PDF 덮어쓰기에서 지운 글줄 자리가 '그림 변경'으로 찍혔다)."""
    out: list = []
    try:
        tp = page.get_textpage()
        try:
            text = tp.get_text_range()
            pos = 0
            for raw in text.split("\n"):
                line = raw.rstrip("\r")
                start, n = pos, len(line)
                pos += len(raw) + 1
                s = " ".join(line.split())
                if len(s) < 2 or n == 0:
                    continue
                try:
                    rects = [tp.get_rect(i) for i in range(tp.count_rects(start, n))]
                except Exception:
                    continue
                if not rects:
                    continue
                left = min(r[0] for r in rects); bottom = min(r[1] for r in rects)
                right = max(r[2] for r in rects); top = max(r[3] for r in rects)
                out.append([s, round(left, 1), round(height_pt - top, 1), round(right, 1), round(height_pt - bottom, 1)])
                if len(out) >= cap:
                    break
        finally:
            tp.close()
    except Exception:
        return out
    return out


VIS_DPI = 100          # 감지용 렌더 해상도 (가는 배선이 픽셀로 남는 수준)
MAX_PAGES = 30         # 파일당 기록 페이지 상한 — 긴 매뉴얼류는 그림 비교 대상이 아니다
DXF_MAX_PX = 3300      # DXF 모델 공간의 긴 변 픽셀 (A1 @100dpi 수준)
DXF_PAD_PX = 20
from watcher.extract import RENDER_EXTS  # noqa: E402,F401  그림 기록·비교 대상 — 형식 레지스트리에서


@dataclass
class PageRender:
    """한 페이지의 그레이 그림. width/height는 pt 단위(72dpi 기준) — PDF와
    DXF를 같은 좌표 규약으로 다루기 위해 DXF도 픽셀을 pt로 환산해 둔다."""
    width_pt: float
    height_pt: float
    png: bytes
    meta: dict = field(default_factory=dict)   # DXF: 픽셀 ↔ 도면 좌표 환산 정보


def _png(img) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)   # 메모리 인코딩 — 파일 쓰기 아님
    return buf.getvalue()


def render_pdf(path: Path, max_pages: int = MAX_PAGES) -> list[PageRender]:
    import pypdfium2 as pdfium

    doc = pdfium.PdfDocument(Path(path).read_bytes())   # 파일 핸들 즉시 반납
    try:
        out = []
        for i in range(min(len(doc), max_pages)):
            page = doc[i]
            try:
                w, h = page.get_size()
                img = page.render(scale=VIS_DPI / 72.0, grayscale=True).to_pil()
                out.append(PageRender(float(w), float(h), _png(img),
                                      {"words": page_words(page), "tboxes": page_text_boxes(page, float(h))}))
            finally:
                page.close()
        return out
    finally:
        doc.close()


def _fill_even_odd(img, draw, polys) -> None:
    """서브패스 여러 개를 even-odd 규칙으로 채운다 (구멍 있는 글자·도형)."""
    from PIL import Image, ImageChops, ImageDraw
    xs = [x for p in polys for x, _ in p]
    ys = [y for p in polys for _, y in p]
    x0, y0 = int(min(xs)) - 1, int(min(ys)) - 1
    x1, y1 = int(max(xs)) + 2, int(max(ys)) + 2
    w, h = max(1, x1 - x0), max(1, y1 - y0)
    if w * h > 4_000_000:          # 비정상적으로 큰 채움은 예전 방식으로
        for pts in polys:
            draw.polygon(pts, fill=0)
        return
    acc = Image.new("1", (w, h), 0)
    for pts in polys:
        m = Image.new("1", (w, h), 0)
        ImageDraw.Draw(m).polygon([(x - x0, y - y0) for x, y in pts], fill=1)
        acc = ImageChops.logical_xor(acc, m)
    img.paste(0, (x0, y0), acc)


RENDER_ENTITY_BUDGET = 400_000     # 블록 전개 규모가 이보다 크면 그림 기록을 건너뛴다


class RenderTooHeavy(RuntimeError):
    """블록 전개 규모가 커서 그림 기록을 건너뛴다 — 호출부가 사유를 고지한다."""


def _expansion_estimate(doc) -> int:
    """모델 공간의 블록 전개 규모(가상 엔티티 수)를 블록 정의별 메모로 센다 — 그리지 않고 O(블록 수)."""
    memo: dict[str, int] = {}
    stack: set = set()

    def count(name: str) -> int:
        if name in memo:
            return memo[name]
        if name in stack:
            return 0
        stack.add(name)
        total = 0
        try:
            blk = doc.blocks.get(name)
            for e in (blk or ()):
                if e.dxftype() == "INSERT":
                    sub = str(getattr(e.dxf, "name", "") or "")
                    total += 1 + (count(sub) if sub else 0)
                else:
                    total += 1
        except Exception:                    # noqa: BLE001
            pass
        stack.discard(name)
        memo[name] = total
        return total
    total = 0
    try:
        for e in doc.modelspace():
            if e.dxftype() == "INSERT":
                total += 1 + count(str(getattr(e.dxf, "name", "") or ""))
            else:
                total += 1
            if total > RENDER_ENTITY_BUDGET:
                break
    except Exception:                        # noqa: BLE001
        return 0
    return total


_HANGUL_FONTS = ("malgun.ttf", "malgunbd.ttf", "NanumGothic.ttf", "gulim.ttc", "batang.ttc")
_FONT_DONE = [False]


def _prefer_hangul_font() -> None:
    """ezdxf의 대체 글꼴을 한글이 있는 것으로 — 기본 대체(DejaVu)에는 한글이 없어 도면
    사진의 '배전반 단선도'가 전부 □□□로 나갔다 (검토19 브리핑 ⑫). SHX 글꼴을 쓰는
    도면은 결국 대체 글꼴로 그려지므로 이 한 줄이 사진 전부에 미친다. 없으면 그대로."""
    if _FONT_DONE[0]:
        return
    _FONT_DONE[0] = True
    try:
        from ezdxf.fonts import fonts as _ef
        fm = _ef.font_manager
        try:
            _ef.load()                       # 시스템 글꼴 목록(캐시) 적재
        except Exception:                    # noqa: BLE001
            pass
        for name in _HANGUL_FONTS:
            if fm.has_font(name):
                fm._fallback_font_name = name            # ezdxf 공개 API 없음 — 내부 필드
                break
    except Exception:                        # noqa: BLE001
        pass


def dxf_image(path: Path, max_px: int = DXF_MAX_PX, fit: dict | None = None):
    """DXF 모델 공간을 그레이 PIL 이미지로. (이미지, 좌표 환산 meta) 또는 None(빈 도면).
    fit(이전 판의 meta)을 주면 그 판과 같은 틀·배율로 그린다 — 선 하나가 도면
    범위 밖으로 나가도 전체가 밀리지 않고 픽셀 단위로 비교된다.
    ezdxf 프런트엔드가 블록·해치·치수·문자까지 선/면으로 풀어 주고, 그 결과를
    Pillow로 그린다. 문자는 글꼴이 없으면 네모로 그려지지만 전/후가 같은 규칙이라
    가짜 차이는 나지 않는다 (글자 변경은 텍스트 비교가 따로 잡는다)."""
    import ezdxf
    from ezdxf.addons.drawing import Frontend, RenderContext
    from ezdxf.addons.drawing.recorder import (
        FilledPathsRecord, PathRecord, PointsRecord, Recorder, SolidLinesRecord)
    from ezdxf.math import Matrix44
    from PIL import Image, ImageDraw

    _prefer_hangul_font()
    doc = ezdxf.readfile(str(path))
    est = _expansion_estimate(doc)
    if est > RENDER_ENTITY_BUDGET:
        # 심볼 라이브러리를 6단으로 쌓은 도면은 ezdxf 프런트엔드가 200초 넘게 걸려 그림 기록이
        # 시간 상한에 걸리고 내용 비교까지 생략됐다 (검토19c ⑤). 그리기 전에 전개 규모를
        # 블록 정의별로 한 번씩만 세어(메모) 넘치면 그림 기록을 건너뛴다 — 글자 비교는 그대로
        raise RenderTooHeavy(f"블록 전개 규모 약 {est:,}개 — 그림 기록 상한({RENDER_ENTITY_BUDGET:,}) 초과")
    rec = Recorder()
    Frontend(RenderContext(doc), rec).draw_layout(doc.modelspace())
    player = rec.player()
    bbox = player.bbox()
    if not bbox.has_data:
        return None
    x0, y0 = bbox.extmin.x, bbox.extmin.y
    x1, y1 = bbox.extmax.x, bbox.extmax.y
    clipped = False
    if not (fit and "scale" in fit):
        # 멀리 떨어진 잡점 하나(줌 익스텐트하면 도면이 점처럼 보이는 파일)가 있으면
        # 전체를 14px로 그려 그림 변경을 영원히 못 봤다 (2026-09-04 검토 extract H-2).
        # 꼭짓점 분포의 1~99% 구간을 도면 본체로 보고, 그 폭의 2배 밖은 잘라낸다
        rx0, ry0, rx1, ry1 = _robust_extent(player)
        if (rx0, ry0, rx1, ry1) != (x0, y0, x1, y1):
            x0, y0, x1, y1 = rx0, ry0, rx1, ry1
            clipped = True
    outside = 0.0
    if fit and "scale" in fit:
        # 이전 판의 틀로 그린다 — 그래야 픽셀 단위로 비교된다. 그런데 **그 틀 밖에
        # 새로 그린 내용은 아예 안 그려져** '그림 동일'로 보였다: 도면 옆에 구역을
        # 통째로 하나 더 그려도 0픽셀 차이였다 (2026-09-10 경우의 수 매트릭스 실측,
        # 원칙 5 위반). 틀 밖으로 얼마나 나갔는지를 재서 meta에 남긴다.
        fx0, fy1, fscale = fit["x0"], fit["y1"], fit["scale"]
        fw, fh = int(fit["w"]), int(fit["h"])
        # 틀이 담는 도면 좌표 범위 (여백 DXF_PAD_PX 제외)
        gx0 = fx0 - DXF_PAD_PX / fscale
        gx1 = fx0 + (fw - DXF_PAD_PX) / fscale
        gy1 = fy1 + DXF_PAD_PX / fscale
        gy0 = fy1 - (fh - DXF_PAD_PX) / fscale
        ow = max(0.0, gx0 - x0) + max(0.0, x1 - gx1)
        oh = max(0.0, gy0 - y0) + max(0.0, y1 - gy1)
        span = max(gx1 - gx0, gy1 - gy0, 1e-9)
        outside = max(ow, oh) / span
        x0, y1, scale = fx0, fy1, fscale
        W, H = fw, fh
    else:
        w, h = max(x1 - x0, 1e-9), max(y1 - y0, 1e-9)
        scale = (max_px - 2 * DXF_PAD_PX) / max(w, h)
        W = int(math.ceil(w * scale)) + 2 * DXF_PAD_PX
        H = int(math.ceil(h * scale)) + 2 * DXF_PAD_PX
    # 도면 좌표 → 픽셀: 원점을 좌상단으로, y를 뒤집는다
    player.transform(Matrix44.translate(-x0, -y1, 0)
                     @ Matrix44.scale(scale, -scale, 1)
                     @ Matrix44.translate(DXF_PAD_PX, DXF_PAD_PX, 0))
    img = Image.new("L", (W, H), 255)
    draw = ImageDraw.Draw(img)
    for r, _props in player.recordings():
        if isinstance(r, SolidLinesRecord):
            vs = list(r.lines.vertices())
            for i in range(0, len(vs) - 1, 2):
                draw.line([(vs[i].x, vs[i].y), (vs[i + 1].x, vs[i + 1].y)], fill=0, width=1)
        elif isinstance(r, PathRecord):
            pts = [(v.x, v.y) for v in r.path.flattening(0.5)]
            if len(pts) > 1:
                draw.line(pts, fill=0, width=1)
        elif isinstance(r, FilledPathsRecord):
            polys = [[(v.x, v.y) for v in p.flattening(0.5)] for p in r.paths]
            polys = [p for p in polys if len(p) > 2]
            if len(polys) <= 1:
                for pts in polys:
                    draw.polygon(pts, fill=0)
            else:
                # 윤곽이 여럿인 글자(한글·O·8)는 구멍이 even-odd로 비어야 한다 — 서브패스를
                # 각각 채우면 검은 조각이 붙었다 (검토19 2차 브리핑 ⑥). XOR 마스크로 채운다
                _fill_even_odd(img, draw, polys)
        elif isinstance(r, PointsRecord):
            # Recorder는 LINE 한 가닥도 점 2개짜리 PointsRecord로 남긴다 — 점으로만
            # 찍으면 선이 사라져 배선 추가를 못 본다 (2026-09-02 테스트에서 발견)
            vs = [(v.x, v.y) for v in r.points.vertices()]
            if len(vs) == 1:
                draw.point(vs[0], fill=0)
            elif vs:
                draw.line(vs, fill=0, width=1)
    meta = {"x0": x0, "y1": y1, "scale": scale, "pad": DXF_PAD_PX, "w": W, "h": H}
    if clipped:
        meta["clipped"] = True
    if outside > 0.02:          # 틀 너비의 2% 넘게 벗어났다 = 눈에 띄는 확장
        meta["outside"] = round(outside, 3)
    return img, meta


def _robust_extent(player) -> tuple[float, float, float, float]:
    """도면 본체의 범위 추정. 기록(엔티티) 하나를 상자 하나로 보고 그 중심의 5~95%
    백분위 상자를 그 폭만큼 사방으로 넓힌 뒤, 그 안에 걸치는 상자들의 합을 쓴다 —
    본체는 그대로, 멀리 떨어진 잡점·잡선·잡글자만 빠진다. (꼭짓점 단위로 세면 글자
    하나가 꼭짓점 수백 개라 1% 안에 안 걸렸다 — 2026-09-04 재검토 #10)"""
    from ezdxf.addons.drawing.recorder import (
        FilledPathsRecord, PathRecord, PointsRecord, SolidLinesRecord)
    boxes: list = []                      # (x0, y0, x1, y1)
    for r, _props in player.recordings():
        vs: list = []
        if isinstance(r, SolidLinesRecord):
            vs = list(r.lines.vertices())
        elif isinstance(r, PathRecord):
            vs = list(r.path.control_vertices())
        elif isinstance(r, FilledPathsRecord):
            for pth in r.paths:
                vs += list(pth.control_vertices())
        elif isinstance(r, PointsRecord):
            vs = list(r.points.vertices())
        if not vs:
            continue
        xs = [v.x for v in vs]
        ys = [v.y for v in vs]
        boxes.append((min(xs), min(ys), max(xs), max(ys)))
    if len(boxes) < 8:
        bb = player.bbox()
        return bb.extmin.x, bb.extmin.y, bb.extmax.x, bb.extmax.y
    cx = sorted((b[0] + b[2]) / 2 for b in boxes)
    cy = sorted((b[1] + b[3]) / 2 for b in boxes)
    lo, hi = int(len(cx) * 0.05), max(int(len(cx) * 0.95) - 1, 0)
    bx0, bx1, by0, by1 = cx[lo], cx[hi], cy[lo], cy[hi]
    span = max(bx1 - bx0, by1 - by0, 1e-9)
    kx0, kx1, ky0, ky1 = bx0 - span, bx1 + span, by0 - span, by1 + span
    keep = [b for b in boxes if b[2] >= kx0 and b[0] <= kx1 and b[3] >= ky0 and b[1] <= ky1]
    if not keep:
        bb = player.bbox()
        return bb.extmin.x, bb.extmin.y, bb.extmax.x, bb.extmax.y
    return (min(b[0] for b in keep), min(b[1] for b in keep),
            max(b[2] for b in keep), max(b[3] for b in keep))


def dxf_units_at(meta: dict, x_pt: float, y_pt: float) -> tuple[float, float]:
    """렌더 좌표(pt, 좌상단 원점) → 도면 좌표. 사람이 CAD에서 찾아갈 수 있게."""
    k = VIS_DPI / 72.0
    ux = meta["x0"] + (x_pt * k - meta["pad"]) / meta["scale"]
    uy = meta["y1"] - (y_pt * k - meta["pad"]) / meta["scale"]
    return ux, uy


def render_dxf(path: Path, fit: dict | None = None) -> list[PageRender]:
    r = dxf_image(path, fit=fit)
    if r is None:
        return []
    img, meta = r
    pt = 72.0 / VIS_DPI
    return [PageRender(img.width * pt, img.height * pt, _png(img), meta)]


def render_thumb(img) -> list[PageRender]:
    """DWG 미리보기(저해상도)를 페이지 그림으로 — 변환 프로그램이 없을 때의 안전망."""
    pt = 72.0 / VIS_DPI
    gray = img.convert("L")
    return [PageRender(gray.width * pt, gray.height * pt, _png(gray), {"thumb": True})]


def render_file(path: Path) -> list[PageRender]:
    """확장자별 페이지 그림. 대상이 아니면 빈 목록."""
    ext = Path(path).suffix.lower()
    if ext == ".pdf":
        return render_pdf(path)
    if ext == ".dxf":
        return render_dxf(path)
    if ext == ".dwg":
        from watcher.dwg import thumbnail_image
        img = thumbnail_image(path)
        return render_thumb(img) if img is not None else []
    return []
