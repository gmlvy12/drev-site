# -*- coding: utf-8 -*-
"""CAD가 띄운 대화상자에 Drev가 대신 답한다 (Windows, 표준 라이브러리 ctypes만).

DWG를 CAD로 변환할 때 글꼴 누락·대체 글꼴·프록시 객체 같은 대화상자가 뜨면 스크립트가
멈춘다 (2026-09-04 회사 PC: 오토캐드 계열 'SHX 파일 누락', CADian '대체 큰 글꼴').
이 모듈은 변환 중 CAD 프로세스(와 자손)의 대화상자를 1초마다 살펴, **알려진 것에만
안전한 버튼**을 누른다.

안전 규칙 (원칙 2 — 읽기 전용):
  - 저장·예·덮어쓰기·삭제가 들어간 버튼은 어떤 경우에도 누르지 않는다.
  - 모르는 대화상자는 건드리지 않고 제목과 버튼을 기록만 한다 → 변환은 지금처럼 멈춤
    감지로 끝나고, 그 기록이 다음 판의 규칙 재료가 된다.
"""
from __future__ import annotations

import sys
import threading
import time

# 절대 누르지 않는 버튼 — 이 낱말이 들어 있으면 후보에서 뺀다
FORBIDDEN = ("저장", "save", "덮어", "overwrite", "삭제", "delete", "예(y)", "yes")

# 알려진 대화상자 규칙: (제목에 모두 들어 있어야 하는 낱말들 중 하나의 묶음, 누를 버튼 후보들,
#  먼저 켤 체크박스 낱말). 후보는 순서대로 찾는다
RULES = (
    # 오토캐드 계열 'SHX 파일 누락' — 무시하고 계속 + '항상 수행'
    ((("shx",),), ("무시", "ignore"), ("항상", "always")),
    # IntelliCAD·CADian '스타일의 대체 큰 글꼴' / 'Alternate (big) font'
    ((("대체", "글꼴"), ("alternate", "font"), ("substitute", "font")), ("확인", "ok"), ()),
    # 프록시 객체 알림 — 확인/계속
    ((("프록시",), ("proxy",)), ("확인", "ok", "계속", "continue", "닫기", "close"), ()),
    # 글꼴/문자 스타일 관련 안내 (글꼴을 찾을 수 없음 등) — 확인만 (계속/닫기는 제목이
    # 확실한 규칙에만: 재검토 ①)
    ((("글꼴",), ("font",)), ("확인", "ok"), ()),
)
# 제목·본문에 이 낱말이 있으면 어떤 버튼도 누르지 않는다 — "글꼴 매핑을 저장할까요?"의
# [확인]은 CAD 설정을 사용자 모르게 저장한다 (2026-09-05 재검토 ①). 'saving'도 잡는다
FORBIDDEN_TEXT = ("저장", "sav", "덮어", "overwrite", "삭제", "delete", "바꾸시겠", "replace")


def _norm(s: str) -> str:
    return "".join(str(s or "").lower().split())


def is_forbidden(button: str) -> bool:
    b = _norm(button)
    return any(f in b for f in FORBIDDEN) or b in ("예", "y")


def text_forbidden(title: str, body: str = "") -> bool:
    s = _norm(title) + " " + _norm(body)
    return any(f in s for f in FORBIDDEN_TEXT)


def decide(title: str, buttons: list[str], checks: list[str] | tuple = (),
           body: str = "") -> tuple[str | None, str | None]:
    """(누를 버튼, 먼저 켤 체크박스) — 모르는 대화상자면 (None, None).
    buttons: 누를 수 있는 버튼 글자만. checks: 체크박스 글자(버튼 후보가 아님, 재검토 ③).
    body: 창 본문 — 제목·본문에 저장/덮어쓰기 등이 있으면 아무것도 안 누른다(재검토 ①)."""
    if text_forbidden(title, body):
        return None, None
    t = _norm(title)
    safe = [b for b in buttons if not is_forbidden(b)]
    for title_words_alts, wants, check_words in RULES:
        if not any(all(w in t for w in alt) for alt in title_words_alts):
            continue
        for w in wants:
            for b in safe:
                if w in _norm(b):
                    chk = next((c for c in checks for cw in check_words if cw in _norm(c)), None)
                    if chk is None and check_words:
                        chk = "__verification__"      # TaskDialog의 숨은 확인 체크박스
                    return b, chk
    # 확인/닫기만 있는 안내 창(버튼 1개, 금지 낱말 없음)은 누른다 — 정보성
    if len(buttons) == 1 and not is_forbidden(buttons[0]) and any(
            w in _norm(buttons[0]) for w in ("확인", "ok", "닫기", "close", "계속", "continue")):
        return buttons[0], None
    return None, None


# ───────────────────────── Win32 (ctypes)
if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    _u32 = ctypes.windll.user32
    _k32 = ctypes.windll.kernel32
    _ENUM = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    _BM_GETCHECK, _BM_CLICK = 0x00F0, 0x00F5
    _GWL_STYLE = -16

    class _PE32(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                    ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
                    ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]

    def tree_pids(root: int) -> set[int]:
        """root와 그 자손 프로세스의 PID 집합 (Toolhelp 스냅샷)."""
        out = {root}
        try:
            snap = _k32.CreateToolhelp32Snapshot(0x2, 0)
        except Exception:
            return out
        if snap == wintypes.HANDLE(-1).value or not snap:
            return out
        try:
            parents: dict[int, int] = {}
            e = _PE32()
            e.dwSize = ctypes.sizeof(_PE32)
            ok = _k32.Process32FirstW(snap, ctypes.byref(e))
            while ok:
                parents[int(e.th32ProcessID)] = int(e.th32ParentProcessID)
                ok = _k32.Process32NextW(snap, ctypes.byref(e))
            changed = True
            while changed:
                changed = False
                for pid, ppid in parents.items():
                    if ppid in out and pid not in out:
                        out.add(pid)
                        changed = True
        finally:
            _k32.CloseHandle(snap)
        return out

    def _text(hwnd) -> str:
        buf = ctypes.create_unicode_buffer(512)
        _u32.GetWindowTextW(hwnd, buf, 512)
        return buf.value

    def _cls(hwnd) -> str:
        buf = ctypes.create_unicode_buffer(64)
        _u32.GetClassNameW(hwnd, buf, 64)
        return buf.value

    def _pid_of(hwnd) -> int:
        pid = wintypes.DWORD(0)
        _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)

    def _children(hwnd) -> list:
        found: list = []

        @_ENUM
        def cb(h, _lp):
            found.append(h)
            return True
        _u32.EnumChildWindows(hwnd, cb, 0)
        return found

    def _is_checkbox(hwnd) -> bool:
        style = _u32.GetWindowLongW(hwnd, _GWL_STYLE) & 0xF
        return style in (2, 3, 5, 6)          # CHECKBOX·AUTOCHECKBOX·3STATE·AUTO3STATE

    def find_dialogs(pids: set[int]) -> list[dict]:
        """pids의 보이는 대화상자(#32770)들:
        {hwnd, title, body, buttons:[(hwnd, text, is_check)]} — body는 Static 글자들."""
        out: list[dict] = []

        @_ENUM
        def cb(h, _lp):
            try:
                if not _u32.IsWindowVisible(h) or _cls(h) != "#32770" or _pid_of(h) not in pids:
                    return True
                btns, body = [], []
                for c in _children(h):
                    cls = _cls(c)
                    if cls == "Button" and _u32.IsWindowVisible(c):
                        txt = "".join(ch for ch in _text(c) if ch != "&")
                        if txt.strip():
                            btns.append((c, txt.strip(), _is_checkbox(c)))
                    elif cls in ("Static", "SysLink", "DirectUIHWND"):
                        txt = _text(c).strip()
                        if txt:
                            body.append(txt)
                out.append({"hwnd": h, "title": _text(h), "body": " ".join(body), "buttons": btns})
            except Exception:
                pass
            return True
        _u32.EnumWindows(cb, 0)
        return out

    def _press(hwnd) -> None:
        _u32.SendMessageW(hwnd, _BM_CLICK, 0, 0)

    _TDM_CLICK_VERIFICATION = 0x0400 + 13

    def answer(dialog: dict) -> tuple[str | None, str | None]:
        """대화상자 하나에 규칙을 적용해 누른다. (누른 버튼, 켠 체크박스) — 모르면 (None, None)."""
        buttons = [b[1] for b in dialog["buttons"] if not b[2]]
        checks = [b[1] for b in dialog["buttons"] if b[2]]
        btn, chk = decide(dialog["title"], buttons, checks, dialog.get("body", ""))
        if btn is None:
            return None, None
        if chk == "__verification__":
            # comctl32 TaskDialog의 '항상 수행' 체크박스는 자식 창으로 안 보인다 — 대화상자에
            # 직접 메시지로 켠다 (재검토 ④)
            _u32.SendMessageW(dialog["hwnd"], _TDM_CLICK_VERIFICATION, 1, 0)
            time.sleep(0.2)
        elif chk:
            for h, txt, is_c in dialog["buttons"]:
                if txt == chk and is_c and not _u32.SendMessageW(h, _BM_GETCHECK, 0, 0):
                    _press(h)
                    time.sleep(0.2)
        for h, txt, is_c in dialog["buttons"]:
            if txt == btn and not is_c:
                _press(h)
                return btn, chk
        return None, None
else:                                          # 다른 OS: 아무것도 하지 않는다
    def tree_pids(root: int) -> set[int]:
        return {root}

    def find_dialogs(pids: set[int]) -> list[dict]:
        return []

    def answer(dialog: dict) -> tuple[str | None, str | None]:
        return None, None


class DialogWatcher:
    """변환 중 CAD 프로세스 트리의 대화상자를 지켜보다 알려진 것에 답한다 (스레드).
    answered: [(제목, 버튼)] / unknown: [(제목, [버튼…])] — 사유·로그·다음 규칙 재료."""

    def __init__(self, root_pid: int, interval: float = 1.0):
        self.root_pid = root_pid
        self.interval = interval
        self.answered: list[tuple[str, str]] = []
        self.unknown: list[tuple[str, list[str]]] = []
        self._seen: dict = {}
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._loop, daemon=True)

    def start(self) -> "DialogWatcher":
        if sys.platform == "win32":
            self._t.start()
        return self

    def stop(self) -> None:
        self._stop.set()
        if self._t.is_alive():
            self._t.join(3)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception:
                pass
            self._stop.wait(self.interval)

    def tick(self) -> None:
        pids = tree_pids(self.root_pid)
        for d in find_dialogs(pids):
            key = d["hwnd"]
            if key in self._seen and time.monotonic() - self._seen[key] < 5:
                continue                        # 방금 누른 창 — 닫히길 잠깐 기다린다
            btn, _chk = answer(d)
            if btn:
                self.answered.append((d["title"], btn))
                self._seen[key] = time.monotonic()
            elif key not in self._seen:
                self.unknown.append((d["title"], [b[1] for b in d["buttons"]]))
                self._seen[key] = time.monotonic() + 3600   # 한 번만 기록
