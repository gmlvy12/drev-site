# -*- coding: utf-8 -*-
"""SQLite 상태 저장소: 파일 스냅샷, 변경 이력, (Stage 5) 확인 기록.

쓰기는 state.db 한 파일에만 한다. 감시 대상 산출물에는 절대 쓰지 않는다.
"""

from __future__ import annotations

import hmac
import os
import time
import json
import re
import secrets
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import NamedTuple

from watcher.scan import FileRecord

_SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    run_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    path        TEXT NOT NULL,
    sha256      TEXT NOT NULL,
    size        INTEGER NOT NULL,
    mtime       REAL NOT NULL,
    PRIMARY KEY (snapshot_id, path)
);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS extracts (
    sha256       TEXT PRIMARY KEY,
    doc_json     TEXT NOT NULL,
    extracted_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS changes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    kind        TEXT NOT NULL CHECK (kind IN ('added', 'modified', 'removed')),
    path        TEXT NOT NULL,
    old_sha256  TEXT,
    new_sha256  TEXT,
    detected_at TEXT NOT NULL,
    project     TEXT
);
CREATE TABLE IF NOT EXISTS issues (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    code        TEXT NOT NULL,
    path        TEXT NOT NULL,
    project     TEXT,
    message     TEXT NOT NULL,
    evidence    TEXT NOT NULL,
    detected_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS change_details (
    change_id     INTEGER PRIMARY KEY REFERENCES changes(id),
    items_json    TEXT NOT NULL,
    captures_json TEXT
);
CREATE TABLE IF NOT EXISTS project_merges (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    at      TEXT NOT NULL,
    into_p  TEXT NOT NULL,           -- 남길 대표 이름
    sources TEXT NOT NULL            -- 합쳐 넣은 이름들 (줄바꿈 구분)
);
CREATE TABLE IF NOT EXISTS project_merge_rows (
    merge_id INTEGER NOT NULL REFERENCES project_merges(id),
    kind     TEXT NOT NULL,          -- 'change' | 'issue'
    row_id   INTEGER NOT NULL,
    old_p    TEXT NOT NULL           -- 바꾸기 전 이름 (되돌리기용)
);
CREATE TABLE IF NOT EXISTS doc_hints (
    path   TEXT PRIMARY KEY,         -- 경로 키
    sha256 TEXT NOT NULL,            -- 어느 판의 내용에서 읽었나
    kind   TEXT NOT NULL,            -- 내용에서 읽은 유형
    why    TEXT NOT NULL             -- 근거 (화면 표시용)
);
CREATE TABLE IF NOT EXISTS renders (
    sha256 TEXT NOT NULL,            -- 어느 판의 그림인가 (render.py, 2026-09-02)
    page   INTEGER NOT NULL,         -- 1부터
    width  REAL NOT NULL,            -- pt
    height REAL NOT NULL,
    meta   TEXT NOT NULL DEFAULT '{}',
    png    BLOB NOT NULL,            -- 그레이 PNG (감지 해상도)
    PRIMARY KEY (sha256, page)
);
CREATE TABLE IF NOT EXISTS manual_pairs (
    child_key TEXT PRIMARY KEY,   -- 대상 파일 (경로 키)
    prev_key  TEXT NOT NULL,      -- 사람이 지정한 이전 판
    by        TEXT,
    at        TEXT
);
CREATE TABLE IF NOT EXISTS acks (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    change_id INTEGER NOT NULL REFERENCES changes(id),
    by        TEXT NOT NULL,
    note      TEXT,
    at        TEXT NOT NULL
);
-- 이력 세대 — 화면이 보는 행(변경·확인·기준선 표시)이 바뀔 때마다 1씩 오른다. 화면은 이 값이 같으면
-- 20만 행 이력을 다시 읽지 않는다 (검토36 C-3: 대시보드 8~19초). 어떤 코드 경로로 바꿔도 빠지지 않게
-- 트리거로 센다. 여는 순간 쓰기가 생기지 않도록 행은 첫 변경 때 만든다
CREATE TABLE IF NOT EXISTS hist_gen (
    k INTEGER PRIMARY KEY CHECK (k = 1),
    v INTEGER NOT NULL
);
CREATE TRIGGER IF NOT EXISTS hg_changes_ins AFTER INSERT ON changes BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_changes_upd AFTER UPDATE ON changes BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_changes_del AFTER DELETE ON changes BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_acks_ins AFTER INSERT ON acks BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_acks_upd AFTER UPDATE ON acks BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_acks_del AFTER DELETE ON acks BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_meta_ins AFTER INSERT ON meta
    WHEN NEW.key IN ('root_first_seen', 'ext_baseline') BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_meta_upd AFTER UPDATE ON meta
    WHEN NEW.key IN ('root_first_seen', 'ext_baseline') BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_meta_del AFTER DELETE ON meta
    WHEN OLD.key IN ('root_first_seen', 'ext_baseline') BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
"""

# 색인이 하나도 없어서 화면 질의가 전부 전체 훑기였다 — 변경 30만 건에서 대시보드
# 한 장이 7.3초, history()가 1.57초였다 (2026-09-09 저장 검토 중간 5 실측).
# 마이그레이션으로 **나중에 생긴 열**(issues.resolved_at, changes.project)도 쓰므로
# _SCHEMA가 아니라 마이그레이션 뒤에 만든다. IF NOT EXISTS라 기존 설치본도 따라온다.
_INDEXES = (
    "CREATE INDEX IF NOT EXISTS ix_acks_change  ON acks(change_id)",
    "CREATE INDEX IF NOT EXISTS ix_chg_path     ON changes(path)",
    "CREATE INDEX IF NOT EXISTS ix_chg_project  ON changes(project)",
    "CREATE INDEX IF NOT EXISTS ix_chg_snapshot ON changes(snapshot_id)",
    "CREATE INDEX IF NOT EXISTS ix_chg_detected ON changes(detected_at)",
    "CREATE INDEX IF NOT EXISTS ix_iss_path     ON issues(path, code)",
    "CREATE INDEX IF NOT EXISTS ix_iss_resolved ON issues(resolved_at)",
    "CREATE INDEX IF NOT EXISTS ix_files_path   ON files(path)",
)


# 변경 종류 → 한글 라벨 (콘솔·브리핑·확인 페이지 공용 — 한 곳에서만 관리)
KIND_LABEL = {"added": "추가", "modified": "수정", "removed": "삭제"}


@dataclass(frozen=True)
class Change:
    """파일 수준 변경 1건. old/new sha256이 '사실'의 근거다 (PRINCIPLE 4·5)."""
    kind: str  # 'added' | 'modified' | 'removed'
    path: str
    old_sha256: str | None
    new_sha256: str | None
    id: int | None = None       # DB에 기록된 뒤 부여 (확인 링크의 대상)
    project: str | None = None  # 귀속 후 set_change_project로 저장


def _proc_created(pid: int) -> int | None:
    """프로세스 생성 시각(FILETIME 정수). 없거나 모르면 None. pid는 재사용되므로
    잠금은 pid+생성 시각으로 식별한다 (2026-09-04 재검토 ②-3: 재부팅 뒤 다른 프로그램이
    같은 pid를 받으면 최대 6시간 검사가 거부되던 것)."""
    if pid <= 0 or sys.platform != "win32":
        return None
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid)              # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return None
        try:
            ft = (ctypes.c_ulonglong * 4)()
            if k32.GetProcessTimes(h, ctypes.byref(ft, 0), ctypes.byref(ft, 8),
                                   ctypes.byref(ft, 16), ctypes.byref(ft, 24)):
                return int(ft[0])
            return None
        finally:
            k32.CloseHandle(h)
    except Exception:
        return None


def _pid_alive(pid: int, created: int | None = None) -> bool:
    """그 pid의 프로세스가 살아 있고(생성 시각까지 같으면) 같은 프로세스인가.
    모르면 살아 있다고 본다(잠금을 지키는 쪽). Windows의 os.kill(pid, 0)은 프로세스를
    죽이므로 쓰지 않는다."""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, pid)          # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return k32.GetLastError() == 5               # 접근 거부 = 있긴 있다
            try:
                code = ctypes.c_ulong()
                if k32.GetExitCodeProcess(h, ctypes.byref(code)) and code.value != 259:
                    return False                             # 종료됨(핸들만 남음)
            finally:
                k32.CloseHandle(h)
        except Exception:
            return True
        if created is not None:
            now_created = _proc_created(pid)
            if now_created is not None and now_created != created:
                return False                                 # 같은 pid를 받은 다른 프로그램
        return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return True


def _headline_of(items: list, with_weight: bool = False):
    """상세 항목 목록에서 가장 무거운 변경 한 줄. 사양·표 행 > Rev > 글자·그림 > 날짜·크기 > 참고.
    with_weight면 (무게, 한 줄)을 돌려준다."""
    def _s(v) -> str:
        return " ".join(str(v or "").split())[:40]
    best, best_w = "", 99
    n_rest = 0
    for it in items:
        k, key = it.get("kind", ""), _s(it.get("key"))
        o, n = _s(it.get("old")), _s(it.get("new"))
        if k.startswith("ROW_"):
            # 키는 '행키.열'(X-11.수량) — 품명 라벨만 쓰면 "RELAY · RELAY 24VDC: 2 → 4"처럼
            # 무엇의 수량인지 안 보였다 (파일럿 모의 3차 ③)
            rk, sep, col = key.rpartition(".")
            head = f"{rk} {col}".strip() if sep else key
            lab = _s(it.get("label"))
            w, txt = 0, (f"{head}: {o} → {n}" + (f" ({lab})" if lab and lab != head else "")
                         if k == "ROW_CHANGED" and o and n
                         else f"{key} 행 {'추가' if k.endswith('ADDED') else '삭제' if k.endswith('REMOVED') else '변경'}"
                              + (f" ({lab})" if lab else ""))
        elif k == "TEXT_CHANGED":
            w, txt = (0 if any(ch.isdigit() for ch in o + n) else 2), f"{o} → {n}"
        elif k == "FIELD_CHANGED" and key.split("#", 1)[0] == "REV" and n and it.get("label") != "새 표제란":
            # 메일·상세와 같은 말 — 둘째 표제란도 Rev, 빈칸→A는 첫 기재 (검토38 R5 중간 6)
            w, txt = 1, (f"Rev {n} 첫 기재" if o in ("", "-", "—") else f"Rev {o} → {n}")
        elif k == "FIELD_CHANGED":
            w, txt = (3 if key in ("DATE", "파일 크기", "저장 시각") else 2), f"{key} {o} → {n}"
        elif k in ("TEXT_ADDED", "TEXT_REMOVED"):
            w, txt = 2, f"글자 {'추가' if k.endswith('ADDED') else '삭제'}: {n or o}"
        elif k == "PAGE_VISUAL_CHANGED":
            w, txt = 2, f"그림 변경 ({key})"
        elif k == "NEW_REVISION_OF":
            w, txt = 2, f"이전 판 {o} → {n}"
        elif k == "CHECK_SKIPPED" and key == "참고":
            w, txt = 4, n
        else:
            continue
        if w < best_w:
            best, best_w = txt, w
        n_rest += 1
    if best and n_rest > 1:
        best += f" 외 {n_rest - 1}건"
    if with_weight:
        return (best_w if best else 5, best)
    return best


_TRANSIENT_DB = ("database is locked", "database table is locked", "busy", "duplicate column",
                 "disk is full", "unable to open", "disk i/o")


def is_transient_db_error(e) -> bool:
    """손상이 아니라 잠시 쓸 수 없는 상태(다른 프로세스·동시 마이그레이션·디스크 가득)인가."""
    m = str(e).lower()
    return any(w in m for w in _TRANSIENT_DB)


class CorruptDatabase(RuntimeError):
    """state.db가 깨져 열 수 없다 — 디스크 오류·백신 격리·복사 중 끊김.

    전에는 날 sqlite3 traceback으로 예약 검사가 죽고 화면은 응답 없이 끊겨, 되살리기
    절차(도움말 '백업 · 다른 PC로 이전 · 되살리기')가 있는데도 아무도 그리로 가지
    못했다 (검토19 운영 ①). 한국어 한 줄과 절차 위치를 함께 실어 올린다."""

    def __init__(self, db_path, why: str):
        self.db_path = str(db_path)
        self.why = why
        super().__init__(
            f"이력 파일이 깨져 열 수 없습니다: {db_path} ({why}). 되살리는 순서는 도움말의 "
            f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다 — 요약: Drev를 끝내고, "
            f"state.db-wal·state.db-shm이 있으면 이름을 바꿔 치우고, backups 폴더의 "
            f"state_backup_N.db를 복사해 state.db로 이름을 바꿉니다.")


# 설정의 backup_dir(NAS 등) — load_config가 알려 준다. State는 설정을 모르지만 누가 열든(화면·검사) 같은
# 흔적을 봐야 한다: 화면이 먼저 열려 빈 DB를 만들면 다음 07:00에 수만 건 기준선이 쌓였다 (검토37 C 중간 1)
_BACKUP_DIRS: dict = {}          # state.db 절대 경로 → 설정의 backup_dir


def _db_key(db_path) -> str:
    try:
        return str(Path(db_path).resolve()).lower()
    except OSError:
        return str(db_path).lower()


def register_backup_dir(db_path, path) -> None:
    if path:
        _BACKUP_DIRS[_db_key(db_path)] = str(path)


def missing_db_evidence(db_path, backup_dir=None) -> list[str]:
    """state.db가 없는데 **있었던 흔적**(-wal·-shm, backups/·backup_dir의 주간 사본) — 있으면 사라진 것이지
    첫 설치가 아니다. 0바이트 state.db도 없어진 것으로 본다(복사가 끊긴 되살리기) (검토37 C 낮음)."""
    db = Path(db_path)
    try:
        if db.exists() and db.stat().st_size > 0:
            return []
    except OSError:
        return []
    out = [p.name for p in (db.with_name(db.name + "-wal"), db.with_name(db.name + "-shm")) if p.exists()]
    extra = {d for d in (backup_dir, _BACKUP_DIRS.get(_db_key(db))) if d}
    dirs = [(db.parent / "backups", "backups")] + [(Path(d), str(d)) for d in sorted(extra)]
    for d, label in dirs:
        try:
            out += [f"{label}/{p.name}" for p in sorted(d.glob("state_backup_*.db"))]
        except OSError:
            pass
    if out and db.exists():
        out.insert(0, f"{db.name}(0바이트)")
    return out


class MissingDatabase(CorruptDatabase):
    """state.db가 사라졌다(백신 격리·잘못된 복원·실수로 지움) — 조용히 빈 DB를 만들면 다음 검사가 수만 건
    '기준선'을 새로 쌓아 1년치 확인 기록이 이유 없이 화면에서 사라졌다 (검토34 M4·검토36 C-7)."""

    def __init__(self, db_path, evidence: list[str]):
        self.db_path = str(db_path)
        self.why = "파일 없음"
        self.evidence = list(evidence)
        RuntimeError.__init__(
            self,
            f"이력 파일이 없습니다: {db_path} — 그런데 있었던 흔적({', '.join(evidence[:5])})이 남아 있어 "
            f"새로 만들지 않고 멈춥니다. 백신이 격리했으면 격리에서 되돌리고, 아니면 backups 폴더의 "
            f"state_backup_N.db 가운데 가장 최근 것을 복사해 state.db로 이름을 바꿉니다(도움말 '백업 · 다른 PC로 "
            f"이전 · 되살리기'). 정말 처음부터 다시 시작하려면 backups 폴더와 state.db-wal·-shm의 이름을 바꿔 "
            f"치운 뒤 다시 실행하세요.")


# 검출 당시 문구가 DB에 남는다 — 옛 판(≤0.57.10)의 재저장 참고 "확인만 하면 됩니다"가 새 화면의
# "확인 대상 아님"과 한 화면에 공존했다 (검토31 A 3-4). 표시 때만 바꾼다
_OLD_NOTE_FIX = (("확인만 하면 됩니다", "확인 대상 아님 (기록만 남깁니다)"),)


def _fix_old_note(it: dict) -> dict:
    try:
        if it.get("kind") == "CHECK_SKIPPED" and isinstance(it.get("new"), str):
            new = it["new"]
            for a, b in _OLD_NOTE_FIX:
                new = b.join(new.split(a))     # (읽기 전용 가드가 replace 호출 이름을 막는다)
            if new != it["new"]:
                it = dict(it, new=new)
    except AttributeError:
        pass
    return it


class RevBump(NamedTuple):
    """최근 Rev 올림의 근거 — 검사 시각(ISO)·그 변경 id·이전 Rev·새 Rev."""
    at: str
    change_id: int
    old: str
    new: str


ROLLED_BACK_KEY = "rolled_back_changes"   # 되돌린 변경·그 확인 (검토39 P5 차단 2)
MOVED_IDS_KEY = "moved_change_ids"        # 되돌렸다 다시 잡힌 변경: 옛 번호 → 새 번호


class State:
    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        gone = missing_db_evidence(self.db_path)
        if gone:
            raise MissingDatabase(self.db_path, gone)
        # 웹서버(다중 스레드)와 검사 스레드가 같은 DB를 쓴다 — WAL이면 읽기가
        # 긴 쓰기(캡처 수 MB 저장)에 막히지 않고, busy_timeout으로 잠금 충돌을
        # 재시도한다 (2026-08-26 리뷰: 'database is locked' 예방)
        self.conn = sqlite3.connect(self.db_path, timeout=15)
        # 여는 도중 어디서든 터지면 **연결을 닫고** 올린다. 열린 채로 두면 윈도우가
        # 그 파일을 잡아, 되살리려고 이름을 바꾸는 것조차 WinError 32로 막힌다
        # (2026-09-09 저장 검토 낮음 9b — 깨진 DB에서 실측)
        try:
            mode = self.conn.execute("PRAGMA journal_mode=WAL").fetchone()[0]
            if str(mode).lower() != "wal":  # 전환 실패는 예외가 아니라 반환값으로만 알린다
                print(f"경고: state.db WAL 전환 실패(현재 {mode}) — 동시 접근 시 "
                      f"잠금 오류 가능", file=sys.stderr)
            if str(self.db_path).startswith("\\\\"):
                print("경고: state.db가 네트워크 경로에 있습니다 — SQLite WAL은 "
                      "네트워크 드라이브에서 신뢰할 수 없습니다(손상 위험). "
                      "이 PC의 로컬 경로를 권장합니다.", file=sys.stderr)
            self.conn.execute("PRAGMA busy_timeout=15000")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.executescript(_SCHEMA)
        except sqlite3.DatabaseError as e:
            try:
                self.conn.close()
            except Exception:
                pass
            # 잠김·바쁨·디스크 가득은 손상이 아니다 — 원래 오류로 올려 cli가 '다시 실행' 안내를 하게 한다.
            # 여기서 감싸면 멀쩡한 DB에 백업을 덮으라는 안내가 나갔다 (검토36 C-2: 동시 열기 20회 중 8회)
            if is_transient_db_error(e):
                raise
            raise CorruptDatabase(self.db_path, str(e)) from e
        except BaseException:
            try:
                self.conn.close()
            except Exception:
                pass
            raise
        # Stage 4 이전에 만든 DB 마이그레이션: changes.project 열 추가
        cols = [r[1] for r in self.conn.execute("PRAGMA table_info(changes)")]
        if "project" not in cols:
            self._add_column("ALTER TABLE changes ADD COLUMN project TEXT")
        # 2026-09-17: 변경 기록에 그 판·이전 판의 파일 저장 시각 — files는 최신 스냅샷만 남아(prune)
        # 다음 날 '저장' 칸이 사라지고 옛 변경 상세가 지금 파일의 시각을 보였다 (검토26 5회차 B1)
        if "mtime" not in cols:
            self._add_column("ALTER TABLE changes ADD COLUMN mtime REAL")
            self._add_column("ALTER TABLE changes ADD COLUMN old_mtime REAL")
            # 남아 있는 스냅샷 기록으로 채울 수 있는 만큼만 채운다
            self.conn.execute(
                "UPDATE changes SET mtime = (SELECT f.mtime FROM files f "
                "WHERE f.snapshot_id = changes.snapshot_id AND f.path = changes.path) WHERE mtime IS NULL")
        # v0.14 마이그레이션: 이슈 해소(닫기) 기록 — 없으면 빨간 숫자가 영원히 쌓인다
        icols = [r[1] for r in self.conn.execute("PRAGMA table_info(issues)")]
        if "resolved_at" not in icols:
            self._add_column("ALTER TABLE issues ADD COLUMN resolved_at TEXT")
            self._add_column("ALTER TABLE issues ADD COLUMN resolved_by TEXT")
        # 검토43 B 중간 8: 사람이 닫은 교차 이슈가 검사에서 **사라졌던** 시각 — 그 뒤 같은 값으로 다시 나오면 재발
        if "gone_at" not in icols:
            self._add_column("ALTER TABLE issues ADD COLUMN gone_at TEXT")
        # v0.19 마이그레이션: 상세 항목 오탐 숨김(복원 가능) 기록
        dcols = [r[1] for r in self.conn.execute("PRAGMA table_info(change_details)")]
        if "dismissed_json" not in dcols:
            self._add_column("ALTER TABLE change_details ADD COLUMN dismissed_json TEXT")
        # v0.21 마이그레이션: 사람이 직접 추가한 '놓친 변경' 기록 (미탐 보완)
        if "user_notes_json" not in dcols:
            self._add_column("ALTER TABLE change_details ADD COLUMN user_notes_json TEXT")
        for stmt in _INDEXES:
            try:
                self.conn.execute(stmt)
            except Exception:      # 색인 하나가 안 만들어져도 프로그램은 돌아야 한다
                pass
        self.conn.commit()

    def _add_column(self, sql: str) -> None:
        """마이그레이션의 열 추가 — 다른 프로세스(예약 검사·창)가 같은 순간 먼저 더했으면 그대로 둔다.
        확인 뒤 ALTER 사이가 원자적이지 않아 동시 열기에서 duplicate column으로 죽었고, 그것이 '손상'
        안내로 이어졌다 (검토34 C M6·검토36 C-2)."""
        try:
            self.conn.execute(sql)
        except sqlite3.OperationalError as e:
            if "duplicate column" not in str(e).lower():
                raise

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "State":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def save_extract(self, sha256: str, doc_dict: dict) -> None:
        """추출 결과를 내용 해시 기준으로 저장. 나중에 구버전과의 내용 비교에 쓴다."""
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            "INSERT OR REPLACE INTO extracts (sha256, doc_json, extracted_at) VALUES (?, ?, ?)",
            (sha256, json.dumps(doc_dict, ensure_ascii=False), now))
        self.conn.commit()

    def load_extract(self, sha256: str | None) -> dict | None:
        if not sha256:
            return None
        row = self.conn.execute(
            "SELECT doc_json FROM extracts WHERE sha256 = ?", (sha256,)).fetchone()
        return json.loads(row[0]) if row else None

    def latest_snapshot(self) -> dict[str, str]:
        """가장 최근 스냅샷: {path: sha256}. 없으면 빈 dict."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return {}
        return dict(self.conn.execute(
            "SELECT path, sha256 FROM files WHERE snapshot_id = ?", (row[0],)))

    def side_notes(self, limit: int = 500) -> dict:
        """복사본·빈 파일 같은 '참고' 메모가 달린 변경 → 문구 (목록 표시용).

        상세를 열지 않고도 훑으며 거를 수 있게 (2026-09-01 처음 쓰는 사람 점검)."""
        import json
        out = {}
        rows = self.conn.execute(
            "SELECT change_id, items_json FROM change_details "
            "WHERE items_json LIKE '%CHECK_SKIPPED%' "
            "ORDER BY change_id DESC LIMIT ?", (limit,)).fetchall()
        for cid, js in rows:
            try:
                for it in json.loads(js):
                    if it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
                        out[cid] = _fix_old_note(it).get("new") or ""
                        break
            except (ValueError, TypeError):
                continue
        return out

    def project_files(self, project: str, limit: int = 0) -> list[str]:
        """그 프로젝트로 잡힌 파일 경로 (중복 제거)."""
        rows = self.conn.execute(
            "SELECT DISTINCT path FROM changes WHERE IFNULL(project,'미분류') = ?"
            " ORDER BY path", (project,)).fetchall()
        paths = [r[0] for r in rows]
        return paths[:limit] if limit else paths

    def merge_projects(self, into: str, sources, path_prefix: str | None = None) -> dict:
        """여러 이름으로 갈린 같은 프로젝트를 대표 이름 하나로 모은다.

        바꾸기 전 값을 project_merge_rows에 남겨 되돌릴 수 있게 한다 — 잘못
        합쳤을 때 원래대로가 없으면 사람이 손댈 방법이 없다 (PRINCIPLE 5)."""
        srcs = [x for x in dict.fromkeys(sources) if x and x != into]
        if not srcs:
            return {"merge_id": 0, "changes": 0, "issues": 0}
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute(
            "INSERT INTO project_merges (at, into_p, sources) VALUES (?, ?, ?)",
            (now, into, "\n".join(srcs)))
        mid = cur.lastrowid
        marks = ",".join("?" * len(srcs))
        # 감시 폴더 하나를 '프로젝트 하나로' 묶을 때는 그 폴더 아래만 — 경로 조건
        # 없이 이름만으로 바꾸면 다른 폴더의 같은 이름(미분류 포함) 이력까지 편입된다
        # (2026-09-02 검토에서 확인). LIKE 대신 접두어 비교: 라벨의 _·%가 와일드카드가
        # 되지 않게
        scope, extra = "", ()
        if path_prefix:
            scope, extra = " AND substr(path, 1, ?) = ?", (len(path_prefix), path_prefix)
        counts = {}
        for kind, table in (("change", "changes"), ("issue", "issues")):
            rows = self.conn.execute(
                f"SELECT id, IFNULL(project,'미분류') FROM {table} "
                f"WHERE IFNULL(project,'미분류') IN ({marks}){scope}",
                tuple(srcs) + extra).fetchall()
            self.conn.executemany(
                "INSERT INTO project_merge_rows (merge_id, kind, row_id, old_p) "
                "VALUES (?, ?, ?, ?)",
                [(mid, kind, rid, old) for rid, old in rows])
            self.conn.executemany(
                f"UPDATE {table} SET project = ? WHERE id = ?",
                [(into, rid) for rid, _ in rows])
            counts[kind] = len(rows)
        self.conn.commit()
        return {"merge_id": mid, "changes": counts["change"],
                "issues": counts["issue"]}

    def undo_merge(self, merge_id: int) -> int:
        """합치기 되돌리기 — 그때 바꾼 행만 원래 이름으로 돌려놓는다."""
        rows = self.conn.execute(
            "SELECT kind, row_id, old_p FROM project_merge_rows "
            "WHERE merge_id = ?", (merge_id,)).fetchall()
        for kind, rid, old in rows:
            table = "changes" if kind == "change" else "issues"
            self.conn.execute(f"UPDATE {table} SET project = ? WHERE id = ?",
                              (old, rid))
        self.conn.execute("DELETE FROM project_merge_rows WHERE merge_id = ?",
                          (merge_id,))
        self.conn.execute("DELETE FROM project_merges WHERE id = ?", (merge_id,))
        self.conn.commit()
        return len(rows)

    def merges(self, limit: int = 20) -> list[dict]:
        """최근 합치기 이력 (되돌리기 버튼용)."""
        out = []
        for mid, at, into, srcs in self.conn.execute(
                "SELECT id, at, into_p, sources FROM project_merges "
                "ORDER BY id DESC LIMIT ?", (limit,)):
            n = self.conn.execute(
                "SELECT COUNT(*) FROM project_merge_rows WHERE merge_id = ?",
                (mid,)).fetchone()[0]
            out.append({"merge_id": mid, "at": at, "into": into,
                        "sources": srcs.split("\n"), "rows": n})
        return out

    def prefix_stats(self, label: str) -> dict:
        """감시 폴더 라벨 아래의 기록 개수 — 지우기 전에 사람에게 보여준다."""
        pre = label + "/"          # LIKE는 _·%를 와일드카드로 본다 — 접두어 비교
        files = self.conn.execute(
            "SELECT COUNT(DISTINCT path) FROM files WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        # 변경 id를 전부 파이썬으로 끌어와 IN (?,…)로 묶으면 32,766개에서
        # "too many SQL variables"로 이 화면이 통째로 죽는다 — 하루 30건이면 3년이다
        # (2026-09-09 저장 검토 차단 2). 전부 서브질의로 바꾼다
        n_changes = self.conn.execute(
            "SELECT COUNT(*) FROM changes WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        acks = self.conn.execute(
            "SELECT COUNT(*) FROM acks WHERE change_id IN "
            "(SELECT id FROM changes WHERE substr(path,1,?) = ?)",
            (len(pre), pre)).fetchone()[0]
        issues = self.conn.execute(
            "SELECT COUNT(*) FROM issues WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        return {"files": files, "changes": n_changes, "acks": acks, "issues": issues}

    def purge_prefix(self, label: str) -> dict:
        """감시 폴더 라벨 아래의 **기록**을 전부 지운다 — 파일 목록·변경·상세·확인·
        검토 필요. 감시 대상 파일은 건드리지 않는다 (PRINCIPLE 2). 되돌릴 수
        없으므로 호출 전에 사람이 확인한다 (2026-09-02)."""
        stats = self.prefix_stats(label)
        pre = label + "/"
        sub = "(SELECT id FROM changes WHERE substr(path,1,?) = ?)"
        arg = (len(pre), pre)
        self.conn.execute(f"DELETE FROM change_details WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM acks WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM project_merge_rows WHERE kind = 'change' "
                          f"AND row_id IN {sub}", arg)
        self.conn.execute("DELETE FROM changes WHERE substr(path,1,?) = ?", arg)
        self.conn.execute("DELETE FROM issues WHERE substr(path,1,?) = ?", (len(pre), pre))
        self.conn.execute("DELETE FROM files WHERE substr(path,1,?) = ?", (len(pre), pre))
        self.conn.execute("DELETE FROM doc_hints WHERE substr(path,1,?) = ?", (len(pre), pre))
        # 라벨의 '첫 검사' 기록도 지운다 — 다시 넣으면 그때가 첫 검사(기준선)다
        try:
            fs = json.loads(self.get_meta("root_first_seen") or "{}")
            kl = json.loads(self.get_meta("known_labels") or "[]")
            fs.pop(label, None)
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('root_first_seen', ?)",
                              (json.dumps(fs, ensure_ascii=False),))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('known_labels', ?)",
                              (json.dumps(sorted(set(kl) - {label}), ensure_ascii=False),))
        except (ValueError, TypeError):
            pass
        self.conn.commit()
        return stats

    def save_hint(self, path: str, sha256: str, hint) -> None:
        """내용 단서 저장 — 없으면(None) 지운다 (2026-09-02)."""
        if hint is None:
            self.conn.execute("DELETE FROM doc_hints WHERE path = ?", (path,))
            return
        self.conn.execute(
            "INSERT OR REPLACE INTO doc_hints (path, sha256, kind, why) "
            "VALUES (?, ?, ?, ?)", (path, sha256, hint[0], hint[1]))

    def backfill_hints(self, compute) -> int:
        """내용 단서가 없는 최신 스냅샷 파일에 대해, 캐시된 추출본으로 단서를 만든다.

        단서는 원래 검사 때 생기므로 업데이트 직후엔 비어 있다 — 다음 검사까지
        기다리지 않게 한 번 소급한다 (2026-09-02). compute(추출본 dict) → (유형, 근거)|None.
        돌려주는 값: 새로 만든 단서 수."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return 0
        # 스냅샷당 한 번만 — 단서 없는 파일은 doc_hints에 흔적이 없어 매 시작마다
        # 4만 추출본을 다시 파싱하고 있었다 (2026-09-02 검토). 검사가 돌면 검사가
        # 직접 단서를 만들므로 소급은 그 전 한 번이면 된다
        done = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'hints_backfill_snapshot'").fetchone()
        if done and str(done[0]) == str(row[0]):
            return 0
        have = {p for (p,) in self.conn.execute("SELECT path FROM doc_hints")}
        made = 0
        pending = [(p, s) for p, s in self.conn.execute(
            "SELECT path, sha256 FROM files WHERE snapshot_id = ?", (row[0],))
            if p not in have]
        for i, (path, sha) in enumerate(pending, 1):
            cached = self.load_extract(sha)
            if cached and cached.get("extract_failed") is None:
                hint = compute(cached)
                if hint:
                    self.save_hint(path, sha, hint)
                    made += 1
            if i % 500 == 0:
                self.conn.commit()        # 쓰기 잠금을 오래 쥐지 않는다
        self.conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES ('hints_backfill_snapshot', ?)",
            (str(row[0]),))
        self.conn.commit()
        return made

    def hints(self) -> dict:
        """{경로: (유형, 근거)} — 화면이 유형을 판별할 때 함께 본다."""
        return {p: (k, w) for p, k, w in
                self.conn.execute("SELECT path, kind, why FROM doc_hints")}

    def delete_project(self, project: str) -> dict:
        """프로젝트의 **기록**을 지운다 — 변경 이력·상세·확인·검토 필요.

        감시 대상 파일은 건드리지 않는다(원칙 2: 이 프로그램은 산출물 파일을
        수정·삭제하지 않는다). 잘못 묶인 프로젝트를 화면에서 치우기 위한 것
        (2026-09-01 요청). 되돌릴 수 없으므로 호출 전에 사람이 확인한다."""
        # id·path를 전부 끌어와 IN (?,…)로 묶으면 32,766건에서 죽는다 — '미분류'는
        # 귀속 실패가 모이는 곳이라 가장 먼저 넘는다 (2026-09-09 저장 검토 차단 2)
        sub = "(SELECT id FROM changes WHERE IFNULL(project,'미분류') = ?)"
        arg = (project,)
        n_changes = self.conn.execute(
            "SELECT COUNT(*) FROM changes WHERE IFNULL(project,'미분류') = ?",
            arg).fetchone()[0]
        if not n_changes:
            return {"changes": 0, "acks": 0, "issues": 0}
        acks = self.conn.execute(
            f"SELECT COUNT(*) FROM acks WHERE change_id IN {sub}", arg).fetchone()[0]
        issues = self.conn.execute(
            "SELECT COUNT(*) FROM issues WHERE IFNULL(project,'미분류') = ?",
            arg).fetchone()[0]
        self.conn.execute(f"DELETE FROM change_details WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM acks WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM project_merge_rows WHERE kind = 'change' "
                          f"AND row_id IN {sub}", arg)
        self.conn.execute(
            "DELETE FROM issues WHERE IFNULL(project,'미분류') = ?", arg)
        self.conn.execute(
            "DELETE FROM doc_hints WHERE path IN "
            "(SELECT path FROM changes WHERE IFNULL(project,'미분류') = ?)", arg)
        self.conn.execute(
            "DELETE FROM changes WHERE IFNULL(project,'미분류') = ?", arg)
        self.conn.commit()
        return {"changes": n_changes, "acks": acks, "issues": issues}

    # ── 페이지 그림 기록 (render.py) — 같은 이름으로 덮어써진 도면의 '이전 판'
    # 그림. 파일은 사라져도 이 기록으로 전/후 그림 비교를 한다 (2026-09-02)

    def save_renders(self, sha256: str, pages) -> None:
        self.conn.execute("DELETE FROM renders WHERE sha256 = ?", (sha256,))
        self.conn.executemany(
            "INSERT INTO renders (sha256, page, width, height, meta, png) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [(sha256, i, float(pg.width_pt), float(pg.height_pt),
              json.dumps(pg.meta), pg.png) for i, pg in enumerate(pages, 1)])
        self.conn.commit()

    def has_renders(self, sha256: str | None) -> bool:
        if not sha256:
            return False
        return self.conn.execute(
            "SELECT 1 FROM renders WHERE sha256 = ? LIMIT 1", (sha256,)).fetchone() is not None

    def load_renders(self, sha256: str | None):
        """PageRender 목록. 기록이 없으면 None."""
        if not sha256:
            return None
        from watcher.render import PageRender
        rows = self.conn.execute(
            "SELECT width, height, meta, png FROM renders WHERE sha256 = ? ORDER BY page",
            (sha256,)).fetchall()
        if not rows:
            return None
        return [PageRender(w, h, bytes(png), json.loads(meta or "{}"))
                for w, h, meta, png in rows]

    def prune_renders(self, keep_days: int = 90, now: datetime | None = None) -> int:
        """최신 스냅샷에 없는 판의 그림을 지운다 (도면 1장 ≈ 100~300KB, 누적 방지).
        단, 변경에서 '이전 판'이었던 그림은 keep_days(=설정의 보존 기간) 동안 남긴다 —
        같은 이름으로 덮어쓴 도면의 '전/후 나란히 보기'용. 0이면 무기한 (2026-09-03:
        "몇 달 뒤 변경도 비교되나" — 현재 판 그림은 원래 기한이 없고, 이것은 지나간
        판을 나중에 다시 열어볼 때의 기한이다. 보존 기간 설정 하나로 통일)."""
        if keep_days and keep_days > 0:
            cutoff = ((now or datetime.now(timezone.utc)) - timedelta(days=keep_days)).isoformat()
            ref = "SELECT old_sha256 FROM changes WHERE detected_at >= ? AND old_sha256 IS NOT NULL"
            params: tuple = (cutoff,)
        else:
            ref = "SELECT old_sha256 FROM changes WHERE old_sha256 IS NOT NULL"
            params = ()
        cur = self.conn.execute(
            "DELETE FROM renders WHERE sha256 NOT IN ("
            " SELECT sha256 FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots))"
            f" AND sha256 NOT IN ({ref})", params)
        self.conn.commit()
        return cur.rowcount

    def _latest_rows(self) -> dict[str, tuple]:
        """최근 스냅샷의 전체 행: {path: (sha256, size, mtime)}."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return {}
        return {p: (s, sz, mt) for p, s, sz, mt in self.conn.execute(
            "SELECT path, sha256, size, mtime FROM files WHERE snapshot_id = ?", (row[0],))}

    def record_run(self, records: list[FileRecord],
                   carry_paths: tuple | list = (),
                   known_prefixes: list[str] | None = None,
                   scanned_prefixes: list[str] | None = None) -> tuple[int, list[Change]]:
        """이전 스냅샷과 비교해 변경을 계산하고, 새 스냅샷+변경을 저장한다.

        carry_paths: 이번 스캔에서 읽지 못한 경로들. 이전 스냅샷 값을 그대로 이월해
        '삭제'로 오인하지 않는다 (잠긴 파일이 removed로 잡히는 것 방지).
        known_prefixes: 다중 감시 폴더의 라벨 목록. 지정되면, 더 이상 감시하지 않는
        라벨 아래의 파일은 '삭제' 알림 없이 조용히 스냅샷에서 빠진다
        (감시 폴더를 목록에서 뺐을 뿐 파일이 지워진 게 아니므로).
        """
        if carry_paths:
            # 같은 경로가 두 번 실려 오면(제외 폴더가 동시에 '읽지 못한 폴더'이기도 한 경우처럼)
            # 스냅샷에 같은 행을 두 번 넣어 PRIMARY KEY를 어기고, 그 예외가 롤백 밖에서 터져
            # **그날 검사가 통째로 죽는다**(브리핑도 메일도 없이). 호출부가 아니라 여기서 막는다
            # (2026-09-09 감시·스캔 검토 차단 S1).
            prev = self._latest_rows()
            have = {r.path for r in records}
            seen: set = set()
            extra = []
            for p in carry_paths:
                if p in prev and p not in have and p not in seen:
                    seen.add(p)
                    extra.append(FileRecord(p, *prev[p]))
            records = records + extra
        old = self.latest_snapshot()
        new = {r.path: r for r in records}
        old_mt = dict(self.conn.execute(
            "SELECT path, mtime FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots)"))

        changes: list[Change] = []
        for path in sorted(new.keys() - old.keys()):
            changes.append(Change("added", path, None, new[path].sha256))
        for path in sorted(new.keys() & old.keys()):
            if new[path].sha256 != old[path]:
                changes.append(Change("modified", path, old[path], new[path].sha256))
        for path in sorted(old.keys() - new.keys()):
            if known_prefixes is not None and path.split("/")[0] not in known_prefixes:
                continue  # 감시 폴더 목록에서 빠진 라벨: 삭제 알림 없이 제외
            changes.append(Change("removed", path, old[path], None))

        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute("INSERT INTO snapshots (run_at) VALUES (?)", (now,))
        snapshot_id = cur.lastrowid
        self.conn.executemany(
            "INSERT INTO files (snapshot_id, path, sha256, size, mtime) VALUES (?, ?, ?, ?, ?)",
            [(snapshot_id, r.path, r.sha256, r.size, r.mtime) for r in records])
        with_ids = []
        for c in changes:
            cur = self.conn.execute(
                "INSERT INTO changes (snapshot_id, kind, path, old_sha256, new_sha256, detected_at, mtime, old_mtime) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (snapshot_id, c.kind, c.path, c.old_sha256, c.new_sha256, now,
                 new[c.path].mtime if c.path in new else None, old_mt.get(c.path)))
            with_ids.append(Change(c.kind, c.path, c.old_sha256, c.new_sha256, cur.lastrowid))
        # '진행 중' 표식을 **같은 트랜잭션**에 넣는다. 전에는 호출부가 커밋 뒤에
        # mark_run_started를 따로 불러서, 그 틈(정전·강제 종료)에 죽으면 스냅샷은 남고
        # 표식은 없어 그날 변경이 영원히 브리핑에 안 실렸다 — 화면에만 보였다
        # (2026-09-09 저장 검토 낮음 9a)
        self.conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES ('run_in_progress', ?)",
            (str(snapshot_id),))
        if scanned_prefixes is not None:
            # 감시 폴더(라벨)별 '첫 실제 검사' 스냅샷을 명시적으로 적는다. 변경 기록의 MIN으로만
            # 추정하면 ①첫 검사 때 비어 있던 폴더에 일주일 뒤 들어온 파일이 전부 '등록'으로 접혀
            # 영영 알리지 않고 ②기록을 남긴 채 뺐다가 다시 넣은 폴더가 '변경 N건' 메일이 됐다
            # (검토20 A-4·A-6). 규칙: 직전까지 실제로 검사된 라벨 집합(known_labels)에 없던 라벨이
            # 이번에 검사되면 이번이 그 폴더의 첫 검사. 설정에서 빠진 라벨은 집합에서 지워 다시
            # 넣으면 또 첫 검사가 된다. 닿지 못한(carry) 폴더는 검사된 적이 없으니 포함하지 않는다
            try:
                first_seen = json.loads(self.get_meta("root_first_seen") or "{}")
                known_raw = self.get_meta("known_labels")
                prev_known = set(json.loads(known_raw)) if known_raw is not None else None
            except (ValueError, TypeError):
                first_seen, prev_known = {}, None
            if prev_known is None:
                # 구판 DB의 첫 실행: 직전 스냅샷에 있던 라벨은 이미 검사된 것 — 이번 검사의 진짜
                # '추가'가 등록으로 접히지 않게
                prev_known = {p.split("/", 1)[0] for p in old.keys() if "/" in p}
            for lb in scanned_prefixes:
                if lb not in prev_known:
                    first_seen[lb] = snapshot_id
            keep = set(known_prefixes) if known_prefixes is not None else set(scanned_prefixes)
            known_now = (prev_known | set(scanned_prefixes)) & keep
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('root_first_seen', ?)",
                              (json.dumps(first_seen, ensure_ascii=False),))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('known_labels', ?)",
                              (json.dumps(sorted(known_now), ensure_ascii=False),))
        self.conn.commit()
        return snapshot_id, with_ids

    def save_change_details(self, change_id: int, items: list[dict],
                            captures: dict | None = None) -> None:
        """변경 1건의 내용 비교 결과(diff 항목 + 위치 캡처)를 화면 조회용으로 저장."""
        self.conn.execute(
            "INSERT OR REPLACE INTO change_details (change_id, items_json, captures_json)"
            " VALUES (?, ?, ?)",
            (change_id, json.dumps(items, ensure_ascii=False),
             json.dumps(captures or {}, ensure_ascii=False)))
        self.conn.commit()

    def change_detail(self, change_id: int) -> dict | None:
        row = self.conn.execute(
            "SELECT items_json, captures_json, dismissed_json, user_notes_json "
            "FROM change_details WHERE change_id = ?", (change_id,)).fetchone()
        if row is None:
            return None
        return {"items": [_fix_old_note(it) for it in json.loads(row[0])], "captures": json.loads(row[1] or "{}"),
                "dismissed": json.loads(row[2] or "{}"),
                "user_notes": json.loads(row[3] or "[]")}

    def add_user_note(self, change_id: int, where: str, text: str, by: str) -> bool:
        """사람이 직접 추가하는 '놓친 변경' 기록 — 프로그램이 인식 못한 변경을
        사람이 보완한다 (오탐 숨김의 반대쪽, 원칙 5 양방향 완성 — 2026-08-27).
        상세가 없는 변경(기준선 등)에는 빈 상세를 만들어서라도 붙인다."""
        row = self.conn.execute(
            "SELECT user_notes_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            if self.get_change(change_id) is None:
                return False
            self.save_change_details(change_id, [], {})
            notes = []
        else:
            notes = json.loads(row[0] or "[]")
        notes.append({"where": where, "text": text, "by": by or "-",
                      "at": datetime.now(timezone.utc).isoformat()})
        self.conn.execute(
            "UPDATE change_details SET user_notes_json = ? WHERE change_id = ?",
            (json.dumps(notes, ensure_ascii=False), change_id))
        self.conn.commit()
        return True

    def delete_user_note(self, change_id: int, idx: int) -> None:
        row = self.conn.execute(
            "SELECT user_notes_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        notes = json.loads(row[0] or "[]")
        if 0 <= idx < len(notes):
            notes.pop(idx)
            self.conn.execute(
                "UPDATE change_details SET user_notes_json = ? WHERE change_id = ?",
                (json.dumps(notes, ensure_ascii=False), change_id))
            self.conn.commit()

    def list_user_notes(self) -> list[dict]:
        """전체 '놓친 변경' 기록 (최신순) — 어떤 파일·양식에서 프로그램이 자주
        놓치는지 보는 미탐 리포트용."""
        out = []
        for cid, path, proj, notes_json in self.conn.execute(
                "SELECT d.change_id, c.path, c.project, d.user_notes_json "
                "FROM change_details d JOIN changes c ON c.id = d.change_id "
                "WHERE d.user_notes_json IS NOT NULL"):
            for n in json.loads(notes_json or "[]"):
                out.append({**n, "change_id": cid, "path": path,
                            "project": proj or "미분류"})
        out.sort(key=lambda n: n.get("at", ""), reverse=True)
        return out

    # ------------------------------------------------------------ 수동 짝 지정
    # 자동 규칙(같은 폴더·이름)이 못 엮는 판을 사람이 직접 짝지음 — 이름 오타,
    # '이전판' 폴더 이동, 영어 꼬리 등 (2026-08-29). 원칙 5: 최종 판단은 사람.

    def set_manual_pair(self, child_key: str, prev_key: str, by: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO manual_pairs (child_key, prev_key, by, at) "
            "VALUES (?, ?, ?, ?)",
            (child_key, prev_key, by or "-",
             datetime.now(timezone.utc).isoformat()))
        self.conn.commit()

    def clear_manual_pair(self, child_key: str) -> None:
        self.conn.execute("DELETE FROM manual_pairs WHERE child_key = ?",
                          (child_key,))
        self.conn.commit()

    def manual_pair(self, child_key: str) -> dict | None:
        """{prev_key, by, at} — 지정이 없으면 None."""
        row = self.conn.execute(
            "SELECT prev_key, by, at FROM manual_pairs WHERE child_key = ?",
            (child_key,)).fetchone()
        return ({"prev_key": row[0], "by": row[1], "at": row[2]}
                if row else None)

    def dismiss_change_item(self, change_id: int, idx: int, by: str) -> None:
        """상세 항목 하나를 '오탐/무의미'로 숨김 — 완전 삭제가 아니라 누가·언제와
        함께 보관하고 복원 가능 (원칙 5: 내용은 초안, 최종 판단은 사람 — 2026-08-27).
        idx는 items_json 배열 인덱스 (저장 순서 불변)."""
        row = self.conn.execute(
            "SELECT dismissed_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        d = json.loads(row[0] or "{}")
        d[str(idx)] = {"by": by or "-",
                       "at": datetime.now(timezone.utc).isoformat()}
        self.conn.execute(
            "UPDATE change_details SET dismissed_json = ? WHERE change_id = ?",
            (json.dumps(d, ensure_ascii=False), change_id))
        self.conn.commit()

    def restore_change_item(self, change_id: int, idx: int) -> None:
        row = self.conn.execute(
            "SELECT dismissed_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        d = json.loads(row[0] or "{}")
        d.pop(str(idx), None)
        self.conn.execute(
            "UPDATE change_details SET dismissed_json = ? WHERE change_id = ?",
            (json.dumps(d, ensure_ascii=False), change_id))
        self.conn.commit()

    # ── 실행 표식: 스냅샷을 커밋한 뒤 보고 전에 프로세스가 죽으면(창 X·정전·업데이트)
    # 그날 변경이 영원히 브리핑에 안 실렸다 — 원칙 5 위반 (2026-09-04 검토 core H1).
    # 시작 때 표식을 남기고 정상 종료 때 지운다. 다음 실행이 표식을 보면 그 스냅샷을
    # 되돌려 같은 변경을 다시 감지한다
    def get_meta(self, key: str) -> str | None:
        row = self.conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_meta(self, key: str, value: str | None) -> None:
        if value is None:
            self.conn.execute("DELETE FROM meta WHERE key = ?", (key,))
        else:
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (key, value))
        self.conn.commit()

    def mark_run_started(self, snapshot_id: int) -> None:
        """record_run이 이미 같은 트랜잭션에서 표시한다 — 호출부 호환용으로 남긴다."""
        self.set_meta("run_in_progress", str(snapshot_id))

    def mark_run_finished(self) -> None:
        self.set_meta("run_in_progress", None)

    def unfinished_run(self) -> int | None:
        """보고를 마치지 못한 채 끝난 스냅샷 id (없으면 None)."""
        v = self.get_meta("run_in_progress")
        try:
            sid = int(v) if v else None
        except ValueError:
            return None
        if sid is None:
            return None
        row = self.conn.execute("SELECT 1 FROM snapshots WHERE id = ?", (sid,)).fetchone()
        return sid if row else None

    # ── 프로세스 간 잠금: 작업 스케줄러의 07시 검사와 화면의 [지금 검사]가 겹치면
    # 같은 변경이 두 번 기록되고 브리핑이 3통 나왔다 (2026-09-04 검토 core H4).
    # 파일 잠금 대신 DB의 meta 행을 쓴다 — 삭제 API 없이(원칙 2 가드) 원자적으로
    def acquire_run_lock(self, pid: int, stale_after: float = 6 * 3600) -> bool:
        """이 프로세스가 검사 잠금을 얻으면 True. 살아 있는 다른 검사가 잡고 있거나 DB가 잠겨 있으면 False."""
        try:
            self.conn.execute("BEGIN IMMEDIATE")
        except sqlite3.OperationalError as e:
            # 백신·백업 프로그램·DB 도구가 state.db를 오래 쥐면 예약 검사가 날 traceback으로 죽었다 (검토41 S9 중간 3)
            if "locked" in str(e).lower() or "busy" in str(e).lower():
                return False
            raise
        try:
            row = self.conn.execute(
                "SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
            if row:
                parts = row[0].split(":")
                try:
                    other_pid, at = int(parts[0]), float(parts[1])
                    created = int(parts[2]) if len(parts) > 2 and parts[2] else None
                except (ValueError, IndexError):
                    other_pid, at, created = 0, 0.0, None
                age = time.time() - at
                if other_pid != pid and age < stale_after and _pid_alive(other_pid, created):
                    self.conn.rollback()
                    return False
            mine = _proc_created(pid)
            self.conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES ('run_lock', ?)",
                (f"{pid}:{time.time()}:{mine if mine is not None else ''}",))
            self.conn.commit()
            return True
        except Exception:
            self.conn.rollback()
            raise

    def space_report(self) -> dict:
        """파일 크기와 빈 공간 — 화면에 보여 주고 VACUUM 판단에도 쓴다."""
        pg = self.conn.execute("PRAGMA page_size").fetchone()[0]
        total = self.conn.execute("PRAGMA page_count").fetchone()[0]
        free = self.conn.execute("PRAGMA freelist_count").fetchone()[0]
        return {"bytes": pg * total, "free_bytes": pg * free,
                "pages": total, "free_pages": free}

    def reclaim_space(self, min_free_bytes: int = 32 * 1024 * 1024,
                      min_ratio: float = 0.25) -> dict | None:
        """지운 기록이 차지하던 빈 페이지를 실제로 디스크에 돌려준다 (VACUUM).

        전에는 prune_details/prune_renders가 행만 지워서 **파일 크기가 역대 최대치에
        영구히 고정**됐다 — 실측으로 921MB 파일의 실데이터가 0.2MB였다. 게다가 주간
        백업이 그 빈 페이지까지 복사해 4슬롯이 3GB였다 (2026-09-09 저장 검토 차단 1).

        VACUUM은 원본만큼의 임시 공간과 시간을 쓰므로 **빈 공간이 충분히 클 때만**
        한다. 돌려준 바이트 수를 알려 주고, 할 일이 없으면 None."""
        rep = self.space_report()
        if rep["free_bytes"] < min_free_bytes or                 rep["free_bytes"] < rep["bytes"] * min_ratio:
            return None
        before = rep["bytes"]
        self.conn.commit()
        self.conn.execute("VACUUM")
        after = self.space_report()["bytes"]
        return {"before": before, "after": after, "freed": max(0, before - after)}

    def integrity_ok(self) -> tuple[bool, str]:
        """DB가 온전한가 — 백업 전에 본다. (정상?, 사유)

        전에는 확인 없이 백업을 덮어써서, 디스크 이상·백신 격리로 DB가 한 번 비면
        4주 안에 멀쩡한 사본 4개가 모두 빈 DB로 덮였다 (2026-09-09 저장 검토 차단 3)."""
        try:
            row = self.conn.execute("PRAGMA integrity_check(20)").fetchone()
        except Exception as e:                      # noqa: BLE001
            return False, f"{type(e).__name__}: {e}"
        msg = str(row[0]) if row else "응답 없음"
        return msg == "ok", msg

    def row_counts(self) -> dict:
        """백업 전후 비교용 주요 표의 행 수."""
        out = {}
        for tbl in ("snapshots", "files", "changes", "acks", "issues"):
            try:
                out[tbl] = self.conn.execute(
                    f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
            except Exception:                       # noqa: BLE001
                out[tbl] = -1
        return out

    def run_lock_holder(self, stale_after: float = 6 * 3600) -> int | None:
        """지금 검사를 돌리고 있는 프로세스의 PID (없으면 None) — 읽기만 한다.

        업데이트 교체가 **다른 프로세스의** 예약 검사를 덮치던 것을 막으려고 추가했다
        (2026-09-09 자동 실행 검토 차단 1): 창의 scan_state()는 자기 스레드만 본다."""
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        if not row:
            return None
        parts = str(row[0]).split(":")
        try:
            pid, at = int(parts[0]), float(parts[1])
            created = int(parts[2]) if len(parts) > 2 and parts[2] else None
        except (ValueError, IndexError):
            return None
        if time.time() - at >= stale_after or not _pid_alive(pid, created):
            return None
        return pid

    def release_run_lock(self, pid: int) -> None:
        row = self.conn.execute("SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        if row and row[0].split(":", 1)[0] == str(pid):
            self.set_meta("run_lock", None)

    def delete_run(self, snapshot_id: int) -> None:
        """실패한 실행의 스냅샷·변경·이슈를 되돌린다 — 다음 실행이 다시 감지하도록.
        (보고 단계 실패 시 알림 유실 방지. extracts는 내용 기준 캐시라 남겨도 무해)"""
        self.conn.execute(
            "DELETE FROM change_details WHERE change_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        # 되돌리는 변경의 확인 기록과 번호를 맡겨 둔다 — 지우기만 하니 검사 중 누른 [확인함]·보고 직후 끊긴 검사의
        # 확인이 사라지고 이미 나간 메일의 확인 링크가 '변경 #70이 없습니다'가 됐다 (검토39 P5 차단 2).
        # 다음 검사가 같은 변경(경로·종류·새 지문)을 다시 잡으면 reattach_rolled_back이 옮겨 붙인다
        rolled = [{"id": cid, "path": pth, "kind": kd, "sha": sha}
                  for cid, pth, kd, sha in self.conn.execute(
                      "SELECT id, path, kind, new_sha256 FROM changes WHERE snapshot_id = ?", (snapshot_id,))]
        acks = [{"id": cid, "by": by, "note": note, "at": at}
                for cid, by, note, at in self.conn.execute(
                    'SELECT a.change_id, a."by", a.note, a.at FROM acks a JOIN changes c ON c.id = a.change_id '
                    "WHERE c.snapshot_id = ?", (snapshot_id,))]
        if rolled:
            try:
                prev = json.loads(self.get_meta(ROLLED_BACK_KEY) or "{}")
            except ValueError:
                prev = {}
            prev.setdefault("changes", []).extend(rolled)
            prev.setdefault("acks", []).extend(acks)
            prev["changes"] = prev["changes"][-5000:]
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (ROLLED_BACK_KEY, json.dumps(prev, ensure_ascii=False)))
        self.conn.execute(
            "DELETE FROM acks WHERE change_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute("DELETE FROM issues WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute(  # 롤백된 변경을 가리키는 합치기 기록 (2026-09-02 재검토)
            "DELETE FROM project_merge_rows WHERE kind = 'change' AND row_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute("DELETE FROM changes WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM files WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM snapshots WHERE id = ?", (snapshot_id,))
        self.conn.execute(
            "DELETE FROM meta WHERE key = 'run_in_progress' AND value = ?", (str(snapshot_id),))
        self.conn.commit()

    def reattach_rolled_back(self) -> int:
        """되돌렸던 변경을 이번 검사가 다시 잡았으면 옛 번호 → 새 번호를 기록하고, 맡겨 둔 확인을 새 변경에
        옮겨 붙인다. 돌려주는 값: 옮긴 확인 수 (검토39 P5 차단 2)."""
        try:
            d = json.loads(self.get_meta(ROLLED_BACK_KEY) or "{}")
        except ValueError:
            return 0
        if not d.get("changes"):
            return 0
        try:
            moved = json.loads(self.get_meta(MOVED_IDS_KEY) or "{}")
        except ValueError:
            moved = {}
        left, n = [], 0
        for c in d.get("changes", []):
            row = self.conn.execute(
                "SELECT id FROM changes WHERE path = ? AND kind = ? AND IFNULL(new_sha256,'') = IFNULL(?,'') "
                "AND id > ? ORDER BY id LIMIT 1", (c["path"], c["kind"], c.get("sha"), c["id"])).fetchone()
            if row:
                moved[str(c["id"])] = row[0]
            else:
                left.append(c)
        keep_acks = []
        for a in d.get("acks", []):
            new_id = moved.get(str(a["id"]))
            if new_id is None:
                keep_acks.append(a)
                continue
            dup = self.conn.execute('SELECT 1 FROM acks WHERE change_id = ? AND "by" = ? AND at = ?',
                                    (new_id, a["by"], a["at"])).fetchone()
            if not dup:
                self.conn.execute('INSERT INTO acks (change_id, "by", note, at) VALUES (?, ?, ?, ?)',
                                  (new_id, a["by"], a["note"], a["at"]))
                n += 1
        self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                          (MOVED_IDS_KEY, json.dumps(dict(list(moved.items())[-5000:]))))
        rest = {"changes": left[-5000:], "acks": keep_acks}
        if left or keep_acks:
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (ROLLED_BACK_KEY, json.dumps(rest, ensure_ascii=False)))
        else:
            self.conn.execute("DELETE FROM meta WHERE key = ?", (ROLLED_BACK_KEY,))
        self.conn.commit()
        return n

    def moved_change_id(self, old_id: int) -> int | None:
        """되돌렸다 다시 잡힌 변경의 새 번호 — 이미 나간 메일 링크를 잇는다."""
        try:
            v = json.loads(self.get_meta(MOVED_IDS_KEY) or "{}").get(str(old_id))
        except ValueError:
            return None
        return int(v) if v is not None else None

    @staticmethod
    def issue_key(code: str, path: str, message: str) -> tuple:
        """중복·해소 대조 키 — 문구의 **변하는 부분**(괄호 안의 값·장수, 앞의 [프로젝트])을 뺀다.

        2026-09-03: '(외 도면 N장에서도 불일치)' 숫자만 바뀐 것이 해소+재생성돼 '신규'로 재알림.
        2026-09-14 실사용 day2: 검토21이 도면 간 불일치 문구에서 ' 외 N장'을 빼자 v0.56→0.57.2
        업데이트 뒤 첫 검사에서 열린 이슈 2건이 '재검출되지 않음'으로 닫히고 같은 내용이 새 이슈로
        태어나 **변경 없는 프로젝트에 검토 필요 메일이 나갔다**. 판이 바뀔 때마다 문구가 조금씩
        바뀌므로, 키는 code+path+태그(문구의 뼈대)만 본다 — 값이 바뀌면 열린 이슈의 문구·근거를
        갱신한다(save_issues)."""
        pm = re.match(r"^\s*\[([^\]]*)\]\s*", message)
        m = message[pm.end():] if pm else message                 # 앞의 [프로젝트]
        m = re.sub(r"\s*\([^()]*\)", "", m)                     # 괄호 안(값·장수·안내)
        m = re.sub(r"\s+", " ", m).strip().rstrip(".。 ")
        if code == "TAG_MISMATCH_ACROSS_DRAWINGS":
            # 도면 간 불일치의 path는 '첫 충돌 도면'이라, 기준 도면을 고치거나 이름이 앞선 도면이
            # 들어오면 path가 옮겨가 같은 불일치가 새 이슈로 태어났다 (검토23 A-2). 폴더 단위로 본다.
            # 한 폴더에 두 프로젝트의 도면이 섞이면 같은 태그가 한 키로 뭉치므로(재검토 1-②) 프로젝트
            # **번호**(별칭·표기 변화에 흔들리지 않는 부분)만 키에 넣는다
            from watcher.project import PROJECT_NO_RE
            path = path.rsplit("/", 1)[0] if "/" in path else path
            no = PROJECT_NO_RE.search(pm.group(1).upper()) if pm else None
            if no is None and pm:
                no = re.search(r"(?<![\w-])(\d{2}-\d{3})(?![\w-])", pm.group(1))
            if no:
                m = f"{no.group()}|{m}"
        return code, path, m

    @staticmethod
    def _loose_key(key: tuple) -> tuple:
        """번호 유무를 무시한 느슨한 키 — 귀속이 '[P26-001]'↔'[포장라인]'처럼 번호 있는 이름표와 없는
        이름표 사이를 오가면(별칭 추가·귀속 규칙 변경) 정확 키가 갈려 옛 이슈는 옛 이름으로 남고 같은
        내용이 새로 태어났다 (v0.57.4 재검토 1-③). 정확 키가 없을 때, 느슨한 키로 **하나만** 짝이
        되면 같은 이슈로 본다 — 둘 이상이면(한 폴더에 두 번호 프로젝트) 합치지 않는다."""
        code, path, m = key
        return code, path, m.split("|", 1)[1] if "|" in m else m

    @staticmethod
    def _loose_pair_ok(k1: tuple, k2: tuple) -> bool:
        """느슨한 짝은 번호 **유무**가 다를 때만 — 번호→다른 번호(P26-001→P26-002)까지 짝이 되면
        하루 차이로 다른 프로젝트의 이슈로 이어졌다 (검토24 B-4)."""
        return ("|" in k1[2]) != ("|" in k2[2])

    def save_issues(self, snapshot_id: int, rows, quiet_paths=frozenset()) -> list:
        """일관성 검사 결과 저장. rows: [(Issue, 프로젝트|None)] — 대시보드 표시용.
        quiet_paths: **이번 검사**에서 조용한 변경(재저장·일자만·이동)만 겪은 경로 — 이번 검사의 상세는
        이 시점에 아직 DB에 없어(이슈 저장이 상세 저장보다 앞) 호출부가 넘겨 준다 (검토31 C 1).

        미해결 불일치(도면-BOM 등)는 변경이 있는 날마다 다시 검출되므로
        동일 내용(code+path+message)은 중복 저장하지 않는다. 닫힌 이슈와의 대조에는 기간 창이 없다 —
        재발은 닫은 뒤 내용 변경·값 변화·한 번 사라짐으로 가린다 (2026-08-25 리뷰 → 검토50 D 중간 1)."""
        # 열린 이슈는 기간과 무관하게 전부 — 30일 cutoff가 여기에도 걸려, 30일 넘게 열린 이슈가
        # 다음 변경 날 '새 검토 필요'로 중복 재탄생했다 (검토23 A-1 차단, 실사용 10-12 재발 예약분)
        existing = {self.issue_key(c, p, m): iid for iid, c, p, m in self.conn.execute(
            "SELECT id, code, path, message FROM issues WHERE resolved_at IS NULL")}
        # 느슨한 키 → 정확 키 목록 (번호 유무가 바뀐 귀속의 짝 찾기용)
        loose: dict = {}
        for k in existing:
            loose.setdefault(self._loose_key(k), []).append(k)
        today = {self.issue_key(i.code, i.path, i.message) for i, _p in rows}
        today_loose: dict = {}
        for k in today:
            today_loose[self._loose_key(k)] = today_loose.get(self._loose_key(k), 0) + 1

        def _match(i):
            """오늘 이슈에 대응하는 열린 이슈 id — 정확 키, 없으면 느슨한 키로 **양쪽 다 유일**하고
            번호 유무가 다를 때만."""
            k = self.issue_key(i.code, i.path, i.message)
            if k in existing:
                return existing[k]
            lk = self._loose_key(k)
            cands = [x for x in loose.get(lk, []) if x not in today and self._loose_pair_ok(k, x)]
            if len(cands) == 1 and today_loose.get(lk, 0) == 1:
                return existing[cands[0]]
            return None

        # 닫힌(resolved) 이슈: 같은 불일치가 **그대로 남아 있는 동안**에는 다시 만들지 않는다.
        # 예전에는 닫는 순간 대조에서 빠져, 검사 때마다 똑같은 내용이 새 이슈로 되살아나
        # 브리핑 메일에 매일 실렸다 — 열어 두면 조용하고 닫으면 시끄러웠다
        # (2026-09-09 확인 검토 A3). 그 파일이 닫은 뒤 **다시 바뀌었으면** 진짜 재발로 본다.
        # 시각이 아니라 **검사 회차**로 본다 — 닫은 시각과 검출 시각이 같은 순간일 수 있고,
        # 우리가 알고 싶은 것은 "그 뒤로 그 파일이 또 바뀌었나"이기 때문이다
        closed: dict = {}
        auto_closed: set = set()
        for c, pth, m, snap, rat, ev, rby, gone in self.conn.execute(
                "SELECT code, path, message, snapshot_id, resolved_at, evidence, resolved_by, gone_at FROM issues "
                # 기간으로 자르지 않는다 — 검출 30일째에 [처리함] 불일치가 새 이슈로 되살아나 메일이 나갔다. 재발은 아래
                # _recurred(닫은 뒤 내용 변경)·_values_changed(값)·gone_at(한 번 사라짐)이 가린다 (검토50 D 중간 1)
                "WHERE resolved_at IS NOT NULL"):
            key = self.issue_key(c, pth, m)
            prev = closed.get(key)
            if prev is None or (snap or 0) > prev[1]:
                closed[key] = (pth, snap or 0, rat or "", (ev, m) if c == "BOM_MISMATCH" else None)
                # 교차 검사 이슈가 '자동 해소'로 닫혔다 = 그 불일치가 **사라졌었다** — 다시 나오면 같은 값이어도 재발이다.
                # 도면을 고쳤다가 같은 값으로 되돌린 날 새 이슈가 없었다 (검토43 B 차단 2)
                # 사람이 [처리함]으로 닫은 뒤 검사에서 한 번 사라졌다가(gone_at) 다시 나와도 재발이다 (검토43 B 중간 8)
                if c in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS") and (
                        str(rby or "").startswith("자동 해소") or (gone and str(gone) >= str(rat or ""))):
                    auto_closed.add(key)
                else:
                    auto_closed.discard(key)

        def _recurred(key) -> bool:
            """닫은 뒤 그 파일이 **내용이 바뀌는** 변경을 겪었는가. 일자만 재출도·재저장·이동 같은
            조용한 변경은 재발이 아니다 — 세트 재출도 날 사람이 닫아 둔 이슈가 전부 되살아났다 (검토31 C 1)."""
            pth, snap, rat, _ev = closed[key]
            for js, at in self.conn.execute(
                    "SELECT d.items_json, c.detected_at FROM changes c "
                    "LEFT JOIN change_details d ON d.change_id = c.id "
                    "WHERE c.path = ? AND c.snapshot_id > ?", (pth, snap)):
                # 검출과 [처리함] 사이에 있던 변경은 사람이 보고 닫은 것이다 — 닫은 뒤의 변경만 (검토31 C 1)
                if rat and str(at or "") < rat:    # 같은 순간(시험의 연속 호출)은 닫은 뒤로 본다
                    continue
                if js is None and pth in quiet_paths:
                    continue                       # 이번 검사의 조용한 변경 (상세는 아직 저장 전)
                if not self._quiet_items(js):
                    return True
            return False

        def _values_changed(key, issue) -> bool:
            """도면-BOM 불일치는 대표 경로가 BOM 파일이고 문구에 값이 없다 — 닫힌 뒤 **도면만** 다른 값으로 다시
            어긋나도 같은 이슈로 묻혔다(검토41 S3 차단 1). 근거에 인용된 파일 경로로 보던 v0.57.20 고침은 파일 이름만
            적힌 근거·폴더 이동·괄호 든 경로에서 소리 없이 무효였고, 인용된 도면의 무관한 편집만으로 [처리함] 이슈를
            되살렸다(검토42 A 차단·중간 5). **값**으로 본다: BOM 사양과 도면 줄이 닫을 때와 다르면 재발이다."""
            if issue.code != "BOM_MISMATCH":
                return False
            ev_old, msg_old = closed[key][3] or (None, "")
            old = self._mismatch_values(ev_old, msg_old)
            new = self._mismatch_values(json.dumps(list(issue.evidence), ensure_ascii=False), issue.message)
            return bool(old and new and old != new)

        closed_loose: dict = {}
        for k in closed:
            closed_loose.setdefault(self._loose_key(k), []).append(k)

        def _closed_key(k):
            """닫힌 이슈 쪽 짝 — 정확 키, 없으면 같은 느슨한 규칙. [처리함]으로 닫은 이슈가 별칭 한 줄
            추가로 새 이슈+'검토 필요 1건' 메일로 되살아났다 (검토24 B-3)."""
            if k in closed:
                return k
            lk = self._loose_key(k)
            cands = [x for x in closed_loose.get(lk, []) if self._loose_pair_ok(k, x)]
            return cands[0] if len(cands) == 1 and today_loose.get(lk, 0) == 1 else None

        now = datetime.now(timezone.utc).isoformat()
        fresh = []
        # 다시 생긴 이슈 → 전에 닫힌 시각 — 메일 카드가 '재발'을 말하지 않아 BOM이 옛 값으로 되돌아간 사고가 새 불일치로만
        # 보였다 (검토44 C 중간 3)
        self.last_recurred = {}
        for i, proj in rows:
            if _match(i) is not None:
                continue
            ck = _closed_key(self.issue_key(i.code, i.path, i.message))
            if ck is None or ck in auto_closed or _recurred(ck) or _values_changed(ck, i):
                fresh.append((i, proj))
                if ck is not None:
                    self.last_recurred[(i.code, i.path, i.message)] = closed[ck][2]
        # 이미 열린 이슈는 근거·문구를 최신 값으로 갱신한다 — 값이 바뀐 뒤에도 옛 값이
        # 화면에 남아 파일과 달랐다 (2026-09-05 전체 검토, 원칙 4)
        # 경로(첫 충돌 도면이 바뀜)·프로젝트(귀속 이름이 바뀜)도 따라간다 — project가 옛 이름으로
        # 남으면 auto_resolve의 '그 프로젝트를 검사했나' 판정에서 영원히 빠져 해소가 안 됐다 (검토23 A-2·A-3)
        # 단, 파일 한 번의 편집을 말하는 이슈('Rev 미갱신' 등)는 근거를 **쌓는다** — 문구에 값이 없어 키가 늘 같으니,
        # 열린 동안 새 편집이 오면 처음 잡힌 편집의 근거가 마지막 편집으로 덮여 무엇 때문에 열렸는지 사라졌다
        # (검토42 D 중간 2, 원칙 4). 상태형(도면 간·도면-BOM 불일치)은 지금 값이 맞는 근거라 예전처럼 갱신
        self.last_continued = []      # (경로, 코드, 프로젝트, 처음 잡힌 시각) — 열린 경고의 파일이 오늘 또 바뀜 (검토43 C 중간 1)
        for i, proj in rows:
            iid = _match(i)
            if iid is not None:
                ev_new = list(i.evidence)
                if i.code in self.EVENT_CODES:
                    row = self.conn.execute("SELECT evidence, detected_at FROM issues WHERE id = ?", (iid,)).fetchone()
                    try:
                        ev_old = json.loads(row[0]) if row and row[0] else []
                    except (ValueError, TypeError):
                        ev_old = []
                    ev_new = self._stack_evidence(ev_old, ev_new, i.code)
                    if ev_new != [str(x) for x in ev_old]:
                        self.last_continued.append((i.path, i.code, proj, row[1] if row else ""))
                self.conn.execute(
                    "UPDATE issues SET message = ?, evidence = ?, path = ?, project = ? WHERE id = ?",
                    (i.message, json.dumps(ev_new, ensure_ascii=False), i.path, proj, iid))
        self.conn.executemany(
            "INSERT INTO issues (snapshot_id, code, path, project, message, evidence,"
            " detected_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [(snapshot_id, i.code, i.path, proj, i.message,
              json.dumps(list(i.evidence), ensure_ascii=False), now)
             for i, proj in fresh])
        self.conn.commit()
        # 새로 기록된 것만 돌려준다 — 브리핑은 신규만 싣고, 미해결 누적은 화면에서
        # 본다 (같은 경고가 변경 있는 날마다 메일로 재알림되던 소음 제거, 2026-08-26)
        return fresh

    # 파일 한 번의 편집을 말하는 이슈 — 근거를 쌓는다(save_issues)
    revert_why: dict = {}   # (경로, 코드) → 자동 해소 사유 — cli가 검사마다 새 dict로 바꿔 넣는다
    EVENT_CODES = frozenset({"CONTENT_CHANGED_REV_SAME", "REV_CHANGED_CONTENT_SAME", "REV_REGRESSED"})
    _STACK_MARK = "── "
    _STACK_KEEP = 3          # 처음 잡힌 편집 + 최근 추가 편집 몇 번까지

    _STACK_HEAD = {"CONTENT_CHANGED_REV_SAME": "Rev가 그대로인 채 또 바뀜",
                   "REV_CHANGED_CONTENT_SAME": "또 Rev만 바뀜", "REV_REGRESSED": "Rev가 또 거꾸로 감"}

    @classmethod
    def _stack_evidence(cls, old: list, new: list, code: str = "CONTENT_CHANGED_REV_SAME") -> list:
        """처음 근거는 그대로 두고, 새 편집의 근거('이번 변경 …' 줄들)를 날짜 머리와 함께 뒤에 붙인다.
        같은 근거가 또 오면(같은 편집을 다시 검사) 붙이지 않는다. 너무 길어지면 중간 편집을 '그 사이 N번'으로 접는다."""
        old = [str(x) for x in (old or [])]
        new = [str(x) for x in (new or [])]
        head = cls._STACK_HEAD.get(code, "또 바뀜")   # 코드마다 맞는 머리 — 'Rev만 갱신'에도 'Rev가 그대로인 채'라 적었다 (검토43 A 낮음 5)
        if not old:
            return new
        body = new[1:] if len(new) > 1 else new
        if not body or all(line in old for line in body):
            return old
        # 처음 편집 블록(첫 머리 줄 전까지)과 이미 붙은 블록들로 나눈다
        first, blocks, cur = [], [], None
        folded = 0
        for line in old:
            if line.startswith(cls._STACK_MARK):
                m = re.match(r"── 그 사이 (\d+)번 더 바뀜", line)
                if m:
                    folded += int(m.group(1))
                    continue
                cur = [line]
                blocks.append(cur)
            elif cur is None:
                first.append(line)
            else:
                cur.append(line)
        when = datetime.now().astimezone().strftime("%m-%d %H:%M")
        # 머리에 ': '를 쓰지 않는다 — 화면이 근거 줄을 ': '에서 두 칸으로 가른다
        blocks.append([f"{cls._STACK_MARK}{when} 검사 — {head}"] + body)
        keep = cls._STACK_KEEP - 1
        if len(blocks) > keep:
            folded += len(blocks) - keep
            blocks = blocks[-keep:]
        out = list(first)
        if folded:
            out.append(f"{cls._STACK_MARK}그 사이 {folded}번 더 바뀜 (변경 이력에 모두 있습니다)")
        for b in blocks:
            out += b
        return out

    def past_version(self, path: str, sha: str, before_snapshot: int | None) -> tuple | None:
        """(기록 시각 ISO, 그 검사에서 **들어온** 판인가). 바뀐 뒤 지문(new_sha256)이 맞으면 그 검사 때 들어온 판, 바뀌기 전
        지문(old_sha256)만 맞으면 그 검사 **전까지** 있던 판 — 한데 보면 날짜가 한 검사 늦었다 (검토43 C 중간 3)."""
        if not sha:
            return None
        for col, came_in in (("new_sha256", True), ("old_sha256", False)):
            row = self.conn.execute(
                f"SELECT detected_at FROM changes WHERE path = ? AND {col} = ? "
                "AND (? IS NULL OR snapshot_id < ?) ORDER BY id DESC LIMIT 1",
                (path, sha, before_snapshot, before_snapshot)).fetchone()
            if row:
                return row[0], came_in
        return None

    def past_version_seen(self, path: str, sha: str, before_snapshot: int | None) -> str | None:
        """이 경로가 **전에** 이 지문(sha)이었던 적이 있으면 그 기록 시각(ISO), 없으면 None — 옛 판으로 되돌아간 표지.
        바뀌기 전 지문(old_sha256)과 바뀐 뒤 지문(new_sha256)을 모두 본다."""
        if not sha:
            return None
        row = self.conn.execute(
            "SELECT detected_at FROM changes WHERE path = ? AND (old_sha256 = ? OR new_sha256 = ?) "
            "AND (? IS NULL OR snapshot_id < ?) ORDER BY id DESC LIMIT 1",
            (path, sha, sha, before_snapshot, before_snapshot)).fetchone()
        return row[0] if row else None

    def pre_issue_sha(self, path: str, code: str) -> str | None:
        """이 파일의 열린 이슈(code)가 처음 잡힌 검사에서 **바뀌기 전** 해시 — 그 편집이 되돌려졌는지 가리는 기준."""
        row = self.conn.execute(
            "SELECT snapshot_id FROM issues WHERE path = ? AND code = ? AND resolved_at IS NULL "
            "ORDER BY id LIMIT 1", (path, code)).fetchone()
        if not row or row[0] is None:
            return None
        ch = self.conn.execute(
            "SELECT old_sha256 FROM changes WHERE path = ? AND snapshot_id = ? AND old_sha256 IS NOT NULL "
            "ORDER BY id LIMIT 1", (path, row[0])).fetchone()
        return ch[0] if ch else None

    def unrevised_pending(self, path: str) -> bool:
        """이 파일의 마지막 'Rev 미갱신' 뒤로 Rev를 올린 적이 없는가(열림·닫힘·기간 무관). 그렇다면 지금의 'Rev만 올림'은 그 편집의
        정식 개정이다 — 14일 창이라 발행 주기가 2~3주인 집은 [처리함] 뒤 정상 개정이 'Rev만 갱신' 경고가 됐다 (검토50 D 중간 2)."""
        row = self.conn.execute(
            "SELECT MAX(snapshot_id) FROM issues WHERE path = ? AND code = 'CONTENT_CHANGED_REV_SAME'", (path,)).fetchone()
        if not row or row[0] is None:
            return False
        for (js,) in self.conn.execute(
                "SELECT d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                "WHERE c.path = ? AND c.snapshot_id > ?", (path, row[0])):
            try:
                its = json.loads(js or "[]")
            except ValueError:
                continue
            if any(str(i.get("kind")) == "FIELD_CHANGED" and str(i.get("key") or "").split("#", 1)[0] == "REV"
                   for i in its if isinstance(i, dict)):
                return False
        return True

    def has_open_issue(self, path: str, code: str, recent_days: int = 14) -> bool:
        """열려 있거나 최근 recent_days 안에 닫힌 이슈가 있는가 — 담당자가 'Rev 미갱신'을 먼저
        [처리함]으로 닫고 Rev를 올리는 순서도 흔하다 (2026-09-05 재검토)."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=recent_days)).isoformat()
        row = self.conn.execute(
            "SELECT 1 FROM issues WHERE path = ? AND code = ? AND "
            "(resolved_at IS NULL OR resolved_at >= ?) LIMIT 1",
            (path, code, cutoff)).fetchone()
        return row is not None

    def issues(self, project: str | None = None, resolved: bool = False) -> list[dict]:
        """확인 필요 이력 (최신순). 프로젝트 필터 가능. resolved=True면 처리된 것.

        처리하면 흔적 없이 사라져 '누가 언제 처리했는지'를 볼 곳이 없었다
        (2026-09-02 처음 보는 사람 검토)."""
        sql = ("SELECT id, detected_at, code, path, project, message, evidence, "
               "snapshot_id, resolved_at, resolved_by FROM issues WHERE resolved_at IS "
               + ("NOT NULL " if resolved else "NULL "))
        params: tuple = ()
        if project:
            sql += "AND project = ? "
            params = (project,)
        sql += "ORDER BY " + ("resolved_at DESC" if resolved else "id DESC")
        keys = ("issue_id", "detected_at", "code", "path", "project", "message",
                "evidence", "snapshot_id", "resolved_at", "resolved_by")
        out = []
        for row in self.conn.execute(sql, params):
            d = dict(zip(keys, row))
            d["evidence"] = json.loads(d["evidence"])
            out.append(d)
        return out

    def changes_for_paths(self, paths, snapshot_id: int | None = None) -> dict:
        """파일 경로 → 전/후 비교를 볼 수 있는 변경 id.

        검토 필요 항목에서 그 파일의 비교 화면으로 바로 갈 수 있게 한다.
        같은 검사(snapshot)의 변경을 우선하고, 없으면 가장 최근 변경을 쓴다.
        내용 비교 기록(change_details)이 있는 변경만 — 링크를 눌렀는데
        '비교 기록이 없습니다'가 나오면 헛걸음이다 (2026-09-02)."""
        paths = [p for p in dict.fromkeys(paths) if p]
        if not paths:
            return {}
        marks = ",".join("?" * len(paths))
        rows = self.conn.execute(
            f"SELECT c.path, c.id, c.snapshot_id FROM changes c "
            f"JOIN change_details d ON d.change_id = c.id "
            f"WHERE c.path IN ({marks}) ORDER BY c.id ASC", tuple(paths)).fetchall()
        out: dict = {}
        for path, cid, snap in rows:            # 뒤(최신)가 앞을 덮는다
            out[path] = cid
        if snapshot_id is not None:             # 같은 검사 것이 있으면 그쪽으로
            for path, cid, snap in rows:
                if snap == snapshot_id:
                    out[path] = cid
        return out

    def auto_resolve_issues(self, keep: set, changed_paths: set, projects: set,
                            readable: set | None = None, present: set | None = None,
                            rev_changed: set | None = None, rev_raised: set | None = None) -> int:
        """열린 이슈 중 이번 검사에서 다시 검출되지 않은 것을 '자동 해소'로 닫는다.
        파일 단위 판정(Rev)은 그 파일이 이번에 바뀌었을 때만, 교차 검사(도면 간·BOM)는
        그 프로젝트가 이번에 검사됐을 때만 — 검사하지 않은 것을 해소로 오인하지 않게.
        readable: 이번에 내용을 읽은 경로 — 못 읽은(손상·잠김) 파일의 이슈는 닫지 않는다.
        present: 이번 스냅샷의 경로 — 없어진 파일의 이슈는 '파일 삭제됨'으로 닫는다.
        (2026-09-03 검토·재검토)"""
        rows = self.conn.execute(
            "SELECT id, code, path, project, message FROM issues "
            "WHERE resolved_at IS NULL").fetchall()
        keep_keys = {self.issue_key(*k) for k in keep}
        keep_loose: dict = {}
        for k in keep_keys:
            keep_loose[self._loose_key(k)] = keep_loose.get(self._loose_key(k), 0) + 1
        open_loose: dict = {}
        for _iid, code, path, _proj, msg in rows:
            lk = self._loose_key(self.issue_key(code, path, msg))
            open_loose[lk] = open_loose.get(lk, 0) + 1
        now = datetime.now(timezone.utc).isoformat()
        n = 0
        for iid, code, path, proj, msg in rows:
            k = self.issue_key(code, path, msg)
            if k in keep_keys:
                continue
            # 번호 유무만 다른 짝이 오늘·열린 쪽 모두 하나뿐이면 같은 이슈(save_issues가 이미 갱신했다)
            lk = self._loose_key(k)
            if keep_loose.get(lk, 0) == 1 and open_loose.get(lk, 0) == 1 \
                    and any(self._loose_pair_ok(k, x) for x in keep_keys if self._loose_key(x) == lk):
                continue
            cross = code in ("TAG_MISMATCH_ACROSS_DRAWINGS", "BOM_MISMATCH")
            why = None
            if present is not None and path not in present:
                why = "자동 해소 — 파일이 삭제됨"
            elif readable is not None and path not in readable:
                continue                       # 못 읽은 파일 — 해소로 오인하지 않는다
            elif code == "REV_REGRESSED" and rev_changed is not None and path not in rev_changed:
                continue                       # Rev는 그대로 두고 내용만 고친 날 '거꾸로 감'이 해소로 닫혔다 (검토46 C 중간 2)
            elif (cross and proj in projects) or (not cross and path in changed_paths):
                why = (self.revert_why.get((path, code)) if not cross else None) \
                    or ("자동 해소 — Rev를 올림(개정 발행)" if code == "CONTENT_CHANGED_REV_SAME" and rev_raised
                        and path in rev_raised else None) \
                    or ("자동 해소 — Rev가 바뀜" if code == "CONTENT_CHANGED_REV_SAME" and rev_changed
                        and path in rev_changed else None) \
                    or "자동 해소 — 다시 검사했을 때 재검출되지 않음"   # 사유를 밝힌다 (검토46 B G42)
            if why:
                self.conn.execute(
                    "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?",
                    (now, why, iid))
                n += 1
        # 사람이 닫은 교차 이슈(도면 간·도면-BOM)가 이번에 그 프로젝트를 검사했는데 다시 나오지 않았다 = 고쳐졌다 — 그 시각을
        # 남겨, 나중에 같은 값으로 다시 어긋나면 새 이슈가 되게 한다 (검토43 B 중간 8)
        for iid, code, path, proj, msg in self.conn.execute(
                "SELECT id, code, path, project, message FROM issues WHERE resolved_at IS NOT NULL AND gone_at IS NULL "
                "AND code IN ('BOM_MISMATCH', 'TAG_MISMATCH_ACROSS_DRAWINGS')").fetchall():   # 기간 창 없음 (검토50 D 중간 1)
            k = self.issue_key(code, path, msg)
            if proj not in projects or k in keep_keys:
                continue
            # 열린 이슈와 같은 규칙 — 못 읽은 파일(잠김·시간 상한)은 '사라짐'이 아니고, 번호 유무만 다른 짝은 같은 이슈다.
            # 빠졌을 때 고친 적 없는 불일치가 다음 날 '재발'로 다시 메일에 나왔다 (검토44 A 중간 4)
            if readable is not None and path not in readable:
                continue
            if any(self._loose_key(x) == self._loose_key(k) and self._loose_pair_ok(k, x) for x in keep_keys):
                continue
            self.conn.execute("UPDATE issues SET gone_at = ? WHERE id = ?", (now, iid))
        self.conn.commit()
        self.revert_why = {}                 # 이번 검사 것만 — 다음 검사에 새지 않게
        return n

    def reopen_issue(self, issue_id: int) -> bool:
        """[처리함]을 잘못 눌렀을 때 되돌린다 — 되돌릴 길이 없어 같은 경고가 다시 검출될 때까지 사라졌다
        (검토38 R9 중간 2). 사람이 닫은 것만(자동 해소는 파일이 바뀌면 다시 판정된다)."""
        cur = self.conn.execute(
            "UPDATE issues SET resolved_at = NULL, resolved_by = NULL WHERE id = ? AND resolved_at IS NOT NULL "
            "AND IFNULL(resolved_by, '') NOT LIKE '자동 해소%'", (issue_id,))
        self.conn.commit()
        return cur.rowcount > 0

    def resolve_issue(self, issue_id: int, by: str = "") -> bool:
        """이상 징후를 '처리함'으로 닫는다 — 목록·누적 숫자에서 빠진다.
        기록은 지우지 않는다 (같은 내용이 다시 검출되면 새 이슈로 다시 쌓인다).

        실제로 닫았으면 True. 없는 id였는데 "표시했습니다"라고 답하던 것을 막는다
        (2026-09-09 웹 검토 낮음 9)."""
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute(
            # 이미 닫힌 것은 건드리지 않는다 — 한꺼번에 처리가 자동 해소된 이슈의 사유를 사람 이름으로 덮었다 (검토45 A 낮음)
            "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ? AND resolved_at IS NULL",
            (now, by, issue_id))
        self.conn.commit()
        return cur.rowcount > 0

    def _secret(self) -> str:
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'ack_secret'").fetchone()
        if row:
            return row[0]
        s = secrets.token_hex(16)
        self.conn.execute("INSERT INTO meta (key, value) VALUES ('ack_secret', ?)", (s,))
        self.conn.commit()
        return s

    def ack_token(self, change_id: int) -> str:
        """확인 링크용 토큰. 링크를 아는 사람만 확인을 저장할 수 있다 (CSRF 방지)."""
        return hmac.new(self._secret().encode(), str(change_id).encode(),
                        "sha256").hexdigest()[:16]

    def csrf_token(self) -> str:
        """웹 대시보드 폼 공용 CSRF 토큰 (설치별 고정).

        127.0.0.1 바인딩이어도 CSRF는 못 막는다 — 요청이 사용자 브라우저에서
        나가기 때문. 외부 페이지는 이 토큰을 읽을 수 없으므로 폼 위조가 차단된다."""
        return hmac.new(self._secret().encode(), b"csrf-form",
                        "sha256").hexdigest()[:32]

    def prune_details(self, days: int = 90, now: datetime | None = None) -> int:
        """보존 기간이 지난 무거운 기록을 지워 DB 비대화를 막는다.
        ①변경 상세(diff+캡처 JSON — 캡처 포함 시 수 MB)
        ②오래된 스냅샷의 파일 목록 — 매 검사마다 전체 파일 목록이 기록되어
          파일 1,000개당 검사 1회 약 172KB씩 영구 누적됨 (2026-08-25 확장성 검토).
          비교에 쓰는 최신 스냅샷은 기간과 무관하게 보존한다.
        변경 이력(changes)·확인(acks)·추출 캐시는 남긴다. 돌려주는 값: 지운 행 수."""
        # now: 기준 시각 — PC 시계가 튄 동안은 '마지막 정상 검사 + 그 뒤 검사 수'를 쓴다 (검토47 E 중간 1)
        cutoff = ((now or datetime.now(timezone.utc)) - timedelta(days=days)).isoformat()
        # 사진(captures — 변경 하나에 수 MB)만 지운다. 근거 항목·오탐 숨김(누가 언제)·사람 메모는 감사 기록이라
        # 남긴다 — 상세를 통째로 지우니 조용한 변경이 미확인으로 되살아났고(검토38 R3 차단 3), 개정 근거와 숨김
        # 기록이 사라져 화면이 '첫 등록이거나 추출 대상 아님'이라는 틀린 사유를 댔다 (검토39 P5 차단 1)
        cur = self.conn.execute(
            "UPDATE change_details SET captures_json = NULL WHERE captures_json IS NOT NULL AND change_id IN "
            "(SELECT id FROM changes WHERE detected_at < ?)", (cutoff,))
        n = cur.rowcount
        # 파일 목록은 최신 스냅샷만 읽는다 — 90일치 4만 건씩(≈360만 행)을 둘 이유가
        # 없다. 최신 1회분만 남긴다 (2026-09-02 재검토)
        cur = self.conn.execute(
            "DELETE FROM files WHERE snapshot_id NOT IN ("
            " SELECT id FROM snapshots ORDER BY id DESC LIMIT 1)")
        n += cur.rowcount
        # 추출 캐시: 최신 스냅샷에도 없고 보존 기간 안의 변경에도 안 걸리는 판은 고아
        # — 모든 판의 전문이 영구 누적되던 것 (2026-09-02 재검토)
        cur = self.conn.execute(
            "DELETE FROM extracts WHERE sha256 NOT IN ("
            " SELECT sha256 FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots))"
            " AND sha256 NOT IN ("
            " SELECT old_sha256 FROM changes WHERE detected_at >= ? AND old_sha256 IS NOT NULL)"
            " AND sha256 NOT IN ("
            " SELECT new_sha256 FROM changes WHERE detected_at >= ? AND new_sha256 IS NOT NULL)",
            (cutoff, cutoff))
        n += cur.rowcount
        self.conn.commit()
        return n

    def set_change_project(self, change_id: int, project: str) -> None:
        self.conn.execute("UPDATE changes SET project = ? WHERE id = ?", (project, change_id))
        self.conn.commit()

    def get_change(self, change_id: int) -> Change | None:
        if not isinstance(change_id, int) or not (0 <= change_id < 2 ** 62):
            return None                  # 큰 정수는 sqlite가 OverflowError로 끊었다 (검토25 화면 3-7)
        row = self.conn.execute(
            "SELECT kind, path, old_sha256, new_sha256, id, project FROM changes WHERE id = ?",
            (change_id,)).fetchone()
        return Change(*row) if row else None

    def change_mtimes(self, change_id: int) -> tuple:
        """(이번 판 저장 시각, 이전 판 저장 시각) — 그 변경이 기록된 순간의 값. 없으면 (None, None)."""
        try:
            row = self.conn.execute("SELECT mtime, old_mtime FROM changes WHERE id = ?", (change_id,)).fetchone()
        except sqlite3.OperationalError:
            return (None, None)
        return (row[0], row[1]) if row else (None, None)

    def add_ack(self, change_id: int, by: str, note: str) -> bool:
        """확인 기록 저장. 대상 변경이 없으면 False."""
        if self.get_change(change_id) is None:
            return False
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute("INSERT INTO acks (change_id, by, note, at) VALUES (?, ?, ?, ?)",
                          (change_id, by, note, now))
        self.conn.commit()
        return True

    def add_ack_bulk(self, change_ids: list[int], by: str, note: str) -> int:
        """여러 변경을 한 번에 확인 처리 — 기준선 수백 건 등 (2026-08-26 신입 검토:
        하나씩 이름 쳐서 확인하는 것 말고는 미확인을 줄일 방법이 없던 문제)."""
        now = datetime.now(timezone.utc).isoformat()
        self.conn.executemany(
            "INSERT INTO acks (change_id, by, note, at) VALUES (?, ?, ?, ?)",
            [(cid, by, note, now) for cid in change_ids])
        self.conn.commit()
        return len(change_ids)

    def first_snapshot_by_root(self) -> dict[str, int]:
        """감시 폴더(경로 키 첫 마디)별 첫 검사 스냅샷 id — 그때의 '추가'는 기준선.
        changes는 정리(prune)되지 않아 폴더를 나중에 추가해도 첫 검사를 알 수 있다
        (2026-09-02 재검토: 두 번째 폴더의 첫 등록이 미확인 변경으로 잡혔다)."""
        out = {r: s for r, s in self.conn.execute(
            "SELECT CASE WHEN instr(path, '/') > 0 THEN substr(path, 1, instr(path, '/') - 1)"
            " ELSE path END AS r, MIN(snapshot_id) FROM changes GROUP BY r")}
        # record_run이 명시적으로 적은 '첫 실제 검사'가 있으면 그것이 우선 (검토20 A-4·A-6)
        try:
            explicit = json.loads(self.get_meta("root_first_seen") or "{}")
        except (ValueError, TypeError):
            explicit = {}
        for r, s in explicit.items():
            try:
                out[str(r)] = int(s)
            except (TypeError, ValueError):
                pass
        # DB 첫 검사(전체 기준선)의 등록도 언제나 등록이다 — 기록을 남긴 채 뺐다가 다시 넣은 폴더는
        # 첫 검사가 새 스냅샷으로 바뀌는데, 그러면 옛 첫 검사 행이 '미확인 변경'으로 되살아났다
        # (검토20 재검증 ①). 예약 키 "*"로 함께 돌려주고 is_first_registration이 본다
        first = self.first_snapshot_id()
        if first is not None:
            out["*"] = first
        return out

    # ── 나중에 켠 확장자의 첫 등록 (2026-09-10 검토18 ③-A)
    # 감시 폴더를 나중에 추가하면 그 폴더의 첫 검사가 기준선인 것처럼, 확장자를 나중에
    # 켜면(설정의 묶음 단추 한 번에 106개) 그 검사에서 잡힌 그 확장자의 '추가'도 변경이
    # 아니라 등록이다 — 아니면 PLC 파일 수백 건이 그날 브리핑에 '추가'로 쏟아진다.
    # 어느 검사에서 어떤 확장자가 새로 켜졌는지를 meta에 남기고 화면·주간·브리핑이 같은
    # 규칙으로 센다. "감시 시작 뒤 처음 나타난 파일"과는 다르다 — 그것은 진짜 추가다.
    def ext_baseline(self) -> dict[str, int]:
        """{확장자: 그 확장자가 처음 켜진 검사의 스냅샷 id}."""
        import json
        raw = self.get_meta("ext_baseline")
        try:
            d = json.loads(raw) if raw else {}
            return {str(k).lower(): int(v) for k, v in d.items()}
        except (ValueError, TypeError, AttributeError):
            return {}

    def note_ext_baseline(self, exts, snapshot_id: int) -> None:
        import json
        d = self.ext_baseline()
        for e in exts:
            d[str(e).lower()] = int(snapshot_id)
        self.set_meta("ext_baseline", json.dumps(d, ensure_ascii=False))

    @staticmethod
    def is_first_registration(kind: str, path: str, snapshot_id,
                              first_by_root: dict, ext_base: dict) -> bool:
        """이 '추가'가 변경이 아니라 등록인가 — 폴더의 첫 검사이거나 확장자를 켠 검사."""
        if kind != "added" or snapshot_id is None:
            return False
        if snapshot_id == first_by_root.get("*"):      # DB 첫 검사(전체 기준선)
            return True
        root = path.split("/", 1)[0] if "/" in path else path
        if snapshot_id == first_by_root.get(root):
            return True
        dot = path.rfind(".")
        ext = path[dot:].lower() if dot > path.rfind("/") else ""
        return bool(ext) and snapshot_id == ext_base.get(ext)

    def repath_open_issues(self, old_path: str, new_path: str) -> int:
        """이동한 파일의 이슈를 새 경로로 옮긴다 — 삭제·재발로 두 번 세지 않게. 열린 것을 센다.
        닫힌 이슈도 따라간다 — 옛 경로에 남으면 '닫은 것과 같은 내용' 대조가 새 경로와 안 맞아
        폴더 정리 날 닫아 둔 이슈가 전부 되살아났다 (검토32 B5)."""
        cur = self.conn.execute(
            "UPDATE issues SET path = ? WHERE path = ? AND resolved_at IS NULL",
            (new_path, old_path))
        n = cur.rowcount or 0
        self.conn.execute("UPDATE issues SET path = ? WHERE path = ? AND resolved_at IS NOT NULL",
                          (new_path, old_path))
        self.conn.commit()
        return n

    _EV_PATH = re.compile(r"[(,]\s*([^(),]+?\.(?:dxf|dwg|pdf|xlsx|xlsm|docx|hwpx))\s*\)", re.I)

    @staticmethod
    def _mismatch_values(ev_json, message: str = "") -> tuple | None:
        """도면-BOM 불일치 근거에서 (BOM 사양, 도면 줄들) — 'BOM: TAG SPEC=5.5kW (…)'·'도면[Rev B, …]: M-101 … (…)'."""
        try:
            lines = json.loads(ev_json or "[]")
        except (ValueError, TypeError):
            return None
        spec, dwg, tag = None, set(), ""
        for ln in lines if isinstance(lines, list) else []:
            t = str(ln)
            m = re.match(r"BOM:\s*(\S+)\s+SPEC=(.*?)\s\(", t)
            if m:
                tag = m.group(1)
                spec = " ".join(m.group(2).split()).upper()
                continue
            if t.startswith(("도면", "문서")) and ": " in t:     # 사양서 근거는 '문서'로 (검토44 C 중간 3)
                # '(위치, 경로)' 묶음은 마지막 쉼표 앞의 ' (' 부터 — 경로에 괄호가 있어도('(삼성)') 줄 글자만 남긴다
                body = t.split(": ", 1)[1].rstrip().rstrip(")")
                ci = body.rfind(", ")
                pi = body.rfind(" (", 0, ci) if ci > 0 else -1
                if pi > 0:
                    # 그 태그의 조각만 — 줄 전체로 견주면 같은 줄 **다른** 태그 값만 바뀌어도 [처리함] 이슈가 되살아났다
                    # (검토43 A 중간 4)
                    txt = body[:pi]
                    if tag:
                        from watcher.consistency import _tag_segment
                        txt = _tag_segment(tag, txt) or txt
                    dwg.add(" ".join(txt.split()).upper())
        # '(외 도면 N장에서도 불일치)' — 근거는 첫 도면만 인용한다. 닫은 뒤 **다른** 도면이 어긋나면 이 수가 바뀐다
        more = re.search(r"외 도면 (\d+)장", str(message or ""))
        n_more = int(more.group(1)) if more else 0
        return (spec, frozenset(dwg), n_more) if spec is not None or dwg else None

    @classmethod
    def _evidence_paths(cls, ev_json) -> list:
        """이슈 근거 줄에 인용된 파일 경로 — '(레이어 EQ, 서버/P/도면/E-101.dxf)' 꼴의 괄호 끝."""
        try:
            lines = json.loads(ev_json or "[]")
        except (ValueError, TypeError):
            return []
        out: list = []
        for ln in lines if isinstance(lines, list) else []:
            for m in cls._EV_PATH.finditer(str(ln)):
                q = m.group(1).strip()
                if q not in out:
                    out.append(q)
        return out

    @staticmethod
    def _quiet_items(items_json) -> bool:
        """항목이 전부 '참고'(CHECK_SKIPPED)이고 조용한 말(재저장·일자만·이동·복사본)뿐인가.
        상세가 없는 변경은 조용하다고 단정하지 않는다."""
        try:
            items = json.loads(items_json or "[]")
        except (ValueError, TypeError):
            return False
        if not items:
            return False
        from watcher.brief import _QUIET_WORDS
        from watcher.diff import CONTENT_KINDS, TITLE_ZONE, is_title_date_text
        if any(it.get("kind") in CONTENT_KINDS
               and not (it.get("kind") == "PAGE_VISUAL_CHANGED" and TITLE_ZONE in str(it.get("where") or ""))
               and not is_title_date_text(it)          # 'DATE: …' 글줄의 날짜만 (검토42 B P01)
               for it in items):
            return False                       # 글자·표·그림이 바뀌었다 — 진짜 변경 (표제란 틀 안 그림은 아님, 검토41 S3)
        return any(it.get("kind") == "CHECK_SKIPPED" and any(w in str(it.get("new") or "") for w in _QUIET_WORDS)
                   for it in items)

    def rev_bumped_recently(self, path: str, hours: int = 36):
        """이 파일에 최근(기본 36시간) 'Rev 올림'이 기록돼 있으면 RevBump(검사 시각·변경 id·이전·새 Rev),
        없으면 None. 참/거짓으로도 쓴다. 값까지 돌려주는 것은 'Rev 미갱신을 내지 않기로 했다'는 판정의
        근거(무엇이 무엇으로 올랐나)가 메일 어디에도 없었기 때문이다 (검토34 A 1, 원칙 4)."""
        from datetime import datetime as _dt, timedelta as _td, timezone as _tz
        _now = _dt.now(_tz.utc)
        # 월요일에는 주말 이틀을 더한다 — 금요일에 Rev를 올리고 월요일에 이어 편집한 것이 64시간이라 'Rev 미갱신'이 됐다
        # (검토50 D 낮음 4). 유예는 개정마다 한 번뿐(_grace_used)이라 넓혀도 경고가 묻히지 않는다
        if _dt.now().weekday() == 0:
            hours += 48
        since = (_now - _td(hours=hours)).isoformat()
        until = (_now + _td(hours=1)).isoformat()      # 미래 기록은 근거가 아니다 (검토34 C M7)
        for js, at, cid in self.conn.execute(
                "SELECT d.items_json, c.detected_at, c.id FROM changes c JOIN change_details d ON d.change_id = c.id "
                "WHERE c.path = ? AND c.detected_at >= ? AND c.detected_at <= ? ORDER BY c.id DESC LIMIT 6",
                (path, since, until)):
            try:
                import json as _json
                from watcher.consistency import is_page_rev_bump
                for it in _json.loads(js or "[]"):
                    # 둘째 표제란(REV#2)의 올림도 — 시트2를 개정한 뒤의 후속 편집이 곧장 경고됐다 (검토37 A 중간 5)
                    from watcher.diff import NEW_TB, _blank_rev
                    _k = str(it.get("key") or "")
                    if it.get("kind") == "FIELD_CHANGED" and _k.split("#", 1)[0] == "REV" \
                            and not _blank_rev(it.get("new")) and it.get("label") != NEW_TB \
                            and not ("#" in _k and it.get("old") is None):   # 시트 신설 (검토38 R1 중간 4·R5 중간 5)
                        bump = RevBump(at, cid, str(it.get("old") or ""), str(it.get("new") or ""))
                    # 세트 PDF의 뒤 쪽 표제란 REV 줄(TEXT_CHANGED)도 Rev 올림 (검토30 B 5-C) — 본문의
                    # 'REV 2' 구름 글자는 아니다 (검토31 B6)
                    elif is_page_rev_bump(it.get("kind"), it.get("old"), it.get("new"), it.get("where"),
                                          "pdf" if str(path).lower().endswith(".pdf") else "other"):
                        bump = RevBump(at, cid, str(it.get("old") or ""), str(it.get("new") or ""))
                    else:
                        continue
                    return None if self._grace_used(path, cid) else bump
            except (ValueError, TypeError, AttributeError):
                continue
        return None

    def _grace_used(self, path: str, bump_id: int) -> bool:
        """Rev 올림 뒤의 유예를 이미 한 번 썼나 — 올림과 지금 판정 중인 변경(가장 최근) **사이에** 내용이
        바뀐 변경이 하나라도 있으면 썼다. '다음에 또 바뀔 때 Rev가 그대로면 경고'라고 해 놓고 36시간 안의
        세 번째 편집도 다시 봐줬다 (검토36 B 중간 2). 재저장·이동 같은 조용한 변경은 세지 않는다."""
        rows = self.conn.execute(
            "SELECT c.id, d.items_json FROM changes c LEFT JOIN change_details d ON d.change_id = c.id "
            "WHERE c.path = ? AND c.id > ? ORDER BY c.id", (path, bump_id)).fetchall()
        between = rows[:-1]                     # 마지막은 지금 판정 중인 변경
        return any(js is not None and not self._quiet_items(js) for _id, js in between)

    def change_summaries(self, ids) -> dict[int, tuple[int, str]]:
        """변경 id → (무게, '무엇이 어떻게' 한 줄). 무게: 사양·표 행 0 < Rev 1 < 글자·그림 2 <
        날짜·크기 3 < 참고만 4 — 화면 정렬과 첫 줄이 같은 근거를 쓴다 (파일럿 모의 2차 조건 2)."""
        import json as _json
        ids = [int(i) for i in ids if i is not None][:200]
        if not ids:
            return {}
        out: dict[int, tuple[int, str]] = {}
        q = ",".join("?" * len(ids))
        for cid, js in self.conn.execute(
                f"SELECT change_id, items_json FROM change_details WHERE change_id IN ({q})", ids):
            try:
                items = _json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            w, head = _headline_of(items, with_weight=True)
            out[int(cid)] = (w, head)
        return out

    def change_headlines(self, ids) -> dict[int, str]:
        """변경 id → '무엇이 어떻게' 한 줄 (M-201 1.5kW→5.5kW / 수량 2→4 / Rev A→B).
        화면 '오늘 확인할 것'이 파일명만 보여 줘 눌러 봐야 알았다 (파일럿 모의 ⑦)."""
        return {k: h for k, (_w, h) in self.change_summaries(ids).items() if h}

    def ack_of(self, change_id: int) -> str | None:
        """그 변경의 최근 확인자 (없으면 None)."""
        row = self.conn.execute(
            "SELECT by FROM acks WHERE change_id = ? ORDER BY id DESC LIMIT 1",
            (change_id,)).fetchone()
        return row[0] if row else None

    def file_facts(self, path: str) -> list[dict]:
        """그 경로의 최근 두 판 기록 — (검사 시각, 지문, 크기, 수정 시각).

        내용 비교를 못 한 변경에도 사람이 판단할 근거는 있어야 한다(원칙 4). 전에는
        비교 실패 화면에 엔진 오류 한 줄뿐이고 지문·크기·수정 시각이 어디에도
        없었다 (2026-09-09 웹 검토 중간 8)."""
        rows = self.conn.execute(
            "SELECT s.run_at, f.sha256, f.size, f.mtime FROM files f "
            "JOIN snapshots s ON s.id = f.snapshot_id WHERE f.path = ? "
            "ORDER BY f.snapshot_id DESC LIMIT 2", (path,)).fetchall()
        return [{"run_at": r[0], "sha256": r[1], "size": r[2], "mtime": r[3]}
                for r in rows]

    def last_review(self, project: str | None = None) -> dict | None:
        """사람이 마지막으로 남긴 확인(변경 [확인함]) 또는 처리(검토 필요 [처리함]) — {at, by, what}.
        '최근 검토한 시간'을 화면에 보이기 위해 (2026-09-15 사용자 요청). project를 주면 그 프로젝트만."""
        if project:
            a = self.conn.execute(
                'SELECT a.at, a."by" FROM acks a JOIN changes c ON c.id = a.change_id '
                "WHERE IFNULL(c.project,'미분류') = ? ORDER BY a.at DESC LIMIT 1", (project,)).fetchone()
            i = self.conn.execute(
                "SELECT resolved_at, resolved_by FROM issues WHERE resolved_at IS NOT NULL "
                "AND IFNULL(project,'미분류') = ? AND resolved_by NOT LIKE '자동 해소%' "
                "ORDER BY resolved_at DESC LIMIT 1", (project,)).fetchone()
        else:
            a = self.conn.execute('SELECT at, "by" FROM acks ORDER BY at DESC LIMIT 1').fetchone()
            i = self.conn.execute(
                "SELECT resolved_at, resolved_by FROM issues WHERE resolved_at IS NOT NULL "
                "AND resolved_by NOT LIKE '자동 해소%' ORDER BY resolved_at DESC LIMIT 1").fetchone()
        cands = []
        if a and a[0]:
            cands.append({"at": a[0], "by": a[1] or "", "what": "변경 확인"})
        if i and i[0]:
            cands.append({"at": i[0], "by": i[1] or "", "what": "검토 필요 처리"})
        return max(cands, key=lambda d: d["at"]) if cands else None

    def acks_of(self, change_id: int) -> list[dict]:
        """그 변경의 확인 기록 전부 (오래된 것부터).

        화면이 이걸 보려고 **전체 이력을 메모리에 올렸다** — 변경 30만 건에서 한 줄에
        1.6초·200MB였다 (2026-09-09 저장 검토 중간 5)."""
        rows = self.conn.execute(
            'SELECT "by", note, at FROM acks WHERE change_id = ? ORDER BY id',
            (change_id,)).fetchall()
        return [{"ack_by": r[0], "ack_note": r[1], "ack_at": r[2]} for r in rows]

    def snapshot_local_time(self, snapshot_id: int) -> str | None:
        """검사 시작 시각을 이 PC 시간으로 'MM-DD HH:MM' — 브리핑의 '비교 기준' 표기용."""
        from datetime import datetime as _dt
        row = self.conn.execute("SELECT run_at FROM snapshots WHERE id = ?",
                                (snapshot_id,)).fetchone()
        if not row or not row[0]:
            return None
        iso = row[0]
        if not ("+" in iso[10:] or iso.endswith("Z")):
            iso += "+00:00"
        try:
            return _dt.fromisoformat(iso).astimezone().strftime("%m-%d %H:%M")
        except ValueError:
            return None

    def prev_snapshot_id(self, snapshot_id: int) -> int | None:
        """이번 검사의 직전 스냅샷 id — 무엇과 비교한 것인지 밝히려고."""
        row = self.conn.execute(
            "SELECT id FROM snapshots WHERE id < ? ORDER BY id DESC LIMIT 1",
            (snapshot_id,)).fetchone()
        return row[0] if row else None

    def snapshot_local_date(self, snapshot_id: int) -> str | None:
        """검사 시작 시각의 이 PC 지역 날짜 (ISO) — 자정을 걸친 검사의 '그 날'."""
        from datetime import datetime as _dt
        row = self.conn.execute("SELECT run_at FROM snapshots WHERE id = ?",
                                (snapshot_id,)).fetchone()
        if not row or not row[0]:
            return None
        iso = row[0]
        if not ("+" in iso[10:] or iso.endswith("Z")):
            iso += "+00:00"
        try:
            return _dt.fromisoformat(iso).astimezone().date().isoformat()
        except ValueError:
            return None

    def changes_on_day(self, day_iso: str, exclude_snapshots=()) -> list[Change]:
        """그 날(이 PC 지역 날짜)에 잡힌 변경 — 같은 날 두 번째 검사가 아침 브리핑과
        합쳐 한 통으로 갱신하기 위해 (2026-09-05 재검토: 초안 8통이 나열됨)."""
        from datetime import datetime as _dt, timedelta as _td
        # 지역 날짜 ±1일 범위만 SQL로 좁힌 뒤 정확한 지역 날짜로 거른다 (전 행 훑기 방지)
        lo = (_dt.fromisoformat(day_iso) - _td(days=1)).strftime("%Y-%m-%d")
        hi = (_dt.fromisoformat(day_iso) + _td(days=2)).strftime("%Y-%m-%d")
        skip = set(exclude_snapshots)
        out = []
        for row in self.conn.execute(
                "SELECT id, kind, path, old_sha256, new_sha256, project, snapshot_id, detected_at"
                " FROM changes WHERE detected_at >= ? AND detected_at < ? ORDER BY id", (lo, hi)):
            if row[6] in skip:                     # 이번 검사·기준선 검사분은 제외
                continue
            iso = row[7] or ""
            if not ("+" in iso[10:] or iso.endswith("Z")):
                iso += "+00:00"
            try:
                if _dt.fromisoformat(iso).astimezone().date().isoformat() != day_iso:
                    continue
            except ValueError:
                continue
            out.append(Change(row[1], row[2], row[3], row[4], id=row[0], project=row[5]))
        return out

    def first_snapshot_id(self) -> int | None:
        """기준선(첫 검사) 스냅샷 id — 그때의 '추가' 대량 건은 실제 변경이 아니다."""
        row = self.conn.execute("SELECT MIN(id) FROM snapshots").fetchone()
        return row[0]

    def next_unacked(self, after_id: int, same_run: bool = True) -> int | None:
        """확인되지 않은 다음 변경의 id — 상세 화면의 [확인하고 다음]이 쓴다 (2026-09-09).

        같은 검사분 안에서 id가 큰 쪽부터 찾고, 없으면 앞쪽으로 한 바퀴 돈다.
        한 건 확인할 때마다 목록으로 돌아갔다 다시 들어가던 것을 없애기 위해서다."""
        snap = None
        if same_run:
            row = self.conn.execute("SELECT snapshot_id FROM changes WHERE id = ?",
                                    (after_id,)).fetchone()
            if row is None:
                return None          # 없는 id — 검사분을 못 좁히므로 아무 데로나 보내지 않는다
            snap = row[0]
        where = "a.id IS NULL AND c.id <> ?"
        params: list = [after_id]
        first = self.first_snapshot_id()
        if first is not None:
            # 기준선의 '추가'는 화면이 '첫 등록'으로 보여 주고 확인을 요구하지 않는다 —
            # 순회가 거기로 데려가면 수백~수천 건을 돌게 된다 (2026-09-09 검토18 F1)
            where += " AND NOT (c.snapshot_id = ? AND c.kind = 'added')"
            params.append(first)
        if snap is not None:
            where += " AND c.snapshot_id = ?"
            params.append(snap)
        sql = ("SELECT c.id FROM changes c LEFT JOIN acks a ON a.change_id = c.id "
               f"WHERE {where} AND c.id > ? ORDER BY c.id LIMIT 1")
        row = self.conn.execute(sql, (*params, after_id)).fetchone()
        if row:
            return int(row[0])
        sql2 = ("SELECT c.id FROM changes c LEFT JOIN acks a ON a.change_id = c.id "
                f"WHERE {where} ORDER BY c.id LIMIT 1")          # 한 바퀴 돌아 앞쪽
        row = self.conn.execute(sql2, tuple(params)).fetchone()
        return int(row[0]) if row else None

    def hist_gen(self) -> int:
        """이력 세대 — 변경·확인·기준선 표시가 바뀔 때마다 오른다 (트리거). 화면 캐시의 열쇠."""
        row = self.conn.execute("SELECT v FROM hist_gen WHERE k = 1").fetchone()
        return int(row[0]) if row else 0

    def history(self, project: str | None = None) -> list[dict]:
        """변경 이력 + 확인 기록 (프로젝트 필터 가능)."""
        # f.mtime = 그 검사 때 파일의 저장(수정) 시각 — '일시'가 검사 시각뿐이라 문서를 언제 고쳤는지
        # 화면에 없었다 (2026-09-17 사용자 요청). 삭제 행은 그 스냅샷에 파일이 없어 NULL
        sql = ("SELECT c.id, c.detected_at, c.kind, c.path, c.project, a.by, a.note, a.at, "
               "c.snapshot_id, c.mtime "
               "FROM changes c LEFT JOIN acks a ON a.change_id = c.id ")
        params: tuple = ()
        if project:
            sql += "WHERE c.project = ? "
            params = (project,)
        sql += "ORDER BY c.id, a.id"
        keys = ("change_id", "detected_at", "kind", "path", "project",
                "ack_by", "ack_note", "ack_at", "snapshot_id", "mtime")
        return [dict(zip(keys, row)) for row in self.conn.execute(sql, params)]
