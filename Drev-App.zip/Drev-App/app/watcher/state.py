# -*- coding: utf-8 -*-
"""SQLite 상태 저장소: 파일 스냅샷, 변경 이력, (Stage 5) 확인 기록.

쓰기는 state.db 한 파일에만 한다. 감시 대상 산출물에는 절대 쓰지 않는다.
"""

from __future__ import annotations

import hmac
import os
import time
import json
import re
import secrets
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from watcher.scan import FileRecord

_SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    run_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    path        TEXT NOT NULL,
    sha256      TEXT NOT NULL,
    size        INTEGER NOT NULL,
    mtime       REAL NOT NULL,
    PRIMARY KEY (snapshot_id, path)
);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS extracts (
    sha256       TEXT PRIMARY KEY,
    doc_json     TEXT NOT NULL,
    extracted_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS changes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    kind        TEXT NOT NULL CHECK (kind IN ('added', 'modified', 'removed')),
    path        TEXT NOT NULL,
    old_sha256  TEXT,
    new_sha256  TEXT,
    detected_at TEXT NOT NULL,
    project     TEXT
);
CREATE TABLE IF NOT EXISTS issues (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    code        TEXT NOT NULL,
    path        TEXT NOT NULL,
    project     TEXT,
    message     TEXT NOT NULL,
    evidence    TEXT NOT NULL,
    detected_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS change_details (
    change_id     INTEGER PRIMARY KEY REFERENCES changes(id),
    items_json    TEXT NOT NULL,
    captures_json TEXT
);
CREATE TABLE IF NOT EXISTS project_merges (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    at      TEXT NOT NULL,
    into_p  TEXT NOT NULL,           -- 남길 대표 이름
    sources TEXT NOT NULL            -- 합쳐 넣은 이름들 (줄바꿈 구분)
);
CREATE TABLE IF NOT EXISTS project_merge_rows (
    merge_id INTEGER NOT NULL REFERENCES project_merges(id),
    kind     TEXT NOT NULL,          -- 'change' | 'issue'
    row_id   INTEGER NOT NULL,
    old_p    TEXT NOT NULL           -- 바꾸기 전 이름 (되돌리기용)
);
CREATE TABLE IF NOT EXISTS doc_hints (
    path   TEXT PRIMARY KEY,         -- 경로 키
    sha256 TEXT NOT NULL,            -- 어느 판의 내용에서 읽었나
    kind   TEXT NOT NULL,            -- 내용에서 읽은 유형
    why    TEXT NOT NULL             -- 근거 (화면 표시용)
);
CREATE TABLE IF NOT EXISTS renders (
    sha256 TEXT NOT NULL,            -- 어느 판의 그림인가 (render.py, 2026-09-02)
    page   INTEGER NOT NULL,         -- 1부터
    width  REAL NOT NULL,            -- pt
    height REAL NOT NULL,
    meta   TEXT NOT NULL DEFAULT '{}',
    png    BLOB NOT NULL,            -- 그레이 PNG (감지 해상도)
    PRIMARY KEY (sha256, page)
);
CREATE TABLE IF NOT EXISTS manual_pairs (
    child_key TEXT PRIMARY KEY,   -- 대상 파일 (경로 키)
    prev_key  TEXT NOT NULL,      -- 사람이 지정한 이전 판
    by        TEXT,
    at        TEXT
);
CREATE TABLE IF NOT EXISTS acks (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    change_id INTEGER NOT NULL REFERENCES changes(id),
    by        TEXT NOT NULL,
    note      TEXT,
    at        TEXT NOT NULL
);
"""

# 색인이 하나도 없어서 화면 질의가 전부 전체 훑기였다 — 변경 30만 건에서 대시보드
# 한 장이 7.3초, history()가 1.57초였다 (2026-09-09 저장 검토 중간 5 실측).
# 마이그레이션으로 **나중에 생긴 열**(issues.resolved_at, changes.project)도 쓰므로
# _SCHEMA가 아니라 마이그레이션 뒤에 만든다. IF NOT EXISTS라 기존 설치본도 따라온다.
_INDEXES = (
    "CREATE INDEX IF NOT EXISTS ix_acks_change  ON acks(change_id)",
    "CREATE INDEX IF NOT EXISTS ix_chg_path     ON changes(path)",
    "CREATE INDEX IF NOT EXISTS ix_chg_project  ON changes(project)",
    "CREATE INDEX IF NOT EXISTS ix_chg_snapshot ON changes(snapshot_id)",
    "CREATE INDEX IF NOT EXISTS ix_chg_detected ON changes(detected_at)",
    "CREATE INDEX IF NOT EXISTS ix_iss_path     ON issues(path, code)",
    "CREATE INDEX IF NOT EXISTS ix_iss_resolved ON issues(resolved_at)",
    "CREATE INDEX IF NOT EXISTS ix_files_path   ON files(path)",
)


# 변경 종류 → 한글 라벨 (콘솔·브리핑·확인 페이지 공용 — 한 곳에서만 관리)
KIND_LABEL = {"added": "추가", "modified": "수정", "removed": "삭제"}


@dataclass(frozen=True)
class Change:
    """파일 수준 변경 1건. old/new sha256이 '사실'의 근거다 (PRINCIPLE 4·5)."""
    kind: str  # 'added' | 'modified' | 'removed'
    path: str
    old_sha256: str | None
    new_sha256: str | None
    id: int | None = None       # DB에 기록된 뒤 부여 (확인 링크의 대상)
    project: str | None = None  # 귀속 후 set_change_project로 저장


def _proc_created(pid: int) -> int | None:
    """프로세스 생성 시각(FILETIME 정수). 없거나 모르면 None. pid는 재사용되므로
    잠금은 pid+생성 시각으로 식별한다 (2026-09-04 재검토 ②-3: 재부팅 뒤 다른 프로그램이
    같은 pid를 받으면 최대 6시간 검사가 거부되던 것)."""
    if pid <= 0 or sys.platform != "win32":
        return None
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid)              # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return None
        try:
            ft = (ctypes.c_ulonglong * 4)()
            if k32.GetProcessTimes(h, ctypes.byref(ft, 0), ctypes.byref(ft, 8),
                                   ctypes.byref(ft, 16), ctypes.byref(ft, 24)):
                return int(ft[0])
            return None
        finally:
            k32.CloseHandle(h)
    except Exception:
        return None


def _pid_alive(pid: int, created: int | None = None) -> bool:
    """그 pid의 프로세스가 살아 있고(생성 시각까지 같으면) 같은 프로세스인가.
    모르면 살아 있다고 본다(잠금을 지키는 쪽). Windows의 os.kill(pid, 0)은 프로세스를
    죽이므로 쓰지 않는다."""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, pid)          # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return k32.GetLastError() == 5               # 접근 거부 = 있긴 있다
            try:
                code = ctypes.c_ulong()
                if k32.GetExitCodeProcess(h, ctypes.byref(code)) and code.value != 259:
                    return False                             # 종료됨(핸들만 남음)
            finally:
                k32.CloseHandle(h)
        except Exception:
            return True
        if created is not None:
            now_created = _proc_created(pid)
            if now_created is not None and now_created != created:
                return False                                 # 같은 pid를 받은 다른 프로그램
        return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return True


def _headline_of(items: list, with_weight: bool = False):
    """상세 항목 목록에서 가장 무거운 변경 한 줄. 사양·표 행 > Rev > 글자·그림 > 날짜·크기 > 참고.
    with_weight면 (무게, 한 줄)을 돌려준다."""
    def _s(v) -> str:
        return " ".join(str(v or "").split())[:40]
    best, best_w = "", 99
    n_rest = 0
    for it in items:
        k, key = it.get("kind", ""), _s(it.get("key"))
        o, n = _s(it.get("old")), _s(it.get("new"))
        if k.startswith("ROW_"):
            # 키는 '행키.열'(X-11.수량) — 품명 라벨만 쓰면 "RELAY · RELAY 24VDC: 2 → 4"처럼
            # 무엇의 수량인지 안 보였다 (파일럿 모의 3차 ③)
            rk, sep, col = key.rpartition(".")
            head = f"{rk} {col}".strip() if sep else key
            lab = _s(it.get("label"))
            w, txt = 0, (f"{head}: {o} → {n}" + (f" ({lab})" if lab and lab != head else "")
                         if k == "ROW_CHANGED" and o and n
                         else f"{key} 행 {'추가' if k.endswith('ADDED') else '삭제' if k.endswith('REMOVED') else '변경'}"
                              + (f" ({lab})" if lab else ""))
        elif k == "TEXT_CHANGED":
            w, txt = (0 if any(ch.isdigit() for ch in o + n) else 2), f"{o} → {n}"
        elif k == "FIELD_CHANGED" and key == "REV":
            w, txt = 1, f"Rev {o} → {n}"
        elif k == "FIELD_CHANGED":
            w, txt = (3 if key in ("DATE", "파일 크기", "저장 시각") else 2), f"{key} {o} → {n}"
        elif k in ("TEXT_ADDED", "TEXT_REMOVED"):
            w, txt = 2, f"글자 {'추가' if k.endswith('ADDED') else '삭제'}: {n or o}"
        elif k == "PAGE_VISUAL_CHANGED":
            w, txt = 2, f"그림 변경 ({key})"
        elif k == "NEW_REVISION_OF":
            w, txt = 2, f"이전 판 {o} → {n}"
        elif k == "CHECK_SKIPPED" and key == "참고":
            w, txt = 4, n
        else:
            continue
        if w < best_w:
            best, best_w = txt, w
        n_rest += 1
    if best and n_rest > 1:
        best += f" 외 {n_rest - 1}건"
    if with_weight:
        return (best_w if best else 5, best)
    return best


class CorruptDatabase(RuntimeError):
    """state.db가 깨져 열 수 없다 — 디스크 오류·백신 격리·복사 중 끊김.

    전에는 날 sqlite3 traceback으로 예약 검사가 죽고 화면은 응답 없이 끊겨, 되살리기
    절차(도움말 '백업 · 다른 PC로 이전 · 되살리기')가 있는데도 아무도 그리로 가지
    못했다 (검토19 운영 ①). 한국어 한 줄과 절차 위치를 함께 실어 올린다."""

    def __init__(self, db_path, why: str):
        self.db_path = str(db_path)
        self.why = why
        super().__init__(
            f"이력 파일이 깨져 열 수 없습니다: {db_path} ({why}). 되살리는 순서는 도움말의 "
            f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다 — 요약: Drev를 끝내고, "
            f"state.db-wal·state.db-shm이 있으면 이름을 바꿔 치우고, backups 폴더의 "
            f"state_backup_N.db를 복사해 state.db로 이름을 바꿉니다.")


class State:
    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        # 웹서버(다중 스레드)와 검사 스레드가 같은 DB를 쓴다 — WAL이면 읽기가
        # 긴 쓰기(캡처 수 MB 저장)에 막히지 않고, busy_timeout으로 잠금 충돌을
        # 재시도한다 (2026-08-26 리뷰: 'database is locked' 예방)
        self.conn = sqlite3.connect(self.db_path, timeout=15)
        # 여는 도중 어디서든 터지면 **연결을 닫고** 올린다. 열린 채로 두면 윈도우가
        # 그 파일을 잡아, 되살리려고 이름을 바꾸는 것조차 WinError 32로 막힌다
        # (2026-09-09 저장 검토 낮음 9b — 깨진 DB에서 실측)
        try:
            mode = self.conn.execute("PRAGMA journal_mode=WAL").fetchone()[0]
            if str(mode).lower() != "wal":  # 전환 실패는 예외가 아니라 반환값으로만 알린다
                print(f"경고: state.db WAL 전환 실패(현재 {mode}) — 동시 접근 시 "
                      f"잠금 오류 가능", file=sys.stderr)
            if str(self.db_path).startswith("\\\\"):
                print("경고: state.db가 네트워크 경로에 있습니다 — SQLite WAL은 "
                      "네트워크 드라이브에서 신뢰할 수 없습니다(손상 위험). "
                      "이 PC의 로컬 경로를 권장합니다.", file=sys.stderr)
            self.conn.execute("PRAGMA busy_timeout=15000")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.executescript(_SCHEMA)
        except sqlite3.DatabaseError as e:
            try:
                self.conn.close()
            except Exception:
                pass
            raise CorruptDatabase(self.db_path, str(e)) from e
        except BaseException:
            try:
                self.conn.close()
            except Exception:
                pass
            raise
        # Stage 4 이전에 만든 DB 마이그레이션: changes.project 열 추가
        cols = [r[1] for r in self.conn.execute("PRAGMA table_info(changes)")]
        if "project" not in cols:
            self.conn.execute("ALTER TABLE changes ADD COLUMN project TEXT")
        # v0.14 마이그레이션: 이슈 해소(닫기) 기록 — 없으면 빨간 숫자가 영원히 쌓인다
        icols = [r[1] for r in self.conn.execute("PRAGMA table_info(issues)")]
        if "resolved_at" not in icols:
            self.conn.execute("ALTER TABLE issues ADD COLUMN resolved_at TEXT")
            self.conn.execute("ALTER TABLE issues ADD COLUMN resolved_by TEXT")
        # v0.19 마이그레이션: 상세 항목 오탐 숨김(복원 가능) 기록
        dcols = [r[1] for r in self.conn.execute("PRAGMA table_info(change_details)")]
        if "dismissed_json" not in dcols:
            self.conn.execute(
                "ALTER TABLE change_details ADD COLUMN dismissed_json TEXT")
        # v0.21 마이그레이션: 사람이 직접 추가한 '놓친 변경' 기록 (미탐 보완)
        if "user_notes_json" not in dcols:
            self.conn.execute(
                "ALTER TABLE change_details ADD COLUMN user_notes_json TEXT")
        for stmt in _INDEXES:
            try:
                self.conn.execute(stmt)
            except Exception:      # 색인 하나가 안 만들어져도 프로그램은 돌아야 한다
                pass
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "State":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def save_extract(self, sha256: str, doc_dict: dict) -> None:
        """추출 결과를 내용 해시 기준으로 저장. 나중에 구버전과의 내용 비교에 쓴다."""
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            "INSERT OR REPLACE INTO extracts (sha256, doc_json, extracted_at) VALUES (?, ?, ?)",
            (sha256, json.dumps(doc_dict, ensure_ascii=False), now))
        self.conn.commit()

    def load_extract(self, sha256: str | None) -> dict | None:
        if not sha256:
            return None
        row = self.conn.execute(
            "SELECT doc_json FROM extracts WHERE sha256 = ?", (sha256,)).fetchone()
        return json.loads(row[0]) if row else None

    def latest_snapshot(self) -> dict[str, str]:
        """가장 최근 스냅샷: {path: sha256}. 없으면 빈 dict."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return {}
        return dict(self.conn.execute(
            "SELECT path, sha256 FROM files WHERE snapshot_id = ?", (row[0],)))

    def side_notes(self, limit: int = 500) -> dict:
        """복사본·빈 파일 같은 '참고' 메모가 달린 변경 → 문구 (목록 표시용).

        상세를 열지 않고도 훑으며 거를 수 있게 (2026-09-01 처음 쓰는 사람 점검)."""
        import json
        out = {}
        rows = self.conn.execute(
            "SELECT change_id, items_json FROM change_details "
            "WHERE items_json LIKE '%CHECK_SKIPPED%' "
            "ORDER BY change_id DESC LIMIT ?", (limit,)).fetchall()
        for cid, js in rows:
            try:
                for it in json.loads(js):
                    if it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
                        out[cid] = it.get("new") or ""
                        break
            except (ValueError, TypeError):
                continue
        return out

    def project_files(self, project: str, limit: int = 0) -> list[str]:
        """그 프로젝트로 잡힌 파일 경로 (중복 제거)."""
        rows = self.conn.execute(
            "SELECT DISTINCT path FROM changes WHERE IFNULL(project,'미분류') = ?"
            " ORDER BY path", (project,)).fetchall()
        paths = [r[0] for r in rows]
        return paths[:limit] if limit else paths

    def merge_projects(self, into: str, sources, path_prefix: str | None = None) -> dict:
        """여러 이름으로 갈린 같은 프로젝트를 대표 이름 하나로 모은다.

        바꾸기 전 값을 project_merge_rows에 남겨 되돌릴 수 있게 한다 — 잘못
        합쳤을 때 원래대로가 없으면 사람이 손댈 방법이 없다 (PRINCIPLE 5)."""
        srcs = [x for x in dict.fromkeys(sources) if x and x != into]
        if not srcs:
            return {"merge_id": 0, "changes": 0, "issues": 0}
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute(
            "INSERT INTO project_merges (at, into_p, sources) VALUES (?, ?, ?)",
            (now, into, "\n".join(srcs)))
        mid = cur.lastrowid
        marks = ",".join("?" * len(srcs))
        # 감시 폴더 하나를 '프로젝트 하나로' 묶을 때는 그 폴더 아래만 — 경로 조건
        # 없이 이름만으로 바꾸면 다른 폴더의 같은 이름(미분류 포함) 이력까지 편입된다
        # (2026-09-02 검토에서 확인). LIKE 대신 접두어 비교: 라벨의 _·%가 와일드카드가
        # 되지 않게
        scope, extra = "", ()
        if path_prefix:
            scope, extra = " AND substr(path, 1, ?) = ?", (len(path_prefix), path_prefix)
        counts = {}
        for kind, table in (("change", "changes"), ("issue", "issues")):
            rows = self.conn.execute(
                f"SELECT id, IFNULL(project,'미분류') FROM {table} "
                f"WHERE IFNULL(project,'미분류') IN ({marks}){scope}",
                tuple(srcs) + extra).fetchall()
            self.conn.executemany(
                "INSERT INTO project_merge_rows (merge_id, kind, row_id, old_p) "
                "VALUES (?, ?, ?, ?)",
                [(mid, kind, rid, old) for rid, old in rows])
            self.conn.executemany(
                f"UPDATE {table} SET project = ? WHERE id = ?",
                [(into, rid) for rid, _ in rows])
            counts[kind] = len(rows)
        self.conn.commit()
        return {"merge_id": mid, "changes": counts["change"],
                "issues": counts["issue"]}

    def undo_merge(self, merge_id: int) -> int:
        """합치기 되돌리기 — 그때 바꾼 행만 원래 이름으로 돌려놓는다."""
        rows = self.conn.execute(
            "SELECT kind, row_id, old_p FROM project_merge_rows "
            "WHERE merge_id = ?", (merge_id,)).fetchall()
        for kind, rid, old in rows:
            table = "changes" if kind == "change" else "issues"
            self.conn.execute(f"UPDATE {table} SET project = ? WHERE id = ?",
                              (old, rid))
        self.conn.execute("DELETE FROM project_merge_rows WHERE merge_id = ?",
                          (merge_id,))
        self.conn.execute("DELETE FROM project_merges WHERE id = ?", (merge_id,))
        self.conn.commit()
        return len(rows)

    def merges(self, limit: int = 20) -> list[dict]:
        """최근 합치기 이력 (되돌리기 버튼용)."""
        out = []
        for mid, at, into, srcs in self.conn.execute(
                "SELECT id, at, into_p, sources FROM project_merges "
                "ORDER BY id DESC LIMIT ?", (limit,)):
            n = self.conn.execute(
                "SELECT COUNT(*) FROM project_merge_rows WHERE merge_id = ?",
                (mid,)).fetchone()[0]
            out.append({"merge_id": mid, "at": at, "into": into,
                        "sources": srcs.split("\n"), "rows": n})
        return out

    def prefix_stats(self, label: str) -> dict:
        """감시 폴더 라벨 아래의 기록 개수 — 지우기 전에 사람에게 보여준다."""
        pre = label + "/"          # LIKE는 _·%를 와일드카드로 본다 — 접두어 비교
        files = self.conn.execute(
            "SELECT COUNT(DISTINCT path) FROM files WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        # 변경 id를 전부 파이썬으로 끌어와 IN (?,…)로 묶으면 32,766개에서
        # "too many SQL variables"로 이 화면이 통째로 죽는다 — 하루 30건이면 3년이다
        # (2026-09-09 저장 검토 차단 2). 전부 서브질의로 바꾼다
        n_changes = self.conn.execute(
            "SELECT COUNT(*) FROM changes WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        acks = self.conn.execute(
            "SELECT COUNT(*) FROM acks WHERE change_id IN "
            "(SELECT id FROM changes WHERE substr(path,1,?) = ?)",
            (len(pre), pre)).fetchone()[0]
        issues = self.conn.execute(
            "SELECT COUNT(*) FROM issues WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        return {"files": files, "changes": n_changes, "acks": acks, "issues": issues}

    def purge_prefix(self, label: str) -> dict:
        """감시 폴더 라벨 아래의 **기록**을 전부 지운다 — 파일 목록·변경·상세·확인·
        검토 필요. 감시 대상 파일은 건드리지 않는다 (PRINCIPLE 2). 되돌릴 수
        없으므로 호출 전에 사람이 확인한다 (2026-09-02)."""
        stats = self.prefix_stats(label)
        pre = label + "/"
        sub = "(SELECT id FROM changes WHERE substr(path,1,?) = ?)"
        arg = (len(pre), pre)
        self.conn.execute(f"DELETE FROM change_details WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM acks WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM project_merge_rows WHERE kind = 'change' "
                          f"AND row_id IN {sub}", arg)
        self.conn.execute("DELETE FROM changes WHERE substr(path,1,?) = ?", arg)
        self.conn.execute("DELETE FROM issues WHERE substr(path,1,?) = ?", (len(pre), pre))
        self.conn.execute("DELETE FROM files WHERE substr(path,1,?) = ?", (len(pre), pre))
        self.conn.execute("DELETE FROM doc_hints WHERE substr(path,1,?) = ?", (len(pre), pre))
        # 라벨의 '첫 검사' 기록도 지운다 — 다시 넣으면 그때가 첫 검사(기준선)다
        try:
            fs = json.loads(self.get_meta("root_first_seen") or "{}")
            kl = json.loads(self.get_meta("known_labels") or "[]")
            fs.pop(label, None)
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('root_first_seen', ?)",
                              (json.dumps(fs, ensure_ascii=False),))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('known_labels', ?)",
                              (json.dumps(sorted(set(kl) - {label}), ensure_ascii=False),))
        except (ValueError, TypeError):
            pass
        self.conn.commit()
        return stats

    def save_hint(self, path: str, sha256: str, hint) -> None:
        """내용 단서 저장 — 없으면(None) 지운다 (2026-09-02)."""
        if hint is None:
            self.conn.execute("DELETE FROM doc_hints WHERE path = ?", (path,))
            return
        self.conn.execute(
            "INSERT OR REPLACE INTO doc_hints (path, sha256, kind, why) "
            "VALUES (?, ?, ?, ?)", (path, sha256, hint[0], hint[1]))

    def backfill_hints(self, compute) -> int:
        """내용 단서가 없는 최신 스냅샷 파일에 대해, 캐시된 추출본으로 단서를 만든다.

        단서는 원래 검사 때 생기므로 업데이트 직후엔 비어 있다 — 다음 검사까지
        기다리지 않게 한 번 소급한다 (2026-09-02). compute(추출본 dict) → (유형, 근거)|None.
        돌려주는 값: 새로 만든 단서 수."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return 0
        # 스냅샷당 한 번만 — 단서 없는 파일은 doc_hints에 흔적이 없어 매 시작마다
        # 4만 추출본을 다시 파싱하고 있었다 (2026-09-02 검토). 검사가 돌면 검사가
        # 직접 단서를 만들므로 소급은 그 전 한 번이면 된다
        done = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'hints_backfill_snapshot'").fetchone()
        if done and str(done[0]) == str(row[0]):
            return 0
        have = {p for (p,) in self.conn.execute("SELECT path FROM doc_hints")}
        made = 0
        pending = [(p, s) for p, s in self.conn.execute(
            "SELECT path, sha256 FROM files WHERE snapshot_id = ?", (row[0],))
            if p not in have]
        for i, (path, sha) in enumerate(pending, 1):
            cached = self.load_extract(sha)
            if cached and cached.get("extract_failed") is None:
                hint = compute(cached)
                if hint:
                    self.save_hint(path, sha, hint)
                    made += 1
            if i % 500 == 0:
                self.conn.commit()        # 쓰기 잠금을 오래 쥐지 않는다
        self.conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES ('hints_backfill_snapshot', ?)",
            (str(row[0]),))
        self.conn.commit()
        return made

    def hints(self) -> dict:
        """{경로: (유형, 근거)} — 화면이 유형을 판별할 때 함께 본다."""
        return {p: (k, w) for p, k, w in
                self.conn.execute("SELECT path, kind, why FROM doc_hints")}

    def delete_project(self, project: str) -> dict:
        """프로젝트의 **기록**을 지운다 — 변경 이력·상세·확인·검토 필요.

        감시 대상 파일은 건드리지 않는다(원칙 2: 이 프로그램은 산출물 파일을
        수정·삭제하지 않는다). 잘못 묶인 프로젝트를 화면에서 치우기 위한 것
        (2026-09-01 요청). 되돌릴 수 없으므로 호출 전에 사람이 확인한다."""
        # id·path를 전부 끌어와 IN (?,…)로 묶으면 32,766건에서 죽는다 — '미분류'는
        # 귀속 실패가 모이는 곳이라 가장 먼저 넘는다 (2026-09-09 저장 검토 차단 2)
        sub = "(SELECT id FROM changes WHERE IFNULL(project,'미분류') = ?)"
        arg = (project,)
        n_changes = self.conn.execute(
            "SELECT COUNT(*) FROM changes WHERE IFNULL(project,'미분류') = ?",
            arg).fetchone()[0]
        if not n_changes:
            return {"changes": 0, "acks": 0, "issues": 0}
        acks = self.conn.execute(
            f"SELECT COUNT(*) FROM acks WHERE change_id IN {sub}", arg).fetchone()[0]
        issues = self.conn.execute(
            "SELECT COUNT(*) FROM issues WHERE IFNULL(project,'미분류') = ?",
            arg).fetchone()[0]
        self.conn.execute(f"DELETE FROM change_details WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM acks WHERE change_id IN {sub}", arg)
        self.conn.execute(f"DELETE FROM project_merge_rows WHERE kind = 'change' "
                          f"AND row_id IN {sub}", arg)
        self.conn.execute(
            "DELETE FROM issues WHERE IFNULL(project,'미분류') = ?", arg)
        self.conn.execute(
            "DELETE FROM doc_hints WHERE path IN "
            "(SELECT path FROM changes WHERE IFNULL(project,'미분류') = ?)", arg)
        self.conn.execute(
            "DELETE FROM changes WHERE IFNULL(project,'미분류') = ?", arg)
        self.conn.commit()
        return {"changes": n_changes, "acks": acks, "issues": issues}

    # ── 페이지 그림 기록 (render.py) — 같은 이름으로 덮어써진 도면의 '이전 판'
    # 그림. 파일은 사라져도 이 기록으로 전/후 그림 비교를 한다 (2026-09-02)

    def save_renders(self, sha256: str, pages) -> None:
        self.conn.execute("DELETE FROM renders WHERE sha256 = ?", (sha256,))
        self.conn.executemany(
            "INSERT INTO renders (sha256, page, width, height, meta, png) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [(sha256, i, float(pg.width_pt), float(pg.height_pt),
              json.dumps(pg.meta), pg.png) for i, pg in enumerate(pages, 1)])
        self.conn.commit()

    def has_renders(self, sha256: str | None) -> bool:
        if not sha256:
            return False
        return self.conn.execute(
            "SELECT 1 FROM renders WHERE sha256 = ? LIMIT 1", (sha256,)).fetchone() is not None

    def load_renders(self, sha256: str | None):
        """PageRender 목록. 기록이 없으면 None."""
        if not sha256:
            return None
        from watcher.render import PageRender
        rows = self.conn.execute(
            "SELECT width, height, meta, png FROM renders WHERE sha256 = ? ORDER BY page",
            (sha256,)).fetchall()
        if not rows:
            return None
        return [PageRender(w, h, bytes(png), json.loads(meta or "{}"))
                for w, h, meta, png in rows]

    def prune_renders(self, keep_days: int = 90) -> int:
        """최신 스냅샷에 없는 판의 그림을 지운다 (도면 1장 ≈ 100~300KB, 누적 방지).
        단, 변경에서 '이전 판'이었던 그림은 keep_days(=설정의 보존 기간) 동안 남긴다 —
        같은 이름으로 덮어쓴 도면의 '전/후 나란히 보기'용. 0이면 무기한 (2026-09-03:
        "몇 달 뒤 변경도 비교되나" — 현재 판 그림은 원래 기한이 없고, 이것은 지나간
        판을 나중에 다시 열어볼 때의 기한이다. 보존 기간 설정 하나로 통일)."""
        if keep_days and keep_days > 0:
            cutoff = (datetime.now(timezone.utc) - timedelta(days=keep_days)).isoformat()
            ref = "SELECT old_sha256 FROM changes WHERE detected_at >= ? AND old_sha256 IS NOT NULL"
            params: tuple = (cutoff,)
        else:
            ref = "SELECT old_sha256 FROM changes WHERE old_sha256 IS NOT NULL"
            params = ()
        cur = self.conn.execute(
            "DELETE FROM renders WHERE sha256 NOT IN ("
            " SELECT sha256 FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots))"
            f" AND sha256 NOT IN ({ref})", params)
        self.conn.commit()
        return cur.rowcount

    def _latest_rows(self) -> dict[str, tuple]:
        """최근 스냅샷의 전체 행: {path: (sha256, size, mtime)}."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return {}
        return {p: (s, sz, mt) for p, s, sz, mt in self.conn.execute(
            "SELECT path, sha256, size, mtime FROM files WHERE snapshot_id = ?", (row[0],))}

    def record_run(self, records: list[FileRecord],
                   carry_paths: tuple | list = (),
                   known_prefixes: list[str] | None = None,
                   scanned_prefixes: list[str] | None = None) -> tuple[int, list[Change]]:
        """이전 스냅샷과 비교해 변경을 계산하고, 새 스냅샷+변경을 저장한다.

        carry_paths: 이번 스캔에서 읽지 못한 경로들. 이전 스냅샷 값을 그대로 이월해
        '삭제'로 오인하지 않는다 (잠긴 파일이 removed로 잡히는 것 방지).
        known_prefixes: 다중 감시 폴더의 라벨 목록. 지정되면, 더 이상 감시하지 않는
        라벨 아래의 파일은 '삭제' 알림 없이 조용히 스냅샷에서 빠진다
        (감시 폴더를 목록에서 뺐을 뿐 파일이 지워진 게 아니므로).
        """
        if carry_paths:
            # 같은 경로가 두 번 실려 오면(제외 폴더가 동시에 '읽지 못한 폴더'이기도 한 경우처럼)
            # 스냅샷에 같은 행을 두 번 넣어 PRIMARY KEY를 어기고, 그 예외가 롤백 밖에서 터져
            # **그날 검사가 통째로 죽는다**(브리핑도 메일도 없이). 호출부가 아니라 여기서 막는다
            # (2026-09-09 감시·스캔 검토 차단 S1).
            prev = self._latest_rows()
            have = {r.path for r in records}
            seen: set = set()
            extra = []
            for p in carry_paths:
                if p in prev and p not in have and p not in seen:
                    seen.add(p)
                    extra.append(FileRecord(p, *prev[p]))
            records = records + extra
        old = self.latest_snapshot()
        new = {r.path: r for r in records}

        changes: list[Change] = []
        for path in sorted(new.keys() - old.keys()):
            changes.append(Change("added", path, None, new[path].sha256))
        for path in sorted(new.keys() & old.keys()):
            if new[path].sha256 != old[path]:
                changes.append(Change("modified", path, old[path], new[path].sha256))
        for path in sorted(old.keys() - new.keys()):
            if known_prefixes is not None and path.split("/")[0] not in known_prefixes:
                continue  # 감시 폴더 목록에서 빠진 라벨: 삭제 알림 없이 제외
            changes.append(Change("removed", path, old[path], None))

        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute("INSERT INTO snapshots (run_at) VALUES (?)", (now,))
        snapshot_id = cur.lastrowid
        self.conn.executemany(
            "INSERT INTO files (snapshot_id, path, sha256, size, mtime) VALUES (?, ?, ?, ?, ?)",
            [(snapshot_id, r.path, r.sha256, r.size, r.mtime) for r in records])
        with_ids = []
        for c in changes:
            cur = self.conn.execute(
                "INSERT INTO changes (snapshot_id, kind, path, old_sha256, new_sha256, detected_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (snapshot_id, c.kind, c.path, c.old_sha256, c.new_sha256, now))
            with_ids.append(Change(c.kind, c.path, c.old_sha256, c.new_sha256, cur.lastrowid))
        # '진행 중' 표식을 **같은 트랜잭션**에 넣는다. 전에는 호출부가 커밋 뒤에
        # mark_run_started를 따로 불러서, 그 틈(정전·강제 종료)에 죽으면 스냅샷은 남고
        # 표식은 없어 그날 변경이 영원히 브리핑에 안 실렸다 — 화면에만 보였다
        # (2026-09-09 저장 검토 낮음 9a)
        self.conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES ('run_in_progress', ?)",
            (str(snapshot_id),))
        if scanned_prefixes is not None:
            # 감시 폴더(라벨)별 '첫 실제 검사' 스냅샷을 명시적으로 적는다. 변경 기록의 MIN으로만
            # 추정하면 ①첫 검사 때 비어 있던 폴더에 일주일 뒤 들어온 파일이 전부 '등록'으로 접혀
            # 영영 알리지 않고 ②기록을 남긴 채 뺐다가 다시 넣은 폴더가 '변경 N건' 메일이 됐다
            # (검토20 A-4·A-6). 규칙: 직전까지 실제로 검사된 라벨 집합(known_labels)에 없던 라벨이
            # 이번에 검사되면 이번이 그 폴더의 첫 검사. 설정에서 빠진 라벨은 집합에서 지워 다시
            # 넣으면 또 첫 검사가 된다. 닿지 못한(carry) 폴더는 검사된 적이 없으니 포함하지 않는다
            try:
                first_seen = json.loads(self.get_meta("root_first_seen") or "{}")
                known_raw = self.get_meta("known_labels")
                prev_known = set(json.loads(known_raw)) if known_raw is not None else None
            except (ValueError, TypeError):
                first_seen, prev_known = {}, None
            if prev_known is None:
                # 구판 DB의 첫 실행: 직전 스냅샷에 있던 라벨은 이미 검사된 것 — 이번 검사의 진짜
                # '추가'가 등록으로 접히지 않게
                prev_known = {p.split("/", 1)[0] for p in old.keys() if "/" in p}
            for lb in scanned_prefixes:
                if lb not in prev_known:
                    first_seen[lb] = snapshot_id
            keep = set(known_prefixes) if known_prefixes is not None else set(scanned_prefixes)
            known_now = (prev_known | set(scanned_prefixes)) & keep
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('root_first_seen', ?)",
                              (json.dumps(first_seen, ensure_ascii=False),))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('known_labels', ?)",
                              (json.dumps(sorted(known_now), ensure_ascii=False),))
        self.conn.commit()
        return snapshot_id, with_ids

    def save_change_details(self, change_id: int, items: list[dict],
                            captures: dict | None = None) -> None:
        """변경 1건의 내용 비교 결과(diff 항목 + 위치 캡처)를 화면 조회용으로 저장."""
        self.conn.execute(
            "INSERT OR REPLACE INTO change_details (change_id, items_json, captures_json)"
            " VALUES (?, ?, ?)",
            (change_id, json.dumps(items, ensure_ascii=False),
             json.dumps(captures or {}, ensure_ascii=False)))
        self.conn.commit()

    def change_detail(self, change_id: int) -> dict | None:
        row = self.conn.execute(
            "SELECT items_json, captures_json, dismissed_json, user_notes_json "
            "FROM change_details WHERE change_id = ?", (change_id,)).fetchone()
        if row is None:
            return None
        return {"items": json.loads(row[0]), "captures": json.loads(row[1] or "{}"),
                "dismissed": json.loads(row[2] or "{}"),
                "user_notes": json.loads(row[3] or "[]")}

    def add_user_note(self, change_id: int, where: str, text: str, by: str) -> bool:
        """사람이 직접 추가하는 '놓친 변경' 기록 — 프로그램이 인식 못한 변경을
        사람이 보완한다 (오탐 숨김의 반대쪽, 원칙 5 양방향 완성 — 2026-08-27).
        상세가 없는 변경(기준선 등)에는 빈 상세를 만들어서라도 붙인다."""
        row = self.conn.execute(
            "SELECT user_notes_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            if self.get_change(change_id) is None:
                return False
            self.save_change_details(change_id, [], {})
            notes = []
        else:
            notes = json.loads(row[0] or "[]")
        notes.append({"where": where, "text": text, "by": by or "-",
                      "at": datetime.now(timezone.utc).isoformat()})
        self.conn.execute(
            "UPDATE change_details SET user_notes_json = ? WHERE change_id = ?",
            (json.dumps(notes, ensure_ascii=False), change_id))
        self.conn.commit()
        return True

    def delete_user_note(self, change_id: int, idx: int) -> None:
        row = self.conn.execute(
            "SELECT user_notes_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        notes = json.loads(row[0] or "[]")
        if 0 <= idx < len(notes):
            notes.pop(idx)
            self.conn.execute(
                "UPDATE change_details SET user_notes_json = ? WHERE change_id = ?",
                (json.dumps(notes, ensure_ascii=False), change_id))
            self.conn.commit()

    def list_user_notes(self) -> list[dict]:
        """전체 '놓친 변경' 기록 (최신순) — 어떤 파일·양식에서 프로그램이 자주
        놓치는지 보는 미탐 리포트용."""
        out = []
        for cid, path, proj, notes_json in self.conn.execute(
                "SELECT d.change_id, c.path, c.project, d.user_notes_json "
                "FROM change_details d JOIN changes c ON c.id = d.change_id "
                "WHERE d.user_notes_json IS NOT NULL"):
            for n in json.loads(notes_json or "[]"):
                out.append({**n, "change_id": cid, "path": path,
                            "project": proj or "미분류"})
        out.sort(key=lambda n: n.get("at", ""), reverse=True)
        return out

    # ------------------------------------------------------------ 수동 짝 지정
    # 자동 규칙(같은 폴더·이름)이 못 엮는 판을 사람이 직접 짝지음 — 이름 오타,
    # '이전판' 폴더 이동, 영어 꼬리 등 (2026-08-29). 원칙 5: 최종 판단은 사람.

    def set_manual_pair(self, child_key: str, prev_key: str, by: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO manual_pairs (child_key, prev_key, by, at) "
            "VALUES (?, ?, ?, ?)",
            (child_key, prev_key, by or "-",
             datetime.now(timezone.utc).isoformat()))
        self.conn.commit()

    def clear_manual_pair(self, child_key: str) -> None:
        self.conn.execute("DELETE FROM manual_pairs WHERE child_key = ?",
                          (child_key,))
        self.conn.commit()

    def manual_pair(self, child_key: str) -> dict | None:
        """{prev_key, by, at} — 지정이 없으면 None."""
        row = self.conn.execute(
            "SELECT prev_key, by, at FROM manual_pairs WHERE child_key = ?",
            (child_key,)).fetchone()
        return ({"prev_key": row[0], "by": row[1], "at": row[2]}
                if row else None)

    def dismiss_change_item(self, change_id: int, idx: int, by: str) -> None:
        """상세 항목 하나를 '오탐/무의미'로 숨김 — 완전 삭제가 아니라 누가·언제와
        함께 보관하고 복원 가능 (원칙 5: 내용은 초안, 최종 판단은 사람 — 2026-08-27).
        idx는 items_json 배열 인덱스 (저장 순서 불변)."""
        row = self.conn.execute(
            "SELECT dismissed_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        d = json.loads(row[0] or "{}")
        d[str(idx)] = {"by": by or "-",
                       "at": datetime.now(timezone.utc).isoformat()}
        self.conn.execute(
            "UPDATE change_details SET dismissed_json = ? WHERE change_id = ?",
            (json.dumps(d, ensure_ascii=False), change_id))
        self.conn.commit()

    def restore_change_item(self, change_id: int, idx: int) -> None:
        row = self.conn.execute(
            "SELECT dismissed_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        d = json.loads(row[0] or "{}")
        d.pop(str(idx), None)
        self.conn.execute(
            "UPDATE change_details SET dismissed_json = ? WHERE change_id = ?",
            (json.dumps(d, ensure_ascii=False), change_id))
        self.conn.commit()

    # ── 실행 표식: 스냅샷을 커밋한 뒤 보고 전에 프로세스가 죽으면(창 X·정전·업데이트)
    # 그날 변경이 영원히 브리핑에 안 실렸다 — 원칙 5 위반 (2026-09-04 검토 core H1).
    # 시작 때 표식을 남기고 정상 종료 때 지운다. 다음 실행이 표식을 보면 그 스냅샷을
    # 되돌려 같은 변경을 다시 감지한다
    def get_meta(self, key: str) -> str | None:
        row = self.conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_meta(self, key: str, value: str | None) -> None:
        if value is None:
            self.conn.execute("DELETE FROM meta WHERE key = ?", (key,))
        else:
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (key, value))
        self.conn.commit()

    def mark_run_started(self, snapshot_id: int) -> None:
        """record_run이 이미 같은 트랜잭션에서 표시한다 — 호출부 호환용으로 남긴다."""
        self.set_meta("run_in_progress", str(snapshot_id))

    def mark_run_finished(self) -> None:
        self.set_meta("run_in_progress", None)

    def unfinished_run(self) -> int | None:
        """보고를 마치지 못한 채 끝난 스냅샷 id (없으면 None)."""
        v = self.get_meta("run_in_progress")
        try:
            sid = int(v) if v else None
        except ValueError:
            return None
        if sid is None:
            return None
        row = self.conn.execute("SELECT 1 FROM snapshots WHERE id = ?", (sid,)).fetchone()
        return sid if row else None

    # ── 프로세스 간 잠금: 작업 스케줄러의 07시 검사와 화면의 [지금 검사]가 겹치면
    # 같은 변경이 두 번 기록되고 브리핑이 3통 나왔다 (2026-09-04 검토 core H4).
    # 파일 잠금 대신 DB의 meta 행을 쓴다 — 삭제 API 없이(원칙 2 가드) 원자적으로
    def acquire_run_lock(self, pid: int, stale_after: float = 6 * 3600) -> bool:
        """이 프로세스가 검사 잠금을 얻으면 True. 살아 있는 다른 검사가 잡고 있으면 False."""
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            row = self.conn.execute(
                "SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
            if row:
                parts = row[0].split(":")
                try:
                    other_pid, at = int(parts[0]), float(parts[1])
                    created = int(parts[2]) if len(parts) > 2 and parts[2] else None
                except (ValueError, IndexError):
                    other_pid, at, created = 0, 0.0, None
                age = time.time() - at
                if other_pid != pid and age < stale_after and _pid_alive(other_pid, created):
                    self.conn.rollback()
                    return False
            mine = _proc_created(pid)
            self.conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES ('run_lock', ?)",
                (f"{pid}:{time.time()}:{mine if mine is not None else ''}",))
            self.conn.commit()
            return True
        except Exception:
            self.conn.rollback()
            raise

    def space_report(self) -> dict:
        """파일 크기와 빈 공간 — 화면에 보여 주고 VACUUM 판단에도 쓴다."""
        pg = self.conn.execute("PRAGMA page_size").fetchone()[0]
        total = self.conn.execute("PRAGMA page_count").fetchone()[0]
        free = self.conn.execute("PRAGMA freelist_count").fetchone()[0]
        return {"bytes": pg * total, "free_bytes": pg * free,
                "pages": total, "free_pages": free}

    def reclaim_space(self, min_free_bytes: int = 32 * 1024 * 1024,
                      min_ratio: float = 0.25) -> dict | None:
        """지운 기록이 차지하던 빈 페이지를 실제로 디스크에 돌려준다 (VACUUM).

        전에는 prune_details/prune_renders가 행만 지워서 **파일 크기가 역대 최대치에
        영구히 고정**됐다 — 실측으로 921MB 파일의 실데이터가 0.2MB였다. 게다가 주간
        백업이 그 빈 페이지까지 복사해 4슬롯이 3GB였다 (2026-09-09 저장 검토 차단 1).

        VACUUM은 원본만큼의 임시 공간과 시간을 쓰므로 **빈 공간이 충분히 클 때만**
        한다. 돌려준 바이트 수를 알려 주고, 할 일이 없으면 None."""
        rep = self.space_report()
        if rep["free_bytes"] < min_free_bytes or                 rep["free_bytes"] < rep["bytes"] * min_ratio:
            return None
        before = rep["bytes"]
        self.conn.commit()
        self.conn.execute("VACUUM")
        after = self.space_report()["bytes"]
        return {"before": before, "after": after, "freed": max(0, before - after)}

    def integrity_ok(self) -> tuple[bool, str]:
        """DB가 온전한가 — 백업 전에 본다. (정상?, 사유)

        전에는 확인 없이 백업을 덮어써서, 디스크 이상·백신 격리로 DB가 한 번 비면
        4주 안에 멀쩡한 사본 4개가 모두 빈 DB로 덮였다 (2026-09-09 저장 검토 차단 3)."""
        try:
            row = self.conn.execute("PRAGMA integrity_check(20)").fetchone()
        except Exception as e:                      # noqa: BLE001
            return False, f"{type(e).__name__}: {e}"
        msg = str(row[0]) if row else "응답 없음"
        return msg == "ok", msg

    def row_counts(self) -> dict:
        """백업 전후 비교용 주요 표의 행 수."""
        out = {}
        for tbl in ("snapshots", "files", "changes", "acks", "issues"):
            try:
                out[tbl] = self.conn.execute(
                    f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
            except Exception:                       # noqa: BLE001
                out[tbl] = -1
        return out

    def run_lock_holder(self, stale_after: float = 6 * 3600) -> int | None:
        """지금 검사를 돌리고 있는 프로세스의 PID (없으면 None) — 읽기만 한다.

        업데이트 교체가 **다른 프로세스의** 예약 검사를 덮치던 것을 막으려고 추가했다
        (2026-09-09 자동 실행 검토 차단 1): 창의 scan_state()는 자기 스레드만 본다."""
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        if not row:
            return None
        parts = str(row[0]).split(":")
        try:
            pid, at = int(parts[0]), float(parts[1])
            created = int(parts[2]) if len(parts) > 2 and parts[2] else None
        except (ValueError, IndexError):
            return None
        if time.time() - at >= stale_after or not _pid_alive(pid, created):
            return None
        return pid

    def release_run_lock(self, pid: int) -> None:
        row = self.conn.execute("SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        if row and row[0].split(":", 1)[0] == str(pid):
            self.set_meta("run_lock", None)

    def delete_run(self, snapshot_id: int) -> None:
        """실패한 실행의 스냅샷·변경·이슈를 되돌린다 — 다음 실행이 다시 감지하도록.
        (보고 단계 실패 시 알림 유실 방지. extracts는 내용 기준 캐시라 남겨도 무해)"""
        self.conn.execute(
            "DELETE FROM change_details WHERE change_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute(  # 롤백된 변경의 확인 기록이 고아로 남지 않게 (2026-08-26 리뷰)
            "DELETE FROM acks WHERE change_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute("DELETE FROM issues WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute(  # 롤백된 변경을 가리키는 합치기 기록 (2026-09-02 재검토)
            "DELETE FROM project_merge_rows WHERE kind = 'change' AND row_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute("DELETE FROM changes WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM files WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM snapshots WHERE id = ?", (snapshot_id,))
        self.conn.execute(
            "DELETE FROM meta WHERE key = 'run_in_progress' AND value = ?", (str(snapshot_id),))
        self.conn.commit()

    @staticmethod
    def issue_key(code: str, path: str, message: str) -> tuple:
        """중복·해소 대조 키 — 문구의 **변하는 부분**(괄호 안의 값·장수, 앞의 [프로젝트])을 뺀다.

        2026-09-03: '(외 도면 N장에서도 불일치)' 숫자만 바뀐 것이 해소+재생성돼 '신규'로 재알림.
        2026-09-14 실사용 day2: 검토21이 도면 간 불일치 문구에서 ' 외 N장'을 빼자 v0.56→0.57.2
        업데이트 뒤 첫 검사에서 열린 이슈 2건이 '재검출되지 않음'으로 닫히고 같은 내용이 새 이슈로
        태어나 **변경 없는 프로젝트에 검토 필요 메일이 나갔다**. 판이 바뀔 때마다 문구가 조금씩
        바뀌므로, 키는 code+path+태그(문구의 뼈대)만 본다 — 값이 바뀌면 열린 이슈의 문구·근거를
        갱신한다(save_issues)."""
        m = re.sub(r"^\s*\[[^\]]*\]\s*", "", message)          # 앞의 [프로젝트]
        m = re.sub(r"\s*\([^()]*\)", "", m)                     # 괄호 안(값·장수·안내)
        m = re.sub(r"\s+", " ", m).strip().rstrip(".。 ")
        if code == "TAG_MISMATCH_ACROSS_DRAWINGS":
            # 도면 간 불일치의 path는 '첫 충돌 도면'이라, 기준 도면을 고치거나 이름이 앞선 도면이
            # 들어오면 path가 옮겨가 같은 불일치가 새 이슈로 태어났다 (검토23 A-2). 폴더 단위로 본다
            path = path.rsplit("/", 1)[0] if "/" in path else path
        return code, path, m

    def save_issues(self, snapshot_id: int, rows) -> list:
        """일관성 검사 결과 저장. rows: [(Issue, 프로젝트|None)] — 대시보드 표시용.

        미해결 불일치(도면-BOM 등)는 변경이 있는 날마다 다시 검출되므로
        동일 내용(code+path+message)은 중복 저장하지 않는다. 단, 최근 30일
        기록에 대해서만 — 전체 이력 대조로는 해결됐다가 재발한 불일치가
        영원히 묻힌다 (2026-08-25 리뷰 지적)."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        # 열린 이슈는 기간과 무관하게 전부 — 30일 cutoff가 여기에도 걸려, 30일 넘게 열린 이슈가
        # 다음 변경 날 '새 검토 필요'로 중복 재탄생했다 (검토23 A-1 차단, 실사용 10-12 재발 예약분)
        existing = {self.issue_key(c, p, m): iid for iid, c, p, m in self.conn.execute(
            "SELECT id, code, path, message FROM issues WHERE resolved_at IS NULL")}
        # 닫힌(resolved) 이슈: 같은 불일치가 **그대로 남아 있는 동안**에는 다시 만들지 않는다.
        # 예전에는 닫는 순간 대조에서 빠져, 검사 때마다 똑같은 내용이 새 이슈로 되살아나
        # 브리핑 메일에 매일 실렸다 — 열어 두면 조용하고 닫으면 시끄러웠다
        # (2026-09-09 확인 검토 A3). 그 파일이 닫은 뒤 **다시 바뀌었으면** 진짜 재발로 본다.
        # 시각이 아니라 **검사 회차**로 본다 — 닫은 시각과 검출 시각이 같은 순간일 수 있고,
        # 우리가 알고 싶은 것은 "그 뒤로 그 파일이 또 바뀌었나"이기 때문이다
        closed: dict = {}
        for c, pth, m, snap in self.conn.execute(
                "SELECT code, path, message, snapshot_id FROM issues "
                "WHERE detected_at >= ? AND resolved_at IS NOT NULL", (cutoff,)):
            key = self.issue_key(c, pth, m)
            prev = closed.get(key)
            if prev is None or (snap or 0) > prev[1]:
                closed[key] = (pth, snap or 0)

        def _recurred(key) -> bool:
            pth, snap = closed[key]
            row = self.conn.execute(
                "SELECT 1 FROM changes WHERE path = ? AND snapshot_id > ? LIMIT 1",
                (pth, snap)).fetchone()
            return row is not None

        now = datetime.now(timezone.utc).isoformat()
        fresh = [(i, proj) for i, proj in rows
                 if self.issue_key(i.code, i.path, i.message) not in existing
                 and (self.issue_key(i.code, i.path, i.message) not in closed
                      or _recurred(self.issue_key(i.code, i.path, i.message)))]
        # 이미 열린 이슈는 근거·문구를 최신 값으로 갱신한다 — 값이 바뀐 뒤에도 옛 값이
        # 화면에 남아 파일과 달랐다 (2026-09-05 전체 검토, 원칙 4)
        # 경로(첫 충돌 도면이 바뀜)·프로젝트(귀속 이름이 바뀜)도 따라간다 — project가 옛 이름으로
        # 남으면 auto_resolve의 '그 프로젝트를 검사했나' 판정에서 영원히 빠져 해소가 안 됐다 (검토23 A-2·A-3)
        for i, proj in rows:
            iid = existing.get(self.issue_key(i.code, i.path, i.message))
            if iid is not None:
                self.conn.execute(
                    "UPDATE issues SET message = ?, evidence = ?, path = ?, project = ? WHERE id = ?",
                    (i.message, json.dumps(list(i.evidence), ensure_ascii=False), i.path, proj, iid))
        self.conn.executemany(
            "INSERT INTO issues (snapshot_id, code, path, project, message, evidence,"
            " detected_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [(snapshot_id, i.code, i.path, proj, i.message,
              json.dumps(list(i.evidence), ensure_ascii=False), now)
             for i, proj in fresh])
        self.conn.commit()
        # 새로 기록된 것만 돌려준다 — 브리핑은 신규만 싣고, 미해결 누적은 화면에서
        # 본다 (같은 경고가 변경 있는 날마다 메일로 재알림되던 소음 제거, 2026-08-26)
        return fresh

    def has_open_issue(self, path: str, code: str, recent_days: int = 14) -> bool:
        """열려 있거나 최근 recent_days 안에 닫힌 이슈가 있는가 — 담당자가 'Rev 미갱신'을 먼저
        [처리함]으로 닫고 Rev를 올리는 순서도 흔하다 (2026-09-05 재검토)."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=recent_days)).isoformat()
        row = self.conn.execute(
            "SELECT 1 FROM issues WHERE path = ? AND code = ? AND "
            "(resolved_at IS NULL OR resolved_at >= ?) LIMIT 1",
            (path, code, cutoff)).fetchone()
        return row is not None

    def issues(self, project: str | None = None, resolved: bool = False) -> list[dict]:
        """확인 필요 이력 (최신순). 프로젝트 필터 가능. resolved=True면 처리된 것.

        처리하면 흔적 없이 사라져 '누가 언제 처리했는지'를 볼 곳이 없었다
        (2026-09-02 처음 보는 사람 검토)."""
        sql = ("SELECT id, detected_at, code, path, project, message, evidence, "
               "snapshot_id, resolved_at, resolved_by FROM issues WHERE resolved_at IS "
               + ("NOT NULL " if resolved else "NULL "))
        params: tuple = ()
        if project:
            sql += "AND project = ? "
            params = (project,)
        sql += "ORDER BY " + ("resolved_at DESC" if resolved else "id DESC")
        keys = ("issue_id", "detected_at", "code", "path", "project", "message",
                "evidence", "snapshot_id", "resolved_at", "resolved_by")
        out = []
        for row in self.conn.execute(sql, params):
            d = dict(zip(keys, row))
            d["evidence"] = json.loads(d["evidence"])
            out.append(d)
        return out

    def changes_for_paths(self, paths, snapshot_id: int | None = None) -> dict:
        """파일 경로 → 전/후 비교를 볼 수 있는 변경 id.

        검토 필요 항목에서 그 파일의 비교 화면으로 바로 갈 수 있게 한다.
        같은 검사(snapshot)의 변경을 우선하고, 없으면 가장 최근 변경을 쓴다.
        내용 비교 기록(change_details)이 있는 변경만 — 링크를 눌렀는데
        '비교 기록이 없습니다'가 나오면 헛걸음이다 (2026-09-02)."""
        paths = [p for p in dict.fromkeys(paths) if p]
        if not paths:
            return {}
        marks = ",".join("?" * len(paths))
        rows = self.conn.execute(
            f"SELECT c.path, c.id, c.snapshot_id FROM changes c "
            f"JOIN change_details d ON d.change_id = c.id "
            f"WHERE c.path IN ({marks}) ORDER BY c.id ASC", tuple(paths)).fetchall()
        out: dict = {}
        for path, cid, snap in rows:            # 뒤(최신)가 앞을 덮는다
            out[path] = cid
        if snapshot_id is not None:             # 같은 검사 것이 있으면 그쪽으로
            for path, cid, snap in rows:
                if snap == snapshot_id:
                    out[path] = cid
        return out

    def auto_resolve_issues(self, keep: set, changed_paths: set, projects: set,
                            readable: set | None = None, present: set | None = None) -> int:
        """열린 이슈 중 이번 검사에서 다시 검출되지 않은 것을 '자동 해소'로 닫는다.
        파일 단위 판정(Rev)은 그 파일이 이번에 바뀌었을 때만, 교차 검사(도면 간·BOM)는
        그 프로젝트가 이번에 검사됐을 때만 — 검사하지 않은 것을 해소로 오인하지 않게.
        readable: 이번에 내용을 읽은 경로 — 못 읽은(손상·잠김) 파일의 이슈는 닫지 않는다.
        present: 이번 스냅샷의 경로 — 없어진 파일의 이슈는 '파일 삭제됨'으로 닫는다.
        (2026-09-03 검토·재검토)"""
        rows = self.conn.execute(
            "SELECT id, code, path, project, message FROM issues "
            "WHERE resolved_at IS NULL").fetchall()
        keep_keys = {self.issue_key(*k) for k in keep}
        now = datetime.now(timezone.utc).isoformat()
        n = 0
        for iid, code, path, proj, msg in rows:
            if self.issue_key(code, path, msg) in keep_keys:
                continue
            cross = code in ("TAG_MISMATCH_ACROSS_DRAWINGS", "BOM_MISMATCH")
            why = None
            if present is not None and path not in present:
                why = "자동 해소 — 파일이 삭제됨"
            elif readable is not None and path not in readable:
                continue                       # 못 읽은 파일 — 해소로 오인하지 않는다
            elif (cross and proj in projects) or (not cross and path in changed_paths):
                why = "자동 해소 — 다시 검사했을 때 재검출되지 않음"
            if why:
                self.conn.execute(
                    "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?",
                    (now, why, iid))
                n += 1
        self.conn.commit()
        return n

    def resolve_issue(self, issue_id: int, by: str = "") -> bool:
        """이상 징후를 '처리함'으로 닫는다 — 목록·누적 숫자에서 빠진다.
        기록은 지우지 않는다 (같은 내용이 다시 검출되면 새 이슈로 다시 쌓인다).

        실제로 닫았으면 True. 없는 id였는데 "표시했습니다"라고 답하던 것을 막는다
        (2026-09-09 웹 검토 낮음 9)."""
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute(
            "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?",
            (now, by, issue_id))
        self.conn.commit()
        return cur.rowcount > 0

    def _secret(self) -> str:
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'ack_secret'").fetchone()
        if row:
            return row[0]
        s = secrets.token_hex(16)
        self.conn.execute("INSERT INTO meta (key, value) VALUES ('ack_secret', ?)", (s,))
        self.conn.commit()
        return s

    def ack_token(self, change_id: int) -> str:
        """확인 링크용 토큰. 링크를 아는 사람만 확인을 저장할 수 있다 (CSRF 방지)."""
        return hmac.new(self._secret().encode(), str(change_id).encode(),
                        "sha256").hexdigest()[:16]

    def csrf_token(self) -> str:
        """웹 대시보드 폼 공용 CSRF 토큰 (설치별 고정).

        127.0.0.1 바인딩이어도 CSRF는 못 막는다 — 요청이 사용자 브라우저에서
        나가기 때문. 외부 페이지는 이 토큰을 읽을 수 없으므로 폼 위조가 차단된다."""
        return hmac.new(self._secret().encode(), b"csrf-form",
                        "sha256").hexdigest()[:32]

    def prune_details(self, days: int = 90) -> int:
        """보존 기간이 지난 무거운 기록을 지워 DB 비대화를 막는다.
        ①변경 상세(diff+캡처 JSON — 캡처 포함 시 수 MB)
        ②오래된 스냅샷의 파일 목록 — 매 검사마다 전체 파일 목록이 기록되어
          파일 1,000개당 검사 1회 약 172KB씩 영구 누적됨 (2026-08-25 확장성 검토).
          비교에 쓰는 최신 스냅샷은 기간과 무관하게 보존한다.
        변경 이력(changes)·확인(acks)·추출 캐시는 남긴다. 돌려주는 값: 지운 행 수."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        cur = self.conn.execute(
            "DELETE FROM change_details WHERE change_id IN "
            "(SELECT id FROM changes WHERE detected_at < ?)", (cutoff,))
        n = cur.rowcount
        # 파일 목록은 최신 스냅샷만 읽는다 — 90일치 4만 건씩(≈360만 행)을 둘 이유가
        # 없다. 최신 1회분만 남긴다 (2026-09-02 재검토)
        cur = self.conn.execute(
            "DELETE FROM files WHERE snapshot_id NOT IN ("
            " SELECT id FROM snapshots ORDER BY id DESC LIMIT 1)")
        n += cur.rowcount
        # 추출 캐시: 최신 스냅샷에도 없고 보존 기간 안의 변경에도 안 걸리는 판은 고아
        # — 모든 판의 전문이 영구 누적되던 것 (2026-09-02 재검토)
        cur = self.conn.execute(
            "DELETE FROM extracts WHERE sha256 NOT IN ("
            " SELECT sha256 FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots))"
            " AND sha256 NOT IN ("
            " SELECT old_sha256 FROM changes WHERE detected_at >= ? AND old_sha256 IS NOT NULL)"
            " AND sha256 NOT IN ("
            " SELECT new_sha256 FROM changes WHERE detected_at >= ? AND new_sha256 IS NOT NULL)",
            (cutoff, cutoff))
        n += cur.rowcount
        self.conn.commit()
        return n

    def set_change_project(self, change_id: int, project: str) -> None:
        self.conn.execute("UPDATE changes SET project = ? WHERE id = ?", (project, change_id))
        self.conn.commit()

    def get_change(self, change_id: int) -> Change | None:
        row = self.conn.execute(
            "SELECT kind, path, old_sha256, new_sha256, id, project FROM changes WHERE id = ?",
            (change_id,)).fetchone()
        return Change(*row) if row else None

    def add_ack(self, change_id: int, by: str, note: str) -> bool:
        """확인 기록 저장. 대상 변경이 없으면 False."""
        if self.get_change(change_id) is None:
            return False
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute("INSERT INTO acks (change_id, by, note, at) VALUES (?, ?, ?, ?)",
                          (change_id, by, note, now))
        self.conn.commit()
        return True

    def add_ack_bulk(self, change_ids: list[int], by: str, note: str) -> int:
        """여러 변경을 한 번에 확인 처리 — 기준선 수백 건 등 (2026-08-26 신입 검토:
        하나씩 이름 쳐서 확인하는 것 말고는 미확인을 줄일 방법이 없던 문제)."""
        now = datetime.now(timezone.utc).isoformat()
        self.conn.executemany(
            "INSERT INTO acks (change_id, by, note, at) VALUES (?, ?, ?, ?)",
            [(cid, by, note, now) for cid in change_ids])
        self.conn.commit()
        return len(change_ids)

    def first_snapshot_by_root(self) -> dict[str, int]:
        """감시 폴더(경로 키 첫 마디)별 첫 검사 스냅샷 id — 그때의 '추가'는 기준선.
        changes는 정리(prune)되지 않아 폴더를 나중에 추가해도 첫 검사를 알 수 있다
        (2026-09-02 재검토: 두 번째 폴더의 첫 등록이 미확인 변경으로 잡혔다)."""
        out = {r: s for r, s in self.conn.execute(
            "SELECT CASE WHEN instr(path, '/') > 0 THEN substr(path, 1, instr(path, '/') - 1)"
            " ELSE path END AS r, MIN(snapshot_id) FROM changes GROUP BY r")}
        # record_run이 명시적으로 적은 '첫 실제 검사'가 있으면 그것이 우선 (검토20 A-4·A-6)
        try:
            explicit = json.loads(self.get_meta("root_first_seen") or "{}")
        except (ValueError, TypeError):
            explicit = {}
        for r, s in explicit.items():
            try:
                out[str(r)] = int(s)
            except (TypeError, ValueError):
                pass
        # DB 첫 검사(전체 기준선)의 등록도 언제나 등록이다 — 기록을 남긴 채 뺐다가 다시 넣은 폴더는
        # 첫 검사가 새 스냅샷으로 바뀌는데, 그러면 옛 첫 검사 행이 '미확인 변경'으로 되살아났다
        # (검토20 재검증 ①). 예약 키 "*"로 함께 돌려주고 is_first_registration이 본다
        first = self.first_snapshot_id()
        if first is not None:
            out["*"] = first
        return out

    # ── 나중에 켠 확장자의 첫 등록 (2026-09-10 검토18 ③-A)
    # 감시 폴더를 나중에 추가하면 그 폴더의 첫 검사가 기준선인 것처럼, 확장자를 나중에
    # 켜면(설정의 묶음 단추 한 번에 106개) 그 검사에서 잡힌 그 확장자의 '추가'도 변경이
    # 아니라 등록이다 — 아니면 PLC 파일 수백 건이 그날 브리핑에 '추가'로 쏟아진다.
    # 어느 검사에서 어떤 확장자가 새로 켜졌는지를 meta에 남기고 화면·주간·브리핑이 같은
    # 규칙으로 센다. "감시 시작 뒤 처음 나타난 파일"과는 다르다 — 그것은 진짜 추가다.
    def ext_baseline(self) -> dict[str, int]:
        """{확장자: 그 확장자가 처음 켜진 검사의 스냅샷 id}."""
        import json
        raw = self.get_meta("ext_baseline")
        try:
            d = json.loads(raw) if raw else {}
            return {str(k).lower(): int(v) for k, v in d.items()}
        except (ValueError, TypeError, AttributeError):
            return {}

    def note_ext_baseline(self, exts, snapshot_id: int) -> None:
        import json
        d = self.ext_baseline()
        for e in exts:
            d[str(e).lower()] = int(snapshot_id)
        self.set_meta("ext_baseline", json.dumps(d, ensure_ascii=False))

    @staticmethod
    def is_first_registration(kind: str, path: str, snapshot_id,
                              first_by_root: dict, ext_base: dict) -> bool:
        """이 '추가'가 변경이 아니라 등록인가 — 폴더의 첫 검사이거나 확장자를 켠 검사."""
        if kind != "added" or snapshot_id is None:
            return False
        if snapshot_id == first_by_root.get("*"):      # DB 첫 검사(전체 기준선)
            return True
        root = path.split("/", 1)[0] if "/" in path else path
        if snapshot_id == first_by_root.get(root):
            return True
        dot = path.rfind(".")
        ext = path[dot:].lower() if dot > path.rfind("/") else ""
        return bool(ext) and snapshot_id == ext_base.get(ext)

    def repath_open_issues(self, old_path: str, new_path: str) -> int:
        """이동한 파일의 열린 이슈를 새 경로로 옮긴다 — 삭제·재발로 두 번 세지 않게."""
        cur = self.conn.execute(
            "UPDATE issues SET path = ? WHERE path = ? AND resolved_at IS NULL",
            (new_path, old_path))
        self.conn.commit()
        return cur.rowcount or 0

    def rev_bumped_recently(self, path: str, hours: int = 36) -> bool:
        """이 파일에 최근(기본 36시간) 'Rev 올림'(FIELD_CHANGED REV) 변경이 기록돼 있나."""
        from datetime import datetime as _dt, timedelta as _td, timezone as _tz
        since = (_dt.now(_tz.utc) - _td(hours=hours)).isoformat()
        for (js,) in self.conn.execute(
                "SELECT d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                "WHERE c.path = ? AND c.detected_at >= ? ORDER BY c.id DESC LIMIT 6", (path, since)):
            try:
                import json as _json
                for it in _json.loads(js or "[]"):
                    if it.get("kind") == "FIELD_CHANGED" and it.get("key") == "REV":
                        return True
            except (ValueError, TypeError, AttributeError):
                continue
        return False

    def change_summaries(self, ids) -> dict[int, tuple[int, str]]:
        """변경 id → (무게, '무엇이 어떻게' 한 줄). 무게: 사양·표 행 0 < Rev 1 < 글자·그림 2 <
        날짜·크기 3 < 참고만 4 — 화면 정렬과 첫 줄이 같은 근거를 쓴다 (파일럿 모의 2차 조건 2)."""
        import json as _json
        ids = [int(i) for i in ids if i is not None][:200]
        if not ids:
            return {}
        out: dict[int, tuple[int, str]] = {}
        q = ",".join("?" * len(ids))
        for cid, js in self.conn.execute(
                f"SELECT change_id, items_json FROM change_details WHERE change_id IN ({q})", ids):
            try:
                items = _json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            w, head = _headline_of(items, with_weight=True)
            out[int(cid)] = (w, head)
        return out

    def change_headlines(self, ids) -> dict[int, str]:
        """변경 id → '무엇이 어떻게' 한 줄 (M-201 1.5kW→5.5kW / 수량 2→4 / Rev A→B).
        화면 '오늘 확인할 것'이 파일명만 보여 줘 눌러 봐야 알았다 (파일럿 모의 ⑦)."""
        return {k: h for k, (_w, h) in self.change_summaries(ids).items() if h}

    def ack_of(self, change_id: int) -> str | None:
        """그 변경의 최근 확인자 (없으면 None)."""
        row = self.conn.execute(
            "SELECT by FROM acks WHERE change_id = ? ORDER BY id DESC LIMIT 1",
            (change_id,)).fetchone()
        return row[0] if row else None

    def file_facts(self, path: str) -> list[dict]:
        """그 경로의 최근 두 판 기록 — (검사 시각, 지문, 크기, 수정 시각).

        내용 비교를 못 한 변경에도 사람이 판단할 근거는 있어야 한다(원칙 4). 전에는
        비교 실패 화면에 엔진 오류 한 줄뿐이고 지문·크기·수정 시각이 어디에도
        없었다 (2026-09-09 웹 검토 중간 8)."""
        rows = self.conn.execute(
            "SELECT s.run_at, f.sha256, f.size, f.mtime FROM files f "
            "JOIN snapshots s ON s.id = f.snapshot_id WHERE f.path = ? "
            "ORDER BY f.snapshot_id DESC LIMIT 2", (path,)).fetchall()
        return [{"run_at": r[0], "sha256": r[1], "size": r[2], "mtime": r[3]}
                for r in rows]

    def acks_of(self, change_id: int) -> list[dict]:
        """그 변경의 확인 기록 전부 (오래된 것부터).

        화면이 이걸 보려고 **전체 이력을 메모리에 올렸다** — 변경 30만 건에서 한 줄에
        1.6초·200MB였다 (2026-09-09 저장 검토 중간 5)."""
        rows = self.conn.execute(
            'SELECT "by", note, at FROM acks WHERE change_id = ? ORDER BY id',
            (change_id,)).fetchall()
        return [{"ack_by": r[0], "ack_note": r[1], "ack_at": r[2]} for r in rows]

    def snapshot_local_time(self, snapshot_id: int) -> str | None:
        """검사 시작 시각을 이 PC 시간으로 'MM-DD HH:MM' — 브리핑의 '비교 기준' 표기용."""
        from datetime import datetime as _dt
        row = self.conn.execute("SELECT run_at FROM snapshots WHERE id = ?",
                                (snapshot_id,)).fetchone()
        if not row or not row[0]:
            return None
        iso = row[0]
        if not ("+" in iso[10:] or iso.endswith("Z")):
            iso += "+00:00"
        try:
            return _dt.fromisoformat(iso).astimezone().strftime("%m-%d %H:%M")
        except ValueError:
            return None

    def prev_snapshot_id(self, snapshot_id: int) -> int | None:
        """이번 검사의 직전 스냅샷 id — 무엇과 비교한 것인지 밝히려고."""
        row = self.conn.execute(
            "SELECT id FROM snapshots WHERE id < ? ORDER BY id DESC LIMIT 1",
            (snapshot_id,)).fetchone()
        return row[0] if row else None

    def snapshot_local_date(self, snapshot_id: int) -> str | None:
        """검사 시작 시각의 이 PC 지역 날짜 (ISO) — 자정을 걸친 검사의 '그 날'."""
        from datetime import datetime as _dt
        row = self.conn.execute("SELECT run_at FROM snapshots WHERE id = ?",
                                (snapshot_id,)).fetchone()
        if not row or not row[0]:
            return None
        iso = row[0]
        if not ("+" in iso[10:] or iso.endswith("Z")):
            iso += "+00:00"
        try:
            return _dt.fromisoformat(iso).astimezone().date().isoformat()
        except ValueError:
            return None

    def changes_on_day(self, day_iso: str, exclude_snapshots=()) -> list[Change]:
        """그 날(이 PC 지역 날짜)에 잡힌 변경 — 같은 날 두 번째 검사가 아침 브리핑과
        합쳐 한 통으로 갱신하기 위해 (2026-09-05 재검토: 초안 8통이 나열됨)."""
        from datetime import datetime as _dt, timedelta as _td
        # 지역 날짜 ±1일 범위만 SQL로 좁힌 뒤 정확한 지역 날짜로 거른다 (전 행 훑기 방지)
        lo = (_dt.fromisoformat(day_iso) - _td(days=1)).strftime("%Y-%m-%d")
        hi = (_dt.fromisoformat(day_iso) + _td(days=2)).strftime("%Y-%m-%d")
        skip = set(exclude_snapshots)
        out = []
        for row in self.conn.execute(
                "SELECT id, kind, path, old_sha256, new_sha256, project, snapshot_id, detected_at"
                " FROM changes WHERE detected_at >= ? AND detected_at < ? ORDER BY id", (lo, hi)):
            if row[6] in skip:                     # 이번 검사·기준선 검사분은 제외
                continue
            iso = row[7] or ""
            if not ("+" in iso[10:] or iso.endswith("Z")):
                iso += "+00:00"
            try:
                if _dt.fromisoformat(iso).astimezone().date().isoformat() != day_iso:
                    continue
            except ValueError:
                continue
            out.append(Change(row[1], row[2], row[3], row[4], id=row[0], project=row[5]))
        return out

    def first_snapshot_id(self) -> int | None:
        """기준선(첫 검사) 스냅샷 id — 그때의 '추가' 대량 건은 실제 변경이 아니다."""
        row = self.conn.execute("SELECT MIN(id) FROM snapshots").fetchone()
        return row[0]

    def next_unacked(self, after_id: int, same_run: bool = True) -> int | None:
        """확인되지 않은 다음 변경의 id — 상세 화면의 [확인하고 다음]이 쓴다 (2026-09-09).

        같은 검사분 안에서 id가 큰 쪽부터 찾고, 없으면 앞쪽으로 한 바퀴 돈다.
        한 건 확인할 때마다 목록으로 돌아갔다 다시 들어가던 것을 없애기 위해서다."""
        snap = None
        if same_run:
            row = self.conn.execute("SELECT snapshot_id FROM changes WHERE id = ?",
                                    (after_id,)).fetchone()
            if row is None:
                return None          # 없는 id — 검사분을 못 좁히므로 아무 데로나 보내지 않는다
            snap = row[0]
        where = "a.id IS NULL AND c.id <> ?"
        params: list = [after_id]
        first = self.first_snapshot_id()
        if first is not None:
            # 기준선의 '추가'는 화면이 '첫 등록'으로 보여 주고 확인을 요구하지 않는다 —
            # 순회가 거기로 데려가면 수백~수천 건을 돌게 된다 (2026-09-09 검토18 F1)
            where += " AND NOT (c.snapshot_id = ? AND c.kind = 'added')"
            params.append(first)
        if snap is not None:
            where += " AND c.snapshot_id = ?"
            params.append(snap)
        sql = ("SELECT c.id FROM changes c LEFT JOIN acks a ON a.change_id = c.id "
               f"WHERE {where} AND c.id > ? ORDER BY c.id LIMIT 1")
        row = self.conn.execute(sql, (*params, after_id)).fetchone()
        if row:
            return int(row[0])
        sql2 = ("SELECT c.id FROM changes c LEFT JOIN acks a ON a.change_id = c.id "
                f"WHERE {where} ORDER BY c.id LIMIT 1")          # 한 바퀴 돌아 앞쪽
        row = self.conn.execute(sql2, tuple(params)).fetchone()
        return int(row[0]) if row else None

    def history(self, project: str | None = None) -> list[dict]:
        """변경 이력 + 확인 기록 (프로젝트 필터 가능)."""
        sql = ("SELECT c.id, c.detected_at, c.kind, c.path, c.project, a.by, a.note, a.at, "
               "c.snapshot_id "
               "FROM changes c LEFT JOIN acks a ON a.change_id = c.id ")
        params: tuple = ()
        if project:
            sql += "WHERE c.project = ? "
            params = (project,)
        sql += "ORDER BY c.id, a.id"
        keys = ("change_id", "detected_at", "kind", "path", "project",
                "ack_by", "ack_note", "ack_at", "snapshot_id")
        return [dict(zip(keys, row)) for row in self.conn.execute(sql, params)]
