# -*- coding: utf-8 -*-
"""SQLite 상태 저장소: 파일 스냅샷, 변경 이력, (Stage 5) 확인 기록.

쓰기는 state.db 한 파일에만 한다. 감시 대상 산출물에는 절대 쓰지 않는다.
"""

from __future__ import annotations

import contextlib
import hmac
import os
import time
import json
import re
import secrets
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import NamedTuple

from watcher.rowkey import split_row_cell
from watcher.scan import FileRecord


def _nfc_s(s) -> str:
    import unicodedata
    return unicodedata.normalize("NFC", str(s or ""))


_SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    run_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    path        TEXT NOT NULL,
    sha256      TEXT NOT NULL,
    size        INTEGER NOT NULL,
    mtime       REAL NOT NULL,
    PRIMARY KEY (snapshot_id, path)
);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS extracts (
    sha256       TEXT PRIMARY KEY,
    doc_json     TEXT NOT NULL,
    extracted_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS changes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    kind        TEXT NOT NULL CHECK (kind IN ('added', 'modified', 'removed')),
    path        TEXT NOT NULL,
    old_sha256  TEXT,
    new_sha256  TEXT,
    detected_at TEXT NOT NULL,
    project     TEXT
);
CREATE TABLE IF NOT EXISTS issues (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    code        TEXT NOT NULL,
    path        TEXT NOT NULL,
    project     TEXT,
    message     TEXT NOT NULL,
    evidence    TEXT NOT NULL,
    detected_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS change_details (
    change_id     INTEGER PRIMARY KEY REFERENCES changes(id),
    items_json    TEXT NOT NULL,
    captures_json TEXT
);
CREATE TABLE IF NOT EXISTS project_merges (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    at      TEXT NOT NULL,
    into_p  TEXT NOT NULL,           -- 남길 대표 이름
    sources TEXT NOT NULL            -- 합쳐 넣은 이름들 (줄바꿈 구분)
);
CREATE TABLE IF NOT EXISTS project_merge_rows (
    merge_id INTEGER NOT NULL REFERENCES project_merges(id),
    kind     TEXT NOT NULL,          -- 'change' | 'issue'
    row_id   INTEGER NOT NULL,
    old_p    TEXT NOT NULL           -- 바꾸기 전 이름 (되돌리기용)
);
CREATE TABLE IF NOT EXISTS doc_hints (
    path   TEXT PRIMARY KEY,         -- 경로 키
    sha256 TEXT NOT NULL,            -- 어느 판의 내용에서 읽었나
    kind   TEXT NOT NULL,            -- 내용에서 읽은 유형
    why    TEXT NOT NULL             -- 근거 (화면 표시용)
);
CREATE TABLE IF NOT EXISTS renders (
    sha256 TEXT NOT NULL,            -- 어느 판의 그림인가 (render.py, 2026-09-02)
    page   INTEGER NOT NULL,         -- 1부터
    width  REAL NOT NULL,            -- pt
    height REAL NOT NULL,
    meta   TEXT NOT NULL DEFAULT '{}',
    png    BLOB NOT NULL,            -- 그레이 PNG (감지 해상도)
    PRIMARY KEY (sha256, page)
);
CREATE TABLE IF NOT EXISTS manual_pairs (
    child_key TEXT PRIMARY KEY,   -- 대상 파일 (경로 키)
    prev_key  TEXT NOT NULL,      -- 사람이 지정한 이전 판
    by        TEXT,
    at        TEXT
);
CREATE TABLE IF NOT EXISTS acks (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    change_id INTEGER NOT NULL REFERENCES changes(id),
    by        TEXT NOT NULL,
    note      TEXT,
    at        TEXT NOT NULL
);
-- 파일별 프로젝트 고정 — 사람이 정한 귀속(귀속기 1순위, 해제 가능) (기능 검토 2026-11-02 J6)
CREATE TABLE IF NOT EXISTS manual_projects (
    path    TEXT PRIMARY KEY,     -- 경로 키
    project TEXT NOT NULL,
    by      TEXT,
    at      TEXT
);
-- 출도(발행) 폴더에 들어온 판 — 그 도면번호의 '출도본' (J2)
CREATE TABLE IF NOT EXISTS issued_copies (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT NOT NULL,     -- 도면번호(접은 꼴)
    path        TEXT NOT NULL,
    sha256      TEXT NOT NULL,
    rev         TEXT,
    saved       REAL,              -- 파일 저장 시각
    snapshot_id INTEGER,           -- 처음 본 검사
    at          TEXT NOT NULL,
    project     TEXT,              -- 출도본의 귀속 — 같은 프로젝트의 원본만 잇는다 (재검토 rr066 judge 2)
    UNIQUE (path, sha256)
);
-- 발주서 행의 태그·품번 — 발주 뒤 그 사양이 바뀌면 표시 (J8). 금액 칸은 담지 않는다(DECISIONS 2026-10-19)
CREATE TABLE IF NOT EXISTS po_lines (
    path        TEXT NOT NULL,
    row         TEXT NOT NULL,     -- '시트!행3'
    tag         TEXT NOT NULL,     -- 태그·품번(접은 꼴)
    spec        TEXT,              -- 그 행의 사양 글(금액 칸 뺌)
    ordered     TEXT,              -- 발주일 'YYYY-MM-DD|칸'(시트 날짜 칸)·'YYYY-MM-DD|저장'(파일 저장 시각 추정)·NULL(모름) — issued._order_date
    snapshot_id INTEGER,           -- 그 행을 처음 본 검사
    project     TEXT,              -- 발주서의 귀속 (다른 프로젝트의 같은 태그는 다른 기기)
    sha256      TEXT,              -- 마지막으로 읽은 발주서 판
    PRIMARY KEY (path, row, tag)
);
-- 변경 기록의 귀속 이력 — 귀속을 정하거나 바꿀 때마다 한 줄 덧붙인다(고치거나 지우지 않는다). changes.project는 지금 값,
-- 첫 줄이 원래 귀속이다 (2026-11-17 R1: 합치기·고정이 원래 귀속을 지우지 않게)
CREATE TABLE IF NOT EXISTS project_log (
    change_id INTEGER NOT NULL,
    at        TEXT NOT NULL,
    project   TEXT,
    how       TEXT,                -- 귀속 근거 부호 (watcher.project.HOW_CODES), NULL = 모름
    why       TEXT,                -- 귀속기 출처 글 그대로 ("표제란 'P24-031'"·"폴더명" …)
    by        TEXT
);
-- 변경 한 줄 요약 (규칙 기반, watcher.summary) — 기록할 때 만든 줄과 그때의 프로젝트. 표시는 State.record_summaries가
-- 숨긴 항목·바뀐 귀속을 반영해 다시 만든다 (2026-11-17 R1)
CREATE TABLE IF NOT EXISTS change_summaries (
    change_id INTEGER PRIMARY KEY,
    summary   TEXT NOT NULL,
    project   TEXT,
    at        TEXT NOT NULL
);
-- [다시 비교]·짝 지정으로 상세를 새로 쓸 때 그 전 항목 — 원래 근거(구값·신값·위치)를 잃지 않게 덧붙여 둔다 (2026-11-17 R1)
CREATE TABLE IF NOT EXISTS change_details_prev (
    change_id      INTEGER NOT NULL,
    replaced_at    TEXT NOT NULL,
    items_json     TEXT NOT NULL,
    dismissed_json TEXT
);
-- 숨긴 기록 묶음 — 프로젝트 정리·감시 폴더 기록 정리는 지우지 않고 숨긴다. 숨긴 행은 '<표>_hidden'에 그대로 옮겨 두고
-- 되살리면 같은 번호로 돌아온다 (2026-11-17 R1, DECISIONS 같은 날)
CREATE TABLE IF NOT EXISTS record_hides (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    at          TEXT NOT NULL,
    kind        TEXT NOT NULL,     -- 'project' | 'prefix'(감시 폴더 라벨)
    target      TEXT NOT NULL,
    by          TEXT,
    counts      TEXT,              -- {"changes": n, "acks": n, "issues": n}
    restored_at TEXT
);
-- 이력 세대 — 화면이 보는 행(변경·확인·기준선 표시)이 바뀔 때마다 1씩 오른다. 화면은 이 값이 같으면
-- 20만 행 이력을 다시 읽지 않는다 (검토36 C-3: 대시보드 8~19초). 어떤 코드 경로로 바꿔도 빠지지 않게
-- 트리거로 센다. 여는 순간 쓰기가 생기지 않도록 행은 첫 변경 때 만든다
CREATE TABLE IF NOT EXISTS hist_gen (
    k INTEGER PRIMARY KEY CHECK (k = 1),
    v INTEGER NOT NULL
);
CREATE TRIGGER IF NOT EXISTS hg_changes_ins AFTER INSERT ON changes BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_changes_upd AFTER UPDATE ON changes BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_changes_del AFTER DELETE ON changes BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_acks_ins AFTER INSERT ON acks BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_acks_upd AFTER UPDATE ON acks BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_acks_del AFTER DELETE ON acks BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_meta_ins AFTER INSERT ON meta
    WHEN NEW.key IN ('root_first_seen', 'ext_baseline') BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_meta_upd AFTER UPDATE ON meta
    WHEN NEW.key IN ('root_first_seen', 'ext_baseline') BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
CREATE TRIGGER IF NOT EXISTS hg_meta_del AFTER DELETE ON meta
    WHEN OLD.key IN ('root_first_seen', 'ext_baseline') BEGIN
    INSERT OR REPLACE INTO hist_gen (k, v) VALUES (1, COALESCE((SELECT v FROM hist_gen WHERE k = 1), 0) + 1); END;
-- 의견 (2026-11-23 사내망 협업 다듬기) — 변경 또는 확인 필요 하나에 붙는 사람 글. 덧붙임만: 고치거나 지우지 않는다(잘못 쓴 것은
-- '정정' 의견을 새로 단다 — 아래 방아쇠가 UPDATE·DELETE를 막는다). kind: 'comment' 의견 | 'resolve' [처리함]과 함께 남긴 메모.
-- 대상 번호는 지우지 않는 표(changes·issues, AUTOINCREMENT)라 다시 쓰이지 않는다
CREATE TABLE IF NOT EXISTS comments (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    target    TEXT NOT NULL CHECK (target IN ('change', 'issue')),
    target_id INTEGER NOT NULL,
    "by"      TEXT NOT NULL,
    body      TEXT NOT NULL,
    at        TEXT NOT NULL,
    kind      TEXT NOT NULL DEFAULT 'comment'
);
-- 담당 (2026-11-23) — 변경·확인 필요의 담당자 기록. 지금 담당 = 마지막 줄, 담당 해제 = 담당자가 빈 줄. 덧붙임만(바뀐 기록이 남는다)
CREATE TABLE IF NOT EXISTS assignments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    target      TEXT NOT NULL CHECK (target IN ('change', 'issue')),
    target_id   INTEGER NOT NULL,
    assignee    TEXT NOT NULL DEFAULT '',
    assignee_id INTEGER,
    "by"        TEXT NOT NULL,
    at          TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS cm_keep_upd BEFORE UPDATE ON comments BEGIN
    SELECT RAISE(ABORT, 'comments are append-only'); END;
CREATE TRIGGER IF NOT EXISTS cm_keep_del BEFORE DELETE ON comments BEGIN
    SELECT RAISE(ABORT, 'comments are append-only'); END;
CREATE TRIGGER IF NOT EXISTS as_keep_upd BEFORE UPDATE ON assignments BEGIN
    SELECT RAISE(ABORT, 'assignments are append-only'); END;
CREATE TRIGGER IF NOT EXISTS as_keep_del BEFORE DELETE ON assignments BEGIN
    SELECT RAISE(ABORT, 'assignments are append-only'); END;
"""

# 색인이 하나도 없어서 화면 질의가 전부 전체 훑기였다 — 변경 30만 건에서 대시보드
# 한 장이 7.3초, history()가 1.57초였다 (2026-09-09 저장 검토 중간 5 실측).
# 마이그레이션으로 **나중에 생긴 열**(issues.resolved_at, changes.project)도 쓰므로
# _SCHEMA가 아니라 마이그레이션 뒤에 만든다. IF NOT EXISTS라 기존 설치본도 따라온다.
_INDEXES = (
    "CREATE INDEX IF NOT EXISTS ix_acks_change  ON acks(change_id)",
    "CREATE INDEX IF NOT EXISTS ix_chg_path     ON changes(path)",
    "CREATE INDEX IF NOT EXISTS ix_chg_project  ON changes(project)",
    "CREATE INDEX IF NOT EXISTS ix_chg_snapshot ON changes(snapshot_id)",
    "CREATE INDEX IF NOT EXISTS ix_chg_detected ON changes(detected_at)",
    "CREATE INDEX IF NOT EXISTS ix_iss_path     ON issues(path, code)",
    "CREATE INDEX IF NOT EXISTS ix_iss_resolved ON issues(resolved_at)",
    "CREATE INDEX IF NOT EXISTS ix_files_path   ON files(path)",
    "CREATE INDEX IF NOT EXISTS ix_plog_change  ON project_log(change_id)",
    "CREATE INDEX IF NOT EXISTS ix_cm_target    ON comments(target, target_id)",
    "CREATE INDEX IF NOT EXISTS ix_as_target    ON assignments(target, target_id)",
    "CREATE INDEX IF NOT EXISTS ix_as_who       ON assignments(assignee_id)",
)


ISSUE_RULE_GEN_KEY = "issue_rule_gen"    # 이 DB를 마지막으로 연 판 — 바뀌면 열린 교차 이슈를 한 번 재판정 (재검토 2026-10-28 R7-D2)
ISSUE_REJUDGE_KEY = "issue_rejudge"      # 재판정 대기 중인 교차 이슈 id 목록
RULE_BUMP_KEY = "rule_bump"              # 판이 바뀐 때 {from, to, at} — 그 뒤 며칠의 재판정 검토 필요를 따로 묶는다 (J4)


# 변경 종류 → 한글 라벨 (콘솔·브리핑·확인 페이지 공용 — 한 곳에서만 관리)
KIND_LABEL = {"added": "추가", "modified": "수정", "removed": "삭제"}

# 사내망(양식함 서버)에서 남긴 확인 — acks.by에 '이름 (사내망·아이디)'로 적는다. 스키마는 그대로 (2026-11-02 갈래 N, FORMS.md 11절)
_LAN_ACK = re.compile(r"^(?P<name>.*\S) \(사내망·(?P<login>[^()\s]{1,64})\)$")


# 보이지 않는 서식 문자(Cf) 가운데 지우지 않는 것 — 이모지 결합(ZWJ: 👨‍👩‍👧)·글자 잇기 막기(ZWNJ). 깃발 이모지의 태그 문자
# (🏴 + U+E0020~E007E + U+E007F)는 그 꼴 안에서만 남긴다
_CF_KEEP = frozenset("‌‍")
_EMOJI_TAG_SEQ = re.compile("\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F")


def clean_ack_text(s) -> str:
    """확인 메모·확인자 이름 — 제어 문자(\\x00·\\x07·ESC 등)와 보이지 않는 서식 문자(양방향 제어 U+202E·폭 없는 공백 U+200B·
    BOM 등, 유니코드 Cf)를 지운 뒤 공백을 한 칸으로 접는다. 이모지 결합 문자(ZWJ)는 남긴다.
    입구(감시 PC 화면·메일 확인 링크·사내망)가 모두 같은 정리를 거친다 (재검토 rr066 lan 1). 저장 때 한 곳에서 지워 감시 화면·
    사내망·대장 엑셀이 같은 글을 보인다 — 감시 화면만 표시 때 U+202E를 대체 문자로 바꾸고 사내망·대장에는 그대로 실렸다 (rv0676 JG8)."""
    import unicodedata
    s = str(s or "")
    keep = {k for m in _EMOJI_TAG_SEQ.finditer(s) for k in range(m.start() + 1, m.end())}
    s = "".join(ch for k, ch in enumerate(s)
                if ch.isspace() or ch in _CF_KEEP or k in keep or unicodedata.category(ch) not in ("Cc", "Cf"))
    return " ".join(s.split())


def local_ack_by(name) -> str:
    """감시 PC 화면·메일 확인 링크·설정에 적은 확인자 이름 — '이름 (사내망·아이디)' 꼴이면 '(사내망·'을 '(사내망 '으로 바꿔
    사내망 확인으로 보이지 않게 한다. 거절하지 않고 바꿔 확인 자체는 남긴다 (재검토 rr066 lan 2, 출처 위장 막기)."""
    s = clean_ack_text(name)
    if _LAN_ACK.match(s):
        s = "(사내망 ".join(s.split("(사내망·"))      # str.replace는 읽기 전용 검사(test_readonly)가 막는 이름이라 split/join
    return s


def lan_ack_by(name: str, login: str) -> str:
    """사내망 확인의 '누가' 값 — 양식함 계정 이름 + 아이디."""
    n = clean_ack_text(name)[:40] or str(login)
    return f"{n} (사내망·{login})"


def ack_origin(by) -> tuple[str, str]:
    """acks.by → (보일 이름, 사내망 아이디 — 감시 PC에서 남긴 확인이면 '')."""
    s = str(by or "")
    m = _LAN_ACK.match(s)
    return (m.group("name"), m.group("login")) if m else (s, "")


def ack_label(by) -> str:
    """화면·대장에 보일 확인자 — 사내망에서 남긴 것은 '사내망에서 확인: 이름'."""
    name, login = ack_origin(by)
    return f"사내망에서 확인: {name}" if login else name


def done_label(by) -> str:
    """확인 필요 처리자(issues.resolved_by) — 사내망에서 [처리함]한 것은 '사내망에서 처리: 이름' (2026-11-23 사내망 협업).
    감시 PC 처리·자동 해소 글은 그대로."""
    name, login = ack_origin(by)
    return f"사내망에서 처리: {name}" if login else str(by or "")


def person_label(by) -> str:
    """의견을 쓴 사람·담당자·지정한 사람 — 사내망 계정이면 '이름 (사내망)', 감시 PC에서 적은 이름은 그대로 (2026-11-23)."""
    name, login = ack_origin(by)
    return f"{name} (사내망)" if login else str(by or "")


# ── 의견·담당 (2026-11-23 사내망 협업 다듬기) — 덧붙임만 ─────────────────────────────
COMMENT_MAX = 1000                # 의견 본문 글자 상한 (여러 줄)
COLLAB_TABLES = ("comments", "assignments")
COLLAB_TARGETS = ("change", "issue")


def clean_comment_text(s) -> str:
    """의견 본문 — 여러 줄. 줄마다 확인 메모와 같은 정리(clean_ack_text: 제어 문자·보이지 않는 서식 문자를 지우고 공백을 접음),
    줄바꿈은 남기되 빈 줄은 하나까지, 앞뒤 빈 줄은 뗀다. 입구(감시 화면·사내망)가 모두 이것을 거친다."""
    out: list = []
    for ln in str(s or "").splitlines():
        t = clean_ack_text(ln)
        if not t and (not out or not out[-1]):
            continue
        out.append(t)
    while out and not out[-1]:
        out.pop()
    return "\n".join(out)


@dataclass(frozen=True)
class Change:
    """파일 수준 변경 1건. old/new sha256이 '사실'의 근거다 (PRINCIPLE 4·5)."""
    kind: str  # 'added' | 'modified' | 'removed'
    path: str
    old_sha256: str | None
    new_sha256: str | None
    id: int | None = None       # DB에 기록된 뒤 부여 (확인 링크의 대상)
    project: str | None = None  # 귀속 후 set_change_project로 저장


def _proc_created(pid: int) -> int | None:
    """프로세스 생성 시각(FILETIME 정수). 없거나 모르면 None. pid는 재사용되므로
    잠금은 pid+생성 시각으로 식별한다 (2026-09-04 재검토 ②-3: 재부팅 뒤 다른 프로그램이
    같은 pid를 받으면 최대 6시간 검사가 거부되던 것)."""
    if pid <= 0 or sys.platform != "win32":
        return None
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid)              # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return None
        try:
            ft = (ctypes.c_ulonglong * 4)()
            if k32.GetProcessTimes(h, ctypes.byref(ft, 0), ctypes.byref(ft, 8),
                                   ctypes.byref(ft, 16), ctypes.byref(ft, 24)):
                return int(ft[0])
            return None
        finally:
            k32.CloseHandle(h)
    except Exception:
        return None


def _pid_alive(pid: int, created: int | None = None) -> bool:
    """그 pid의 프로세스가 살아 있고(생성 시각까지 같으면) 같은 프로세스인가.
    모르면 살아 있다고 본다(잠금을 지키는 쪽). Windows의 os.kill(pid, 0)은 프로세스를
    죽이므로 쓰지 않는다."""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, pid)          # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return k32.GetLastError() == 5               # 접근 거부 = 있긴 있다
            try:
                code = ctypes.c_ulong()
                if k32.GetExitCodeProcess(h, ctypes.byref(code)) and code.value != 259:
                    return False                             # 종료됨(핸들만 남음)
            finally:
                k32.CloseHandle(h)
        except Exception:
            return True
        if created is not None:
            now_created = _proc_created(pid)
            if now_created is not None and now_created != created:
                return False                                 # 같은 pid를 받은 다른 프로그램
        return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return True


# ── 검사 잠금 값: "pid:벽시계:생성시각:단조시계". 단조 시계(time.monotonic — Windows에서는 부팅 뒤 경과, 프로세스 사이 공통)는
# 잡은 순간과 검사 중 심장 박동(cli._lock_heartbeat)이 갱신한다. 전에는 "6시간 지났으면 PID가 살아 있어도 낡음"이라
# 6시간 넘게 도는 첫 기준선 검사·검사 중 시계가 +7h 맞춰진 PC에서 다음 검사가 잠금을 빼앗고 진행 중 스냅샷을 되돌려
# 같은 날 '변경 2건(갱신)'이 됐다 (재검토 2026-10-28 R8-1). 이제 같은 프로세스(pid+생성 시각)가 살아 있음이 확인되면
# 벽시계와 무관하게 **심장 박동이 멈춘 지** 6시간일 때만 낡음 — 잠금만 남은 창 프로세스(검토64 B2)는 여전히 풀린다.
# 생성 시각을 모르는(옛 형식·권한 없음) 잠금은 예전 규칙(벽시계 6시간) 그대로.
def lock_value(pid: int) -> str:
    mine = _proc_created(pid)
    return f"{pid}:{time.time()}:{mine if mine is not None else ''}:{time.monotonic()}"


def _lock_parts(value) -> tuple:
    """(pid, 벽시계, 생성시각|None, 단조시계|None). 못 읽으면 pid 0."""
    parts = str(value or "").split(":")
    try:
        pid, at = int(parts[0]), float(parts[1])
    except (ValueError, IndexError):
        return 0, 0.0, None, None
    try:
        created = int(parts[2]) if len(parts) > 2 and parts[2] else None
    except ValueError:
        created = None
    try:
        mono = float(parts[3]) if len(parts) > 3 and parts[3] else None
    except ValueError:
        mono = None
    return pid, at, created, mono


def _lock_live(value, stale_after: float = 6 * 3600) -> bool:
    """잠금을 쥔 검사가 아직 살아 있다고 볼 것인가 (넘겨받으면 안 되는가)."""
    pid, at, created, mono = _lock_parts(value)
    if pid <= 0 or not _pid_alive(pid, created):
        return False
    if created is not None and mono is not None and _proc_created(pid) == created:
        # 같은 프로세스가 살아 있다 = 같은 부팅 — 단조 시계를 견줄 수 있다. 음수(있을 수 없음)는 살아 있는 쪽으로
        return time.monotonic() - mono < stale_after
    return time.time() - at < stale_after


# 가장 무거운 한 줄은 watcher.summary 한 곳으로 모았다 (2026-11-17 R1) — 옛 이름은 시험·호출자가 그대로 쓴다
from watcher.summary import headline as _headline_of  # noqa: E402


_TRANSIENT_DB = ("database is locked", "database table is locked", "busy", "duplicate column",
                 "disk is full", "unable to open", "disk i/o")


def is_transient_db_error(e) -> bool:
    """손상이 아니라 잠시 쓸 수 없는 상태(다른 프로세스·동시 마이그레이션·디스크 가득)인가."""
    m = str(e).lower()
    return any(w in m for w in _TRANSIENT_DB)


class CorruptDatabase(RuntimeError):
    """state.db가 깨져 열 수 없다 — 디스크 오류·백신 격리·복사 중 끊김.

    전에는 날 sqlite3 traceback으로 예약 검사가 죽고 화면은 응답 없이 끊겨, 되살리기
    절차(도움말 '백업 · 다른 PC로 이전 · 되살리기')가 있는데도 아무도 그리로 가지
    못했다 (검토19 운영 ①). 한국어 한 줄과 절차 위치를 함께 실어 올린다."""

    def __init__(self, db_path, why: str):
        self.db_path = str(db_path)
        self.why = why
        super().__init__(
            f"이력 파일이 깨져 열 수 없습니다: {db_path} ({why}). 되살리는 순서는 도움말의 "
            f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다 — 요약: Drev를 끝내고, "
            f"state.db-wal·state.db-shm이 있으면 이름을 바꿔 치우고, backups 폴더의 "
            f"state_backup_N.db를 복사해 state.db로 이름을 바꿉니다.")


# 설정의 backup_dir(NAS 등) — load_config가 알려 준다. State는 설정을 모르지만 누가 열든(화면·검사) 같은
# 흔적을 봐야 한다: 화면이 먼저 열려 빈 DB를 만들면 다음 07:00에 수만 건 기준선이 쌓였다 (검토37 C 중간 1)
_BACKUP_DIRS: dict = {}          # state.db 절대 경로 → 설정의 backup_dir


def _db_key(db_path) -> str:
    try:
        return str(Path(db_path).resolve()).lower()
    except OSError:
        return str(db_path).lower()


def register_backup_dir(db_path, path) -> None:
    if path:
        _BACKUP_DIRS[_db_key(db_path)] = str(path)


def missing_db_evidence(db_path, backup_dir=None) -> list[str]:
    """state.db가 없는데 **있었던 흔적**(-wal·-shm, backups/·backup_dir의 주간 사본) — 있으면 사라진 것이지
    첫 설치가 아니다. 0바이트 state.db도 없어진 것으로 본다(복사가 끊긴 되살리기) (검토37 C 낮음)."""
    db = Path(db_path)
    try:
        if db.exists() and db.stat().st_size > 0:
            return []
    except OSError:
        return []
    out = [p.name for p in (db.with_name(db.name + "-wal"), db.with_name(db.name + "-shm")) if p.exists()]
    extra = {d for d in (backup_dir, _BACKUP_DIRS.get(_db_key(db))) if d}
    dirs = [(db.parent / "backups", "backups")] + [(Path(d), str(d)) for d in sorted(extra)]
    for d, label in dirs:
        try:
            out += [f"{label}/{p.name}" for p in sorted(d.glob("state_backup_*.db"))]
        except OSError:
            pass
    if out and db.exists():
        out.insert(0, f"{db.name}(0바이트)")
    return out


class MissingDatabase(CorruptDatabase):
    """state.db가 사라졌다(백신 격리·잘못된 복원·실수로 지움) — 조용히 빈 DB를 만들면 다음 검사가 수만 건
    '기준선'을 새로 쌓아 1년치 확인 기록이 이유 없이 화면에서 사라졌다 (검토34 M4·검토36 C-7)."""

    def __init__(self, db_path, evidence: list[str]):
        self.db_path = str(db_path)
        self.why = "파일 없음"
        self.evidence = list(evidence)
        RuntimeError.__init__(
            self,
            f"이력 파일이 없습니다: {db_path} — 그런데 있었던 흔적({', '.join(evidence[:5])})이 남아 있어 "
            f"새로 만들지 않고 멈춥니다. 백신이 격리했으면 격리에서 되돌리고, 아니면 backups 폴더의 "
            f"state_backup_N.db 가운데 가장 최근 것을 복사해 state.db로 이름을 바꿉니다(도움말 '백업 · 다른 PC로 "
            f"이전 · 되살리기'). 정말 처음부터 다시 시작하려면 backups 폴더와 state.db-wal·-shm의 이름을 바꿔 "
            f"치운 뒤 다시 실행하세요.")


# 검출 당시 문구가 DB에 남는다 — 옛 판(≤0.57.10)의 재저장 참고 "확인만 하면 됩니다"가 새 화면의
# "확인 대상 아님"과 한 화면에 공존했다 (검토31 A 3-4). 표시 때만 바꾼다
_OLD_NOTE_FIX = (("확인만 하면 됩니다", "확인 대상 아님 (기록만 남깁니다)"),)


def _fix_old_note(it: dict) -> dict:
    try:
        if it.get("kind") == "CHECK_SKIPPED" and isinstance(it.get("new"), str):
            new = it["new"]
            for a, b in _OLD_NOTE_FIX:
                new = b.join(new.split(a))     # (읽기 전용 가드가 replace 호출 이름을 막는다)
            if new != it["new"]:
                it = dict(it, new=new)
    except AttributeError:
        pass
    return it


def _note_in(items_json) -> str:
    """change_details.items_json의 '참고' 문구 (없으면 빈 문자열) — 옛 문구는 화면과 같게 고쳐서."""
    if isinstance(items_json, str) and "CHECK_SKIPPED" not in items_json:
        return ""                              # 큰 상세를 풀지 않는다 — 미확인 수만 건을 한 번에 읽는 곳이 있다 (ux25 F1)
    try:
        items = json.loads(items_json or "[]")
    except (ValueError, TypeError):
        return ""
    for it in items if isinstance(items, list) else ():
        if isinstance(it, dict) and it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
            return str(_fix_old_note(it).get("new") or "")
    return ""


# 확인 대상이 아닌 변경을 밀어 넣었을 때의 말 — 세 입구가 같은 말을 한다 (State.ack_exempt)
ACK_EXEMPT_TEXT = {"first": "첫 등록은 확인 대상이 아니라 기록만 남깁니다",
                   "quiet": "이동·재저장·복사본은 확인 대상이 아니라 기록만 남깁니다"}
ACK_REPEAT_SECONDS = 5           # 이 안에 같은 사람·같은 메모가 또 오면 두 번 누른 것 (ux24 AK5)


class RevBump(NamedTuple):
    """최근 Rev 올림의 근거 — 검사 시각(ISO)·그 변경 id·이전 Rev·새 Rev."""
    at: str
    change_id: int
    old: str
    new: str


ROLLED_BACK_KEY = "rolled_back_changes"   # 되돌린 변경·그 확인 (검토39 P5 차단 2)
MOVED_IDS_KEY = "moved_change_ids"        # 되돌렸다 다시 잡힌 변경: 옛 번호 → 새 번호


_PAREN_CODES = ("TAG_MISMATCH_ACROSS_DRAWINGS", "REV_BLOCK_MISMATCH")
_VALUE_CODES = ("BOM_MISMATCH",) + _PAREN_CODES     # 닫힌 이슈의 근거·문구를 값 비교용으로 남기는 코드



# 추출기 묶음 — 같은 바이트라도 확장자가 다르면 다른 추출기가 읽는다 (F2). 문서 종류(doc_type) → 묶음
_EXT_GROUP = {".dxf": "dxf", ".dwg": "dwg", ".pdf": "pdf", ".xlsx": "xlsx", ".xlsm": "xlsx", ".docx": "docx", ".hwpx": "docx"}
_TYPE_GROUP = {"hwpx": "docx"}


def extract_group(path) -> str | None:
    import os.path as _op
    return _EXT_GROUP.get(_op.splitext(str(path or ""))[1].lower())

class State:
    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        gone = missing_db_evidence(self.db_path)
        if gone:
            raise MissingDatabase(self.db_path, gone)
        # 웹서버(다중 스레드)와 검사 스레드가 같은 DB를 쓴다 — WAL이면 읽기가
        # 긴 쓰기(캡처 수 MB 저장)에 막히지 않고, busy_timeout으로 잠금 충돌을
        # 재시도한다 (2026-08-26 리뷰: 'database is locked' 예방)
        self.conn = sqlite3.connect(self.db_path, timeout=15)
        # 여는 도중 어디서든 터지면 **연결을 닫고** 올린다. 열린 채로 두면 윈도우가
        # 그 파일을 잡아, 되살리려고 이름을 바꾸는 것조차 WinError 32로 막힌다
        # (2026-09-09 저장 검토 낮음 9b — 깨진 DB에서 실측)
        try:
            mode = self.conn.execute("PRAGMA journal_mode=WAL").fetchone()[0]
            if str(mode).lower() != "wal":  # 전환 실패는 예외가 아니라 반환값으로만 알린다
                print(f"경고: state.db WAL 전환 실패(현재 {mode}) — 동시 접근 시 "
                      f"잠금 오류 가능", file=sys.stderr)
            if str(self.db_path).startswith("\\\\"):
                print("경고: state.db가 네트워크 경로에 있습니다 — SQLite WAL은 "
                      "네트워크 드라이브에서 신뢰할 수 없습니다(손상 위험). "
                      "이 PC의 로컬 경로를 권장합니다.", file=sys.stderr)
            self.conn.execute("PRAGMA busy_timeout=15000")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.executescript(_SCHEMA)
        except sqlite3.DatabaseError as e:
            try:
                self.conn.close()
            except Exception:
                pass
            # 잠김·바쁨·디스크 가득은 손상이 아니다 — 원래 오류로 올려 cli가 '다시 실행' 안내를 하게 한다.
            # 여기서 감싸면 멀쩡한 DB에 백업을 덮으라는 안내가 나갔다 (검토36 C-2: 동시 열기 20회 중 8회)
            if is_transient_db_error(e):
                raise
            raise CorruptDatabase(self.db_path, str(e)) from e
        except BaseException:
            try:
                self.conn.close()
            except Exception:
                pass
            raise
        # Stage 4 이전에 만든 DB 마이그레이션: changes.project 열 추가
        cols = [r[1] for r in self.conn.execute("PRAGMA table_info(changes)")]
        if "project" not in cols:
            self._add_column("ALTER TABLE changes ADD COLUMN project TEXT")
        # 2026-09-17: 변경 기록에 그 판·이전 판의 파일 저장 시각 — files는 최신 스냅샷만 남아(prune)
        # 다음 날 '저장' 칸이 사라지고 옛 변경 상세가 지금 파일의 시각을 보였다 (검토26 5회차 B1)
        if "mtime" not in cols:
            self._add_column("ALTER TABLE changes ADD COLUMN mtime REAL")
            self._add_column("ALTER TABLE changes ADD COLUMN old_mtime REAL")
            # 남아 있는 스냅샷 기록으로 채울 수 있는 만큼만 채운다 (빈 칸만 — 있는 값은 고치지 않는다, 기록 불변 허용 목록)
            self.conn.execute(
                "UPDATE changes SET mtime = (SELECT f.mtime FROM files f "
                "WHERE f.snapshot_id = changes.snapshot_id AND f.path = changes.path) WHERE mtime IS NULL")
        # 2026-11-17 R1: 변경마다 귀속 근거 — 부호(project_how)와 귀속기 출처 글(project_why). 옛 행은 NULL = '모름'
        if "project_how" not in cols:
            self._add_column("ALTER TABLE changes ADD COLUMN project_how TEXT")
        if "project_why" not in cols:
            self._add_column("ALTER TABLE changes ADD COLUMN project_why TEXT")
        # 합치기 되돌리기가 귀속 근거까지 돌려놓게 — 옛 합치기 줄은 NULL(모름)로 돌아간다
        mcols = [r[1] for r in self.conn.execute("PRAGMA table_info(project_merge_rows)")]
        if "old_how" not in mcols:
            self._add_column("ALTER TABLE project_merge_rows ADD COLUMN old_how TEXT")
            self._add_column("ALTER TABLE project_merge_rows ADD COLUMN old_why TEXT")
        # v0.14 마이그레이션: 이슈 해소(닫기) 기록 — 없으면 빨간 숫자가 영원히 쌓인다
        icols = [r[1] for r in self.conn.execute("PRAGMA table_info(issues)")]
        if "resolved_at" not in icols:
            self._add_column("ALTER TABLE issues ADD COLUMN resolved_at TEXT")
            self._add_column("ALTER TABLE issues ADD COLUMN resolved_by TEXT")
        # 검토43 B 중간 8: 사람이 닫은 교차 이슈가 검사에서 **사라졌던** 시각 — 그 뒤 같은 값으로 다시 나오면 재발
        if "gone_at" not in icols:
            self._add_column("ALTER TABLE issues ADD COLUMN gone_at TEXT")
        # v0.19 마이그레이션: 상세 항목 오탐 숨김(복원 가능) 기록
        dcols = [r[1] for r in self.conn.execute("PRAGMA table_info(change_details)")]
        if "dismissed_json" not in dcols:
            self._add_column("ALTER TABLE change_details ADD COLUMN dismissed_json TEXT")
        # v0.21 마이그레이션: 사람이 직접 추가한 '놓친 변경' 기록 (미탐 보완)
        if "user_notes_json" not in dcols:
            self._add_column("ALTER TABLE change_details ADD COLUMN user_notes_json TEXT")
        # 재검토 rr066 judge 2: 출도본의 귀속 — 키가 도면번호뿐이라 다른 프로젝트의 같은 번호 원본을 잇었다. 옛 행은 NULL로 남고
        # 대조 때 같은 감시 폴더 첫 마디(경로 앞 두 마디)로 본다 (watcher.issued._same_scope)
        if "project" not in [r[1] for r in self.conn.execute("PRAGMA table_info(issued_copies)")]:
            self._add_column("ALTER TABLE issued_copies ADD COLUMN project TEXT")
        for stmt in _INDEXES:
            try:
                self.conn.execute(stmt)
            except Exception:      # 색인 하나가 안 만들어져도 프로그램은 돌아야 한다
                pass
        self.conn.commit()
        self._note_rule_gen()

    def _note_rule_gen(self) -> None:
        """판(검사 규칙 세대)이 바뀐 뒤 처음 열 때, 그때 열려 있던 교차 '검토 필요'를 재판정 대기로 적는다 — 옛 판이 낸 거짓
        양성(옛 추출기 오류의 'MOTOR vs 5.5kW')은 새 판이 다시 잡지 않는데, 인용 파일이 안 바뀌면 열어 두는 규칙(검토54)
        때문에 영영 열려 있었다 (재검토 2026-10-28 R7-D2). 대기 중인 것은 그 프로젝트를 다음에 검사할 때 한 번만, 인용
        파일 미변경 규칙 없이 판정한다. 잠겨 있으면 다음에 열 때 다시 — 화면을 막지 않게 짧게만 기다린다."""
        from watcher import __version__
        try:
            row = self.conn.execute("SELECT value FROM meta WHERE key = ?", (ISSUE_RULE_GEN_KEY,)).fetchone()
            if row and row[0] == __version__:
                return
            ids = {r_[0] for r_ in self.conn.execute(
                "SELECT id FROM issues WHERE resolved_at IS NULL "
                "AND code IN ('TAG_MISMATCH_ACROSS_DRAWINGS', 'BOM_MISMATCH')")}
            self.conn.execute("PRAGMA busy_timeout=1000")
            try:
                self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                                  (ISSUE_REJUDGE_KEY, json.dumps(sorted(ids | self._rejudge_ids()))))
                self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                                  (ISSUE_RULE_GEN_KEY, __version__))
                if row and row[0]:
                    # 판이 바뀌었다 — 그 뒤 첫 교차 검사들이 파일 변경 없이 낸 검토 필요는 '프로그램 업데이트로 다시 판정한 것'으로
                    # 따로 묶는다(기능 검토 2026-11-02 J4). 처음 만든 DB(row 없음)는 판 올림이 아니다
                    self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                                      (RULE_BUMP_KEY, json.dumps({"from": row[0], "to": __version__,
                                                                  "at": datetime.now(timezone.utc).isoformat()})))
                self.conn.commit()
            finally:
                self.conn.execute("PRAGMA busy_timeout=15000")
        except sqlite3.Error:
            try:
                self.conn.rollback()
            except sqlite3.Error:
                pass

    def _rejudge_ids(self) -> set:
        try:
            v = json.loads(self.get_meta(ISSUE_REJUDGE_KEY) or "[]")
            return {int(x) for x in v} if isinstance(v, list) else set()
        except (ValueError, TypeError, sqlite3.Error):
            return set()

    def _add_column(self, sql: str) -> None:
        """마이그레이션의 열 추가 — 다른 프로세스(예약 검사·창)가 같은 순간 먼저 더했으면 그대로 둔다.
        확인 뒤 ALTER 사이가 원자적이지 않아 동시 열기에서 duplicate column으로 죽었고, 그것이 '손상'
        안내로 이어졌다 (검토34 C M6·검토36 C-2)."""
        try:
            self.conn.execute(sql)
        except sqlite3.OperationalError as e:
            if "duplicate column" not in str(e).lower():
                raise

    @classmethod
    def attach(cls, conn: sqlite3.Connection, db_path) -> "State":
        """이미 연 연결에 State 메서드만 붙인다 — 스키마 만들기·이주·메타 적기를 하지 않는다 (2026-11-02 갈래 N).
        양식함 서버의 사내망 변경 확인이 감시 기록을 읽고 확인(acks) 한 줄만 쓰려고 쓴다 — 표가 없으면 그 메서드가 오류를 낸다."""
        self = cls.__new__(cls)
        self.db_path = Path(db_path)
        self.conn = conn
        return self

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "State":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def _row_group_of(self, key: str) -> str | None:
        """저장된 추출 기록의 추출기 묶음 — 없거나 모르면 None."""
        try:
            row = self.conn.execute(
                "SELECT json_extract(doc_json, '$.ext_kind'), json_extract(doc_json, '$.doc_type') "
                "FROM extracts WHERE sha256 = ?", (key,)).fetchone()
        except sqlite3.OperationalError:
            raise
        except sqlite3.DatabaseError:
            return None
        if not row:
            return None
        g = row[0] or row[1]
        return _TYPE_GROUP.get(g, g) if g else None

    def save_extract(self, sha256: str, doc_dict: dict, path: str | None = None) -> None:
        """추출 결과를 내용 해시 기준으로 저장. 나중에 구버전과의 내용 비교에 쓴다.
        path를 주면 추출기 묶음(확장자)을 함께 적고, 같은 바이트가 **다른 묶음**으로 이미 저장돼 있으면 'sha:묶음' 열쇠에 따로
        둔다 — PDF 바이트를 담은 .dxf가 PDF 추출본을 받아 도면으로 귀속됐다 (고장 주입 2026-10-26 F2)."""
        now = datetime.now(timezone.utc).isoformat()
        key = sha256
        if path:
            want = extract_group(path)
            if want:
                doc_dict = {**doc_dict, "ext_kind": want}
                have = self._row_group_of(sha256)
                if have and have != want:
                    key = f"{sha256}:{want}"
        self.conn.execute(
            "INSERT OR REPLACE INTO extracts (sha256, doc_json, extracted_at) VALUES (?, ?, ?)",
            (key, json.dumps(doc_dict, ensure_ascii=False), now))
        self.conn.commit()

    def load_extract(self, sha256: str | None, path: str | None = None) -> dict | None:
        """내용 해시의 추출 기록. path를 주면 그 확장자의 추출기 묶음과 맞는 기록만 — 다른 묶음 기록뿐이면 None(다시 추출).
        묶음 표시가 없는 옛 기록(실패 기록 등)은 그대로 쓴다 — 판올림 뒤 재추출 폭주가 없게."""
        d = self._load_extract_key(sha256)
        if d is None or not path:
            return d
        want = extract_group(path)
        g = d.get("ext_kind") or d.get("doc_type")
        g = _TYPE_GROUP.get(g, g) if g else None
        if not want or not g or g == want:
            return d
        return self._load_extract_key(f"{sha256}:{want}")

    def _load_extract_key(self, sha256: str | None) -> dict | None:
        if not sha256:
            return None
        # 추출 기록은 다시 만들 수 있는 캐시다 — 한 행·한 페이지가 손상되면 예외가 검사 전체를 '보고 단계 실패'로 매일
        # 되돌렸다 (검토60 ② 차단). 못 읽으면 '기록 없음'으로 보고 다시 추출하게 한다(손상 사실은 남긴다)
        try:
            row = self.conn.execute(
                "SELECT doc_json FROM extracts WHERE sha256 = ?", (sha256,)).fetchone()
            return json.loads(row[0]) if row else None
        except sqlite3.OperationalError:
            raise                 # 잠김('database is locked')은 손상이 아니다 — 기록 없음으로 보면 비교를 영영 잃는다 (검토63 B-S4)
        except (sqlite3.DatabaseError, ValueError, TypeError) as e:
            self.extract_read_errors = getattr(self, "extract_read_errors", 0) + 1
            self.extract_read_error_why = f"{type(e).__name__}: {e}"
            try:
                self.conn.execute("DELETE FROM extracts WHERE sha256 = ?", (sha256,))
            except sqlite3.DatabaseError:
                pass
            return None

    def latest_snapshot(self) -> dict[str, str]:
        """가장 최근 스냅샷: {path: sha256}. 없으면 빈 dict."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return {}
        return dict(self.conn.execute(
            "SELECT path, sha256 FROM files WHERE snapshot_id = ?", (row[0],)))

    def side_notes(self, limit: int = 500) -> dict:
        """복사본·빈 파일 같은 '참고' 메모가 달린 변경 → 문구 (목록 표시용).

        상세를 열지 않고도 훑으며 거를 수 있게 (2026-09-01 처음 쓰는 사람 점검)."""
        import json
        out = {}
        rows = self.conn.execute(
            "SELECT change_id, items_json FROM change_details "
            "WHERE items_json LIKE '%CHECK_SKIPPED%' "
            "ORDER BY change_id DESC LIMIT ?", (limit,)).fetchall()
        for cid, js in rows:
            try:
                for it in json.loads(js):
                    if it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
                        out[cid] = _fix_old_note(it).get("new") or ""
                        break
            except (ValueError, TypeError):
                continue
        return out

    def project_files(self, project: str, limit: int = 0) -> list[str]:
        """그 프로젝트로 잡힌 파일 경로 (중복 제거)."""
        rows = self.conn.execute(
            "SELECT DISTINCT path FROM changes WHERE IFNULL(project,'미분류') = ?"
            " ORDER BY path", (project,)).fetchall()
        paths = [r[0] for r in rows]
        return paths[:limit] if limit else paths

    def merge_projects(self, into: str, sources, path_prefix: str | None = None) -> dict:
        """여러 이름으로 갈린 같은 프로젝트를 대표 이름 하나로 모은다.

        바꾸기 전 값을 project_merge_rows에 남겨 되돌릴 수 있게 한다 — 잘못
        합쳤을 때 원래대로가 없으면 사람이 손댈 방법이 없다 (PRINCIPLE 5)."""
        srcs = [x for x in dict.fromkeys(sources) if x and x != into]
        if not srcs:
            return {"merge_id": 0, "changes": 0, "issues": 0}
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute(
            "INSERT INTO project_merges (at, into_p, sources) VALUES (?, ?, ?)",
            (now, into, "\n".join(srcs)))
        mid = cur.lastrowid
        marks = ",".join("?" * len(srcs))
        # 감시 폴더 하나를 '프로젝트 하나로' 묶을 때는 그 폴더 아래만 — 경로 조건
        # 없이 이름만으로 바꾸면 다른 폴더의 같은 이름(미분류 포함) 이력까지 편입된다
        # (2026-09-02 검토에서 확인). LIKE 대신 접두어 비교: 라벨의 _·%가 와일드카드가
        # 되지 않게
        scope, extra = "", ()
        if path_prefix:
            scope, extra = " AND substr(path, 1, ?) = ?", (len(path_prefix), path_prefix)
        counts = {}
        for kind, table in (("change", "changes"), ("issue", "issues")):
            # 변경은 귀속 근거도 함께 맡겨 둔다 — 되돌리면 원래 근거까지 돌아오게 (2026-11-17 R1)
            hw = ", project_how, project_why" if kind == "change" else ", NULL, NULL"
            rows = self.conn.execute(
                f"SELECT id, IFNULL(project,'미분류'){hw} FROM {table} "
                f"WHERE IFNULL(project,'미분류') IN ({marks}){scope}",
                tuple(srcs) + extra).fetchall()
            self.conn.executemany(
                "INSERT INTO project_merge_rows (merge_id, kind, row_id, old_p, old_how, old_why) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                [(mid, kind, rid, old, oh, ow) for rid, old, oh, ow in rows])
            if kind == "change":
                self.conn.executemany(
                    "UPDATE changes SET project = ?, project_how = 'merge', project_why = ? WHERE id = ?",
                    [(into, f"프로젝트 합치기 ({old} → {into})", rid) for rid, old, _oh, _ow in rows])
                self._log_project([(rid, into, "merge", f"프로젝트 합치기 ({old} → {into})") for rid, old, _oh, _ow in rows],
                                  at=now)
            else:
                self.conn.executemany(
                    f"UPDATE {table} SET project = ? WHERE id = ?",
                    [(into, rid) for rid, *_ in rows])
            counts[kind] = len(rows)
        self.conn.commit()
        return {"merge_id": mid, "changes": counts["change"],
                "issues": counts["issue"]}

    def undo_merge(self, merge_id: int) -> int:
        """합치기 되돌리기 — 그때 바꾼 행만 원래 이름으로 돌려놓는다."""
        rows = self.conn.execute(
            "SELECT kind, row_id, old_p, old_how, old_why FROM project_merge_rows "
            "WHERE merge_id = ?", (merge_id,)).fetchall()
        back = []
        for kind, rid, old, oh, ow in rows:
            if kind == "change":
                n_ = self.conn.execute("UPDATE changes SET project = ?, project_how = ?, project_why = ? WHERE id = ?",
                                       (old, oh, ow, rid)).rowcount
                if n_:
                    back.append((rid, old, oh, ow))
            else:
                self.conn.execute("UPDATE issues SET project = ? WHERE id = ?", (old, rid))
        self._log_project(back, by="합치기 되돌림")
        self.conn.execute("DELETE FROM project_merge_rows WHERE merge_id = ?",
                          (merge_id,))
        self.conn.execute("DELETE FROM project_merges WHERE id = ?", (merge_id,))
        self.conn.commit()
        return len(rows)

    def merges(self, limit: int = 20) -> list[dict]:
        """최근 합치기 이력 (되돌리기 버튼용)."""
        out = []
        for mid, at, into, srcs in self.conn.execute(
                "SELECT id, at, into_p, sources FROM project_merges "
                "ORDER BY id DESC LIMIT ?", (limit,)):
            n = self.conn.execute(
                "SELECT COUNT(*) FROM project_merge_rows WHERE merge_id = ?",
                (mid,)).fetchone()[0]
            out.append({"merge_id": mid, "at": at, "into": into,
                        "sources": srcs.split("\n"), "rows": n})
        return out

    def prefix_stats(self, label: str) -> dict:
        """감시 폴더 라벨 아래의 기록 개수 — 지우기 전에 사람에게 보여준다."""
        pre = label + "/"          # LIKE는 _·%를 와일드카드로 본다 — 접두어 비교
        files = self.conn.execute(
            "SELECT COUNT(DISTINCT path) FROM files WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        # 변경 id를 전부 파이썬으로 끌어와 IN (?,…)로 묶으면 32,766개에서
        # "too many SQL variables"로 이 화면이 통째로 죽는다 — 하루 30건이면 3년이다
        # (2026-09-09 저장 검토 차단 2). 전부 서브질의로 바꾼다
        n_changes = self.conn.execute(
            "SELECT COUNT(*) FROM changes WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        acks = self.conn.execute(
            "SELECT COUNT(*) FROM acks WHERE change_id IN "
            "(SELECT id FROM changes WHERE substr(path,1,?) = ?)",
            (len(pre), pre)).fetchone()[0]
        issues = self.conn.execute(
            "SELECT COUNT(*) FROM issues WHERE substr(path,1,?) = ?",
            (len(pre), pre)).fetchone()[0]
        return {"files": files, "changes": n_changes, "acks": acks, "issues": issues}

    def purge_prefix(self, label: str, by: str = "") -> dict:
        """감시 폴더 라벨 아래의 **기록**을 숨긴다 — 변경·상세·확인·검토 필요는 지우지 않고 숨긴 기록으로 옮겨(되살릴 수
        있음) 화면·메일·대장·수 세기에서 뺀다 (2026-11-17 R1, DECISIONS 같은 날 — 전에는 DELETE). 파일 목록(스냅샷)·내용
        단서·'첫 검사' 표식은 기록이 아니라 검사 상태라 지운다 — 다시 넣으면 그때가 첫 검사(기준선)다. 감시 대상 파일은
        건드리지 않는다 (PRINCIPLE 2)."""
        stats = self.prefix_stats(label)
        pre = label + "/"
        h = self._hide_records("prefix", label, "substr(path,1,?) = ?", (len(pre), pre), by=by)
        stats = {**stats, "hide_id": h["hide_id"]}
        self.conn.execute("DELETE FROM files WHERE substr(path,1,?) = ?", (len(pre), pre))
        self.conn.execute("DELETE FROM doc_hints WHERE substr(path,1,?) = ?", (len(pre), pre))
        # 라벨의 '첫 검사' 기록도 지운다 — 다시 넣으면 그때가 첫 검사(기준선)다
        try:
            fs = json.loads(self.get_meta("root_first_seen") or "{}")
            kl = json.loads(self.get_meta("known_labels") or "[]")
            fs.pop(label, None)
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('root_first_seen', ?)",
                              (json.dumps(fs, ensure_ascii=False),))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('known_labels', ?)",
                              (json.dumps(sorted(set(kl) - {label}), ensure_ascii=False),))
        except (ValueError, TypeError):
            pass
        self.conn.commit()
        return stats

    def save_hint(self, path: str, sha256: str, hint) -> None:
        """내용 단서 저장 — 없으면(None) 지운다 (2026-09-02)."""
        if hint is None:
            self.conn.execute("DELETE FROM doc_hints WHERE path = ?", (path,))
            return
        self.conn.execute(
            "INSERT OR REPLACE INTO doc_hints (path, sha256, kind, why) "
            "VALUES (?, ?, ?, ?)", (path, sha256, hint[0], hint[1]))

    def backfill_hints(self, compute) -> int:
        """내용 단서가 없는 최신 스냅샷 파일에 대해, 캐시된 추출본으로 단서를 만든다.

        단서는 원래 검사 때 생기므로 업데이트 직후엔 비어 있다 — 다음 검사까지
        기다리지 않게 한 번 소급한다 (2026-09-02). compute(추출본 dict) → (유형, 근거)|None.
        돌려주는 값: 새로 만든 단서 수."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return 0
        # 스냅샷당 한 번만 — 단서 없는 파일은 doc_hints에 흔적이 없어 매 시작마다
        # 4만 추출본을 다시 파싱하고 있었다 (2026-09-02 검토). 검사가 돌면 검사가
        # 직접 단서를 만들므로 소급은 그 전 한 번이면 된다
        done = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'hints_backfill_snapshot'").fetchone()
        if done and str(done[0]) == str(row[0]):
            return 0
        have = {p for (p,) in self.conn.execute("SELECT path FROM doc_hints")}
        made = 0
        pending = [(p, s) for p, s in self.conn.execute(
            "SELECT path, sha256 FROM files WHERE snapshot_id = ?", (row[0],))
            if p not in have]
        for i, (path, sha) in enumerate(pending, 1):
            cached = self.load_extract(sha, path)
            if cached and cached.get("extract_failed") is None:
                hint = compute(cached)
                if hint:
                    self.save_hint(path, sha, hint)
                    made += 1
            if i % 500 == 0:
                self.conn.commit()        # 쓰기 잠금을 오래 쥐지 않는다
        self.conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES ('hints_backfill_snapshot', ?)",
            (str(row[0]),))
        self.conn.commit()
        return made

    def hints(self) -> dict:
        """{경로: (유형, 근거)} — 화면이 유형을 판별할 때 함께 본다."""
        return {p: (k, w) for p, k, w in
                self.conn.execute("SELECT path, kind, why FROM doc_hints")}

    def delete_project(self, project: str, by: str = "") -> dict:
        """프로젝트의 **기록**을 숨긴다 — 변경 이력·상세·확인·검토 필요를 지우지 않고 숨긴 기록으로 옮긴다. 화면·메일·대장·
        수 세기에서 빠지고, [숨긴 기록]에서 같은 번호로 되살릴 수 있다 (2026-11-17 R1, DECISIONS 같은 날 — 전에는 DELETE로
        되돌릴 수 없었다). 감시 대상 파일은 건드리지 않는다(원칙 2). 잘못 묶인 프로젝트를 화면에서 치우기 위한 것 (2026-09-01).
        이름은 옛 호출자 그대로 둔다."""
        # 값을 IN (?,…)로 묶지 않는다 — 32,766건에서 죽었다 (2026-09-09 저장 검토 차단 2)
        n_changes = self.conn.execute(
            "SELECT COUNT(*) FROM changes WHERE IFNULL(project,'미분류') = ?", (project,)).fetchone()[0]
        if not n_changes:
            return {"changes": 0, "acks": 0, "issues": 0}
        self.conn.execute(
            "DELETE FROM doc_hints WHERE path IN "
            "(SELECT path FROM changes WHERE IFNULL(project,'미분류') = ?)", (project,))
        h = self._hide_records("project", project, "IFNULL(project,'미분류') = ?", (project,), by=by)
        return {"changes": h["changes"], "acks": h["acks"], "issues": h["issues"], "hide_id": h["hide_id"]}

    # ── 숨긴 기록 (2026-11-17 R1) — 프로젝트 정리·감시 폴더 기록 정리. 행을 '<표>_hidden'으로 그대로 옮긴다(값·번호 불변)
    _HIDE_TABLES = ("change_details", "acks", "changes", "issues")

    def _mirror(self, tbl: str) -> list:
        """'<표>_hidden'을 만들고(없으면) 원래 표의 칸을 모두 갖추게 한다. 옮길 칸 이름 목록을 돌려준다."""
        cols = [r_[1] for r_ in self.conn.execute(f"PRAGMA table_info({tbl})")]
        self.conn.execute(f"CREATE TABLE IF NOT EXISTS {tbl}_hidden AS SELECT * FROM {tbl} WHERE 0")
        have = {r_[1] for r_ in self.conn.execute(f"PRAGMA table_info({tbl}_hidden)")}
        if "hide_id" not in have:
            self.conn.execute(f"ALTER TABLE {tbl}_hidden ADD COLUMN hide_id INTEGER")
        for c in cols:
            if c not in have:
                self.conn.execute(f'ALTER TABLE {tbl}_hidden ADD COLUMN "{c}"')
        return cols

    def _hide_records(self, kind: str, target: str, cond: str, args: tuple, by: str = "") -> dict:
        """cond(changes·issues의 WHERE 조각)에 맞는 변경과 그 상세·확인, 검토 필요를 숨긴 기록으로 옮긴다 — 한 트랜잭션."""
        now = datetime.now(timezone.utc).isoformat()
        with self._immediate():
            hid = self.conn.execute("INSERT INTO record_hides (at, kind, target, by) VALUES (?, ?, ?, ?)",
                                    (now, kind, target, by or None)).lastrowid
            sub = f"(SELECT id FROM changes WHERE {cond})"
            where = {"change_details": (f"change_id IN {sub}", args), "acks": (f"change_id IN {sub}", args),
                     "changes": (cond, args), "issues": (cond, args)}
            counts = {}
            for tbl in self._HIDE_TABLES:          # 상세·확인을 먼저 — 변경을 옮기면 서브질의가 비어 버린다
                cols = self._mirror(tbl)
                cl = ", ".join(f'"{c}"' for c in cols)
                w, a_ = where[tbl]
                cur = self.conn.execute(f"INSERT INTO {tbl}_hidden (hide_id, {cl}) SELECT ?, {cl} FROM {tbl} WHERE {w}",
                                        (hid,) + tuple(a_))
                counts[tbl] = cur.rowcount or 0
                self.conn.execute(f"DELETE FROM {tbl} WHERE {w}", tuple(a_))
            out = {"changes": counts["changes"], "acks": counts["acks"], "issues": counts["issues"]}
            self.conn.execute("UPDATE record_hides SET counts = ? WHERE id = ?", (json.dumps(out), hid))
        return {**out, "hide_id": hid}

    def hidden_records(self, include_restored: bool = False) -> list[dict]:
        """숨긴 기록 묶음 (최신순) — [숨긴 기록] 화면·되살리기용. 표가 없는 옛 DB는 빈 목록."""
        try:
            rows = self.conn.execute(
                "SELECT id, at, kind, target, by, counts, restored_at FROM record_hides "
                + ("" if include_restored else "WHERE restored_at IS NULL ") + "ORDER BY id DESC").fetchall()
        except sqlite3.OperationalError:
            return []
        out = []
        for hid, at, kind, target, by, counts, restored in rows:
            try:
                c = json.loads(counts or "{}")
            except ValueError:
                c = {}
            out.append({"hide_id": hid, "at": at, "kind": kind, "target": target, "by": by,
                        "changes": int(c.get("changes") or 0), "acks": int(c.get("acks") or 0),
                        "issues": int(c.get("issues") or 0), "restored_at": restored})
        return out

    def restore_hidden(self, hide_id: int) -> dict:
        """숨긴 기록 묶음을 같은 번호·같은 값으로 되살린다. 돌려주는 값: 되살린 수 (없는 묶음이면 changes 0)."""
        out = {"changes": 0, "acks": 0, "issues": 0}
        try:
            row = self.conn.execute("SELECT restored_at FROM record_hides WHERE id = ?", (int(hide_id),)).fetchone()
        except (sqlite3.OperationalError, ValueError, TypeError):
            return out
        if row is None or row[0]:
            return out
        back_issues: list = []
        with self._immediate():
            for tbl in ("changes", "change_details", "acks", "issues"):
                try:
                    have = {r_[1] for r_ in self.conn.execute(f"PRAGMA table_info({tbl}_hidden)")}
                except sqlite3.OperationalError:
                    continue
                if not have:
                    continue
                cols = [r_[1] for r_ in self.conn.execute(f"PRAGMA table_info({tbl})") if r_[1] in have]
                cl = ", ".join(f'"{c}"' for c in cols)
                if tbl == "issues" and "id" in have:
                    back_issues = [r_[0] for r_ in self.conn.execute(
                        "SELECT id FROM issues_hidden WHERE hide_id = ?", (int(hide_id),))]
                cur = self.conn.execute(f"INSERT OR IGNORE INTO {tbl} ({cl}) SELECT {cl} FROM {tbl}_hidden WHERE hide_id = ?",
                                        (int(hide_id),))
                if tbl in out:
                    out[tbl] = cur.rowcount or 0
                self.conn.execute(f"DELETE FROM {tbl}_hidden WHERE hide_id = ?", (int(hide_id),))
            now = datetime.now(timezone.utc).isoformat()
            out["replaced"] = self._close_restored_twins(back_issues, now)
            self.conn.execute("UPDATE record_hides SET restored_at = ? WHERE id = ?", (now, int(hide_id)))
        return out

    def _close_restored_twins(self, back_ids, now: str) -> int:
        """되살린 열린 검토 필요 가운데, 숨긴 동안 같은 열쇠(issue_key)로 새로 열린 것이 있는 옛 것을 닫는다 — 같은 사실의 열린 카드가
        둘이 되고 옛 근거(7.5kW)가 영원히 남았다 (독립 검토 2026-11-17 V1-5). 지우지 않고 닫기만 한다(값·근거 불변). 돌려주는 값: 닫은 수."""
        back = {int(i) for i in back_ids or ()}
        if not back:
            return 0
        try:
            rows = self.conn.execute(
                "SELECT id, code, path, message FROM issues WHERE resolved_at IS NULL ORDER BY id").fetchall()
        except sqlite3.OperationalError:
            return 0
        newer: dict = {}
        for iid, code, path, msg in rows:
            if iid not in back:
                newer.setdefault(self.issue_key(code, path, msg), iid)
        n = 0
        for iid, code, path, msg in rows:
            twin = newer.get(self.issue_key(code, path, msg)) if iid in back else None
            if twin is not None:
                self.conn.execute(
                    "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ? AND resolved_at IS NULL",
                    (now, f"자동 해소 — 숨긴 동안 같은 확인 필요가 새로 열려 그것으로 대체 (#{twin})", iid))
                n += 1
        return n

    # ── 페이지 그림 기록 (render.py) — 같은 이름으로 덮어써진 도면의 '이전 판'
    # 그림. 파일은 사라져도 이 기록으로 전/후 그림 비교를 한다 (2026-09-02)

    def save_renders(self, sha256: str, pages) -> None:
        self.conn.execute("DELETE FROM renders WHERE sha256 = ?", (sha256,))
        self.conn.executemany(
            "INSERT INTO renders (sha256, page, width, height, meta, png) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [(sha256, i, float(pg.width_pt), float(pg.height_pt),
              json.dumps(pg.meta), pg.png) for i, pg in enumerate(pages, 1)])
        self.conn.commit()

    def has_renders(self, sha256: str | None) -> bool:
        if not sha256:
            return False
        return self.conn.execute(
            "SELECT 1 FROM renders WHERE sha256 = ? LIMIT 1", (sha256,)).fetchone() is not None

    def load_renders(self, sha256: str | None):
        """PageRender 목록. 기록이 없으면 None."""
        if not sha256:
            return None
        from watcher.render import PageRender
        rows = self.conn.execute(
            "SELECT width, height, meta, png FROM renders WHERE sha256 = ? ORDER BY page",
            (sha256,)).fetchall()
        if not rows:
            return None
        return [PageRender(w, h, bytes(png), json.loads(meta or "{}"))
                for w, h, meta, png in rows]

    def prune_renders(self, keep_days: int = 90, now: datetime | None = None) -> int:
        """최신 스냅샷에 없는 판의 그림을 지운다 (도면 1장 ≈ 100~300KB, 누적 방지).
        단, 변경에서 '이전 판'이었던 그림은 keep_days(=설정의 보존 기간) 동안 남긴다 —
        같은 이름으로 덮어쓴 도면의 '전/후 나란히 보기'용. 0이면 무기한 (2026-09-03:
        "몇 달 뒤 변경도 비교되나" — 현재 판 그림은 원래 기한이 없고, 이것은 지나간
        판을 나중에 다시 열어볼 때의 기한이다. 보존 기간 설정 하나로 통일)."""
        if keep_days and keep_days > 0:
            cutoff = ((now or datetime.now(timezone.utc)) - timedelta(days=keep_days)).isoformat()
            ref = "SELECT old_sha256 FROM changes WHERE detected_at >= ? AND old_sha256 IS NOT NULL"
            params: tuple = (cutoff,)
        else:
            ref = "SELECT old_sha256 FROM changes WHERE old_sha256 IS NOT NULL"
            params = ()
        cur = self.conn.execute(
            "DELETE FROM renders WHERE sha256 NOT IN ("
            " SELECT sha256 FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots))"
            f" AND sha256 NOT IN ({ref})", params)
        self.conn.commit()
        return cur.rowcount

    def _latest_rows(self) -> dict[str, tuple]:
        """최근 스냅샷의 전체 행: {path: (sha256, size, mtime)}."""
        row = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        if row[0] is None:
            return {}
        return {p: (s, sz, mt) for p, s, sz, mt in self.conn.execute(
            "SELECT path, sha256, size, mtime FROM files WHERE snapshot_id = ?", (row[0],))}

    def record_run(self, records: list[FileRecord],
                   carry_paths: tuple | list = (),
                   known_prefixes: list[str] | None = None,
                   scanned_prefixes: list[str] | None = None) -> tuple[int, list[Change]]:
        """이전 스냅샷과 비교해 변경을 계산하고, 새 스냅샷+변경을 저장한다.

        carry_paths: 이번 스캔에서 읽지 못한 경로들. 이전 스냅샷 값을 그대로 이월해
        '삭제'로 오인하지 않는다 (잠긴 파일이 removed로 잡히는 것 방지).
        known_prefixes: 다중 감시 폴더의 라벨 목록. 지정되면, 더 이상 감시하지 않는
        라벨 아래의 파일은 '삭제' 알림 없이 조용히 스냅샷에서 빠진다
        (감시 폴더를 목록에서 뺐을 뿐 파일이 지워진 게 아니므로).
        """
        if carry_paths:
            # 같은 경로가 두 번 실려 오면(제외 폴더가 동시에 '읽지 못한 폴더'이기도 한 경우처럼)
            # 스냅샷에 같은 행을 두 번 넣어 PRIMARY KEY를 어기고, 그 예외가 롤백 밖에서 터져
            # **그날 검사가 통째로 죽는다**(브리핑도 메일도 없이). 호출부가 아니라 여기서 막는다
            # (2026-09-09 감시·스캔 검토 차단 S1).
            prev = self._latest_rows()
            have = {r.path for r in records}
            seen: set = set()
            extra = []
            for p in carry_paths:
                if p in prev and p not in have and p not in seen:
                    seen.add(p)
                    extra.append(FileRecord(p, *prev[p]))
            records = records + extra
        old = self.latest_snapshot()
        new = {r.path: r for r in records}
        old_mt = dict(self.conn.execute(
            "SELECT path, mtime FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots)"))

        changes: list[Change] = []
        for path in sorted(new.keys() - old.keys()):
            changes.append(Change("added", path, None, new[path].sha256))
        for path in sorted(new.keys() & old.keys()):
            if new[path].sha256 != old[path]:
                changes.append(Change("modified", path, old[path], new[path].sha256))
        for path in sorted(old.keys() - new.keys()):
            if known_prefixes is not None and path.split("/")[0] not in known_prefixes:
                continue  # 감시 폴더 목록에서 빠진 라벨: 삭제 알림 없이 제외
            changes.append(Change("removed", path, old[path], None))

        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute("INSERT INTO snapshots (run_at) VALUES (?)", (now,))
        snapshot_id = cur.lastrowid
        self.conn.executemany(
            "INSERT INTO files (snapshot_id, path, sha256, size, mtime) VALUES (?, ?, ?, ?, ?)",
            [(snapshot_id, r.path, r.sha256, r.size, r.mtime) for r in records])
        with_ids = []
        for c in changes:
            cur = self.conn.execute(
                "INSERT INTO changes (snapshot_id, kind, path, old_sha256, new_sha256, detected_at, mtime, old_mtime) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (snapshot_id, c.kind, c.path, c.old_sha256, c.new_sha256, now,
                 new[c.path].mtime if c.path in new else None, old_mt.get(c.path)))
            with_ids.append(Change(c.kind, c.path, c.old_sha256, c.new_sha256, cur.lastrowid))
        # '진행 중' 표식을 **같은 트랜잭션**에 넣는다. 전에는 호출부가 커밋 뒤에
        # mark_run_started를 따로 불러서, 그 틈(정전·강제 종료)에 죽으면 스냅샷은 남고
        # 표식은 없어 그날 변경이 영원히 브리핑에 안 실렸다 — 화면에만 보였다
        # (2026-09-09 저장 검토 낮음 9a)
        self.conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES ('run_in_progress', ?)",
            (str(snapshot_id),))
        if scanned_prefixes is not None:
            # 감시 폴더(라벨)별 '첫 실제 검사' 스냅샷을 명시적으로 적는다. 변경 기록의 MIN으로만
            # 추정하면 ①첫 검사 때 비어 있던 폴더에 일주일 뒤 들어온 파일이 전부 '등록'으로 접혀
            # 영영 알리지 않고 ②기록을 남긴 채 뺐다가 다시 넣은 폴더가 '변경 N건' 메일이 됐다
            # (검토20 A-4·A-6). 규칙: 직전까지 실제로 검사된 라벨 집합(known_labels)에 없던 라벨이
            # 이번에 검사되면 이번이 그 폴더의 첫 검사. 설정에서 빠진 라벨은 집합에서 지워 다시
            # 넣으면 또 첫 검사가 된다. 닿지 못한(carry) 폴더는 검사된 적이 없으니 포함하지 않는다
            try:
                first_seen = json.loads(self.get_meta("root_first_seen") or "{}")
                known_raw = self.get_meta("known_labels")
                prev_known = set(json.loads(known_raw)) if known_raw is not None else None
            except (ValueError, TypeError):
                first_seen, prev_known = {}, None
            if prev_known is None:
                # 구판 DB의 첫 실행: 직전 스냅샷에 있던 라벨은 이미 검사된 것 — 이번 검사의 진짜
                # '추가'가 등록으로 접히지 않게
                prev_known = {p.split("/", 1)[0] for p in old.keys() if "/" in p}
            else:
                # 되돌린(지워진) 검사가 남긴 '첫 검사' 표식 — 그 스냅샷이 없고 직전 스냅샷에 그 폴더 파일도 없으면 그 폴더는
                # 아직 검사된 적이 없다. 옛 판의 롤백이 표식을 남겨 이튿날 새 감시 폴더의 첫 등록이 '추가 N건' 메일이 됐다
                # (재검토 2026-10-28 R9-1 — 이미 그 일을 겪은 DB를 위한 자가 치유. 새 롤백은 delete_run이 표식을 거둔다)
                old_labels = {p.split("/", 1)[0] for p in old.keys() if "/" in p}
                live = {r_[0] for r_ in self.conn.execute("SELECT id FROM snapshots")}
                for lb in list(prev_known):
                    try:
                        sid_ = int(first_seen[lb]) if lb in first_seen else None
                    except (TypeError, ValueError):
                        sid_ = None
                    if sid_ is not None and sid_ not in live and lb not in old_labels:
                        prev_known.discard(lb)
            for lb in scanned_prefixes:
                if lb not in prev_known:
                    first_seen[lb] = snapshot_id
            keep = set(known_prefixes) if known_prefixes is not None else set(scanned_prefixes)
            known_now = (prev_known | set(scanned_prefixes)) & keep
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('root_first_seen', ?)",
                              (json.dumps(first_seen, ensure_ascii=False),))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('known_labels', ?)",
                              (json.dumps(sorted(known_now), ensure_ascii=False),))
        self.conn.commit()
        return snapshot_id, with_ids

    @contextlib.contextmanager
    def _immediate(self):
        """읽고-고치고-쓰기를 다른 연결과 겹치지 않게 — 같은 변경에 두 사람(두 탭)이 메모를 적으면 하나가 조용히 사라졌다
        (검토64 B4). 쓰기 잠금을 먼저 잡고 읽는다."""
        if self.conn.in_transaction:
            self.conn.commit()
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield
        except BaseException:
            self.conn.rollback()
            raise
        else:
            self.conn.commit()

    def save_change_details(self, change_id: int, items: list[dict],
                            captures: dict | None = None) -> None:
        """변경 1건의 내용 비교 결과(diff 항목 + 위치 캡처)를 화면 조회용으로 저장.
        [다시 비교]·짝 지정으로 다시 쓸 때 사람이 남긴 메모는 그대로, 숨김은 같은 항목에 다시 붙인다 — 행을 통째로 바꿔
        메모·숨김이 단추 한 번에 사라졌다 (검토64 B5)."""
        with self._immediate():
            row = self.conn.execute(
                "SELECT items_json, dismissed_json, user_notes_json FROM change_details WHERE change_id = ?",
                (change_id,)).fetchone()
            dismissed, notes = None, None
            if row is not None:
                notes = row[2]
                try:
                    old_items = json.loads(row[0] or "[]")
                    old_d = json.loads(row[1] or "{}")
                except ValueError:
                    old_items, old_d = [], {}

                def _sig(it):
                    return (it.get("kind"), str(it.get("key")), str(it.get("old")), str(it.get("new")))
                # 위치까지 같은 항목을 먼저, 없으면 글자만 같은 아직 안 쓴 항목 — 같은 'NOTE 1' 삭제가 1행·9행 두 곳이면 9행에
                # 붙인 숨김이 다시 비교 뒤 1행으로 옮겨 갔다 (검토66 A6)
                new_full, new_pos = {}, {}
                for k, it in enumerate(items):
                    new_full.setdefault(_sig(it) + (str(it.get("where")),), []).append(k)
                    new_pos.setdefault(_sig(it), []).append(k)
                remap, used = {}, set()
                for k_old, v in old_d.items():
                    try:
                        oi = old_items[int(k_old)]
                        sig = _sig(oi)
                    except (ValueError, IndexError, TypeError, AttributeError):
                        continue
                    cand = ([k for k in new_full.get(sig + (str(oi.get("where")),), []) if k not in used]
                            or [k for k in new_pos.get(sig, []) if k not in used])
                    if cand:
                        used.add(cand[0])
                        remap[str(cand[0])] = v
                dismissed = json.dumps(remap, ensure_ascii=False) if remap else None
                # 그 전 항목(원래 근거)은 덧붙여 남긴다 — [다시 비교]·짝 지정이 처음 기록한 구값·신값·위치를 지우지 않게
                # (2026-11-17 R1, 기록 불변: 덧붙임만). 같은 항목을 다시 쓰는 것이면 남길 것이 없다
                if row[0] != json.dumps(items, ensure_ascii=False):
                    self.conn.execute(
                        "INSERT INTO change_details_prev (change_id, replaced_at, items_json, dismissed_json) VALUES (?, ?, ?, ?)",
                        (change_id, datetime.now(timezone.utc).isoformat(), row[0] or "[]", row[1]))
            self.conn.execute(
                "INSERT OR REPLACE INTO change_details (change_id, items_json, captures_json, dismissed_json, user_notes_json)"
                " VALUES (?, ?, ?, ?, ?)",
                (change_id, json.dumps(items, ensure_ascii=False),
                 json.dumps(captures or {}, ensure_ascii=False), dismissed, notes))

    def change_detail(self, change_id: int) -> dict | None:
        row = self.conn.execute(
            "SELECT items_json, captures_json, dismissed_json, user_notes_json "
            "FROM change_details WHERE change_id = ?", (change_id,)).fetchone()
        if row is None:
            return None
        return {"items": [_fix_old_note(it) for it in json.loads(row[0])], "captures": json.loads(row[1] or "{}"),
                "dismissed": json.loads(row[2] or "{}"),
                "user_notes": json.loads(row[3] or "[]")}

    def add_user_note(self, change_id: int, where: str, text: str, by: str) -> bool:
        """사람이 직접 추가하는 '놓친 변경' 기록 — 프로그램이 인식 못한 변경을
        사람이 보완한다 (오탐 숨김의 반대쪽, 원칙 5 양방향 완성 — 2026-08-27).
        상세가 없는 변경(기준선 등)에는 빈 상세를 만들어서라도 붙인다."""
        if self.get_change(change_id) is None:
            return False
        with self._immediate():
            row = self.conn.execute(
                "SELECT user_notes_json FROM change_details WHERE change_id = ?",
                (change_id,)).fetchone()
            if row is None:
                self.conn.execute("INSERT INTO change_details (change_id, items_json, captures_json) VALUES (?, '[]', '{}')",
                                  (change_id,))
                notes = []
            else:
                notes = json.loads(row[0] or "[]")
            notes.append({"where": where, "text": text, "by": by or "-",
                          "at": datetime.now(timezone.utc).isoformat()})
            self.conn.execute(
                "UPDATE change_details SET user_notes_json = ? WHERE change_id = ?",
                (json.dumps(notes, ensure_ascii=False), change_id))
        return True

    def delete_user_note(self, change_id: int, idx: int) -> None:
        with self._immediate():
            row = self.conn.execute(
                "SELECT user_notes_json FROM change_details WHERE change_id = ?",
                (change_id,)).fetchone()
            if row is None:
                return
            notes = json.loads(row[0] or "[]")
            if 0 <= idx < len(notes):
                notes.pop(idx)
                self.conn.execute(
                    "UPDATE change_details SET user_notes_json = ? WHERE change_id = ?",
                    (json.dumps(notes, ensure_ascii=False), change_id))

    def list_user_notes(self) -> list[dict]:
        """전체 '놓친 변경' 기록 (최신순) — 어떤 파일·양식에서 프로그램이 자주
        놓치는지 보는 미탐 리포트용."""
        out = []
        for cid, path, proj, notes_json in self.conn.execute(
                "SELECT d.change_id, c.path, c.project, d.user_notes_json "
                "FROM change_details d JOIN changes c ON c.id = d.change_id "
                "WHERE d.user_notes_json IS NOT NULL"):
            for n in json.loads(notes_json or "[]"):
                out.append({**n, "change_id": cid, "path": path,
                            "project": proj or "미분류"})
        out.sort(key=lambda n: n.get("at", ""), reverse=True)
        return out

    # ------------------------------------------------------------ 수동 짝 지정
    # 자동 규칙(같은 폴더·이름)이 못 엮는 판을 사람이 직접 짝지음 — 이름 오타,
    # '이전판' 폴더 이동, 영어 꼬리 등 (2026-08-29). 원칙 5: 최종 판단은 사람.

    def manual_projects(self) -> dict:
        """파일별 프로젝트 고정 {경로: 프로젝트} — 귀속기 1순위 (J6). 표가 없는 옛 DB·읽기 실패는 빈 dict."""
        try:
            return {_nfc_s(p): _nfc_s(v) for p, v in self.conn.execute("SELECT path, project FROM manual_projects")
                    if p and v}
        except sqlite3.Error:
            return {}

    def set_manual_project(self, path: str, project: str, by: str = "") -> int:
        """이 파일의 프로젝트를 고정하고, 이미 기록된 그 파일의 변경·열린 검토 필요도 그 프로젝트로 옮긴다 — 화면에 바로 보이게.
        옮긴 행 수를 돌려준다."""
        path, project = _nfc_s(path), _nfc_s(project).strip()
        if not path or not project:
            return 0
        self.conn.execute("INSERT OR REPLACE INTO manual_projects (path, project, by, at) VALUES (?, ?, ?, ?)",
                          (path, project, by or None, datetime.now(timezone.utc).isoformat()))
        # 귀속을 바꾸되 원래 귀속은 project_log에 남는다(덧붙임만, 2026-11-17 R1)
        ids = [r_[0] for r_ in self.conn.execute("SELECT id FROM changes WHERE path = ?", (path,))]
        n = self.conn.execute("UPDATE changes SET project = ?, project_how = 'manual', project_why = '직접 지정' "
                              "WHERE path = ?", (project, path)).rowcount or 0
        self._log_project([(i, project, "manual", "직접 지정") for i in ids], by=by)
        n += self.conn.execute("UPDATE issues SET project = ? WHERE path = ? AND resolved_at IS NULL",
                               (project, path)).rowcount or 0
        self.conn.commit()
        return n

    def clear_manual_project(self, path: str) -> bool:
        cur = self.conn.execute("DELETE FROM manual_projects WHERE path = ?", (_nfc_s(path),))
        self.conn.commit()
        return bool(cur.rowcount)

    def set_manual_pair(self, child_key: str, prev_key: str, by: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO manual_pairs (child_key, prev_key, by, at) "
            "VALUES (?, ?, ?, ?)",
            (child_key, prev_key, by or "-",
             datetime.now(timezone.utc).isoformat()))
        self.conn.commit()

    def clear_manual_pair(self, child_key: str) -> None:
        self.conn.execute("DELETE FROM manual_pairs WHERE child_key = ?",
                          (child_key,))
        self.conn.commit()

    def manual_pair(self, child_key: str) -> dict | None:
        """{prev_key, by, at} — 지정이 없으면 None."""
        row = self.conn.execute(
            "SELECT prev_key, by, at FROM manual_pairs WHERE child_key = ?",
            (child_key,)).fetchone()
        return ({"prev_key": row[0], "by": row[1], "at": row[2]}
                if row else None)

    def dismiss_change_item(self, change_id: int, idx: int, by: str) -> None:
        """상세 항목 하나를 '오탐/무의미'로 숨김 — 완전 삭제가 아니라 누가·언제와
        함께 보관하고 복원 가능 (원칙 5: 내용은 초안, 최종 판단은 사람 — 2026-08-27).
        idx는 items_json 배열 인덱스 (저장 순서 불변)."""
        with self._immediate():
            row = self.conn.execute(
                "SELECT dismissed_json FROM change_details WHERE change_id = ?",
                (change_id,)).fetchone()
            if row is None:
                return
            d = json.loads(row[0] or "{}")
            d[str(idx)] = {"by": by or "-",
                           "at": datetime.now(timezone.utc).isoformat()}
            self.conn.execute(
                "UPDATE change_details SET dismissed_json = ? WHERE change_id = ?",
                (json.dumps(d, ensure_ascii=False), change_id))

    def restore_change_item(self, change_id: int, idx: int) -> None:
        row = self.conn.execute(
            "SELECT dismissed_json FROM change_details WHERE change_id = ?",
            (change_id,)).fetchone()
        if row is None:
            return
        d = json.loads(row[0] or "{}")
        d.pop(str(idx), None)
        self.conn.execute(
            "UPDATE change_details SET dismissed_json = ? WHERE change_id = ?",
            (json.dumps(d, ensure_ascii=False), change_id))
        self.conn.commit()

    # ── 실행 표식: 스냅샷을 커밋한 뒤 보고 전에 프로세스가 죽으면(창 X·정전·업데이트)
    # 그날 변경이 영원히 브리핑에 안 실렸다 — 원칙 5 위반 (2026-09-04 검토 core H1).
    # 시작 때 표식을 남기고 정상 종료 때 지운다. 다음 실행이 표식을 보면 그 스냅샷을
    # 되돌려 같은 변경을 다시 감지한다
    def get_meta(self, key: str) -> str | None:
        row = self.conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_meta(self, key: str, value: str | None) -> None:
        if value is None:
            self.conn.execute("DELETE FROM meta WHERE key = ?", (key,))
        else:
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (key, value))
        self.conn.commit()

    def mark_run_started(self, snapshot_id: int) -> None:
        """record_run이 이미 같은 트랜잭션에서 표시한다 — 호출부 호환용으로 남긴다."""
        self.set_meta("run_in_progress", str(snapshot_id))

    def mark_run_finished(self) -> None:
        self.set_meta("run_in_progress", None)

    def unfinished_run(self) -> int | None:
        """보고를 마치지 못한 채 끝난 스냅샷 id (없으면 None)."""
        v = self.get_meta("run_in_progress")
        try:
            sid = int(v) if v else None
        except ValueError:
            return None
        if sid is None:
            return None
        row = self.conn.execute("SELECT 1 FROM snapshots WHERE id = ?", (sid,)).fetchone()
        return sid if row else None

    # ── 프로세스 간 잠금: 작업 스케줄러의 07시 검사와 화면의 [지금 검사]가 겹치면
    # 같은 변경이 두 번 기록되고 브리핑이 3통 나왔다 (2026-09-04 검토 core H4).
    # 파일 잠금 대신 DB의 meta 행을 쓴다 — 삭제 API 없이(원칙 2 가드) 원자적으로
    def acquire_run_lock(self, pid: int, stale_after: float = 6 * 3600) -> bool:
        """이 프로세스가 검사 잠금을 얻으면 True. 살아 있는 다른 검사가 잡고 있거나 DB가 잠겨 있으면 False."""
        try:
            self.conn.execute("BEGIN IMMEDIATE")
        except sqlite3.OperationalError as e:
            # 백신·백업 프로그램·DB 도구가 state.db를 오래 쥐면 예약 검사가 날 traceback으로 죽었다 (검토41 S9 중간 3)
            if "locked" in str(e).lower() or "busy" in str(e).lower():
                return False
            raise
        try:
            row = self.conn.execute(
                "SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
            if row:
                other_pid = _lock_parts(row[0])[0]
                if other_pid != pid and _lock_live(row[0], stale_after):
                    self.conn.rollback()
                    return False
            self.conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES ('run_lock', ?)", (lock_value(pid),))
            self.conn.commit()
            return True
        except Exception:
            self.conn.rollback()
            raise

    def space_report(self) -> dict:
        """파일 크기와 빈 공간 — 화면에 보여 주고 VACUUM 판단에도 쓴다."""
        pg = self.conn.execute("PRAGMA page_size").fetchone()[0]
        total = self.conn.execute("PRAGMA page_count").fetchone()[0]
        free = self.conn.execute("PRAGMA freelist_count").fetchone()[0]
        return {"bytes": pg * total, "free_bytes": pg * free,
                "pages": total, "free_pages": free}

    def reclaim_space(self, min_free_bytes: int = 32 * 1024 * 1024,
                      min_ratio: float = 0.25) -> dict | None:
        """지운 기록이 차지하던 빈 페이지를 실제로 디스크에 돌려준다 (VACUUM).

        전에는 prune_details/prune_renders가 행만 지워서 **파일 크기가 역대 최대치에
        영구히 고정**됐다 — 실측으로 921MB 파일의 실데이터가 0.2MB였다. 게다가 주간
        백업이 그 빈 페이지까지 복사해 4슬롯이 3GB였다 (2026-09-09 저장 검토 차단 1).

        VACUUM은 원본만큼의 임시 공간과 시간을 쓰므로 **빈 공간이 충분히 클 때만**
        한다. 돌려준 바이트 수를 알려 주고, 할 일이 없으면 None."""
        rep = self.space_report()
        if rep["free_bytes"] < min_free_bytes or                 rep["free_bytes"] < rep["bytes"] * min_ratio:
            return None
        before = rep["bytes"]
        self.conn.commit()
        self.conn.execute("VACUUM")
        after = self.space_report()["bytes"]
        return {"before": before, "after": after, "freed": max(0, before - after)}

    def integrity_ok(self) -> tuple[bool, str]:
        """DB가 온전한가 — 백업 전에 본다. (정상?, 사유)

        전에는 확인 없이 백업을 덮어써서, 디스크 이상·백신 격리로 DB가 한 번 비면
        4주 안에 멀쩡한 사본 4개가 모두 빈 DB로 덮였다 (2026-09-09 저장 검토 차단 3)."""
        try:
            row = self.conn.execute("PRAGMA integrity_check(20)").fetchone()
        except Exception as e:                      # noqa: BLE001
            return False, f"{type(e).__name__}: {e}"
        msg = str(row[0]) if row else "응답 없음"
        return msg == "ok", msg

    def row_counts(self) -> dict:
        """백업 전후 비교용 주요 표의 행 수."""
        out = {}
        for tbl in ("snapshots", "files", "changes", "acks", "issues"):
            try:
                out[tbl] = self.conn.execute(
                    f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
            except Exception:                       # noqa: BLE001
                out[tbl] = -1
        return out

    def run_lock_holder(self, stale_after: float = 6 * 3600) -> int | None:
        """지금 검사를 돌리고 있는 프로세스의 PID (없으면 None) — 읽기만 한다.

        업데이트 교체가 **다른 프로세스의** 예약 검사를 덮치던 것을 막으려고 추가했다
        (2026-09-09 자동 실행 검토 차단 1): 창의 scan_state()는 자기 스레드만 본다."""
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        if not row:
            return None
        pid = _lock_parts(row[0])[0]
        if pid <= 0 or not _lock_live(row[0], stale_after):
            return None
        return pid

    def release_run_lock(self, pid: int, patience: float = 180.0) -> None:
        """내 잠금이면 푼다. 다른 프로그램(백신·백업·DB 도구)이 이력 파일을 쥐고 있으면 기다렸다 다시 — 한 번 실패하고 말면
        잠금이 창 PID로 남아, 창이 떠 있는 동안 예약 검사가 전부 '이미 진행 중'으로 막혔다 (검토64 B2)."""
        deadline = time.monotonic() + max(patience, 0.0)
        while True:
            try:
                row = self.conn.execute("SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
                if row and row[0].split(":", 1)[0] == str(pid):
                    self.set_meta("run_lock", None)
                return
            except sqlite3.OperationalError as e:
                if ("locked" not in str(e).lower() and "busy" not in str(e).lower()) or time.monotonic() >= deadline:
                    raise
                time.sleep(2.0)

    def delete_run(self, snapshot_id: int) -> None:
        """실패한 실행의 스냅샷·변경·이슈를 되돌린다 — 다음 실행이 다시 감지하도록.
        (보고 단계 실패 시 알림 유실 방지. extracts는 내용 기준 캐시라 남겨도 무해)"""
        self.conn.execute(
            "DELETE FROM change_details WHERE change_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        # 되돌리는 변경의 확인 기록과 번호를 맡겨 둔다 — 지우기만 하니 검사 중 누른 [확인함]·보고 직후 끊긴 검사의
        # 확인이 사라지고 이미 나간 메일의 확인 링크가 '변경 #70이 없습니다'가 됐다 (검토39 P5 차단 2).
        # 다음 검사가 같은 변경(경로·종류·새 지문)을 다시 잡으면 reattach_rolled_back이 옮겨 붙인다
        rolled = [{"id": cid, "path": pth, "kind": kd, "sha": sha}
                  for cid, pth, kd, sha in self.conn.execute(
                      "SELECT id, path, kind, new_sha256 FROM changes WHERE snapshot_id = ?", (snapshot_id,))]
        acks = [{"id": cid, "by": by, "note": note, "at": at}
                for cid, by, note, at in self.conn.execute(
                    'SELECT a.change_id, a."by", a.note, a.at FROM acks a JOIN changes c ON c.id = a.change_id '
                    "WHERE c.snapshot_id = ?", (snapshot_id,))]
        if rolled:
            try:
                prev = json.loads(self.get_meta(ROLLED_BACK_KEY) or "{}")
            except ValueError:
                prev = {}
            prev.setdefault("changes", []).extend(rolled)
            prev.setdefault("acks", []).extend(acks)
            prev["changes"] = prev["changes"][-5000:]
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (ROLLED_BACK_KEY, json.dumps(prev, ensure_ascii=False)))
        self.conn.execute(
            "DELETE FROM acks WHERE change_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute("DELETE FROM issues WHERE snapshot_id = ?", (snapshot_id,))
        # 그 검사가 처음 본 출도본·발주서 행도 — 남기면 다음 검사가 같은 판을 '이미 본 출도본'으로 건너뛴다 (J2·J8)
        self.conn.execute("DELETE FROM issued_copies WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM po_lines WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute(  # 롤백된 변경을 가리키는 합치기 기록 (2026-09-02 재검토)
            "DELETE FROM project_merge_rows WHERE kind = 'change' AND row_id IN "
            "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        # 확정 전 기록의 귀속 이력·요약·옛 상세도 함께 (2026-11-17 R1 — 되돌리기는 그대로 지운다)
        for tbl in ("project_log", "change_summaries", "change_details_prev"):
            self.conn.execute(f"DELETE FROM {tbl} WHERE change_id IN "
                              "(SELECT id FROM changes WHERE snapshot_id = ?)", (snapshot_id,))
        self.conn.execute("DELETE FROM changes WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM files WHERE snapshot_id = ?", (snapshot_id,))
        self.conn.execute("DELETE FROM snapshots WHERE id = ?", (snapshot_id,))
        self.conn.execute(
            "DELETE FROM meta WHERE key = 'run_in_progress' AND value = ?", (str(snapshot_id),))
        self._revert_run_meta(snapshot_id)
        self.conn.commit()

    def _revert_run_meta(self, snapshot_id: int) -> None:
        """되돌리는 검사가 meta에 남긴 '처음' 표식을 거둔다 — 그 스냅샷을 가리키는 폴더 첫 검사(root_first_seen·known_labels)와
        켠 확장자(ext_baseline·last_extensions). 남기면 이튿날 새 감시 폴더·새 확장자의 첫 등록이 등록이 아니라 '추가 N건'
        메일이 됐다 — 보고 단계 예외는 호출부가 일부만 되돌렸고, 크래시 뒤의 되돌림(다음 검사 시작)은 하나도 안 되돌렸다
        (재검토 2026-10-28 R9-1). 같은 트랜잭션 안에서 — 커밋은 delete_run이 한다."""
        def _put(key, value) -> None:
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (key, value))

        def _same(v) -> bool:
            try:
                return int(v) == int(snapshot_id)
            except (TypeError, ValueError):
                return False
        try:
            fs = json.loads(self.get_meta("root_first_seen") or "{}")
            if not isinstance(fs, dict):
                fs = {}
        except (ValueError, TypeError):
            fs = {}
        born = {lb for lb, s in fs.items() if _same(s)}
        if born:
            for lb in born:
                fs.pop(lb, None)
            _put("root_first_seen", json.dumps(fs, ensure_ascii=False))
            try:
                kl = json.loads(self.get_meta("known_labels") or "null")
            except (ValueError, TypeError):
                kl = None
            if isinstance(kl, list):
                _put("known_labels", json.dumps(sorted(set(kl) - born), ensure_ascii=False))
        eb = self.ext_baseline()
        on = {e for e, s in eb.items() if _same(s)}
        if on:
            for e in on:
                eb.pop(e, None)
            _put("ext_baseline", json.dumps(eb, ensure_ascii=False))
            try:
                le = json.loads(self.get_meta("last_extensions") or "null")
            except (ValueError, TypeError):
                le = None
            if isinstance(le, list):
                _put("last_extensions", json.dumps([e for e in le if str(e).lower() not in on]))

    def reattach_rolled_back(self) -> int:
        """되돌렸던 변경을 이번 검사가 다시 잡았으면 옛 번호 → 새 번호를 기록하고, 맡겨 둔 확인을 새 변경에
        옮겨 붙인다. 돌려주는 값: 옮긴 확인 수 (검토39 P5 차단 2)."""
        try:
            d = json.loads(self.get_meta(ROLLED_BACK_KEY) or "{}")
        except ValueError:
            return 0
        if not d.get("changes"):
            return 0
        try:
            moved = json.loads(self.get_meta(MOVED_IDS_KEY) or "{}")
        except ValueError:
            moved = {}
        left, n = [], 0
        for c in d.get("changes", []):
            row = self.conn.execute(
                "SELECT id FROM changes WHERE path = ? AND kind = ? AND IFNULL(new_sha256,'') = IFNULL(?,'') "
                "AND id > ? ORDER BY id LIMIT 1", (c["path"], c["kind"], c.get("sha"), c["id"])).fetchone()
            if row:
                moved[str(c["id"])] = row[0]
            else:
                left.append(c)
        keep_acks = []
        for a in d.get("acks", []):
            new_id = moved.get(str(a["id"]))
            if new_id is None:
                keep_acks.append(a)
                continue
            dup = self.conn.execute('SELECT 1 FROM acks WHERE change_id = ? AND "by" = ? AND at = ?',
                                    (new_id, a["by"], a["at"])).fetchone()
            if not dup:
                self.conn.execute('INSERT INTO acks (change_id, "by", note, at) VALUES (?, ?, ?, ?)',
                                  (new_id, a["by"], a["note"], a["at"]))
                n += 1
        self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                          (MOVED_IDS_KEY, json.dumps(dict(list(moved.items())[-5000:]))))
        rest = {"changes": left[-5000:], "acks": keep_acks}
        if left or keep_acks:
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (ROLLED_BACK_KEY, json.dumps(rest, ensure_ascii=False)))
        else:
            self.conn.execute("DELETE FROM meta WHERE key = ?", (ROLLED_BACK_KEY,))
        self.conn.commit()
        return n

    def moved_change_id(self, old_id: int) -> int | None:
        """되돌렸다 다시 잡힌 변경의 새 번호 — 이미 나간 메일 링크를 잇는다."""
        try:
            v = json.loads(self.get_meta(MOVED_IDS_KEY) or "{}").get(str(old_id))
        except ValueError:
            return None
        return int(v) if v is not None else None

    @staticmethod
    def issue_key(code: str, path: str, message: str) -> tuple:
        """중복·해소 대조 키 — 문구의 **변하는 부분**(괄호 안의 값·장수, 앞의 [프로젝트])을 뺀다.

        2026-09-03: '(외 도면 N장에서도 불일치)' 숫자만 바뀐 것이 해소+재생성돼 '신규'로 재알림.
        2026-09-14 실사용 day2: 검토21이 도면 간 불일치 문구에서 ' 외 N장'을 빼자 v0.56→0.57.2
        업데이트 뒤 첫 검사에서 열린 이슈 2건이 '재검출되지 않음'으로 닫히고 같은 내용이 새 이슈로
        태어나 **변경 없는 프로젝트에 검토 필요 메일이 나갔다**. 판이 바뀔 때마다 문구가 조금씩
        바뀌므로, 키는 code+path+태그(문구의 뼈대)만 본다 — 값이 바뀌면 열린 이슈의 문구·근거를
        갱신한다(save_issues)."""
        pm = re.match(r"^\s*\[([^\]]*)\]\s*", message)
        m = message[pm.end():] if pm else message                 # 앞의 [프로젝트]
        m = re.sub(r"\s*\([^()]*\)", "", m)                     # 괄호 안(값·장수·안내)
        m = re.sub(r"\s+", " ", m).strip().rstrip(".。 ")
        # 개정표를 부르는 이름을 '개정표' 하나로 고친 판(검토71 R4 중간 4) 전후의 문구가 같은 이슈로 이어지게 — 옛 문구
        # '리비전 블록'·'개정이력 표'·'개정이력 Rev가'와 새 문구 '개정표'·'머리글 Rev가'를 같은 뼈대로 본다
        m = re.sub(r"리비전 블록|개정이력 표|개정이력", "개정표", m)
        if code == "CONTENT_CHANGED_REV_SAME":
            m = re.sub(r"^내용이 바뀌었는데 (?:개정표|머리글|바닥글|문서 머리) Rev가", "내용이 바뀌었는데 개정표 Rev가", m)
        if code == "TAG_MISMATCH_ACROSS_DRAWINGS":
            # 도면 간 불일치의 path는 '첫 충돌 도면'이라, 기준 도면을 고치거나 이름이 앞선 도면이
            # 들어오면 path가 옮겨가 같은 불일치가 새 이슈로 태어났다 (검토23 A-2). 폴더 단위로 본다.
            # 한 폴더에 두 프로젝트의 도면이 섞이면 같은 태그가 한 키로 뭉치므로(재검토 1-②) 프로젝트
            # **번호**(별칭·표기 변화에 흔들리지 않는 부분)만 키에 넣는다
            from watcher.project import PROJECT_NO_RE, fold_text
            path = path.rsplit("/", 1)[0] if "/" in path else path
            # 전각·대시 변종('[P25－007]')도 같은 번호 — 귀속·묶음 키와 같은 접기 (재검토 2026-10-28 R9-3·R6-10)
            _pl = fold_text(pm.group(1)) if pm else ""
            no = PROJECT_NO_RE.search(_pl.upper()) if pm else None
            if no is None and pm:
                no = re.search(r"(?<![\w-])(\d{2}-\d{3})(?![\w-])", _pl)
            if no:
                m = f"{no.group()}|{m}"
        return code, path, m

    @staticmethod
    def _loose_key(key: tuple) -> tuple:
        """번호 유무를 무시한 느슨한 키 — 귀속이 '[P26-001]'↔'[포장라인]'처럼 번호 있는 이름표와 없는
        이름표 사이를 오가면(별칭 추가·귀속 규칙 변경) 정확 키가 갈려 옛 이슈는 옛 이름으로 남고 같은
        내용이 새로 태어났다 (v0.57.4 재검토 1-③). 정확 키가 없을 때, 느슨한 키로 **하나만** 짝이
        되면 같은 이슈로 본다 — 둘 이상이면(한 폴더에 두 번호 프로젝트) 합치지 않는다."""
        code, path, m = key
        return code, path, m.split("|", 1)[1] if "|" in m else m

    @staticmethod
    def _loose_pair_ok(k1: tuple, k2: tuple) -> bool:
        """느슨한 짝은 번호 **유무**가 다를 때만 — 번호→다른 번호(P26-001→P26-002)까지 짝이 되면
        하루 차이로 다른 프로젝트의 이슈로 이어졌다 (검토24 B-4)."""
        return ("|" in k1[2]) != ("|" in k2[2])

    def absorb_twins(self, issues) -> int:
        """같은 사실 두 카드를 합친 판으로 처음 검사하는 날의 이주 (기능 검토 2026-11-02 J3). 합친 카드(도면-BOM)와 거기 합쳐진
        카드(도면 간)가 둘 다 열려 있으면 합쳐진 쪽을 닫고, 합쳐진 쪽만 열려 있으면 그 행을 합친 카드로 바꿔 이어 간다 — 업데이트 날
        '해소 1건 + 새로 생김 1건'으로 메일이 나지 않게. 닫는 사유는 '자동 해소'로 시작해, 나중에 도면 간 불일치만 따로 남으면
        재발(새 카드)로 잡힌다. 바꾼·닫은 행 수."""
        rows = [i for i in issues or () if getattr(i, "absorbed", ())]
        if not rows:
            return 0
        open_ = {}
        for iid, c, p, m in self.conn.execute(
                "SELECT id, code, path, message FROM issues WHERE resolved_at IS NULL "
                "AND code IN ('BOM_MISMATCH', 'TAG_MISMATCH_ACROSS_DRAWINGS')"):
            open_.setdefault(self.issue_key(c, p, m), iid)
        now = datetime.now(timezone.utc).isoformat()
        n = 0
        for i in rows:
            mine = open_.get(self.issue_key(i.code, i.path, i.message))
            twin = open_.get(self.issue_key(*i.absorbed))
            if twin is None:
                continue
            if mine is not None:
                self.conn.execute("UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?",
                                  (now, "자동 해소 — 같은 태그·값의 도면-BOM 불일치 카드에 합침", twin))
            else:
                self.conn.execute("UPDATE issues SET code = ?, path = ?, message = ?, evidence = ? WHERE id = ?",
                                  (i.code, i.path, i.message, json.dumps(list(i.evidence), ensure_ascii=False), twin))
                open_[self.issue_key(i.code, i.path, i.message)] = twin
            open_.pop(self.issue_key(*i.absorbed), None)
            n += 1
        self.conn.commit()
        return n

    def save_issues(self, snapshot_id: int, rows, quiet_paths=frozenset()) -> list:
        """일관성 검사 결과 저장. rows: [(Issue, 프로젝트|None)] — 대시보드 표시용.
        quiet_paths: **이번 검사**에서 조용한 변경(재저장·일자만·이동)만 겪은 경로 — 이번 검사의 상세는
        이 시점에 아직 DB에 없어(이슈 저장이 상세 저장보다 앞) 호출부가 넘겨 준다 (검토31 C 1).

        미해결 불일치(도면-BOM 등)는 변경이 있는 날마다 다시 검출되므로
        동일 내용(code+path+message)은 중복 저장하지 않는다. 닫힌 이슈와의 대조에는 기간 창이 없다 —
        재발은 닫은 뒤 내용 변경·값 변화·한 번 사라짐으로 가린다 (2026-08-25 리뷰 → 검토50 D 중간 1)."""
        # 열린 이슈는 기간과 무관하게 전부 — 30일 cutoff가 여기에도 걸려, 30일 넘게 열린 이슈가
        # 다음 변경 날 '새 검토 필요'로 중복 재탄생했다 (검토23 A-1 차단, 실사용 10-12 재발 예약분)
        existing = {self.issue_key(c, p, m): iid for iid, c, p, m in self.conn.execute(
            "SELECT id, code, path, message FROM issues WHERE resolved_at IS NULL")}
        # 느슨한 키 → 정확 키 목록 (번호 유무가 바뀐 귀속의 짝 찾기용)
        loose: dict = {}
        for k in existing:
            loose.setdefault(self._loose_key(k), []).append(k)
        today = {self.issue_key(i.code, i.path, i.message) for i, _p in rows}
        today_loose: dict = {}
        for k in today:
            today_loose[self._loose_key(k)] = today_loose.get(self._loose_key(k), 0) + 1

        def _match(i):
            """오늘 이슈에 대응하는 열린 이슈 id — 정확 키, 없으면 느슨한 키로 **양쪽 다 유일**하고
            번호 유무가 다를 때만."""
            k = self.issue_key(i.code, i.path, i.message)
            if k in existing:
                return existing[k]
            lk = self._loose_key(k)
            cands = [x for x in loose.get(lk, []) if x not in today and self._loose_pair_ok(k, x)]
            if len(cands) == 1 and today_loose.get(lk, 0) == 1:
                return existing[cands[0]]
            return None

        # 닫힌(resolved) 이슈: 같은 불일치가 **그대로 남아 있는 동안**에는 다시 만들지 않는다.
        # 예전에는 닫는 순간 대조에서 빠져, 검사 때마다 똑같은 내용이 새 이슈로 되살아나
        # 브리핑 메일에 매일 실렸다 — 열어 두면 조용하고 닫으면 시끄러웠다
        # (2026-09-09 확인 검토 A3). 그 파일이 닫은 뒤 **다시 바뀌었으면** 진짜 재발로 본다.
        # 시각이 아니라 **검사 회차**로 본다 — 닫은 시각과 검출 시각이 같은 순간일 수 있고,
        # 우리가 알고 싶은 것은 "그 뒤로 그 파일이 또 바뀌었나"이기 때문이다
        closed: dict = {}
        auto_closed: set = set()
        for c, pth, m, snap, rat, ev, rby, gone in self.conn.execute(
                "SELECT code, path, message, snapshot_id, resolved_at, evidence, resolved_by, gone_at FROM issues "
                # 기간으로 자르지 않는다 — 검출 30일째에 [처리함] 불일치가 새 이슈로 되살아나 메일이 나갔다. 재발은 아래
                # _recurred(닫은 뒤 내용 변경)·_values_changed(값)·gone_at(한 번 사라짐)이 가린다 (검토50 D 중간 1)
                "WHERE resolved_at IS NOT NULL"):
            key = self.issue_key(c, pth, m)
            prev = closed.get(key)
            if prev is None or (snap or 0) > prev[1]:
                closed[key] = (pth, snap or 0, rat or "", (ev, m) if c in _VALUE_CODES else None)
                # 교차 검사 이슈가 '자동 해소'로 닫혔다 = 그 불일치가 **사라졌었다** — 다시 나오면 같은 값이어도 재발이다.
                # 도면을 고쳤다가 같은 값으로 되돌린 날 새 이슈가 없었다 (검토43 B 차단 2)
                # 사람이 [처리함]으로 닫은 뒤 검사에서 한 번 사라졌다가(gone_at) 다시 나와도 재발이다 (검토43 B 중간 8)
                # 표제란 Rev≠리비전 블록도 — 값으로만 재발을 가리게 한 뒤(검토58 ⑦) 고쳤다가 같은 값으로 되돌아간 진짜 재발이
                # 묻혔다 (검토59 F2-1)
                if c in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS", "REV_BLOCK_MISMATCH") and (
                        str(rby or "").startswith("자동 해소") or (gone and str(gone) >= str(rat or ""))):
                    auto_closed.add(key)
                else:
                    auto_closed.discard(key)

        def _recurred(key) -> bool:
            """닫은 뒤 그 파일이 **내용이 바뀌는** 변경을 겪었는가. 일자만 재출도·재저장·이동 같은
            조용한 변경은 재발이 아니다 — 세트 재출도 날 사람이 닫아 둔 이슈가 전부 되살아났다 (검토31 C 1)."""
            pth, snap, rat, _ev = closed[key]
            for js, at in self.conn.execute(
                    "SELECT d.items_json, c.detected_at FROM changes c "
                    "LEFT JOIN change_details d ON d.change_id = c.id "
                    "WHERE c.path = ? AND c.snapshot_id > ?", (pth, snap)):
                # 검출과 [처리함] 사이에 있던 변경은 사람이 보고 닫은 것이다 — 닫은 뒤의 변경만 (검토31 C 1)
                if rat and str(at or "") < rat:    # 같은 순간(시험의 연속 호출)은 닫은 뒤로 본다
                    continue
                if js is None and pth in quiet_paths:
                    continue                       # 이번 검사의 조용한 변경 (상세는 아직 저장 전)
                if not self._quiet_items(js):
                    return True
            return False

        def _paren_vals(msg: str):
            """도면 간 불일치·표제란 Rev≠리비전 블록은 값이 문구 괄호 안에 있다 — '(7.5kW vs 11kW)'·'(표제란 B · 리비전 블록 A)'."""
            got = re.findall(r"\(([^()]*)\)", msg or "")
            return " ".join(got[-1].split()).upper() if got else None

        def _same_paren(key, issue) -> bool:
            """도면 간 불일치·표제란 Rev≠리비전 블록은 값이 그대로면 재발이 아니다 — [처리함] 뒤 그 도면의 무관한 편집(NOTE
            한 줄)만으로 값이 같은 이슈가 새로 태어났다 (검토58 F2 E08·D07). **막기만** 한다 — 다른 도면이 바뀌어 셋째 값이
            달라진 것으로 되살리지는 않는다(검토32 D 1-5: 닫은 이슈는 다른 파일 변경으로 되살아나지 않는다)"""
            if issue.code not in _PAREN_CODES:
                return False
            _ev, msg_old = closed[key][3] or (None, "")
            old, new = _paren_vals(msg_old), _paren_vals(issue.message)
            return bool(old and new and old == new)

        def _values_changed(key, issue) -> bool:
            """도면-BOM 불일치는 대표 경로가 BOM 파일이고 문구에 값이 없다 — 닫힌 뒤 **도면만** 다른 값으로 다시
            어긋나도 같은 이슈로 묻혔다(검토41 S3 차단 1). 근거에 인용된 파일 경로로 보던 v0.57.20 고침은 파일 이름만
            적힌 근거·폴더 이동·괄호 든 경로에서 소리 없이 무효였고, 인용된 도면의 무관한 편집만으로 [처리함] 이슈를
            되살렸다(검토42 A 차단·중간 5). **값**으로 본다: BOM 사양과 도면 줄이 닫을 때와 다르면 재발이다."""
            if issue.code != "BOM_MISMATCH":
                return False
            ev_old, msg_old = closed[key][3] or (None, "")
            old = self._mismatch_values(ev_old, msg_old)
            new = self._mismatch_values(json.dumps(list(issue.evidence), ensure_ascii=False), issue.message)
            return bool(old and new and old != new)

        def _by_values(key, issue) -> bool:
            """도면-BOM 불일치를 닫을 때·지금 값이 둘 다 읽히면 재발은 **값으로만** 가린다 — BOM에 무관한 행 하나를
            더한 것만으로 [처리함] 이슈가 새로 열렸고, 그 이슈가 열려 있어 뒤이은 진짜 값 변화(11kW)는 '재발'로
            표시되지 않았다 (경우100 C03). 도면 쪽 무관한 편집은 검토42 A에서 이미 값으로 가렸다"""
            if issue.code != "BOM_MISMATCH":
                return False
            ev_old, msg_old = closed[key][3] or (None, "")
            return bool(self._mismatch_values(ev_old, msg_old)) and bool(
                self._mismatch_values(json.dumps(list(issue.evidence), ensure_ascii=False), issue.message))

        closed_loose: dict = {}
        for k in closed:
            closed_loose.setdefault(self._loose_key(k), []).append(k)

        def _closed_key(k):
            """닫힌 이슈 쪽 짝 — 정확 키, 없으면 같은 느슨한 규칙. [처리함]으로 닫은 이슈가 별칭 한 줄
            추가로 새 이슈+'검토 필요 1건' 메일로 되살아났다 (검토24 B-3)."""
            if k in closed:
                return k
            lk = self._loose_key(k)
            cands = [x for x in closed_loose.get(lk, []) if self._loose_pair_ok(k, x)]
            return cands[0] if len(cands) == 1 and today_loose.get(lk, 0) == 1 else None

        now = datetime.now(timezone.utc).isoformat()
        fresh = []
        # 다시 생긴 이슈 → 전에 닫힌 시각 — 메일 카드가 '재발'을 말하지 않아 BOM이 옛 값으로 되돌아간 사고가 새 불일치로만
        # 보였다 (검토44 C 중간 3)
        self.last_recurred = {}
        for i, proj in rows:
            if _match(i) is not None:
                continue
            ck = _closed_key(self.issue_key(i.code, i.path, i.message))
            if ck is None or ck in auto_closed or (not _by_values(ck, i) and _recurred(ck) and not _same_paren(ck, i)) \
                    or _values_changed(ck, i):
                fresh.append((i, proj))
                if ck is not None:
                    self.last_recurred[(i.code, i.path, i.message)] = closed[ck][2]
        # 이미 열린 이슈는 근거·문구를 최신 값으로 갱신한다 — 값이 바뀐 뒤에도 옛 값이
        # 화면에 남아 파일과 달랐다 (2026-09-05 전체 검토, 원칙 4)
        # 경로(첫 충돌 도면이 바뀜)·프로젝트(귀속 이름이 바뀜)도 따라간다 — project가 옛 이름으로
        # 남으면 auto_resolve의 '그 프로젝트를 검사했나' 판정에서 영원히 빠져 해소가 안 됐다 (검토23 A-2·A-3)
        # 단, 파일 한 번의 편집을 말하는 이슈('Rev 미갱신' 등)는 근거를 **쌓는다** — 문구에 값이 없어 키가 늘 같으니,
        # 열린 동안 새 편집이 오면 처음 잡힌 편집의 근거가 마지막 편집으로 덮여 무엇 때문에 열렸는지 사라졌다
        # (검토42 D 중간 2, 원칙 4). 상태형(도면 간·도면-BOM 불일치)은 지금 값이 맞는 근거라 예전처럼 갱신
        self.last_continued = []      # (경로, 코드, 프로젝트, 처음 잡힌 시각) — 열린 경고의 파일이 오늘 또 바뀜 (검토43 C 중간 1)
        redate = self._baseline_redate(snapshot_id, rows, _match, _paren_vals, quiet_paths)
        redated: list = []
        for i, proj in rows:
            iid = _match(i)
            if iid is not None and iid in redate:
                # 기준선(첫 검사)부터 열린 불일치인데 오늘 값이 바뀌었다 — 오늘 건으로 올린다(새 검출 회차·시각, 신규 목록).
                # 같은 이슈 키라 근거만 갱신돼 '설치 전부터' 꼬리표를 단 옛 건처럼 묻혔다 (구매 평가 2차 P1 SC-1)
                ev_new = list(i.evidence) + [redate[iid]]
                self.conn.execute(
                    "UPDATE issues SET message = ?, evidence = ?, path = ?, project = ?, snapshot_id = ?, detected_at = ? "
                    "WHERE id = ?", (i.message, json.dumps(ev_new, ensure_ascii=False), i.path, proj, snapshot_id, now, iid))
                redated.append((i, proj))
                continue
            if iid is not None:
                ev_new = list(i.evidence)
                if i.code in self.EVENT_CODES:
                    row = self.conn.execute("SELECT evidence, detected_at FROM issues WHERE id = ?", (iid,)).fetchone()
                    try:
                        ev_old = json.loads(row[0]) if row and row[0] else []
                    except (ValueError, TypeError):
                        ev_old = []
                    ev_new = self._stack_evidence(ev_old, ev_new, i.code)
                    if ev_new != [str(x) for x in ev_old]:
                        self.last_continued.append((i.path, i.code, proj, row[1] if row else ""))
                self.conn.execute(
                    "UPDATE issues SET message = ?, evidence = ?, path = ?, project = ? WHERE id = ?",
                    (i.message, json.dumps(ev_new, ensure_ascii=False), i.path, proj, iid))
        self.conn.executemany(
            "INSERT INTO issues (snapshot_id, code, path, project, message, evidence,"
            " detected_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [(snapshot_id, i.code, i.path, proj, i.message,
              json.dumps(list(i.evidence), ensure_ascii=False), now)
             for i, proj in fresh])
        self.conn.commit()
        # 새로 기록된 것만 돌려준다 — 브리핑은 신규만 싣고, 미해결 누적은 화면에서
        # 본다 (같은 경고가 변경 있는 날마다 메일로 재알림되던 소음 제거, 2026-08-26)
        return fresh + redated

    def _baseline_redate(self, snapshot_id, rows, match, paren_vals, quiet_paths=frozenset()) -> dict:
        """기준선부터 열린 교차 불일치(도면 간·도면-BOM·표제란≠개정표) 가운데 **오늘 값이 바뀐** 것 {이슈 id: 덧붙일 근거 줄}.

        조건 셋을 모두: ① 그 이슈가 기준선(첫 검사) 회차에 잡혔다 ② 값이 바뀌었다 — 도면-BOM은 근거의 (BOM 사양, 도면 줄),
        나머지는 문구 괄호 안 값 ③ 근거에 인용된 파일 하나 이상이 **이번 검사에서 내용이 바뀌었다**(조용한 재저장·일자만 제외).
        ③이 없으면 판 교체(추출 규칙 변경)만으로 값 표기가 달라진 날 기준선 이슈가 모두 오늘 건으로 올라왔을 것이다."""
        base = self.first_snapshot_id()
        if base is None or snapshot_id is None or snapshot_id == base:
            return {}
        changed_now = {p for (p,) in self.conn.execute(
            "SELECT path FROM changes WHERE snapshot_id = ? AND kind IN ('modified', 'added')", (snapshot_id,))} - set(quiet_paths)
        if not changed_now:
            return {}
        out: dict = {}
        for i, _proj in rows:
            if i.code not in _VALUE_CODES:
                continue
            iid = match(i)
            if iid is None or iid in out:
                continue
            row = self.conn.execute("SELECT snapshot_id, message, evidence FROM issues WHERE id = ?", (iid,)).fetchone()
            if not row or row[0] != base:
                continue
            new_ev = json.dumps(list(i.evidence), ensure_ascii=False)
            if i.code == "BOM_MISMATCH":
                old_v, new_v = self._mismatch_values(row[2], row[1]), self._mismatch_values(new_ev, i.message)
                if not (old_v and new_v) or old_v[:2] == new_v[:2]:
                    continue
                shown = " · ".join(sorted(old_v[1])) or "—"
            else:
                # 값 묶음으로 — 옛 판 문구의 ' 외 N장' 같은 덧말·순서만 다른 것은 값이 바뀐 게 아니다 (test_review22 문구 갱신)
                def _vals(msg):
                    pv = paren_vals(msg)
                    if not pv:
                        return None
                    pv = re.sub(r"\s*외\s*\d+\s*장", "", pv)
                    return frozenset(x.strip() for x in re.split(r"\s+VS\s+|\s+·\s+", pv) if x.strip())
                old_v, new_v = _vals(row[1]), _vals(i.message)
                if not (old_v and new_v) or old_v == new_v:
                    continue
                shown = re.findall(r"\(([^()]*)\)", row[1] or "")[-1]
            if not (set(self._evidence_paths(new_ev, changed_now)) & changed_now):
                continue
            # 근거 줄에 ': '를 쓰지 않는다 — 화면이 근거 줄을 ': '에서 두 칸으로 가른다
            out[iid] = f"첫 검사(설치 때)부터 있던 불일치 — 오늘 값이 바뀌어 오늘 건으로 올림 (첫 검사 때 값 {shown})"
        return out

    # 파일 한 번의 편집을 말하는 이슈 — 근거를 쌓는다(save_issues)
    revert_why: dict = {}   # (경로, 코드) → 자동 해소 사유 — cli가 검사마다 새 dict로 바꿔 넣는다
    EVENT_CODES = frozenset({"CONTENT_CHANGED_REV_SAME", "REV_CHANGED_CONTENT_SAME", "REV_REGRESSED",
                             "POST_ISSUE_CHANGE"})      # 출도 후 변경 — 출도본 값(첫 편집)을 잃지 않게 쌓는다 (J2)
    _STACK_MARK = "── "
    _STACK_KEEP = 3          # 처음 잡힌 편집 + 최근 추가 편집 몇 번까지

    _STACK_HEAD = {"CONTENT_CHANGED_REV_SAME": "Rev가 그대로인 채 또 바뀜",
                   "REV_CHANGED_CONTENT_SAME": "또 Rev만 바뀜", "REV_REGRESSED": "Rev가 또 거꾸로 감",
                   "POST_ISSUE_CHANGE": "새 출도 없이 또 바뀜"}

    @classmethod
    def _stack_evidence(cls, old: list, new: list, code: str = "CONTENT_CHANGED_REV_SAME") -> list:
        """처음 근거는 그대로 두고, 새 편집의 근거('이번 변경 …' 줄들)를 날짜 머리와 함께 뒤에 붙인다.
        같은 근거가 또 오면(같은 편집을 다시 검사) 붙이지 않는다. 너무 길어지면 중간 편집을 '그 사이 N번'으로 접는다."""
        old = [str(x) for x in (old or [])]
        new = [str(x) for x in (new or [])]
        head = cls._STACK_HEAD.get(code, "또 바뀜")   # 코드마다 맞는 머리 — 'Rev만 갱신'에도 'Rev가 그대로인 채'라 적었다 (검토43 A 낮음 5)
        if not old:
            return new
        body = new[1:] if len(new) > 1 else new
        if not body or all(line in old for line in body):
            return old
        # 처음 편집 블록(첫 머리 줄 전까지)과 이미 붙은 블록들로 나눈다
        first, blocks, cur = [], [], None
        folded = 0
        for line in old:
            if line.startswith(cls._STACK_MARK):
                m = re.match(r"── 그 사이 (\d+)번 더 바뀜", line)
                if m:
                    folded += int(m.group(1))
                    continue
                cur = [line]
                blocks.append(cur)
            elif cur is None:
                first.append(line)
            else:
                cur.append(line)
        when = datetime.now().astimezone().strftime("%m-%d %H:%M")
        # 머리에 ': '를 쓰지 않는다 — 화면이 근거 줄을 ': '에서 두 칸으로 가른다
        blocks.append([f"{cls._STACK_MARK}{when} 검사 — {head}"] + body)
        keep = cls._STACK_KEEP - 1
        if len(blocks) > keep:
            folded += len(blocks) - keep
            blocks = blocks[-keep:]
        out = list(first)
        if folded:
            out.append(f"{cls._STACK_MARK}그 사이 {folded}번 더 바뀜 (변경 이력에 모두 있습니다)")
        for b in blocks:
            out += b
        return out

    def past_version(self, path: str, sha: str, before_snapshot: int | None) -> tuple | None:
        """(기록 시각 ISO, 그 검사에서 **들어온** 판인가). 바뀐 뒤 지문(new_sha256)이 맞으면 그 검사 때 들어온 판, 바뀌기 전
        지문(old_sha256)만 맞으면 그 검사 **전까지** 있던 판 — 한데 보면 날짜가 한 검사 늦었다 (검토43 C 중간 3)."""
        if not sha:
            return None
        for col, came_in in (("new_sha256", True), ("old_sha256", False)):
            row = self.conn.execute(
                f"SELECT detected_at FROM changes WHERE path = ? AND {col} = ? "
                "AND (? IS NULL OR snapshot_id < ?) ORDER BY id DESC LIMIT 1",
                (path, sha, before_snapshot, before_snapshot)).fetchone()
            if row:
                return row[0], came_in
        return None

    def past_version_seen(self, path: str, sha: str, before_snapshot: int | None) -> str | None:
        """이 경로가 **전에** 이 지문(sha)이었던 적이 있으면 그 기록 시각(ISO), 없으면 None — 옛 판으로 되돌아간 표지.
        바뀌기 전 지문(old_sha256)과 바뀐 뒤 지문(new_sha256)을 모두 본다."""
        if not sha:
            return None
        row = self.conn.execute(
            "SELECT detected_at FROM changes WHERE path = ? AND (old_sha256 = ? OR new_sha256 = ?) "
            "AND (? IS NULL OR snapshot_id < ?) ORDER BY id DESC LIMIT 1",
            (path, sha, sha, before_snapshot, before_snapshot)).fetchone()
        return row[0] if row else None

    def pre_issue_sha(self, path: str, code: str) -> str | None:
        """이 파일의 열린 이슈(code)가 처음 잡힌 검사에서 **바뀌기 전** 해시 — 그 편집이 되돌려졌는지 가리는 기준."""
        row = self.conn.execute(
            "SELECT snapshot_id FROM issues WHERE path = ? AND code = ? AND resolved_at IS NULL "
            "ORDER BY id LIMIT 1", (path, code)).fetchone()
        if not row or row[0] is None:
            return None
        ch = self.conn.execute(
            "SELECT old_sha256 FROM changes WHERE path = ? AND snapshot_id = ? AND old_sha256 IS NOT NULL "
            "ORDER BY id LIMIT 1", (path, row[0])).fetchone()
        return ch[0] if ch else None

    def unrevised_pending(self, path: str) -> bool:
        """이 파일의 마지막 'Rev 미갱신' 뒤로 Rev를 올린 적이 없는가(열림·닫힘·기간 무관). 그렇다면 지금의 'Rev만 올림'은 그 편집의
        정식 개정이다 — 14일 창이라 발행 주기가 2~3주인 집은 [처리함] 뒤 정상 개정이 'Rev만 갱신' 경고가 됐다 (검토50 D 중간 2)."""
        row = self.conn.execute(
            "SELECT MAX(snapshot_id) FROM issues WHERE path = ? AND code = 'CONTENT_CHANGED_REV_SAME'", (path,)).fetchone()
        # 첫 편집 유예로 경고 없이 넘긴 편집도 — 그 뒤의 'Rev만 올림'은 그 편집의 정식 개정이다 (기능 검토 2026-11-02 J1)
        g = self.conn.execute(
            "SELECT MAX(c.snapshot_id) FROM changes c JOIN change_details d ON d.change_id = c.id "
            "WHERE c.path = ? AND d.items_json LIKE ?", (path, "%" + self._GRACE_MARKS[0][1] + "%")).fetchone()
        snaps = [x for x in ((row or [None])[0], (g or [None])[0]) if x is not None]
        if not snaps:
            return False
        row = (max(snaps),)
        for (js,) in self.conn.execute(
                "SELECT d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                "WHERE c.path = ? AND c.snapshot_id > ?", (path, row[0])):
            try:
                its = json.loads(js or "[]")
            except ValueError:
                continue
            if any(self._is_rev_bump_item(i, path) for i in its):
                return False
        return True

    # 'Rev 미갱신'을 내지 않고 넘긴 편집의 표식 — 첫 편집 유예(cli.FIRST_EDIT_MARK)·Rev 올림 뒤 후속 편집 유예
    _GRACE_MARKS = (("first", "첫 편집이라 참고로만 남깁니다"), ("bump", "올린 파일의 후속 편집으로 봅니다"))

    def first_edit_pending(self, path: str, days: int | None = None, prev: str | None = None):
        """이 파일에 'Rev 미갱신'을 넘긴 편집(첫 편집 유예·Rev 올림 뒤 후속 편집)이 있고 그 뒤 Rev를 올린 적이 없으면
        (변경 id, 검사 시각, 'first'|'bump') — 지금 판정 중인 편집이 '또' 바뀐 것이다 (기능 검토 2026-11-02 J1). 없으면 None.
        유예는 **Rev가 바뀔 때까지 파일당 한 번**이다 — '마지막 유예부터 days일' 창이 지나면 다시 유예해, 8일 간격으로 고치는
        파일은 영영 참고로만 남았다 (재검토 rr066 judge 6, DECISIONS 2026-11-02 J1 개정). days는 옛 호출 호환용(쓰지 않는다).
        이름·폴더를 바꾼 파일은 옛 경로의 유예를 이어 본다(prev = 오늘 옮겨진 옛 경로) — 바꿀 때마다 유예가 새로 났다 (judge 5).
        지금 판정 중인 변경의 상세는 아직 저장 전이라 세지 않는다."""
        paths = self.path_lineage(path, prev)
        q = ",".join("?" * len(paths))
        cur = self.conn.execute(
            "SELECT c.id, c.detected_at, c.path, d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
            f"WHERE c.path IN ({q}) ORDER BY c.id DESC", paths)
        for cid, at, p_, js in cur:
            try:
                its = json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            if any(self._is_rev_bump_item(i, p_) for i in its if isinstance(i, dict)):
                return None                 # 가장 최근 유예보다 Rev 올림이 나중 — 새 개정 주기
            kind = next((k for k, mark in self._GRACE_MARKS for i in its if isinstance(i, dict)
                         and i.get("kind") == "CHECK_SKIPPED" and mark in str(i.get("new") or "")), None)
            if kind is not None:
                return (cid, at, kind)
        return None

    # 옮겨진 파일의 '추가' 쪽 참고 — 옛 경로를 읽는다 (cli._pair_moves·_compare_modified 문구)
    _MOVED_FROM = re.compile(r"^이름·위치만 바뀜 — 이전: (.+) \(내용 동일\)$|^(.+?\.[A-Za-z0-9]{2,5})에서 옮겨짐")

    def path_lineage(self, path: str, prev: str | None = None, depth: int = 12) -> list:
        """이 파일의 지금 경로와 옛 경로들(이름 바꿈·폴더 이동을 거슬러) — [지금, 직전, …]. prev는 이번 검사에서 옮겨진 옛 경로."""
        out = [path]
        cur = path
        if prev and prev != path:
            out.append(prev)
            cur = prev
        for _ in range(depth):
            nxt = None
            for (js,) in self.conn.execute(
                    "SELECT d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                    "WHERE c.path = ? AND (d.items_json LIKE ? OR d.items_json LIKE ?) ORDER BY c.id DESC",
                    (cur, "%이름·위치만 바뀜 — 이전: %", "%에서 옮겨짐%")):
                try:
                    its = json.loads(js or "[]")
                except (ValueError, TypeError):
                    continue
                for i in its if isinstance(its, list) else ():
                    if isinstance(i, dict) and i.get("kind") == "CHECK_SKIPPED":
                        m = self._MOVED_FROM.match(str(i.get("new") or ""))
                        if m:
                            nxt = (m.group(1) or m.group(2) or "").strip()
                            break
                if nxt:
                    break
            if not nxt or nxt in out:
                break
            out.append(nxt)
            cur = nxt
        return out

    def path_successor(self, path: str, depth: int = 12, since: str = "") -> str:
        """옛 경로에서 지금 경로로 — 그 뒤 '이름·위치만 바뀜 — 이전: 옛 경로'·'옛 경로에서 옮겨짐'이 적힌 변경을 따라간다.
        since(검사 시각)를 주면 그 뒤 변경만 훑는다(시각 색인) — 상세 전체를 날마다 훑지 않게."""
        cur = path
        seen = {path}
        for _ in range(depth):
            nxt = None
            for p_, js in self.conn.execute(
                    "SELECT c.path, d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                    "WHERE c.detected_at >= ? AND c.kind IN ('added', 'modified') "
                    "AND (d.items_json LIKE ? OR d.items_json LIKE ?) ORDER BY c.id DESC",
                    (since or "", f"%이름·위치만 바뀜 — 이전: {cur} (내용 동일)%", f"%{cur}에서 옮겨짐%")):
                try:
                    its = json.loads(js or "[]")
                except (ValueError, TypeError):
                    continue
                for i in its if isinstance(its, list) else ():
                    m = self._MOVED_FROM.match(str(i.get("new") or "")) if isinstance(i, dict) \
                        and i.get("kind") == "CHECK_SKIPPED" else None
                    if m and (m.group(1) or m.group(2) or "").strip() == cur and p_ != cur:
                        nxt = p_
                        break
                if nxt:
                    break
            if not nxt or nxt in seen:
                break
            seen.add(nxt)
            cur = nxt
        return cur

    def first_edit_graces(self, since: str, until: str) -> list:
        """첫 편집 유예를 쓴 변경 [(변경 id, 경로, 검사 시각)] — since ≤ 시각 ≤ until."""
        mark = self._GRACE_MARKS[0][1]
        return self.conn.execute(
            "SELECT c.id, c.path, c.detected_at FROM changes c JOIN change_details d ON d.change_id = c.id "
            "WHERE c.detected_at >= ? AND c.detected_at <= ? AND d.items_json LIKE ? ORDER BY c.id",
            (since, until, f"%{mark}%")).fetchall()

    def rev_bumped_after(self, paths, change_id: int) -> bool:
        """그 변경 뒤 이 경로들(한 파일의 옛·지금 경로)에서 Rev를 올린 적이 있나."""
        paths = list(paths)
        q = ",".join("?" * len(paths))
        for p_, js in self.conn.execute(
                "SELECT c.path, d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                f"WHERE c.path IN ({q}) AND c.id > ?", (*paths, change_id)):
            try:
                its = json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            if any(self._is_rev_bump_item(i, p_) for i in its if isinstance(i, dict)):
                return True
        return False

    def rev_same_issue_since(self, paths, at: str) -> bool:
        """그 시각 뒤 이 경로들에 'Rev 미갱신'이 열린 적이 있나(지금 열림·닫힘 모두)."""
        paths = list(paths)
        q = ",".join("?" * len(paths))
        return self.conn.execute(
            f"SELECT 1 FROM issues WHERE code = 'CONTENT_CHANGED_REV_SAME' AND path IN ({q}) AND detected_at > ? LIMIT 1",
            (*paths, str(at or ""))).fetchone() is not None

    def has_open_issue(self, path: str, code: str, recent_days: int = 14) -> bool:
        """열려 있거나 최근 recent_days 안에 닫힌 이슈가 있는가 — 담당자가 'Rev 미갱신'을 먼저
        [처리함]으로 닫고 Rev를 올리는 순서도 흔하다 (2026-09-05 재검토)."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=recent_days)).isoformat()
        row = self.conn.execute(
            "SELECT 1 FROM issues WHERE path = ? AND code = ? AND "
            "(resolved_at IS NULL OR resolved_at >= ?) LIMIT 1",
            (path, code, cutoff)).fetchone()
        return row is not None

    def issues(self, project: str | None = None, resolved: bool = False) -> list[dict]:
        """확인 필요 이력 (최신순). 프로젝트 필터 가능. resolved=True면 처리된 것.

        처리하면 흔적 없이 사라져 '누가 언제 처리했는지'를 볼 곳이 없었다
        (2026-09-02 처음 보는 사람 검토)."""
        sql = ("SELECT id, detected_at, code, path, project, message, evidence, "
               "snapshot_id, resolved_at, resolved_by FROM issues WHERE resolved_at IS "
               + ("NOT NULL " if resolved else "NULL "))
        params: tuple = ()
        if project:
            sql += "AND project = ? "
            params = (project,)
        sql += "ORDER BY " + ("resolved_at DESC" if resolved else "id DESC")
        keys = ("issue_id", "detected_at", "code", "path", "project", "message",
                "evidence", "snapshot_id", "resolved_at", "resolved_by")
        out = []
        for row in self.conn.execute(sql, params):
            d = dict(zip(keys, row))
            # 근거 한 줄이 JSON이 아니면(손상·옛 기록) 그 글자를 그대로 근거 한 줄로 — 한 줄 때문에 이 목록을 쓰는 모든 화면이 죽었다
            # (2026-11-21 검토 X2 M1: 범위 밖 프로젝트의 손상 줄 하나가 사내망 변경 상세 전부를 500으로). 기록은 고치지 않는다
            raw = d["evidence"]
            try:
                ev = json.loads(raw) if raw else []
            except (TypeError, ValueError):
                ev = [str(raw)]
            d["evidence"] = ev if isinstance(ev, list) else [str(raw)]
            out.append(d)
        return out

    def issue_by_id(self, issue_id) -> dict | None:
        """확인 필요 하나(열림·처리됨 모두) — issues()와 같은 칸. 없으면 None (사내망 확인 필요 하나 보기, 2026-11-23)."""
        if not isinstance(issue_id, int) or not (0 <= issue_id < 2 ** 62):
            return None
        row = self.conn.execute(
            "SELECT id, detected_at, code, path, project, message, evidence, snapshot_id, resolved_at, resolved_by "
            "FROM issues WHERE id = ?", (issue_id,)).fetchone()
        if not row:
            return None
        d = dict(zip(("issue_id", "detected_at", "code", "path", "project", "message", "evidence", "snapshot_id",
                      "resolved_at", "resolved_by"), row))
        try:
            ev = json.loads(d["evidence"]) if d["evidence"] else []
        except (TypeError, ValueError):
            ev = [str(d["evidence"])]
        d["evidence"] = ev if isinstance(ev, list) else [str(d["evidence"])]
        return d

    def changes_for_paths(self, paths, snapshot_id: int | None = None) -> dict:
        """파일 경로 → 전/후 비교를 볼 수 있는 변경 id.

        검토 필요 항목에서 그 파일의 비교 화면으로 바로 갈 수 있게 한다.
        같은 검사(snapshot)의 변경을 우선하고, 없으면 가장 최근 변경을 쓴다.
        내용 비교 기록(change_details)이 있는 변경만 — 링크를 눌렀는데
        '비교 기록이 없습니다'가 나오면 헛걸음이다 (2026-09-02)."""
        paths = [p for p in dict.fromkeys(paths) if p]
        if not paths:
            return {}
        marks = ",".join("?" * len(paths))
        rows = self.conn.execute(
            f"SELECT c.path, c.id, c.snapshot_id FROM changes c "
            f"JOIN change_details d ON d.change_id = c.id "
            f"WHERE c.path IN ({marks}) ORDER BY c.id ASC", tuple(paths)).fetchall()
        out: dict = {}
        for path, cid, snap in rows:            # 뒤(최신)가 앞을 덮는다
            out[path] = cid
        if snapshot_id is not None:             # 같은 검사 것이 있으면 그쪽으로
            for path, cid, snap in rows:
                if snap == snapshot_id:
                    out[path] = cid
        return out

    def auto_resolve_issues(self, keep: set, changed_paths: set, projects: set,
                            readable: set | None = None, present: set | None = None,
                            rev_changed: set | None = None, rev_raised: set | None = None,
                            superseded: set | None = None, attributed: dict | None = None,
                            frozen_codes=frozenset(), replaced_by: dict | None = None) -> int:
        """열린 이슈 중 이번 검사에서 다시 검출되지 않은 것을 '자동 해소'로 닫는다.
        frozen_codes: 설정에서 끈 검사의 코드(파일럿판의 도면 간 대조) — 끈 동안 그 코드의 열린 카드는 닫지 않고, 닫힌 카드에
        '사라짐'(gone_at)도 찍지 않는다. 검사를 안 했으니 재검출이 없는 것은 고쳐졌다는 뜻이 아니다 (2026-11-13)
        파일 단위 판정(Rev)은 그 파일이 이번에 바뀌었을 때만, 교차 검사(도면 간·BOM)는
        그 프로젝트가 이번에 검사됐을 때만 — 검사하지 않은 것을 해소로 오인하지 않게.
        readable: 이번에 내용을 읽은 경로 — 못 읽은(손상·잠김) 파일의 이슈는 닫지 않는다.
        present: 이번 스냅샷의 경로 — 없어진 파일의 이슈는 '파일 삭제됨'으로 닫는다.
        (2026-09-03 검토·재검토)"""
        rows = self.conn.execute(
            "SELECT id, code, path, project, message, evidence FROM issues "
            "WHERE resolved_at IS NULL").fetchall()
        ev_of = {r[0]: r[5] for r in rows}
        rows = [r[:5] for r in rows]
        keep_keys = {self.issue_key(*k) for k in keep}
        keep_loose: dict = {}
        for k in keep_keys:
            keep_loose[self._loose_key(k)] = keep_loose.get(self._loose_key(k), 0) + 1
        open_loose: dict = {}
        for _iid, code, path, _proj, msg in rows:
            lk = self._loose_key(self.issue_key(code, path, msg))
            open_loose[lk] = open_loose.get(lk, 0) + 1
        now = datetime.now(timezone.utc).isoformat()
        n = 0
        pend = self._rejudge_ids()         # 판을 올리기 전에 열린 교차 이슈 — 이번에 한 번 인용 파일 규칙 없이 (R7-D2)
        judged: set = set()
        for iid, code, path, proj, msg in rows:
            if code in frozen_codes:
                continue                   # 끈 검사의 카드 — 갱신도 해소도 하지 않는다(재판정 대기도 그대로 둔다)
            k = self.issue_key(code, path, msg)
            if k in keep_keys:
                judged.add(iid)            # 새 판도 다시 잡았다 — 재판정 끝
                continue
            # 번호 유무만 다른 짝이 오늘·열린 쪽 모두 하나뿐이면 같은 이슈(save_issues가 이미 갱신했다)
            lk = self._loose_key(k)
            if keep_loose.get(lk, 0) == 1 and open_loose.get(lk, 0) == 1 \
                    and any(self._loose_pair_ok(k, x) for x in keep_keys if self._loose_key(x) == lk):
                judged.add(iid)
                continue
            cross = code in ("TAG_MISMATCH_ACROSS_DRAWINGS", "BOM_MISMATCH")
            why = None
            if replaced_by and iid in replaced_by:
                # BOM 새 판(새 이름)으로 대체된 옛 판의 카드인데 새 판에서는 안 잡혔다 — 호출부(cli._carry_bom_cards)가 새 판을 오늘
                # 읽었고 그 프로젝트를 검사한 것만 넘긴다. 옛 판이 지워졌어도 '파일이 삭제됨'보다 이 사유가 사실이다 (pv2 B-1)
                why = f"자동 해소 — 새 판으로 대체됨 — {str(replaced_by[iid]).rsplit('/', 1)[-1]}에서 재검출되지 않음"
            elif present is not None and path not in present:
                why = "자동 해소 — 파일이 삭제됨"
            elif superseded and path in superseded and not cross and code in (
                    "CONTENT_CHANGED_REV_SAME", "REV_REGRESSED", "REV_BLOCK_MISMATCH"):
                # 같은 폴더에 새 판(_rev2·_최종)이 생기거나 보관 폴더로 옮긴 구판의 'Rev 미갱신'은 그 파일을 다시 고칠 일이 없어
                # 영영 열려 있었다 — 90일에 열린 42건 중 8건 (검토66 B5)
                why = "자동 해소 — 새 판으로 대체됨(구판)"
            elif readable is not None and path not in readable:
                continue                       # 못 읽은 파일 — 해소로 오인하지 않는다
            elif cross and readable is not None and present is not None and any(
                    c_ in present and c_ not in readable for c_ in self._evidence_paths(ev_of.get(iid)) if "/" in c_):
                # 근거로 인용된 **다른** 파일을 오늘 못 읽었으면(다른 프로그램이 잠금) 불일치가 안 나온 것은 고쳐진 게 아니다 —
                # '자동 해소'로 닫혔다가 다음 날 '다시 생김'으로 되살아났다 (검토63 D-F6)
                continue
            elif code == "REV_REGRESSED" and rev_changed is not None and path not in rev_changed:
                continue                       # Rev는 그대로 두고 내용만 고친 날 '거꾸로 감'이 해소로 닫혔다 (검토46 C 중간 2)
            elif cross and attributed and path in attributed and proj \
                    and _nfc_s(attributed[path]) != _nfc_s(proj):
                # 그 파일의 귀속이 오늘 다른 프로젝트로 옮겨졌다 — 옛 프로젝트에서 안 잡힌 것은 고쳐진 게 아니다. 폴더 다수결이 2:2로
                # 갈린 날 BOM이 부서 폴더로 뒤집히며 실제로 더 커진 불일치가 '재검출되지 않음'으로 닫혔다 (검토20 r13 3). 열어 둔다
                continue
            elif cross and proj in projects and present is not None and iid not in pend and self._cited_untouched(
                    ev_of.get(iid), path, changed_paths, present):
                # 근거에 인용된 파일이 **하나도 안 바뀌었고 모두 그대로 있는데** 불일치가 사라졌다 = 고쳐진 게 아니라 비교 대상에서
                # 빠진 것(같은 번호·같은 Rev 두 파일의 현행 판정이 바뀜 등). '해소'로 닫으면 진짜 불일치가 메일에서
                # '해소된 검토 필요'로 사라졌다 (검토54 ③11·14) — 연 채로 둔다. 판을 올리기 전에 열린 것(pend)은 예외 — 옛 판의
                # 추출·검사 규칙이 낸 것이면 새 판이 안 잡는 것이 곧 판정이다 (재검토 2026-10-28 R7-D2)
                continue
            elif (cross and proj in projects) or (not cross and path in changed_paths):
                if cross:
                    judged.add(iid)
                why = (self.revert_why.get((path, code)) if not cross else None) \
                    or ("자동 해소 — Rev를 올림(개정 발행)" if code == "CONTENT_CHANGED_REV_SAME" and rev_raised
                        and path in rev_raised else None) \
                    or ("자동 해소 — Rev가 바뀜" if code == "CONTENT_CHANGED_REV_SAME" and rev_changed
                        and path in rev_changed else None) \
                    or ("자동 해소 — 판을 올린 뒤 다시 검사했을 때 재검출되지 않음 (옛 판이 낸 확인 필요였을 수 있음)"
                        if cross and iid in pend else None) \
                    or "자동 해소 — 다시 검사했을 때 재검출되지 않음"   # 사유를 밝힌다 (검토46 B G42)
            if why:
                self.conn.execute(
                    "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?",
                    (now, why, iid))
                n += 1
                judged.add(iid)
        if pend:
            # 판정한 것·이미 닫힌 것은 대기에서 뺀다 — 한 번만. 못 읽은 파일로 미룬 것·검사 안 한 프로젝트 것은 남는다
            still_open = {r_[0] for r_ in rows}
            left = sorted((pend - judged) & still_open)
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                              (ISSUE_REJUDGE_KEY, json.dumps(left)))
        # 사람이 닫은 교차 이슈(도면 간·도면-BOM)가 이번에 그 프로젝트를 검사했는데 다시 나오지 않았다 = 고쳐졌다 — 그 시각을
        # 남겨, 나중에 같은 값으로 다시 어긋나면 새 이슈가 되게 한다 (검토43 B 중간 8)
        for iid, code, path, proj, msg in self.conn.execute(
                "SELECT id, code, path, project, message FROM issues WHERE resolved_at IS NOT NULL AND gone_at IS NULL "
                "AND code IN ('BOM_MISMATCH', 'TAG_MISMATCH_ACROSS_DRAWINGS')").fetchall():   # 기간 창 없음 (검토50 D 중간 1)
            if code in frozen_codes:
                continue
            k = self.issue_key(code, path, msg)
            if proj not in projects or k in keep_keys:
                continue
            # 열린 이슈와 같은 규칙 — 못 읽은 파일(잠김·시간 상한)은 '사라짐'이 아니고, 번호 유무만 다른 짝은 같은 이슈다.
            # 빠졌을 때 고친 적 없는 불일치가 다음 날 '재발'로 다시 메일에 나왔다 (검토44 A 중간 4)
            if readable is not None and path not in readable:
                continue
            if any(self._loose_key(x) == self._loose_key(k) and self._loose_pair_ok(k, x) for x in keep_keys):
                continue
            self.conn.execute("UPDATE issues SET gone_at = ? WHERE id = ?", (now, iid))
        # 표제란 Rev≠리비전 블록은 파일 단위라 그 파일을 이번에 다시 검사했을 때(바뀜·읽힘)만 '사라짐'을 남긴다 (검토59 F2-1)
        for iid, code, path, msg in self.conn.execute(
                "SELECT id, code, path, message FROM issues WHERE resolved_at IS NOT NULL AND gone_at IS NULL "
                "AND code = 'REV_BLOCK_MISMATCH'").fetchall():
            if path not in changed_paths or self.issue_key(code, path, msg) in keep_keys:
                continue
            if readable is not None and path not in readable:
                continue
            self.conn.execute("UPDATE issues SET gone_at = ? WHERE id = ?", (now, iid))
        self.conn.commit()
        self.revert_why = {}                 # 이번 검사 것만 — 다음 검사에 새지 않게
        return n

    @classmethod
    def _cited_untouched(cls, ev_json, path: str, changed_paths: set, present: set) -> bool:
        """교차 이슈의 근거 파일(전체 경로로 인용된 것)이 모두 이번 스냅샷에 있고 하나도 바뀌지 않았나.
        경로를 못 읽으면(옛 근거·파일 이름만) False — 예전처럼 판정한다."""
        cited = [c for c in cls._evidence_paths(ev_json) if "/" in c]
        if not cited:
            return False
        if path in changed_paths:
            return False
        return all(c in present for c in cited) and not any(c in changed_paths for c in cited)

    def reopen_issue(self, issue_id: int) -> bool:
        """[처리함]을 잘못 눌렀을 때 되돌린다 — 되돌릴 길이 없어 같은 경고가 다시 검출될 때까지 사라졌다
        (검토38 R9 중간 2). 사람이 닫은 것만(자동 해소는 파일이 바뀌면 다시 판정된다)."""
        cur = self.conn.execute(
            "UPDATE issues SET resolved_at = NULL, resolved_by = NULL WHERE id = ? AND resolved_at IS NOT NULL "
            "AND IFNULL(resolved_by, '') NOT LIKE '자동 해소%'", (issue_id,))
        self.conn.commit()
        return cur.rowcount > 0

    def resolve_issue(self, issue_id: int, by: str = "") -> bool:
        """이상 징후를 '처리함'으로 닫는다 — 목록·누적 숫자에서 빠진다.
        기록은 지우지 않는다 (같은 내용이 다시 검출되면 새 이슈로 다시 쌓인다).

        실제로 닫았으면 True. 없는 id였는데 "표시했습니다"라고 답하던 것을 막는다
        (2026-09-09 웹 검토 낮음 9)."""
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute(
            # 이미 닫힌 것은 건드리지 않는다 — 한꺼번에 처리가 자동 해소된 이슈의 사유를 사람 이름으로 덮었다 (검토45 A 낮음)
            "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ? AND resolved_at IS NULL",
            (now, by, issue_id))
        self.conn.commit()
        return cur.rowcount > 0

    def _secret(self) -> str:
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = 'ack_secret'").fetchone()
        if row:
            return row[0]
        s = secrets.token_hex(16)
        # 화면 요청 여럿이 첫 비밀을 동시에 만들면 UNIQUE 위반으로 요청이 죽었다 — 먼저 쓴 것을 쓴다 (검토20 r14 시험 중 발견)
        self.conn.execute("INSERT OR IGNORE INTO meta (key, value) VALUES ('ack_secret', ?)", (s,))
        self.conn.commit()
        row = self.conn.execute("SELECT value FROM meta WHERE key = 'ack_secret'").fetchone()
        return row[0] if row else s

    def ack_token(self, change_id: int) -> str:
        """확인 링크용 토큰. 링크를 아는 사람만 확인을 저장할 수 있다 (CSRF 방지)."""
        return hmac.new(self._secret().encode(), str(change_id).encode(),
                        "sha256").hexdigest()[:16]

    def csrf_token(self) -> str:
        """웹 대시보드 폼 공용 CSRF 토큰 (설치별 고정).

        127.0.0.1 바인딩이어도 CSRF는 못 막는다 — 요청이 사용자 브라우저에서
        나가기 때문. 외부 페이지는 이 토큰을 읽을 수 없으므로 폼 위조가 차단된다."""
        return hmac.new(self._secret().encode(), b"csrf-form",
                        "sha256").hexdigest()[:32]

    def prune_details(self, days: int = 90, now: datetime | None = None) -> int:
        """보존 기간이 지난 무거운 기록을 지워 DB 비대화를 막는다.
        ①변경 상세(diff+캡처 JSON — 캡처 포함 시 수 MB)
        ②오래된 스냅샷의 파일 목록 — 매 검사마다 전체 파일 목록이 기록되어
          파일 1,000개당 검사 1회 약 172KB씩 영구 누적됨 (2026-08-25 확장성 검토).
          비교에 쓰는 최신 스냅샷은 기간과 무관하게 보존한다.
        변경 이력(changes)·확인(acks)·추출 캐시는 남긴다. 돌려주는 값: 지운 행 수."""
        # now: 기준 시각 — PC 시계가 튄 동안은 '마지막 정상 검사 + 그 뒤 검사 수'를 쓴다 (검토47 E 중간 1)
        # days <= 0('정리 안 함'): 사진은 그대로 두고, 아래 파일 목록·고아 추출본 정리만 한다 — 이 둘이 보존 일수에
        # 묶여 있어 0이면 매 검사 전체 파일 목록이 영영 쌓였다(10만 파일에 검사마다 +20MB, 검토20 r15-2).
        # 이때 추출본은 **어느 변경에든** 걸린 판이면 남긴다(cutoff '' = 모든 변경)
        n = 0
        if days > 0:
            cutoff = ((now or datetime.now(timezone.utc)) - timedelta(days=days)).isoformat()
            # 사진(captures — 변경 하나에 수 MB)만 지운다. 근거 항목·오탐 숨김(누가 언제)·사람 메모는 감사 기록이라
            # 남긴다 — 상세를 통째로 지우니 조용한 변경이 미확인으로 되살아났고(검토38 R3 차단 3), 개정 근거와 숨김
            # 기록이 사라져 화면이 '첫 등록이거나 추출 대상 아님'이라는 틀린 사유를 댔다 (검토39 P5 차단 1)
            cur = self.conn.execute(
                "UPDATE change_details SET captures_json = NULL WHERE captures_json IS NOT NULL AND change_id IN "
                "(SELECT id FROM changes WHERE detected_at < ?)", (cutoff,))
            n = cur.rowcount
        else:
            cutoff = ""
        # 파일 목록은 최신 스냅샷만 읽는다 — 90일치 4만 건씩(≈360만 행)을 둘 이유가
        # 없다. 최신 1회분만 남긴다 (2026-09-02 재검토)
        cur = self.conn.execute(
            "DELETE FROM files WHERE snapshot_id NOT IN ("
            " SELECT id FROM snapshots ORDER BY id DESC LIMIT 1)")
        n += cur.rowcount
        # 추출 캐시: 최신 스냅샷에도 없고 보존 기간 안의 변경에도 안 걸리는 판은 고아
        # — 모든 판의 전문이 영구 누적되던 것 (2026-09-02 재검토)
        cur = self.conn.execute(
            # 'sha:묶음' 열쇠(같은 바이트의 다른 확장자 추출본, F2)도 앞 64자 지문으로 본다
            "DELETE FROM extracts WHERE substr(sha256, 1, 64) NOT IN ("
            " SELECT sha256 FROM files WHERE snapshot_id = (SELECT MAX(id) FROM snapshots))"
            " AND substr(sha256, 1, 64) NOT IN ("
            " SELECT old_sha256 FROM changes WHERE detected_at >= ? AND old_sha256 IS NOT NULL)"
            " AND substr(sha256, 1, 64) NOT IN ("
            " SELECT new_sha256 FROM changes WHERE detected_at >= ? AND new_sha256 IS NOT NULL)",
            (cutoff, cutoff))
        n += cur.rowcount
        self.conn.commit()
        return n

    def set_change_project(self, change_id: int, project: str, how: str | None = None, why: str | None = None,
                           by: str | None = None, commit: bool = True) -> None:
        """변경의 귀속과 그 근거(부호 how — watcher.project.HOW_CODES, 출처 글 why). 근거를 모르면 NULL('모름').
        고칠 때마다 project_log에 한 줄 덧붙인다 — 첫 줄이 원래 귀속 (2026-11-17 R1)."""
        self.conn.execute("UPDATE changes SET project = ?, project_how = ?, project_why = ? WHERE id = ?",
                          (project, how, why, change_id))
        self._log_project([(change_id, project, how, why)], by=by)
        if commit:
            self.conn.commit()

    def _log_project(self, rows, by: str | None = None, at: str | None = None) -> None:
        """귀속 이력 덧붙이기 — rows: (change_id, project, how, why). 표가 없으면(옛 DB를 attach로 연 경우) 조용히 건너뛴다."""
        rows = [r_ for r_ in rows]
        if not rows:
            return
        at = at or datetime.now(timezone.utc).isoformat()
        try:
            self.conn.executemany("INSERT INTO project_log (change_id, at, project, how, why, by) VALUES (?, ?, ?, ?, ?, ?)",
                                  [(cid, at, pj, how, why, by or None) for cid, pj, how, why in rows])
        except sqlite3.OperationalError:
            pass

    def attribution(self, change_id: int) -> dict | None:
        """변경의 귀속과 근거 — {project, how, how_label, why, original: {project, how, how_label, why, at, by}|None,
        history: [...]}. 옛 행(근거 칸 NULL)은 how None·how_label '모름'. 없는 변경은 None."""
        from watcher.project import how_label
        try:
            row = self.conn.execute("SELECT project, project_how, project_why FROM changes WHERE id = ?",
                                    (int(change_id),)).fetchone()
        except sqlite3.OperationalError:          # 근거 칸이 없는 옛 DB(사내망 attach)
            row = self.conn.execute("SELECT project, NULL, NULL FROM changes WHERE id = ?", (int(change_id),)).fetchone()
        if row is None:
            return None
        try:
            hist = [{"at": at, "project": pj, "how": how, "how_label": how_label(how), "why": why, "by": by}
                    for at, pj, how, why, by in self.conn.execute(
                        "SELECT at, project, how, why, by FROM project_log WHERE change_id = ? ORDER BY rowid", (int(change_id),))]
        except sqlite3.OperationalError:
            hist = []
        return {"project": row[0] or "미분류", "how": row[1], "how_label": how_label(row[1]), "why": row[2],
                "original": hist[0] if hist else None, "history": hist}

    def amend_inflight_sha(self, path: str, old_sha: str, new_sha: str, size=None, mtime=None) -> int:
        """**진행 중인 검사**(run_in_progress = 가장 최근 스냅샷)의 변경 한 줄의 새 지문을 실제로 읽은 판으로 맞춘다 — 해시한
        뒤 읽기 전에 파일이 또 저장된 경우 (검토63 B-F5). 확정된 기록은 고치지 않는다(기록 불변 허용 목록: 확정 전 기록만).
        돌려주는 값: 고친 변경 줄 수."""
        live = self.get_meta("run_in_progress")
        top = self.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()[0]
        if live is None or top is None or str(live) != str(top):
            return 0
        self.conn.execute("UPDATE files SET sha256 = ?, size = COALESCE(?, size), mtime = COALESCE(?, mtime) "
                          "WHERE path = ? AND sha256 = ? AND snapshot_id = ?", (new_sha, size, mtime, path, old_sha, top))
        return self.conn.execute(
            "UPDATE changes SET new_sha256 = ? WHERE path = ? AND new_sha256 = ? AND snapshot_id = ?",
            (new_sha, path, old_sha, top)).rowcount or 0

    # ── 변경 한 줄 요약 (2026-11-17 R1) — watcher.summary의 규칙 하나로 만들고, 기록할 때 저장한다

    _LOW_ISSUES = ("TAG_PATTERN_UNRECOGNIZED", "BOM_SPEC_COLUMN_UNRECOGNIZED")     # 낮음 — 안내일 뿐 '확인 필요'가 아니다
    _CROSS_ISSUES = ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS")
    _TAG_IN_MSG = re.compile(r"\]\s*([^:\s\]]+):")

    _TOKEN_SPLIT = re.compile(r"[^\w\-]+")
    _ONE_TOKEN = re.compile(r"[\w\-]+")

    @classmethod
    def _item_tokens(cls, items) -> tuple[set, str]:
        """변경 항목이 건드린 낱말 묶음(대문자)과 그 글 — 태그는 **낱말 경계**로 견준다: 'M-10'은 'M-101'을 건드린 변경에 붙지 않고
        'M-10.SPEC'·'M-10 5.5kW'에는 붙는다 (V1-4: items_json 부분 문자열로 골라 M-10 불일치가 M-101 BOM 변경에 붙었다)."""
        bits = []
        for it in items or ():
            if isinstance(it, dict):
                for k in ("key", "old", "new", "label"):
                    v = it.get(k)
                    if v not in (None, ""):
                        bits.append(str(v))
        blob = " ".join(bits).upper()
        return {t for t in cls._TOKEN_SPLIT.split(blob) if t}, blob

    def _issues_opened_by(self, chs: list) -> dict:
        """변경 → 그 변경으로 열린 검토 필요 [{id, code, path, message, evidence, cited}]. 같은 검사에서 처음 잡힌 것 가운데 그 파일의 것,
        도면-BOM·도면 간 불일치는 같은 검사에서 그 태그 항목을 건드린 변경 모두 — 근거에 인용된 파일이거나 같은 프로젝트의 파일(V1-7:
        같은 태그 도면 12장을 함께 고친 날 근거에 인용된 첫 도면에만 붙었다). 인용되지 않은 변경은 cited 거짓(도면 값을 싣지 않는다).
        아무도 태그를 안 건드렸으면 인용된 변경 모두. 검사마다 그 검사의 변경을 한 번만 읽는다(V1-9: 교차 이슈마다 다시 훑어 2만 변경·
        2천 불일치 첫 등록이 42초)."""
        from watcher.summary import _mismatch_bits
        by_snap: dict = {}
        for c in chs:
            by_snap.setdefault(c["snapshot_id"], []).append(c)
        out: dict = {c["id"]: [] for c in chs}
        for sid, group in by_snap.items():
            try:
                iss = self.conn.execute(
                    "SELECT id, code, path, project, message, evidence FROM issues WHERE snapshot_id = ? ORDER BY id",
                    (sid,)).fetchall()
            except sqlite3.OperationalError:
                continue
            in_group = {c["id"] for c in group}
            group_by_path: dict = {}
            for c in group:
                group_by_path.setdefault(c["path"], []).append(c["id"])
            snap: dict | None = None                 # 그 검사의 변경 — 교차 이슈가 있을 때 한 번만 읽는다
            by_path: dict = {}
            by_tok: dict = {}
            known = [p for p in group_by_path if any(ch in p for ch in "(),")]   # 괄호 끝 꼴로 못 읽는 경로만 통째 대조
            for iid, code, ipath, iproj, msg, ev in iss:
                if code in self._LOW_ISSUES:
                    continue
                try:
                    evl = json.loads(ev or "[]")
                except ValueError:
                    evl = []
                d = {"id": iid, "code": code, "path": ipath, "message": msg, "evidence": evl if isinstance(evl, list) else []}
                if code not in self._CROSS_ISSUES:
                    for cid in group_by_path.get(ipath, ()):
                        out[cid].append(d)
                    continue
                if snap is None:
                    snap = {}
                    for cid, cpath, cproj, js in self.conn.execute(
                            "SELECT c.id, c.path, c.project, d.items_json FROM changes c "
                            "LEFT JOIN change_details d ON d.change_id = c.id WHERE c.snapshot_id = ?", (sid,)):
                        try:
                            items = json.loads(js or "[]")
                        except (ValueError, TypeError):
                            items = []
                        toks, blob = self._item_tokens(items if isinstance(items, list) else [])
                        snap[cid] = (cpath, cproj, blob)
                        by_path.setdefault(cpath, set()).add(cid)
                        for t in toks:
                            by_tok.setdefault(t, set()).add(cid)
                cited_paths = set(self._evidence_paths(ev, known)) | {ipath}
                cited = set().union(*(by_path.get(p, set()) for p in cited_paths))
                bits = _mismatch_bits(msg or "", d["evidence"]) if code == "BOM_MISMATCH" else None
                m = self._TAG_IN_MSG.search(str(msg or ""))
                tag = (bits[0] if bits else (m.group(1) if m else "")).upper()
                touch: set = set()
                if tag:
                    if self._ONE_TOKEN.fullmatch(tag):
                        hits = by_tok.get(tag, set())
                    else:                            # 낱말 경계 글자가 든 태그('Q-1.1') — 글로 견준다
                        pat = re.compile(r"(?<![\w\-])" + re.escape(tag) + r"(?![\w\-])")
                        hits = {cid for cid, (_p, _pj, blob) in snap.items() if pat.search(blob)}
                    touch = {cid for cid in hits
                             if cid in cited or (iproj is not None and (snap[cid][1] or "") == (iproj or ""))}
                pick = touch or cited
                for cid in pick & in_group:
                    out[cid].append(d if cid in cited else {**d, "cited": False})
        return out

    def _summary_rows(self, ids) -> list:
        ids = [int(i) for i in ids if i is not None]
        rows: list = []
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            q = ",".join("?" * len(part))
            for cid, sid, kind, path, proj, js, dj in self.conn.execute(
                    f"SELECT c.id, c.snapshot_id, c.kind, c.path, c.project, d.items_json, d.dismissed_json FROM changes c "
                    f"LEFT JOIN change_details d ON d.change_id = c.id WHERE c.id IN ({q})", part):
                try:
                    items = json.loads(js or "[]")
                    dismissed = json.loads(dj or "{}")
                except (ValueError, TypeError):
                    items, dismissed = [], {}
                rows.append({"id": cid, "snapshot_id": sid, "kind": kind, "path": path, "project": proj,
                             "items": [_fix_old_note(it) for it in items if isinstance(it, dict)],
                             "dismissed": dismissed if isinstance(dismissed, dict) else {}})
        return rows

    def build_summaries(self, ids, hide_dismissed: bool = True, values: bool = False, stored: dict | None = None) -> dict[int, str]:
        """변경 id → 한 줄 요약을 지금 기록(항목·귀속·그 검사의 검토 필요)으로 만든다. hide_dismissed면 숨긴 항목을 뺀다.

        검토 필요 근거(issues.evidence·message)는 이슈가 열려 있는 동안 최신 판 값으로 갱신된다 — 그 값을 옛 변경에 붙이면 거짓이다
        (V1-1). 그래서 [확인 필요] 머리는:
        - stored {변경 id: (저장 요약, 저장 때 프로젝트)}에 있으면 저장 요약의 머리를 글자 그대로(주어·숨긴 항목은 꼬리에만 반영),
        - 없고 values 참(검사 직후 기록하는 순간 — 근거가 그 변경 시점 것)이면 근거 값을 싣고,
        - 둘 다 아니면(저장 요약 없는 옛 행) 값 없이 코드 이름표만."""
        from watcher.summary import stored_head, summarize, visible_items
        rows = self._summary_rows(ids)
        opened = self._issues_opened_by(rows)
        stored = stored or {}
        out = {}
        for r_ in rows:
            vis = visible_items(r_["items"], r_["dismissed"]) if hide_dismissed else r_["items"]
            n_hidden = len(r_["dismissed"]) if hide_dismissed and r_["dismissed"] and r_["items"] and not vis else 0
            iss = opened.get(r_["id"], ())
            head = None
            if r_["id"] in stored:
                s_line, s_proj = stored[r_["id"]]
                head = stored_head(s_line, r_["kind"], r_["path"], s_proj, r_["items"], iss) or ""
            out[r_["id"]] = summarize(r_["kind"], r_["path"], r_["project"], vis, iss,
                                      values=values, head=head, n_hidden=n_hidden)
        return out

    def store_summaries(self, ids, fresh: bool = True) -> int:
        """기록할 때 한 줄 요약을 저장한다(그때의 항목 전부·그때의 귀속). 돌려주는 값: 저장한 수.
        fresh: 검사 직후 기록하는 순간인가 — 거짓([다시 비교]로 상세만 새로 쓸 때)이면 [확인 필요] 머리는 먼저 저장한 요약의 것을
        그대로 두고, 그것도 없으면 값 없이 (V1-1: 그때의 근거는 지금 값으로 갱신돼 있다)."""
        ids = [int(i) for i in ids if i is not None]
        if not ids:
            return 0
        prev = {} if fresh else self._stored_with_project(ids)
        lines = self.build_summaries(ids, hide_dismissed=False, values=fresh, stored=prev)
        proj: dict = {}
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            proj.update(dict(self.conn.execute(
                f"SELECT id, project FROM changes WHERE id IN ({','.join('?' * len(part))})", part)))
        now = datetime.now(timezone.utc).isoformat()
        self.conn.executemany(
            "INSERT OR REPLACE INTO change_summaries (change_id, summary, project, at) VALUES (?, ?, ?, ?)",
            [(cid, line, proj.get(cid), now) for cid, line in lines.items()])
        self.conn.commit()
        return len(lines)

    def _stored_with_project(self, ids) -> dict:
        """{변경 id: (저장 요약, 저장 때 프로젝트)} — 표가 없으면 빈 사전."""
        out: dict = {}
        try:
            for k in range(0, len(ids), 400):
                part = ids[k:k + 400]
                for cid, line, sp in self.conn.execute(
                        f"SELECT change_id, summary, project FROM change_summaries WHERE change_id IN ({','.join('?' * len(part))})",
                        part):
                    out[cid] = (line, sp)
        except sqlite3.OperationalError:
            return {}
        return out

    def stored_summaries(self, ids) -> dict[int, str]:
        """기록할 때 저장한 그대로의 요약 (없으면 빠짐)."""
        ids = [int(i) for i in ids if i is not None]
        out: dict = {}
        try:
            for k in range(0, len(ids), 400):
                part = ids[k:k + 400]
                out.update(dict(self.conn.execute(
                    f"SELECT change_id, summary FROM change_summaries WHERE change_id IN ({','.join('?' * len(part))})", part)))
        except sqlite3.OperationalError:
            return {}
        return out

    def record_summaries(self, ids) -> dict[int, str]:
        """변경 id → **보여 줄** 한 줄 요약. 저장한 줄을 쓰되, 저장한 줄이 없거나(옛 행) 숨긴 항목이 있거나 귀속이 그 뒤
        바뀌었으면 지금 기록으로 다시 만든다 — 저장값은 그대로 둔다 (pv2 C6). 다시 만들 때 [확인 필요] 머리는 저장 요약의 것을
        그대로 쓰고, 저장 요약이 없으면 값 없이 만든다 (V1-1). 새 표가 없는 DB(사내망 attach)도 만든다."""
        ids = [int(i) for i in ids if i is not None]
        if not ids:
            return {}
        stored: dict = {}
        prev: dict = {}
        try:
            for k in range(0, len(ids), 400):
                part = ids[k:k + 400]
                q = ",".join("?" * len(part))
                for cid, line, sp, cp, dj in self.conn.execute(
                        f"SELECT s.change_id, s.summary, s.project, c.project, d.dismissed_json FROM change_summaries s "
                        f"JOIN changes c ON c.id = s.change_id LEFT JOIN change_details d ON d.change_id = s.change_id "
                        f"WHERE s.change_id IN ({q})", part):
                    if (sp or "") == (cp or "") and dj in (None, "", "{}"):
                        stored[cid] = line
                    else:
                        prev[cid] = (line, sp)
        except sqlite3.OperationalError:
            stored, prev = {}, {}
        rest = [i for i in ids if i not in stored]
        if rest:
            stored.update(self.build_summaries(rest, values=False, stored=prev))
        return stored

    def get_change(self, change_id: int) -> Change | None:
        if not isinstance(change_id, int) or not (0 <= change_id < 2 ** 62):
            return None                  # 큰 정수는 sqlite가 OverflowError로 끊었다 (검토25 화면 3-7)
        row = self.conn.execute(
            "SELECT kind, path, old_sha256, new_sha256, id, project FROM changes WHERE id = ?",
            (change_id,)).fetchone()
        return Change(*row) if row else None

    def change_mtimes(self, change_id: int) -> tuple:
        """(이번 판 저장 시각, 이전 판 저장 시각) — 그 변경이 기록된 순간의 값. 없으면 (None, None)."""
        try:
            row = self.conn.execute("SELECT mtime, old_mtime FROM changes WHERE id = ?", (change_id,)).fetchone()
        except sqlite3.OperationalError:
            return (None, None)
        return (row[0], row[1]) if row else (None, None)

    def add_ack(self, change_id: int, by: str, note: str) -> bool:
        """확인 기록 저장. 대상 변경이 없으면 False.

        같은 사람이 같은 메모로 ACK_REPEAT_SECONDS 안에 또 보내면 두 번 누른 것이라 한 줄만 남긴다 — 확인 기록은
        지울 수 없어 같은 확인 2줄이 그대로 남았다 (ux24 AK5). 한 문장으로 넣어 동시에 온 두 요청도 한 줄이다."""
        if self.get_change(change_id) is None:
            return False
        at = datetime.now(timezone.utc)
        now, since = at.isoformat(), (at - timedelta(seconds=ACK_REPEAT_SECONDS)).isoformat()
        self.conn.execute(
            'INSERT INTO acks (change_id, "by", note, at) SELECT ?, ?, ?, ? WHERE NOT EXISTS ('
            'SELECT 1 FROM acks WHERE change_id = ? AND "by" = ? AND IFNULL(note, \'\') = ? AND at BETWEEN ? AND ?)',
            (change_id, by, note, now, change_id, by, note or "", since, now))
        self.conn.commit()
        return True

    def ack_exempt_map(self, change_ids) -> dict[int, str]:
        """확인 대상이 아닌 변경만 {변경 id: 까닭} — 'first' 첫 등록, 'quiet' 이동·재저장·복사본(그 밖의 알림).

        감시 화면·메일 토큰·사내망 세 입구가 이 판정 하나를 쓴다. 입구마다 따로 보아 조용한 행과 첫 등록에 지울 수 없는
        확인이 남았고, 사내망은 그 행을 미확인으로 보였다 (ux24 AK2·AK4). 이동 짝의 삭제 쪽은 추가 쪽 한 줄로 접히는
        행이라 메일·화면 어디에도 없으므로 같은 '기록만'이다. 없는 번호는 그냥 빠진다.
        '미확인 N건'을 세는 곳도 모두 이 판정을 쓴다 — 최근 500건만 드는 참고 문구 표(side_notes)로 세면, 창 밖으로 밀린
        조용한 행이 '미확인'인데 입구는 거절해 영영 지울 수 없었다 (ux25 F1)."""
        return self.ack_marks(change_ids)[0]

    def ack_marks(self, change_ids) -> tuple[dict[int, str], dict[int, str]]:
        """(ack_exempt_map의 판정, {변경 id: 참고 문구}) — 같은 행을 두 번 읽지 않게 한 번에. 문구는 있는 행만.
        수를 세는 쪽이 이동 짝을 접으려면 판정과 같은 범위의 문구가 필요하다. 변수 한도에 걸리지 않게 400개씩 나눠 읽는다.
        판정에 쓰는 것은 참고 문구(CHECK_SKIPPED) 하나뿐이라 그 낱말이 없는 상세는 DB에서 받지도 않는다 — _note_in의 첫 줄과 같은
        조건이다(instr는 그 줄의 `in`처럼 대소문자를 가린다). 진짜 비교 3KB JSON 5만 건을 받아 쥐고 있어, 첫 읽기가 세 배·메모리가
        네 배가 됐다 (ux25 G1). '참고'까지 조건에 넣지 않는다: 한글을 \\uXXXX로 풀어 저장한 행을 놓치면 F1이 되살아난다."""
        from watcher.brief import _MOVE_MARK, is_quiet
        ids = sorted({i for i in change_ids if isinstance(i, int) and 0 <= i < 2 ** 62})
        if not ids:
            return {}, {}
        first, ext_base = self.first_snapshot_by_root(), self.ext_baseline()
        out: dict[int, str] = {}
        side: dict[int, str] = {}
        removed: list[tuple] = []
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            for cid, kind, path, snap, js in self.conn.execute(
                    "SELECT c.id, c.kind, c.path, c.snapshot_id, "
                    "CASE WHEN instr(d.items_json, 'CHECK_SKIPPED') > 0 THEN d.items_json END FROM changes c "
                    "LEFT JOIN change_details d ON d.change_id = c.id "
                    f"WHERE c.id IN ({','.join('?' * len(part))})", part).fetchall():
                note = _note_in(js) if js else ""
                if note:
                    side[cid] = note
                if State.is_first_registration(kind, path, snap, first, ext_base):
                    out[cid] = "first"
                elif note and is_quiet(note):
                    out[cid] = "quiet"
                elif kind == "removed":
                    removed.append((cid, path, snap))
        moved_out: dict = {}                       # 검사별 '이 경로에서 옮겨 감' — 삭제 행이 많아도 검사마다 한 번만 읽는다
        for cid, path, snap in removed:
            if snap not in moved_out:
                notes = [_note_in(js) for (js,) in self.conn.execute(
                    "SELECT d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
                    "WHERE c.snapshot_id = ? AND c.kind = 'added' AND d.items_json LIKE '%CHECK_SKIPPED%'", (snap,))]
                moved_out[snap] = {n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
                                   for n in notes if _MOVE_MARK in n}
            if path in moved_out[snap]:
                out[cid] = "quiet"
        return out, side

    def ack_exempt(self, change_id: int) -> str | None:
        """확인 대상이 아니면 까닭('first'·'quiet'), 대상이면 None — ack_exempt_map의 한 건짜리."""
        return self.ack_exempt_map([change_id]).get(change_id)

    def add_ack_bulk(self, change_ids: list[int], by: str, note: str) -> int:
        """여러 변경을 한 번에 확인 처리 — 기준선 수백 건 등 (2026-08-26 신입 검토:
        하나씩 이름 쳐서 확인하는 것 말고는 미확인을 줄일 방법이 없던 문제)."""
        now = datetime.now(timezone.utc).isoformat()
        self.conn.executemany(
            "INSERT INTO acks (change_id, by, note, at) VALUES (?, ?, ?, ?)",
            [(cid, by, note, now) for cid in change_ids])
        self.conn.commit()
        return len(change_ids)

    def first_snapshot_by_root(self) -> dict[str, int]:
        """감시 폴더(경로 키 첫 마디)별 첫 검사 스냅샷 id — 그때의 '추가'는 기준선.
        changes는 정리(prune)되지 않아 폴더를 나중에 추가해도 첫 검사를 알 수 있다
        (2026-09-02 재검토: 두 번째 폴더의 첫 등록이 미확인 변경으로 잡혔다)."""
        out = {r: s for r, s in self.conn.execute(
            "SELECT CASE WHEN instr(path, '/') > 0 THEN substr(path, 1, instr(path, '/') - 1)"
            " ELSE path END AS r, MIN(snapshot_id) FROM changes GROUP BY r")}
        # record_run이 명시적으로 적은 '첫 실제 검사'가 있으면 그것이 우선 (검토20 A-4·A-6)
        try:
            explicit = json.loads(self.get_meta("root_first_seen") or "{}")
        except (ValueError, TypeError):
            explicit = {}
        for r, s in explicit.items():
            try:
                out[str(r)] = int(s)
            except (TypeError, ValueError):
                pass
        # DB 첫 검사(전체 기준선)의 등록도 언제나 등록이다 — 기록을 남긴 채 뺐다가 다시 넣은 폴더는
        # 첫 검사가 새 스냅샷으로 바뀌는데, 그러면 옛 첫 검사 행이 '미확인 변경'으로 되살아났다
        # (검토20 재검증 ①). 예약 키 "*"로 함께 돌려주고 is_first_registration이 본다
        first = self.first_snapshot_id()
        if first is not None:
            out["*"] = first
        return out

    # ── 나중에 켠 확장자의 첫 등록 (2026-09-10 검토18 ③-A)
    # 감시 폴더를 나중에 추가하면 그 폴더의 첫 검사가 기준선인 것처럼, 확장자를 나중에
    # 켜면(설정의 묶음 단추 한 번에 106개) 그 검사에서 잡힌 그 확장자의 '추가'도 변경이
    # 아니라 등록이다 — 아니면 PLC 파일 수백 건이 그날 브리핑에 '추가'로 쏟아진다.
    # 어느 검사에서 어떤 확장자가 새로 켜졌는지를 meta에 남기고 화면·주간·브리핑이 같은
    # 규칙으로 센다. "감시 시작 뒤 처음 나타난 파일"과는 다르다 — 그것은 진짜 추가다.
    def ext_baseline(self) -> dict[str, int]:
        """{확장자: 그 확장자가 처음 켜진 검사의 스냅샷 id}."""
        import json
        raw = self.get_meta("ext_baseline")
        try:
            d = json.loads(raw) if raw else {}
            return {str(k).lower(): int(v) for k, v in d.items()}
        except (ValueError, TypeError, AttributeError):
            return {}

    def note_ext_baseline(self, exts, snapshot_id: int) -> None:
        import json
        d = self.ext_baseline()
        for e in exts:
            d[str(e).lower()] = int(snapshot_id)
        self.set_meta("ext_baseline", json.dumps(d, ensure_ascii=False))

    @staticmethod
    def is_first_registration(kind: str, path: str, snapshot_id,
                              first_by_root: dict, ext_base: dict) -> bool:
        """이 '추가'가 변경이 아니라 등록인가 — 폴더의 첫 검사이거나 확장자를 켠 검사."""
        if kind != "added" or snapshot_id is None:
            return False
        if snapshot_id == first_by_root.get("*"):      # DB 첫 검사(전체 기준선)
            return True
        root = path.split("/", 1)[0] if "/" in path else path
        if snapshot_id == first_by_root.get(root):
            return True
        dot = path.rfind(".")
        ext = path[dot:].lower() if dot > path.rfind("/") else ""
        return bool(ext) and snapshot_id == ext_base.get(ext)

    def repath_open_issues(self, old_path: str, new_path: str) -> int:
        """이동한 파일의 이슈를 새 경로로 옮긴다 — 삭제·재발로 두 번 세지 않게. 열린 것을 센다.
        닫힌 이슈도 따라간다 — 옛 경로에 남으면 '닫은 것과 같은 내용' 대조가 새 경로와 안 맞아
        폴더 정리 날 닫아 둔 이슈가 전부 되살아났다 (검토32 B5)."""
        cur = self.conn.execute(
            "UPDATE issues SET path = ? WHERE path = ? AND resolved_at IS NULL",
            (new_path, old_path))
        n = cur.rowcount or 0
        self.conn.execute("UPDATE issues SET path = ? WHERE path = ? AND resolved_at IS NOT NULL",
                          (new_path, old_path))
        self.conn.commit()
        return n

    _EV_PATH = re.compile(r"[(,]\s*([^(),]+?\.(?:dxf|dwg|pdf|xlsx|xlsm|docx|hwpx))\s*\)", re.I)

    @staticmethod
    def _mismatch_values(ev_json, message: str = "") -> tuple | None:
        """도면-BOM 불일치 근거에서 (BOM 사양, 도면 줄들) — 'BOM: TAG SPEC=5.5kW (…)'·'도면[Rev B, …]: M-101 … (…)'."""
        try:
            lines = json.loads(ev_json or "[]")
        except (ValueError, TypeError):
            return None
        spec, dwg, tag = None, set(), ""
        for ln in lines if isinstance(lines, list) else []:
            t = str(ln)
            m = re.match(r"BOM:\s*(\S+)\s+SPEC=(.*?)\s\(", t)
            if m:
                tag = m.group(1)
                spec = " ".join(m.group(2).split()).upper()
                continue
            if t.startswith(("도면", "문서", "출도본")) and ": " in t:     # 사양서 근거는 '문서'로 (검토44 C 중간 3), 출도 사본은 '출도본'으로 (ux27 G6)
                # '(위치, 경로)' 묶음은 마지막 쉼표 앞의 ' (' 부터 — 경로에 괄호가 있어도('(삼성)') 줄 글자만 남긴다
                body = t.split(": ", 1)[1].rstrip().rstrip(")")
                ci = body.rfind(", ")
                pi = body.rfind(" (", 0, ci) if ci > 0 else -1
                if pi > 0:
                    # 그 태그의 조각만 — 줄 전체로 견주면 같은 줄 **다른** 태그 값만 바뀌어도 [처리함] 이슈가 되살아났다
                    # (검토43 A 중간 4)
                    txt = body[:pi]
                    if tag:
                        from watcher.consistency import _tag_segment
                        txt = _tag_segment(tag, txt) or txt
                    dwg.add(" ".join(txt.split()).upper())
        # '(외 도면 N장에서도 불일치)' — 근거는 첫 도면만 인용한다. 닫은 뒤 **다른** 도면이 어긋나면 이 수가 바뀐다
        more = re.search(r"외 도면 (\d+)장", str(message or ""))
        n_more = int(more.group(1)) if more else 0
        return (spec, frozenset(dwg), n_more) if spec is not None or dwg else None

    @classmethod
    def _evidence_paths(cls, ev_json, known=None) -> list:
        """이슈 근거 줄에 인용된 파일 경로 — '(레이어 EQ, 서버/P/도면/E-101.dxf)' 꼴의 괄호 끝.
        known(아는 경로 묶음 — 오늘 바뀐 파일 등)을 주면 근거 줄에 그 경로 글자가 통째로 든 것도 넣는다 — 괄호·쉼표 든 경로
        ('P26-090 컨베이어(삼성)'·'컨베이어, 2차')는 괄호 끝 꼴로 못 읽거나 '2차/도면/E-101.dxf' 같은 꼬리만 읽혀, 오늘 고친
        도면이 인용된 새 불일치를 '파일 변경 없는 재판정'으로 접었다 (재검토 rr066 judge 1). 그때 읽힌 꼬리 조각은 뺀다."""
        try:
            lines = json.loads(ev_json or "[]")
        except (ValueError, TypeError):
            return []
        known = [k for k in (known or ()) if k]
        out: list = []
        for ln in lines if isinstance(lines, list) else []:
            s = str(ln)
            hits = [k for k in known if k in s]
            for m in cls._EV_PATH.finditer(s):
                q = m.group(1).strip()
                if any(h != q and h.endswith(q) for h in hits):
                    continue                    # 괄호·쉼표 든 경로의 꼬리 조각 — 통째 경로가 아래에 들어간다
                if q not in out:
                    out.append(q)
            for h in hits:
                if h not in out:
                    out.append(h)
        return out

    @staticmethod
    def _quiet_items(items_json) -> bool:
        """항목이 전부 '참고'(CHECK_SKIPPED)이고 조용한 말(재저장·일자만·이동·복사본)뿐인가.
        상세가 없는 변경은 조용하다고 단정하지 않는다."""
        try:
            items = json.loads(items_json or "[]")
        except (ValueError, TypeError):
            return False
        if not items:
            return False
        from watcher.brief import _QUIET_WORDS
        from watcher.diff import CONTENT_KINDS, LAYOUT_ZONE, ORDER_KINDS, TITLE_ZONE, is_title_date_text
        # '…에서 옮겨짐 — 그 판과 비교합니다'는 비교를 한 변경이다 — '옮겨짐'만 보고 조용하다고 해, 옮기며 Rev를 올린 파일의
        # 열린 'Rev 미갱신'이 닫히지 않았다 (검토64 A4; brief.is_quiet와 같은 예외)
        if any(it.get("kind") == "CHECK_SKIPPED" and "그 판과 비교" in str(it.get("new") or "") for it in items):
            return False
        if any(it.get("kind") in CONTENT_KINDS and it.get("kind") not in ORDER_KINDS   # 순서만은 내용 아님 (경우100 C06)
               and not (it.get("kind") == "PAGE_VISUAL_CHANGED" and (TITLE_ZONE in str(it.get("where") or "")
                                                                    or LAYOUT_ZONE in str(it.get("where") or "")))
               and not is_title_date_text(it)          # 'DATE: …' 글줄의 날짜만 (검토42 B P01)
               for it in items):
            return False                       # 글자·표·그림이 바뀌었다 — 진짜 변경 (표제란 틀 안 그림은 아님, 검토41 S3)
        return any(it.get("kind") == "CHECK_SKIPPED" and any(w in str(it.get("new") or "") for w in _QUIET_WORDS)
                   for it in items)

    def rev_bumped_recently(self, path: str, hours: int = 36):
        """이 파일에 최근(기본 36시간) 'Rev 올림'이 기록돼 있으면 RevBump(검사 시각·변경 id·이전·새 Rev),
        없으면 None. 참/거짓으로도 쓴다. 값까지 돌려주는 것은 'Rev 미갱신을 내지 않기로 했다'는 판정의
        근거(무엇이 무엇으로 올랐나)가 메일 어디에도 없었기 때문이다 (검토34 A 1, 원칙 4)."""
        from datetime import datetime as _dt, timedelta as _td, timezone as _tz
        _now = _dt.now(_tz.utc)
        # 월요일에는 주말 이틀을 더한다 — 금요일에 Rev를 올리고 월요일에 이어 편집한 것이 64시간이라 'Rev 미갱신'이 됐다
        # (검토50 D 낮음 4). 유예는 개정마다 한 번뿐(_grace_used)이라 넓혀도 경고가 묻히지 않는다
        if _dt.now().weekday() == 0:
            hours += 48
        since = (_now - _td(hours=hours)).isoformat()
        until = (_now + _td(hours=1)).isoformat()      # 미래 기록은 근거가 아니다 (검토34 C M7)
        for js, at, cid in self.conn.execute(
                "SELECT d.items_json, c.detected_at, c.id FROM changes c JOIN change_details d ON d.change_id = c.id "
                "WHERE c.path = ? AND c.detected_at >= ? AND c.detected_at <= ? ORDER BY c.id DESC LIMIT 6",
                (path, since, until)):
            try:
                import json as _json
                for it in _json.loads(js or "[]"):
                    if not self._is_rev_bump_item(it, path):
                        continue
                    bump = RevBump(at, cid, str(it.get("old") or ""), str(it.get("new") or ""))
                    return None if self._grace_used(path, cid) else bump
            except (ValueError, TypeError, AttributeError):
                continue
        return None

    @staticmethod
    def _is_rev_bump_item(it: dict, path: str) -> bool:
        """저장된 변경 항목 하나가 'Rev 올림'인가 — 후속 편집 유예와 '아직 개정 안 함' 판정이 같은 규칙을 쓴다. 두 곳이 따로
        세어 세트 PDF 쪽 REV 줄·빈 값·시트 신설에서 서로 다르게 판정했다 (검토51 A 중간 2)."""
        from watcher.consistency import is_page_rev_bump
        from watcher.diff import NEW_TB, _blank_rev
        if not isinstance(it, dict):
            return False
        _k = str(it.get("key") or "")
        # 둘째 표제란(REV#2)의 올림도 — 시트2를 개정한 뒤의 후속 편집이 곧장 경고됐다 (검토37 A 중간 5)
        if it.get("kind") == "FIELD_CHANGED" and _k.split("#", 1)[0] == "REV":
            # 거꾸로 간 Rev(B→A)는 올림이 아니다 — 옛 판으로 덮어쓴 파일에 36시간 '후속 편집' 유예를 줬다 (검토58 F2 C03)
            from watcher.scan import rev_key, rev_shape
            _o, _n = str(it.get("old") or "").strip(), str(it.get("new") or "").strip()
            if _o and _n and rev_shape(_o) and rev_shape(_o) == rev_shape(_n) and rev_key(_n) < rev_key(_o):
                return False
            return (not _blank_rev(it.get("new")) and it.get("label") != NEW_TB
                    and not ("#" in _k and it.get("old") is None))   # 시트 신설 (검토38 R1 중간 4·R5 중간 5)
        # 세트 PDF의 뒤 쪽 표제란 REV 줄(TEXT_CHANGED)도 Rev 올림 (검토30 B 5-C) — 본문의 'REV 2' 구름 글자는 아니다 (검토31 B6)
        return bool(is_page_rev_bump(it.get("kind"), it.get("old"), it.get("new"), it.get("where"),
                                     "pdf" if str(path).lower().endswith(".pdf") else "other"))

    def _grace_used(self, path: str, bump_id: int) -> bool:
        """Rev 올림 뒤의 유예를 이미 한 번 썼나 — 올림과 지금 판정 중인 변경(가장 최근) **사이에** 내용이
        바뀐 변경이 하나라도 있으면 썼다. '다음에 또 바뀔 때 Rev가 그대로면 경고'라고 해 놓고 36시간 안의
        세 번째 편집도 다시 봐줬다 (검토36 B 중간 2). 재저장·이동 같은 조용한 변경은 세지 않는다."""
        rows = self.conn.execute(
            "SELECT c.id, d.items_json FROM changes c LEFT JOIN change_details d ON d.change_id = c.id "
            "WHERE c.path = ? AND c.id > ? ORDER BY c.id", (path, bump_id)).fetchall()
        between = rows[:-1]                     # 마지막은 지금 판정 중인 변경
        return any(js is not None and not self._quiet_items(js) for _id, js in between)

    def change_summaries(self, ids, was: bool = False) -> dict[int, tuple[int, str]]:
        """변경 id → (무게, '무엇이 어떻게' 한 줄). 무게: 사양·표 행 0 < Rev 1 < 글자·그림 2 <
        날짜·크기 3 < 참고만 4 — 화면 정렬과 첫 줄이 같은 근거를 쓴다 (파일럿 모의 2차 조건 2).
        was: 값 짝을 화살표 대신 '지금(이전 …)'으로 — 항목 값에서 바로 만든다(만든 한 줄을 다시 쪼개지 않는다, 검토 Y2 H1)."""
        import json as _json
        ids = [int(i) for i in ids if i is not None][:200]
        if not ids:
            return {}
        out: dict[int, tuple[int, str]] = {}
        q = ",".join("?" * len(ids))
        from watcher.summary import visible_items
        for cid, js, dj in self.conn.execute(
                f"SELECT change_id, items_json, dismissed_json FROM change_details WHERE change_id IN ({q})", ids):
            try:
                items = _json.loads(js or "[]")
                dismissed = _json.loads(dj or "{}")
            except (ValueError, TypeError):
                continue
            # [잘못 잡힘 숨기기]로 숨긴 항목은 화면 한 줄에서도 뺀다 — 숨긴 값이 '오늘' 줄에 그대로 남았다 (pv2 C6). 저장값은 그대로
            items = visible_items(items, dismissed if isinstance(dismissed, dict) else {})
            w, head = _headline_of(items, with_weight=True, was=was)
            out[int(cid)] = (w, head)
        return out

    def change_headlines(self, ids, was: bool = False) -> dict[int, str]:
        """변경 id → '무엇이 어떻게' 한 줄 (M-201 1.5kW→5.5kW / 수량 2→4 / Rev A→B).
        화면 '오늘 확인할 것'이 파일명만 보여 줘 눌러 봐야 알았다 (파일럿 모의 ⑦). was: 'M-201 5.5kW(이전 1.5kW)' 꼴(대장·한 줄 자리)."""
        return {k: h for k, (_w, h) in self.change_summaries(ids, was=was).items() if h}

    def ack_of(self, change_id: int) -> str | None:
        """그 변경의 최근 확인자 (없으면 None)."""
        row = self.conn.execute(
            "SELECT by FROM acks WHERE change_id = ? ORDER BY id DESC LIMIT 1",
            (change_id,)).fetchone()
        return row[0] if row else None

    def file_facts(self, path: str) -> list[dict]:
        """그 경로의 최근 두 판 기록 — (검사 시각, 지문, 크기, 수정 시각).

        내용 비교를 못 한 변경에도 사람이 판단할 근거는 있어야 한다(원칙 4). 전에는
        비교 실패 화면에 엔진 오류 한 줄뿐이고 지문·크기·수정 시각이 어디에도
        없었다 (2026-09-09 웹 검토 중간 8)."""
        rows = self.conn.execute(
            "SELECT s.run_at, f.sha256, f.size, f.mtime FROM files f "
            "JOIN snapshots s ON s.id = f.snapshot_id WHERE f.path = ? "
            "ORDER BY f.snapshot_id DESC LIMIT 2", (path,)).fetchall()
        return [{"run_at": r[0], "sha256": r[1], "size": r[2], "mtime": r[3]}
                for r in rows]

    def last_review(self, project: str | None = None) -> dict | None:
        """사람이 마지막으로 남긴 확인(변경 [확인함]) 또는 처리(검토 필요 [처리함]) — {at, by, what}.
        '최근 검토한 시간'을 화면에 보이기 위해 (2026-09-15 사용자 요청). project를 주면 그 프로젝트만."""
        if project:
            a = self.conn.execute(
                'SELECT a.at, a."by" FROM acks a JOIN changes c ON c.id = a.change_id '
                "WHERE IFNULL(c.project,'미분류') = ? ORDER BY a.at DESC LIMIT 1", (project,)).fetchone()
            i = self.conn.execute(
                "SELECT resolved_at, resolved_by FROM issues WHERE resolved_at IS NOT NULL "
                "AND IFNULL(project,'미분류') = ? AND resolved_by NOT LIKE '자동 해소%' "
                "ORDER BY resolved_at DESC LIMIT 1", (project,)).fetchone()
        else:
            a = self.conn.execute('SELECT at, "by" FROM acks ORDER BY at DESC LIMIT 1').fetchone()
            i = self.conn.execute(
                "SELECT resolved_at, resolved_by FROM issues WHERE resolved_at IS NOT NULL "
                "AND resolved_by NOT LIKE '자동 해소%' ORDER BY resolved_at DESC LIMIT 1").fetchone()
        cands = []
        if a and a[0]:
            cands.append({"at": a[0], "by": a[1] or "", "what": "변경 확인"})
        if i and i[0]:
            cands.append({"at": i[0], "by": i[1] or "", "what": "확인 필요 처리"})
        return max(cands, key=lambda d: d["at"]) if cands else None

    def acks_of(self, change_id: int) -> list[dict]:
        """그 변경의 확인 기록 전부 (오래된 것부터).

        화면이 이걸 보려고 **전체 이력을 메모리에 올렸다** — 변경 30만 건에서 한 줄에
        1.6초·200MB였다 (2026-09-09 저장 검토 중간 5)."""
        rows = self.conn.execute(
            'SELECT "by", note, at FROM acks WHERE change_id = ? ORDER BY id',
            (change_id,)).fetchall()
        return [{"ack_by": r[0], "ack_note": r[1], "ack_at": r[2]} for r in rows]

    # ── 의견·담당 (2026-11-23 사내망 협업 다듬기, DECISIONS 같은 날) ──────────────────────────
    # 표 둘(comments·assignments)은 덧붙임만 — 고치거나 지우는 메서드가 없고 표의 방아쇠가 UPDATE·DELETE를 막는다.
    # 이주는 감시 쪽(State 열기 — _SCHEMA)에서만. 사내망(State.attach)은 표가 없으면 has_collab()이 False라 그 구역만 숨긴다.

    def has_collab(self) -> bool:
        """의견·담당 표가 있나 — 옛 판 DB를 사내망이 열면 없다(사내망은 스키마를 만들지 않는다)."""
        try:
            got = {r_[0] for r_ in self.conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name IN ('comments', 'assignments')")}
        except sqlite3.Error:
            return False
        return got == set(COLLAB_TABLES)

    def target_exists(self, target: str, target_id) -> bool:
        if target not in COLLAB_TARGETS or not isinstance(target_id, int) or not (0 <= target_id < 2 ** 62):
            return False
        if target == "change":
            return self.get_change(target_id) is not None
        return self.conn.execute("SELECT 1 FROM issues WHERE id = ?", (target_id,)).fetchone() is not None

    def add_comment(self, target: str, target_id: int, by: str, body: str, kind: str = "comment") -> int | None:
        """의견 한 줄 덧붙임 — 돌려주는 값: 의견 번호(대상이 없으면 None). 본문은 부르는 쪽이 clean_comment_text·길이를 본 뒤.
        같은 사람이 같은 글을 ACK_REPEAT_SECONDS 안에 또 보내면 두 번 누른 것이라 한 줄만(확인과 같은 규칙). 확인([확인함])은 남기지
        않는다 — 의견은 확인과 다른 동작이다."""
        if kind not in ("comment", "resolve") or not str(body or "").strip() or not str(by or "").strip():
            return None
        if not self.target_exists(target, target_id):
            return None
        at = datetime.now(timezone.utc)
        now, since = at.isoformat(), (at - timedelta(seconds=ACK_REPEAT_SECONDS)).isoformat()
        cur = self.conn.execute(
            'INSERT INTO comments (target, target_id, "by", body, at, kind) SELECT ?, ?, ?, ?, ?, ? WHERE NOT EXISTS ('
            'SELECT 1 FROM comments WHERE target = ? AND target_id = ? AND "by" = ? AND body = ? AND at BETWEEN ? AND ?)',
            (target, target_id, by, body, now, kind, target, target_id, by, body, since, now))
        self.conn.commit()
        if cur.rowcount:
            return int(cur.lastrowid)
        row = self.conn.execute('SELECT MAX(id) FROM comments WHERE target = ? AND target_id = ? AND "by" = ? AND body = ?',
                                (target, target_id, by, body)).fetchone()
        return int(row[0]) if row and row[0] is not None else None

    def comments_of(self, target: str, target_id: int) -> list[dict]:
        """그 대상의 의견 전부 (오래된 것부터) — {id, by, body, at, kind}."""
        return [{"id": r[0], "by": r[1], "body": r[2], "at": r[3], "kind": r[4]} for r in self.conn.execute(
            'SELECT id, "by", body, at, kind FROM comments WHERE target = ? AND target_id = ? ORDER BY id',
            (target, int(target_id)))]

    def comment_counts(self, target: str, ids=None) -> dict[int, int]:
        """{대상 번호: 의견 수} — 목록의 '의견 N'. 없는 것은 빠진다. ids=None이면 그 종류 전부(의견은 사람 글이라 표가 작다 —
        20만 줄 이력 화면이 번호를 넘기지 않고 한 번에 읽는다). 번호를 주면 400개씩 나눠 읽는다."""
        if ids is None:
            return {int(t): int(n) for t, n in self.conn.execute(
                "SELECT target_id, COUNT(*) FROM comments WHERE target = ? GROUP BY target_id", (target,))}
        ids = sorted({int(i) for i in ids if isinstance(i, int) and 0 <= i < 2 ** 62})
        out: dict[int, int] = {}
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            for tid, n in self.conn.execute(
                    f"SELECT target_id, COUNT(*) FROM comments WHERE target = ? AND target_id IN ({','.join('?' * len(part))}) "
                    "GROUP BY target_id", [target] + part):
                out[int(tid)] = int(n)
        return out

    def comments_for(self, target: str, ids) -> dict[int, list]:
        """{대상 번호: [의견…]} — 여러 대상을 한 번에(확인 필요 목록의 펼친 근거). 없는 것은 빠진다."""
        ids = sorted({int(i) for i in ids if isinstance(i, int) and 0 <= i < 2 ** 62})
        out: dict[int, list] = {}
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            for cid, tid, by, body, at, kind in self.conn.execute(
                    f'SELECT id, target_id, "by", body, at, kind FROM comments WHERE target = ? AND target_id IN '
                    f"({','.join('?' * len(part))}) ORDER BY id", [target] + part):
                out.setdefault(int(tid), []).append({"id": cid, "by": by, "body": body, "at": at, "kind": kind})
        return out

    def assign(self, target: str, target_id: int, assignee: str, assignee_id, by: str) -> bool | None:
        """담당 한 줄 덧붙임 — assignee ''(·assignee_id None)이면 담당 해제. 돌려주는 값: True 덧붙임, False 이미 그 담당이라 그대로,
        None 대상 없음. 권한·열람 범위 판정은 부르는 쪽(사내망 서버)이 한다."""
        if not self.target_exists(target, target_id) or not str(by or "").strip():
            return None
        assignee = str(assignee or "").strip()
        aid = int(assignee_id) if (assignee and assignee_id is not None) else None
        cur = self.assignee_of(target, target_id)
        if (cur is None and not assignee) or (cur is not None and assignee and cur["assignee_id"] == aid
                                               and cur["assignee"] == assignee):
            return False
        self.conn.execute('INSERT INTO assignments (target, target_id, assignee, assignee_id, "by", at) VALUES (?, ?, ?, ?, ?, ?)',
                          (target, target_id, assignee, aid, by, datetime.now(timezone.utc).isoformat()))
        self.conn.commit()
        return True

    def assignee_of(self, target: str, target_id: int) -> dict | None:
        """지금 담당 — 마지막 줄. 해제됐거나 없으면 None. {assignee, assignee_id, by, at}."""
        return self.assignees(target, [int(target_id)]).get(int(target_id))

    def assignees(self, target: str, ids=None) -> dict[int, dict]:
        """{대상 번호: 지금 담당} — 담당이 있는 것만(해제된 것은 빠진다). ids=None이면 그 종류 전부(표가 작다)."""
        out: dict[int, dict] = {}
        if ids is None:
            for tid, who, aid, by, at in self.conn.execute(
                    'SELECT a.target_id, a.assignee, a.assignee_id, a."by", a.at FROM assignments a JOIN ('
                    "SELECT MAX(id) AS m FROM assignments WHERE target = ? GROUP BY target_id) t ON a.id = t.m", (target,)):
                if who:
                    out[int(tid)] = {"assignee": who, "assignee_id": aid, "by": by, "at": at}
            return out
        ids = sorted({int(i) for i in ids if isinstance(i, int) and 0 <= i < 2 ** 62})
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            for tid, who, aid, by, at in self.conn.execute(
                    'SELECT a.target_id, a.assignee, a.assignee_id, a."by", a.at FROM assignments a JOIN ('
                    f"SELECT MAX(id) AS m FROM assignments WHERE target = ? AND target_id IN ({','.join('?' * len(part))}) "
                    "GROUP BY target_id) t ON a.id = t.m", [target] + part):
                if who:
                    out[int(tid)] = {"assignee": who, "assignee_id": aid, "by": by, "at": at}
        return out

    def assignment_log(self, target: str, target_id: int) -> list[dict]:
        """그 대상의 담당 기록 전부 (오래된 것부터) — 바뀐 기록을 보이려고."""
        return [{"assignee": r[0], "assignee_id": r[1], "by": r[2], "at": r[3]} for r in self.conn.execute(
            'SELECT assignee, assignee_id, "by", at FROM assignments WHERE target = ? AND target_id = ? ORDER BY id',
            (target, int(target_id)))]

    def assigned_to(self, assignee_id: int) -> list[tuple[str, int]]:
        """그 계정에게 **지금** 맡겨진 대상 [(종류, 번호)…] (최근 지정부터). 열림·미확인·범위는 부르는 쪽이 거른다."""
        return [(str(t), int(i)) for t, i in self.conn.execute(
            "SELECT a.target, a.target_id FROM assignments a JOIN ("
            "SELECT MAX(id) AS m FROM assignments GROUP BY target, target_id) t ON a.id = t.m "
            "WHERE a.assignee_id = ? AND a.assignee != '' ORDER BY a.id DESC", (int(assignee_id),))]

    def snapshot_local_time(self, snapshot_id: int) -> str | None:
        """검사 시작 시각을 이 PC 시간으로 'MM-DD HH:MM' — 브리핑의 '비교 기준' 표기용."""
        from datetime import datetime as _dt
        row = self.conn.execute("SELECT run_at FROM snapshots WHERE id = ?",
                                (snapshot_id,)).fetchone()
        if not row or not row[0]:
            return None
        iso = row[0]
        if not ("+" in iso[10:] or iso.endswith("Z")):
            iso += "+00:00"
        try:
            return _dt.fromisoformat(iso).astimezone().strftime("%m-%d %H:%M")
        except ValueError:
            return None

    def prev_snapshot_id(self, snapshot_id: int) -> int | None:
        """이번 검사의 직전 스냅샷 id — 무엇과 비교한 것인지 밝히려고."""
        row = self.conn.execute(
            "SELECT id FROM snapshots WHERE id < ? ORDER BY id DESC LIMIT 1",
            (snapshot_id,)).fetchone()
        return row[0] if row else None

    def snapshot_local_date(self, snapshot_id: int) -> str | None:
        """검사 시작 시각의 이 PC 지역 날짜 (ISO) — 자정을 걸친 검사의 '그 날'."""
        from datetime import datetime as _dt
        row = self.conn.execute("SELECT run_at FROM snapshots WHERE id = ?",
                                (snapshot_id,)).fetchone()
        if not row or not row[0]:
            return None
        iso = row[0]
        if not ("+" in iso[10:] or iso.endswith("Z")):
            iso += "+00:00"
        try:
            return _dt.fromisoformat(iso).astimezone().date().isoformat()
        except ValueError:
            return None

    def changes_on_day(self, day_iso: str, exclude_snapshots=()) -> list[Change]:
        """그 날(이 PC 지역 날짜)에 잡힌 변경 — 같은 날 두 번째 검사가 아침 브리핑과
        합쳐 한 통으로 갱신하기 위해 (2026-09-05 재검토: 초안 8통이 나열됨)."""
        from datetime import datetime as _dt, timedelta as _td
        # 지역 날짜 ±1일 범위만 SQL로 좁힌 뒤 정확한 지역 날짜로 거른다 (전 행 훑기 방지)
        lo = (_dt.fromisoformat(day_iso) - _td(days=1)).strftime("%Y-%m-%d")
        hi = (_dt.fromisoformat(day_iso) + _td(days=2)).strftime("%Y-%m-%d")
        skip = set(exclude_snapshots)
        out = []
        for row in self.conn.execute(
                "SELECT id, kind, path, old_sha256, new_sha256, project, snapshot_id, detected_at"
                " FROM changes WHERE detected_at >= ? AND detected_at < ? ORDER BY id", (lo, hi)):
            if row[6] in skip:                     # 이번 검사·기준선 검사분은 제외
                continue
            iso = row[7] or ""
            if not ("+" in iso[10:] or iso.endswith("Z")):
                iso += "+00:00"
            try:
                if _dt.fromisoformat(iso).astimezone().date().isoformat() != day_iso:
                    continue
            except ValueError:
                continue
            out.append(Change(row[1], row[2], row[3], row[4], id=row[0], project=row[5]))
        return out

    def first_snapshot_id(self) -> int | None:
        """기준선(첫 검사) 스냅샷 id — 그때의 '추가' 대량 건은 실제 변경이 아니다."""
        row = self.conn.execute("SELECT MIN(id) FROM snapshots").fetchone()
        return row[0]

    def next_unacked(self, after_id: int, same_run: bool = True) -> int | None:
        """확인되지 않은 다음 변경의 id — 상세 화면의 [확인하고 다음]이 쓴다 (2026-09-09).

        같은 검사분 안에서 id가 큰 쪽부터 찾고, 없으면 앞쪽으로 한 바퀴 돈다.
        한 건 확인할 때마다 목록으로 돌아갔다 다시 들어가던 것을 없애기 위해서다."""
        snap = None
        if same_run:
            row = self.conn.execute("SELECT snapshot_id FROM changes WHERE id = ?",
                                    (after_id,)).fetchone()
            if row is None:
                return None          # 없는 id — 검사분을 못 좁히므로 아무 데로나 보내지 않는다
            snap = row[0]
        where = "a.id IS NULL AND c.id <> ?"
        params: list = [after_id]
        first = self.first_snapshot_id()
        if first is not None:
            # 기준선의 '추가'는 화면이 '첫 등록'으로 보여 주고 확인을 요구하지 않는다 —
            # 순회가 거기로 데려가면 수백~수천 건을 돌게 된다 (2026-09-09 검토18 F1)
            where += " AND NOT (c.snapshot_id = ? AND c.kind = 'added')"
            params.append(first)
        if snap is not None:
            where += " AND c.snapshot_id = ?"
            params.append(snap)
        sql = ("SELECT c.id FROM changes c LEFT JOIN acks a ON a.change_id = c.id "
               f"WHERE {where} AND c.id > ? ORDER BY c.id LIMIT 1")
        row = self.conn.execute(sql, (*params, after_id)).fetchone()
        if row:
            return int(row[0])
        sql2 = ("SELECT c.id FROM changes c LEFT JOIN acks a ON a.change_id = c.id "
                f"WHERE {where} ORDER BY c.id LIMIT 1")          # 한 바퀴 돌아 앞쪽
        row = self.conn.execute(sql2, tuple(params)).fetchone()
        return int(row[0]) if row else None

    def hist_gen(self) -> int:
        """이력 세대 — 변경·확인·기준선 표시가 바뀔 때마다 오른다 (트리거). 화면 캐시의 열쇠."""
        row = self.conn.execute("SELECT v FROM hist_gen WHERE k = 1").fetchone()
        return int(row[0]) if row else 0

    def history(self, project: str | None = None) -> list[dict]:
        """변경 이력 + 확인 기록 (프로젝트 필터 가능)."""
        # f.mtime = 그 검사 때 파일의 저장(수정) 시각 — '일시'가 검사 시각뿐이라 문서를 언제 고쳤는지
        # 화면에 없었다 (2026-09-17 사용자 요청). 삭제 행은 그 스냅샷에 파일이 없어 NULL
        sql = ("SELECT c.id, c.detected_at, c.kind, c.path, c.project, a.by, a.note, a.at, "
               "c.snapshot_id, c.mtime "
               "FROM changes c LEFT JOIN acks a ON a.change_id = c.id ")
        params: tuple = ()
        if project:
            sql += "WHERE c.project = ? "
            params = (project,)
        sql += "ORDER BY c.id, a.id"
        keys = ("change_id", "detected_at", "kind", "path", "project",
                "ack_by", "ack_note", "ack_at", "snapshot_id", "mtime")
        return [dict(zip(keys, row)) for row in self.conn.execute(sql, params)]
