# -*- coding: utf-8 -*-
"""SMTP 비밀번호 보관 — Windows DPAPI(이 PC의 이 계정만 풀 수 있는 암호화) (2026-09-05).

config.yaml에 평문으로 놓이던 비밀번호를 `dpapi:<base64>`로 바꿔 둔다. 파일을 복사해 가도
다른 PC·다른 계정에서는 풀리지 않는다. Windows가 아니거나 DPAPI가 실패하면 평문 그대로 둔다
(그 경우 화면이 알려준다). 이 모듈은 파일을 쓰지 않는다 — 값만 바꿔 준다.
"""

from __future__ import annotations

import base64
import sys

PREFIX = "dpapi:"
_ENTROPY = b"Drev mail password v1"


class SecretError(Exception):
    """이 PC·계정에서 풀 수 없는 값 (다른 PC에서 복사한 config.yaml 등)."""


def is_protected(value) -> bool:
    return isinstance(value, str) and value.startswith(PREFIX)


def available() -> bool:
    return sys.platform == "win32"


def _crypt(data: bytes, protect: bool) -> bytes:
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def _blob(b: bytes) -> DATA_BLOB:
        buf = ctypes.create_string_buffer(b, len(b))
        return DATA_BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    inp, ent, out = _blob(data), _blob(_ENTROPY), DATA_BLOB()
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    CRYPTPROTECT_UI_FORBIDDEN = 0x01
    ok = fn(ctypes.byref(inp), None, ctypes.byref(ent), None, None,
            CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out))
    if not ok:
        raise SecretError("이 PC·계정에서 풀 수 없는 값입니다")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def protect(plain: str) -> str:
    """평문 → 'dpapi:…'. 이미 보호된 값이나 빈 값은 그대로. DPAPI를 못 쓰면 평문 그대로."""
    if not plain or is_protected(plain) or not available():
        return plain
    try:
        return PREFIX + base64.b64encode(_crypt(plain.encode("utf-8"), True)).decode("ascii")
    except Exception:
        return plain


def reveal(value) -> str:
    """'dpapi:…' → 평문. 평문이면 그대로. 못 풀면 SecretError."""
    if not value or not is_protected(value):
        return value or ""
    try:
        raw = base64.b64decode(value[len(PREFIX):].encode("ascii"))
    except (ValueError, UnicodeEncodeError) as e:
        raise SecretError(f"저장된 비밀번호 형식이 깨졌습니다 ({e})")
    if not available():
        raise SecretError("이 비밀번호는 Windows에서 암호화돼 여기서는 풀 수 없습니다")
    return _crypt(raw, False).decode("utf-8", "replace")
