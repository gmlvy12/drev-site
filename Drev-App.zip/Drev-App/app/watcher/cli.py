# -*- coding: utf-8 -*-
"""CLI: run / init / ack-serve / history.

사용:
  python -m watcher.cli init                # config.example.yaml → config.yaml
  python -m watcher.cli run [--dry-run]     # 스캔 → 브리핑 생성 (+ 설정 시 메일)
  python -m watcher.cli ack-serve           # 5초 확인 로컬 웹 서버
  python -m watcher.cli history [--project] # 변경·확인 이력 조회
"""

from __future__ import annotations

import argparse
from collections import OrderedDict
from collections.abc import Mapping
import contextlib
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
from collections import Counter
from dataclasses import dataclass
from dataclasses import field as dc_field
from datetime import datetime, timedelta, timezone
from html import escape as html_escape
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

import yaml

from watcher import __version__
from watcher.brief import brief_counts, brief_filename, build_brief
from watcher.consistency import CODE_LABEL, Issue, check_project_consistency, check_revision
from watcher.diff import ChangeItem, diff_documents
from watcher.doctype import HINTS, content_hint, kind_of, looks_like_doctype_folder
from watcher.extract import extract
from watcher.extract.base import Document, clean_text
from watcher.mail import send_brief
from watcher.project import ProjectResolver
from watcher.convert import converted_many, resolve as resolve_converter
from watcher.render import RENDER_EXTS, render_dxf, render_file
from watcher.scan import DEFAULT_EXTENSIONS, is_excluded, pair_key, scan
from watcher.state import KIND_LABEL, CorruptDatabase, State

# PyInstaller exe에서는 예시 설정이 임시 해제 폴더(_MEIPASS)에 번들된다
if getattr(sys, "frozen", False):
    PROJECT_DIR = Path(getattr(sys, "_MEIPASS", "."))
else:
    PROJECT_DIR = Path(__file__).resolve().parent.parent

_CONFIG_DEFAULTS = {
    "extensions": list(DEFAULT_EXTENSIONS),
    "state_db": "state.db",
    "brief_dir": "briefs",
    "mail": {"enabled": False},
    "aliases": "aliases.yaml",
    "projects": {},
    "ack_url": "http://127.0.0.1:8765",
    "exclude": [],
}


class ConfigError(Exception):
    """config.yaml을 읽을 수 없다 — 사람이 고쳐야 하는 오류 (사유 포함)."""


def _parse_config_text(raw: bytes, path: Path) -> dict:
    """YAML 해석. utf-8이 아니면 cp949(메모장 ANSI 저장)로 다시 시도하고, 문법 오류는
    몇 행인지 한국어로 알려준다 — 창 모드에서는 콘솔이 없어 '더블클릭해도 안 뜸'만
    남았다 (2026-09-04 검토 ops M1)."""
    text = None
    for enc in ("utf-8-sig", "cp949"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ConfigError(f"{path.name}의 글자 인코딩을 읽을 수 없습니다 — "
                          f"메모장에서 'UTF-8'로 다시 저장해주세요.")
    try:
        cfg = yaml.safe_load(text) or {}
    except yaml.YAMLError as e:
        mark = getattr(e, "problem_mark", None)
        where = f" {mark.line + 1}행" if mark is not None else ""
        hint = " (탭 문자는 쓸 수 없습니다 — 공백으로 들여쓰세요)" if "\t" in text else ""
        raise ConfigError(f"{path.name}{where}에 문법 오류가 있습니다{hint}: "
                          f"{getattr(e, 'problem', None) or e}") from e
    if not isinstance(cfg, dict):
        raise ConfigError(f"{path.name}의 내용이 설정 형식이 아닙니다 — 'roots:' 등 "
                          f"키: 값 꼴이어야 합니다.")
    return cfg


def load_config(path: Path) -> dict:
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except FileNotFoundError:
        print(f"오류: 설정 파일이 없습니다: {path}\n"
              f"  먼저 실행: python -m watcher.cli init", file=sys.stderr)
        raise SystemExit(2)
    cfg = _parse_config_text(raw, Path(path))
    # 'mail:'처럼 값 없이 키만 있으면 None이 되어 setdefault로는 못 막는다 → 명시 치환
    for key, default in _CONFIG_DEFAULTS.items():
        if cfg.get(key) is None:
            cfg[key] = default
    # 감시 폴더: roots 목록 우선, 구버전 root_path(단일 문자열)도 수용
    roots = cfg.get("roots")
    if not roots:
        rp = cfg.get("root_path")
        roots = [rp] if rp else []
    if isinstance(roots, (str, Path)):
        # roots: 'D:\\x' 처럼 목록이 아니게 적으면 글자 단위로 쪼개져 '\\'가 C:\\ 전체
        # 검사가 됐다 (2026-09-04 검토 ops M2)
        roots = [roots]
    cleaned = []
    for r in roots:
        s = str(r).strip() if r else ""
        if not s or s in ("\\", "/", "\\\\"):
            continue
        cleaned.append(s)
    cfg["roots"] = cleaned
    return cfg


def write_initial_config(root: str, dst: Path = Path("config.yaml")) -> None:
    """첫 설정 생성: 예시 설정의 감시 폴더만 입력값으로 바꿔 저장 (위저드·GUI 공용)."""
    text = (PROJECT_DIR / "config.example.yaml").read_text(encoding="utf-8")
    safe = "''".join(str(root).split("'"))  # YAML 단일따옴표 이스케이프
    text = re.sub(r'^\s*-\s*"tests/fixtures"\s*$', lambda _: f"  - '{safe}'",
                  text, count=1, flags=re.M)
    dst.write_text(text, encoding="utf-8")


def _root_labels(roots: list[Path]) -> list[str]:
    """감시 폴더별 라벨(경로 접두어). 폴더명 기준, 중복 시 ~2, ~3."""
    labels, seen = [], {}
    for r in roots:
        base = r.name or str(r)
        seen[base] = seen.get(base, 0) + 1
        labels.append(base if seen[base] == 1 else f"{base}~{seen[base]}")
    return labels


FOLDER_VOTES_META = "folder_votes"


def _save_folder_votes(state: State, votes: dict) -> None:
    """폴더 다수결 표를 DB meta에 남긴다 — 화면(정리 제안·폴더 구조·변경 상세)의 귀속 표시가
    검사와 같은 답을 내게 (검토22 D1). 실패해도 검사는 계속한다."""
    import json as _json
    try:
        state.set_meta(FOLDER_VOTES_META, _json.dumps(votes, ensure_ascii=False) if votes else None)
    except Exception:
        pass


def _load_folder_votes(state: State) -> dict:
    import json as _json
    try:
        raw = state.get_meta(FOLDER_VOTES_META)
        return _json.loads(raw) if raw else {}
    except Exception:
        return {}


def make_resolver(cfg: dict, roots: list, paths=None) -> ProjectResolver:
    """설정·감시 폴더 목록으로 귀속기를 만든다 — 검사와 화면이 같은 것을 쓴다.

    감시 폴더 이름에 프로젝트 번호가 있으면 그 폴더 전체를 그 프로젝트로 (자동).
    config `root_projects: {경로: 이름}`로 지정하거나(이름 ""이면 자동도 끔),
    설정 화면의 [프로젝트 하나로]로 정한다 (2026-09-02)."""
    roots = [Path(r) for r in roots]
    labels = _root_labels(roots)
    resolver = ProjectResolver.load(cfg["aliases"])
    resolver.root_labels = set(labels)
    declared = {str(k): ("" if v is None else str(v))
                for k, v in (cfg.get("root_projects") or {}).items()}
    rp = {}
    for root, label in zip(roots, labels):
        key = str(root)
        alt = root.as_posix()
        if key in declared or alt in declared:
            rp[label] = declared.get(key, declared.get(alt, ""))
        else:
            auto = resolver.root_project_for(label, root.name)
            if auto:
                rp[label] = auto
    resolver.root_projects = rp
    if paths:
        # 바로 아래 폴더들이 문서 종류 이름이면 프로젝트 하나 (구조 추정)
        resolver.infer_single_roots(
            paths, {label: root.name for root, label in zip(roots, labels)}, cfg)
    return resolver


def _excludes_for(label: str, all_labels: list[str], excludes: list[str]) -> list[str]:
    """제외 목록을 해당 감시 폴더 몫으로 변환.
    '라벨/상대경로' 형식은 그 폴더에만, 라벨 없는 형식은 모든 폴더에 공통 적용."""
    out = []
    for e in excludes:
        e = e.strip("/")
        head = e.split("/", 1)[0]
        if head == label and "/" in e:
            out.append(e.split("/", 1)[1])
        elif head not in all_labels:
            out.append(e)
    return out


def cmd_init(args: argparse.Namespace) -> int:
    dst = Path(args.config)
    if dst.exists():
        print(f"이미 있음: {dst} (덮어쓰지 않음)")
        return 1
    src = PROJECT_DIR / "config.example.yaml"
    dst.write_bytes(src.read_bytes())
    print(f"생성됨: {dst} — roots: 목록의 폴더를 감시할 파일서버 폴더로 바꿔주세요.")
    return 0


# 추출 결과 형식 세대 — 추출 결과의 모양이 달라질 때 올린다
# (v2: PDF 엔진 pdfium 교체 / v3: XLSX 전 시트 / v4: 머리글 최다 열 선택)
_CACHE_VER = 12   # 2026-09-20: PDF 표제란 REV.A·REV-A 구분자 (검토31 B11); 11: 2026-09-15: xlsx 개정이력 REV는 최고값 (검토25 6-4); 10: 개정이력 → REV 필드 (검토24 A-2)
# 형식별 호환 하한 — 그 형식의 추출 결과가 마지막으로 바뀐 세대. 이 이상이면 옛 기록도 그대로 쓴다:
# 세대가 오를 때마다 확장자 무관 전체 재추출(4만 파일이면 시간 단위)이 되고, 판 교체 전에 바뀐 파일은
# '이전 판' 기록이 옛 세대라 비교를 통째로 건너뛰었다 (검토25 D 2-1·감지 6-1, 검토26 1회차 1).
# 새 세대를 올릴 때 바뀐 형식만 여기서 올린다
_CACHE_FLOOR = {".xlsx": 11, ".xlsm": 11, ".dxf": 9, ".dwg": 9, ".pdf": 12, ".docx": 9, ".hwpx": 9}
# 세대를 올릴 때 바뀐 형식의 하한을 같이 올린다 — v0.57.12가 PDF 규칙을 바꾸고 하한을 9에 둬, 판 교체 뒤
# refresh-cache가 '128개 완료'라면서 실제로는 0건 재추출했다 (검토32 A 1). test_cache_ver가 max(하한)==세대를 지킨다


def _cache_ok(cached: dict | None, path: str) -> bool:
    """이 추출 기록을 지금 판이 그대로 써도 되나."""
    if not cached:
        return False
    gen = cached.get("cache_ver")
    if gen == _CACHE_VER:
        return True
    if not isinstance(gen, int) or gen > _CACHE_VER:      # 새 판이 쓴 기록을 구판이 섞지 않는다
        return False
    ext = PurePosixPath(str(path)).suffix.lower()
    return gen >= _CACHE_FLOOR.get(ext, _CACHE_VER)
# 추출 코드가 바뀌면 이 숫자를 올려야 캐시가 새로 만들어진다. 2026-08-26 이후 다섯 판 동안
# 4로 방치돼, 판올림 뒤 옛 캐시와 새 추출본을 섞어 비교했다(한 칸 수정에 브리핑 27줄).
# 손으로 지키는 규율은 무너지므로 시험(tests/test_cache_ver.py)이 지문으로 지킨다
# (2026-09-09 추출 검토 차단 1).
#
# v8 (2026-09-10 검토19): DXF 블록 6단·우상단 표제란 필드·XLSX 표 옆 낱 셀 — 캐시된 결과가
# 실제로 달라지므로 세대를 올린다(한 판 재추출). 앞선 .xlsm 추가(v0.55.0)는 결과가 안 변해
# 지문만 바꿨었다.
_EXTRACT_FINGERPRINT = "ba7f65697a49152c"  # v12: PDF REV.A·REV-A; v11: 개정이력 REV 최고값; v10: 개정이력 → REV 필드; v9: 배치공간 글자·세트 PDF 표제란 줄

# 검사 진행 상황 — 같은 프로세스의 웹 대시보드가 읽어 진행률을 보여준다
# (2026-08-28 사용자 요청: "몇 개 검토 중인지 / 몇 %인지 보이게").
# total이 0이면 전체 수를 아직 모르는 단계 → 개수만 표시
PROGRESS = {"phase": "", "done": 0, "total": 0, "current": "", "since": 0.0}

# 내용 비교를 시도하는 파일 크기 상한(MB) — 이보다 크면 변경 사실만 감시하고 내용 비교는
# 생략한다. 100만 선분 PDF·10만 행 엑셀은 분 단위, 병적 파일은 무한이다 (2026-09-04)
from watcher.extract import EXTRACT_MAX_MB  # noqa: E402  형식 레지스트리에서 파생 (검토19 원칙 ⑤)
SLOW_FILE_SECONDS = 30
EXTRACT_TIMEOUT = 300           # 파일 하나의 내용 추출·그림 상한(초) — config extract_timeout


# 멈춤 요청 — 같은 프로세스의 화면([검사 중지])이 세운다 (2026-09-02)
STOP = threading.Event()


class ScanCancelled(Exception):
    """사람이 검사를 멈췄다. 오류가 아니다."""


def request_stop() -> None:
    STOP.set()


def _set_progress(phase: str, done: int = 0, total: int = 0, current: str = "",
                  keep_since: bool = False) -> None:
    same_phase = PROGRESS.get("phase") == phase
    PROGRESS["phase"], PROGRESS["done"], PROGRESS["total"] = phase, done, total
    if PROGRESS.get("current") != current:
        # 지금 붙잡고 있는 파일과 그 시작 시각 — 한 파일에서 멈추면 화면에 보이게 (2026-09-04).
        # keep_since=폴더를 훑는 중: 표시할 폴더는 초당 수천 번 바뀌지만 시계는 '훑기 시작'부터
        # 흘러야 한다. 리셋하면 늘 (0초째)라 오래 걸림 경고가 영원히 안 뜬다 (7차 중간-C)
        if keep_since and same_phase and PROGRESS.get("current") and PROGRESS.get("since"):
            PROGRESS["current"] = current
        else:
            PROGRESS["current"], PROGRESS["since"] = current, time.time()
    # 진행 표시는 파일마다 갱신된다 — 멈춤을 확인하기에 가장 촘촘한 지점
    if phase and STOP.is_set():
        raise ScanCancelled()


VISUAL_EXTS = RENDER_EXTS + (".dwg",)   # 그림 비교 대상 — DWG는 기록된 그림끼리
DWG_NO_CONVERTER = ("DWG는 변환 프로그램이 있어야 글자·표제란을 읽습니다 (설정 › DWG 도면) "
                    "— 미리보기 그림으로만 비교")


def _wants_render(path: str, doc_or_dict) -> bool:
    """그림 기록 대상인가: DXF는 전부, PDF는 도면으로 보이는 것만 (표제란 항목이
    있거나 이름·폴더가 도면). 사양서·매뉴얼 PDF까지 그리면 DB만 커진다."""
    ext = PurePosixPath(path).suffix.lower()
    if ext not in RENDER_EXTS:
        return False
    if ext == ".dxf":
        return True
    fields = (doc_or_dict.fields if isinstance(doc_or_dict, Document)
              else (doc_or_dict.get("fields") or {}))
    if any(k in fields for k in ("DWG_NO", "REV", "DRAWING_NO")):
        return True
    return kind_of(path) == "도면"


def _dedupe_page_items(items: list) -> list:
    """글자 비교와 그림 비교가 같은 페이지 추가/삭제를 각각 잡으면 하나만 남긴다 —
    글자 쪽(줄 수가 적힌 것)을 우선 (2026-09-06). 둘이 **다른** 페이지를 가리키면
    글자 쪽만 남긴다 — 한 쪽을 지웠는데 "2페이지 삭제"와 "3페이지 삭제"가 함께 실려
    두 쪽 지운 것으로 읽혔다 (검토19 감지 ⑦; 잉크 분포가 비슷한 도면 세트에서 그림
    정렬이 순서대로 짝짓는 한계)."""
    def _is_txt(i) -> bool:
        return "텍스트" in str(i.old or "") + str(i.new or "")
    # 그림 정렬이 글자 비교의 페이지 대응을 앵커로 쓰게 된 뒤로는(검토19 2차 N2) 그림 쪽이
    # 가리키는 '다른 쪽' 삭제도 믿을 수 있다 — 그림만 있는 쪽의 삭제를 통째로 버리던 규칙을
    # 거둔다 (검토19c ③). 같은 쪽을 둘 다 잡았을 때만 글자 쪽을 남긴다
    best: dict = {}
    for i in items:
        if i.kind in ("PAGE_ADDED", "PAGE_REMOVED"):
            k = (i.kind, i.key)
            txt = _is_txt(i)
            if k not in best or (txt and not _is_txt(best[k])):
                best[k] = i
    out, seen = [], set()
    for i in items:
        if i.kind in ("PAGE_ADDED", "PAGE_REMOVED"):
            k = (i.kind, i.key)
            if k in seen or best[k] is not i:
                continue
            seen.add(k)
        out.append(i)
    return out


def _add_visual(rd: "RunData", path: str, items: list, vis) -> bool:
    """그림 비교 결과를 항목·캡처로 옮긴다. 돌려주는 값: 비교가 실제로 수행됐는가."""
    if vis is None:  # '비교 못 함'을 '변경 없음'과 구분해 고지 (원칙 4)
        items.append(ChangeItem(
            "CHECK_SKIPPED", "시각 비교", None,
            "수행 못 함: 페이지 렌더 실패 — 그림(도형) 변경은 비교하지 못함 "
            "(글자·표 비교는 위 항목대로)", "시각 비교 단계"))
        return False
    regions, caps = vis
    rot = caps.pop("PAGE_ROTATED", None)
    if rot:
        pgs = ", ".join(f"{p}페이지" for p in rot["pages"][:6])
        items.append(ChangeItem(
            "CHECK_SKIPPED", "페이지 방향", None,
            f"{pgs}의 방향이 돌아갔습니다 — 글자·그림 내용은 같습니다. 재스캔이면 "
            f"무시해도 되고, 일부러 돌린 것이면 인쇄 방향이 바뀝니다", "시각 비교"))
    beyond = caps.pop("PAGES_BEYOND", None)
    if beyond:
        items.append(ChangeItem("CHECK_SKIPPED", "시각 비교", None,
                                str(beyond.get("where", "")), "시각 비교"))
    grew = caps.pop("AREA_GREW", None)
    if grew:
        # 픽셀 비교로는 영영 안 보이는 변경 — 사실 자체를 알린다 (원칙 5)
        items.append(ChangeItem(
            "PAGE_VISUAL_CHANGED", "도면 범위", None,
            f"도면 범위가 넓어졌습니다 — {grew['where']}에 내용이 "
            f"새로 그려졌습니다. 그 부분은 이전 판에 없어 전/후 사진으로 겹쳐 볼 수 "
            f"없으니 파일을 열어 확인하세요", "도면 전체"))
    for key, where in regions:
        items.append(ChangeItem(
            "PAGE_VISUAL_CHANGED", key, None,
            "도면 그림 변경 감지 (전/후 확대 사진 참조)", where))
    # 페이지가 빠지거나 끼어든 것 — 글자 비교가 이미 같은 페이지를 잡았으면 중복 보고하지 않는다
    # (2026-09-06: 페이지 삭제로 번호가 밀리면 뒤 페이지가 전부 '신규'로 보이던 것)
    have_pages = {(i.kind, i.key) for i in items if i.kind in ("PAGE_ADDED", "PAGE_REMOVED")}
    for key, cap in caps.items():
        if key == "PAGE_MAP":
            rd.captures[(path, "PAGE_MAP")] = cap
            continue
        kind, _, pkey = key.partition("|")
        if kind in ("PAGE_ADDED", "PAGE_REMOVED", "PAGE_MOVED"):
            where = cap.get("where", pkey)
            if (kind, pkey) not in have_pages:      # 글자 비교 항목은 나중에 합쳐질 수 있어
                items.append(ChangeItem(kind, pkey, None if kind in ("PAGE_ADDED", "PAGE_MOVED") else where,
                                        where if kind in ("PAGE_ADDED", "PAGE_MOVED") else None, where))
            if cap.get("before") or cap.get("after"):
                rd.captures[(path, key)] = {"before": cap.get("before"), "after": cap.get("after")}
            continue
        rd.captures[(path, f"PAGE_VISUAL_CHANGED|{key}")] = cap
    return True


class LazyDocs(Mapping):
    """경로 → Document 사전이되, 문서는 필요할 때 추출 캐시(DB)에서 읽고 최근 것만
    몇 천 개 들고 있는다. 4만 파일의 추출본을 검사 내내 전부 메모리에 올리던 것
    (2026-09-04 검토 core H5: +1.4GB, 실서버는 몇 배 → MemoryError 뒤 매일 롤백)."""

    def __init__(self, state: State, keep: int = 2048):
        self._state = state
        self._sha: dict[str, str] = {}
        self._live: "OrderedDict[str, Document]" = OrderedDict()
        self._keep = keep

    def register(self, path: str, sha: str, doc: "Document | None" = None) -> None:
        self._sha[path] = sha
        if doc is not None:
            self._put(path, doc)

    def _put(self, path: str, doc: "Document") -> None:
        self._live[path] = doc
        self._live.move_to_end(path)
        while len(self._live) > self._keep:
            self._live.popitem(last=False)

    def __getitem__(self, path: str) -> "Document":
        d = self._live.get(path)
        if d is not None:
            self._live.move_to_end(path)
            return d
        sha = self._sha[path]                       # KeyError = 없는 경로 (dict와 같게)
        cached = self._state.load_extract(sha)
        if cached is None or "doc_type" not in cached:
            raise KeyError(path)
        d = Document.from_dict(cached)
        self._put(path, d)
        return d

    def __iter__(self):
        return iter(self._sha)

    def __len__(self) -> int:
        return len(self._sha)

    def __contains__(self, path) -> bool:
        return path in self._sha


def _extract_docs(state: State, abs_of: dict, records,
                  cfg: dict | None = None) -> tuple[Mapping, dict]:
    """현재 스냅샷의 문서 추출 (내용 해시 캐시). 실패는 (경로→사유)로 수집.
    돌려주는 docs는 지연 적재 사전(LazyDocs) — dict처럼 쓰되 전부를 들고 있지 않는다."""
    docs = LazyDocs(state)
    failures: dict[str, str] = {}
    total = len(records)
    known_hints = state.hints()          # 바뀐 것만 쓴다 — 검사 내내 쓰기 잠금 방지

    def _hint(path: str, sha: str, doc_or_dict) -> None:
        h = content_hint(doc_or_dict)
        if known_hints.get(path) != h:
            state.save_hint(path, sha, h)

    # 파일을 실제로 여는 일은 자식 프로세스에서 — 한 파일이 라이브러리 안에서 멈춰도 상한
    # (기본 300초)에서 끊고 다음 파일로 간다 (2026-09-05, 회사 PC "63/4,059 (1%) 멈춤").
    # 자식을 못 띄우면 예전처럼 같은 프로세스에서 연다
    from watcher.worker import ExtractTimeout, ExtractWorker, RemoteError
    # 표의 행 식별 열 — 설정 key_columns (2026-09-06 정밀화). 같은 프로세스 추출기에도 넣는다
    key_cols = [str(c).strip() for c in ((cfg or {}).get("key_columns") or []) if str(c).strip()]
    from watcher.extract import pdf as _pdf_mod
    from watcher.extract import xlsx as _xlsx_mod
    _xlsx_mod.USER_KEY_COLS = tuple(key_cols)
    ocr_on = bool((cfg or {}).get("ocr", True))         # 글자 없는 PDF를 Windows OCR로 (2026-09-06)
    _pdf_mod.OCR_ENABLED = ocr_on
    try:
        from watcher import ocr as _ocr_mod
        ocr_stamp = f"on:{_ocr_mod.language() or 'none'}" if ocr_on and _ocr_mod.available() else ("on:none" if ocr_on else "off")
    except Exception:
        ocr_stamp = "on:none" if ocr_on else "off"

    def _fresh(path: str, cached) -> bool:
        """저장된 추출본을 그대로 써도 되나 — 엑셀은 키 열 설정이 바뀌면 행 키가 달라져 다시 읽는다."""
        if not (cached is not None and "notes" in cached and _cache_ok(cached, path)):
            return False
        if PurePosixPath(path).suffix.lower() in (".xlsx", ".xlsm"):
            return list(cached.get("key_cols") or []) == key_cols
        if PurePosixPath(path).suffix.lower() == ".pdf":
            # OCR이 관여한 PDF(읽었거나 못 읽은 것)만 도장을 비교한다 — 글자 있는 PDF 수천 개를 토글마다
            # 다시 읽지 않게 (리뷰12 운영 중간-3). 도장 없는 '못 읽음' 기록(v0.50)은 한 번 다시 읽는다
            if "ocr" in cached:
                return cached["ocr"] == ocr_stamp
            return not any("텍스트가 거의 추출되지" in str(n) for n in (cached.get("notes") or []))
        return True

    def _stamp(path: str, d: dict) -> dict:
        if PurePosixPath(path).suffix.lower() in (".xlsx", ".xlsm"):
            d["key_cols"] = key_cols
        if PurePosixPath(path).suffix.lower() == ".pdf" and _ocr_involved(d):
            d["ocr"] = ocr_stamp
        return d
    worker: ExtractWorker | None = None
    if (cfg or {}).get("extract_worker", True) and not os.environ.get("DREV_NO_WORKER"):
        try:
            timeout = float((cfg or {}).get("extract_timeout") or EXTRACT_TIMEOUT)
        except (TypeError, ValueError):
            timeout = float(EXTRACT_TIMEOUT)
        w = ExtractWorker(timeout=timeout, cancel=STOP.is_set)
        if w.ping() and w.configure(key_cols, ocr_on):
            worker = w
        elif w.alive():
            w.kill()
            print("  참고: 내용 추출 자식 프로세스에 표 키 열 설정을 전하지 못해 같은 프로세스에서 엽니다",
                  file=sys.stderr)
        else:
            w.kill()
            print("  참고: 내용 추출 자식 프로세스를 띄우지 못해 같은 프로세스에서 엽니다 "
                  "(파일 하나가 멈추면 검사가 함께 멈출 수 있음)", file=sys.stderr)

    def _cancelled(e: RemoteError) -> bool:
        return getattr(e, "error_type", "") == "Cancelled"

    def _do_extract(abs_path):
        if worker is None:
            return extract(abs_path)
        try:
            return worker.extract(abs_path)
        except RemoteError as e:
            if _cancelled(e):
                raise ScanCancelled()
            raise

    def _do_render(abs_path, kind: str = "file"):
        if worker is None:
            return render_dxf(abs_path) if kind == "dxf" else render_file(abs_path)
        try:
            return worker.render(abs_path, kind)
        except RemoteError as e:
            if _cancelled(e):
                raise ScanCancelled()
            raise

    def _timeout_note(e: ExtractTimeout) -> str:
        return (f"{e} — 내용 비교를 생략하고 변경 사실만 감시합니다 (파일이 바뀌면 다시 시도, "
                f"상한은 설정 › 고급 › '파일 하나 시간 상한')")

    def _render(path: str, sha: str, abs_path, doc_or_dict) -> None:
        """도면이면 페이지 그림을 기록 — 같은 이름으로 덮어써도 전/후 그림 비교가
        되게 하는 '이전 판' (2026-09-02). 판(해시)당 한 번만 렌더한다."""
        if not _wants_render(path, doc_or_dict) or state.has_renders(sha):
            return
        if state.get_meta(f"render_skip:{sha}"):
            return                         # 지난번 상한을 넘긴 판 — 매일 5분씩 다시 멈추지 않게
        try:
            pages = _do_render(abs_path)
        except ExtractTimeout as e:
            state.set_meta(f"render_skip:{sha}", str(e))
            print(f"  경고: 페이지 그림 기록 중단 {path}: {_timeout_note(e)}", file=sys.stderr)
            return
        except ScanCancelled:
            raise                          # 사람이 멈춘 것 — 실패가 아니다 (리뷰11 차단)
        except Exception as e:
            if "그림 기록 상한" in str(e):
                # 심볼 라이브러리를 겹겹이 쌓은 도면 — 그리기 전에 규모를 재서 건너뛴다. 판(해시)당
                # 한 번만 알리고 다시 시도하지 않는다 (검토19c ⑤). 글자 비교는 그대로 된다
                state.set_meta(f"render_skip:{sha}", str(e))
                print(f"  참고: 페이지 그림 기록 생략 {path}: {clean_text(str(e))} — 글자·표제란 비교만 합니다",
                      file=sys.stderr)
                return
            print(f"  경고: 페이지 그림 기록 실패 {path}: {clean_text(str(e))}",
                  file=sys.stderr)
            return
        if pages:
            if str(path).lower().endswith(".dxf"):
                # 글자 자리도 함께 기록 — 이 판이 '옛 판'이 된 뒤 지워진 글줄의 자리를 가리려면 파일이
                # 없어도 자리를 알아야 한다 (검토21 재검증 D9)
                from watcher.capture import attach_text_boxes
                attach_text_boxes(abs_path, pages)
            state.save_renders(sha, pages)

    conv = resolve_converter(cfg)
    try:
        from watcher.convert import sweep_temp
        sweep_temp()                       # 지난 강제 종료가 남긴 임시 DWG 폴더 정리 (재검토 ⑥)
    except Exception:
        pass
    # 스크립트 방식이 대화상자(글꼴 누락 등)에서 멈춘 적이 있으면 며칠간 CAD를 띄우지
    # 않는다 — 매일 3분씩 CAD가 켜졌다 죽는 것 방지. [DWG 변환 시험]이 풀어 준다 (2026-09-04)
    backoff_note = None
    until = state.get_meta("dwg_backoff_until")
    if conv is not None and until:
        try:
            until_dt = datetime.fromisoformat(until)
        except ValueError:
            until_dt = None
        if until_dt and until_dt > datetime.now():
            backoff_note = (f"DWG 변환 프로그램({conv['name']})이 대화상자에서 멈춘 적이 있어 "
                            f"{until_dt:%m-%d}까지 변환을 건너뜁니다 — 빠진 글꼴을 채우거나 ODA File "
                            f"Converter를 설치한 뒤 설정 › [DWG 변환 시험]으로 다시 켜세요")
            conv = None
        else:
            state.set_meta("dwg_backoff_until", None)
    if backoff_note:
        print(f"  {backoff_note}", flush=True)
    if conv is None and any(r.path.lower().endswith(".dwg") for r in records):
        from watcher.convert import status as _conv_status
        print(f"  DWG 변환 프로그램: {_conv_status(cfg)[1]}", flush=True)

    def _dwg(r, cached) -> None:
        """DWG: 변환 프로그램이 있으면 DXF로 바꿔 글자·그림을, 없으면 미리보기 그림만.
        실패는 캐시하지 않는다 — 나중에 변환 프로그램을 설치하면 바로 살아나게 (2026-09-03)."""
        ap = abs_of[r.path]
        doc_ok = (cached is not None and "notes" in cached and _cache_ok(cached, r.path))
        if doc_ok:
            docs.register(r.path, r.sha256)
            _hint(r.path, r.sha256, cached)
            if state.has_renders(r.sha256):
                return
        if conv is not None and not doc_ok:
            res = batch.get(Path(ap))
            try:
                if not isinstance(res, Path):
                    raise RuntimeError(res or "이번 검사의 변환 묶음에 없음")
                doc = _do_extract(res)
                pages = _do_render(res, "dxf")
            except ExtractTimeout as e:
                failures[r.path] = f"DWG 읽기 중단: {_timeout_note(e)}"
                state.save_extract(r.sha256, {"extract_failed": failures[r.path],
                                              "cache_ver": _CACHE_VER})
                print(f"  경고: {failures[r.path]} — {r.path}", file=sys.stderr)
            except ScanCancelled:
                raise
            except Exception as e:
                failures[r.path] = f"DWG 변환 실패({conv['name']}): {clean_text(str(e))}"
                print(f"  경고: {failures[r.path]} — {r.path}", file=sys.stderr)
            else:
                if doc is not None:
                    doc = Document.from_dict({**doc.to_dict(), "doc_type": "dwg", "path": r.path})
                    state.save_extract(r.sha256, {**doc.to_dict(), "cache_ver": _CACHE_VER})
                    docs.register(r.path, r.sha256, doc)
                    _hint(r.path, r.sha256, doc)
                if pages:
                    state.save_renders(r.sha256, pages)
                    return
        if not state.has_renders(r.sha256) and not state.get_meta(f"render_skip:{r.sha256}"):
            try:
                pages = _do_render(ap)               # 파일 안의 미리보기 그림
            except ExtractTimeout as e:
                state.set_meta(f"render_skip:{r.sha256}", str(e))
                pages = []
            except ScanCancelled:
                raise
            except Exception:
                pages = []
            if pages:
                state.save_renders(r.sha256, pages)
        if conv is None and not doc_ok:
            failures[r.path] = backoff_note or DWG_NO_CONVERTER

    # 지난 검사가 어느 파일을 처리하다 죽었는가(창 닫힘·강제 종료) — 같은 파일이 매번 검사를
    # 붙잡는 '독 파일'이 되지 않게 이번에는 건너뛰고, 파일이 바뀔 때까지 다시 시도하지 않는다
    stale = state.get_meta("extract_in_progress") or ""
    stale_sha = stale.split("|", 1)[0] if stale else ""
    if stale:
        state.set_meta("extract_in_progress", None)
        # 창 닫기·강제 종료 때 우연히 열려 있던 정상 파일까지 영구 건너뛰기가 되지 않게 —
        # **두 번 연속** 같은 판에서 죽었을 때만 독 파일로 본다 (재검토 ②)
        if state.get_meta("poison_candidate") == stale_sha:
            print(f"  지난 검사 두 번이 {stale.split('|', 1)[-1]} 처리 중에 끝나 이번에는 그 파일의 "
                  f"내용 비교를 건너뜁니다", file=sys.stderr)
        else:
            state.set_meta("poison_candidate", stale_sha)
            print(f"  지난 검사가 {stale.split('|', 1)[-1]} 처리 중에 끝났습니다 — 이번에 다시 시도하고, "
                  f"또 멈추면 건너뜁니다", file=sys.stderr)
            stale_sha = ""
    poison_cand = state.get_meta("poison_candidate") or ""

    def _guard(r, on: bool) -> None:
        """실제로 파일을 여는 동안만 표식을 둔다 (캐시된 것은 표식 없음)."""
        state.set_meta("extract_in_progress", f"{r.sha256}|{r.path}" if on else None)

    def _too_big(r) -> str | None:
        cap = EXTRACT_MAX_MB.get(PurePosixPath(r.path).suffix.lower())
        size = getattr(r, "size", 0) or 0
        if cap and size > cap * 1024 * 1024:
            return (f"파일이 너무 큽니다({size / 1048576:.0f}MB, 상한 {cap}MB) — 변경 사실만 감시하고 "
                    f"내용 비교는 생략합니다")
        return None

    def _extract_loop(state, abs_of, records, total, docs, failures, _hint, _dwg) -> None:
        for i, r in enumerate(records, 1):
            _set_progress("2/3 내용 추출", i, total, current=r.path)
            if i % 100 == 0:
                print(f"  내용 추출 {i}/{total}…", flush=True)
            cached = state.load_extract(r.sha256)
            if stale_sha and r.sha256 == stale_sha and not (
                    cached is not None and "notes" in cached):
                failures[r.path] = ("지난 검사가 이 파일을 처리하다 멈춰 이번에는 내용 비교를 "
                                    "건너뜁니다 (파일이 바뀌면 다시 시도). 너무 크거나 깨진 파일이면 "
                                    "감시 제외에 추가하세요")
                state.save_extract(r.sha256, {"extract_failed": failures[r.path],
                                              "cache_ver": _CACHE_VER})
                state.set_meta("poison_candidate", None)
                continue
            if r.path.lower().endswith(".dwg"):
                _guard(r, True)
                t0 = time.monotonic()
                _dwg(r, cached)
                _guard(r, False)
                if time.monotonic() - t0 > SLOW_FILE_SECONDS:
                    print(f"  느린 파일: {r.path} ({time.monotonic() - t0:.0f}초)", file=sys.stderr)
                continue
            big = _too_big(r)
            if big and not (cached is not None and "notes" in cached):
                failures[r.path] = big
                if cached is None or cached.get("extract_failed") is None:
                    state.save_extract(r.sha256, {"extract_failed": big, "cache_ver": _CACHE_VER})
                continue
            # 실패 캐시: 암호·손상 파일을 매 검사마다 다시 여는 낭비 방지 (2026-08-29
            # — 4만 파일 실서버에서 수백 건이 매일 재시도되던 것). 파일이 바뀌면
            # 해시가 달라져 자동으로 재시도된다
            if cached is not None and cached.get("extract_failed") is not None \
                    and _cache_ok(cached, r.path):
                failures[r.path] = cached["extract_failed"]
                continue
            # 구버전 스키마(notes 없음)나 다른 추출 엔진 세대의 저장분은 재추출 —
            # 엔진이 다르면 줄 나뉨이 달라 섞어 비교하면 소음이 난다 (2026-08-26 pdfium 교체)
            if _fresh(r.path, cached):
                docs.register(r.path, r.sha256)        # 필요할 때 다시 읽는다
                _hint(r.path, r.sha256, cached)
                if poison_cand and r.sha256 == poison_cand:
                    # 추출본은 이미 있었고 그림 기록 중에 죽은 경우 — 여기서도 후보를 풀어야
                    # 다음에 걸리면 '두 번째'로 세지 않는다 (검토19 감지 ⑩)
                    state.set_meta("poison_candidate", None)
                if not state.has_renders(r.sha256):
                    _guard(r, True)
                    _render(r.path, r.sha256, abs_of[r.path], cached)
                    _guard(r, False)
                continue
            _guard(r, True)
            t0 = time.monotonic()
            try:
                doc = _do_extract(abs_of[r.path])
            except ExtractTimeout as e:
                failures[r.path] = _timeout_note(e)
                print(f"  경고: 추출 중단 {r.path}: {failures[r.path]}", file=sys.stderr)
                state.save_extract(r.sha256, {"extract_failed": failures[r.path],
                                              "cache_ver": _CACHE_VER})
                _guard(r, False)
                continue
            except ScanCancelled:
                _guard(r, False)
                raise                      # [검사 중지] — '추출 실패'로 캐시하면 다음 검사부터 매일 실패로 나온다 (리뷰11 차단)
            except Exception as e:  # 손상 파일 등 — 파일 수준 감지는 이미 됐음
                # 예외 메시지에도 깨진 인코딩이 실려 올 수 있다 — 그대로 DB·브리핑에
                # 들어가면 저장이 죽는다 (2026-08-27 회사 실파일)
                failures[r.path] = _friendly_error(e)
                print(f"  경고: 추출 실패 {r.path}: {failures[r.path]}", file=sys.stderr)
                # 잠김·순단(OSError)은 일시적일 수 있어 캐시하지 않는다. 사유가 비어 있으면 무엇인지
                # 모르는 실패라 캐시하지 않는다
                transient = isinstance(e, OSError) or (
                    isinstance(e, RemoteError) and (e.transient or e.error_type in ("WorkerDied", "BrokenPipe", "ConfigLost")))
                if not transient and failures[r.path].strip():
                    state.save_extract(r.sha256, {
                        "extract_failed": failures[r.path], "cache_ver": _CACHE_VER})
                _guard(r, False)
                continue
            if doc is not None:
                state.save_extract(r.sha256, _stamp(r.path, {**doc.to_dict(), "cache_ver": _CACHE_VER}))
                docs.register(r.path, r.sha256, doc)
                # 내용에서 읽은 유형 단서 — 파일명에 이름이 없는 견적서 등 (2026-09-02)
                _hint(r.path, r.sha256, doc)
                _render(r.path, r.sha256, abs_of[r.path], doc)
            _guard(r, False)
            if poison_cand and r.sha256 == poison_cand:
                state.set_meta("poison_candidate", None)   # 다시 시도해 성공 — 후보 해제
            if time.monotonic() - t0 > SLOW_FILE_SECONDS:
                print(f"  느린 파일: {r.path} ({time.monotonic() - t0:.0f}초)", file=sys.stderr)

    # DWG는 검사당 한 번의 실행으로 묶어 변환한다 — 장마다 CAD가 켜졌다 꺼지던 것
    # (2026-09-03). 이미 읽은 판(추출본 있음)은 다시 변환하지 않는다
    batch: dict = {}
    pending = []
    if conv is not None:
        for r in records:
            if not r.path.lower().endswith(".dwg"):
                continue
            c_ = state.load_extract(r.sha256)
            if not (c_ is not None and "notes" in c_ and _cache_ok(c_, r.path)):
                pending.append(Path(abs_of[r.path]))
    with contextlib.ExitStack() as stack:
        if pending:
            print(f"  DWG 변환: {conv['name']} — {len(pending)}장을 한 번에", flush=True)
            # 화면이 '멈춘 것처럼' 보이지 않게 — CAD가 도는 동안의 단계 표시 (2026-09-04)
            phase = f"DWG 변환 중 — {conv['name']} 실행 (결과가 3분간 없으면 자동 중단)"
            _set_progress(phase, 0, len(pending))
            # [검사 중지]가 CAD 묶음 도중에도 바로 먹고, 묶음마다 진행이 올라가게 (2026-09-04)
            batch = stack.enter_context(converted_many(
                pending, conv, cancel=STOP.is_set,
                progress=lambda k, n: PROGRESS.update({"phase": phase, "done": k, "total": n})))
            if STOP.is_set():
                raise ScanCancelled()
            from watcher.convert import DIALOG_LOG, UNKNOWN_DIALOGS
            if DIALOG_LOG:
                kinds = sorted({f"'{ttl[:40]}' → [{btn}]" for ttl, btn in DIALOG_LOG})
                print(f"  CAD 대화상자 자동 응답 {len(DIALOG_LOG)}건: {'; '.join(kinds)}", flush=True)
            for ttl, btns in UNKNOWN_DIALOGS:
                print(f"  경고: 모르는 CAD 대화상자 '{ttl}' (버튼: {', '.join(btns) or '없음'}) — "
                      f"이 문구를 알려주시면 다음 판에서 자동 응답합니다", file=sys.stderr)
            if conv.get("kind") == "cadscript" and any(
                    isinstance(v, str) and "대화상자" in v for v in batch.values()):
                # 백오프는 CAD 창을 빌리는 방식에만 — ODA의 거대 도면 지연은 대화상자가 아니다 (재검토 ⑪)
                state.set_meta("dwg_backoff_until",
                               (datetime.now() + timedelta(days=7)).isoformat(timespec="minutes"))
        try:
            _extract_loop(state, abs_of, records, total, docs, failures, _hint, _dwg)
        finally:
            if worker is not None:
                if worker.timeouts or worker.restarts:
                    print(f"  내용 추출 프로세스: 상한 초과 {worker.timeouts}회, 다시 띄움 "
                          f"{worker.restarts}회", flush=True)
                worker.close()
    state.conn.commit()
    HINTS.clear()
    HINTS.update(state.hints())               # 이번 검사의 보고·화면이 바로 쓰게
    return docs, failures


# 따옴표로 **감싸인** 경로는 닫는 따옴표까지(공백 포함), 그 밖은 공백 전까지 (재검증 N3, 2차: 따옴표가
# 뒤쪽 어딘가에만 있으면 문장까지 삼키던 것)
_QUOTED_PATH_RE = re.compile(r"(?<=['\"])(?:[A-Za-z]:\\|\\\\)[^'\"\r\n]*?(?=['\"])")
_ABS_PATH_RE = re.compile(r"(?:[A-Za-z]:\\|\\\\)[^\s'\"()]+")


def _strip_paths(s: str) -> str:
    """문장 속 서버 절대 경로를 지운다 — 메일은 파일 이름만 말한다 (검토21 브리핑 중간 7)."""
    def _name(m):
        return "(경로 생략)/" + m.group(0).rstrip("\\").rsplit("\\", 1)[-1]
    return _ABS_PATH_RE.sub(_name, _QUOTED_PATH_RE.sub(_name, s))


def _friendly_error(e: Exception) -> str:
    """라이브러리 오류 원문("File is not a zip file")을 담당자 말로 (2026-09-05 전체 검토)."""
    s = clean_text(str(e))
    low = s.lower()
    tname = (getattr(e, "error_type", "") or type(e).__name__).lower()
    if "not a dxf file" in low or "invalid dxf" in low or "dxfstructureerror" in tname:
        return f"DXF 파일로 읽을 수 없음 — 저장 중 끊겼거나 확장자와 내용이 다른 파일일 수 있습니다 ({s})"
    if "not a zip file" in low or "bad zip" in low or "badzipfile" in tname:
        return f"파일이 깨져 열 수 없음 — 저장 중 끊겼거나 확장자와 내용이 다른 파일일 수 있습니다 ({s})"
    if "password" in low or "encrypted" in low:
        return f"암호가 걸린 파일이라 내용을 읽지 못함 ({s})"
    if "permission" in low or "being used" in low or "errno 13" in low:
        return f"파일이 잠겨 있거나 권한이 없음 — 다음 검사에서 다시 시도 ({s})"
    if "no such file" in low or "errno 2" in low:
        return f"검사 중 파일이 사라짐 — 다음 검사에서 다시 확인 ({s})"
    return s


def _ocr_involved(d: dict) -> bool:
    """추출본에 OCR이 관여했나 — OCR로 읽은 글줄·필드가 있거나, 글자를 못 읽어 고지가 남은 경우."""
    try:
        if any("OCR" in str(f.get("where", "")) for f in (d.get("fields") or {}).values()):
            return True
        if any("OCR" in str(t.get("where", "")) for t in (d.get("raw_texts") or [])):
            return True
        return any("텍스트가 거의 추출되지" in str(n) for n in (d.get("notes") or []))
    except Exception:
        return False


# 고지 중에는 '이 파일은 비교 못 한다'가 아니라 '일부 검사만 못 한다'는 것도 있다.
# 그것까지 비교를 막으면 멀쩡히 읽은 본문 변경이 통째로 사라진다 — 칸이 나뉜 표제란(라벨 위,
# 값 아래) 도면에서 태그·주기 변경 세 건이 없어졌다 (2026-09-09 추출 검토 차단 2).
from watcher.extract.pdf import PARTIAL_READ_NOTE as _PARTIAL_READ

# 일부만 못 읽은 고지는 비교를 막지 않는다 — 표제란을 읽었는데도 "비교 불가"라
# 고지하고 Rev 변경을 빠뜨리던 것 (2026-09-09 배포 후 검토 차단 2)
_PARTIAL_NOTES = ("표제란을 인식하지 못함", _PARTIAL_READ)


def _blocking_notes(doc: Document | None) -> list:
    return [n for n in (doc.notes if doc is not None else [])
            if not str(n).startswith(_PARTIAL_NOTES)]


def unreadable_note(old_doc: Document | None, new_doc: Document | None) -> str | None:
    """구/신 어느 쪽이든 추출기가 '비교 불가' 고지를 남겼으면 그 사유.
    이 경우 diff·Rev 검사를 하지 않는다 — 근거 없는 비교 결과를 내지 않기 위해 (PRINCIPLE 4).
    일부 검사만 못 하는 고지(_PARTIAL_NOTES)는 여기서 세지 않는다."""
    if new_doc is not None and _blocking_notes(new_doc):
        return _blocking_notes(new_doc)[0]
    if old_doc is not None and _blocking_notes(old_doc):
        if new_doc is not None and "OCR" in _blocking_notes(old_doc)[0]:
            # 이전 판은 OCR을 끈 채(또는 언어팩 없이) 기록됐고 새 판은 읽혔다 — 사유를 그대로 옮기면
            # "켰는데 꺼져 있다"가 된다 (2026-09-06 사용성 5차 (f))
            return "이전 판이 OCR 없이 기록된 판이라 이번엔 글자 비교를 못 했습니다 — 다음 변경부터 비교합니다"
        return f"(이전 판) {_blocking_notes(old_doc)[0]}"
    return None


def _protect_config_password(config_path, cfg) -> str:
    """config.yaml에 평문으로 남은 SMTP 비밀번호를 DPAPI로 감싸 저장한다 — 설정 화면을 여는 PC만
    감싸지던 것 (리뷰10 낮음-8). 감쌌으면 안내 한 줄, 아니면 빈 문자열. 실패는 조용히 넘긴다."""
    from watcher.secret import available, is_protected, protect
    m = dict((cfg or {}).get("mail") or {})
    pw = m.get("password")
    if not pw or is_protected(str(pw)) or not available():
        return ""
    try:
        import yaml
        p = Path(config_path)
        text = p.read_text(encoding="utf-8")
        data = yaml.safe_load(text) or {}
        mm = dict(data.get("mail") or {})
        if not mm.get("password") or is_protected(str(mm["password"])):
            return ""
        wrapped = protect(str(mm["password"]))
        if not is_protected(wrapped):
            return ""
        # 손으로 적은 주석을 지우지 않게 통째로 다시 쓰지 않고 password 줄만 바꾼다 (리뷰11 낮음-4).
        # 줄을 못 찾으면(따옴표·접힘 등) 그때만 통째로 다시 쓴다
        pat = re.compile(r"^(\s+password\s*:\s*)(.*?)\s*(#.*)?$", re.M)
        found = [m for m in pat.finditer(text)
                 if yaml.safe_load(m.group(2)) == mm["password"]]
        if len(found) == 1:
            m = found[0]
            new_text = text[:m.start()] + m.group(1) + f'"{wrapped}"' + (" " + m.group(3) if m.group(3) else "") \
                + text[m.end():]
            if (yaml.safe_load(new_text) or {}).get("mail", {}).get("password") != wrapped:
                raise ValueError("줄 바꾸기 검증 실패")
            p.write_text(new_text, encoding="utf-8")
        else:
            mm["password"] = wrapped
            data["mail"] = mm
            p.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
        if isinstance(cfg.get("mail"), dict):
            cfg["mail"]["password"] = wrapped
        return "저장돼 있던 SMTP 비밀번호를 이 PC의 Windows 계정으로 암호화했습니다"
    except Exception as e:
        return f"경고: SMTP 비밀번호가 config.yaml에 평문으로 남아 있는데 암호화해 저장하지 못했습니다 ({e}) — 설정 › 메일에서 다시 저장하세요"


def _brief_target(day_path: Path, run_at: datetime, merged: bool, dry_run: bool) -> Path:
    """그 날의 브리핑 파일 — 합산했으면 그 날 파일을 갱신(덮어씀), 미리보기(dry-run)는 `_미리보기`를
    붙여 실검사 파일과 섞이지 않게, 그 밖(기준선·합산 없음)은 시각을 붙여 보존 (리뷰10 중간-6)."""
    if merged:
        return day_path
    if dry_run and "_기준선" not in day_path.stem:      # 기준선은 이미 제 이름이 있어 합산과 겹치지 않는다
        day_path = day_path.with_name(f"{day_path.stem}_미리보기{day_path.suffix}")
    return _unique_brief(day_path, run_at)


def _unique_brief(path: Path, run_at: datetime) -> Path:
    """같은 날 두 번째 검사가 아침 브리핑을 덮어쓰지 않게 — 시각을 붙인다 (2026-09-03 검토)."""
    if not path.exists():
        return path
    cand = path.with_name(f"{path.stem}_{run_at:%H%M}{path.suffix}")
    n = 2
    while cand.exists():
        cand = path.with_name(f"{path.stem}_{run_at:%H%M}_{n}{path.suffix}")
        n += 1
    return cand


def _report_and_send(args, cfg, state: State, rd) -> None:
    """귀속 → 이슈 저장 → 콘솔 출력 → 브리핑 저장 → 메일. 실패 시 호출부가 롤백."""
    root = rd.root_display
    changes, docs, details = rd.changes, rd.docs, rd.details
    issues, scan_errors, labels = rd.issues, rd.scan_errors, rd.labels
    snapshot_id, captures = rd.snapshot_id, rd.captures
    # 폴더 구조 추정(하위가 종류 폴더면 하나)은 **제안**으로만 쓴다 — 귀속에 자동
    # 적용하면 '종류 우선, 그 아래 프로젝트' 구조에서 표제란 번호를 덮어썼다
    # (2026-09-02 검토). 지정(root_projects)·폴더명 번호만 귀속에 쓴다
    resolver = make_resolver(cfg, rd.roots)
    resolver.folder_votes = rd.folder_votes or _load_folder_votes(state)
    involved = {c.path for c in changes} | {i.path for i in issues}
    proj_of = {}
    for p in involved:
        doc = docs.get(p)
        if doc is None:  # 삭제된 파일: 구버전 추출본으로 표제란 귀속 시도
            c = next((c for c in changes if c.path == p and c.old_sha256), None)
            old = state.load_extract(c.old_sha256) if c else None
            doc = (Document.from_dict(old)
                   if old and old.get("fields") is not None else None)
        proj_of[p] = resolver.attribute(p, doc)

    for c in changes:
        if c.id is not None:
            state.set_change_project(c.id, proj_of[c.path][0])

    # 일관성 이슈를 DB에 남긴다 — 대시보드 화면·누적 카운터용.
    # 브리핑·콘솔에는 '새로 검출된 것'만 싣는다 (미해결 이슈가 변경 있는 날마다
    # 메일로 재알림되던 소음 제거 — 누적은 화면에서 본다, 2026-08-26)
    today_keys = {(i.code, i.path, i.message) for i in issues}
    # 폴더를 옮기면(아카이브 등) 옛 경로의 열린 이슈가 '파일 삭제됨'으로 닫히고 새 경로에서
    # '새 검토 필요'로 되살아나 메일 초안까지 냈다 (파일럿 모의 ②). 이동 짝이 있으면 이슈의
    # 경로를 따라 옮긴다 — 그러면 저장 단계의 중복 억제에 걸려 새 것으로 세지 않는다
    if snapshot_id is not None and rd.moved:
        n_re = 0
        for new_p, (old_p, _sha, _same) in rd.moved.items():
            if old_p != new_p:
                n_re += state.repath_open_issues(old_p, new_p)
        if n_re:
            print(f"검토 필요 {n_re}건의 경로를 옮긴 파일을 따라 갱신 (새 이슈 아님)")
    if issues and snapshot_id is not None:
        # 이번 검사에서 조용한 변경(재저장·일자만·이동)만 겪은 경로 — 닫아 둔 이슈를 되살리지 않게.
        # 상세는 이 뒤에 저장되므로 여기서 같은 규칙으로 판정해 넘긴다 (검토31 C 1)
        import json as _json
        quiet_now = frozenset(
            p_ for p_, its in (rd.details or {}).items()
            if State._quiet_items(_json.dumps([{"kind": getattr(i, "kind", ""), "new": getattr(i, "new", None)}
                                               for i in (its or [])], ensure_ascii=False)))
        fresh = state.save_issues(snapshot_id,
                                  [(i, proj_of[i.path][0]) for i in issues], quiet_paths=quiet_now)
        issues = [i for i, _ in fresh]
    if snapshot_id is not None and changes:
        # 다시 검사했는데 재검출되지 않은 열린 이슈는 해소된 것 (2026-09-03 검토)
        # 내용 그대로 옮겨진 파일은 다시 검사된 것이 아니다 — 새 경로가 '추가'로 들어가 옮겨 준 이슈가
        # 같은 실행에서 "재검출되지 않음"으로 닫혔다 (검토21 감지 중간 4)
        same_moves = {p for p, (_o, _s, same) in (rd.moved or {}).items() if same}
        n_auto = state.auto_resolve_issues(
            today_keys, {c.path for c in changes} - same_moves, set(rd.checked_projects),
            readable=set(rd.docs),
            present={r.path for r in rd.records} | set(rd.carry_paths))
        if n_auto:
            print(f"검토 필요 자동 해소 {n_auto}건 (다시 검사했을 때 재검출되지 않음)")

    # 변경 상세(diff+캡처)도 저장 — 화면에서 변경 행을 클릭하면 바로 보이도록
    from dataclasses import asdict
    for p_ in list(details):
        details[p_] = _dedupe_page_items(details[p_])
    for c in changes:
        if c.id is not None and c.path in details:
            caps = {k[1]: v for k, v in (captures or {}).items() if k[0] == c.path}
            state.save_change_details(
                c.id, [asdict(i) for i in details[c.path]], caps)

    if scan_errors:
        print(f"읽지 못한 파일 {len(scan_errors)}건 (다음 실행에서 재시도):")
        for p, err in scan_errors:
            print(f"  [실패] {p}: {err}")
    if not changes:
        print("변경 없음.")
    else:
        print(f"변경 {len(changes)}건:")
        for c in changes:
            old = (c.old_sha256 or "-")[:12]
            new = (c.new_sha256 or "-")[:12]
            print(f"  [{KIND_LABEL[c.kind]}] {c.path}  (sha256 {old} -> {new})")
            for i in details.get(c.path, []):
                print(f"      {i.kind} {i.key}: {i.old or '—'} -> {i.new or '—'}  @ {i.where}")
    if issues:
        print(f"검토 필요 {len(issues)}건:")
        for iss in issues:
            print(f"  [{CODE_LABEL[iss.code]}] {iss.path} — {iss.message}")
            for ev in iss.evidence:
                print(f"      근거: {ev}")

    groups: dict[str, dict] = {}
    for c in changes:
        g = groups.setdefault(proj_of[c.path][0], {"changes": [], "issues": []})
        g["changes"].append(c)
    for iss in issues:
        g = groups.setdefault(proj_of[iss.path][0], {"changes": [], "issues": []})
        g["issues"].append(iss)

    ack_tokens = {c.id: state.ack_token(c.id) for c in changes if c.id is not None}
    ack_host = urlparse(cfg["ack_url"]).hostname or ""
    mail_on = bool(cfg["mail"].get("enabled")) and not args.dry_run
    if mail_on and ack_host in ("127.0.0.1", "localhost"):
        print("참고: 메일의 [확인했음 기록] 링크는 이 PC에서 누를 때만 동작합니다 "
              "(화면은 보안상 이 PC에서만 열립니다). 수신자는 회신으로, 기록은 이 PC의 "
              "화면에서 담당자가 남기는 운영을 권장합니다.", file=sys.stderr)

    run_at = datetime.now()
    brief_dir = Path(args.brief_dir or cfg["brief_dir"])
    brief_dir.mkdir(parents=True, exist_ok=True)
    scanned = len(rd.records)  # 브리핑 '파일 N개 검사' 표기용
    # 도면번호·Rev·개정 사유 — 실무 언어로 브리핑 (설계 10년차 검토, 2026-08-28)
    doc_info: dict = {}
    _mt_of = {r.path: r.mtime for r in rd.records}      # 파일 저장 시각 (2026-09-17 요청)
    for c in changes:
        if c.kind != "removed" and _mt_of.get(c.path):
            doc_info.setdefault(c.path, {"dwg": None, "rev": None, "note": None})["mtime"] = _mt_of[c.path]
        d = docs.get(c.path)
        if d is None and c.kind == "removed" and c.old_sha256:
            # 삭제 행에도 도면번호·Rev — 구판 추출본이 있다 (검토19 브리핑 ⑯)
            dd = state.load_extract(c.old_sha256)
            if dd and not dd.get("extract_failed"):
                try:
                    d = Document.from_dict(dd)
                except Exception:      # noqa: BLE001
                    d = None
        if d is None:
            continue
        f_dwg, f_rev = d.fields.get("DWG_NO"), d.fields.get("REV")
        note = (_reason_from_items(details.get(c.path, []))
                or _latest_rev_note(d.revision_history, f_rev.value if f_rev else None))
        if f_dwg or f_rev or note:
            doc_info[c.path] = {"dwg": f_dwg.value if f_dwg else None,
                                "rev": f_rev.value if f_rev else None,
                                # 리비전 행이 이번 변경에서 생겼을 때만 — 옛 행을 인용하면
                                # 되돌림에서 반대 방향 사유가 실린다 (2026-09-03 검토)
                                "note": (note if note and any(
                                    i.kind == "REVROW_ADDED" for i in details.get(c.path, []))
                                    else None),
                                "mtime": _mt_of.get(c.path) if c.kind != "removed" else None}
    # 첫 검사(기준선)의 '추가' N건은 변경이 아니다 — "변경 33건" 메일 초안이 화면(0건)과
    # 어긋났다 (2026-09-05 전체 검토). 브리핑은 '기준선 등록'으로 표기하고, 메일 초안은
    # 검토 필요가 있는 프로젝트만 만든다
    is_baseline = (state.first_snapshot_id() == snapshot_id)
    rd.is_baseline = is_baseline
    # 같은 날 두 번째 검사는 아침 브리핑과 **합쳐 한 통**으로 갱신한다 — 프로젝트마다 초안이
    # 시각별로 쌓여 어느 통을 보낼지 골라야 했다 (2026-09-05 재검토). 앞선 변경의 상세·캡처는
    # DB에서 되살린다. 첫 검사(기준선)의 등록 건은 변경이 아니라 합치지 않는다
    merged_note: dict[str, str] = {}
    acked_by: dict[int, str] = {}
    # 같은 파일이 오늘 두 번 바뀌면 상세·캡처가 경로 키로 겹친다 — 변경 id별로 따로 싣는다
    details_by_id: dict[int, list] = {}
    if snapshot_id is not None and not is_baseline and not args.dry_run:
        details = dict(details)
        captures = dict(captures or {})
        first_id = state.first_snapshot_id()
        # 기준 날짜는 보고 시점이 아니라 이번 검사의 시작 시각 — 자정을 걸친 검사가 다음 날
        # 파일로 가던 것 (코드 검토)
        day_iso = state.snapshot_local_date(snapshot_id) or run_at_local_date()
        earlier = [c for c in state.changes_on_day(day_iso, exclude_snapshots={snapshot_id, first_id})
                   if c.id is not None]
        # 같은 날 아침에 켠 확장자의 첫 등록이 오후 '갱신' 통에서 '추가'로 되살아났다 —
        # 등록으로 접은 것을 합산 경로가 몰랐다 (검토19 브리핑 ②, 검토18의 같은 날 재발)
        ext_base = state.ext_baseline()
        if earlier:
            # 확장자 등록뿐 아니라 **나중에 추가한 폴더의 첫 등록**도 걸러야 한다 — 이 블록이
            # `ext_base`가 있을 때만 돌아, 확장자를 켠 적 없는 설치본에서는 아침에 추가한 폴더의
            # 등록이 오후 '갱신' 통에서 "변경 3건"으로 되살아났다 (검토20 A-1)
            ids = [c.id for c in earlier]
            snap_of: dict = {}
            for k in range(0, len(ids), 500):
                chunk = ids[k:k + 500]
                snap_of.update(state.conn.execute(
                    "SELECT id, snapshot_id FROM changes WHERE id IN (%s)"
                    % ",".join("?" * len(chunk)), chunk))
            first_by_root = state.first_snapshot_by_root()
            earlier = [c for c in earlier
                       if not State.is_first_registration(c.kind, c.path, snap_of.get(c.id),
                                                          first_by_root, ext_base)]
        earlier_ids = {c.id for c in earlier}
        cur_paths = {c.path for c in changes}
        for c in earlier:
            proj = c.project or "미분류"
            # 되살린 앞선 변경은 **그때의** 도면번호·Rev를 단다 — 경로 키를 쓰면 A→B 행이
            # 'Rev C'(현재 값)로 보였다. 세 번째 지적 (2026-09-06·09-09·검토19 브리핑 ⑪)
            if c.new_sha256 and c.id is not None:
                dd = state.load_extract(c.new_sha256)
                if dd and not dd.get("extract_failed"):
                    fl = dd.get("fields") or {}
                    dwg_ = (fl.get("DWG_NO") or {}).get("value")
                    rev_ = (fl.get("REV") or {}).get("value")
                    if dwg_ or rev_:
                        doc_info[c.id] = {"dwg": dwg_, "rev": rev_, "note": None,
                                          "mtime": state.change_mtimes(c.id)[0]}   # 되살린 변경의 저장 시각
            if proj not in groups:
                continue                   # 이번 검사에 그 프로젝트 변경이 없으면 아침 통이 그대로 유효
            cur_ids = {x.id for x in groups[proj]["changes"]}
            if c.id in cur_ids:
                continue
            # 같은 파일이 오늘 두 번 바뀐 경우도 싣는다 — 예전에는 최신 변경만 남기고
            # 아침 근거(전/후 사진·항목)를 버렸다 (2026-09-09 브리핑 검토 차단 2).
            # 상세·캡처를 변경 id로 넣어 두 행이 각자의 근거를 갖게 한다
            same_path = c.path in cur_paths
            d = state.change_detail(c.id)
            if d:
                dismissed = d.get("dismissed") or {}
                items = []
                for ix, it in enumerate(d.get("items") or []):
                    if str(ix) in dismissed:          # 사람이 '오탐 삭제'한 항목은 싣지 않는다
                        continue
                    try:
                        items.append(ChangeItem(it["kind"], it["key"], it.get("old"), it.get("new"),
                                                it.get("where", ""), it.get("label")))
                    except (KeyError, TypeError):
                        continue
                if items:
                    # **항상** 변경 id로 — 경로 키는 같은 파일의 앞선 변경 둘(진짜 변경 + 재저장)이
                    # 서로 덮어써 진짜 변경이 "재저장"이 되거나 BOM 행이 복제됐다 (파일럿 모의 2차 1위)
                    details_by_id[c.id] = items
                    # 아침 통에 있던 '개정 사유' 줄이 갱신 통에서 사라졌다 (검토25 브리핑 A-1) — 원본과
                    # 같은 규칙: 이 변경에서 리비전 행이 생겼을 때만 그 사유를 싣는다
                    if c.id in doc_info and any(it.kind == "REVROW_ADDED" for it in items):
                        dd_ = state.load_extract(c.new_sha256) if c.new_sha256 else None
                        rh_ = (dd_ or {}).get("revision_history") or []
                        note_ = _reason_from_items(items) or _latest_rev_note(rh_, doc_info[c.id].get("rev"))
                        if note_:
                            doc_info[c.id]["note"] = note_
                    if not same_path and c.path not in details:
                        details[c.path] = items      # 경로 키는 이 파일의 첫 변경만 (하위 호환)
                for k, v in (d.get("captures") or {}).items():
                    captures[(c.id, k)] = v
                    if not same_path and (c.path, k) not in captures:
                        captures[(c.path, k)] = v
            groups[proj]["changes"].append(c)
            merged_note[proj] = merged_note.get(proj, "") or "x"
            who = state.ack_of(c.id)
            if who:
                acked_by[c.id] = who       # 이미 확인된 건은 링크 대신 '확인됨'
            else:
                ack_tokens[c.id] = state.ack_token(c.id)
        for proj in sorted(merged_note):
            k = sum(1 for c in groups[proj]["changes"] if c.id in earlier_ids)
            auto = bool(cfg["mail"].get("enabled")) and not args.dry_run
            head = (f"오늘 앞선 검사에서 잡힌 변경 {k}건을 합쳐 이 한 통으로 갱신했습니다 — "
                    + ("앞서 보낸 메일과 겹칩니다(갱신본)." if auto
                       else "앞선 초안은 이 파일로 갱신되었습니다 — 이 한 통만 보내면 됩니다.")) if k else ""
            names = sorted({PurePosixPath(c.path).name for c in groups[proj]["changes"]
                            if c.id in earlier_ids and c.path in cur_paths})
            if names:
                head += (f" 오늘 여러 번 바뀐 파일({', '.join(names)})은 앞선 변경과 이번 변경을 "
                         f"각각 근거까지 실었습니다.")
            merged_note[proj] = head.strip()
            # 앞선 검사가 새로 잡은 '검토 필요'도 아직 열려 있으면 같이 싣는다
            have = {(i.code, i.path, i.message) for i in groups[proj]["issues"]}
            for d in state.issues(proj):
                if (d["snapshot_id"] in (snapshot_id, first_id)
                        or _local_date_of(d["detected_at"]).isoformat() != day_iso
                        or (d["code"], d["path"], d["message"]) in have):
                    continue
                groups[proj]["issues"].append(Issue(d["code"], d["path"], d["message"],
                                                    tuple(d["evidence"] or ())))
    if not groups:
        brief_path = _unique_brief(brief_dir / brief_filename(run_at), run_at)
        html0 = build_brief([], run_at, str(root), scan_errors=scan_errors,
                            scanned_count=scanned)
        brief_path.write_text(html0, encoding="utf-8")
        print(f"브리핑 저장: {brief_path}")
        # 변경 0건이어도 **못 읽은 파일이 있으면** 알린다. 지금까지는 이 날 메일이 한 통도
        # 안 나가서, 파일 절반을 못 읽고 지나간 날과 정말 조용한 날이 받는 쪽에서 똑같았다
        # (2026-09-09 브리핑 검토 차단 1). 원칙 5 — 변경 사실은 100% 잡는다
        if scan_errors and not args.dry_run:
            mc0 = {**cfg["mail"], "recipients": _recipients_for(cfg)}
            # '파일 N건'이라 쓰면 폴더·보류 알림까지 파일로 읽힌다 (검토21 브리핑 차단 4) — 종류별로
            n_f = sum(1 for p, _m in scan_errors if not str(p).endswith("/") and not str(p).startswith("("))
            n_d = sum(1 for p, _m in scan_errors if str(p).endswith("/"))
            n_n = len(scan_errors) - n_f - n_d
            parts = ([f"읽지 못한 파일 {n_f}건"] if n_f else []) + \
                    ([f"닿지 못한 폴더 {n_d}개"] if n_d else []) + ([f"알림 {n_n}건"] if n_n else [])
            subj0 = (f"[Drev] {run_at.strftime('%Y-%m-%d')} 변경 0건 — " + " · ".join(parts))
            _deliver(cfg, mc0, subj0, html0, brief_path)
    # 무엇과 비교한 것인지 — PC가 며칠 꺼져 있던 날의 '변경 12건'이 어제 하루 일로
    # 읽히던 것 (2026-09-09 자동 실행 검토 중간 8)
    _since = None
    if snapshot_id is not None and not is_baseline:
        try:
            prev = state.prev_snapshot_id(snapshot_id)
            _since = state.snapshot_local_time(prev) if prev else None
        except Exception:
            _since = None
    for proj in sorted(groups):
        g = groups[proj]
        if rd.reg_paths and not is_baseline:
            # 새로 켠 확장자의 첫 등록은 그 프로젝트의 '기준선 등록' 브리핑으로 따로 남기고
            # (메일 없음), 오늘 브리핑에는 진짜 변경만 싣는다 (검토18 ③-A)
            regs = [c for c in g["changes"] if c.path in rd.reg_paths]
            if regs:
                reg_path = _brief_target(
                    brief_dir / brief_filename(run_at, proj, baseline=True), run_at,
                    merged=False, dry_run=True)
                # 새로 추가한 폴더의 첫 검사가 찾은 검토 필요(기존 불일치)는 그 기준선 브리핑에
                # 싣는다 — 첫 검사(기준선)와 같은 규칙. 오늘 변경 브리핑에 남기면 "변경 0건 /
                # 검토 필요 6건" 메일이 나간다 (2026-09-11 실사용 첫날)
                def _root_of(p):
                    return p.split("/", 1)[0] if "/" in p else p

                def _touches_new_root(i) -> bool:
                    # 대표 경로(i.path)는 정렬상 앞선 파일이라 기존 폴더 쪽일 수 있다 — 근거에 새 폴더
                    # 파일이 하나라도 인용되면 그 폴더의 첫 검사가 드러낸 기존 불일치다 (검토20 A-2)
                    if _root_of(i.path) in rd.reg_roots:
                        return True
                    return any(re.search(r"(?<![\w/])" + re.escape(rr) + "/", str(ev))
                               for ev in (i.evidence or ()) for rr in rd.reg_roots)
                reg_issues = [i for i in g["issues"] if _touches_new_root(i)]
                why = []
                reg_exts = sorted({PurePosixPath(c.path).suffix.lower() for c in regs
                                   if PurePosixPath(c.path).suffix.lower() in rd.reg_exts})
                if reg_exts:
                    why.append(f"새로 켠 확장자({', '.join(reg_exts)})")
                reg_roots = sorted({_root_of(c.path) for c in regs if _root_of(c.path) in rd.reg_roots})
                if reg_roots:
                    why.append(f"새로 추가한 감시 폴더({', '.join(reg_roots)})")
                def _reg_brief(for_mail: bool) -> str:
                    # 첫 검사(기준선)와 같은 재료를 다 싣는다 — 그림 비교를 해 놓고 사진을 안 싣던
                    # 것 (검토20 A-7). 메일 판만 사진 상한
                    return build_brief(
                        regs, run_at, str(root), details=details, issues=reg_issues, project=proj,
                        ack_base=cfg["ack_url"], ack_tokens=ack_tokens, scan_errors=scan_errors,
                        captures=captures, scanned_count=scanned,
                        doc_info=doc_info, baseline=True, acked_by=acked_by,
                        details_by_id=details_by_id, photo_budget=for_mail,
                        baseline_note=f"{' · '.join(why) or '첫 등록'}의 첫 등록입니다")
                reg_path.write_text(_reg_brief(False), encoding="utf-8")
                print(f"[{proj}] 첫 등록 {len(regs)}건"
                      f"{f' / 검토 필요 {len(reg_issues)}건' if reg_issues else ''} → {reg_path}")
                if reg_issues and not args.dry_run and not _QUIET_PROJECT.search(proj or ""):
                    # 기준선에 검토 필요가 있으면 첫 검사와 같이 초안을 만든다 (등록만이면 없음)
                    subj = (f"[Drev] [{proj}] {run_at.strftime('%Y-%m-%d')} 기준선 등록 {len(regs)}건"
                            f" / 검토 필요 {len(reg_issues)}건")
                    _deliver(cfg, {**cfg["mail"], "recipients": (cfg["projects"].get(proj) or {}).get(
                        "recipients") or cfg["mail"].get("recipients", [])},
                             subj, _reg_brief(True), reg_path)
                g["changes"] = [c for c in g["changes"] if c.path not in rd.reg_paths]
                g["issues"] = [i for i in g["issues"] if i not in reg_issues]
                if not g["changes"] and not g["issues"]:
                    continue
        day_path = brief_dir / brief_filename(run_at, proj, baseline=is_baseline)
        # 합산했으면 그 날 파일을 갱신(덮어씀), 아니면(dry-run·기준선) 시각을 붙여 보존.
        # 합산본이 앞선 검사의 근거까지 담으므로 덮어도 잃는 게 없다 (위 details_by_id)
        brief_path = _brief_target(day_path, run_at, merged=proj in merged_note,
                                   dry_run=bool(args.dry_run))
        def _brief(for_mail: bool) -> str:
            return build_brief(g["changes"], run_at, str(root), details=details,
                               issues=g["issues"], project=proj, ack_base=cfg["ack_url"],
                               ack_tokens=ack_tokens, scan_errors=scan_errors,
                               captures=captures, scanned_count=scanned,
                               doc_info=doc_info, baseline=is_baseline,
                               merged_note=merged_note.get(proj), acked_by=acked_by,
                               details_by_id=details_by_id, since=_since,
                               photo_budget=for_mail)
        # 디스크에 남는 브리핑은 **사진을 다 담는다** — 여기가 보존 기간 뒤에도 남는
        # 근거다. 용량 상한은 메일 한 통에만 건다 (2026-09-09 배포 후 검토, 원칙 4)
        html = _brief(for_mail=False)
        brief_path.write_text(html, encoding="utf-8")
        srcs = {proj_of[c.path][1] for c in g["changes"] if c.path in proj_of}
        n_main, n_quiet = (len(g["changes"]), 0) if is_baseline else brief_counts(g["changes"], details, details_by_id)
        print(f"[{proj}] {'기준선 등록' if is_baseline else '변경'} {n_main}건"
              f"{f' (+그 밖의 알림 {n_quiet}건)' if n_quiet else ''} / "
              f"검토 필요 {len(g['issues'])}건 "
              f"(귀속 근거: {', '.join(sorted(srcs)) or '—'}) → {brief_path}")

        if args.dry_run:
            continue
        if _QUIET_PROJECT.search(proj or ""):
            # 임시·공용·아카이브·양식 폴더가 '프로젝트'로 매일 메일 초안을 받았다 (파일럿 모의 ⑥).
            # 브리핑 파일은 남기되 초안·발송은 하지 않는다
            print(f"[{proj}] 보관·공용 성격의 폴더 — 메일 초안은 만들지 않습니다 (브리핑 파일만)")
            continue
        if is_baseline and not g["issues"]:
            continue                       # 기준선 등록만 있는 프로젝트는 메일 초안을 만들지 않는다
        if not is_baseline and not n_main and not g["issues"]:
            continue                       # 이동·복사본·재저장뿐인 날은 보낼 게 없다 (브리핑만 남김)
        # 프로젝트별 수신자는 전체 수신자를 **대체**한다 — 그래서 사장이 P26-040 메일을 못 받았다
        # (검토21 파일럿 중간 13). 모든 통을 받아야 하는 사람은 always_recipients에
        recipients = _recipients_for(cfg, proj)
        mail_cfg = {**cfg["mail"], "recipients": recipients}
        # 제목에 무엇이 바뀌었는지 힌트 — 구매 담당은 BOM인지 Rev인지를 열어 봐야 알았고,
        # "검토 필요 0건"이 매일 붙어 신호가 죽었다 (검토19 브리핑 ⑭)
        hint_parts = []

        def _items_of(c):        # 갱신 통은 변경 id별 상세 — 경로 키로 세면 같은 파일을 두 번 센다
            return (details_by_id or {}).get(c.id) or details.get(c.path, [])
        n_rev = sum(1 for c in g["changes"] for it in _items_of(c)
                    if it.kind == "FIELD_CHANGED" and it.key == "REV")
        # 'BOM행'은 구매로 이어지는 표(BOM·발주서·견적서)의 행만 — 사양서·회의록 표 행까지 세어
        # 구매 담당이 BOM 변경으로 읽었다 (검토21 브리핑 차단 1). 그 밖의 표는 '표 행'
        from watcher.brief import impact_label as _impact
        n_row = sum(1 for c in g["changes"] for it in _items_of(c)
                    if it.kind.startswith("ROW_") and _impact(c.path, cfg) == "발주 영향")
        n_tbl = sum(1 for c in g["changes"] for it in _items_of(c)
                    if it.kind.startswith("ROW_")) - n_row
        if n_rev:
            hint_parts.append(f"Rev {n_rev}")
        if n_row:
            hint_parts.append(f"BOM행 {n_row}")
        if n_tbl:
            hint_parts.append(f"표 행 {n_tbl}")
        hint = f" [{'·'.join(hint_parts)}]" if hint_parts else ""
        subject = (f"[Drev] [{proj}] {run_at.strftime('%Y-%m-%d')} "
                   f"{'기준선 등록' if is_baseline else '변경'} {n_main}건"
                   f"{f' (+그 밖의 알림 {n_quiet}건)' if n_quiet else ''}"
                   f"{f' / 검토 필요 {len(g['issues'])}건' if g['issues'] else ''}{hint}"
                   f"{' (갱신)' if merged_note.get(proj) else ''}")
        _deliver(cfg, mail_cfg, subject, _brief(for_mail=True), brief_path)
    _note_mail_trouble(state)
    if args.dry_run:
        # dry-run은 '메일만 생략'이지 미리보기가 아니다 — 검사 기록이 남아 같은 변경은 다시 보고되지 않는다.
        # 기록을 되돌리는 안은 시험 29곳이 이 뜻에 기대고 있어 접었다 (2026-09-06 사용성 4차 ④-2)
        print("(dry-run: 메일 초안·발송만 생략 — 검사 기록은 남으므로 같은 변경은 다음 검사에서 다시 보고되지 않습니다)")


# 한 검사 안의 발송 상태 — 서버가 죽은 날 프로젝트 30개가 각각 10초씩 기다리며 경고 30줄을
# 내던 것 (검토19 운영 ③). 첫 실패 뒤에는 시도하지 않고 합산해 한 줄로, 그리고 화면 배너로
MAIL_TROUBLE_KEY = "mail_trouble"
# 프로젝트가 아니라 보관·공용 성격의 폴더 이름 — 메일 초안 대상에서 뺀다
_QUIET_PROJECT = re.compile(r"^(임시|temp|tmp|공용|공통|양식|template|아카이브|archive|백업|backup|"
                            r"old|구버전|보관|참고자료|참고|scratch|미분류)(?![A-Za-z0-9가-힣])"
                            r"|(아카이브|archive|백업|backup)$", re.IGNORECASE)
_MAIL_STATE = {"down": "", "skipped": 0, "sent": 0}


_REASON_COL = re.compile(r"(?i)^(DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)$")
_REVCOL = re.compile(r"(?i)^(REV(ISION)?|개정|판|버전|VER)")


def _reason_from_items(items) -> str | None:
    """이번 변경에서 추가된 리비전 행(REVROW_ADDED)의 사유 — 여럿이면 마지막. REV 열이 없는 개정이력
    (NO·DATE·내용)에서는 최신 행을 REV로 못 찾으니 '이번에 생긴 행'이 곧 새 사유다 (2회차 A2)."""
    added = [it for it in (items or []) if getattr(it, "kind", None) == "REVROW_ADDED"]
    if len(added) > 1:
        # 새 행 하나에 옛 행들까지 '추가'로 잡힌 경우(키 열이 흔들림) — 가장 옛 사유가 실리지 않게
        # 일자·Rev가 가장 최신인 행 하나만 본다 (3회차 A4 → 4회차: 행 번호 최소는 아래가 최신인 양식에서 거꾸로)
        def _when(it):
            txt = str(getattr(it, "new", "") or "")
            dm = re.search(r"(?:DATE|일자|날짜)'?\s*[:=]\s*'?(\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{8})", txt, re.I)
            d = re.sub(r"\D", "", dm.group(1)) if dm else ""
            nm = re.search(r"(?:NO|번호|순번|연번)'?\s*[:=]\s*'?(\d{1,5})", txt, re.I)
            no = int(nm.group(1)) if nm else -1
            rm = re.search(r"(?:REV(?:ISION)?|개정|판)'?\s*[:=]\s*'?([A-Za-z0-9.]{1,6})", txt, re.I)
            rv = rm.group(1).upper() if rm else ""
            wm = re.search(r"행(\d+)", str(getattr(it, "where", "") or ""))
            top = -int(wm.group(1)) if wm else 0          # 전부 같으면 위쪽 행(흔한 '위가 최신' 양식)
            return (d, no, (2, int(rv)) if rv.isdigit() else (1, len(rv), rv), top)
        added = [max(added, key=_when)]      # 일자 > 순번 > Rev > 위쪽 행 (5회차 A3: 같은 날 두 행·DATE 없는 양식)
    for it in reversed(added):
        txt = str(getattr(it, "new", "") or "")
        m = (re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*'([^']*)'", txt, re.I)
             or re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*([^,}]+)", txt, re.I))
        if m and m.group(1).strip():
            return m.group(1).strip()
    return None


def _latest_rev_note(rev_rows, cur_rev: str | None) -> str | None:
    """리비전 행들에서 **최신 판**(표제란/개정이력 REV와 같은 값, 없으면 마지막 행)의 사유.
    엑셀 개정이력이 위가 최신인 양식에서 마지막 행(가장 옛 'FIRST ISSUE')이 개정 사유로 실렸다
    (검토26 1회차 4). rev_rows: Row 객체 또는 {"values": {...}} dict."""
    def _vals(r):
        if isinstance(r, dict):                       # 캐시(dict) — dict.values는 메서드다
            return r.get("values") or {}
        return getattr(r, "values", None) or {}
    rows = list(rev_rows or [])
    if not rows:
        return None
    pick = None
    if cur_rev:
        for r in rows:
            v = _vals(r)
            rv = next((str(x).strip() for k, x in v.items() if x not in (None, "") and _REVCOL.match(str(k).strip())
                       and not re.search(r"(일자|날짜|DATE|내용|사유|비고|DESC)", str(k), re.I)), None)
            if rv and rv.upper() == str(cur_rev).strip().upper():
                pick = r
        if pick is None:
            for r in rows:
                if str(getattr(r, "key", "") or "").strip().upper() == str(cur_rev).strip().upper():
                    pick = r
    if pick is None:
        pick = rows[-1]
    v = _vals(pick)
    return next((str(v[k]) for k in v if _REASON_COL.match(str(k)) and v[k]), None)


def _recipients_for(cfg: dict, project: str | None = None) -> list[str]:
    """한 통의 수신자 — 프로젝트별 수신자(있으면 전체 수신자를 대체) + always_recipients.
    세 곳(일일·주간·0건/오류 통)이 제각각 계산해 주간 요약·오류 통이 사장(always)을 뺐다 (검토25 브리핑 C-1)."""
    mail = cfg.get("mail") or {}
    proj_cfg = (cfg.get("projects") or {}).get(project) or {} if project else {}
    out = list(proj_cfg.get("recipients") or mail.get("recipients") or [])
    if not out and project is None:
        # 프로젝트별 수신자만 있는 설정 — 주간 요약·오류 통은 그들 전부에게 (검토26 1회차 5)
        for pc in (cfg.get("projects") or {}).values():
            for a in (pc or {}).get("recipients") or []:
                if a and a not in out:
                    out.append(a)
    for a in mail.get("always_recipients") or []:
        if a and a not in out:
            out.append(a)
    return out


def _deliver(cfg: dict, mail_cfg: dict, subject: str, html: str, brief_path: Path) -> None:
    """메일 초안(.eml) 저장 + 자동 발송. 둘 다 실패해도 검사는 성공으로 둔다."""
    # 기본: 보내기만 하면 되는 메일 초안(.eml) 생성 — 전송은 사람이 한다 (원칙 1)
    if cfg["mail"].get("draft", True):
        from watcher.mail import write_eml
        try:
            eml = write_eml(mail_cfg, subject, html, brief_path.with_suffix(".eml"))
            if mail_cfg.get("recipients"):
                print(f"  메일 초안 저장: {eml} (더블클릭 → [보내기]만 누르면 됩니다)")
            else:      # 받는 사람이 비어 '[보내기]만'이 거짓이었다 (검토32 A 5)
                print(f"  메일 초안 저장: {eml} (받는 사람을 채운 뒤 보내세요 — 설정 › 메일)")
        except Exception as e:
            print(f"  메일 초안 생성 실패(브리핑은 정상 저장됨): {e}", file=sys.stderr)
    if _MAIL_STATE["down"]:
        _MAIL_STATE["skipped"] += 1        # 같은 서버가 방금 실패했다 — 다시 기다리지 않는다
        return
    try:
        if send_brief(mail_cfg, subject, html):
            print(f"  메일 자동 발송 완료: {', '.join(mail_cfg.get('recipients') or [])}")
            _MAIL_STATE["sent"] += 1
    except Exception as e:
        # 발송 실패는 검사 실패가 아니다 — 여기서 예외를 올리면 그날 스냅샷이
        # 통째로 롤백돼 SMTP가 죽은 날은 이력이 하나도 안 쌓인다 (2026-09-02
        # 재검토 실측: 설정 오류면 기준선조차 영원히 안 생김). 브리핑·.eml 초안은
        # 이미 저장됐으니 경고만 남긴다
        _MAIL_STATE["down"] = str(e)
        print(f"  경고: 메일 자동 발송 실패 — {e}. 브리핑 파일과 메일 초안(.eml)은 "
              f"저장됐으니 직접 보내주세요. (이번 검사의 나머지 통은 보내지 않습니다)",
              file=sys.stderr)


def _note_mail_trouble(state: "State") -> None:
    """검사 끝에 발송 상태를 DB에 남긴다 — 다음 날 아침 화면 배너가 읽는다."""
    import json as _json
    if _MAIL_STATE["down"]:
        n = 1 + _MAIL_STATE["skipped"]
        state.set_meta(MAIL_TROUBLE_KEY, _json.dumps({
            "at": datetime.now(timezone.utc).isoformat(), "why": _MAIL_STATE["down"][:300],
            "count": n}, ensure_ascii=False))
        if _MAIL_STATE["skipped"]:
            print(f"  메일 자동 발송: 첫 실패 뒤 {_MAIL_STATE['skipped']}통은 시도하지 않았습니다 "
                  f"— .eml 초안은 모두 저장됨", file=sys.stderr)
    elif _MAIL_STATE["sent"]:
        state.set_meta(MAIL_TROUBLE_KEY, None)


def run_at_local_date() -> str:
    return run_at_local_date_obj().isoformat()


def run_at_local_date_obj():
    return datetime.now().astimezone().date()


def _local_date_of(iso: str):
    """저장된 UTC ISO → 이 PC 지역 날짜 (주간 집계용)."""
    if not ("+" in iso[10:] or iso.endswith("Z")):
        iso = iso + "+00:00"
    return datetime.fromisoformat(iso).astimezone().date()


def _weekly_issue_counts(state: State, start, end) -> tuple[Counter, Counter]:
    """지난주 '검토 필요' — (신규, 열림). 신규는 그 주에 검출된 것 중 **자동 해소된 옛 이슈의 재탄생 짝**
    (같은 issue_key가 같은 날 '자동 해소'로 닫힘)을 뺀다 — 변경 0인 프로젝트에 '검토 필요 1'이 찍혔다
    (검토32 A 2, 09-14 사고의 흔적). 열림은 지금 열려 있는 누적."""
    new: Counter = Counter()
    open_: Counter = Counter()
    rows = state.conn.execute(
        "SELECT project, detected_at, code, path, message, resolved_at, resolved_by FROM issues").fetchall()
    def _k(code, path, msg):
        # 옛 판(≤0.57.2)의 문구 '… 외 3장'은 키에 남는다 — 09-14 재탄생 짝이 그 꼴이라 장수 꼬리를 걷고 견준다
        return state.issue_key(code, path, re.sub(r"\s*외\s*\d+\s*장", "", str(msg or "")))
    auto_closed = set()
    for proj, det, code, path, msg, rat, rby in rows:
        if rat and str(rby or "").startswith("자동 해소"):
            auto_closed.add((_k(code, path, msg), _local_date_of(rat)))
    for proj, det, code, path, msg, rat, rby in rows:
        p = proj or "미분류"
        if rat is None:
            open_[p] += 1
        d = _local_date_of(det)
        if start <= d <= end and (_k(code, path, msg), d) not in auto_closed:
            new[p] += 1
    return new, open_


def _scan_days_line(state: State, start, end) -> str:
    """지난주 검사가 돈 날 수 — 09-16 PC 꺼짐으로 검사가 없던 날이 주간 통 어디에도 없었다 (검토32 A 3)."""
    days = {_local_date_of(r) for (r,) in state.conn.execute("SELECT run_at FROM snapshots") if r}
    wk = [start + timedelta(days=i) for i in range((end - start).days + 1)]
    ran = [d for d in wk if d in days]
    missing = [d for d in wk if d not in days]
    line = f"검사 {len(ran)}/{len(wk)}일"
    if missing:
        line += " (없는 날: " + ", ".join(d.strftime("%m-%d") for d in missing) + ")"
    return line


def write_weekly_summary(state: State, cfg: dict, brief_dir: Path,
                         run_at: datetime) -> Path | None:
    """이번 주 첫 검사 때 지난주(월~일) 프로젝트별 요약 브리핑 생성 (2026-08-26).
    파일명은 이번 주 월요일 날짜로 고정 — 월요일에 PC가 꺼져 있었어도
    화요일 검사가 대신 만든다 (요일 조건이었다가 공휴일에 영구 생략되던 문제 수정).
    이미 이번 주 것이 있으면 생략. 돌려주는 값: 만든 파일 경로 또는 None."""
    if not cfg.get("weekly_summary", True):
        return None
    monday = (run_at - timedelta(days=run_at.weekday())).date()
    out = brief_dir / f"brief_weekly_{monday.strftime('%Y%m%d')}.html"
    if out.exists():
        return None
    start = monday - timedelta(days=7)
    end = monday - timedelta(days=1)
    # 설치 전 주를 "지난주 변경이 없습니다 — 감시는 정상 동작했습니다"라 보고하던 것
    # (2026-09-05 재검토) — 첫 검사가 그 주 뒤면 만들지 않는다
    first_at = state.conn.execute("SELECT MIN(run_at) FROM snapshots").fetchone()[0]
    if first_at and _local_date_of(first_at) > end:
        return None

    by_change: dict[int, dict] = {}
    for r in state.history():  # (변경×확인) 조인 → 변경 단위로 접기
        d = by_change.setdefault(r["change_id"], dict(r, acked=False))
        if r["ack_by"]:
            d["acked"] = True
    first = state.first_snapshot_by_root()   # 첫 등록은 변경이 아니다 (화면과 같은 규칙)
    ext_base = state.ext_baseline()
    week = [d for d in by_change.values()
            if start <= _local_date_of(d["detected_at"]) <= end
            and not State.is_first_registration(d["kind"], d["path"], d.get("snapshot_id"),
                                                first, ext_base)]
    # 일일 브리핑과 같은 규칙으로 센다 — 폴더 이동(삭제+추가)은 한 건, 재저장·복사본·일자만 갱신은
    # '그 밖의 알림'이라 수정·미확인에 넣지 않는다. 그대로 세니 사장이 보는 표가 "P26-040 수정 120 /
    # 미확인 121"(실제 변경 1건 + 재출력 119장)이 됐다 (검토21 브리핑 차단 2·파일럿 차단 2)
    from watcher.brief import _MOVE_MARK, is_quiet as _is_quiet
    notes = state.side_notes()
    removed_by_path = {d["path"]: d for d in week if d["kind"] == "removed"}
    hide: set = set()
    for d in week:
        n = notes.get(d["change_id"], "") or ""
        if d["kind"] == "added" and _MOVE_MARK in n:
            prev = n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
            x = removed_by_path.get(prev)
            if x is not None:
                hide.add(x["change_id"])
        if d["kind"] == "removed" and "옮겨지며 내용도 바뀜" in n:
            hide.add(d["change_id"])
    week = [d for d in week if d["change_id"] not in hide]
    quiet_ids = {d["change_id"] for d in week
                 if (d["kind"] == "added" and _MOVE_MARK in (notes.get(d["change_id"]) or ""))
                 or _is_quiet(notes.get(d["change_id"], "") or "")}
    iss_week, iss_open = _weekly_issue_counts(state, start, end)

    projects = sorted({d["project"] or "미분류" for d in week} | set(iss_week) | set(iss_open))
    # 임시·공용·아카이브 폴더는 일일 메일도 만들지 않는다 — 주간 표에서도 뺀다
    projects = [p for p in projects if not _QUIET_PROJECT.search(p or "")]
    trs, tot = [], Counter()
    for p in projects:
        pr = [d for d in week if (d["project"] or "미분류") == p]
        main = [d for d in pr if d["change_id"] not in quiet_ids]
        row = Counter(d["kind"] for d in main)
        n_quiet = len(pr) - len(main)
        unack = sum(1 for d in main if not d["acked"])
        iss = iss_week.get(p, 0)
        iss_o = iss_open.get(p, 0)
        tot.update(row)
        tot["quiet"] += n_quiet
        tot["unack"] += unack
        tot["iss"] += iss
        tot["iss_open"] += iss_o
        trs.append(f"<tr><td style='{_W_TD}'>{html_escape(p)}</td>"
                   f"<td style='{_W_TD}'>{row.get('added', 0)}</td>"
                   f"<td style='{_W_TD}'>{row.get('modified', 0)}</td>"
                   f"<td style='{_W_TD}'>{row.get('removed', 0)}</td>"
                   f"<td style='{_W_TD};color:#57606a'>{n_quiet}</td>"
                   f"<td style='{_W_TD};color:#cf222e'>{unack}</td>"
                   f"<td style='{_W_TD};color:#9a6700'>{iss} / {iss_o}</td></tr>")
    body = (f"<table style='border-collapse:collapse;width:100%'>"
            f"<tr><th style='{_W_TH}'>프로젝트</th><th style='{_W_TH}'>추가</th>"
            f"<th style='{_W_TH}'>수정</th><th style='{_W_TH}'>삭제</th>"
            f"<th style='{_W_TH}'>그 밖의 알림</th>"
            f"<th style='{_W_TH}'>미확인</th><th style='{_W_TH}'>검토 필요<br><span style='font-weight:400'>신규 / 열림</span></th></tr>"
            + "".join(trs)
            + f"<tr><td style='{_W_TD};font-weight:700'>합계</td>"
              f"<td style='{_W_TD}'>{tot.get('added', 0)}</td>"
              f"<td style='{_W_TD}'>{tot.get('modified', 0)}</td>"
              f"<td style='{_W_TD}'>{tot.get('removed', 0)}</td>"
              f"<td style='{_W_TD};color:#57606a'>{tot.get('quiet', 0)}</td>"
              f"<td style='{_W_TD};color:#cf222e'>{tot.get('unack', 0)}</td>"
              f"<td style='{_W_TD};color:#9a6700'>{tot.get('iss', 0)} / {tot.get('iss_open', 0)}</td></tr>"
            "</table>"
            "<p style='color:#57606a;font-size:12.5px'>'그 밖의 알림'은 폴더 이동·이름 변경, 다시 저장(내용 동일), "
            "복사본, 표제란 일자만 갱신된 재출력 — 변경으로 세지 않고 미확인에도 넣지 않습니다. "
            "'검토 필요'의 신규는 지난주에 새로 검출된 것, 열림은 지금까지 처리되지 않고 남은 누적입니다.</p>") if projects else \
        "<p style='color:#1a7f37'>지난주 변경이 없습니다 — 감시는 정상 동작했습니다.</p>"
    title = f"주간 요약 {start.strftime('%m/%d')}~{end.strftime('%m/%d')}"
    doc = (f"<!DOCTYPE html><html lang='ko'><head><meta charset='utf-8'>"
           f"<title>{title}</title></head>"
           f"<body style=\"font-family:'Malgun Gothic',Segoe UI,sans-serif;"
           f"max-width:720px;margin:0 auto;padding:24px;color:#1f2328\">"
           f"<h2>산출물 감시 {title}</h2>"
           f"<p style='color:#57606a'>{_scan_days_line(state, start, end)} · 미확인 변경은 감시 PC 화면에서, 상세는 해당 주의 "
           f"일일 브리핑에서 확인하세요.</p>{body}"
           f"<p style='color:#8c959f;font-size:12px;margin-top:20px'>Drev"
           f" — 매주 첫 검사 때 지난주(월~일)를 정리해 자동 생성됩니다.</p></body></html>")
    out.write_text(doc, encoding="utf-8")
    mc = {**(cfg.get("mail") or {}), "recipients": _recipients_for(cfg)}
    if mc.get("draft", True):
        try:
            from watcher.mail import write_eml
            write_eml(mc, f"[Drev] {title}", doc, out.with_suffix(".eml"))
        except Exception as e:
            print(f"경고: 주간 요약 메일 초안 생성 실패(요약 HTML은 정상): {e}",
                  file=sys.stderr)
    # 자동 발송을 켠 집에서도 주간 요약만 초안으로 남아 아무도 못 봤다 — 변경이 없는 주에
    # 받는 쪽이 '감시가 살아 있다'를 확인할 수 있는 유일한 통이다 (2026-09-09 브리핑 검토 1)
    if mc.get("enabled"):
        try:
            if send_brief(mc, f"[Drev] {title}", doc):
                print(f"주간 요약 메일 발송: {', '.join(mc.get('recipients') or [])}")
        except Exception as e:
            print(f"경고: 주간 요약 메일 발송 실패(요약 HTML·초안은 정상): {e}",
                  file=sys.stderr)
    return out


_W_TH = ("border:1px solid #d0d7de;padding:7px 12px;background:#f6f8fa;"
         "text-align:left;font-size:13px")
_W_TD = "border:1px solid #d0d7de;padding:7px 12px;font-size:13.5px"


@dataclass
class RunData:
    """검사 파이프라인 한 회분의 공유 상태 — 단계 함수들이 이 묶음만 주고받는다.
    (파라미터 11개짜리 시그니처와 args 밀수를 없애기 위한 것, 2026-08-26 리팩토링)"""
    cfg: dict
    roots: list
    labels: list
    root_display: str
    prev_files: dict = dc_field(default_factory=dict)
    records: list = dc_field(default_factory=list)
    abs_of: dict = dc_field(default_factory=dict)
    scan_errors: list = dc_field(default_factory=list)
    old_versions: set = dc_field(default_factory=set)   # 짝짓기로 '이전 판'이 된 경로
    folder_votes: dict = dc_field(default_factory=dict)  # 폴더 → {프로젝트: 표제란 수} (검토22 D1)
    ocr_boxes: dict = dc_field(default_factory=dict)    # 경로 → {OCR 글자: (pno, x0, y0, x1, y1)} 사진 자리
    snapshot_id: int | None = None
    changes: list = dc_field(default_factory=list)
    docs: dict = dc_field(default_factory=dict)
    extract_failures: dict = dc_field(default_factory=dict)
    details: dict = dc_field(default_factory=dict)
    prev_abs: dict = dc_field(default_factory=dict)   # 판 짝짓기 시 이전 판 파일 경로
    issues: list = dc_field(default_factory=list)
    captures: dict = dc_field(default_factory=dict)
    baseline_visual: set = dc_field(default_factory=set)  # 기준선에서 그림 비교한 파일
    moved: dict = dc_field(default_factory=dict)   # 새 경로 → (이전 경로, 이전 sha, 내용 동일?)
    checked_projects: set = dc_field(default_factory=set)  # 이번 교차 검사가 본 프로젝트
    carry_paths: list = dc_field(default_factory=list)   # 이번 검사에서 이전 상태를 이월한 경로
    is_baseline: bool = False                            # 첫 검사(기준선)였는가
    reg_paths: set = dc_field(default_factory=set)       # 새로 켠 확장자·새로 추가한 폴더의 첫 등록 경로
    reg_exts: set = dc_field(default_factory=set)        # 이번 검사에서 새로 켠 확장자
    reg_roots: set = dc_field(default_factory=set)       # 이번 검사가 첫 검사인 감시 폴더(라벨)
    force_full: bool = False                             # 주 1회 전체 재해싱 (크기·시각 단축 없이)
    missing_labels: list = dc_field(default_factory=list)  # 이번 검사에 접근 못 한 감시 폴더 라벨


def _scan_roots(rd: RunData, args) -> list:
    """루트별 스캔 → rd.records/abs_of/scan_errors 채움.
    돌려주는 값: 감시 제외로 조용히 이월할 이전 스냅샷 경로들."""
    # 진행률 분모: 직전 스냅샷 파일 수(재검사) — 첫 검사는 미상이라 개수만 표시
    total_est = len(rd.prev_files)
    for r_path, label in zip(rd.roots, rd.labels):
        errs: list[tuple[str, str]] = []
        excludes = _excludes_for(label, rd.labels, rd.cfg["exclude"])
        prev_root = None
        if not (getattr(args, "full", False) or rd.force_full):
            # 크기·수정시각이 같으면 재해싱 생략 (라벨 접두를 벗겨 폴더 몫만)
            pfx = label + "/"
            prev_root = {k[len(pfx):]: v for k, v in rd.prev_files.items()
                         if k.startswith(pfx)}
        _seen = [0]

        def _tick(n: int, _label=label, _base=len(rd.records)) -> None:
            _seen[0] = n
            _set_progress("1/3 파일 확인", _base + n, total_est)
            if n % 500 == 0:
                print(f"  파일 확인 중({_label}): {n}개…", flush=True)

        def _act(text: str, _base=len(rd.records)) -> None:
            # 폴더를 훑는 동안에도 화면과 [검사 중지]가 살아 있게 (2026-09-07 회사 PC:
            # "1/3 파일 확인 12개"에서 한 시간 넘게 멈춘 것처럼 보임)
            _set_progress("1/3 파일 확인", _base + _seen[0], total_est, current=text,
                          keep_since=text.startswith("폴더 "))

        for rec in scan(r_path, rd.cfg["extensions"], errors=errs,
                        excludes=excludes, prev=prev_root, progress=_tick,
                        activity=_act):
            key = f"{label}/{rec.path}"
            rd.records.append(type(rec)(key, rec.sha256, rec.size, rec.mtime))
            rd.abs_of[key] = r_path / PurePosixPath(rec.path)
        rd.scan_errors += [(f"{label}/{p}", e) for p, e in errs]
        # 폴더 단위 오류(권한 없음·순단): 그 아래 이전 기록을 통째로 이월 — 삭제 오보 방지
        # (2026-09-04 검토 core H3). 파일 단위 오류(잠김)는 원래대로 경로만 이월
        for p, _e in errs:
            if p.endswith("/"):
                pfx = f"{label}/{p}" if p != "/" else f"{label}/"
                rd.carry_paths += [k for k in rd.prev_files if k.startswith(pfx)]

    # 감시 제외로 새로 빠진 기존 파일은 '삭제'로 보고하지 않고 조용히 이월한다 —
    # 제외는 "더 이상 안 본다"이지 파일이 사라진 게 아니다 (2026-08-25 리뷰)
    current_paths = {r.path for r in rd.records}
    excluded_carry = []
    for r_path, label in zip(rd.roots, rd.labels):
        excludes = _excludes_for(label, rd.labels, rd.cfg["exclude"])
        if not excludes:
            continue
        pfx = label + "/"
        excluded_carry += [
            k for k in rd.prev_files
            if k.startswith(pfx) and k not in current_paths
            and is_excluded(k[len(pfx):], excludes)]
    return excluded_carry


def _visual_sides(state: State, rd: "RunData", path: str, old_sha, new_sha):
    """덮어쓰기 비교의 전/후 그림 공급원. 전: 검사 때 기록한 그림. 후: PDF·DXF는
    파일(선명한 확대 사진), DWG는 기록(파일을 직접 못 그린다)."""
    old_pages = state.load_renders(old_sha)
    if PurePosixPath(path).suffix.lower() == ".dwg":
        return old_pages, state.load_renders(new_sha)
    return old_pages, rd.abs_of.get(path)


def _changed_texts(old_doc, new_doc) -> set:
    """새 판에만 있는 글줄·표제란 값·리비전 설명 — 그 자리의 픽셀 차이는 '그림 변경'이
    아니라 글자 변경이다 (2026-09-03 검토: 표제란 글자가 그림 변경 3곳으로 부풀고
    'Rev만 갱신' 판정이 DXF에서 절대 안 나오던 원인)."""
    if old_doc is None or new_doc is None:
        return set()

    from watcher.extract.dxf import _LABEL_ALIASES

    def texts(d) -> set:
        s = {" ".join(ln.text.split()) for ln in d.raw_texts}
        s |= {" ".join(str(f.value).split()) for f in d.fields.values()}
        # 표제란 한 칸이 'REV: B' 한 덩이인 도면 — 값 'B'만으로는 그 엔티티(PDF 줄)를 못
        # 찾아 Rev 올림이 '그림 변경'으로 잡히고 'Rev만 갱신' 경고가 사라졌다. 09-03·09-04·
        # 09-06·09-10 네 번째 재발 (검토19 감지 ③). 라벨+값 꼴도 마스크 후보로 넣는다
        for f in d.fields.values():
            v = " ".join(str(f.value).split())
            if not v:
                continue
            for alias, canon in _LABEL_ALIASES.items():
                if canon == f.name:
                    s.add(f"{alias}: {v}")
                    s.add(f"{alias}:{v}")
                    s.add(f"{alias} {v}")
                    s.add(f"{alias}. {v}")
        for r in d.revision_history:
            for v in r.values.values():
                v = " ".join(str(v).split())
                if len(v) >= 4:
                    s.add(v)
        return {x for x in s if x}
    # 양쪽에만 있는 글줄 전부 — 지워진 글줄(옛 판에만 있음)의 자리도 가려야 그 자리가 '그림 변경'이
    # 되지 않는다 (검토21 감지 중간 9). 마스크는 capture가 새 판·옛 판 양쪽에서 찾는다
    return texts(new_doc) ^ texts(old_doc)


_PAGE_OF_WHERE = re.compile(r"(\d+)페이지")


def _safe_diff(old_doc, new_doc, path: str = "") -> list:
    """diff_documents — 문서 하나의 예외가 그날 검사 전체를 롤백시키지 않게 (리뷰13 치명-1: 뒤집힌 스캔 한 장에
    브리핑 0통). 실패는 그 파일의 항목으로 남기고 다음 파일로 간다 (원칙 4·5: '못 봄'을 숨기지 않는다)."""
    try:
        return diff_documents(old_doc, new_doc)
    except ScanCancelled:
        raise
    except Exception as e:
        print(f"  경고: 내용 비교 실패 {path}: {clean_text(str(e))[:200]}", file=sys.stderr)
        return [ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                           f"수행 못 함: 비교 중 오류 — {clean_text(str(e))[:160]} (변경 사실과 그림 비교만 봅니다)",
                           "비교 단계")]


def _ocr_boxes_of(doc) -> dict:
    """새 판의 OCR 글줄·필드 → {글자: (pno, x0, y0, x1, y1)} — 그림 비교 마스크와 변경 자리 사진용."""
    out: dict = {}
    if doc is None:
        return out
    for obj, text in ([(t, t.text) for t in doc.raw_texts] + [(f, str(f.value)) for f in doc.fields.values()]):
        box = getattr(obj, "box", None)
        where = str(getattr(obj, "where", "") or "")
        if not box or "OCR" not in where:
            continue
        m = _PAGE_OF_WHERE.search(where)
        if m:
            out.setdefault(" ".join(text.split()), (int(m.group(1)), *box))
    return out


def _changed_boxes(old_doc, new_doc) -> list:
    """새 판에만 있는 OCR 글줄·필드의 자리 — 그 자리의 픽셀 차이는 글자 변경이지 그림 변경이 아니다."""
    if old_doc is None or new_doc is None:
        return []
    from watcher.ocr import normalize
    old_norm = {normalize(t.text) for t in old_doc.raw_texts} | {normalize(str(f.value)) for f in old_doc.fields.values()}
    return [box for text, box in _ocr_boxes_of(new_doc).items() if normalize(text) not in old_norm]


def _pair_moves(rd: "RunData") -> None:
    """삭제+추가 쌍을 이동·이름 변경으로 묶는다 — 폴더 이름 하나 바꾸면 그 안의 진짜
    변경(성적서 NG 등)이 '추가'로 세탁되던 것 (2026-09-03 검토).
    ① 내용(sha)이 같으면 이름·위치만 바뀐 것 ② 파일명이 같고 폴더만 다르면 이동+수정."""
    removed = [c for c in rd.changes if c.kind == "removed"]
    added = [c for c in rd.changes if c.kind == "added"]
    if not removed or not added:
        return
    by_sha: dict = {}
    by_name: dict = {}
    for c in removed:
        by_sha.setdefault(c.old_sha256, []).append(c)
        by_name.setdefault(PurePosixPath(c.path).name, []).append(c)
    used: set = set()
    present_dirs = {PurePosixPath(r.path).parent for r in (rd.records or ())}
    root_of = {lb: Path(r) for r, lb in zip(rd.roots or (), rd.labels or ())}

    def _dir_gone(key_dir: str) -> bool:
        """옛 폴더가 디스크에서 사라졌나 — 빈 채 남아 있으면 이름 변경이 아니다."""
        lb, _, rel = key_dir.partition("/")
        r = root_of.get(lb)
        if r is None:
            return PurePosixPath(key_dir) not in present_dirs
        try:
            return not (r / rel if rel else r).is_dir()
        except OSError:
            return PurePosixPath(key_dir) not in present_dirs
    # ⓞ 폴더 이름 변경·이동 속의 같은 파일을 **상대 경로(하위 폴더 꼬리 + 파일명)** 로 먼저 맺는다 —
    # 내용(sha)으로 먼저 맺으면, 폴더 이름을 바꾸면서 안의 E-101을 고친 날 새 E-101(Rev B)은
    # 짝이 없어 "비교 대상 없음"이 되고 구 E-101은 임시 폴더의 동일 사본으로 '이동'됐다고
    # 말했다 — 도면 변경이 유실됐다 (검토21 파일럿 차단 1). 이름이 유일하고 옛 폴더가 사라졸
    # 때만(이름 변경·이동의 증거) 맺고, 내용이 같으면 이동, 다르면 이동+수정이다
    for a in added:
        name = PurePosixPath(a.path).name
        cands = [r for r in by_name.get(name, []) if r.path not in used and r.path != a.path]
        if len(cands) != 1:
            continue
        r = cands[0]
        od, nd = PurePosixPath(r.path).parent, PurePosixPath(a.path).parent
        if od == nd:
            continue
        op_, np_ = od.parts, nd.parts
        k = 0
        while k < min(len(op_), len(np_)) and op_[-1 - k] == np_[-1 - k]:
            k += 1
        if k < 1 or not _dir_gone(str(od)):
            continue
        used.add(r.path)
        same = bool(a.new_sha256) and r.old_sha256 == a.new_sha256
        rd.moved[a.path] = (r.path, r.old_sha256, same)
        if same:
            rd.details.setdefault(a.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"이름·위치만 바뀜 — 이전: {r.path} (내용 동일)", "파일 확인"))
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨짐 — 파일이 없어진 것이 아닙니다", "파일 확인"))
        else:
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨지며 내용도 바뀜 — 비교는 새 경로 쪽에", "파일 확인"))
    # 내용(sha) 짝을 먼저 전부 맺는다 — 같은 이름 파일 둘이 동시에 옮겨질 때 이름 후보가
    # 2개라 하나를 놓치던 것 (2026-09-03 재검토)
    for a in added:
        if a.path in rd.moved:
            continue
        cands = [r for r in by_sha.get(a.new_sha256, []) if r.path not in used]
        if cands:
            r = cands[0]
            used.add(r.path)
            rd.moved[a.path] = (r.path, r.old_sha256, True)
            rd.details.setdefault(a.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"이름·위치만 바뀜 — 이전: {r.path} (내용 동일)", "파일 확인"))
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨짐 — 파일이 없어진 것이 아닙니다", "파일 확인"))
    for a in added:
        if a.path in rd.moved:
            continue
        cands = [r for r in by_name.get(PurePosixPath(a.path).name, []) if r.path not in used]
        # BOM.xlsx·표지.pdf·전장도.dxf 같은 범용 이름은 프로젝트마다 있다 — 다른 폴더의
        # 동명 파일을 "옮겨지며 내용도 바뀜"으로 짝지어 남의 프로젝트 메일에 거짓 근거를
        # 실었다 (검토19 감지 ④). 숫자가 든 이름(E-101, P26-014_BOM)은 트리 어디서든
        # 짝짓되, 숫자 없는 이름은 같은 폴더 안에서만 — 단 옛 폴더가 통째로 사라졌으면
        # (폴더 이름 변경·이동, 디스크에서 확인) 그 안의 범용 이름도 짝이다.
        # 후보를 먼저 좁힌 뒤 유일성을 본다 (검토19 2차 감지 N8)
        stem = PurePosixPath(a.path).stem
        if not any(ch.isdigit() for ch in stem):
            new_dir = PurePosixPath(a.path).parent

            def _renamed_sibling(old_dir: PurePosixPath) -> bool:
                # 옛 폴더가 사라졌더라도 **형제 폴더의 이름 변경이나 같은 꼬리(프로젝트/하위)를
                # 가진 이동**일 때만 — 조건이 "사라짐"뿐이면 남의 프로젝트 BOM과 교차로
                # 짝지어 그 행 변경이 내 메일 근거로 나갔다 (검토19c ②)
                if not _dir_gone(str(old_dir)):
                    return False
                if old_dir.parent == new_dir.parent:
                    return True
                op, npn = old_dir.parts, new_dir.parts
                k = 0
                while k < min(len(op), len(npn)) and op[-1 - k] == npn[-1 - k]:
                    k += 1
                return k >= 2
            cands = [r for r in cands
                     if PurePosixPath(r.path).parent == new_dir
                     or _renamed_sibling(PurePosixPath(r.path).parent)]
        if len(cands) == 1:
            r = cands[0]
            used.add(r.path)
            rd.moved[a.path] = (r.path, r.old_sha256, False)
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨지며 내용도 바뀜 — 비교는 새 경로 쪽에", "파일 확인"))


def _is_date_item(i) -> bool:
    """표제란 일자·리비전 블록의 일자 칸만 바뀐 항목 — 재출력의 흔적이지 내용이 아니다.
    표제란 DATE만 보던 규칙은 리비전 행 일자가 함께 갱신되는 실제 재출력에서 한 번도
    발동하지 않았다 (파일럿 모의 3차 ②)."""
    kind, key = getattr(i, "kind", ""), str(getattr(i, "key", "") or "")
    if kind == "FIELD_CHANGED" and key == "DATE":
        return True
    if kind == "REVROW_CHANGED" and (key.upper().endswith("DATE") or key.endswith("일자")):
        return True
    return False


def _file_level_items(path: str, old_row, new_rec) -> list:
    """내용을 못 읽는 파일의 근거 — 크기와 저장 시각. 바뀐 것만 항목으로 낸다.

    "직접 확인이 불가능한 확장자들 … PLC 프로그램 등은 저장 날짜나 파일명 변경된거
    정도는 관리가 가능하면 좋겠네" (2026-09-10). 이름·폴더 변경은 이미 이동으로
    접히므로 여기서는 크기·저장 시각만 본다."""
    def _sz(n) -> str:
        try:
            n = int(n)
        except (TypeError, ValueError):
            return "—"
        return f"{n:,}바이트" + (f" ({n / 1048576:.1f}MB)" if n >= 1048576 else "")

    def _tm(v) -> str:
        try:
            return datetime.fromtimestamp(float(v)).strftime("%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError, OSError, OverflowError):
            # 1e20 같은 값은 OverflowError — 한 파일의 이상한 시각이 검사 전체를
            # 죽이면 안 된다 (검토18)
            return "—"
    out: list = []
    if new_rec is None:
        return out
    o_size = o_mtime = None
    if old_row is not None:
        # _latest_rows()는 (sha256, size, mtime) 꼴로 준다
        try:
            o_size, o_mtime = old_row[1], old_row[2]
        except (TypeError, IndexError, KeyError):
            o_size = o_mtime = None
    try:
        size_changed = o_size is not None and int(o_size) != int(new_rec.size)
    except (TypeError, ValueError):
        size_changed = False
    if size_changed:
        out.append(ChangeItem("FIELD_CHANGED", "파일 크기", _sz(o_size),
                              _sz(new_rec.size), "파일 수준"))
    try:
        time_changed = o_mtime is None or abs(float(o_mtime) - float(new_rec.mtime)) > 1.0
    except (TypeError, ValueError):
        time_changed = True
    if time_changed:
        out.append(ChangeItem("FIELD_CHANGED", "저장 시각", _tm(o_mtime),
                              _tm(new_rec.mtime), "파일 수준"))
    return out


def _compare_modified(state: State, rd: RunData) -> None:
    """덮어쓰기 수정 파일(+ 옮겨지며 바뀐 파일): 구버전 추출본과 내용 비교, 기록해 둔
    그림으로 전/후 그림 비교(글자 변경 자리는 제외), Rev 일관성 검사. 글자를 못 읽는
    판(DWG 변환 없음 등)도 그림은 비교한다."""
    from watcher.capture import visual_page_diff
    sha_of = {r.path: r.sha256 for r in rd.records}
    now_of = {r.path: r for r in rd.records}          # 크기·저장 시각 (파일 수준 근거)
    prev_of = getattr(rd, "prev_files", None) or {}
    targets = [(c.path, c.old_sha256, c.new_sha256, None)
               for c in rd.changes if c.kind == "modified"]
    targets += [(new, old_sha, sha_of.get(new), old_path)
                for new, (old_path, old_sha, same) in rd.moved.items() if not same]
    for ti, (path, old_sha, new_sha, moved_from) in enumerate(targets, 1):
        # 가장 오래 걸리는 구간(글자 diff+그림 비교)에 진행이 없어 마지막 추출 파일 이름으로 얼어
        # 보였다 (검토24 B-1: 수정 24장 시험에서 전체의 34%)
        _set_progress("3/3 변경 비교 (글자·그림)", ti, len(targets), current=path)
        ext = PurePosixPath(path).suffix.lower()
        items: list = list(rd.details.get(path, []))
        if moved_from:
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{moved_from}에서 옮겨짐(이름·폴더 변경) — 그 판과 비교합니다", "파일 확인"))
        # ① 글자·표 — 구버전 추출본과
        old_dict = state.load_extract(old_sha)
        new_doc = rd.docs.get(path)
        if old_dict is not None and old_dict.get("extract_failed"):
            old_dict = None  # 구버전이 추출 불가였던 파일 — 내용 비교 불가로 처리
        old_doc = None
        text_items: list = []
        text_checked = False
        if old_dict is None or new_doc is None:
            # 검사 불가를 브리핑에 명시 — '이상 없음'과 '못 봄'을 구분
            from watcher.extract import can_read_content
            if new_doc is None and not can_read_content(path) \
                    and path not in rd.extract_failures:
                # PLC 프로젝트·DWG 바이너리처럼 **원래** 내용을 못 읽는 형식.
                # 전에는 "구버전 추출본 없음 — 이번 판을 기준으로 저장"이라 적어
                # 다음엔 될 것처럼 읽혔다 (2026-09-10 사용자 요청). `new_doc is None`
                # 조건이 있어야 한다 — 변환 프로그램이 있어 DWG를 실제로 읽었는데
                # 구판만 없는 경우는 형식 탓이 아니고 다음 판부터 비교된다 (검토18 ①)
                # "이름 변경으로 관리"는 과했다 — 이름 변경은 이 항목이 아니라 이동·판
                # 짝짓기가 보여 주고, 그것도 같은 이름 규칙일 때만이다 (검토18 문구 ⑧)
                more = ("그림 비교는 아래에 따로 싣습니다" if ext in VISUAL_EXTS
                        else "파일이 바뀐 사실과 크기·저장 시각으로 관리하고, 같은 이름 규칙의 "
                             "새 판은 이전 판과 짝지어 보여줍니다")
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "내용 비교", None,
                    f"이 형식({ext or '확장자 없음'})은 글자·표를 읽지 못합니다 — "
                    f"{more}", "파일 수준 감시"))
            else:
                reason = rd.extract_failures.get(
                    path, "구버전 추출본 없음 — 이번 판을 기준으로 저장")
                # 라이브러리 원문("File 'C:\...\E-103.dxf' is not a DXF file")이 서버 절대 경로까지 메일에
                # 실렸다 (검토21 브리핑 중간 7) — 담당자 말로 바꾸고 경로는 지운다
                # 이미 한국어 문구면 다시 포장하지 않는다 (재검증 N2: 같은 문장이 두 번)
                msg = reason if re.search(r"[가-힣]", str(reason)) else _friendly_error(Exception(reason))
                items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                        f"수행 못 함: {_strip_paths(msg)}", "추출 단계"))
            # 내용 비교를 못 한 모든 경우에 크기·저장 시각을 근거로 단다 — 사유가
            # 무엇이든(변환기 없는 DWG, 시간 초과, 원래 못 읽는 형식) 브리핑에 사실이
            # 하나는 있어야 한다 (원칙 4, 검토18 ②)
            items += _file_level_items(path, prev_of.get(moved_from or path),
                                       now_of.get(path))
        elif not _cache_ok(old_dict, path):
            # 구버전(다른 추출 엔진 세대) 기록과 새 추출본을 섞어 비교하면
            # 줄 나뉨 차이가 가짜 diff 수백 건이 된다 (2026-08-26 리뷰)
            items.append(ChangeItem(
                "CHECK_SKIPPED", "내용 비교", None,
                "수행 못 함: 이전 판의 추출 기록이 구버전 형식이라 비교를 생략하고 "
                "이번 판을 새 기준으로 저장합니다. 다음 변경부터 정상 비교됩니다",
                "추출 단계"))
            items += _file_level_items(path, prev_of.get(moved_from or path),
                                       now_of.get(path))
        else:
            old_doc = Document.from_dict(old_dict)
            note = unreadable_note(old_doc, new_doc)
            if note:  # 텍스트를 못 읽는 판이 끼면 엉터리 diff 대신 사유를 보고
                items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                        f"수행 못 함: {note}", "추출 단계"))
                old_doc = None
                # 스캔본(글자 없는 PDF)의 덮어쓰기 — 이 분기만 파일 수준 근거가 빠져
                # 근거 0줄이었다 (검토19 브리핑 ③)
                items += _file_level_items(path, prev_of.get(moved_from or path),
                                           now_of.get(path))
            else:
                text_items = _safe_diff(old_doc, new_doc, path)
                text_checked = True
        # ② 그림 — 검사 때 기록해 둔 페이지 그림이 '이전 판' (2026-09-02). 기록이
        # 없으면 '이상 없음'과 '못 봄'을 구분해 고지 (원칙 4)
        visual_done = ext not in VISUAL_EXTS   # PDF·DXF·DWG만 그림 비교 대상
        vis_regions = 0
        if ext in VISUAL_EXTS:
            old_pages, new_side = _visual_sides(state, rd, path, old_sha, new_sha)
            if old_pages and new_side is not None:
                print(f"  그림 비교(기록): {PurePosixPath(path).name}", flush=True)
                from watcher.diff import page_anchors
                vis = visual_page_diff(old_pages, new_side,
                                       ignore_texts=_changed_texts(old_doc, new_doc),
                                       ignore_boxes=_changed_boxes(old_doc, new_doc),
                                       anchors=(page_anchors(old_doc, new_doc)
                                                if old_doc is not None and new_doc is not None else None))
                visual_done = _add_visual(rd, path, items, vis)
                vis_regions = len(vis[0]) if vis else 0
            else:
                if new_doc is not None and not _wants_render(path, new_doc):
                    # 문서 폴더의 스캔본·매뉴얼 PDF는 그림을 **영영** 기록하지 않는다 —
                    # "다음 변경부터 비교됩니다"가 매번 되풀이되는 거짓 약속이었다 (검토19 2차 ⑤)
                    items.append(ChangeItem(
                        "CHECK_SKIPPED", "시각 비교", None,
                        "수행 못 함: 도면이 아닌 문서라 페이지 그림을 기록하지 않습니다 — "
                        "글자·크기·저장 시각으로 관리합니다 (도면 폴더로 옮기거나 표제란이 "
                        "있으면 그림도 비교합니다)", "시각 비교 단계"))
                else:
                    items.append(ChangeItem(
                        "CHECK_SKIPPED", "시각 비교", None,
                        "수행 못 함: 이전 판의 페이지 그림 기록이 없음 — 그림(도형) "
                        "변경은 비교하지 못함(글자·표 비교는 위 항목대로). 이번 판부터 그림을 "
                        "기록하므로 다음 변경부터는 같은 이름으로 덮어써도 그림 비교됩니다",
                        "시각 비교 단계"))
        items += text_items
        # 방향이 돌아갔거나 도면 범위가 넓어졌다고 이미 말했으면 "변경 없음"이라 덧붙이지
        # 않는다 — 한 화면에서 서로를 부정한다 (2026-09-10 매트릭스)
        said_something = any(getattr(i, "key", "") in ("페이지 방향", "도면 범위")
                             or getattr(i, "kind", "") in ("PAGE_ADDED", "PAGE_REMOVED", "PAGE_MOVED")
                             for i in items)          # 쪽이 빠졌다고 해 놓고 "재저장"이라 하지 않게 (검토19c ④)
        settled = text_checked and vis_regions == 0 and not said_something \
            and (ext not in VISUAL_EXTS or visual_done)
        if settled and not text_items:
            # 내용 같은 재저장 — '수정'으로만 보이고 상세가 비어 무엇이 바뀌었는지
            # 알 수 없던 것 (2026-09-03 검토: 케이블 스케줄·IO 리스트)
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                "내용 변경 없음 — 파일이 다시 저장되기만 했습니다 (글자·표·그림 동일). "
                "확인 대상 아님 (기록만 남깁니다)", "내용 비교"))
        elif text_checked and vis_regions == 0 and not said_something and text_items                 and all(_is_date_item(i) for i in text_items):
            # 표제란 일자만 갱신된 일괄 재출력 — 40장이 장마다 사진을 달고 '변경'으로 실려
            # 744KB 메일이 됐다 (파일럿 모의 ③). 그림 비교를 못 한 경우도 글자로는 날짜뿐이니
            # 그 밖의 알림으로 접되 그 사실을 적는다 (파일럿 모의 2차 day9)
            tail = ("그 밖의 글자·표·그림 동일" if (ext not in VISUAL_EXTS or visual_done)
                    else "그 밖의 글자·표 동일 (그림은 비교하지 못함)")
            what = ("표제란·리비전 블록의 일자만" if any(i.kind == "REVROW_CHANGED" for i in text_items)
                    else "표제란 일자만")
            # 옛/새 일자를 함께 — 접힌 행에 값이 없어 원칙 4에 어긋났다 (검토21 브리핑 중간 8)
            dt0 = next((i for i in text_items if i.kind == "FIELD_CHANGED" and i.key == "DATE"), None) \
                or text_items[0]
            vals = f" {dt0.old} → {dt0.new}" if (dt0.old or dt0.new) else ""
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{what} 갱신됨 (재출력){vals} — {tail}. 확인 대상 아님 (기록만 남깁니다)",
                "내용 비교"))
        if items:
            # 글자·그림이 같은 페이지 삭제를 각각 잡은 것은 **여기서** 접는다 — 보고 단계에서
            # 접으면 검토 필요 근거("이번 변경 2건 중 예시: 3페이지 삭제, 2페이지 삭제")가
            # 접기 전 목록으로 만들어졌다 (검토19 2차 감지 ⑦). 접히며 버려진 그림 항목의
            # 사진은 남은 글자 항목으로 옮겨 고아가 되지 않게
            before = {(i.kind, i.key) for i in items if i.kind in ("PAGE_ADDED", "PAGE_REMOVED")}
            items = _dedupe_page_items(items)
            after = {(i.kind, i.key) for i in items if i.kind in ("PAGE_ADDED", "PAGE_REMOVED")}
            for kind in ("PAGE_ADDED", "PAGE_REMOVED"):
                dropped = [k for kd, k in before - after if kd == kind]
                kept = [k for kd, k in after if kd == kind]
                if len(dropped) == 1 and len(kept) == 1:
                    cap = rd.captures.pop((path, f"{kind}|{dropped[0]}"), None)
                    if cap is not None and (path, f"{kind}|{kept[0]}") not in rd.captures:
                        rd.captures[(path, f"{kind}|{kept[0]}")] = cap
            rd.details[path] = items
        if old_doc is not None:
            rd.issues += _revision_issues(state, path, old_doc, new_doc, items, visual_done)


def _revision_issues(state: State, path: str, old_doc, new_doc, items, visual_checked):
    """check_revision + 억제 규칙. 'Rev 미갱신'을 지적받고 다음 날 Rev를 올리면 '자동 해소'
    직후 'Rev만 갱신' 경고가 새로 뜨던 것 (2026-09-05 전체 검토, 판매 위험 1순위) —
    ①이 파일에 열린 'Rev 미갱신' 이슈가 있었거나 ②리비전 행에 개정 사유가 적혔으면
    'Rev만 갱신'은 경고가 아니라 정상 개정이다."""
    issues = check_revision(path, old_doc, new_doc, items, visual_checked=visual_checked)
    # ③ 오늘 앞서 Rev를 올린 파일의 후속 편집 — 같은 날 계속 작업하는 것을 'Rev 미갱신'이라
    # 부르면 오탐이다 (파일럿 모의 ⑧). 내일도 Rev가 그대로면 그때 경고한다
    _bumped_at = state.rev_bumped_recently(path) if any(i.code == "CONTENT_CHANGED_REV_SAME" for i in issues) else None
    if _bumped_at:
        try:
            _d = datetime.fromisoformat(_bumped_at).astimezone()
            _when = ("오늘 앞서" if _d.date() == datetime.now().astimezone().date()
                     else f"어제({_d.strftime('%m-%d %H:%M')} 검사)")
        except (TypeError, ValueError):
            _when = "앞서"
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                f"{_when} Rev를 올린 파일의 후속 편집으로 봅니다 — 'Rev 미갱신' 경고는 "
                                "하지 않습니다 (이 파일이 다음에 또 바뀔 때 Rev가 그대로면 경고)", "Rev 검사"))
        issues = [i for i in issues if i.code != "CONTENT_CHANGED_REV_SAME"]
    if any(i.code == "CONTENT_CHANGED_REV_SAME" for i in issues) \
            and any(it.kind == "REVROW_ADDED" for it in items):
        # 개정이력에 새 행이 붙었는데 REV 필드가 못 따라온 경우(엑셀 개정이력이 위가 최신인 양식 등)
        # — 자기 근거(리비전 행 추가)가 자기 결론(Rev 그대로)을 부정하는 메일이 됐다 (검토25 감지 6-4)
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                "개정이력에 새 행이 추가됐습니다 — Rev 미갱신으로 보지 않습니다", "Rev 검사"))
        issues = [i for i in issues if i.code != "CONTENT_CHANGED_REV_SAME"]
    rev_only = [i for i in issues if i.code == "REV_CHANGED_CONTENT_SAME"]
    if not rev_only:
        return issues
    why = None
    if state.has_open_issue(path, "CONTENT_CHANGED_REV_SAME"):
        why = "앞서 지적된 'Rev 미갱신'을 반영해 Rev를 올린 것으로 봅니다"
    else:
        for it in items:
            if it.kind == "REVROW_ADDED":
                # xlsx·docx 개정이력의 사유 열은 '내용'·'사유'·'비고'가 흔하다 (검토25 감지 6-5)
                m = (re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*'([^']*)'",
                               str(it.new), re.IGNORECASE)
                     or re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*([^,}]+)",
                                  str(it.new), re.IGNORECASE))
                desc = (m.group(1).strip() if m else "")
                if desc and re.search(r"[A-Za-z0-9가-힣]", desc):    # '-'·'.' 같은 구분자만이면 사유 아님
                    why = f"리비전 행에 개정 사유가 있습니다: {desc[:60]}"
                    break
    if why is None:
        return issues
    items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                            f"Rev가 올라갔고 글자 변경은 없습니다 — {why}. 경고하지 않습니다",
                            "Rev 검사"))
    return [i for i in issues if i.code != "REV_CHANGED_CONTENT_SAME"]


def find_prev_version(state: State, key: str):
    """현재 스냅샷에서 key 파일의 '이전 판'. 사람이 직접 지정한 짝이 있으면
    그것이 자동 규칙(같은 폴더·확장자·stem, 더 오래된 것)보다 우선한다 —
    재비교·나란히 보기·이전 판 열기가 전부 이 함수를 쓰므로 한 곳에서 일괄 적용
    (2026-08-29). 돌려주는 값: (prev_key, prev_sha, 실패사유) — 실패 시 앞 둘은 None."""
    rows = state._latest_rows()
    if key not in rows:
        return None, None, "이 파일이 현재 감시 목록에 없습니다 (삭제되었거나 폴더가 바뀜)."
    mp = state.manual_pair(key)
    if mp and mp["prev_key"] in rows:
        return mp["prev_key"], rows[mp["prev_key"]][0], ""
    # 지정된 판이 감시 목록에서 사라졌으면 자동 규칙으로 폴백
    my_sha, _sz, my_mt = rows[key]
    p = PurePosixPath(key)
    stem, ext = pair_key(p.name), p.suffix.lower()
    sibs = [(k, r) for k, r in rows.items()
            if k != key
            and PurePosixPath(k).parent == p.parent
            and PurePosixPath(k).suffix.lower() == ext
            and pair_key(PurePosixPath(k).name) == stem
            and (r[2], k) < (my_mt, key)]
    if not sibs:
        return None, None, ("같은 폴더에서 이전 판을 찾지 못했습니다 — 날짜·버전 "
                            "표기를 뺀 파일 이름이 같아야 하고, 이 파일보다 "
                            "수정시각이 오래된 판이 있어야 합니다.")
    prev_key, (prev_sha, _s2, _m2) = max(sibs, key=lambda kv: (kv[1][2], kv[0]))
    return prev_key, prev_sha, ""


def recompare_change(state: State, change_id: int, abs_of_key,
                     sensitive: bool = False) -> tuple[bool, str]:
    """소급 재비교 — 과거에 짝지어지지 못한 변경(기준선 등록분, 구버전에서 놓친 판)을
    현재 폴더의 이전 판과 비교해 상세를 채운다 (2026-08-27 사용자 문제: 여러 판 중
    일부만 비교됨). abs_of_key: 경로 키 → 실제 Path. 돌려주는 값: (성공, 메시지)."""
    from dataclasses import asdict

    from watcher.capture import capture_pair, visual_page_diff

    ch = state.get_change(change_id)
    if ch is None:
        return False, "변경을 찾을 수 없습니다."
    key = ch.path
    prev_key, prev_sha, why = find_prev_version(state, key)
    if prev_key is None:
        return False, why
    my_sha = state._latest_rows()[key][0]
    p = PurePosixPath(key)
    ext = p.suffix.lower()
    new_abs, prev_abs = abs_of_key(key), abs_of_key(prev_key)
    if new_abs is None or prev_abs is None:
        return False, "파일에 접근할 수 없습니다 (잠김 또는 권한)."

    def _doc(sha, ap):
        d = state.load_extract(sha)
        if d is not None and "notes" in d and _cache_ok(d, ap):
            return Document.from_dict(d)
        if ext == ".dwg":
            return None          # DWG는 검사 때 변환한 기록만 쓴다 (없으면 글자 비교 생략)
        doc = extract(ap)
        state.save_extract(sha, {**doc.to_dict(), "cache_ver": _CACHE_VER})
        return doc

    try:
        old_doc, new_doc = _doc(prev_sha, prev_abs), _doc(my_sha, new_abs)
    except Exception as e:
        return False, f"내용 추출 실패: {e}"

    mp = state.manual_pair(key)
    how = ("사람 지정 짝" if mp and mp["prev_key"] == prev_key
           else "파일명 짝짓기")
    items = [ChangeItem("NEW_REVISION_OF", "이전 판",
                        PurePosixPath(prev_key).name, p.name,
                        f"{how} — 소급 재비교")]
    caps: dict = {}
    if old_doc is None or new_doc is None:
        note = DWG_NO_CONVERTER
    else:
        note = unreadable_note(old_doc, new_doc)
    text_items = _safe_diff(old_doc, new_doc, key) if not note else []
    masks = _changed_texts(old_doc, new_doc) if not note else set()
    boxes = _changed_boxes(old_doc, new_doc) if not note else []
    if ext == ".dwg":                       # 그림은 기록끼리 (파일을 직접 못 그린다)
        prev_abs, new_abs = state.load_renders(prev_sha), state.load_renders(my_sha)
    if ext in VISUAL_EXTS:
        vis = (visual_page_diff(prev_abs, new_abs, sensitive=sensitive, ignore_texts=masks, ignore_boxes=boxes)
               if prev_abs is not None and new_abs is not None else None)
        if vis is None:
            items.append(ChangeItem(
                "CHECK_SKIPPED", "시각 비교", None,
                "수행 못 함: 페이지 렌더 실패 또는 그림 기록 없음 — 텍스트 변경만 비교함",
                "시각 비교 단계"))
        else:
            for k, where in vis[0]:
                items.append(ChangeItem(
                    "PAGE_VISUAL_CHANGED", k, None,
                    "도면 그림 변경 감지 (전/후 확대 사진 참조)", where))
            for k, cap in vis[1].items():
                caps[f"PAGE_VISUAL_CHANGED|{k}"] = cap
    if note:
        items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                f"수행 못 함: {note}", "추출 단계"))
    else:
        items += text_items
        n = 0
        for it in items:  # 텍스트 변경 위치 캡처 (파일당 4장 제한)
            if n >= CAPTURE_PER_FILE:
                break
            if it.kind == "TEXT_CHANGED" and it.new:
                cap = capture_pair(new_abs, it.new, prev_abs, it.old)
            elif it.kind == "TEXT_ADDED" and it.new:
                cap = capture_pair(new_abs, it.new, prev_abs, None)
            else:
                continue
            if cap:
                _ck = f"{it.kind}|{it.key}"
                if _ck in caps:          # 같은 키가 여럿이면 자리까지 붙인다 (검토19 브리핑 ④)
                    _ck = f"{_ck}|{it.where}"
                caps[_ck] = cap
                n += 1
    state.save_change_details(change_id, [asdict(i) for i in items], caps)
    n_content = sum(1 for i in items if i.kind != "NEW_REVISION_OF")
    mode = " (민감 모드 — 미세 변경까지, 오탐은 [오탐 삭제]로 정리)" if sensitive else ""
    return True, (f"이전 판({PurePosixPath(prev_key).name})과 다시 비교했습니다 — "
                  f"항목 {n_content}건.{mode}")


# 파일 하나에서 사진을 만들 변경 항목 수 상한.
#
# 원래 4였다. 사용자가 "각 변경사항마다 한 장씩 각각 다 붙여야지", 이어서
# "100장이 바꼈을수도 있는거 아니야? 문제가 뭔데"라고 물어 실제 비용을 쟀다.
# 상한이 필요했던 이유는 **내 비효율**이었지 진짜 한계가 아니었다:
#   - 사진마다 도면 전체를 다시 그렸다        → 파일 단위로 한 번만 (캐시)
#   - 사진마다 DXF 파일을 다시 파싱했다       → 글자 목록도 파일 단위로 한 번만
# 실측(엔티티 2만 개 DXF): 장당 0.93초 → **0.003초** (310배). 이제 파일당 첫 장의
# 렌더(3.3초)가 비용의 거의 전부라, 항목이 5건이든 100건이든 시간이 같다.
#   도면 100장 × 항목  20건 = 사진 2,000장  → 5.5분,  12MB/일 (90일 1.1GB)
#   도면 100장 × 항목 100건 = 사진 10,000장 → 6.0분,  60MB/일 (90일 5.3GB)
# 남은 제약은 시간이 아니라 저장 공간이고, 그건 보존 기간 설정과 설정 화면의
# 용량 표시가 다룬다. 그래서 상한을 사실상 없앤다 — 아래 값은 한 파일이 수천 건
# 바뀐 병적인 날에만 걸리는 안전판이고, 걸리면 조용히 자르지 않고 알린다.
CAPTURE_PER_FILE = 500

# 기준선(첫 검사)에서 그림 비교를 해줄 도면 쌍 수 — 첫날 체감과 소요 시간의 절충
BASELINE_VISUAL_PAIRS = 30


# 프로젝트가 아니라 '공용 서랍'인 폴더 이름 — 교차 검사 묶음으로 쓰지 않는다
_COMMON_FOLDERS = {"공용", "공통", "참고", "참고자료", "표준", "양식", "템플릿", "개인", "임시", "기타",
                   "COMMON", "SHARED", "REFERENCE", "TEMPLATE", "TEMP", "ETC", "MISC"}


# 윈도우 복사본·빈 파일처럼 "변경이 아니라 부산물"인 것들을 알아본다
# (2026-09-01 처음 쓰는 사람 관점 점검: 'ㅇㅇ - 복사본.pdf'가 새 도면처럼 보고됨)
# 윈도우 사본은 '(2)'부터 — '(1)'은 시트다 (consistency._COPY_MARK_RE와 같은 규칙, 검토32 B1)
_COPY_MARK = re.compile(r"(- ?복사본|\((?:[2-9]|\d{2,})\)|\s-\s*copy|copy of )", re.IGNORECASE)


def _side_note(rd: RunData, c) -> str:
    """이 변경이 복사본·빈 파일 같은 부산물이면 한 줄 설명, 아니면 빈 문자열."""
    name = PurePosixPath(c.path).name
    ap = rd.abs_of.get(c.path)
    try:
        size = ap.stat().st_size if ap else None
    except OSError:
        size = None
    if size == 0:
        return "빈 파일(0바이트)입니다 — 저장이 덜 됐거나 잘못 만들어진 파일일 수 있습니다"
    if _COPY_MARK.search(name):
        same = [p for p, r in rd.prev_files.items()
                if r[0] == c.new_sha256 and p != c.path]
        if same:
            return (f"내용이 {PurePosixPath(same[0]).name} 와 같은 복사본입니다 — "
                    f"실제 개정이 아닐 수 있습니다")
        return "파일명이 복사본 형태입니다 — 실제 개정인지 확인해주세요"
    return ""


def _pair_index(rd):
    """판 짝짓기 후보 색인 — 검사당 한 번만 만든다.

    후보를 추가 파일마다 전체 목록에서 훑으면 추가 × 전체(4만 기준선 외삽 169분,
    2026-09-02 재검토 실측). (폴더, 확장자, 짝 키) → 목록으로 O(1) 조회."""
    idx = getattr(rd, "_pair_idx", None)
    if idx is not None:
        return idx
    prev_idx: dict = {}
    for pp, row in rd.prev_files.items():
        q = PurePosixPath(pp)
        stem = pair_key(q.name)
        if stem:
            prev_idx.setdefault((str(q.parent), q.suffix.lower(), stem), []).append((pp, row))
    rec_idx: dict = {}
    rec_by_path: dict = {}
    for r in rd.records:
        q = PurePosixPath(r.path)
        rec_by_path[r.path] = r
        stem = pair_key(q.name)
        if stem:
            rec_idx.setdefault((str(q.parent), q.suffix.lower(), stem), []).append(r)
    rd._pair_idx = (prev_idx, rec_idx, rec_by_path)
    return rd._pair_idx


from watcher.scan import ver_rank as _ver_rank      # 판 표기 순위 (scan.ver_rank, consistency와 공용)


def sheet_bases(paths) -> set:
    """'이름 (1).ext'가 있는 폴더의 '폴더/이름' — 그 옆의 '(2)'·'(3)'은 사본이 아니라 시트다 (검토32 D 1-7)."""
    return {str(PurePosixPath(p).parent) + "/" + re.sub(r"\s*\(1\)$", "", PurePosixPath(p).stem)
            for p in paths if re.search(r"\(1\)$", PurePosixPath(p).stem)}


def is_copy_marked(path: str, sheets: set) -> bool:
    """사본 표식('- 복사본'·'(2)'·' copy')이 붙었나 — 단, 같은 폴더에 '(1)'이 있으면 '(N)'은 시트."""
    from watcher.consistency import _COPY_MARK_RE
    stem = PurePosixPath(path).stem
    m = _COPY_MARK_RE.search(stem)
    if not m:
        return False
    if re.fullmatch(r"\(\d+\)", m.group(1)):
        base = str(PurePosixPath(path).parent) + "/" + stem[:m.start()].rstrip()
        if base in sheets:
            return False
    return True


def _superseded_paths(rd: RunData, project_of=None) -> set:
    """같은 폴더·같은 도면 이름(판 표기만 다른)의 여러 판 가운데 최신 하나만 남기고 나머지.
    project_of(path) → 프로젝트 이름(없으면 None): 주어지면 **프로젝트가 같은 것끼리만** 겨룬다 — 루트에
    떨어진 양식 한 장이 그 아래 모든 프로젝트의 같은 번호 도면을 밀어냈다 (검토31 B2)
    판 짝짓기가 '이전 판'으로 삼은 경로는 그 검사분에서만 교차 검사에서 빠졌고, 다음 날부터 구판이
    도면 간·도면-BOM 불일치의 기준으로 되돌아왔다 (2회차 B7).
    - 표제란 도면번호가 서로 **다르면** 다른 도면이다 — '판넬도면'과 '판넬도면_rev2'가 별개인 회사 (3회차 A2-2)
    - 최신은 이름의 판 표기 순으로, 같으면 저장 시각 (3회차 A2-1: 구판 재저장)"""
    import functools
    from watcher.scan import pair_key
    _prev_idx, rec_idx, _by = _pair_index(rd)

    def _no_of(r):
        d = rd.docs.get(r.path)
        f = getattr(d, "fields", {}).get("DWG_NO") if d is not None else None
        return (f.value or "").strip().upper() if f else ""

    def _rev_of(r):
        d = rd.docs.get(r.path)
        rv = str(getattr(d, "revision", "") or "") if d is not None else ""
        return (len(rv), rv.upper())

    from watcher.consistency import _OLD_FOLDER, _COPY_MARK_RE
    from datetime import datetime as _dt

    def _is_old(r) -> bool:
        return bool(_OLD_FOLDER.search(r.path))

    _sheet1 = sheet_bases(rd.docs)

    def _is_copy(r) -> bool:
        return is_copy_marked(r.path, _sheet1)

    def _mtime_day(r) -> int:
        try:
            return int(_dt.fromtimestamp(float(r.mtime or 0)).strftime("%Y%m%d"))
        except (OverflowError, OSError, ValueError):
            return 0

    def _date_of(vr) -> int:
        """ver_rank의 날짜 꼬리 (0, n) → YYYYMMDD (6자리면 20YYMMDD)."""
        n = vr[1]
        return n if n >= 10_000_000 else (20_000_000 + n if n >= 100_000 else 0)

    def _mixed_revs(g) -> bool:
        """숫자 Rev와 문자 Rev가 한 묶음에 섞였나 — 쌍마다 건너뛰면 '1 > 0 > A > 1' 순환이 생겨 정렬 순서가
        답을 정했다(검토32 B2). 섞였으면 묶음 전체에서 Rev 단계를 뺀다"""
        kinds = {_rev_of(r)[1].isdigit() for r in g if _rev_of(r)[0]}
        return len(kinds) > 1

    def _cmp(a, b, use_rev: bool = True) -> int:
        """a가 b보다 '현행'이면 양수. 순서: 구판 폴더는 항상 짐(검토31 B1: 하위 OLD/의 재저장 구판이 현행을
        밀어냈다) → 사본 표식은 짐(B5) → 표제란 Rev(같은 체계일 때만 — '0' vs 'A'처럼 숫자·문자 혼용은
        비교 불가, B3) → 한쪽만 비면 저장 시각 → 무표기 vs 날짜판은 날짜가 무표기 저장일 이후면 날짜판이
        신판, 아니면 그날의 사본(B4) → 무표기 우선 → 이름의 판 표기 → 저장 시각 (검토30 B 5-D)"""
        oa, ob = _is_old(a), _is_old(b)
        if oa != ob:
            return -1 if oa else 1
        ca, cb = _is_copy(a), _is_copy(b)
        if ca != cb:
            return -1 if ca else 1
        ra, rb = _rev_of(a), _rev_of(b)
        if use_rev and ra[0] and rb[0] and ra != rb:
            return 1 if ra > rb else -1
        if use_rev and bool(ra[0]) != bool(rb[0]):
            return 1 if (a.mtime, a.path) > (b.mtime, b.path) else -1
        va, vb = _ver_rank(PurePosixPath(a.path).name), _ver_rank(PurePosixPath(b.path).name)
        ua, ub = va == (1, 0, ""), vb == (1, 0, "")
        if ua and vb[0] == 0 and _date_of(vb) and _date_of(vb) > _mtime_day(a):
            return -1
        if ub and va[0] == 0 and _date_of(va) and _date_of(va) > _mtime_day(b):
            return 1
        if ua != ub:
            return 1 if ua else -1
        if va != vb:
            return 1 if va > vb else -1
        return 1 if (a.mtime, a.path) > (b.mtime, b.path) else -1

    # 묶음: 같은 프로젝트 + 같은 도면번호 + 같은 pair_key(사본 표식은 걷고)는 폴더가 달라도(현행을 전기/로
    # 옮김) 한 묶음 (5-E); 번호 없는 파일은 예전처럼 같은 폴더·같은 stem만
    groups: dict = {}
    for _k, recs in rec_idx.items():
        for r in recs:
            no = _no_of(r)
            name = PurePosixPath(r.path).name
            proj = project_of(r.path) if project_of else None
            if project_of and not proj:
                proj = ("dir", _k)            # 귀속 없는 파일(미분류)은 같은 폴더 안에서만 겨룬다
            key = ("no", proj, no, PurePosixPath(r.path).suffix.lower(), pair_key(_COPY_MARK.sub("", name))) \
                if no else ("dir", _k)
            groups.setdefault(key, []).append(r)

    def _clusters(g: list) -> list:
        """폴더가 같거나 한쪽이 다른 쪽의 상위인 것끼리 묶는다 — 번호·이름이 같아도 **형제 폴더**의 도면은
        남남이다 (검토30 매트릭스 C105). 폴더 이름순으로 정렬하면 하위 폴더가 상위 바로 뒤에 오므로
        한 번 훑어 묶는다 — 제곱 탐색은 형제 2,000개에 19초였다 (검토31 B7)"""
        # 문자열 정렬은 'P26-050 추가'(공백 < '/')를 'P26-050'과 'P26-050/전기' 사이에 끼워 묶음을 끊었다
        # (검토32 D 1-2) — 경로 조각 튜플로 견주면 자식이 형제보다 먼저 온다
        items = sorted(g, key=lambda r: (PurePosixPath(r.path).parent.parts, r.path))
        out_: list = []
        tops: list = []
        for r in items:
            d = PurePosixPath(r.path).parent.parts
            if out_ and d[:len(tops[-1])] == tops[-1]:
                out_[-1].append(r)
            else:
                out_.append([r])
                tops.append(d)
        return out_

    out: set = set()
    for key, g in groups.items():
        if len(g) < 2:
            continue
        if key[0] == "dir":
            nos = {_no_of(r) for r in g if _no_of(r)}
            if nos:                       # 번호 있는 파일은 위 묶음에서 다뤘다 — 번호 없는 것끼리만
                g = [r for r in g if not _no_of(r)]
                if len(g) < 2:
                    continue
        for cl in (_clusters(g) if key[0] == "no" else [g]):
            if len(cl) < 2:
                continue
            _use = not _mixed_revs(cl)
            newest = max(cl, key=functools.cmp_to_key(lambda a, b: _cmp(a, b, _use)))
            out.update(r.path for r in cl if r.path != newest.path)
    return out


def _pair_revisions(state: State, rd: RunData) -> None:
    """판 짝짓기: 날짜/버전을 파일명에 붙여 '새 파일'로 저장하는 문화 대응.
    추가된 파일과 같은 폴더에서 stem(날짜·버전 제외 이름)이 같은 이전 판을 찾아
    비교하고, PDF면 페이지 시각 변경(그림·배선)도 감지한다."""
    # 첫 검사(기준선)에는 무거운 그림 비교를 하지 않는다 — 수년치 판이 쌓인
    # 서버에서 모든 과거 쌍을 페이지 렌더로 비교하면 몇 시간~며칠이 걸린다
    # (2026-08-27 회사 서버 5,211개 실측). 텍스트 짝짓기·diff는 유지, 그림은
    # 이후 일일 검사에서 새 판이 올 때부터. 과거 도면이 필요하면 화면의
    # [더 민감하게 다시 비교]로 파일 단위 소급 비교가 가능하다.
    baseline = not rd.prev_files
    noted = False
    for ci, c in enumerate(rd.changes, 1):
        _set_progress("3/3 변경 비교·기록", ci, len(rd.changes))
        if c.kind != "added" or c.path in rd.details or c.path in rd.moved:
            continue
        # 복사본·빈 파일이면 그 사실을 항목으로 남긴다 — 사람이 열어보지 않아도
        # 무엇인지 알 수 있게 (2026-09-01 처음 쓰는 사람 관점 점검)
        side = _side_note(rd, c)
        if side:
            rd.details.setdefault(c.path, []).append(
                ChangeItem("CHECK_SKIPPED", "참고", None, side, "파일 확인"))
        if c.path in rd.extract_failures and not side:   # 빈 파일 안내와 겹치지 않게
            # 손상·잠김으로 못 읽은 새 파일 — 사유가 콘솔에만 남고 화면엔 없던 것
            # (2026-09-03 검토)
            reason = rd.extract_failures[c.path]
            hint = ("" if reason.startswith("DWG") or "끝나지 않아 중단" in reason else
                    " — 파일이 손상됐거나 저장이 끊겼을 수 있습니다 (프로그램으로 열리는지 확인)")
            rd.details.setdefault(c.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "내용 추출 실패", None, f"수행 못 함: {reason}{hint}", "추출 단계"))
        p = PurePosixPath(c.path)
        stem, ext = pair_key(p.name), p.suffix.lower()
        if not stem:
            continue
        prev_idx, rec_idx, rec_by_path = _pair_index(rd)
        key = (str(p.parent), ext, stem)
        cands = [(pp, row) for pp, row in prev_idx.get(key, ()) if pp != c.path]
        if cands:
            prev_path, prev_row = max(cands, key=lambda kv: kv[1][2])
            prev_sha = prev_row[0]
        else:
            # 같은 검사에서 두 판이 한꺼번에 처음 등장한 경우 — 직전 스냅샷에는
            # 없지만 이번 스캔의 형제 파일과 짝지어 비교한다 (2026-08-26 실사용:
            # 구판·신판을 동시에 넣으면 비교가 안 되던 문제. '하나 빼고 검사 후
            # 다시 넣기' 우회도 이제 불필요). 자기보다 오래된(수정시각) 판만 구판 후보.
            me = rec_by_path.get(c.path)
            if me is None:
                continue
            sibs = [r for r in rec_idx.get(key, ())
                    if r.path != c.path and (r.mtime, r.path) < (me.mtime, me.path)]
            if not sibs:
                continue  # 자신이 가장 오래된 판 — 신판 쪽에서 짝지어진다
            prev_rec = max(sibs, key=lambda r: (r.mtime, r.path))
            prev_path, prev_sha = prev_rec.path, prev_rec.sha256
            prev_row = (prev_sha, prev_rec.size, prev_rec.mtime)
        old_dict = state.load_extract(prev_sha)
        new_doc = rd.docs.get(c.path)
        if old_dict is None or new_doc is None \
                or old_dict.get("extract_failed"):
            from watcher.extract import can_read_content
            if can_read_content(c.path):
                continue        # 읽을 수 있는 형식인데 못 읽은 것 — 위에서 사유를 남겼다
            # 내용을 못 읽는 형식(PLC 프로젝트·DWG 등)도 "이것이 그 파일의 새 판이고
            # 구판은 사라진 게 아니다"와 크기·저장 시각은 말해 줘야 한다. 전에는 DWG만
            # 그림이 있을 때 짝지었고 나머지는 여기서 빠져나가, 브리핑에 '추가'와
            # '삭제'가 서로 남처럼 따로 떴다 (2026-09-10 요청)
            me = rec_by_path.get(c.path)
            rd.old_versions.add(prev_path)
            items = list(rd.details.get(c.path, []))   # 위에서 달아 둔 참고·실패 사유 보존
            items.append(ChangeItem("NEW_REVISION_OF", "이전 판",
                                    PurePosixPath(prev_path).name, p.name,
                                    "파일명 짝짓기 (날짜·버전 표기 제외 동일)"))
            if ext == ".dwg":
                # 변환 프로그램 없는 DWG: 글자는 없어도 미리보기 그림끼리는 비교 (2026-09-03)
                old_pages = state.load_renders(prev_sha)
                new_pages = state.load_renders(me.sha256) if me else None
                if old_pages and new_pages:
                    from watcher.capture import visual_page_diff
                    _add_visual(rd, c.path, items,
                                visual_page_diff(old_pages, new_pages))
            if new_doc is not None:
                # 이번 판은 읽었는데(변환기 있는 DWG) 구판 기록만 없다 — 형식 탓이
                # 아니며 다음 판부터 비교된다 (검토18 ①)
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "내용 비교", None,
                    "수행 못 함: 이전 판의 추출 기록이 없음 — 이번 판을 기준으로 저장",
                    "추출 단계"))
            elif c.path not in rd.extract_failures:    # 사유가 없으면 형식 탓임을 밝힌다
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "내용 비교", None,
                    f"이 형식({ext or '확장자 없음'})은 글자·표를 읽지 못합니다 — "
                    f"파일이 바뀐 사실과 크기·저장 시각으로 관리합니다",
                    "파일 수준 감시"))
            items += _file_level_items(c.path, prev_row, me)
            if prev_path not in rec_by_path:
                rd.details.setdefault(prev_path, []).append(ChangeItem(
                    "CHECK_SKIPPED", "참고", None,
                    f"새 판 {p.name}(으)로 대체됨 — 파일이 없어진 것이 아닙니다",
                    "판 짝짓기"))
            rd.details[c.path] = items
            continue
        if not _cache_ok(old_dict, c.path):
            # 이전 판이 제외 폴더 등으로 재추출되지 않은 경우의 엔진 혼합 방지
            rd.details[c.path] = [ChangeItem(
                "CHECK_SKIPPED", "내용 비교", None,
                "수행 못 함: 이전 판의 추출 기록이 구버전 형식이라 비교를 생략합니다",
                "추출 단계")]
            continue
        old_doc = Document.from_dict(old_dict)
        rd.old_versions.add(prev_path)
        if prev_path not in rec_by_path:
            # 이름을 바꿔 저장한 새 판 — 구판은 '삭제'로 잡히지만 사라진 게 아니다.
            # 그 삭제 항목에 참고를 달아 목록·브리핑에서 바로 알게 (2026-09-02 검토)
            rd.details.setdefault(prev_path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"새 판 {p.name}(으)로 대체됨 — 파일이 없어진 것이 아닙니다", "판 짝짓기"))
        items = [ChangeItem("NEW_REVISION_OF", "이전 판",
                            PurePosixPath(prev_path).name, p.name,
                            "파일명 짝짓기 (날짜·버전 표기 제외 동일)")]
        note = unreadable_note(old_doc, new_doc)
        if note:  # 텍스트를 못 읽는 판이 끼면 엉터리 diff 대신 사유를 보고
            items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                    f"수행 못 함: {note}", "추출 단계"))
            rd.details[c.path] = items
            continue
        # 페이지 시각 변경 감지 (PDF 도면, 이전 판 파일이 남아 있을 때) —
        # 배선·도형처럼 텍스트 비교가 못 보는 변경 (원칙 7, 2026-08-24 개정)
        text_items = _safe_diff(old_doc, new_doc, c.path)
        masks = _changed_texts(old_doc, new_doc)
        boxes = _changed_boxes(old_doc, new_doc)
        rd.ocr_boxes[c.path] = _ocr_boxes_of(new_doc)
        visual_done = ext not in VISUAL_EXTS   # PDF·DXF·DWG만 그림 비교 대상
        # 이전 판 파일이 남아 있으면 파일끼리, 이미 지워졌으면 기록해 둔 그림으로.
        # DWG는 파일을 직접 못 그리니 양쪽 다 기록 그림
        old_side = rd.abs_of.get(prev_path) if ext != ".dwg" else None
        new_side = rd.abs_of.get(c.path) if ext != ".dwg" else None
        if ext in VISUAL_EXTS:
            if old_side is None:
                old_side = state.load_renders(prev_sha)
            if new_side is None and c.path in rec_by_path:
                new_side = state.load_renders(rec_by_path[c.path].sha256)
        # 나중에 추가한 감시 폴더의 첫 검사도 그 폴더에선 기준선이다 — 수년치 판이 쌓인 폴더를
        # 추가한 날 모든 과거 쌍을 그림 비교하지 않게 (2026-09-11)
        base_here = baseline or ((c.path.split("/", 1)[0] if "/" in c.path else c.path) in rd.reg_roots)
        if (base_here and ext in VISUAL_EXTS
                and len(rd.baseline_visual) >= BASELINE_VISUAL_PAIRS):
            # 기준선에서도 앞 N건은 그림 비교를 해준다 — 첫날부터 전/후 사진을
            # 봐야 이 기능이 있는 줄 안다 (2026-08-31 사용자: "도면은 왜 사진
            # 비교가 없어진 거야?"). 그 이상은 시간이 폭증해 건너뛴다
            if not noted:
                noted = True
                print(f"{'첫 검사(기준선)' if baseline else '새로 추가한 폴더의 첫 검사'}: 그림(페이지) 비교는 앞 "
                      f"{BASELINE_VISUAL_PAIRS}건까지만 하고 나머지는 "
                      f"건너뜁니다 — 텍스트 비교는 전부 기록되며, 필요한 도면은 "
                      f"화면의 [더 민감하게 다시 비교]로 소급 비교됩니다.",
                      flush=True)
        elif old_side is not None and new_side is not None and ext in VISUAL_EXTS:
            from watcher.capture import visual_page_diff
            print(f"  그림 비교: {p.name} ← {PurePosixPath(prev_path).name}",
                  flush=True)
            visual_done = _add_visual(rd, c.path, items,
                                      visual_page_diff(old_side, new_side, ignore_texts=masks, ignore_boxes=boxes,
                                                       anchors=__import__("watcher.diff", fromlist=["page_anchors"]).page_anchors(old_doc, new_doc)))
            if base_here:
                rd.baseline_visual.add(c.path)
        items += text_items
        rd.details[c.path] = items
        if prev_path in rd.abs_of:  # 이전 판 파일이 아직 있으면 전 사진 가능
            rd.prev_abs[c.path] = rd.abs_of[prev_path]
        rd.issues += _revision_issues(state, c.path, old_doc, new_doc, items,
                                    visual_checked=visual_done)


def _collect_text_captures(rd: RunData) -> None:
    """변경 위치 캡처 (도면 유형만, 파일당 4장 제한 — 브리핑 용량 보호).
    전/후 쌍: 이전 판 파일이 남아 있으면(판 짝짓기) 전 사진도, 덮어쓰기면 후만."""
    baseline = not rd.prev_files
    if baseline and not rd.baseline_visual:
        return  # 첫 검사: 그림 비교 대상이 없으면 렌더 캡처도 생략(소요 시간)
    from watcher.capture import capture_pair
    for pi, (cpath, citems) in enumerate(rd.details.items(), 1):
        _set_progress("3/3 변경 자리 사진", pi, len(rd.details), current=cpath)
        if baseline and cpath not in rd.baseline_visual:
            continue        # 기준선에서는 그림 비교한 파일만 사진을 만든다
        ap = rd.abs_of.get(cpath)
        if ap is None:
            continue
        old_ap = rd.prev_abs.get(cpath)
        boxes = rd.ocr_boxes.get(cpath) or {}
        n = 0
        want = sum(1 for it in citems
                   if it.kind in ("TEXT_CHANGED", "TEXT_ADDED", "FIELD_CHANGED") and it.new)
        if want > CAPTURE_PER_FILE:
            print(f"  참고: {PurePosixPath(cpath).name}의 변경 {want}건 중 앞 "
                  f"{CAPTURE_PER_FILE}건만 사진을 만듭니다 (나머지는 글자 비교로 남습니다)",
                  flush=True)
        for it in citems:
            if n >= CAPTURE_PER_FILE:
                break
            if it.kind == "FIELD_CHANGED" and it.key == "DATE":
                continue        # 날짜 칸은 값이 근거다 — 장마다 표제란 사진을 붙이면 메일만 붓는다 (파일럿 모의 ③)
            bx = boxes.get(" ".join(str(it.new or "").split()))
            if it.kind == "TEXT_CHANGED" and it.new:
                cap = capture_pair(ap, it.new, old_ap, it.old, box=bx)
            elif it.kind == "TEXT_ADDED" and it.new:
                cap = capture_pair(ap, it.new, old_ap, None, box=bx)
            elif it.kind == "FIELD_CHANGED" and it.new:
                # OCR 자리가 있으면 그 자리를, 없으면 글자로 찾는다. 전에는 OCR일 때만
                # 사진을 만들어, 보통 도면은 Rev가 바뀌어도 글자만 나왔다
                # (2026-09-10 "왜 글로만 비교가 되는거야?")
                cap = capture_pair(ap, str(it.new), old_ap, it.old, box=bx)
                if cap is None and it.key:
                    # 표제란은 'REV: B'처럼 라벨과 값이 한 칸에 있는 일이 흔하다
                    cap = capture_pair(ap, f"{it.key}: {it.new}", old_ap,
                                       f"{it.key}: {it.old}" if it.old else None)
            else:
                continue
            if cap:
                # kind를 키에 포함 — 같은 key의 TEXT_CHANGED/ADDED가
                # 서로의 사진을 덮어쓰지 않게 (2026-08-25 리뷰)
                _ck = f"{it.kind}|{it.key}"
                if (cpath, _ck) in rd.captures:
                    _ck = f"{_ck}|{it.where}"
                rd.captures[(cpath, _ck)] = cap
                n += 1


BACKUP_ROWS_KEY = "backup_rows"      # 지난 백업 때의 행 수 (급감 감지용)


def _slot_rows(path: Path) -> dict | None:
    """백업 슬롯 **파일 자체**의 행 수. 못 읽으면 None."""
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except Exception:                                     # noqa: BLE001
        return None
    try:
        return {t_: con.execute(f"SELECT COUNT(*) FROM {t_}").fetchone()[0]
                for t_ in ("snapshots", "changes")}
    except Exception:                                     # noqa: BLE001
        return None
    finally:
        con.close()


def _backup_db(state: State, db_path: Path, backup_dir: str | None = None) -> None:
    """주 1회 state.db 자동 백업 — backups/ 아래 4개 슬롯 순환(약 한 달 보관).
    모든 이력이 파일 하나라 유실이 곧 신뢰 붕괴 (2026-08-29). 삭제 API 없이
    같은 슬롯을 덮어쓰는 방식이라 읽기 전용 원칙과도 충돌 없음.

    **설계 이력 (2026-09-10)**: 검토 세 번에서 세 번 다 이 자리가 깨졌다 —
    ①검증이 아예 없어 깨진 DB가 멀쩡한 사본을 덮음 ②고친 뒤에는 기준값이 파괴되는
    그 DB 안에 있어 정작 그 사고에서 방어가 건너뛰어짐 ③방어가 발동하면 기준값을
    갱신하지 않아 백업이 영구 정지. 원인은 방어가 아니라 **"급감이면 미룬다"는
    휴리스틱**이었다. 사고와 사람의 의도를 구분하려고 상태를 저장할 때마다 그 상태가
    새 구멍이 됐다. 그래서 상태를 없앴다:

    - 한 달치 방어는 **슬롯 4개가 이미 한다** — 사고는 한 주에 한 슬롯만 망가뜨리고,
      나머지 셋은 3주 더 남는다. 미루지 않아도 되살릴 사본이 있다.
    - 원본이 온전할 때만 쓰고(integrity_check), **쓴 뒤 그 백업을 다시 열어**
      원본과 행 수가 맞는지 확인한다 — 쓰다 만 백업을 성공이라 말하지 않는다.
    - 이력이 지난 사본들보다 크게 줄었으면 **경고만** 남기고 백업은 한다."""
    import sqlite3
    # config backup_dir로 다른 디스크(NAS 등)를 지정할 수 있다 — 같은 디스크의 사본은 그
    # 디스크가 죽으면 함께 죽는다 (2026-09-02 위시, 검토19 운영 ⑬). 없으면 DB 옆 backups/
    bdir = Path(backup_dir) if backup_dir else db_path.parent / "backups"
    try:
        bdir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"경고: 백업 폴더를 만들 수 없어 이번 주 백업을 건너뜁니다 ({bdir}: {e})",
              file=sys.stderr)
        return
    week = datetime.now().isocalendar()[1]
    dst = bdir / f"state_backup_{week % 4 + 1}.db"
    if dst.exists() and (datetime.now().timestamp()
                         - dst.stat().st_mtime) < 6 * 86400:
        return  # 이번 주 몫은 이미 있음
    ok, why = state.integrity_ok()
    if not ok:
        print(f"경고: state.db가 온전하지 않아 백업을 건너뜁니다 ({why}) — "
              f"{bdir} 안의 지난 사본은 그대로 둡니다. 되살리는 순서는 도움말의 "
              f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다.", file=sys.stderr)
        return

    now = state.row_counts()
    # 지난 사본들과 견줘 크게 줄었으면 **알리되 막지는 않는다** (막으면 백업이 멈춘다).
    # 덮어쓸 슬롯도 센다 — 그것도 4주 전의 사본이고, 첫 달에는 그것뿐일 수 있다
    others = [r for f in sorted(bdir.glob("state_backup_*.db"))
              for r in (_slot_rows(f),) if r]
    if others:
        best = max(others, key=lambda r: r.get("changes", 0))
        gone = [k for k in ("snapshots", "changes")
                if best.get(k, 0) > 20 and now.get(k, 0) < best[k] * 0.5]
        if gone:
            print("경고: 이력이 지난 사본보다 크게 줄었습니다 (" + ", ".join(
                f"{k} {best.get(k)}→{now.get(k)}" for k in gone)
                + f"). 사람이 지운 것이면 정상입니다. 사고라면 {bdir} 안의 다른 "
                f"사본으로 되살리세요 — 이번 주 슬롯({dst.name})만 덮어씁니다.",
                file=sys.stderr)

    # 슬롯을 제자리에서 덮어쓰면 디스크 풀·중단 때 4주 전 사본까지 잃는다 (검토19 운영 ④).
    # 먼저 옆의 .new에 쓰고 검증한 뒤 슬롯으로 옮긴다 — 이름 바꾸기(삭제·이동 API)는
    # 읽기 전용 원칙으로 쓰지 않으므로 SQLite 백업 API로 한 번 더 복사한다. .new는 다음
    # 주까지 그대로 남아 가장 최근의 검증된 사본 구실을 한다. 백업 파일은 WAL이 아니라
    # 단일 파일(DELETE 저널)로 — .db만 옮겨도 온전하도록
    def _copy_into(src_conn, path: Path) -> None:
        dc = sqlite3.connect(path)
        try:
            src_conn.backup(dc)
            # 백업 API는 머리(WAL 표식)까지 복사한다 — 복사 **뒤에** 단일 파일로 바꿔야 한다
            dc.execute("PRAGMA journal_mode=DELETE")
        finally:
            dc.close()

    tmp = dst.with_name(dst.name + ".new")
    _copy_into(state.conn, tmp)
    made = _slot_rows(tmp)
    if made is None or any(made.get(k) != now.get(k) for k in ("snapshots", "changes")):
        print(f"경고: 백업을 저장했지만 다시 읽었을 때 내용이 원본과 다릅니다 "
              f"({tmp.name}: {made} vs {now}) — 지난 슬롯 {dst.name}은 건드리지 "
              f"않았습니다. 디스크 공간·권한을 확인하세요.", file=sys.stderr)
        return
    src = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True)
    try:
        _copy_into(src, dst)
    finally:
        src.close()
    # 쓴 것을 **다시 열어** 확인한다 — 디스크가 차거나 중간에 끊긴 백업을
    # "저장 완료"라 말하지 않기 위해
    made = _slot_rows(dst)
    if made is None or any(made.get(k) != now.get(k) for k in ("snapshots", "changes")):
        print(f"경고: 백업을 저장했지만 다시 읽었을 때 내용이 원본과 다릅니다 "
              f"({dst.name}: {made} vs {now}) — 검증된 사본은 {tmp.name}에 있습니다. "
              f"디스크 공간·권한을 확인하세요.", file=sys.stderr)
        return
    state.set_meta(BACKUP_ROWS_KEY, __import__("json").dumps(now))   # 화면 표시용
    print(f"이력 백업: {dst.name} (주 1회, 4개 순환, 확인 완료) — 되살리는 순서는 "
          f"도움말의 '백업 · 다른 PC로 이전 · 되살리기'에 있습니다 "
          f"(state.db-wal을 먼저 지워야 합니다)")


def _housekeep(state: State, cfg: dict, args, skip_weekly: bool = False) -> None:
    """검사 뒤 정리: 보존 기간 지난 상세 정리 + DB 주간 백업 + 월요일 주간 요약.
    전부 실패해도 검사 결과에는 영향 없음 — 단, 원인은 stderr에 남긴다."""
    try:
        _backup_db(state, Path(args.state_db or cfg["state_db"]), cfg.get("backup_dir"))
    except Exception as e:
        print(f"경고: 이력 백업 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        days = int(cfg.get("retention_days", 90) or 0)
        if days > 0:
            state.prune_details(days)
    except Exception as e:
        print(f"경고: 오래된 기록 정리 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        # 현재 파일의 그림 + 보존 기간 안의 이전 판 그림 (0 = 무기한)
        state.prune_renders(int(cfg.get("retention_days", 90) or 0))
    except Exception as e:
        print(f"경고: 페이지 그림 기록 정리 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        # 지운 기록이 차지하던 빈 페이지를 디스크에 돌려준다 — 전에는 파일 크기가
        # 역대 최대치에 영구 고정됐고 백업이 그 빈 페이지까지 복사했다
        got = state.reclaim_space()
        if got:
            print(f"이력 파일 정리: {got['before']/1048576:.0f}MB → "
                  f"{got['after']/1048576:.0f}MB ({got['freed']/1048576:.0f}MB 회수)")
    except Exception as e:
        print(f"경고: 이력 파일 공간 회수 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        _warn_disk(state, Path(args.brief_dir or cfg["brief_dir"]))
    except Exception as e:
        print(f"경고: 저장 공간 점검 실패(검사 결과는 정상): {e}", file=sys.stderr)
    if not args.dry_run and not skip_weekly:
        try:
            wp = write_weekly_summary(
                state, cfg, Path(args.brief_dir or cfg["brief_dir"]),
                datetime.now())
            if wp:
                print(f"주간 요약 저장: {wp}")
        except Exception as e:
            print(f"경고: 주간 요약 생성 실패(검사 결과는 정상): {e}", file=sys.stderr)


# 브리핑 폴더가 이만큼 커지면 알린다. 프로젝트 1개·하루 최대 13.1MB를 실측했다 —
# 5개면 1년에 24GB다. Drev는 산출물도, 자기 브리핑도 **지우지 않는다**(원칙 2) —
# 사람에게 알리고 정리는 사람이 한다 (2026-09-09 저장 검토 차단 4)
BRIEF_WARN_BYTES = 3 * 1024 ** 3
DB_WARN_BYTES = 8 * 1024 ** 3


def dir_size(path: Path) -> tuple[int, int]:
    """(바이트, 파일 수) — 폴더 하나만 센다(하위 폴더 포함)."""
    total = n = 0
    try:
        for f in path.rglob("*"):
            try:
                if f.is_file():
                    total += f.stat().st_size
                    n += 1
            except OSError:
                continue
    except OSError:
        pass
    return total, n


def _warn_disk(state: State, brief_dir: Path) -> None:
    """이력 파일·브리핑 폴더가 너무 커지면 사람에게 알린다."""
    rep = state.space_report()
    if rep["bytes"] >= DB_WARN_BYTES:
        print(f"경고: 이력 파일이 {rep['bytes'] / 1024 ** 3:.1f}GB입니다 — 설정의 "
              f"'보존 기간'을 줄이면 다음 검사 때 줄어듭니다 "
              f"(0=정리 안 함으로 두면 계속 커집니다).", file=sys.stderr)
    size, n = dir_size(brief_dir)
    if size >= BRIEF_WARN_BYTES:
        print(f"경고: 브리핑 폴더가 {size / 1024 ** 3:.1f}GB({n}개)입니다 — "
              f"{brief_dir}\n  Drev는 파일을 지우지 않습니다(읽기 전용). 오래된 "
              f"브리핑은 직접 지우거나 다른 디스크로 옮겨 주세요.", file=sys.stderr)


def _rotate_logs() -> None:
    """검사를 시작할 때 로그가 너무 크면 한 번 밀어낸다.

    상한이 없어 몇 년 쓴 설치본의 watcher.log가 수백 MB가 됐고, 화면·업데이트
    진단이 시작마다 그 파일을 통째로 읽었다 (2026-09-09 자동 실행 검토 중간 2)."""
    try:
        from watcher.logfile import rotate
        base = (Path(sys.executable).parent if getattr(sys, "frozen", False)
                else Path.cwd())
        for name in ("watcher.log", "run_daily.log"):
            rotate(base / name)
    except Exception:
        pass


SCAN_TROUBLE_KEY = "scan_trouble"     # {"at":ISO, "missing":[...], "fatal":bool}


def _note_scan_trouble(db_path: Path, missing: list[str], fatal: bool) -> None:
    """검사가 감시 폴더에 닿지 못한 사실을 state.db에 남긴다(없으면 지운다).

    화면(web.scan_health)이 이것을 읽어 지속 배너로 보여 준다 — 한 번 스쳐 사라지는
    문구로는 자동 실행이 실패한 날을 아무도 모른다."""
    import json
    try:
        with State(db_path) as st:
            if missing:
                st.set_meta(SCAN_TROUBLE_KEY, json.dumps(
                    {"at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                     "missing": missing[:8], "fatal": bool(fatal)}, ensure_ascii=False))
            else:
                st.set_meta(SCAN_TROUBLE_KEY, None)
    except Exception:
        pass              # 기록 실패가 검사를 막지는 않는다


def cmd_run(args: argparse.Namespace) -> int:
    # 검사가 돌기 전에 남아 있던 멈춤 요청은 무시 — 진행 표시가 첫 줄부터 나오므로
    # 여기서 지워야 한다 (2026-09-02: '준비 중' 표시에서 바로 멈추던 것)
    STOP.clear()
    # '같은 서버가 방금 실패했다'는 한 검사 안의 이야기다 — 창 프로세스에서는 아침의 SMTP 실패가
    # 낮의 [지금 검사]·보충 검사까지 모든 통을 침묵시켰다 (검토30 D 4-2, 같은 프로세스 4회 실측)
    _MAIL_STATE.update(down="", skipped=0, sent=0)
    _rotate_logs()
    cfg = load_config(Path(args.config))
    try:                                   # 설정 화면을 안 여는 PC의 평문 SMTP 비밀번호도 감싼다 (리뷰10)
        _pw_note = _protect_config_password(Path(args.config), cfg)
        if _pw_note:
            print(f"  {_pw_note}", flush=True)
    except Exception:
        pass
    if cfg.get("tag_pattern"):  # 회사별 태그 관례 재정의 (2026-08-26)
        from watcher.extract import base as _tag_base
        try:
            _tag_base.set_tag_pattern(str(cfg["tag_pattern"]))
        except re.error as e:
            print(f"경고: tag_pattern 정규식 오류({e}) — 기본 패턴 사용", file=sys.stderr)
    roots_cfg = [args.root] if args.root else cfg["roots"]
    if not roots_cfg:
        print("오류: 감시 폴더가 없습니다 — 설정 화면 또는 config.yaml의 roots에 추가하세요.",
              file=sys.stderr)
        return 2
    all_roots = [Path(r) for r in roots_cfg]
    all_labels = _root_labels(all_roots)
    missing = [(r, lb) for r, lb in zip(all_roots, all_labels) if not r.is_dir()]
    for m, _lb in missing:
        print(f"경고: 감시 폴더에 접근할 수 없음(이전 상태 이월): {m}", file=sys.stderr)
    roots = [r for r in all_roots if r.is_dir()]
    # 접근 못 한 폴더를 **화면이 알 수 있게** 기록한다. 지금까지는 stderr 한 줄뿐이라,
    # 네트워크 드라이브가 끊긴 채 07:00 배치가 며칠 실패해도 대시보드는 계속
    # "마지막 검사 …정상"이었다 (2026-09-09 웹 검토 차단 1). 배치는 다른 프로세스라
    # DB를 통해서만 화면에 닿는다
    _note_scan_trouble(Path(args.state_db or cfg["state_db"]),
                       [str(r) for r, _lb in missing],
                       fatal=not roots)
    if not roots:
        print("오류: 존재하는 감시 폴더가 하나도 없습니다.", file=sys.stderr)
        # 그날의 흔적을 브리핑 폴더에도 남긴다 — 복구 뒤엔 어디에도 "그날 검사가 안 됐다"가 없었다
        # (검토21 파일럿 중간 10). 스냅샷·메일은 만들지 않는다
        try:
            bdir = Path(args.brief_dir or cfg["brief_dir"])
            bdir.mkdir(parents=True, exist_ok=True)
            now_ = datetime.now()
            bp = _unique_brief(bdir / brief_filename(now_), now_)
            html_ = build_brief(
                [], now_, ", ".join(str(r) for r in all_roots),
                scan_errors=[(str(r) + "/", "감시 폴더에 접근할 수 없어 이날 검사를 하지 못했습니다 — "
                              "다음 검사에서 그동안의 변경을 다시 잡습니다") for r, _lb in missing],
                scanned_count=0)
            bp.write_text(html_, encoding="utf-8")
            print(f"브리핑 저장: {bp} (검사 못 한 날의 기록)")
            # 메일도 한 통 — 감시 폴더 전체가 끊긴 날이 받는 쪽에서 '조용한 날'과 똑같았다. 일부 폴더만
            # 끊긴 날은 메일이 나가는데 하나뿐인 감시 폴더가 끊기면 침묵했다 (검토25 브리핑 C-2, 원칙 5)
            if not getattr(args, "dry_run", False) and cfg.get("mail"):
                _deliver(cfg, {**cfg["mail"], "recipients": _recipients_for(cfg)},
                         f"[Drev] {now_.strftime('%Y-%m-%d')} 검사 못 함 — 감시 폴더 연결 안 됨 "
                         f"({len(missing)}개)", html_, bp)
        except Exception:
            pass
        return 2

    _set_progress("준비 중")
    # 경로 키는 항상 '폴더라벨/상대경로' — 폴더를 더하고 빼도 기존 키가 흔들리지 않는다.
    # 라벨은 설정의 전체 목록으로 매긴다 — 그날 안 붙은 폴더 때문에 남은 폴더의
    # 라벨(~2)이 바뀌면 안 된다
    labels = [lb for r, lb in zip(all_roots, all_labels) if r.is_dir()]
    db_path = Path(args.state_db or cfg["state_db"])
    try:
        state = State(db_path)
    except CorruptDatabase as e:
        # 날 traceback 대신 한국어 한 줄 + 되살리기 절차 위치 (검토19 운영 ①). 화면 배너용 기록은
        # DB 자체가 깨졌으므로 남길 수 없다 — 화면은 같은 예외를 잡아 전용 페이지를 낸다
        print(f"오류: {e}", file=sys.stderr)
        return 5
    with state:
        # 프로세스 간 잠금 — 자동 실행과 [지금 검사]가 겹치지 않게 (core H4)
        if not state.acquire_run_lock(os.getpid()):
            print("다른 검사가 이미 진행 중입니다(자동 실행 또는 다른 창) — "
                  "끝난 뒤 다시 시도하세요.", file=sys.stderr)
            _set_progress("")
            return 4
        try:
            return _cmd_run_locked(args, cfg, state, roots, labels, all_roots,
                                   [lb for _r, lb in missing])
        finally:
            state.release_run_lock(os.getpid())


def cmd_refresh_cache(args: argparse.Namespace) -> int:
    """판 교체 뒤 추출 기록(캐시)을 새 세대로 갱신 — 스냅샷·브리핑 없이 지금 파일만 다시 읽는다.

    세대가 다른 추출본은 섞어 비교하지 않으므로(2026-08-26), 세대가 오른 뒤 첫 검사는 그 사이
    바뀐 파일의 '이전 판' 기록이 옛 세대뿐이라 내용 비교를 통째로 건너뛰었다 — 실사용에서
    판을 올린 다음 날 아침이 정확히 그 경우였다 (검토25 감지 6-1). 교체 직후 이것을 돌려 두면
    다음 검사의 '이전 판'은 새 세대 기록이 된다. 검사와 같은 잠금을 쓴다."""
    if getattr(args, "to_log", False):
        # 판 교체 프로세스가 띄운 자식 — 로그를 스스로 append로 연다 (2회차 A5)
        try:
            _lf = open(Path.cwd() / "watcher.log", "a", encoding="utf-8", errors="replace", buffering=1)
            sys.stdout = sys.stderr = _lf
            print(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')} refresh-cache ===")
        except OSError:
            pass
    cfg = load_config(Path(args.config))
    if not cfg.get("roots"):
        return 0
    all_roots = [Path(r) for r in cfg["roots"]]
    all_labels = _root_labels(all_roots)
    roots = [r for r in all_roots if r.is_dir()]
    labels = [lb for r, lb in zip(all_roots, all_labels) if r.is_dir()]
    if not roots:
        return 0
    try:
        state = State(Path(args.state_db or cfg["state_db"]))
    except CorruptDatabase as e:
        print(f"오류: {e}", file=sys.stderr)
        return 5
    with state:
        if not state.acquire_run_lock(os.getpid()):
            print("다른 검사가 진행 중이라 추출 기록 갱신을 건너뜁니다 — 다음 검사가 바뀐 형식의 파일을 다시 읽습니다.")
            return 4
        try:
            snap = state.latest_snapshot()
            if not snap:
                return 0
            rd = RunData(cfg=cfg, roots=roots, labels=labels,
                         root_display=", ".join(str(r) for r in all_roots))
            rd.prev_files = state._latest_rows()
            print(f"Drev v{__version__} — 판 교체 뒤 추출 기록 갱신(세대 {_CACHE_VER}): "
                  f"파일 {len(snap)}개 확인")
            _scan_roots(rd, argparse.Namespace(full=False))
            # 지금 스냅샷에 있는 파일만(새로 생긴 파일은 다음 검사가 '추가'로 잡으며 그때 읽는다)
            rd.records = [r for r in rd.records if r.path in snap]
            _set_progress("2/3 내용 추출 (판 교체 뒤 기록 갱신)", 0, len(rd.records))
            _t0 = datetime.now(timezone.utc).isoformat()
            docs, failures = _extract_docs(state, rd.abs_of, rd.records, cfg)
            n = len(rd.records)
            # 레코드 수가 아니라 **실제로 다시 읽은** 수 — '128개 완료'가 0건 재추출을 가렸다 (검토32 A 1)
            n_new = state.conn.execute("SELECT COUNT(*) FROM extracts WHERE extracted_at >= ?", (_t0,)).fetchone()[0]
            print(f"추출 기록 갱신 완료: 다시 읽음 {n_new}개 / 그대로 {max(n - n_new, 0)}개 "
                  f"(읽기 실패 {len(failures)}개) — 스냅샷·브리핑은 만들지 않습니다")
            return 0
        except ScanCancelled:
            print("추출 기록 갱신을 중단했습니다.")
            return 3
        finally:
            _set_progress("")
            state.release_run_lock(os.getpid())


def _cmd_run_locked(args, cfg, state: State, roots, labels, all_roots, missing_labels) -> int:
    db_path = Path(args.state_db or cfg["state_db"])
    # 지난번에 스냅샷만 남기고 죽은 실행(창 닫힘·정전·업데이트)이 있으면 되돌린다 —
    # 그 변경은 이번 검사가 다시 감지해 브리핑에 싣는다 (core H1)
    stale = state.unfinished_run()
    if stale is not None:
        state.delete_run(stale)
        print(f"지난 검사(스냅샷 #{stale})가 보고를 마치지 못하고 끝나 있어 되돌렸습니다 — "
              f"그때의 변경은 이번 검사가 다시 감지합니다.")
    if True:
        rd = RunData(cfg=cfg, roots=roots, labels=labels,
                     root_display=", ".join(str(r) for r in all_roots),
                     missing_labels=list(missing_labels))
        rd.prev_files = state._latest_rows()  # 해시 단축·판 짝짓기용: 직전 스냅샷
        try:
            # 주 1회는 크기·저장 시각 단축 없이 전부 다시 해싱한다 — 타임스탬프를 보존하는
            # 복사(robocopy /COPY:DAT, PDM 체크인)·같은 크기 치환은 단축에 걸려 영영 못 봤다.
            # "변경 사실은 100% 잡는다"(원칙 5)가 코드로 보증되지 않던 것, 두 검토 연속
            # 지적 (2026-09-04, 검토19 원칙 ①). --full 없이도 7일마다 자동
            _last_full = state.get_meta("last_full_rehash")
            try:
                _age = (datetime.now(timezone.utc)
                        - datetime.fromisoformat(_last_full)).total_seconds() if _last_full else None
            except (TypeError, ValueError):
                _age = None
            if not getattr(args, "full", False) and (_age is None or _age > 7 * 86400):
                rd.force_full = True
                print("  이번 검사는 주 1회 전체 확인 — 크기·저장 시각이 같은 파일도 내용을 다시 읽습니다")
            excluded_carry = _scan_roots(rd, args)
            if rd.force_full or getattr(args, "full", False):
                state.set_meta("last_full_rehash", datetime.now(timezone.utc).isoformat())
        except ScanCancelled:
            # 스냅샷 전 — 기록한 것이 없으니 그냥 끝낸다
            print("검사를 중단했습니다 (파일 확인 단계). 기록된 것은 없습니다.")
            _set_progress("")
            return 3
        artifact_dirs = {PurePosixPath(r.path).parent for r in rd.records}

        # 그날 안 붙은 감시 폴더(네트워크 드라이브 끊김): 이전 상태를 그대로 이월한다 —
        # 조용히 빠졌다가 복귀 시 전부 '추가'로 재등록되고 그 사이 수정은 비교되지 않으며
        # 열린 이슈가 '삭제됨'으로 닫히던 것 (2026-09-04 검토 core H2)
        for lb in rd.missing_labels:
            rd.carry_paths += [k for k in rd.prev_files if k.startswith(lb + "/")]
            rd.scan_errors.append((lb + "/", "감시 폴더에 접근할 수 없어 이전 상태를 이월했습니다 "
                                   "(네트워크 드라이브 연결을 확인하세요)"))
        # 대량 삭제 보류: 직전 기록의 절반 넘게(20개 이상) 한 번에 사라지면 서버 순단·
        # 드라이브 문자 변경일 가능성이 크다 — 하루 보류하고 다음 검사에도 없으면 삭제로
        # 보고한다 (core H3 재검토 권고)
        current = {r.path for r in rd.records} | set(rd.carry_paths) \
            | {p for p, _ in rd.scan_errors} | set(excluded_carry)
        watched_prev = {k for k in rd.prev_files if k.split("/")[0] in labels}
        vanished = sorted(watched_prev - current)
        if len(vanished) >= 20 and len(vanished) > len(watched_prev) / 2:
            # 보류는 딱 하루 — 개수가 달라져도 다음 검사에는 보고한다 (재검토 ②-6)
            if state.get_meta("mass_removal_hold") is None:
                state.set_meta("mass_removal_hold", "1")
                rd.carry_paths += vanished
                rd.scan_errors.append(
                    ("(대량 삭제 보류)", f"파일 {len(vanished)}개가 한 번에 사라졌습니다 — "
                     f"서버 연결 문제일 수 있어 삭제 알림을 하루 보류합니다. 다음 검사에도 "
                     f"없으면 삭제로 보고합니다"))
                print(f"주의: 파일 {len(vanished)}개가 한 번에 사라져 삭제 알림을 보류했습니다.",
                      file=sys.stderr)
            else:
                state.set_meta("mass_removal_hold", None)
        elif state.get_meta("mass_removal_hold"):
            state.set_meta("mass_removal_hold", None)

        import json
        cur_exts = sorted({str(e).lower() for e in (rd.cfg.get("extensions") or ())})
        prev_exts_raw = state.get_meta("last_extensions")
        rd.snapshot_id, rd.changes = state.record_run(
            rd.records, carry_paths=[p for p, _ in rd.scan_errors] + excluded_carry
            + rd.carry_paths,
            known_prefixes=labels + list(rd.missing_labels),
            scanned_prefixes=labels)              # 실제로 검사한 라벨 — 폴더별 '첫 검사' 기록용
        state.mark_run_started(rd.snapshot_id)
        # 이번 검사에서 새로 켠 확장자 — 그 파일들의 '추가'는 변경이 아니라 등록이다
        # (2026-09-10 검토18: 묶음 단추로 106개를 켠 다음 날 PLC 파일 수백 건이
        # '추가'로 쏟아지던 것). 첫 검사(기준선)는 원래 전부 등록이므로 제외
        if prev_exts_raw is not None:
            try:
                prev_exts = {str(e).lower() for e in json.loads(prev_exts_raw)}
            except (ValueError, TypeError):
                prev_exts = set(cur_exts)
            new_exts = set(cur_exts) - prev_exts
            if new_exts:
                state.note_ext_baseline(new_exts, rd.snapshot_id)
                rd.reg_exts = set(new_exts)
                rd.reg_paths = {c.path for c in rd.changes if c.kind == "added"
                                and PurePosixPath(c.path).suffix.lower() in new_exts}
                if rd.reg_paths:
                    print(f"새로 켠 확장자({', '.join(sorted(new_exts))})의 파일 "
                          f"{len(rd.reg_paths)}개를 등록했습니다 — 변경이 아니라 기준선입니다")
        # 나중에 **추가한 감시 폴더**의 첫 검사도 같다 — 그 폴더의 '추가'는 등록이다. 화면은
        # 폴더별 첫 스냅샷으로 그렇게 세는데 브리핑·메일은 DB 전체의 첫 검사만 기준선으로 봐
        # "변경 113건 / 검토 필요 6건" 메일 초안을 만들었다 (2026-09-11 실사용 첫날). DB의 첫
        # 검사(전체가 기준선)는 제외. last_extensions 메타가 없는 구판 DB에서도 돈다 (검토20 A-10)
        if state.first_snapshot_id() != rd.snapshot_id:
            first_by_root = state.first_snapshot_by_root()
            rd.reg_roots = {r for r, s in first_by_root.items() if s == rd.snapshot_id and r != "*"}
            if rd.reg_roots:
                root_regs = {c.path for c in rd.changes if c.kind == "added"
                             and (c.path.split("/", 1)[0] if "/" in c.path else c.path) in rd.reg_roots}
                rd.reg_paths = set(rd.reg_paths) | root_regs
                if root_regs:
                    print(f"새로 추가한 감시 폴더({', '.join(sorted(rd.reg_roots))})의 파일 "
                          f"{len(root_regs)}개를 등록했습니다 — 변경이 아니라 기준선입니다")
        state.set_meta("last_extensions", json.dumps(cur_exts))
        _pair_moves(rd)
        print(f"Drev v{__version__} — 감시 폴더 {len(roots)}개: {rd.root_display}")
        print(f"산출물 폴더 {len(artifact_dirs)}개, 파일 {len(rd.records)}개 스캔 "
              f"(스냅샷 #{rd.snapshot_id})")

        try:
            rd.docs, rd.extract_failures = _extract_docs(state, rd.abs_of, rd.records, cfg)
            _compare_modified(state, rd)
            _pair_revisions(state, rd)
            # 프로젝트 단위 교차 검사는 변경이 있던 날만 (매일 같은 소음 방지)
            if rd.changes:
                # 짝짓기로 '이전 판'이 된 파일(revA가 디스크에 남은 경우)은 뺀다 —
                # 구판과 신판 사이의 '도면 간 불일치'는 거짓 경보다 (2026-09-02 재검토).
                # 복사본("(2)", "- 복사본")과 내용이 같은 중복 파일도 뺀다 — 근거가
                # 사본을 인용하고, 사본이 지워지면 링크가 깨졌다 (2026-09-03 검토)
                # 보고 단계(_report_and_send)와 같은 귀속기를 쓴다 — 다르면 이슈의 프로젝트
                # 이름이 어긋나 자동 해소가 영원히 안 된다 (2026-09-03 재검토)
                resolver = make_resolver(rd.cfg, rd.roots)
                sha_of = {r.path: r.sha256 for r in rd.records}
                seen_sha: set = set()
                _sheets_in = sheet_bases(rd.docs)
                paths_in = []            # 문서는 아직 적재하지 않는다 — 경로만 (core H5)
                for p_ in sorted(rd.docs,
                                 key=lambda k: (bool(_COPY_MARK.search(
                                     PurePosixPath(k).name)), k)):
                    pp_ = PurePosixPath(p_)
                    if p_ in rd.old_versions:
                        continue
                    # 사본 표식을 걷은 이름으로 견준다 — pair_key는 표식을 안 걷어 이 규칙이 죽어 있었고
                    # 편집 전 사본이 원본과 '도면 간 불일치'로 메일에 나갔다 (검토31 B5)
                    # 원본은 **표식 없는** 파일만 — 사본끼리 서로를 원본으로 삼아 둘 다 빠지면 그 번호가
                    # 교차 검사에서 통째로 사라졌다 (검토32 B1: 'E-160 (2)/(3)'만 남은 폴더)
                    if is_copy_marked(p_, _sheets_in) and any(
                            q != p_ and PurePosixPath(q).parent == pp_.parent
                            and not is_copy_marked(q, _sheets_in)
                            and pair_key(PurePosixPath(q).name) == pair_key(_COPY_MARK.sub("", pp_.name))
                            for q in rd.docs):
                        continue        # 원본이 같은 폴더에 있는 복사본만 제외
                    paths_in.append(p_)
                # 표제란 있는 도면으로 폴더의 프로젝트를 먼저 배운다 — '2026 수주/삼성 3라인/BOM'
                # 같은 묶음 폴더의 BOM이 도면과 다른 프로젝트로 갈려 도면-BOM 검사에서 조용히
                # 빠지던 것 (검토22 실용 D1). 배운 표는 보고 단계·화면도 같이 쓴다
                # 여기부터 보고·정리까지는 파일 단위 진행이 없다 — 마지막 파일 이름과 시계가 그대로
                # 흘러 '지금: <파일> (300초째)'가 빨갛게 떴다 (v0.57.4 재검토 3-⑤ b, '얼어붙음' 후보)
                _set_progress("3/3 교차 검사 (도면 간·도면-BOM)", 0, 0, "")
                for p_ in paths_in:
                    resolver.learn(p_, rd.docs.get(p_))
                rd.folder_votes = resolver.folder_votes
                _save_folder_votes(state, resolver.folder_votes)

                def _proj_of(p_, d_):
                    # 프로젝트가 없는 파일(미분류)이나 '도면/BOM/공용' 같은 구조 폴더 이름을
                    # 프로젝트로 삼은 것은 묶지 않는다 — 무관한 도면끼리 비교되는 오탐
                    # (2026-09-03 재검토)
                    proj_, why_ = resolver.attribute(p_, d_)
                    if why_ == "미분류":
                        return None
                    if why_ == "폴더 구조" and (
                            proj_ in rd.labels or looks_like_doctype_folder(proj_, rd.cfg)
                            or proj_ in _COMMON_FOLDERS):
                        return None
                    return proj_
                _proj = _proj_of
                # 이름에 판을 붙인 구판 — 짝지은 날뿐 아니라 늘(2회차 B7). 귀속을 배운 뒤 **프로젝트별로**
                # 정한다 — 루트의 양식 한 장이 아래 모든 프로젝트의 같은 번호를 밀어냈다 (검토31 B2)
                superseded = _superseded_paths(rd, project_of=lambda p_: _proj_of(p_, rd.docs.get(p_)))
                paths_in = [p_ for p_ in paths_in if p_ not in superseded]
                # 같은 폴더의 같은 내용 파일은 하나만 — 구판 제외 **뒤에** 한다. 앞에서 하면 편집 전에 복사해 둔
                # 다음 판(revB = revA와 같은 바이트)이 먼저 지워지고 _cmp가 revA를 구판이라 또 지워 그 번호가
                # 교차 검사에서 통째로 사라졌다 (검토32 D 1-1, v0.57.12 회귀)
                _dedup: list = []
                for p_ in paths_in:
                    key_ = (str(PurePosixPath(p_).parent), sha_of.get(p_))
                    if key_ in seen_sha:
                        continue
                    seen_sha.add(key_)
                    _dedup.append(p_)
                paths_in = _dedup
                # 프로젝트별로 묶어 그 묶음의 문서만 적재해 검사한다 — 4만 파일의 추출본을
                # 통째로 올리면 +1.4GB, 실서버는 몇 배 (2026-09-04 검토 core H5)
                from watcher.consistency import _canon_project
                by_proj: dict = {}
                for p_ in paths_in:
                    raw_ = _proj(p_, rd.docs.get(p_))
                    key_ = _canon_project(raw_) if raw_ else None
                    if key_:
                        by_proj.setdefault(key_, []).append(p_)
                rd.checked_projects = set(by_proj)
                # 이월된 파일(끊긴 폴더·못 읽은 폴더)이 속한 프로젝트는 이번에 다 본 게
                # 아니다 — 그 프로젝트의 열린 이슈를 '재검출되지 않음'으로 닫지 않게
                # (2026-09-04 재검토 ②-4)
                for p_ in rd.carry_paths:
                    raw_ = resolver.attribute(p_, None)[0]
                    key_ = _canon_project(raw_) if raw_ else None
                    rd.checked_projects.discard(key_)
                for key_, paths_ in sorted(by_proj.items()):
                    docs_p = [(p_, rd.docs[p_]) for p_ in paths_ if p_ in rd.docs]
                    rd.issues += check_project_consistency(
                        docs_p, project_of=lambda _p, _d, _k=key_: _k)
                    del docs_p
            _set_progress("3/3 변경 자리 사진", 0, 0, "")
            _collect_text_captures(rd)
            _set_progress("3/3 브리핑·메일 작성", 0, 0, "")
            _report_and_send(args, cfg, state, rd)
            state.mark_run_finished()
            _set_progress("마무리 (백업·정리)", 0, 0, "")
            _housekeep(state, cfg, args, skip_weekly=getattr(rd, "is_baseline", False))
        except ScanCancelled:
            # 사람이 멈췄다 — 스냅샷을 되돌려 다음 검사가 같은 변경을 다시 잡게
            state.delete_run(rd.snapshot_id)
            print("검사를 중단했습니다 — 이번 스냅샷을 되돌렸습니다. "
                  "변경은 유실되지 않으며 다음 검사가 다시 감지합니다.")
            _set_progress("")
            return 3
        except Exception as e:
            # 보고를 못 했으면 스냅샷을 되돌린다 — 다음 실행이 같은 변경을 다시
            # 감지·보고하도록. 커밋만 하고 죽으면 알림이 영구 유실된다 (PRINCIPLE 5)
            state.delete_run(rd.snapshot_id)
            print(f"오류: 보고 단계 실패 — 이번 스냅샷을 롤백했습니다. "
                  f"다음 실행에서 변경을 다시 감지합니다.\n  사유: {e}", file=sys.stderr)
            _set_progress("")
            return 1
    _set_progress("")
    return 0


def cmd_ack_serve(args: argparse.Namespace) -> int:
    from watcher.ack_server import serve
    cfg = load_config(Path(args.config))
    db_path = Path(args.state_db or cfg["state_db"])
    # 포트는 ack_url이 기준 — 메일 링크와 서버가 어긋나지 않게 한 곳에서만 정한다
    port = args.port or urlparse(cfg["ack_url"]).port or 8765
    serve(db_path, port=port)
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    cfg = load_config(Path(args.config))
    db_path = Path(args.state_db or cfg["state_db"])
    with State(db_path) as state:
        rows = state.history(args.project)
    if not rows:
        print("이력 없음." + (f" (프로젝트 {args.project})" if args.project else ""))
        return 0
    for r in rows:
        ack = (f"확인: {r['ack_by']} ({r['ack_at'][:16]})"
               + (f" — {r['ack_note']}" if r['ack_note'] else "")) \
            if r["ack_by"] else "미확인"
        print(f"#{r['change_id']:>4} {r['detected_at'][:16]} "
              f"[{KIND_LABEL[r['kind']]}] [{r['project'] or '미분류'}] {r['path']}  | {ack}")
    return 0


def _ask(prompt: str) -> str:
    try:
        return input(prompt).strip().strip('"')
    except EOFError:
        return ""


def _wizard_make_config(cfg_path: Path) -> bool:
    print("처음 실행이시네요. 딱 하나만 물어볼게요.\n")
    print("감시할 루트 폴더 경로를 입력하세요.")
    print(r"  예: \\fileserver\projects  또는  D:\projects")
    for _ in range(3):
        root = _ask("\n루트 폴더: ")
        if not root:
            print("입력이 없어 설정을 만들지 않고 종료합니다.")
            return False
        if Path(root).is_dir():
            break
        print(f"  폴더를 찾을 수 없습니다: {root}  (다시 입력해주세요)")
    else:
        return False
    write_initial_config(root, cfg_path)
    print(f"\n설정 저장됨: {cfg_path.resolve()}")
    print("(메일 발송은 꺼진 상태로 시작합니다 — 브리핑은 briefs 폴더에 저장됩니다)")
    return True


_TASK_NAME = "ProjectWatcher"


def _daily_bat_text(root: Path | None = None) -> str:
    """매일 실행 배치 내용. exe면 exe를, 소스 실행이면 현재 파이썬을 그대로 쓴다 —
    다른 PC의 개발 경로를 하드코딩하지 않는다 (2026-08-25 UX 검토).
    root: 포터블을 다른 폴더로 옮긴 뒤 그 위치로 등록할 때 (2026-09-04)."""
    if root is not None and (root / "python" / "python.exe").is_file():
        run_line = (f'"{root / "python" / "python.exe"}" '
                    f'"{root / "app" / "entry.py"}" run')
    elif getattr(sys, "frozen", False):
        run_line = f"\"{Path(sys.executable).name}\" run"  # exe 이름 변경에도 안전
    elif Path(sys.executable).name.lower().startswith("drev"):
        # 포터블: 루트의 pythonw 사본(Drev.exe)은 무인자일 때 화면을 띄우는
        # 자동부트가 있어 자동 실행엔 python 원본을 쓴다 (2026-08-30 검토)
        root = Path(sys.executable).parent
        run_line = (f'"{root / "python" / "python.exe"}" '
                    f'"{root / "app" / "entry.py"}" run')
    else:
        repo = Path(__file__).resolve().parent.parent
        run_line = (f'set PYTHONPATH={repo};%PYTHONPATH%\r\n'
                    f'"{sys.executable}" -m watcher.cli run')
    return ('@echo off\r\ncd /d "%~dp0"\r\n'
            f"{run_line} >> run_daily.log 2>&1\r\n")


# 창 모드 앱에서 콘솔 프로그램(schtasks 등)을 부르면 검은 창이 깜빡인다 —
# CREATE_NO_WINDOW로 막는다 (2026-09-02: 설정 화면 진입마다 창이 떴다)
_NO_WINDOW = 0x08000000


# 예약이 못 돈 날의 설명 — 화면·도움말·설치안내·사이트가 한 문장을 쓴다. "놓치면 다음에 켜질 때 바로"는
# 09-16에 거짓으로 판명됐다(대화형 로그온 작업은 로그오프 상태의 회차를 되살리지 않는다, 검토30 D 2-1)
CATCH_UP_NOTE = ("""로그인된 상태여야 돌며, 절전 중이면 깨워서 실행합니다. 재부팅·절전으로 그 시각을 놓친 날은 Drev 창을 여는 순간 대신 검사합니다.""")


def schedule_disabled() -> bool:
    """등록은 돼 있는데 '사용 안 함'으로 꺼 둔 작업인가 (schtasks 상세의 Status/상태 칸).
    schedule_status()는 rc만 보므로 꺼 둔 PC에서도 True다 — 보충 검사는 이걸 더 본다 (검토30 D 1-4)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception:
        return False
    if q.returncode != 0:
        return False
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" \
        else q.stdout.decode("utf-8", "replace")
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if sep and head.strip().lower() in ("status", "상태", "scheduled task state", "예약된 작업 상태"):
            v = val.strip().lower()
            if v in ("disabled", "사용 안 함", "사용 안함"):
                return True
    return False


def schedule_status() -> bool:
    """작업 스케줄러에 ProjectWatcher가 등록돼 있는가."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME],
                           capture_output=True, timeout=15,
                           stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
        return q.returncode == 0
    except Exception:
        return False


def _schedule_action(root: Path | None = None) -> tuple[str, str, str] | None:
    """콘솔 창 없이 도는 작업 동작 (실행 파일, 인수, 작업 폴더). 없으면 None → 배치 사용.

    배치(cmd)로 등록하면 07시에 검은 창이 떴다. 포터블·설치판은 pythonw + entry.py, exe는
    자기 자신 — 둘 다 창 없이 돌고 출력은 entry.py가 watcher.log로 돌린다 (2026-09-05)."""
    base = root
    if base is None:
        exe = Path(sys.executable)
        if getattr(sys, "frozen", False):
            return str(exe), "run", str(exe.parent)
        if exe.name.lower().startswith("drev"):
            base = exe.parent
    if base is not None:
        pyw, entry = base / "python" / "pythonw.exe", base / "app" / "entry.py"
        if pyw.is_file() and entry.is_file():
            return str(pyw), f'"{entry}" run', str(base)
    return None


def _ps_quote(s: str) -> str:
    return "'" + "''".join(str(s).split("'")) + "'"     # 작은따옴표는 두 개로


def _schedule_tune(time_str: str, action: tuple[str, str, str] | None) -> tuple[bool, str]:
    """schtasks /Create가 못 정하는 조건을 PowerShell로 맞춘다: 배터리에서도 실행, 절전이면
    깨움, 그 시각을 놓치면 다음 켜질 때 바로 실행, 6시간 상한, 중복 실행 금지. 그리고 동작을
    창 없는 실행 파일로 바꾼다 (2026-09-05: 노트북·절전 PC에서 조용히 빠지던 날들)."""
    lines = [
        "$s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries "
        "-StartWhenAvailable -WakeToRun -MultipleInstances IgnoreNew "
        "-ExecutionTimeLimit (New-TimeSpan -Hours 6)",
    ]
    if action is not None:
        prog, args, wd = action
        lines.append(f"$a = New-ScheduledTaskAction -Execute {_ps_quote(prog)} "
                     f"-Argument {_ps_quote(args)} -WorkingDirectory {_ps_quote(wd)}")
        lines.append(f"Set-ScheduledTask -TaskName {_ps_quote(_TASK_NAME)} -Action $a -Settings $s | Out-Null")
    else:
        lines.append(f"Set-ScheduledTask -TaskName {_ps_quote(_TASK_NAME)} -Settings $s | Out-Null")
    script = "; ".join(lines)
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-Command", script],
                           capture_output=True, timeout=60, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception as e:
        return False, str(e)
    if r.returncode != 0:
        return False, (r.stderr or b"").decode("mbcs", "replace")[-300:]
    return True, ""


def _task_exe_of(task_to_run: str) -> str:
    """'C:\\x\\pythonw.exe "C:\\x\\app\\entry.py" run' → 실행 파일 경로."""
    s = task_to_run.strip()
    if s.startswith('"'):
        return s[1:].split('"', 1)[0]
    m = re.match(r"(.+?\.(?:exe|bat|cmd))(?:\s|$)", s, re.I)
    return m.group(1) if m else s


def schedule_start_time() -> str | None:
    """등록된 작업의 시작 시각 'HH:MM' (schtasks 상세 조회). 모르면 None.
    화면이 config의 시각만 보여 주면 구판·수동으로 바뀐 등록과 어긋난다 (검토19 운영 ⑦)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception:
        return None
    if q.returncode != 0:
        return None
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" \
        else q.stdout.decode("utf-8", "replace")
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if sep and head.strip().lower() in ("start time", "시작 시간"):
            m = re.search(r"(\d{1,2}):(\d{2})", val)
            if not m:
                return None
            h, mi = int(m.group(1)), int(m.group(2))
            v = val.lower()
            if ("pm" in v or "오후" in v) and h < 12:
                h += 12
            if ("am" in v or "오전" in v) and h == 12:
                h = 0
            return f"{h:02d}:{mi:02d}"
    return None


def schedule_target() -> str | None:
    """등록된 작업이 실행하는 파일 경로 (schtasks 상세 조회). 모르면 None.
    옮긴 뒤 옛 폴더를 가리키는 등록을 화면이 '정상'으로 보이던 것 (2026-09-04)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception:
        return None
    if q.returncode != 0:
        return None
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" \
        else q.stdout.decode("utf-8", "replace")
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if sep and head.strip().lower() in ("task to run", "실행할 작업"):
            return _task_exe_of(val)
    return None


def schedule_register(time_str: str = "07:00", root: Path | None = None) -> tuple[bool, str]:
    """매일 자동 실행 등록. run_daily.bat을 (없거나 낡았으면) 새로 쓰고 등록한다.
    root: 배치를 둘 폴더(기본 현재 폴더) — 설치로 옮긴 새 위치에 등록할 때."""
    bat = (root or Path.cwd()) / "run_daily.bat"
    text = _daily_bat_text(root)
    action = _schedule_action(root)
    bat_ok, bat_why = True, ""
    try:
        # cmd는 배치를 ANSI(cp949)로 읽는다 — utf-8로 쓰면 경로에 한글이 있을 때 깨짐.
        # cp949로 표현 불가한 문자는 조용히 지우지 말고(bat 파손) 등록을 거부한다
        if not bat.exists() or bat.read_text(encoding="mbcs",
                                             errors="ignore") != text:
            bat.write_text(text, encoding="mbcs", errors="strict")
    except UnicodeEncodeError:
        bat_ok, bat_why = False, ("경로에 한글/영문 외 특수문자가 있어 배치 파일을 "
                                 "만들 수 없었습니다")
    except OSError as e:
        bat_ok, bat_why = False, f"배치 파일을 쓸 수 없었습니다 ({e})"
    # 배치를 못 써도 **창 없는 동작**이 있으면 그것으로 바로 등록한다. 전에는 여기서
    # 거부해 schtasks를 부르지도 않았고, 정작 등록되는 동작은 _schedule_tune이
    # pythonw+entry.py로 갈아치우는 것이라 배치는 쓰이지도 않았다 — 쓰기 제한된
    # 폴더에 설치하면 자동 실행을 아예 못 켰다 (2026-09-09 자동 실행 검토 낮음 10)
    if not bat_ok and action is None:
        return False, (f"등록 실패: {bat_why} — 설치 폴더를 쓸 수 있는 곳으로 "
                       f"옮기거나 권한을 확인해주세요.")
    tr = f'"{bat}"' if bat_ok else f'"{action[0]}" {action[1]}'
    try:
        r = subprocess.run(["schtasks", "/Create", "/TN", _TASK_NAME,
                            "/TR", tr, "/SC", "DAILY",
                            "/ST", time_str, "/F"],
                           capture_output=True, timeout=15,
                           stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception as e:
        return False, f"등록 실패: {e}"
    if r.returncode == 0:
        ok, why = _schedule_tune(time_str, action)
        if ok:
            return True, (f"등록 완료 — 매일 {time_str}에 자동 검사합니다. " + CATCH_UP_NOTE
                          + " 배터리 상태에서도 돌며, 창은 뜨지 않습니다.")
        return True, (f"등록 완료 — 매일 {time_str}에 자동 검사합니다. 다만 절전·배터리 조건을 "
                      f"바꾸지 못해 그 시각에 PC가 켜져 있고 전원이 연결돼 있어야 하며, 실행 때 검은 창이 "
                      f"잠깐 뜹니다 ({why.strip()[:120]})")
    return False, ("등록 실패 (권한 문제일 수 있음) — 프로그램을 마우스 오른쪽 클릭 → "
                   "'관리자 권한으로 실행'한 뒤 다시 시도해보세요.")


def schedule_unregister() -> tuple[bool, str]:
    try:
        r = subprocess.run(["schtasks", "/Delete", "/TN", _TASK_NAME, "/F"],
                           capture_output=True, timeout=15,
                           stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception as e:
        return False, f"해제 실패: {e}"
    return (r.returncode == 0,
            "자동 실행을 해제했습니다." if r.returncode == 0 else "해제 실패 — 이미 없거나 권한 문제입니다.")


def _wizard_schedule(exe_dir: Path) -> None:
    if schedule_status():
        return  # 이미 등록됨
    ans = _ask("\n매일 아침 07:00 자동 실행을 등록할까요? (y/n): ").lower()
    if ans != "y":
        print("나중에 화면의 [설정] → 자동 실행에서 등록할 수 있습니다.")
        return
    ok, msg = schedule_register()
    print(msg)


def run_wizard() -> int:
    """더블클릭(인수 없음) 진입점: 설정 → 스캔 → 자동 실행 등록까지 안내."""
    if getattr(sys, "frozen", False):
        os.chdir(Path(sys.executable).parent)
    print("=" * 46)
    print(" Drev — 산출물 변경 감시자")
    print("=" * 46)
    cfg_path = Path("config.yaml")
    first_time = not cfg_path.exists()
    if first_time and not _wizard_make_config(cfg_path):
        _ask("\n종료하려면 Enter를 누르세요...")
        return 1

    print("\n--- 스캔 실행 ---")
    args = argparse.Namespace(config="config.yaml", root=None, state_db=None,
                              brief_dir=None, dry_run=False)
    rc = cmd_run(args)
    if rc == 0:
        if first_time:
            print("\n첫 실행은 기준선 확보라 전체 파일이 '추가'로 기록됩니다.")
            print("내일부터는 바뀐 것만 브리핑에 올라옵니다.")
        _wizard_schedule(Path.cwd())
        cfg = load_config(cfg_path)
        brief_dir = Path(cfg["brief_dir"])
        if brief_dir.is_dir() and sys.stdin.isatty():
            try:
                os.startfile(brief_dir)  # 브리핑 폴더를 탐색기로 보여준다
            except OSError:
                pass
        print(f"\n브리핑 위치: {brief_dir.resolve()}")
    _ask("\n종료하려면 Enter를 누르세요...")
    return rc


def cmd_uninstall(args) -> int:
    """바로가기·제거 목록 등록만 지운다 — 이력(state.db)은 남긴다.

    폴더까지 지울지는 사람이 판단한다(원칙 5). 프로그램이 자기 데이터를 말없이
    지우면 되돌릴 수 없기 때문."""
    from watcher.install import uninstall
    r = uninstall()
    ok_s, _m = schedule_unregister()     # 매일 실행 작업이 남아 지운 폴더를 매일 부르던 것
    if ok_s:
        print("매일 자동 실행 등록을 해제했습니다.")
    print(f"바로가기 {r['shortcuts']}개 제거, 프로그램 목록 등록 "
          f"{'해제됨' if r['registry'] else '없음'}.")
    print(f"이력·설정은 그대로 남아 있습니다: {r['folder']}")
    print("완전히 지우려면 위 폴더를 삭제하세요.")
    return 0


def main(argv: list[str] | None = None) -> int:
    if (argv if argv is not None else sys.argv[1:]) == []:
        # 더블클릭 진입점: 웹 대시보드(브라우저). 실패 시 콘솔 위저드 폴백
        try:
            from watcher.web import run_web
            return run_web()
        except SystemExit:
            raise
        except Exception as e:
            print(f"화면 실행 실패({e}) — 콘솔 모드로 전환합니다.", file=sys.stderr)
            return run_wizard()
    parser = argparse.ArgumentParser(prog="watcher", description="프로젝트 산출물 변경 감시자")
    parser.add_argument("--config", default="config.yaml")
    # 자동 업데이트가 내려받은 실행 파일이 이 PC에서 정말 실행되는지(SAC 차단 여부
    # 포함) 확인하는 데도 쓴다 — 교체 전에 한 번 돌려본다 (2026-08-31)
    parser.add_argument("--version", action="version",
                        version=f"Drev {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="config.yaml 생성")
    p_init.set_defaults(func=cmd_init)

    p_run = sub.add_parser("run", help="스캔 1회 실행")
    p_run.add_argument("--root", help="config의 root_path 대신 사용할 루트")
    p_run.add_argument("--state-db", help="config의 state_db 대신 사용할 DB 경로")
    p_run.add_argument("--brief-dir", help="config의 brief_dir 대신 사용할 브리핑 저장 폴더")
    p_run.add_argument("--dry-run", action="store_true", help="메일 발송 없이 브리핑 HTML만 저장")
    p_run.add_argument("--full", action="store_true",
                       help="크기·수정시각 단축 없이 전체 파일을 다시 해싱 (주기 점검용)")
    p_run.set_defaults(func=cmd_run)

    # 판 교체 직후 selfupdate가 부른다 — 추출 기록만 새 세대로 (검토25 감지 6-1)
    p_rc = sub.add_parser("refresh-cache", help=argparse.SUPPRESS)
    p_rc.add_argument("--state-db", default=None)
    p_rc.add_argument("--to-log", action="store_true")
    p_rc.set_defaults(func=cmd_refresh_cache)

    # 윈도우 '프로그램 추가/제거'가 부르는 제거 명령 (2026-08-31)
    p_uni = sub.add_parser("uninstall", help="바로가기·프로그램 목록 등록 정리")
    p_uni.set_defaults(func=cmd_uninstall)

    p_ack = sub.add_parser("ack-serve", help="5초 확인 로컬 웹 서버 (127.0.0.1)")
    p_ack.add_argument("--state-db", help="config의 state_db 대신 사용할 DB 경로")
    p_ack.add_argument("--port", type=int, default=None,
                       help="기본값: config ack_url의 포트")
    p_ack.set_defaults(func=cmd_ack_serve)

    p_hist = sub.add_parser("history", help="변경·확인 이력 조회")
    p_hist.add_argument("--state-db", help="config의 state_db 대신 사용할 DB 경로")
    p_hist.add_argument("--project", help="프로젝트 번호로 필터 (예: P24-031)")
    p_hist.set_defaults(func=cmd_history)

    # 내용 추출 자식 프로세스 (검사가 내부적으로 띄운다 — 사람이 직접 쓰지 않음)
    p_wk = sub.add_parser("extract-worker", help=argparse.SUPPRESS)
    p_wk.set_defaults(func=lambda a: __import__("watcher.worker", fromlist=["serve"]).serve())

    args = parser.parse_args(argv)
    try:
        rc = args.func(args)
    except ConfigError as e:
        # 예약 검사(콘솔 없음)가 설정 파일 탭·문법 오류에 날 traceback으로 죽었다 (검토21 운영 1)
        print(f"오류: {e}", file=sys.stderr)
        return 2
    except sqlite3.DatabaseError as e:
        # 머리 페이지는 멀쩡하고 안쪽이 깨진 이력 파일은 열린 뒤 첫 질의에서 터진다 (검토21 운영 2)
        print(f"오류: 이력 파일(state.db)이 손상되었습니다 — {e}. 되살리는 순서는 도움말의 "
              f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다 (state.db-wal을 먼저 지워야 합니다).",
              file=sys.stderr)
        return 5
    if args.command == "run" and rc == 0 and not getattr(args, "dry_run", False):
        # 명령줄(예약 작업)로 돈 검사만 — 창의 [지금 검사]는 cmd_run을 직접 부르므로 여기를 지나지 않는다
        msg = auto_update_after_run(Path(args.config))
        if msg:
            print(msg)
    return rc


def auto_update_after_run(config_path: Path) -> str:
    """예약 검사(창 없음)가 끝난 뒤 새 판이 있으면 스스로 내려받아 검증하고, 이 프로세스가 끝나면
    교체한다 — 화면을 열어 [설치]를 누르는 사람이 없는 설치본은 영영 옛 판이었다
    (2026-09-11 "자동 업데이트가 안되는중"). config `auto_update: false`로 끈다.
    창이 떠 있으면 미룬다(창에 [설치]가 있고, 창이 쓰는 파일을 밑에서 갈지 않기 위해).
    돌려주는 값은 로그용 한 줄(없으면 빈 문자열). 어떤 실패도 검사 결과(rc)에 얹지 않는다."""
    try:
        cfg = load_config(config_path)
    except BaseException:
        return ""
    if not cfg.get("auto_update", True) or not cfg.get("update_check", True):
        return ""
    try:
        from watcher import selfupdate as _su
        from watcher.web import PORTABLE_URL, UPDATE_URL, check_update
        root = _su.install_root()
        if root is None:
            return ""
        url = cfg.get("update_url") or UPDATE_URL
        if not _su.url_ok(url):
            return ""
        info = check_update(__version__, url)
        if not info:
            return ""
        ver = info.get("version", "")
        why = _su.recent_failure(root, ver)
        if why:
            # 같은 판이 최근에 실패했다 — 매일 55MB를 다시 받아 교체·원복을 반복하지 않는다 (검토20 중간 2)
            return (f"[update] 새 판 v{ver}의 자동 업데이트가 최근 실패해({why[:120]}) "
                    f"{_su.FAILED_RETRY_DAYS}일간 다시 시도하지 않습니다 — 창의 [설치]로는 바로 시도할 수 있습니다")
        wr = _su.window_running(root)
        if wr is not False:
            return (f"[update] 새 판 v{ver}이 있지만 "
                    + ("창이 떠 있어" if wr else "창 실행 여부를 확인할 수 없어")
                    + " 무인 교체는 다음 예약 검사 때 다시 시도합니다 — 창 왼쪽 메뉴의 [설치]를 누르면 바로 됩니다")
        sha = info.get("sha256") or {}
        # 내려받는 수 분 동안도 '교체 중' 표식을 둔다 — 이때 켜진 창의 정리가 .update를 지워
        # 내려받기가 깨지고 거짓 실패 기록이 남았다 (검토20 재검증 ③). 교체 프로세스가 이어받는다
        try:
            (root / _su.APPLYING_MARK).write_text(str(os.getpid()), encoding="utf-8")
        except OSError:
            pass
        _su.run_update(root, info.get("portable") or PORTABLE_URL, ver, exit_after=False,
                       app_url=info.get("app", ""), remote_runtime=info.get("runtime", ""),
                       app_sha=sha.get("app", ""), portable_sha=sha.get("portable", ""),
                       relaunch=False,
                       # 교체 직전에 다른 검사가 돌고 있는지 볼 이력 DB — 업데이트 모듈은 스스로 설정을
                       # 읽지 않으므로 여기서 넘긴다
                       lock_db=str(Path(cfg["state_db"]).resolve()))
        if _su.PROGRESS.get("error"):
            _su._rm(root / _su.APPLYING_MARK)      # 교체 프로세스가 뜨지 않았다 — 표식은 내 것
            return f"[update] 무인 교체 실패 — {_su.PROGRESS['error']} (이전 판 그대로)"
        return (f"[update] 새 판 v{ver} 내려받아 검증함 — 이 검사가 끝나는 대로 교체합니다 "
                f"(창은 열지 않음, 이력·설정 그대로)")
    except Exception as e:
        return f"[update] 무인 교체를 시도하지 못했습니다(무시): {type(e).__name__}: {e}"


if __name__ == "__main__":
    sys.exit(main())
