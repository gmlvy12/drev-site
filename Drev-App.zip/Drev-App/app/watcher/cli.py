# -*- coding: utf-8 -*-
"""CLI: run / init / history (+ 화면·설치용 명령).

사용:
  python -m watcher.cli init                # config.example.yaml → config.yaml
  python -m watcher.cli run [--dry-run]     # 스캔 → 브리핑 생성 (+ 설정 시 메일)
  python -m watcher.cli history [--project] # 변경·확인 이력 조회
"""

from __future__ import annotations

import argparse
from collections import OrderedDict
from collections.abc import Mapping
import contextlib
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
import unicodedata
from collections import Counter
from dataclasses import dataclass
from dataclasses import field as dc_field
from datetime import datetime, timedelta, timezone
from html import escape as html_escape
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

import yaml

from watcher import __version__
from watcher.brief import brief_counts, brief_filename, build_brief, items_for
from watcher.consistency import CODE_LABEL, Issue, check_project_consistency, check_revision
from watcher.diff import ChangeItem, diff_documents
from watcher.doctype import HINTS, content_hint, kind_of, looks_like_doctype_folder
from watcher.extract import extract
from watcher.extract.base import Document, clean_text
from watcher.mail import send_brief
from watcher.project import ProjectResolver
from watcher.convert import converted_many, resolve as resolve_converter
from watcher.render import RENDER_EXTS, render_dxf, render_file
from watcher.scan import DEFAULT_EXTENSIONS, is_excluded, pair_key, scan
from watcher.state import KIND_LABEL, CorruptDatabase, State
from watcher.issued import po_marked as _po_marked  # 발주 후 변경 표지 (기능 검토 2026-11-02 J8)

# PyInstaller exe에서는 예시 설정이 임시 해제 폴더(_MEIPASS)에 번들된다
if getattr(sys, "frozen", False):
    PROJECT_DIR = Path(getattr(sys, "_MEIPASS", "."))
else:
    PROJECT_DIR = Path(__file__).resolve().parent.parent

_CONFIG_DEFAULTS = {
    "extensions": list(DEFAULT_EXTENSIONS),
    "state_db": "state.db",
    "brief_dir": "briefs",
    "mail": {"enabled": False},
    "aliases": "aliases.yaml",
    "projects": {},
    "ack_url": "http://127.0.0.1:8765",
    "exclude": [],
}


class ConfigError(Exception):
    """config.yaml을 읽을 수 없다 — 사람이 고쳐야 하는 오류 (사유 포함)."""


def _parse_config_text(raw: bytes, path: Path) -> dict:
    """YAML 해석. utf-8이 아니면 cp949(메모장 ANSI 저장)로 다시 시도하고, 문법 오류는
    몇 행인지 한국어로 알려준다 — 창 모드에서는 콘솔이 없어 '더블클릭해도 안 뜸'만
    남았다 (2026-09-04 검토 ops M1)."""
    text = None
    for enc in ("utf-8-sig", "cp949"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ConfigError(f"{path.name}의 글자 인코딩을 읽을 수 없습니다 — "
                          f"메모장에서 'UTF-8'로 다시 저장해주세요.")
    try:
        cfg = yaml.safe_load(text) or {}
    except yaml.YAMLError as e:
        mark = getattr(e, "problem_mark", None)
        where = f" {mark.line + 1}행" if mark is not None else ""
        hint = " (탭 문자는 쓸 수 없습니다 — 공백으로 들여쓰세요)" if "\t" in text else ""
        raise ConfigError(f"{path.name}{where}에 문법 오류가 있습니다{hint}: "
                          f"{getattr(e, 'problem', None) or e}") from e
    if not isinstance(cfg, dict):
        raise ConfigError(f"{path.name}의 내용이 설정 형식이 아닙니다 — 'roots:' 등 "
                          f"키: 값 꼴이어야 합니다.")
    return cfg


import threading as _threading_cfg

# 설정 파일 읽기·쓰기를 한 프로세스 안에서 줄 세운다 — 화면의 저장 두 개가 겹쳐 config.yaml이 통째로 날아갔고, 저장 중에
# [지금 검사]가 빈 파일을 읽어 '감시 폴더가 없습니다'로 끝났다 (검토64 B1·B3)
CONFIG_LOCK = _threading_cfg.RLock()


def write_config_text(path, text: str) -> None:
    """설정 파일을 제자리에 덮어쓴다 — 먼저 비우지 않아 다른 프로세스가 빈 파일을 읽는 창이 없다(바꾸기·이름 바꾸기는
    읽기 전용 가드상 쓰지 않는다). 끝을 잘라 짧아진 내용의 꼬리를 남기지 않는다."""
    data = text.encode("utf-8")
    with CONFIG_LOCK:
        try:
            f = open(path, "r+b")
        except FileNotFoundError:
            f = open(path, "wb")
        with f:
            f.seek(0)
            f.write(data)
            f.truncate()
            f.flush()


def _read_config_bytes(path) -> bytes:
    """다른 프로세스가 막 쓰는 중이면 빈·반쪽 내용을 읽을 수 있다 — 짧게 몇 번 다시 읽는다 (검토64 B3)."""
    raw = b""
    for _k in range(6):
        with CONFIG_LOCK:
            with open(path, "rb") as f:
                raw = f.read()
        try:
            import yaml as _y
            if raw.strip() and isinstance(_y.safe_load(raw.decode("utf-8-sig", "replace")), dict):
                return raw
        except Exception:
            pass
        if not raw.strip() and _k >= 2:
            return raw
        time.sleep(0.15)
    return raw


_NK_CACHE: dict = {}


def load_config(path: Path) -> dict:
    try:
        raw = _read_config_bytes(path)
    except FileNotFoundError:
        print(f"오류: 설정 파일이 없습니다: {path}\n"
              f"  Drev 창(바탕화면·시작 메뉴의 Drev)을 한 번 열어 감시 폴더를 고르세요"
              , file=sys.stderr)   # 포터블·설치판에는 없는 명령만 알려 줬다 (검토55 ②6). 개발용 꼬리도 뺀다 (검토56 ②6)
        raise SystemExit(2)
    cfg = _parse_config_text(raw, Path(path))
    # 'mail:'처럼 값 없이 키만 있으면 None이 되어 setdefault로는 못 막는다 → 명시 치환
    for key, default in _CONFIG_DEFAULTS.items():
        if cfg.get(key) is None:
            cfg[key] = default
    # 화면 포트: 설정 › 고급 › 화면 포트(port)가 옛 '확인 링크 주소(ack_url)'보다 앞선다. port가 없거나 틀리면 ack_url을
    # 그대로 읽어 포트를 얻는다 — 깔린 판의 config.yaml에 남은 ack_url도 계속 쓴다 (2026-11-02 기능 검토 S)
    try:
        _pt = int(str(cfg.get("port")).strip()) if cfg.get("port") not in (None, "") else 0
    except ValueError:
        _pt = 0
    if 1 <= _pt <= 65535:
        cfg["ack_url"] = f"http://127.0.0.1:{_pt}"
    # 감시 폴더: roots 목록 우선, 구버전 root_path(단일 문자열)도 수용
    roots = cfg.get("roots")
    if not roots:
        rp = cfg.get("root_path")
        roots = [rp] if rp else []
    if isinstance(roots, (str, Path)):
        # roots: 'D:\\x' 처럼 목록이 아니게 적으면 글자 단위로 쪼개져 '\\'가 C:\\ 전체
        # 검사가 됐다 (2026-09-04 검토 ops M2)
        roots = [roots]
    cleaned = []
    for r in roots:
        s = str(r).strip() if r else ""
        if not s or s in ("\\", "/", "\\\\"):
            continue
        cleaned.append(s)
    # 같은 폴더 두 번·서로 포함하는 폴더(A와 A\하위)는 파일이 두 번 등록되고 변경이 두 번 보고됐다 (검토58 F6 F5) — 걷어낸다
    import os as _os
    def _nk(p_: str) -> str:
        # '\\?\C:\…'·짧은 이름(PROGRA~1)·접합점도 같은 폴더로 — 표기만 다른 두 줄이 모든 변경을 두 번 보고했다 (검토64 D3)
        _hit = _NK_CACHE.get(p_)
        if _hit and time.monotonic() - _hit[0] < 600:     # 끊긴 네트워크 폴더에 화면 요청마다 묻지 않게
            return _hit[1]
        q = p_
        try:
            q = _os.path.realpath(p_)
        except (OSError, ValueError):
            pass
        if q.startswith("\\\\?\\UNC\\"):
            q = "\\\\" + q[8:]
        elif q.startswith("\\\\?\\"):
            q = q[4:]
        _v = _os.path.normcase(_os.path.normpath(q)).rstrip("\\/")
        _NK_CACHE[p_] = (time.monotonic(), _v)
        return _v

    def _same(a_: str, b_: str) -> bool:
        # 매핑 드라이브(Z:\도면)와 UNC(\\nas\도면)처럼 글자로는 못 맞추는 같은 폴더 — 파일 시스템에 묻는다
        if _nk(a_) == _nk(b_):
            return True
        if _os.path.basename(_nk(a_)) != _os.path.basename(_nk(b_)):
            return False
        try:
            return _os.path.samefile(a_, b_)
        except (OSError, ValueError):
            return False
    kept: list = []
    for _i, s in enumerate(cleaned):
        k = _nk(s)
        # 뒤에 같은 폴더 이름의 감시 폴더가 있으면 빼지 않는다 — 빼면 그 폴더의 라벨(서버~3)이 서버~2로 밀려 업데이트 첫날
        # 거짓 삭제·추가 메일이 났다 (검토59 F3 H4). 라벨이 밀리지 않을 때만 걷어낸다
        _base = _os.path.basename(k)
        if any(_os.path.basename(_nk(o)) == _base for o in cleaned[_i + 1:]) and any(_same(s, o) for o in kept):
            print(f"참고: 감시 폴더 '{s}'가 두 번 적혀 있습니다 — 설정 화면에서 하나를 지워 주세요", file=sys.stderr)
            kept.append(s)
            continue
        if any(_same(s, o) for o in kept):
            print(f"참고: 감시 폴더 '{s}'가 두 번 적혀 있어 하나만 씁니다", file=sys.stderr)
            continue
        if any(k.startswith(_nk(o) + _os.sep) for o in kept):
            print(f"참고: 감시 폴더 '{s}'는 이미 감시하는 폴더 안이라 뺐습니다", file=sys.stderr)
            continue
        inner = [o for o in kept if _nk(o).startswith(k + _os.sep)]
        for o in inner:
            print(f"참고: 감시 폴더 '{o}'는 '{s}' 안이라 뺐습니다", file=sys.stderr)
        kept = [o for o in kept if o not in inner] + [s]
    cfg["roots"] = kept
    # 제외 목록의 빈 줄(YAML '- ')·숫자는 None·int가 되어 검사가 traceback으로 죽었다 (검토58 F6 F1)
    ex = cfg.get("exclude")
    if isinstance(ex, (str, Path)):
        ex = [ex]
    cfg["exclude"] = [str(e).strip() for e in (ex if isinstance(ex, (list, tuple)) else [])
                      if e is not None and str(e).strip()]
    # 확장자 '[]'는 0개 감시였다 — 예시 설정은 '비워 두면 기본'이라 했다 (검토58 F6 F2)
    if isinstance(cfg.get("extensions"), (list, tuple)) and not cfg["extensions"]:
        cfg["extensions"] = list(DEFAULT_EXTENSIONS)
    # 경로 칸에 따옴표 없는 숫자(backup_dir: 123)면 Path()가 TypeError로 검사 전체를 죽였다 (검토58 F3 G2)
    for _k in ("state_db", "brief_dir", "backup_dir"):
        if cfg.get(_k) is not None and not isinstance(cfg[_k], (str, Path)):
            cfg[_k] = str(cfg[_k])
    # 상대 경로는 설정 파일 폴더 기준 — 작업 폴더(cwd) 기준이면 다른 곳에서 실행한 날 새 이력·브리핑이 생겨 '기준선 등록'을
    # 다시 했고(이력이 둘로 갈림), System32에서 돌면 쓸 수 없는 곳을 가리켰다 (검토64 D5)
    try:
        _base = Path(path).resolve().parent
        for _k in ("state_db", "brief_dir", "backup_dir", "aliases"):
            _v = cfg.get(_k)
            if _v and not Path(str(_v)).is_absolute():
                cfg[_k] = str(_base / str(_v))
    except (OSError, ValueError):
        pass
    # 받는 사람 칸은 어디든 목록으로 — 'always_recipients: ceo@x'처럼 글자로 적으면 list()가 한 글자씩 쪼개 To가 'c, e, o, @…'가
    # 되고 로그는 '발송 완료'였다. ';'·쉼표·줄바꿈으로 여럿을 적은 칸도 나눈다 (검토67 D1)
    from watcher.mail import split_addrs as _sa

    def _addrs(v):
        return _sa(v if isinstance(v, (list, tuple)) else [v]) if v else []
    if isinstance(cfg.get("mail"), dict):
        for _k in ("recipients", "always_recipients", "purchase_recipients"):
            if _k in cfg["mail"]:
                cfg["mail"][_k] = _addrs(cfg["mail"][_k])
    if isinstance(cfg.get("projects"), dict):
        for _pc in cfg["projects"].values():
            if isinstance(_pc, dict) and "recipients" in _pc:
                _pc["recipients"] = _addrs(_pc["recipients"])
    if cfg.get("backup_dir"):
        from watcher.state import register_backup_dir
        register_backup_dir(cfg.get("state_db") or "state.db", cfg["backup_dir"])       # 화면·검사 어디서 열든 없어진 DB 흔적으로 (검토37 C 중간 1)
    return cfg


def write_initial_config(root: str, dst: Path = Path("config.yaml")) -> None:
    """첫 설정 생성: 예시 설정의 감시 폴더만 입력값으로 바꿔 저장 (위저드·GUI 공용).

    예시의 자리표시가 바뀌었는데(2026-09-09 `tests/fixtures` → `\\서버\공유\도면`) 치환 정규식이
    옛 글자를 찾아 **0건 치환**으로 자리표시를 그대로 저장했다 — 콘솔로 처음 켠 사람은 답을 하고도
    "감시 폴더에 접근할 수 없음"을 봤다 (검토33 B1). roots 줄을 찾아 통째로 바꾸고, 못 찾으면 예외."""
    text = (PROJECT_DIR / "config.example.yaml").read_text(encoding="utf-8")
    safe = "''".join(str(root).split("'"))  # YAML 단일따옴표 이스케이프
    text, n = re.subn(r'(?m)^roots:\s*$\n(?:[ \t]*-[^\n]*\n)+',
                      lambda _: f"roots:\n  - '{safe}'\n", text, count=1)
    if n != 1:
        raise RuntimeError("config.example.yaml의 roots 줄을 찾지 못했습니다 — 첫 설정을 만들 수 없습니다")
    dst.write_text(text, encoding="utf-8")


def _root_labels(roots: list[Path]) -> list[str]:
    """감시 폴더별 라벨(경로 접두어). 폴더명 기준, 중복 시 ~2, ~3."""
    labels, seen = [], {}
    for r in roots:
        base = r.name or str(r)
        seen[base] = seen.get(base, 0) + 1
        labels.append(base if seen[base] == 1 else f"{base}~{seen[base]}")
    return labels


FOLDER_VOTES_META = "folder_votes"


def _save_folder_votes(state: State, votes: dict) -> None:
    """폴더 다수결 표를 DB meta에 남긴다 — 화면(정리 제안·폴더 구조·변경 상세)의 귀속 표시가
    검사와 같은 답을 내게 (검토22 D1). 실패해도 검사는 계속한다."""
    import json as _json
    try:
        state.set_meta(FOLDER_VOTES_META, _json.dumps(votes, ensure_ascii=False) if votes else None)
    except Exception:
        pass


def _load_folder_votes(state: State) -> dict:
    import json as _json
    try:
        raw = state.get_meta(FOLDER_VOTES_META)
        return _json.loads(raw) if raw else {}
    except Exception:
        return {}


ALIAS_TROUBLE_KEY = "alias_trouble"   # {"at":ISO, "error":str|None, "how":str|None, "warnings":[...]} — 별칭 사전 문제 (검토20 r13 1)
_ALIAS_CACHE: dict = {}


def load_aliases(cfg: dict, roots=(), write_ok: bool = False):
    """별칭 사전 읽기 — 실패하면 마지막으로 잘 읽힌 사본(.ok), 그것도 없으면 별칭 없이. (resolver, 문제 사전|None).
    귀속(make_resolver)과 수신자(_project_cfg)가 **같은** 읽기를 쓴다 — 수신자 쪽이 사전을 직접 다시 읽어, 사전이 깨진 날 귀속은
    .ok 사본으로 맞는데 별칭 이름으로 적은 프로젝트 수신자를 못 찾아 메일이 전체 수신자에게 갔다 (검토20 r13 2)."""
    _ap = Path(str(cfg.get("aliases") or "aliases.yaml"))
    _ok_copy = _ap.with_name(_ap.name + ".ok")       # 마지막으로 잘 읽힌 사본 (Drev 폴더 — 감시 폴더가 아니다)
    trouble = None
    try:
        resolver = ProjectResolver.load(_ap)
        if getattr(resolver, "load_warnings", None):
            trouble = {"error": None, "how": None, "warnings": list(resolver.load_warnings)[:8]}
        if write_ok:
            try:
                # 사전을 감시 폴더 안에 둔 집이면 사본을 쓰지 않는다 — 감시 공유에 파일을 만들면 원칙 2 취지에 어긋난다 (검토60 ③)
                _apr = _ap.resolve()
                _ap_in = any(_apr.is_relative_to(Path(r).resolve()) for r in roots)
                if not _ap_in and _ap.is_file() and (not _ok_copy.is_file() or _ok_copy.read_bytes() != _ap.read_bytes()):
                    _ok_copy.write_bytes(_ap.read_bytes())
            except OSError:
                pass
    except Exception as e:
        # 별칭 사전은 보조 정보 — 문법 오류·목록 꼴이면 검사가 '보고 단계 실패'로 매일 되돌려졌다 (검토58 F6 F4).
        # 별칭 없이 진행하면 그날 귀속·수신자가 바뀌어 다른 프로젝트 이름 메일이 기본 수신자에게 갔다 (검토59 F3 J1) —
        # 마지막으로 잘 읽힌 사본으로 진행하고 알린다
        try:
            resolver = ProjectResolver.load(_ok_copy) if _ok_copy.is_file() else None
            how = "마지막으로 잘 읽힌 별칭 사전으로" if resolver is not None else "별칭 없이"
        except Exception:
            resolver = None
            how = "별칭 없이"
        if resolver is None:
            resolver = ProjectResolver({})
        err = f"{type(e).__name__}: {str(e).splitlines()[0][:160] if str(e) else ''}"
        trouble = {"error": err, "how": how, "warnings": []}
        print(f"경고: 별칭 사전({_ap})을 읽지 못해 {how} 검사합니다 — 고쳐 주세요 ({type(e).__name__}: {e})",
              file=sys.stderr)
    return resolver, trouble


def _alias_for_cfg(cfg: dict):
    """수신자 찾기용 별칭 사전 — 사전·사본 수정 시각으로 캐시(프로젝트마다 다시 읽어 경고가 두 번 찍혔다, 검토20 r13 2 부수)."""
    _ap = Path(str(cfg.get("aliases") or "aliases.yaml"))
    try:
        key = (str(_ap), _ap.stat().st_mtime_ns if _ap.exists() else None,
               _ap.with_name(_ap.name + ".ok").stat().st_mtime_ns if _ap.with_name(_ap.name + ".ok").exists() else None)
    except OSError:
        key = (str(_ap), None, None)
    hit = _ALIAS_CACHE.get("cfg")
    if hit and hit[0] == key:
        return hit[1]
    import contextlib
    import io
    with contextlib.redirect_stderr(io.StringIO()):       # 경고는 make_resolver가 이미 한 번 남겼다
        res, _t = load_aliases(cfg)
    _ALIAS_CACHE["cfg"] = (key, res)
    return res


def alias_note(trouble: dict | None) -> str | None:
    """별칭 사전 문제 한 줄 — 브리핑·메일 머리와 화면 배너가 같은 문구를 쓴다."""
    if not trouble:
        return None
    if trouble.get("error"):
        return (f"별칭 사전(aliases.yaml)을 읽지 못해 {trouble.get('how') or '별칭 없이'} 프로젝트를 나눴습니다 — "
                f"그 사이 새로 적은 별칭은 적용되지 않습니다. 고쳐 주세요 ({trouble['error']})")
    ws = trouble.get("warnings") or []
    if ws:
        return f"별칭 사전(aliases.yaml) 확인 필요 {len(ws)}건 — " + " / ".join(ws[:3])
    return None


class _PrevProjects:
    """경로 → 그 파일의 마지막 귀속(changes.project) — 필요할 때만 한 경로씩 묻는다."""

    def __init__(self, state):
        self._state = state
        self._cache: dict = {}
        # 파일별 프로젝트 고정(J6) — 검사·보고 두 귀속기가 이 객체를 함께 쓰므로 여기 실으면 둘 다 같은 고정을 본다
        try:
            self.manual = state.manual_projects()
        except Exception:
            self.manual = {}

    def get(self, path, default=None):
        if path not in self._cache:
            try:
                row = self._state.conn.execute(
                    "SELECT project FROM changes WHERE path = ? AND project IS NOT NULL AND project != '' "
                    "ORDER BY id DESC LIMIT 1", (path,)).fetchone()
                self._cache[path] = row[0] if row else None
            except Exception:
                self._cache[path] = None
        return self._cache[path] if self._cache[path] is not None else default


def make_resolver(cfg: dict, roots: list, paths=None) -> ProjectResolver:
    """설정·감시 폴더 목록으로 귀속기를 만든다 — 검사와 화면이 같은 것을 쓴다.

    감시 폴더 이름에 프로젝트 번호가 있으면 그 폴더 전체를 그 프로젝트로 (자동).
    config `root_projects: {경로: 이름}`로 지정하거나(이름 ""이면 자동도 끔),
    설정 화면의 [프로젝트 하나로]로 정한다 (2026-09-02)."""
    roots = [Path(r) for r in roots]
    labels = _root_labels(roots)
    resolver, trouble = load_aliases(cfg, roots, write_ok=True)
    resolver.alias_trouble = trouble
    resolver.root_labels = set(labels)
    declared = {str(k): ("" if v is None else str(v))
                for k, v in (cfg.get("root_projects") or {}).items()}
    rp = {}
    for root, label in zip(roots, labels):
        key = str(root)
        alt = root.as_posix()
        if key in declared or alt in declared:
            rp[label] = declared.get(key, declared.get(alt, ""))
        else:
            auto = resolver.root_project_for(label, root.name)
            if auto:
                rp[label] = auto
    resolver.root_projects = rp
    if paths:
        # 바로 아래 폴더들이 문서 종류 이름이면 프로젝트 하나 (구조 추정)
        resolver.infer_single_roots(
            paths, {label: root.name for root, label in zip(roots, labels)}, cfg)
    return resolver


def _excludes_for(label: str, all_labels: list[str], excludes: list[str]) -> list[str]:
    """제외 목록을 해당 감시 폴더 몫으로 변환.
    '라벨/상대경로' 형식은 그 폴더에만, 라벨 없는 형식은 모든 폴더에 공통 적용."""
    out = []
    for e in excludes:
        e = e.strip("/")
        head = e.split("/", 1)[0]
        if head == label and "/" in e:
            out.append(e.split("/", 1)[1])
        elif head not in all_labels:
            out.append(e)
    return out


def cmd_init(args: argparse.Namespace) -> int:
    dst = Path(args.config)
    if dst.exists():
        print(f"이미 있음: {dst} (덮어쓰지 않음)")
        return 1
    src = PROJECT_DIR / "config.example.yaml"
    dst.write_bytes(src.read_bytes())
    print(f"생성됨: {dst} — roots: 목록의 폴더를 감시할 파일서버 폴더로 바꿔주세요.")
    return 0


# 추출 결과 형식 세대 — 추출 결과의 모양이 달라질 때 올린다
# (v2: PDF 엔진 pdfium 교체 / v3: XLSX 전 시트 / v4: 머리글 최다 열 선택)
_CACHE_VER = 48   # 2026-11-06(ux24 PO6): XLSX '발주일자'·'발주 일자' 라벨 DATE; 47: 2026-11-03(ux20 buy 6): XLSX 개정이력 REV 키 열 고유성 0.9→0.5(같은 Rev 두 행이어도 REV 열); 46: 2026-11-01b(검토20 r08·r11·r12): XLSX 행 키 TAG 열 이름 변종(TAG.·TAG NO.·TAG NAME·태그·태그번호)·TYPE 사양 열, DOCX 자동 필드 자리표시({DATE}·{PAGE}·목차 쪽 번호)·붙임표·기호(w:sym)·메모(comments)·머리글 개정이력 표·쓰이는 머리글만·표 번호 워드 기준·gridBefore·본문만 4,000문단 상한(머리글·각주는 모두), HWPX 구역 숫자 순·자동 필드·run 넘는 삭제 구간·표 캡션·그림 캡션·숨은 설명·메모, 태그 /숫자 꼬리(M-101/1 — DXF 줄 잇기가 쓴다); 45: 2026-11-01(검토20 r03·r07): DXF 상수 속성(ATTDEF CONSTANT) 글자·치수 '<>' 접두·접미 실측 치환·치수 스타일 소수 자리(dimdec·dimrnd)·거울 삽입 글자 근거 위치 세계 좌표·중첩 표제란 틀(title_box), PDF 라벨 위·값 아래 칸표 넓은 칸·ToUnicode 없는 글꼴 쪽 OCR·OCR 'DATE.' 라벨·한 줄 여러 쌍 중 맞는 쌍 살림·OCR 달 '1 1' 붙임·Rev 검사 못 함 고지; 44: 2026-10-28(재검토 10방식 B1): HWPX hp:t 안 탭·줄바꿈·형광펜·붙임 빈칸 뒤 글자(tail)·한글 수식(hp:script), DOCX 수식(m:t), XLSX 시트 도형 글자('[도형] …')·인쇄 머리글/바닥글·도형 부품 지문(xl/drawings), DXF 다중 지시선 글자·풍선 속성·기하 공차·여러 줄 속성 둘째 줄·R12 \M+ 한글·MTEXT '\~' '%%u' '%%%' 위첨자 쌓기·코드페이지 머리말≠바이트 다시 읽기·글자 표제란 SHEET/UNIT/SIZE/서명 칸 값(META:…), PDF 자유 글자 주석·양식 입력 칸 값; 43: 2026-10-23(뒤흔들기 PDF): 살짝 기운 글자의 실제 각도 축·자간(Tc·Tw) 빼고 낱말 틈·쪽 대부분이 90·180·270°면 그 방향을 가로로·U+00AD 등 글자 정규화·글자마다 그린 ISO 값 행 낱말 묶기·ISO 라벨 행의 다른 표 조각 빼기; 같은 세대 2026-10-23(뒤흔들기 DXF): 모델 공간 도면 틀(닫힌 사각형) 여럿이면 틀마다 따로 읽기(REV#2·첫 틀 개정표), TITLE 레이어 없는 표제란을 라벨 밀도로(위치 무관), 글자 회전 최빈각으로 되돌려 읽기, 서명·도면명 한 덩이(META:…·콜론 없는 도면명), 글자 높이 1.5배 넘게 다른 같은 줄은 상자 겹침, 8배 넘게 먼 다른 레이어 조각은 다른 줄, 배치 공간 머리 없는 개정 행·위치 경계 걸친 개정표; 42: 2026-10-20b(뒤흔들기 DOC): DOCX·HWPX 1행·1열 표는 제자리 문단 글, 표 위 병합 제목 행은 표 제목 글줄(열 이름 아님), 머리글·바닥글 줄 글자에서 '[머리글] ' 머리표 뗌(자리는 where), 글상자 속 1칸 표 칸은 머리표 없이, DOCX 머리글 사본 종류(Document.hf_kinds); 같은 세대 2026-10-20(XLSX 뒤흔들기 1,500건): 머리글 찾는 창을 값 있는 행 30개로·빈 열 하나 끼어든 한 표·옆 작은 표 칸 자리·표 여럿인 시트의 수식 기록·수식 참조 정규화(Document.formulas 다섯째)·둘째 일자 칸 같은 날; 41: 2026-10-20(대량 시험 DXF): DXF 칸표 표제란은 칸 높이(아래 라벨 줄까지)로 값을 집고, 여러 줄 MTEXT 표제란의 빈 칸('PROJECT: '), 세로 용지 표제란 경계 왼쪽 라벨 칸; 같은 세대 2026-10-20(PDF 대량 시험 2,500건): PDF 글줄을 그리는 순서가 아니라 글자 자리로 묶음(행·칸·덩어리 차례, ISO 라벨 행 나누기, 세로 라벨 칸+값 칸), 개정표 머리 칸 이름(BY·APPD…)은 REV 값 아님; 같은 세대 2026-10-20(XLSX 대량 시험 2,500건): XLSX·XLSM 수식 칸 열 이름을 30행 창 밖에서도(표 머리글)·개정이력 시트 행 이름표는 REV 열·'Rev.:' 한 칸 표제·차트 지문은 시트 이름·값 캐시를 뺀 꼴; 같은 세대 2026-10-20(대량 시험 DOC): HWPX 표 칸 병합(colSpan)·자리(colAddr) 펼침, DOCX·HWPX 머리글·바닥글 '버전 1.1'을 Rev로; 40: 2026-10-19(구매 평가 2차 F1): DOCX·HWPX 개정이력 표의 버전 꼴 값('1.0'·'1.1')을 Rev로 — 본문만 고치고 버전 그대로인 사양서의 Rev 미갱신; 39: 2026-10-17(검토71 R3, 같은 세대): PDF 라벨만 든 줄과 값 줄 한 줄로(같은 바탕선·바로 아래)·개정표 쪽 글줄 자리, DXF 늦은 일자 칸 개정표의 빈 뒤 칸·'작성일' 일자 칸; 2026-10-17b(검토71 R4): DOCX·HWPX·XLSX 문서 안 그림·개체 부품 지문(Document.parts) — 그림만 바꾼 날과 다시 저장만 한 날을 가른다; 38: 2026-10-14b(고정 벤치마크 99%): DXF 본문 MTEXT 문단마다 글줄·태그 줄 아래로 넘어간 사양 값 잇기; DOCX·HWPX 머리말·바닥글 사본의 같은 줄 한 번; PDF 세로 글줄 표제란 줄바꿈; 37: 2026-10-14(검토68 문서 200건): DXF 표 꼴·빈 칸·점 든 라벨 표제란, 리비전 행 속성·ISO 개정표·여러 줄 MTEXT 표제란; PDF 회전 쪽 줄 묶음·스캔 칸표 OCR 라벨-값·한 글자 Rev; XLSX 머리글 목록·소문자 머리글 수식 열; DOCX·HWPX 개정이력 표 행 위치·REV 보충, HWPX 각주·글상자 따로; 36: 2026-10-13: XLSX 행 수식 기록에 칸별 수식 글자(수식이 같을 때만 계산값 차이를 저장 프로그램 탓으로, 검토67 — v0.57.45의 세대 35 캐시는 글자가 없어 그 거름이 꺼진다); 35: 2026-10-10c(배포 전이라 같은 세대): PDF 한 쪽짜리도 표제란 줄을 본문에, DOCX·HWPX 순번 열 표는 내용 키·머리글 위치는 그 안의 순번·HWPX 연속 띄어쓰기, XLSX 표지 REV|값은 머리글 아님·값 안 띄어쓰기 두 칸 (검토62); 2026-10-10b: DXF TEXT 제어 코드(%%c·%%d·%%p·%%u)·MTEXT 공차 쌓기·ACAD_TABLE 칸 글자, DOCX 줄바꿈·탭은 띄어쓰기, XLSX 행별 수식 칸 수(검토61); 34: 2026-10-10: XLSX 쉼표만 든 칸이 숫자로 잡혀 추출 실패하던 것 (검토60 ③)·시각 있는 날짜는 분까지(④) — 실패로 캐시된 BOM을 다시 읽게; 33: 2026-10-09: XLSX 조합 키에서도 사람·부서 열 제외 (검토57 ⑥28); 32: 2026-10-07: XLSX 키 열 — 사람·부서 열은 이름표에서 내리고 공정·작업 이름은 올림 (검토55 ④4); 31: 2026-10-06b: DOCX·HWPX 머리글·바닥글의 콜론 없는 Rev(Rev. A)·머리글 표(DOC NO | REV) 라벨-값 짝, 암호 문서(OLE) 안내 (경우100 B11·B16·B17), 머리글 표 제목 행·HWPX 머리글 표·값의 | 자르기·양식 Rev 제외, XLSX TAG 빈 행은 품명+규격 키 (검토53); 30: 2026-10-06: PDF 바닥글 REV 규칙은 쪽 표식·앞 글자 있을 때만(세트 PDF 쪽 REV 줄 복원), XLSX 병합 숫자 품번 열은 남김 (검토52 B), 바닥글 REV 꼴 넓힘·외톨이 REV 제외·그림 쪽 표지(검토52 A·C), XLSX 병합 숫자 든 값·위 진짜 표, DOCX 글상자 사본(표·머리글·칸) (검토52 C); 29: 2026-10-05: DOCX 각주·미주·글상자(사본 제외)·바닥글 REV 첫 토큰, PDF 바닥글 'REV: A  Page n'·몇 쪽만 그림인 PDF 표지, XLSX 병합 숫자 칸·표제 칸 덩어리 (검토51 B); 28: 2026-10-04: 파일 속 마지막 저장자(DXF $LASTSAVEDBY·XLSX·DOCX lastModifiedBy) (구매자 평가); 27: 2026-10-03: HWPX 본문을 머리글·바닥글보다 먼저(둘째 칸 순서), 꾸밈말 앞도 두 칸이면 라벨·제목 칸 값 끝 낱말은 아님, 머리글·바닥글 줄 가운데 라벨 (검토47 A·B); 26: 2026-10-02d: DOCX 머리글·바닥글의 겹친 칸은 REV#2 같은 둘째 칸·긴 꾸밈말 라벨 끊기·바닥글 근거 위치, 꾸밈말은 앞 칸 값 끝이면 아님·SERVICE 등 뺌 (검토46 A·B·C); 25: 2026-10-02c: DOCX·HWPX 줄의 'DUE DATE:'·'납기 일자:'는 표제 DATE 아님·앞 문단이 차지한 칸은 본문에 남김, 날짜 꾸밈말 WARRANTY·보증 등 (검토45 A·B); 24: 2026-10-02b: PDF 한 줄 여러 칸의 'DUE DATE:'는 표제 DATE 아님·개정표 행 판정은 설명 앞부분만, DXF '축척1:50' 붙여 쓴 축척, DOCX 머리글·바닥글 줄의 필드 (검토44 A·B); 23: 2026-10-02: DXF 한 덩어리 축척 글자는 본문에서 뺌 (검토43 C 중간 6); 22: 2026-10-01: PDF 표제 줄 DESCRIPTION·XLSX QP 문서번호 Rev·DXF 축척 빈칸 (검토43 A); 21: 2026-09-30b: DXF 글자 표제란 축척(META:SCALE) (검토42 B T04); 20: 2026-09-30: PDF·XLSX·DOCX 일자 칸은 날짜만(뒤 글자는 본문)·둘째 일자 라벨은 글줄·줄의 '라벨: 날짜' 조각 보존, PDF 개정표 행, XLSX 양식 개정번호·표지 KV REV, DOCX 줄 값은 다음 라벨 앞까지, DXF 표제란 틀 세로 범위 (검토42 B); 19: 2026-09-28: PDF 한 줄 여러 라벨·REV NO·검사일, XLSX 시트 이름 순·연도 아님·'-' 빈 Rev·병합 배너, DOCX 두 줄 머리글 판정, DXF 한 덩어리 '개정' 값 (검토41 S2·S4); 18: 2026-09-27: DXF 표제란 틀 범위(title_box), DOCX 한 줄 여러 라벨·가로 병합 머리글, PDF DOC NO, XLSX 표 위 표제 칸 (검토38 R4-C·D·E, 검토39 P1); 17: 2026-09-27: DXF 표제란 판별(풍선·심볼·마커·틀 셋)·개정 행 판별·탭 순서·PDF·DXF 한글 개정 라벨(값은 Rev 꼴만) (검토37 A·검토38 R1·R5·검토39 F2); 16: 2026-09-25: DXF 블록 속성은 '표제란다운 삽입'만 표제란(둘째 표제란은 REV#2…), 쌓인 행 블록은 개정이력 행, 심볼·목록표 속성은 본문 (검토36 A N2·N3·N4); 15: 2026-09-24: DXF는 표준 표제란 속성·서명만 본문에서 제외(배치 공간 CLIENT 등은 비교), PDF 부분 읽기 고지 문구 (검토35 A); 14: 2026-09-23: DXF 블록 속성 값은 본문에서 제외, PDF 긴 스캔 고지 말머리 (검토34 B 차단 1·2 — v0.57.14 세대 13의 DXF 본문에 속성 값이 새어 들어갔다); 13: 2026-09-22: DXF REV NO 라벨·TITLE 레이어 글자, PDF 긴 스캔 고지 (검토33 C1·C2·C4); 12: PDF 표제란 REV.A·REV-A 구분자 (검토31 B11); 11: 2026-09-15: xlsx 개정이력 REV는 최고값 (검토25 6-4); 10: 개정이력 → REV 필드 (검토24 A-2)
# 형식별 호환 하한 — 그 형식의 추출 결과가 마지막으로 바뀐 세대. 이 이상이면 옛 기록도 그대로 쓴다:
# 세대가 오를 때마다 확장자 무관 전체 재추출(4만 파일이면 시간 단위)이 되고, 판 교체 전에 바뀐 파일은
# '이전 판' 기록이 옛 세대라 비교를 통째로 건너뛰었다 (검토25 D 2-1·감지 6-1, 검토26 1회차 1).
# 새 세대를 올릴 때 바뀐 형식만 여기서 올린다
_CACHE_FLOOR = {".xlsx": 48, ".xlsm": 48, ".dxf": 46, ".dwg": 46, ".pdf": 45, ".docx": 46, ".hwpx": 46}
# 세대를 올릴 때 바뀐 형식의 하한을 같이 올린다 — v0.57.12가 PDF 규칙을 바꾸고 하한을 9에 둬, 판 교체 뒤
# refresh-cache가 '128개 완료'라면서 실제로는 0건 재추출했다 (검토32 A 1). test_cache_ver가 max(하한)==세대를 지킨다
# 비교 호환 하한 — 이 세대 이상의 옛 판 기록은 다시 읽어야 해도(_CACHE_FLOOR 아래) 지금 판의 새 추출본과 **견줄 수는** 있다.
# 없는 형식은 _CACHE_FLOOR와 같다. 옛 판 파일은 이미 없어 다시 읽을 수 없으므로, 하나로 쓰면 판 올림 뒤 첫 검사에서 그 사이 바뀐
# 파일 전부가 '비교 생략'이 된다 — 세대 48에서 XLSX 전부의 행 비교·발주 후 변경 표지·구매 수신이 빠졌다 (ux26 SP1).
# 세대를 올릴 때: ① 바뀐 형식의 _CACHE_FLOOR를 새 세대로 올린다. ② 그 형식에 여기 항목이 있으면 낡은 것이니 지운다(안 지우면
# test_cache_ver가 실패한다 — 두 세대 건너 섞지 않게). ③ 옛 세대 기록과 새 추출을 합성 문서로 직접 견줘(실제 git show로 규칙 차이를
# 읽고), 파일이 같을 때 거짓 줄이 없으면 항목을 옛 세대로 새로 둔다. 거짓 줄이 있으면 _old_doc처럼 비교 쪽 다리를 놓거나, 다리가
# 안 되는 변경(행 키·줄 나눔이 달라짐)이면 항목을 두지 않고 비교 생략을 받아들인다
_COMPARE_FLOOR = {".xlsx": 47, ".xlsm": 47}   # 47↔48: '발주일자'·'발주 일자' 라벨만 다르다(행·개정이력·수식 같음) — 차이는 _lift_po_date가 맞춘다
_PO_DATE_GEN = 48                             # 이 세대부터 XLSX 표 위 '발주일자'·'발주 일자' 칸이 DATE 필드다


_TIMEOUT_MSG = re.compile(r"(\d+)초 안에 끝나지 않아 중단")


def _timeout_raised(cached: dict | None, cur_timeout: float) -> bool:
    """시간 상한으로 실패한 기록인데 지금 상한이 그때보다 큰가 — 그러면 다시 읽는다 (F4). 옛 기록은 문구의 초로."""
    if not cached:
        return False
    t = cached.get("timeout_s")
    if t is None:
        m = _TIMEOUT_MSG.search(str(cached.get("extract_failed") or ""))
        t = m.group(1) if m else None
    try:
        return t is not None and float(cur_timeout) > float(t)
    except (TypeError, ValueError):
        return False


def _cache_ok(cached: dict | None, path: str) -> bool:
    """이 추출 기록을 지금 판이 그대로 써도 되나."""
    if not cached:
        return False
    gen = cached.get("cache_ver")
    if gen == _CACHE_VER:
        return True
    if not isinstance(gen, int) or gen > _CACHE_VER:      # 새 판이 쓴 기록을 구판이 섞지 않는다
        return False
    ext = PurePosixPath(str(path)).suffix.lower()
    return gen >= _CACHE_FLOOR.get(ext, _CACHE_VER)


def _compare_ok(cached: dict | None, path: str) -> bool:
    """이 옛 판 기록을 지금 판의 새 추출본과 견줘도 되나 — 다시 읽을지(_cache_ok)와 다른 물음이다 (ux26 SP1). 비교하는 곳은
    이 판정과 _old_doc을 함께 쓴다."""
    if _cache_ok(cached, path):
        return True
    gen = (cached or {}).get("cache_ver")
    if not isinstance(gen, int) or gen > _CACHE_VER:
        return False
    return gen >= _COMPARE_FLOOR.get(PurePosixPath(str(path)).suffix.lower(), _CACHE_VER + 1)


_PO_DATE_LABEL = re.compile(r"(?:(?<=\s)|^)발주\s*일자(?:(?P<colon>\s*[._:：]+)|(?=\s|$))\s*")
_PO_WORD_END = re.compile(r"(?:^|\s)발주\s*$")
_PO_WORD_START = re.compile(r"발주\s+")
_TITLE_WHERE = re.compile(r"(.*)!제목 \d+행(?: \('(.*)' 칸\))?", re.S)     # 추출기가 제목 칸 필드에 적는 위치 — (시트, 칸 라벨|한 칸이면 None)
_DATE_WORD = "DATE|일자|작성일|검사일|발주일|일시"


def _old_doc(old_dict: dict, new_doc, path: str) -> Document:
    """_compare_ok를 통과한 옛 판 기록을 비교할 문서로. 지금 판과 읽는 규칙이 다른 세대면 옛 쪽을 지금 규칙으로 맞춘다."""
    doc = Document.from_dict(old_dict)
    gen = old_dict.get("cache_ver")
    if (isinstance(gen, int) and gen < _PO_DATE_GEN and new_doc is not None
            and PurePosixPath(str(path)).suffix.lower() in (".xlsx", ".xlsm")):
        _lift_po_date(doc, new_doc)
    return doc


def _lift_po_date(old: Document, new: Document) -> None:
    """세대 47 XLSX 기록의 '발주일자' 칸을 세대 48처럼 DATE로 올린다 (ux26 SP1, 추출기 xlsx._title_fields의 거울). 47은 그 칸을
    제목 글줄로 남겨, 그대로 견주면 파일이 같아도 'DATE 없음→값'과 글줄 삭제 두 줄이 나고 Rev 있는 문서엔 거짓 'Rev 미갱신'까지
    났다. 줄을 지우지 않고 옛 값을 필드로 옮겨 **진짜 바뀐 발주일은 DATE 한 줄로 남긴다**. 새 판에 그대로 있는 글줄(둘째 일자 칸·
    날짜 아닌 값)은 48도 글줄로 둔 것이므로 건드리지 않는다. 새 추출본은 칸 순서를 알려 주는 안내로만 읽는다.
    기준은 같은 두 파일을 48끼리 견준 결과다. 다리는 거짓 줄을 없애는 것보다 진짜 변경을 숨기지 않는 것이 먼저라, 어느 쪽인지 애매하면
    옛 글을 그대로 둔다 — 거짓 줄 하나가 숨은 변경보다 낫다 (ux27 U1~U3)."""
    from watcher.extract.base import Field, TextLine
    from watcher.extract.xlsx import _DATE_HEAD
    now = {(t.where, t.text) for t in new.raw_texts}
    was = {(t.where, t.text) for t in old.raw_texts}
    head = new.fields.get("DATE")
    lines = []
    raised = False                  # 이 문서의 '발주일자'를 이미 DATE로 올렸다 — 같은 시트의 둘째 칸은 48도 글줄에 둔다
    for t in old.raw_texts:
        text = t.text
        if not str(t.where).endswith("!제목") or (t.where, text) in now:
            lines.append(t)
            continue
        sheet = str(t.where)[:-len("!제목")]
        cur = old.fields.get("DATE")
        cm = _TITLE_WHERE.fullmatch(str(cur.where)) if cur is not None else None
        m = _PO_DATE_LABEL.search(text)
        if m is None:
            # '발주 일자: d' 한 칸 — 47은 '일자:'만 읽어 DATE는 있고 '발주'가 글줄에 남았다('구매 발주'). 글줄 끝이고 뗀 글이 새 판에 그대로
            # 있을 때만 뗀다 — 제목의 낱말 '발주'를 정말 지운 편집('발주 BOM'→'BOM')이 '내용 변경 없음'이 됐다 (ux27 U2)
            # 그 칸이 행의 첫 칸이면 남은 '발주'는 글줄 앞에 온다('발주 구매 발주서') — 재저장만 한 발주서가 변경 1건과 7일 뒤 거짓 Rev
            # 미갱신이 됐다 (ux28 bridge 1). 앞에서 떼는 것도 뗀 글이 새 판에 있을 때만
            we = _PO_WORD_END.search(text)
            fw = None if we else _PO_WORD_START.match(text)
            if (we or fw) and cm and cm.group(1) == sheet and cm.group(2) is None:
                rest_ = " ".join((text[:we.start()] if we else text[fw.end():]).split())
                if (we and not rest_) or (rest_ and (t.where, rest_) in now):
                    text = rest_
        else:
            rest = text[m.end():]
            dm = _DATE_HEAD.match(rest)
            tok = rest.split()[0] if rest.split() and m.group("colon") and re.search("[:：]", m.group("colon")) else None
            val = dm.group(0).strip() if dm else tok
            tail = rest[dm.end():] if dm else (rest.split(None, 1)[1] if tok and len(rest.split(None, 1)) > 1 else "")
            without = " ".join(f"{text[:m.start()]} {tail}".split())
            if val is None:
                # 같은 날의 둘째 일자 칸이면 값이 앞 칸에 먹혀 라벨만 남았다. DATE가 없으면 날짜 아닌 값('발주일자 미정')이다
                text = without if cur is not None else text
            elif cur is None:
                old.fields["DATE"] = Field("DATE", val, head.where if head else f"{sheet}!제목 1행")
                raised = True
                text = without
            elif str(cur.value) == val:
                text = without                  # 같은 날 — 48은 칸을 필드로 읽었다
            elif cm is None or cm.group(1) != sheet:
                # 다른 시트 — 48은 칸을 필드로 읽고 시트 이름순 첫 값만 남긴다. 이 시트가 앞이면 48의 DATE는 이 칸이다 (ux27 U1)
                if cm is not None and sheet < cm.group(1):
                    old.fields["DATE"] = Field("DATE", val, head.where if head and head.where.startswith(f"{sheet}!") else f"{sheet}!제목 1행")
                    raised = True
                text = without
            elif not raised and head is not None and (hm := _TITLE_WHERE.fullmatch(str(head.where))) and hm.group(1) == sheet:
                # '발주일자 | d2 | 작성일 | d1' — 47은 작성일, 48은 앞 칸인 발주일자가 DATE라 작성일이 글줄로 내려갔다. 칸 라벨이 있으면 그것이
                # 증거다(발주일자가 바뀐 날도 옛 값이 나오게, ux27 U3). 한 칸이면 값이나 내려간 글줄로 본다. '작성일 | d1 | 발주일자 | d2'는 건드리지 않는다
                lab_ = re.escape(cm.group(2)) if cm.group(2) else _DATE_WORD
                twin = next((n.text for n in new.raw_texts if n.where == t.where and (n.where, n.text) not in was
                             and re.search(rf"(?:{lab_})[\s._:：]*{re.escape(str(cur.value))}", n.text)), None)
                if (_PO_DATE_LABEL.fullmatch(hm.group(2)) if hm.group(2) else (head.value == val or twin)):
                    old.fields["DATE"] = Field("DATE", val, head.where)
                    raised = True
                    # 작성일도 바뀐 날은 내려갔을 글줄을 옛 값으로 짓는다 — 48끼리 견준 '작성일 d1→d3' 한 줄과 같게.
                    # 쌍둥이 줄은 더하는 것이지 대신하는 것이 아니다 — 같은 행의 '담당 홍길동'이 사라져 거짓 추가가 됐다 (ux28 bridge 2)
                    if twin and without:
                        lines.append(TextLine(without, t.where, t.box))
                    text = twin or (" ".join(f"{text[:m.start()]} {cm.group(2)} {cur.value} {tail}".split()) if cm.group(2) else without)
        if text == t.text:
            lines.append(t)
        elif text:
            lines.append(TextLine(text, t.where, t.box))
    old.raw_texts[:] = lines


# 추출 코드가 바뀌면 이 숫자를 올려야 캐시가 새로 만들어진다. 2026-08-26 이후 다섯 판 동안
# 4로 방치돼, 판올림 뒤 옛 캐시와 새 추출본을 섞어 비교했다(한 칸 수정에 브리핑 27줄).
# 손으로 지키는 규율은 무너지므로 시험(tests/test_cache_ver.py)이 지문으로 지킨다
# (2026-09-09 추출 검토 차단 1).
#
# v8 (2026-09-10 검토19): DXF 블록 6단·우상단 표제란 필드·XLSX 표 옆 낱 셀 — 캐시된 결과가
# 실제로 달라지므로 세대를 올린다(한 판 재추출). 앞선 .xlsm 추가(v0.55.0)는 결과가 안 변해
# 지문만 바꿨었다.
_EXTRACT_FINGERPRINT = "9d3cd48b48d7d7a0"  # v48(ux24 PO6 XLSX 발주일자 라벨); v47(ux20 buy 6 XLSX 개정이력 REV 키 고유성); v46(검토20 r08·r11·r12 XLSX 키·DOCX/HWPX 필드·메모·캡션·상한·태그 꼬리); v45(검토20 r03·r07 DXF·PDF 추출); v44(재검토 2026-10-28 B1: HWPX 꼬리 글자·수식, DOCX 수식, XLSX 도형 글자·인쇄 머리글·도형 부품 지문, DXF 다중 지시선·공차·여러 줄 속성·MIF·MTEXT 잔여 코드·코드페이지 다시 읽기·글자 표제란 META 칸, PDF 주석·양식 값); v43(뒤흔들기 PDF: 기운 글자 각도 축·자간 빼기·주된 읽기 방향·글자 정규화·글자마다 그린 값 행·ISO 라벨 행 표 조각); v43(뒤흔들기 DXF: 모델 공간 틀 여럿 나눠 읽기·라벨 밀도 표제란·돌린 도면 되돌려 읽기·서명/도면명 한 덩이·높이 다른 같은 줄·먼 다른 레이어 줄 끊기·배치 공간 머리 없는 개정 행); v42(XLSX 뒤흔들기: 머리글 창 값 있는 행 30개·빈 열 한 표·옆 표 칸 자리·표별 수식 기록·수식 참조 정규화·둘째 일자 칸); v41(대량 시험 DXF: 칸표 표제란 칸 높이·MTEXT 빈 칸·낱말 여럿 칸 값·세로 용지 경계); v42(뒤흔들기 DOC: 1행·1열 표 글·병합 제목 행 글·머리글 머리표 뗌·머리글 사본 종류); v41(PDF 대량 시험: 글자 자리로 줄 묶기·ISO 라벨 행·개정표 머리 칸 이름); v41(XLSX 대량 시험: 수식 칸 열 이름 30행 밖·개정이력 REV 키·Rev.: 표제·차트 지문 정규화); v41(대량 시험 DOC: HWPX 병합 칸 펼침·머리글 버전 Rev); v40(구매 평가 2차 F1: DOCX·HWPX 개정이력 버전 꼴 Rev); v39(검토71 R4: 문서 안 그림·개체 부품 지문; 검토71 R3: PDF 라벨·값 줄 묶기·개정표 쪽 글줄 자리, DXF 일자 칸 x 범위·작성일); v38(갈래 D 2026-10-16: DXF 오른쪽 맞춤 MTEXT 왼쪽 끝·늦은 일자 칸 개정표·띄운 단위·한글 꾸밈말·들여 쓴 값 줄 잇기; 검토70 B: PDF 세로 글자 칸 나누기 — 배포 전이라 같은 세대; 검토69: 본문 MTEXT 문단 쪼개기·머리말 사본 한 번 되돌림 — 배포 전이라 같은 세대): 고정 벤치마크 DXF 줄 넘김, DOCX·HWPX 머리말 사본, PDF 세로 표제란; v35: 검토61 DXF 제어 코드·ACAD_TABLE·공차 쌓기, DOCX 줄바꿈, XLSX 수식 칸 수, Document.formulas; v34: 검토60 XLSX _NUM_VAL 숫자 하나 이상·시각 있는 날짜는 분까지; 세대 그대로 33: 검토58 xlsx _majority_sig 속도만(합성 통합문서 590개 추출 결과 동일 — 세대를 올리지 않는다); v33: 검토57 XLSX 조합 키 사람 열 제외; v32: 검토55 XLSX 키 열(담당·부서 아님, 공정 우선); v31(+검토54 XLSX 표 아래 라벨|값 꼬리 행): 경우100 DOCX 머리글 Rev·암호 문서 + 검토53 머리글 표 제목 행·HWPX 머리글 표·| 자르기·양식 Rev 제외·XLSX TAG 빈 행 내용 키(배포 전이라 같은 세대); v30: 검토52 B PDF·XLSX; v29: 검토51 B 문서류 추출; 세대 28 그대로: base.py 태그 꼴 선택·BOM 이름만(검토48)·스레드별 허용 목록(검토49)(추출 결과 불변 — 태그는 대조 때만 읽는다); v23: DXF 축척 글자; v22: 검토43 A 추출 퇴행; v21: DXF 축척 칸; v20: 검토42 B 일자 칸·개정표 행·양식 Rev·KV REV·DXF 틀 범위; v19: 검토41 PDF·XLSX·DOCX·DXF 추출; v18: DXF title_box·DOCX 한 줄 여러 라벨·gridSpan·PDF DOC NO·XLSX 표제 칸; v17: DXF 표제란 판별·개정 행·한글 개정 라벨(PDF 포함); v16: DXF 표제란다운 삽입·REV#2·속성 행 블록·탭 순서·도면번호 가진 표제란 첫째; v15(줄 끝 정규화 지문): DXF 속성 제외 범위·PDF 고지 문구; v14: DXF 속성 값 본문 제외·PDF 고지 말머리; v13: DXF REV NO·TITLE 레이어, PDF 긴 스캔 고지; v12: PDF REV.A·REV-A; v11: 개정이력 REV 최고값; v10: 개정이력 → REV 필드; v9: 배치공간 글자·세트 PDF 표제란 줄

# 검사 진행 상황 — 같은 프로세스의 웹 대시보드가 읽어 진행률을 보여준다
# (2026-08-28 사용자 요청: "몇 개 검토 중인지 / 몇 %인지 보이게").
# total이 0이면 전체 수를 아직 모르는 단계 → 개수만 표시
PROGRESS = {"phase": "", "done": 0, "total": 0, "current": "", "since": 0.0}

# 내용 비교를 시도하는 파일 크기 상한(MB) — 이보다 크면 변경 사실만 감시하고 내용 비교는
# 생략한다. 100만 선분 PDF·10만 행 엑셀은 분 단위, 병적 파일은 무한이다 (2026-09-04)
from watcher.extract import EXTRACT_MAX_MB, READABLE_EXTS  # noqa: E402  형식 레지스트리에서 파생 (검토19 원칙 ⑤)
SLOW_FILE_SECONDS = 30
EXTRACT_TIMEOUT = 300           # 파일 하나의 내용 추출·그림 상한(초) — config extract_timeout


# 멈춤 요청 — 같은 프로세스의 화면([검사 중지])이 세운다 (2026-09-02)
STOP = threading.Event()


class ScanCancelled(Exception):
    """사람이 검사를 멈췄다. 오류가 아니다."""


def request_stop() -> None:
    STOP.set()


def _set_progress(phase: str, done: int = 0, total: int = 0, current: str = "",
                  keep_since: bool = False) -> None:
    same_phase = PROGRESS.get("phase") == phase
    PROGRESS["phase"], PROGRESS["done"], PROGRESS["total"] = phase, done, total
    if PROGRESS.get("current") != current:
        # 지금 붙잡고 있는 파일과 그 시작 시각 — 한 파일에서 멈추면 화면에 보이게 (2026-09-04).
        # keep_since=폴더를 훑는 중: 표시할 폴더는 초당 수천 번 바뀌지만 시계는 '훑기 시작'부터
        # 흘러야 한다. 리셋하면 늘 (0초째)라 오래 걸림 경고가 영원히 안 뜬다 (7차 중간-C)
        if keep_since and same_phase and PROGRESS.get("current") and PROGRESS.get("since"):
            PROGRESS["current"] = current
        else:
            PROGRESS["current"], PROGRESS["since"] = current, time.time()
    # 진행 표시는 파일마다 갱신된다 — 멈춤을 확인하기에 가장 촘촘한 지점
    if phase and STOP.is_set():
        raise ScanCancelled()


VISUAL_EXTS = RENDER_EXTS + (".dwg",)   # 그림 비교 대상 — DWG는 기록된 그림끼리
DWG_NO_CONVERTER = ("DWG는 변환 프로그램이 있어야 글자·표제란을 읽습니다 (설정 › DWG 도면) "
                    "— 미리보기 그림으로만 비교")


# 이 프로세스(같은 코드)가 그린 판의 해시 — 그 그림만 그림 비교의 새 판으로 다시 쓴다(옛 판 코드가 그린 기록은 그림이 다를 수 있다)
_FRESH_RENDERS: set = set()


def _fresh_renders(state, sha):
    """이 프로세스가 이번에 기록한 판이면 그 그림 (capture.visual_page_diff new_renders), 아니면 None."""
    return state.load_renders(sha) if sha and sha in _FRESH_RENDERS else None


def _wants_render(path: str, doc_or_dict) -> bool:
    """그림 기록 대상인가: DXF는 전부, PDF는 도면으로 보이는 것만 (표제란 항목이
    있거나 이름·폴더가 도면). 사양서·매뉴얼 PDF까지 그리면 DB만 커진다."""
    ext = PurePosixPath(path).suffix.lower()
    if ext not in RENDER_EXTS:
        return False
    if ext == ".dxf":
        return True
    fields = (doc_or_dict.fields if isinstance(doc_or_dict, Document)
              else (doc_or_dict.get("fields") or {}))
    if any(k in fields for k in ("DWG_NO", "REV", "DRAWING_NO")):
        return True
    return kind_of(path) == "도면"


def _dedupe_page_items(items: list) -> list:
    """글자 비교와 그림 비교가 같은 페이지 추가/삭제를 각각 잡으면 하나만 남긴다 —
    글자 쪽(줄 수가 적힌 것)을 우선 (2026-09-06). 둘이 **다른** 페이지를 가리키면
    글자 쪽만 남긴다 — 한 쪽을 지웠는데 "2페이지 삭제"와 "3페이지 삭제"가 함께 실려
    두 쪽 지운 것으로 읽혔다 (검토19 감지 ⑦; 잉크 분포가 비슷한 도면 세트에서 그림
    정렬이 순서대로 짝짓는 한계)."""
    def _is_txt(i) -> bool:
        return "텍스트" in str(i.old or "") + str(i.new or "")
    # 그림 정렬이 글자 비교의 페이지 대응을 앵커로 쓰게 된 뒤로는(검토19 2차 N2) 그림 쪽이
    # 가리키는 '다른 쪽' 삭제도 믿을 수 있다 — 그림만 있는 쪽의 삭제를 통째로 버리던 규칙을
    # 거둔다 (검토19c ③). 같은 쪽을 둘 다 잡았을 때만 글자 쪽을 남긴다
    best: dict = {}
    for i in items:
        if i.kind in ("PAGE_ADDED", "PAGE_REMOVED"):
            k = (i.kind, i.key)
            txt = _is_txt(i)
            if k not in best or (txt and not _is_txt(best[k])):
                best[k] = i
    out, seen = [], set()
    for i in items:
        if i.kind in ("PAGE_ADDED", "PAGE_REMOVED"):
            k = (i.kind, i.key)
            if k in seen or best[k] is not i:
                continue
            seen.add(k)
        out.append(i)
    # 글자 비교가 '쪽 나눔·합침'(글줄이 다른 쪽으로 옮겨짐 — diff._flow_pages)으로 본 판에서 그림 정렬만 짝을 못 찾은 쪽 추가·삭제는
    # 그 나눔·합침이다 — 늘어난(줄어든) 쪽 수가 나눔 표지 수를 넘지 않을 때만 접는다(그림만 있는 쪽을 따로 더한 것은 남는다)
    from watcher.diff import PAGE_FLOW_KEY
    fl_new = sum(1 for i in out if i.kind == "CHECK_SKIPPED" and i.key == PAGE_FLOW_KEY and i.new)
    fl_old = sum(1 for i in out if i.kind == "CHECK_SKIPPED" and i.key == PAGE_FLOW_KEY and i.old)
    if fl_new or fl_old:
        va = [i for i in out if i.kind == "PAGE_ADDED" and not _is_txt(i)]
        vr = [i for i in out if i.kind == "PAGE_REMOVED" and not _is_txt(i)]
        drop = set()
        if va and len(va) <= max(fl_new, 1) and fl_new:
            drop |= set(map(id, va))
        if vr and len(vr) <= max(fl_old, fl_new) and (fl_old or fl_new):
            drop |= set(map(id, vr))
        out = [i for i in out if id(i) not in drop]
    return out


MOVED_KEY = "도면 위치"       # 도면 전체 이동·배율만 바뀐 판의 그림 항목 이름 (capture._moved_only)
FORMAT_ONLY_KEY = "글자 서식"   # 서식만 바뀐 글자 참고 항목 이름 (capture.FORMAT_ONLY)
FORMAT_ONLY_NOTE = "서식만 바뀜"
# diff.content_items가 '전체가 살짝 어긋남' 그림 변경을 Rev 판단 내용에서 뺀다 — 같은 급(자리·배율만)임을 위치 문구에 적는다
MOVED_WHERE = "자리·배율만 바뀜(전체가 살짝 어긋남과 같은 급, 제 범위로 다시 견줌 — 그림은 같음)"


def _add_visual(rd: "RunData", path: str, items: list, vis) -> bool:
    """그림 비교 결과를 항목·캡처로 옮긴다. 돌려주는 값: 비교가 실제로 수행됐는가."""
    if vis is None:  # '비교 못 함'을 '변경 없음'과 구분해 고지 (원칙 4)
        items.append(ChangeItem(
            "CHECK_SKIPPED", "시각 비교", None,
            "수행 못 함: 페이지 렌더 실패 — 그림(도형) 변경은 비교하지 못함 "
            "(글자·표 비교는 위 항목대로)", "시각 비교 단계"))
        return False
    regions, caps = vis
    rot = caps.pop("PAGE_ROTATED", None)
    if rot:
        pgs = ", ".join(f"{p}페이지" for p in rot["pages"][:6])
        items.append(ChangeItem(
            "CHECK_SKIPPED", "페이지 방향", None,
            f"{pgs}의 방향이 돌아갔습니다 — 글자·그림 내용은 같습니다. 재스캔이면 "
            f"무시해도 되고, 일부러 돌린 것이면 인쇄 방향이 바뀝니다", "시각 비교"))
    fmt = caps.pop("FORMAT_ONLY", None)
    if fmt:
        # 글자·자리·크기는 같고 서식(글꼴·색·굵기)만 바뀐 글자 — 그 자리 픽셀 차이는 그림 변경으로 세지 않았다는 사실을 남긴다
        # (검토20 r03 4: 표준 글꼴을 바꾼 날 모든 도면이 거짓 'Rev 미갱신'). 크기·자리 변화는 그대로 그림 변경이다
        ex = ", ".join(f"'{str(x)[:30]}'" for x in (fmt.get("texts") or [])[:3])
        items.append(ChangeItem(
            "CHECK_SKIPPED", FORMAT_ONLY_KEY, None,
            f"{FORMAT_ONLY_NOTE} — 글꼴·색·굵기만 바뀐 글자 {int(fmt.get('n') or 0)}곳"
            + (f" ({ex})" if ex else "") + ": 글자·자리·크기는 같아 그림 변경으로 세지 않았습니다", "그림 비교"))
    beyond = caps.pop("PAGES_BEYOND", None)
    if beyond:
        items.append(ChangeItem("CHECK_SKIPPED", "시각 비교", None,
                                str(beyond.get("where", "")), "시각 비교"))
    moved = caps.pop("DRAWING_MOVED", None)
    if moved:
        # 도면 전체 평행 이동·배율만 바뀐 판 — 바뀐 사실(원칙 5)은 그림 항목으로 남기되(매트릭스 '글자가 자리만 옮겨감'), 위치에
        # '전체가 살짝 어긋남'과 같은 급임을 적어 Rev 판단의 내용에서 빠지게 한다(diff.content_items, 뒤흔들기 DXF C5). 사진 위치가
        # 아니라 regions에 넣지 않는다 — 다른 변경이 없으면 조용한 재저장 줄이 함께 붙는다
        items.append(ChangeItem("PAGE_VISUAL_CHANGED", MOVED_KEY, None, str(moved.get("where", "")),
                                f"도면 전체 — {MOVED_WHERE}"))
    grew = caps.pop("AREA_GREW", None)
    if grew:
        # 픽셀 비교로는 영영 안 보이는 변경 — 사실 자체를 알린다 (원칙 5)
        items.append(ChangeItem(
            "PAGE_VISUAL_CHANGED", "도면 범위", None,
            f"도면 범위가 넓어졌습니다 — {grew['where']}에 내용이 "
            f"새로 그려졌습니다. 그 부분은 이전 판에 없어 전/후 사진으로 겹쳐 볼 수 "
            f"없으니 파일을 열어 확인하세요", "도면 전체"))
    for key, where in regions:
        items.append(ChangeItem(
            "PAGE_VISUAL_CHANGED", key, None, _visual_note(where), where))
    # 페이지가 빠지거나 끼어든 것 — 글자 비교가 이미 같은 페이지를 잡았으면 중복 보고하지 않는다
    # (2026-09-06: 페이지 삭제로 번호가 밀리면 뒤 페이지가 전부 '신규'로 보이던 것)
    have_pages = {(i.kind, i.key) for i in items if i.kind in ("PAGE_ADDED", "PAGE_REMOVED")}
    for key, cap in caps.items():
        if key == "PAGE_MAP":
            rd.captures[(path, "PAGE_MAP")] = cap
            continue
        kind, _, pkey = key.partition("|")
        if kind in ("PAGE_ADDED", "PAGE_REMOVED", "PAGE_MOVED"):
            where = cap.get("where", pkey)
            if (kind, pkey) not in have_pages:      # 글자 비교 항목은 나중에 합쳐질 수 있어
                items.append(ChangeItem(kind, pkey, None if kind in ("PAGE_ADDED", "PAGE_MOVED") else where,
                                        where if kind in ("PAGE_ADDED", "PAGE_MOVED") else None, where))
            if cap.get("before") or cap.get("after"):
                rd.captures[(path, key)] = {"before": cap.get("before"), "after": cap.get("after")}
            continue
        rd.captures[(path, f"PAGE_VISUAL_CHANGED|{key}")] = cap
    return True


class LazyDocs(Mapping):
    """경로 → Document 사전이되, 문서는 필요할 때 추출 캐시(DB)에서 읽고 최근 것만
    몇 천 개 들고 있는다. 4만 파일의 추출본을 검사 내내 전부 메모리에 올리던 것
    (2026-09-04 검토 core H5: +1.4GB, 실서버는 몇 배 → MemoryError 뒤 매일 롤백)."""

    def __init__(self, state: State, keep: int = 2048):
        self._state = state
        self._sha: dict[str, str] = {}
        self._live: "OrderedDict[str, Document]" = OrderedDict()
        self._keep = keep
        # 이번 검사에서 **옛 기록이 있는데 다시 읽은** 경로 — 지문이 같아도 추출본이 달라졌을 수 있다(키 열·OCR 설정, 세대
        # 바닥). 교차 검사 생략 판정(R3-F1)이 이 경로가 든 프로젝트는 다시 본다. 처음 보는 지문은 그 자체로 묶음 지문이 바뀐다
        self.fresh_extract: set = set()

    def register(self, path: str, sha: str, doc: "Document | None" = None, reread: bool = False) -> None:
        self._sha[path] = sha
        if doc is not None:
            self._put(path, doc)
        if reread:
            self.fresh_extract.add(path)
        else:
            self.fresh_extract.discard(path)

    def sha_of(self, path: str) -> str | None:
        return self._sha.get(path)

    def _put(self, path: str, doc: "Document") -> None:
        self._live[path] = doc
        self._live.move_to_end(path)
        while len(self._live) > self._keep:
            self._live.popitem(last=False)

    def __getitem__(self, path: str) -> "Document":
        d = self._live.get(path)
        if d is not None:
            self._live.move_to_end(path)
            return d
        sha = self._sha[path]                       # KeyError = 없는 경로 (dict와 같게)
        cached = self._state.load_extract(sha, path)
        if cached is None or "doc_type" not in cached:
            raise KeyError(path)
        d = Document.from_dict(cached)
        self._put(path, d)
        return d

    def __iter__(self):
        return iter(self._sha)

    def __len__(self) -> int:
        return len(self._sha)

    def __contains__(self, path) -> bool:
        return path in self._sha


def _extract_docs(state: State, abs_of: dict, records,
                  cfg: dict | None = None) -> tuple[Mapping, dict]:
    """현재 스냅샷의 문서 추출 (내용 해시 캐시). 실패는 (경로→사유)로 수집.
    돌려주는 docs는 지연 적재 사전(LazyDocs) — dict처럼 쓰되 전부를 들고 있지 않는다."""
    docs = LazyDocs(state)
    failures: dict[str, str] = {}
    total = len(records)
    known_hints = state.hints()          # 바뀐 것만 쓴다 — 검사 내내 쓰기 잠금 방지

    def _hint(path: str, sha: str, doc_or_dict) -> None:
        h = content_hint(doc_or_dict)
        if known_hints.get(path) != h:
            state.save_hint(path, sha, h)

    # 파일을 실제로 여는 일은 자식 프로세스에서 — 한 파일이 라이브러리 안에서 멈춰도 상한
    # (기본 300초)에서 끊고 다음 파일로 간다 (2026-09-05, 회사 PC "63/4,059 (1%) 멈춤").
    # 자식을 못 띄우면 예전처럼 같은 프로세스에서 연다
    from watcher.worker import ExtractTimeout, ExtractWorker, RemoteError
    # 표의 행 식별 열 — 설정 key_columns (2026-09-06 정밀화). 같은 프로세스 추출기에도 넣는다
    key_cols = [str(c).strip() for c in ((cfg or {}).get("key_columns") or []) if str(c).strip()]
    from watcher.extract import pdf as _pdf_mod
    from watcher.extract import xlsx as _xlsx_mod
    _xlsx_mod.USER_KEY_COLS = tuple(key_cols)
    ocr_on = bool((cfg or {}).get("ocr", True))         # 글자 없는 PDF를 Windows OCR로 (2026-09-06)
    _pdf_mod.OCR_ENABLED = ocr_on
    try:
        from watcher import ocr as _ocr_mod
        ocr_stamp = f"on:{_ocr_mod.language() or 'none'}" if ocr_on and _ocr_mod.available() else ("on:none" if ocr_on else "off")
    except Exception:
        ocr_stamp = "on:none" if ocr_on else "off"

    def _fresh(path: str, cached) -> bool:
        """저장된 추출본을 그대로 써도 되나 — 엑셀은 키 열 설정이 바뀌면 행 키가 달라져 다시 읽는다."""
        if not (cached is not None and "notes" in cached and _cache_ok(cached, path)):
            return False
        if PurePosixPath(path).suffix.lower() in (".xlsx", ".xlsm"):
            return list(cached.get("key_cols") or []) == key_cols
        if PurePosixPath(path).suffix.lower() == ".pdf":
            # OCR이 관여한 PDF(읽었거나 못 읽은 것)만 도장을 비교한다 — 글자 있는 PDF 수천 개를 토글마다
            # 다시 읽지 않게 (리뷰12 운영 중간-3). 도장 없는 '못 읽음' 기록(v0.50)은 한 번 다시 읽는다
            if "ocr" in cached:
                return cached["ocr"] == ocr_stamp
            return not any("텍스트가 거의 추출되지" in str(n) for n in (cached.get("notes") or []))
        return True

    def _stamp(path: str, d: dict) -> dict:
        if PurePosixPath(path).suffix.lower() in (".xlsx", ".xlsm"):
            d["key_cols"] = key_cols
        if PurePosixPath(path).suffix.lower() == ".pdf" and _ocr_involved(d):
            d["ocr"] = ocr_stamp
        return d
    worker: ExtractWorker | None = None
    try:
        cur_timeout = float((cfg or {}).get("extract_timeout") or EXTRACT_TIMEOUT)
    except (TypeError, ValueError):
        cur_timeout = float(EXTRACT_TIMEOUT)
    if (cfg or {}).get("extract_worker", True) and not os.environ.get("DREV_NO_WORKER"):
        timeout = cur_timeout
        w = ExtractWorker(timeout=timeout, cancel=STOP.is_set)
        if w.ping() and w.configure(key_cols, ocr_on):
            worker = w
        elif w.alive():
            w.kill()
            print("  참고: 내용 추출 자식 프로세스에 표 키 열 설정을 전하지 못해 같은 프로세스에서 엽니다",
                  file=sys.stderr)
        else:
            w.kill()
            print("  참고: 내용 추출 자식 프로세스를 띄우지 못해 같은 프로세스에서 엽니다 "
                  "(파일 하나가 멈추면 검사가 함께 멈출 수 있음)", file=sys.stderr)

    def _cancelled(e: RemoteError) -> bool:
        return getattr(e, "error_type", "") == "Cancelled"

    def _do_extract(abs_path):
        if worker is None:
            return extract(abs_path)
        try:
            return worker.extract(abs_path)
        except RemoteError as e:
            if _cancelled(e):
                raise ScanCancelled()
            raise

    def _do_render(abs_path, kind: str = "file"):
        if worker is None:
            return render_dxf(abs_path) if kind == "dxf" else render_file(abs_path)
        try:
            return worker.render(abs_path, kind)
        except RemoteError as e:
            if _cancelled(e):
                raise ScanCancelled()
            raise

    def _timeout_note(e: ExtractTimeout) -> str:
        return (f"{e} — 내용 비교를 생략하고 변경 사실만 감시합니다 (파일이 바뀌면 다시 시도, "
                f"상한은 설정 › 고급 › '파일 하나 시간 상한')")

    def _render(path: str, sha: str, abs_path, doc_or_dict) -> None:
        """도면이면 페이지 그림을 기록 — 같은 이름으로 덮어써도 전/후 그림 비교가
        되게 하는 '이전 판' (2026-09-02). 판(해시)당 한 번만 렌더한다."""
        if not _wants_render(path, doc_or_dict) or state.has_renders(sha):
            return
        if state.get_meta(f"render_skip:{sha}"):
            return                         # 지난번 상한을 넘긴 판 — 매일 5분씩 다시 멈추지 않게
        try:
            pages = _do_render(abs_path)
        except ExtractTimeout as e:
            state.set_meta(f"render_skip:{sha}", str(e))
            print(f"  경고: 페이지 그림 기록 중단 {path}: {_timeout_note(e)}", file=sys.stderr)
            return
        except ScanCancelled:
            raise                          # 사람이 멈춘 것 — 실패가 아니다 (리뷰11 차단)
        except Exception as e:
            if "그림 기록 상한" in str(e):
                # 심볼 라이브러리를 겹겹이 쌓은 도면 — 그리기 전에 규모를 재서 건너뛴다. 판(해시)당
                # 한 번만 알리고 다시 시도하지 않는다 (검토19c ⑤). 글자 비교는 그대로 된다
                state.set_meta(f"render_skip:{sha}", str(e))
                print(f"  참고: 페이지 그림 기록 생략 {path}: {clean_text(str(e))} — 글자·표제란 비교만 합니다",
                      file=sys.stderr)
                return
            print(f"  경고: 페이지 그림 기록 실패 {path}: {clean_text(str(e))}",
                  file=sys.stderr)
            return
        if pages:
            if str(path).lower().endswith(".dxf"):
                # 글자 자리도 함께 기록 — 이 판이 '옛 판'이 된 뒤 지워진 글줄의 자리를 가리려면 파일이
                # 없어도 자리를 알아야 한다 (검토21 재검증 D9)
                from watcher.capture import attach_text_boxes
                attach_text_boxes(abs_path, pages)
            state.save_renders(sha, pages)
            _FRESH_RENDERS.add(sha)

    conv = resolve_converter(cfg)
    try:
        from watcher.convert import sweep_temp
        sweep_temp()                       # 지난 강제 종료가 남긴 임시 DWG 폴더 정리 (재검토 ⑥)
    except Exception:
        pass
    # 스크립트 방식이 대화상자(글꼴 누락 등)에서 멈춘 적이 있으면 며칠간 CAD를 띄우지
    # 않는다 — 매일 3분씩 CAD가 켜졌다 죽는 것 방지. [DWG 변환 시험]이 풀어 준다 (2026-09-04)
    backoff_note = None
    until = state.get_meta("dwg_backoff_until")
    if conv is not None and until:
        try:
            until_dt = datetime.fromisoformat(until)
        except ValueError:
            until_dt = None
        if until_dt and until_dt > datetime.now():
            backoff_note = (f"DWG 변환 프로그램({conv['name']})이 대화상자에서 멈춘 적이 있어 "
                            f"{until_dt:%m-%d}까지 변환을 건너뜁니다 — 빠진 글꼴을 채우거나 ODA File "
                            f"Converter를 설치한 뒤 설정 › [DWG 변환 시험]으로 다시 켜세요")
            conv = None
        else:
            state.set_meta("dwg_backoff_until", None)
    if backoff_note:
        print(f"  {backoff_note}", flush=True)
    if conv is None and any(r.path.lower().endswith(".dwg") for r in records):
        from watcher.convert import status as _conv_status
        print(f"  DWG 변환 프로그램: {_conv_status(cfg)[1]}", flush=True)

    def _dwg(r, cached) -> None:
        """DWG: 변환 프로그램이 있으면 DXF로 바꿔 글자·그림을, 없으면 미리보기 그림만.
        실패는 캐시하지 않는다 — 나중에 변환 프로그램을 설치하면 바로 살아나게 (2026-09-03)."""
        ap = abs_of[r.path]
        doc_ok = (cached is not None and "notes" in cached and _cache_ok(cached, r.path))
        if doc_ok:
            docs.register(r.path, r.sha256)
            _hint(r.path, r.sha256, cached)
            if state.has_renders(r.sha256):
                return
        if conv is not None and not doc_ok:
            res = batch.get(Path(ap))
            try:
                if not isinstance(res, Path):
                    raise RuntimeError(res or "이번 검사의 변환 묶음에 없음")
                doc = _do_extract(res)
                pages = _do_render(res, "dxf")
            except ExtractTimeout as e:
                failures[r.path] = f"DWG 읽기 중단: {_timeout_note(e)}"
                state.save_extract(r.sha256, {"extract_failed": failures[r.path],
                                              "cache_ver": _CACHE_VER, "timeout_s": cur_timeout}, r.path)
                print(f"  경고: {failures[r.path]} — {r.path}", file=sys.stderr)
            except ScanCancelled:
                raise
            except Exception as e:
                failures[r.path] = f"DWG 변환 실패({conv['name']}): {_strip_paths(clean_text(str(e)))}"   # 변환기 출력 속 경로 (검토48 E 낮음 3)
                print(f"  경고: {failures[r.path]} — {r.path}", file=sys.stderr)
            else:
                if doc is not None:
                    doc = Document.from_dict({**doc.to_dict(), "doc_type": "dwg", "path": r.path})
                    state.save_extract(r.sha256, {**doc.to_dict(), "cache_ver": _CACHE_VER}, r.path)
                    docs.register(r.path, r.sha256, doc, reread=cached is not None)
                    _hint(r.path, r.sha256, doc)
                if pages:
                    state.save_renders(r.sha256, pages)
                    return
        if not state.has_renders(r.sha256) and not state.get_meta(f"render_skip:{r.sha256}"):
            try:
                pages = _do_render(ap)               # 파일 안의 미리보기 그림
            except ExtractTimeout as e:
                state.set_meta(f"render_skip:{r.sha256}", str(e))
                pages = []
            except ScanCancelled:
                raise
            except Exception:
                pages = []
            if pages:
                state.save_renders(r.sha256, pages)
        if conv is None and not doc_ok:
            failures[r.path] = backoff_note or DWG_NO_CONVERTER

    # 지난 검사가 어느 파일을 처리하다 죽었는가(창 닫힘·강제 종료) — 같은 파일이 매번 검사를
    # 붙잡는 '독 파일'이 되지 않게 이번에는 건너뛰고, 파일이 바뀔 때까지 다시 시도하지 않는다
    stale = state.get_meta("extract_in_progress") or ""
    stale_sha = stale.split("|", 1)[0] if stale else ""
    if stale:
        state.set_meta("extract_in_progress", None)
        # 창 닫기·강제 종료 때 우연히 열려 있던 정상 파일까지 영구 건너뛰기가 되지 않게 —
        # **두 번 연속** 같은 판에서 죽었을 때만 독 파일로 본다 (재검토 ②)
        if state.get_meta("poison_candidate") == stale_sha:
            print(f"  지난 검사 두 번이 {stale.split('|', 1)[-1]} 처리 중에 끝나 이번에는 그 파일의 "
                  f"내용 비교를 건너뜁니다", file=sys.stderr)
        else:
            state.set_meta("poison_candidate", stale_sha)
            print(f"  지난 검사가 {stale.split('|', 1)[-1]} 처리 중에 끝났습니다 — 이번에 다시 시도하고, "
                  f"또 멈추면 건너뜁니다", file=sys.stderr)
            stale_sha = ""
    poison_cand = state.get_meta("poison_candidate") or ""

    def _guard(r, on: bool) -> None:
        """실제로 파일을 여는 동안만 표식을 둔다 (캐시된 것은 표식 없음)."""
        state.set_meta("extract_in_progress", f"{r.sha256}|{r.path}" if on else None)

    def _too_big(r) -> str | None:
        cap = EXTRACT_MAX_MB.get(PurePosixPath(r.path).suffix.lower())
        size = getattr(r, "size", 0) or 0
        if cap and size > cap * 1024 * 1024:
            return (f"파일이 너무 큽니다({size / 1048576:.0f}MB, 상한 {cap}MB) — 변경 사실만 감시하고 "
                    f"내용 비교는 생략합니다")
        return None

    def _extract_loop(state, abs_of, records, total, docs, failures, _hint, _dwg) -> None:
        for i, r in enumerate(records, 1):
            _set_progress("2/3 내용 추출", i, total, current=r.path)
            if i % 100 == 0:
                print(f"  내용 추출 {i}/{total}…", flush=True)
            if not r.path.lower().endswith(".dwg") and PurePosixPath(r.path).suffix.lower() not in READABLE_EXTS:
                # 내용을 읽지 않는 형식(.hwp·.xls·.csv…)은 추출기가 늘 None이다 — 그래도 파일마다 기록 조회·표식 쓰기 두 번·
                # 추출 자식 왕복을 매일 했다(10만 파일 무변경 날 28초, 검토20 r15-4). 결과가 같으므로 바로 넘어간다
                continue
            cached = state.load_extract(r.sha256, r.path)
            if stale_sha and r.sha256 == stale_sha and not (
                    cached is not None and "notes" in cached):
                failures[r.path] = ("지난 검사가 이 파일을 처리하다 멈춰 이번에는 내용 비교를 "
                                    "건너뜁니다 (파일이 바뀌면 다시 시도). 너무 크거나 깨진 파일이면 "
                                    "감시 제외에 추가하세요")
                state.save_extract(r.sha256, {"extract_failed": failures[r.path],
                                              "cache_ver": _CACHE_VER}, r.path)
                state.set_meta("poison_candidate", None)
                continue
            if r.path.lower().endswith(".dwg"):
                _guard(r, True)
                t0 = time.monotonic()
                _dwg(r, cached)
                _guard(r, False)
                if time.monotonic() - t0 > SLOW_FILE_SECONDS:
                    print(f"  느린 파일: {r.path} ({time.monotonic() - t0:.0f}초)", file=sys.stderr)
                continue
            big = _too_big(r)
            if big and not (cached is not None and "notes" in cached):
                failures[r.path] = big
                if cached is None or cached.get("extract_failed") is None:
                    state.save_extract(r.sha256, {"extract_failed": big, "cache_ver": _CACHE_VER}, r.path)
                continue
            # 실패 캐시: 암호·손상 파일을 매 검사마다 다시 여는 낭비 방지 (2026-08-29
            # — 4만 파일 실서버에서 수백 건이 매일 재시도되던 것). 파일이 바뀌면
            # 해시가 달라져 자동으로 재시도된다
            # 시간 상한 실패는 **그때 상한**보다 지금 상한이 크면 다시 읽는다 — 상한을 올려도 그 판을 영영 다시 읽지 않았다
            # (고장 주입 2026-10-26 F4)
            if cached is not None and cached.get("extract_failed") is not None \
                    and _cache_ok(cached, r.path) and not _timeout_raised(cached, cur_timeout):
                failures[r.path] = cached["extract_failed"]
                continue
            # 구버전 스키마(notes 없음)나 다른 추출 엔진 세대의 저장분은 재추출 —
            # 엔진이 다르면 줄 나뉨이 달라 섞어 비교하면 소음이 난다 (2026-08-26 pdfium 교체)
            if _fresh(r.path, cached):
                docs.register(r.path, r.sha256)        # 필요할 때 다시 읽는다
                _hint(r.path, r.sha256, cached)
                if poison_cand and r.sha256 == poison_cand:
                    # 추출본은 이미 있었고 그림 기록 중에 죽은 경우 — 여기서도 후보를 풀어야
                    # 다음에 걸리면 '두 번째'로 세지 않는다 (검토19 감지 ⑩)
                    state.set_meta("poison_candidate", None)
                if not state.has_renders(r.sha256):
                    _guard(r, True)
                    _render(r.path, r.sha256, abs_of[r.path], cached)
                    _guard(r, False)
                continue
            _guard(r, True)
            t0 = time.monotonic()
            try:
                doc = _do_extract(abs_of[r.path])
            except ExtractTimeout as e:
                failures[r.path] = _timeout_note(e)
                print(f"  경고: 추출 중단 {r.path}: {failures[r.path]}", file=sys.stderr)
                # 처음 한 번은 캐시하지 않는다 — PC가 잠깐 느렸던 것(백신·다른 작업)까지 그 판을 영영 다시 읽지 않았다
                # (검토60 ②). 같은 판이 다음 검사에서도 상한에 걸리면 그때 캐시
                _tk = f"timeout_once:{r.sha256}"
                if state.get_meta(_tk):
                    state.save_extract(r.sha256, {"extract_failed": failures[r.path],
                                                  "cache_ver": _CACHE_VER, "timeout_s": cur_timeout}, r.path)
                    state.set_meta(_tk, None)
                else:
                    state.set_meta(_tk, "1")
                _guard(r, False)
                continue
            except ScanCancelled:
                _guard(r, False)
                raise                      # [검사 중지] — '추출 실패'로 캐시하면 다음 검사부터 매일 실패로 나온다 (리뷰11 차단)
            except Exception as e:  # 손상 파일 등 — 파일 수준 감지는 이미 됐음
                # 예외 메시지에도 깨진 인코딩이 실려 올 수 있다 — 그대로 DB·브리핑에
                # 들어가면 저장이 죽는다 (2026-08-27 회사 실파일)
                failures[r.path] = _friendly_error(e)
                print(f"  경고: 추출 실패 {r.path}: {failures[r.path]}", file=sys.stderr)
                # 잠김·순단(OSError)은 일시적일 수 있어 캐시하지 않는다. 사유가 비어 있으면 무엇인지
                # 모르는 실패라 캐시하지 않는다
                # 단 ezdxf 파서가 내는 IOError('… is not a DXF file')는 errno 없는 영구 실패다 — 위장·깨진 DXF를 매일 다시
                # 열었다 (검토58 F6 F9). 그 밖의 OSError(잠김·순단)는 그대로 일시적
                _dxf_parse = getattr(e, "errno", None) is None and bool(re.search(r"not a DXF file|DXFStructureError", str(e)))
                # 잘린 zip(errno 22)·통합문서 본체 없음도 영구 손상이다 — 일시적으로 보아 매일 다시 열었다 (검토63 D-F5)
                _dxf_parse = _dxf_parse or bool(re.search(r"Errno 22|no valid workbook part", str(e), re.I))
                # 추출 자식(기본 경로)이 보낸 오류도 — 자식의 OSError는 일시적으로 분류돼 검토58 고침이 먹지 않았다 (검토59 F1 F-2)
                transient = (isinstance(e, OSError) and not _dxf_parse) or (
                    isinstance(e, RemoteError) and not _dxf_parse and (e.transient or e.error_type in ("WorkerDied", "BrokenPipe", "ConfigLost")))
                if not transient and failures[r.path].strip():
                    state.save_extract(r.sha256, {
                        "extract_failed": failures[r.path], "cache_ver": _CACHE_VER}, r.path)
                _guard(r, False)
                continue
            if doc is not None:
                # 해시한 뒤 읽기 전에 파일이 또 저장됐으면(긴 검사 도중 덮어쓰기) 읽은 내용은 **지금** 판의 것이다 — 스캔 때
                # 지문 아래 두면 다음 검사가 '내용 변경 없음 — 다시 저장되기만'이라는 거짓 안내를 냈다 (검토59 F6-1).
                # 지금 판의 지문 아래 둔다(오늘 비교는 최신 내용으로)
                _key_sha = r.sha256
                try:
                    _st = Path(abs_of[r.path]).stat()
                    if _st.st_size != r.size or abs(_st.st_mtime - float(r.mtime or 0)) > 1e-3:
                        from watcher.scan import sha256_of as _sha_of
                        _now = _sha_of(Path(abs_of[r.path]))
                        if _now != r.sha256:
                            _key_sha = _now
                            print(f"  참고: 검사 도중 다시 저장된 파일 — 최신 내용으로 비교합니다: {r.path}", file=sys.stderr)
                            # 스냅샷·오늘 변경 기록도 지금 판으로 — 스캔 때 지문으로 두면 지금 판 추출본이 검사 끝 정리에서 지워지고,
                            # 이튿날 같은 변경을 또 보고하고 Rev 미갱신을 두 번 냈다 (검토63 B-F5)
                            try:
                                state.conn.execute(
                                    "UPDATE files SET sha256 = ?, size = ?, mtime = ? WHERE path = ? AND sha256 = ? "
                                    "AND snapshot_id = (SELECT MAX(id) FROM snapshots)",
                                    (_now, _st.st_size, _st.st_mtime, r.path, r.sha256))
                                state.conn.execute(
                                    "UPDATE changes SET new_sha256 = ? WHERE path = ? AND new_sha256 = ? "
                                    "AND snapshot_id = (SELECT MAX(id) FROM snapshots)", (_now, r.path, r.sha256))
                            except Exception as _e:      # noqa: BLE001
                                print(f"  참고: 다시 저장된 파일의 기록 갱신 실패({type(_e).__name__})", file=sys.stderr)
                except (OSError, TypeError, ValueError):
                    pass
                state.save_extract(_key_sha, _stamp(r.path, {**doc.to_dict(), "cache_ver": _CACHE_VER}), r.path)
                docs.register(r.path, _key_sha, doc)     # 메모리에서 밀려나도 같은 지문으로 다시 읽게
                if cached is not None and _key_sha == r.sha256:
                    docs.fresh_extract.add(r.path)       # 옛 기록이 있던 지문을 다시 읽음 — 교차 검사 생략 금지 (R3-F1)
                # 내용에서 읽은 유형 단서 — 파일명에 이름이 없는 견적서 등 (2026-09-02)
                _hint(r.path, r.sha256, doc)
                _render(r.path, r.sha256, abs_of[r.path], doc)
            _guard(r, False)
            if poison_cand and r.sha256 == poison_cand:
                state.set_meta("poison_candidate", None)   # 다시 시도해 성공 — 후보 해제
            if time.monotonic() - t0 > SLOW_FILE_SECONDS:
                print(f"  느린 파일: {r.path} ({time.monotonic() - t0:.0f}초)", file=sys.stderr)

    # DWG는 검사당 한 번의 실행으로 묶어 변환한다 — 장마다 CAD가 켜졌다 꺼지던 것
    # (2026-09-03). 이미 읽은 판(추출본 있음)은 다시 변환하지 않는다
    batch: dict = {}
    pending = []
    if conv is not None:
        for r in records:
            if not r.path.lower().endswith(".dwg"):
                continue
            c_ = state.load_extract(r.sha256, r.path)
            if not (c_ is not None and "notes" in c_ and _cache_ok(c_, r.path)):
                pending.append(Path(abs_of[r.path]))
    with contextlib.ExitStack() as stack:
        if pending:
            print(f"  DWG 변환: {conv['name']} — {len(pending)}장을 한 번에", flush=True)
            # 화면이 '멈춘 것처럼' 보이지 않게 — CAD가 도는 동안의 단계 표시 (2026-09-04)
            phase = f"DWG 변환 중 — {conv['name']} 실행 (결과가 3분간 없으면 자동 중단)"
            _set_progress(phase, 0, len(pending))
            # [검사 중지]가 CAD 묶음 도중에도 바로 먹고, 묶음마다 진행이 올라가게 (2026-09-04)
            batch = stack.enter_context(converted_many(
                pending, conv, cancel=STOP.is_set,
                progress=lambda k, n: PROGRESS.update({"phase": phase, "done": k, "total": n})))
            if STOP.is_set():
                raise ScanCancelled()
            from watcher.convert import DIALOG_LOG, UNKNOWN_DIALOGS
            if DIALOG_LOG:
                kinds = sorted({f"'{ttl[:40]}' → [{btn}]" for ttl, btn in DIALOG_LOG})
                print(f"  CAD 대화상자 자동 응답 {len(DIALOG_LOG)}건: {'; '.join(kinds)}", flush=True)
            for ttl, btns in UNKNOWN_DIALOGS:
                print(f"  경고: 모르는 CAD 대화상자 '{ttl}' (버튼: {', '.join(btns) or '없음'}) — "
                      f"이 문구를 알려주시면 다음 판에서 자동 응답합니다", file=sys.stderr)
            if conv.get("kind") == "cadscript" and any(
                    isinstance(v, str) and "대화상자" in v for v in batch.values()):
                # 백오프는 CAD 창을 빌리는 방식에만 — ODA의 거대 도면 지연은 대화상자가 아니다 (재검토 ⑪)
                state.set_meta("dwg_backoff_until",
                               (datetime.now() + timedelta(days=7)).isoformat(timespec="minutes"))
        try:
            _extract_loop(state, abs_of, records, total, docs, failures, _hint, _dwg)
        finally:
            if worker is not None:
                if worker.timeouts or worker.restarts:
                    print(f"  내용 추출 프로세스: 상한 초과 {worker.timeouts}회, 다시 띄움 "
                          f"{worker.restarts}회", flush=True)
                worker.close()
    state.conn.commit()
    HINTS.clear()
    HINTS.update(state.hints())               # 이번 검사의 보고·화면이 바로 쓰게
    return docs, failures


# 따옴표로 **감싸인** 경로는 닫는 따옴표까지(공백 포함), 그 밖은 공백 전까지 (재검증 N3, 2차: 따옴표가
# 뒤쪽 어딘가에만 있으면 문장까지 삼키던 것)
_QUOTED_PATH_RE = re.compile(r"(?<=['\"])(?:[A-Za-z]:\\|\\\\)[^'\"\r\n]*?(?=['\"])")
_ABS_PATH_RE = re.compile(r"(?:[A-Za-z]:\\|\\\\)[^\s'\"()]+")


def _strip_paths(s: str) -> str:
    """문장 속 서버 절대 경로를 지운다 — 메일은 파일 이름만 말한다 (검토21 브리핑 중간 7)."""
    def _name(m):
        return "(경로 생략)/" + m.group(0).rstrip("\\").rsplit("\\", 1)[-1]
    return _ABS_PATH_RE.sub(_name, _QUOTED_PATH_RE.sub(_name, s))


def _issued_of_rev(latest: dict, path: str, doc, proj) -> tuple | None:
    """이 Rev가 이미 출도됐나 — 같은 프로젝트의 가장 나중 출도본. 없거나 그 Rev가 원본 지금 Rev보다 낮으면(Rev A 출도 뒤 Rev B 작업
    중, 그 Rev는 아직 발행 전) None. 출도본 Rev를 모르면 낮다고 하지 않는다 (ux24 RD6, '작업본' 안내 _issued_rev_same)."""
    from watcher.issued import _pick_issued, _rev_lower, doc_key
    cur = _pick_issued(latest, doc_key(path, doc), path, proj)
    return None if cur is None or _rev_lower(cur[3], getattr(doc, "revision", None)) else cur


def _issued_rev_same(state: State, docs, issues: list, proj_of: dict) -> list:
    """이 Rev로 이미 출도된 도면의 'Rev 미갱신'에서 '(발행 전 작업본이면 무시하세요)'를 뺀다 — 출도본이 있는데 작업본이라 했다 (ux24 RD6).
    출도본 Rev가 원본 지금 Rev보다 낮으면(Rev A 출도 뒤 Rev B 작업 중) 그 Rev는 아직 발행 전이라 안내가 맞다. 대조 키(state.issue_key)는
    괄호를 안 보므로 열린 이슈는 그대로 이어진다."""
    from watcher.consistency import _canon_project, without_wip_hint
    from watcher.issued import _latest_issued
    code = "CONTENT_CHANGED_REV_SAME"
    if not any(i.code == code for i in issues):
        return issues
    latest = _latest_issued(state)
    if not latest:
        return issues
    out = []
    for i in issues:
        if i.code == code:
            doc = docs.get(i.path)
            name, why = (proj_of.get(i.path) or (None, "미분류"))[:2]
            if _issued_of_rev(latest, i.path, doc, None if why == "미분류" or not name else _canon_project(name)) is not None:
                i = Issue(i.code, i.path, without_wip_hint(i.message), i.evidence, i.absorbed)
        out.append(i)
    return out


def _resolved_this_run(state: State, since_auto: str | None, since_track: str | None) -> dict:
    """이번 검사에서 자동 해소된 검토 필요 {프로젝트: [이슈]}. since_auto: 재검출 판정을 시작한 시각(그 판정이 닫은 것이 없으면 None).
    since_track: 출도·발주 기록을 시작한 시각 — '출도 후 변경'의 '새 출도본이 들어옴' 해소는 재검출 판정보다 앞서(issued.track) 닫혀,
    DB에는 3건인데 메일 '해소된 검토 필요'에는 2건이었다 (ux24 RD3). 그 종류만 앞 시각으로 본다."""
    from watcher.issued import POST_ISSUE_CODE
    post = since_track is not None and state.conn.execute(
        "SELECT 1 FROM issues WHERE code = ? AND resolved_at >= ? LIMIT 1", (POST_ISSUE_CODE, since_track)).fetchone() is not None
    out: dict = {}
    if since_auto is None and not post:
        return out
    for d in state.issues(resolved=True):
        at = str(d.get("resolved_at") or "")
        if str(d.get("resolved_by") or "").startswith("자동 해소") and (
                (since_auto is not None and at >= since_auto)
                or (post and d.get("code") == POST_ISSUE_CODE and at >= since_track)):
            out.setdefault(d["project"], []).append(d)
    return out


def _ordered_tags(state: State, proj, paths) -> set | None:
    """이 프로젝트 발주서(po_lines)에 오른 태그·품번(접은 꼴) — 메일 머리 한 줄이 이미 발주된 품목에 '발주 전 확인'이라 하지 않게 (ux24 RD1).
    같은 태그 다른 프로젝트는 다른 기기다 — 범위는 출도·발주와 같은 규칙(issued._same_scope). 못 읽으면 None(모름)."""
    from watcher.consistency import _canon_project
    from watcher.issued import _same_scope
    mine = _canon_project(str(proj)) if proj and proj != "미분류" else ""
    try:
        rows = state.conn.execute("SELECT DISTINCT tag, path, project FROM po_lines").fetchall()
    except sqlite3.Error:
        return None
    return {tag for tag, po_path, po_proj in rows
            if any(_same_scope(po_path, po_proj, p_, mine) for p_ in paths)}


def _msg_core(msg) -> str:
    """경고 문구의 뼈대 — 괄호 속 값·건수('(외 도면 1장에서도 불일치)')를 뺀 것. 같은 경고인지 견줄 때."""
    return re.sub(r"\s+", " ", re.sub(r"\([^)]*\)", "", str(msg or ""))).strip()


def _friendly_error(e: Exception) -> str:
    """라이브러리 오류 원문("File is not a zip file")을 담당자 말로 (2026-09-05 전체 검토)."""
    # 제어 문자(NUL·0x19)가 브리핑 HTML에 날것으로 들어갔다 (검토63 D-F10)
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", clean_text(str(e)))
    low = s.lower()
    tname = (getattr(e, "error_type", "") or type(e).__name__).lower()
    # 원문은 짧게 — 깨진 바이트가 2.7KB 그대로 화면·메일에 실렸다(DXF·zip·그 밖의 가지 모두) (검토45·46 A 낮음)
    # 경로를 먼저 지우고 자른다 — 자른 뒤 지우면 잘린 경로가 지우기 규칙에 안 걸려 고객명 폴더가 메일에 실렸다 (검토47 A 중간 4)
    s = _strip_paths(s)
    s = s[:120] + ("…" if len(s) > 120 else "")
    if "not a dxf file" in low or "invalid dxf" in low or "dxfstructureerror" in tname:
        return f"DXF 파일로 읽을 수 없음 — 저장 중 끊겼거나 확장자와 내용이 다른 파일일 수 있습니다 ({s})"
    if "not a zip file" in low or "bad zip" in low or "badzipfile" in tname:
        return f"파일이 깨져 열 수 없음 — 저장 중 끊겼거나 확장자와 내용이 다른 파일일 수 있습니다 ({s})"
    if "password" in low or "encrypted" in low:
        return f"암호가 걸린 파일이라 내용을 읽지 못함 ({s})"
    # zip은 열리는데 본체(word/document.xml 등)가 없다 — 영문 원문 'There is no item named …'이 근거에 그대로 실렸다 (검토53 B F14)
    if "there is no item named" in low:
        return f"문서 본체가 없는 손상 파일 — 저장 중 끊겼거나 다른 프로그램이 만든 파일일 수 있습니다 ({s})"
    # PDFium 원문 'Failed to load document'가 대시보드 사유 묶음 이름으로 영어 그대로 나왔다 (검토48 C 중간 5)
    if "failed to load" in low or "data format error" in low or "pdfium" in low or "pdfiumerror" in tname:
        return f"PDF 파일로 읽을 수 없음 — 저장 중 끊겼거나 확장자와 내용이 다른 파일일 수 있습니다 ({s})"
    if "permission" in low or "being used" in low or "errno 13" in low:
        return f"파일이 잠겨 있거나 권한이 없음 — 다음 검사에서 다시 시도 ({s})"
    # 'errno 22'(잘린 zip의 음수 위치)까지 'errno 2'로 잡혀 '파일이 사라짐'이라 했다 (검토63 D-F5)
    if "no such file" in low or re.search(r"errno 2\]|errno 2\b", low):
        return f"검사 중 파일이 사라짐 — 다음 검사에서 다시 확인 ({s})"
    # 영어 원문·빈 사유가 메일·화면에 그대로였다(실패의 26%) — 종류별 담당자 말로 (검토63 D-F4)
    if "fileexistserror" in tname or "winerror 183" in low:
        return ("만들어야 할 폴더 자리에 같은 이름의 파일이 있습니다 — 브리핑·백업 폴더 경로에 같은 이름의 파일이 있는지 확인하고 "
                "치우거나, 설정에서 폴더를 바꾸세요")
    if "memoryerror" in tname:
        return "파일이 너무 커서(메모리 부족) 읽지 못함 — 표 범위·병합이 비정상적으로 큰 파일일 수 있습니다"
    if "errno 22" in low or "no valid workbook part" in low or "unable to read workbook" in low:
        return f"파일 구조가 손상돼 열 수 없음 — 저장 중 끊겼거나 일부가 잘린 파일일 수 있습니다 ({s})"
    if tname in ("parseerror", "expaterror") or any(k in low for k in (
            "not well-formed", "mismatched tag", "unclosed token", "no element found", "junk after document",
            "undefined entity", "invalid token", "duplicate attribute", "encoding specified", "multi-byte encodings",
            "reference to invalid character", "partial character", "amplification factor")):
        return f"문서 안의 XML이 깨져 읽을 수 없음 — 저장 중 끊겼거나 손상된 파일일 수 있습니다 ({s})"
    if "decompress" in low or tname == "error" and "zlib" in low:
        return f"압축된 내용이 손상돼 읽을 수 없음 — 저장 중 끊겼거나 손상된 파일일 수 있습니다 ({s})"
    if tname in ("keyerror", "indexerror", "valueerror", "stopiteration", "typeerror", "attributeerror",
                 "recursionerror", "zerodivisionerror", "overflowerror", "unicodedecodeerror") or not s.strip():
        return (f"파일 구조가 예상과 달라 읽지 못함 — 손상됐거나 특이한 프로그램으로 저장된 파일일 수 있습니다"
                f" (유형: {type(e).__name__ if not getattr(e, 'error_type', '') else e.error_type}"
                + (f", {s}" if s.strip() else "") + ")")
    return s


def _ocr_involved(d: dict) -> bool:
    """추출본에 OCR이 관여했나 — OCR로 읽은 글줄·필드가 있거나, 글자를 못 읽어 고지가 남은 경우."""
    try:
        if any("OCR" in str(f.get("where", "")) for f in (d.get("fields") or {}).values()):
            return True
        if any("OCR" in str(t.get("where", "")) for t in (d.get("raw_texts") or [])):
            return True
        return any("텍스트가 거의 추출되지" in str(n) for n in (d.get("notes") or []))
    except Exception:
        return False


# 고지 중에는 '이 파일은 비교 못 한다'가 아니라 '일부 검사만 못 한다'는 것도 있다.
# 그것까지 비교를 막으면 멀쩡히 읽은 본문 변경이 통째로 사라진다 — 칸이 나뉜 표제란(라벨 위,
# 값 아래) 도면에서 태그·주기 변경 세 건이 없어졌다 (2026-09-09 추출 검토 차단 2).
from watcher.extract.pdf import PARTIAL_READ_NOTE as _PARTIAL_READ

# 일부만 못 읽은 고지는 비교를 막지 않는다 — 표제란을 읽었는데도 "비교 불가"라
# 고지하고 Rev 변경을 빠뜨리던 것 (2026-09-09 배포 후 검토 차단 2)
from watcher.extract.docx import PARTIAL_BODY_NOTE as _PARTIAL_BODY  # noqa: E402  (워드·한글 본문 상한, 검토20 r11 1)
_PARTIAL_NOTES = ("표제란을 인식하지 못함", _PARTIAL_READ, _PARTIAL_BODY)


def _blocking_notes(doc: Document | None) -> list:
    return [n for n in (doc.notes if doc is not None else [])
            if not str(n).startswith(_PARTIAL_NOTES)]


def unreadable_note(old_doc: Document | None, new_doc: Document | None) -> str | None:
    """구/신 어느 쪽이든 추출기가 '비교 불가' 고지를 남겼으면 그 사유.
    이 경우 diff·Rev 검사를 하지 않는다 — 근거 없는 비교 결과를 내지 않기 위해 (PRINCIPLE 4).
    일부 검사만 못 하는 고지(_PARTIAL_NOTES)는 여기서 세지 않는다."""
    if new_doc is not None and _blocking_notes(new_doc):
        return _blocking_notes(new_doc)[0]
    if old_doc is not None and _blocking_notes(old_doc):
        if new_doc is not None and "OCR" in _blocking_notes(old_doc)[0]:
            # 이전 판은 OCR을 끈 채(또는 언어팩 없이) 기록됐고 새 판은 읽혔다 — 사유를 그대로 옮기면
            # "켰는데 꺼져 있다"가 된다 (2026-09-06 사용성 5차 (f))
            return "이전 판이 OCR 없이 기록된 판이라 이번엔 글자 비교를 못 했습니다 — 다음 변경부터 비교합니다"
        # 이전 판이 '빈 표'(읽기 실패가 아니라 값이 없던 것)면 빈 판과 견준다 — 빈 시트·머리글만 있던 BOM에 행을 처음 채운
        # 날 '행 추가' 대신 크기·저장 시각만 나갔다 (검토58 F6 F6)
        if new_doc is not None and all("표로 읽을 내용을 찾지 못했습니다" in n_ for n_ in _blocking_notes(old_doc)):
            return None
        return f"(이전 판) {_blocking_notes(old_doc)[0]}"
    # 도면(DXF·PDF)인데 한쪽에서 글자·표제란·표를 **하나도** 못 읽었으면 손상일 가능성이 크다 — 빈 도면과 견주어 '글자·표제란
    # 전부 삭제'를 단언했고, 복구 판은 그 빈 판과 견주어 'Rev 첫 기재'로 진짜 Rev 올림이 묻혔다 (검토63 D-F3)
    def _blank(d):
        return (d is not None and getattr(d, "doc_type", "") in ("dxf", "pdf")
                and not d.raw_texts and not d.fields and not d.rows and not d.revision_history)

    def _has(d):
        return d is not None and bool(d.raw_texts or d.fields or d.rows)
    if _blank(new_doc) and _has(old_doc):
        return "새 판에서 글자를 하나도 읽지 못했습니다 — 손상됐거나 글자 없이 출력된 도면일 수 있어 내용 비교를 하지 않습니다"
    if _blank(old_doc) and _has(new_doc):
        return "(이전 판) 글자를 하나도 읽지 못한 판이라 이번엔 글자 비교를 못 했습니다 — 다음 변경부터 비교합니다"
    return None


def _protect_config_password(config_path, cfg) -> str:
    with CONFIG_LOCK:          # 읽고-고치고-쓰기 — 화면 저장과 겹치면 한쪽이 사라졌다 (검토64 B1)
        return _protect_config_password_locked(config_path, cfg)


def _protect_config_password_locked(config_path, cfg) -> str:
    """config.yaml에 평문으로 남은 SMTP 비밀번호를 DPAPI로 감싸 저장한다 — 설정 화면을 여는 PC만
    감싸지던 것 (리뷰10 낮음-8). 감쌌으면 안내 한 줄, 아니면 빈 문자열. 실패는 조용히 넘긴다."""
    from watcher.secret import available, is_protected, protect
    m = dict((cfg or {}).get("mail") or {})
    pw = m.get("password")
    if not pw or is_protected(str(pw)) or not available():
        return ""
    try:
        import yaml
        p = Path(config_path)
        text = p.read_text(encoding="utf-8")
        data = yaml.safe_load(text) or {}
        mm = dict(data.get("mail") or {})
        if not mm.get("password") or is_protected(str(mm["password"])):
            return ""
        wrapped = protect(str(mm["password"]))
        if not is_protected(wrapped):
            return ""
        # 손으로 적은 주석을 지우지 않게 통째로 다시 쓰지 않고 password 줄만 바꾼다 (리뷰11 낮음-4).
        # 줄을 못 찾으면(따옴표·접힘 등) 그때만 통째로 다시 쓴다
        pat = re.compile(r"^(\s+password\s*:\s*)(.*?)\s*(#.*)?$", re.M)
        found = [m for m in pat.finditer(text)
                 if yaml.safe_load(m.group(2)) == mm["password"]]
        if len(found) == 1:
            m = found[0]
            new_text = text[:m.start()] + m.group(1) + f'"{wrapped}"' + (" " + m.group(3) if m.group(3) else "") \
                + text[m.end():]
            if (yaml.safe_load(new_text) or {}).get("mail", {}).get("password") != wrapped:
                raise ValueError("줄 바꾸기 검증 실패")
            write_config_text(p, new_text)       # 화면 저장과 겹치지 않게 (검토64 B1)
        else:
            mm["password"] = wrapped
            data["mail"] = mm
            write_config_text(p, yaml.safe_dump(data, allow_unicode=True, sort_keys=False))
        if isinstance(cfg.get("mail"), dict):
            cfg["mail"]["password"] = wrapped
        return "저장돼 있던 SMTP 비밀번호를 이 PC의 Windows 계정으로 암호화했습니다"
    except Exception as e:
        return f"경고: SMTP 비밀번호가 config.yaml에 평문으로 남아 있는데 암호화해 저장하지 못했습니다 ({e}) — 설정 › 메일에서 다시 저장하세요"


def _brief_target(day_path: Path, run_at: datetime, merged: bool, dry_run: bool) -> Path:
    """그 날의 브리핑 파일 — 합산했으면 그 날 파일을 갱신(덮어씀), 미리보기(dry-run)는 `_미리보기`를
    붙여 실검사 파일과 섞이지 않게, 그 밖(기준선·합산 없음)은 시각을 붙여 보존 (리뷰10 중간-6)."""
    if merged:
        return day_path
    if dry_run and "_기준선" not in day_path.stem:      # 기준선은 이미 제 이름이 있어 합산과 겹치지 않는다
        day_path = day_path.with_name(f"{day_path.stem}_미리보기{day_path.suffix}")
    return _unique_brief(day_path, run_at)


def _unique_brief(path: Path, run_at: datetime) -> Path:
    """같은 날 두 번째 검사가 아침 브리핑을 덮어쓰지 않게 — 시각을 붙인다 (2026-09-03 검토)."""
    if not path.exists():
        return path
    cand = path.with_name(f"{path.stem}_{run_at:%H%M}{path.suffix}")
    n = 2
    while cand.exists():
        cand = path.with_name(f"{path.stem}_{run_at:%H%M}_{n}{path.suffix}")
        n += 1
    return cand


def _sweep_quiet_cross_issues(state: State, labels) -> int:
    """경로가 보관·임시·백업 폴더에 있는 **열린 교차 이슈**(도면 간·도면-BOM)를 닫는다 — 그 폴더의 파일은 교차 검사에 들어가지
    않아(D1) 다시 판정될 일이 없다. 이 고침 전에 옮겨진 종료 프로젝트의 것까지 (R2-1). 파일 단위 이슈는 건드리지 않는다."""
    from watcher.project import in_quiet_folder as _iqf_s
    try:
        rows = state.conn.execute(
            "SELECT id, path FROM issues WHERE resolved_at IS NULL "
            "AND code IN ('BOM_MISMATCH', 'TAG_MISMATCH_ACROSS_DRAWINGS')").fetchall()
        hit = [(iid, p_) for iid, p_ in rows if p_ and _iqf_s(str(p_), labels)]
        if not hit:
            return 0
        now = datetime.now(timezone.utc).isoformat()
        state.conn.executemany(
            "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ? AND resolved_at IS NULL",
            [(now, f"자동 해소 — 보관 폴더에 있음 ({p_}) — 보관·임시 폴더는 교차 검사 대상이 아닙니다", iid) for iid, p_ in hit])
        state.conn.commit()
        print(f"보관·임시 폴더에 있는 열린 불일치 {len(hit)}건을 닫았습니다 (보관됨)")
        return len(hit)
    except sqlite3.DatabaseError:
        return 0


REJUDGE_DAYS = 14                 # 판 올림 뒤 이 기간의 '파일 변경 없는' 교차 검토 필요를 재판정으로 본다 (J4)
_REJUDGE_CODES = ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS", "TAG_PATTERN_UNRECOGNIZED", "BOM_SPEC_COLUMN_UNRECOGNIZED")


def _split_rejudged(state: State, rd, issues: list) -> tuple[list, list]:
    """(오늘 확인할 검토 필요, 프로그램 업데이트로 다시 판정한 것) — 기능 검토 2026-11-02 J4. 앱 판이 바뀐 뒤 REJUDGE_DAYS 안의
    검사에서, 근거에 인용된 파일이 오늘 하나도 안 바뀌었는데 새로 생기거나 값이 바뀐 교차 검토 필요는 파일 변경이 아니라 판정 규칙·
    추출 세대가 바뀐 결과다 — 판 올림 첫 검사의 재판정이 '오늘 확인할 것'에 섞여 업데이트 날 메일이 무거웠다(구매자 평가 B2).
    DB에는 그대로 열린 검토 필요로 남는다(화면에서 본다). 메일은 머리에 한 묶음(접힘)으로만 싣는다."""
    if not issues:
        return issues, []
    import json as _js
    try:
        bump = _js.loads(state.get_meta("rule_bump") or "null") or {}
        at = datetime.fromisoformat(str(bump.get("at")))
    except (ValueError, TypeError, AttributeError):
        return issues, []
    age = (datetime.now(timezone.utc) - at).total_seconds()
    if age < 0 or age > REJUDGE_DAYS * 86400:
        return issues, []
    changed = {c.path for c in (rd.changes or ())}
    keep, rej = [], []
    for i in issues:
        if i.code in _REJUDGE_CODES:
            cited = {i.path} | {p_ for p_ in State._evidence_paths(_js.dumps(list(i.evidence), ensure_ascii=False), changed)
                                if "/" in p_}
            # 오늘 바뀐 경로 글자가 근거·문구 어디에든 들어 있으면 오늘 건이다 — 애매하면 '재판정'이 아니라 '새로 잡힘' 쪽으로.
            # 괄호·쉼표 든 경로를 근거 줄에서 못 읽어 오늘 편집으로 생긴 불일치를 업데이트 재판정으로 접었다 (재검토 rr066 judge 1)
            _txt = " ".join([str(i.message or "")] + [str(e) for e in (i.evidence or ())])
            if not (cited & changed) and not any(p_ and p_ in _txt for p_ in changed):
                rej.append(i)
                continue
        keep.append(i)
    if rej:
        print(f"프로그램 업데이트(v{bump.get('from')} → v{bump.get('to')})로 다시 판정한 검토 필요 {len(rej)}건 — "
              f"파일 변경이 아니라 메일 머리에 따로 묶습니다")
    return keep, rej


def _unread_project(resolver, path) -> str | None:
    """읽지 못한 파일의 프로젝트. 폴더·보류 안내, 귀속을 모르는 파일, 메일이 없는 보관·공용 폴더는 None — 전 프로젝트 메일에 싣는다(놓치지 않는 쪽)."""
    sp = str(path)
    if sp.endswith("/") or sp.startswith("("):
        return None
    try:
        pj, src = resolver.attribute(sp, None)
        if src not in ("직접 지정", "감시 폴더"):      # 표제란으로 귀속된 파일은 오늘 내용을 못 읽었다 — 지난 귀속이 먼저, 폴더 구조 짐작은 모름
            pj = resolver.prev_projects.get(sp) or (None if src == "폴더 구조" else pj)
    except Exception:           # noqa: BLE001 — 귀속 실패가 안내를 지우면 안 된다
        return None
    return None if not pj or pj == "미분류" or _QUIET_PROJECT.search(pj) else pj


def _report_and_send(args, cfg, state: State, rd) -> None:
    """귀속 → 이슈 저장 → 콘솔 출력 → 브리핑 저장 → 메일. 실패 시 호출부가 롤백."""
    root = rd.root_display
    changes, docs, details = rd.changes, rd.docs, rd.details
    issues, scan_errors, labels = rd.issues, rd.scan_errors, rd.labels
    snapshot_id, captures = rd.snapshot_id, rd.captures
    # 폴더 구조 추정(하위가 종류 폴더면 하나)은 **제안**으로만 쓴다 — 귀속에 자동
    # 적용하면 '종류 우선, 그 아래 프로젝트' 구조에서 표제란 번호를 덮어썼다
    # (2026-09-02 검토). 지정(root_projects)·폴더명 번호만 귀속에 쓴다
    resolver = make_resolver(cfg, rd.roots)
    resolver.folder_votes = rd.folder_votes or _load_folder_votes(state)
    resolver.prev_projects = _PrevProjects(state)        # 폴더 다수결이 갈린 날 지난 귀속 유지 (검토20 r13 3)
    # 별칭 사전 문제는 화면 배너·브리핑 머리에 — stderr(watcher.log)에만 남아 아무도 몰랐다 (검토20 r13 1)
    _atr = getattr(resolver, "alias_trouble", None)
    rd.alias_note = alias_note(_atr)
    try:
        import json as _json_al
        state.set_meta(ALIAS_TROUBLE_KEY, _json_al.dumps(
            {**_atr, "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}, ensure_ascii=False) if _atr else None)
    except Exception:
        pass
    involved = {c.path for c in changes} | {i.path for i in issues}
    proj_of = {}
    for p in involved:
        doc = docs.get(p)
        if doc is None:  # 삭제된 파일: 구버전 추출본으로 표제란 귀속 시도
            c = next((c for c in changes if c.path == p and c.old_sha256), None)
            old = state.load_extract(c.old_sha256, c.path) if c else None
            doc = (Document.from_dict(old)
                   if old and old.get("fields") is not None else None)
        proj_of[p] = resolver.attribute(p, doc)
    issues = rd.issues = _issued_rev_same(state, docs, issues, proj_of)

    for c in changes:
        if c.id is not None:
            state.set_change_project(c.id, proj_of[c.path][0])

    # 일관성 이슈를 DB에 남긴다 — 대시보드 화면·누적 카운터용.
    # 브리핑·콘솔에는 '새로 검출된 것'만 싣는다 (미해결 이슈가 변경 있는 날마다
    # 메일로 재알림되던 소음 제거 — 누적은 화면에서 본다, 2026-08-26)
    today_keys = {(i.code, i.path, i.message) for i in issues}
    _t_auto = None                    # 재검출 판정이 무언가를 닫았으면 그 판정의 시작 시각
    # 폴더를 옮기면(아카이브 등) 옛 경로의 열린 이슈가 '파일 삭제됨'으로 닫히고 새 경로에서
    # '새 검토 필요'로 되살아나 메일 초안까지 냈다 (파일럿 모의 ②). 이동 짝이 있으면 이슈의
    # 경로를 따라 옮긴다 — 그러면 저장 단계의 중복 억제에 걸려 새 것으로 세지 않는다
    if snapshot_id is not None and rd.moved:
        n_re = 0
        _to_archive = []
        from watcher.project import in_quiet_folder as _iqf_m
        for new_p, (old_p, _sha, _same) in rd.moved.items():
            if old_p != new_p:
                n_re += state.repath_open_issues(old_p, new_p)
                if _iqf_m(new_p, labels) and not _iqf_m(old_p, labels):
                    _to_archive.append((old_p, new_p))
        if n_re:
            print(f"검토 필요 {n_re}건의 경로를 옮긴 파일을 따라 갱신 (새 이슈 아님)")
        # 보관·백업 폴더로 옮긴 파일(종료 프로젝트를 '_보관/'으로)의 열린 검토 필요는 닫는다 — 그 폴더는 교차 검사·메일 밖이라 다시
        # 판정될 일이 없어, 1년 뒤 열린 121건 중 28건이 '_보관/'이었다(가장 오래된 363일째) (재검토 2026-10-28 R2-1). 사유에 옮긴
        # 경로를 남기고, '자동 해소'로 닫아 다시 꺼내 같은 불일치가 나오면 새로 잡힌다
        if _to_archive:
            _now_a = datetime.now(timezone.utc).isoformat()
            n_arch = 0
            for old_p, new_p in _to_archive:
                cur_ = state.conn.execute(
                    "UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE path = ? AND resolved_at IS NULL",
                    (_now_a, f"자동 해소 — 보관 폴더로 옮겨짐 ({old_p} → {new_p})", new_p))
                n_arch += cur_.rowcount or 0
            state.conn.commit()
            if n_arch:
                print(f"보관 폴더로 옮긴 파일의 검토 필요 {n_arch}건을 닫았습니다 (보관됨)")
    if snapshot_id is not None:
        _sweep_quiet_cross_issues(state, labels)
    # 열린 불일치의 **오늘 갱신 전** 근거 — 당사자 도면을 고친 날(E-104 5.5→7.5kW) 그 도면은 새 근거에서 '같은 값 도면 N장'
    # 으로만 남아 경로가 빠졌고, 그래서 '관련 파일이 바뀌었지만 아직 열린 불일치' 문단이 그날만 안 나왔다 (재검토 2026-10-26 D2)
    _prev_refs: dict = {}
    try:
        for d in state.issues():
            if d["code"] in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS"):
                _prev_refs[d["issue_id"]] = " ".join([str(d["path"] or "")] + [str(e) for e in (d.get("evidence") or [])])
    except Exception:
        _prev_refs = {}
    if issues and snapshot_id is not None:
        # 이번 검사에서 조용한 변경(재저장·일자만·이동)만 겪은 경로 — 닫아 둔 이슈를 되살리지 않게.
        # 상세는 이 뒤에 저장되므로 여기서 같은 규칙으로 판정해 넘긴다 (검토31 C 1)
        import json as _json
        quiet_now = frozenset(
            p_ for p_, its in (rd.details or {}).items()
            if State._quiet_items(_json.dumps([{"kind": getattr(i, "kind", ""), "new": getattr(i, "new", None), "where": getattr(i, "where", None)}
                                               for i in (its or [])], ensure_ascii=False)))
        fresh = state.save_issues(snapshot_id,
                                  [(i, proj_of[i.path][0]) for i in issues], quiet_paths=quiet_now)
        rd.continued = list(getattr(state, "last_continued", []) or [])
        rd.recurred = dict(getattr(state, "last_recurred", {}) or {})
        issues = [i for i, _ in fresh]
        issues, rd.rejudged = _split_rejudged(state, rd, issues)        # 판 올림 재판정은 따로 (J4)
    if snapshot_id is not None and changes:
        # 다시 검사했는데 재검출되지 않은 열린 이슈는 해소된 것 (2026-09-03 검토)
        # 내용 그대로 옮겨진 파일은 다시 검사된 것이 아니다 — 새 경로가 '추가'로 들어가 옮겨 준 이슈가
        # 같은 실행에서 "재검출되지 않음"으로 닫혔다 (검토21 감지 중간 4)
        same_moves = {p for p, (_o, _s, same) in (rd.moved or {}).items() if same}
        # 재저장·일자만 같은 조용한 변경은 '다시 검사해 재검출 안 됨'의 근거가 아니다 — 재저장만으로 열린
        # 'Rev 미갱신'이 닫혔다 (검토38 R3 중간 4)
        import json as _json_q
        quiet_today = {p_ for p_, its in (rd.details or {}).items()
                       if State._quiet_items(_json_q.dumps(
                           [{"kind": getattr(i, "kind", ""), "new": getattr(i, "new", None), "where": getattr(i, "where", None)} for i in (its or [])],
                           ensure_ascii=False))}
        # 못 읽은(잠김·권한) 파일은 삭제가 아니다 — '자동 해소 — 파일이 삭제됨'으로 닫혔다가 다음 날 새 이슈로
        # 되살아났다 (검토38 R3 차단 2)
        unread = {str(p_) for p_, _e in (rd.scan_errors or [])}
        _t_try = datetime.now(timezone.utc).isoformat()
        from watcher.diff import CONTENT_KINDS
        n_auto = state.auto_resolve_issues(
            # 비교할 옛 판 없이 '추가'로만 들어온 파일(다시 넣은 감시 폴더의 첫 등록 등)은 Rev 검사를 하지 않았다 — 재검출이 없다고
            # 그 경로의 열린 'Rev 미갱신'을 닫으면 안 된다 (검토64 A1)
            today_keys, {c.path for c in changes if not (c.kind == "added" and not any(
                getattr(i_, "kind", "") in CONTENT_KINDS or str(getattr(i_, "kind", "")).startswith(("FIELD_", "REVROW_"))
                for i_ in ((rd.details or {}).get(c.path) or [])))} - same_moves - quiet_today, set(rd.checked_projects),
            # 비교를 생략한 파일은 '다시 검사해 재검출되지 않은' 것이 아니다 — 판 교체 창에 고친 파일의 열린
            # 'Rev 미갱신'이 닫혔다 (검토40 B 중간 2)
            readable=set(rd.docs) - rd.compare_skipped,
            # 감시 제외·끈 확장자·감시 폴더에서 뺀 파일도 '없어진' 것이 아니다 — 그 파일의 열린 불일치가 '파일이 삭제됨'으로
            # 닫혔다가 다시 켜면 새 이슈·메일로 되살아났다 (검토59 F3 I5·I6·H5)
            present={r.path for r in rd.records} | set(rd.carry_paths) | unread
            | set(rd.__dict__.get("excluded_carry") or ())
            | {p_ for p_ in (rd.prev_files or {}) if p_.split("/", 1)[0] not in set(rd.labels)}
            # 뺀 감시 폴더의 파일은 빼진 첫 검사 뒤 스냅샷에서도 빠진다 — 둘째 검사부터 그 폴더의 열린 이슈가 '파일이 삭제됨'으로
            # 닫혔다 (검토64 A1). 열린 이슈의 경로가 지금 감시 폴더 밖이면 없어진 것으로 보지 않는다
            | {p_ for (p_,) in state.conn.execute("SELECT path FROM issues WHERE resolved_at IS NULL").fetchall()
               if p_ and str(p_).split("/", 1)[0] not in set(rd.labels)},
            rev_changed=_rev_changed_paths(rd), rev_raised=_rev_raised_paths(rd),
            superseded=rd.__dict__.get("superseded"),
            # 귀속이 다른 프로젝트로 옮겨진 파일의 교차 이슈는 '재검출되지 않음'이 아니다 — 열어 둔다 (검토20 r13 3)
            attributed={p_: v_[0] for p_, v_ in proj_of.items()})
        if n_auto:
            print(f"검토 필요 자동 해소 {n_auto}건 (다시 검사했을 때 재검출되지 않음)")
            _t_auto = _t_try
    # 해소 소식도 그 프로젝트 메일에 — 넘긴 일이 끝났는지가 메일·카드 어디에도 없었다 (검토39 P2 중간 2)
    auto_resolved = _resolved_this_run(state, _t_auto, rd.__dict__.get("t_track")) if snapshot_id is not None else {}
    # 오늘 관련 파일이 바뀌었는데도 **아직 열린** 불일치 — BOM을 고친 날 메일이 "E-102가 아직 5.5kW"라는 지금 근거를 알려 주지
    # 않아 닷새를 헤맸다(화면은 이미 갱신돼 있었다) (구매자 평가 P3 차단 1). **자동 해소 뒤에** 센다 — 앞에서 세면 오늘 해소된
    # 불일치가 같은 메일에 '해소됨'과 '아직 열림(옛 근거)'으로 두 번 실렸다 (검토50 B 차단 1)
    try:
        # 이슈 대조 키로 견준다 — 도면 간 불일치는 경로가 '첫 충돌 도면'이라 옮겨 다녀, 같은 M-101이 메일에 '새로 잡힘'과
        # '아직 열림'으로 두 번 실렸다 (검토52 D 중간 7)
        _fresh_keys = {State.issue_key(i.code, i.path, i.message) for i in issues}
        _changed = {c.path for c in changes}
        rd.still_open = []
        for d in state.issues():
            if d["code"] not in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS"):
                continue
            if State.issue_key(d["code"], d["path"], d["message"]) in _fresh_keys:
                continue
            ev = [str(e) for e in (d.get("evidence") or [])]
            _refs = " ".join(ev) + " " + _prev_refs.get(d["issue_id"], "")
            if any(p_ in _refs or p_ == d["path"] for p_ in _changed):
                rd.still_open.append((d["project"], d["code"], d["message"], ev[:3], d.get("detected_at")))
    except Exception as e:
        print(f"  (아직 열린 검토 확인 실패 — 무시: {e})", file=sys.stderr)
        rd.still_open = []

    # 변경 상세(diff+캡처)도 저장 — 화면에서 변경 행을 클릭하면 바로 보이도록
    from dataclasses import asdict
    for p_ in list(details):
        details[p_] = _dedupe_page_items(details[p_])
    _pair_spec_tags(rd, details)
    for c in changes:
        if c.id is not None and c.path in details:
            caps = {k[1]: v for k, v in (captures or {}).items() if k[0] == c.path}
            state.save_change_details(
                c.id, [asdict(i) for i in details[c.path]], caps)

    from watcher.brief import split_hold_notes as _split_holds
    _holds, _read_errs = _split_holds(scan_errors)
    for p, err in _holds:
        print(f"  [삭제 보류] {p}: {err}")
    if _read_errs:
        print(f"읽지 못한 파일 {len(_read_errs)}건 (다음 실행에서 재시도):")
        for p, err in _read_errs:
            print(f"  [실패] {p}: {err}")
    if not args.dry_run and snapshot_id is not None:
        # 화면에도 남긴다 — 읽지 못한 파일은 메일과 콘솔에만 있어, 메일을 끈 집에서는 몇 주째 같은 파일을
        # 못 읽어도 화면 어디에도 없었다 (검토36 B 5). 마지막 검사 것만, 상한 200줄
        # 삭제 보류는 화면에 제 배너(mass_removal_hold)가 따로 있다 — '읽지 못한 폴더·파일'에 함께 세지 않는다 (R5-2)
        import json as _json_e
        try:
            state.set_meta("last_scan_errors", _json_e.dumps(
                {"at": datetime.now(timezone.utc).isoformat(), "n": len(_read_errs),
                 "items": [[str(p), str(e)] for p, e in _read_errs[:200]]}, ensure_ascii=False)
                if _read_errs else None)
            # 열리긴 하지만 **내용**을 못 읽는 파일(암호·손상·DWG 변환 프로그램 없음·너무 큼) — 바뀐 날의 변경 행에만
            # 사유가 있어, 바뀌지 않는 동안은 '감시 중 126개'가 전부 비교되는 줄 알았다 (구매자 평가 2026-10-04 P2·P3)
            _xf = sorted((rd.extract_failures or {}).items())
            state.set_meta("last_extract_failures", _json_e.dumps(
                {"at": datetime.now(timezone.utc).isoformat(), "n": len(_xf),
                 "items": [[str(p), str(e)] for p, e in _xf[:500]]}, ensure_ascii=False)
                if _xf else None)
        except Exception as e:
            print(f"경고: 읽지 못한 파일 목록을 화면용으로 남기지 못함: {e}", file=sys.stderr)
    if not changes:
        print("변경 없음.")
    else:
        print(f"변경 {len(changes)}건:")
        for c in changes:
            old = (c.old_sha256 or "-")[:12]
            new = (c.new_sha256 or "-")[:12]
            print(f"  [{KIND_LABEL[c.kind]}] {c.path}  (sha256 {old} -> {new})")
            for i in details.get(c.path, []):
                print(f"      {i.kind} {i.key}: {i.old or '—'} -> {i.new or '—'}  @ {i.where}")
    if issues:
        print(f"검토 필요 {len(issues)}건:")
        for iss in issues:
            print(f"  [{CODE_LABEL[iss.code]}] {iss.path} — {iss.message}")
            for ev in iss.evidence:
                print(f"      근거: {ev}")

    groups: dict[str, dict] = {}
    for c in changes:
        g = groups.setdefault(proj_of[c.path][0], {"changes": [], "issues": []})
        g["changes"].append(c)
    for iss in issues:
        g = groups.setdefault(proj_of[iss.path][0], {"changes": [], "issues": []})
        g["issues"].append(iss)
    for iss in getattr(rd, "rejudged", None) or []:
        groups.setdefault(proj_of[iss.path][0], {"changes": [], "issues": []}).setdefault("rejudged", []).append(iss)

    ack_tokens = {c.id: state.ack_token(c.id) for c in changes if c.id is not None}
    ack_host = urlparse(cfg["ack_url"]).hostname or ""
    mail_on = bool(cfg["mail"].get("enabled")) and not args.dry_run
    from watcher import brief as _brief_mod
    # 양식함 사내망 링크가 붙는 날은 수신자가 사내망에서 확인한다 — 반대 안내를 남기지 않는다 (재검토 rr066 upgrade 2)
    if mail_on and ack_host in ("127.0.0.1", "localhost") and ack_tracking_on(cfg) and not _brief_mod.LAN_BASE:
        print("참고: 메일의 [확인했음 기록] 링크는 이 PC에서 누를 때만 동작합니다 "
              "(화면은 보안상 이 PC에서만 열립니다). 수신자는 회신으로, 기록은 이 PC의 "
              "화면에서 담당자가 남기는 운영을 권장합니다.", file=sys.stderr)

    run_at = datetime.now()
    if snapshot_id is not None:
        # 브리핑의 '그 날'은 검사를 **시작한** 날 — 23:58에 시작해 00:01에 보고하면 파일·메일 제목은 다음 날,
        # DB·화면·주간 집계는 전날이 되어 다음 날 아침 통이 사본(_0700)이 됐다 (검토38 R7 1)
        try:
            _iso = state.conn.execute("SELECT run_at FROM snapshots WHERE id = ?", (snapshot_id,)).fetchone()[0]
            if not ("+" in _iso[10:] or _iso.endswith("Z")):
                _iso += "+00:00"
            _start = datetime.fromisoformat(_iso).astimezone()
            run_at = datetime(_start.year, _start.month, _start.day, _start.hour, _start.minute, _start.second)
        except (TypeError, ValueError, IndexError):
            pass
    brief_dir = Path(args.brief_dir or cfg["brief_dir"])
    brief_dir.mkdir(parents=True, exist_ok=True)
    scanned = len(rd.records)  # 브리핑 '파일 N개 검사' 표기용
    # 도면번호·Rev·개정 사유 — 실무 언어로 브리핑 (설계 10년차 검토, 2026-08-28)
    doc_info: dict = {}
    _mt_of = {r.path: r.mtime for r in rd.records}      # 파일 저장 시각 (2026-09-17 요청)
    for c in changes:
        if c.kind != "removed" and _mt_of.get(c.path):
            doc_info.setdefault(c.path, {"dwg": None, "rev": None, "note": None})["mtime"] = _mt_of[c.path]
        d = docs.get(c.path)
        if d is None and c.kind == "removed" and c.old_sha256:
            # 삭제 행에도 도면번호·Rev — 구판 추출본이 있다 (검토19 브리핑 ⑯)
            dd = state.load_extract(c.old_sha256, c.path)
            if dd and not dd.get("extract_failed"):
                try:
                    d = Document.from_dict(dd)
                except Exception:      # noqa: BLE001
                    d = None
        if d is None:
            continue
        # 문서류(사양서·발주서)는 문서번호(DOC_NO) — 새 문서 파일 칸에 번호·Rev가 없었다 (검토61 D B2)
        f_dwg, f_rev = d.fields.get("DWG_NO") or d.fields.get("DOC_NO"), d.fields.get("REV")
        note = (_reason_from_items(details.get(c.path, []))
                or _latest_rev_note(d.revision_history, f_rev.value if f_rev else None))
        _dwg_v = f_dwg.value if f_dwg else None
        if getattr(d, "doc_type", "") == "pdf" and c.kind != "removed":
            # 세트 PDF에서 한 쪽만 바뀌었으면 그 쪽의 도면번호로 — 2쪽(E-702)만 바뀐 날 제목·행 머리가 첫 시트 'E-701'이었다
            # (검토71 R4 중간 6)
            from watcher.consistency import set_sheet_label as _ssl
            _pgs = {int(m.group(1)) for i in details.get(c.path, [])
                    if i.kind not in ("CHECK_SKIPPED", "NEW_REVISION_OF")
                    for m in [re.match(r"^(\d+)페이지", str(i.where or "")) or re.match(r"^(\d+)페이지", str(i.key or ""))] if m}
            _sl = _ssl(d, next(iter(_pgs))) if len(_pgs) == 1 else None
            if _sl:
                _dwg_v = _sl
        if _dwg_v or f_rev or note or getattr(d, "saved_by", None):
            doc_info[c.path] = {"dwg": _dwg_v,
                                "rev": f_rev.value if f_rev else None,
                                # 리비전 행이 이번 변경에서 생겼을 때만 — 옛 행을 인용하면
                                # 되돌림에서 반대 방향 사유가 실린다 (2026-09-03 검토)
                                "note": (note if note and any(
                                    i.kind == "REVROW_ADDED" for i in details.get(c.path, []))
                                    else None),
                                "mtime": _mt_of.get(c.path) if c.kind != "removed" else None,
                                "who": getattr(d, "saved_by", None) if c.kind != "removed" else None}
    # 같은 이름 파일이 같은 프로젝트에 또 있으면(작업중_사본/·구판/) 메일 머리 한 줄에 폴더 꼬리 (ux20 daily 1)
    try:
        from watcher.brief import same_name_folder as _snf
        _by_name: dict = {}
        for _p in [r.path for r in (rd.records or ())] + list(rd.carry_paths or ()):
            _by_name.setdefault(PurePosixPath(_p).name.casefold(), []).append(_p)
        for c in changes:
            _sib = _by_name.get(PurePosixPath(c.path).name.casefold()) or ()
            _fd = _snf(c.path, _sib) if len(_sib) > 1 or (c.kind == "removed" and _sib) else ""
            if _fd:
                doc_info.setdefault(c.path, {"dwg": None, "rev": None, "note": None})["folder"] = _fd
    except Exception:          # noqa: BLE001 — 꼬리를 못 달아도 브리핑은 그대로
        pass
    # 첫 검사(기준선)의 '추가' N건은 변경이 아니다 — "변경 33건" 메일 초안이 화면(0건)과
    # 어긋났다 (2026-09-05 전체 검토). 브리핑은 '기준선 등록'으로 표기하고, 메일 초안은
    # 검토 필요가 있는 프로젝트만 만든다
    is_baseline = (state.first_snapshot_id() == snapshot_id)
    rd.is_baseline = is_baseline
    # 같은 날 두 번째 검사는 아침 브리핑과 **합쳐 한 통**으로 갱신한다 — 프로젝트마다 초안이
    # 시각별로 쌓여 어느 통을 보낼지 골라야 했다 (2026-09-05 재검토). 앞선 변경의 상세·캡처는
    # DB에서 되살린다. 첫 검사(기준선)의 등록 건은 변경이 아니라 합치지 않는다
    merged_note: dict[str, str] = {}
    acked_by: dict[int, str] = {}
    # 같은 파일이 오늘 두 번 바뀌면 상세·캡처가 경로 키로 겹친다 — 변경 id별로 따로 싣는다
    details_by_id: dict[int, list] = {}
    if snapshot_id is not None and not is_baseline and not args.dry_run:
        details = dict(details)
        captures = dict(captures or {})
        first_id = state.first_snapshot_id()
        # 기준 날짜는 보고 시점이 아니라 이번 검사의 시작 시각 — 자정을 걸친 검사가 다음 날
        # 파일로 가던 것 (코드 검토)
        day_iso = state.snapshot_local_date(snapshot_id) or run_at_local_date()
        earlier = [c for c in state.changes_on_day(day_iso, exclude_snapshots={snapshot_id, first_id})
                   if c.id is not None]
        # 같은 날 아침에 켠 확장자의 첫 등록이 오후 '갱신' 통에서 '추가'로 되살아났다 —
        # 등록으로 접은 것을 합산 경로가 몰랐다 (검토19 브리핑 ②, 검토18의 같은 날 재발)
        ext_base = state.ext_baseline()
        if earlier:
            # 확장자 등록뿐 아니라 **나중에 추가한 폴더의 첫 등록**도 걸러야 한다 — 이 블록이
            # `ext_base`가 있을 때만 돌아, 확장자를 켠 적 없는 설치본에서는 아침에 추가한 폴더의
            # 등록이 오후 '갱신' 통에서 "변경 3건"으로 되살아났다 (검토20 A-1)
            ids = [c.id for c in earlier]
            snap_of: dict = {}
            for k in range(0, len(ids), 500):
                chunk = ids[k:k + 500]
                snap_of.update(state.conn.execute(
                    "SELECT id, snapshot_id FROM changes WHERE id IN (%s)"
                    % ",".join("?" * len(chunk)), chunk))
            first_by_root = state.first_snapshot_by_root()
            earlier = [c for c in earlier
                       if not State.is_first_registration(c.kind, c.path, snap_of.get(c.id),
                                                          first_by_root, ext_base)]
        earlier_ids = {c.id for c in earlier}
        cur_paths = {c.path for c in changes}
        for c in earlier:
            proj = c.project or "미분류"
            # 되살린 앞선 변경은 **그때의** 도면번호·Rev를 단다 — 경로 키를 쓰면 A→B 행이
            # 'Rev C'(현재 값)로 보였다. 세 번째 지적 (2026-09-06·09-09·검토19 브리핑 ⑪)
            if c.new_sha256 and c.id is not None:
                dd = state.load_extract(c.new_sha256, c.path)
                if dd and not dd.get("extract_failed"):
                    fl = dd.get("fields") or {}
                    dwg_ = (fl.get("DWG_NO") or fl.get("DOC_NO") or {}).get("value")
                    rev_ = (fl.get("REV") or {}).get("value")
                    # 도면번호·Rev가 없는 문서(BOM·발주서·사양서)도 id 키로 — 경로 키(오후 변경)의 저장 시각을 빌려 검사마다 달랐다
                    # (검토59 F4b-2)
                    doc_info[c.id] = {"dwg": dwg_, "rev": rev_, "note": None,
                                      "mtime": state.change_mtimes(c.id)[0]}   # 되살린 변경의 저장 시각
            elif c.kind == "removed" and c.id is not None:
                dd = state.load_extract(c.old_sha256, c.path) if c.old_sha256 else None
                fl = ((dd or {}).get("fields") or {}) if dd and not dd.get("extract_failed") else {}
                doc_info[c.id] = {"dwg": (fl.get("DWG_NO") or fl.get("DOC_NO") or {}).get("value"),
                                  "rev": (fl.get("REV") or {}).get("value"), "note": None, "mtime": None}
            if proj not in groups:
                continue                   # 이번 검사에 그 프로젝트 변경이 없으면 아침 통이 그대로 유효
            cur_ids = {x.id for x in groups[proj]["changes"]}
            if c.id in cur_ids:
                continue
            # 같은 파일이 오늘 두 번 바뀐 경우도 싣는다 — 예전에는 최신 변경만 남기고
            # 아침 근거(전/후 사진·항목)를 버렸다 (2026-09-09 브리핑 검토 차단 2).
            # 상세·캡처를 변경 id로 넣어 두 행이 각자의 근거를 갖게 한다
            same_path = c.path in cur_paths
            d = state.change_detail(c.id)
            if d:
                dismissed = d.get("dismissed") or {}
                items = []
                for ix, it in enumerate(d.get("items") or []):
                    if str(ix) in dismissed:          # 사람이 '오탐 삭제'한 항목은 싣지 않는다
                        continue
                    try:
                        items.append(ChangeItem(it["kind"], it["key"], it.get("old"), it.get("new"),
                                                it.get("where", ""), it.get("label")))
                    except (KeyError, TypeError):
                        continue
                if items:
                    # **항상** 변경 id로 — 경로 키는 같은 파일의 앞선 변경 둘(진짜 변경 + 재저장)이
                    # 서로 덮어써 진짜 변경이 "재저장"이 되거나 BOM 행이 복제됐다 (파일럿 모의 2차 1위)
                    details_by_id[c.id] = items
                    # 아침 통에 있던 '개정 사유' 줄이 갱신 통에서 사라졌다 (검토25 브리핑 A-1) — 원본과
                    # 같은 규칙: 이 변경에서 리비전 행이 생겼을 때만 그 사유를 싣는다
                    if c.id in doc_info and any(it.kind == "REVROW_ADDED" for it in items):
                        dd_ = state.load_extract(c.new_sha256, c.path) if c.new_sha256 else None
                        rh_ = (dd_ or {}).get("revision_history") or []
                        note_ = _reason_from_items(items) or _latest_rev_note(rh_, doc_info[c.id].get("rev"))
                        if note_:
                            doc_info[c.id]["note"] = note_
                    if not same_path and c.path not in details:
                        details[c.path] = items      # 경로 키는 이 파일의 첫 변경만 (하위 호환)
                for k, v in (d.get("captures") or {}).items():
                    captures[(c.id, k)] = v
                    if not same_path and (c.path, k) not in captures:
                        captures[(c.path, k)] = v
            if c.id not in details_by_id:
                # 상세가 없는 앞선 변경(추가 등)이 경로 키로 오늘 변경의 근거·사진을 빌려 '추가'인데 '변경 전' 사진이 붙었다
                # (검토52 D 중간 2) — 이 변경은 빈 상세로. 오늘 세 번째 검사부터는 추가·수정이 모두 '앞선 변경'이라
                # same_path 조건을 비켜 '추가' 행이 뒤 수정의 근거를 빌렸다 (검토56 ⑤21) — 같은 경로든 아니든 빈 상세로
                details_by_id[c.id] = []
            groups[proj]["changes"].append(c)
            merged_note[proj] = merged_note.get(proj, "") or "x"
            who = state.ack_of(c.id)
            if who:
                acked_by[c.id] = who       # 이미 확인된 건은 링크 대신 '확인됨'
            else:
                ack_tokens[c.id] = state.ack_token(c.id)
        for proj in sorted(merged_note):
            from watcher.brief import is_quiet as _iq, items_for as _if, note_of as _no
            # 제목·본문과 같은 기준으로 센다 — 이동·재저장 같은 '그 밖의 알림'까지 세어 '11건을 합쳐'인데 제목은
            # '변경 6건'이었다 (검토53 D 중간 3). 문구 중복도 줄임 (D 낮음 11)
            early = [c for c in groups[proj]["changes"] if c.id in earlier_ids]
            # 제목과 같은 함수로 — 이동+내용 변경의 삭제 쪽(접히는 행)까지 세어 오전 제목과 달랐다 (검토58 F4-3)
            k = brief_counts(early, details, details_by_id)[0]
            auto = bool(cfg["mail"].get("enabled")) and not args.dry_run
            head = ((f"오늘 앞선 검사에서 잡힌 변경 {k}건을 합쳐 갱신한 한 통입니다 — " if k else
                     "오늘 앞선 검사의 알림을 합쳐 갱신한 한 통입니다 — ")
                    + ("앞서 보낸 메일과 겹칩니다." if auto else "앞선 초안 대신 이 한 통만 보내면 됩니다.")) if early else ""
            names = sorted({PurePosixPath(c.path).name for c in groups[proj]["changes"]
                            if c.id in earlier_ids and c.path in cur_paths})
            if names:
                head += (f" 오늘 여러 번 바뀐 파일({', '.join(names)})은 앞선 변경과 이번 변경을 "
                         f"각각 근거까지 실었습니다.")
            merged_note[proj] = head.strip()
            # 앞선 검사가 새로 잡은 '검토 필요'도 아직 열려 있으면 같이 싣는다
            have = {(i.code, i.path, i.message) for i in groups[proj]["issues"]}
            for d in state.issues(proj):
                if (d["snapshot_id"] in (snapshot_id, first_id)
                        or _local_date_of(d["detected_at"]).isoformat() != day_iso
                        or (d["code"], d["path"], d["message"]) in have):
                    continue
                groups[proj]["issues"].append(Issue(d["code"], d["path"], d["message"],
                                                    tuple(d["evidence"] or ())))
    # 놓친 평일·시계 띠는 변경 0건인 날에도 — 프로젝트 브리핑에만 붙어, 목·금 꺼졌다가 월요일 변경 0건이면 그날 기록은 '정상 동작
    # 중'뿐이었다. 0건 날은 메일이 없으니 화면 배너도 읽게 이력에 남긴다 (재검토 2026-10-28 R8-3)
    _gap0 = None if is_baseline else _missed_days_note(state)
    _clk0 = None if is_baseline else _clock_note(state)
    try:
        import json as _json_gap
        state.set_meta(GAP_NOTE_KEY, _json_gap.dumps({"note": _gap0, "sid": snapshot_id}, ensure_ascii=False)
                       if _gap0 else None)
    except Exception:
        pass
    if not groups:
        brief_path = _unique_brief(brief_dir / brief_filename(run_at), run_at)
        html0 = build_brief([], run_at, str(root), scan_errors=scan_errors,
                            scanned_count=scanned, clock_note=_clk0, gap_note=_gap0,
                            alias_note=getattr(rd, "alias_note", None))
        brief_path.write_text(html0, encoding="utf-8")
        print(f"브리핑 저장: {brief_path}")
        # 변경 0건이어도 **못 읽은 파일이 있으면** 알린다. 지금까지는 이 날 메일이 한 통도
        # 안 나가서, 파일 절반을 못 읽고 지나간 날과 정말 조용한 날이 받는 쪽에서 똑같았다
        # (2026-09-09 브리핑 검토 차단 1). 원칙 5 — 변경 사실은 100% 잡는다
        # 받는 사람 목록마다 그 목록의 안내만 — 합집합 한 통이면 다른 프로젝트 담당에게 범위 밖 경로가 갔다 (ux28 mail 3, ux26 WK4).
        # 프로젝트를 모르는 안내는 지금처럼 전체(없으면 합집합)에게
        if scan_errors and not args.dry_run:
            _by_to: dict = {}
            for e_ in scan_errors:
                pj_ = _unread_project(resolver, e_[0])
                to_ = _recipients_for(cfg, pj_)
                _by_to.setdefault(_list_key(to_), (to_, pj_, []))[2].append(e_)
            for to_, pj_, errs_ in _by_to.values():
                if len(_by_to) == 1:
                    path_, h_ = brief_path, html0
                else:
                    sole_ = pj_ if all(_unread_project(resolver, x_[0]) == pj_ for x_ in errs_) else None
                    path_ = _unique_brief(brief_dir / brief_filename(run_at, sole_), run_at)
                    h_ = build_brief([], run_at, str(root), scan_errors=errs_, project=sole_, scanned_count=scanned,
                                     clock_note=_clk0, gap_note=_gap0, alias_note=getattr(rd, "alias_note", None))
                    path_.write_text(h_, encoding="utf-8")
                _deliver(cfg, {**cfg["mail"], "recipients": to_}, _unread_subject(run_at, errs_, None if len(_by_to) == 1 else sole_),
                         h_, path_)
    # 무엇과 비교한 것인지 — PC가 며칠 꺼져 있던 날의 '변경 12건'이 어제 하루 일로
    # 읽히던 것 (2026-09-09 자동 실행 검토 중간 8)
    _since = None
    if snapshot_id is not None and not is_baseline:
        try:
            prev = state.prev_snapshot_id(snapshot_id)
            _since = state.snapshot_local_time(prev) if prev else None
        except Exception:
            _since = None
    # 열린 검토 필요 누적 — 메일은 **새로 잡힌 것만** 싣는다(같은 경고가 매일 오던 소음 제거). 그러다 보니
    # 한 번 넘긴 검토 필요가 몇 주째 열려 있어도 메일 쪽에서는 보이지 않았다 (검토36 B 3). 수만 한 줄로
    open_backlog: dict = {}
    if not is_baseline:
        try:
            for d in state.issues():
                n_, old_ = open_backlog.get(d["project"], (0, None))
                day_ = _local_date_of(d["detected_at"])
                open_backlog[d["project"]] = (n_ + 1, day_ if old_ is None or day_ < old_ else old_)
        except Exception:
            open_backlog = {}
    mailed_any = False
    # 파일 단위 읽기 실패는 그 파일의 프로젝트 메일에만 — 다른 프로젝트 담당에게 받는 범위 밖 경로가 실렸다 (ux26 WK4). 그 프로젝트 메일이
    # 오늘 없으면 그 프로젝트 받는 사람 목록으로 오늘 나가는 통에 함께 싣고, 그런 통이 없을 때만 따로 한 통 (ux27 K1 — 아래 _left)
    _unread_proj = {p_: _unread_project(resolver, p_) for p_, _e in scan_errors or ()}
    _mailed_projs: set = set()

    def _unread_for(proj_) -> list:
        return [e_ for e_ in scan_errors or () if _unread_proj.get(e_[0]) in (None, proj_)]
    if not args.dry_run:
        _resend_unsent(state, cfg)
    _present_dirs = None              # 지금 남은 파일들의 조상 폴더 — 폴더 통째 삭제 판정용, 필요할 때 한 번 (R5-6)
    # 하루 한 통 묶음(기본 켬, mail.digest: false면 프로젝트마다) — 프로젝트 넷이면 아침에 넷이 와 읽지 않게 됐다 (기능 검토 M1)
    _digest_on = _cfg_on((cfg.get("mail") or {}).get("digest"), True)
    _outbox: list = []          # 오늘 나갈 통 — 어느 통에 어떤 안내를 실을지는 통이 다 정해진 루프 뒤에야 안다 (ux27 K1)
    _day_brief: dict = {}       # 프로젝트 → (브리핑 함수, 오늘 브리핑 파일) — 메일 없이 파일만 남은 프로젝트의 안내 통이 다시 쓴다 (K2)
    # 첫 검사(기준선) 날은 프로젝트별 기준선 통 대신 '도입 첫날 보고서' 한 통 — 메일이 설정돼 있을 때 (M7)
    _first_day_mail = is_baseline and not args.dry_run and snapshot_id is not None and _mail_configured(cfg)
    for proj in sorted(groups):
        g = groups[proj]
        if rd.reg_paths and not is_baseline:
            # 새로 켠 확장자의 첫 등록은 그 프로젝트의 '기준선 등록' 브리핑으로 따로 남기고
            # (메일 없음), 오늘 브리핑에는 진짜 변경만 싣는다 (검토18 ③-A)
            regs = [c for c in g["changes"] if c.path in rd.reg_paths]
            if regs:
                reg_path = _brief_target(
                    brief_dir / brief_filename(run_at, proj, baseline=True), run_at,
                    merged=False, dry_run=True)
                # 새로 추가한 폴더의 첫 검사가 찾은 검토 필요(기존 불일치)는 그 기준선 브리핑에
                # 싣는다 — 첫 검사(기준선)와 같은 규칙. 오늘 변경 브리핑에 남기면 "변경 0건 /
                # 검토 필요 6건" 메일이 나간다 (2026-09-11 실사용 첫날)
                def _root_of(p):
                    return p.split("/", 1)[0] if "/" in p else p

                def _touches_new_root(i) -> bool:
                    # 대표 경로(i.path)는 정렬상 앞선 파일이라 기존 폴더 쪽일 수 있다 — 근거에 새 폴더
                    # 파일이 하나라도 인용되면 그 폴더의 첫 검사가 드러낸 기존 불일치다 (검토20 A-2)
                    if _root_of(i.path) in rd.reg_roots:
                        return True
                    return any(re.search(r"(?<![\w/])" + re.escape(rr) + "/", str(ev))
                               for ev in (i.evidence or ()) for rr in rd.reg_roots)
                reg_issues = [i for i in g["issues"] if _touches_new_root(i)]
                why = []
                reg_exts = sorted({PurePosixPath(c.path).suffix.lower() for c in regs
                                   if PurePosixPath(c.path).suffix.lower() in rd.reg_exts})
                if reg_exts:
                    why.append(f"새로 켠 확장자({', '.join(reg_exts)})")
                reg_roots = sorted({_root_of(c.path) for c in regs if _root_of(c.path) in rd.reg_roots})
                if reg_roots:
                    why.append(f"새로 추가한 감시 폴더({', '.join(reg_roots)})")
                def _reg_brief(for_mail: bool) -> str:
                    # 첫 검사(기준선)와 같은 재료를 다 싣는다 — 그림 비교를 해 놓고 사진을 안 싣던
                    # 것 (검토20 A-7). 메일 판만 사진 상한
                    return build_brief(
                        regs, run_at, str(root), details=details, issues=reg_issues, project=proj,
                        ack_base=cfg["ack_url"], ack_tokens=ack_tokens, scan_errors=_unread_for(proj),
                        captures=captures, scanned_count=scanned,
                        doc_info=doc_info, baseline=True, acked_by=acked_by,
                        details_by_id=details_by_id, photo_budget=for_mail,
                        baseline_note=f"{' · '.join(why) or '첫 등록'}의 첫 등록입니다")
                reg_path.write_text(_reg_brief(False), encoding="utf-8")
                print(f"[{proj}] 첫 등록 {len(regs)}건"
                      f"{f' / 검토 필요 {len(reg_issues)}건' if reg_issues else ''} → {reg_path}")
                if reg_issues and not args.dry_run and not _QUIET_PROJECT.search(proj or ""):
                    # 기준선에 검토 필요가 있으면 첫 검사와 같이 초안을 만든다 (등록만이면 없음)
                    subj = (f"[Drev] [{proj}] {run_at.strftime('%Y-%m-%d')} 기준선 등록 {len(regs)}건"
                            f" / 검토 필요 {len(reg_issues)}건")
                    # 첫 등록 통도 같은 규칙(프로젝트별 + 늘 받는 사람) — 사장(always)이 빠졌다 (검토67 D5)
                    _deliver(cfg, {**cfg["mail"], "recipients": _recipients_for(cfg, proj)},
                             subj, _reg_brief(True), reg_path)
                    mailed_any = True
                    _mailed_projs.add(proj)
                g["changes"] = [c for c in g["changes"] if c.path not in rd.reg_paths]
                g["issues"] = [i for i in g["issues"] if i not in reg_issues]
                if not g["changes"] and not g["issues"]:
                    continue
        # 등록 파일이 하나도 안 남은 폴더의 삭제 — '폴더 X 전체(N개) 삭제' 한 줄로 (R5-6)
        _wiped = []
        if not is_baseline and any(c.kind == "removed" for c in g["changes"]):
            try:
                from watcher.brief import arrange_changes as _arr, wiped_folders as _wf
                if _present_dirs is None:
                    _present_dirs = set()
                    for p_ in [r.path for r in (rd.records or [])] + list(rd.carry_paths or []):
                        _present_dirs.update(str(a) for a in PurePosixPath(p_).parents)
                _wiped = _wf(_arr(g["changes"], details, details_by_id)[0], _present_dirs)
            except Exception:
                _wiped = []
        day_path = brief_dir / brief_filename(run_at, proj, baseline=is_baseline)
        # 합산했으면 그 날 파일을 갱신(덮어씀), 아니면(dry-run·기준선) 시각을 붙여 보존.
        # 합산본이 앞선 검사의 근거까지 담으므로 덮어도 잃는 게 없다 (위 details_by_id)
        brief_path = _brief_target(day_path, run_at, merged=proj in merged_note,
                                   dry_run=bool(args.dry_run))
        def _brief(for_mail, g=g, proj=proj, _wiped=_wiped, errs=None, above=None) -> str:   # 기본값으로 묶는다 — 하루 묶음은 루프 뒤에 부른다 (M1)
            return build_brief(g["changes"], run_at, str(root), details=details,
                               issues=g["issues"], project=proj, ack_base=cfg["ack_url"],
                               ack_tokens=ack_tokens, scan_errors=_unread_for(proj) if errs is None else errs,
                               errors_above=above,
                               captures=captures, scanned_count=scanned,
                               doc_info=doc_info, baseline=is_baseline,
                               merged_note=merged_note.get(proj), acked_by=acked_by,
                               rollback_note=_rollback_note(rd, {c.path for c in g["changes"]}, g["issues"]),
                               clock_note=_clock_note(state), gap_note=_missed_days_note(state),
                               alias_note=getattr(rd, "alias_note", None),
                               continued=[c_ for c_ in (rd.continued or []) if c_[2] == proj],
                               # 이 메일의 '검토 필요'에 이미 실린 것은 빼고 — 같은 날 두 번째 검사의 합본 메일에서 앞선 검사의
                               # 불일치가 '검토 필요'와 '아직 열린 불일치'로 두 번 실렸다 (검토53 D 중간 2)
                               still_open=[s_ for s_ in (getattr(rd, "still_open", None) or []) if s_[0] == proj
                                           and (s_[1], _msg_core(s_[2])) not in
                                           {(i_.code, _msg_core(i_.message)) for i_ in g["issues"]}],
                               recurred=rd.recurred,
                               details_by_id=details_by_id, since=_since,
                               photo_budget=for_mail,
                               open_backlog=_backlog_of(open_backlog.get(proj), run_at),
                               resolved=auto_resolved.get(proj) or (auto_resolved.get(None) if proj in (None, "미분류") else None),
                               rejudged=g.get("rejudged"),
                               wiped_folders=_wiped,
                               ordered_tags=_ordered_tags(state, proj, [c.path for c in g["changes"]]))
        # 디스크에 남는 브리핑은 **사진을 다 담는다** — 여기가 보존 기간 뒤에도 남는
        # 근거다. 용량 상한은 메일 한 통에만 건다 (2026-09-09 배포 후 검토, 원칙 4)
        html = _brief(for_mail=False)
        brief_path.write_text(html, encoding="utf-8")
        _day_brief[proj] = (_brief, brief_path)
        srcs = {proj_of[c.path][1] for c in g["changes"] if c.path in proj_of}
        n_main, n_quiet = (len(g["changes"]), 0) if is_baseline else brief_counts(g["changes"], details, details_by_id)
        print(f"[{proj}] {'기준선 등록' if is_baseline else '변경'} {n_main}건"
              f"{f' (+그 밖의 알림 {n_quiet}건)' if n_quiet else ''} / "
              f"검토 필요 {len(g['issues'])}건 "
              f"(귀속 근거: {', '.join(sorted(srcs)) or '—'}) → {brief_path}")

        if args.dry_run:
            continue
        if _QUIET_PROJECT.search(proj or ""):
            # 임시·공용·아카이브·양식 폴더가 '프로젝트'로 매일 메일 초안을 받았다 (파일럿 모의 ⑥).
            # 브리핑 파일은 남기되 초안·발송은 하지 않는다
            print(f"[{proj}] 보관·공용 성격의 폴더 — 메일 초안은 만들지 않습니다 (브리핑 파일만)")
            continue
        if is_baseline and (not g["issues"] or _first_day_mail):
            continue                       # 기준선 등록만 있는 프로젝트는 메일 초안을 만들지 않는다 (첫날 보고서가 대신 — M7)
        from watcher.brief import uncompared_resaves as _uncmp
        _n_uncmp = 0 if is_baseline else len(_uncmp(g["changes"], details, details_by_id))
        if not is_baseline and not n_main and not g["issues"] and not _n_uncmp:
            continue                       # 이동·복사본·재저장뿐인 날은 보낼 게 없다 (브리핑만 남김)
        # 단 그림·개체를 비교하지 못한 재저장(DOCX·XLSX — 문서 안 그림만 바꾼 날도 이 꼴)은 바뀐 사실을 한 줄로 알린다
        # (원칙 5, 검토69 B M2b: 그림 바이트만 바꾼 사양서가 '참고'뿐이라 메일이 없었다)
        # 프로젝트별 수신자는 전체 수신자를 **대체**한다 — 그래서 사장이 P26-040 메일을 못 받았다
        # (검토21 파일럿 중간 13). 모든 통을 받아야 하는 사람은 always_recipients에
        recipients = _recipients_for(cfg, proj)
        # 구매 담당 — BOM·발주서·견적서가 바뀌었거나 도면-BOM 불일치가 있는 날의 프로젝트 메일만 받는다. 수신자가 프로젝트별로만
        # 있어 BOM 변경·불일치 메일이 구매에 가지 않았다 (구매자 평가 P4 차단 1)
        _buyers = [a for a in ((cfg.get("mail") or {}).get("purchase_recipients") or []) if a]
        if _buyers:
            from watcher.brief import impact_label as _imp
            # 경로만 보아 다시 저장만 한 BOM에도 구매가 받았다 — 파일이 새로 생겼거나 없어졌거나 행이 실제로 바뀐 날만 (검토55 ④3)
            def _rows_moved(c) -> bool:
                # 새로 생기거나 없어진 것은 표 문서(BOM·발주서·견적서)일 때만 — 도면 PDF 출도·폴더 이름 변경에도 구매가
                # 받았다 (검토56 ④16). 도면의 부품표는 본문 글자로 읽혀 행(ROW_)이 생기지 않으니, 도면만 바뀐 날은 아래 도면-BOM
                # 불일치가 있을 때만 구매가 받는다 (검토57 ④16 — 조건을 사실대로)
                # 확장자로 가르면 공급사가 보낸 발주서·견적서 PDF가 생긴 날을 놓쳤다 (검토57 ④16 — 검토56 퇴행) — 문서 종류로
                if c.kind in ("added", "removed"):
                    from watcher.doctype import canonical as _can, kind_of as _kind
                    return _can(_kind(c.path, cfg) or "") != "도면"
                its = items_for(c, details, details_by_id)     # 빈 상세도 그대로 — 'or' 폴백은 뒤 수정을 빌렸다 (검토58 F4-1)
                return any(str(getattr(it, "kind", "")).startswith("ROW_") and it.kind != "ROW_MOVED" for it in its)
            if any(_imp(c.path, cfg) in ("발주 영향", "견적 영향") and _rows_moved(c) for c in g["changes"]) \
                    or any(i.code == "BOM_MISMATCH" for i in g["issues"]) \
                    or any(_po_marked(items_for(c, details, details_by_id)) for c in g["changes"]):   # 발주 후 변경 (J8)
                recipients = recipients + [a for a in _buyers if a not in recipients]
        mail_cfg = {**cfg["mail"], "recipients": recipients}
        # 제목에 무엇이 바뀌었는지 힌트 — 구매 담당은 BOM인지 Rev인지를 열어 봐야 알았고,
        # "검토 필요 0건"이 매일 붙어 신호가 죽었다 (검토19 브리핑 ⑭)
        hint_parts = []

        def _items_of(c):        # 갱신 통은 변경 id별 상세 — 경로 키로 세면 같은 파일을 두 번 센다
            return items_for(c, details, details_by_id)
        from watcher.diff import is_rev_field
        from watcher.scan import rev_key as _rk, rev_shape as _rs

        def _rev_down(it) -> bool:
            o_, n_ = str(it.old or "").strip(), str(it.new or "").strip()
            return bool(o_ and n_ and _rs(o_) is not None and _rs(o_) == _rs(n_) and _rk(n_) < _rk(o_))
        # 올림과 내림을 가른다 — 백업을 되돌려 12장이 Rev B→A로 내려간 날 제목이 '[Rev 올림 12]'였다 (검토43 C 차단 1)
        # 파일마다 하나 — 표지 REV와 바닥글 REV#2를 함께 올린 문서가 'Rev 올림 2'였다 (검토46 A 중간 2). 첫째 칸을 먼저
        _rev_items = []
        for c in g["changes"]:
            _rs_ = [it for it in _items_of(c) if is_rev_field(it)]
            if _rs_:
                _rev_items.append(next((it for it in _rs_ if "#" not in str(it.key)), _rs_[0]))
        n_down = sum(1 for it in _rev_items if _rev_down(it))

        def _rev_other(it) -> bool:
            # 꼴이 다른 Rev 변화(A→P1 예비판으로, B→'-')는 올림도 내림도 아니다 — 전부 '올림'으로 셌다 (검토44 B J03).
            # 첫 기재(빈 값→A)는 올림으로 둔다
            o_, n_ = str(it.old or "").strip(), str(it.new or "").strip()
            so, sn = _rs(o_), _rs(n_)
            if not (o_ and n_) or so == sn or (so or ("",))[0] == "X":
                return False                    # 같은 꼴·첫 기재('-'→A)
            return not ((so or ("",))[0] == "P" and (sn or ("",))[0] in ("L", "D"))   # 예비판→정식판(P1→A)은 올림
        n_other = sum(1 for it in _rev_items if _rev_other(it))
        n_rev = len(_rev_items) - n_down - n_other
        # 'BOM행'은 구매로 이어지는 표(BOM·발주서·견적서)의 행만 — 사양서·회의록 표 행까지 세어
        # 구매 담당이 BOM 변경으로 읽었다 (검토21 브리핑 차단 1). 그 밖의 표는 '표 행'
        from watcher.brief import impact_label as _impact
        # 행 수는 **행**으로 센다 — 한 행의 칸 셋(M-101.QTY·M-101.SPEC…)이 'BOM행 3'이 됐다 (검토43 C 중간 4)
        # 행은 **자리(where)** 로 센다 — 키를 '.'에서 자르면 품명 'SCH.40 PIPE 50A'·'SCH.40 PIPE 80A'가 한 행이 됐다 (검토44 A 낮음 1)
        def _rows_of(c):
            return {(c.path, str(it.where or "") or str(it.key or "")) for it in _items_of(c)
                    if it.kind.startswith("ROW_") and it.kind != "ROW_MOVED"}
        # 이름표는 문서 종류로 — 발주서 납기만 바뀐 날 제목이 '[BOM행 1]'이었다 (검토44 C 중간 1)
        from watcher.doctype import kind_of as _kind_of
        _row_by_kind: dict = {}
        for c in g["changes"]:
            if _impact(c.path, cfg) in ("발주 영향", "견적 영향"):
                _k = _kind_of(c.path, cfg)
                # 영문 이름('Purchase Order')도 같은 이름표로 — PO-50.xlsx가 'BOM행'으로 셌다 (검토45 B J26)
                _k = {"Purchase Order": "발주서", "Quotation": "견적서", "Purchase Request": "구매요청서"}.get(_k, _k)
                _k = _k if _k in ("발주서", "견적서", "자재표", "구매요청서") else "BOM"
                _row_by_kind[_k] = _row_by_kind.get(_k, 0) + len(_rows_of(c))
        n_row = sum(_row_by_kind.values())
        n_tbl = sum(len(_rows_of(c)) for c in g["changes"]) - n_row
        crit_parts = []       # 제목이 길어도 빼지 않는 꼬리 — 사고의 신호 (구매 평가 2차 F2)
        if n_rev:
            hint_parts.append(f"Rev 올림 {n_rev}")   # "[Rev 1]"이 리비전 번호로 읽혔다 (검토41 S6 중간 4)
        if n_down:
            hint_parts.append(f"Rev 내림 {n_down}")
            crit_parts.append(f"Rev 내림 {n_down}")
        if n_other:
            hint_parts.append(f"Rev 꼴 바뀜 {n_other}")
        for _k, _n in sorted(_row_by_kind.items(), key=lambda kv: (kv[0] != "BOM", kv[0])):
            if _n:
                hint_parts.append(f"{_k}행 {_n}" if _k == "BOM" else f"{_k} {_n}행")
        if n_tbl:
            hint_parts.append(f"표 행 {n_tbl}")
        if _n_uncmp:
            # '변경 0건'만으로는 왜 온 통인지 몰랐다. 다른 변경과 섞인 통에도 늘 — 섞이면 꼬리가 빠져 그 파일이 제목에서 사라졌다
            # (검토71 R4 차단 2)
            hint_parts.append(f"그림·개체 비교 못 한 재저장 {_n_uncmp}")
            crit_parts.append(f"그림·개체 비교 못 한 재저장 {_n_uncmp}")
        # 오늘 바뀌었는데 읽지 못한 파일(손상·잠김) — 제목이 '변경 1건'뿐이라 도면이 깨진 날인 줄 몰랐다 (검토47 C 중간 4)
        _n_unread = sum(1 for c in g["changes"] if c.kind != "removed" and c.path in (rd.extract_failures or {}))
        if _n_unread:
            hint_parts.append(f"읽지 못함 {_n_unread}")
            crit_parts.append(f"읽지 못함 {_n_unread}")
        # 제목만으로 구매가 거를 수 있게 — 불일치(도면 간·도면-BOM)는 따로 센다 (검토39 P3 중간 7)
        _n_mis = sum(1 for i in g["issues"] if i.code in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS"))
        # Rev를 올리며 리비전 블록을 안 적은 날이 가장 중요한데 제목에 흔적이 없었다 (검토48 C 중간 7)
        _n_blk = sum(1 for i in g["issues"] if i.code == "REV_BLOCK_MISMATCH")
        _kinds = "·".join(x for x in ((f"불일치 {_n_mis}" if _n_mis else ""),
                                      (f"개정표 {_n_blk}" if _n_blk else "")) if x)
        # 제목 끝에 **무엇이** — 건수·꼬리표만으로는 무엇이 바뀌었는지 몰랐다. '(+그 밖의 알림 N건)'은 사장에게 뜻이 없어 뺀다
        # (구매자 평가 P1·P3). 메일 머리 한 줄(mail_headline)의 짧은 말 — 'MCCB-04 75→100AT, BOM 그대로'. 없으면(값 변화가 없는 날)
        # 첫 항목의 요약: 검토 필요가 걸린 파일 → 사양값·표 행이 바뀐 파일 → 첫 변경 순
        _what = ""
        if not is_baseline and (n_main or g["issues"]):
            try:
                from watcher.brief import _short_no, _toc_entries, arrange_changes, mail_headline
                _main = arrange_changes(g["changes"], details, details_by_id)[0]
                _what = mail_headline(_main, g["issues"], details, doc_info, details_by_id, proj)[1]
                if not _what and _wiped:
                    # 폴더 통째 삭제 — 첫 파일 이름 '…pdf 삭제 외 25' 대신 (R5-6)
                    _n_w = sum(n_ for _d, n_ in _wiped)
                    _what = (f"폴더 {PurePosixPath(_wiped[0][0]).name} 전체 삭제 {_wiped[0][1]}개"
                             + (f" 외 폴더 {len(_wiped) - 1}개" if len(_wiped) > 1 else "")
                             + (f" 외 {len(_main) - _n_w}" if len(_main) > _n_w else ""))
                if not _what and _main:
                    _ent = _toc_entries(_main, details, doc_info, False, details_by_id)
                    _iss_paths = {i.path for i in g["issues"]}
                    _pick = (next((e for e in _ent if _main[e[0]].path in _iss_paths), None)
                             or next((e for e in _ent if e[3]), None) or (_ent[0] if _ent else None))
                    if _pick:
                        _sm = _pick[2]
                        _inner = re.search(r"\(([^()]*→[^()]*)\)", _sm)        # '표 변경 2건 (M-101 SPEC: 5.5kW → 7.5kW)'의 괄호 안
                        _sm = re.sub(r"\s*→\s*", "→", _inner.group(1) if _inner else _sm)
                        _c0 = _main[_pick[0]]
                        _nm = _short_no(((doc_info or {}).get(_c0.id) or (doc_info or {}).get(_c0.path) or {}).get("dwg"),
                                        proj) or PurePosixPath(_c0.path).name
                        _what = f"{_nm} {_sm}" + (f" 외 {len(_main) - 1}" if len(_main) > 1 else "")
            except Exception:
                _what = ""
        subject = _compose_subject(
            f"[Drev] [{proj}] {run_at.strftime('%Y-%m-%d')} {'기준선 등록' if is_baseline else '변경'} {n_main}건",
            len(g["issues"]), _kinds, hint_parts, crit_parts, _what, " (갱신)" if merged_note.get(proj) else "")
        # 하루 한 통 — 프로젝트별 받는 사람이 없는 프로젝트는 루프 뒤에 받는 사람이 같은 것끼리 한 통으로 (기능 검토 2026-11-02 M1)
        _outbox.append({"proj": proj, "mail_cfg": mail_cfg, "subject": subject, "make": _brief,
                        "path": brief_path, "n": n_main, "n_iss": len(g["issues"]), "crit": list(crit_parts),
                        "merged": bool(merged_note.get(proj)),
                        "digest": _digest_on and not _project_cfg(cfg, proj).get("recipients"),
                        "own": [e_ for e_ in scan_errors or () if _unread_proj.get(e_[0]) == proj],
                        "common": [e_ for e_ in scan_errors or () if _unread_proj.get(e_[0]) is None],
                        "hosted": []})
        mailed_any = True
        _mailed_projs.add(proj)
    # 오늘 메일이 없는 프로젝트의 못 읽은 파일 — 받는 사람 목록으로 묶는다. 프로젝트마다 한 통이면 '변경 1 + 다른 프로젝트 잠김 3'이
    # 넉 통이 돼 하루 묶음(M1)을 거꾸로 돌렸다 (ux27 K1). 목록이 다르면 절대 섞지 않는다 — 범위 밖 경로를 보내지 않는 것이 WK4의 목적이다.
    # 메일이 한 통도 없는 날은 프로젝트를 모르는 안내도 여기로 — 전체 받는 사람에게 (검토38 R3-5)
    _left: dict = {}
    if groups and scan_errors and not args.dry_run and not is_baseline:
        for e_ in scan_errors:
            pj_ = _unread_proj.get(e_[0])
            if pj_ in _mailed_projs or (pj_ is None and mailed_any):
                continue
            to_ = _recipients_for(cfg, pj_)
            ent_ = _left.setdefault(_list_key(to_), {"to": to_, "errs": [], "projs": []})
            ent_["errs"].append(e_)
            if pj_ is not None and pj_ not in ent_["projs"]:
                ent_["projs"].append(pj_)
        for k_ in list(_left):
            host_ = next((m_ for m_ in _outbox if _list_key(m_["mail_cfg"].get("recipients")) == k_), None)
            if host_ is not None:
                host_["hosted"].extend(_left.pop(k_)["errs"])
    for m_ in _outbox:
        if not m_["digest"]:
            _deliver_one(cfg, m_)
    if any(m_["digest"] for m_ in _outbox):
        _deliver_digest(cfg, [m_ for m_ in _outbox if m_["digest"]], run_at, brief_dir, is_baseline)
    if is_baseline and snapshot_id is not None and not args.dry_run:
        try:
            _fd = write_first_day_report(cfg, state, rd, proj_of, issues, run_at, brief_dir)
            if _first_day_mail:
                _deliver_first_day(cfg, state, rd, proj_of, issues, run_at, brief_dir, _fd)   # 받는 사람별 판 (rr066 mail 1)
                mailed_any = True
        except Exception as e:      # noqa: BLE001 — 보고서가 실패해도 검사는 성공
            print(f"경고: 도입 첫날 보고서를 만들지 못했습니다(검사 결과는 정상): {e}", file=sys.stderr)
    # 그 목록의 통이 오늘 전혀 없다 — 목록마다 한 통. 이동·재저장뿐이라 메일 없이 파일만 남은 날은 안내도 그 파일에 이미 실려 있으니
    # 둘째 '변경 0건' 파일을 만들지 않고 그 파일을 통으로 낸다 (ux27 K2, 검토38 R3-5)
    for ent_ in sorted(_left.values(), key=lambda x_: x_["projs"]):
        errs_, projs_ = ent_["errs"], ent_["projs"]
        sole_ = projs_[0] if len(projs_) == 1 and all(_unread_proj.get(e_[0]) for e_ in errs_) else None
        # 다시 쓰는 것은 그 안내의 프로젝트 파일뿐 — 받는 사람이 같다고 남의 파일을 집으면 보관·공용 폴더의 변경 상세가 '변경 0건' 제목으로
        # 나갔다 (ux28 mail 1·2)
        made_ = _day_brief.get(projs_[0]) if len(projs_) == 1 else None
        if made_ is not None:
            path0 = made_[1]
            html0 = _fit_mail_size(lambda: made_[0](True, errs=errs_))
        else:
            path0 = _unique_brief(brief_dir / brief_filename(run_at, sole_), run_at)
            html0 = build_brief([], run_at, str(root), scan_errors=errs_, project=sole_, scanned_count=scanned,
                                clock_note=_clk0, gap_note=_gap0, alias_note=getattr(rd, "alias_note", None))
            path0.write_text(html0, encoding="utf-8")
        _deliver(cfg, {**cfg["mail"], "recipients": ent_["to"]}, _unread_subject(run_at, errs_, sole_), html0, path0)
    _note_mail_trouble(state)
    if args.dry_run:
        # dry-run은 '메일만 생략'이지 미리보기가 아니다 — 검사 기록이 남아 같은 변경은 다시 보고되지 않는다.
        # 기록을 되돌리는 안은 시험 29곳이 이 뜻에 기대고 있어 접었다 (2026-09-06 사용성 4차 ④-2)
        print("(dry-run: 메일 초안·발송만 생략 — 검사 기록은 남으므로 같은 변경은 다음 검사에서 다시 보고되지 않습니다)")


_PAIR_FILES_MAX = 40      # 한 검사에서 사양-태그 짝을 찾으려 다시 읽는 DXF 수 상한 (도면 수백 장 재출도 날 시간 보호)


def _pair_spec_tags(rd, details: dict) -> None:
    """DXF 글줄 변경에 '태그: 옛 값 → 새 값' 이름표 — 같은 높이 사양 글자가 한 줄로 묶여 어느 기기 값인지 메일에서 찾을 수
    없었다 (구매 평가 2차 F2). 이름표만 붙인다(비교·이슈·캐시 불변). 실패하면 조용히 그대로."""
    n = 0
    for p_, its in list(details.items()):
        if PurePosixPath(p_).suffix.lower() != ".dxf" or not any(
                getattr(i, "kind", "") in ("TEXT_CHANGED", "TEXT_ADDED") and str(getattr(i, "where", "")).startswith("레이어 ")
                for i in its or ()):
            continue
        ap = (getattr(rd, "abs_of", None) or {}).get(p_)
        if ap is None:
            continue
        if n >= _PAIR_FILES_MAX:
            break
        n += 1
        try:
            from watcher.capture import _dxf_texts_cached
            from watcher.diff import spec_tag_labels
            details[p_] = spec_tag_labels(list(its), _dxf_texts_cached(Path(ap)))
        except Exception as e:      # noqa: BLE001  — 이름표는 덤이다
            print(f"  (사양-태그 짝 생략 — {PurePosixPath(p_).name}: {type(e).__name__})", file=sys.stderr)


# 한 검사 안의 발송 상태 — 서버가 죽은 날 프로젝트 30개가 각각 10초씩 기다리며 경고 30줄을
# 내던 것 (검토19 운영 ③). 첫 실패 뒤에는 시도하지 않고 합산해 한 줄로, 그리고 화면 배너로
def _visual_note(where) -> str:
    """그림 변경 항목의 문구 — 쪽 크기만 바뀐 곳은 사진이 없는데 '사진 참조'라 했다 (검토61 B31)."""
    if "페이지 크기 변경" in str(where or ""):
        return "페이지(용지) 크기가 바뀜 — 크기가 달라 전/후를 겹쳐 비교할 수 없어 사진이 없습니다. 파일을 열어 확인하세요"
    return "도면 그림 변경 감지 (전/후 확대 사진 참조)"


def _ocr_read(doc) -> bool:
    """글자를 OCR로 읽은 쪽이 있는 문서인가 (스캔본)."""
    if doc is None:
        return False
    return any("OCR" in str(getattr(t, "where", "") or "") for t in (getattr(doc, "raw_texts", None) or [])) \
        or any("OCR" in str(getattr(f, "where", "") or "") for f in (getattr(doc, "fields", None) or {}).values())


MAIL_TROUBLE_KEY = "mail_trouble"
DRAFT_TROUBLE_KEY = "draft_trouble"   # .eml 초안 저장 실패 — 전에는 stderr에만 남았다 (검토60 ②)
# 프로젝트가 아니라 보관·공용 성격의 폴더 이름 — 메일 초안 대상에서 뺀다
from watcher.project import QUIET_PROJECT_RE as _QUIET_PROJECT  # noqa: E402  (규칙은 project.py 한 곳 — 이름 전체 일치, 검토20 r13 9)
_MAIL_STATE = {"down": "", "skipped": 0, "sent": 0, "draft_fail": "", "drafted": 0, "refused": [], "unsent": []}
MAIL_UNSENT_KEY = "mail_unsent"     # 못 보낸 통(.eml) — 다음 검사가 다시 보낸다 (검토67 D4)


_REASON_COL = re.compile(r"(?i)^(DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)$")
_REVCOL = re.compile(r"(?i)^(REV(ISION)?|개정|판|버전|VER)")


def _reason_from_items(items) -> str | None:
    """이번 변경에서 추가된 리비전 행(REVROW_ADDED)의 사유 — 여럿이면 마지막. REV 열이 없는 개정이력
    (NO·DATE·내용)에서는 최신 행을 REV로 못 찾으니 '이번에 생긴 행'이 곧 새 사유다 (2회차 A2)."""
    added = [it for it in (items or []) if getattr(it, "kind", None) == "REVROW_ADDED"]
    if len(added) > 1:
        # 새 행 하나에 옛 행들까지 '추가'로 잡힌 경우(키 열이 흔들림) — 가장 옛 사유가 실리지 않게
        # 일자·Rev가 가장 최신인 행 하나만 본다 (3회차 A4 → 4회차: 행 번호 최소는 아래가 최신인 양식에서 거꾸로)
        def _when(it):
            txt = str(getattr(it, "new", "") or "")
            dm = re.search(r"(?:DATE|일자|날짜)'?\s*[:=]\s*'?(\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{8})", txt, re.I)
            d = re.sub(r"\D", "", dm.group(1)) if dm else ""
            nm = re.search(r"(?:NO|번호|순번|연번)'?\s*[:=]\s*'?(\d{1,5})", txt, re.I)
            no = int(nm.group(1)) if nm else -1
            rm = re.search(r"(?:REV(?:ISION)?|개정|판)'?\s*[:=]\s*'?([A-Za-z0-9.]{1,6})", txt, re.I)
            rv = rm.group(1).upper() if rm else ""
            wm = re.search(r"행(\d+)", str(getattr(it, "where", "") or ""))
            top = -int(wm.group(1)) if wm else 0          # 전부 같으면 위쪽 행(흔한 '위가 최신' 양식)
            return (d, no, (2, int(rv)) if rv.isdigit() else (1, len(rv), rv), top)
        added = [max(added, key=_when)]      # 일자 > 순번 > Rev > 위쪽 행 (5회차 A3: 같은 날 두 행·DATE 없는 양식)
    for it in reversed(added):
        txt = str(getattr(it, "new", "") or "")
        m = (re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*'([^']*)'", txt, re.I)
             or re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*([^,}]+)", txt, re.I))
        if m and m.group(1).strip():
            return m.group(1).strip()
    return None


def _latest_rev_note(rev_rows, cur_rev: str | None) -> str | None:
    """리비전 행들에서 **최신 판**(표제란/개정이력 REV와 같은 값, 없으면 마지막 행)의 사유.
    엑셀 개정이력이 위가 최신인 양식에서 마지막 행(가장 옛 'FIRST ISSUE')이 개정 사유로 실렸다
    (검토26 1회차 4). rev_rows: Row 객체 또는 {"values": {...}} dict."""
    def _vals(r):
        if isinstance(r, dict):                       # 캐시(dict) — dict.values는 메서드다
            return r.get("values") or {}
        return getattr(r, "values", None) or {}
    rows = list(rev_rows or [])
    if not rows:
        return None
    pick = None
    if cur_rev:
        for r in rows:
            v = _vals(r)
            rv = next((str(x).strip() for k, x in v.items() if x not in (None, "") and _REVCOL.match(str(k).strip())
                       and not re.search(r"(일자|날짜|DATE|내용|사유|비고|DESC)", str(k), re.I)), None)
            if rv and rv.upper() == str(cur_rev).strip().upper():
                pick = r
        if pick is None:
            for r in rows:
                if str(getattr(r, "key", "") or "").strip().upper() == str(cur_rev).strip().upper():
                    pick = r
    if pick is None:
        pick = rows[-1]
    v = _vals(pick)
    return next((str(v[k]) for k in v if _REASON_COL.match(str(k)) and v[k]), None)


SUBJECT_MAX = 84      # 메일 목록에서 잘리지 않는 길이 — '[Drev] [프로젝트] 날짜 변경 N건 / 검토 필요 M건 — 가장 중요한 한 건'


def _compose_subject(base: str, n_issues: int, kinds: str, hints: list, crit: list, what: str, tail: str) -> str:
    """메일 제목 — 길면 덜 중요한 것부터 뺀다: 꼬리표(Rev 올림·BOM행) → 검토 필요 종류 괄호 → '무엇이'를 **낱말 경계**에서 줄임.
    사고 신호 꼬리(Rev 내림·읽지 못함·그림 비교 못 한 재저장)는 남긴다. 전에는 48자에서 글자로 잘라 '3.7kW 4…'·'M-1…'처럼
    낱말 가운데서 끊겼고, 꼬리표·파일 이름까지 붙어 목록에서 가장 중요한 값이 보이지 않았다 (구매 평가 2차 P2)."""
    from watcher.brief import cut_words

    def build(hs, with_kinds, w):
        iss = (f" / 검토 필요 {n_issues}건" + (f"({kinds})" if (kinds and with_kinds) else "")) if n_issues else ""
        return (base + iss + (f" [{'·'.join(hs)}]" if hs else "") + (f" — {w}" if w else "") + tail)
    tries = [(hints, True, what), (crit, True, what), (crit, False, what)]
    for hs, wk, w in tries:
        s = build(hs, wk, w)
        if len(s) <= SUBJECT_MAX:
            return s
    room = SUBJECT_MAX - len(build(crit, False, "x")) + 1
    if what and room >= 12:
        # 쉼표로 이은 뒷마디(', Rev A→B')부터 통째로 뗀다 — 'Rev 안…'처럼 반쪽 말이 남지 않게
        w = what
        while len(w) > room and ", " in w:
            w = w.rsplit(", ", 1)[0]
        return build(crit, False, w if len(w) <= room else cut_words(w, room))
    return build(crit, False, "")


def _unread_subject(run_at, scan_errors, project: str | None = None) -> str:
    """못 읽은 파일만 알리는 날의 제목. '파일 N건'이라 쓰면 폴더·보류 알림까지 파일로 읽힌다 (검토21 브리핑 차단 4) — 종류별로."""
    # 삭제 보류는 '알림 N건'이 아니라 제 이름으로, 맨 앞에 — 파일 79개가 사라진 날 제목이 '변경 0건 — 알림 1건'이었다 (R5-2)
    from watcher.brief import hold_file_count, split_hold_notes
    holds, scan_errors = split_hold_notes(scan_errors)
    n_f = sum(1 for p, _m in scan_errors if not str(p).endswith("/") and not str(p).startswith("("))
    n_d = sum(1 for p, _m in scan_errors if str(p).endswith("/"))
    n_n = len(scan_errors) - n_f - n_d
    n_h = hold_file_count(holds) if holds else 0
    parts = ([f"파일 {n_h}개 사라짐, 삭제 알림 보류(서버 연결 확인)" if n_h else "삭제 알림 보류(서버 연결 확인)"] if holds else []) + \
            ([f"읽지 못한 파일 {n_f}건"] if n_f else []) + \
            ([f"닿지 못한 폴더 {n_d}개"] if n_d else []) + ([f"알림 {n_n}건"] if n_n else [])
    return f"[Drev] {f'[{project}] ' if project else ''}{run_at.strftime('%Y-%m-%d')} 변경 0건 — " + " · ".join(parts)


def _project_cfg(cfg: dict, project: str) -> dict:
    """config `projects:`에서 그 프로젝트의 칸 — 키를 별칭 이름('배관동')이나 소문자('p67-105')로 적으면 조용히 무시되고
    전체 수신자에게 갔다 (검토67 D8). 정확히 같은 키 → 대소문자 무시 → 별칭 사전으로 같은 프로젝트인 키 순."""
    projs = cfg.get("projects") or {}
    if not isinstance(projs, dict) or not project:
        return {}
    if project in projs:
        return projs[project] or {}
    # NFC·NFD(맥에서 적은 키)·전각도 같은 키로 (검토20 r13 4)
    from watcher.project import fold_text
    low = fold_text(project).casefold()
    for k, v in projs.items():
        if fold_text(k).casefold() == low:
            return v or {}
    try:
        # 귀속과 같은 읽기(깨졌으면 .ok 사본) — 검토20 r13 2
        res = _alias_for_cfg(cfg)
        for k, v in projs.items():
            if fold_text(res.canonical(str(k)) or "").casefold() == low:
                return v or {}
    except Exception:
        pass
    return {}


def _recipients_for(cfg: dict, project: str | None = None) -> list[str]:
    """한 통의 수신자 — 프로젝트별 수신자(있으면 전체 수신자를 대체) + always_recipients.
    세 곳(일일·주간·0건/오류 통)이 제각각 계산해 주간 요약·오류 통이 사장(always)을 뺐다 (검토25 브리핑 C-1)."""
    mail = cfg.get("mail") or {}
    proj_cfg = _project_cfg(cfg, project) if project else {}
    out = list(proj_cfg.get("recipients") or mail.get("recipients") or [])
    if not out and project is None:
        # 프로젝트별 수신자만 있는 설정 — 주간 요약·오류 통은 그들 전부에게 (검토26 1회차 5)
        for pc in (cfg.get("projects") or {}).values():
            for a in (pc or {}).get("recipients") or []:
                if a and a not in out:
                    out.append(a)
    for a in mail.get("always_recipients") or []:
        if a and a not in out:
            out.append(a)
    return out


def _recipients_all(cfg: dict) -> list[str]:
    """주간 요약 수신자 — 매일 통을 받는 사람 모두(전체·프로젝트별·구매 담당·항상). 전체 수신자만 받아 프로젝트 담당과
    구매 담당은 매일 통은 받고 주간 요약은 못 받았다 (검토50 B 중간 7)."""
    out = _recipients_for(cfg)
    mail = cfg.get("mail") or {}
    for a in ([a for pc in (cfg.get("projects") or {}).values() for a in ((pc or {}).get("recipients") or [])]
              + list(mail.get("purchase_recipients") or [])):
        if a and a not in out:
            out.append(a)
    return out


GMAIL_CLIP_BYTES = 95_000


def _fit_mail_size(make) -> str:
    """메일 본문(사진 제외)이 Gmail 잘림 한도(102KB) 안에 들게 — 넘으면 파일당 상세 표를 40 → 12 → 4건으로 줄이고 맨 위에
    알린다. 큰 날 메일이 114~150KB라 Gmail이 중간에서 '[메시지가 잘렸습니다]'로 바꿔 뒤쪽 변경을 못 봤다 (검토50 B 차단 2).
    디스크의 브리핑 원본은 줄이지 않는다."""
    import watcher.brief as _b
    html, used = "", None
    for cap in (None, 12, 4):
        old = _b._DETAIL_CAP
        if cap is not None:
            _b._DETAIL_CAP = cap
        try:
            html = make()
        finally:
            _b._DETAIL_CAP = old
        used = cap
        fits = len(re.sub(r"data:[^\"')\s]+", "", html).encode("utf-8")) <= GMAIL_CLIP_BYTES
        if fits:
            break
    if used is not None:
        note = (f'<div style="border-left:4px solid #9a6700;padding:6px 12px;margin:0 0 10px;background:#fff8e5;'
                f'font-size:13px;color:#1f2328">메일 용량(일부 메일 앱이 약 100KB에서 본문을 자름) 때문에 파일마다 상세 '
                f'변경을 {used}건까지만 실었습니다.'
                # 줄여도 넘으면 그렇다고 — '4건까지만'으로 끝내 여전히 잘릴 수 있음을 말하지 않았다 (검토51 A 낮음 6)
                + ('' if fits else ' 그래도 변경 파일이 많아 일부 메일 앱에서는 뒤쪽이 잘려 보일 수 있습니다.')
                + ' 전체는 감시 PC의 브리핑 원본과 화면의 변경 상세에 있습니다.</div>')
        # 제목(h2) 아래에 — 맨 위에 끼어 첫 화면 첫 줄이 기술 안내였다 (재검토 R5-7)
        m = re.search(r"</h2>", html) or re.search(r"<body[^>]*>", html)
        html = html[:m.end()] + note + html[m.end():] if m else note + html
    return html


def _deliver(cfg: dict, mail_cfg: dict, subject: str, html: str, brief_path: Path) -> None:
    """메일 초안(.eml) 저장 + 자동 발송. 둘 다 실패해도 검사는 성공으로 둔다."""
    # 기본: 보내기만 하면 되는 메일 초안(.eml) 생성 — 전송은 사람이 한다 (원칙 1)
    if cfg["mail"].get("draft", True):
        from watcher.mail import write_eml
        try:
            eml = write_eml(mail_cfg, subject, html, brief_path.with_suffix(".eml"))
            _MAIL_STATE["drafted"] += 1
            if mail_cfg.get("recipients"):
                print(f"  메일 초안 저장: {eml} (더블클릭 → [보내기]만 누르면 됩니다)")
            else:      # 받는 사람이 비어 '[보내기]만'이 거짓이었다 (검토32 A 5)
                print(f"  메일 초안 저장: {eml} (받는 사람을 채운 뒤 보내세요 — 설정 › 메일)")
        except Exception as e:
            print(f"  메일 초안 생성 실패(브리핑은 정상 저장됨): {e}", file=sys.stderr)
            _MAIL_STATE["draft_fail"] = _MAIL_STATE["draft_fail"] or f"{type(e).__name__}: {e}"
    _eml = str(brief_path.with_suffix(".eml"))
    if _MAIL_STATE["down"]:
        _MAIL_STATE["skipped"] += 1        # 같은 서버가 방금 실패했다 — 다시 기다리지 않는다
        if (cfg.get("mail") or {}).get("enabled"):
            _MAIL_STATE["unsent"].append({"subject": subject, "eml": _eml})
        return
    try:
        if send_brief(mail_cfg, subject, html):
            import watcher.mail as _wm
            _ref = dict(getattr(_wm, "LAST_REFUSED", {}) or {})
            if _ref:
                # 일부 주소만 거부 — '발송 완료'로 조용히 지나갔다 (검토67 D3)
                _bad = ", ".join(sorted(_ref))
                print(f"  경고: 메일 서버가 일부 받는 사람을 거부했습니다 — {_bad} (나머지에게는 발송됨: {subject})",
                      file=sys.stderr)
                _MAIL_STATE["refused"].append(f"주소 {_bad} (통: {subject})")
            print(f"  메일 자동 발송 완료: {', '.join(a for a in (mail_cfg.get('recipients') or []) if a not in _ref)}")
            _MAIL_STATE["sent"] += 1
    except Exception as e:
        import smtplib as _smtp
        if isinstance(e.__cause__, (_smtp.SMTPRecipientsRefused, _smtp.SMTPDataError)):
            # 그 통의 받는 사람 전부 거부·그 통만 거절 — 주소 오타 하나로 그날 다른 프로젝트 통이 모두 멈췄다 (검토67 D2).
            # 서버는 살아 있으니 다음 통은 계속 보낸다. 문구는 원인대로 — 554(크기·스팸)에도 '주소를 확인하세요'였고,
            # 전원 거부는 어느 주소인지 없이 배너의 '주소:' 뒤에 제목이 왔다 (재검토 R5-4·R5-5)
            _why = str(e).rstrip(". ")
            print(f"  경고: 이 메일은 서버가 받지 않았습니다 — {_why} ({subject}). "
                  f"브리핑과 .eml 초안은 저장됨", file=sys.stderr)
            if isinstance(e.__cause__, _smtp.SMTPRecipientsRefused):
                _bad = ", ".join(sorted(str(a) for a in (getattr(e.__cause__, "recipients", None) or {})))
                _MAIL_STATE["refused"].append(f"주소 {_bad or '(알 수 없음)'} (통: {subject})")
            else:
                _MAIL_STATE["refused"].append(f"메일 본문 거절 {getattr(e.__cause__, 'smtp_code', '')} — 크기·스팸 판정일 수 있음 (통: {subject})")
            _MAIL_STATE["unsent"].append({"subject": subject, "eml": _eml, "refused": True})
            return
        _MAIL_STATE["unsent"].append({"subject": subject, "eml": _eml})
        # 발송 실패는 검사 실패가 아니다 — 여기서 예외를 올리면 그날 스냅샷이
        # 통째로 롤백돼 SMTP가 죽은 날은 이력이 하나도 안 쌓인다 (2026-09-02
        # 재검토 실측: 설정 오류면 기준선조차 영원히 안 생김). 브리핑·.eml 초안은
        # 이미 저장됐으니 경고만 남긴다
        _MAIL_STATE["down"] = str(e)
        print(f"  경고: 메일 자동 발송 실패 — {str(e).rstrip('. ')}. 브리핑 파일과 메일 초안(.eml)은 "
              f"저장됐으니 직접 보내주세요. (이번 검사의 나머지 통은 보내지 않습니다)",
              file=sys.stderr)


def _cfg_on(v, default: bool) -> bool:
    """설정의 켬/끔 — 비었으면 기본값, 'false'·'0'·'no'·'off'·'아니오'는 끔."""
    if v is None or v == "":
        return default
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() not in ("false", "0", "no", "off", "아니오")


def ack_tracking_on(cfg: dict) -> bool:
    """확인 기록 기능(기본 켬) — 끄면 메일·화면에서 확인 열·미확인 수를 빼고 '검토 필요 열림'만 (기능 검토 2026-11-02 M5)."""
    return _cfg_on((cfg or {}).get("ack_tracking"), True)


def _mail_configured(cfg: dict) -> bool:
    """메일이 설정돼 있는가 — 자동 발송을 켰거나 받는 사람이 있다(초안을 보낼 곳이 정해짐)."""
    mc = (cfg or {}).get("mail") or {}
    return bool(mc.get("enabled")) or bool(_recipients_for(cfg))


def _digest_subject(run_at, ents: list, baseline: bool, part: tuple | None = None) -> str:
    """하루 묶음 제목 — '[Drev] 11-02 변경 7건(P26-031 3·033 4) · 검토 필요 2건'. 프로젝트 번호의 같은 앞부분은 둘째부터 뗀다.
    길면 사고 신호 꼬리(프로젝트별 'Rev 내림 1')를 종류별 합계('Rev 내림 3 · 읽지 못함 5')로 접고, 그래도 길면 프로젝트 목록을
    '(프로젝트 N곳)'으로 — 꼬리에 상한이 없어 10곳이면 412자였다 (재검토 rr066 mail 3). part=(k, n)이면 끝에 '(k/n)'."""
    import os.path as _op
    names = [str(e["proj"] or "미분류") for e in ents]
    pre = _op.commonprefix(names)
    cut = max(pre.rfind("-"), pre.rfind("_"))
    pre = pre[:cut + 1] if cut >= 0 else ""
    shown = [n if (k == 0 or not pre or len(n) <= len(pre)) else n[len(pre):] for k, n in enumerate(names)]
    n_all = sum(int(e["n"]) for e in ents)
    n_iss = sum(int(e["n_iss"]) for e in ents)
    crit: list = []
    tot: dict = {}                       # 종류별 합계 — 넣은 순서 그대로
    for e in ents:
        for c in e.get("crit") or []:
            crit.append(f"{e['proj']} {c}")
            m_ = re.match(r"^(.*\S)\s+(\d+)$", str(c))
            lab, n_ = (m_.group(1), int(m_.group(2))) if m_ else (str(c), 0)
            tot[lab] = tot.get(lab, 0) + n_
    folded = [f"{lab} {n_}" if n_ else lab for lab, n_ in tot.items()]
    word = "기준선 등록" if baseline else "변경"
    _part = f" ({part[0]}/{part[1]})" if part else ""

    def tail(cr):
        return ((f" · 검토 필요 {n_iss}건" if n_iss else "") + (f" [{' · '.join(cr)}]" if cr else "")
                + (" (갱신)" if any(e.get("merged") for e in ents) else "") + _part)
    head = f"[Drev] {run_at.strftime('%m-%d')} {word} {n_all}건"
    listing = "(" + "·".join(f"{nm} {e['n']}" for nm, e in zip(shown, ents)) + ")"
    s = ""
    for body, cr in ((listing, crit), (listing, folded), (f"(프로젝트 {len(ents)}곳)", folded), ("", folded)):
        s = head + body + tail(cr)
        if len(s) <= SUBJECT_MAX:
            return s
    return s


def _body_bytes(html: str) -> int:
    """메일 본문 크기(사진 data: 제외) — Gmail 잘림 판정과 같은 셈."""
    return len(re.sub(r"data:[^\"')\s]+", "", html).encode("utf-8"))


def _list_key(to) -> frozenset:
    """받는 사람 목록 비교 열쇠 — 순서·대소문자는 다른 목록이 아니다."""
    return frozenset(str(a).strip().casefold() for a in to or () if a)


def _deliver_one(cfg: dict, e: dict) -> None:
    """프로젝트 통 한 통 — 다른 프로젝트 안내를 맡았으면(hosted, ux27 K1) 함께 싣고, 디스크의 브리핑도 메일과 같게 한다(맡긴 프로젝트는
    오늘 파일이 없을 수 있다)."""
    errs = e["own"] + e["common"] + e["hosted"] if e.get("hosted") else None
    if errs is not None:
        try:
            e["path"].write_text(e["make"](False, errs=errs), encoding="utf-8")
        except OSError as e_:
            print(f"  경고: 브리핑에 읽지 못한 파일 안내를 더하지 못했습니다({e_}) — 메일·초안은 계속", file=sys.stderr)
    _deliver(cfg, e["mail_cfg"], e["subject"],
             _fit_mail_size(lambda: e["make"](True) if errs is None else e["make"](True, errs=errs)), e["path"])


def _deliver_digest(cfg: dict, ents: list, run_at, brief_dir: Path, baseline: bool) -> None:
    """하루 묶음 — 받는 사람이 같은 프로젝트 통끼리 한 통으로. 하나뿐이면 지금처럼 그 프로젝트 통 그대로.
    사진 예산(6MB)과 Gmail 본문 압축은 묶은 통 전체에 건다(예산은 곳 수로 나눈 몫, 남으면 다음 곳으로 이월). 줄여도 Gmail 한도를
    넘으면 같은 받는 사람 묶음을 n통으로 나눠 제목에 '(1/2)' (rr066 mail 2). 디스크의 프로젝트별 브리핑은 그대로 남는다.
    프로젝트를 모르는 안내와 맡은 안내는 프로젝트 섹션마다가 아니라 통 맨 위에 한 번 (ux27 K3)."""
    from watcher.brief import PhotoBudget, _scan_errors_section, digest_brief
    by_to: dict = {}
    for e in ents:
        by_to.setdefault(tuple(e["mail_cfg"].get("recipients") or ()), []).append(e)

    def _above(chunk) -> list:
        return list(chunk[0].get("common") or ()) + [x for e in chunk for x in e.get("hosted") or ()]

    def _section(e, budget, above) -> str:
        return e["make"](budget, errs=e["own"], above=above) if "own" in e else e["make"](budget)

    def _make(chunk, subject, part=None) -> str:
        budget = PhotoBudget()             # 통 하나에 예산 하나 — 프로젝트마다 6MB씩이면 넷이 묶인 통이 24MB가 됐다
        parts = []
        above = _above(chunk)
        for i, e in enumerate(chunk):
            # 곳 수로 나눈 몫 — 선착이면 앞 프로젝트가 다 써 뒤 프로젝트는 사진이 0장이었다 (rr066 mail 4)
            sub = budget.portion(len(chunk) - i)
            parts.append((e["proj"], _section(e, sub, above)))
            budget.settle(sub)
        return digest_brief(parts, run_at, subject, part, notes=_scan_errors_section(above) if above else "")

    for _to, grp in by_to.items():
        if len(grp) == 1:
            _deliver_one(cfg, grp[0])
            continue
        subject = _digest_subject(run_at, grp, baseline)
        html = _fit_mail_size(lambda grp=grp, subject=subject: _make(grp, subject))
        mails = [(grp, subject, html)]
        if _body_bytes(html) > GMAIL_CLIP_BYTES:
            # 줄여도 넘는다 — 프로젝트 섹션 크기대로 앞에서부터 담아 n통으로. 한 곳이 혼자 넘으면 그 통은 _fit_mail_size가 줄인다
            above = _above(grp)
            empty = _body_bytes(digest_brief([], run_at, subject, notes=_scan_errors_section(above) if above else ""))
            room = GMAIL_CLIP_BYTES - empty - 2_000          # 맨 위·아래로 모은 안내 몫
            chunks, cur, used = [], [], 0
            for e in grp:
                s_ = max(0, _body_bytes(digest_brief([(e["proj"], _section(e, PhotoBudget(), above))], run_at, subject,
                                                     notes=_scan_errors_section(above) if above else "")) - empty)
                if cur and used + s_ > room:
                    chunks.append(cur)
                    cur, used = [], 0
                cur.append(e)
                used += s_
            if cur:
                chunks.append(cur)
            if len(chunks) > 1:
                mails = []
                for k, ch in enumerate(chunks, 1):
                    sj = _digest_subject(run_at, ch, baseline, part=(k, len(chunks)))
                    mails.append((ch, sj, _fit_mail_size(lambda ch=ch, sj=sj, k=k: _make(ch, sj, (k, len(chunks))))))
        for ch, sj, html_ in mails:
            path = _unique_brief(brief_dir / f"brief_{run_at.strftime('%Y%m%d')}_하루묶음.html", run_at)
            try:
                path.write_text(html_, encoding="utf-8")      # 브리핑 목록에서 '메일 초안 열기'와 짝이 되게 — 사진은 메일 예산만큼
            except OSError as e_:
                print(f"  경고: 하루 묶음 사본을 저장하지 못했습니다({e_}) — 메일·초안은 계속", file=sys.stderr)
            print(f"하루 묶음 메일: 프로젝트 {len(ch)}곳 → {path.name}")
            _deliver(cfg, grp[0]["mail_cfg"], sj, html_, path)


_FD_SAMPLE = ('<table style="border-collapse:collapse;width:100%;font-size:13px;color:#57606a;margin:6px 0">'
              '<tr><td style="padding:5px 8px;border:1px dashed #d0d7de"><b>샘플</b></td>'
              '<td style="padding:5px 8px;border:1px dashed #d0d7de">수정 · E-101 Rev B → C</td>'
              '<td style="padding:5px 8px;border:1px dashed #d0d7de">MCCB-04 정격 75AT → 100AT (표제란·개정표 근거 첨부)</td></tr>'
              '</table><p style="color:#57606a;font-size:12px;margin:0">위 한 줄은 <b>표시용 샘플</b>입니다 — 실제 변경이 아닙니다.</p>')


def write_first_day_report(cfg: dict, state: "State", rd, proj_of: dict, issues: list, run_at, brief_dir: Path,
                           only: set | None = None, name_suffix: str = ""):
    """도입 첫날 보고서 — 첫 검사(기준선)의 '변경 0건' 대신 지금 상태를 한 장으로 (기능 검토 2026-11-02 M7).
    기준선은 변경이 아니다(원칙 유지) — 이 보고서는 '현재 상태'다. 각 줄에 근거(파일·값). 의미 판단은 하지 않는다(원칙 6).
    only: 이 프로젝트들만 싣는 받는 사람별 판(요약 숫자도 그 범위로 — rr066 mail 1). 프로젝트를 알 수 없는 못 읽은 파일 알림은
    매일 브리핑처럼 모든 판에 싣는다. 디스크의 전체 판(only 없음)만 대시보드가 가리킨다.
    돌려주는 값: (경로, 메일 제목, HTML)."""
    from collections import defaultdict
    from watcher.doctype import canonical as _can, summarize as _summ
    from watcher.brief import split_hold_notes
    esc = html_escape
    paths = [r.path for r in (rd.records or [])]
    proj = {p: (proj_of.get(p) or (None,))[0] or "미분류" for p in paths}

    def _in(pj) -> bool:
        return only is None or (pj or "미분류") in only
    if only is not None:
        paths = [p for p in paths if _in(proj[p])]
    projs = sorted({proj[p] for p in paths if not _QUIET_PROJECT.search(proj[p] or "")})
    # 'Purchase Order 3 · 발주서 5'처럼 갈라졌다 — 화면 집계(web)처럼 정규 이름으로 합친다 (ux26 WK3)
    counts: dict = {}
    for k_, n_ in _summ(paths, cfg)[0].items():
        counts[_can(k_)] = counts.get(_can(k_), 0) + n_
    kinds = " · ".join(f"{esc(str(k))} {n}" for k, n in sorted(counts.items(), key=lambda kv: -kv[1]))
    secs: list = []

    def sec(title: str, rows: list, why: str = "") -> None:
        if not rows:
            secs.append(f'<li style="margin:6px 0"><b>{esc(title)}</b>: 0건</li>')
            return
        lis = "".join(f'<li>{r}</li>' for r in rows[:8]) + (f'<li style="color:#57606a">외 {len(rows) - 8}건</li>' if len(rows) > 8 else "")
        secs.append(f'<li style="margin:6px 0"><b>{esc(title)}</b>: {len(rows)}건'
                    + (f' <span style="color:#57606a;font-size:12.5px">— {esc(why)}</span>' if why else "")
                    + f'<ul style="margin:2px 0;padding-left:18px;font-size:13px">{lis}</ul></li>')
    # 같은 도면번호 여러 판 — 표제란 도면번호가 같은 파일이 둘 넘게
    by_no: dict = defaultdict(list)
    for p_, d in (rd.docs or {}).items():
        f = (d.fields or {}).get("DWG_NO")
        if f and str(f.value or "").strip() and _in(proj.get(p_, "미분류")):
            r_ = (d.fields or {}).get("REV")
            by_no[(proj.get(p_, "미분류"), " ".join(str(f.value).split()).upper())].append(
                (p_, str(r_.value) if r_ and r_.value else "—"))
    # 같은 (도면번호, Rev)의 출도본·PDF 사본은 '여러 판'이 아니다 — 원본 DXF와 같은 Rev의 출도 PDF 짝 624쌍을 전부 '구판이 함께
    # 있는지 확인'으로 실어 첫날 메일이 '살펴볼 것 608건'이었다 (rvall B1). 빼는 것은 좁게: Rev를 읽었고 같으며, 출도 폴더 안이고 짝이
    # 출도 폴더 밖이거나, 같은 폴더·같은 이름에 확장자만 다른 PDF(CAD 짝)일 때만. Rev가 다른 둘·출도 폴더 밖 같은 Rev 두 벌은 그대로
    from watcher.issued import in_issued_folder as _in_iss
    from watcher.consistency import _rev_norm as _rvn

    def _rk(rv) -> str:
        # 영숫자가 없는 Rev('-'·'—'·'.')는 못 읽은 것 — '-'끼리 같은 판으로 접지 않는다 (rvall 재검토 K4)
        r_ = _rvn(rv) if rv != "—" else ""
        return r_ if re.search(r"[0-9A-Za-z가-힣]", r_) else ""

    def _twins(v) -> set:
        # 묶음마다 한 번 색인해 선형으로 — 같은 도면번호·Rev 3,000장 묶음에서 쌍마다 비교해 35초가 걸렸다 (rvall 재검토 K3)
        rows_ = []
        outside: dict = {}               # Rev → 출도 폴더 밖 파일 수
        cad_keys: dict = {}              # Rev → {(폴더, 이름 줄기)} (DXF·DWG)
        for p_, rv in v:
            r0 = _rk(rv)
            if not r0:
                continue
            pp_, iss_ = PurePosixPath(p_), bool(_in_iss(p_, cfg))
            rows_.append((p_, pp_, r0, iss_))
            if not iss_:
                outside[r0] = outside.get(r0, 0) + 1
            if pp_.suffix.lower() in (".dxf", ".dwg"):
                cad_keys.setdefault(r0, set()).add((str(pp_.parent), _nfc(pp_.stem).casefold()))
        out_ = set()
        for p_, pp_, r0, iss_ in rows_:
            if (iss_ and outside.get(r0, 0) > 0) or (
                    pp_.suffix.lower() == ".pdf" and (str(pp_.parent), _nfc(pp_.stem).casefold()) in cad_keys.get(r0, ())):
                out_.add(p_)
        return out_
    dup, n_twin = [], 0
    for (pj, no), v in sorted(by_no.items()):
        tw_ = _twins(v) if len(v) > 1 else set()
        n_twin += len(tw_)
        v = sorted((PurePosixPath(p_).name, rv) for p_, rv in v if p_ not in tw_)
        if len(v) > 1:
            dup.append(f'[{esc(pj)}] 도면번호 <b>{esc(no)}</b> — ' + ", ".join(f"{esc(n)} (Rev {esc(rv)})" for n, rv in v[:6])
                       + (f" 외 {len(v) - 6}" if len(v) > 6 else ""))

    def iss_rows(code: str) -> list:
        out = []
        for i in issues or []:
            if i.code != code:
                continue
            pj_ = proj.get(i.path) or (proj_of.get(i.path) or ("미분류",))[0] or "미분류"
            if not _in(pj_):
                continue
            ev = "; ".join(str(e) for e in (i.evidence or ())[:2])
            out.append(f'[{esc(pj_)}] '
                       f'<code>{esc(PurePosixPath(i.path).name)}</code> — {esc(i.message)}'
                       + (f'<div style="color:#57606a">근거: {esc(ev)}</div>' if ev else ""))
        return out
    # BOM 없는 프로젝트 — 도면은 있는데 BOM 종류 파일이 하나도 없다 (사실만)
    kinds_of: dict = defaultdict(set)
    for p_ in paths:
        kinds_of[proj[p_]].add(_can(kind_of(p_, cfg) or ""))
    no_bom = [f'[{esc(pj)}] 도면 {sum(1 for p_ in paths if proj[p_] == pj and _can(kind_of(p_, cfg) or "") == "도면")}개, BOM 파일 없음'
              for pj in projs if "도면" in kinds_of[pj] and "BOM" not in kinds_of[pj]]
    # 읽지 못한 파일 — 열지 못함(잠김·권한) + 내용을 못 읽음(암호·손상·변환 프로그램 없음)
    _h, errs = split_hold_notes(rd.scan_errors or [])
    def _unread_in(p_) -> bool:            # 프로젝트를 알 수 없는 것(폴더·잠긴 파일)은 모든 판에 — 매일 브리핑과 같게
        pj_ = proj.get(str(p_)) or (proj_of.get(str(p_)) or (None,))[0]
        return pj_ is None or _in(pj_)
    unread = [f'<code>{esc(str(p_))}</code> — {esc(str(e_))}' for p_, e_ in errs if _unread_in(p_)] + \
             [f'<code>{esc(str(p_))}</code> — {esc(str(e_))}' for p_, e_ in sorted((rd.extract_failures or {}).items())
              if _unread_in(p_)]
    # 1년 넘게 조용한 프로젝트 — 파일 저장 시각이 모두 365일보다 오래
    now_ts = time.time()
    last_mt: dict = {}
    for r in rd.records or []:
        pj = proj.get(r.path)
        if pj in projs and r.mtime:
            last_mt[pj] = max(last_mt.get(pj, 0), float(r.mtime))
    quiet = [f'[{esc(pj)}] 마지막 저장 {datetime.fromtimestamp(t).strftime("%Y-%m-%d")}'
             for pj, t in sorted(last_mt.items()) if now_ts - t > 365 * 86400]
    sec("같은 도면번호 여러 판", dup, "표제란 도면번호가 같은 파일 — 구판이 함께 있는지 확인")
    if n_twin:          # 사실만 센다 — '살펴볼 것'에 넣지 않는다 (rvall B1)
        secs.append(f'<li style="margin:6px 0;color:#57606a">출도본·PDF 사본 {n_twin}장 — 원본과 도면번호·Rev가 같아 '
                    f'\'여러 판\'에서 뺐습니다</li>')
    sec("표제란 Rev ≠ 개정표", iss_rows("REV_BLOCK_MISMATCH"))
    sec("도면-BOM 불일치", iss_rows("BOM_MISMATCH"))
    sec("도면 간 태그 불일치", iss_rows("TAG_MISMATCH_ACROSS_DRAWINGS"))
    sec("BOM 없는 프로젝트", no_bom)
    sec("읽지 못한 파일", unread, "다음 검사에서 다시 시도")
    sec("1년 넘게 조용한 프로젝트", quiet, "보관 폴더로 옮기면 교차 검사·메일에서 빠집니다")
    n_find = sum(1 for x in (dup, iss_rows("REV_BLOCK_MISMATCH"), iss_rows("BOM_MISMATCH"),
                             iss_rows("TAG_MISMATCH_ACROSS_DRAWINGS")) for _ in x)
    title = f"도입 첫날 보고서 — 지금 상태 (프로젝트 {len(projs)} · 문서 {len(paths)})"
    subject = f"[Drev] {run_at.strftime('%Y-%m-%d')} 도입 첫날 — 지금 상태: 프로젝트 {len(projs)} · 문서 {len(paths)}" \
              + (f" · 살펴볼 것 {n_find}건" if n_find else "")
    doc = (f"<!DOCTYPE html><html lang='ko'><head><meta charset='utf-8'><title>{esc(title)}</title></head>"
           f"<body bgcolor='#ffffff' style=\"font-family:'Malgun Gothic',Segoe UI,sans-serif;color:#1f2328;background:#ffffff;"
           f"max-width:860px;margin:0 auto;padding:24px;word-break:keep-all;overflow-wrap:anywhere\">"
           f"<h2 style='margin:0 0 6px'>{esc(title)}</h2>"
           f"<p style='background:#fff8e5;border:1px solid #e3b341;padding:8px 12px;border-radius:6px;margin:0 0 12px'>"
           f"첫 검사(기준선) 결과입니다 — 아래는 <b>변경이 아니라 현재 상태</b>입니다. 맞고 틀림은 판단하지 않고, 서로 어긋난 곳과 "
           f"근거(파일·값)만 적었습니다.</p>"
           f"<p style='margin:0 0 8px'>프로젝트 <b>{len(projs)}</b>곳 · 문서 <b>{len(paths)}</b>개"
           + (f" <span style='color:#57606a;font-size:13px'>({kinds})</span>" if kinds else "") + "</p>"
           f"<ul style='padding-left:20px;margin:0 0 12px'>{''.join(secs)}</ul>"
           f"<h3 style='margin:16px 0 4px'>내일부터는 바뀐 것만 이런 메일로 옵니다</h3>{_FD_SAMPLE}"
           f"<p style='color:#57606a;font-size:12px;margin-top:16px'>{esc(run_at.strftime('%Y-%m-%d %H:%M'))} 기준 · Drev — 읽기 전용 감시</p>"
           f"</body></html>")
    _name = f"brief_{run_at.strftime('%Y%m%d')}_도입첫날.html"
    if name_suffix:                                     # 받는 사람별 판 — '_도입첫날_메일2.html'
        _name = _name[:-len(".html")] + name_suffix + ".html"
    path = _unique_brief(brief_dir / _name, run_at)
    path.write_text(doc, encoding="utf-8")
    if only is None:
        try:
            state.set_meta(FIRST_DAY_KEY, path.name)
        except Exception:
            pass
    print(f"도입 첫날 보고서 저장: {path}" + (f" (받는 사람별 판 — 프로젝트 {len(projs)}곳)" if only is not None else ""))
    return path, subject, doc


def _deliver_first_day(cfg: dict, state: "State", rd, proj_of: dict, issues: list, run_at, brief_dir: Path, full) -> None:
    """도입 첫날 보고서 메일 — 하루 한 통 묶음과 **같은 받는 사람 규칙**(프로젝트별 받는 사람이 있으면 그 사람, 없으면 전체 + 늘 받는
    사람). 받는 사람마다 자기가 받는 프로젝트 절만 실린 판을 보낸다 — 전체 판을 전체 수신자에게 보내 프로젝트 전용 담당의 상태가
    다른 사람에게 가고 그 담당은 못 받았다 (재검토 rr066 mail 1). 구매 담당은 대상이 아니다 — 구매는 BOM·발주서 행이 바뀌었거나
    도면-BOM 불일치가 **생긴 날**의 통만 받는 규칙이고, 첫날은 변경이 아니라 현재 상태라서다."""
    paths = [r.path for r in (rd.records or [])]
    projs = sorted(pj for pj in {(proj_of.get(p) or (None,))[0] or "미분류" for p in paths}
                   if not _QUIET_PROJECT.search(pj))        # 보관·공용 폴더는 매일 메일도 없다
    groups: dict = {}
    for pj in projs:
        groups.setdefault(tuple(_recipients_for(cfg, pj)), []).append(pj)
    if len(groups) <= 1:
        to = list(next(iter(groups))) if groups else _recipients_for(cfg)
        _deliver(cfg, {**cfg["mail"], "recipients": to}, full[1], full[2], full[0])
        return
    for k, (to, pjs) in enumerate(groups.items(), 1):
        p_, subj, doc = write_first_day_report(cfg, state, rd, proj_of, issues, run_at, brief_dir,
                                               only=set(pjs), name_suffix=f"_메일{k}")
        _deliver(cfg, {**cfg["mail"], "recipients": list(to)}, subj, doc, p_)


FIRST_DAY_KEY = "first_day_report"
WEEKLY_NOACK_KEY = "weekly_noack_week"     # '확인 기록 없음'을 실은 마지막 주(월요일) — 연속된 주에는 한 번만 (M5)


def _resend_unsent(state: "State", cfg: dict) -> None:
    """지난 검사에서 못 보낸 통(.eml 초안)을 다시 보낸다 — 실패한 날의 Rev 변경 통이 영영 안 갔다 (검토67 D4).
    서버가 받지 않은 주소(오타)의 통은 주소를 고치기 전엔 같은 결과라 다시 보내지 않고 목록에만 남긴다."""
    import json as _json
    mc = cfg.get("mail") or {}
    if not mc.get("enabled") or not mc.get("smtp_host"):
        return
    try:
        pend = _json.loads(state.get_meta(MAIL_UNSENT_KEY) or "[]")
    except (ValueError, TypeError):
        return
    if not pend:
        return
    from watcher.mail import resend_eml
    left = []
    stop = False
    for u in pend:
        if not isinstance(u, dict):
            continue
        p_ = Path(str(u.get("eml") or ""))
        if stop or u.get("refused") or not p_.is_file():
            if p_.is_file():
                left.append(u)          # 초안이 없으면 다시 보낼 수 없다 — 목록에서 뺀다(배너는 그날 남았다)
            continue
        try:
            if resend_eml(mc, p_):
                print(f"  지난번에 못 보낸 메일을 보냈습니다: {u.get('subject') or p_.name}")
                _MAIL_STATE["sent"] += 1
                continue
            left.append(u)
        except Exception as e:
            print(f"  지난번에 못 보낸 메일을 다시 보내지 못했습니다 — {e} ({p_.name})", file=sys.stderr)
            left.append(u)
            stop = True                 # 서버가 아직 안 된다 — 나머지는 다음에
    state.set_meta(MAIL_UNSENT_KEY, _json.dumps(left, ensure_ascii=False) if left else None)


def _note_mail_trouble(state: "State") -> None:
    """검사 끝에 발송 상태를 DB에 남긴다 — 다음 날 아침 화면 배너가 읽는다."""
    import json as _json
    if _MAIL_STATE["draft_fail"]:
        state.set_meta(DRAFT_TROUBLE_KEY, _json.dumps({
            "at": datetime.now(timezone.utc).isoformat(),
            "why": _MAIL_STATE["draft_fail"][:300]}, ensure_ascii=False))
    elif _MAIL_STATE["drafted"]:
        state.set_meta(DRAFT_TROUBLE_KEY, None)
    # 못 보낸 통 목록 — 지난번 것 중 아직 못 보낸 것 + 이번 것. 실패한 날 통이 다음 날 한 통만 성공해도 기록이 지워져 영영 안 갔다 (검토67 D4)
    try:
        _prev = _json.loads(state.get_meta(MAIL_UNSENT_KEY) or "[]")
    except (ValueError, TypeError):
        _prev = []
    _keep = [u for u in _prev if isinstance(u, dict) and not u.get("sent")] + list(_MAIL_STATE["unsent"])
    _seen_e: set = set()
    _keep = [u for u in _keep if not (u.get("eml") in _seen_e or _seen_e.add(u.get("eml")))][-60:]
    state.set_meta(MAIL_UNSENT_KEY, _json.dumps(_keep, ensure_ascii=False) if _keep else None)
    if _MAIL_STATE["down"] or _MAIL_STATE["refused"]:
        n = (1 + _MAIL_STATE["skipped"]) if _MAIL_STATE["down"] else 0
        why = _MAIL_STATE["down"] or ""
        if _MAIL_STATE["refused"]:
            why = (why + " · " if why else "") + "서버가 받지 않음: " + " / ".join(_MAIL_STATE["refused"])
        state.set_meta(MAIL_TROUBLE_KEY, _json.dumps({
            "at": datetime.now(timezone.utc).isoformat(), "why": why[:600],
            "count": n + len(_MAIL_STATE["refused"]), "unsent": len(_keep)}, ensure_ascii=False))
        if _MAIL_STATE["skipped"]:
            print(f"  메일 자동 발송: 첫 실패 뒤 {_MAIL_STATE['skipped']}통은 시도하지 않았습니다 "
                  f"— .eml 초안은 모두 저장됨 (다음 검사 때 다시 보냅니다)", file=sys.stderr)
    elif _MAIL_STATE["sent"] and not _keep:
        state.set_meta(MAIL_TROUBLE_KEY, None)


def _local_hm(iso) -> str:
    """저장된 UTC 시각 → 이 PC 시각 'YYYY-MM-DD HH:MM' — history가 UTC를 그대로 보여 13:09 검사가 04:09로 나왔다 (검토67 A4)."""
    s_ = str(iso or "")
    try:
        if s_.endswith("Z"):
            s_ = s_[:-1] + "+00:00"
        elif "+" not in s_[10:]:
            s_ = s_ + "+00:00"
        return datetime.fromisoformat(s_).astimezone().strftime("%Y-%m-%d %H:%M")
    except ValueError:
        return str(iso or "")[:16]


def run_at_local_date() -> str:
    return run_at_local_date_obj().isoformat()


def run_at_local_date_obj():
    return datetime.now().astimezone().date()


def _local_date_of(iso: str):
    """저장된 UTC ISO → 이 PC 지역 날짜 (주간 집계용)."""
    if not ("+" in iso[10:] or iso.endswith("Z")):
        iso = iso + "+00:00"
    return datetime.fromisoformat(iso).astimezone().date()


def _backlog_of(entry, run_at) -> tuple | None:
    """(열린 수, 가장 오래된 검출일) → 브리핑 한 줄 재료 (열린 수, 며칠째). 없으면 None."""
    if not entry or not entry[0]:
        return None
    n, oldest = entry
    return n, max(0, (run_at.date() - oldest).days) if oldest else 0


def _weekly_issue_counts(state: State, start, end) -> tuple[Counter, Counter]:
    """지난주 '검토 필요' — (신규, 열림). 신규는 그 주에 검출된 것 중 **자동 해소된 옛 이슈의 재탄생 짝**
    (같은 issue_key가 같은 날 '자동 해소'로 닫힘)을 뺀다 — 변경 0인 프로젝트에 '검토 필요 1'이 찍혔다
    (검토32 A 2, 09-14 사고의 흔적). 열림은 지금 열려 있는 누적."""
    new: Counter = Counter()
    open_: Counter = Counter()
    rows = state.conn.execute(
        "SELECT project, detected_at, code, path, message, resolved_at, resolved_by FROM issues").fetchall()
    def _k(code, path, msg):
        # 옛 판(≤0.57.2)의 문구 '… 외 3장'은 키에 남는다 — 09-14 재탄생 짝이 그 꼴이라 장수 꼬리를 걷고 견준다
        return state.issue_key(code, path, re.sub(r"\s*외\s*\d+\s*장", "", str(msg or "")))
    auto_closed = set()
    for proj, det, code, path, msg, rat, rby in rows:
        if rat and str(rby or "").startswith("자동 해소"):
            auto_closed.add((_k(code, path, msg), _local_date_of(rat)))
    for proj, det, code, path, msg, rat, rby in rows:
        p = proj or "미분류"
        if rat is None:
            open_[p] += 1
        d = _local_date_of(det)
        if start <= d <= end and (_k(code, path, msg), d) not in auto_closed:
            new[p] += 1
    return new, open_


def _weekly_lead(state: State, start, end, tot, unack_all: int, ack_on: bool = True, noack_repeat: bool = False,
                 only: set | None = None) -> str:
    """주간 요약 맨 위의 한두 문장 — 표 7열과 각주만 있어 도면을 못 읽는 사람이 그 주의 규모·위험·사용을 알
    수 없었다 (검토39 P6 중간 1·P2 중간 4). 숫자는 표와 같은 것을 문장으로만 옮긴다.
    only: 받는 사람별 판의 프로젝트들 — 그 범위만 센다 (ux20 mail 3)."""
    def _in(pj) -> bool:
        return only is None or (pj or "미분류") in only
    try:
        n_chg = sum(int(tot.get(k, 0)) for k in ("added", "modified", "removed"))
        # 표와 같은 집합(보관·공용 폴더 제외)으로 — 첫 문장 6건, 표 합계 5건이었다 (검토58 F4-4)
        _open_rows = [d for d in state.issues() if _in(d.get("project"))]
        n_new, n_open = int(tot.get("iss", 0)), int(tot["iss_open"]) if "iss_open" in tot else len(_open_rows)
        oldest = None
        for d in _open_rows:
            day = _local_date_of(d["detected_at"])
            oldest = day if oldest is None or day < oldest else oldest
        acks_week = sum(1 for (at, pj) in state.conn.execute(
                            "SELECT a.at, c.project FROM acks a LEFT JOIN changes c ON c.id = a.change_id")
                        if at and start <= _local_date_of(at) <= end and _in(pj))
    except Exception:
        return ""
    # 사장이 보는 첫 줄 — '변경 30·미확인 37'만으로는 돈이 걸린 불일치(도면-BOM·도면 간)를 몇 건 잡아 몇 건 처리했는지 알 수
    # 없었다 (검토49 C 중간 10). 검토 필요 41건 중 29건이 'Rev 미갱신'이라 합계로는 묻혔다
    s0 = ""
    try:
        _mis = ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS")
        _rows = [r[:4] for r in state.conn.execute(
            "SELECT code, detected_at, resolved_at, resolved_by, project FROM issues WHERE code IN (?, ?)", _mis).fetchall()
                 if _in(r[4])]
        _new = Counter(c for c, d, _r, _b in _rows if start <= _local_date_of(d) <= end)
        _wk = [b for _c, _d, r, b in _rows if r and start <= _local_date_of(r) <= end]
        # 파일이 바뀌어 저절로 닫힌 것과 사람이 [처리함]을 누른 것을 나눈다 — 전부 자동 해소인데 '처리됨'이라 하고 같은 문단에
        # '확인 기록이 한 건도 없습니다'가 붙어 사장에게 모순으로 읽혔다 (검토50 B 중간 7)
        _auto = sum(1 for b in _wk if str(b or "").startswith("자동 해소"))
        _man = len(_wk) - _auto
        _left = sum(1 for _c, _d, r, _b in _rows if not r)
        if _new or _wk or _left:
            _res = " · ".join(x for x in ((f"파일이 고쳐져 해소 {_auto}건" if _auto else ""),
                                          (f"담당자가 처리 {_man}건" if _man else "")) if x) or "해소 0건"
            s0 = (f"도면-BOM·도면 간 불일치: 지난주 새로 잡음 {sum(_new.values())}건"
                  f"(도면-BOM {_new.get('BOM_MISMATCH', 0)} · 도면 간 {_new.get('TAG_MISMATCH_ACROSS_DRAWINGS', 0)}), "
                  f"{_res}, 지금 남음 {_left}건.")
    except Exception:
        s0 = ""
    s1 = f"지난주 변경 {n_chg}건, 새 검토 필요 {n_new}건."
    # 돈·출도가 걸린 표지 수 — 주간만 받는 사람(전무)이 발주 뒤 바뀐 것을 몰랐다 (ux21 mail 4). 0이면 싣지 않는다
    try:
        _po, _post = _weekly_po_post(state, start, end, _in)
        _pp = " · ".join(x for x in ((f"발주 후 변경 {_po}건" if _po else ""), (f"출도 후 변경 {_post}건" if _post else "")) if x)
        if _pp:
            s1 += f" 그중 {_pp}."
    except Exception:       # noqa: BLE001 — 세지 못해도 요약은 그대로
        pass
    # 한 주 내내 꺼져 있었으면 '변경 0건'은 거짓 평온이다 — 열린 이슈가 있으면 표가 0으로 채워져 '검사 없음' 안내도 안
    # 나갔다 (검토60 ⑥)
    try:
        _no_run = not _ran_days(state, start, end)
    except Exception:
        _no_run = False
    if _no_run:
        s1 = ("지난주에는 검사가 한 번도 돌지 않았습니다 — PC가 꺼져 있었거나 매일 자동 실행이 "
              "멈췄을 수 있습니다. 그동안의 변경은 다음 검사가 한꺼번에 잡습니다(아래 표의 0은 '변경 없음'이 아닙니다).")
    if n_open:
        age = (end - oldest).days + 1 if oldest else 0
        s1 += f" 아직 처리되지 않은 검토 필요 {n_open}건" + (f"(가장 오래된 것 {age}일째)" if age >= 7 else "") + "."
    if n_chg and not acks_week and ack_on and not noack_repeat:
        # 팀을 지적하지 않는다 — 확인 기록은 선택 기능이다. 2주 연속이면 한 번만 (기능 검토 2026-11-02 M5)
        s2 = f" 확인 기록 없음(선택 기능 — 설정에서 끌 수 있음) · 미확인 {unack_all}건."
        color = "#1f2328"
    elif n_chg and not acks_week and ack_on:
        s2, color = "", "#1f2328"
    elif n_open and oldest and (end - oldest).days + 1 >= 14:
        s2 = " 2주 넘게 열린 검토 필요가 있습니다 — 담당자 확인이 필요합니다."
        color = "#9a6700"
    else:
        s2, color = "", "#1f2328"
    lead0 = (f"<p style='font-size:15px;color:#1f2328;margin:0 0 6px'><b>{html_escape(s0)}</b></p>" if s0 else "")
    if _no_run:
        color = "#cf222e"
    return lead0 + f"<p style='font-size:15px;color:{color};margin:0 0 10px'><b>{html_escape(s1 + s2)}</b></p>"


def _weekly_po_post(state: State, start, end, in_scope) -> tuple[int, int]:
    """그 주의 (발주 후 변경 표지가 붙은 변경 수, 새로 잡힌 출도 후 변경 검토 필요 수). in_scope(프로젝트) → bool."""
    import json
    from watcher.issued import PO_MARK_KEY, POST_ISSUE_CODE
    po = 0
    for at, pj, js in state.conn.execute(
            "SELECT c.detected_at, c.project, d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
            "WHERE d.items_json LIKE ?", (f"%{PO_MARK_KEY}%",)):
        if not at or not (start <= _local_date_of(at) <= end) or not in_scope(pj):
            continue
        try:
            its = json.loads(js or "[]")
        except (ValueError, TypeError):
            continue
        if any(isinstance(i, dict) and i.get("kind") == "CHECK_SKIPPED" and i.get("key") == PO_MARK_KEY for i in its):
            po += 1
    post = sum(1 for at, pj in state.conn.execute("SELECT detected_at, project FROM issues WHERE code = ?", (POST_ISSUE_CODE,))
               if at and start <= _local_date_of(at) <= end and in_scope(pj))
    return po, post


def _ran_days(state: State, start, end) -> int:
    """그 주에 검사가 돈 날 수 (검토38 R7 3)."""
    days = {_local_date_of(r) for (r,) in state.conn.execute("SELECT run_at FROM snapshots") if r}
    return sum(1 for i in range((end - start).days + 1) if start + timedelta(days=i) in days)


def _scan_days_line(state: State, start, end) -> str:
    """지난주 검사가 돈 날 수 — 09-16 PC 꺼짐으로 검사가 없던 날이 주간 통 어디에도 없었다 (검토32 A 3)."""
    days = {_local_date_of(r) for (r,) in state.conn.execute("SELECT run_at FROM snapshots") if r}
    wk = [start + timedelta(days=i) for i in range((end - start).days + 1)]
    ran = [d for d in wk if d in days]
    missing = [d for d in wk if d not in days]
    line = f"검사 {len(ran)}/{len(wk)}일"
    if missing:
        line += " (없는 날: " + ", ".join(d.strftime("%m-%d") for d in missing) + ")"
    return line


def _fold_for_count(items: list, notes: dict, exempt=()) -> tuple[list, set]:
    """일일 브리핑과 같은 규칙으로 센다 — 폴더 이동(삭제+추가)은 한 건, 재저장·복사본·일자만 갱신은
    '그 밖의 알림'이라 수정·미확인에 넣지 않는다. 그대로 세니 사장이 보는 표가 "P26-040 수정 120 /
    미확인 121"(실제 변경 1건 + 재출력 119장)이 됐다 (검토21 브리핑 차단 2·파일럿 차단 2).
    exempt: State.ack_exempt_map의 판정 — 화면·입구가 '기록만'으로 거절하는 행은 여기서도 미확인이 아니다 (ux25 F1).
    돌려주는 값: (이동 짝을 뺀 변경들, 그중 '그 밖의 알림' change_id)"""
    from watcher.brief import _MOVE_MARK, is_quiet as _is_quiet
    removed_by_path = {d["path"]: d for d in items if d["kind"] == "removed"}
    hide: set = set()
    for d in items:
        n = notes.get(d["change_id"], "") or ""
        if d["kind"] == "added" and _MOVE_MARK in n:
            prev = n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
            x = removed_by_path.get(prev)
            if x is not None:
                hide.add(x["change_id"])
        if d["kind"] == "removed" and "옮겨지며 내용도 바뀜" in n:
            hide.add(d["change_id"])
    kept = [d for d in items if d["change_id"] not in hide]
    # 옮겨지며 내용도 바뀐 파일(추가 쪽, '그 판과 비교')은 수정으로 센다 — 재편한 날 편집이 '추가'로 집계됐다 (검토60 ⑥)
    kept = [(dict(d, kind="modified") if d["kind"] == "added" and "그 판과 비교" in (notes.get(d["change_id"]) or "") else d)
            for d in kept]
    quiet_ids = {d["change_id"] for d in kept
                 if d["change_id"] in exempt
                 or (d["kind"] == "added" and _MOVE_MARK in (notes.get(d["change_id"]) or ""))
                 or _is_quiet(notes.get(d["change_id"], "") or "")}
    return kept, quiet_ids


def _last_review_line(state: State) -> str:
    """마지막 사람 확인 — 아무도 확인하지 않는 집을 주간 통에서 드러낸다 (검토36 B 4)."""
    try:
        lr = state.last_review()
    except Exception:
        return ""
    if not lr:
        return "사람이 남긴 확인 기록이 아직 없습니다"
    try:
        at = datetime.fromisoformat(lr["at"] if ("+" in lr["at"][10:] or lr["at"].endswith("Z"))
                                    else lr["at"] + "+00:00").astimezone()
        when = at.strftime("%m-%d %H:%M")
    except (TypeError, ValueError):
        when = str(lr["at"])[:16]
    by = f" · {lr['by']}" if lr.get("by") else ""
    return f"마지막 사람 확인 {when} ({lr['what']}{by})"


def write_weekly_summary(state: State, cfg: dict, brief_dir: Path,
                         run_at: datetime) -> Path | None:
    """이번 주 첫 검사 때 지난주(월~일) 프로젝트별 요약 브리핑 생성 (2026-08-26).
    파일명은 이번 주 월요일 날짜로 고정 — 월요일에 PC가 꺼져 있었어도
    화요일 검사가 대신 만든다 (요일 조건이었다가 공휴일에 영구 생략되던 문제 수정).
    이미 이번 주 것이 있으면 생략. 돌려주는 값: 만든 파일 경로 또는 None."""
    if not cfg.get("weekly_summary", True):
        return None
    monday = (run_at - timedelta(days=run_at.weekday())).date()
    out = brief_dir / f"brief_weekly_{monday.strftime('%Y%m%d')}.html"
    if out.exists():
        return None
    start = monday - timedelta(days=7)
    end = monday - timedelta(days=1)
    # 설치 전 주를 "지난주 변경이 없습니다 — 감시는 정상 동작했습니다"라 보고하던 것
    # (2026-09-05 재검토) — 첫 검사가 그 주 뒤면 만들지 않는다
    first_at = state.conn.execute("SELECT MIN(run_at) FROM snapshots").fetchone()[0]
    if first_at and _local_date_of(first_at) > end:
        return None

    by_change: dict[int, dict] = {}
    for r in state.history():  # (변경×확인) 조인 → 변경 단위로 접기
        d = by_change.setdefault(r["change_id"], dict(r, acked=False))
        if r["ack_by"]:
            d["acked"] = True
    first = state.first_snapshot_by_root()   # 첫 등록은 변경이 아니다 (화면과 같은 규칙)
    ext_base = state.ext_baseline()
    real = [d for d in by_change.values()
            if not State.is_first_registration(d["kind"], d["path"], d.get("snapshot_id"),
                                               first, ext_base)]
    # 판정·문구는 화면과 같은 ack_marks로 — 최근 500건만 드는 side_notes로 세면 창 밖의 재저장이 미확인으로 되살아났다 (ux25 F1)
    exempt, notes = state.ack_marks([d["change_id"] for d in real])
    week, quiet_ids = _fold_for_count(
        [d for d in real if start <= _local_date_of(d["detected_at"]) <= end], notes, exempt)
    # 쌓인 미확인 누적 — 주간 표의 '미확인'은 그 주에 생긴 것뿐이라, 몇 주째 아무도 확인하지 않아도
    # 주간 통이 매주 작은 수만 보였다 (검토36 B 4). 같은 규칙으로 전체를 센다
    all_kept, all_quiet = _fold_for_count(real, notes, exempt)
    lr_line = _last_review_line(state)
    # 확인 기록을 끈 집은 미확인 열·누적·'확인 기록 없음'을 싣지 않는다 — '검토 필요 열림'만 (기능 검토 2026-11-02 M5)
    ack_on = ack_tracking_on(cfg)
    # '확인 기록 없음'은 연속된 주에 한 번만 — 매주 같은 꾸지람이 쌓였다 (M5). 지난주에 이미 실었으면 이번 주는 뺀다
    noack_repeat = False
    try:
        _acks_wk = sum(1 for (at,) in state.conn.execute("SELECT at FROM acks") if at and start <= _local_date_of(at) <= end)
        _prev_mon = (monday - timedelta(days=7)).isoformat()
        _streak = state.get_meta(WEEKLY_NOACK_KEY)
        if _acks_wk:
            state.set_meta(WEEKLY_NOACK_KEY, None)
        else:
            noack_repeat = _streak in (_prev_mon, monday.isoformat())
            state.set_meta(WEEKLY_NOACK_KEY, monday.isoformat())
    except Exception:
        noack_repeat = False
    iss_week, iss_open = _weekly_issue_counts(state, start, end)
    title = f"주간 요약 {start.strftime('%m/%d')}~{end.strftime('%m/%d')}"
    doc, tot = _weekly_doc(state, cfg, start, end, title, week, quiet_ids, all_kept, all_quiet, iss_week, iss_open,
                           lr_line, ack_on, noack_repeat)
    out.write_text(doc, encoding="utf-8")
    # 그 주에 돈 검사가 **기준선(첫 등록)뿐**이고 변경이 없으면 메일은 내지 않는다 — 설치한 주 금요일 기준선 뒤 월요일에 '검사 1/7일
    # · 변경 0' 주간 메일이 나가, 받는 사람이 무엇을 보라는 것인지 몰랐다 (구매 평가 2차 P2 day1). 요약 파일은 화면용으로 남긴다
    try:
        _firsts = {state.first_snapshot_id()} | set((state.first_snapshot_by_root() or {}).values())
        _wk_snaps = [sid for sid, r in state.conn.execute("SELECT id, run_at FROM snapshots").fetchall()
                     if r and start <= _local_date_of(r) <= end]
        if _wk_snaps and all(s in _firsts for s in _wk_snaps) and not week:
            print(f"주간 요약 {title}: 그 주는 기준선 등록뿐이라 메일은 만들지 않습니다 (요약 파일만)")
            return out
    except Exception:       # noqa: BLE001  — 판정 실패면 전처럼 낸다
        pass
    # 받는 사람별 판 — 도입 첫날 보고서(rr066 mail 1)와 같은 방식: 프로젝트 담당은 자기 프로젝트 줄만 받는다. 한 통 9곳 전부가
    # PM·다른 팀 설계자에게도 갔다 (ux20 mail 3). 구매 담당·늘 받는 사람·전체 수신자는 전체 판
    groups = _weekly_groups(cfg, state)
    if len(groups) <= 1:
        _to = list(next(iter(groups))) if groups else _recipients_all(cfg)
        _send_weekly(state, cfg, _to, _weekly_subject(title, tot), doc, out)
        return out
    for k, (to, pjs) in enumerate(groups.items(), 1):
        if pjs is None:
            d_, t_, p_ = doc, tot, out
        else:
            d_, t_ = _weekly_doc(state, cfg, start, end, title, week, quiet_ids, all_kept, all_quiet, iss_week, iss_open,
                                 lr_line, ack_on, noack_repeat, only=set(pjs))
            p_ = out.with_name(f"{out.stem}_메일{k}.html")
            try:
                p_.write_text(d_, encoding="utf-8")
            except OSError as e_:
                print(f"경고: 주간 요약 받는 사람별 판을 저장하지 못했습니다({e_})", file=sys.stderr)
                continue
        _send_weekly(state, cfg, list(to), _weekly_subject(title, t_), d_, p_)
    return out


def _weekly_subject(title: str, tot) -> str:
    """'[Drev] 주간 요약 10/26~11/01 · 변경 16 · 검토 필요 7' — 제목에 수가 없어 열어 봐야 알았다 (ux20 mail 10)."""
    n_chg = sum(int(tot.get(k, 0)) for k in ("added", "modified", "removed"))
    n_iss = int(tot.get("iss", 0))
    return f"[Drev] {title} · 변경 {n_chg}" + (f" · 검토 필요 {n_iss}" if n_iss else "")


def _weekly_groups(cfg: dict, state: State) -> dict:
    """{(받는 사람…): 프로젝트 목록 | None(전체 판)} — 주간 요약을 받는 사람별 판으로 나눌 묶음.
    전체 수신자·늘 받는 사람·구매 담당은 전체 판(None). 프로젝트별 수신자는 자기 프로젝트만."""
    mail = cfg.get("mail") or {}
    everyone = set(a for a in (mail.get("recipients") or []) if a) | set(a for a in (mail.get("always_recipients") or []) if a) \
        | set(a for a in (mail.get("purchase_recipients") or []) if a)
    if not any((pc or {}).get("recipients") for pc in (cfg.get("projects") or {}).values()):
        return {tuple(_recipients_all(cfg)): None} if _recipients_all(cfg) else {}
    # 기록에 있는 프로젝트마다 매일 통과 같은 규칙(_project_cfg — 대소문자·별칭 키도)으로 그 담당을 찾는다
    try:
        known = ({r[0] for r in state.conn.execute("SELECT DISTINCT IFNULL(project, '미분류') FROM changes")}
                 | {r[0] for r in state.conn.execute("SELECT DISTINCT IFNULL(project, '미분류') FROM issues")})
    except Exception:       # noqa: BLE001
        known = set()
    mine: dict = {}
    for pj in sorted(known):
        for a in _project_cfg(cfg, pj).get("recipients") or []:
            if a and a not in everyone:
                mine.setdefault(a, set()).add(pj)
    by_set: dict = {}
    for a in _recipients_all(cfg):
        if a in mine:
            key = frozenset(mine[a])
        else:
            key = None
        by_set.setdefault(key, []).append(a)
    return {tuple(v): (None if k is None else sorted(k)) for k, v in by_set.items()}


def _send_weekly(state: State, cfg: dict, to: list, subject: str, doc: str, out: Path) -> None:
    mc = {**(cfg.get("mail") or {}), "recipients": to}
    if mc.get("draft", True):
        try:
            from watcher.mail import write_eml
            write_eml(mc, subject, doc, out.with_suffix(".eml"))
        except Exception as e:
            print(f"경고: 주간 요약 메일 초안 생성 실패(요약 HTML은 정상): {e}",
                  file=sys.stderr)
    # 자동 발송을 켠 집에서도 주간 요약만 초안으로 남아 아무도 못 봤다 — 변경이 없는 주에
    # 받는 쪽이 '감시가 살아 있다'를 확인할 수 있는 유일한 통이다 (2026-09-09 브리핑 검토 1)
    if mc.get("enabled"):
        try:
            if send_brief(mc, subject, doc):
                print(f"주간 요약 메일 발송: {', '.join(mc.get('recipients') or [])}")
        except Exception as e:
            print(f"경고: 주간 요약 메일 발송 실패(요약 HTML·초안은 정상): {e}",
                  file=sys.stderr)
            # 변경 없는 월요일엔 이 통이 유일하다 — 실패가 화면 배너·재발송 목록 어디에도 남지 않았다 (검토67 D6)
            try:
                import json as _json
                state.set_meta(MAIL_TROUBLE_KEY, _json.dumps({
                    "at": datetime.now(timezone.utc).isoformat(), "why": f"주간 요약: {e}"[:600], "count": 1, "unsent": 1},
                    ensure_ascii=False))
                _eml = out.with_suffix(".eml")
                if _eml.is_file():
                    _pend = _json.loads(state.get_meta(MAIL_UNSENT_KEY) or "[]")
                    _pend.append({"subject": subject, "eml": str(_eml)})
                    state.set_meta(MAIL_UNSENT_KEY, _json.dumps(_pend[-60:], ensure_ascii=False))
            except Exception:
                pass


def _weekly_doc(state: State, cfg: dict, start, end, title: str, week: list, quiet_ids: set, all_kept: list, all_quiet: set,
                iss_week, iss_open, lr_line: str, ack_on: bool, noack_repeat: bool, only: set | None = None):
    """주간 요약 HTML 한 벌 → (HTML, 합계). only: 받는 사람별 판의 프로젝트들(그 줄만·그 범위의 수만)."""
    def _in(pj) -> bool:
        return only is None or (pj or "미분류") in only
    week = [d for d in week if _in(d["project"])]
    if only is not None:
        lr_line = ""                 # 마지막 확인 한 줄은 다른 프로젝트의 파일·사람일 수 있다 — 전체 판에만
    # 지난주 끝까지 쌓인 것만 — 오늘 아침 검사분까지 세어 첫 문장 '미확인 10건'이 같은 화면 표 합계 7과 달랐다 (검토41 S6 중간 2)
    unack_all = sum(1 for d in all_kept if d["change_id"] not in all_quiet and not d["acked"]
                    and not _QUIET_PROJECT.search(d["project"] or "") and _in(d["project"])
                    and _local_date_of(d["detected_at"]) <= end)
    projects = sorted({d["project"] or "미분류" for d in week} | set(iss_week) | set(iss_open))
    # 임시·공용·아카이브 폴더는 일일 메일도 만들지 않는다 — 주간 표에서도 뺀다
    projects = [p for p in projects if not _QUIET_PROJECT.search(p or "") and _in(p)]
    trs, tot = [], Counter()
    for p in projects:
        pr = [d for d in week if (d["project"] or "미분류") == p]
        main = [d for d in pr if d["change_id"] not in quiet_ids]
        row = Counter(d["kind"] for d in main)
        n_quiet = len(pr) - len(main)
        unack = sum(1 for d in main if not d["acked"])
        iss = iss_week.get(p, 0)
        iss_o = iss_open.get(p, 0)
        tot.update(row)
        tot["quiet"] += n_quiet
        tot["unack"] += unack
        tot["iss"] += iss
        tot["iss_open"] += iss_o
        trs.append(f"<tr><td style='{_W_TD}'>{html_escape(p)}</td>"
                   f"<td style='{_W_TD}'>{row.get('added', 0)}</td>"
                   f"<td style='{_W_TD}'>{row.get('modified', 0)}</td>"
                   f"<td style='{_W_TD}'>{row.get('removed', 0)}</td>"
                   f"<td style='{_W_TD};color:#57606a'>{n_quiet}</td>"
                   + (f"<td style='{_W_TD};color:#cf222e'>{unack}</td>" if ack_on else "")
                   + f"<td style='{_W_TD};color:#9a6700'>{iss} / {iss_o}</td></tr>")
    body = (f"<table style='border-collapse:collapse;width:100%'>"
            f"<tr><th style='{_W_TH}'>프로젝트</th><th style='{_W_TH}'>추가</th>"
            f"<th style='{_W_TH}'>수정</th><th style='{_W_TH}'>삭제</th>"
            f"<th style='{_W_TH}'>그 밖의 알림</th>"
            + (f"<th style='{_W_TH}'>미확인</th>" if ack_on else "") + f"<th style='{_W_TH}'>검토 필요<br><span style='font-weight:400'>신규 / 열림</span></th></tr>"
            + "".join(trs)
            + f"<tr><td style='{_W_TD};font-weight:700'>합계</td>"
              f"<td style='{_W_TD}'>{tot.get('added', 0)}</td>"
              f"<td style='{_W_TD}'>{tot.get('modified', 0)}</td>"
              f"<td style='{_W_TD}'>{tot.get('removed', 0)}</td>"
              f"<td style='{_W_TD};color:#57606a'>{tot.get('quiet', 0)}</td>"
            + (f"<td style='{_W_TD};color:#cf222e'>{tot.get('unack', 0)}</td>" if ack_on else "")
            + f"<td style='{_W_TD};color:#9a6700'>{tot.get('iss', 0)} / {tot.get('iss_open', 0)}</td></tr>"
            "</table>"
            "<p style='color:#57606a;font-size:12.5px'>'그 밖의 알림'은 폴더 이동·이름 변경, 다시 저장(내용 동일), "
            "복사본, 표제란 일자만 갱신된 재출력 — 변경으로 세지 않고 미확인에도 넣지 않습니다. "
            "'검토 필요'의 신규는 지난주에 새로 검출된 것, 열림은 지금까지 처리되지 않고 남은 누적입니다. "
            + ("표의 '미확인'은 지난주에 생긴 변경 가운데 아직 확인 안 된 것이고, 위 '쌓인 미확인 누적'은 그 전 주들까지 "
               "합친 지금의 수입니다." if ack_on else "") + "</p>") if projects else \
        (("<p style='color:#cf222e'>지난주에는 검사가 한 번도 돌지 않았습니다 — PC가 꺼져 있었거나 매일 자동 "
          "실행이 멈췄을 수 있습니다. 그동안의 변경은 다음 검사가 한꺼번에 잡습니다.</p>")
         if not _ran_days(state, start, end) else
         "<p style='color:#1a7f37'>지난주 변경이 없습니다 — 감시는 정상 동작했습니다.</p>")
    # 사내망 양식함이 켜져 있으면 미확인 변경은 받는 사람이 열 수 있는 곳으로 — '감시 PC 화면에서'는 못 여는 곳이었다 (ux20 mail 3)
    from watcher.brief import LAN_BASE as _lan
    _where = (f"미확인 변경은 <a href='{html_escape(_lan)}/changes?show=unacked' style='color:#0969da'>사내망에서 미확인 변경 보기</a>, "
              if (_lan and ack_on) else ("미확인 변경은 감시 PC 화면에서, " if ack_on else ""))
    _scope = ("" if only is None else
              f"<p style='color:#57606a;font-size:13px'>이 통에는 받는 분이 담당한 프로젝트({html_escape(', '.join(sorted(only)))})만 "
              f"실었습니다 — 다른 프로젝트는 그 담당자에게 따로 갑니다.</p>")
    doc = (f"<!DOCTYPE html><html lang='ko'><head><meta charset='utf-8'>"
           f"<title>{title}</title></head>"
           f"<body style=\"font-family:'Malgun Gothic',Segoe UI,sans-serif;"
           f"max-width:720px;margin:0 auto;padding:24px;color:#1f2328\">"
           f"<h2>산출물 감시 {title}</h2>"
           f"{_weekly_lead(state, start, end, tot, unack_all, ack_on=ack_on, noack_repeat=noack_repeat, only=only)}"
           f"{_scope}"
           f"<p style='color:#57606a'>{_scan_days_line(state, start, end)} · "
           + _where + "상세는 해당 주의 일일 브리핑에서 확인하세요.</p>"
           + (f"<p style='color:{'#cf222e' if unack_all else '#57606a'}'>지난주까지 쌓인 미확인 변경 누적 {unack_all}건"
              f"{html_escape(' · ' + lr_line) if lr_line else ''}</p>" if ack_on else "")
           + f"{body}"
           f"<p style='color:#57606a;font-size:12px;margin-top:20px'>Drev"
           f" — 매주 첫 검사 때 지난주(월~일)를 정리해 자동 생성됩니다. 받는 사람은 감시 PC 설정에서 정합니다 — "
           f"바꾸거나 그만 받으려면 감시 PC 관리자에게 말씀하세요.</p></body></html>")
    return doc, tot


_W_TH = ("border:1px solid #d0d7de;padding:7px 12px;background:#f6f8fa;"
         "text-align:left;font-size:13px")
_W_TD = "border:1px solid #d0d7de;padding:7px 12px;font-size:13.5px"


@dataclass
class RunData:
    """검사 파이프라인 한 회분의 공유 상태 — 단계 함수들이 이 묶음만 주고받는다.
    (파라미터 11개짜리 시그니처와 args 밀수를 없애기 위한 것, 2026-08-26 리팩토링)"""
    cfg: dict
    roots: list
    labels: list
    root_display: str
    prev_files: dict = dc_field(default_factory=dict)
    records: list = dc_field(default_factory=list)
    abs_of: dict = dc_field(default_factory=dict)
    scan_errors: list = dc_field(default_factory=list)
    old_versions: set = dc_field(default_factory=set)   # 짝짓기로 '이전 판'이 된 경로
    newer_of: dict = dc_field(default_factory=dict)     # 이전 판 경로 → 그것을 이전 판으로 삼은 새 판 경로들
    compare_skipped: set = dc_field(default_factory=set)  # 이전 기록이 구버전 형식이라 비교를 생략한 경로
    folder_votes: dict = dc_field(default_factory=dict)  # 폴더 → {프로젝트: 표제란 수} (검토22 D1)
    ocr_boxes: dict = dc_field(default_factory=dict)    # 경로 → {OCR 글자: (pno, x0, y0, x1, y1)} 사진 자리
    snapshot_id: int | None = None
    changes: list = dc_field(default_factory=list)
    docs: dict = dc_field(default_factory=dict)
    extract_failures: dict = dc_field(default_factory=dict)
    details: dict = dc_field(default_factory=dict)
    prev_abs: dict = dc_field(default_factory=dict)   # 판 짝짓기 시 이전 판 파일 경로
    issues: list = dc_field(default_factory=list)
    captures: dict = dc_field(default_factory=dict)
    baseline_visual: set = dc_field(default_factory=set)  # 기준선에서 그림 비교한 파일
    moved: dict = dc_field(default_factory=dict)   # 새 경로 → (이전 경로, 이전 sha, 내용 동일?)
    checked_projects: set = dc_field(default_factory=set)  # 이번 교차 검사가 본 프로젝트
    carry_paths: list = dc_field(default_factory=list)   # 이번 검사에서 이전 상태를 이월한 경로
    is_baseline: bool = False                            # 첫 검사(기준선)였는가
    reg_paths: set = dc_field(default_factory=set)       # 새로 켠 확장자·새로 추가한 폴더의 첫 등록 경로
    reg_exts: set = dc_field(default_factory=set)        # 이번 검사에서 새로 켠 확장자
    reg_roots: set = dc_field(default_factory=set)       # 이번 검사가 첫 검사인 감시 폴더(라벨)
    force_full: bool = False                             # 주 1회 전체 재해싱 (크기·시각 단축 없이)
    missing_labels: list = dc_field(default_factory=list)  # 이번 검사에 접근 못 한 감시 폴더 라벨
    continued: list = dc_field(default_factory=list)       # 열린 경고의 파일이 또 바뀜 (검토43 C 중간 1)
    recurred: dict = dc_field(default_factory=dict)        # 다시 생긴 이슈 → 전에 닫힌 시각 (검토44 C 중간 3)
    still_open: list = dc_field(default_factory=list)      # 오늘 관련 파일이 바뀌었는데 아직 열린 불일치 (구매자 평가 P3)
    went_back: dict = dc_field(default_factory=dict)       # 옛 판으로 되돌아간 표지 {경로: 'sha'|'mtime'} (검토42 D 중간 6)
    rejudged: list = dc_field(default_factory=list)        # 판 올림 뒤 파일 변경 없이 다시 판정한 검토 필요 (J4)


def _scan_roots(rd: RunData, args) -> list:
    """루트별 스캔 → rd.records/abs_of/scan_errors 채움.
    돌려주는 값: 감시 제외로 조용히 이월할 이전 스냅샷 경로들."""
    # 진행률 분모: 직전 스냅샷 파일 수(재검사) — 첫 검사는 미상이라 개수만 표시
    total_est = len(rd.prev_files)
    for r_path, label in zip(rd.roots, rd.labels):
        errs: list[tuple[str, str]] = []
        excludes = _excludes_for(label, rd.labels, rd.cfg["exclude"])
        prev_root = None
        if not (getattr(args, "full", False) or rd.force_full):
            # 크기·수정시각이 같으면 재해싱 생략 (라벨 접두를 벗겨 폴더 몫만)
            pfx = label + "/"
            prev_root = {k[len(pfx):]: v for k, v in rd.prev_files.items()
                         if k.startswith(pfx)}
        _seen = [0]

        def _tick(n: int, _label=label, _base=len(rd.records)) -> None:
            _seen[0] = n
            _set_progress("1/3 파일 확인", _base + n, total_est)
            if n % 500 == 0:
                print(f"  파일 확인 중({_label}): {n}개…", flush=True)

        def _act(text: str, _base=len(rd.records)) -> None:
            # 폴더를 훑는 동안에도 화면과 [검사 중지]가 살아 있게 (2026-09-07 회사 PC:
            # "1/3 파일 확인 12개"에서 한 시간 넘게 멈춘 것처럼 보임)
            _set_progress("1/3 파일 확인", _base + _seen[0], total_est, current=text,
                          keep_since=text.startswith("폴더 "))

        for rec in scan(r_path, rd.cfg["extensions"], errors=errs,
                        excludes=excludes, prev=prev_root, progress=_tick,
                        activity=_act):
            key = f"{label}/{rec.path}"
            rd.records.append(type(rec)(key, rec.sha256, rec.size, rec.mtime))
            rd.abs_of[key] = r_path / PurePosixPath(rec.path)
        rd.scan_errors += [(f"{label}/{p}", e) for p, e in errs]
        # 폴더 단위 오류(권한 없음·순단): 그 아래 이전 기록을 통째로 이월 — 삭제 오보 방지
        # (2026-09-04 검토 core H3). 파일 단위 오류(잠김)는 원래대로 경로만 이월
        for p, _e in errs:
            if p.endswith("/"):
                pfx = f"{label}/{p}" if p != "/" else f"{label}/"
                rd.carry_paths += [k for k in rd.prev_files if k.startswith(pfx)]

    # 감시 제외로 새로 빠진 기존 파일은 '삭제'로 보고하지 않고 조용히 이월한다 —
    # 제외는 "더 이상 안 본다"이지 파일이 사라진 게 아니다 (2026-08-25 리뷰)
    current_paths = {r.path for r in rd.records}
    excluded_carry = []
    for r_path, label in zip(rd.roots, rd.labels):
        excludes = _excludes_for(label, rd.labels, rd.cfg["exclude"])
        if not excludes:
            continue
        pfx = label + "/"
        excluded_carry += [
            k for k in rd.prev_files
            if k.startswith(pfx) and k not in current_paths
            and is_excluded(k[len(pfx):], excludes)]
    # 감시 확장자에서 뺀 형식도 같다 — 확장자를 줄인 다음 날 그 파일들이 전부 '삭제'로 보고되고 메일 초안까지 만들어졌다
    # (검토58 F6 F2). 켤 때 '등록'으로 받는 것과 대칭으로, 끌 때는 조용히 이월
    _exts = {str(e).lower() for e in (rd.cfg.get("extensions") or ())}
    if _exts:
        _seen = set(excluded_carry)
        excluded_carry += [k for k in rd.prev_files
                           if k not in current_paths and k not in _seen
                           and PurePosixPath(k).suffix.lower() not in _exts]
    return excluded_carry


def _visual_sides(state: State, rd: "RunData", path: str, old_sha, new_sha):
    """덮어쓰기 비교의 전/후 그림 공급원. 전: 검사 때 기록한 그림. 후: PDF·DXF는
    파일(선명한 확대 사진), DWG는 기록(파일을 직접 못 그린다)."""
    old_pages = state.load_renders(old_sha)
    if PurePosixPath(path).suffix.lower() == ".dwg":
        return old_pages, state.load_renders(new_sha)
    return old_pages, rd.abs_of.get(path)


def _changed_texts(old_doc, new_doc) -> set:
    """새 판에만 있는 글줄·표제란 값·리비전 설명 — 그 자리의 픽셀 차이는 '그림 변경'이
    아니라 글자 변경이다 (2026-09-03 검토: 표제란 글자가 그림 변경 3곳으로 부풀고
    'Rev만 갱신' 판정이 DXF에서 절대 안 나오던 원인)."""
    if old_doc is None or new_doc is None:
        return set()

    from watcher.capture import RevSymbol
    from watcher.extract.dxf import _LABEL_ALIASES

    def texts(d) -> set:
        s = {" ".join(ln.text.split()) for ln in d.raw_texts}
        s |= {" ".join(str(f.value).split()) for f in d.fields.values()}
        # 표제란 한 칸이 'REV: B' 한 덩이인 도면 — 값 'B'만으로는 그 엔티티(PDF 줄)를 못
        # 찾아 Rev 올림이 '그림 변경'으로 잡히고 'Rev만 갱신' 경고가 사라졌다. 09-03·09-04·
        # 09-06·09-10 네 번째 재발 (검토19 감지 ③). 라벨+값 꼴도 마스크 후보로 넣는다
        for f in d.fields.values():
            v = " ".join(str(f.value).split())
            if not v:
                continue
            for alias, canon in _LABEL_ALIASES.items():
                if canon == f.name:
                    s.add(f"{alias}: {v}")
                    s.add(f"{alias}:{v}")
                    s.add(f"{alias} {v}")
                    s.add(f"{alias}. {v}")
        for r in d.revision_history:
            # 개정 기호('C')도 — 표제란 Rev는 그대로 두고 개정표에만 행을 더한 날 그 칸의 'C'가 덤 '그림 변경'이 됐다 (벤치 dxf68 D07)
            k = " ".join(str(r.key or "").split())
            # 기호는 RevSymbol로 — DXF 그림 비교는 같은 행 개정표 글 옆에서만 가린다. 글자로만 찾으면 본문 'DETAIL C'의 'C'를
            # 옮긴 그림 변경까지 가렸다 (검토69 B V6c)
            if k and not k.startswith("행"):
                s.add(RevSymbol(k))
            for v in r.values.values():
                v = " ".join(str(v).split())
                if len(v) >= 4:
                    s.add(v)
        return {x for x in s if x}
    # 양쪽에만 있는 글줄 전부 — 지워진 글줄(옛 판에만 있음)의 자리도 가려야 그 자리가 '그림 변경'이
    # 되지 않는다 (검토21 감지 중간 9). 마스크는 capture가 새 판·옛 판 양쪽에서 찾는다
    out = texts(new_doc) ^ texts(old_doc)
    # 바뀐 표제란 칸의 값은 늘 넣는다 — 개정표 행 기호('A'·'B')가 양쪽에 있으면 대칭차에서 지워져, Rev B→A로 되돌린 표제란
    # 'A' 글자가 덤 '그림 변경'이 됐다 (벤치 dxf68 E08 — 전에는 DXF 행 간격 '밀림'이 우연히 가렸다)
    vals: set = set()
    for k, f in (new_doc.fields or {}).items():
        o = (old_doc.fields or {}).get(k)
        nv = " ".join(str(f.value).split())
        ov = " ".join(str(o.value).split()) if o is not None else ""
        if nv != ov:
            vals |= {v for v in (nv, ov) if v}
    for k, o in (old_doc.fields or {}).items():
        if k not in (new_doc.fields or {}):
            ov = " ".join(str(o.value).split())
            if ov:
                vals.add(ov)
    # 같은 글의 개정 기호(RevSymbol)가 이미 들었으면 표제란 칸 값으로 바꿔 넣는다. 칸 값은 TitleValue — DXF 그림 비교는 표제란
    # 틀 안에서만 가린다: 어디서든 가리면 Rev B→C인 날 본문 'DETAIL C'의 'C'를 옮긴 그림 변경이 사라졌다 (검토69 B V6).
    # 같은 글이 본문 글줄로도 바뀌었으면(한쪽 판에만 있는 글줄) 그대로 어디서든 가린다
    from watcher.capture import TitleValue
    plain = ({" ".join(ln.text.split()) for ln in new_doc.raw_texts}
             ^ {" ".join(ln.text.split()) for ln in old_doc.raw_texts})

    # 개정표 행 값으로도 바뀐 글(표제란 DATE와 개정표 A 행 일자가 함께 2026-07-10→2026-10-17)은 개정표 자리에서도 가린다 — 개정표는
    # 표제란 틀 밖에 놓이는 일이 많아, 틀 안에서만 가리자 일자만 다시 뽑은 도면 14장이 장마다 '그림 변경 2곳 + Rev 미갱신'이 됐다
    # (검토71 R1 day9 — f3362f4의 퇴행). 개정 기호('C')는 RevSymbol로 따로 가므로 본문 'DETAIL C'를 가리지 않는다(검토69 V6)
    def _rv(d) -> set:
        return {" ".join(str(v).split()) for r in d.revision_history for v in (r.values or {}).values()
                if len(" ".join(str(v).split())) >= 4}
    plain |= _rv(new_doc) ^ _rv(old_doc)
    return {x for x in out if x not in vals} | {v if v in plain else TitleValue(v) for v in vals}


_PAGE_OF_WHERE = re.compile(r"(\d+)페이지")


def _safe_diff(old_doc, new_doc, path: str = "") -> list:
    """diff_documents — 문서 하나의 예외가 그날 검사 전체를 롤백시키지 않게 (리뷰13 치명-1: 뒤집힌 스캔 한 장에
    브리핑 0통). 실패는 그 파일의 항목으로 남기고 다음 파일로 간다 (원칙 4·5: '못 봄'을 숨기지 않는다)."""
    try:
        return diff_documents(old_doc, new_doc)
    except ScanCancelled:
        raise
    except Exception as e:
        print(f"  경고: 내용 비교 실패 {path}: {clean_text(str(e))[:200]}", file=sys.stderr)
        return [ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                           f"수행 못 함: 비교 중 오류 — {clean_text(str(e))[:160]} (변경 사실과 그림 비교만 봅니다)",
                           "비교 단계")]


def _ocr_boxes_of(doc) -> dict:
    """새 판의 OCR 글줄·필드 → {글자: (pno, x0, y0, x1, y1)} — 그림 비교 마스크와 변경 자리 사진용."""
    out: dict = {}
    if doc is None:
        return out
    for obj, text in ([(t, t.text) for t in doc.raw_texts] + [(f, str(f.value)) for f in doc.fields.values()]):
        box = getattr(obj, "box", None)
        where = str(getattr(obj, "where", "") or "")
        if not box or "OCR" not in where:
            continue
        m = _PAGE_OF_WHERE.search(where)
        if m:
            out.setdefault(" ".join(text.split()), (int(m.group(1)), *box))
    return out


def _changed_boxes(old_doc, new_doc) -> list:
    """한쪽 판에만 있는 OCR 글줄·필드의 자리 — 그 자리의 픽셀 차이는 글자 변경이지 그림 변경이 아니다.
    옛 판에만 있는 줄(지워진 줄)의 자리도 — 새 판 쪽만 보아, 출도 PDF에서 PROJECT 줄이 빠진 날은 '표제란 칸 삭제'와
    '그림 변경'으로 두 번 세어 거짓 'Rev 미갱신'이 났고 그 줄이 다시 생긴 날은 조용했다 (검토42 D 중간 5)."""
    if old_doc is None or new_doc is None:
        return []
    from watcher.ocr import normalize

    def _norms(d) -> set:
        return {normalize(t.text) for t in d.raw_texts} | {normalize(str(f.value)) for f in d.fields.values()}
    old_norm, new_norm = _norms(old_doc), _norms(new_doc)
    return ([box for text, box in _ocr_boxes_of(new_doc).items() if normalize(text) not in old_norm]
            + [box for text, box in _ocr_boxes_of(old_doc).items() if normalize(text) not in new_norm])


def _prev_heads(prev_files) -> set:
    """직전 스냅샷의 '감시 폴더/첫 폴더' 모음."""
    return {"/".join(k.split("/", 2)[:2]) for k in prev_files if k.count("/") >= 2}


def _other_project_move(old: str, new: str, prev_heads: set, cfg=None) -> bool:
    """이름만 같은 두 파일이 **이미 있던 다른 프로젝트 폴더** 사이에 있나 — 그러면 이동 짝이 아니다. 한 프로젝트 폴더가 순단으로
    사라진 날 다른 프로젝트에 같은 이름의 새 도면이 생기자 '옮겨지며 내용 바뀜' 30쌍과 거짓 'Rev 미갱신' 30건이 났다
    (검토44 B F06·F07). 프로젝트 폴더 이름 변경은 새 폴더가 처음 보는 이름이라 그대로 짝이다."""
    op, np_ = PurePosixPath(old).parts, PurePosixPath(new).parts
    if len(op) < 3 or len(np_) < 3 or op[0] != np_[0]:
        return False
    # 프로젝트 번호는 **경로 전체**(파일 이름 앞 폴더들)에서 찾아 먼저 본다 — 같은 번호면 같은 프로젝트('2025/P25-010 →
    # 2026/P25-010' 연도 폴더 정리, 검토45 A 중간 1), 다르면 처음 보는 폴더여도 다른 프로젝트('P26-050 → P26-061', 검토44 F06).
    # 첫 폴더만 보면 연도 폴더 아래('2026/P26-050 → 2026/P26-061')·문서 낱말 든 프로젝트 폴더('P26-050 구매')에서 프로젝트를 넘어
    # 짝지었다 (검토45 B F20·F37). '2026-09' 같은 연-월 폴더는 번호가 아니다
    # 프로젝트 번호는 **영문 머리가 붙은 꼴**(P26-050·PJT25-010)만 — '24-01'·'26-0150'·'26-09' 같은 숫자만의 하위 폴더(표준 판·
    # 발주 번호·연-월)를 번호로 보아 같은 프로젝트 안 이동+수정이 '다른 프로젝트'가 되었다 (검토46 A 차단 1).
    # 먼저 **처음 갈리는 폴더**끼리 보고(양식 폴더 'P26-000'이 두 프로젝트 아래 같이 있어도 속지 않게), 없으면 경로 전체로
    _num = re.compile(r"(?<![A-Za-z0-9])[A-Za-z]{1,4}\d{2,4}[-_]\d{2,4}(?![0-9])")
    # 프로젝트 자리(감시 폴더 바로 아래, 또는 연도 폴더 바로 아래)에서는 숫자만의 번호('26-050'·'PJT 26-050'·'P-26-050')도
    # 번호다 — 연도 폴더 아래 숫자 번호 프로젝트끼리 이동 짝을 지었다 (검토47 A 중간 2). 연-월('26-09')은 아니다
    _num_top = re.compile(r"(?<![A-Za-z0-9])(?:[A-Za-z]{1,4}[-_ ]?)?\d{2,4}[-_]\d{3,4}(?![0-9])")
    _year = re.compile(r"^(?:19|20)\d\d(?:년)?$")

    def _nums(parts, rx=_num):
        # 숫자만 견준다 — 'P26-050 → PJT-26-050' 표기 바꿈은 같은 프로젝트 (검토47 B F60)
        return {re.sub(r"[^0-9]", "", x) for part in parts for x in rx.findall(part)}
    k = 1
    while k < min(len(op), len(np_)) - 1 and op[k] == np_[k]:
        k += 1
    # 처음 갈리는 폴더는 **프로젝트 자리일 때만** 그 번호로 가른다 — 프로젝트 안 하위 폴더('PO26-0150→PO26-0151'·
    # 'REV26-01')까지 보면 같은 프로젝트 안 이동+수정이 '다른 프로젝트'가 됐다 (검토47 A 차단 1)
    if k < len(op) - 1 and k < len(np_) - 1 and (k == 1 or (k == 2 and _year.match(op[1]))):
        a_, b_ = _nums([op[k]], _num_top), _nums([np_[k]], _num_top)
        if a_ and b_:
            return not (a_ & b_)
    no, nn = _nums(op[1:-1]), _nums(np_[1:-1])
    if no and nn:
        return not (no & nn)
    if op[1] == np_[1]:
        return False
    if looks_like_doctype_folder(op[1], cfg) or looks_like_doctype_folder(np_[1], cfg):
        return False                     # 감시 폴더 = 프로젝트 하나(바로 아래가 도면·구매…)
    return f"{np_[0]}/{np_[1]}" in prev_heads


def _pair_moves(rd: "RunData") -> None:
    """삭제+추가 쌍을 이동·이름 변경으로 묶는다 — 폴더 이름 하나 바꾸면 그 안의 진짜
    변경(성적서 NG 등)이 '추가'로 세탁되던 것 (2026-09-03 검토).
    ① 내용(sha)이 같으면 이름·위치만 바뀐 것 ② 파일명이 같고 폴더만 다르면 이동+수정."""
    removed = [c for c in rd.changes if c.kind == "removed"]
    added = [c for c in rd.changes if c.kind == "added"]
    if not removed or not added:
        return
    by_sha: dict = {}
    by_name: dict = {}
    for c in removed:
        by_sha.setdefault(c.old_sha256, []).append(c)
        by_name.setdefault(PurePosixPath(c.path).name, []).append(c)
    used: set = set()
    _heads = _prev_heads(rd.prev_files)
    present_dirs = {PurePosixPath(r.path).parent for r in (rd.records or ())}
    root_of = {lb: Path(r) for r, lb in zip(rd.roots or (), rd.labels or ())}

    def _dir_gone(key_dir: str) -> bool:
        """옛 폴더가 디스크에서 사라졌나 — 빈 채 남아 있으면 이름 변경이 아니다."""
        lb, _, rel = key_dir.partition("/")
        r = root_of.get(lb)
        if r is None:
            return PurePosixPath(key_dir) not in present_dirs
        try:
            return not (r / rel if rel else r).is_dir()
        except OSError:
            return PurePosixPath(key_dir) not in present_dirs
    # ⓞ 폴더 이름 변경·이동 속의 같은 파일을 **상대 경로(하위 폴더 꼬리 + 파일명)** 로 먼저 맺는다 —
    # 내용(sha)으로 먼저 맺으면, 폴더 이름을 바꾸면서 안의 E-101을 고친 날 새 E-101(Rev B)은
    # 짝이 없어 "비교 대상 없음"이 되고 구 E-101은 임시 폴더의 동일 사본으로 '이동'됐다고
    # 말했다 — 도면 변경이 유실됐다 (검토21 파일럿 차단 1). 이름이 유일하고 옛 폴더가 사라졸
    # 때만(이름 변경·이동의 증거) 맺고, 내용이 같으면 이동, 다르면 이동+수정이다
    for a in added:
        name = PurePosixPath(a.path).name
        cands = [r for r in by_name.get(name, []) if r.path not in used and r.path != a.path]
        if len(cands) != 1:
            continue
        r = cands[0]
        od, nd = PurePosixPath(r.path).parent, PurePosixPath(a.path).parent
        if od == nd:
            continue
        if r.old_sha256 != a.new_sha256 and _other_project_move(r.path, a.path, _heads, rd.cfg):
            continue
        op_, np_ = od.parts, nd.parts
        k = 0
        while k < min(len(op_), len(np_)) and op_[-1 - k] == np_[-1 - k]:
            k += 1
        if k < 1 or not _dir_gone(str(od)):
            continue
        used.add(r.path)
        same = bool(a.new_sha256) and r.old_sha256 == a.new_sha256
        rd.moved[a.path] = (r.path, r.old_sha256, same)
        if same:
            rd.details.setdefault(a.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"이름·위치만 바뀜 — 이전: {r.path} (내용 동일)", "파일 확인"))
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨짐 — 파일이 없어진 것이 아닙니다", "파일 확인"))
        else:
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨지며 내용도 바뀜 — 비교는 새 경로 쪽에", "파일 확인"))
    # 내용(sha) 짝을 먼저 전부 맺는다 — 같은 이름 파일 둘이 동시에 옮겨질 때 이름 후보가
    # 2개라 하나를 놓치던 것 (2026-09-03 재검토)
    # 단, 내용이 같다는 것만으로는 이동이 아니다 — 빈 양식·표지·표준 상세도처럼 같은 바이트의 파일이 여러 곳에 있는
    # 현장에서 도면 삭제가 '다른 곳의 새 사본으로 옮겨짐'으로 세탁됐다(검토20 r15-1). 같은 이름(표기만 다름 포함)이거나,
    # 같은 폴더 안 이름 바꾸기거나, 옛 폴더가 사라졌을 때만 짝짓고, 그 밖은 삭제 그대로 + '같은 내용의 새 파일' 참고
    def _nkey(p: str) -> str:
        return unicodedata.normalize("NFC", PurePosixPath(p).name).casefold()

    def _sha_pair_ok(r, a) -> bool:
        od, nd = PurePosixPath(r.path).parent, PurePosixPath(a.path).parent
        return _nkey(r.path) == _nkey(a.path) or od == nd or _dir_gone(str(od))
    same_content: dict = {}
    for a in added:
        if a.path in rd.moved:
            continue
        cands = [r for r in by_sha.get(a.new_sha256, []) if r.path not in used]
        if not a.new_sha256:
            cands = []
        # 같은 내용이 여럿(X.pdf와 사본 X (1).pdf)이면 같은 이름 → 같은 폴더 꼬리 순으로 — 엇갈려 맺혀 폴더 이름을 바꾼 날
        # 사본이 '추가'·'삭제'로 오늘 확인할 것에 올랐다 (검토67 B3)
        _an = PurePosixPath(a.path).name
        for r in cands:
            if not _sha_pair_ok(r, a):
                same_content.setdefault(r.path, []).append(a.path)
        cands = [r for r in cands if _sha_pair_ok(r, a)]
        cands.sort(key=lambda r: (PurePosixPath(r.path).name != _an, r.path))
        if cands:
            r = cands[0]
            used.add(r.path)
            rd.moved[a.path] = (r.path, r.old_sha256, True)
            rd.details.setdefault(a.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"이름·위치만 바뀜 — 이전: {r.path} (내용 동일)", "파일 확인"))
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨짐 — 파일이 없어진 것이 아닙니다", "파일 확인"))
    for a in added:
        if a.path in rd.moved:
            continue
        cands = [r for r in by_name.get(PurePosixPath(a.path).name, []) if r.path not in used]
        # BOM.xlsx·표지.pdf·전장도.dxf 같은 범용 이름은 프로젝트마다 있다 — 다른 폴더의
        # 동명 파일을 "옮겨지며 내용도 바뀜"으로 짝지어 남의 프로젝트 메일에 거짓 근거를
        # 실었다 (검토19 감지 ④). 숫자가 든 이름(E-101, P26-014_BOM)은 트리 어디서든
        # 짝짓되, 숫자 없는 이름은 같은 폴더 안에서만 — 단 옛 폴더가 통째로 사라졌으면
        # (폴더 이름 변경·이동, 디스크에서 확인) 그 안의 범용 이름도 짝이다.
        # 후보를 먼저 좁힌 뒤 유일성을 본다 (검토19 2차 감지 N8)
        stem = PurePosixPath(a.path).stem
        if not any(ch.isdigit() for ch in stem):
            new_dir = PurePosixPath(a.path).parent

            def _renamed_sibling(old_dir: PurePosixPath) -> bool:
                # 옛 폴더가 사라졌더라도 **형제 폴더의 이름 변경이나 같은 꼬리(프로젝트/하위)를
                # 가진 이동**일 때만 — 조건이 "사라짐"뿐이면 남의 프로젝트 BOM과 교차로
                # 짝지어 그 행 변경이 내 메일 근거로 나갔다 (검토19c ②)
                if not _dir_gone(str(old_dir)):
                    return False
                if old_dir.parent == new_dir.parent:
                    return True
                op, npn = old_dir.parts, new_dir.parts
                k = 0
                while k < min(len(op), len(npn)) and op[-1 - k] == npn[-1 - k]:
                    k += 1
                return k >= 2
            cands = [r for r in cands
                     if PurePosixPath(r.path).parent == new_dir
                     or _renamed_sibling(PurePosixPath(r.path).parent)]
        cands = [r for r in cands if not _other_project_move(r.path, a.path, _heads, rd.cfg)]
        if len(cands) == 1:
            r = cands[0]
            used.add(r.path)
            rd.moved[a.path] = (r.path, r.old_sha256, False)
            rd.details.setdefault(r.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{a.path}(으)로 옮겨지며 내용도 바뀜 — 비교는 새 경로 쪽에", "파일 확인"))
    # 짝짓지 않은 삭제에 '같은 내용의 새 파일'을 참고로 — 이동이었는지는 사람이 판단한다 (검토20 r15-1)
    for rp, news in same_content.items():
        if rp in used:
            continue
        news = sorted(set(news) - set(rd.moved))
        if not news:
            continue
        more = f" 외 {len(news) - 1}곳" if len(news) > 1 else ""
        rd.details.setdefault(rp, []).append(ChangeItem(
            "CHECK_SKIPPED", "참고", None,
            f"삭제됨 — 같은 내용의 새 파일 있음: {news[0]}{more} (다른 이름·다른 폴더라 이동으로 묶지 않았습니다)",
            "파일 확인"))

def _date_went_back(items) -> bool:
    """표제란 DATE가 더 이른 날짜로 바뀌었나 — 둘 다 날짜로 읽힐 때만."""
    def _d(v):
        m = re.search(r"(\d{4})[-./](\d{1,2})[-./](\d{1,2})", str(v or ""))
        return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
    for i in items:
        if getattr(i, "kind", "") == "FIELD_CHANGED" and str(getattr(i, "key", "")).split("#", 1)[0] == "DATE":
            a, b = _d(i.old), _d(i.new)
            if a and b and b < a:
                return True
    return False


def _order_only(items) -> bool:
    """내용 항목이 순서 바뀜(행·열·쪽)뿐인가 — 쪽이 빠지거나 끼어들었거나 방향·범위를 말했으면 아니다."""
    from watcher.diff import CONTENT_KINDS, ORDER_KINDS
    kinds = [getattr(i, "kind", "") for i in items]
    if any(getattr(i, "key", "") in ("페이지 방향", "도면 범위") or "상한 밖" in str(getattr(i, "new", "") or "")
           for i in items):
        return False
    content = [k for k in kinds if k in CONTENT_KINDS or k.startswith(("FIELD_", "REVROW_"))]
    return bool(content) and all(k in ORDER_KINDS for k in content)


def _is_date_item(i) -> bool:
    """표제란 일자·리비전 블록의 일자 칸만 바뀐 항목 — 재출력의 흔적이지 내용이 아니다.
    표제란 DATE만 보던 규칙은 리비전 행 일자가 함께 갱신되는 실제 재출력에서 한 번도
    발동하지 않았다 (파일럿 모의 3차 ②)."""
    kind, key = getattr(i, "kind", ""), str(getattr(i, "key", "") or "")
    if kind == "FIELD_CHANGED" and key.split("#", 1)[0] == "DATE":     # DATE#2 = 둘째 표제란 (검토36 A N2)
        # 값에 글자가 섞이면 일자가 아니다 — '2026-09-30 검사자 홍길동 판정 합격→불합격'을 일자로 접었다 (검토42 B 차단 2)
        return not any(re.search(r"[A-Za-z가-힣]", re.sub(r"[년월일]", "", str(v)))
                       for v in (getattr(i, "old", None), getattr(i, "new", None)) if v not in (None, ""))
    from watcher.diff import is_title_date_text
    if is_title_date_text(i):                       # 'DATE: 2026-09-01' 글줄의 날짜만 (검토42 B 중간 2)
        return True
    # 'UPDATE' 열이 일자로 접혔다 — 낱말로서의 DATE만 (검토37 A 낮음)
    if kind == "REVROW_CHANGED" and (re.search(r"(?:^|[^A-Z])DATE$", key.upper()) or key.endswith("일자")):
        return True
    return False


def _file_level_items(path: str, old_row, new_rec) -> list:
    """내용을 못 읽는 파일의 근거 — 크기와 저장 시각. 바뀐 것만 항목으로 낸다.

    "직접 확인이 불가능한 확장자들 … PLC 프로그램 등은 저장 날짜나 파일명 변경된거
    정도는 관리가 가능하면 좋겠네" (2026-09-10). 이름·폴더 변경은 이미 이동으로
    접히므로 여기서는 크기·저장 시각만 본다."""
    def _sz(n) -> str:
        try:
            n = int(n)
        except (TypeError, ValueError):
            return "—"
        return f"{n:,}바이트" + (f" ({n / 1048576:.1f}MB)" if n >= 1048576 else "")

    def _tm(v) -> str:
        try:
            return datetime.fromtimestamp(float(v)).strftime("%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError, OSError, OverflowError):
            # 1e20 같은 값은 OverflowError — 한 파일의 이상한 시각이 검사 전체를
            # 죽이면 안 된다 (검토18)
            return "—"
    out: list = []
    if new_rec is None:
        return out
    o_size = o_mtime = None
    if old_row is not None:
        # _latest_rows()는 (sha256, size, mtime) 꼴로 준다
        try:
            o_size, o_mtime = old_row[1], old_row[2]
        except (TypeError, IndexError, KeyError):
            o_size = o_mtime = None
    try:
        size_changed = o_size is not None and int(o_size) != int(new_rec.size)
    except (TypeError, ValueError):
        size_changed = False
    if size_changed:
        out.append(ChangeItem("FIELD_CHANGED", "파일 크기", _sz(o_size),
                              _sz(new_rec.size), "파일 수준"))
    try:
        time_changed = o_mtime is None or abs(float(o_mtime) - float(new_rec.mtime)) > 1.0
    except (TypeError, ValueError):
        time_changed = True
    if time_changed:
        out.append(ChangeItem("FIELD_CHANGED", "저장 시각", _tm(o_mtime),
                              _tm(new_rec.mtime), "파일 수준"))
    return out


def _last_readable_extract(state: State, path: str, skip_sha: str | None, new_sha: str | None = None):
    """이 경로의 지난 판 가운데 내용을 읽었던 가장 최근 판의 추출 기록 — (기록, 'MM-DD 검사 때 들어온 판', 지문) 또는 None."""
    # 스냅샷 파일 표는 최신 것만 남으므로 **변경 기록**의 이전/새 지문을 거꾸로 따라간다
    try:
        rows = []
        for o_sha, n_sha, at in state.conn.execute(
                "SELECT old_sha256, new_sha256, detected_at FROM changes WHERE path = ? ORDER BY id DESC LIMIT 60",
                (path,)).fetchall():
            if o_sha == skip_sha and n_sha == new_sha:
                continue                         # 오늘 이 변경 자체 — 오늘 판과 견주면 '변경 없음'이 된다
            rows += [(n_sha, at, "검사 때 들어온 판"), (o_sha, at, "검사 전까지 있던 판")]
    except sqlite3.Error:
        return None
    seen: set = set()
    for sha, run_at, how in rows:
        if not sha or sha == skip_sha or sha in seen:     # 복구한 판이 손상 전 판과 같으면 그 판과 견줘 '변경 없음'이 맞다
            continue
        seen.add(sha)
        d = state.load_extract(sha, path)       # 묶음 열쇠 — 같은 바이트의 다른 형식 기록을 섞지 않게 (S1)
        if d and not d.get("extract_failed") and _compare_ok(d, path):
            try:
                when = datetime.fromisoformat(str(run_at)).astimezone().strftime("%m-%d ") + how
            except (ValueError, TypeError):
                when = str(run_at)[:10] + " " + how
            return d, when, sha
    return None


def _compare_modified(state: State, rd: RunData) -> None:
    """덮어쓰기 수정 파일(+ 옮겨지며 바뀐 파일): 구버전 추출본과 내용 비교, 기록해 둔
    그림으로 전/후 그림 비교(글자 변경 자리는 제외), Rev 일관성 검사. 글자를 못 읽는
    판(DWG 변환 없음 등)도 그림은 비교한다."""
    from watcher.capture import visual_page_diff
    sha_of = {r.path: r.sha256 for r in rd.records}
    now_of = {r.path: r for r in rd.records}          # 크기·저장 시각 (파일 수준 근거)
    prev_of = getattr(rd, "prev_files", None) or {}
    targets = [(c.path, c.old_sha256, c.new_sha256, None)
               for c in rd.changes if c.kind == "modified"]
    targets += [(new, old_sha, sha_of.get(new), old_path)
                for new, (old_path, old_sha, same) in rd.moved.items() if not same]
    for ti, (path, old_sha, new_sha, moved_from) in enumerate(targets, 1):
        # 가장 오래 걸리는 구간(글자 diff+그림 비교)에 진행이 없어 마지막 추출 파일 이름으로 얼어
        # 보였다 (검토24 B-1: 수정 24장 시험에서 전체의 34%)
        _set_progress("3/3 변경 비교 (글자·그림)", ti, len(targets), current=path)
        ext = PurePosixPath(path).suffix.lower()
        items: list = list(rd.details.get(path, []))
        if moved_from:
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{moved_from}에서 옮겨짐(이름·폴더 변경) — 그 판과 비교합니다", "파일 확인"))
        # ① 글자·표 — 구버전 추출본과
        old_dict = state.load_extract(old_sha, moved_from or path)
        vis_old_sha = old_sha
        new_doc = rd.docs.get(path)
        old_sha_failed = bool(old_dict is not None and old_dict.get("extract_failed"))
        if old_sha_failed or (old_dict is None and old_sha and new_doc is not None):
            # 직전 판이 손상·잠김으로 못 읽은 판이면 **그 전에 읽었던 판**과 비교한다 — 복구한 날 비교 기준이 없어 열린
            # 'Rev 미갱신'이 '재검출되지 않음'으로 닫혔다 (검토45·46 B G31·G40~48). 없으면 비교 생략으로 두어 닫지 않는다
            old_dict = None
            good = _last_readable_extract(state, moved_from or path, old_sha, new_sha)
            if good is not None:
                old_dict, _good_at, vis_old_sha = good          # 그림 비교도 그 판과
                # 기록만 없는 경우를 '손상'이라 하지 않는다 (검토47 A 낮음)
                _why_prev = ("직전 판을 읽지 못해(손상·잠김)" if old_sha_failed else "직전 판의 내용 기록이 없어")
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "참고", None,
                    f"{_why_prev} 그 전에 읽은 판({_good_at})과 비교합니다", "파일 확인"))
            else:
                rd.compare_skipped.add(path)
        old_doc = None
        text_items: list = []
        text_checked = False
        if old_dict is None or new_doc is None:
            # 검사 불가를 브리핑에 명시 — '이상 없음'과 '못 봄'을 구분
            from watcher.extract import can_read_content
            if new_doc is None and not can_read_content(path) \
                    and path not in rd.extract_failures:
                # PLC 프로젝트·DWG 바이너리처럼 **원래** 내용을 못 읽는 형식.
                # 전에는 "구버전 추출본 없음 — 이번 판을 기준으로 저장"이라 적어
                # 다음엔 될 것처럼 읽혔다 (2026-09-10 사용자 요청). `new_doc is None`
                # 조건이 있어야 한다 — 변환 프로그램이 있어 DWG를 실제로 읽었는데
                # 구판만 없는 경우는 형식 탓이 아니고 다음 판부터 비교된다 (검토18 ①)
                # "이름 변경으로 관리"는 과했다 — 이름 변경은 이 항목이 아니라 이동·판
                # 짝짓기가 보여 주고, 그것도 같은 이름 규칙일 때만이다 (검토18 문구 ⑧)
                more = ("그림 비교는 아래에 따로 싣습니다" if ext in VISUAL_EXTS
                        else "파일이 바뀐 사실과 크기·저장 시각으로 관리하고, 같은 이름 규칙의 "
                             "새 판은 이전 판과 짝지어 보여줍니다")
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "내용 비교", None,
                    f"이 형식({ext or '확장자 없음'})은 글자·표를 읽지 못합니다 — "
                    f"{more}", "파일 수준 감시"))
            else:
                reason = rd.extract_failures.get(
                    path, "구버전 추출본 없음 — 이번 판을 기준으로 저장")
                # 라이브러리 원문("File 'C:\...\E-103.dxf' is not a DXF file")이 서버 절대 경로까지 메일에
                # 실렸다 (검토21 브리핑 중간 7) — 담당자 말로 바꾸고 경로는 지운다
                # 이미 한국어 문구면 다시 포장하지 않는다 (재검증 N2: 같은 문장이 두 번)
                msg = reason if re.search(r"[가-힣]", str(reason)) else _friendly_error(Exception(reason))
                items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                        f"수행 못 함: {_strip_paths(msg)}", "추출 단계"))
            # 내용 비교를 못 한 모든 경우에 크기·저장 시각을 근거로 단다 — 사유가
            # 무엇이든(변환기 없는 DWG, 시간 초과, 원래 못 읽는 형식) 브리핑에 사실이
            # 하나는 있어야 한다 (원칙 4, 검토18 ②)
            items += _file_level_items(path, prev_of.get(moved_from or path),
                                       now_of.get(path))
        elif not _compare_ok(old_dict, path):
            # 구버전(다른 추출 엔진 세대) 기록과 새 추출본을 섞어 비교하면
            # 줄 나뉨 차이가 가짜 diff 수백 건이 된다 (2026-08-26 리뷰)
            rd.compare_skipped.add(path)
            items.append(ChangeItem(
                "CHECK_SKIPPED", "내용 비교", None,
                "수행 못 함: 이전 판의 추출 기록이 다른 프로그램 판의 형식(판 교체 전후)이라 비교를 생략하고 "
                "이번 판을 새 기준으로 저장합니다. 다음 변경부터 정상 비교됩니다",
                "추출 단계"))
            items += _file_level_items(path, prev_of.get(moved_from or path),
                                       now_of.get(path))
        else:
            old_doc = _old_doc(old_dict, new_doc, path)
            note = unreadable_note(old_doc, new_doc)
            if note:  # 텍스트를 못 읽는 판이 끼면 엉터리 diff 대신 사유를 보고
                items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                        f"수행 못 함: {note}", "추출 단계"))
                old_doc = None
                # 스캔본(글자 없는 PDF)의 덮어쓰기 — 이 분기만 파일 수준 근거가 빠져
                # 근거 0줄이었다 (검토19 브리핑 ③)
                items += _file_level_items(path, prev_of.get(moved_from or path),
                                           now_of.get(path))
            else:
                text_items = _safe_diff(old_doc, new_doc, path)
                text_checked = True
        # ② 그림 — 검사 때 기록해 둔 페이지 그림이 '이전 판' (2026-09-02). 기록이
        # 없으면 '이상 없음'과 '못 봄'을 구분해 고지 (원칙 4)
        visual_done = ext not in VISUAL_EXTS   # PDF·DXF·DWG만 그림 비교 대상
        vis_regions = 0
        if ext in VISUAL_EXTS and ext != ".dwg" and path in (rd.extract_failures or {}):     # DWG는 미리보기 그림끼리
            # 이번 판을 읽지 못한(시간 상한·손상) 파일을 그림 비교가 주 프로세스에서 상한 없이 다시 열어 검사가 10분 넘게
            # 멈췄다 (검토63 D-F1) — 그 판은 그림도 그리지 않는다
            items.append(ChangeItem("CHECK_SKIPPED", "시각 비교", None,
                                    "수행 못 함: 이번 판을 읽지 못해(시간 상한·손상) 그림 비교도 하지 않았습니다", "시각 비교 단계"))
        elif ext in VISUAL_EXTS:
            old_pages, new_side = _visual_sides(state, rd, path, vis_old_sha, new_sha)
            if old_pages and new_side is not None:
                print(f"  그림 비교(기록): {PurePosixPath(path).name}", flush=True)
                from watcher.diff import page_anchors
                vis = visual_page_diff(old_pages, new_side,
                                       ignore_texts=_changed_texts(old_doc, new_doc),
                                       ignore_boxes=_changed_boxes(old_doc, new_doc),
                                       anchors=(page_anchors(old_doc, new_doc)
                                                if old_doc is not None and new_doc is not None else None),
                                       title_boxes=_title_boxes_of(old_doc, new_doc),
                                       split=_split_flow(text_items),
                                       new_renders=(_fresh_renders(state, new_sha)
                                                    if PurePosixPath(path).suffix.lower() == ".dxf" else None))
                visual_done = _add_visual(rd, path, items, vis)
                vis_regions = len(vis[0]) if vis else 0
                if visual_done and vis_regions == 0 and not text_items and ext == ".pdf" and _ocr_read(new_doc):
                    # 스캔본(OCR)은 글자를 잘못 읽으면 값 변경이 글자 비교에서 사라진다 — 그림 비교까지 0곳이면 '다시 저장만'으로
                    # 접혀 짧은 칸 값 변경('LT-2103'→'LT-2113'·'2'→'4')을 조용히 놓쳤다 (2026-10-20 PDF 대량 시험 O2, 원칙 5).
                    # 글자 비교가 아무것도 못 찾은 스캔 문서만 민감 비교를 한 번 더 — 작은 자리 몇 곳(3곳 이하)이면 그림 변경으로
                    # 싣는다. 재스캔 잡음(회색 차 20대 픽셀 몇 개)은 뚜렷한 픽셀(차 80 넘음) 6개 미만이라 거른다 — 글자 하나가 바뀐
                    # 자리는 14~33개(대량 시험 O2 9건), 재스캔 잡음은 0개(재스캔 64건)
                    vis2 = visual_page_diff(old_pages, new_side, sensitive=True, strong_px=6,
                                            anchors=(page_anchors(old_doc, new_doc)
                                                     if old_doc is not None and new_doc is not None else None))
                    if vis2 and 0 < len(vis2[0]) <= 3 and all("위치" in k for k, _w in vis2[0]):
                        _keys = {k for k, _w in vis2[0]}
                        _add_visual(rd, path, items, ([(k, f"{w} · 스캔본 민감 비교") for k, w in vis2[0]],
                                                      {k: v for k, v in vis2[1].items() if k in _keys}))
                        vis_regions = len(vis2[0])
            else:
                if new_doc is not None and not _wants_render(path, new_doc):
                    # 문서 폴더의 스캔본·매뉴얼 PDF는 그림을 **영영** 기록하지 않는다 —
                    # "다음 변경부터 비교됩니다"가 매번 되풀이되는 거짓 약속이었다 (검토19 2차 ⑤)
                    items.append(ChangeItem(
                        "CHECK_SKIPPED", "시각 비교", None,
                        # 성적서·납품문서에 '도면 폴더로 옮기라'는 조언은 엉뚱했다 (검토56 ⑤23)
                        "수행 못 함: 도면이 아닌 문서라 페이지 그림은 기록하지 않습니다 — "
                        "글자(스캔본은 OCR)·크기·저장 시각으로 비교합니다", "시각 비교 단계"))
                else:
                    items.append(ChangeItem(
                        "CHECK_SKIPPED", "시각 비교", None,
                        "수행 못 함: 이전 판의 페이지 그림 기록이 없음 — 그림(도형) "
                        "변경은 비교하지 못함(글자·표 비교는 위 항목대로). 이번 판부터 그림을 "
                        "기록하므로 다음 변경부터는 같은 이름으로 덮어써도 그림 비교됩니다",
                        "시각 비교 단계"))
        items += text_items
        # 일부 쪽만 읽은 문서의 고지는 '비교 불가'가 아니라서 _blocking_notes가 거르는데, 그 뒤 어디에도
        # 실리지 않아 긴 스캔본의 31쪽 이후 변경이 '글자·표·그림 동일, 확인 대상 아님'으로 접혔다
        # (검토35 A 중간 1 — 검토33 C4가 막으려던 장면). 항목으로 싣고 '동일' 단언을 막는다
        _partial = [str(n) for n in (new_doc.notes if new_doc is not None else [])
                    if str(n).startswith(_PARTIAL_READ)]
        # 워드·한글 본문이 상한(4,000문단)을 넘어 일부만 비교했다 — '동일'·'다시 저장되기만'이라 단언하지 않는다 (검토20 r11 1)
        _partial_body = [str(n) for n in ((new_doc.notes if new_doc is not None else [])
                                          + (old_doc.notes if old_doc is not None else []))
                         if str(n).startswith(_PARTIAL_BODY)][:1]
        if _partial_body and text_items:
            items.append(ChangeItem("CHECK_SKIPPED", "비교 범위", None,
                                    "일부만 비교 — " + _partial_body[0].split(": ", 1)[-1], "내용 비교"))
        # 방향이 돌아갔거나 도면 범위가 넓어졌다고 이미 말했으면 "변경 없음"이라 덧붙이지
        # 않는다 — 한 화면에서 서로를 부정한다 (2026-09-10 매트릭스)
        said_something = any(getattr(i, "key", "") in ("페이지 방향", "도면 범위")
                             or getattr(i, "kind", "") in ("PAGE_ADDED", "PAGE_REMOVED", "PAGE_MOVED")
                             or "상한 밖" in str(getattr(i, "new", "") or "")
                             or str(getattr(i, "new", "") or "").startswith("문단 나눔·합침만")   # 검토61 D07
                             for i in items)          # 쪽이 빠졌다고 해 놓고 "재저장"이라 하지 않게 (검토19c ④)
        settled = text_checked and vis_regions == 0 and not said_something \
            and (ext not in VISUAL_EXTS or visual_done)
        # PDF를 다른 프로그램으로 다시 뽑아 띄어쓰기만 달라진 판(글자 자리는 같고 낱말 사이 틈만 다름) — 글자·그림이 같으면 조용한
        # 재저장이다. '띄어쓰기만 바뀜' 참고 하나로 메일·'오늘 확인할 것'에 올랐다 (2026-10-20 PDF 대량 시험 N8). 항목은 남긴다
        _space_note = [i for i in text_items if getattr(i, "kind", "") == "CHECK_SKIPPED"
                       and str(getattr(i, "new", "") or "").startswith("띄어쓰기만 바뀜")]
        if text_checked and vis_regions == 0 and not said_something and ext == ".pdf" and _space_note \
                and len(_space_note) == len(text_items) and not _partial:
            _sn = ("글자·표·그림 동일" if visual_done else "글자·표 동일 — 그림은 비교하지 못함")
            # 띄어쓰기 참고 줄은 이 한 줄로 합친다(근거 글은 그대로 싣는다) — 첫 참고 줄이 조용한 말이어야 메일·화면이 접는다
            _what = re.sub(r" \(글자는 그대로입니다\)$", "", str(_space_note[0].new).split(" — ", 1)[-1])
            items = [i for i in items if not any(i is s_ for s_ in _space_note)]
            text_items = [i for i in text_items if not any(i is s_ for s_ in _space_note)]
            _what = re.sub(" · ", " ·", _what)
            # 그림까지 같으면 조용한 재저장 문구 그대로(메일에서 뺀다 — brief.is_silent_resave), 그림을 못 봤으면 그 사실을 적는다
            _txt = (f"내용 변경 없음 — 파일이 다시 저장되기만 했습니다 ({_sn}). 다시 출력되며 띄어쓰기만 달라짐 ({_what}). "
                    "확인 대상 아님 (기록만 남깁니다)" if visual_done else
                    f"내용 변경 없음 — 다시 출력되며 띄어쓰기만 달라졌습니다 ({_what}; {_sn}). 확인 대상 아님 (기록만 남깁니다)")
            items.append(ChangeItem("CHECK_SKIPPED", "참고", None, _txt, _space_note[0].where))
        elif settled and not text_items and _partial_body:
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                "일부만 비교 — 비교한 범위(앞 문단·머리글·바닥글·각주·표)에서는 글자 변경이 없습니다. "
                + _partial_body[0].split(": ", 1)[-1] + " — 파일을 열어 확인하세요", "내용 비교"))
        elif settled and not text_items:
            # 내용 같은 재저장 — '수정'으로만 보이고 상세가 비어 무엇이 바뀌었는지
            # 알 수 없던 것 (2026-09-03 검토: 케이블 스케줄·IO 리스트).
            # 그림을 비교하지 않는 형식(docx·xlsx)에 "그림 동일"을 단언하면 안 된다 — 사양서의 배치 그림,
            # BOM 시트의 캡처가 바뀐 날 "확인 대상 아님"으로 접혔다 (검토33 C3, 원칙 4·5)
            # 그림을 비교하지 않는 형식(docx·xlsx)에 "그림 동일"을 단언하지 않는다 (검토33 C3). 다만
            # 확인 대상으로 올리지도 않는다 — 조용한 행이라 확인 자체가 거부돼 "한 번 열어 확인해 주세요"가
            # 실행 불가능한 요구였고, 일괄 재저장 100건이 전부 그 줄이 됐다 (검토34 B 중간 1)
            # 문서 안 그림만 바꾼 날도 이 줄이 된다 — '다시 저장되기만'이라 단정하지 말고 그림을 열어 보라고 (검토67 C2)
            # 문서 안 그림·개체 부품까지 두 판 모두 읽었으면 '그림 동일'이라 말할 수 있다 — 그러면 PDF·DXF 재저장처럼 메일에서 뺀다.
            # 부품을 못 읽은 판(손상·옛 기록)만 '비교 못 함' (검토71 R4: 재저장 메일 5.3배, DECISIONS 2026-10-17b)
            from watcher.diff import parts_compared as _pc
            _seen = ("글자·표·그림 동일" if ext in VISUAL_EXTS or _pc(old_doc, new_doc)
                     else "글자·표 동일 — 그림·개체는 비교하지 못함. 그림만 바꿨다면 파일을 열어 확인하세요")
            if _partial:
                _seen = "읽은 쪽의 글자·표·그림 동일"
            if any(getattr(i, "key", "") == MOVED_KEY for i in items):
                _seen += " — 도면 전체의 자리·배율만 바뀜"
            if any(getattr(i, "key", "") == FORMAT_ONLY_KEY for i in items):
                _seen += " — 글자 서식(글꼴·색·굵기)만 바뀜"          # 뒤흔들기 DXF C5: 위 그림 항목과 서로 부정하지 않게
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"내용 변경 없음 — 파일이 다시 저장되기만 했습니다 ({_seen}). "
                "확인 대상 아님 (기록만 남깁니다)"
                + (f" · {_partial[0].split(': ', 1)[-1]}" if _partial else ""), "내용 비교"))
        elif text_checked and vis_regions == 0 and not said_something and text_items \
                and all(_is_date_item(i) for i in text_items) and _date_went_back(text_items):
            # 일자가 **과거로** 갔다 — '갱신(재출력)'이 아니라 옛 판을 되살렸을 수 있다. 조용히 접으면 되돌림이
            # 묻혔다 (검토42 D 중간 3). 참고 문구에 조용한 말(갱신·재저장)을 쓰지 않아 목록·메일에 남는다
            from watcher.diff import field_base as _fb
            # DATE#2(둘째 표제란)도 — 'DATE'만 찾다가 없으면 엉뚱한 항목(개정표 행) 값을 표제란 일자로 인용했다 (검토43 A 낮음 3)
            dtb = next((i for i in text_items if i.kind == "FIELD_CHANGED" and _fb(i.key) == "DATE"), text_items[0])
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"표제란 일자가 이전 날짜로 바뀜 {dtb.old} → {dtb.new} — 옛 판으로 되돌렸는지 확인하세요 "
                f"(글자·표는 일자 말고 같습니다)", "내용 비교"))
        elif text_checked and vis_regions == 0 and not said_something and text_items \
                and all(_is_date_item(i) for i in text_items):
            # 표제란 일자만 갱신된 일괄 재출력 — 40장이 장마다 사진을 달고 '변경'으로 실려
            # 744KB 메일이 됐다 (파일럿 모의 ③). 그림 비교를 못 한 경우도 글자로는 날짜뿐이니
            # 그 밖의 알림으로 접되 그 사실을 적는다 (파일럿 모의 2차 day9)
            # 그림을 비교하지 않는 형식(문서류)에 '그림 동일'을 단언하지 않는다 — 조건이 거꾸로였다 (검토43 A 낮음 4, 검토33 C3 취지)
            from watcher.diff import parts_compared as _pc
            tail = ("그 밖의 글자·표 동일 — 그림·개체는 비교하지 못함" if ext not in VISUAL_EXTS and not _pc(old_doc, new_doc)
                    else "그 밖의 글자·표·그림 동일" if visual_done or ext not in VISUAL_EXTS
                    else "그 밖의 글자·표 동일 (그림은 비교하지 못함)")
            what = ("표제란·개정표의 일자만" if any(i.kind == "REVROW_CHANGED" for i in text_items)
                    else "표제란 일자만" if ext in VISUAL_EXTS else "문서 일자만")
            # 옛/새 일자를 함께 — 접힌 행에 값이 없어 원칙 4에 어긋났다 (검토21 브리핑 중간 8)
            dt0 = next((i for i in text_items if i.kind == "FIELD_CHANGED" and i.key == "DATE"), None) \
                or text_items[0]
            vals = f" {dt0.old or '없음'} → {dt0.new or '없음'}" if (dt0.old or dt0.new) else ""
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{what} 갱신됨{' (재출력)' if ext in VISUAL_EXTS else ''}{vals} — {tail}. 확인 대상 아님 (기록만 남깁니다)",
                "내용 비교"))
        elif text_checked and vis_regions == 0 and (ext not in VISUAL_EXTS or visual_done) \
                and _order_only(items):
            # 행 정렬·쪽 순서만 바뀐 판 — 값·글자는 같다. '수정'으로 메일을 내고 Rev 미갱신까지 났다 (경우100 B04·C06)
            what = ("쪽 순서" if any(getattr(i, "kind", "") == "PAGE_MOVED" for i in items)
                    else "열 순서" if all(getattr(i, "kind", "") != "ROW_MOVED" for i in items) else "행 순서")
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{what}만 바뀜 — 값·글자는 같습니다. 확인 대상 아님 (기록만 남깁니다)", "내용 비교"))
        elif text_checked and vis_regions == 0 and ext not in VISUAL_EXTS and not said_something and text_items \
                and any(_is_date_item(i) for i in text_items) \
                and any(getattr(i, "kind", "") == "ROW_MOVED" for i in text_items) \
                and all(_is_date_item(i) or getattr(i, "kind", "") == "ROW_MOVED" for i in text_items) \
                and not _date_went_back([i for i in text_items if _is_date_item(i)]):
            # 문서 일자만 갱신 + 행 정렬만 — 각각은 조용한 변경인데 둘이 겹치면 '수정' 메일이 나갔다 (대량 시험 XLSX O1, 2026-10-20).
            # 문서류(그림 비교 없는 형식)만 — 도면은 위 규칙대로
            dt0 = next((i for i in text_items if i.kind == "FIELD_CHANGED" and str(i.key).split("#", 1)[0] == "DATE"), None) \
                or next(i for i in text_items if _is_date_item(i))
            vals = f" {dt0.old or '없음'} → {dt0.new or '없음'}" if (dt0.old or dt0.new) else ""
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"문서 일자만 갱신됨{vals} · 행 순서만 바뀜 — 값·글자는 같습니다. 확인 대상 아님 (기록만 남깁니다)",
                "내용 비교"))
        # 변경이 있는 날(접히지 않은 날)에는 '일부 쪽은 읽지 못했다'를 따로 싣는다 — 그 쪽의 변경은 빠졌을 수
        # 있다(검토35 A 중간 1). 접힌 날은 위 참고 문구 끝에 붙였으므로 여기서 또 싣지 않는다 (검토35 B 중간 1)
        if _partial and not any(getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == "참고"
                                and "확인 대상 아님" in str(getattr(i, "new", "") or "") for i in items):
            items.append(ChangeItem("CHECK_SKIPPED", "글자 비교", None, _partial[0], "글자 비교 단계"))
        if not moved_from:
            _back = _went_back_note(state, rd, path, new_sha, now_of.get(path), prev_of.get(path))
            if _back:
                rd.went_back[path] = _back[0]
                items.append(ChangeItem("CHECK_SKIPPED", "참고", None, _back[1], "파일 확인"))
        if moved_from:
            # 옮기며 다시 저장만 한 파일(또는 일자만 갱신) — 첫 참고가 '옮겨짐 — 그 판과 비교'라 메일·화면은 진짜 변경으로,
            # DB는 조용한 변경으로 셌다(규칙 둘, 검토42 D 중간 4). 옮김 문구에 그 조용한 사유를 합쳐 한 줄로 — 세 곳이
            # 같은 문구를 읽고 같은 답을 낸다
            import json
            from watcher.brief import is_quiet
            _mv = [i for i in items if getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == "참고"
                   and "그 판과 비교" in str(getattr(i, "new", "") or "")]
            _rest = [i for i in items if i not in _mv]
            _qn = next((i for i in _rest if getattr(i, "kind", "") == "CHECK_SKIPPED"
                        and getattr(i, "key", "") == "참고" and is_quiet(str(i.new or ""))), None)
            if _mv and _qn is not None and State._quiet_items(json.dumps(
                    [{"kind": i.kind, "new": i.new, "where": i.where, "old": i.old} for i in _rest], ensure_ascii=False)):
                items = [ChangeItem("CHECK_SKIPPED", "참고", None, f"{moved_from}에서 옮겨짐 — {_qn.new}", "파일 확인")] \
                    + [i for i in _rest if i is not _qn]
        if items:
            # 글자·그림이 같은 페이지 삭제를 각각 잡은 것은 **여기서** 접는다 — 보고 단계에서
            # 접으면 검토 필요 근거("이번 변경 2건 중 예시: 3페이지 삭제, 2페이지 삭제")가
            # 접기 전 목록으로 만들어졌다 (검토19 2차 감지 ⑦). 접히며 버려진 그림 항목의
            # 사진은 남은 글자 항목으로 옮겨 고아가 되지 않게
            before = {(i.kind, i.key) for i in items if i.kind in ("PAGE_ADDED", "PAGE_REMOVED")}
            items = _dedupe_page_items(items)
            after = {(i.kind, i.key) for i in items if i.kind in ("PAGE_ADDED", "PAGE_REMOVED")}
            for kind in ("PAGE_ADDED", "PAGE_REMOVED"):
                dropped = [k for kd, k in before - after if kd == kind]
                kept = [k for kd, k in after if kd == kind]
                if len(dropped) == 1 and len(kept) == 1:
                    cap = rd.captures.pop((path, f"{kind}|{dropped[0]}"), None)
                    if cap is not None and (path, f"{kind}|{kept[0]}") not in rd.captures:
                        rd.captures[(path, f"{kind}|{kept[0]}")] = cap
            rd.details[path] = items
        if old_doc is not None:
            rd.issues += _revision_issues(state, path, old_doc, new_doc, items, visual_done, new_sha=new_sha, rd=rd)


_VIS_XY = re.compile(r"도면 좌표 \((-?\d+(?:\.\d+)?), (-?\d+(?:\.\d+)?)\)")


def _split_flow(text_items) -> bool:
    """글자 비교가 '쪽 나눔'으로 본 판인가 — 그림 비교가 짝 없는 새 쪽도 옛 쪽과 맞대 보게 (capture.visual_page_diff split)"""
    from watcher.diff import PAGE_FLOW_KEY
    return any(i.kind == "CHECK_SKIPPED" and i.key == PAGE_FLOW_KEY for i in (text_items or []))


def _title_boxes_of(old_doc, new_doc) -> list:
    """두 판의 표제란 틀 범위(DXF 도면 좌표) — 그림 비교가 본문 묶음과 따로 센다."""
    return [list(b) for b in (getattr(old_doc, "title_box", None), getattr(new_doc, "title_box", None))
            if b and len(b) == 4]


def _note_title_frame_only(items: list) -> None:
    """바뀐 것이 전부 표제란 틀 안(그림 변경 '표제란 자리', 본문→표제란 칸 '옮김', 일자)이면 참고를 달아 조용하게 —
    회사 표준 틀로 바꾼 날 'Rev 미갱신'은 없어졌지만 '그림 변경 위치 3곳'으로 메일·미확인에 올랐다 (검토41 S3 중간 3).
    Rev·도면번호·본문 글자·본문 그림이 하나라도 바뀌었으면 달지 않는다."""
    from watcher.diff import TITLE_ZONE, _MOVED_FROM_FIELD, _MOVED_TO_FIELD
    frame = False
    for it in items:
        k, w = it.kind, str(it.where or "")
        if k == "CHECK_SKIPPED" or k == "NEW_REVISION_OF":
            continue
        if k == "PAGE_VISUAL_CHANGED" and TITLE_ZONE in w:
            frame = True
            continue
        if k == "FIELD_CHANGED" and (_MOVED_TO_FIELD in w or _MOVED_FROM_FIELD in w or _is_date_item(it)
                                     or str(it.key).startswith("META:")):
            continue
        return
    if frame and not any(getattr(i, "key", None) == "참고" for i in items):
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                "표제란 틀만 바뀜 — 글자·표·본문 그림은 같습니다 (확인 대상 아님)", "표제란"))


LAYOUT_NOTE = "배치만 바뀜 — 같은 글자·표가 자리만 옮겼거나 쪽 전체가 옮겨졌습니다 (글자·표 같음, 확인 대상 아님)"


def _note_layout_only(items: list) -> None:
    """바뀐 것이 '배치만 바뀜' 그림 변경뿐이면(글자·표·필드·본문 그림 변경 없음) 참고를 달아 조용하게 — 표제란·개정표를 다른 모서리로
    옮기거나 쪽을 살짝 돌려 다시 뽑기만 한 판이 '내용 변경, Rev 미갱신'으로 메일에 올랐다 (2026-10-23 뒤흔들기 C5 정책)."""
    from watcher.diff import LAYOUT_ZONE, content_items
    if not any(it.kind == "PAGE_VISUAL_CHANGED" and LAYOUT_ZONE in str(it.where or "") for it in items):
        return
    if content_items(items) or any(getattr(i, "key", None) == "참고" for i in items):
        return
    # Rev·일자 칸이나 쪽 순서가 바뀐 판은 조용하게 접지 않는다 — 참고 한 줄이 파일 전체를 '그 밖의 알림'으로 보내 Rev를 올린
    # 판이 메일에서 빠졌다(뒤흔들기 B02-144)
    from watcher.diff import TITLE_ZONE
    if any(not (it.kind == "CHECK_SKIPPED"
                or (it.kind == "PAGE_VISUAL_CHANGED" and (LAYOUT_ZONE in str(it.where or "") or TITLE_ZONE in str(it.where or ""))))
           for it in items):
        return
    items.append(ChangeItem("CHECK_SKIPPED", "참고", None, LAYOUT_NOTE, "그림 비교"))


def _mark_title_visuals(old_doc, new_doc, items: list) -> None:
    """표제란 틀 안의 그림 변경에 '표제란 자리' 표식을 단다(제자리 수정) — Rev 판단의 근거에서 빠진다.
    회사 표준 표제란 블록으로 틀만 바꾼 날 틀 자리 픽셀 차이 세 곳이 '내용 변경, Rev 미갱신'으로 팀장
    메일에 올랐고, 그 거짓 이슈가 다음 진짜 'Rev만 갱신'을 눌렀다 (검토39 P1 중간 1)."""
    from watcher.diff import TITLE_ZONE
    boxes = [b for b in (getattr(old_doc, "title_box", None), getattr(new_doc, "title_box", None))
             if b and len(b) == 4]
    if not boxes:
        return
    for n, it in enumerate(items):
        if it.kind != "PAGE_VISUAL_CHANGED" or TITLE_ZONE in str(it.where or ""):
            continue
        m = _VIS_XY.search(str(it.where or ""))
        if not m:
            continue
        x, y = float(m.group(1)), float(m.group(2))
        for x0, y0, x1, y1 in boxes:
            px, py = (x1 - x0) * 0.03, (y1 - y0) * 0.03
            if x0 - px <= x <= x1 + px and y0 - py <= y <= y1 + py:
                items[n] = ChangeItem(it.kind, it.key, it.old,
                                      f"{it.new or ''} — 표제란 틀 안 (Rev 판단에서 제외)".strip(" —"),
                                      f"{it.where} · {TITLE_ZONE}", it.label)
                break


def _went_back_note(state: State, rd, path: str, new_sha, now_rec, prev_rec):
    """옛 판으로 되돌아간 파일의 표지 — ('sha'|'mtime', 참고 문구) 또는 None. 서버를 백업에서 되돌린 날 107개 파일이
    그냥 '수정'으로만 나와 무슨 일이 있었는지 알 수 없었다 (검토42 D 중간 6). 판단이 아니라 사실만 적는다:
    ①지문이 전에 있던 판과 같다 ②저장 시각이 이전보다 과거다(저장하면 지금 시각이 된다 — 옛 파일을 복사해 덮은 흔적)."""
    pv = state.past_version(path, new_sha, getattr(rd, "snapshot_id", None)) if new_sha else None
    if pv:
        seen, came_in = pv
        try:
            when = _local_date_of(seen).strftime("%m-%d")
        except (TypeError, ValueError):
            when = "전"
        return ("sha", f"옛 판으로 되돌아감 — 파일 지문이 {when} 검사 때 들어온 판과 같습니다" if came_in
                else f"옛 판으로 되돌아감 — 파일 지문이 {when} 검사 전까지 있던 판과 같습니다")
    try:
        mt_new = float(getattr(now_rec, "mtime", 0) or 0)
        mt_old = float((prev_rec or (None, None, 0))[2] or 0)
    except (TypeError, ValueError, IndexError):
        return None
    if mt_new and mt_old and mt_new + 60 < mt_old:
        f = "%Y-%m-%d %H:%M"
        return ("mtime", f"저장 시각이 이전보다 과거로 갔습니다 ({datetime.fromtimestamp(mt_old).strftime(f)} → "
                         f"{datetime.fromtimestamp(mt_new).strftime(f)}) — 옛 파일을 복사해 덮어썼을 수 있습니다")
    return None


def _rev_raised_paths(rd) -> set:
    """이번 검사에서 Rev가 **올라간** 파일 — 해소 사유 'Rev를 올림'은 올렸을 때만 (검토47 A 중간 5)."""
    from watcher.diff import is_rev_field
    from watcher.scan import rev_key, rev_shape
    out = set()
    for p, its in (rd.details or {}).items():
        for i in its or []:
            if not is_rev_field(i):
                continue
            o_, n_ = str(i.old or "").strip(), str(i.new or "").strip()
            if not o_ or (rev_shape(o_) == rev_shape(n_) and rev_key(n_) > rev_key(o_)):
                out.add(p)
    return out


def _rev_changed_paths(rd) -> set:
    """이번 검사에서 Rev 칸이 바뀐 파일 — 'Rev가 거꾸로 감'은 Rev가 다시 움직였을 때만 닫는다."""
    from watcher.diff import is_rev_field
    return {p for p, its in (rd.details or {}).items() if any(is_rev_field(i) for i in (its or []))}


def _clock_note(state) -> str | None:
    """PC 시계가 직전 정상 검사보다 30일 넘게 앞서 있으면 메일 맨 위 한 줄 — 화면 배너만 있어 메일만 보는 사람은 '08-23 검사'·
    '44일째'를 설명 없이 받았다 (검토45 C 중간 2)."""
    try:
        rows = state.conn.execute("SELECT run_at FROM snapshots ORDER BY id DESC LIMIT 2").fetchall()
        if len(rows) < 2:
            return None
        suspect = state.get_meta(CLOCK_SUSPECT_KEY)
        base = suspect or rows[1][0]
        gap = datetime.fromisoformat(rows[0][0]) - datetime.fromisoformat(base)
        # 오늘 검사 끝(정리 단계)에 풀릴 날이면 띠를 달지 않는다 — 풀리는 날 메일에 '시계를 맞추라'가 그대로 갔다 (검토46 C 중간 1)
    except (ValueError, TypeError, sqlite3.Error):
        return None
    if gap <= timedelta(days=30):
        return None
    # 며칠 앞섰는지는 밝히지 않는다 — 그 숫자가 시계를 맞춘 척 꾸밀 재료가 됐다 (검토47 E 낮음 1)
    return ("PC 시계가 직전 정상 검사보다 30일 넘게 앞서 있습니다 — 이 메일의 날짜 간격·'N일째'는 시계가 맞을 때까지 믿지 마세요. "
            "오래 쉬었다 켠 것이 아니면 Windows 시계를 맞추고, 시계가 맞다면 감시 PC 화면에서 [시계가 맞습니다]를 누르세요.")


def _missed_days_note(state) -> str | None:
    """직전 검사와 이번 검사 사이에 **평일**이 빠졌으면 메일 맨 위 한 줄 — 창을 안 열고 메일만 받는 집은 예약 검사가
    며칠 돌지 않은 것을 알 길이 없었다 (검토53 G ③). 주말만 빠진 것은 말하지 않는다(주말에 PC를 끄는 회사가 많다)."""
    # 직전 검사는 id 순서가 아니라 **이번 검사 날짜보다 이른 검사 날짜 중 가장 늦은 날** — 시계가 뒤로 간 검사가 끼면 id 순서와
    # 시각 순서가 어긋나, 실제로 검사한 11/2를 '검사가 없었다'고 썼다 (재검토 2026-10-28 R8-2)
    try:
        rows = state.conn.execute("SELECT id, run_at FROM snapshots ORDER BY id DESC LIMIT 400").fetchall()
        if len(rows) < 2:
            return None
        cur = datetime.fromisoformat(rows[0][1]).astimezone().date()
        last = datetime.fromisoformat(rows[1][1]).astimezone().date()
        others = set()
        for _sid, ra in rows[1:]:
            try:
                others.add(datetime.fromisoformat(ra).astimezone().date())
            except (ValueError, TypeError):
                continue
    except (ValueError, TypeError, sqlite3.Error):
        return None
    # 이번 검사가 바로 앞 검사보다 이른 날(시계 역행 그 자체)·같은 날 앞선 검사가 있는 날은 공백이 아니다. 오래전 앞으로 튀었던
    # 미래 날짜 검사는 견주지 않는다(그것 때문에 1년 내내 안내가 꺼지면 안 된다)
    if last >= cur or cur in others:
        return None
    prev = max(d for d in others if d < cur)
    gap = (cur - prev).days
    if gap <= 1 or gap > 30:
        return None                 # 30일 넘게는 시계 경고(_clock_note)가 맡는다
    missed = [prev + timedelta(days=k) for k in range(1, gap) if (prev + timedelta(days=k)).weekday() < 5]
    if not missed:
        return None
    days = ", ".join(f"{d.month}/{d.day}" for d in missed[:5]) + (" 외" if len(missed) > 5 else "")
    # 검사가 돌다 꺼진 날(되돌린 스냅샷)도 여기 든다 — '꺼져 있었다'고만 하면 틀린 말이었다 (검토53 K 낮음 4)
    return (f"지난 평일 {len(missed)}일({days}) 검사가 없었거나 끝나지 못했습니다 — PC가 꺼져 있었거나, 로그인 전이었거나, "
            f"검사 도중 꺼졌습니다. 그 사이 바뀐 것은 이번 메일에 모았습니다.")


_WENT_BACK_MIN = 10      # 한 검사에서 이만큼 넘게 되돌아가면 '서버를 되돌린 날'로 요약 한 줄


def _rollback_note(rd, paths: set, issues: list) -> str | None:
    """되돌림이 많은 날 프로젝트 메일 맨 위 한 줄 — 담당자에게 필요한 것은 '백업 이후 작업분이 사라졌나'다."""
    wb = getattr(rd, "went_back", {}) or {}
    if len(wb) < _WENT_BACK_MIN:
        return None
    mine = [p for p in paths if p in wb]
    if not mine:
        return None
    n_sha = sum(1 for p in mine if wb[p] == "sha")
    n_mt = len(mine) - n_sha
    moved_old = {v[0] for v in (rd.moved or {}).values()}
    gone = sum(1 for c in rd.changes if c.kind == "removed" and c.path in paths and c.path not in moved_old)
    down = sum(1 for i in issues if getattr(i, "code", "") == "REV_REGRESSED")
    # 0인 갈래는 빼고 쓴다 — '저장 시각이 과거로 0개'가 '시각은 정상'으로 읽혔다(지문으로 먼저 분류됐을 뿐) (검토44 C 낮음 2)
    _why = " · ".join(x for x in ((f"전에 있던 판과 지문이 같음 {n_sha}개" if n_sha else ""),
                                  (f"저장 시각만 과거로 감 {n_mt}개" if n_mt else "")) if x)
    parts = [f"이 프로젝트 파일 {len(mine)}개가 옛 판으로 돌아간 것으로 보입니다" + (f" ({_why})" if _why else "")]
    if down:
        parts.append(f"Rev가 내려간 파일 {down}개")
    if gone:
        parts.append(f"사라진 파일 {gone}개")
    return (" · ".join(parts) + ". 서버나 폴더를 백업에서 되돌렸다면, 백업 이후 작업분(사라진 파일·내려간 Rev)을 "
            "되살려야 하는지 확인하세요 — 아래 각 파일의 '옛 판으로 되돌아감' 표지가 근거입니다.")


REV_UNCHECKED_KEY = "Rev 검사"


def _rev_unchecked_note(new_doc, items: list) -> None:
    """내용이 바뀌었는데 표제란 칸 라벨은 있고 값을 못 짝지었거나(검토20 r07 1) 글꼴 대응표가 없어 표제란 글자를 못 읽은(r07 2)
    PDF는 Rev 검사가 소리 없이 꺼졌다 — 그 사실을 참고 한 줄로 남긴다(원칙 4). 표제란이 아예 없는 문서에는 달지 않는다."""
    if new_doc is None or getattr(new_doc, "fields", None) or getattr(new_doc, "doc_type", "") != "pdf":
        return
    from watcher.extract.pdf import REV_UNPAIRED_NOTE
    why = next((str(n) for n in (new_doc.notes or []) if str(n) == REV_UNPAIRED_NOTE or "ToUnicode" in str(n)), None)
    if why is None:
        return
    from watcher.diff import content_items
    if not content_items(items) or any(getattr(i, "key", "") == REV_UNCHECKED_KEY for i in items):
        return
    items.append(ChangeItem("CHECK_SKIPPED", REV_UNCHECKED_KEY, None,
                            "Rev 검사 못 함 — " + why.split(" — ", 1)[-1].split(": ", 1)[-1], "Rev 검사"))


REV_DATE_KEY = "확인 필요"       # Rev 올림 변경 행의 '일자 그대로' 표지 (J7)


def _rev_date_note(path: str, old_doc, new_doc, items: list, issues: list) -> None:
    """Rev를 올렸는데 표제란 일자(또는 개정표 최신 행 일자)가 그대로면 그 변경 행에 '확인 필요 — Rev A→B로 올렸지만 일자는 그대로
    (2026-10-01)' 표지를 단다 (기능 검토 2026-11-02 J7). 근거(구·신 일자와 위치)를 같은 줄에 싣는다(원칙 4)."""
    if old_doc is None or new_doc is None or any(getattr(i, "code", "") == "REV_REGRESSED" for i in issues):
        return
    from watcher.consistency import rev_date_unchanged
    from watcher.diff import is_rev_field
    rc = next((i for i in items if is_rev_field(i) and "#" not in str(getattr(i, "key", ""))), None) \
        or next((i for i in items if is_rev_field(i)), None)
    try:
        ds = rev_date_unchanged(path, old_doc, new_doc, rc, items)
    except Exception:
        ds = None
    if ds is None or any(getattr(i, "key", "") == REV_DATE_KEY for i in items):
        return
    items.append(ChangeItem("CHECK_SKIPPED", REV_DATE_KEY, None,
                            ds.message.rstrip(".") + " — " + " · ".join(str(e) for e in ds.evidence[1:]), "Rev 검사"))


REV_CHECK_DAYS_DEFAULT = 7       # 설정 rev_check_days가 없을 때 — 첫 편집 유예 창(일). 0이면 첫 편집부터 경고(옛 동작)
FIRST_EDIT_MARK = "첫 편집이라 참고로만 남깁니다"     # 저장된 상세에서 '첫 편집 유예를 썼다'를 찾는 표식 (state.first_edit_pending)


def rev_check_days(cfg: dict | None) -> int:
    """첫 편집 유예 창(일). 설정 값이 이상하면 기본값 — 잘못 적은 한 줄이 검사를 죽이지 않게."""
    v = (cfg or {}).get("rev_check_days")
    if v is None or v == "":
        return REV_CHECK_DAYS_DEFAULT
    try:
        return max(0, min(365, int(v)))
    except (TypeError, ValueError):
        return REV_CHECK_DAYS_DEFAULT


def _first_edit_grace(state: State, path: str, new_doc, items, issues, rd=None):
    """'Rev 미갱신'의 첫 편집 유예 (기능 검토 2026-11-02 J1) — 발행 전 작업본을 몇 주 고치는 현장에서 첫 편집마다 경고가 났다
    (실사용 검토 필요의 19%, 문구 스스로 '작업본이면 무시'). 한 파일의 'Rev 그대로 내용 변경'은 처음엔 참고로만 남기고, 그 뒤
    rev_check_days일 안에 Rev가 안 오르고 **또** 바뀌면 검토 필요로 올린다. 출도(발행) 폴더 안의 파일, 이미 열린 'Rev 미갱신',
    Rev 올림 뒤 유예를 이미 쓴 파일('다음에 또 바뀔 때 경고')은 지금처럼 바로 경고한다."""
    cfg = getattr(rd, "cfg", None) or {}
    days = rev_check_days(cfg)
    code = "CONTENT_CHANGED_REV_SAME"
    if days <= 0:
        return issues
    from watcher.issued import in_issued_folder
    if in_issued_folder(path, cfg):
        out = []
        for i in issues:
            if i.code == code:
                i = Issue(i.code, i.path, i.message, tuple(i.evidence) + (
                    "출도(발행) 폴더 안의 파일이라 첫 편집부터 경고합니다",))
            out.append(i)
        return out
    if state.has_open_issue(path, code, recent_days=0):
        return issues                       # 이미 열린 이슈는 그대로 — 근거를 쌓고 '재검출되지 않음'으로 닫히지 않게
    # 오늘 이름·폴더를 바꾸며 고친 파일은 옛 경로의 유예를 이어 본다 (재검토 rr066 judge 5)
    _mv = (getattr(rd, "moved", None) or {}).get(path) if rd is not None else None
    prev = state.first_edit_pending(path, days, prev=_mv[0] if _mv else None)
    if prev is not None:
        _cid, _at, _kind = prev
        try:
            _when = datetime.fromisoformat(_at).astimezone().strftime("%m-%d")
        except (TypeError, ValueError):
            _when = "앞서"
        # 유예는 Rev가 바뀔 때까지 파일당 한 번 — 며칠 뒤든 Rev 없이 또 바뀌면 바로 검토 필요 (재검토 rr066 judge 6)
        _line = (f"앞선 편집({_when}, 변경 #{_cid})은 Rev 올림 뒤 후속 편집으로 넘겼고 Rev 없이 또 바뀌었습니다" if _kind == "bump"
                 else f"첫 편집({_when}, 변경 #{_cid})은 참고로 넘겼고 그 뒤 Rev 없이 또 바뀌었습니다")
        return [Issue(i.code, i.path, i.message, tuple(i.evidence) + (_line,)) if i.code == code else i for i in issues]
    _now_rev = new_doc.revision if new_doc is not None else None
    items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                            f"Rev{' ' + str(_now_rev) if _now_rev else ''} 그대로 내용이 바뀌었습니다 — {FIRST_EDIT_MARK} "
                            f"(발행 전 작업본일 수 있음). Rev를 올리지 않고 또 바뀌면 바로, 더 바뀌지 않아도 {days}일 뒤 "
                            f"Rev가 그대로면 '검토 필요'로 올립니다",
                            "Rev 검사"))
    return [i for i in issues if i.code != code]


FIRST_EDIT_HORIZON_DAYS = 120    # 첫 편집 뒤 이만큼 지난 유예는 더 보지 않는다(날마다 훑는 양의 상한). 그 전에 검사가 한 번이라도 돌면 열린다


def _first_edit_overdue(state: State, rd) -> list:
    """첫 편집 유예 뒤 rev_check_days일이 지나도록 Rev가 그대로인 파일의 '검토 필요' (재검토 rr066 judge 6, DECISIONS 2026-11-02
    J1 개정). 유예 창이 '또 바뀔 때'만 경고해, 한 번 고치고 그대로 출도·발주로 가는 파일은 영영 참고로만 남았다(dog10 기본 설정
    day5 E-101·BOM_전장). '하루 늦게'(최대 days일)는 받아들이되 '영영'은 없다. 파일이 지워졌거나 보관 폴더로 갔거나 새 판으로
    대체됐거나 Rev를 올렸거나, 그 뒤 'Rev 미갱신'이 이미 열렸던(닫힘 포함) 파일은 열지 않는다. 오늘 바뀐 파일은 오늘 판정이 맡는다.
    근거: 첫 편집의 구/신 값·위치, 첫 편집 변경 #번호."""
    cfg = getattr(rd, "cfg", None) or {}
    days = rev_check_days(cfg)
    if days <= 0 or getattr(rd, "is_baseline", False) or rd.snapshot_id is None:
        return []
    from watcher.consistency import _OLD_FOLDER as _OLDF, _fmt_item
    from watcher.diff import content_items
    from watcher.issued import in_issued_folder
    from watcher.project import in_quiet_folder
    code = "CONTENT_CHANGED_REV_SAME"
    now = datetime.now(timezone.utc)
    graces = state.first_edit_graces((now - timedelta(days=days + FIRST_EDIT_HORIZON_DAYS)).isoformat(),
                                     (now - timedelta(days=days)).isoformat())
    if not graces:
        return []
    present = {r.path for r in (rd.records or ())}
    today = {c.path for c in (rd.changes or ())} | {old for old, _s, _x in (getattr(rd, "moved", None) or {}).values()}
    done = {i.path for i in (rd.issues or ()) if i.code == code}
    superseded = set(rd.__dict__.get("superseded") or ())
    out = []
    for cid, gpath, at in graces:
        # 그 자리에 그대로 있으면 옮겨 다닌 길을 찾지 않는다(대부분) — 없어진 경로만 그 뒤 변경에서 새 경로를 찾는다
        cur = gpath if gpath in present else state.path_successor(gpath, since=str(at or ""))
        if cur in today or cur in done or cur not in present or cur in superseded:
            continue
        if _OLDF.search(cur) or in_quiet_folder(cur, rd.labels) or in_issued_folder(cur, cfg):
            continue
        lineage = state.path_lineage(cur)
        if gpath not in lineage:
            lineage.append(gpath)
        if state.has_open_issue(cur, code, recent_days=0) or state.rev_same_issue_since(lineage, at) \
                or state.rev_bumped_after(lineage, cid):
            continue
        # 같은 파일의 더 나중 유예가 있으면 그것이 이 주기의 첫 편집이다(Rev 올림 뒤 새 주기) — 위 rev_bumped_after가 걸러 준다
        det = state.change_detail(cid) or {}
        raw = [i for i in (det.get("items") or []) if isinstance(i, dict)]
        note = next((str(i.get("new") or "") for i in raw if FIRST_EDIT_MARK in str(i.get("new") or "")), "")
        m = re.match(r"^Rev (.+?) 그대로 내용이", note)
        doc = None
        try:
            doc = rd.docs.get(cur)
        except Exception:
            doc = None
        rev = (m.group(1) if m else None) or (getattr(doc, "revision", None) if doc is not None else None) or "-"
        try:
            when = datetime.fromisoformat(at).astimezone().strftime("%m-%d")
            n_days = max(days, (now - datetime.fromisoformat(at)).days)
        except (TypeError, ValueError):
            when, n_days = "앞서", days
        # check_revision과 같은 이름 — 이슈 대조 키(문구 뼈대)가 같아야 다음 편집 때 같은 카드로 이어진다
        _rf = (getattr(doc, "fields", None) or {}).get("REV") if doc is not None else None
        _w = str(getattr(_rf, "where", "") or "")
        zone = ("표제란" if PurePosixPath(cur).suffix.lower() not in (".xlsx", ".xlsm", ".docx", ".hwpx")
                else "개정표" if "개정이력" in _w else "바닥글" if _w.startswith("바닥글")
                else "머리글" if _w.startswith("머리글") else "문서 머리")
        items = []
        for i in raw:
            try:
                items.append(ChangeItem(str(i.get("kind") or ""), str(i.get("key") or ""), i.get("old"), i.get("new"),
                                        str(i.get("where") or ""), i.get("label")))
            except Exception:
                continue
        content = content_items(items)
        ev = [f"{n_days}일째 Rev {rev} 그대로 — 첫 편집({when}, 변경 #{cid})은 참고로 넘겼고 그 뒤 Rev를 올리지 않았습니다",
              (f"첫 편집 변경 #{cid}의 {len(content)}건 중 예시:" if len(content) > 1 else f"첫 편집 변경 #{cid}:")]
        ev += [_fmt_item(i) for i in content[:5]] or ["(변경 상세에 글자·표 변경 없음 — 그림 변경일 수 있습니다)"]
        if cur != gpath:
            ev.append(f"그 뒤 옮겨짐 — 첫 편집 때 경로: {gpath}")
        out.append(Issue(code, cur,
                         f"내용이 바뀌었는데 {zone} Rev가 {rev} 그대로입니다. ({n_days}일째 Rev 그대로 — 검토 필요. "
                         f"발행 전 작업본이면 무시하세요 — 발행 시 Rev를 올리면 해소됩니다)", tuple(ev)))
        done.add(cur)
    if out:
        print(f"첫 편집 뒤 {days}일이 지나도록 Rev가 그대로인 파일 {len(out)}개 — 검토 필요로 올립니다")
    return out


def _revision_issues(state: State, path: str, old_doc, new_doc, items, visual_checked, new_sha=None, rd=None):
    """check_revision + 억제 규칙. 'Rev 미갱신'을 지적받고 다음 날 Rev를 올리면 '자동 해소'
    직후 'Rev만 갱신' 경고가 새로 뜨던 것 (2026-09-05 전체 검토, 판매 위험 1순위) —
    ①이 파일에 열린 'Rev 미갱신' 이슈가 있었거나 ②리비전 행에 개정 사유가 적혔으면
    'Rev만 갱신'은 경고가 아니라 정상 개정이다."""
    # 표제란 자리 표식은 그림 비교(capture)가 묶음 **전체**로 단다 — 여기서 중심점으로 다시 달면 틀 안으로 들어간 본문
    # 배선까지 표제란 자리가 됐다 (검토42 B 중간 6). _mark_title_visuals는 옛 기록(표식 없는 상세)용으로만 남긴다
    _note_title_frame_only(items)
    _note_layout_only(items)
    issues = check_revision(path, old_doc, new_doc, items, visual_checked=visual_checked)
    _rev_unchecked_note(new_doc, items)
    _rev_date_note(path, old_doc, new_doc, items, issues)
    # 보관 폴더(old·구판·백업·보관) 안 파일의 편집은 변경으로 기록만 하고 Rev 경고는 내지 않는다 — 그 폴더로 옮긴 파일의 열린
    # 검토 필요는 '보관 폴더로 옮겨짐'으로 닫으면서, 그 안에서 고친 파일에는 'Rev 미갱신'을 새로 열었다 (검토20 r12 5)
    from watcher.consistency import _OLD_FOLDER as _OLDF
    if issues and _OLDF.search(path):
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                "보관 폴더(old·구판·백업) 안 파일이라 Rev 검사 경고는 내지 않습니다 — 변경 사실은 기록합니다",
                                "Rev 검사"))
        return []
    # ③ 오늘 앞서 Rev를 올린 파일의 후속 편집 — 같은 날 계속 작업하는 것을 'Rev 미갱신'이라
    # 부르면 오탐이다 (파일럿 모의 ⑧). 내일도 Rev가 그대로면 그때 경고한다
    _bump = state.rev_bumped_recently(path) if any(i.code == "CONTENT_CHANGED_REV_SAME" for i in issues) else None
    if _bump:
        try:
            _d = datetime.fromisoformat(_bump.at).astimezone()
            # 문장째 저장되므로 '오늘 앞서·어제' 같은 상대어를 쓰지 않는다 — 며칠 뒤 보면 '어제'가 거짓이었다 (검토49 C 중간 7)
            _when = f"{_d.strftime('%m-%d %H:%M')} 검사에서"
        except (TypeError, ValueError):
            _when = "앞서"
        # 무엇이 무엇으로 올랐는지 적는다 — 'Rev 미갱신을 내지 않기로 했다'는 판정에 근거가 하나도
        # 없었다 (검토34 A 1, 원칙 4)
        _rev_txt = (f" Rev {_bump.old}→{_bump.new}를" if _bump.old and _bump.new else " Rev를")
        _now_rev = new_doc.revision if new_doc is not None else None
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                f"{_when}{_rev_txt} 올린 파일의 후속 편집으로 봅니다 — 'Rev 미갱신' 경고는 "
                                "하지 않습니다 (이 파일이 다음에 또 바뀔 때 Rev가 그대로면 경고)"
                                + (f" · 지금 Rev {_now_rev}" if _now_rev else "")
                                + f" · 그때 변경 #{_bump.change_id}", "Rev 검사"))
        issues = [i for i in issues if i.code != "CONTENT_CHANGED_REV_SAME"]
    # 열린 'Rev 미갱신'을 만든 편집이 되돌려져 파일이 그 전 판과 **바이트까지** 같아졌다 — 되돌림도 '내용 변경, Rev
    # 그대로'라 같은 이슈가 계속 열려 되돌린 방향의 근거가 붙었다 (검토42 D 중간 2). 해시가 같을 때만(글자만 같으면
    # 그림 변경을 놓칠 수 있다)
    def _same_as_pre_issue() -> bool:
        pre = state.pre_issue_sha(path, "CONTENT_CHANGED_REV_SAME")
        if not pre:
            return False
        if pre == new_sha:
            return True
        # 문서류(엑셀·워드·한글)는 글자·표가 비교의 전부다 — 옛 값을 **다시 입력해** 되돌리면 바이트가 달라 닫히지 않고
        # 되돌린 방향의 근거가 쌓였다 (검토43 B 중간 3). 그림을 비교하는 도면은 지금처럼 바이트가 같을 때만
        if PurePosixPath(path).suffix.lower() in VISUAL_EXTS or new_doc is None:
            return False
        pre_dict = state.load_extract(pre, path)    # 묶음 열쇠 (S1)
        if not pre_dict or pre_dict.get("extract_failed") or not _compare_ok(pre_dict, path):
            return False
        try:
            from watcher.diff import content_items as _ci
            pre_doc = _old_doc(pre_dict, new_doc, path)
            d_ = diff_documents(pre_doc, new_doc)
            return not _ci(d_) and not any(getattr(x, "kind", "") == "FIELD_CHANGED" and str(x.key).split("#")[0] == "REV"
                                           for x in d_)
        except Exception:
            return False
    if new_sha and any(i.code == "CONTENT_CHANGED_REV_SAME" for i in issues) and _same_as_pre_issue():
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                "앞서 'Rev 미갱신'이 잡힌 편집이 되돌려져, 파일이 그 편집 전 판과 같아졌습니다 — "
                                "경고를 닫습니다", "Rev 검사"))
        state.revert_why = {**state.revert_why,           # 클래스 기본값(빈 dict)을 건드리지 않게 새 dict로
                            (path, "CONTENT_CHANGED_REV_SAME"): "자동 해소 — 편집이 되돌려짐(그 편집 전 판과 같음)"}
        issues = [i for i in issues if i.code != "CONTENT_CHANGED_REV_SAME"]
    if any(i.code == "CONTENT_CHANGED_REV_SAME" for i in issues) \
            and any(it.kind == "REVROW_ADDED" for it in items):
        # 개정이력에 새 행이 붙었는데 REV 필드가 못 따라온 경우(엑셀 개정이력이 위가 최신인 양식 등)
        # — 자기 근거(리비전 행 추가)가 자기 결론(Rev 그대로)을 부정하는 메일이 됐다 (검토25 감지 6-4)
        # 같은 파일에 '표제란 Rev ≠ 개정표'(표제란 Rev를 올리지 않았을 수 있습니다)가 함께 나면 이 참고는 그 경고를 부정한다 —
        # 'Rev 미갱신으로 보지 않습니다'와 'Rev를 올리지 않았을 수 있습니다'가 한 파일에 나란히 실렸다 (검토71 R4 중간 3). 그때는
        # 개정표 경고가 말하므로 참고를 싣지 않는다(Rev 미갱신은 같은 사실을 두 번 말하지 않게 그대로 뺀다)
        if not any(i.code == "REV_BLOCK_MISMATCH" for i in issues):
            items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                    "개정표에 새 행이 추가됐습니다 — Rev 미갱신으로 보지 않습니다", "Rev 검사"))
        issues = [i for i in issues if i.code != "CONTENT_CHANGED_REV_SAME"]
    if any(i.code == "CONTENT_CHANGED_REV_SAME" for i in issues):
        issues = _first_edit_grace(state, path, new_doc, items, issues, rd)
    rev_only = [i for i in issues if i.code == "REV_CHANGED_CONTENT_SAME"]
    if not rev_only:
        return issues
    why = None
    # 지금 **열린** Rev 미갱신(같은 검사의 개정)이거나, 마지막 Rev 미갱신 뒤로 아직 Rev를 안 올렸을 때만 — 닫힌 지 14일 창이
    # 남아 있어 정식 개정(A→B) 뒤의 진짜 'Rev만 올림'(B→C)까지 묻혔다 (검토51 A 중간 1)
    if state.has_open_issue(path, "CONTENT_CHANGED_REV_SAME", recent_days=0) or state.unrevised_pending(path):
        why = "앞선 내용 변경(열려 있던 'Rev 미갱신')을 이번에 개정한 것으로 봅니다"   # '지적을 반영해'는 설계자의 발행 주기를 도구가 시킨 일로 적었다 (검토39 P1 낮음 4)
    else:
        # 같은 값으로 지워졌다 다시 붙은 행(행 이름표가 바뀌어 옛 행이 삭제+추가로 나간 것)은 이번 개정의 사유가 아니다 — 재추가된
        # 옛 행 'A 최초 발행'의 사유로 사유 빈칸인 새 C행의 'Rev만 갱신' 경고가 지워졌다 (대량 시험 XLSX F4, 2026-10-20)
        _gone = {str(it.old) for it in items if it.kind == "REVROW_REMOVED" and it.old}
        for it in items:
            if it.kind == "REVROW_ADDED" and str(it.new) not in _gone:
                # xlsx·docx 개정이력의 사유 열은 '내용'·'사유'·'비고'가 흔하다 (검토25 감지 6-5)
                m = (re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*'([^']*)'",
                               str(it.new), re.IGNORECASE)
                     or re.search(r"(?:DESCRIPTION|REMARKS?|내용|사유|개정\s*내용|변경\s*내용|비고)'?\s*[:=]\s*([^,}]+)",
                                  str(it.new), re.IGNORECASE))
                desc = (m.group(1).strip() if m else "")
                if desc and re.search(r"[A-Za-z0-9가-힣]", desc):    # '-'·'.' 같은 구분자만이면 사유 아님
                    why = f"개정표 행에 개정 사유가 있습니다: {desc[:60]}"
                    break
    if why is None:
        return issues
    items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                            f"Rev가 올라갔고 글자 변경은 없습니다 — {why}. 경고하지 않습니다",
                            "Rev 검사"))
    return [i for i in issues if i.code != "REV_CHANGED_CONTENT_SAME"]


def find_prev_version(state: State, key: str):
    """현재 스냅샷에서 key 파일의 '이전 판'. 사람이 직접 지정한 짝이 있으면
    그것이 자동 규칙(같은 폴더·확장자·stem, 더 오래된 것)보다 우선한다 —
    재비교·나란히 보기·이전 판 열기가 전부 이 함수를 쓰므로 한 곳에서 일괄 적용
    (2026-08-29). 돌려주는 값: (prev_key, prev_sha, 실패사유) — 실패 시 앞 둘은 None."""
    rows = state._latest_rows()
    if key not in rows:
        return None, None, "이 파일이 현재 감시 목록에 없습니다 (삭제되었거나 폴더가 바뀜)."
    mp = state.manual_pair(key)
    if mp and mp["prev_key"] in rows:
        return mp["prev_key"], rows[mp["prev_key"]][0], ""
    # 지정된 판이 감시 목록에서 사라졌으면 자동 규칙으로 폴백
    my_sha, _sz, my_mt = rows[key]
    p = PurePosixPath(key)
    stem, ext = pair_key(p.name), p.suffix.lower()
    sibs = [(k, r) for k, r in rows.items()
            if k != key
            and PurePosixPath(k).parent == p.parent
            and PurePosixPath(k).suffix.lower() == ext
            and pair_key(PurePosixPath(k).name) == stem
            and (r[2], k) < (my_mt, key)]
    if not sibs:
        return None, None, ("같은 폴더에서 이전 판을 찾지 못했습니다 — 날짜·버전 "
                            "표기를 뺀 파일 이름이 같아야 하고, 이 파일보다 "
                            "수정시각이 오래된 판이 있어야 합니다.")
    prev_key, (prev_sha, _s2, _m2) = max(sibs, key=lambda kv: (kv[1][2], kv[0]))
    return prev_key, prev_sha, ""


def recompare_change(state: State, change_id: int, abs_of_key,
                     sensitive: bool = False) -> tuple[bool, str]:
    """소급 재비교 — 과거에 짝지어지지 못한 변경(기준선 등록분, 구버전에서 놓친 판)을
    현재 폴더의 이전 판과 비교해 상세를 채운다 (2026-08-27 사용자 문제: 여러 판 중
    일부만 비교됨). abs_of_key: 경로 키 → 실제 Path. 돌려주는 값: (성공, 메시지)."""
    from dataclasses import asdict

    from watcher.capture import capture_pair, visual_page_diff

    ch = state.get_change(change_id)
    if ch is None:
        return False, "변경을 찾을 수 없습니다."
    key = ch.path
    prev_key, prev_sha, why = find_prev_version(state, key)
    if prev_key is None:
        return False, why
    my_sha = state._latest_rows()[key][0]
    p = PurePosixPath(key)
    ext = p.suffix.lower()
    new_abs, prev_abs = abs_of_key(key), abs_of_key(prev_key)
    if new_abs is None or prev_abs is None:
        return False, "파일에 접근할 수 없습니다 (잠김 또는 권한)."

    def _doc(sha, ap):
        d = state.load_extract(sha, key)
        if d is not None and "notes" in d and _cache_ok(d, ap):
            return Document.from_dict(d)
        if ext == ".dwg":
            return None          # DWG는 검사 때 변환한 기록만 쓴다 (없으면 글자 비교 생략)
        doc = extract(ap)
        state.save_extract(sha, {**doc.to_dict(), "cache_ver": _CACHE_VER}, key)
        return doc

    try:
        old_doc, new_doc = _doc(prev_sha, prev_abs), _doc(my_sha, new_abs)
    except Exception as e:
        return False, f"내용 추출 실패: {e}"

    mp = state.manual_pair(key)
    how = ("사람 지정 짝" if mp and mp["prev_key"] == prev_key
           else "파일명 짝짓기")
    items = [ChangeItem("NEW_REVISION_OF", "이전 판",
                        PurePosixPath(prev_key).name, p.name,
                        f"{how} — 소급 재비교")]
    caps: dict = {}
    if old_doc is None or new_doc is None:
        note = DWG_NO_CONVERTER
    else:
        note = unreadable_note(old_doc, new_doc)
    text_items = _safe_diff(old_doc, new_doc, key) if not note else []
    masks = _changed_texts(old_doc, new_doc) if not note else set()
    boxes = _changed_boxes(old_doc, new_doc) if not note else []
    if ext == ".dwg":                       # 그림은 기록끼리 (파일을 직접 못 그린다)
        prev_abs, new_abs = state.load_renders(prev_sha), state.load_renders(my_sha)
    if ext in VISUAL_EXTS:
        vis = (visual_page_diff(prev_abs, new_abs, sensitive=sensitive, ignore_texts=masks, ignore_boxes=boxes,
                                title_boxes=_title_boxes_of(old_doc, new_doc), split=_split_flow(text_items))
               if prev_abs is not None and new_abs is not None else None)
        if vis is None:
            items.append(ChangeItem(
                "CHECK_SKIPPED", "시각 비교", None,
                "수행 못 함: 페이지 렌더 실패 또는 그림 기록 없음 — 텍스트 변경만 비교함",
                "시각 비교 단계"))
        else:
            for k, where in vis[0]:
                items.append(ChangeItem(
                    "PAGE_VISUAL_CHANGED", k, None, _visual_note(where), where))
            for k, cap in vis[1].items():
                caps[f"PAGE_VISUAL_CHANGED|{k}"] = cap
    if note:
        items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                f"수행 못 함: {note}", "추출 단계"))
    else:
        items += text_items
        n = 0
        for it in items:  # 텍스트 변경 위치 캡처 (파일당 4장 제한)
            if n >= CAPTURE_PER_FILE:
                break
            if it.kind == "TEXT_CHANGED" and it.new:
                cap = capture_pair(new_abs, it.new, prev_abs, it.old)
            elif it.kind == "TEXT_ADDED" and it.new:
                cap = capture_pair(new_abs, it.new, prev_abs, None)
            else:
                continue
            if cap:
                _ck = f"{it.kind}|{it.key}"
                if _ck in caps:          # 같은 키가 여럿이면 자리까지 붙인다 (검토19 브리핑 ④)
                    _ck = f"{_ck}|{it.where}"
                caps[_ck] = cap
                n += 1
    state.save_change_details(change_id, [asdict(i) for i in items], caps)
    n_content = sum(1 for i in items if i.kind != "NEW_REVISION_OF")
    mode = " (민감 모드 — 미세 변경까지, 오탐은 [오탐 삭제]로 정리)" if sensitive else ""
    return True, (f"이전 판({PurePosixPath(prev_key).name})과 다시 비교했습니다 — "
                  f"항목 {n_content}건.{mode}")


# 파일 하나에서 사진을 만들 변경 항목 수 상한.
#
# 원래 4였다. 사용자가 "각 변경사항마다 한 장씩 각각 다 붙여야지", 이어서
# "100장이 바꼈을수도 있는거 아니야? 문제가 뭔데"라고 물어 실제 비용을 쟀다.
# 상한이 필요했던 이유는 **내 비효율**이었지 진짜 한계가 아니었다:
#   - 사진마다 도면 전체를 다시 그렸다        → 파일 단위로 한 번만 (캐시)
#   - 사진마다 DXF 파일을 다시 파싱했다       → 글자 목록도 파일 단위로 한 번만
# 실측(엔티티 2만 개 DXF): 장당 0.93초 → **0.003초** (310배). 이제 파일당 첫 장의
# 렌더(3.3초)가 비용의 거의 전부라, 항목이 5건이든 100건이든 시간이 같다.
#   도면 100장 × 항목  20건 = 사진 2,000장  → 5.5분,  12MB/일 (90일 1.1GB)
#   도면 100장 × 항목 100건 = 사진 10,000장 → 6.0분,  60MB/일 (90일 5.3GB)
# 남은 제약은 시간이 아니라 저장 공간이고, 그건 보존 기간 설정과 설정 화면의
# 용량 표시가 다룬다. 그래서 상한을 사실상 없앤다 — 아래 값은 한 파일이 수천 건
# 바뀐 병적인 날에만 걸리는 안전판이고, 걸리면 조용히 자르지 않고 알린다.
CAPTURE_PER_FILE = 500

# 기준선(첫 검사)에서 그림 비교를 해줄 도면 쌍 수 — 첫날 체감과 소요 시간의 절충
BASELINE_VISUAL_PAIRS = 30


# 프로젝트가 아니라 '공용 서랍'인 폴더 이름 — 교차 검사 묶음으로 쓰지 않는다
_COMMON_FOLDERS = {"공용", "공통", "참고", "참고자료", "표준", "양식", "템플릿", "개인", "임시", "기타",
                   "COMMON", "SHARED", "REFERENCE", "TEMPLATE", "TEMP", "ETC", "MISC"}


# 윈도우 복사본·빈 파일처럼 "변경이 아니라 부산물"인 것들을 알아본다
# (2026-09-01 처음 쓰는 사람 관점 점검: 'ㅇㅇ - 복사본.pdf'가 새 도면처럼 보고됨)
# 윈도우 사본은 '(2)'부터 — '(1)'은 시트다 (consistency._COPY_MARK_RE와 같은 규칙, 검토32 B1)
# 동기화 충돌 사본(OneDrive '(충돌 사본 날짜)'·Dropbox '(… conflicted copy …)')도 사본이다 — 옛 내용의 충돌 사본이 원본의 '새 판'·
# 도면 간·도면-BOM 불일치를 만들었다 (검토59 F6-2)
_COPY_MARK = re.compile(r"(- ?복사본|\((?:[2-9]|\d{2,})\)|\s-\s*copy|copy of |\([^()]*(?:충돌 사본|conflicted copy|-conflict-|conflict \d{4}-\d{2}-\d{2})[^()]*\))", re.IGNORECASE)


def _nfc(s: str) -> str:
    """맥에서 올린 이름(NFD)도 같은 이름으로 (검토66 B4)."""
    import unicodedata
    return unicodedata.normalize("NFC", s)


def _side_note(rd: RunData, c) -> str:
    """이 변경이 복사본·빈 파일 같은 부산물이면 한 줄 설명, 아니면 빈 문자열."""
    name = PurePosixPath(c.path).name
    ap = rd.abs_of.get(c.path)
    try:
        size = ap.stat().st_size if ap else None
    except OSError:
        size = None
    if size == 0:
        return "빈 파일(0바이트)입니다 — 저장이 덜 됐거나 잘못 만들어진 파일일 수 있습니다"
    if _COPY_MARK.search(name):
        same = [p for p, r in rd.prev_files.items()
                if r[0] == c.new_sha256 and p != c.path]
        # 오늘 고친 원본의 사본은 원본이 직전 스냅샷과 내용이 달라 '원본 없음'이라 했다 — 지금 파일들도 본다 (검토58 F5-2)
        same += [r.path for r in (rd.records or ()) if r.sha256 == c.new_sha256 and r.path != c.path and r.path not in same]
        if same:
            return (f"내용이 {PurePosixPath(same[0]).name} 와 같은 복사본입니다 — "
                    f"실제 개정이 아닐 수 있습니다")
        return "파일명은 사본 꼴인데 같은 내용의 원본이 없습니다 — 실제 개정인지 확인해주세요"
    # '(1)'은 시트 번호일 수 있어 사본 표기에서 뺐다 — 다만 같은 폴더에 '(1)'만 뗀 이름의 **같은 내용** 파일이 있으면 윈도우
    # 사본이다. '추가'로 메일이 나가 소음 메일의 절반이었다 (검토66 B2)
    _m1 = re.match(r"^(.*?)\s*\(1\)(\.[^.]+)?$", name)
    if _m1 and c.new_sha256:
        _orig = (PurePosixPath(c.path).parent / (_m1.group(1) + (_m1.group(2) or ""))).as_posix()
        if any(r.path == _orig and r.sha256 == c.new_sha256 for r in (rd.records or ())):
            return (f"내용이 {PurePosixPath(_orig).name} 와 같은 복사본입니다 — "
                    f"실제 개정이 아닐 수 있습니다")
    # 옛 판을 old/·보관 폴더에 같은 이름으로 넣어 둔 것 — 내용이 그 이름 파일의 **지난 판**과 같고 원본은 남아 있다.
    # '추가 · 도면 E-101 Rev A'로 오늘 확인할 것에 올라, 같은 메일에 E-101이 '수정 Rev B'와 나란히 실렸다 (경우100 A19)
    if c.kind == "added" and c.new_sha256:
        idx = rd.__dict__.get("_prev_by_sha")
        if idx is None:
            idx = {}
            for p, r in rd.prev_files.items():
                idx.setdefault(r[0], []).append(p)
            rd.__dict__["_prev_by_sha"] = idx
            rd.__dict__["_alive"] = {r.path: r.sha256 for r in rd.records or ()}
        alive = rd.__dict__["_alive"]
        # 원본은 **오늘 바뀐** 파일이어야 한다 — 바뀌지 않은 현재 판을 출도/·새 프로젝트로 복사한 것까지 '옛 판 보관'이라
        # 하며 메일에서 접었다(검토53 A 차단 2, 원칙 4)
        twin = next((p for p in idx.get(c.new_sha256, ()) if p != c.path and p in alive
                     and alive[p] != c.new_sha256
                     and _nfc(PurePosixPath(p).name).lower() == _nfc(name).lower()), None)
        if twin:
            return (f"보관용 복사본입니다 — 내용이 {PurePosixPath(twin).parent.name}/{name} 의 지난 판과 같습니다 "
                    f"(옛 판을 따로 넣어 둔 것으로 보입니다)")
        # 현행 도면을 바이트 그대로 구판/…_RevD.dxf로 보관한 것 — 그 폴더의 구판 RevC와 짝지어 'RevC→RevD, 7.5→11kW' 변경으로
        # 미확인·메일에 올랐다 (rvall B3). 좁게(재검토 K1 — 넓게 잡아 작업 폴더 '폐기물 소각설비/도면'·'기구판금'·'공통 도면'·'임시'의
        # 진짜 새 판 RevB가 같은 날 송부/로 뜬 사본과 짝지어져 A→B 내용이 어디에도 안 실렸다): ① 새 파일의 **바로 위 폴더 이름 전체**가
        # 구판·백업 낱말이고 ② 같은 바이트의 '현행'이 구판 류·출도 폴더 밖에 있으며 **직전 검사에도 같은 내용으로** 있었을 때만(오늘 새로
        # 들어온 사본은 현행이 아니다). 출도·새 프로젝트로의 복사는 여기 오지 않는다(검토53 A 차단 2). 그 밖은 판 짝짓기로 비교한다
        from watcher.issued import in_issued_folder
        if _ARCHIVE_LEAF.fullmatch(_nfc(PurePosixPath(c.path).parent.name).strip()):
            _cfg = getattr(rd, "cfg", None) or {}
            by_sha = rd.__dict__.get("_rec_by_sha")
            if by_sha is None:
                by_sha = rd.__dict__["_rec_by_sha"] = {}
                for r in rd.records or ():
                    by_sha.setdefault(r.sha256, []).append(r.path)
            prev = rd.prev_files or {}
            cur = next((p for p in by_sha.get(c.new_sha256, ()) if p != c.path
                        and (prev.get(p) or (None,))[0] == c.new_sha256
                        and not _ARCHIVE_LEAF.fullmatch(_nfc(PurePosixPath(p).parent.name).strip())
                        and not in_issued_folder(p, _cfg)), None)
            if cur:
                where = f"{PurePosixPath(cur).parent.name}/{PurePosixPath(cur).name}"
                pj_me, pj_cur = _side_project(rd, c.path), _side_project(rd, cur)
                if pj_cur and pj_cur != pj_me:          # 다른 프로젝트의 현행이면 그 이름을 (재검토 K2)
                    where = f"[{pj_cur}] {where}"
                return (f"{ARCHIVED_CURRENT_NOTE} — {PurePosixPath(c.path).parent.name} 폴더의 이 파일은 현행 "
                        f"{where} 와 내용이 같습니다 (내용 변경 없음)")
    return ""


ARCHIVED_CURRENT_NOTE = "현행 판의 보관용 복사본입니다"    # 판 짝짓기를 하지 않는다 (rvall B3)
# 보관 사본 판정용 — 폴더 이름 **전체**가 구판·백업 낱말(앞 정렬 번호·뒤 연도·날짜 허용). '폐기물 소각설비'·'기구판금'·'공통 도면'·
# '임시'는 아니다 (rvall 재검토 K1). _originals의 in_archive_folder(넓게 빼는 쪽이 안전한 자리)와 따로 둔다
_ARCHIVE_LEAF = re.compile(r"(?:\d{1,4}[\s_.\-]+|[\s_\-.~#@]+)?(?:구판|옛판|이전판|구버전|옛버전|이전버전|폐기|백업|아카이브|"
                           r"old|archive|backup|superseded|obsolete|void)(?:\s*(?:도면|파일|drawings?|files?))?"
                           r"[\s_\-.()\d]*", re.IGNORECASE)


def _side_project(rd, path: str) -> str | None:
    """참고 문구에 쓸 귀속 프로젝트 — 검사의 귀속기와 같은 것. 모르면 None."""
    try:
        res = rd.__dict__.get("_side_res")
        if res is None:
            res = rd.__dict__["_side_res"] = make_resolver(rd.cfg, rd.roots)
            res.folder_votes = rd.folder_votes or {}
        pj, why = res.attribute(path, (rd.docs or {}).get(path))
        return None if why == "미분류" else pj
    except Exception:
        return None


_COPY_TAIL = re.compile(r"^(?:\s*\(1\)|[\s_\-]+[^\s_\-].{0,23})$")


def _copy_origin(pp: PurePosixPath, same: list) -> str | None:
    """지운 파일의 원본 — 같은 폴더·같은 확장자에 **같은 내용**으로 남은 파일 중 이름이 지운 이름의 앞부분(덧붙임: '(1)'·
    '_최종'·' 사본2' 따위 24자 이내)인 것. 지운 쪽이 더 짧은 이름(원본)이면 없다."""
    stem = _nfc(pp.stem).lower()
    for q in same:
        qq = PurePosixPath(q)
        if qq.parent != pp.parent or qq.suffix.lower() != pp.suffix.lower():
            continue
        qs = _nfc(qq.stem).lower()
        if len(stem) > len(qs) and stem.startswith(qs) and _COPY_TAIL.match(stem[len(qs):]):
            return q
    return None


def _note_removed_copies(rd: RunData, state=None) -> None:
    """복사본('- 복사본'·'(2)'·'_OLD')을 지운 것이고 같은 내용의 파일이 남아 있으면 '복사본 정리'로 접는다 — 생길 때는
    '같은 복사본' 참고로 조용했는데 지울 때는 '삭제 도면'으로 오늘 확인할 것에 올랐다 (검토39 P1 낮음 7).
    내용이 다른 사본(편집된 사본)을 지운 것은 그대로 알린다."""
    alive: dict = {}
    for r in rd.records or ():
        alive.setdefault(r.sha256, []).append(r.path)
    # (폴더, 확장자, 짝 키) → [(판 순위, 경로)] 와 저장 시각 — 삭제 1건마다 레코드 전체를 훑어 2만 파일·삭제 200건에
    # 30초가 걸렸다 (검토43 A 참고). 처음 쓸 때 한 번만 만든다
    _by_key: dict | None = None
    _mt_of: dict = {}

    def _index():
        nonlocal _by_key
        if _by_key is None:
            from watcher.scan import pair_key as _pk, ver_rank as _vr
            _by_key = {}
            for r in rd.records or ():
                rp = PurePosixPath(r.path)
                _by_key.setdefault((str(rp.parent), rp.suffix.lower(), _pk(rp.name)), []).append((_vr(rp.name), r.path))
                _mt_of[r.path] = r.mtime or 0
        return _by_key
    for c in rd.changes:
        if c.kind != "removed" or not c.old_sha256 or c.path in rd.moved:
            continue
        if any(getattr(it, "key", None) == "참고" for it in rd.details.get(c.path, [])):
            continue                     # 이미 사유가 있다(새 판으로 대체 등)
        pp = PurePosixPath(c.path)
        if not _COPY_MARK.search(pp.name):
            # 윈도우 사본 'M-001 (1).dxf'·덧붙인 이름 '사양서_최종.docx'를 지웠는데 덧붙임을 뗀 **원본 이름**이 같은 폴더에 **같은
            # 내용**으로 남아 있으면 복사본 정리다 — 생길 때는 '복사본'·'새 이름 저장'으로 조용했는데 지울 때는 '삭제 | 도면 M-001'로
            # 오늘 확인할 것·단독 메일이 되어 원본이 지워진 줄 알았다 (구매 평가 2차 P2 day10). 원본을 지우고 사본이 남은 것은 아니다
            orig = _copy_origin(pp, [p for p in alive.get(c.old_sha256, []) if p != c.path])
            if orig:
                rd.details.setdefault(c.path, []).append(ChangeItem(
                    "CHECK_SKIPPED", "참고", None,
                    f"복사본 정리 — 내용이 {PurePosixPath(orig).name} 와 같은 복사본을 지웠습니다 (원본은 그대로)", "파일 확인"))
                continue
            # 옛 날짜판·rev판을 지운 것 — 같은 폴더에 **더 새 판**(무표기 현행·높은 rev)이 남아 있으면 구판 정리다.
            # '삭제 도면 E-104 Rev A'가 오늘 확인할 것에 올라 도면이 지워진 줄 알았다 (검토41 S3 중간 4 c)
            from watcher.scan import pair_key, ver_rank
            key_, rank_ = pair_key(pp.name), ver_rank(pp.name)
            if key_ and key_ != "".join(pp.stem.lower().split()):
                cur = [q for rk, q in sorted(_index().get((str(pp.parent), pp.suffix.lower(), key_), []))
                       if rk > rank_]
                # 남은 '현행'이 지운 파일보다 **나중에(또는 같이) 저장된** 것일 때만 — 이름 순서만 보면 가장 새 날짜판(Rev B)을
                # 지우고 옛 무표기(Rev A)가 남은 날까지 '구판 정리'로 접혀 메일이 없었다 (검토42 A 중간 2)
                _gone_mt = (rd.prev_files.get(c.path) or (None, None, 0))[2] or 0
                cur = [q for q in cur if _mt_of.get(q, 0) + 60 >= _gone_mt]
                # 지운 판의 표제란 Rev가 남은 현행보다 **높으면** 최신 작업본을 지운 것이다 — 같은 때 저장된 두 파일에서
                # Rev C 날짜판을 지우고 Rev A 무표기가 남은 날이 '구판 정리'로 접혔다 (검토42 B C01)
                from watcher.scan import rev_key, rev_shape
                _gone_doc = state.load_extract(c.old_sha256, c.path) if state is not None else None
                _gone_rev = str((((_gone_doc or {}).get("fields") or {}).get("REV") or {}).get("value") or "")

                def _older(q) -> bool:
                    d_ = rd.docs.get(q)
                    rv = str(d_.fields["REV"].value) if d_ is not None and "REV" in d_.fields else ""
                    return bool(rv and _gone_rev and rev_shape(rv) is not None and rev_shape(rv) == rev_shape(_gone_rev)
                                and rev_key(rv) < rev_key(_gone_rev))
                cur = [q for q in cur if not _older(q)]
                if cur:
                    rd.details.setdefault(c.path, []).append(ChangeItem(
                        "CHECK_SKIPPED", "참고", None,
                        f"구판 정리 — 현행 {PurePosixPath(cur[-1]).name}은 그대로입니다", "파일 확인"))
            continue
        same = [p for p in alive.get(c.old_sha256, []) if p != c.path]
        if same:
            rd.details.setdefault(c.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"복사본 정리 — 내용이 {PurePosixPath(same[0]).name} 와 같은 복사본을 지웠습니다 (원본은 그대로)",
                "파일 확인"))


def _pair_index(rd):
    """판 짝짓기 후보 색인 — 검사당 한 번만 만든다.

    후보를 추가 파일마다 전체 목록에서 훑으면 추가 × 전체(4만 기준선 외삽 169분,
    2026-09-02 재검토 실측). (폴더, 확장자, 짝 키) → 목록으로 O(1) 조회."""
    idx = getattr(rd, "_pair_idx", None)
    if idx is not None:
        return idx
    prev_idx: dict = {}
    for pp, row in rd.prev_files.items():
        q = PurePosixPath(pp)
        stem = pair_key(q.name)
        if stem:
            prev_idx.setdefault((str(q.parent), q.suffix.lower(), stem), []).append((pp, row))
    rec_idx: dict = {}
    rec_by_path: dict = {}
    for r in rd.records:
        q = PurePosixPath(r.path)
        rec_by_path[r.path] = r
        stem = pair_key(q.name)
        if stem:
            rec_idx.setdefault((str(q.parent), q.suffix.lower(), stem), []).append(r)
    rd._pair_idx = (prev_idx, rec_idx, rec_by_path)
    return rd._pair_idx


from watcher.scan import ver_rank as _ver_rank      # 판 표기 순위 (scan.ver_rank, consistency와 공용)


def sheet_bases(paths) -> set:
    """'이름 (1).ext'가 있는 폴더의 '폴더/이름' — 그 옆의 '(2)'·'(3)'은 사본이 아니라 시트다 (검토32 D 1-7)."""
    return {str(PurePosixPath(p).parent) + "/" + re.sub(r"\s*\(1\)$", "", PurePosixPath(p).stem)
            for p in paths if re.search(r"\(1\)$", PurePosixPath(p).stem)}


def is_copy_marked(path: str, sheets: set) -> bool:
    """사본 표식('- 복사본'·'(2)'·' copy')이 붙었나 — 단, 같은 폴더에 '(1)'이 있으면 '(N)'은 시트."""
    from watcher.consistency import _COPY_MARK_RE
    stem = PurePosixPath(path).stem
    m = _COPY_MARK_RE.search(stem)
    if not m:
        return False
    if re.fullmatch(r"\(\d+\)", m.group(1)):
        base = str(PurePosixPath(path).parent) + "/" + stem[:m.start()].rstrip()
        if base in sheets:
            return False
    return True


def _version_comparer(rd: RunData):
    """같은 도면의 여러 판 가운데 어느 쪽이 '현행'인가 — (cmp, mixed_revs).
    구판 제외(_superseded_paths)와 판 짝짓기(_pair_revisions)가 **같은 함수**를 쓴다. 따로 두었더니
    같은 날 날짜판·rev2가 섞인 묶음에서 둘이 반대 답을 내, 한쪽은 옛 파일을 다른 쪽은 날짜판을 구판으로
    치워 그 도면번호가 교차 검사에서 통째로 빠졌다 (검토35 A 중간 2)."""
    from watcher.scan import rev_key as _rev_key, rev_shape as _rev_shape

    def _rev_of(r) -> str:
        d = rd.docs.get(r.path)
        return (str(getattr(d, "revision", "") or "") if d is not None else "").strip().upper()

    from watcher.consistency import _OLD_FOLDER, _COPY_MARK_RE
    from datetime import datetime as _dt

    def _is_old(r) -> bool:
        return bool(_OLD_FOLDER.search(r.path))

    _sheet1 = sheet_bases(rd.docs)

    def _is_copy(r) -> bool:
        return is_copy_marked(r.path, _sheet1)

    def _mtime_day(r) -> int:
        try:
            return int(_dt.fromtimestamp(float(r.mtime or 0)).strftime("%Y%m%d"))
        except (OverflowError, OSError, ValueError):
            return 0

    def _date_of(vr) -> int:
        """ver_rank의 날짜 꼬리 (0, n) → YYYYMMDD (6자리면 20YYMMDD)."""
        n = vr[1]
        return n if n >= 10_000_000 else (20_000_000 + n if n >= 100_000 else 0)

    def _mixed_revs(g) -> bool:
        """Rev 모양이 한 묶음에 섞였나 — 쌍마다 건너뛰면 '1 > 0 > A > 1' 순환이 생겨 정렬 순서가 답을
        정했다(검토32 B2). 'P2'(예비)와 'A'(발행), 'A1'과 'B'처럼 모양이 다른 것도 섞임이다(검토36 A N1).
        섞였으면 묶음 전체에서 Rev 단계를 뺀다"""
        return len({_rev_shape(_rev_of(r)) for r in g if _rev_of(r)}) > 1

    def _cmp(a, b, use_rev: bool = True) -> int:
        """a가 b보다 '현행'이면 양수. 순서: 구판 폴더는 항상 짐(검토31 B1: 하위 OLD/의 재저장 구판이 현행을
        밀어냈다) → 사본 표식은 짐(B5) → 표제란 Rev(같은 체계일 때만 — '0' vs 'A'처럼 숫자·문자 혼용은
        비교 불가, B3) → 한쪽만 비면 저장 시각 → 무표기 vs 날짜판은 날짜가 무표기 저장일 이후면 날짜판이
        신판, 아니면 그날의 사본(B4) → 무표기 우선 → 이름의 판 표기 → 저장 시각 (검토30 B 5-D)"""
        oa, ob = _is_old(a), _is_old(b)
        if oa != ob:
            return -1 if oa else 1
        ca, cb = _is_copy(a), _is_copy(b)
        if ca != cb:
            return -1 if ca else 1
        ra, rb = _rev_of(a), _rev_of(b)
        va, vb = _ver_rank(PurePosixPath(a.path).name), _ver_rank(PurePosixPath(b.path).name)
        if use_rev and ra and rb and ra != rb and _rev_shape(ra) == _rev_shape(rb):
            ka, kb = _rev_key(ra), _rev_key(rb)
            if ka != kb:
                return 1 if ka > kb else -1
        if use_rev and bool(ra) != bool(rb):
            # 한쪽 Rev가 비었을 때 두 이름 모두 판 표기(revA·rev2·날짜)가 있으면 이름이 더 믿을 만하다 —
            # 저장 시각만 보면 구판을 나중에 열어 저장한 날 방향이 뒤집혔다 (검토36 A N1)
            if not (va != (1, 0, "") and vb != (1, 0, "")):
                return 1 if (a.mtime, a.path) > (b.mtime, b.path) else -1
        ua, ub = va == (1, 0, ""), vb == (1, 0, "")
        if ua and vb[0] == 0 and _date_of(vb) and _date_of(vb) > _mtime_day(a):
            return -1
        if ub and va[0] == 0 and _date_of(va) and _date_of(va) > _mtime_day(b):
            return 1
        if ua != ub:
            return 1 if ua else -1
        if va != vb:
            if va[0] == 3 and vb[0] == 3:
                # 이름의 판 표기도 Rev와 같은 규칙 — 'revP2'와 'revA'처럼 모양이 다르면 이름으로는 순서를
                # 모른다(길이부터 견주면 예비판 P2가 발행판 A보다 새 판이 됐다, 검토36 A N1). 저장 시각으로
                sa, sb = _rev_shape(va[2]), _rev_shape(vb[2])
                if sa == sb and _rev_key(va[2]) != _rev_key(vb[2]):
                    return 1 if _rev_key(va[2]) > _rev_key(vb[2]) else -1
                if sa != sb:
                    return 1 if (a.mtime, a.path) > (b.mtime, b.path) else -1
            return 1 if va > vb else -1
        return 1 if (a.mtime, a.path) > (b.mtime, b.path) else -1

    return _cmp, _mixed_revs


def _truly_replaced(rd: RunData, superseded) -> set:
    """교차 검사의 '구판'(현행이 아닌 판) 가운데 **정말 새 판으로 대체된 것**만 — 보관 폴더(old·보관·Archive)로 옮긴 것, 또는 같은 폴더에
    같은 도면 이름의 더 나중에 저장된 현행 판이 있는 것. 무표기 원본을 현행으로 치는 규칙 때문에 가장 최근 작업본 '_최종_진짜'가
    '구판'이 되어, 그 파일의 'Rev 미갱신'이 하루 만에 '새 판으로 대체됨'으로 닫혔다 (검토67 B1)."""
    from watcher.consistency import _OLD_FOLDER
    from watcher.scan import pair_key
    recs = {r.path: r for r in (rd.records or ())}
    cur: dict = {}
    for p, r in recs.items():
        if p not in superseded:
            k = (str(PurePosixPath(p).parent), pair_key(_COPY_MARK.sub("", PurePosixPath(p).name)))
            cur[k] = max(cur.get(k, 0.0), float(r.mtime or 0))
    out = set()
    for p in superseded or ():
        r = recs.get(p)
        if r is None:
            continue
        if _OLD_FOLDER.search(p):
            out.add(p)
            continue
        k = (str(PurePosixPath(p).parent), pair_key(_COPY_MARK.sub("", PurePosixPath(p).name)))
        if cur.get(k, 0.0) > float(r.mtime or 0):
            out.add(p)
    return out


def _superseded_paths(rd: RunData, project_of=None) -> set:
    """같은 폴더·같은 도면 이름(판 표기만 다른)의 여러 판 가운데 최신 하나만 남기고 나머지.
    project_of(path) → 프로젝트 이름(없으면 None): 주어지면 **프로젝트가 같은 것끼리만** 겨룬다 — 루트에
    떨어진 양식 한 장이 그 아래 모든 프로젝트의 같은 번호 도면을 밀어냈다 (검토31 B2)
    판 짝짓기가 '이전 판'으로 삼은 경로는 그 검사분에서만 교차 검사에서 빠졌고, 다음 날부터 구판이
    도면 간·도면-BOM 불일치의 기준으로 되돌아왔다 (2회차 B7).
    - 표제란 도면번호가 서로 **다르면** 다른 도면이다 — '판넬도면'과 '판넬도면_rev2'가 별개인 회사 (3회차 A2-2)
    - 최신은 이름의 판 표기 순으로, 같으면 저장 시각 (3회차 A2-1: 구판 재저장)"""
    import functools
    from watcher.scan import pair_key
    _prev_idx, rec_idx, _by = _pair_index(rd)

    def _no_of(r):
        d = rd.docs.get(r.path)
        f = getattr(d, "fields", {}).get("DWG_NO") if d is not None else None
        return (f.value or "").strip().upper() if f else ""

    _cmp, _mixed_revs = _version_comparer(rd)

    # 묶음: 같은 프로젝트 + 같은 도면번호 + 같은 pair_key(사본 표식은 걷고)는 폴더가 달라도(현행을 전기/로
    # 옮김) 한 묶음 (5-E); 번호 없는 파일은 예전처럼 같은 폴더·같은 stem만
    groups: dict = {}
    for _k, recs in rec_idx.items():
        for r in recs:
            no = _no_of(r)
            name = PurePosixPath(r.path).name
            proj = project_of(r.path) if project_of else None
            if project_of and not proj:
                proj = ("dir", _k)            # 귀속 없는 파일(미분류)은 같은 폴더 안에서만 겨룬다
            key = ("no", proj, no, PurePosixPath(r.path).suffix.lower(), pair_key(_COPY_MARK.sub("", name))) \
                if no else ("dir", _k)
            groups.setdefault(key, []).append(r)

    def _clusters(g: list) -> list:
        """폴더가 같거나 한쪽이 다른 쪽의 상위인 것끼리 묶는다 — 번호·이름이 같아도 **형제 폴더**의 도면은
        남남이다 (검토30 매트릭스 C105). 폴더 이름순으로 정렬하면 하위 폴더가 상위 바로 뒤에 오므로
        한 번 훑어 묶는다 — 제곱 탐색은 형제 2,000개에 19초였다 (검토31 B7)"""
        # 문자열 정렬은 'P26-050 추가'(공백 < '/')를 'P26-050'과 'P26-050/전기' 사이에 끼워 묶음을 끊었다
        # (검토32 D 1-2) — 경로 조각 튜플로 견주면 자식이 형제보다 먼저 온다
        items = sorted(g, key=lambda r: (PurePosixPath(r.path).parent.parts, r.path))
        out_: list = []
        tops: list = []
        for r in items:
            d = PurePosixPath(r.path).parent.parts
            if out_ and d[:len(tops[-1])] == tops[-1]:
                out_[-1].append(r)
            else:
                out_.append([r])
                tops.append(d)
        return out_

    out: set = set()
    for key, g in groups.items():
        if len(g) < 2:
            continue
        if key[0] == "dir":
            nos = {_no_of(r) for r in g if _no_of(r)}
            if nos:                       # 번호 있는 파일은 위 묶음에서 다뤘다 — 번호 없는 것끼리만
                g = [r for r in g if not _no_of(r)]
                if len(g) < 2:
                    continue
        for cl in (_clusters(g) if key[0] == "no" else [g]):
            if len(cl) < 2:
                continue
            _use = not _mixed_revs(cl)
            newest = max(cl, key=functools.cmp_to_key(lambda a, b: _cmp(a, b, _use)))
            out.update(r.path for r in cl if r.path != newest.path)
    return out


def _pair_revisions(state: State, rd: RunData) -> None:
    """판 짝짓기: 날짜/버전을 파일명에 붙여 '새 파일'로 저장하는 문화 대응.
    추가된 파일과 같은 폴더에서 stem(날짜·버전 제외 이름)이 같은 이전 판을 찾아
    비교하고, PDF면 페이지 시각 변경(그림·배선)도 감지한다."""
    # 첫 검사(기준선)에는 무거운 그림 비교를 하지 않는다 — 수년치 판이 쌓인
    # 서버에서 모든 과거 쌍을 페이지 렌더로 비교하면 몇 시간~며칠이 걸린다
    # (2026-08-27 회사 서버 5,211개 실측). 텍스트 짝짓기·diff는 유지, 그림은
    # 이후 일일 검사에서 새 판이 올 때부터. 과거 도면이 필요하면 화면의
    # [더 민감하게 다시 비교]로 파일 단위 소급 비교가 가능하다.
    baseline = not rd.prev_files
    noted = False
    for ci, c in enumerate(rd.changes, 1):
        _set_progress("3/3 변경 비교·기록", ci, len(rd.changes))
        if c.kind != "added" or c.path in rd.details or c.path in rd.moved:
            continue
        # 복사본·빈 파일이면 그 사실을 항목으로 남긴다 — 사람이 열어보지 않아도
        # 무엇인지 알 수 있게 (2026-09-01 처음 쓰는 사람 관점 점검)
        side = _side_note(rd, c)
        if side:
            rd.details.setdefault(c.path, []).append(
                ChangeItem("CHECK_SKIPPED", "참고", None, side, "파일 확인"))
            if side.startswith(ARCHIVED_CURRENT_NOTE):
                continue        # 현행의 바이트 사본 — 구판 폴더의 옛 판과 짝지어 새 판 변경으로 내지 않는다 (rvall B3)
        if c.path in rd.extract_failures and not side:   # 빈 파일 안내와 겹치지 않게
            # 손상·잠김으로 못 읽은 새 파일 — 사유가 콘솔에만 남고 화면엔 없던 것
            # (2026-09-03 검토)
            reason = rd.extract_failures[c.path]
            # 크기 상한으로 일부러 안 읽은 파일에 '손상됐을 수 있습니다'를 붙이면 멀쩡한 파일을 의심하게 했다 (검토39 F2 ⑦)
            # 암호 문서에 '손상됐을 수 있습니다'를 붙이면 열어 보면 멀쩡해 혼란이었다 (검토55 ⑤23)
            # 크기·시간 상한으로 생략한 것도 — '파일이 너무 큽니다(…상한 120MB)'에 손상 힌트가 붙었다 (고장 주입 2026-10-26 F5)
            hint = ("" if reason.startswith("DWG") or any(w in reason for w in (
                        "끝나지 않아 중단", "읽지 않습니다", "암호", "너무 큽니다", "상한", "처리하다 멈춰"))
                    else " — 파일이 손상됐거나 저장이 끊겼을 수 있습니다 (프로그램으로 열리는지 확인)")
            rd.details.setdefault(c.path, []).append(ChangeItem(
                "CHECK_SKIPPED", "내용 추출 실패", None, f"수행 못 함: {reason}{hint}", "추출 단계"))
        p = PurePosixPath(c.path)
        stem, ext = pair_key(p.name), p.suffix.lower()
        if not stem:
            continue
        prev_idx, rec_idx, rec_by_path = _pair_index(rd)
        key = (str(p.parent), ext, stem)
        cands = [(pp, row) for pp, row in prev_idx.get(key, ()) if pp != c.path]
        # 같은 날 여러 판(_241101·_241201)을 한꺼번에 넣으면 둘 다 옛 판(_241001)과 비교돼 _241201에 241101의 변경까지
        # 겹쳐 실렸다 — 도움말은 '날짜순으로 줄줄이' (검토67 C1). 오늘 함께 들어온 더 이른 판이 있으면 그것과 비교한다
        _older_today = []
        if cands and not baseline:
            _added = rd.__dict__.get("_added_set")
            if _added is None:
                _added = rd.__dict__["_added_set"] = {x.path for x in rd.changes if x.kind == "added"}
            _me0 = rec_by_path.get(c.path)
            _sib0 = [r for r in rec_idx.get(key, ()) if r.path != c.path and r.path in _added]
            if _me0 is not None and _sib0:
                if getattr(rd, "_vcmp_cache", None) is None:
                    rd._vcmp_cache = _version_comparer(rd)
                _vc0, _vm0 = rd._vcmp_cache
                _u0 = not _vm0(list(rec_idx.get(key, ())))
                _older_today = [r for r in _sib0 if _vc0(r, _me0, _u0) < 0]
        if _older_today:
            import functools as _ft0
            _pr = max(_older_today, key=_ft0.cmp_to_key(lambda x, y: _vc0(x, y, _u0)))
            prev_path, prev_sha = _pr.path, _pr.sha256
            prev_row = (prev_sha, _pr.size, _pr.mtime)
        elif cands:
            prev_path, prev_row = max(cands, key=lambda kv: kv[1][2])
            prev_sha = prev_row[0]
        else:
            # 같은 검사에서 두 판이 한꺼번에 처음 등장한 경우 — 직전 스냅샷에는
            # 없지만 이번 스캔의 형제 파일과 짝지어 비교한다 (2026-08-26 실사용:
            # 구판·신판을 동시에 넣으면 비교가 안 되던 문제. '하나 빼고 검사 후
            # 다시 넣기' 우회도 이제 불필요). 자기보다 오래된(수정시각) 판만 구판 후보.
            me = rec_by_path.get(c.path)
            if me is None:
                continue
            # 어느 쪽이 더 새 판인가는 구판 제외와 **같은 함수**로 정한다 — 이름 판 표기(검토33 B2)·날짜판
            # 예외(검토34 B 중간 2)를 따로 두었더니 둘이 반대 답을 냈다 (검토35 A 중간 2)
            import functools as _ft
            if getattr(rd, "_vcmp_cache", None) is None:     # 문서 전체를 한 번 훑으므로 검사당 한 번
                rd._vcmp_cache = _version_comparer(rd)
            _vcmp, _vmixed = rd._vcmp_cache
            _group = list(rec_idx.get(key, ()))
            _use = not _vmixed(_group)
            sibs = [r for r in _group if r.path != c.path and _vcmp(r, me, _use) < 0]
            if not sibs:
                continue  # 자신이 가장 오래된 판 — 신판 쪽에서 짝지어진다
            prev_rec = max(sibs, key=_ft.cmp_to_key(lambda x, y: _vcmp(x, y, _use)))
            prev_path, prev_sha = prev_rec.path, prev_rec.sha256
            prev_row = (prev_sha, prev_rec.size, prev_rec.mtime)
        # 이 (구판 내용 → 새 내용) 쌍이 **이미 보고된 변경**이면 사본이다 — 현행 파일을 백업 폴더에 복사했더니 그 폴더의 옛
        # 사본과 짝지어 지난번에 보고한 행 추가를 오늘 또 냈다 (검토58 F5-1). 검토58의 '내용이 지금도 다른 곳에 있으면'은
        # 다른 프로젝트·백업과 우연히 같은 진짜 새 판(되돌림 포함)의 비교까지 뺐다 (검토59 F1 F-1·F5 F2) — 쌍으로 좁힌다
        if c.new_sha256 and prev_sha and not baseline and prev_sha != c.new_sha256:
            try:
                _seen = state.conn.execute(
                    "SELECT 1 FROM changes WHERE old_sha256 = ? AND new_sha256 = ? LIMIT 1",
                    (prev_sha, c.new_sha256)).fetchone()
                # (현행 도면을 옛 날짜판이 있는 백업 폴더에 복사한 경우는 옛 날짜판이 원본의 지난 판과 바이트가 달라 여기 안
                # 걸린다 — 이미 아는 차이를 한 번 더 보이지만 비교를 잃지는 않는다. 넓힌 규칙들은 진짜 새 판 비교를 뺐다, 검토59)
            except Exception:
                _seen = None
            if _seen:
                if not side:
                    rd.details.setdefault(c.path, []).append(ChangeItem(
                        "CHECK_SKIPPED", "참고", None,
                        f"내용이 이미 보고된 {PurePosixPath(prev_path).name}의 새 내용과 같은 복사본입니다 — 실제 개정이 아닐 수 있습니다",
                        "판 짝짓기"))
                continue
        old_dict = state.load_extract(prev_sha, prev_path)
        new_doc = rd.docs.get(c.path)
        if old_dict is None or new_doc is None \
                or old_dict.get("extract_failed"):
            from watcher.extract import can_read_content
            if can_read_content(c.path):
                continue        # 읽을 수 있는 형식인데 못 읽은 것 — 위에서 사유를 남겼다
            # 내용을 못 읽는 형식(PLC 프로젝트·DWG 등)도 "이것이 그 파일의 새 판이고
            # 구판은 사라진 게 아니다"와 크기·저장 시각은 말해 줘야 한다. 전에는 DWG만
            # 그림이 있을 때 짝지었고 나머지는 여기서 빠져나가, 브리핑에 '추가'와
            # '삭제'가 서로 남처럼 따로 떴다 (2026-09-10 요청)
            me = rec_by_path.get(c.path)
            rd.old_versions.add(prev_path)
            rd.newer_of.setdefault(prev_path, set()).add(c.path)
            items = list(rd.details.get(c.path, []))   # 위에서 달아 둔 참고·실패 사유 보존
            items.append(ChangeItem("NEW_REVISION_OF", "이전 판",
                                    PurePosixPath(prev_path).name, p.name,
                                    "파일명 짝짓기 (날짜·버전 표기 제외 동일)"))
            if ext == ".dwg":
                # 변환 프로그램 없는 DWG: 글자는 없어도 미리보기 그림끼리는 비교 (2026-09-03)
                old_pages = state.load_renders(prev_sha)
                new_pages = state.load_renders(me.sha256) if me else None
                if old_pages and new_pages:
                    from watcher.capture import visual_page_diff
                    _add_visual(rd, c.path, items,
                                visual_page_diff(old_pages, new_pages))
            if new_doc is not None:
                # 이번 판은 읽었는데(변환기 있는 DWG) 구판 기록만 없다 — 형식 탓이
                # 아니며 다음 판부터 비교된다 (검토18 ①)
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "내용 비교", None,
                    "수행 못 함: 이전 판의 추출 기록이 없음 — 이번 판을 기준으로 저장",
                    "추출 단계"))
            elif c.path not in rd.extract_failures:    # 사유가 없으면 형식 탓임을 밝힌다
                items.append(ChangeItem(
                    "CHECK_SKIPPED", "내용 비교", None,
                    f"이 형식({ext or '확장자 없음'})은 글자·표를 읽지 못합니다 — "
                    f"파일이 바뀐 사실과 크기·저장 시각으로 관리합니다",
                    "파일 수준 감시"))
            items += _file_level_items(c.path, prev_row, me)
            if prev_path not in rec_by_path:
                rd.details.setdefault(prev_path, []).append(ChangeItem(
                    "CHECK_SKIPPED", "참고", None,
                    f"새 판 {p.name}(으)로 대체됨 — 파일이 없어진 것이 아닙니다",
                    "판 짝짓기"))
            rd.details[c.path] = items
            continue
        if not _compare_ok(old_dict, c.path):
            # 이전 판이 제외 폴더 등으로 재추출되지 않은 경우의 엔진 혼합 방지
            rd.compare_skipped.add(c.path)
            rd.details[c.path] = [ChangeItem(
                "CHECK_SKIPPED", "내용 비교", None,
                "수행 못 함: 이전 판의 추출 기록이 다른 프로그램 판의 형식(판 교체 전후)이라 비교를 생략합니다",
                "추출 단계")]
            continue
        old_doc = _old_doc(old_dict, new_doc, c.path)
        # 원본이 **오늘 바뀌었고** 이 파일이 그 원본의 사본이면(날짜판·사본을 떠 두는 문화) '새 판'이 아니다 —
        # (a) 편집 전에 뜬 사본(내용 = 어제 원본)이 "이전 판 원본 → 사본"이라는 거꾸로 된 새 판으로, (b) 편집 뒤 저장한
        # 사본(내용 = 오늘 원본)이 원본과 같은 diff로 한 번 더 '변경'이 됐다 (검토41 S3 중간 4). 현행은 원본이다
        _orig_now, _me0 = rec_by_path.get(prev_path), rec_by_path.get(c.path)
        if _orig_now is not None and _me0 is not None and _orig_now.sha256 != prev_sha \
                and _me0.sha256 in (prev_sha, _orig_now.sha256):
            what = ("오늘 고치기 전 원본" if _me0.sha256 == prev_sha else "오늘 저장한 원본")
            rd.details[c.path] = list(rd.details.get(c.path, [])) + [ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"{what} {PurePosixPath(prev_path).name}와 같은 내용의 사본(날짜판) — 현행은 원본입니다 "
                f"(내용 변경 없음)", "판 짝짓기")]
            continue
        rd.old_versions.add(prev_path)
        rd.newer_of.setdefault(prev_path, set()).add(c.path)
        if prev_path not in rec_by_path:
            # 이름을 바꿔 저장한 새 판 — 구판은 '삭제'로 잡히지만 사라진 게 아니다.
            # 그 삭제 항목에 참고를 달아 목록·브리핑에서 바로 알게 (2026-09-02 검토)
            rd.details.setdefault(prev_path, []).append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"새 판 {p.name}(으)로 대체됨 — 파일이 없어진 것이 아닙니다", "판 짝짓기"))
        # 이전 판으로 본 쪽이 **더 나중에 저장됐으면** 방향을 단언하지 않는다 — 판 표기가 약한 근거(날짜판 대
        # rev판)일 때 '09-20 저장 → 09-10 저장, 7.5→5.5'를 새 판이라 불렀다 (검토36 E 낮음 1)
        _me = rec_by_path.get(c.path)
        _late = bool(_me is not None and prev_row and prev_row[2] and prev_row[2] > (_me.mtime or 0) + 60)
        items = [ChangeItem("NEW_REVISION_OF", "이전 판",
                            PurePosixPath(prev_path).name, p.name,
                            "파일명 짝짓기 (날짜·버전 표기 제외 동일)"
                            + (" — 이전 판으로 본 쪽이 더 나중에 저장됐습니다: 어느 쪽이 최신인지 확인하세요"
                               if _late else ""))]
        note = unreadable_note(old_doc, new_doc)
        if note:  # 텍스트를 못 읽는 판이 끼면 엉터리 diff 대신 사유를 보고
            items.append(ChangeItem("CHECK_SKIPPED", "내용 비교", None,
                                    f"수행 못 함: {note}", "추출 단계"))
            rd.details[c.path] = items
            continue
        # 페이지 시각 변경 감지 (PDF 도면, 이전 판 파일이 남아 있을 때) —
        # 배선·도형처럼 텍스트 비교가 못 보는 변경 (원칙 7, 2026-08-24 개정)
        text_items = _safe_diff(old_doc, new_doc, c.path)
        masks = _changed_texts(old_doc, new_doc)
        boxes = _changed_boxes(old_doc, new_doc)
        rd.ocr_boxes[c.path] = _ocr_boxes_of(new_doc)
        visual_done = ext not in VISUAL_EXTS   # PDF·DXF·DWG만 그림 비교 대상
        # 이전 판 파일이 남아 있으면 파일끼리, 이미 지워졌으면 기록해 둔 그림으로.
        # DWG는 파일을 직접 못 그리니 양쪽 다 기록 그림
        # 이전 판 파일이 **오늘 바뀌었으면** 디스크의 그 파일은 이전 판이 아니다 — 사본을 떠 두고 원본을 고친 날
        # 사본이 '고친 원본'과 그림 비교되어 사본에 거짓 'Rev 미갱신'이 나고 전/후 사진이 뒤집혔다 (검토40 B 중간 3)
        _prev_now = rec_by_path.get(prev_path)
        prev_file_ok = _prev_now is None or _prev_now.sha256 == prev_sha
        old_side = rd.abs_of.get(prev_path) if ext != ".dwg" and prev_file_ok else None
        new_side = rd.abs_of.get(c.path) if ext != ".dwg" else None
        if ext in VISUAL_EXTS:
            if old_side is None:
                old_side = state.load_renders(prev_sha)
            if new_side is None and c.path in rec_by_path:
                new_side = state.load_renders(rec_by_path[c.path].sha256)
        # 나중에 추가한 감시 폴더의 첫 검사도 그 폴더에선 기준선이다 — 수년치 판이 쌓인 폴더를
        # 추가한 날 모든 과거 쌍을 그림 비교하지 않게 (2026-09-11)
        base_here = baseline or ((c.path.split("/", 1)[0] if "/" in c.path else c.path) in rd.reg_roots)
        if (base_here and ext in VISUAL_EXTS
                and len(rd.baseline_visual) >= BASELINE_VISUAL_PAIRS):
            # 기준선에서도 앞 N건은 그림 비교를 해준다 — 첫날부터 전/후 사진을
            # 봐야 이 기능이 있는 줄 안다 (2026-08-31 사용자: "도면은 왜 사진
            # 비교가 없어진 거야?"). 그 이상은 시간이 폭증해 건너뛴다
            if not noted:
                noted = True
                print(f"{'첫 검사(기준선)' if baseline else '새로 추가한 폴더의 첫 검사'}: 그림(페이지) 비교는 앞 "
                      f"{BASELINE_VISUAL_PAIRS}건까지만 하고 나머지는 "
                      f"건너뜁니다 — 텍스트 비교는 전부 기록되며, 필요한 도면은 "
                      f"화면의 [더 민감하게 다시 비교]로 소급 비교됩니다.",
                      flush=True)
        elif old_side is not None and new_side is not None and ext in VISUAL_EXTS \
                and (ext == ".dwg" or c.path not in (rd.extract_failures or {})):     # 읽지 못한 판은 그리지 않는다 (검토63 D-F1)
            from watcher.capture import visual_page_diff
            print(f"  그림 비교: {p.name} ← {PurePosixPath(prev_path).name}",
                  flush=True)
            visual_done = _add_visual(rd, c.path, items,
                                      visual_page_diff(old_side, new_side, ignore_texts=masks, ignore_boxes=boxes,
                                                       anchors=__import__("watcher.diff", fromlist=["page_anchors"]).page_anchors(old_doc, new_doc),
                                                       title_boxes=_title_boxes_of(old_doc, new_doc),
                                                       split=_split_flow(text_items),
                                                       new_renders=(_fresh_renders(state, rec_by_path[c.path].sha256)
                                                                    if ext == ".dxf" and c.path in rec_by_path else None)))
            if base_here:
                rd.baseline_visual.add(c.path)
        items += text_items
        from watcher.diff import CONTENT_KINDS as _CK
        if visual_done and not any((getattr(i, "kind", "") in _CK and getattr(i, "key", "") != MOVED_KEY)
                                   or str(getattr(i, "kind", "")).startswith(("FIELD_", "REVROW_"))
                                   or getattr(i, "kind", "") == "CHECK_SKIPPED"
                                   for i in items):
            # 이름만 새 판('_최종_진짜')이고 글자·표·그림이 이전 판과 같다 — 차이 0인 '새 판'이 오늘 확인할 것·메일에 올랐다 (검토67 B2)
            items.append(ChangeItem(
                "CHECK_SKIPPED", "참고", None,
                f"내용 변경 없음 — 이전 판 {PurePosixPath(prev_path).name}과 내용이 같은 새 이름 저장입니다"
                f" ({'글자·표·그림 동일' if ext in VISUAL_EXTS or __import__('watcher.diff', fromlist=['parts_compared']).parts_compared(old_doc, new_doc) else '글자·표 동일 — 그림·개체는 비교하지 못함'}). "
                "확인 대상 아님 (기록만 남깁니다)", "내용 비교"))
        rd.details[c.path] = items
        if prev_path in rd.abs_of and prev_file_ok:  # 이전 판 파일이 (그대로) 남아 있으면 전 사진 가능
            rd.prev_abs[c.path] = rd.abs_of[prev_path]
        rd.issues += _revision_issues(state, c.path, old_doc, new_doc, items,
                                    visual_checked=visual_done, rd=rd)


def _collect_text_captures(rd: RunData) -> None:
    """변경 위치 캡처 (도면 유형만, 파일당 4장 제한 — 브리핑 용량 보호).
    전/후 쌍: 이전 판 파일이 남아 있으면(판 짝짓기) 전 사진도, 덮어쓰기면 후만."""
    baseline = not rd.prev_files
    if baseline and not rd.baseline_visual:
        return  # 첫 검사: 그림 비교 대상이 없으면 렌더 캡처도 생략(소요 시간)
    from watcher.capture import capture_pair
    for pi, (cpath, citems) in enumerate(rd.details.items(), 1):
        _set_progress("3/3 변경 자리 사진", pi, len(rd.details), current=cpath)
        if baseline and cpath not in rd.baseline_visual:
            continue        # 기준선에서는 그림 비교한 파일만 사진을 만든다
        ap = rd.abs_of.get(cpath)
        if ap is None:
            continue
        old_ap = rd.prev_abs.get(cpath)
        boxes = rd.ocr_boxes.get(cpath) or {}
        n = 0
        want = sum(1 for it in citems
                   if it.kind in ("TEXT_CHANGED", "TEXT_ADDED", "FIELD_CHANGED") and it.new)
        if want > CAPTURE_PER_FILE:
            print(f"  참고: {PurePosixPath(cpath).name}의 변경 {want}건 중 앞 "
                  f"{CAPTURE_PER_FILE}건만 사진을 만듭니다 (나머지는 글자 비교로 남습니다)",
                  flush=True)
        for it in citems:
            if n >= CAPTURE_PER_FILE:
                break
            if it.kind == "FIELD_CHANGED" and it.key == "DATE":
                continue        # 날짜 칸은 값이 근거다 — 장마다 표제란 사진을 붙이면 메일만 붓는다 (파일럿 모의 ③)
            bx = boxes.get(" ".join(str(it.new or "").split()))
            if it.kind == "TEXT_CHANGED" and it.new:
                cap = capture_pair(ap, it.new, old_ap, it.old, box=bx)
            elif it.kind == "TEXT_ADDED" and it.new:
                cap = capture_pair(ap, it.new, old_ap, None, box=bx)
            elif it.kind == "FIELD_CHANGED" and it.new:
                # OCR 자리가 있으면 그 자리를, 없으면 글자로 찾는다. 전에는 OCR일 때만
                # 사진을 만들어, 보통 도면은 Rev가 바뀌어도 글자만 나왔다
                # (2026-09-10 "왜 글로만 비교가 되는거야?")
                cap = capture_pair(ap, str(it.new), old_ap, it.old, box=bx)
                if cap is None and it.key:
                    # 표제란은 'REV: B'처럼 라벨과 값이 한 칸에 있는 일이 흔하다
                    cap = capture_pair(ap, f"{it.key}: {it.new}", old_ap,
                                       f"{it.key}: {it.old}" if it.old else None)
            else:
                continue
            if cap:
                # kind를 키에 포함 — 같은 key의 TEXT_CHANGED/ADDED가
                # 서로의 사진을 덮어쓰지 않게 (2026-08-25 리뷰)
                _ck = f"{it.kind}|{it.key}"
                if (cpath, _ck) in rd.captures:
                    _ck = f"{_ck}|{it.where}"
                rd.captures[(cpath, _ck)] = cap
                n += 1


BACKUP_ROWS_KEY = "backup_rows"      # 지난 백업 때의 행 수 (급감 감지용)


def _slot_rows(path: Path) -> dict | None:
    """백업 슬롯 **파일 자체**의 행 수. 못 읽으면 None."""
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except Exception:                                     # noqa: BLE001
        return None
    try:
        return {t_: con.execute(f"SELECT COUNT(*) FROM {t_}").fetchone()[0]
                for t_ in ("snapshots", "changes")}
    except Exception:                                     # noqa: BLE001
        return None
    finally:
        con.close()


BACKUP_INFO_KEY = "backup_info"      # 백업 폴더 총용량·슬롯 수 — 상태 정보용 (재검토 2026-10-28 R3-F4)


def _slot_verified(state: State, slot: Path) -> bool:
    """그 슬롯이 지난 성공한 백업 그대로인가 — 그때 남긴 행 수(BACKUP_ROWS_KEY)와 슬롯 파일의 행 수가 같으면."""
    import json as _j
    try:
        want = _j.loads(state.get_meta(BACKUP_ROWS_KEY) or "{}")
    except ValueError:
        return False
    got = _slot_rows(slot)
    return bool(want) and got is not None and all(got.get(k) == want.get(k) for k in ("snapshots", "changes"))


def _note_backup_info(state: State, bdir: Path) -> None:
    import json as _j
    try:
        files = [p for p in bdir.glob("state_backup*") if p.is_file()]
        total = sum(p.stat().st_size for p in files)
        slots = sum(1 for p in files if re.fullmatch(r"state_backup_\d\.db", p.name) and p.stat().st_size)
        state.set_meta(BACKUP_INFO_KEY, _j.dumps({"bytes": total, "slots": slots, "dir": str(bdir),
                                                  "at": datetime.now(timezone.utc).isoformat()}, ensure_ascii=False))
    except (OSError, sqlite3.Error):
        pass


DB_INTEGRITY_KEY = "db_integrity"
LAST_RUN_FAILED_KEY = "last_run_failed"   # 보고 단계에서 되돌린 검사의 시각·사유 — 화면 배너 (검토60 ②)


BACKUP_DIR_PROBLEM_KEY = "backup_dir_problem"   # 마지막 백업 때 backup_dir 판정(감시 폴더 안이면 까닭 한 줄) — 화면 배너 (rvall RG2)


def backup_dir_in_watch(backup_dir, roots) -> str:
    """config의 backup_dir가 감시 폴더와 같거나 그 안이면 까닭 한 줄, 아니면 ''. 양식함 backup_dir_problem과 같은 말투·같은
    판정(inside_watch_root — 링크를 풀고 대소문자 없이). 그대로 두면 주간 백업이 감시 폴더에 state_backup_N.db를 쓰고 다음
    검사가 그것을 '추가'로 잡았다 — 원칙 2 (rvall A2)."""
    if not backup_dir:
        return ""
    from watcher.forms.settings import inside_watch_root
    r = inside_watch_root(backup_dir, roots or ())
    return f"백업 폴더가 감시 폴더 안에 있습니다({r}) — 감시 밖의 폴더를 골라 주세요" if r else ""


def backup_dir_for(db_path, backup_dir, roots=()) -> tuple[Path | None, str]:
    """이번 주 백업을 실제로 쓸 폴더와 알릴 문제 한 줄. backup_dir가 감시 폴더 안이면 그 폴더는 쓰지 않고 **기본 위치**
    (state.db 옆 backups)로 대신한다 — 백업을 통째로 멈추면 이력 사본이 늙기만 하는데 아무도 모르고(백업은 조용한 일),
    기본 위치는 설치가 처음부터 쓰던 곳이라 되살리기 안내·'없어진 이력' 흔적 찾기(missing_db_evidence)가 늘 본다.
    backup_dir를 손으로 감시 안에 적었는데 기본 위치마저 감시 폴더 안이면(state.db를 감시 공유에 둔 집) None — 건너뛰고 알린다.
    backup_dir를 적지 않은 집은 예전 그대로 기본 위치를 쓴다(이 검사로 백업이 새로 멈추지 않게)."""
    default = Path(db_path).parent / "backups"
    if not backup_dir:
        return default, ""
    why = backup_dir_in_watch(backup_dir, roots)
    if not why:
        return Path(backup_dir), ""
    if backup_dir_in_watch(default, roots):
        return None, why + " (기본 위치도 감시 폴더 안이라 주간 백업을 하지 않습니다)"
    return default, why + f" (주간 백업은 그 대신 기본 위치 {default}에 합니다)"


def _backup_db(state: State, db_path: Path, backup_dir: str | None = None, roots=()) -> None:
    """주 1회 state.db 자동 백업 — backups/ 아래 4개 슬롯 순환(약 한 달 보관).
    모든 이력이 파일 하나라 유실이 곧 신뢰 붕괴 (2026-08-29). 삭제 API 없이
    같은 슬롯을 덮어쓰는 방식이라 읽기 전용 원칙과도 충돌 없음.

    **설계 이력 (2026-09-10)**: 검토 세 번에서 세 번 다 이 자리가 깨졌다 —
    ①검증이 아예 없어 깨진 DB가 멀쩡한 사본을 덮음 ②고친 뒤에는 기준값이 파괴되는
    그 DB 안에 있어 정작 그 사고에서 방어가 건너뛰어짐 ③방어가 발동하면 기준값을
    갱신하지 않아 백업이 영구 정지. 원인은 방어가 아니라 **"급감이면 미룬다"는
    휴리스틱**이었다. 사고와 사람의 의도를 구분하려고 상태를 저장할 때마다 그 상태가
    새 구멍이 됐다. 그래서 상태를 없앴다:

    - 한 달치 방어는 **슬롯 4개가 이미 한다** — 사고는 한 주에 한 슬롯만 망가뜨리고,
      나머지 셋은 3주 더 남는다. 미루지 않아도 되살릴 사본이 있다.
    - 원본이 온전할 때만 쓰고(integrity_check), **쓴 뒤 그 백업을 다시 열어**
      원본과 행 수가 맞는지 확인한다 — 쓰다 만 백업을 성공이라 말하지 않는다.
    - 이력이 지난 사본들보다 크게 줄었으면 **경고만** 남기고 백업은 한다."""
    import sqlite3
    # 무결성은 백업 폴더보다 먼저 본다 — 백업 폴더(NAS)가 끊겨 여기서 돌아가면 검사도 안 돌아 배너가 옛
    # 상태로 굳고 새 손상도 못 잡았다 (검토36 F 낮음 4a)
    # 온전한지는 **하루 한 번** 먼저 본다 — 이번 주 몫이 이미 있으면(<6일) 검사 자체를 건너뛰어, 끝이 깨진 DB가
    # 몇 주째 돌아도 아무 표시가 없었고 그동안 가장 최근 정상 사본만 늙었다 (검토34 M5·검토36 C-7).
    # 결과는 meta에 남겨 화면이 지속 배너로 보인다
    import json as _json_i
    try:
        _prev = _json_i.loads(state.get_meta(DB_INTEGRITY_KEY) or "{}")
    except ValueError:
        _prev = {}
    _age_h = None
    try:
        _age_h = (datetime.now(timezone.utc) - datetime.fromisoformat(_prev["at"])).total_seconds() / 3600
    except (KeyError, TypeError, ValueError):
        pass
    if _age_h is None or _age_h >= 20 or _age_h < 0 or not _prev.get("ok", True):   # 음수 = 시계가 튀었다 돌아옴
        ok, why = state.integrity_ok()
        state.set_meta(DB_INTEGRITY_KEY, _json_i.dumps(
            {"ok": ok, "why": "" if ok else why, "at": datetime.now(timezone.utc).isoformat(),
             "since": (_prev.get("since") or datetime.now(timezone.utc).isoformat()) if not ok else ""},
            ensure_ascii=False))
    else:
        ok, why = True, ""
    # config backup_dir로 다른 디스크(NAS 등)를 지정할 수 있다 — 같은 디스크의 사본은 그
    # 디스크가 죽으면 함께 죽는다 (2026-09-02 위시, 검토19 운영 ⑬). 없으면 DB 옆 backups/
    # 감시 폴더 안이면 그 폴더에 쓰지 않는다 — 기본 위치로 대신하고 알린다(화면 배너는 같은 판정을 설정에서 바로 본다) (rvall A2)
    bdir, _bwhy = backup_dir_for(db_path, backup_dir, roots)
    if _bwhy:
        print(f"경고: {_bwhy}", file=sys.stderr)
    # 화면 배너는 이 판정만 읽는다 — 대시보드가 backup_dir 경로를 직접 풀면(realpath) 꺼진 NAS에서 요청마다 21초 멈췄다 (rvall RG2)
    try:
        state.set_meta(BACKUP_DIR_PROBLEM_KEY, _bwhy or None)
    except sqlite3.Error:
        pass
    if bdir is None:
        return
    try:
        bdir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"경고: 백업 폴더를 만들 수 없어 이번 주 백업을 건너뜁니다 ({bdir}: {e})",
              file=sys.stderr)
        return
    # 연속 주 번호로 — ISO 주(1~53)는 53주 해 연말에 같은 슬롯을 두 주 연속 써 '한 달 보관'이 3주가 됐다 (검토50 D 낮음 5).
    # 월요일 시작 주(1년 1월 1일이 월요일이라 toordinal 6을 더하면 월요일마다 바뀐다)
    week = (datetime.now().date().toordinal() + 6) // 7
    dst = bdir / f"state_backup_{week % 4 + 1}.db"
    # 경과가 **음수**(시계가 뒤로 감 — 슬롯 mtime이 미래)면 '이미 있음'이 아니다 — 시계가 그 시각을 지날 때까지 백업이 0이었다
    # (검토43 D 낮음 5)
    # 6.5일 — 매일 같은 시각에 돌면 일요일이 정확히 6일째라 '< 6일'을 못 넘어 주 2회(월·일) 백업했다 (검토60 ⑥)
    if dst.exists() and 0 <= (datetime.now().timestamp() - dst.stat().st_mtime) < 6.5 * 86400:
        # 이번 주 몫은 이미 있음. 옛 판이 남긴 DB 크기의 임시 사본은 이번 주 슬롯이 검증된 사본일 때만 비운다 (R3-F4)
        _tmp0 = dst.with_name("state_backup.new")
        try:
            if _tmp0.exists() and _tmp0.stat().st_size and _slot_verified(state, dst):
                _tmp0.write_bytes(b"")
                _note_backup_info(state, bdir)
        except OSError:
            pass
        return
    # 옛 판(v0.57.1x)이 남긴 슬롯별 임시 사본 — 지금은 state_backup.new 하나만 쓴다. 아무도 덮지 않아 DB 크기×3이 영구히
    # 묶였다 (검토43 D 낮음 4). Drev가 만든 백업 폴더의 자기 파일이라 감시 파일과 무관하다
    # 지우기는 원칙상 어디서도 쓰지 않으므로(읽기 전용 가드) 0바이트로 비운다
    for _old in bdir.glob("state_backup_[0-9].db.new"):
        try:
            if _old.stat().st_size:
                _old.write_bytes(b"")
        except OSError:
            pass
    if not ok:
        print(f"경고: state.db가 온전하지 않아 백업을 건너뜁니다 ({why}) — "
              f"{bdir} 안의 지난 사본은 그대로 둡니다. 되살리는 순서는 도움말의 "
              f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다.", file=sys.stderr)
        return

    now = state.row_counts()
    # 지난 사본들과 견줘 크게 줄었으면 **알리되 막지는 않는다** (막으면 백업이 멈춘다).
    # 덮어쓸 슬롯도 센다 — 그것도 4주 전의 사본이고, 첫 달에는 그것뿐일 수 있다
    others = [r for f in sorted(bdir.glob("state_backup_*.db"))
              for r in (_slot_rows(f),) if r]
    if others:
        best = max(others, key=lambda r: r.get("changes", 0))
        gone = [k for k in ("snapshots", "changes")
                if best.get(k, 0) > 20 and now.get(k, 0) < best[k] * 0.5]
        if gone:
            print("경고: 이력이 지난 사본보다 크게 줄었습니다 (" + ", ".join(
                f"{k} {best.get(k)}→{now.get(k)}" for k in gone)
                + f"). 사람이 지운 것이면 정상입니다. 사고라면 {bdir} 안의 다른 "
                f"사본으로 되살리세요 — 이번 주 슬롯({dst.name})만 덮어씁니다.",
                file=sys.stderr)

    # 슬롯을 제자리에서 덮어쓰면 디스크 풀·중단 때 4주 전 사본까지 잃는다 (검토19 운영 ④).
    # 먼저 옆의 .new에 쓰고 검증한 뒤 슬롯으로 옮긴다 — 이름 바꾸기(삭제·이동 API)는
    # 읽기 전용 원칙으로 쓰지 않으므로 SQLite 백업 API로 한 번 더 복사한다. 슬롯까지 검증되면
    # .new는 0바이트로 비운다(R3-F4) — 슬롯 검증이 실패한 주에만 가장 최근의 검증된 사본으로 남는다. 백업 파일은 WAL이 아니라
    # 단일 파일(DELETE 저널)로 — .db만 옮겨도 온전하도록
    def _copy_into(src_conn, path: Path) -> None:
        dc = sqlite3.connect(path)
        try:
            src_conn.backup(dc)
            # 백업 API는 머리(WAL 표식)까지 복사한다 — 복사 **뒤에** 단일 파일로 바꿔야 한다
            dc.execute("PRAGMA journal_mode=DELETE")
        finally:
            dc.close()

    # 임시 사본은 **하나**를 돌려 쓴다 — 슬롯마다 따로 두면 4슬롯+4임시로 DB의 8배(4만 파일 1년이면
    # 20GB대)가 됐다 (검토34 C M2). 지울 수 없으니(읽기 전용 가드) 이름을 하나로 묶는다
    tmp = dst.with_name("state_backup.new")
    try:
        _copy_into(state.conn, tmp)
    except sqlite3.DatabaseError:
        # 지난주 복사 중 정전 등으로 깨진 임시 사본 위에는 백업 API가 쓰지 못해 **매주** 실패했다 (검토37 C 중간 4).
        # 지울 수 없으니(읽기 전용 가드) 0바이트로 비운 뒤 다시 쓴다
        with open(tmp, "wb"):
            pass
        _copy_into(state.conn, tmp)
    made = _slot_rows(tmp)
    if made is None or any(made.get(k) != now.get(k) for k in ("snapshots", "changes")):
        print(f"경고: 백업을 저장했지만 다시 읽었을 때 내용이 원본과 다릅니다 "
              f"({tmp.name}: {made} vs {now}) — 지난 슬롯 {dst.name}은 건드리지 "
              f"않았습니다. 이번 주 {tmp.name}은 되살리기에 쓰지 마세요. "
              f"디스크 공간·권한을 확인하세요.", file=sys.stderr)
        return
    src = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True)
    try:
        try:
            _copy_into(src, dst)
        except sqlite3.DatabaseError as e:
            # 슬롯도 깨졌으면(백업 도중 정전) 그 슬롯은 4주마다 영영 실패했다 — 임시 사본처럼 비우고 다시 (검토49 A 낮음 8).
            # **깨진 슬롯일 때만** — 디스크 가득·입출력 오류에도 비우면 4주 전 사본을 0바이트로 잃었다 (검토50 A 중간 3)
            if not re.search(r"malformed|not a database|file is encrypted", str(e), re.I):
                raise
            with open(dst, "wb"):
                pass
            _copy_into(src, dst)
    finally:
        src.close()
    # 쓴 것을 **다시 열어** 확인한다 — 디스크가 차거나 중간에 끊긴 백업을
    # "저장 완료"라 말하지 않기 위해
    made = _slot_rows(dst)
    if made is None or any(made.get(k) != now.get(k) for k in ("snapshots", "changes")):
        print(f"경고: 백업을 저장했지만 다시 읽었을 때 내용이 원본과 다릅니다 "
              f"({dst.name}: {made} vs {now}) — 검증된 사본은 {tmp.name}에 있습니다. "
              f"디스크 공간·권한을 확인하세요.", file=sys.stderr)
        return
    state.set_meta(BACKUP_ROWS_KEY, __import__("json").dumps(now))   # 화면 표시용
    # 슬롯이 검증됐으면 임시 사본은 비운다 — 다음 주까지 DB 크기 그대로(실측 460MB) 상주해 백업 폴더가 슬롯 넷 + DB 하나였다
    # (재검토 2026-10-28 R3-F4). 지우기는 원칙상 쓰지 않으므로(읽기 전용 가드) 0바이트로. 가장 최근 검증된 사본은 이제 슬롯이다
    try:
        tmp.write_bytes(b"")
    except OSError:
        pass
    _note_backup_info(state, bdir)
    print(f"이력 백업: {dst.name} (주 1회, 4개 순환, 확인 완료) — 되살리는 순서는 "
          f"도움말의 '백업 · 다른 PC로 이전 · 되살리기'에 있습니다 "
          f"(state.db-wal을 먼저 지워야 합니다)")


def _housekeep(state: State, cfg: dict, args, skip_weekly: bool = False) -> None:
    """검사 뒤 정리: 보존 기간 지난 상세 정리 + DB 주간 백업 + 월요일 주간 요약.
    전부 실패해도 검사 결과에는 영향 없음 — 단, 원인은 stderr에 남긴다."""
    # 시계가 직전 검사보다 30일 넘게 앞서 있으면(배터리 나간 BIOS·잘못 맞춘 시각) 보존 기간 정리와 주간 요약을 건너뛴다 —
    # 1년 앞으로 튄 검사 한 번에 전/후 사진 242개와 추출 기록 절반이 지워지고 미래 주간 요약이 생겼다 (검토43 D 중간 2)
    clock_jump = False
    try:
        rows = state.conn.execute("SELECT run_at FROM snapshots ORDER BY id DESC LIMIT 2").fetchall()
        if len(rows) == 2:
            gap = datetime.fromisoformat(rows[0][0]) - datetime.fromisoformat(rows[1][0])
            clock_jump = gap > timedelta(days=30)
            if gap < timedelta(hours=-1):
                print("경고: 이번 검사 시각이 직전 검사보다 이릅니다 — PC 시계를 확인하세요 (주간 요약·보존 기간 계산이 틀어집니다)",
                      file=sys.stderr)
    except (ValueError, TypeError, sqlite3.Error):
        clock_jump = False
    # 한 번 튄 시계가 틀린 채 머무르면 이튿날 검사는 직전과 하루 차이라 그대로 정리했다 — 튀기 전 마지막 검사 시각을 남기고,
    # 시계가 그 근처(30일 안)로 돌아오거나 사람이 화면에서 '시계가 맞습니다'를 누를 때까지 **PC 시계 대신 '마지막 정상 검사 +
    # 그 뒤 검사 횟수만큼의 날'을 기준으로** 정리한다. 서버 파일 시각으로 저절로 푸는 방식은 파일 몇 개를 한 번 쓰는 것으로 풀려
    # 틀린 '오늘' 기준 정리가 돌았다(검토47 E 중간 1) — 풀지 않고 안전한 기준 시각으로 정리를 계속하면 무인 설치본도 멈추지 않는다
    prune_now = None
    try:
        base = state.get_meta(CLOCK_SUSPECT_KEY)
        if clock_jump and base is None and len(rows) == 2:
            base = rows[1][0]
            state.set_meta(CLOCK_SUSPECT_KEY, base)
        elif base is not None and not clock_jump                 and datetime.fromisoformat(rows[0][0]) - datetime.fromisoformat(base) <= timedelta(days=30):
            state.set_meta(CLOCK_SUSPECT_KEY, None)          # 시계가 돌아왔다
            print("시계 확인 풀림 — PC 시계가 마지막 정상 검사 근처로 돌아왔습니다. 정리·주간 요약을 PC 시계로 다시 합니다")   # 검토47 C 중간 5
            base = None
        if base is not None:
            clock_jump = True
            n_after = state.conn.execute("SELECT COUNT(*) FROM snapshots WHERE run_at > ?", (base,)).fetchone()[0]
            prune_now = min(datetime.fromisoformat(base) + timedelta(days=max(int(n_after) - 1, 0)),
                            datetime.fromisoformat(rows[0][0]))
    except (ValueError, TypeError, sqlite3.Error, NameError, IndexError):
        pass
    if clock_jump:
        print("경고: PC 시계가 마지막 정상 검사보다 30일 넘게 앞서 있습니다 — 시계를 확인하세요. 주간 요약은 건너뛰고, 오래된 기록 "
              "정리는 PC 시계 대신 마지막 정상 검사 기준으로 실제 검사한 날수만큼만 합니다", file=sys.stderr)
        skip_weekly = True
    # 온전하지 않은 이력 파일에는 정리(DELETE)·VACUUM을 걸지 않는다 — 백업과 같은 논리. 배너는 '되살리세요'인데 프로그램이
    # 매일 그 파일을 고쳐 썼다 (검토49 A 중간 4)
    try:
        import json as _json_h
        _integ = _json_h.loads(state.get_meta(DB_INTEGRITY_KEY) or "{}")
    except Exception:
        _integ = {}
    _damaged = bool(_integ) and not _integ.get("ok", True)
    if _damaged:
        print("경고: 이력 파일이 온전하지 않아 오래된 기록 정리·공간 회수를 건너뜁니다 — 백업에서 되살린 뒤 다시 합니다",
              file=sys.stderr)
    _ld = low_disk_note(cfg)
    if _ld:
        print(f"경고: {_ld}", file=sys.stderr)
    try:
        days = int(cfg.get("retention_days", 90) or 0)
        # 0(정리 안 함)이어도 지난 스냅샷의 파일 목록·고아 추출본은 정리한다 — 사진만 보존 일수를 따른다 (검토20 r15-2)
        if not (clock_jump and prune_now is None) and not _damaged:
            state.prune_details(days, now=prune_now)
    except Exception as e:
        print(f"경고: 오래된 기록 정리 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        # 현재 파일의 그림 + 보존 기간 안의 이전 판 그림 (0 = 무기한)
        if not (clock_jump and prune_now is None) and not _damaged:
            state.prune_renders(int(cfg.get("retention_days", 90) or 0), now=prune_now)
    except Exception as e:
        print(f"경고: 페이지 그림 기록 정리 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        # 지운 기록이 차지하던 빈 페이지를 디스크에 돌려준다 — 전에는 파일 크기가
        # 역대 최대치에 영구 고정됐고 백업이 그 빈 페이지까지 복사했다
        got = None if _damaged else state.reclaim_space()
        if got:
            print(f"이력 파일 정리: {got['before']/1048576:.0f}MB → "
                  f"{got['after']/1048576:.0f}MB ({got['freed']/1048576:.0f}MB 회수)")
    except Exception as e:
        print(f"경고: 이력 파일 공간 회수 실패(검사 결과는 정상): {e}", file=sys.stderr)
    # 백업은 정리·공간 회수 **뒤에** — 앞에서 뜨면 사본이 늘 정리 전(부푼) 크기라 66MB 이력에 백업이 785MB였다 (검토54 ⑥26).
    # 정리가 실패해도 지난주 사본들이 남아 있고, 온전하지 않은 이력은 위에서 정리를 건너뛴다
    try:
        _backup_db(state, Path(args.state_db or cfg["state_db"]), cfg.get("backup_dir"),
                   roots=[str(r) for r in (cfg.get("roots") or [])] + ([str(args.root)] if getattr(args, "root", None) else []))
    except Exception as e:
        print(f"경고: 이력 백업 실패(검사 결과는 정상): {e}", file=sys.stderr)
    try:
        _warn_disk(state, Path(args.brief_dir or cfg["brief_dir"]))
    except Exception as e:
        print(f"경고: 저장 공간 점검 실패(검사 결과는 정상): {e}", file=sys.stderr)
    if not args.dry_run and not skip_weekly:
        try:
            # 한 주 통째로 꺼져 있었으면 그 앞 주(변경이 있던 주)의 요약이 영구히 빠졌다 (검토38 R7 2) —
            # 한 주 앞 것부터 차례로(이미 있으면 건너뛴다)
            _now = datetime.now()
            # 2주 넘게 꺼져 있던 집은 그 앞 주 요약이 영구히 빠졌다 (검토41 S9 중간 4) — 최대 8주 앞까지, 첫 검사 이전
            # 주는 빼고(설치 전 주를 '검사 0/7일'로 만들지 않게) 오래된 주부터 차례로. 이미 있는 주는 건너뛴다
            try:
                _first = state.conn.execute("SELECT MIN(run_at) FROM snapshots").fetchone()[0]
                _first_day = _local_date_of(_first) if _first else None
            except Exception:
                _first_day = None
            # 마지막으로 요약한 주 **다음**부터만 — 파일이 있나로만 보면 브리핑 폴더를 바꾸거나 옛 브리핑을 옮긴 날 옛 주
            # 요약 6통이 한꺼번에 만들어지고 발송됐다 (검토42 A 중간 3). 기록이 없는 옛 설치본은 예전처럼 한 주 앞까지만
            _last = state.get_meta("weekly_last_monday")
            try:
                _last_day = datetime.fromisoformat(_last).date() if _last else None
            except ValueError:
                _last_day = None
            for _back in range(56, -1, -7):
                _d = (_now - timedelta(days=_back)).date()
                _week_end = _d - timedelta(days=_d.weekday() + 1)        # 그 요약이 다루는 주의 일요일
                if _back and (_first_day is None or _week_end < _first_day):
                    continue
                if _back and (_last_day is None and _back > 7 or _last_day is not None
                              and _d - timedelta(days=_d.weekday()) <= _last_day):
                    continue
                wp = write_weekly_summary(
                    state, cfg, Path(args.brief_dir or cfg["brief_dir"]),
                    _now - timedelta(days=_back))
                if wp:
                    print(f"주간 요약 저장: {wp}")
            state.set_meta("weekly_last_monday", (_now.date() - timedelta(days=_now.weekday())).isoformat())
        except Exception as e:
            print(f"경고: 주간 요약 생성 실패(검사 결과는 정상): {e}", file=sys.stderr)


# 브리핑 폴더가 이만큼 커지면 알린다. 프로젝트 1개·하루 최대 13.1MB를 실측했다 —
# 5개면 1년에 24GB다. Drev는 산출물도, 자기 브리핑도 **지우지 않는다**(원칙 2) —
# 사람에게 알리고 정리는 사람이 한다 (2026-09-09 저장 검토 차단 4)
BRIEF_WARN_BYTES = 3 * 1024 ** 3
DB_WARN_BYTES = 8 * 1024 ** 3


def dir_size(path: Path) -> tuple[int, int]:
    """(바이트, 파일 수) — 폴더 하나만 센다(하위 폴더 포함)."""
    total = n = 0
    try:
        for f in path.rglob("*"):
            try:
                if f.is_file():
                    total += f.stat().st_size
                    n += 1
            except OSError:
                continue
    except OSError:
        pass
    return total, n


LOW_DISK_BYTES = 500 * 1024 ** 2


def low_disk_note(cfg: dict) -> str | None:
    """이력·브리핑·백업 폴더가 있는 드라이브의 여유 공간이 바닥이면 한 줄. 가득 차면 검사가 'database or disk is full'로
    매일 조용히 실패하고 수신자에게는 '조용한 날'과 같았다 — 여유 공간을 어디서도 보지 않았다 (검토49 A 중간 2)."""
    import shutil as _sh
    seen = set()
    for key in ("state_db", "brief_dir", "backup_dir"):
        v = (cfg or {}).get(key)
        if not v:
            continue
        p = Path(v)
        p = p if p.is_dir() else p.parent
        try:
            p = p.resolve()
            drive = p.anchor or str(p)
            if drive in seen:
                continue
            seen.add(drive)
            u = _sh.disk_usage(p)
        except OSError:
            continue
        # 비율 기준은 작은 드라이브(100GB 미만)에만 — 2TB에 40GB 남아도 '부족'이라 했다 (검토50 A 낮음 5)
        if u.free < LOW_DISK_BYTES or (u.total and u.total < 100 * 1024 ** 3 and u.free / u.total < 0.02):
            return (f"{drive} 드라이브 여유 공간이 {u.free / 1024 ** 2:,.0f}MB뿐입니다 — 가득 차면 검사·브리핑·백업이 실패합니다. "
                    f"필요 없는 파일을 정리하거나 설정의 '보존 기간'을 줄이세요.")
    return None


def _warn_disk(state: State, brief_dir: Path) -> None:
    """이력 파일·브리핑 폴더가 너무 커지면 사람에게 알린다."""
    rep = state.space_report()
    if rep["bytes"] >= DB_WARN_BYTES:
        print(f"경고: 이력 파일이 {rep['bytes'] / 1024 ** 3:.1f}GB입니다 — 설정의 "
              f"'보존 기간'을 줄이면 다음 검사 때 줄어듭니다 "
              f"(0=정리 안 함으로 두면 계속 커집니다).", file=sys.stderr)
    size, n = dir_size(brief_dir)
    if size >= BRIEF_WARN_BYTES:
        print(f"경고: 브리핑 폴더가 {size / 1024 ** 3:.1f}GB({n}개)입니다 — "
              f"{brief_dir}\n  Drev는 파일을 지우지 않습니다(읽기 전용). 오래된 "
              f"브리핑은 직접 지우거나 다른 디스크로 옮겨 주세요.", file=sys.stderr)


def _rotate_logs() -> None:
    """검사를 시작할 때 로그가 너무 크면 한 번 밀어낸다.

    상한이 없어 몇 년 쓴 설치본의 watcher.log가 수백 MB가 됐고, 화면·업데이트
    진단이 시작마다 그 파일을 통째로 읽었다 (2026-09-09 자동 실행 검토 중간 2)."""
    try:
        from watcher.logfile import rotate
        base = (Path(sys.executable).parent if getattr(sys, "frozen", False)
                else Path.cwd())
        for name in ("watcher.log", "run_daily.log"):
            rotate(base / name)
    except Exception:
        pass


SCAN_TROUBLE_KEY = "scan_trouble"     # {"at":ISO, "missing":[...], "fatal":bool}


def _check_missing_db(cfg: dict, db_path: Path) -> None:
    """백업을 다른 곳(NAS 등, backup_dir)에 두는 집은 DB 옆 backups/가 비어 있어, state.db가 사라져도 흔적이
    없다고 보고 조용히 새로 시작했다 (검토36 F 낮음 4b) — 그 폴더의 사본도 흔적으로 본다."""
    from watcher.state import MissingDatabase, missing_db_evidence
    gone = missing_db_evidence(db_path, cfg.get("backup_dir"))
    if gone:
        raise MissingDatabase(db_path, gone)
    bd = cfg.get("backup_dir")
    if bd and not db_path.exists():
        # 아직 안 만든 폴더(첫 설치)는 괜찮다 — 드라이브·공유(\\서버\공유\) 자체에 닿지 않을 때만 끊긴 것
        try:
            anchor = Path(bd).anchor
            # 상대 경로(앵커 없음)는 이 PC 안이다 — 첫 설치를 '없어졌습니다'로 멈췄다 (검토39 F2 ⑤)
            reachable = Path(bd).is_dir() or not anchor or Path(anchor).exists()
        except OSError:
            reachable = False
        if not reachable:
            # 백업 폴더(NAS)가 끊긴 채 이력 파일이 없으면 '처음'인지 '사라짐'인지 알 수 없다 — 새로 쌓지 않는다
            # (검토37 D2). 정말 처음이면 NAS를 연결하거나 설정의 backup_dir을 비우고 다시 실행한다
            raise MissingDatabase(db_path, [f"{bd} (백업 폴더에 닿지 못함 — 연결을 확인하세요)"])


def _note_scan_trouble(db_path: Path, missing: list[str], fatal: bool) -> None:
    """검사가 감시 폴더에 닿지 못한 사실을 state.db에 남긴다(없으면 지운다).

    화면(web.scan_health)이 이것을 읽어 지속 배너로 보여 준다 — 한 번 스쳐 사라지는
    문구로는 자동 실행이 실패한 날을 아무도 모른다."""
    import json
    try:
        with State(db_path) as st:
            if missing:
                st.set_meta(SCAN_TROUBLE_KEY, json.dumps(
                    {"at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                     "missing": missing[:8], "fatal": bool(fatal)}, ensure_ascii=False))
            else:
                st.set_meta(SCAN_TROUBLE_KEY, None)
    except Exception:
        pass              # 기록 실패가 검사를 막지는 않는다


# 옛 판 config.example.yaml이 **활성 줄**로 두었고 위저드가 그대로 복사한 기본 목록 (v0.30대 5종 → 2026-09-28 6종)
_OLD_DEFAULT_EXTS = (frozenset({".dwg", ".dxf", ".pdf", ".xlsx", ".docx"}),
                     frozenset({".dwg", ".dxf", ".pdf", ".xlsx", ".xlsm", ".docx"}))


def _old_config_notes(cfg: dict) -> list:
    """옛 판 설정이 남긴 것 중 말없이 넘어가던 것 — 검사 기록(watcher.log)에 한 줄씩 (재검토 2026-10-28 R7-D3·D4).
    목록을 바꾸지는 않는다 — 같은 5종을 사람이 골랐을 수도 있다. 화면의 '기본 감시 형식 중 이 PC 목록에 없는 것' 칸과 같은 규칙
    ('이대로 둠'을 누른 형식은 다시 말하지 않는다)."""
    out = []
    exts = {str(e).lower() for e in (cfg.get("extensions") or ())}
    if exts in _OLD_DEFAULT_EXTS:
        keep = {str(e).lower() for e in (cfg.get("ext_defaults_ok") or ())}
        miss = [e for e in DEFAULT_EXTENSIONS if e not in exts and e not in keep]
        if miss:
            out.append(f"참고: 감시 확장자가 옛 판 기본 목록({len(exts)}종) 그대로입니다 — 지금 기본에 더해진 {', '.join(miss)}는 "
                       f"감시하지 않습니다. 감시하려면 감시 PC 화면의 '기본 감시 형식 중 이 PC 목록에 없는 것'에서 [켜기]를, 지금 "
                       f"목록이 맞으면 [이대로 둠]을 누르세요 (설정 › 감시 확장자)")
    if isinstance(cfg.get("schedule"), dict):
        out.append("참고: 설정 파일의 'schedule:' 블록은 옛 형식입니다 — 매일 검사 시각은 Windows 작업 스케줄러 등록"
                   "(설정 › 자동 실행)이 정하고, 이 값은 등록을 찾지 못할 때 '오늘 예약 검사가 이미 돌았나'를 볼 때만 참고합니다")
    return out


_LOCK_HEARTBEAT_SEC = 300.0     # 검사 잠금 심장 박동 간격 — 잠금이 낡았는지는 이것이 멈춘 지 6시간으로 본다


@contextlib.contextmanager
def _lock_heartbeat(db_path, pid: int):
    """잠금을 쥔 동안 따로 연 연결로 잠금 값의 시각(벽시계·단조 시계)을 주기적으로 새로 적는다 — 6시간 넘게 도는 검사, 검사 중
    시계가 앞으로 튄 PC에서 다음 검사가 살아 있는 검사의 잠금을 빼앗고 진행 중 스냅샷을 되돌렸다 (재검토 2026-10-28 R8-1).
    내 잠금일 때만 고치고, DB가 잠겨 있으면 이번 박동은 건너뛴다(검사 본체를 막지 않게). 실패는 검사에 영향 없음."""
    from watcher.state import lock_value
    stop = threading.Event()

    def _beat() -> None:
        while not stop.wait(_LOCK_HEARTBEAT_SEC):
            try:
                con = sqlite3.connect(str(db_path), timeout=2)
                try:
                    con.execute("UPDATE meta SET value = ? WHERE key = 'run_lock' AND value LIKE ?",
                                (lock_value(pid), f"{pid}:%"))
                    con.commit()
                finally:
                    con.close()
            except Exception:       # noqa: BLE001 — 박동 한 번 거르는 것은 무해(6시간 여유)
                pass
    t = threading.Thread(target=_beat, name="drev-lock-heartbeat", daemon=True)
    t.start()
    try:
        yield
    finally:
        stop.set()
        t.join(timeout=5)


def cmd_run(args: argparse.Namespace) -> int:
    # 검사가 돌기 전에 남아 있던 멈춤 요청은 무시 — 진행 표시가 첫 줄부터 나오므로
    # 여기서 지워야 한다 (2026-09-02: '준비 중' 표시에서 바로 멈추던 것)
    STOP.clear()
    # '같은 서버가 방금 실패했다'는 한 검사 안의 이야기다 — 창 프로세스에서는 아침의 SMTP 실패가
    # 낮의 [지금 검사]·보충 검사까지 모든 통을 침묵시켰다 (검토30 D 4-2, 같은 프로세스 4회 실측)
    _MAIL_STATE.update(down="", skipped=0, sent=0, draft_fail="", drafted=0, refused=[], unsent=[])
    _rotate_logs()
    cfg = load_config(Path(args.config))
    try:                                   # 설정 화면을 안 여는 PC의 평문 SMTP 비밀번호도 감싼다 (리뷰10)
        _pw_note = _protect_config_password(Path(args.config), cfg)
        if _pw_note:
            print(f"  {_pw_note}", flush=True)
    except Exception:
        pass
    if getattr(args, "if_missed", False):
        _ran = due_already_ran(cfg, Path(args.state_db or cfg["state_db"]))
        if _ran:
            print(f"{_ran} 예약 검사가 이미 돌았습니다 — 로그인 보충 실행은 건너뜁니다.", flush=True)
            return 0
    for _note in _old_config_notes(cfg):
        print(_note, flush=True)
    from watcher.extract import base as _tag_base   # 회사별 태그 관례 (2026-08-26, 설정 화면의 꼴 선택 2026-10-04)
    _tag_err = _tag_base.apply_tag_config(cfg)
    if _tag_err:
        print(f"경고: {_tag_err}", file=sys.stderr)
    try:            # 브리핑의 [사내망에서 보기·확인] 링크 — 양식함이 켜져 있고 사내망 주소가 있을 때만 (갈래 N, FORMS.md 11절)
        from watcher.brief import set_lan_base
        from watcher.forms.settings import lan_changes_base
        set_lan_base(lan_changes_base(cfg))
    except Exception:
        from watcher.brief import set_lan_base
        set_lan_base("")
    roots_cfg = [args.root] if args.root else cfg["roots"]
    if not roots_cfg:
        print("오류: 감시 폴더가 없습니다 — 설정 화면 또는 config.yaml의 roots에 추가하세요.",
              file=sys.stderr)
        return 2
    all_roots = [Path(r) for r in roots_cfg]
    all_labels = _root_labels(all_roots)
    missing = [(r, lb) for r, lb in zip(all_roots, all_labels) if not r.is_dir()]
    for m, _lb in missing:
        print(f"경고: 감시 폴더에 접근할 수 없음(이전 상태 이월): {m}", file=sys.stderr)
    roots = [r for r in all_roots if r.is_dir()]
    # Drev가 쓰는 파일(이력·브리핑·백업)이 감시 폴더 안이면 감시 대상 공유에 쓰게 된다 — 원칙 2 취지 (검토43 E 낮음 7).
    # 막으면 공유 폴더에 풀어 쓰던 집의 검사가 갑자기 서므로 알리기만 한다.
    # 백업 폴더는 여기서 빼다 — 감시 안이면 백업이 그 폴더에 쓰지 않고 기본 위치로 대신하며, 경고는 _backup_db(로그)와
    # 화면의 backup_dir_banner(설정을 바로 봄)가 한다. '그 공유에 기록을 씁니다'가 거짓이 된다 (rvall A2)
    _inside: list = []
    for _nm, _p in (("이력 파일", args.state_db or cfg.get("state_db")), ("브리핑 폴더", args.brief_dir or cfg.get("brief_dir")),
                    ("실행 기록", str(Path.cwd() / "watcher.log")),
                    ("별칭 사전", cfg.get("aliases"))):
        if not _p:
            continue
        try:
            _rp = Path(_p).resolve()
            _in = next((r for r in roots if _rp == r.resolve() or _rp.is_relative_to(r.resolve())), None)
        except (OSError, ValueError):
            _in = None
        if _in is not None:
            print(f"경고: {_nm}({_rp})이 감시 폴더({_in}) 안에 있습니다 — Drev는 감시 파일을 건드리지 않지만 그 공유에 "
                  f"기록을 씁니다. 설정에서 감시 폴더 밖으로 옮기세요", file=sys.stderr)
            _inside.append(f"{_nm}: {_rp}")
    # 로그에만 남으면 아무도 못 본다 — 화면 배너가 읽게 이력에도 (검토44 E 낮음 7). 이력 파일이 없으면 만들지 않는다
    # (사라진 이력 감지가 먼저다)
    try:
        _dbp = Path(args.state_db or cfg["state_db"])
        if _dbp.exists():
            import json as _json_in
            with State(_dbp) as _st_in:
                _st_in.set_meta(OUTPUTS_INSIDE_KEY, _json_in.dumps(_inside, ensure_ascii=False) if _inside else None)
    except Exception:
        pass
    # 접근 못 한 폴더를 **화면이 알 수 있게** 기록한다. 지금까지는 stderr 한 줄뿐이라,
    # 네트워크 드라이브가 끊긴 채 07:00 배치가 며칠 실패해도 대시보드는 계속
    # "마지막 검사 …정상"이었다 (2026-09-09 웹 검토 차단 1). 배치는 다른 프로세스라
    # DB를 통해서만 화면에 닿는다
    try:
        _check_missing_db(cfg, Path(args.state_db or cfg["state_db"]))
        _note_scan_trouble(Path(args.state_db or cfg["state_db"]),
                           [str(r) for r, _lb in missing],
                           fatal=not roots)
    except CorruptDatabase:
        pass            # 기록은 건너뛴다 — 아래 본 검사 열기가 같은 사유로 멈추고 안내한다
    if not roots:
        print("오류: 존재하는 감시 폴더가 하나도 없습니다.", file=sys.stderr)
        # 그날의 흔적을 브리핑 폴더에도 남긴다 — 복구 뒤엔 어디에도 "그날 검사가 안 됐다"가 없었다
        # (검토21 파일럿 중간 10). 스냅샷·메일은 만들지 않는다
        try:
            bdir = Path(args.brief_dir or cfg["brief_dir"])
            bdir.mkdir(parents=True, exist_ok=True)
            now_ = datetime.now()
            bp = _unique_brief(bdir / brief_filename(now_), now_)
            html_ = build_brief(
                [], now_, ", ".join(str(r) for r in all_roots),
                scan_errors=[(str(r) + "/", "감시 폴더에 접근할 수 없어 이날 검사를 하지 못했습니다 — "
                              "다음 검사에서 그동안의 변경을 다시 잡습니다") for r, _lb in missing],
                scanned_count=0)
            bp.write_text(html_, encoding="utf-8")
            print(f"브리핑 저장: {bp} (검사 못 한 날의 기록)")
            # 메일도 한 통 — 감시 폴더 전체가 끊긴 날이 받는 쪽에서 '조용한 날'과 똑같았다. 일부 폴더만
            # 끊긴 날은 메일이 나가는데 하나뿐인 감시 폴더가 끊기면 침묵했다 (검토25 브리핑 C-2, 원칙 5)
            if not getattr(args, "dry_run", False) and cfg.get("mail"):
                _deliver(cfg, {**cfg["mail"], "recipients": _recipients_for(cfg)},
                         f"[Drev] {now_.strftime('%Y-%m-%d')} 검사 못 함 — 감시 폴더 연결 안 됨 "
                         f"({len(missing)}개)", html_, bp)
        except Exception as e:      # 조용히 삼키면 '검사 못 한 날' 기록이 왜 없는지 아무도 모른다 (검토60 ③)
            print(f"경고: 검사 못 한 날의 브리핑·메일을 남기지 못했습니다 ({type(e).__name__}: {e})", file=sys.stderr)
        return 2

    _set_progress("준비 중")
    # 경로 키는 항상 '폴더라벨/상대경로' — 폴더를 더하고 빼도 기존 키가 흔들리지 않는다.
    # 라벨은 설정의 전체 목록으로 매긴다 — 그날 안 붙은 폴더 때문에 남은 폴더의
    # 라벨(~2)이 바뀌면 안 된다
    labels = [lb for r, lb in zip(all_roots, all_labels) if r.is_dir()]
    db_path = Path(args.state_db or cfg["state_db"])
    try:
        _check_missing_db(cfg, db_path)
        state = State(db_path)
    except CorruptDatabase as e:
        # 날 traceback 대신 한국어 한 줄 + 되살리기 절차 위치 (검토19 운영 ①). 화면 배너용 기록은
        # DB 자체가 깨졌으므로 남길 수 없다 — 화면은 같은 예외를 잡아 전용 페이지를 낸다
        print(f"오류: {e}", file=sys.stderr)
        return 5
    with state:
        # 프로세스 간 잠금 — 자동 실행과 [지금 검사]가 겹치지 않게 (core H4)
        _wait_until = time.time() + float(getattr(args, "lock_wait", 0) or 0)
        _told = False
        while not state.acquire_run_lock(os.getpid()):
            if time.time() >= _wait_until:
                print("다른 검사(또는 판 교체 뒤 추출 기록 갱신)가 이미 진행 중이거나 이력 파일이 잠겨 있습니다 — "
                      "끝난 뒤 다시 시도하세요.", file=sys.stderr)
                _set_progress("")
                return 4
            if not _told:
                print("다른 검사·추출 기록 갱신이 끝나기를 기다립니다 (예약 검사, 최대 "
                      f"{int(float(getattr(args, 'lock_wait', 0)) // 60)}분)", flush=True)
                _told = True
            time.sleep(10)
        try:
            with _lock_heartbeat(db_path, os.getpid()):
                _rc = _cmd_run_locked(args, cfg, state, roots, labels, all_roots,
                                      [lb for _r, lb in missing])
            # 창을 안 여는 집은 옛 예약(동작 'run', 트리거 하나)이 영영 그대로였다 — 검사 끝에서도 한 번 올린다 (검토53 J 낮음 8).
            # 이 설치본의 실행 파일을 가리키는 우리 작업일 때만 움직이고, 개발용 파이썬에서는 바로 끝난다
            if not getattr(args, "if_missed", False):
                try:
                    if schedule_upgrade_logon():
                        print("매일 자동 실행에 '로그인 3분 뒤 보충' 조건을 더했습니다", flush=True)
                except Exception:
                    pass
            return _rc
        finally:
            state.release_run_lock(os.getpid())


def cmd_refresh_cache(args: argparse.Namespace) -> int:
    """판 교체 뒤 추출 기록(캐시)을 새 세대로 갱신 — 스냅샷·브리핑 없이 지금 파일만 다시 읽는다.

    세대가 다른 추출본은 섞어 비교하지 않으므로(2026-08-26), 세대가 오른 뒤 첫 검사는 그 사이
    바뀐 파일의 '이전 판' 기록이 옛 세대뿐이라 내용 비교를 통째로 건너뛰었다 — 실사용에서
    판을 올린 다음 날 아침이 정확히 그 경우였다 (검토25 감지 6-1). 교체 직후 이것을 돌려 두면
    다음 검사의 '이전 판'은 새 세대 기록이 된다. 검사와 같은 잠금을 쓴다."""
    if getattr(args, "to_log", False):
        # 판 교체 프로세스가 띄운 자식 — 로그를 스스로 append로 연다 (2회차 A5)
        try:
            _lf = open(Path.cwd() / "watcher.log", "a", encoding="utf-8", errors="replace", buffering=1)
            sys.stdout = sys.stderr = _lf
            print(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')} refresh-cache ===")
        except OSError:
            pass
    # 무인 교체 직후 — 새 판의 '로그인 3분 뒤 보충'을 다음 날 07:00 검사 끝까지 기다리면, 창을 안 여는 집은 그 하루
    # 재부팅 보충이 없었다 (검토55 ②9). 교체된 새 판이 여기서 바로 올린다
    try:
        if schedule_upgrade_logon():
            print("매일 자동 실행에 '로그인 3분 뒤 보충' 조건을 더했습니다", flush=True)
    except Exception:
        pass
    cfg = load_config(Path(args.config))
    if not cfg.get("roots"):
        return 0
    all_roots = [Path(r) for r in cfg["roots"]]
    all_labels = _root_labels(all_roots)
    roots = [r for r in all_roots if r.is_dir()]
    labels = [lb for r, lb in zip(all_roots, all_labels) if r.is_dir()]
    if not roots:
        return 0
    try:
        state = State(Path(args.state_db or cfg["state_db"]))
    except CorruptDatabase as e:
        print(f"오류: {e}", file=sys.stderr)
        return 5
    with state:
        if not state.acquire_run_lock(os.getpid()):
            # 곧바로 물러나면 그 뒤 첫 변경들이 전부 '비교 생략'이 됐고, "다음 검사가 다시 읽습니다"는 사실이
            # 아니었다 — 다음 검사는 새 판만 읽고 이전 판은 이미 디스크에 없다 (검토36 C-1).
            # 먼저 '갱신 대기'를 남기고(잠금을 쥔 검사가 끝나며 이어서 갱신한다) 잠시 기다려 본다
            state.set_meta(REFRESH_PENDING_KEY, datetime.now(timezone.utc).isoformat())
            wait_until = time.time() + float(getattr(args, "lock_wait", 1800) or 0)
            while True:
                if not state.get_meta(REFRESH_PENDING_KEY):
                    print("추출 기록 갱신은 앞선 검사가 끝나며 이미 마쳤습니다.")
                    return 0
                if state.acquire_run_lock(os.getpid()):
                    break
                if time.time() >= wait_until:
                    print("다른 검사가 진행 중이라 추출 기록 갱신을 미룹니다 — 그 검사가 끝난 뒤, 또는 다음 "
                          "검사 끝에 이어서 갱신합니다. 그 전에 바뀐 파일은 이번 한 번 내용 비교를 건너뛸 수 있습니다.")
                    return 4
                time.sleep(10)
        try:
            with _lock_heartbeat(state.db_path, os.getpid()):
                return _refresh_extracts(state, cfg, roots, labels, all_roots)
        except ScanCancelled:
            print("추출 기록 갱신을 중단했습니다.")
            return 3
        finally:
            _set_progress("")
            state.release_run_lock(os.getpid())


REFRESH_PENDING_KEY = "refresh_pending"
OUTPUTS_INSIDE_KEY = "outputs_inside_roots"   # 이력·브리핑·백업·로그가 감시 폴더 안 (검토44 E 낮음 7)
CLOCK_SUSPECT_KEY = "clock_suspect"            # 시계가 앞으로 튄 뒤 정리를 멈춘 상태 (검토44 A 중간 5·E 중간 1)
GAP_NOTE_KEY = "gap_note"                      # 이번 검사가 본 '놓친 평일' 한 줄 + 그 스냅샷 — 0건 날 화면 배너용 (재검토 2026-10-28 R8-3)
MASS_REMOVAL_ACCEPT_KEY = "mass_removal_accept"  # 사용자가 화면에서 '보류한 대량 삭제는 진짜'라고 확인함 — 다음 검사가 삭제로 기록 (F1)
EXTRACT_GEN_KEY = "extract_gen"       # 마지막으로 전부 새 세대로 읽은 추출 세대 (검토43 D 중간 1)


def extract_gen_stale(state: State) -> bool:
    """추출 기록이 옛 세대인가 — 판 교체 경로(selfupdate)가 아닌 수동 업그레이드(설치판 재설치·zip 덮기)는 refresh-cache를
    띄우지 않아, 그 사이 바뀐 도면이 '구버전 형식이라 비교 생략'이 되고 'Rev 미갱신'이 빠졌다 (검토43 D 중간 1)."""
    try:
        g = state.get_meta(EXTRACT_GEN_KEY)
        if g is not None:
            return int(g) < _CACHE_VER
        # 표식이 없으면 **지금 스냅샷 파일**의 기록 가운데 이 판이 못 쓰는 것이 하나라도 있는지로 — MAX(세대)로 보면 07:00 검사가
        # 바뀐 파일 하나를 새 세대로 읽는 순간 '최신'이 되어, 나머지 파일의 갱신이 영영 돌지 않았다 (검토44 A 중간 3·E 중간 2)
        rows = state.conn.execute(
            "SELECT f.path, CAST(json_extract(e.doc_json, '$.cache_ver') AS INTEGER) FROM files f "
            "JOIN extracts e ON e.sha256 = f.sha256 WHERE f.snapshot_id = (SELECT MAX(id) FROM snapshots)").fetchall()
        if not rows:
            return False
        if any(not _cache_ok({"cache_ver": gen}, path) for path, gen in rows):
            return True
        state.set_meta(EXTRACT_GEN_KEY, str(_CACHE_VER))     # 모두 쓸 수 있으면 표식을 남겨 다음부터는 한 줄로 판정
        return False
    except (ValueError, TypeError, sqlite3.Error):
        return False


def _refresh_extracts(state: State, cfg: dict, roots, labels, all_roots,
                      phase: str = "2/3 내용 추출 (판 교체 뒤 기록 갱신)", since: str | None = None) -> int:
    """지금 스냅샷에 있는 파일의 추출 기록을 새 세대로 다시 읽는다 (잠금은 호출부가 쥔다).
    시작할 때 '갱신 대기'를 남기고 끝나면 지운다 — 4만 파일이면 두 시간이 걸려, 그 사이 PC가 꺼지면 다음
    검사가 이어 하지 않고 남은 도면의 다음 변경이 '비교 생략'이 됐다 (검토37 C 중간 2)."""
    if not state.get_meta(REFRESH_PENDING_KEY):
        state.set_meta(REFRESH_PENDING_KEY, datetime.now(timezone.utc).isoformat())
    snap = state.latest_snapshot()
    if not snap:
        state.set_meta(REFRESH_PENDING_KEY, None)
        # 조용히 끝나면 로그가 머리줄로 끊겨 멈춘 것처럼 보였다 (ux24 SH1)
        print("아직 검사 이력이 없어 추출 기록 갱신을 건너뜁니다 — 첫 검사가 새 판으로 읽습니다.")
        return 0
    rd = RunData(cfg=cfg, roots=roots, labels=labels,
                 root_display=", ".join(str(r) for r in all_roots))
    rd.prev_files = state._latest_rows()
    print(f"Drev v{__version__} — 판 교체 뒤 추출 기록 갱신(세대 {_CACHE_VER}): "
          f"파일 {len(snap)}개 확인")
    _scan_roots(rd, argparse.Namespace(full=False))
    # 지금 스냅샷에 있는 파일만(새로 생긴 파일은 다음 검사가 '추가'로 잡으며 그때 읽는다)
    rd.records = [r for r in rd.records if r.path in snap]
    _set_progress(phase, 0, len(rd.records))
    _t0 = datetime.now(timezone.utc).isoformat()
    docs, failures = _extract_docs(state, rd.abs_of, rd.records, cfg)
    n = len(rd.records)
    # 레코드 수가 아니라 **실제로 다시 읽은** 수 — '128개 완료'가 0건 재추출을 가렸다 (검토32 A 1)
    n_new = state.conn.execute("SELECT COUNT(*) FROM extracts WHERE extracted_at >= ?", (_t0,)).fetchone()[0]
    state.set_meta(REFRESH_PENDING_KEY, None)
    state.set_meta(EXTRACT_GEN_KEY, str(_CACHE_VER))
    if n_new:
        # 같은 지문의 추출본이 새로 읽혔다 — 교차 검사 생략(R3-F1)이 옛 추출본으로 낸 결과를 이월하지 않게 다음 변경일엔 전부
        state.set_meta(XCHECK_SIGS_KEY, None)
    # 검사 끝에 이어 하는 갱신이면 대부분은 검사의 내용 추출 단계가 이미 다시 읽었다 — 여기서 센 0개만 말하면 '판을 올렸는데
    # 갱신 0개'로 읽혔다 (검토62 C-1)
    n_run = (state.conn.execute("SELECT COUNT(*) FROM extracts WHERE extracted_at >= ?", (since,)).fetchone()[0] - n_new
             if since else 0)
    print(f"추출 기록 갱신 완료(세대 {_CACHE_VER}): "
          + (f"이번 검사의 내용 추출 단계에서 {n_run}개, " if n_run > 0 else "")
          + f"여기서 {n_new}개 다시 읽음 / 그대로 {max(n - n_new - max(n_run, 0), 0)}개 "
          f"(읽기 실패 {len(failures)}개) — 스냅샷·브리핑은 만들지 않습니다")
    return 0


XCHECK_SIGS_KEY = "xcheck_sigs"   # 프로젝트별 마지막 교차 검사의 {열쇠: [묶음 지문, 찾은 이슈 수]} (R3-F1)


def _xcheck_sig(key: str, paths: list, docs) -> str | None:
    """프로젝트 교차 검사 묶음의 지문 — 검사에 들어간 (경로, 내용 지문) 차례 + 판·추출 세대. 같으면 검사 결과도 같다
    (check_project_consistency는 문서만 본다). 이번에 새로 읽은 추출본이 끼어 있거나 지문을 모르면 None(꼭 검사)."""
    sha_of = getattr(docs, "sha_of", None)
    fresh = getattr(docs, "fresh_extract", None)
    if sha_of is None or fresh is None:
        return None
    parts = [__version__, str(_CACHE_VER), _EXTRACT_FINGERPRINT, key]
    for p_ in paths:
        s_ = sha_of(p_)
        if not s_ or p_ in fresh:
            return None
        parts.append(f"{p_}\x00{s_}")
    import hashlib
    return hashlib.sha1("\x01".join(parts).encode("utf-8", "surrogatepass")).hexdigest()


def _xcheck_keep_open(state: State) -> tuple[set, set]:
    """교차 검사를 생략하면 안 되는 (프로젝트 이름들, 경로들) — 열린 교차 이슈, 그리고 닫혔지만 '사라짐'(gone_at)이
    아직 안 찍힌 교차 이슈. 이들은 검사해야 자동 해소·재발 판정이 예전과 같다 (R3-F1). 파일 단위 이슈(Rev 미갱신·태그 표기)는
    '그 파일이 바뀌었나'로만 닫히고, 바뀌었으면 묶음 지문이 달라 어차피 검사한다."""
    from watcher.consistency import _canon_project
    projs, paths = set(), set()
    try:
        rows = state.conn.execute(
            "SELECT project, path FROM issues WHERE (resolved_at IS NULL OR gone_at IS NULL) "
            "AND code IN ('BOM_MISMATCH', 'TAG_MISMATCH_ACROSS_DRAWINGS')").fetchall()
    except sqlite3.DatabaseError:
        return {"*"}, set()
    for proj, path in rows:
        if proj:
            projs.add(str(proj))
            try:
                projs.add(_canon_project(str(proj)))
            except Exception:
                pass
        if path:
            paths.add(str(path))
    return projs, paths


def _load_xcheck_sigs(state: State) -> dict:
    import json
    try:
        d = json.loads(state.get_meta(XCHECK_SIGS_KEY) or "{}")
        return d if isinstance(d, dict) else {}
    except (ValueError, TypeError):
        return {}


def _track_issued_po(state: State, rd) -> None:
    from watcher.consistency import _canon_project
    from watcher.issued import track
    rd.t_track = datetime.now(timezone.utc).isoformat()      # 여기서 닫히는 '출도 후 변경'도 메일 해소 줄에 (ux24 RD3)
    _res = None

    def _project_of(p_, d_):
        nonlocal _res
        if _res is None:
            _res = make_resolver(rd.cfg, rd.roots)
            _res.folder_votes = rd.folder_votes or _load_folder_votes(state)
            _res.prev_projects = _PrevProjects(state)
        proj_, why_ = _res.attribute(p_, d_)
        return None if why_ == "미분류" else _canon_project(proj_)
    from watcher.issued import issued_folders as _isf
    # 출도 폴더 설정을 기록에 — 설정 파일을 못 읽는 사내망 상세·대장이 감시 화면과 같은 출도본 안내를 하게 (rv0676 재검토 RS2)
    import json as _json_if
    from watcher.change_ledger import ISSUED_FOLDERS_META
    state.set_meta(ISSUED_FOLDERS_META, _json_if.dumps(_isf(rd.cfg), ensure_ascii=False))
    if rd.details and (_isf(rd.cfg) or state.conn.execute("SELECT 1 FROM po_lines LIMIT 1").fetchone()):
        # 사양 글자만 바뀐 DXF 줄의 태그 이름표 — 발주 대조·출도본 값 찾기가 쓴다(보고 단계가 다시 해도 같다)
        _pair_spec_tags(rd, rd.details)
    track(state, rd, _project_of)


def _cmd_run_locked(args, cfg, state: State, roots, labels, all_roots, missing_labels) -> int:
    db_path = Path(args.state_db or cfg["state_db"])
    # 지난번에 스냅샷만 남기고 죽은 실행(창 닫힘·정전·업데이트)이 있으면 되돌린다 —
    # 그 변경은 이번 검사가 다시 감지해 브리핑에 싣는다 (core H1). 로그인 보충 판정보다 **먼저** (검토53 J 중간 4)
    stale = state.unfinished_run()
    if stale is not None:
        state.delete_run(stale)
        print(f"지난 검사(스냅샷 #{stale})가 보고를 마치지 못하고 끝나 있어 되돌렸습니다 — "
              f"그때의 변경은 이번 검사가 다시 감지합니다.")
    if getattr(args, "if_missed", False):
        # 잠금을 기다리는 동안 창의 보충 검사가 끝났을 수 있다 — 그러면 또 돌지 않는다 (검토53 I 낮음 6)
        _ran = due_already_ran(cfg, db_path)
        if _ran:
            print(f"{_ran} 예약 검사가 이미 돌았습니다 — 로그인 보충 실행은 건너뜁니다.", flush=True)
            return 0
    if True:
        rd = RunData(cfg=cfg, roots=roots, labels=labels,
                     root_display=", ".join(str(r) for r in all_roots),
                     missing_labels=list(missing_labels))
        rd.prev_files = state._latest_rows()  # 해시 단축·판 짝짓기용: 직전 스냅샷
        try:
            # 주 1회는 크기·저장 시각 단축 없이 전부 다시 해싱한다 — 타임스탬프를 보존하는
            # 복사(robocopy /COPY:DAT, PDM 체크인)·같은 크기 치환은 단축에 걸려 영영 못 봤다.
            # "변경 사실은 100% 잡는다"(원칙 5)가 코드로 보증되지 않던 것, 두 검토 연속
            # 지적 (2026-09-04, 검토19 원칙 ①). --full 없이도 7일마다 자동
            _last_full = state.get_meta("last_full_rehash")
            try:
                _age = (datetime.now(timezone.utc)
                        - datetime.fromisoformat(_last_full)).total_seconds() if _last_full else None
            except (TypeError, ValueError):
                _age = None
            if not getattr(args, "full", False) and (_age is None or _age > 7 * 86400 or _age < 0):   # 음수 = 시계 튐 (검토38 R7-4)
                rd.force_full = True
                print("  이번 검사는 주 1회 전체 확인 — 크기·저장 시각이 같은 파일도 내용을 다시 읽습니다")
            excluded_carry = _scan_roots(rd, args)
            rd.__dict__["excluded_carry"] = list(excluded_carry)   # 이슈 해소 판정의 '있음'에도 (검토59 F3 I5)
            # 이번 검사가 쓰는 표식 — 보고 단계에서 되돌리면 함께 되돌린다. 남겨 두면 이튿날 켠 확장자의 첫 등록이 '변경 N건',
            # 대량 삭제 보류가 풀려 '삭제 N건' 메일이 나갔다 (검토59 F3 G7·G8)
            rd.__dict__["meta_before"] = {k_: state.get_meta(k_) for k_ in ("mass_removal_hold", MASS_REMOVAL_ACCEPT_KEY,
                                                                              "last_extensions", "ext_baseline")}
            # 전체 재해싱 표시는 검사가 끝난 뒤(mark_run_finished)에 남긴다 — 여기서 남기면 보고 단계에서 검사가
            # 되돌려진 날 다음 날부터 단축 검사가 되어 '같은 크기·같은 저장 시각' 변경을 6일 못 봤다 (검토41 S9 중간 1)
            _full_done_at = (datetime.now(timezone.utc).isoformat()
                             if rd.force_full or getattr(args, "full", False) else None)
        except ScanCancelled:
            # 스냅샷 전 — 기록한 것이 없으니 그냥 끝낸다
            print("검사를 중단했습니다 (파일 확인 단계). 기록된 것은 없습니다.")
            _set_progress("")
            return 3
        artifact_dirs = {PurePosixPath(r.path).parent for r in rd.records}

        # 그날 안 붙은 감시 폴더(네트워크 드라이브 끊김): 이전 상태를 그대로 이월한다 —
        # 조용히 빠졌다가 복귀 시 전부 '추가'로 재등록되고 그 사이 수정은 비교되지 않으며
        # 열린 이슈가 '삭제됨'으로 닫히던 것 (2026-09-04 검토 core H2)
        for lb in rd.missing_labels:
            rd.carry_paths += [k for k in rd.prev_files if k.startswith(lb + "/")]
            rd.scan_errors.append((lb + "/", "감시 폴더에 접근할 수 없어 이전 상태를 이월했습니다 "
                                   "(네트워크 드라이브 연결을 확인하세요)"))
        # 대량 삭제 보류: 직전 기록의 절반 넘게(20개 이상) 한 번에 사라지면 서버 순단·
        # 드라이브 문자 변경일 가능성이 크다 — 하루 보류하고 다음 검사에도 없으면 삭제로
        # 보고한다 (core H3 재검토 권고)
        current = {r.path for r in rd.records} | set(rd.carry_paths) \
            | {p for p, _ in rd.scan_errors} | set(excluded_carry)
        watched_prev = {k for k in rd.prev_files if k.split("/")[0] in labels}
        vanished = sorted(watched_prev - current)
        # 사라진 파일 대부분이 같은 지문·같은 이름으로 **다른 경로에 나타났으면** 폴더 이름 변경이다 — 보류하면 그날은
        # '추가' 30건, 이튿날 '삭제' 30건이 되고 그 안의 진짜 편집은 비교되지 않았다 (검토43 B 중간 4)
        _new = [r for r in rd.records if r.path not in rd.prev_files]
        _new_sha = Counter(r.sha256 for r in _new)
        _new_name: dict = {}
        _heads44 = _prev_heads(rd.prev_files)
        for r in _new:
            _new_name.setdefault(PurePosixPath(r.path).name, []).append(r.path)
        _moved_like = 0
        _moved_keys: set = set()          # 같은 지문·같은 이름으로 다른 경로에 나타난 사라진 파일 (R9-4)
        for k in vanished:
            sha_ = (rd.prev_files.get(k) or (None,))[0]
            nm_ = PurePosixPath(k).name
            if sha_ and _new_sha[sha_] > 0:
                _new_sha[sha_] -= 1
                _moved_like += 1
                _moved_keys.add(k)
            else:
                # 이름만 같은 것은 **다른 기존 프로젝트**로의 짝이 아닐 때만 — 순단 날 남의 프로젝트에 같은 이름 새 도면이
                # 생기면 보류가 풀렸다 (검토44 B F06)
                _c = [q for q in _new_name.get(nm_, ()) if not _other_project_move(k, q, _heads44, rd.cfg)]
                if _c:
                    _new_name[nm_] = [q for q in _new_name[nm_] if q != _c[0]]   # .remove는 읽기 전용 보호가 막는다
                    _moved_like += 1
                    _moved_keys.add(k)
        # 파일을 하나도 읽지 못한 감시 폴더(폴더는 있는데 비었다 — 공유가 끊겨 마운트 지점만 남은 날)도 보류한다. 개수와 상관없이
        # (재검토 2026-10-26 고장 주입 F1: 빈 루트 이틀째에 '삭제 36건' 메일 3통, 복귀일에 '추가 36건')
        import json
        _scanned_labels = {r.path.split("/", 1)[0] for r in rd.records} | {str(p).split("/", 1)[0] for p, _ in rd.scan_errors}
        empty_labels = sorted({k.split("/", 1)[0] for k in vanished} - _scanned_labels)
        # 빈 감시 폴더의 파일 절반 넘게가 다른 감시 폴더에 같은 지문·이름으로 나타났으면 끊긴 게 아니라 **옮긴** 것이다 — 보류하면
        # A→B 통째 이동이 'B에 추가 N건'이 되고 옮기며 고친 도면의 내용 비교가 사라졌다 (재검토 2026-10-28 R9-4). 그 폴더는
        # 보류하지 않고, 절반이 안 돼도 옮긴 것으로 보이는 파일은 보류에서 빼 이동 짝짓기(_pair_moves)가 접게 한다
        _emp_moved = []
        for lb in empty_labels:
            _in_lb = [k for k in vanished if k.split("/", 1)[0] == lb]
            if _in_lb and sum(1 for k in _in_lb if k in _moved_keys) * 2 > len(_in_lb):
                _emp_moved.append(lb)
        if _emp_moved:
            print(f"감시 폴더 {', '.join(_emp_moved)}의 파일이 다른 감시 폴더로 옮겨진 것으로 보여 삭제 보류 없이 이동으로 비교합니다")
            empty_labels = [lb for lb in empty_labels if lb not in _emp_moved]
        mass = len(vanished) >= 20 and len(vanished) > len(watched_prev) / 2 and _moved_like * 2 <= len(vanished)
        if (mass or empty_labels) and vanished:
            # 보류는 **읽힌 파일이 돌아오거나(조건이 풀림) 사용자가 화면에서 [삭제로 기록]을 누를 때까지** 이어진다. 전에는 딱 하루라
            # 둘째 날 거짓 삭제가 확정됐다 (재검토 ②-6 결정을 2026-10-26 F1로 바꿈 — DECISIONS)
            if state.get_meta(MASS_REMOVAL_ACCEPT_KEY):
                state.set_meta(MASS_REMOVAL_ACCEPT_KEY, None)
                state.set_meta("mass_removal_hold", None)
                print(f"사용자가 확인한 대량 삭제 {len(vanished)}개를 삭제로 기록합니다.")
            else:
                # 다른 경로에 같은 지문·이름으로 나타난 파일은 보류하지 않는다 — 이동 짝짓기가 '이름·위치만 바뀜'이나 내용 비교로
                # 접는다 (R9-4)
                _held = [k for k in vanished if (mass or k.split("/", 1)[0] in empty_labels) and k not in _moved_keys]
                _since = None
                try:
                    _since = (json.loads(state.get_meta("mass_removal_hold") or "null") or {}).get("since")
                except (ValueError, TypeError, AttributeError):
                    _since = None
                state.set_meta("mass_removal_hold", json.dumps(
                    {"n": len(_held), "since": _since or datetime.now().strftime("%Y-%m-%d"),
                     "empty": empty_labels}, ensure_ascii=False))
                rd.carry_paths += _held
                for lb in empty_labels:
                    _n_lb = sum(1 for k in _held if k.split("/", 1)[0] == lb)
                    rd.scan_errors.append(
                        (f"(감시 폴더 비어 있음) {lb}/", f"감시 폴더 '{lb}'가 비어 있습니다 — 파일 {_n_lb}개를 하나도 읽지 못해 이전 상태를 "
                         f"이월하고 삭제 알림을 보류합니다({_since or '오늘'}부터). 네트워크 드라이브·공유 연결을 확인하세요. 정말 모두 "
                         f"지운 것이면 감시 PC 화면에서 [삭제로 기록]을 누르세요"))
                if mass and len(_held) > sum(1 for k in _held if k.split("/", 1)[0] in empty_labels):
                    rd.scan_errors.append(
                        ("(대량 삭제 보류)", f"파일 {len(_held)}개가 한꺼번에 사라져 삭제 알림을 보류합니다({_since or '오늘'}부터) — "
                         f"서버·네트워크 드라이브 연결을 확인하세요. 파일이 돌아오면 저절로 풀리고, 정말 지운 것이면 감시 PC 화면에서 "
                         f"[삭제로 기록]을 누르세요"))
                # '비어 있음: 없음'은 뜻이 안 통했다 (R5-2) — 빈 감시 폴더가 있을 때만 그 이름을
                print(f"주의: 파일 {len(_held)}개가 한꺼번에 사라져 삭제 알림을 보류했습니다"
                      + (f" (비어 있는 감시 폴더: {', '.join(empty_labels)})" if empty_labels else "")
                      + " — 서버 연결을 확인하세요. 정말 지운 것이면 감시 PC 화면에서 [삭제로 기록]",
                      file=sys.stderr)
        else:
            if state.get_meta("mass_removal_hold"):
                state.set_meta("mass_removal_hold", None)
            if state.get_meta(MASS_REMOVAL_ACCEPT_KEY):
                state.set_meta(MASS_REMOVAL_ACCEPT_KEY, None)      # 보류가 풀렸으면 지난 확인은 다음 사건에 쓰지 않는다

        import json
        cur_exts = sorted({str(e).lower() for e in (rd.cfg.get("extensions") or ())})
        prev_exts_raw = state.get_meta("last_extensions")
        rd.snapshot_id, rd.changes = state.record_run(
            rd.records, carry_paths=[p for p, _ in rd.scan_errors] + excluded_carry
            + rd.carry_paths,
            known_prefixes=labels + list(rd.missing_labels),
            scanned_prefixes=labels)              # 실제로 검사한 라벨 — 폴더별 '첫 검사' 기록용
        state.mark_run_started(rd.snapshot_id)
        # 이번 검사에서 새로 켠 확장자 — 그 파일들의 '추가'는 변경이 아니라 등록이다
        # (2026-09-10 검토18: 묶음 단추로 106개를 켠 다음 날 PLC 파일 수백 건이
        # '추가'로 쏟아지던 것). 첫 검사(기준선)는 원래 전부 등록이므로 제외
        if prev_exts_raw is not None:
            try:
                prev_exts = {str(e).lower() for e in json.loads(prev_exts_raw)}
            except (ValueError, TypeError):
                prev_exts = set(cur_exts)
            new_exts = set(cur_exts) - prev_exts
            # 되돌린(지워진) 검사가 켠 확장자로 남긴 표식 — 그 스냅샷이 없고 직전 스냅샷에 그 형식 파일도 없으면 아직 켠 적이
            # 없는 것이다. 옛 판의 롤백이 last_extensions·ext_baseline을 남겨 첫 등록이 '추가 N건'이 됐다 (재검토 2026-10-28 R9-1)
            try:
                _live = {r_[0] for r_ in state.conn.execute("SELECT id FROM snapshots")}
                _old_sfx = {PurePosixPath(p_).suffix.lower() for p_ in rd.prev_files}
                new_exts |= {e_ for e_, s_ in state.ext_baseline().items()
                             if e_ in cur_exts and s_ not in _live and e_ not in _old_sfx}
            except Exception:
                pass
            if new_exts:
                state.note_ext_baseline(new_exts, rd.snapshot_id)
                rd.reg_exts = set(new_exts)
                rd.reg_paths = {c.path for c in rd.changes if c.kind == "added"
                                and PurePosixPath(c.path).suffix.lower() in new_exts}
                if rd.reg_paths:
                    print(f"새로 켠 확장자({', '.join(sorted(new_exts))})의 파일 "
                          f"{len(rd.reg_paths)}개를 등록했습니다 — 변경이 아니라 기준선입니다")
        # 나중에 **추가한 감시 폴더**의 첫 검사도 같다 — 그 폴더의 '추가'는 등록이다. 화면은
        # 폴더별 첫 스냅샷으로 그렇게 세는데 브리핑·메일은 DB 전체의 첫 검사만 기준선으로 봐
        # "변경 113건 / 검토 필요 6건" 메일 초안을 만들었다 (2026-09-11 실사용 첫날). DB의 첫
        # 검사(전체가 기준선)는 제외. last_extensions 메타가 없는 구판 DB에서도 돈다 (검토20 A-10)
        if state.first_snapshot_id() != rd.snapshot_id:
            first_by_root = state.first_snapshot_by_root()
            rd.reg_roots = {r for r, s in first_by_root.items() if s == rd.snapshot_id and r != "*"}
            if rd.reg_roots:
                root_regs = {c.path for c in rd.changes if c.kind == "added"
                             and (c.path.split("/", 1)[0] if "/" in c.path else c.path) in rd.reg_roots}
                rd.reg_paths = set(rd.reg_paths) | root_regs
                if root_regs:
                    print(f"새로 추가한 감시 폴더({', '.join(sorted(rd.reg_roots))})의 파일 "
                          f"{len(root_regs)}개를 등록했습니다 — 변경이 아니라 기준선입니다")
        state.set_meta("last_extensions", json.dumps(cur_exts))
        _pair_moves(rd)
        print(f"Drev v{__version__} — 감시 폴더 {len(roots)}개: {rd.root_display}")
        print(f"산출물 폴더 {len(artifact_dirs)}개, 파일 {len(rd.records)}개 스캔 "
              f"(스냅샷 #{rd.snapshot_id})")

        try:
            rd.docs, rd.extract_failures = _extract_docs(state, rd.abs_of, rd.records, cfg)
            _compare_modified(state, rd)
            _pair_revisions(state, rd)
            _note_removed_copies(rd, state)
            # 출도본·발주서 기록과 '출도 후 변경'·'발주 후 변경' (기능 검토 2026-11-02 J2·J8) — 설정에 출도 폴더가 없고 발주서가
            # 없으면 하는 일이 없다
            _track_issued_po(state, rd)
            # 첫 편집 유예 뒤 rev_check_days일이 지나도록 Rev 그대로인 파일 — 변경 없는 날에도 (재검토 rr066 judge 6)
            try:
                rd.issues += _first_edit_overdue(state, rd)
            except Exception as e:          # 부가 판정 — 이것 때문에 검사·메일이 되돌려지면 안 된다
                print(f"경고: 첫 편집 유예 기한 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
            # 프로젝트 단위 교차 검사는 변경이 있던 날만 (매일 같은 소음 방지)
            if rd.changes:
                # 짝짓기로 '이전 판'이 된 파일(revA가 디스크에 남은 경우)은 뺀다 —
                # 구판과 신판 사이의 '도면 간 불일치'는 거짓 경보다 (2026-09-02 재검토).
                # 복사본("(2)", "- 복사본")과 내용이 같은 중복 파일도 뺀다 — 근거가
                # 사본을 인용하고, 사본이 지워지면 링크가 깨졌다 (2026-09-03 검토)
                # 보고 단계(_report_and_send)와 같은 귀속기를 쓴다 — 다르면 이슈의 프로젝트
                # 이름이 어긋나 자동 해소가 영원히 안 된다 (2026-09-03 재검토)
                resolver = make_resolver(rd.cfg, rd.roots)
                resolver.prev_projects = _PrevProjects(state)      # 보고 단계와 같은 귀속 (검토20 r13 3)
                sha_of = {r.path: r.sha256 for r in rd.records}
                seen_sha: set = set()
                _sheets_in = sheet_bases(rd.docs)
                # 같은 폴더·같은 짝 키의 **표식 없는** 원본이 있는가 — 사본마다 전체 문서를 훑으면 2만 파일 서버의
                # 변경일이 제곱으로 느려졌다(4분 중 대부분, 검토41 S5 차단 1). 한 번 색인해 두고 찾는다
                _orig_idx: set = set()
                for q in rd.docs:
                    if not is_copy_marked(q, _sheets_in):
                        qq = PurePosixPath(q)
                        _orig_idx.add((str(qq.parent), pair_key(qq.name)))
                paths_in = []            # 문서는 아직 적재하지 않는다 — 경로만 (core H5)
                for p_ in sorted(rd.docs,
                                 key=lambda k: (bool(_COPY_MARK.search(
                                     PurePosixPath(k).name)), k)):
                    pp_ = PurePosixPath(p_)
                    if p_ in rd.old_versions:
                        continue
                    # 사본 표식을 걷은 이름으로 견준다 — pair_key는 표식을 안 걷어 이 규칙이 죽어 있었고
                    # 편집 전 사본이 원본과 '도면 간 불일치'로 메일에 나갔다 (검토31 B5)
                    # 원본은 **표식 없는** 파일만 — 사본끼리 서로를 원본으로 삼아 둘 다 빠지면 그 번호가
                    # 교차 검사에서 통째로 사라졌다 (검토32 B1: 'E-160 (2)/(3)'만 남은 폴더)
                    if is_copy_marked(p_, _sheets_in) \
                            and (str(pp_.parent), pair_key(_COPY_MARK.sub("", pp_.name))) in _orig_idx:
                        continue        # 원본이 같은 폴더에 있는 복사본만 제외
                    paths_in.append(p_)
                # 표제란 있는 도면으로 폴더의 프로젝트를 먼저 배운다 — '2026 수주/삼성 3라인/BOM'
                # 같은 묶음 폴더의 BOM이 도면과 다른 프로젝트로 갈려 도면-BOM 검사에서 조용히
                # 빠지던 것 (검토22 실용 D1). 배운 표는 보고 단계·화면도 같이 쓴다
                # 여기부터 보고·정리까지는 파일 단위 진행이 없다 — 마지막 파일 이름과 시계가 그대로
                # 흘러 '지금: <파일> (300초째)'가 빨갛게 떴다 (v0.57.4 재검토 3-⑤ b, '얼어붙음' 후보)
                _set_progress("3/3 교차 검사 (도면 간·도면-BOM)", 0, 0, "")
                for p_ in paths_in:
                    resolver.learn(p_, rd.docs.get(p_))
                rd.folder_votes = resolver.folder_votes
                _save_folder_votes(state, resolver.folder_votes)

                def _proj_of(p_, d_):
                    # 프로젝트가 없는 파일(미분류)이나 '도면/BOM/공용' 같은 구조 폴더 이름을
                    # 프로젝트로 삼은 것은 묶지 않는다 — 무관한 도면끼리 비교되는 오탐
                    # (2026-09-03 재검토)
                    proj_, why_ = resolver.attribute(p_, d_)
                    if why_ == "미분류":
                        return None
                    # 임시·공용·백업·old 폴더의 도면 사본은 도면 간·도면-BOM 대조의 근거가 아니다 — '서버/임시/test.dxf'(옛 E-101
                    # 사본)가 P26-031 불일치 근거에 '다른 값 도면'으로 늘 남아, 현행 도면을 다 고쳐도 닫히지 않았다
                    # (재검토 2026-10-26 D1, DECISIONS 2026-10-26)
                    from watcher.project import in_quiet_folder as _iqf
                    if _iqf(p_, rd.labels):
                        return None
                    if why_ == "폴더 구조" and (
                            proj_ in rd.labels or looks_like_doctype_folder(proj_, rd.cfg)
                            or proj_ in _COMMON_FOLDERS):
                        return None
                    return proj_
                _proj = _proj_of
                # 이름에 판을 붙인 구판 — 짝지은 날뿐 아니라 늘(2회차 B7). 귀속을 배운 뒤 **프로젝트별로**
                # 정한다 — 루트의 양식 한 장이 아래 모든 프로젝트의 같은 번호를 밀어냈다 (검토31 B2)
                superseded = _superseded_paths(rd, project_of=lambda p_: _proj_of(p_, rd.docs.get(p_)))
                rd.__dict__["superseded"] = _truly_replaced(rd, superseded)   # 구판의 열린 'Rev 미갱신'을 닫는 데 (검토66 B5)
                paths_in = [p_ for p_ in paths_in if p_ not in superseded]
                # 짝짓기가 '이전 판'으로 뺀 원본의 새 판이 구판 판정에서 다시 빠지면(날짜 꼬리가 원본 저장일과 같은
                # '그날의 사본') 둘 다 교차 검사에서 사라졌다 — 진짜 도면 간 불일치가 '자동 해소'로 닫혔다
                # (검토39 P1 중간 3). 그때는 원본과 새 판 가운데 **나중에 저장된 쪽**을 되살린다 — 원본을 되살리면
                # 날짜판에 값을 고쳐 저장한 날 옛 값으로(검토40 A 중간 5), 새 판을 되살리면 사본을 먼저 떠 두고 원본을
                # 고친 날 옛 사본으로(검토40 B) 거짓 불일치가 났다
                _have = set(paths_in)
                _mt = {r.path: (r.mtime or 0) for r in rd.records}

                def _no_key(q):
                    f_ = getattr(rd.docs.get(q), "fields", {}).get("DWG_NO")
                    return (str(PurePosixPath(q).parent), (f_.value or "").strip().upper()) if f_ and f_.value else None
                # 같은 폴더·같은 도면번호가 이미 들어 있으면 그 도면은 대표가 있다 — '_20261014_2'처럼 이름 짝이 안 되는
                # 둘째 날짜판이 현행일 때 옛 날짜판을 되살려 거짓 불일치를 냈다 (검토40 A 재확인 R3)
                _have_no = {k for k in (_no_key(q) for q in _have) if k}
                _kids = set().union(*rd.newer_of.values()) if rd.newer_of else set()
                for p_ in sorted(k for k in rd.newer_of if k not in _kids):       # 뿌리(원본)마다
                    fam, stack = {p_}, [p_]
                    while stack:                          # 날짜판의 날짜판까지 (검토40 A 재확인 2-c)
                        for n_ in rd.newer_of.get(stack.pop(), ()):
                            if n_ not in fam:
                                fam.add(n_)
                                stack.append(n_)
                    fam = {q for q in fam if q in rd.docs}
                    # 가족 모두 교차 검사 밖인데 구판 판정이 그 가운데 하나를 현행으로 본 경우만 — 다른 판(revC)이
                    # 현행이면 가족 전체가 구판이다
                    if fam and not (fam & _have) and (fam - superseded):
                        pick = max(fam, key=lambda q: (_mt.get(q, 0), q))
                        if _no_key(pick) in _have_no:
                            continue
                        paths_in.append(pick)
                        _have.add(pick)
                # 같은 폴더의 같은 내용 파일은 하나만 — 구판 제외 **뒤에** 한다. 앞에서 하면 편집 전에 복사해 둔
                # 다음 판(revB = revA와 같은 바이트)이 먼저 지워지고 _cmp가 revA를 구판이라 또 지워 그 번호가
                # 교차 검사에서 통째로 사라졌다 (검토32 D 1-1, v0.57.12 회귀)
                _dedup: list = []
                for p_ in paths_in:
                    key_ = (str(PurePosixPath(p_).parent), sha_of.get(p_))
                    if key_ in seen_sha:
                        continue
                    seen_sha.add(key_)
                    _dedup.append(p_)
                paths_in = _dedup
                # 프로젝트별로 묶어 그 묶음의 문서만 적재해 검사한다 — 4만 파일의 추출본을
                # 통째로 올리면 +1.4GB, 실서버는 몇 배 (2026-09-04 검토 core H5)
                from watcher.consistency import _canon_project
                by_proj: dict = {}
                for p_ in paths_in:
                    raw_ = _proj(p_, rd.docs.get(p_))
                    key_ = _canon_project(raw_) if raw_ else None
                    if key_:
                        by_proj.setdefault(key_, []).append(p_)
                rd.checked_projects = set(by_proj)
                # 이월된 파일(끊긴 폴더·못 읽은 폴더)이 속한 프로젝트는 이번에 다 본 게
                # 아니다 — 그 프로젝트의 열린 이슈를 '재검출되지 않음'으로 닫지 않게
                # (2026-09-04 재검토 ②-4)
                # 오늘 바뀌었는데 읽지 못한 파일(손상·잠김·시간 상한)이 든 프로젝트도 — 도면이 하루 못 읽힌 날 그 도면과의
                # 열린 불일치가 '재검출되지 않음'으로 닫혔다(이슈 경로가 BOM이라 읽기 검사를 비켜감) (검토44 B G06·G03)
                _mod_today = {c.path for c in rd.changes if c.kind == "modified"}
                for p_ in [q for q in rd.extract_failures if q in _mod_today] + list(rd.carry_paths):
                    raw_ = resolver.attribute(p_, None)[0]
                    key_ = _canon_project(raw_) if raw_ else None
                    rd.checked_projects.discard(key_)
                # 바뀌지 않은 프로젝트는 다시 검사하지 않는다 — 10만 파일 서버의 변경일에 변경 없는 프로젝트 377개까지 전부 검사해
                # 330초 중 247초였다 (재검토 2026-10-28 R3-F1). 생략은 셋 다일 때만: ① 검사 묶음(경로·내용 지문·판)이 지난 검사와
                # 같고 ② 지난 검사가 찾은 것이 0건 ③ 열린(또는 '사라짐' 미기록) 교차 이슈가 없다. 그러면 오늘 검사해도 0건이고
                # 자동 해소·재발 판정에 쓸 것이 없다 — 생략한 프로젝트는 '검사한 프로젝트'에서 빼서 그 이슈를 해소로 닫지 않는다
                _sigs_prev = _load_xcheck_sigs(state)
                _keep_projs, _keep_paths = _xcheck_keep_open(state)
                _sigs_new: dict = {}
                _n_skip = 0
                for key_, paths_ in sorted(by_proj.items()):
                    _in = [p_ for p_ in paths_ if p_ in rd.docs]
                    _sig = _xcheck_sig(key_, _in, rd.docs)
                    _was = _sigs_prev.get(key_)
                    if (_sig is not None and isinstance(_was, list) and len(_was) == 2 and _was[0] == _sig
                            and _was[1] == 0 and "*" not in _keep_projs and key_ not in _keep_projs
                            and not any(p_ in _keep_paths for p_ in paths_)):
                        rd.checked_projects.discard(key_)
                        _sigs_new[key_] = _was
                        _n_skip += 1
                        continue
                    docs_p = [(p_, rd.docs[p_]) for p_ in _in]
                    _found = check_project_consistency(
                        docs_p, project_of=lambda _p, _d, _k=key_: _k, cfg=cfg)
                    if any(getattr(i_, "absorbed", ()) for i_ in _found):
                        state.absorb_twins(_found)        # 두 카드 합친 판의 첫 검사 — 열린 옛 카드를 이어 붙인다 (J3)
                    rd.issues += _found
                    del docs_p
                    if _sig is not None and key_ in rd.checked_projects:
                        _sigs_new[key_] = [_sig, len(_found)]
                # 기록은 검사가 끝까지 간 뒤(mark_run_finished)에 — 보고 단계에서 되돌린 검사의 지문이 남으면 다음 날
                # 그 프로젝트를 생략해 되돌린 이슈를 다시 못 잡는다
                rd.__dict__["xcheck_sigs"] = _sigs_new
                if _n_skip:
                    print(f"  교차 검사: 프로젝트 {len(by_proj) - _n_skip}개 검사 — 바뀌지 않았고 검토 필요가 없던 "
                          f"{_n_skip}개는 지난 결과(0건) 그대로")
            _set_progress("3/3 변경 자리 사진", 0, 0, "")
            _collect_text_captures(rd)
            _set_progress("3/3 브리핑·메일 작성", 0, 0, "")
            from watcher.brief import ACK_ON as _ACK_ON
            _ack_tok = _ACK_ON.set(ack_tracking_on(cfg))      # 확인 기록을 끈 집은 브리핑에 확인 열이 없다 (M5)
            try:
                _report_and_send(args, cfg, state, rd)
            finally:
                _ACK_ON.reset(_ack_tok)
            # 메일을 낸 **바로 뒤** 끝남을 찍는다 — 확인 기록 옮기기 사이에 꺼지면 다음 실행이 이 검사를 되돌려 같은 변경
            # 메일을 또 보냈다 (검토53 K 낮음 3)
            state.mark_run_finished()
            rd.reported = True
            if rd.__dict__.get("xcheck_sigs") is not None:
                try:
                    import json as _jx
                    state.set_meta(XCHECK_SIGS_KEY, _jx.dumps(rd.__dict__["xcheck_sigs"], ensure_ascii=False))
                except Exception:
                    state.set_meta(XCHECK_SIGS_KEY, None)       # 못 남기면 다음 변경일에 전부 검사(예전과 같다)
            if rd.changes and any(c.kind == "removed" for c in rd.changes):
                # 사라진 경로의 내용 단서(doc_hints)는 지운다 — 1년 뒤 322행 중 184행이 없는 경로였다 (R2-3). 이월된 파일은
                # 스냅샷에 남아 있어 그대로 둔다. 다시 나타나면 추출 단계가 단서를 다시 만든다
                try:
                    state.conn.execute(
                        "DELETE FROM doc_hints WHERE path NOT IN (SELECT path FROM files WHERE snapshot_id = ?)",
                        (rd.snapshot_id,))
                    state.conn.commit()
                except sqlite3.DatabaseError:
                    pass
            if state.get_meta(LAST_RUN_FAILED_KEY):
                state.set_meta(LAST_RUN_FAILED_KEY, None)      # 다시 성공했으면 배너를 거둔다
            if getattr(state, "extract_read_errors", 0):
                print(f"경고: 추출 기록 {state.extract_read_errors}건을 읽지 못해 다시 읽었습니다(이력 파일 일부 손상 가능 — "
                      f"{getattr(state, 'extract_read_error_why', '')})", file=sys.stderr)        # 이 뒤의 예외(정리·백업)는 검사를 되돌리지 않는다 (검토58 F3 G1)
            try:
                _n_re = state.reattach_rolled_back()      # 되돌렸던 검사의 확인을 다시 잡힌 변경에 (검토39 P5 차단 2)
                if _n_re:
                    print(f"되돌렸던 검사의 확인 기록 {_n_re}건을 다시 잡힌 같은 변경에 옮겼습니다")
            except Exception as e:
                print(f"경고: 되돌린 검사의 확인 기록 옮기기 실패(검사 결과는 정상): {e}", file=sys.stderr)
            # 메일까지 나간 검사는 되돌리지 않는다 — 발송 중에 누른 [멈춤]이 '마무리'에서 터져 스냅샷이 롤백되고 다음 날 같은
            # 변경을 또 보냈다 (검토51 A 중간 3). 정리는 짧으니 끝까지 한다
            STOP.clear()
            if _full_done_at:
                state.set_meta("last_full_rehash", _full_done_at)
            _set_progress("마무리 (백업·정리)", 0, 0, "")
            _housekeep(state, cfg, args, skip_weekly=getattr(rd, "is_baseline", False))
        except ScanCancelled:
            # 사람이 멈췄다 — 스냅샷을 되돌려 다음 검사가 같은 변경을 다시 잡게
            state.delete_run(rd.snapshot_id)
            for k_, v_ in (rd.__dict__.get("meta_before") or {}).items():
                state.set_meta(k_, v_)
            print("검사를 중단했습니다 — 이번 스냅샷을 되돌렸습니다. "
                  "변경은 유실되지 않으며 다음 검사가 다시 감지합니다.")
            _set_progress("")
            return 3
        except Exception as e:
            if getattr(rd, "reported", False):
                # 브리핑·메일까지 끝난 뒤의 마무리(백업·정리·전체 확인 기록) 실패 — 되돌리면 다음 검사가 같은 변경을 다시
                # 잡아 메일을 또 보내고, 원인이 그대로면 **매일** 되풀이됐다 (검토58 F3 G1). 검사는 성공, 경고만
                print(f"경고: 검사·브리핑은 끝났지만 마무리(백업·정리) 중 오류가 났습니다 — 다음 검사에서 다시 정리합니다.\n"
                      f"  사유: {type(e).__name__}: {e}", file=sys.stderr)
                _set_progress("")
                return 0
            # 보고를 못 했으면 스냅샷을 되돌린다 — 다음 실행이 같은 변경을 다시
            # 감지·보고하도록. 커밋만 하고 죽으면 알림이 영구 유실된다 (PRINCIPLE 5)
            state.delete_run(rd.snapshot_id)
            for k_, v_ in (rd.__dict__.get("meta_before") or {}).items():
                state.set_meta(k_, v_)
            print(f"오류: 보고 단계 실패 — 이번 스냅샷을 롤백했습니다. "
                  f"다음 실행에서 변경을 다시 감지합니다.\n  사유: {e}", file=sys.stderr)
            # 화면에 남긴다 — 사유가 콘솔에만 있어 매일 돌고 실패하는데 25시간 뒤 '검사가 없습니다'로만 보였다 (검토60 ②)
            try:
                import json as _jf
                state.set_meta(LAST_RUN_FAILED_KEY, _jf.dumps(
                    {"at": datetime.now(timezone.utc).isoformat(), "why": _friendly_error(e)[:400]},   # 날 예외 대신 사람 말 (검토65 D-4)
                    ensure_ascii=False))
                if isinstance(e, sqlite3.DatabaseError):
                    # DB 쪽 오류면 그 자리에서 무결성을 보고 배너에 올린다 — 무결성 검사는 마무리(백업) 단계에만 있어
                    # 거기까지 못 가는 손상은 '온전함'으로 남았다 (검토60 ② 차단)
                    ok_i, why_i = state.integrity_ok()
                    if not ok_i:
                        state.set_meta(DB_INTEGRITY_KEY, _jf.dumps(
                            {"ok": False, "why": why_i, "at": datetime.now(timezone.utc).isoformat(),
                             "since": datetime.now(timezone.utc).isoformat()}, ensure_ascii=False))
            except Exception:
                pass
            _set_progress("")
            return 1
    # 판 교체 뒤 기록 갱신이 이 검사의 잠금에 밀렸으면 여기서 이어서 한다 — 브리핑·메일은 이미 끝났고, 이번
    # 검사로 확정된 파일들이 다음 변경 때 내용 비교를 건너뛰지 않게 (검토36 C-1). 실패해도 이번 검사는 성공이다
    if not args.dry_run and (state.get_meta(REFRESH_PENDING_KEY) or extract_gen_stale(state)):
        try:
            # 단계 이름이 3/3 뒤에 '2/3'으로 되돌아가 보였다 (검토36 F 낮음 5)
            _snap_at = (state.conn.execute("SELECT run_at FROM snapshots ORDER BY id DESC LIMIT 1").fetchone() or [None])[0]
            _refresh_extracts(state, cfg, roots, labels, all_roots,
                              phase="4/4 판 교체 뒤 기록 갱신 (브리핑은 끝남)", since=_snap_at)
        except (Exception, ScanCancelled) as e:
            print(f"참고: 판 교체 뒤 추출 기록 갱신을 마치지 못했습니다 — 다음 검사 끝에 다시 합니다 ({e})",
                  file=sys.stderr)
    # 검사 결과를 본 파일(state.db)로 옮겨 둔다 — 창이 연결을 쥐고 있으면 끝남 표식까지 WAL에만 있어, state.db만 복사·이전하거나
    # -wal을 지우면 그날 검사가 통째로 되돌아갔다 (검토60 ②). PASSIVE는 누구도 기다리지 않는다
    try:
        state.conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
    except sqlite3.DatabaseError:
        pass
    _set_progress("")
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    cfg = load_config(Path(args.config))
    db_path = Path(args.state_db or cfg["state_db"])
    with State(db_path) as state:
        rows = state.history(args.project)
    if not rows:
        print("이력 없음." + (f" (프로젝트 {args.project})" if args.project else ""))
        return 0
    for r in rows:
        ack = (f"확인: {r['ack_by']} ({_local_hm(r['ack_at'])})"
               + (f" — {r['ack_note']}" if r['ack_note'] else "")) \
            if r["ack_by"] else "미확인"
        print(f"#{r['change_id']:>4} {_local_hm(r['detected_at'])} "
              f"[{KIND_LABEL[r['kind']]}] [{r['project'] or '미분류'}] {r['path']}  | {ack}")
    return 0


_TASK_NAME = "ProjectWatcher"


def _daily_bat_text(root: Path | None = None) -> str:
    """매일 실행 배치 내용. exe면 exe를, 소스 실행이면 현재 파이썬을 그대로 쓴다 —
    다른 PC의 개발 경로를 하드코딩하지 않는다 (2026-08-25 UX 검토).
    root: 포터블을 다른 폴더로 옮긴 뒤 그 위치로 등록할 때 (2026-09-04)."""
    if root is not None and (root / "python" / "python.exe").is_file():
        run_line = (f'"{root / "python" / "python.exe"}" '
                    f'"{root / "app" / "entry.py"}" run')
    elif getattr(sys, "frozen", False):
        run_line = f"\"{Path(sys.executable).name}\" run"  # exe 이름 변경에도 안전
    elif Path(sys.executable).name.lower().startswith("drev"):
        # 포터블: 루트의 pythonw 사본(Drev.exe)은 무인자일 때 화면을 띄우는
        # 자동부트가 있어 자동 실행엔 python 원본을 쓴다 (2026-08-30 검토)
        root = Path(sys.executable).parent
        run_line = (f'"{root / "python" / "python.exe"}" '
                    f'"{root / "app" / "entry.py"}" run')
    else:
        repo = Path(__file__).resolve().parent.parent
        run_line = (f'set PYTHONPATH={repo};%PYTHONPATH%\r\n'
                    f'"{sys.executable}" -m watcher.cli run')
    return ('@echo off\r\ncd /d "%~dp0"\r\n'
            f"{run_line} >> run_daily.log 2>&1\r\n")


# 창 모드 앱에서 콘솔 프로그램(schtasks 등)을 부르면 검은 창이 깜빡인다 —
# CREATE_NO_WINDOW로 막는다 (2026-09-02: 설정 화면 진입마다 창이 떴다)
_NO_WINDOW = 0x08000000


# 예약이 못 돈 날의 설명 — 화면·도움말·설치안내·사이트가 한 문장을 쓴다. "놓치면 다음에 켜질 때 바로"는
# 09-16에 거짓으로 판명됐다(대화형 로그온 작업은 로그오프 상태의 회차를 되살리지 않는다, 검토30 D 2-1)
CATCH_UP_NOTE = ("""로그인된 상태여야 돌며, 절전 중이면 깨워서 실행합니다(전원 옵션이 깨우기를 막으면 깨어난 뒤 바로). """
                 """재부팅·로그오프로 그 시각을 놓친 날은 다음 로그인 3분 뒤(또는 Drev 창을 여는 순간) 대신 검사합니다.""")


def schedule_disabled() -> bool:
    """등록은 돼 있는데 '사용 안 함'으로 꺼 둔 작업인가 (schtasks 상세의 Status/상태 칸).
    schedule_status()는 rc만 보므로 꺼 둔 PC에서도 True다 — 보충 검사는 이걸 더 본다 (검토30 D 1-4)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception:
        return False
    if q.returncode != 0:
        return False
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" \
        else q.stdout.decode("utf-8", "replace")
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if sep and head.strip().lower() in ("status", "상태", "scheduled task state", "예약된 작업 상태"):
            v = val.strip().lower()
            if v in ("disabled", "사용 안 함", "사용 안함"):
                return True
    return False


# 작업 스케줄러 '마지막 결과' 코드의 뜻 — 0x41301 실행 중·0x41303 아직 안 돎은 정상
_TASK_RESULT = {
    1: "검사가 오류로 끝났습니다 — watcher.log를 확인하세요",
    2: "감시 폴더·설정 파일 문제로 검사하지 못했습니다 — watcher.log를 확인하세요",
    3: "검사가 중간에 멈췄습니다",
    4: "다른 검사가 돌고 있어 건너뛰었거나 이력 파일을 쓸 수 없었습니다 — 계속되면 watcher.log를 확인하세요",
    5: "이력 파일을 둘 폴더에 쓸 수 없습니다 — Drev 폴더를 사용자 폴더로 옮기세요",
    0x41306: "6시간 상한에 걸려 중단됐습니다",
    0x80070002: "실행 파일을 찾지 못했습니다 — Drev 폴더를 옮겼다면 설정 › 매일 자동 실행에서 [다시 등록]",
    0x800710E0: "로그인 전이라 실행하지 못했습니다",
}


def _parse_task_result(v: str) -> int | None:
    v = v.strip()
    try:
        n = int(v, 16) if v.lower().startswith("0x") else int(v)
    except ValueError:
        return None
    return n & 0xFFFFFFFF


def schedule_health(user: str | None = None) -> list[str]:
    """등록된 예약 작업이 **실제로 돌 수 있나** — 실행 계정·마지막 결과를 읽어 사람 말 경고 목록으로. 등록만 보고 '등록됨'이라
    하면, 표준 사용자가 관리자 자격으로 등록해 다른 계정에 걸린 작업·매일 오류로 끝나는 작업이 화면에서 정상으로 보였다
    (검토53 G ②). 조회를 못 하면 빈 목록(조르지 않는다)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    except Exception:
        return []
    if q.returncode != 0:
        return []
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" else q.stdout.decode("utf-8", "replace")
    info: dict = {}
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        h = head.strip().lower()
        if not sep:
            continue
        if h in ("run as user", "다음 사용자 이름으로 실행", "실행할 사용자", "다음 사용자로 실행"):
            info.setdefault("run_as", val.strip())
        elif h in ("last result", "마지막 결과"):
            info.setdefault("result", val.strip())
        elif h in ("last run time", "마지막 실행 시간"):
            info.setdefault("last_run", line.partition(":")[2].strip())
    out = []
    me = (user or os.environ.get("USERNAME") or "").strip().lower()
    ra = str(info.get("run_as") or "").strip()
    _ra_l = ra.split("\\")[-1].lower()
    _nobody = ("interactive", "users", "administrators", "system", "local service", "network service", "localsystem",
               "authenticated users", "everyone")
    if ra and me and _ra_l not in (me, "") and _ra_l not in _nobody:
        out.append(f"매일 자동 실행이 다른 사용자({ra})로 등록돼 있어, 지금 사용자로 로그인한 동안에는 돌지 않습니다 — "
                   "설정 › 매일 자동 실행에서 [다시 등록]하세요 (관리자 권한으로 실행할 필요는 없습니다)")
    rc = _parse_task_result(str(info.get("result") or ""))
    if rc not in (None, 0, 0x41300, 0x41301, 0x41302, 0x41303, 0x41304, 0x41325):
        why = _TASK_RESULT.get(rc, f"알 수 없는 결과 0x{rc:X}")
        lr = str(info.get("last_run") or "").strip()
        out.append(f"마지막 자동 실행{f'({lr})' if lr else ''}: {why}")
    return out


def schedule_status() -> bool:
    """작업 스케줄러에 ProjectWatcher가 등록돼 있는가."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME],
                           capture_output=True, timeout=15,
                           stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
        return q.returncode == 0
    except Exception:
        return False


def _schedule_action(root: Path | None = None) -> tuple[str, str, str] | None:
    """콘솔 창 없이 도는 작업 동작 (실행 파일, 인수, 작업 폴더). 없으면 None → 배치 사용.

    배치(cmd)로 등록하면 07시에 검은 창이 떴다. 포터블·설치판은 pythonw + entry.py, exe는
    자기 자신 — 둘 다 창 없이 돌고 출력은 entry.py가 watcher.log로 돌린다 (2026-09-05)."""
    base = root
    if base is None:
        exe = Path(sys.executable)
        if getattr(sys, "frozen", False):
            return str(exe), "run --if-missed", str(exe.parent)
        if exe.name.lower().startswith("drev"):
            base = exe.parent
        else:
            try:
                from watcher.selfupdate import install_root
                base = install_root()
            except Exception:
                base = None
    if base is not None:
        pyw, entry = base / "python" / "pythonw.exe", base / "app" / "entry.py"
        if pyw.is_file() and entry.is_file():
            return str(pyw), f'"{entry}" run --if-missed', str(base)
    return None


def _ps_quote(s: str) -> str:
    return "'" + "''".join(str(s).split("'")) + "'"     # 작은따옴표는 두 개로


def _schedule_tune(time_str: str, action: tuple[str, str, str] | None) -> tuple[bool, str]:
    """schtasks /Create가 못 정하는 조건을 PowerShell로 맞춘다: 배터리에서도 실행, 절전이면
    깨움, 그 시각을 놓치면 다음 켜질 때 바로 실행, 6시간 상한, 중복 실행 금지. 그리고 동작을
    창 없는 실행 파일로 바꾼다 (2026-09-05: 노트북·절전 PC에서 조용히 빠지던 날들)."""
    lines = [
        "$s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries "
        "-StartWhenAvailable -WakeToRun -MultipleInstances IgnoreNew "
        "-ExecutionTimeLimit (New-TimeSpan -Hours 6)",
    ]
    if action is not None:
        prog, args, wd = action
        lines.append(f"$a = New-ScheduledTaskAction -Execute {_ps_quote(prog)} "
                     f"-Argument {_ps_quote(args)} -WorkingDirectory {_ps_quote(wd)}")
        lines.append(f"Set-ScheduledTask -TaskName {_ps_quote(_TASK_NAME)} -Action $a -Settings $s | Out-Null")
    else:
        lines.append(f"Set-ScheduledTask -TaskName {_ps_quote(_TASK_NAME)} -Settings $s | Out-Null")
    script = "; ".join(lines)
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-Command", script],
                           capture_output=True, timeout=60, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception as e:
        return False, str(e)
    if r.returncode != 0:
        return False, (r.stderr or b"").decode("mbcs", "replace")[-300:]
    return True, ""


def _schedule_add_logon(time_str: str) -> bool:
    """로그인 3분 뒤에도 한 번 — 재부팅 뒤 로그인 화면에 머문 날(09-16 실사용), 로그오프한 밤에 07:00을 놓치면 창을 열기
    전까지 검사가 없었다. 동작은 `run --if-missed`라 그날 예약분이 이미 돌았으면 바로 끝난다 (검토53 G ①).
    실패해도(정책·권한) 등록은 유효하다."""
    lines = [f"$t1 = New-ScheduledTaskTrigger -Daily -At {_ps_quote(time_str)}",
             # Azure AD·도메인 캐시 로그온에서는 'DOMAIN\이름' 지정이 풀리지 않아 보충 조건이 통째로 빠졌다 (검토55 ②8).
             # 이름만 → 지정 없이 차례로 — 지정 없이 걸면 공용 PC의 다른 계정 로그인에도 발동하므로 마지막 수단 (검토56 ②9)
             "$ok = $false",
             "foreach ($u in @(($env:USERDOMAIN + '\\' + $env:USERNAME), $env:USERNAME, '')) { if ($ok) { break }; "
             "try { $t2 = if ($u) { New-ScheduledTaskTrigger -AtLogOn -User $u } else { New-ScheduledTaskTrigger -AtLogOn }; "
             f"$t2.Delay = 'PT3M'; Set-ScheduledTask -TaskName {_ps_quote(_TASK_NAME)} -Trigger $t1,$t2 -ErrorAction Stop | Out-Null; $ok = $true }} catch {{ }} }}",
             "if (-not $ok) { exit 1 }"]
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-Command", "; ".join(lines)],
                           capture_output=True, timeout=60, stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    except Exception:
        return False
    return r.returncode == 0


def schedule_upgrade_logon() -> bool:
    """옛 판이 등록한 예약(동작 'run', 07:00 트리거 하나)을 한 번 올린다 — 동작에 --if-missed, 로그인 3분 뒤 트리거.
    **이 설치본의 실행 파일을 가리키는 우리 작업일 때만**(다른 폴더의 판·사람이 손댄 작업은 그대로). 올렸으면 True.
    업데이트로 문구는 '다음 로그인 3분 뒤 대신 검사'가 됐는데 기존 고객의 작업에는 그 조건이 없었다 (검토53 G ①)."""
    action = _schedule_action()
    if action is None:
        return False
    exe = action[0]
    lines = [f"$t = Get-ScheduledTask -TaskName {_ps_quote(_TASK_NAME)} -ErrorAction SilentlyContinue",
             f"if ($t -and $t.Actions.Count -eq 1 -and $t.Actions[0].Execute -ieq {_ps_quote(exe)} "
             "-and $t.Actions[0].Arguments -notmatch '--if-missed') {",
             "$a = $t.Actions[0]; $a.Arguments = ($a.Arguments + ' --if-missed').Trim()",
             "$d = @($t.Triggers | Where-Object { $_.CimClass.CimClassName -eq 'MSFT_TaskDailyTrigger' })",
             # 트리거가 매일 하나뿐인 작업만 — 사람이 더한 주간·다른 트리거를 지웠다 (검토53 I 중간 5)
             # 사용자 지정이 안 풀리는 PC(Azure AD·캐시 로그온)에서 오류를 내고도 'UPGRADED'를 찍어 거짓 "조건을 더했습니다"가
             # 매번 남았다 — 오류는 멈추게 하고, 이름만·지정 없이 차례로 다시 건다 (검토56 ②9)
             "if ($d.Count -eq 1 -and @($t.Triggers).Count -eq 1) { $ok = $false; "
             "foreach ($u in @(($env:USERDOMAIN + '\\' + $env:USERNAME), $env:USERNAME, '')) { if ($ok) { break }; "
             "try { $t2 = if ($u) { New-ScheduledTaskTrigger -AtLogOn -User $u } else { New-ScheduledTaskTrigger -AtLogOn }; "
             "$t2.Delay = 'PT3M'; Set-ScheduledTask -TaskName " + _ps_quote(_TASK_NAME) + " -Action $a -Trigger $d[0],$t2 -ErrorAction Stop | Out-Null; $ok = $true } catch { } }; "
             "if ($ok) { 'UPGRADED' } } }"]
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-Command", "; ".join(lines)],
                           capture_output=True, timeout=60, stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    except Exception:
        return False
    return r.returncode == 0 and b"UPGRADED" in (r.stdout or b"")


def due_already_ran(cfg: dict, db_path: Path, now: datetime | None = None) -> str | None:
    """`run --if-missed`: 지금까지 가장 최근 예약 시각(오늘 그 시각이 지났으면 오늘, 아니면 어제) 뒤에 검사가 이미 있으면
    그 예약 시각 'HH:MM', 없으면 None(돌아야 함). 창의 보충 판정과 달리 20분 여유를 두지 않는다 — 07:00 트리거 자신도
    이 플래그로 돌기 때문에, 여유를 두면 정각 실행이 '어제 돌았음'으로 건너뛰어진다."""
    from datetime import time as _dtime
    # 시각은 **등록 실물**이 먼저 — config만 보면 사람이 작업 스케줄러에서 06:00으로 바꾼 집, 옛 'schedule' 블록 집에서 정규
    # 예약이 '이미 돌았다'로 건너뛰어졌다 (검토53 I 중간 1). 창의 보충 판정과 같은 순서
    old_block = cfg.get("schedule") if isinstance(cfg.get("schedule"), dict) else {}
    hhmm = str((cfg.get("_registered_time") or schedule_start_time()) or cfg.get("schedule_time")
               or (old_block or {}).get("time") or "07:00")
    now = (now or datetime.now()).astimezone()
    try:
        hh, mm = (int(x) for x in hhmm.split(":")[:2])
        due = datetime.combine(now.date(), _dtime(hh, mm)).astimezone()
    except (ValueError, TypeError):
        hhmm = "07:00"
        due = datetime.combine(now.date(), _dtime(7, 0)).astimezone()
    if now < due:
        due -= timedelta(days=1)
    if not db_path.exists():
        return None
    try:
        from urllib.parse import quote as _q
        with sqlite3.connect(f"file:{_q(db_path.as_posix(), safe='/:')}?mode=ro", uri=True) as c:
            # 보고를 마치지 못하고 죽은 검사(run_in_progress)의 스냅샷은 '돌았다'가 아니다 — 07:00 검사가 중간에 죽은 날
            # 로그인 보충이 정확히 그날만 건너뛰었다 (검토53 J 중간 4)
            try:
                _bad = c.execute("SELECT value FROM meta WHERE key = 'run_in_progress'").fetchone()
            except sqlite3.Error:
                _bad = None
            _bad_id = int(_bad[0]) if _bad and str(_bad[0] or "").isdigit() else -1
            row = c.execute("SELECT run_at FROM snapshots WHERE id != ? ORDER BY id DESC LIMIT 1", (_bad_id,)).fetchone()
    except sqlite3.Error:
        return None
    if not row:
        return None
    try:
        last = datetime.fromisoformat(row[0]).astimezone()
    except (TypeError, ValueError):
        return None
    return hhmm if due <= last <= now + timedelta(hours=1) else None


def _task_exe_of(task_to_run: str) -> str:
    """'C:\\x\\pythonw.exe "C:\\x\\app\\entry.py" run' → 실행 파일 경로."""
    s = task_to_run.strip()
    if s.startswith('"'):
        return s[1:].split('"', 1)[0]
    m = re.match(r"(.+?\.(?:exe|bat|cmd))(?:\s|$)", s, re.I)
    return m.group(1) if m else s


def schedule_start_time() -> str | None:
    """등록된 작업의 시작 시각 'HH:MM' (schtasks 상세 조회). 모르면 None.
    화면이 config의 시각만 보여 주면 구판·수동으로 바뀐 등록과 어긋난다 (검토19 운영 ⑦)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception:
        return None
    if q.returncode != 0:
        return None
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" \
        else q.stdout.decode("utf-8", "replace")
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if sep and head.strip().lower() in ("start time", "시작 시간"):
            m = re.search(r"(\d{1,2}):(\d{2})", val)
            if not m:
                return None
            h, mi = int(m.group(1)), int(m.group(2))
            v = val.lower()
            if ("pm" in v or "오후" in v) and h < 12:
                h += 12
            if ("am" in v or "오전" in v) and h == 12:
                h = 0
            return f"{h:02d}:{mi:02d}"
    return None


def _target_is_ours(tgt: str) -> bool:
    """예약이 실행하는 파일이 이 설치본 폴더 안인가 (화면의 _sched_foreign과 같은 판정)."""
    try:
        from watcher import selfupdate as _su
        root = _su.install_root() or Path.cwd()
        return str(Path(tgt).resolve()).lower().startswith(str(root.resolve()).lower().rstrip("\\") + "\\")
    except OSError:
        return False


def schedule_target() -> str | None:
    """등록된 작업이 실행하는 파일 경로 (schtasks 상세 조회). 모르면 None.
    옮긴 뒤 옛 폴더를 가리키는 등록을 화면이 '정상'으로 보이던 것 (2026-09-04)."""
    try:
        q = subprocess.run(["schtasks", "/Query", "/TN", _TASK_NAME, "/V", "/FO", "LIST"],
                           capture_output=True, timeout=15, stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception:
        return None
    if q.returncode != 0:
        return None
    text = q.stdout.decode("mbcs", "replace") if sys.platform == "win32" \
        else q.stdout.decode("utf-8", "replace")
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if sep and head.strip().lower() in ("task to run", "실행할 작업"):
            return _task_exe_of(val)
    return None


def schedule_register(time_str: str = "07:00", root: Path | None = None) -> tuple[bool, str]:
    """매일 자동 실행 등록. run_daily.bat을 (없거나 낡았으면) 새로 쓰고 등록한다.
    root: 배치를 둘 폴더(기본 현재 폴더) — 설치로 옮긴 새 위치에 등록할 때."""
    bat = (root or Path.cwd()) / "run_daily.bat"
    text = _daily_bat_text(root)
    action = _schedule_action(root)
    bat_ok, bat_why = True, ""
    try:
        # cmd는 배치를 ANSI(cp949)로 읽는다 — utf-8로 쓰면 경로에 한글이 있을 때 깨짐.
        # cp949로 표현 불가한 문자는 조용히 지우지 말고(bat 파손) 등록을 거부한다
        if not bat.exists() or bat.read_text(encoding="mbcs",
                                             errors="ignore") != text:
            bat.write_text(text, encoding="mbcs", errors="strict")
    except UnicodeEncodeError:
        bat_ok, bat_why = False, ("경로에 한글/영문 외 특수문자가 있어 배치 파일을 "
                                 "만들 수 없었습니다")
    except OSError as e:
        bat_ok, bat_why = False, f"배치 파일을 쓸 수 없었습니다 ({e})"
    # 배치를 못 써도 **창 없는 동작**이 있으면 그것으로 바로 등록한다. 전에는 여기서
    # 거부해 schtasks를 부르지도 않았고, 정작 등록되는 동작은 _schedule_tune이
    # pythonw+entry.py로 갈아치우는 것이라 배치는 쓰이지도 않았다 — 쓰기 제한된
    # 폴더에 설치하면 자동 실행을 아예 못 켰다 (2026-09-09 자동 실행 검토 낮음 10)
    if not bat_ok and action is None:
        return False, (f"등록 실패: {bat_why} — 설치 폴더를 쓸 수 있는 곳으로 "
                       f"옮기거나 권한을 확인해주세요.")
    tr = f'"{bat}"' if bat_ok else f'"{action[0]}" {action[1]}'
    try:
        r = subprocess.run(["schtasks", "/Create", "/TN", _TASK_NAME,
                            "/TR", tr, "/SC", "DAILY",
                            "/ST", time_str, "/F"],
                           capture_output=True, timeout=15,
                           stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception as e:
        return False, f"등록 실패: {e}"
    if r.returncode == 0:
        ok, why = _schedule_tune(time_str, action)
        if ok:
            logon = _schedule_add_logon(time_str) if action is not None else False
            return True, (f"등록 완료 — 매일 {time_str}에 자동 검사합니다. " + CATCH_UP_NOTE
                          + " 배터리 상태에서도 돌며, 창은 뜨지 않습니다."
                          + ("" if logon else " (로그인 때 대신 검사하는 조건은 걸지 못했습니다 — 창을 열면 대신 검사합니다)"))
        return True, (f"등록 완료 — 매일 {time_str}에 자동 검사합니다. 다만 절전·배터리 조건을 "
                      f"바꾸지 못해 그 시각에 PC가 켜져 있고 전원이 연결돼 있어야 하며, 실행 때 검은 창이 "
                      f"잠깐 뜹니다 ({why.strip()[:120]})")
    # 사용자 작업은 관리자 권한이 필요 없다 — '관리자 권한으로 실행'을 권하면 작업이 관리자 계정에 걸려 이 사용자로 돌지 않았다.
    # Windows가 준 이유를 그대로 보이고, 회사 정책으로 막힌 경우를 안내한다 (구매자 평가 P2)
    try:
        _why = (r.stderr or r.stdout or b"").decode("cp949", "replace").strip().splitlines()
        _why = (_why[-1] if _why else "")[:160]
    except Exception:
        _why = ""
    return False, ("등록 실패" + (f" — Windows: {_why}" if _why else "") + ". 회사 보안 정책이 예약 작업 만들기를 막았을 수 "
                   "있습니다 — 전산 담당에게 '이 사용자로 매일 도는 예약 작업을 만들 수 있게' 요청하거나, 도움말 › 관리자용 "
                   "'작업 스케줄러에서 직접 등록' 순서대로 만들어 주세요(포터블판에는 설치안내.txt가 없습니다). "
                   "관리자 권한으로 실행할 필요는 없습니다.")


def schedule_unregister() -> tuple[bool, str]:
    try:
        r = subprocess.run(["schtasks", "/Delete", "/TN", _TASK_NAME, "/F"],
                           capture_output=True, timeout=15,
                           stdin=subprocess.DEVNULL,
                           creationflags=_NO_WINDOW)
    except Exception as e:
        return False, f"해제 실패: {e}"
    return (r.returncode == 0,
            "자동 실행을 해제했습니다." if r.returncode == 0 else "해제 실패 — 이미 없거나 권한 문제입니다.")


# ── 양식함 상주 작업 DrevForms (2026-10-28 F4, FORMS.md 7절) ─────────────────────────────────────────
# 감시 작업(ProjectWatcher)과 완전히 따로다 — 이름이 다른 작업 하나만 만들고·시작하고·멈추고·지운다.
# ProjectWatcher는 여기서 읽지도 바꾸지도 않는다(아래 _forms_task_cmd가 그 이름이 섞인 명령을 거부한다).
_FORMS_TASK = "DrevForms"
_OTHER_TASK_RE = re.compile(r"(?i)(/TN\s+\"?" + re.escape(_TASK_NAME) + r"\b|TaskName\s+'?" + re.escape(_TASK_NAME) + r"\b)")


def _forms_task_cmd(cmd: list, timeout: float = 60):
    """DrevForms 작업에 대한 외부 명령(schtasks·PowerShell)이 모두 지나는 한 곳 — 시험은 이것을 가짜로 바꾼다.
    감시 작업 이름이 섞이거나 DrevForms가 없는 명령은 실행하지 않는다(안전장치)."""
    joined = " ".join(str(c) for c in cmd)
    if _OTHER_TASK_RE.search(joined) or _FORMS_TASK not in joined:
        raise RuntimeError("양식함 작업 명령이 아닙니다 — 실행하지 않습니다")
    return subprocess.run([str(c) for c in cmd], capture_output=True, timeout=timeout,
                          stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)


def forms_task_action(config_path) -> tuple[str, str, str] | None:
    """양식함 상주 작업의 동작 (실행 파일, 인수, 작업 폴더). 작업 폴더는 **데이터 폴더(config.yaml이 있는 곳)** —
    app\\ 을 작업 폴더로 잡으면 업데이트가 app 폴더 이름을 바꾸지 못한다. 만들 수 없으면 None."""
    cfg = Path(config_path).resolve()
    data = cfg.parent
    exe = Path(sys.executable)
    if getattr(sys, "frozen", False):
        return str(exe), f'--config "{cfg}" forms-serve', str(data)
    base = None
    if exe.name.lower().startswith("drev"):
        base = exe.parent
    else:
        try:
            from watcher.selfupdate import install_root
            base = install_root()
        except Exception:
            base = None
    if base is not None:
        pyw, entry = base / "python" / "pythonw.exe", base / "app" / "entry.py"
        if pyw.is_file() and entry.is_file():
            return str(pyw), f'"{entry}" --config "{cfg}" forms-serve', str(data)
    pyw = exe.with_name("pythonw.exe")             # 개발 실행 — 저장소에서 -m 으로
    if pyw.is_file():
        return str(pyw), f'-m watcher.cli --config "{cfg}" forms-serve', str(PROJECT_DIR)
    return None


def _schtasks_list(text: str) -> dict:
    info: dict = {}
    for line in text.splitlines():
        head, sep, val = line.partition(":")
        if not sep:
            continue
        h = head.strip().lower()
        if h in ("status", "상태"):
            info.setdefault("status", val.strip())
        elif h in ("task to run", "실행할 작업"):
            info.setdefault("target", val.strip())
        elif h in ("start in", "시작 위치"):
            info.setdefault("start_in", val.strip())
    return info


def forms_task_status() -> dict:
    """{exists, running, target} — 양식함 작업이 등록돼 있나·지금 도나. 조회를 못 하면 없음으로."""
    out = {"exists": False, "running": False, "target": ""}
    try:
        q = _forms_task_cmd(["schtasks", "/Query", "/TN", _FORMS_TASK, "/V", "/FO", "LIST"], timeout=15)
    except Exception:
        return out
    if q.returncode != 0:
        return out
    raw = q.stdout or b""
    text = raw.decode("mbcs", "replace") if sys.platform == "win32" else raw.decode("utf-8", "replace")
    info = _schtasks_list(text)
    st = str(info.get("status") or "").lower()
    tgt = info.get("target") or ""
    try:
        tgt = _task_exe_of(tgt) or tgt if tgt else ""
    except Exception:
        pass
    out.update(exists=True, running=st in ("running", "실행 중", "실행중"), target=tgt)
    return out


def _forms_register_script(action: tuple[str, str, str]) -> str:
    """로그온 때 시작(30초 뒤), 실패하면 1분 뒤 다시(3번), 시간 상한 없음, 겹쳐 띄우지 않음, 배터리에서도."""
    prog, args, wd = action
    name = _ps_quote(_FORMS_TASK)
    return "; ".join([
        f"$a = New-ScheduledTaskAction -Execute {_ps_quote(prog)} -Argument {_ps_quote(args)} -WorkingDirectory {_ps_quote(wd)}",
        "$s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable "
        "-MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -RestartCount 3 "
        "-RestartInterval (New-TimeSpan -Minutes 1)",
        "$ok = $false",
        # 이 사용자 로그온만 — 'DOMAIN\이름'이 안 풀리는 PC(Azure AD·캐시 로그온)는 이름만 (감시 작업과 같은 순서)
        "foreach ($u in @(($env:USERDOMAIN + '\\' + $env:USERNAME), $env:USERNAME)) { if ($ok) { break }; "
        "try { $t = New-ScheduledTaskTrigger -AtLogOn -User $u; $t.Delay = 'PT30S'; "
        f"Register-ScheduledTask -TaskName {name} -Action $a -Trigger $t -Settings $s "
        "-Description 'Drev 양식함 (사내망 양식 서버) — Drev 설정 › 양식함에서 켜고 끕니다' -Force -ErrorAction Stop | Out-Null; "
        "$ok = $true } catch { } }",
        "if (-not $ok) { exit 1 }",
    ])


def forms_task_register(config_path) -> tuple[bool, str]:
    """[양식함 켜기] — 로그온 시 시작·실패 시 다시 시작하는 DrevForms 작업을 만들고 바로 시작한다."""
    action = forms_task_action(config_path)
    if action is None:
        return False, "이 실행 형태에서는 양식함 상주 작업을 만들 수 없습니다 — 포터블·설치판 Drev에서 켜 주세요"
    try:
        r = _forms_task_cmd(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                             "-Command", _forms_register_script(action)], timeout=60)
    except Exception as e:
        return False, f"양식함 작업을 만들지 못했습니다: {e}"
    if r.returncode != 0:
        why = (r.stderr or r.stdout or b"").decode("mbcs", "replace").strip().splitlines()
        return False, ("양식함 작업을 만들지 못했습니다" + (f" — Windows: {why[-1][:160]}" if why else "")
                       + ". 회사 보안 정책이 예약 작업 만들기를 막았을 수 있습니다 — 전산 담당에게 문의하세요")
    try:
        s = _forms_task_cmd(["schtasks", "/Run", "/TN", _FORMS_TASK], timeout=15)
        started = s.returncode == 0
    except Exception:
        started = False
    return True, ("양식함을 켰습니다 — " + ("지금 시작했고, " if started else "")
                  + "앞으로 Windows에 로그인하면 저절로 시작합니다(멈추면 1분 뒤 다시 시작)."
                  + ("" if started else " 지금 바로 시작하지는 못했습니다 — 다시 로그인하거나 [다시 시작]을 누르세요."))


def forms_task_start() -> bool:
    try:
        return _forms_task_cmd(["schtasks", "/Run", "/TN", _FORMS_TASK], timeout=15).returncode == 0
    except Exception:
        return False


def forms_task_stop() -> bool:
    try:
        return _forms_task_cmd(["schtasks", "/End", "/TN", _FORMS_TASK], timeout=15).returncode == 0
    except Exception:
        return False


def forms_task_unregister() -> tuple[bool, str]:
    """[양식함 끄기] — 작업을 멈추고 지운다. 데이터(forms.db·forms_store)는 그대로 남는다."""
    forms_task_stop()
    try:
        r = _forms_task_cmd(["schtasks", "/Delete", "/TN", _FORMS_TASK, "/F"], timeout=15)
    except Exception as e:
        return False, f"양식함 작업을 지우지 못했습니다: {e}"
    if r.returncode != 0:
        return False, "양식함 작업을 지우지 못했습니다 — 이미 없거나 권한 문제입니다"
    return True, "양식함을 껐습니다 — 서버를 멈추고 자동 시작을 지웠습니다. 양식·계정·이력은 그대로 남습니다."


def _forms_logger(data_dir: Path):
    """forms.log(데이터 폴더, 5MB 상한·.old 하나)에 drev.forms 로거를 붙인다 — pythonw에는 콘솔이 없다."""
    import logging
    from watcher.logfile import CappedFileHandler
    lg = logging.getLogger("drev.forms")
    lg.setLevel(logging.INFO)
    path = Path(data_dir) / "forms.log"
    if not any(getattr(h, "baseFilename", "") == str(path) for h in lg.handlers):
        try:
            h = CappedFileHandler(path)
            h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
            lg.addHandler(h)
        except OSError as e:
            print(f"[forms] 로그 파일을 열 수 없습니다({e}) — 기록 없이 계속합니다", file=sys.stderr)
    return logging.getLogger("drev.forms.server")


def cmd_forms_serve(args) -> int:
    """양식함 사내망 서버를 돌린다(멈출 때까지) — DrevForms 작업이 pythonw로 부른다. 설정에서 꺼져 있으면 안내하고 끝낸다.
    돌려주는 값: 0 정상·꺼짐, 1 열 수 없음(주소·포트·폴더), 2 이미 실행 중."""
    cfg = load_config(Path(args.config))
    from watcher.forms.settings import base_url, forms_settings
    fs = forms_settings(cfg)
    if not fs["enabled"]:
        print("양식함이 꺼져 있습니다 — Drev 화면의 설정 › 양식함에서 켜세요. 아무것도 하지 않고 끝냅니다.")
        return 0
    data_dir = Path(cfg["state_db"]).resolve().parent
    if not data_dir.is_dir():
        print(f"오류: Drev 데이터 폴더가 없습니다: {data_dir}", file=sys.stderr)
        return 1
    try:
        os.chdir(data_dir)        # 작업 폴더가 app\ 이면 업데이트가 app 폴더 이름을 못 바꾼다
    except OSError:
        pass
    log = _forms_logger(data_dir)
    from watcher.forms import server as FS
    from watcher.forms.store import FormsError
    try:
        host = FS.check_bind_host(fs["host"])
    except FormsError as e:
        log.error("양식함을 열 수 없습니다: %s", e)
        print(f"오류: {e}", file=sys.stderr)
        return 1
    notify_mail = dict(cfg.get("mail") or {}) if fs["notify"] else None
    url = base_url(host, fs["port"])
    start_roots = [str(r) for r in (cfg.get("roots") or [])]
    from watcher.forms.settings import mirror_root_problem
    why = mirror_root_problem(fs["mirror_root"], start_roots)
    if why:                     # 화면 저장만 막고 있었다 — config.yaml을 손으로 고친 경우도 (검토20 r04-1)
        log.error("양식함: %s", why)
        print(f"경고: {why}", file=sys.stderr)

    def watch_roots():
        """동기화마다 config.yaml의 감시 폴더를 다시 읽는다 — 미러를 정한 뒤 그 위 폴더를 감시에 더한 경우 (검토20 r04-1)."""
        try:
            return [str(r) for r in (load_config(Path(args.config)).get("roots") or [])]
        except Exception:
            return start_roots

    def watch_recipients():
        """사내망 변경 열람의 기본 범위 제안 — 화면을 열 때마다 감시 메일 받는 사람을 다시 읽는다 (갈래 N, 2026-11-02)."""
        from watcher.forms.settings import watch_recipients as _wr
        try:
            return _wr(load_config(Path(args.config)))
        except (Exception, SystemExit):          # 설정을 못 읽어도(파일 없음 = SystemExit) 화면은 제안 없이 그대로
            return {}

    def ready(srv):
        h_, p_ = srv.server_address[:2]
        try:          # 매일 백업·주간 알림 (2026-10-30) — 붙이지 못해도 양식함은 돈다
            from watcher.forms.backup import attach
            attach(srv, fs, data_dir=data_dir, mail_cfg=cfg.get("mail"), base_url=url,
                   watch_roots=[str(r) for r in (cfg.get("roots") or [])])
        except Exception:
            log.exception("양식함 백업·주간 알림을 붙이지 못했습니다")
        log.info("양식함이 열렸습니다: %s:%s (데이터 %s, 미러 %s, 메일 알림 %s, 백업 %s, 주간 알림 %s)", h_, p_, data_dir,
                 fs["mirror_root"] or "없음", "켬" if notify_mail is not None else "끔",
                 getattr(getattr(srv, "backup", None), "dir", None) or "끔",
                 "켬" if getattr(srv, "weekly", None) is not None else "끔")
        print(f"양식함이 열렸습니다: http://{h_}:{p_}/", flush=True)

    deadline = time.monotonic() + max(0.0, float(getattr(args, "wait", 300) or 0))
    while True:
        try:
            FS.serve(data_dir, host, fs["port"], mirror_root=fs["mirror_root"] or None,
                     max_upload_bytes=fs["max_upload_mb"] * 1024 * 1024, compare_timeout=fs["compare_timeout"],
                     notify_mail=notify_mail, base_url=url, on_ready=ready,
                     audit_max_rows=fs["audit_max_rows"], pending_keep_days=fs["pending_keep_days"],
                     review_months_default=fs["review_months_default"], watch_roots=watch_roots,
                     watch_db=Path(cfg["state_db"]), watch_recipients=watch_recipients)   # 사내망 변경 확인 (갈래 N)
            return 0
        except FS.AlreadyRunning as e:
            log.info("%s", e)
            print(str(e), file=sys.stderr)
            return 2
        except KeyboardInterrupt:
            return 0
        except FormsError as e:
            log.error("양식함을 열 수 없습니다: %s", e)
            print(f"오류: {e}", file=sys.stderr)
            return 1
        except sqlite3.Error as e:      # 잠김·디스크 — 바깥 처리기가 state.db 이야기로 바꾸지 않게 (재검토 이주 2)
            log.error("forms.db를 열 수 없습니다(잠김·디스크): %s", e)
            print(f"오류: forms.db를 열 수 없습니다(다른 프로그램이 쓰는 중이거나 디스크 문제) — {e}", file=sys.stderr)
            return 1
        except OSError as e:
            # 로그온 직후에는 사내망 주소가 아직 안 붙었을 수 있다 — 잠깐씩 다시 해 본다
            if time.monotonic() >= deadline:
                log.error("양식함 주소 %s:%s 를 열 수 없습니다: %s", host, fs["port"], e)
                print(f"오류: 양식함 주소 {host}:{fs['port']}를 열 수 없습니다 — {e} (다른 프로그램이 포트를 쓰거나 "
                      f"그 주소가 이 PC에 없습니다)", file=sys.stderr)
                return 1
            log.warning("양식함 주소 %s:%s 를 아직 열 수 없어 10초 뒤 다시 합니다: %s", host, fs["port"], e)
            time.sleep(min(10.0, max(0.5, deadline - time.monotonic())))


def cmd_forms_restore(args) -> int:
    """양식함 백업에서 forms.db·판 파일을 되살린다 (2026-10-30, watcher/forms/backup.py).
    돌려주는 값: 0 성공(미리보기 포함), 1 실패·확인 문제, 2 양식함 서버가 실행 중."""
    cfg = load_config(Path(args.config))
    from watcher.forms.backup import backup_dir_of, restore
    from watcher.forms.settings import forms_settings
    data_dir = Path(cfg["state_db"]).resolve().parent
    src = args.from_dir or str(backup_dir_of(data_dir, forms_settings(cfg)["backup_dir"]))
    slot = args.slot
    if slot is not None and not 1 <= slot <= 99:
        print("오류: --slot 은 1~99 사이 번호입니다", file=sys.stderr)
        return 1
    return restore(data_dir, src, slot=slot, dry_run=args.dry_run, out=lambda t: print(t, flush=True))


def cmd_uninstall(args) -> int:
    """바로가기·제거 목록 등록만 지운다 — 이력(state.db)은 남긴다.

    폴더까지 지울지는 사람이 판단한다(원칙 5). 프로그램이 자기 데이터를 말없이
    지우면 되돌릴 수 없기 때문."""
    from watcher.install import uninstall
    r = uninstall()
    # 매일 실행 작업이 남아 지운 폴더를 매일 부르던 것 — 단 이 폴더를 가리킬 때만. 같은 PC의 다른 Drev로 옮긴 예약까지
    # 지워 그쪽 아침 검사가 말없이 사라졌다 (검토56 ②8)
    tgt = schedule_target() if schedule_status() else None
    if tgt and _target_is_ours(tgt):
        ok_s, _m = schedule_unregister()
        if ok_s:
            print("매일 자동 실행 등록을 해제했습니다.")
    elif tgt:
        print(f"매일 자동 실행은 다른 폴더의 Drev를 가리켜 그대로 둡니다: {tgt}")
    elif schedule_status():
        # 대상을 읽지 못하면(영·한 외 Windows 머리글 등) 말없이 남겼다 (검토57 ②8)
        print("매일 자동 실행이 무엇을 가리키는지 확인하지 못해 그대로 둡니다 — 직접 지우려면: schtasks /Delete /TN ProjectWatcher /F")
    # 양식함 상주 작업도 이 폴더를 가리킬 때만 지운다 (2026-10-28 F4)
    ft = forms_task_status()
    if ft["exists"] and ft["target"] and _target_is_ours(ft["target"]):
        ok_f, _m = forms_task_unregister()
        if ok_f:
            print("양식함 상주 작업(DrevForms)을 멈추고 지웠습니다.")
    print(f"바로가기 {r['shortcuts']}개 제거, 프로그램 목록 등록 "
          f"{'해제됨' if r['registry'] else '없음'}.")
    print(f"이력·설정은 그대로 남아 있습니다: {r['folder']}")
    print("완전히 지우려면 위 폴더를 삭제하세요.")
    return 0


# 콘솔(cp949)에 없는 글자 → 비슷한 ASCII. 'replace'만 걸면 머리말·--help의 '—'가 전부 '?'로 찍혔다 (검토20 r17-a)
_CONSOLE_FALLBACK = {"\u2014": "-", "\u2013": "-", "\u2012": "-", "\u2212": "-", "\u2192": "->", "\u2190": "<-",
                     "\u2026": "...", "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"', "\u00a0": " ",
                     "\u2713": "v", "\u2717": "x", "\u26a0": "!", "\u00b7": "."}


def _console_fallback(e):
    if not isinstance(e, UnicodeEncodeError):
        raise e
    bad = e.object[e.start:e.end]
    out = []
    for ch in bad:
        rep = _CONSOLE_FALLBACK.get(ch, "?")
        try:
            rep.encode(e.encoding)
        except (UnicodeEncodeError, LookupError):
            rep = "?"
        out.append(rep)
    return "".join(out), e.end


def _console_safe(stream) -> None:
    """못 찍는 글자에서 죽지 않고, '—' 같은 흔한 기호는 '-'로 바꿔 찍게 스트림을 맞춘다."""
    import codecs
    try:
        codecs.lookup_error("drev_console")
    except LookupError:
        codecs.register_error("drev_console", _console_fallback)
    try:
        if stream is not None and hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="drev_console")
    except Exception:      # noqa: BLE001
        pass


def main(argv: list[str] | None = None) -> int:
    # cp949 콘솔·파이프에서 '—'(U+2014) 한 글자에 첫 줄부터 죽었다 — entry.py처럼 못 찍는 글자는 바꿔 찍는다 (검토64 D2)
    for _s in (sys.stdout, sys.stderr):
        _console_safe(_s)
    if (argv if argv is not None else sys.argv[1:]) == []:
        # 더블클릭 진입점: 웹 대시보드(브라우저). 실패하면 이유를 메시지 상자로 알리고 watcher.log에 한 줄 남긴다 —
        # 콘솔 질문식 첫 설정(run_wizard)은 창 모드에 콘솔이 없어 쓰이지 않았다 (2026-11-02 기능 검토 S)
        try:
            from watcher.web import run_web
            return run_web()
        except SystemExit:
            raise
        except Exception as e:
            print(f"화면 실행 실패: {type(e).__name__}: {e}", file=sys.stderr)
            try:
                from watcher.web import _message_box
                _message_box("Drev — 화면을 열지 못했습니다",
                             f"화면을 열지 못했습니다: {e}\n\n자세한 내용은 Drev 폴더의 watcher.log에 있습니다. "
                             "계속되면 그 파일을 판매자에게 보내 주세요.")
            except Exception:      # noqa: BLE001 — 알림 실패로 원래 오류를 가리지 않는다
                pass
            return 1
    parser = argparse.ArgumentParser(prog="watcher", description="프로젝트 산출물 변경 감시자")
    parser.add_argument("--config", default="config.yaml",
                        help="설정 파일 경로 (기본: 현재 폴더의 config.yaml)")
    # 자동 업데이트가 내려받은 실행 파일이 이 PC에서 정말 실행되는지(SAC 차단 여부
    # 포함) 확인하는 데도 쓴다 — 교체 전에 한 번 돌려본다 (2026-08-31)
    parser.add_argument("--version", action="version",
                        version=f"Drev {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="config.yaml 생성")
    p_init.set_defaults(func=cmd_init)

    p_run = sub.add_parser("run", help="스캔 1회 실행")
    p_run.add_argument("--root", help="config의 root_path 대신 사용할 루트")
    p_run.add_argument("--state-db", help="config의 state_db 대신 사용할 DB 경로")
    p_run.add_argument("--brief-dir", help="config의 brief_dir 대신 사용할 브리핑 저장 폴더")
    p_run.add_argument("--dry-run", action="store_true",
                       help="메일 초안·발송 없이 브리핑 HTML만 저장 — 미리보기가 아니다: 검사 기록은 남아 같은 변경은 다음 검사에서 "
                            "다시 보고되지 않는다 (검토67 C4)")
    p_run.add_argument("--if-missed", action="store_true",
                       help="가장 최근 예약 시각 뒤에 검사가 이미 있으면 바로 끝낸다 (예약 작업의 로그인 보충용)")
    p_run.add_argument("--full", action="store_true",
                       help="크기·수정시각 단축 없이 전체 파일을 다시 해싱 (주기 점검용)")
    p_run.add_argument("--lock-wait", type=float, default=1200, dest="lock_wait",
                       help="다른 검사·추출 기록 갱신이 잠금을 쥐고 있으면 기다릴 초 (예약 검사용, 기본 20분)")
    p_run.set_defaults(func=cmd_run)

    # 판 교체 직후 selfupdate가 부른다 — 추출 기록만 새 세대로 (검토25 감지 6-1)
    p_rc = sub.add_parser("refresh-cache", help=argparse.SUPPRESS)
    p_rc.add_argument("--state-db", default=None)
    p_rc.add_argument("--to-log", action="store_true")
    p_rc.set_defaults(func=cmd_refresh_cache)

    # 윈도우 '프로그램 추가/제거'가 부르는 제거 명령 (2026-08-31)
    p_uni = sub.add_parser("uninstall", help="바로가기·프로그램 목록 등록과 이 폴더의 매일 자동 실행 정리")
    p_uni.set_defaults(func=cmd_uninstall)

    # ack-serve(확인 링크만 받는 맨 서버)는 뺐다 — 확인 링크는 화면(web.py)이 받고, 이 명령은 어디서도
    # 안내하지 않았다 (검토36 기능 정리). ack_server 모듈은 화면이 이어받아 쓴다
    p_hist = sub.add_parser("history", help="변경·확인 이력 조회")
    p_hist.add_argument("--state-db", help="config의 state_db 대신 사용할 DB 경로")
    p_hist.add_argument("--project", help="프로젝트 번호로 필터 (예: P24-031)")
    p_hist.set_defaults(func=cmd_history)

    # 양식함 사내망 서버 — 설정 › 양식함에서 켜면 DrevForms 작업이 로그온 때 pythonw로 부른다 (2026-10-28 F4)
    p_fs = sub.add_parser("forms-serve", help="양식함(사내망 양식 관리) 서버 실행 — 설정에서 켠 경우만, 멈출 때까지 돈다",
                          description="양식함 사내망 서버를 돌린다. config.yaml의 forms: 묶음(enabled·host·port·"
                                      "mirror_root·max_upload_mb·compare_timeout·notify)을 읽고, 꺼져 있으면 안내만 하고 끝낸다. "
                                      "기록은 데이터 폴더의 forms.log.")
    p_fs.add_argument("--wait", type=float, default=300,
                      help="주소·포트를 아직 열 수 없을 때(로그온 직후 등) 다시 해 볼 최대 초 (기본 300)")
    p_fs.set_defaults(func=cmd_forms_serve)

    # 양식함 복원 — 양식함 서버를 끈 뒤 Drev PC에서만 (2026-10-30). 백업은 서버가 매일 한다
    p_fr = sub.add_parser("forms-restore", help="양식함 백업에서 forms.db·판 파일 되살리기 (양식함을 끈 뒤, --dry-run 먼저)",
                          description="양식함 백업 폴더에서 검사(integrity_check)를 통과한 가장 새 DB 사본을 forms.db로 되살리고, "
                                      "없는 판 파일만 되살린 뒤 모든 판의 파일·지문을 확인한다. 지금 forms.db는 지우지 않고 "
                                      "forms.db.before-restore-<때>로 남긴다. 양식함 서버가 돌고 있으면 거부한다 — "
                                      "서버를 끈 같은 Windows 계정에서 실행하세요.")
    p_fr.add_argument("--from", dest="from_dir", default=None,
                      help="백업 폴더 (기본: 설정의 forms.backup_dir, 비었으면 <데이터 폴더>\\forms_backup)")
    p_fr.add_argument("--slot", type=int, default=None, help="이 번호의 DB 사본만 쓴다 (기본: 검사를 통과한 가장 새 것)")
    p_fr.add_argument("--dry-run", action="store_true", dest="dry_run", help="무엇이 바뀌는지 보여 주기만 한다")
    p_fr.set_defaults(func=cmd_forms_restore)

    # 내용 추출 자식 프로세스 (검사가 내부적으로 띄운다 — 사람이 직접 쓰지 않음)
    p_wk = sub.add_parser("extract-worker", help=argparse.SUPPRESS)
    p_wk.set_defaults(func=lambda a: __import__("watcher.worker", fromlist=["serve"]).serve())
    # 3.12의 add_parser(help=SUPPRESS)는 숨기지 못하고 '==SUPPRESS=='를 찍었다 — 내부 명령은 목록에서 뺀다 (검토55 ②6)
    # init·history는 화면(첫 실행 온보딩·변경 이력)이 대신한다 — 명령은 남기고 도움말 목록에서만 숨긴다 (2026-11-02 기능 검토 S)
    _hidden = {"refresh-cache", "extract-worker", "init", "history"}
    sub._choices_actions = [a for a in sub._choices_actions if a.dest not in _hidden]
    sub.metavar = "{" + ",".join(n for n in sub.choices if n not in _hidden) + "}"

    args = parser.parse_args(argv)
    try:
        rc = args.func(args)
    except ConfigError as e:
        # 예약 검사(콘솔 없음)가 설정 파일 탭·문법 오류에 날 traceback으로 죽었다 (검토21 운영 1)
        print(f"오류: {e}", file=sys.stderr)
        return 2
    except CorruptDatabase as e:
        # run은 스스로 안내하지만 history 등 다른 명령은 깨진·없어진 state.db에 Traceback을 냈다 (고장 주입 2026-10-26 F7)
        print(f"오류: {e}", file=sys.stderr)
        return 5
    except sqlite3.DatabaseError as e:
        # 잠금·동시 마이그레이션·디스크 가득은 손상이 아니다 — '손상'이라 하면 멀쩡한 DB에 백업을
        # 덮어쓰게 된다 (검토34 C M6: 옛 DB 동시 열기 30회 중 15회가 duplicate column)
        # 낱말 목록은 state 한 곳에 — 두 벌이면 한쪽만 고쳐져 'table is locked'가 '손상'이 됐다 (검토36 E 낮음 2)
        from watcher.state import is_transient_db_error
        if "unable to open" in str(e).lower():
            # 폴더에 쓸 수 없는 것(Program Files·읽기 전용 공유)은 '잠시 뒤 다시'로 풀리지 않는다 (검토39 P7 중간 1)
            try:
                _cfg_db = Path(getattr(args, "state_db", None) or load_config(Path(args.config))["state_db"])
                _dir = _cfg_db.resolve().parent
                # 한 번만 만들어 본다 — tempfile은 ACL로 막힌 폴더(System32·Program Files)에서 PermissionError를 '이름 겹침'으로
                # 보고 다른 이름으로 20억 번 다시 시도해 검사가 영원히 끝나지 않았다 (검토64 D4). O_TEMPORARY: 닫으면 저절로 사라진다
                _fd = os.open(str(_dir / f".drev_write_probe_{os.getpid()}"),
                              os.O_CREAT | os.O_EXCL | os.O_RDWR | getattr(os, "O_TEMPORARY", 0))
                os.close(_fd)
                _writable = True
            except (OSError, SystemExit, KeyError, AttributeError):
                _writable = False
            if not _writable:
                print(f"오류: 이력 파일(state.db)을 둘 폴더에 쓸 수 없습니다 — {e}. Program Files처럼 보호된 폴더나 "
                      f"읽기 전용 공유에 풀었다면 Drev 폴더를 사용자 폴더(예: 문서·바탕화면)로 옮긴 뒤 다시 실행하세요.",
                      file=sys.stderr)
                return 5
        if "readonly" in str(e).lower() or "read-only" in str(e).lower():
            # 읽기 전용 속성·폴더 권한을 '손상'이라 하고 백업 복원을 권해, 멀쩡한 이력을 1주 전 사본으로 덮게 했다 (검토49 A 중간 1)
            print(f"오류: 이력 파일(state.db)에 쓸 수 없습니다 — {e}. 손상이 아닙니다: state.db의 읽기 전용 속성이나 "
                  f"Drev 폴더 권한을 푸세요(파일 속성 › '읽기 전용' 해제, 또는 전산 담당에게 쓰기 권한 요청). "
                  f"백업으로 되돌리지 마세요.", file=sys.stderr)
            return 4
        if is_transient_db_error(e):
            print(f"오류: 이력 파일(state.db)을 지금 쓸 수 없습니다 — {e}. 손상이 아닙니다: 다른 검사·창이 "
                  f"같은 파일을 쓰는 중이거나 디스크 공간이 부족합니다. 잠시 뒤 다시 실행하세요.",
                  file=sys.stderr)
            return 4
        # 머리 페이지는 멀쩡하고 안쪽이 깨진 이력 파일은 열린 뒤 첫 질의에서 터진다 (검토21 운영 2)
        print(f"오류: 이력 파일(state.db)이 손상되었습니다 — {e}. 되살리는 순서는 도움말의 "
              f"'백업 · 다른 PC로 이전 · 되살리기'에 있습니다 (state.db-wal을 먼저 지워야 합니다).",
              file=sys.stderr)
        return 5
    if args.command == "run" and rc == 0 and not getattr(args, "dry_run", False):
        # 명령줄(예약 작업)로 돈 검사만 — 창의 [지금 검사]는 cmd_run을 직접 부르므로 여기를 지나지 않는다
        msg = auto_update_after_run(Path(args.config))
        if msg:
            print(msg)
    return rc


def auto_update_after_run(config_path: Path) -> str:
    """예약 검사(창 없음)가 끝난 뒤 새 판이 있으면 스스로 내려받아 검증하고, 이 프로세스가 끝나면
    교체한다 — 화면을 열어 [설치]를 누르는 사람이 없는 설치본은 영영 옛 판이었다
    (2026-09-11 "자동 업데이트가 안되는중"). config `auto_update: false`로 끈다.
    창이 떠 있으면 미룬다(창에 [설치]가 있고, 창이 쓰는 파일을 밑에서 갈지 않기 위해).
    돌려주는 값은 로그용 한 줄(없으면 빈 문자열). 어떤 실패도 검사 결과(rc)에 얹지 않는다."""
    try:
        cfg = load_config(config_path)
    except BaseException:
        return ""
    if not cfg.get("auto_update", True) or not cfg.get("update_check", True):
        return ""
    try:
        from watcher import selfupdate as _su
        from watcher.web import PORTABLE_URL, UPDATE_URL, check_update
        root = _su.install_root()
        if root is None:
            return ""
        url = cfg.get("update_url") or UPDATE_URL
        if not _su.url_ok(url):
            return ""
        info = check_update(__version__, url)
        if not info:
            return ""
        ver = info.get("version", "")
        if not info.get("verified"):
            # 판매자 서명(고정 공개키)이 확인되지 않은 목록으로는 받지 않는다 (2026-10-19 구매 평가 2차 IT 심사)
            return (f"[update] 새 판 v{ver} 안내의 판매자 서명을 확인하지 못해 자동 업데이트하지 않습니다 — "
                    f"{info.get('sig_error') or '사유 없음'} (이전 판 그대로)")
        why = _su.recent_failure(root, ver)
        if why:
            # 같은 판이 최근에 실패했다 — 매일 55MB를 다시 받아 교체·원복을 반복하지 않는다 (검토20 중간 2)
            return (f"[update] 새 판 v{ver}의 자동 업데이트가 최근 실패해({why[:120]}) "
                    f"{_su.FAILED_RETRY_DAYS}일간 다시 시도하지 않습니다 — 창의 [설치]로는 바로 시도할 수 있습니다")
        wr = _su.window_running(root)
        if wr is not False:
            return (f"[update] 새 판 v{ver}이 있지만 "
                    + ("창이 떠 있어" if wr else "창 실행 여부를 확인할 수 없어")
                    + " 무인 교체는 다음 예약 검사 때 다시 시도합니다 — 창 왼쪽 메뉴의 [설치]를 누르면 바로 됩니다")
        sha = info.get("sha256") or {}
        # 내려받는 수 분 동안도 '교체 중' 표식을 둔다 — 이때 켜진 창의 정리가 .update를 지워
        # 내려받기가 깨지고 거짓 실패 기록이 남았다 (검토20 재검증 ③). 교체 프로세스가 이어받는다
        try:
            (root / _su.APPLYING_MARK).write_text(str(os.getpid()), encoding="utf-8")
        except OSError:
            pass
        _su.run_update(root, info.get("portable") or PORTABLE_URL, ver, exit_after=False,
                       app_url=info.get("app", ""), remote_runtime=info.get("runtime", ""),
                       app_sha=sha.get("app", ""), portable_sha=sha.get("portable", ""),
                       relaunch=False,
                       # 교체 직전에 다른 검사가 돌고 있는지 볼 이력 DB — 업데이트 모듈은 스스로 설정을
                       # 읽지 않으므로 여기서 넘긴다
                       lock_db=str(Path(cfg["state_db"]).resolve()),
                       # 둘째 서명의 크기 = 내려받기 상한 (검토20 r16-1) — 없으면 selfupdate의 기본 상한
                       **({"sizes": dict(info["sizes"])} if info.get("sizes") else {}))
        if _su.PROGRESS.get("error"):
            _su._rm(root / _su.APPLYING_MARK)      # 교체 프로세스가 뜨지 않았다 — 표식은 내 것
            # 내려받기·지문 실패도 기록한다 — 교체 단계 실패만 남겨, 같은 판을 예약 검사마다 다시 받았다(하루 55MB) (검토67 A3)
            try:
                (root / _su.FAILED_MARK).write_text(
                    f"{ver}|{time.time():.0f}|{str(_su.PROGRESS['error'])[:200]}", encoding="utf-8")
            except OSError:
                pass
            return f"[update] 무인 교체 실패 — {_su.PROGRESS['error']} (이전 판 그대로)"
        return (f"[update] 새 판 v{ver} 내려받아 검증함 — 이 검사가 끝나는 대로 교체합니다 "
                f"(창은 열지 않음, 이력·설정 그대로)")
    except Exception as e:
        return f"[update] 무인 교체를 시도하지 못했습니다(무시): {type(e).__name__}: {e}"


if __name__ == "__main__":
    sys.exit(main())
