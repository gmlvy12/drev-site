# -*- coding: utf-8 -*-
"""구/신 Document 비교 → ChangeItem 목록. 모든 항목에 근거(old/new/where) 필수."""

from __future__ import annotations

import difflib
import re
from collections import Counter
from dataclasses import dataclass

from watcher.extract.base import Document, TextLine, date_qualified, find_tags

# TAG 없는 표의 행번호 키 (xlsx.py가 부여; 다중 시트에서는 '시트명!행N')
_POS_KEY = re.compile(r"^(?:[^!]*!)?행\d+")
# 순번 성격의 열: 행이 삽입되면 이후 전부 밀려 '변경'처럼 보이므로 비교에서 제외
_ORDINAL_COL = re.compile(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", re.IGNORECASE)

# kind 종류:
#   FIELD_CHANGED             표제란 값 변경 (REV, DATE 등)
#   ROW_ADDED/REMOVED/CHANGED 표(BOM 등) 행 변경
#   REVROW_ADDED/REMOVED      리비전 블록 행 변경
#   TEXT_CHANGED/ADDED/REMOVED 본문 줄 변경
CONTENT_KINDS = {"ROW_ADDED", "ROW_REMOVED", "ROW_CHANGED",
                 "TEXT_ADDED", "TEXT_REMOVED", "TEXT_CHANGED",
                 "PAGE_ADDED", "PAGE_REMOVED", "PAGE_VISUAL_CHANGED",
                 "COL_RENAMED", "COL_ADDED", "COL_REMOVED", "COL_MOVED", "ROW_MOVED", "TEXT_MOVED", "PAGE_MOVED",
                 "SHEET_ADDED", "SHEET_REMOVED", "SHEET_RENAMED"}
# 순서만 바뀐 것(행 정렬·열 순서·쪽 순서) — 값·글자는 같다. Rev 미갱신의 근거도, 확인 대상도 아니다. 쪽 순서만 바꾼
# PDF가 '검토 필요 1건(Rev 미갱신)', 정렬만 한 BOM이 메일 초안을 냈다 (경우100 B04·C06). 글줄 이동(TEXT_MOVED)은
# 도면에서 자리를 옮긴 것이라 내용으로 둔다
ORDER_KINDS = {"ROW_MOVED", "COL_MOVED", "PAGE_MOVED"}


@dataclass(frozen=True)
class ChangeItem:
    kind: str
    key: str
    old: str | None
    new: str | None
    where: str
    label: str | None = None  # 사람용 식별 — 행 변경이면 품명·규격 (2026-08-25 요청)


# 행의 '무슨 부품/품목인지'를 보여줄 열 (우선순위 순). BOM·발주서·자재표 공통 관례
# 라벨 열 묶음 — 묶음마다 값 하나씩, 순서대로 (품번 → 품명 → 규격 → 업체). 구매가 발주를
# 정정하려면 품번·업체가 있어야 하는데 품명·규격 둘만 뽑아 BOM을 다시 열게 했다 (검토22 실용 B1)
_LABEL_GROUPS = (
    ("품번", "자재코드", "자재번호", "부품번호", "부품코드", "품목코드", "코드", "P/N", "PN", "PART NO",
     "PART NUMBER", "PARTNO", "ITEM CODE", "CODE"),
    ("품명", "부품명", "자재명", "명칭", "품목", "DESCRIPTION", "NAME", "PART", "ITEM"),
    ("규격", "SPEC", "MODEL", "형식", "TYPE"),
    ("업체", "제조사", "제조원", "메이커", "구매처", "MAKER", "VENDOR", "MANUFACTURER", "BRAND"),
)
_LABEL_COLS = tuple(w for g in _LABEL_GROUPS for w in g)   # 호환용(다른 곳에서 참조)
_LABEL_SPLIT = re.compile(r"[^A-Z0-9가-힣/]+")


def _col_matches(cu: str, want: str) -> bool:
    """머리글 cu가 라벨 낱말 want를 뜻하는가 — 낱말 단위로. 'PART NO.'→PART NO, 'P/N'→P/N,
    'PART NAME'은 PART(품명)이되 PART NO(품번)는 아니고, 'BARCODE'는 CODE가 아니다
    (재검증 B1: 부분 문자열 일치가 바코드를 품번 자리에 넣었다). 한글은 '업체명'·'제조사명'·
    '규격(SPEC)'처럼 낱말로 시작하면 같은 뜻으로 본다."""
    if cu == want:
        return True
    toks = [t for t in _LABEL_SPLIT.split(cu) if t]
    norm = " ".join(toks)
    if norm == want or norm.startswith(want + " ") or norm.endswith(" " + want):
        return True
    return not want.isascii() and cu.startswith(want)


def _row_label(values: dict) -> str | None:
    """행에서 사람이 알아볼 식별값(품번·품명·규격·업체, 묶음마다 하나·최대 4개)을 뽑는다."""
    out: list[str] = []
    for group in _LABEL_GROUPS:
        found = None
        for want in group:
            for col, val in values.items():
                cu = col.upper().strip()
                if _ORDINAL_COL.match(cu):
                    continue  # 'ITEM NO' 같은 순번 열이 ITEM에 걸려 번호가 품명 되는 것 방지
                if _col_matches(cu, want) and val and str(val) not in out:
                    found = str(val)
                    break
            if found:
                break
        if found:
            out.append(found)
    return " · ".join(out) if out else None


_OCR_WHERE = re.compile(r"\d+페이지 OCR \d+행")


def _is_ocr(where) -> bool:
    """OCR로 읽은 글줄·필드의 위치 표기('N페이지 OCR M행')인가 — 시트 이름에 OCR이 든 진짜 글자와 헷갈리지 않게."""
    return bool(_OCR_WHERE.search(str(where or "")))


def same_ocr_value(o, n) -> bool:
    """두 필드(또는 where 있는 글줄)가 모두 OCR 유래이고 혼동 문자를 지우면 같은가 — 재스캔에서 'REV B'가 '8'로
    읽힌 것을 Rev 변경으로 보지 않는다 (리뷰12 중간-C). 어느 한쪽이 진짜 글자면 정규화하지 않는다."""
    if o is None or n is None or not (_is_ocr(getattr(o, "where", "")) and _is_ocr(getattr(n, "where", ""))):
        return False
    from watcher.ocr import normalize
    a = normalize(getattr(o, "value", getattr(o, "text", "")))
    b = normalize(getattr(n, "value", getattr(n, "text", "")))
    return bool(a) and a == b


def field_base(key) -> str:
    """'REV#2'(한 파일의 둘째 표제란, 검토36 A N2) → 'REV'. 번호 없는 이름은 그대로."""
    return str(key or "").split("#", 1)[0]


NEW_TB, GONE_TB = "새 표제란", "없어진 표제란"


def _blank_rev(v) -> bool:
    return str(v or "").strip() in ("", "-", "—", "–")


def is_rev_field(item) -> bool:
    """표제란 Rev가 올라간(또는 처음 적힌) 것인가 — 첫 표제란(REV)이든 둘째 표제란(REV#2)이든.
    - 새 값이 비면 Rev 변경이 아니다(칸 삭제·시트 삭제).
    - 첫 표제란의 빈칸·'-' → A는 **첫 발행**이다 — 둘 다 값이 있어야 한다고 좁혔더니 발행하며 Rev를 처음 채운
      날마다 거짓 'Rev 미갱신'이 났다 (검토37 A 차단 1, DXF·PDF·XLSX 모두).
    - 짝 없는 **새 표제란**(시트·틀 신설, 표식 NEW_TB)의 Rev는 올림이 아니다 (검토36 F 중간 3) — 표지 시트를
      앞에 넣어 그것이 첫 표제란이 돼도 마찬가지 (검토37 A)."""
    if getattr(item, "kind", "") != "FIELD_CHANGED" or field_base(getattr(item, "key", "")) != "REV":
        return False
    old, new = getattr(item, "old", None), getattr(item, "new", None)
    if _blank_rev(new):
        return False
    if getattr(item, "label", None) == NEW_TB:
        return False
    return True


def field_label(key) -> str:
    """화면·메일에 보이는 필드 이름 — 'REV#2' → 'REV (다른 표제란)'. 번호는 내부 열쇠일 뿐이다 (검토36 F 낮음 5)."""
    k = str(key or "")
    if k == "SCALE":
        return "축척"                      # 'SCALE 1:50 → 1:25'가 내부 이름으로 보였다 (검토43 C 중간 6)
    if k.startswith("SCALE#"):
        return "축척 (다른 표제란)"
    return f"{field_base(k)} (다른 표제란)" if "#" in k and not k.startswith("META:") else k


_TB_BASES = {"REV", "DATE", "DWG_NO", "PROJECT", "TITLE"}


def _title_groups(fields: dict) -> dict:
    """번호별 표제란 묶음 {'': {REV: Field…}, '2': {…}} — 표제란 칸만."""
    out: dict = {}
    for k, f in fields.items():
        base, _sep, n = str(k).partition("#")
        if base in _TB_BASES and not str(k).startswith("META:"):
            out.setdefault(n, {})[base] = f
    return out


def _pair_title_groups(og: dict, ng: dict) -> list:
    """두 판의 표제란 묶음을 짝짓는다 — 번호(순서)가 아니라 **도면번호**, 없으면 **배치 이름**, 그래도 없으면
    순서로. 번호로 짝지으면 표지 시트를 앞에 넣거나 시트 이름만 바꿔도 번호가 밀려 'Rev B→A, 글자 변경 없음'
    검토 필요가 떴다 (검토36 F 중간 1). 돌려주는 값: [(옛 번호|None, 새 번호|None)]"""
    import re as _re

    def _no(g):
        f = g.get("DWG_NO")
        return str(f.value).strip() if f is not None and str(f.value or "").strip() else None

    def _sp(g):
        for f in g.values():
            w = str(getattr(f, "where", "") or "")
            m = _re.search(r"배치 (.+?) (?:다른 )?표제란", w) or _re.match(r"(.+?)!제목 \d+행", w)   # XLSX 시트 (검토41 S4)
            if m:
                return m.group(1)
        return None

    def _order(n):
        return (0, 0) if n == "" else (1, int(n) if n.isdigit() else 0)

    def _ti(g):
        f = g.get("TITLE")
        return str(f.value).strip() if f is not None and str(f.value or "").strip() else None

    left_o, left_n = sorted(og, key=_order), sorted(ng, key=_order)
    pairs = []
    # 도면번호 → 도면명 → 배치 이름 순 — 도면번호 속성이 없는 두 틀의 순서가 바뀌면 거짓 'REV#2 B→A' (검토38 R5 중간 4)
    for keyf in (_no, _ti, _sp):
        for o in list(left_o):
            ko = keyf(og[o])
            if ko is None:
                continue
            cand = [n for n in left_n if keyf(ng[n]) == ko]
            if len(cand) == 1 and sum(1 for x in left_o if keyf(og[x]) == ko) == 1:
                pairs.append((o, cand[0]))
                # 짝지은 것은 남은 목록에서 뺀다 — 새 목록으로(읽기 전용 가드가 삭제류 API를 막는다)
                left_o = [x for x in left_o if x != o]
                left_n = [x for x in left_n if x != cand[0]]
    # 남은 것은 순서대로 짝 — 양쪽에 다 남았으면 그 틀의 도면번호가 바뀐 것이다(E-102→E-103 한 줄).
    # 한쪽에만 남은 것은 새로 생긴·없어진 틀
    # 단, 둘 다 배치 표제란이고 배치 이름이 다르면 시트 교체다 — 옛 시트 삭제 + 새 시트 추가를 한 틀로 짝지어
    # 'Rev B→A로 올라갔는데' 거짓 검토 필요가 떴다 (검토37 A 중간 5)
    def _rv(g):
        f = g.get("REV")
        return str(f.value).strip() if f is not None and str(f.value or "").strip() else None

    def _forward(ra, rb) -> bool:
        """Rev가 앞으로 갔나 — 같은 모양에서 올라갔거나, 예비 번호(P1)가 발행(A·0)이 됐다."""
        from watcher.scan import rev_key, rev_shape
        sa, sb = rev_shape(ra), rev_shape(rb)
        if sa and sa == sb:
            return rev_key(rb) > rev_key(ra)
        return bool(sa and sa[0] == "P" and sb and sb[0] in ("L", "D"))

    def _swap(a, b) -> bool:
        """도면번호도 Rev도 다른 두 틀은 교체다 — 모델 공간 틀 교체가 순서 짝으로 거짓 'Rev B→A' (검토38 R1 중간 5).
        단 Rev가 **앞으로** 갔으면 같은 틀의 발행이다 — 예비번호 E-102-P/P1을 E-102/A로 발행한 날 짝을 끊어 거짓
        'Rev 미갱신'이 났다 (검토41 S4 중간 2)"""
        return bool(_no(a) and _no(b) and _no(a) != _no(b) and _rv(a) and _rv(b) and _rv(a) != _rv(b)
                    and not _forward(_rv(a), _rv(b)))

    rest_o, rest_n = list(left_o), list(left_n)
    for o in list(rest_o):
        n = next((n for n in rest_n
                  if not (_sp(og[o]) and _sp(ng[n]) and _sp(og[o]) != _sp(ng[n])) and not _swap(og[o], ng[n])), None)
        if n is not None:
            pairs.append((o, n))
            rest_o = [x for x in rest_o if x != o]
            rest_n = [x for x in rest_n if x != n]
    pairs += [(o, None) for o in rest_o] + [(None, n) for n in rest_n]
    return pairs


def _diff_fields(old: Document, new: Document) -> list[ChangeItem]:
    og, ng = _title_groups(old.fields), _title_groups(new.fields)
    if len(og) > 1 or len(ng) > 1:
        # 표제란이 여럿이면 묶음끼리 짝지어 견준다 — 열쇠는 새 판의 번호(없어진 묶음은 옛 번호)
        items = []
        for o, n in _pair_title_groups(og, ng):
            go, gn = og.get(o, {}) if o is not None else {}, ng.get(n, {}) if n is not None else {}
            sfx = n if n is not None else o
            for base in sorted(go.keys() | gn.keys()):
                fo, fn = go.get(base), gn.get(base)
                ov = fo.value if fo else None
                nv = fn.value if fn else None
                if ov != nv and not same_ocr_value(fo, fn):
                    # 짝 없는 표제란은 시트(틀) 신설·삭제다 — 표식을 달아 Rev 올림·첫 Rev 기재와 가른다 (검토37 A)
                    items.append(ChangeItem("FIELD_CHANGED", base + (f"#{sfx}" if sfx else ""), ov, nv,
                                            (fn or fo).where,
                                            NEW_TB if o is None else GONE_TB if n is None else None))
        items.sort(key=lambda i: i.key)          # 첫 표제란(REV)이 번호 붙은 것보다 앞
        rest_o = {k: v for k, v in old.fields.items() if str(k).partition("#")[0] not in _TB_BASES}
        rest_n = {k: v for k, v in new.fields.items() if str(k).partition("#")[0] not in _TB_BASES}
    else:
        items, rest_o, rest_n = [], old.fields, new.fields
    for name in sorted(rest_o.keys() | rest_n.keys()):
        if name.startswith("META:"):
            # 작성·검토·승인 서명은 그림 비교에서 그 자리를 빼려고만 둔다. **축척**은 도면의 성질이라 바뀌면 알린다 —
            # 1:50→1:100이 '변경 없음'이었다 (검토42 B T04). 내용 변경(CONTENT_KINDS)이 아니라 Rev 판단엔 쓰지 않는다
            if name.split(":", 1)[1].split("#", 1)[0].upper() not in ("SCALE", "축척"):
                continue
            # 둘째 표제란의 축척도 — 첫 축척이 아니라고 버려 배치2의 1:20→1:10이 아무 말 없었다 (검토64 C-F5). 첫 것은 'SCALE',
            # 그 뒤 것은 'SCALE#2'(화면에는 '축척 (다른 표제란)')
            _first = not any(k_ != name and k_.split(":", 1)[-1].split("#", 1)[0].upper() in ("SCALE", "축척")
                             and k_ < name for k_ in (rest_o.keys() | rest_n.keys()) if k_.startswith("META:"))
            o, n = old.fields.get(name), new.fields.get(name)
            ov, nv = (o.value if o else None), (n.value if n else None)
            if ov and nv and ov != nv:
                _sk = "SCALE" if _first else "SCALE#" + (name.split("#", 1)[1] if "#" in name else "2")
                items.append(ChangeItem("FIELD_CHANGED", _sk, ov, nv, (n or o).where))
            continue
        o, n = old.fields.get(name), new.fields.get(name)
        ov = o.value if o else None
        nv = n.value if n else None
        if ov != nv and not same_ocr_value(o, n):
            where = (n or o).where
            items.append(ChangeItem("FIELD_CHANGED", name, ov, nv, where))
    return items


def _keyed(rows) -> dict:
    """행을 key로 사전화하되, 중복 key는 #2, #3 순번을 붙여 유실을 막는다.
    (같은 TAG가 여러 행인 BOM에서 마지막 행만 남아 변경이 사라지는 것 방지)"""
    out, counts = {}, Counter()
    for r in rows:
        counts[r.key] += 1
        k = r.key if counts[r.key] == 1 else f"{r.key}#{counts[r.key]}"
        out[k] = r
    return out


_PLAIN_NUM = re.compile(r"^-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?$")


def _num(v):
    """'1,200' '1200.0' ' 1200 ' → 1200.0 / 숫자가 아니면 None.
    '010'(코드)·'1e3'(지수)·'1,2'(천 단위가 아닌 쉼표)는 숫자로 보지 않는다 (리뷰10 중간-3)."""
    s = str(v if v is not None else "").strip()
    if not s or not _PLAIN_NUM.match(s):
        return None
    digits = s.lstrip("-")
    if len(digits) > 1 and digits[0] == "0" and digits[1].isdigit():
        return None                               # 앞자리 0은 코드
    try:
        return float("".join(s.split(",")))
    except ValueError:
        return None


def _refs_of(s: str):
    """수식의 셀 참조를 (열 번호, 행 번호) 목록으로."""
    out = []
    for ref in _CELL_REF.findall(s):
        m = re.match(r"\$?([A-Z]{1,3})\$?(\d+)", ref)
        col = 0
        for ch in m.group(1):
            col = col * 26 + (ord(ch) - 64)
        out.append((col, int(m.group(2))))
    return out


def _same_formula(sa: str, sb: str) -> bool:
    """열·행을 끼워 넣어 참조가 밀린 수식만 같다고 본다 (리뷰10 중간-3).
    =B2*C2→=B2*B2(다른 열을 곱함), =SUM(D2:D4)→=SUM(D2:D3)(범위 축소)는 다르다.
    같다: 모든 참조가 같은 만큼 밀림(=B2*C2→=C2*D2) / 범위의 끝만 한 칸 늘어남(=SUM(B2:G2)→=SUM(B2:H2))."""
    if _CELL_REF.sub("?", sa) != _CELL_REF.sub("?", sb):
        return False
    ra, rb = _refs_of(sa), _refs_of(sb)
    if len(ra) != len(rb):
        return False
    if not ra:
        return True
    deltas = {(b[0] - a[0], b[1] - a[1]) for a, b in zip(ra, rb)}
    if len(deltas) == 1:
        return True
    # 범위(A:B 짝)의 끝만 +1 — 범위 안에 열·행이 끼어든 것. 시작은 그대로여야 한다
    ranges = re.findall(r"(\$?[A-Z]{1,3}\$?\d+):(\$?[A-Z]{1,3}\$?\d+)", sb)
    if not ranges:
        return False
    for a, b in zip(ra, rb):
        d = (b[0] - a[0], b[1] - a[1])
        if d != (0, 0) and d not in ((1, 0), (0, 1)):
            return False
    ends_b = {(_refs_of(e)[0]) for _, e in ranges}
    return all((b[0] - a[0], b[1] - a[1]) == (0, 0) or b in ends_b for a, b in zip(ra, rb))


_CELL_REF = re.compile(r"\$?[A-Z]{1,3}\$?\d+")
_THOUSANDS = re.compile(r"(?<![A-Za-z]\d)(?<=\d),(?=\d{3}(?!\d))")   # 'M8,100mm'의 쉼표는 천 단위가 아니다


def same_value(a, b) -> bool:
    """표기만 다른 같은 값인가 — 10 vs 10.0, 1200 vs 1,200 (2026-09-06 양식 시험).
    수식은 셀 참조만 밀린 것(열 추가로 =SUM(B2:G2)→=SUM(B2:H2))을 같은 것으로 본다."""
    if a == b:
        return True
    sa, sb = str(a or ""), str(b or "")
    if sa.startswith("=") and sb.startswith("=") and _same_formula(sa, sb):
        return True                            # 참조가 같은 모양으로 밀린 수식(=SUM(B2:G2)→=SUM(B2:H2)) — 단, 범위 끝만 바뀐 건 다르다
    if _THOUSANDS.sub("", sa) == _THOUSANDS.sub("", sb) and sa != sb and any(ch.isdigit() for ch in sa):
        return True                            # '245,000원' vs '245000원' — 천 단위 쉼표만
    x, y = _num(a), _num(b)
    return x is not None and y is not None and abs(x - y) < 1e-9


_SEQ_COLS: set = set()   # 비교 중인 두 표에서 '내용상 순번'으로 판정된 열 (choose 단계에서 채움)
_HEADERS: tuple = (None, None)   # 비교 중인 두 판의 표 머리글 {표 이름: [열]} — 모르면 None (검토68 C3)


def sequential_cols(old_rows, new_rows) -> set:
    """이름은 순번이 아니어도(ITEM, SEQ, #) 값이 1,2,3…으로 이어지는 열 — 삽입 한 줄에 전부 밀려
    변경으로 도배되던 것 (2026-09-06 양식 시험: 영문 BOM의 ITEM 열)."""
    out = set()
    cols = set()
    for r in old_rows[:400] + new_rows[:400]:
        cols.update(r.values.keys())
    for c in cols:
        for rows in (old_rows, new_rows):
            vals = [_num(r.values.get(c)) for r in rows]
            got = [v for v in vals if v is not None]
            if len(got) < max(3, len(rows) * 0.9) or any(v != int(v) for v in got):
                break
            seq = [int(v) for v in got]
            if sum(1 for a, b in zip(seq, seq[1:]) if b == a + 1) < (len(seq) - 1) * 0.9:
                break
            if any(b < a for a, b in zip(seq, seq[1:])):
                break                        # 한 번이라도 되돌아가면(카드마다 0..15) 순번이 아니다 (리뷰10)
        else:
            out.add(c)
    return out


def _rows_changed_items(o, n, prefix: str, skip_ordinal: bool = False) -> list[ChangeItem]:
    out = []
    label = _row_label(n.values) or _row_label(o.values)
    for col in sorted(o.values.keys() | n.values.keys()):
        if skip_ordinal and _ORDINAL_COL.match(col):
            continue  # 순번 밀림은 내용 변경이 아니다
        if col in _SEQ_COLS:
            continue
        ov, nv = o.values.get(col), n.values.get(col)
        if not same_value(ov, nv):
            out.append(ChangeItem(f"{prefix}_CHANGED", f"{n.key}.{col}", ov, nv,
                                  n.where, label=label))
    return out


def _row_sig(r) -> tuple:
    """위치 정렬용 행 서명 — 순번 열은 제외 (삽입 시 전체가 밀려 무의미)."""
    # 값으로 순번이라 판정된 열(ITEM·SEQ 등)도 뺀다 — 이름만 보던 탓에 ITEM 열 표에 한 행을 끼우면 아래 행이 전부 '값 변경'이
    # 됐다 (검토64 C-F1; 값 비교 쪽은 이미 건너뛰고 있었다)
    return tuple(sorted((k, v) for k, v in r.values.items()
                        if not _ORDINAL_COL.match(k) and k not in _SEQ_COLS))


def _diff_rows_positional(old_rows, new_rows, prefix: str) -> list[ChangeItem]:
    """TAG 없는 표(행번호 키): 위치 정렬로 비교 — 행 하나가 삽입돼도
    이후 행 전체가 밀려 오탐 연쇄(수천 건)가 나지 않는다 (2026-08-23 실사용 발견)."""
    items: list[ChangeItem] = []
    ot = {r.key: r for r in old_rows if _is_total(r)}
    nt = {r.key: r for r in new_rows if _is_total(r)}
    if ot or nt:                               # 합계·소계 행은 라벨로 짝지어 값만 비교
        for k in sorted(ot.keys() & nt.keys()):
            items += _rows_changed_items(ot[k], nt[k], prefix, skip_ordinal=True)
        old_rows = [r for r in old_rows if not _is_total(r)]
        new_rows = [r for r in new_rows if not _is_total(r)]
    ov = [_row_sig(r) for r in old_rows]
    nv = [_row_sig(r) for r in new_rows]
    sm = difflib.SequenceMatcher(a=ov, b=nv, autojunk=False)
    ops = [op for op in sm.get_opcodes() if op[0] != "equal"]
    # 어긋난 자리의 삭제·추가 가운데 내용(서명)이 같은 짝은 자리만 옮긴 행이다 — 품명+규격으로만 갈리는 표를 정렬만 해도
    # 거짓 추가 279·삭제 279가 났다 (검토68 C2). 짝은 지우고 '행 순서만 바뀜'으로 센다
    pool: dict = {}
    for _t, i1, i2, _j1, _j2 in ops:
        for i in range(i1, i2):
            pool.setdefault(ov[i], []).append(i)
    moved_o: set = set()
    moved: list = []
    for _t, _i1, _i2, j1, j2 in ops:
        for j in range(j1, j2):
            if pool.get(nv[j]):
                i = pool[nv[j]].pop(0)
                moved_o.add(i)
                moved.append((i, j))
    moved_n = {j for _i, j in moved}
    for _t, i1, i2, j1, j2 in ops:
        oi = [i for i in range(i1, i2) if i not in moved_o]
        nj = [j for j in range(j1, j2) if j not in moved_n]
        if not oi and not nj:
            continue
        if not oi:
            for j in nj:
                r = new_rows[j]
                items.append(ChangeItem(f"{prefix}_ADDED", r.key, None,
                                        str(r.values), r.where,
                                        label=_row_label(r.values)))
        elif not nj:
            for i in oi:
                r = old_rows[i]
                items.append(ChangeItem(f"{prefix}_REMOVED", r.key,
                                        str(r.values), None, r.where,
                                        label=_row_label(r.values)))
        else:  # replace: 겹치는 만큼은 값 변경, 남는 쪽은 추가/삭제
            for k in range(max(len(oi), len(nj))):
                o = old_rows[oi[k]] if k < len(oi) else None
                n = new_rows[nj[k]] if k < len(nj) else None
                if o is not None and n is not None:
                    items += _rows_changed_items(o, n, prefix, skip_ordinal=True)
                elif n is not None:
                    items.append(ChangeItem(f"{prefix}_ADDED", n.key, None,
                                            str(n.values), n.where,
                                            label=_row_label(n.values)))
                else:
                    items.append(ChangeItem(f"{prefix}_REMOVED", o.key,
                                            str(o.values), None, o.where,
                                            label=_row_label(o.values)))
    # 자리만 옮긴 행 — 키 있는 표와 같은 꼴: 몇 행이면 각각 '이동', 많으면 '행 순서만 바뀜' 참고 한 건 (검토68 C2)
    if moved and len(moved) <= 3:
        for i, j in moved:
            o, n = old_rows[i], new_rows[j]
            items.append(ChangeItem(f"{prefix}_MOVED", n.key, o.where, n.where, n.where, label=_row_label(n.values)))
    elif moved:
        items.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                                f"행 순서만 바뀜 — {len(moved)}행 자리 바뀜, 내용 변경 없음",
                                new_rows[0].where.split("!", 1)[0] if "!" in new_rows[0].where else "표"))
    return items


# 행 앞의 순번("조건 4: 과부하", "1. 개요") — 한 행을 지우면 뒤 행 전부의 번호가
# 바뀌어 삭제 1건이 추가 4/삭제 5로 보였다 (2026-09-03 검토: 인터락 시트)
# 접두 낱말은 순번을 뜻하는 것만(조건·항목·NO·순번·번호) — "Rev 3:", "10 - 12"는 값이다
# (2026-09-03 재검토). 숫자는 3자리까지(연도 "2026." 보호), 구분자 뒤엔 공백 필수
_LEAD_NO = re.compile(r"^\s*(?:(?:조건|항목|순번|번호|NO\.?|No\.?)\s*)?\d{1,3}\s*(?:[:.]\s+|\)\s*)")
_ORDINAL_COL = re.compile(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", re.IGNORECASE)


def strip_leading_no(text) -> str:
    return _LEAD_NO.sub("", str(text or ""), count=1).strip()


# 행의 이름표가 될 수 없는 열 — 값이 바뀌는 칸 (규격을 고치면 행이 신규+삭제로 갈린다)
_NOT_KEY_COLS = {"규격", "사양", "SPEC", "SPECIFICATION", "단가", "금액", "수량", "QTY", "Q'TY",
                 "PRICE", "AMOUNT", "UNIT PRICE", "비고", "REMARK", "REMARKS", "NOTE", "NOTES",
                 "날짜", "DATE", "단위", "UNIT"}


_NUM_RE = re.compile(r"^\s*-?[\d,]+(\.\d+)?\s*$")
_DATE_RE = re.compile(r"^\s*(\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{2}[-./]\d{1,2}[-./]\d{1,2}|\d{1,2}/\d{1,2})\s*$")
_TOTAL_KEY = re.compile(r"^(?:.+ )?(소\s*계|합\s*계|총\s*계|계|SUB\s*TOTAL|TOTAL|G\.?\s*TOTAL)(#\d+)?$", re.IGNORECASE)


def _is_total(r) -> bool:
    return bool(_TOTAL_KEY.match(r.key))


def _pair_count(old_rows, new_rows, col=None) -> int:
    """이 열(없으면 현재 키)로 맞췄을 때 두 판에서 짝지어지는 행 수."""
    def vals(rows):
        if col is None:
            return {r.key for r in rows if not _POS_KEY.match(r.key)}
        return {strip_leading_no(r.values.get(col)) for r in rows if r.values.get(col)}
    return len(vals(old_rows) & vals(new_rows))


def choose_key_col(old_rows, new_rows) -> str | None:
    """두 판을 같이 놓고 '어느 열로 맞추면 행이 가장 많이 짝지어지는가'를 센다.

    파일 하나만 보고 고른 키(품명·설명류)는 그 칸을 고치는 순간 행이 신규+삭제로 갈렸고,
    양식이 수십 종이라 열 이름을 설정에 적어 두라고 할 수도 없다 (2026-09-06 사용자:
    "문서가 한두 개도 아니고 다 넣어주려면 안 할 것"). 조건: 양쪽 거의 모든 행에 있고,
    양쪽에서 거의 고유하며, 값 열(규격·수량·비고)이 아닌 열 가운데 짝이 가장 많은 것.
    지금 키보다 확실히 나을 때만 바꾼다."""
    if not old_rows or not new_rows:
        return None
    from watcher.extract.xlsx import code_ratio
    old_rows = [r for r in old_rows if not _is_total(r)] or old_rows
    new_rows = [r for r in new_rows if not _is_total(r)] or new_rows
    cols: list = []
    for r in old_rows[:400] + new_rows[:400]:
        for c in r.values:
            if c not in cols:
                cols.append(c)                  # 머리글 순서 — 동점이면 왼쪽 열
    n_min = min(len(old_rows), len(new_rows))
    current = _pair_count(old_rows, new_rows)
    # TAG 빈 행의 내용 키('CABLE · 4SQ')는 태그꼴 비율에서 뺀다 — 세면 비율이 0.9 아래로 떨어져 '태그 키 유지' 금지가 꺼지고
    # 태그 개명(X-11→X-12)이 다시 'RELAY.TAG 변경'으로 묻혔다 (검토53 J 차단 1)
    cur_keys = [r.key for r in old_rows if not _POS_KEY.match(r.key) and " · " not in str(r.key)]
    cur_code = code_ratio(cur_keys) if cur_keys else 0.0
    best, best_score = None, (current, 1 if cur_code >= 0.9 else 0, 1)
    for c in cols:
        cu = str(c).strip().upper()
        if _ORDINAL_COL.match(str(c).strip()) or cu in _NOT_KEY_COLS or c in _SEQ_COLS:
            continue
        ov = [strip_leading_no(r.values.get(c)) for r in old_rows if r.values.get(c)]
        nv = [strip_leading_no(r.values.get(c)) for r in new_rows if r.values.get(c)]
        if len(ov) < len(old_rows) * 0.9 or len(nv) < len(new_rows) * 0.9:
            continue
        if len(set(ov)) < len(ov) * 0.95 or len(set(nv)) < len(nv) * 0.95:
            continue
        codes = code_ratio(ov)
        if sum(len(str(v)) for v in ov) / max(1, len(ov)) < 2:
            continue                            # X/O 마크 열
        if sum(1 for v in ov if _NUM_RE.match(str(v))) >= len(ov) * 0.8:
            continue                            # 숫자만인 열(생산량·금액)은 값이지 이름표가 아니다
        if sum(1 for v in ov if str(v).startswith("=")) >= len(ov) * 0.5:
            continue                            # 수식 열도 마찬가지
        is_date = sum(1 for v in ov if _DATE_RE.search(str(v))) >= len(ov) * 0.8
        n = len(set(ov) & set(nv))
        if n < max(2, int(n_min * 0.5)):
            continue
        # 짝 수가 같으면 코드 모양(품번) 열이 설명 열보다 낫다 — 설명은 고쳐지는 칸.
        # 날짜 열은 다른 후보가 없을 때만 (공정표의 시작일은 키가 아니지만 일별 기록의 일자는 키)
        score = (n, 1 if codes >= 0.9 else 0, 0 if is_date else 1)
        if is_date:
            score = (n, -1, 0)
        # 지금 키가 품번·태그꼴이고 거의 다 맞으면 설명 열로 갈아타지 않는다 — X-11 삭제 + X-12 추가(둘 다 RELAY)가
        # 짝 하나 차이로 품명 열에 지고 'RELAY QTY 2→1·TAG X-11→X-12'로 읽혀 신규 발주가 묻혔다 (경우100 C04).
        # 태그 체계를 통째로 바꾼 날(지금 키 짝이 절반 미만)에는 여전히 갈아탄다. 금지는 후보가 **겨우** 나을 때만 —
        # TAG가 빈 행(전선·소모품)이 섞인 BOM은 그 행들이 행 번호 키라, 맨 위에 한 행만 끼워도 아래가 전부 밀려
        # 거짓 변경 11건이 났다(검토53 A 차단 1). 그때는 설명 열이 훨씬 많이 맞으니 갈아탄다
        if cur_code >= 0.9 and codes < 0.9 and current >= n_min * 0.5 and n - current <= max(1, n_min // 10):
            continue
        if score > best_score:
            best, best_score = c, score
    return best


def _rekey(rows, col: str):
    from watcher.extract.base import Row
    out = []
    for r in rows:
        if _is_total(r):
            out.append(r)                     # 합계 행의 키는 라벨 그대로
            continue
        v = strip_leading_no(r.values.get(col)) if r.values.get(col) else None
        out.append(Row(key=v or r.key, values=r.values, where=r.where) if v else r)
    return out


def _moved_keys(order_old: list, n_pos: dict) -> list:
    """옛 순서의 키 목록이 새 순서에서 얼마나 어긋나나 — 가장 긴 오름 부분열(LIS) 밖의 키가 '옮겨진' 행."""
    seq = [n_pos[k] for k in order_old]
    if len(seq) < 2:
        return []
    import bisect
    tails: list = []
    prev = [-1] * len(seq)
    idx_at: list = []
    for i, v in enumerate(seq):
        j = bisect.bisect_left(tails, v)
        if j == len(tails):
            tails.append(v); idx_at.append(i)
        else:
            tails[j] = v; idx_at[j] = i
        prev[i] = idx_at[j - 1] if j else -1
    keep = set()
    i = idx_at[-1] if idx_at else -1
    while i >= 0:
        keep.add(i); i = prev[i]
    return [order_old[i] for i in range(len(seq)) if i not in keep]


def _col_values(rows, col) -> Counter:
    return Counter(str(r.values.get(col)) for r in rows if r.values.get(col))


def _col_order(rows) -> list:
    """행들의 열 이름을 머리글 순서대로 합친다. 첫 행에서 빈 칸이던 열을 뒤에 붙이면 열 순서가 틀어져
    값 하나 채워진 날 '열 위치 이동'이 나던 것 (리뷰10 퍼즈 105) — 새 열은 그 행에서 뒤따르는
    아는 열 앞에 끼운다."""
    order: list = []
    for r in rows:
        cols = list(r.values)
        for k, c in enumerate(cols):
            if c in order:
                continue
            nxt = next((x for x in cols[k + 1:] if x in order), None)
            if nxt is None:
                order.append(c)
            else:
                order.insert(order.index(nxt), c)
    return order


def align_columns(old_rows, new_rows):
    """열 이름 변경·열 추가·열 삭제를 먼저 알아본다 → (옛 행들, 새 행들, 열 단위 항목).

    머리글 한 칸을 '일자'→'개정일'로 바꾸면 전 행이 "일자 삭제 + 개정일 추가"로, 열 하나를 더하면
    전 행이 "값 변경"으로 도배됐다 (2026-09-06 블라인드 양식 시험 08·17·24·28·29). 이름이 바뀐 열은
    값 분포가 거의 같은(80% 이상) 옛 열과 짝지어 새 이름으로 맞추고, 대부분 행에 값이 있는 열의
    추가·삭제는 한 건으로 요약한다. 드문드문 채워진 열(비고 한 칸)은 그대로 행 단위로 본다."""
    from watcher.extract.base import Row
    if not old_rows or not new_rows:
        return old_rows, new_rows, []
    o_cols = _col_order(old_rows)
    n_cols = _col_order(new_rows)
    only_o = [c for c in o_cols if c not in n_cols]
    only_n = [c for c in n_cols if c not in o_cols]
    where = old_rows[0].where.split("!", 1)[0] if "!" in old_rows[0].where else ""
    items: list[ChangeItem] = []
    common = [c for c in o_cols if c in n_cols]
    n_idx = {c: i for i, c in enumerate(n_cols)}
    moved = _moved_keys(common, n_idx)
    if moved:
        o_idx = {c: i for i, c in enumerate(o_cols)}
        moved = [c for c in moved if o_idx[c] != n_idx[c]]
    if moved:
        if len(moved) <= 3:
            for c in moved:
                items.append(ChangeItem("COL_MOVED", c, f"{o_idx[c] + 1}번째 열", f"{n_idx[c] + 1}번째 열",
                                        where or "표", label="열 위치 이동 — 값은 그대로"))
        else:
            items.append(ChangeItem("COL_MOVED", "열 순서", f"{len(moved)}열 자리 바뀜", "재배치", where or "표"))
    rename: dict = {}
    used_n: set = set()
    for a in only_o:
        va = _col_values(old_rows, a)
        if sum(va.values()) < 3:
            continue                        # 값이 거의 없는 열은 이름 변경 판정 대상이 아니다
        best, best_s = None, 0.0
        for b in only_n:
            if b in used_n:
                continue
            vb = _col_values(new_rows, b)
            inter = sum((va & vb).values())
            s = inter / max(sum(va.values()), sum(vb.values()))
            if s > best_s:
                best, best_s = b, s
        if best is not None and (best_s >= 0.8 or (best_s >= 0.5 and len(only_o) == 1 and len(only_n) == 1)):
            rename[a] = best
            used_n.add(best)
            items.append(ChangeItem("COL_RENAMED", best, a, best, where or "표",
                                    label=f"열 이름 변경 — 값은 {int(best_s * 100)}% 그대로"))
    n_old, n_new = len(old_rows), len(new_rows)
    # 두 판의 머리글을 알면 드문드문 채운 열도 — 옛 머리글에 있고 새 머리글에서 사라졌으면 열 삭제다. 문턱(절반)만 보던 탓에
    # 비고 열을 지우면 '값 변경 11건'으로 나왔다 (검토68 C3). 머리글이 남아 값만 지운 것은 그대로 행 변경
    _ho, _hn = _HEADERS
    _hdr_o = (_ho or {}).get(where) if where else None
    _hdr_n = (_hn or {}).get(_sheet_of(new_rows[0])) if _hn else None
    drop_o = []
    for c in only_o:
        if c in rename:
            continue
        filled = sum(1 for r in old_rows if r.values.get(c))
        gone = bool(_hdr_o and _hdr_n is not None and c in _hdr_o and c not in _hdr_n)
        if filled >= max(3, n_old * 0.5) or (gone and filled):
            drop_o.append(c)
            sample = [f"{r.key}: {r.values[c]}" for r in old_rows if r.values.get(c)][:5]
            items.append(ChangeItem("COL_REMOVED", c,
                                    f"값 있는 행 {filled}개 — " + ", ".join(sample) + (" …" if filled > 5 else ""),
                                    None, where or "표", label=f"열 삭제 — {filled}행"))
    drop_n = []
    for c in only_n:
        if c in used_n:
            continue
        filled = sum(1 for r in new_rows if r.values.get(c))
        if filled >= max(3, n_new * 0.5):
            drop_n.append(c)
            sample = [f"{r.key}: {r.values[c]}" for r in new_rows if r.values.get(c)][:5]
            items.append(ChangeItem("COL_ADDED", c, None,
                                    f"값 있는 행 {filled}개 — " + ", ".join(sample) + (" …" if filled > 5 else ""),
                                    where or "표", label=f"열 추가 — {filled}행"))
    if not (rename or drop_o or drop_n):
        return old_rows, new_rows, items

    def fix_old(r):
        v = {rename.get(k, k): x for k, x in r.values.items() if k not in drop_o}
        return Row(key=r.key, values=v, where=r.where)

    def fix_new(r):
        v = {k: x for k, x in r.values.items() if k not in drop_n}
        return Row(key=r.key, values=v, where=r.where)
    return [fix_old(r) for r in old_rows], [fix_new(r) for r in new_rows], items


def _sheet_of(r) -> str:
    return r.where.split("!", 1)[0] if "!" in r.where else ""


def _diff_rows(old_rows, new_rows, kind_prefix: str) -> list[ChangeItem]:
    """표 비교 입구. 시트가 여럿이면 시트끼리 먼저 짝짓고(이름 같음 → 값이 가장 닮은 것) 시트마다
    따로 비교한다 — 시트마다 같은 키(일자)가 있어 뒤섞이고, 시트 하나를 지우면 그 행 전부가
    '삭제'로 도배되던 것 (2026-09-06 블라인드 2차 09·25)."""
    if kind_prefix != "ROW" or not (old_rows or new_rows):
        return _diff_rows_one(old_rows, new_rows, kind_prefix)
    so = list(dict.fromkeys(_sheet_of(r) for r in old_rows))
    sn = list(dict.fromkeys(_sheet_of(r) for r in new_rows))
    if len(so) <= 1 and len(sn) <= 1:
        out = _diff_rows_one(old_rows, new_rows, kind_prefix)
        if so and sn and so[0] and sn[0] and so[0] != sn[0]:
            # 시트가 하나뿐이어도 이름이 바뀐 사실은 남긴다 — 'BOM'→'BOM_최종'이
            # "글자·표·그림 동일"로 단언됐다 (검토19 감지 ⑪)
            out.insert(0, ChangeItem("SHEET_RENAMED", sn[0], so[0], sn[0], sn[0],
                                     label="표 제목 변경" if "·" in so[0] or "·" in sn[0]
                                     else "시트 이름 변경"))
        return out
    by_o = {s: [r for r in old_rows if _sheet_of(r) == s] for s in so}
    by_n = {s: [r for r in new_rows if _sheet_of(r) == s] for s in sn}
    pairs = [(s, s) for s in so if s in by_n]
    rest_o = [s for s in so if s not in by_n]
    rest_n = [s for s in sn if s not in by_o]

    def sig(rows):
        return {tuple(sorted(r.values.items())) for r in rows}
    cand = []
    for a in rest_o:
        for b in rest_n:
            ka, kb = sig(by_o[a]), sig(by_n[b])
            if ka and kb:
                cand.append((len(ka & kb) / min(len(ka), len(kb)), a, b))
    renamed = []
    for ratio, a, b in sorted(cand, reverse=True):
        if a in rest_o and b in rest_n and ratio >= 0.5:
            rest_o = [s for s in rest_o if s != a]
            rest_n = [s for s in rest_n if s != b]
            renamed.append((a, b))
    items: list[ChangeItem] = []
    for a, b in renamed:
        items.append(ChangeItem("SHEET_RENAMED", b, a, b, b,
                                label="표 제목 변경" if "·" in a or "·" in b else "시트 이름 변경"))
    for a in rest_o:
        keys = [r.key for r in by_o[a]][:5]
        items.append(ChangeItem("SHEET_REMOVED", a, f"{len(by_o[a])}행 ({', '.join(keys)}{' …' if len(by_o[a]) > 5 else ''})",
                                None, a, label="시트 삭제"))
    for b in rest_n:
        keys = [r.key for r in by_n[b]][:5]
        twin = next((s for s in list(so) + [x for x in sn if x != b]
                     if (by_o.get(s) or by_n.get(s)) and sig(by_o.get(s) or by_n.get(s)) == sig(by_n[b])), None)
        items.append(ChangeItem("SHEET_ADDED", b, None,
                                f"{len(by_n[b])}행 ({', '.join(keys)}{' …' if len(by_n[b]) > 5 else ''})"
                                + (f" — '{twin}' 시트와 내용 같음(복사본)" if twin else ""),
                                b, label="시트 추가"))
    for a, b in pairs + renamed:
        items += _diff_rows_one(by_o[a], by_n[b], kind_prefix)
    return items


def _diff_rows_one(old_rows, new_rows, kind_prefix: str) -> list[ChangeItem]:
    global _SEQ_COLS
    _SEQ_COLS = sequential_cols(old_rows, new_rows) if kind_prefix == "ROW" else set()
    col_items: list[ChangeItem] = []
    if kind_prefix == "ROW" and old_rows and new_rows:
        old_rows, new_rows, col_items = align_columns(old_rows, new_rows)
        # 사용자가 키 열(key_columns)을 정했으면 그 키를 그대로 — 다시 고르면 설정이 무시됐다 (경우100 C04)
        from watcher.extract.xlsx import _user_key_col
        _hdr = list(dict.fromkeys(c for r in old_rows[:50] + new_rows[:50] for c in r.values))
        col = None if _user_key_col(_hdr) is not None else choose_key_col(old_rows, new_rows)
        if col is not None:
            old_rows, new_rows = _rekey(old_rows, col), _rekey(new_rows, col)
        # 두 판이 서로 다른 키(한쪽은 품번, 다른 쪽은 입고번호+LOT 조합)로 읽혀 거의 안 맞으면 키를 버리고
        # 위치 정렬로 — 키가 달라 전 행이 삭제+추가로 갈리던 것 (2026-09-06 블라인드 3차 17)
        n_min = min(len(old_rows), len(new_rows))
        if n_min >= 2 and _pair_count(old_rows, new_rows) < 0.3 * n_min:
            from watcher.extract.base import Row
            # 워드·한글 표의 위치는 '표1 행3' — 위치 키 꼴('표1!행3')로 바꿔야 아래 위치 정렬로 간다. 그대로 두면 행 번호끼리
            # 짝지어 가운데 행 하나 삭제가 아래 행 전부 '값 변경'이 됐다 (검토62 A-A)
            def _pk(w):
                return w if _POS_KEY.match(w) else re.sub(r"\s+(?=행\d+$)", "!", w)
            old_rows = [r if _is_total(r) else Row(key=_pk(r.where), values=r.values, where=r.where) for r in old_rows]
            new_rows = [r if _is_total(r) else Row(key=_pk(r.where), values=r.values, where=r.where) for r in new_rows]
    return col_items + _diff_rows_body(old_rows, new_rows, kind_prefix)


def _diff_rows_body(old_rows, new_rows, kind_prefix: str) -> list[ChangeItem]:

    # 행번호 키가 지배적이면(=TAG 없는 표) 위치 정렬 방식으로
    def positional_ratio(rows):
        return (sum(1 for r in rows if _POS_KEY.match(r.key)) / len(rows)) if rows else 0
    if kind_prefix == "ROW" and old_rows and new_rows \
            and (positional_ratio(old_rows) > 0.5 or positional_ratio(new_rows) > 0.5):
        # 한쪽만 행번호 키(행이 둘로 갈려 품번이 겹치는 등)면 둘 다 위치 정렬로 — 키가 다른 채로
        # 비교하면 전 행이 삭제+추가가 된다 (2026-09-06 블라인드 3차 17)
        # 다중 시트 파일은 시트별로 따로 위치 정렬 — 시트를 한 줄로 이으면
        # 앞 시트의 행 증감이 뒤 시트 전체를 밀어 오탐이 된다 (2026-08-26)
        def sheet_of(r) -> str:
            return r.where.split("!", 1)[0] if "!" in r.where else ""

        o_sheets = list(dict.fromkeys(sheet_of(r) for r in old_rows))
        n_sheets = list(dict.fromkeys(sheet_of(r) for r in new_rows))
        # 이름이 같은 시트끼리, 남은 시트는 순서대로 — 시트 이름만 바꾼 파일(Sheet1→BOM_rev2)이
        # 전 행 삭제+추가로 보이던 것 (2026-09-06 양식 시험)
        pairs = [(s, s) for s in o_sheets if s in n_sheets]
        rest_o = [s for s in o_sheets if s not in n_sheets]
        rest_n = [s for s in n_sheets if s not in o_sheets]
        pairs += list(zip(rest_o, rest_n))
        pairs += [(s, None) for s in rest_o[len(rest_n):]] + [(None, s) for s in rest_n[len(rest_o):]]
        if len(pairs) > 1 or (pairs and pairs[0][0] != pairs[0][1]):
            items: list[ChangeItem] = []
            for so, sn in pairs:
                items += _diff_rows_positional(
                    [r for r in old_rows if so is not None and sheet_of(r) == so],
                    [r for r in new_rows if sn is not None and sheet_of(r) == sn], kind_prefix)
            return items
        return _diff_rows_positional(old_rows, new_rows, kind_prefix)

    old_by = _keyed(old_rows)
    new_by = _keyed(new_rows)
    items = []
    added_keys = sorted(new_by.keys() - old_by.keys())
    removed_keys = sorted(old_by.keys() - new_by.keys())
    # 키 칸(품명 등) 하나만 고친 행은 신규+삭제가 아니라 그 칸의 변경이다 — 나머지 값이 전부 같은
    # 삭제·신규 짝을 찾는다 (리뷰10 퍼즈: 품명이 키인 표에서 품명 오타 수정이 '새 품목'으로 보이던 것)
    for okey in list(removed_keys):
        o = old_by[okey]
        for nkey in list(added_keys):
            n = new_by[nkey]
            diff_cols = [c for c in set(o.values) | set(n.values) if not same_value(o.values.get(c), n.values.get(c))]
            if len(diff_cols) == 1 and len(o.values) >= 2 and o.where == n.where:
                col = diff_cols[0]
                items.append(ChangeItem(f"{kind_prefix}_CHANGED", f"{okey}.{col}", o.values.get(col), n.values.get(col),
                                        n.where, label=_row_label(n.values)))
                removed_keys = [k for k in removed_keys if k != okey]
                added_keys = [k for k in added_keys if k != nkey]
                break
    for key in added_keys:
        r = new_by[key]
        items.append(ChangeItem(f"{kind_prefix}_ADDED", key, None, str(r.values),
                                r.where, label=_row_label(r.values)))
    for key in removed_keys:
        r = old_by[key]
        items.append(ChangeItem(f"{kind_prefix}_REMOVED", key, str(r.values), None,
                                r.where, label=_row_label(r.values)))
    # 행 순서: 공통 키의 순서가 바뀌었으면 — 몇 행이면 각각 '이동', 많으면 '재정렬' 한 건
    # (2026-09-06 블라인드 양식 시험 09·11·27: 실무자는 순서 변경도 알고 싶어 한다)
    reorder_note = None
    common = [k for k in old_by if k in new_by and not _is_total(old_by[k])]
    n_pos = {k: i for i, k in enumerate(new_by)}
    moved = _moved_keys(common, n_pos)
    if moved:
        o_pos = {k: i for i, k in enumerate(old_by)}
        moved = [k for k in moved if o_pos[k] != n_pos[k]]
    if moved:
        if len(moved) <= 3:
            for k in moved:
                items.append(ChangeItem(f"{kind_prefix}_MOVED", k, old_by[k].where, new_by[k].where,
                                        new_by[k].where, label=_row_label(new_by[k].values)))
        else:
            # 정렬만 바꾼 표 — 값은 그대로라 변경으로 세지 않고 참고로만 (2026-09-06 블라인드 2차 28).
            # 다른 변경이 하나라도 있으면 '내용 변경 없음'이 거짓이 되고 파일 전체가 접힌다 (리뷰10 차단-2)
            # → 뒤에서 값 변경이 나오면 이 참고를 뺀다
            reorder_note = ChangeItem("CHECK_SKIPPED", "참고", None,
                                      f"행 순서만 바뀜 — {len(moved)}행 자리 바뀜, 내용 변경 없음",
                                      new_rows[0].where.split("!", 1)[0] if "!" in new_rows[0].where else "표")
            items.append(reorder_note)
    for key in sorted(old_by.keys() & new_by.keys()):
        o, n = old_by[key], new_by[key]
        if o.values != n.values:
            label = _row_label(n.values) or _row_label(o.values)
            for col in sorted(o.values.keys() | n.values.keys()):
                ov, nv = o.values.get(col), n.values.get(col)
                if same_value(ov, nv) or col in _SEQ_COLS:
                    continue
                if _ORDINAL_COL.match(str(col).strip()) \
                        or strip_leading_no(ov) == strip_leading_no(nv):
                    continue        # 순번만 밀린 것은 변경이 아니다
                items.append(ChangeItem(f"{kind_prefix}_CHANGED", f"{key}.{col}",
                                        ov, nv, n.where, label=label))
    if reorder_note is not None and any(i is not reorder_note and i.kind != "CHECK_SKIPPED" for i in items):
        items = [i for i in items if i is not reorder_note]
        items.append(ChangeItem(f"{kind_prefix}_MOVED", "행 순서", None, f"{len(moved)}행 자리 바뀜 (값은 위 항목 외 그대로)",
                                new_rows[0].where.split("!", 1)[0] if "!" in new_rows[0].where else "표",
                                label="행 순서 재정렬"))
    return items


_LINE_LABEL = re.compile(
    r"^\s*((?:제\s*\d{1,3}\s*[조항호])|(?:\d{1,3}(?:[.\-]\d{1,3})*[.)])|(?:\d{1,3}(?:\.\d{1,3})+)|(?:[A-Z]{2,8}\s*\d{1,3}[.:])|"
    r"(?:[①-⑳㉑-㉟⑴-⒇⒈-⒛])|(?:[•·▪▫◦‣∙‧\-–—])|(?:\(\d+\))|(?:[가-힣]\.)|"
    # 로마 숫자 'Ⅰ.'·'IV.', '가)'·'(가)', 'ⓐ', 'Article 3.' — 이름표로 몰라 가운데 조항 하나를 지우고 번호를 다시 매기면
    # 아래 조항이 전부 글자 변경이 됐다 (검토68 D2)
    r"(?:[Ⅰ-Ⅻⅰ-ⅻ]\.)|(?:(?=[IVX])X{0,2}(?:IX|IV|V?I{0,3})\.)|(?:[가-힣]\))|(?:\([가-힣]\))|(?:[Ⓐ-ⓩ])|"
    r"(?:(?:Article|ARTICLE|Clause|CLAUSE|Section|SECTION)\s*\d{1,3}\.?)|"
    r"(?:[가-힣A-Za-z][가-힣A-Za-z /]{1,14}:))"
    # 조 번호 바로 뒤 괄호 제목 '제3조(검수)'도 — 이름표로 못 읽어 두 조를 맞바꾸고 번호를 다시 매긴 계약서가 글자 변경 2건 + 거짓
    # Rev 미갱신이 됐다 (검토70 B, held69 W07). 제목은 이름표 밖(나머지 글)에 남아 제목만 고친 것은 변경으로 보인다
    r"(?=\s|$|(?<=[조항호])\()")
# 번호·기호 이름표는 재부여될 수 있다(①→② / • 는 어느 항목이나 같다) — 나머지 글자로 짝짓는다
_NUMERIC_LABEL = re.compile(r"^\s*(제\s*\d+|\d|[①-⑳㉑-㉟⑴-⒇⒈-⒛]|[•·▪▫◦‣∙‧\-–—]|\(\d+\)|[가-힣]\.|"
                            r"[Ⅰ-Ⅻⅰ-ⅻ]\.|(?=[IVX])X{0,2}(?:IX|IV|V?I{0,3})\.|[가-힣]\)|\([가-힣]\)|[Ⓐ-ⓩ]|"
                            r"(?:Article|ARTICLE|Clause|CLAUSE|Section|SECTION)\s*\d)")
# 부록 조항 번호 'A-3'·'A.3'·'A20.3' — 글자 하나+번호 꼴은 기기 태그('X-12')·나사('M3.5')와 모양이 같아 전역 이름표로 둘 수
# 없다. 한 비교 단위 안에서 같은 머리의 번호가 빈틈없이 이어질 때만(양쪽 모두, 한쪽은 3개 이상) 조항 번호로 본다 — 태그로
# 짝지어 조항 하나 지운 날 엇갈린 글자 변경과 엉뚱한 마지막 조항 '삭제'가 났다 (검토68 D1·D2)
_SEQ_HEAD = re.compile(r"^\s*(?:([A-Z]-)(\d{1,2})|([A-Z]\d{0,3}\.)(\d{1,3}))\.?(?=\s)")


_NUM_RUN = re.compile(r"\d+(?:[.,]\d+)*")


def _space_only(a, b) -> bool:
    """두 글이 띄어쓰기만 다른가 — 공백을 뺀 글자가 같고 숫자 덩어리도 같다 (검토68 D6)."""
    a, b = str(a or ""), str(b or "")
    if a == b or re.sub(r"\s+", "", a) != re.sub(r"\s+", "", b):
        return False
    return _NUM_RUN.findall(a) == _NUM_RUN.findall(b)


def _space_only_cells(items: list) -> list:
    """워드·한글 표 칸의 띄어쓰기만 변경('380 V' → '380V')은 문단과 같은 규칙(검토68 D6)으로 참고 한 줄 — 행 변경 + 거짓 'Rev
    미갱신'이 됐다 (검토70 B, held69 W06). 원칙 5대로 사라지지 않고 참고 항목으로 남는다. 엑셀(BOM) 칸은 대상이 아니다."""
    sp = [i for i in items if i.kind == "ROW_CHANGED" and _space_only(i.old, i.new)]
    if not sp:
        return items

    def _cut(s):
        s = " ".join(str(s or "").split())
        return s if len(s) <= 60 else s[:59] + "…"
    out = [i for i in items if not any(i is x for x in sp)]
    out.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                          f"띄어쓰기만 바뀜 — '{_cut(sp[0].old)}' → '{_cut(sp[0].new)}'"
                          + (f" 외 {len(sp) - 1}곳" if len(sp) > 1 else "")
                          + f" (표 칸 {sp[0].key} · 글자는 그대로입니다)", sp[0].where))
    return out


def _seq_families(*sides) -> set:
    """줄 머리 '글자+번호' 꼴 가운데 조항 번호 체계로 보이는 머리(예: 'A-', 'A20.')."""
    per = []
    for lines in sides:
        d: dict = {}
        for t in lines:
            m = _SEQ_HEAD.match(t.text or "")
            if m:
                d.setdefault(m.group(1) or m.group(3), []).append(int(m.group(2) or m.group(4)))
        per.append(d)
    out = set()
    for fam in set().union(*per):
        ns_all = [d[fam] for d in per if d.get(fam)]
        if all(len(set(ns)) == len(ns) and max(ns) - min(ns) + 1 == len(ns) for ns in ns_all) \
                and any(len(ns) >= 3 for ns in ns_all):
            out.add(fam)
    return out


def _page_of(where: str) -> str:
    m = _PAGE_WHERE.match(where or "")
    return m.group(1) if m else ""


_SHEET_OF = re.compile(r"^\s*(?:SHEET|SH\.?|PAGE|PG\.?|쪽|페이지|장)?\s*:?\s*\d{1,3}\s*(?:OF|/)\s*(\d{1,3})\s*(?:쪽|페이지|장)?\s*$", re.I)


def _after_label(text: str) -> str:
    m = _LINE_LABEL.match(text or "")
    return " ".join((text[m.end():] if m else text or "").split())


def _line_label(text: str) -> str | None:
    """줄 머리의 항목 이름표 — '4.', '3-1.', '제6조', 'NOTE 2.', '변경 사유:'. 같은 이름표의 삭제+추가는
    문장을 크게 고쳐도 한 항목의 '변경'이다 (2026-09-06 블라인드 양식 시험 35·37·38)."""
    m = _LINE_LABEL.match(text or "")
    return "".join(m.group(1).split()).upper() if m else None


def _with_swap_partners(order: list, n_pos: dict, moved: list) -> list:
    """맞바꿈(두 항목이 서로의 자리로)이면 두 항목 다 '이동'이다. 가장 긴 오름 부분열 밖만 세면 이웃한 두 조항 3.2↔3.3을
    바꾸고 번호를 다시 매긴 날 한쪽만 '이동'으로 나와, 다른 쪽 조항('치수를 측정…' 3.3→3.2)은 어디에도 없었다 (고정 벤치마크
    doc68 D18·H14). 맞바꿈 짝만 더하고, 옛 순번과 새 순번이 같은 항목은 뺀다(멀리 떨어진 맞바꿈의 가운데 항목)."""
    rank_new = {k: r for r, k in enumerate(sorted(order, key=lambda k: n_pos[k]))}
    old_rank = {k: i for i, k in enumerate(order)}
    out = list(moved)
    for k in moved:
        p = order[rank_new[k]]
        if p not in out and rank_new[p] == old_rank[k]:
            out.append(p)
    out = [k for k in out if old_rank[k] != rank_new[k]] or out[:1]
    return sorted(out, key=lambda k: old_rank[k])


RENUM_MOVE_LABEL = "내용은 그대로, 순서를 바꾸고 번호를 다시 매김"


def _moved_labelled_lines(old_lines, new_lines, swaps: bool = False) -> list[ChangeItem]:
    """'제8조 …'처럼 이름표가 붙은 줄이 그대로인 채 자리만 옮겨졌으면 '이동'으로 — 계약서 조항 순서
    (2026-09-06 블라인드 채점: 문단 이동 0/1). 이름표 없는 줄의 재배치는 여전히 소음으로 보고 무시."""
    def labelled(lines):
        out = {}
        for i, t in enumerate(lines):
            lb = _line_label(t.text)
            if not lb:
                continue
            # 번호 이름표는 재부여될 수 있으니 나머지 글자로 짝짓고, 글자 이름표는 이름표 자체로
            k = ("R", _after_label(t.text)) if _NUMERIC_LABEL.match(t.text) else ("L", lb)
            if k[1] and k not in out:
                out[k] = (i, t)
        return out
    lo, ln = labelled(old_lines), labelled(new_lines)
    common = [k for k, (i, t) in sorted(lo.items(), key=lambda kv: kv[1][0])
              if k in ln and (k[0] == "R" or ln[k][1].text == t.text)]
    if len(common) < 2:
        return []
    n_pos = {lb: ln[lb][0] for lb in common}
    moved = _moved_keys(common, n_pos)
    if not moved:
        return []
    def _renumbered(k) -> bool:
        return k[0] == "R" and _line_label(lo[k][1].text) != _line_label(ln[k][1].text)
    renum = False
    if swaps:      # 워드·한글 문단만 — PDF 글줄은 재출력 순서 흔들림이 많아 짝을 더하면 소음이 는다(fmt66 P03)
        moved = _with_swap_partners(common, n_pos, moved)
    elif any(_renumbered(k) for k in moved):
        # PDF라도 옮겨진 항목의 **번호가 실제로 바뀌었으면**(주기 1·2를 맞바꾸고 번호를 다시 매김) 그리는 순서 흔들림이 아니라
        # 순서를 바꾼 편집이다 — '이동만 남은 PDF는 재출력 순서'라는 거름에 걸려 '다시 저장만'으로 판정됐다 (검토70 B, adv69 M5).
        # 번호가 그대로인 재출력 순서 섞임(fmt66 P03)은 예전대로
        moved = [k for k in _with_swap_partners(common, n_pos, moved) if _renumbered(k)]
        renum = bool(moved)
    if len(moved) > 3:
        return [ChangeItem("TEXT_MOVED", "문단 순서", f"{len(moved)}개 항목 자리 바뀜", "재배치", new_lines[0].where,
                           label=RENUM_MOVE_LABEL if renum else None)]
    return [ChangeItem("TEXT_MOVED", ln[lb][1].text[:30], lo[lb][1].where, ln[lb][1].where, ln[lb][1].where,
                       label=RENUM_MOVE_LABEL if renum else "내용은 그대로, 자리만 이동") for lb in moved]


def _tag_of(text: str) -> str | None:
    tags = find_tags(text)  # 제외 접두(도면번호 등)를 거친 첫 태그
    return tags[0] if tags else None


def _excess_instances(lines, own_counts: Counter, other_counts: Counter) -> list:
    """상대쪽보다 많은 만큼(N−M개)만 골라낸다 — 전 인스턴스를 지목하면
    아직 존재하는 줄을 삭제됐다고 보고하는 거짓 근거가 된다."""
    taken: Counter = Counter()
    out = []
    for t in lines:
        excess = own_counts[t.text] - other_counts[t.text]
        if taken[t.text] < excess:
            taken[t.text] += 1
            out.append(t)
    return out


# where가 "N페이지 M행" 꼴이면 페이지 정보가 있는 문서 (pdf.py 형식)
_PAGE_WHERE = re.compile(r"^(\d+)페이지")
# 페이지 짝짓기 최소 유사도 — 이보다 다르면 같은 도면의 개정판이 아니라 다른 페이지
_PAGE_SIM_MIN = 0.3
# 페이지 짝짓기 전수 비교 상한 (P×Q). 넘으면 순서대로 짝짓는다 (성능 보호)
_PAGE_PAIR_CAP = 40_000


def _pages(lines) -> dict[int, list]:
    """TextLine들을 페이지 번호로 묶는다. 페이지 정보 없는 줄은 0번 묶음."""
    out: dict[int, list] = {}
    for t in lines:
        m = _PAGE_WHERE.match(t.where)
        out.setdefault(int(m.group(1)) if m else 0, []).append(t)
    return out


def _page_preview(lines) -> str:
    """추가·삭제된 쪽이 무엇인지 글로 — '텍스트 8줄'과 사진뿐이라 지운 쪽이 어느 도면인지 글로는 없었다 (검토61 B14·B47).
    표제란 라벨 줄('DWG NO: …')을 앞에, 나머지 줄을 이어 앞 세 줄만."""
    texts = [" ".join(str(t.text).split()) for t in lines if str(t.text).strip()]
    head = [t for t in texts if _TITLE_LINE.match(t)][:1]
    rest = [t for t in texts if t not in head]
    pv = [t[:40] for t in head + rest][:3]
    return (": " + " / ".join(pv) + (" …" if len(texts) > len(pv) else "")) if pv else ""


def _page_added(pno: int, lines) -> ChangeItem:
    return ChangeItem("PAGE_ADDED", f"{pno}페이지", None,
                      f"페이지 추가 (텍스트 {len(lines)}줄{_page_preview(lines)})", lines[0].where)


def _page_removed(pno: int, lines) -> ChangeItem:
    return ChangeItem("PAGE_REMOVED", f"{pno}페이지",
                      f"페이지 삭제 (텍스트 {len(lines)}줄{_page_preview(lines)})", None, lines[0].where)


def _pair_changed_pages(old_ids, new_ids, op, np_) -> list[ChangeItem]:
    """내용이 달라진 페이지들을 토큰 겹침 비율로 짝짓는다.
    (재출력 시 페이지 순서가 밀리거나 바뀌어도 같은 도면끼리 비교되도록.
    비율 분모는 작은 쪽 — 한 줄짜리 페이지의 값 변경도 짝지어지게)"""
    items: list[ChangeItem] = []
    if len(old_ids) * len(new_ids) > _PAGE_PAIR_CAP:
        for i, j in zip(old_ids, new_ids):
            items += _diff_text_lines(op[i], np_[j])
        for i in old_ids[len(new_ids):]:
            items.append(_page_removed(i, op[i]))
        for j in new_ids[len(old_ids):]:
            items.append(_page_added(j, np_[j]))
        return items

    otok = {i: {tok for t in op[i] for tok in t.text.split()} for i in old_ids}
    ntok = {j: {tok for t in np_[j] for tok in t.text.split()} for j in new_ids}
    sims = []
    for i in old_ids:
        for j in new_ids:
            inter = len(otok[i] & ntok[j])
            floor = min(len(otok[i]), len(ntok[j])) or 1
            sims.append((inter / floor, i, j))
    used_o, used_n, pairs = set(), set(), []
    for sim, i, j in sorted(sims, key=lambda s: (-s[0], abs(s[1] - s[2]))):
        if sim < _PAGE_SIM_MIN:
            break
        if i in used_o or j in used_n:
            continue
        used_o.add(i)
        used_n.add(j)
        pairs.append((i, j))
    for i, j in sorted(pairs, key=lambda p: p[1]):
        items += _diff_text_lines(op[i], np_[j])
    # 같은 번호 쪽이 글자에서 '글자 없음(그림)' 표지로(또는 그 반대로) 바뀐 것은 쪽 삭제·추가가 아니다 — 서명 쪽만 스캔으로 끼운
    # 재출력을 '2페이지 삭제'라 했다 (검토51 B 중간 6). 한 줄로 알리고 그 쪽은 그림 비교에 맡긴다
    def _blank_marker(lines) -> bool:
        return bool(lines) and all("글자 없음 — 그림(스캔·벡터)" in str(t.text) for t in lines)
    for i in list(old_ids):
        if i in used_o or i not in new_ids or i in used_n:
            continue
        if _blank_marker(np_[i]) != _blank_marker(op[i]):
            used_o.add(i)
            used_n.add(i)
            to_img = _blank_marker(np_[i])
            items.append(ChangeItem(
                "CHECK_SKIPPED", "글자 비교", None,
                (f"{i}페이지가 글자 없는 그림(스캔)으로 바뀌어 글자를 비교하지 못했습니다 — 전에는 글자 {len(op[i])}줄"
                 if to_img else f"{i}페이지가 그림(스캔)에서 글자 있는 쪽으로 바뀌었습니다 — 글자 {len(np_[i])}줄"),
                f"{i}페이지"))
    for i in old_ids:
        if i not in used_o:
            # 그림 쪽 표지뿐인 쪽이 빠지거나 생긴 것은 '텍스트 1줄 쪽 추가·삭제'가 아니다 — 근거 문구가 틀렸다 (검토52 A 낮음 4b)
            if _blank_marker(op[i]):
                items.append(ChangeItem("CHECK_SKIPPED", "글자 비교", None,
                                        f"글자 없는 그림 쪽({i}페이지)이 빠졌거나 자리가 바뀌었습니다 — 그림 비교로 봅니다",
                                        f"{i}페이지"))
                continue
            items.append(_page_removed(i, op[i]))
    for j in new_ids:
        if j not in used_n:
            if _blank_marker(np_[j]):
                items.append(ChangeItem("CHECK_SKIPPED", "글자 비교", None,
                                        f"글자 없는 그림 쪽({j}페이지)이 생겼거나 자리가 바뀌었습니다 — 그림 비교로 봅니다",
                                        f"{j}페이지"))
                continue
            items.append(_page_added(j, np_[j]))
    return items


def _diff_pages(op: dict, np_: dict) -> list[ChangeItem]:
    """페이지 단위 본문 diff. 도면 세트 PDF는 페이지 하나가 별개 도면이므로
    문서 전체를 한 풀로 섞으면 ①페이지 간 이동이 무변경으로 오인되고
    ②문서가 클수록 다른 페이지의 같은 단어가 진짜 변경을 상쇄해 삼킨다
    (2026-08-23 실사용 발견: 131페이지 도면 세트에서 변경 2/3가 유실).

    1단계: 내용이 완전히 같은 페이지끼리 상쇄 (순서 이동은 변경이 아님).
    2단계: 남은 페이지를 유사도로 짝지어 페이지별 줄 diff.
    3단계: 짝 못 찾은 페이지는 페이지 추가/삭제로 보고."""
    osig = {i: tuple(sorted(t.text for t in op[i])) for i in sorted(op)}
    nsig = {j: tuple(sorted(t.text for t in np_[j])) for j in sorted(np_)}
    n_avail = Counter(nsig.values())
    rem_old = []
    for i, s in osig.items():
        if n_avail[s] > 0:
            n_avail[s] -= 1
        else:
            rem_old.append(i)
    o_avail = Counter(osig.values())
    rem_new = []
    for j, s in nsig.items():
        if o_avail[s] > 0:
            o_avail[s] -= 1
        else:
            rem_new.append(j)
    return _pair_changed_pages(rem_old, rem_new, op, np_)


def page_anchors(old: Document, new: Document) -> dict[int, int]:
    """글자로 확실한 페이지 대응 {옛 쪽: 새 쪽} — 그림 정렬의 앵커 (검토19 2차 감지 N2).
    ①내용이 완전히 같은 쪽은 순서대로 ②남은 쪽은 낱말 겹침(Jaccard ≥ 0.5)이 큰 순으로, 단조 증가만."""
    try:
        op, np_ = _pages(old.raw_texts), _pages(new.raw_texts)
    except Exception:
        return {}
    if len(op) <= 1 and len(np_) <= 1:
        return {}
    osig = {i: tuple(sorted(t.text for t in op[i])) for i in op}
    nsig = {j: tuple(sorted(t.text for t in np_[j])) for j in np_}
    out: dict[int, int] = {}
    used_j: set = set()
    for i in sorted(osig):
        if not osig[i]:
            continue
        for j in sorted(nsig):
            if j not in used_j and nsig[j] == osig[i] and all(j > b for a, b in out.items() if a < i):
                out[i] = j
                used_j.add(j)
                break
    # 글자가 완전히 같은 쪽은 순서를 거슬러도 짝이다 — 2쪽↔3쪽을 맞바꾼 세트가 단조 조건에 걸려 3쪽 짝을 잃고, 기록 그림과
    # 파일 그림의 잉크 서명이 달라 번호 그대로 짝지어 '그림 변경 4곳 + Rev 미갱신'이 났다 (검토61 B15). 순서를 따지는
    # 쪽(align_pages의 DP)은 단조인 것만 골라 쓴다
    for i in sorted(osig):
        if i in out or not osig[i]:
            continue
        same = [j for j in sorted(nsig) if j not in used_j and nsig[j] == osig[i]]
        if len(same) == 1 and sum(1 for k in osig if osig[k] == osig[i]) == 1:
            out[i] = same[0]
            used_j.add(same[0])
    ow = {i: {w for t in op[i] for w in t.text.split()} for i in op if i not in out}
    nw = {j: {w for t in np_[j] for w in t.text.split()} for j in np_ if j not in used_j}
    cands = sorted(((len(ow[i] & nw[j]) / max(1, len(ow[i] | nw[j])), i, j)
                    for i in ow for j in nw if ow[i] and nw[j]), reverse=True)
    for s, i, j in cands:
        if s < 0.5 or i in out or j in used_j:
            continue
        if any((a < i) != (b < j) for a, b in out.items()):     # 단조 증가 유지
            continue
        out[i] = j
        used_j.add(j)
    # 순서를 거스르는 짝도 서로가 가장 닮은 쪽이고 충분히 닮았으면 — 1쪽↔3쪽을 맞바꾸고 둘 다 조금 고친 세트가 앵커를 못 얻어
    # 첫 쪽 표제란끼리 비교해 '도면번호 E-1 → E-3' 거짓 변경이 났다 (검토62 B5). 순서를 따지는 쪽은 단조인 것만 골라 쓴다
    for s, i, j in cands:
        if s < 0.6 or i in out or j in used_j:
            continue
        if max((s2 for s2, i2, j2 in cands if i2 == i and j2 not in used_j), default=0) > s \
                or max((s2 for s2, i2, j2 in cands if j2 == j and i2 not in out), default=0) > s:
            continue
        out[i] = j
        used_j.add(j)
    return out


_PAGE_NUM_LINE = re.compile(r"(?i)^(.*?)\s*(?:(?:PAGE|PG\.?|P\.|SHEET|SH\.?)\s*)?(\d{1,3})\s*(?:OF|/)\s*(\d{1,3})\s*(?:쪽|페이지|장)?\s*$")
# 쪽 번호가 줄 **앞**에 오고 뒤에 문서번호가 붙은 바닥글 'Page 1 of 3 QP-1401' (검토70 B, held69 P14) — 쪽 표식 낱말(PAGE·SHEET
# + of·/, 또는 '쪽·페이지')이 있을 때만. 표식 없는 'SCALE 1/2 NTS'는 쪽 번호가 아니다(검토69 r2)
_PAGE_NUM_LEAD = re.compile(r"(?i)^(.*?)\s*(?:(?:PAGE|PG\.?|P\.|SHEET|SH\.?)\s*(\d{1,3})\s*(?:OF|/)\s*(\d{1,3})"
                            r"|(\d{1,3})\s*/\s*(\d{1,3})\s*(?:쪽|페이지))\s+(\S.*?)\s*$")


def _page_num(text: str):
    """쪽 번호 줄이면 (앞 글, 쪽, 전체, 뒤 글, 표식 있음), 아니면 None."""
    s = str(text or "")
    m = _PAGE_NUM_LINE.match(s)
    if m:
        return (m.group(1).strip(), int(m.group(2)), int(m.group(3)), "",
                bool(_PAGE_WORD_END.search(m.group(1).strip()) or _PAGE_WORD_IN.search(s[m.end(1):])))
    m = _PAGE_NUM_LEAD.match(s)
    if m:
        k, n = (m.group(2), m.group(3)) if m.group(2) else (m.group(4), m.group(5))
        return (m.group(1).strip(), int(k), int(n), " ".join(m.group(6).split()), True)
    return None


def _drop_page_renumbering(items: list, op: dict, np_: dict, no: int, nn: int) -> list:
    """쪽을 더하거나 빼거나 옮긴 결과로 바뀐 바닥글 쪽 번호('Page 1 of 1'→'Page 1 of 2', '3/3'→'2/2', 옮긴 쪽의 'Page 3/4'→'2/4')는
    따로 센 변경이 아니다 — 쪽 추가·삭제·이동 항목이 이미 말한다. 한 쪽 부록을 더했을 뿐인데 '글자 변경'이 하나 더 붙었다
    (검토68 B43·B44·B49). 옛 줄이 옛 판의 **바로 그 쪽 번호·전체 쪽수** 자리에 있었고, 새 줄도 새 판의 그 쪽 번호·전체 쪽수일
    때만 — 쪽 번호를 잘못 적었다가 고친 것('2/3'이 3쪽에 있던 것)은 남는다."""
    out = []
    for i in items:
        if i.kind == "TEXT_CHANGED":
            mo, mn = _page_num(i.old), _page_num(i.new)
            pn = _page_of(getattr(i, "where", "") or "")
            # 앞 글과 뒤 글이 모두 같고 쪽 번호만 다를 때 (검토70 B P14)
            if mo and mn and pn and mo[0] == mn[0] and mo[3] == mn[3] \
                    and _page_marked(mo, op, no) and _page_marked(mn, np_, nn):
                ko, mo_, kn, mn_ = mo[1], mo[2], mn[1], mn[2]
                if kn == int(pn) and mn_ == nn and mo_ == no and (ko, mo_) != (kn, mn_) \
                        and any(t.text == i.old for t in op.get(ko, [])) \
                        and (ko == kn or _page_words_sim(np_.get(kn, []), op.get(ko, []))
                             >= max(0.5, _page_words_sim(np_.get(kn, []), op.get(kn, [])))):
                    continue
        out.append(i)
    return out


_PAGE_WORD_END = re.compile(r"(?i)(?:PAGE|PG\.?|P\.|SHEET|SH\.?|쪽|페이지|장|NO\.?)\s*[:：]?\s*$")
_PAGE_WORD_IN = re.compile(r"(?i)PAGE|PG\.|SHEET|SH\.|\bOF\b|쪽|페이지|장")


def _page_marked(m, pages: dict, total: int) -> bool:
    """쪽 번호 줄인가 — 앞 글자 없이 'n/m'만이면 그렇다고 보고, 앞 글자가 있으면 쪽 표식(PAGE·SHEET·쪽·of …)이 있거나, 같은
    앞 글자의 'k/전체' 줄이 그 판의 **모든 쪽**에 있어야(바닥글 'FI-6007 1/3'). 'SCALE 1/2' → 'SCALE 1/3'이 쪽 추가와 함께
    바뀐 날 쪽 번호로 접혀 사라졌다 (검토69 r2)."""
    pre, post = m[0], m[3]
    if not pre and not post:
        return True
    if m[4]:
        return True
    if total < 2:
        return False
    for k in range(1, total + 1):
        if not any((mm := _page_num(t.text)) and mm[0] == pre and mm[3] == post
                   and mm[1] == k and mm[2] == total for t in pages.get(k, [])):
            return False
    return True


def _page_words_sim(a, b) -> float:
    """두 쪽의 낱말 겹침(Jaccard) — 쪽 번호 줄은 빼고. 새 쪽이 옛 몇 쪽에서 왔는지 가늠한다."""
    wa = {w for t in a if not _PAGE_NUM_LINE.match(t.text) for w in t.text.split()}
    wb = {w for t in b if not _PAGE_NUM_LINE.match(t.text) for w in t.text.split()}
    return len(wa & wb) / max(1, len(wa | wb))


def _diff_texts(old: Document, new: Document) -> list[ChangeItem]:
    """본문 줄 diff. 페이지 정보가 있는 다중 페이지 문서는 페이지끼리 짝지어
    비교하고, 그 외에는 문서 전체를 한 번에 비교한다."""
    op, np_ = _pages(old.raw_texts), _pages(new.raw_texts)
    if len(op) > 1 or len(np_) > 1:
        out = _group_repeats(_diff_pages(op, np_), page_count=max(len(op), len(np_)))
        # 쪽이 늘거나 줄었으면 전체 쪽수를 한 번 — '페이지 추가 2'만으로는 4쪽이 6쪽이 됐는지 알 수 없었다 (검토62 D1 S4)
        no, nn = len([k for k in op if k]), len([k for k in np_ if k])
        out = _drop_page_renumbering(out, op, np_, no, nn)
        if no != nn:
            for k, i in enumerate(out):
                if i.kind == "PAGE_ADDED":
                    out[k] = ChangeItem(i.kind, i.key, i.old, f"{i.new} · 전체 {no}쪽 → {nn}쪽", i.where)
                    break
                if i.kind == "PAGE_REMOVED":
                    out[k] = ChangeItem(i.kind, i.key, f"{i.old} · 전체 {no}쪽 → {nn}쪽", i.new, i.where)
                    break
        return out
    # 워드·한글은 문단이 진짜 단위다 — PDF 재출력 줄바꿈 소음 대책(낱말 상쇄)을 그대로 쓰면 문단 합침이 '내용 변경 없음',
    # 나눔은 뒤 문장이 '삭제'처럼, 순서 바꿈은 아무것도 안 보였다 (검토61 D05·D06·D07)
    structured = getattr(new, "doc_type", "") in ("docx", "hwpx") and getattr(old, "doc_type", "") in ("docx", "hwpx")
    ol, nl = old.raw_texts, new.raw_texts
    moved: list = []
    if getattr(new, "doc_type", "") == "dxf" and getattr(old, "doc_type", "") == "dxf":
        ol, nl, moved = _split_block_pairs(ol, nl)
        ol, nl = _split_block_lines(ol, nl), _split_block_lines(nl, ol)
    return _group_repeats(_diff_text_lines(ol, nl, structured=structured) + moved)


def _block_rest(s: str) -> str:
    return " ".join(strip_leading_no(s).split())


def _split_block_pairs(old_lines: list, new_lines: list):
    """같은 레이어에서 옛 판에만 있는 MTEXT 덩이와 새 판에만 있는 덩이가 줄 단위로 대부분 같으면(번호 뺀 글 기준 절반 이상)
    둘 다 줄로 편다 — 바뀐 줄만 변경으로 남는다. 같은 줄들의 순서가 바뀌었으면 '문단 순서' 이동 한 건. 번호 문단을 맞바꾸고
    번호를 다시 매긴 MTEXT('1. 설계 압력 …' ↔ '1. 시험 압력 …')가 재부여 거름과 글자 자리 가림에 함께 걸려 아무 데도 안
    나왔다 (검토69 B P2·P2b·P5)."""
    oc, nc = Counter(t.text for t in old_lines), Counter(t.text for t in new_lines)
    ob = [t for t in old_lines if "\n" in t.text and not nc.get(t.text)]
    nb = [t for t in new_lines if "\n" in t.text and not oc.get(t.text)]
    if not ob or not nb:
        return old_lines, new_lines, []
    split_o, split_n, moved, used = set(), set(), [], set()
    for o in ob:
        op = [p for p in o.text.split("\n") if p.strip()]
        orest = Counter(_block_rest(p) for p in op)
        best, best_c = None, 0
        for n in nb:
            if id(n) in used or n.where != o.where:
                continue
            np_ = [p for p in n.text.split("\n") if p.strip()]
            c = sum((orest & Counter(_block_rest(p) for p in np_)).values())
            if 2 * c >= max(len(op), len(np_)) and c >= 2 and c > best_c:
                best, best_c = n, c
        if best is None:
            continue
        np_ = [p for p in best.text.split("\n") if p.strip()]
        common = orest & Counter(_block_rest(p) for p in np_)
        def _seq(parts):
            left = Counter(common)
            out_ = []
            for r in (_block_rest(p) for p in parts):
                if left.get(r, 0) > 0:
                    left[r] -= 1
                    out_.append(r)
            return out_
        seq_o, seq_n = _seq(op), _seq(np_)
        # 같은 문단들의 **순서가 바뀐** 덩이만 편다 — 문단 하나를 고치거나 덧붙인 덩이는 전처럼 덩이째 '변경' 한 건(퍼즈 62_B 오라클과
        # 같은 단위). 펴면 그 변경이 줄 조각 여럿으로 갈렸다
        if seq_o == seq_n:
            continue
        used.add(id(best))
        split_o.add(id(o))
        split_n.add(id(best))
        if Counter(seq_o) == Counter(seq_n) and seq_o != seq_n:
            diff = [r for r, s in zip(seq_o, seq_n) if r != s]
            moved.append(ChangeItem("TEXT_MOVED", "문단 순서", " / ".join(diff[:3])[:120],
                                    " / ".join(r for r in seq_n if r in diff)[:120], best.where,
                                    label="내용은 그대로, 자리만 이동"))

    def expand(lines, ids):
        out = []
        for t in lines:
            if id(t) in ids:
                out.extend(TextLine(" ".join(p.split()), t.where) for p in t.text.split("\n") if p.strip())
            else:
                out.append(t)
        return out
    return expand(old_lines, split_o), expand(new_lines, split_n), moved


_UNIT_ONLY = re.compile(r"(?i)^\s*(?:k?W|kVA|VA|V|VAC|VDC|m?A|kA|mm|cm|m|bar|MPa|kPa|Pa|psi|℃|°C|Hz|rpm|RPM|kg|t|ton|L|LPM|"
                        r"CMH|CMM|m3/h|㎥/h|mmAq|HP|P|EA|SQ|sq|㎟|mm2|AF|AT|Ω|kΩ|%|A/h|Ah|kWh|lux|dB)\s*$")


def _blocks_correspond(parts: list, cand: list) -> bool:
    """덩이의 줄들(parts)이 다른 쪽 같은 레이어 글줄(cand, 위→아래)과 순서대로 하나씩 대응하나 — 줄마다 같거나 닮고
    (태그가 같거나 SequenceMatcher 0.6 이상), 절반 이상은 글자까지 같아야. 사이에 낀 남의 줄은 한 줄까지만."""
    from difflib import SequenceMatcher
    j, exact, gaps, start = 0, 0, 0, None
    for p in parts:
        hit = None
        for k in range(j, len(cand)):
            c = cand[k]
            if c == p or (_tag_of(p) and _tag_of(p) == _tag_of(c)) or SequenceMatcher(None, p, c).ratio() >= 0.6:
                hit = k
                break
            if start is not None:
                gaps += 1
                if gaps > 1:
                    return False
        if hit is None:
            return False
        if start is None:
            start = hit
        exact += cand[hit] == p
        j = hit + 1
    return 2 * exact >= len(parts)


def _split_block_lines(side: list, other: list) -> list:
    """DXF 본문 MTEXT 한 덩이(줄바꿈 든 글) ↔ 다른 쪽의 같은 레이어 TEXT 여러 줄이 줄 단위로 대응하면 덩이를 줄로 편다.
    다른 CAD가 TEXT 세 줄을 서식 MTEXT 한 덩이로 바꿔 저장하면 덩이가 첫 줄 태그와 짝지어져 '첫 줄이 세 줄로 바뀜 + 둘째·셋째
    줄 삭제'로 나왔다 (고정 벤치마크 fmt66 D14). 추출에서 쪼개면 같은 높이 다른 TEXT와 붙고 태그 줄이 사양을 잃어(검토69 차단 1)
    비교 단계에서, 대응이 보일 때만 편다 — 바뀐 줄만 변경으로 남는다."""
    if not any("\n" in t.text for t in side):
        return side
    full = Counter(t.text for t in other)
    by_where: dict = {}
    for t in other:
        if "\n" not in t.text:
            by_where.setdefault(t.where, []).append(" ".join(t.text.split()))
    out = []
    for t in side:
        if "\n" in t.text and not full.get(t.text):
            parts = [" ".join(p.split()) for p in t.text.split("\n") if p.strip()]
            if len(parts) >= 2 and _blocks_correspond(parts, by_where.get(t.where, [])):
                out.extend(TextLine(p, t.where) for p in parts)
                continue
        out.append(t)
    return out


REFLOW_NOTE = "문단 나눔·합침만 바뀜"


def _moved_paragraphs(old_lines, new_lines, skip: set) -> list[ChangeItem]:
    """문서(워드·한글)에서 이름표 없는 문단이 그대로 자리만 옮겨진 것 — 양쪽에 한 번씩만 있는 문단끼리 순서를 본다."""
    oc, nc = Counter(t.text for t in old_lines), Counter(t.text for t in new_lines)
    uniq = [t for t in old_lines if oc[t.text] == 1 and nc.get(t.text) == 1 and len(t.text.strip()) >= 6
            and t.text[:30] not in skip]
    if len(uniq) < 2:
        return []
    n_idx = {t.text: (i, t) for i, t in enumerate(new_lines)}
    order = [t.text for t in uniq]
    moved = _moved_keys(order, {k: n_idx[k][0] for k in order})
    # 두 문단 맞바꿈에서 가운데 문단이 '문단 3 → 문단 3'으로 함께 나왔다 — 같은 문단들 사이 순번이 그대로면 뺀다
    n_rank = {k: r for r, k in enumerate(sorted(order, key=lambda k: n_idx[k][0]))}
    moved = [k for k in moved if order.index(k) != n_rank[k]] or moved[:1]
    if not moved:
        return []
    o_where = {t.text: t.where for t in uniq}
    if len(moved) > 3:
        return [ChangeItem("TEXT_MOVED", "문단 순서", f"{len(moved)}개 문단 자리 바뀜", "재배치", new_lines[0].where)]
    return [ChangeItem("TEXT_MOVED", k[:30], o_where[k], n_idx[k][1].where, n_idx[k][1].where,
                       label="내용은 그대로, 자리만 이동") for k in moved]


def _tag_slots(text: str):
    """줄의 낱말 중 태그 하나만 든 자리마다 (열쇠, 태그) — 열쇠는 낱말 수·자리·앞뒤 낱말·태그 앞뒤 구두점."""
    toks = text.split()
    if len(toks) < 2:
        return
    for i, tok in enumerate(toks):
        tg = find_tags(tok)
        if len(tg) != 1:
            continue
        pre, _sep, post = tok.partition(tg[0])
        yield (len(toks), i, tuple(toks[:i]), pre, post, tuple(toks[i + 1:])), tg[0]


def _renamed_tag_pair(a, slot_idx: dict, used: set, order: dict):
    """추가 줄 a와 '태그 한 낱말만 다르고 나머지 글이 같은' 삭제 줄 → (삭제 줄, 옛 태그, 새 태그). 없으면 None.
    같은 자리여야 한다 — DXF는 같은 레이어(where가 같음), PDF는 같은 쪽(같은 줄이면 우선). 낱말 수가 같고 정확히 한 자리만
    다르며, 그 두 낱말이 각각 태그 하나(앞뒤 구두점까지 같음)일 때만. 태그만 있는 줄은 짝짓지 않는다(나머지 글이 없다).
    slot_idx = _tag_slots 열쇠 → [(삭제 줄, 태그)], used = 이미 짝지은 삭제 줄 id, order = 삭제 줄 순서(먼저 나온 것 우선)."""
    exact, page = None, None
    for key, nt in _tag_slots(a.text):
        for r, ot in slot_idx.get(key, ()):
            if id(r) in used or ot == nt:
                continue
            if r.where == a.where:
                if exact is None or order[id(r)] < order[id(exact[0])]:
                    exact = (r, ot, nt)
            elif _page_of(r.where) and _page_of(r.where) == _page_of(a.where):
                if page is None or order[id(r)] < order[id(page[0])]:
                    page = (r, ot, nt)
    return exact or page


def _diff_text_lines(old_lines, new_lines, structured: bool = False) -> list[ChangeItem]:
    """한 비교 단위(문서 전체 또는 페이지 한 쌍)의 줄 diff.
    같은 태그를 가진 삭제+추가 줄은 '변경' 한 건으로 짝짓는다.

    재배치 소음 상쇄: PDF는 같은 내용도 재출력 시 줄 나뉨이 달라져 삭제+추가
    수백 쌍이 생긴다(2026-08-23 실사용 발견). 삭제/추가 줄의 단어 풀을 서로 빼서,
    '실제로 사라진/새로 생긴 단어'를 하나도 안 담은 줄은 줄바꿈·이동으로 보고
    보고하지 않는다. (단어가 우연히 다른 줄에 있는 진짜 삭제는 묻힐 수 있는
    트레이드오프 — 내용 보존이 확인되므로 감수. 페이지 단위로 좁혀 부작용 최소화)"""
    old_counts = Counter(t.text for t in old_lines)
    new_counts = Counter(t.text for t in new_lines)
    removed = _excess_instances(old_lines, old_counts, new_counts)
    added = _excess_instances(new_lines, new_counts, old_counts)
    # 부록 조항 번호('A-3'·'A20.3')는 이 비교 단위에서 번호가 이어질 때만 이름표 — 태그('A-3')로 짝짓지 않는다 (검토68 D1·D2)
    _fams = _seq_families(old_lines, new_lines)

    def _fam(text):
        m = _SEQ_HEAD.match(text or "")
        return m if m and (m.group(1) or m.group(3)) in _fams else None

    def _tg(text):
        m = _fam(text)
        if not m:
            return _tag_of(text)
        head = "".join(m.group(0).split()).rstrip(".")
        tags = [x for x in find_tags(text) if x.rstrip(".") != head]
        return tags[0] if tags else None

    def _lab(text):
        m = _fam(text)
        return "".join(m.group(0).split()).upper() if m else _line_label(text)

    def _isnum(text) -> bool:
        return bool(_fam(text)) or bool(_NUMERIC_LABEL.match(text or ""))

    def _rest(text) -> str:
        m = _fam(text)
        return " ".join(text[m.end():].split()) if m else _after_label(text)

    # 항목 번호만 바뀐 줄('3.1.2 필름 폭' → '3.1.3 필름 폭')은 재부여 — 변경이 아니다
    # (2026-09-06 블라인드 2차 31·37)
    def _renum(t) -> bool:
        # 나머지 글이 단위 낱말 하나뿐이면('5.5 kW'→'7.5 kW') 번호가 아니라 값이다 — 재부여로 버려 줄 넘김 사양 변경이
        # '다시 저장만'이 되고 메일에서도 빠졌다 (검토69 C D10)
        return bool(_lab(t.text)) and _isnum(t.text) and not _UNIT_ONLY.match(_rest(t.text))
    rest_a = Counter(_rest(t.text) for t in added if _renum(t))
    drop_r, drop_a = set(), set()
    for t in removed:
        k = _rest(t.text)
        if _renum(t) and k and rest_a.get(k, 0) > 0:
            rest_a[k] -= 1
            drop_r.add(id(t))
            for a in added:
                if id(a) not in drop_a and _renum(a) and _rest(a.text) == k:
                    drop_a.add(id(a)); break
    removed = [t for t in removed if id(t) not in drop_r]
    added = [t for t in added if id(t) not in drop_a]
    # OCR 글줄끼리는 혼동 문자(O/0·I/1·S/5·B/8)와 구두점을 지워 같으면 같은 줄 — 재스캔의 기울기·밝기 차이가
    # 매번 글자 변경·Rev 미갱신 경고를 내던 것 (리뷰12 중간-B)
    if any(_is_ocr(t.where) for t in removed) and any(_is_ocr(t.where) for t in added):
        from watcher.ocr import normalize
        pool: dict = {}
        for a in added:
            if _is_ocr(a.where):
                pool.setdefault(normalize(a.text), []).append(a)
        drop_r2, drop_a2 = set(), set()
        for r in removed:
            if not _is_ocr(r.where):
                continue
            k = normalize(r.text)
            if k and pool.get(k):
                a = pool[k].pop(0)
                drop_r2.add(id(r)); drop_a2.add(id(a))
        # 유사도 짝짓기는 쓰지 않는다 — 0.85 규칙이 M12x40→45·8EA→6EA·체결→용접 같은 진짜 변경을 삼켰다
        # (리뷰13 치명-2). 흔들림은 혼동 문자 정규화로만 흡수한다

        # 짝이 없는 짧은 OCR 조각(정규화 8자 이하, 숫자 없거나 한글이 절반 이상)은 그림을 글자로 읽은 잡음으로
        # 본다 — 재스캔마다 생겼다 사라지는 '이 조 리 도'·'커 0 프' 같은 조각. 숫자·긴 줄은 변경으로 남긴다
        def _noise(t) -> bool:
            # '이 조 리 도'·'• 커 0 프'처럼 한 글자씩 끊긴 조각만 — 토큰이 모두 2자 이하이고 전체 8자 이하.
            # '승인'·'폐기'는 한 토큰이라 2자 규칙에 걸리므로 낱말 하나짜리는 남긴다 (리뷰13 낮음-4)
            k = normalize(t.text)
            if not _is_ocr(t.where) or len(k) > 8:
                return False
            toks = [x for x in str(t.text).split() if normalize(x)]
            return len(toks) >= 2 and all(len(normalize(x)) <= 2 for x in toks)
        removed = [t for t in removed if id(t) not in drop_r2 and not _noise(t)]
        added = [t for t in added if id(t) not in drop_a2 and not _noise(t)]
    # 'SHEET 1 OF 4' → 'SHEET 1 OF 3' — 쪽수가 바뀌면 전 페이지가 함께 바뀌는 줄. 양쪽에 다 있으면
    # 재부여로 본다 (2026-09-06 사용성 4차 ④-3: 2쪽 지운 도면이 글자 변경 3줄로)
    tot_r = {_SHEET_OF.match(t.text).group(1) for t in removed if _SHEET_OF.match(t.text)}
    tot_a = {_SHEET_OF.match(t.text).group(1) for t in added if _SHEET_OF.match(t.text)}
    if tot_r and tot_a and tot_r != tot_a:            # 전체 쪽수(m)가 바뀐 경우만 — 같은 쪽수에서 번호만 바뀌면 진짜 변경
        removed = [t for t in removed if not _SHEET_OF.match(t.text)]
        added = [t for t in added if not _SHEET_OF.match(t.text)]

    # 태그 단위 짝짓기를 낱말 상쇄보다 **먼저** 한다 — 두 줄 사이에서 값이 맞바뀌면
    # (M-101 5.5kW ↔ M-102 7.5kW) 낱말 집합은 같아 상쇄에서 전부 사라지고 "내용 변경
    # 없음"이 됐다 (검토19 감지 ①). 재출력 줄바꿈 조각(태그 없는 짧은 줄로 갈라진 낱말)은
    # 여전히 상쇄에 맡긴다: 달라진 낱말이 전부 태그 없는 조각에서 나오면 짝짓지 않는다
    tag_pairs: list = []
    if removed and added:
        rm_by_tag0: dict = {}
        for t in removed:
            tag = _tg(t.text)
            if tag:
                rm_by_tag0.setdefault(tag, []).append(t)
        frag_ad_lines = [t.text.split() for t in added if not _tg(t.text)]
        frag_rm_lines = [t.text.split() for t in removed if not _tg(t.text)]

        def _covered(tok, frags, base_toks) -> bool:
            # 줄바꿈 조각으로 보려면 그 조각 줄의 **모든** 낱말이 짝 후보 줄의 낱말이어야 한다 —
            # 'SPARE MOTOR 5.5kW' 같은 남의 줄에 낱말이 있다고 조각으로 봐, 태그 줄과
            # 비태그 줄 사이의 값 맞바꿈이 "변경 없음"이 됐다 (검토19 2차 감지 N3)
            return any(tok in fl and all(x in base_toks for x in fl) for fl in frags)
        used_r0: set = set()
        used_a0: set = set()
        from difflib import SequenceMatcher as _SM0
        for a in added:
            tag = _tg(a.text)
            _c0 = [o_ for o_ in (rm_by_tag0.get(tag) or []) if id(o_) not in used_r0] if tag else []
            if not _c0:
                continue
            # 같은 태그 줄이 여럿이면 가장 닮은 옛 줄과 — 첫 줄과만 짝지어 'MOTOR 5.5kW → CABLE 6SQ'처럼 엇갈렸다 (검토64 C-F2)
            o = max(_c0, key=lambda o_: _SM0(None, o_.text, a.text).ratio())
            if " ".join(o.text.split()) == " ".join(a.text.split()):
                continue
            o_toks, a_toks = o.text.split(), a.text.split()
            o_only = [x for x in o_toks if x not in a_toks]
            a_only = [x for x in a_toks if x not in o_toks]
            wrap_noise = (all(_covered(x, frag_ad_lines, o_toks) for x in o_only)
                          and all(_covered(x, frag_rm_lines, a_toks) for x in a_only))
            if wrap_noise:
                continue
            used_r0.add(id(o))
            used_a0.add(id(a))
            tag_pairs.append(ChangeItem("TEXT_CHANGED", tag, o.text, a.text, a.where))
        removed = [t for t in removed if id(t) not in used_r0]
        added = [t for t in added if id(t) not in used_a0]

    rm_tokens = Counter(tok for t in removed for tok in t.text.split())
    ad_tokens = Counter(tok for t in added for tok in t.text.split())
    real_rm = rm_tokens - ad_tokens
    real_ad = ad_tokens - rm_tokens
    # 문단 끝에 덧붙인 수정("…기준)" → "…기준) ※ 고객 요청…")은 삭제 줄의 낱말이
    # 전부 추가 줄에 들어 있어 '줄바꿈 소음'으로 버려지고 TEXT_ADDED만 남았다
    # (2026-09-03 검토: 사양서·계약서). 실제 낱말 증감이 있는 쌍 가운데 접두/유사한
    # 삭제+추가는 '변경' 한 건으로 짝짓는다. 순수 재배치(양쪽 다 새 낱말 없음)는 제외
    pre: list = list(tag_pairs)
    # 줄 수가 같으면 나눔·합침이 아니다 — 두 문단 사이 값 맞바꿈('모터 5.5kW/펌프 7.5kW' → 반대)·낱말 순서 바꿈('밸브 열기 후 펌프
    # 정지' → '펌프 정지 후 밸브 열기')까지 '나눔·합침만'이라 단언하고 삼켰다 (검토63 B-F4) — 그때는 아래 짝짓기로
    if structured and removed and added and len(removed) != len(added) \
            and Counter(tok for t in removed for tok in t.text.split()) \
            == Counter(tok for t in added for tok in t.text.split()):
        # 낱말이 하나도 안 바뀐 문단 나눔·합침 — 삭제+추가로 늘어놓으면 소음이고(검토59 F1), 비워 두면 '다시 저장되기만'이라
        # 거짓 단언했다(검토61 D07). 한 줄 참고로
        pre.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                              (f"{REFLOW_NOTE} — 문단 {len(removed)}개 → {len(added)}개, 낱말은 그대로입니다"
                               if len(removed) != len(added) else
                               "문단 나눔·합침만 바뀜 — 띄어쓰기·줄 나눔만 다르고 낱말은 그대로입니다"),
                              added[0].where))
        removed, added = [], []
    if removed and added and len(removed) * len(added) <= 40000:
        from difflib import SequenceMatcher
        used_r: set = set()
        used_a: set = set()
        # 가장 닮은 짝부터 배정한다 — 삭제 줄을 순서대로 돌며 각자 best를 먼저 집으면, 부품표에서 'PUMP' 행을 지우고 번호를
        # 다시 매긴 날 '5 PUMP'가 '5 VALVE'(0.78)를 가져가 더 닮은 '6 VALVE'(0.96)가 짝을 잃고 'PUMP→VALVE 변경 + VALVE
        # 삭제'가 됐다 (검토62 A-B). 반대 방향은 맞게 나와 비대칭이었다
        _cands: list = []
        # 워드·한글에서 같은 번호 조항('1.3')이 지운 쪽과 더한 쪽에 하나씩만 남았으면 — 번호만 바뀐 재부여 줄은 위에서 이미
        # 빠졌으니 — 그 조항 문장을 통째로 바꾼 것이다. 변경 추적으로 '엄격한 쪽을 따른다' → '도면이 우선한다'를 바꾼 날 문장이
        # 거의 안 닮아 '글자 추가 + 글자 삭제'로 갈라졌다 (고정 벤치마크 doc68 D22). 숫자 든 번호 이름표만(글머리표 '•'는 아님)
        _one_lab: set = set()
        if structured:
            _rl = Counter(_lab(t.text) for t in removed if not _tg(t.text))
            _al = Counter(_lab(t.text) for t in added if not _tg(t.text))
            _one_lab = {lb for lb in _rl if lb and any(ch.isdigit() for ch in lb) and _rl[lb] == 1 and _al.get(lb) == 1}

        def _better_rest(r, a) -> bool:
            # 같은 번호라도 다른 삭제 줄이 그 추가 줄의 글과 더 닮았으면(0.6 이상) 강제 짝을 짓지 않는다 — 1.3을 지우고 1.4가
            # 1.3이 되며 '2년→3년'으로 고친 날 무관한 옛 1.3과 짝지어져 2년→3년이 안 보였다 (검토69 B C2)
            ra = _rest(a.text)
            return any(o is not r and not _tg(o.text) and SequenceMatcher(None, _rest(o.text), ra).ratio() >= 0.6
                       for o in removed)
        for ri, r in enumerate(removed):
            if _tg(r.text):
                continue
            r_real = any(tok in real_rm for tok in r.text.split())
            r_label = _lab(r.text)
            for ai, a in enumerate(added):
                if _tg(a.text):
                    continue
                if not (structured or r_real or any(tok in real_ad for tok in a.text.split())):
                    continue
                shorter, longer = sorted((len(r.text), len(a.text)))
                if r_label and r_label == _lab(a.text) and (
                        not _isnum(r.text) or SequenceMatcher(None, _rest(r.text), _rest(a.text)).ratio() >= 0.5
                        or (r_label in _one_lab and not _better_rest(r, a))):
                    ratio = 1.0                     # "4. 출하 일정은 …" ↔ "4. 출하 일정은 …" 같은 항목;
                    # '종합 판정: 합격' → '종합 판정: 재검사'는 값이 통째로 바뀌어도 그 항목의 변경
                elif (a.text.startswith(r.text) or r.text.startswith(a.text)) \
                        and shorter >= 0.6 * longer:   # 재출력 줄바꿈 조각은 접두가 아니다
                    ratio = 1.0
                else:
                    ratio = SequenceMatcher(None, r.text, a.text).ratio()
                if ratio >= 0.75:
                    _cands.append((-ratio, ri, ai))
        _got = []
        for _nr, ri, ai in sorted(_cands):
            r, a = removed[ri], added[ai]
            if id(r) in used_r or id(a) in used_a:
                continue
            used_r.add(id(r))
            used_a.add(id(a))
            _got.append((ri, r, a))
        for _ri, r, a in sorted(_got, key=lambda x: x[0]):
            pre.append(ChangeItem("TEXT_CHANGED", r.text[:30], r.text, a.text, a.where))
        removed = [t for t in removed if id(t) not in used_r]
        added = [t for t in added if id(t) not in used_a]
    # 띄어쓰기만 바뀐 짝('기초 공사' → '기초공사')은 글자 변경이 아니라 참고 한 줄 — 일반 글자 변경 + 'Rev 미갱신' 근거가
    # 됐다 (검토68 D6). 숫자 사이 띄어쓰기('1 50' → '150')는 값이 바뀐 것이라 그대로 둔다
    _sp = [i for i in pre if i.kind == "TEXT_CHANGED" and _space_only(i.old, i.new)]
    if _sp:
        pre = [i for i in pre if not any(i is x for x in _sp)]

        def _cut(s):
            s = " ".join(str(s or "").split())
            return s if len(s) <= 60 else s[:59] + "…"
        pre.append(ChangeItem("CHECK_SKIPPED", "참고", None,
                              f"띄어쓰기만 바뀜 — '{_cut(_sp[0].old)}' → '{_cut(_sp[0].new)}'"
                              + (f" 외 {len(_sp) - 1}곳" if len(_sp) > 1 else "") + " (글자는 그대로입니다)",
                              _sp[0].where))
    if not structured:
        _rm_all, _ad_all = list(removed), list(added)
        removed = [t for t in removed if any(tok in real_rm for tok in t.text.split())]
        rm_tags = {_tg(t.text) for t in removed if _tg(t.text)}
        added = [t for t in added if any(tok in real_ad for tok in t.text.split())
                 or (_tg(t.text) and _tg(t.text) in rm_tags)]
        # 줄 끝·앞에 덧붙인 수정('320' → '320 (A/B) 100%')은 옛 줄의 낱말이 전부 새 줄에 있어 줄바꿈 소음으로 버려져
        # '글자 추가'만 남고 옛 값이 사라졌다. 덧붙인 낱말이 다른 삭제 줄의 낱말과 상쇄되면 변경이 통째로 사라졌다
        # (검토62 B1·B2). 같은 쪽에서 버려진 옛 줄을 그대로 품고 늘어난 새 줄이면 '변경'으로 짝짓는다 — 늘어난 부분이
        # 다른 옛 줄 자체면(재출력 줄 합침) 짝짓지 않는다
        _kept_r = {id(t) for t in removed}
        _drop_r = [t for t in _rm_all if id(t) not in _kept_r and len(t.text.strip()) >= 2]
        _used: set = set()
        _pair_ad: set = set()
        for ad in _ad_all:
            best = None
            for r in _drop_r:
                if id(r) in _used or _page_of(r.where) != _page_of(ad.where):
                    continue
                rt, at = r.text.strip(), ad.text.strip()
                if at.startswith(rt + " "):
                    extra = at[len(rt):].strip()
                elif at.endswith(" " + rt):
                    extra = at[:-len(rt)].strip()
                else:
                    continue
                if any(o is not r and o.text.strip() and o.text.strip() in extra for o in _rm_all):
                    continue
                # 늘어난 낱말이 전부 다른 버려진 옛 줄(줄바꿈 조각)에서 왔으면 재출력 줄 다시 접힘이다 — 'NOTE 1 … 별도' +
                # '표기가 없는 한 공차는'이 'NOTE 1 … 별도 표기가 없는 한'으로 접힌 PDF에 거짓 글자 변경·Rev 미갱신이 났다 (검토63 B-F1)
                _pool = Counter(tok for o in _drop_r if o is not r for tok in o.text.split())
                if not (Counter(extra.split()) - _pool):
                    continue
                if best is None or len(rt) > len(best.text.strip()):
                    best = r
            if best is not None:
                _used.add(id(best))
                _pair_ad.add(id(ad))
                pre.append(ChangeItem("TEXT_CHANGED", best.text[:30], best.text, ad.text, ad.where))
        added = [t for t in added if id(t) not in _pair_ad]
    # 같은 자리(같은 페이지)에 짧은 줄 하나가 사라지고 하나가 생겼으면 그 값의 변경 —
    # 도면 치수 '320' → '340' (2026-09-06 블라인드 2차 44)
    if len(removed) == 1 and len(added) == 1 and len(removed[0].text) <= 12 and len(added[0].text) <= 12 \
            and _page_of(removed[0].where) == _page_of(added[0].where) \
            and not _tg(removed[0].text) and not _tg(added[0].text):
        pre.append(ChangeItem("TEXT_CHANGED", removed[0].text[:30], removed[0].text, added[0].text, added[0].where))
        removed, added = [], []

    items = pre
    _mv = _moved_labelled_lines(old_lines, new_lines, swaps=structured)
    items += _mv
    # 이름표 문단 이동을 '문단 순서 N개'로 이미 요약했으면 같은 이동을 다시 세지 않는다 — 항목이 두 번 나왔다 (검토64 C-F3)
    if structured and not any(str(i.key) == "문단 순서" for i in _mv):
        items += _moved_paragraphs(old_lines, new_lines, {str(i.key) for i in _mv})
    paired: set = set()
    removed_by_tag = {}
    for t in removed:
        tag = _tg(t.text)
        if tag and tag not in removed_by_tag:
            removed_by_tag[tag] = t
    # 태그 개명('MC-21 GMC-32 220VAC' → 'MC-23 GMC-32 220VAC') — 같은 자리에서 태그 한 낱말만 바뀌고 나머지 글이 그대로면
    # '변경' 한 건이다. 태그가 달라 위 짝짓기에 안 걸려 '추가 1 + 삭제 1'로 쪼개졌다 (벤치 dxf68 A03·D04·E06·G03, pdf68 B07·B17).
    # 나머지 글까지 다르면(한 기기를 지우고 다른 기기를 넣음) 그대로 추가·삭제로 둔다
    renamed: dict = {}
    _same_tag = {id(t) for t in added if _tg(t.text) and _tg(t.text) in removed_by_tag}
    _rm_used: set = {id(removed_by_tag[_tg(t.text)]) for t in added if id(t) in _same_tag}
    # 태그 뺀 나머지 글을 열쇠로 한 사전 — 삭제 줄 전부와 견주면 태그 3,000줄 일괄 재부여가 0.2초→23초였다 (검토69 성능 b)
    _slot_idx: dict = {}
    _rm_order = {id(r): k for k, r in enumerate(removed)}
    for r in removed:
        if _tg(r.text):
            for key, tag in _tag_slots(r.text):
                _slot_idx.setdefault(key, []).append((r, tag))
    for t in added:
        if id(t) in _same_tag:
            continue
        pick = _renamed_tag_pair(t, _slot_idx, _rm_used, _rm_order)
        if pick is not None:
            _rm_used.add(id(pick[0]))
            renamed[id(t)] = pick
    for t in added:
        tag = _tg(t.text)
        if id(t) in renamed:
            o, old_tag, new_tag = renamed[id(t)]
            paired.add(o)
            items.append(ChangeItem("TEXT_CHANGED", old_tag, o.text, t.text, t.where))
        elif tag and tag in removed_by_tag and removed_by_tag[tag] not in paired:
            o = removed_by_tag[tag]
            paired.add(o)
            items.append(ChangeItem("TEXT_CHANGED", tag, o.text, t.text, t.where))
        else:
            items.append(ChangeItem("TEXT_ADDED", tag or t.text[:30], None, t.text, t.where))
    for t in removed:
        if t not in paired:
            key = _tg(t.text) or t.text[:30]
            items.append(ChangeItem("TEXT_REMOVED", key, t.text, None, t.where))
    return items


def _group_repeats(items: list[ChangeItem], page_count: int = 0) -> list[ChangeItem]:
    """같은 텍스트의 추가/삭제 반복을 1건으로 묶는다 ('외 N곳' 표기).
    페이지마다 반복되는 표제란 라벨·회사명이 페이지 수 변화로 수십 건씩
    나열되던 소음 제거 (2026-08-23 실사용 발견: 331건 → 고유 121종).

    페이지 절반 이상에서 반복된 변경은 '전 페이지 공통'으로 표시한다 —
    표제란·테두리 양식 변경이 회로 변경과 섞여 보고서를 도배하는 것 구분용."""
    order: list = []          # 첫 등장 순서의 (그룹키 또는 원본 항목)
    first: dict[tuple, ChangeItem] = {}
    counts: Counter = Counter()
    for i in items:
        if i.kind in ("TEXT_ADDED", "TEXT_REMOVED", "TEXT_CHANGED"):
            gkey = (i.kind, i.old, i.new)
            counts[gkey] += 1
            if gkey not in first:
                first[gkey] = i
                order.append(gkey)
        else:
            order.append(i)
    out: list[ChangeItem] = []
    for entry in order:
        if isinstance(entry, ChangeItem):
            out.append(entry)
            continue
        i, n = first[entry], counts[entry]
        where = i.where if n == 1 else f"{i.where} 외 {n - 1}곳"
        if page_count >= 4 and n >= (page_count + 1) // 2:
            where += " — 전 페이지 공통(표제란·양식 변경 가능성)"
        out.append(ChangeItem(i.kind, i.key, i.old, i.new, where))
    return out


_REORDER_NOTE = re.compile(r"^행 순서만 바뀜 — (\d+)행 자리 바뀜")


# 표제란 **칸 한 줄**만 — 라벨 + 콜론 + 짧은 값 하나로 끝나는 줄. 'REVISION NOTE: …'·'DATE OF TEST: …' 같은
# 본문 문장까지 걸러 변경을 삼켰다 (검토21 재검증 N1, 원칙 5)
_TITLE_LINE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?|리비전|DATE|일자)"
    r"\s*[:：]\s*\S{1,24}\s*$",
    re.IGNORECASE)
_PAGE_OF = re.compile(r"(\d+)페이지")


def _title_field_line(text: str) -> bool:
    """표제란 칸 한 줄인가 — 콜론 꼴(_TITLE_LINE)에 더해 칸표 출력의 콜론 없는 'REV B'·'개정 0'·'DATE 2026-10-04'도.
    콜론 없는 줄은 pdf.py가 필드로 읽는 규칙(값 한 토큰·REV는 짧은 값·한글 '개정'은 Rev 꼴)과 같을 때만 — 그 줄이 본문 글자
    변경으로 남아 'Rev만 갱신'을 놓치고 REV·DATE가 두 번 나왔다 (검토68 B3)."""
    if _TITLE_LINE.match(text):
        return True
    try:
        from watcher.extract.pdf import _FIELD_NOCOLON_RE, _KO_REV, _SHORT_REV, _canon_label, _nocolon_value_ok
    except Exception:
        return False
    # 한글 '개정: A' — pdf.py가 값이 Rev 꼴(짧은 영숫자·'1차')일 때 표제란 REV로 읽는 바로 그 줄. 세로 띠 표제란을 칸으로 나눈 뒤
    # 이 줄이 본문 글자 변경으로 남아 'Rev만 갱신'을 놓쳤다 (검토70 B, held69 P15)
    mk = re.match(r"^\s*개정\s*(?:번호)?\s*[:：]\s*(\S+)\s*$", text)
    if mk and (_SHORT_REV.match(mk.group(1)) or _KO_REV.match(mk.group(1))):
        return True
    m = _FIELD_NOCOLON_RE.match(text)
    if not m:
        return False
    canon = _canon_label(m.group(1))
    val = m.group(2).strip()
    if canon not in ("DWG_NO", "PROJECT", "REV", "DATE") or not _nocolon_value_ok(canon, val):
        return False
    if canon == "REV" and re.search(r"[가-힣]", m.group(1)) and not (_SHORT_REV.match(val) or _KO_REV.match(val)):
        return False
    if canon == "DATE" and not re.match(r"^\d{2,4}\s*[-./]\s*\d{1,2}\s*[-./]\s*\d{1,2}$", val):
        return False
    return True


def _field_page(doc: Document):
    """표제란 필드가 놓인 쪽 번호 (PDF 세트) — 없으면 None."""
    for f in (doc.fields or {}).values():
        m = _PAGE_OF.search(str(getattr(f, "where", "") or ""))
        if m:
            return m.group(1)
    return None


def _all_title_pairs(text: str) -> bool:
    """줄 전체가 표제란 '라벨: 값'들뿐인가 — 'DOC NO: X  REV: A  DATE: d'. 한 라벨 줄만 거르던 필터가 이 줄을
    남겨, 일자만 고친 사양서가 '글자 변경'으로 한 번 더 잡혀 거짓 'Rev 미갱신' (검토41 S2 재채점 P12·P13)."""
    try:
        from watcher.extract.pdf import _MULTI_FIELD_RE, _canon_label
    except Exception:
        return False
    pairs = list(_MULTI_FIELD_RE.finditer(text))
    if len(pairs) < 2 or not all(_canon_label(m.group(1)) for m in pairs):
        return False
    rest = _MULTI_FIELD_RE.sub(" ", text)
    return not rest.strip()


def _drop_formula_cache_noise(old: Document, new: Document, items: list) -> list:
    """두 판 모두 수식인 칸의 '계산값'만 달라진 것은 저장한 프로그램의 차이다 — openpyxl·xlsxwriter로 만든 BOM을 엑셀에서 열고
    저장만 해도 '금액 =E2*G2 → 1,200,000'·'0 → 1,200,000'이 값 변경 3건으로 나가 진짜 변경이 머리 요약에서 밀렸다 (검토66 C3).
    계산값이 생기거나 사라진 칸, 그리고 그 행에서 바뀐 칸이 모두 수식 칸뿐인 행(입력 칸은 그대로)만 뺀다 — 입력 칸이 바뀐 행의
    금액 변화는 그대로 보인다."""
    of, nf = getattr(old, "formulas", None), getattr(new, "formulas", None)
    if not of or not nf:
        return items

    def fcols(rec) -> set:
        return set(rec[2]) if rec and len(rec) > 2 and rec[2] else set()

    def ftext(rec, col):
        return (rec[3] or {}).get(col) if rec and len(rec) > 3 and isinstance(rec[3], dict) else None

    def same_formula(rk, col) -> bool:
        a, b = ftext(of.get(rk), col), ftext(nf.get(rk), col)
        return bool(a and b and (a == b or _same_formula(a, b)))
    by_row: dict = {}
    for i in items:
        if i.kind == "ROW_CHANGED":
            rk, _, col = str(i.key).rpartition(".")
            by_row.setdefault(rk, []).append(col)
    def derived_cell(i) -> bool:
        rk, _, col = str(i.key).rpartition(".")
        return col in (fcols(of.get(rk)) & fcols(nf.get(rk))) and same_formula(rk, col)
    # 문서 안 어디든 입력 칸이 바뀌었거나 행이 늘고 줄었으면 수식 칸의 계산값 변화(합계·부가세·총액 행)는 그 결과다 —
    # 저장 프로그램 탓으로 지우면 단가를 바꾼 발주서에서 합계 행 변경이 사라졌다 (검토68 C1). 0 캐시가 채워진 것은 그래도 뺀다
    real_input = any(i.kind in ("ROW_ADDED", "ROW_REMOVED") or (i.kind == "ROW_CHANGED" and not derived_cell(i))
                     for i in items)

    def zero_doc(doc, fm) -> bool:
        """수식 칸 계산값이 모두 0·빈칸인 판 — 계산 안 하는 도구(xlsxwriter 등)가 저장한 파일."""
        seen: Counter = Counter()
        vals = []
        for r in getattr(doc, "rows", None) or []:
            seen[r.key] += 1
            rec = fm.get(r.key if seen[r.key] == 1 else f"{r.key}#{seen[r.key]}")
            vals += [str((r.values or {}).get(c) or "").strip() for c in fcols(rec)]
        return bool(vals) and all(v in ("0", "") for v in vals)
    zero_old, zero_new = (zero_doc(old, of), zero_doc(new, nf)) if real_input else (False, False)
    drop = set()
    for n, i in enumerate(items):
        if i.kind != "ROW_CHANGED":
            continue
        rk, _, col = str(i.key).rpartition(".")
        both = fcols(of.get(rk)) & fcols(nf.get(rk))
        if col not in both or not same_formula(rk, col):
            continue                    # 수식 자체가 바뀐 것(=F2*H2 → =F2*H2*1.1)은 진짜 변경이다
        so, sn = str(i.old or ""), str(i.new or "")
        flip = so.startswith("=") != sn.startswith("=")
        zero_cache = (zero_old and so.strip() in ("0", "")) or (zero_new and sn.strip() in ("0", ""))
        derived_only = (not so.startswith("=") and not sn.startswith("=")
                        and (not real_input or zero_cache)
                        and all(c in both and same_formula(rk, c) for c in by_row.get(rk, [])))
        if flip or derived_only:
            drop.add(n)
    return [i for n, i in enumerate(items) if n not in drop] if drop else items


def _diff_formulas(old: Document, new: Document, seen: list | None = None) -> list[ChangeItem]:
    """표 행의 수식 칸이 줄거나 는 것 — 같은 값의 상수로 덮어쓰면 글자·표가 같아 '내용 변경 없음'이라 단언했다
    (검토61 C49). 두 판 모두 수식 기록이 있고 그 행이 양쪽에 있을 때만(옛 캐시·행 추가/삭제는 말하지 않는다)."""
    of, nf = getattr(old, "formulas", None), getattr(new, "formulas", None)
    if of is None or nf is None:
        return []

    def keys(rows) -> set:
        seen: Counter = Counter()
        out = set()
        for r in rows:
            seen[r.key] += 1
            out.add(r.key if seen[r.key] == 1 else f"{r.key}#{seen[r.key]}")
        return out
    both = keys(old.rows) & keys(new.rows)
    # 계산값 없는 수식은 칸에 수식 글자가 보여 행 변경('=SUM(…) → 3100')이 이미 말한다 — 겹쳐 내지 않는다
    shown = {str(i.key).rpartition(".")[0] for i in (seen or [])
             if i.kind == "ROW_CHANGED" and (str(i.old or "").startswith("=") or str(i.new or "").startswith("="))}
    items = []
    for k in sorted(both):
        if _POS_KEY.match(str(k)):
            continue        # 위치 키(행 번호)는 행 삽입에 밀린다 — 밀린 행이 '값이 수식으로' 거짓 항목이 됐다 (검토63 B-F6)
        o = int((of.get(k) or [0])[0])
        n = int((nf.get(k) or [0])[0])
        if o == n or k in shown:
            continue
        rec = nf.get(k) or of.get(k) or [0, ""]
        where = rec[1]
        cols = next((list(r_[2]) for r_ in (of.get(k), nf.get(k)) if r_ and len(r_) > 2 and r_[2]), [])
        if n < o:
            new_s = f"수식 칸 {n}개 — 수식이 값(상수)으로 바뀜, 계산이 더는 따라가지 않습니다"
        else:
            new_s = f"수식 칸 {n}개 — 값(상수)이 수식으로 바뀜"
        name = f"{k} {'·'.join(cols)} 수식" if cols else f"{k} 수식"
        items.append(ChangeItem("TEXT_CHANGED", name, f"수식 칸 {o}개", new_s, where))
    return items


def _drop_shifted_fields(old: Document, new: Document, items: list) -> list:
    """세트 PDF 앞에 쪽이 끼거나 빠지면 '첫 쪽 표제란'이 다른 도면의 것이 된다 — 표지를 앞에 넣었더니
    'DWG_NO E-201 → E-200 값 변경'이 났다 (검토61 B47). 글자로 확실한 쪽 대응에서 옛 필드 쪽이 새 필드 쪽과
    짝이 아니면 그 표제란 칸 비교는 빼고 쪽끼리 본문 비교(표제란 줄도 본문에 있다)에 맡긴다."""
    if getattr(new, "doc_type", "") != "pdf" or not any(i.kind == "FIELD_CHANGED" for i in items):
        return items
    anc = page_anchors(old, new)
    if not anc:
        return items

    def pg(f):
        m = _PAGE_OF.search(str(getattr(f, "where", "") or ""))
        return int(m.group(1)) if m else None
    out = []
    for i in items:
        if i.kind == "FIELD_CHANGED" and str(i.key).partition("#")[0] in _TB_BASES:
            po, pn = pg(old.fields.get(i.key)), pg(new.fields.get(i.key))
            if po and pn and ((po in anc and anc[po] != pn) or (po not in anc and pn in anc.values())):
                continue
        out.append(i)
    return out


_REV_IN_LINE = re.compile(r"(?i)\bREV(?:ISION)?\.?\s*(?:NO\.?)?\s*[:：]?\s*([A-Z0-9]{1,3})\b")


_REVTABLE_HEAD = re.compile(r"(?i)^\s*(?:REV(?:ISION)?\.?|개정)\s+(?:DATE|일자)\s+(?:DESCRIPTION|DESC\.?|내용|사유)\b")
# 개정표 머리를 낱말 집합으로 — 'REV | DESCRIPTION | DATE'(설명이 날짜 앞)·'NO. | DATE | REVISION'(번호 칸 + 개정 내용 칸) 순서를
# 몰라 새 행이 '글자 추가'로 남고 '표제란 Rev ≠ 개정표'를 놓쳤다 (검토70 B, held69 P11·P12). 머리 줄의 **모든** 낱말이 개정표 칸
# 이름이고, 첫 칸이 개정 기호 칸, 날짜 칸·내용 칸이 있으며 'REV/REVISION/개정' 낱말이 어딘가 있을 때만
_RH_SYM = {"REV", "REVNO", "REVISION", "NO", "개정", "개정번호", "차수", "판"}
_RH_DATE = {"DATE", "일자", "날짜", "개정일", "개정일자"}
_RH_DESC = {"DESCRIPTION", "DESC", "REVISION", "내용", "개정내용", "사유", "REMARKS", "REMARK"}
_RH_OTHER = {"BY", "APPR", "APP", "APPD", "APPROVED", "CHK", "CHKD", "CHECKED", "DRN", "DRAWN", "DSN", "DESIGNED",
             "작성", "검토", "승인", "확인", "담당", "SIGN", "서명", "ECN", "ECO"}
_RH_DATE_RE = r"(?<![\d./-])(?:\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{1,2}[-./]\d{1,2}[-./]\d{4})(?![\d./-])"


def _revtable_cols(text: str) -> list | None:
    """개정표 머리 줄이면 칸 역할 순서(['SYM', 'DESC', 'DATE', …]), 아니면 None."""
    toks = [re.sub(r"[.:：'’]", "", t).upper() for t in str(text or "").split()]
    toks = [t for t in toks if t]
    if not 3 <= len(toks) <= 8:
        return None
    if len(toks) >= 2 and toks[0] in ("REV", "REVISION") and toks[1] == "NO":
        toks = ["REVNO"] + toks[2:]
    roles = []
    for k, t in enumerate(toks):
        if k == 0:
            if t not in _RH_SYM:
                return None
            roles.append("SYM")
        elif t in _RH_DATE:
            roles.append("DATE")
        elif t in _RH_DESC:
            roles.append("DESC")
        elif t in _RH_OTHER:
            roles.append("OTHER")
        else:
            return None
    if roles.count("DATE") != 1 or "DESC" not in roles \
            or not any(t in ("REV", "REVNO", "REVISION", "개정", "개정번호", "개정내용") for t in toks):
        return None
    return roles


def _revtable_row(text: str, roles: list):
    """개정표 행 '(기호) … (날짜) …' → (기호, 날짜, 나머지). 날짜 칸이 기호 바로 뒤 칸이면 날짜가 기호 바로 뒤에, 내용 칸 뒤면
    기호와 날짜 사이에 글이 있어야 한다 — 같은 칸 순서의 행만 (검토70 B)."""
    m = re.match(r"^\s*([A-Z]|\d{1,2})\s+(.*)$", str(text or ""))
    if not m:
        return None
    sym, rest = m.group(1), m.group(2)
    dates = list(re.finditer(_RH_DATE_RE, rest))
    if len(dates) != 1:
        return None
    d = dates[0]
    if roles.index("DATE") == 1:
        if d.start() != 0:
            return None
    elif not rest[:d.start()].strip():
        return None
    other = " ".join((rest[:d.start()] + " " + rest[d.end():]).split())
    return sym, d.group(0), other


def _pdf_revision_rows(new: Document, items: list) -> list:
    """PDF 개정표에 새로 생긴 행('B 2026-10-10 RE-ISSUE')을 '리비전 행 추가'로 — PDF는 개정표를 따로 읽지 않아 이 줄이
    본문 '글자 추가'로 남아, Rev만 올린 일괄 재출력 다섯 장이 내용이 바뀐 장과 구별되지 않았다 (검토62 D1-1).
    줄 머리가 이번에 올라간 Rev 값이고 바로 뒤가 날짜일 때만."""
    if getattr(new, "doc_type", "") != "pdf":
        return items
    revs = set()
    # 이번에 **올라간** Rev만 — 그대로인 REV 값(숫자 Rev '1')을 넣으면 일정표 줄 '1 2026-11-01 착수 회의' 추가가 개정 행이 되어
    # Rev 미갱신이 꺼졌다 (검토63 B-F3)
    for i in items:
        if i.kind == "FIELD_CHANGED" and i.key == "REV" and str(i.new or "").strip():
            revs.add(str(i.new).strip().upper())
    for i in items:
        if i.kind == "TEXT_CHANGED":
            m = _REV_IN_LINE.search(str(i.new or ""))
            if m and _REV_IN_LINE.search(str(i.old or "")):
                revs.add(m.group(1).upper())
    # 표제란 REV는 그대로인데 개정표에만 새 행('B 2026-10-06 펌프 양정 변경')을 적은 도면 — 그 행이 '글자 추가'로 남아 '표제란 Rev ≠
    # 개정표'를 말할 근거가 없었다 (검토68 B32). 같은 쪽에 개정표 머리('REV DATE …')가 있고 줄 머리가 Rev 꼴(한 글자·두 자리 숫자)일
    # 때만 개정표 행으로 본다.
    # 단 머리 바로 아래(위)에 붙은 행 묶음이 **개정표**일 때만 — 표제란 REV 값이 그 묶음의 행 기호 중에 있고, 새 행 기호가 표제란
    # REV와 같은 꼴(글자·숫자)이며 그보다 뒤일 때. 일정표 줄('2 2026-11-15 FAT TEST', REV A)·송부서 행('C …', 표제 REV A인데 표는
    # B부터)·시운전 차수('2 …', REV 0인데 표는 1부터)가 개정 행이 되어 Rev 미갱신이 꺼지고 거짓 '표제란 ≠ 개정표'가 났다
    # (검토69 r3·B R1·R5·C P21)
    head_rows: dict = {}
    if any(_REVTABLE_HEAD.match(str(t.text or "")) or _revtable_cols(t.text) for t in (new.raw_texts or [])):
        from watcher.scan import rev_key, rev_shape
        title_rev = next((str(f.value).strip().upper() for k, f in (new.fields or {}).items()
                          if field_base(k) == "REV" and str(f.value or "").strip()), "")
        row_re = re.compile(r"^\s*([A-Z]|\d{1,2})\s+\d{4}[-./]\d{1,2}[-./]\d{1,2}\b")
        lines = list(new.raw_texts or [])
        for hi, h in enumerate(lines):
            if not title_rev:
                break
            if _REVTABLE_HEAD.match(str(h.text or "")):
                # 'REV DATE DESCRIPTION' 머리는 예전대로 + 일/월/년 날짜 행도 (adv69 R4·held69 P12와 같은 꼴)
                def parse(s, roles=_revtable_cols(h.text) or ["SYM", "DATE", "DESC"]):
                    mm = row_re.match(s or "")
                    return (mm.group(1), None, None) if mm else _revtable_row(s, roles)
            else:
                roles = _revtable_cols(h.text)
                if not roles:
                    continue

                def parse(s, roles=roles):
                    return _revtable_row(s, roles)
            pg = _page_of(h.where)
            run = []
            for step in (1, -1):              # 머리 아래로 쌓이는 표, 위로 쌓이는 표(ISO)
                k = hi + step
                while 0 <= k < len(lines) and _page_of(lines[k].where) == pg and parse(lines[k].text):
                    run.append(lines[k])
                    k += step
            syms = {parse(t.text)[0].upper() for t in run}
            if title_rev not in syms:
                continue
            for t in run:
                s, d_, rest_ = parse(t.text)
                s = s.upper()
                if rev_shape(s) == rev_shape(title_rev) and rev_key(s) > rev_key(title_rev):
                    head_rows[(pg, " ".join(str(t.text).split()))] = (s, d_, rest_)
    if not revs and not head_rows:
        return items
    pat = re.compile(r"^\s*(" + "|".join(re.escape(r) for r in sorted(revs)) + r")\s+(\d{4}[-./]\d{1,2}[-./]\d{1,2})\b\s*(.*)$", re.I) \
        if revs else None
    any_row = re.compile(r"^\s*([A-Z]|\d{1,2})\s+(\d{4}[-./]\d{1,2}[-./]\d{1,2})\b\s*(.*)$")
    out = []
    for i in items:
        m = None
        hr = None
        if i.kind == "TEXT_ADDED":
            m = pat.match(str(i.new or "")) if pat is not None else None
            if m is None:
                hr = head_rows.get((_page_of(i.where), " ".join(str(i.new or "").split())))
                if hr is not None:
                    m = any_row.match(str(i.new or ""))
                    if m is None and hr[1]:         # 칸 순서가 다른 개정표 행 (검토70 B)
                        out.append(ChangeItem("REVROW_ADDED", hr[0], None,
                                              f"REV {hr[0]} · {hr[1]}" + (f" · {hr[2]}" if hr[2] else ""), i.where))
                        continue
        if m:
            out.append(ChangeItem("REVROW_ADDED", m.group(1).upper(), None,
                                  f"REV {m.group(1).upper()} · {m.group(2)}" + (f" · {m.group(3).strip()}" if m.group(3).strip() else ""),
                                  i.where))
        else:
            out.append(i)
    return out


def diff_documents(old: Document, new: Document) -> list[ChangeItem]:
    _fi = _diff_fields(old, new)
    if getattr(new, "doc_type", "") in ("docx", "hwpx") and getattr(old, "doc_type", "") in ("docx", "hwpx"):
        # 첫 쪽·짝수 쪽·기본 머리말 사본이 **똑같이** 바뀐 것(REV·REV#2·REV#3 모두 A→B)은 한 번의 변경이다 (고정 벤치마크
        # fmt66 W10). 추출에서 같은 줄을 한 번만 읽으면 사본 하나만 고친 날 'REV#2 (없음)→B'·한 사본에서만 지운 줄이 숨었다
        # (검토69 B H1·H2·H4·H5·C W17) — 사본은 모두 읽고, 같은 이름·같은 전후 값의 번호 붙은 칸 변경만 접는다
        _seen_f: set = set()
        _kept: list = []
        for i in _fi:
            k = (field_base(i.key), i.old, i.new)
            if "#" in str(i.key) and k in _seen_f:
                continue
            _seen_f.add(k)
            _kept.append(i)
        _fi = _kept
    items = _drop_shifted_fields(old, new, _fi)
    # 쪽 대응이 밀려 표제란 칸 비교를 뺐으면 그 쪽들의 표제란 줄 변경이 유일한 근거다 — 아래 걸러 내기까지 하면
    # 쪽을 맞바꾸고 Rev를 올린 세트가 아무 말도 없이 'Rev 그대로'가 됐다 (검토62 B4)
    _shifted = len(items) < len(_fi)
    global _HEADERS
    _HEADERS = (getattr(old, "headers", None), getattr(new, "headers", None))    # (검토68 C3)
    try:
        _rows_i = _diff_rows(old.rows, new.rows, "ROW")
    finally:
        _HEADERS = (None, None)
    if getattr(new, "doc_type", "") in ("docx", "hwpx") and getattr(old, "doc_type", "") in ("docx", "hwpx"):
        _rows_i = _space_only_cells(_rows_i)
    items += _rows_i
    items += _diff_rows(old.revision_history, new.revision_history, "REVROW")
    texts = _diff_texts(old, new)
    # 도면 세트 PDF는 표제란 줄을 본문에도 두므로(pdf.py) 표제란이 있는 쪽의 라벨 줄 변경은
    # FIELD_CHANGED와 겹친다 — 글자 쪽을 걸러 한 번만 말한다 (검토21 감지 차단 3)
    # 표지(DOC NO)와 바닥글(REV·DATE)처럼 필드가 여러 쪽에 흩어질 수 있다 — 필드가 놓인 모든 쪽 (검토41 S2 P12)
    pages = {m.group(1) for d in (old, new) for f in (d.fields or {}).values()
             for m in [_PAGE_OF.search(str(getattr(f, "where", "") or ""))] if m}
    # 여러 쪽 문서에서만 — 한 쪽 PDF는 표제란 줄을 본문에 두지 않으므로 걸러낼 것이 없고, 걸러내면
    # 본문의 'REV: C' 같은 줄 변경을 잃는다 (검토21 재검증 N1)
    # 한 쪽짜리도 표제란 줄이 본문에 있다(검토62 B3) — 다만 필드를 낳은 바로 그 줄만 거른다(같은 쪽의 다른 'REV: C' 줄은 남긴다)
    _src_rows = {m.group(1) for d in (old, new) for f in (d.fields or {}).values()
                 for m in [re.search(r"\((\d+페이지 \d+행)\)", str(getattr(f, "where", "") or ""))] if m}
    _multi = len(_pages(old.raw_texts)) > 1 or len(_pages(new.raw_texts)) > 1
    if pages and not _shifted:
        texts = [i for i in texts
                 if not (i.kind in ("TEXT_ADDED", "TEXT_REMOVED", "TEXT_CHANGED")
                         and ((_multi and any(str(i.where or "").startswith(f"{p}페이지") for p in pages)
                               and (_title_field_line(str(i.new or i.old or ""))
                                    or _all_title_pairs(str(i.new or i.old or ""))))
                              or (str(i.where or "") in _src_rows
                                  and (_title_field_line(str(i.new or i.old or ""))
                                       or _all_title_pairs(str(i.new or i.old or ""))))))
                 # 표제란 줄의 '자리 이동'도 — PDF를 다시 뽑아 표제란 글자를 그리는 순서만 바뀌어도 'DWG NO 1행→5행' 이동
                 # 3건과 거짓 Rev 미갱신이 났고, 'Rev만 갱신'을 놓쳤다 (검토66 A1·C4)
                 and not (i.kind == "TEXT_MOVED"
                          and (_title_field_line(str(i.key or "")) or _all_title_pairs(str(i.key or ""))
                               or str(i.old or "") in _src_rows or str(i.new or "") in _src_rows))]
    # 같은 자리로의 '이동'(5행→5행)은 이동이 아니다 (검토66 A1)
    texts = [i for i in texts if not (i.kind == "TEXT_MOVED" and i.old and str(i.old) == str(i.new))]
    # PDF의 글줄 순서는 '그리는 순서'다 — 다른 프로그램으로 다시 뽑기만 해도 이름표 줄이 '3행→9행 문단 이동'이 되어 무변경
    # 재출력이 '오늘 확인할 것'에 올랐다 (검토68 B7). 글자 변경 없이 이동만 남았으면 뺀다 — 자리가 정말 옮겨졌다면 그림 비교가
    # 전/후 사진으로 잡고, 아니면 '내용 변경 없음'으로 조용히 접힌다
    if (getattr(new, "doc_type", "") == "pdf" and getattr(old, "doc_type", "") == "pdf"
            and texts and all(i.kind == "TEXT_MOVED" for i in texts)
            and not any(i.label == RENUM_MOVE_LABEL for i in texts)):   # 번호를 다시 매긴 맞바꿈은 편집이다 (검토70 B M5)
        texts = []
    if _shifted and not any(i.kind == "FIELD_CHANGED" and i.key == "REV" for i in items):
        # 쪽이 밀려 칸 비교를 뺀 세트에서 1쪽 표제란 REV 줄의 올림은 표제란 REV 변경 그 자체다 — 글줄 변경으로만 두면 다음 편집
        # 날의 '후속 편집 유예'·'Rev를 올림' 해소가 그것을 몰라 거짓 'Rev 미갱신'이 났다 (검토63 A-2)
        _nf = (new.fields or {}).get("REV")
        for k, i in enumerate(texts):
            mo, mn = _REV_IN_LINE.search(str(i.old or "")), _REV_IN_LINE.search(str(i.new or ""))
            if (i.kind == "TEXT_CHANGED" and _page_of(i.where) == "1" and mo and mn and _nf
                    and mn.group(1).upper() == str(_nf.value or "").strip().upper() and mo.group(1).upper() != mn.group(1).upper()):
                texts[k] = ChangeItem("FIELD_CHANGED", "REV", mo.group(1), mn.group(1), f"표제란({i.where})")
                break
    items += texts
    items = _pdf_revision_rows(new, items)
    items = _drop_formula_cache_noise(old, new, items)
    items += _diff_formulas(old, new, items)
    if getattr(new, "doc_type", "") in ("dxf", "dwg"):      # DWG는 변환해 DXF로 읽는다 (검토40 A 중간 3)
        items = _fold_moves_into_fields(items)
    # '행 순서만 바뀜 … 내용 변경 없음' 참고는 문서 전체에 다른 변경이 없을 때만 참이다 — 다른 시트의
    # 값 변경·제목 변경이 있으면 그 파일이 통째로 접혔다 (리뷰11 중간-G)
    notes = [i for i in items if i.kind == "CHECK_SKIPPED" and i.key == "참고" and _REORDER_NOTE.match(str(i.new or ""))]
    # 표제 칸·리비전 행이 바뀐 것도 '다른 변경' — 정렬 + Rev 올림이 '순서만 바뀜'으로 통째로 접혔다 (검토53 J 중간 2)
    if notes and any(i.kind in CONTENT_KINDS or i.kind.startswith(("FIELD_", "REVROW_")) for i in items):
        items = [i for i in items if i not in notes]
        for n in notes:
            cnt = _REORDER_NOTE.match(str(n.new)).group(1)
            items.append(ChangeItem("ROW_MOVED", "행 순서", None, f"{cnt}행 자리 바뀜 (값은 위 항목 외 그대로)",
                                    n.where, label="행 순서 재정렬"))
    # 옆으로 놓인 표의 제목 변경은 '표 제목 변경' 한 건이다 — 같은 글자의 TEXT_CHANGED를 겹쳐 내지 않는다 (리뷰11 낮음-N)
    renames = [(i.old.split("·", 1)[1], i.new.split("·", 1)[1]) for i in items
               if i.kind == "SHEET_RENAMED" and "·" in str(i.old or "") and "·" in str(i.new or "")]
    if renames:
        items = [i for i in items if not (i.kind == "TEXT_CHANGED" and any(
            a in str(i.old or "") and b in str(i.new or "") for a, b in renames))]
    # OCR로 읽은 글줄과 글자 쪽 글줄이 대소문자·구두점만 다르면('800x1800'↔'800X1800', 'NOTE:'↔'NOTE.') 변경이 아니다 — OCR이
    # 읽은 차이일 뿐인데 '내용 변경, Rev 미갱신'이 났고 근거는 눈으로 같은 글이었다 (검토52 D 중간 5)
    def _loose(s):
        return re.sub(r"[^0-9a-z가-힣]", "", str(s or "").lower())
    items = [i for i in items if not (i.kind == "TEXT_CHANGED" and "OCR" in str(i.where or "")
                                      and _loose(i.old) == _loose(i.new))]
    return items


TITLE_ZONE = "표제란 자리"       # 표제란 틀 안의 그림 변경 표식 (cli._mark_title_visuals)
_MOVED_TO_FIELD = "본문 글자에서 표제란 칸으로 옮김"
_MOVED_FROM_FIELD = "표제란 칸에서 본문 글자로 옮김"


def _fold_moves_into_fields(items: list[ChangeItem]) -> list[ChangeItem]:
    """표제란을 글자에서 속성 블록으로 바꾸면 도면명이 '글자 삭제' + '칸 새로 생김'으로 두 번 나와, 글자 삭제가
    내용 변경으로 셈해져 거짓 'Rev 미갱신'이 났다 (검토39 P1 중간 1). 값이 같으면 옮긴 것 — 칸 변경 하나로 접는다."""
    def _n(v):
        return " ".join(str(v or "").split()).upper()

    appeared = {_n(i.new): i for i in items if i.kind == "FIELD_CHANGED" and i.old in (None, "") and i.new}
    vanished = {_n(i.old): i for i in items if i.kind == "FIELD_CHANGED" and i.new in (None, "") and i.old}
    drop, relabel = set(), {}
    for i in items:
        if i.kind == "TEXT_REMOVED" and _n(i.old) in appeared and id(appeared[_n(i.old)]) not in relabel:
            drop.add(id(i))
            relabel[id(appeared[_n(i.old)])] = _MOVED_TO_FIELD
        elif i.kind == "TEXT_ADDED" and _n(i.new) in vanished and id(vanished[_n(i.new)]) not in relabel:
            drop.add(id(i))
            relabel[id(vanished[_n(i.new)])] = _MOVED_FROM_FIELD
    if not drop:
        return items
    out = []
    for i in items:
        if id(i) in drop:
            continue
        if id(i) in relabel:
            i = ChangeItem(i.kind, i.key, i.old, i.new, f"{i.where} — {relabel[id(i)]}", i.label)
        out.append(i)
    return out


# 라벨 앞은 낱말 경계 — 'UPDATE'·'RECHECKED' 속 DATE·CHECKED에 걸렸다. 앞에 꾸밈말이 붙은 날짜('DELIVERY DATE'·'DUE DATE'·
# '납기 일자')는 표제 일자가 아니라 **내용**이다 — 발주서 납기 변경이 '일자만 갱신, 확인 대상 아님'으로 접혔다 (검토43 A 차단 1).
# 꾸밈말은 고정 길이 lookbehind 대신 일치 **앞 문맥**으로 본다 — 'DELIVERY  DATE'(두 칸)·'DELIVERY_DATE'·'납품 예정 일자'가
# 빠져나갔고, 한글 앞경계는 '작성일자·발행일자'까지 막아 날짜만 바꾼 재출력이 거짓 'Rev 미갱신'이 됐다 (검토44 A 중간 1·낮음 5)
# 달 이름은 정확한 꼴만 — 'MAYOR 12 2026'이 날짜로 걸렸다 (검토46 A 낮음)
_MON = (r"(?:JAN(?:UARY)?|FEB(?:RUARY)?|MAR(?:CH)?|APR(?:IL)?|MAY|JUNE?|JULY?|AUG(?:UST)?|SEP(?:T|TEMBER)?|OCT(?:OBER)?"
        r"|NOV(?:EMBER)?|DEC(?:EMBER)?)(?![A-Za-z])")
_TITLE_DATE = re.compile(
    r"(?:(?<![A-Za-z])(?:DATE(?:\s+OF\s+(?:ISSUE|DRAWING|PRINT|REVISION|APPROVAL))?|APPROVED|PLOTTED|CHECKED|DRAWN|ISSUED)"   # 'DATE OF ISSUE' (검토46 B Q71)
    r"|(?<![가-힣])(?:(?:작성|발행|개정|출력|승인|검사|발주|검토|설계)\s*일자?|일자))"
    r"\.?\s*[:：]?\s*"
    # '01-SEP-2026'·'SEP 01, 2026' 같은 영문 달 표기도 날짜다 — 재출력이 거짓 'Rev 미갱신'이 됐다 (검토45 B Q33)
    r"(?:\d{2,4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2}\s*일?"
    r"|\d{1,2}[-\s./]?" + _MON + r"[-\s./,]*\d{2,4}"
    r"|" + _MON + r"\.?\s*\d{1,2},?\s*\d{4})", re.I)


def _title_dates(t: str) -> list:
    """표제 일자 일치만 — 앞에 납기·DELIVERY 같은 꾸밈말이 붙은 것은 뺀다."""
    return [m for m in _TITLE_DATE.finditer(t) if not date_qualified(t[:m.start()])]


def _sub_title_dates(t: str, rep: str) -> str:
    out, last = [], 0
    for m in _title_dates(t):
        out.append(t[last:m.start()]); out.append(rep); last = m.end()
    return "".join(out) + t[last:]


def is_title_date_text(i) -> bool:
    """표제 일자 라벨('DATE: 2026-09-01'·'APPROVED 2026-09-01') 뒤 날짜만 바뀐 글줄 — 재출력의 흔적이다. 위쪽 '작성일'이
    DATE 칸을 먼저 차지한 PDF에서 바닥글 DATE만 고친 날 이 줄이 '글자 추가'가 되어 거짓 'Rev 미갱신'이 났다
    (검토42 B 중간 2). 납기·발주 같은 다른 날짜는 내용이다."""
    _g = i.get if isinstance(i, dict) else (lambda k: getattr(i, k, None))   # 저장된 항목(dict)도 — 조용함 판정
    kind = _g("kind") or ""
    o, n = str(_g("old") or ""), str(_g("new") or "")
    if kind == "TEXT_CHANGED":
        return o != n and bool(_title_dates(o)) and _sub_title_dates(o, "#D#") == _sub_title_dates(n, "#D#")
    if kind in ("TEXT_ADDED", "TEXT_REMOVED"):
        t = n if kind == "TEXT_ADDED" else o
        return bool(_title_dates(t)) and not re.sub(r"[\s,;|/·]+", "", _sub_title_dates(t, ""))
    return False


def content_items(items: list[ChangeItem]) -> list[ChangeItem]:
    """'내용' 변경만 (표제란·리비전 블록 제외). Rev 일관성 판단의 기준.
    페이지 전체가 살짝 어긋난 그림 변경(재스캔·기울기)은 근거가 못 된다 (2026-09-06 사용성 5차).
    표제란 틀 안의 그림 변경도 표제란 변경이다 (검토39 P1 중간 1)."""
    # 시트 이름만 바뀐 것은 내용이 아니다 — 'Sheet1→MCC-1'만으로 'Rev 미갱신'이 났다 (검토42 B 중간 4)
    return [i for i in items if i.kind in CONTENT_KINDS and i.kind != "SHEET_RENAMED"
            and i.kind not in ORDER_KINDS
            and not is_title_date_text(i)
            and not (i.kind == "PAGE_VISUAL_CHANGED" and ("전체가 살짝 어긋남" in str(i.where or "")
                                                         or TITLE_ZONE in str(i.where or "")))]
