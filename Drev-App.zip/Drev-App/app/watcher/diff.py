# -*- coding: utf-8 -*-
"""구/신 Document 비교 → ChangeItem 목록. 모든 항목에 근거(old/new/where) 필수."""

from __future__ import annotations

import difflib
import re
from collections import Counter
from dataclasses import dataclass

from watcher.extract.base import Document, find_tags

# TAG 없는 표의 행번호 키 (xlsx.py가 부여; 다중 시트에서는 '시트명!행N')
_POS_KEY = re.compile(r"^(?:[^!]*!)?행\d+")
# 순번 성격의 열: 행이 삽입되면 이후 전부 밀려 '변경'처럼 보이므로 비교에서 제외
_ORDINAL_COL = re.compile(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", re.IGNORECASE)

# kind 종류:
#   FIELD_CHANGED             표제란 값 변경 (REV, DATE 등)
#   ROW_ADDED/REMOVED/CHANGED 표(BOM 등) 행 변경
#   REVROW_ADDED/REMOVED      리비전 블록 행 변경
#   TEXT_CHANGED/ADDED/REMOVED 본문 줄 변경
CONTENT_KINDS = {"ROW_ADDED", "ROW_REMOVED", "ROW_CHANGED",
                 "TEXT_ADDED", "TEXT_REMOVED", "TEXT_CHANGED",
                 "PAGE_ADDED", "PAGE_REMOVED", "PAGE_VISUAL_CHANGED",
                 "COL_RENAMED", "COL_ADDED", "COL_REMOVED", "COL_MOVED", "ROW_MOVED", "TEXT_MOVED", "PAGE_MOVED",
                 "SHEET_ADDED", "SHEET_REMOVED", "SHEET_RENAMED"}


@dataclass(frozen=True)
class ChangeItem:
    kind: str
    key: str
    old: str | None
    new: str | None
    where: str
    label: str | None = None  # 사람용 식별 — 행 변경이면 품명·규격 (2026-08-25 요청)


# 행의 '무슨 부품/품목인지'를 보여줄 열 (우선순위 순). BOM·발주서·자재표 공통 관례
# 라벨 열 묶음 — 묶음마다 값 하나씩, 순서대로 (품번 → 품명 → 규격 → 업체). 구매가 발주를
# 정정하려면 품번·업체가 있어야 하는데 품명·규격 둘만 뽑아 BOM을 다시 열게 했다 (검토22 실용 B1)
_LABEL_GROUPS = (
    ("품번", "자재코드", "자재번호", "부품번호", "부품코드", "품목코드", "코드", "P/N", "PN", "PART NO",
     "PART NUMBER", "PARTNO", "ITEM CODE", "CODE"),
    ("품명", "부품명", "자재명", "명칭", "품목", "DESCRIPTION", "NAME", "PART", "ITEM"),
    ("규격", "SPEC", "MODEL", "형식", "TYPE"),
    ("업체", "제조사", "제조원", "메이커", "구매처", "MAKER", "VENDOR", "MANUFACTURER", "BRAND"),
)
_LABEL_COLS = tuple(w for g in _LABEL_GROUPS for w in g)   # 호환용(다른 곳에서 참조)
_LABEL_SPLIT = re.compile(r"[^A-Z0-9가-힣/]+")


def _col_matches(cu: str, want: str) -> bool:
    """머리글 cu가 라벨 낱말 want를 뜻하는가 — 낱말 단위로. 'PART NO.'→PART NO, 'P/N'→P/N,
    'PART NAME'은 PART(품명)이되 PART NO(품번)는 아니고, 'BARCODE'는 CODE가 아니다
    (재검증 B1: 부분 문자열 일치가 바코드를 품번 자리에 넣었다). 한글은 '업체명'·'제조사명'·
    '규격(SPEC)'처럼 낱말로 시작하면 같은 뜻으로 본다."""
    if cu == want:
        return True
    toks = [t for t in _LABEL_SPLIT.split(cu) if t]
    norm = " ".join(toks)
    if norm == want or norm.startswith(want + " ") or norm.endswith(" " + want):
        return True
    return not want.isascii() and cu.startswith(want)


def _row_label(values: dict) -> str | None:
    """행에서 사람이 알아볼 식별값(품번·품명·규격·업체, 묶음마다 하나·최대 4개)을 뽑는다."""
    out: list[str] = []
    for group in _LABEL_GROUPS:
        found = None
        for want in group:
            for col, val in values.items():
                cu = col.upper().strip()
                if _ORDINAL_COL.match(cu):
                    continue  # 'ITEM NO' 같은 순번 열이 ITEM에 걸려 번호가 품명 되는 것 방지
                if _col_matches(cu, want) and val and str(val) not in out:
                    found = str(val)
                    break
            if found:
                break
        if found:
            out.append(found)
    return " · ".join(out) if out else None


_OCR_WHERE = re.compile(r"\d+페이지 OCR \d+행")


def _is_ocr(where) -> bool:
    """OCR로 읽은 글줄·필드의 위치 표기('N페이지 OCR M행')인가 — 시트 이름에 OCR이 든 진짜 글자와 헷갈리지 않게."""
    return bool(_OCR_WHERE.search(str(where or "")))


def same_ocr_value(o, n) -> bool:
    """두 필드(또는 where 있는 글줄)가 모두 OCR 유래이고 혼동 문자를 지우면 같은가 — 재스캔에서 'REV B'가 '8'로
    읽힌 것을 Rev 변경으로 보지 않는다 (리뷰12 중간-C). 어느 한쪽이 진짜 글자면 정규화하지 않는다."""
    if o is None or n is None or not (_is_ocr(getattr(o, "where", "")) and _is_ocr(getattr(n, "where", ""))):
        return False
    from watcher.ocr import normalize
    a = normalize(getattr(o, "value", getattr(o, "text", "")))
    b = normalize(getattr(n, "value", getattr(n, "text", "")))
    return bool(a) and a == b


def _diff_fields(old: Document, new: Document) -> list[ChangeItem]:
    items = []
    for name in sorted(old.fields.keys() | new.fields.keys()):
        if name.startswith("META:"):
            continue                       # 작성·검토·승인·축척 — 그림 비교에서 그 자리를 빼려고만 둔다
        o, n = old.fields.get(name), new.fields.get(name)
        ov = o.value if o else None
        nv = n.value if n else None
        if ov != nv and not same_ocr_value(o, n):
            where = (n or o).where
            items.append(ChangeItem("FIELD_CHANGED", name, ov, nv, where))
    return items


def _keyed(rows) -> dict:
    """행을 key로 사전화하되, 중복 key는 #2, #3 순번을 붙여 유실을 막는다.
    (같은 TAG가 여러 행인 BOM에서 마지막 행만 남아 변경이 사라지는 것 방지)"""
    out, counts = {}, Counter()
    for r in rows:
        counts[r.key] += 1
        k = r.key if counts[r.key] == 1 else f"{r.key}#{counts[r.key]}"
        out[k] = r
    return out


_PLAIN_NUM = re.compile(r"^-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?$")


def _num(v):
    """'1,200' '1200.0' ' 1200 ' → 1200.0 / 숫자가 아니면 None.
    '010'(코드)·'1e3'(지수)·'1,2'(천 단위가 아닌 쉼표)는 숫자로 보지 않는다 (리뷰10 중간-3)."""
    s = str(v if v is not None else "").strip()
    if not s or not _PLAIN_NUM.match(s):
        return None
    digits = s.lstrip("-")
    if len(digits) > 1 and digits[0] == "0" and digits[1].isdigit():
        return None                               # 앞자리 0은 코드
    try:
        return float("".join(s.split(",")))
    except ValueError:
        return None


def _refs_of(s: str):
    """수식의 셀 참조를 (열 번호, 행 번호) 목록으로."""
    out = []
    for ref in _CELL_REF.findall(s):
        m = re.match(r"\$?([A-Z]{1,3})\$?(\d+)", ref)
        col = 0
        for ch in m.group(1):
            col = col * 26 + (ord(ch) - 64)
        out.append((col, int(m.group(2))))
    return out


def _same_formula(sa: str, sb: str) -> bool:
    """열·행을 끼워 넣어 참조가 밀린 수식만 같다고 본다 (리뷰10 중간-3).
    =B2*C2→=B2*B2(다른 열을 곱함), =SUM(D2:D4)→=SUM(D2:D3)(범위 축소)는 다르다.
    같다: 모든 참조가 같은 만큼 밀림(=B2*C2→=C2*D2) / 범위의 끝만 한 칸 늘어남(=SUM(B2:G2)→=SUM(B2:H2))."""
    if _CELL_REF.sub("?", sa) != _CELL_REF.sub("?", sb):
        return False
    ra, rb = _refs_of(sa), _refs_of(sb)
    if len(ra) != len(rb):
        return False
    if not ra:
        return True
    deltas = {(b[0] - a[0], b[1] - a[1]) for a, b in zip(ra, rb)}
    if len(deltas) == 1:
        return True
    # 범위(A:B 짝)의 끝만 +1 — 범위 안에 열·행이 끼어든 것. 시작은 그대로여야 한다
    ranges = re.findall(r"(\$?[A-Z]{1,3}\$?\d+):(\$?[A-Z]{1,3}\$?\d+)", sb)
    if not ranges:
        return False
    for a, b in zip(ra, rb):
        d = (b[0] - a[0], b[1] - a[1])
        if d != (0, 0) and d not in ((1, 0), (0, 1)):
            return False
    ends_b = {(_refs_of(e)[0]) for _, e in ranges}
    return all((b[0] - a[0], b[1] - a[1]) == (0, 0) or b in ends_b for a, b in zip(ra, rb))


_CELL_REF = re.compile(r"\$?[A-Z]{1,3}\$?\d+")
_THOUSANDS = re.compile(r"(?<![A-Za-z]\d)(?<=\d),(?=\d{3}(?!\d))")   # 'M8,100mm'의 쉼표는 천 단위가 아니다


def same_value(a, b) -> bool:
    """표기만 다른 같은 값인가 — 10 vs 10.0, 1200 vs 1,200 (2026-09-06 양식 시험).
    수식은 셀 참조만 밀린 것(열 추가로 =SUM(B2:G2)→=SUM(B2:H2))을 같은 것으로 본다."""
    if a == b:
        return True
    sa, sb = str(a or ""), str(b or "")
    if sa.startswith("=") and sb.startswith("=") and _same_formula(sa, sb):
        return True                            # 참조가 같은 모양으로 밀린 수식(=SUM(B2:G2)→=SUM(B2:H2)) — 단, 범위 끝만 바뀐 건 다르다
    if _THOUSANDS.sub("", sa) == _THOUSANDS.sub("", sb) and sa != sb and any(ch.isdigit() for ch in sa):
        return True                            # '245,000원' vs '245000원' — 천 단위 쉼표만
    x, y = _num(a), _num(b)
    return x is not None and y is not None and abs(x - y) < 1e-9


_SEQ_COLS: set = set()   # 비교 중인 두 표에서 '내용상 순번'으로 판정된 열 (choose 단계에서 채움)


def sequential_cols(old_rows, new_rows) -> set:
    """이름은 순번이 아니어도(ITEM, SEQ, #) 값이 1,2,3…으로 이어지는 열 — 삽입 한 줄에 전부 밀려
    변경으로 도배되던 것 (2026-09-06 양식 시험: 영문 BOM의 ITEM 열)."""
    out = set()
    cols = set()
    for r in old_rows[:400] + new_rows[:400]:
        cols.update(r.values.keys())
    for c in cols:
        for rows in (old_rows, new_rows):
            vals = [_num(r.values.get(c)) for r in rows]
            got = [v for v in vals if v is not None]
            if len(got) < max(3, len(rows) * 0.9) or any(v != int(v) for v in got):
                break
            seq = [int(v) for v in got]
            if sum(1 for a, b in zip(seq, seq[1:]) if b == a + 1) < (len(seq) - 1) * 0.9:
                break
            if any(b < a for a, b in zip(seq, seq[1:])):
                break                        # 한 번이라도 되돌아가면(카드마다 0..15) 순번이 아니다 (리뷰10)
        else:
            out.add(c)
    return out


def _rows_changed_items(o, n, prefix: str, skip_ordinal: bool = False) -> list[ChangeItem]:
    out = []
    label = _row_label(n.values) or _row_label(o.values)
    for col in sorted(o.values.keys() | n.values.keys()):
        if skip_ordinal and _ORDINAL_COL.match(col):
            continue  # 순번 밀림은 내용 변경이 아니다
        if col in _SEQ_COLS:
            continue
        ov, nv = o.values.get(col), n.values.get(col)
        if not same_value(ov, nv):
            out.append(ChangeItem(f"{prefix}_CHANGED", f"{n.key}.{col}", ov, nv,
                                  n.where, label=label))
    return out


def _row_sig(r) -> tuple:
    """위치 정렬용 행 서명 — 순번 열은 제외 (삽입 시 전체가 밀려 무의미)."""
    return tuple(sorted((k, v) for k, v in r.values.items()
                        if not _ORDINAL_COL.match(k)))


def _diff_rows_positional(old_rows, new_rows, prefix: str) -> list[ChangeItem]:
    """TAG 없는 표(행번호 키): 위치 정렬로 비교 — 행 하나가 삽입돼도
    이후 행 전체가 밀려 오탐 연쇄(수천 건)가 나지 않는다 (2026-08-23 실사용 발견)."""
    items: list[ChangeItem] = []
    ot = {r.key: r for r in old_rows if _is_total(r)}
    nt = {r.key: r for r in new_rows if _is_total(r)}
    if ot or nt:                               # 합계·소계 행은 라벨로 짝지어 값만 비교
        for k in sorted(ot.keys() & nt.keys()):
            items += _rows_changed_items(ot[k], nt[k], prefix, skip_ordinal=True)
        old_rows = [r for r in old_rows if not _is_total(r)]
        new_rows = [r for r in new_rows if not _is_total(r)]
    ov = [_row_sig(r) for r in old_rows]
    nv = [_row_sig(r) for r in new_rows]
    sm = difflib.SequenceMatcher(a=ov, b=nv, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "insert":
            for j in range(j1, j2):
                r = new_rows[j]
                items.append(ChangeItem(f"{prefix}_ADDED", r.key, None,
                                        str(r.values), r.where,
                                        label=_row_label(r.values)))
        elif tag == "delete":
            for i in range(i1, i2):
                r = old_rows[i]
                items.append(ChangeItem(f"{prefix}_REMOVED", r.key,
                                        str(r.values), None, r.where,
                                        label=_row_label(r.values)))
        else:  # replace: 겹치는 만큼은 값 변경, 남는 쪽은 추가/삭제
            for k in range(max(i2 - i1, j2 - j1)):
                o = old_rows[i1 + k] if i1 + k < i2 else None
                n = new_rows[j1 + k] if j1 + k < j2 else None
                if o is not None and n is not None:
                    items += _rows_changed_items(o, n, prefix, skip_ordinal=True)
                elif n is not None:
                    items.append(ChangeItem(f"{prefix}_ADDED", n.key, None,
                                            str(n.values), n.where,
                                            label=_row_label(n.values)))
                else:
                    items.append(ChangeItem(f"{prefix}_REMOVED", o.key,
                                            str(o.values), None, o.where,
                                            label=_row_label(o.values)))
    return items


# 행 앞의 순번("조건 4: 과부하", "1. 개요") — 한 행을 지우면 뒤 행 전부의 번호가
# 바뀌어 삭제 1건이 추가 4/삭제 5로 보였다 (2026-09-03 검토: 인터락 시트)
# 접두 낱말은 순번을 뜻하는 것만(조건·항목·NO·순번·번호) — "Rev 3:", "10 - 12"는 값이다
# (2026-09-03 재검토). 숫자는 3자리까지(연도 "2026." 보호), 구분자 뒤엔 공백 필수
_LEAD_NO = re.compile(r"^\s*(?:(?:조건|항목|순번|번호|NO\.?|No\.?)\s*)?\d{1,3}\s*(?:[:.]\s+|\)\s*)")
_ORDINAL_COL = re.compile(r"^(NO\.?|번호|순번|연번|NR\.?|ITEM ?NO\.?)$", re.IGNORECASE)


def strip_leading_no(text) -> str:
    return _LEAD_NO.sub("", str(text or ""), count=1).strip()


# 행의 이름표가 될 수 없는 열 — 값이 바뀌는 칸 (규격을 고치면 행이 신규+삭제로 갈린다)
_NOT_KEY_COLS = {"규격", "사양", "SPEC", "SPECIFICATION", "단가", "금액", "수량", "QTY", "Q'TY",
                 "PRICE", "AMOUNT", "UNIT PRICE", "비고", "REMARK", "REMARKS", "NOTE", "NOTES",
                 "날짜", "DATE", "단위", "UNIT"}


_NUM_RE = re.compile(r"^\s*-?[\d,]+(\.\d+)?\s*$")
_DATE_RE = re.compile(r"^\s*(\d{4}[-./]\d{1,2}[-./]\d{1,2}|\d{2}[-./]\d{1,2}[-./]\d{1,2}|\d{1,2}/\d{1,2})\s*$")
_TOTAL_KEY = re.compile(r"^(?:.+ )?(소\s*계|합\s*계|총\s*계|계|SUB\s*TOTAL|TOTAL|G\.?\s*TOTAL)(#\d+)?$", re.IGNORECASE)


def _is_total(r) -> bool:
    return bool(_TOTAL_KEY.match(r.key))


def _pair_count(old_rows, new_rows, col=None) -> int:
    """이 열(없으면 현재 키)로 맞췄을 때 두 판에서 짝지어지는 행 수."""
    def vals(rows):
        if col is None:
            return {r.key for r in rows if not _POS_KEY.match(r.key)}
        return {strip_leading_no(r.values.get(col)) for r in rows if r.values.get(col)}
    return len(vals(old_rows) & vals(new_rows))


def choose_key_col(old_rows, new_rows) -> str | None:
    """두 판을 같이 놓고 '어느 열로 맞추면 행이 가장 많이 짝지어지는가'를 센다.

    파일 하나만 보고 고른 키(품명·설명류)는 그 칸을 고치는 순간 행이 신규+삭제로 갈렸고,
    양식이 수십 종이라 열 이름을 설정에 적어 두라고 할 수도 없다 (2026-09-06 사용자:
    "문서가 한두 개도 아니고 다 넣어주려면 안 할 것"). 조건: 양쪽 거의 모든 행에 있고,
    양쪽에서 거의 고유하며, 값 열(규격·수량·비고)이 아닌 열 가운데 짝이 가장 많은 것.
    지금 키보다 확실히 나을 때만 바꾼다."""
    if not old_rows or not new_rows:
        return None
    from watcher.extract.xlsx import code_ratio
    old_rows = [r for r in old_rows if not _is_total(r)] or old_rows
    new_rows = [r for r in new_rows if not _is_total(r)] or new_rows
    cols: list = []
    for r in old_rows[:400] + new_rows[:400]:
        for c in r.values:
            if c not in cols:
                cols.append(c)                  # 머리글 순서 — 동점이면 왼쪽 열
    n_min = min(len(old_rows), len(new_rows))
    current = _pair_count(old_rows, new_rows)
    cur_keys = [r.key for r in old_rows if not _POS_KEY.match(r.key)]
    cur_code = code_ratio(cur_keys) if cur_keys else 0.0
    best, best_score = None, (current, 1 if cur_code >= 0.9 else 0, 1)
    for c in cols:
        cu = str(c).strip().upper()
        if _ORDINAL_COL.match(str(c).strip()) or cu in _NOT_KEY_COLS or c in _SEQ_COLS:
            continue
        ov = [strip_leading_no(r.values.get(c)) for r in old_rows if r.values.get(c)]
        nv = [strip_leading_no(r.values.get(c)) for r in new_rows if r.values.get(c)]
        if len(ov) < len(old_rows) * 0.9 or len(nv) < len(new_rows) * 0.9:
            continue
        if len(set(ov)) < len(ov) * 0.95 or len(set(nv)) < len(nv) * 0.95:
            continue
        codes = code_ratio(ov)
        if sum(len(str(v)) for v in ov) / max(1, len(ov)) < 2:
            continue                            # X/O 마크 열
        if sum(1 for v in ov if _NUM_RE.match(str(v))) >= len(ov) * 0.8:
            continue                            # 숫자만인 열(생산량·금액)은 값이지 이름표가 아니다
        if sum(1 for v in ov if str(v).startswith("=")) >= len(ov) * 0.5:
            continue                            # 수식 열도 마찬가지
        is_date = sum(1 for v in ov if _DATE_RE.search(str(v))) >= len(ov) * 0.8
        n = len(set(ov) & set(nv))
        if n < max(2, int(n_min * 0.5)):
            continue
        # 짝 수가 같으면 코드 모양(품번) 열이 설명 열보다 낫다 — 설명은 고쳐지는 칸.
        # 날짜 열은 다른 후보가 없을 때만 (공정표의 시작일은 키가 아니지만 일별 기록의 일자는 키)
        score = (n, 1 if codes >= 0.9 else 0, 0 if is_date else 1)
        if is_date:
            score = (n, -1, 0)
        if score > best_score:
            best, best_score = c, score
    return best


def _rekey(rows, col: str):
    from watcher.extract.base import Row
    out = []
    for r in rows:
        if _is_total(r):
            out.append(r)                     # 합계 행의 키는 라벨 그대로
            continue
        v = strip_leading_no(r.values.get(col)) if r.values.get(col) else None
        out.append(Row(key=v or r.key, values=r.values, where=r.where) if v else r)
    return out


def _moved_keys(order_old: list, n_pos: dict) -> list:
    """옛 순서의 키 목록이 새 순서에서 얼마나 어긋나나 — 가장 긴 오름 부분열(LIS) 밖의 키가 '옮겨진' 행."""
    seq = [n_pos[k] for k in order_old]
    if len(seq) < 2:
        return []
    import bisect
    tails: list = []
    prev = [-1] * len(seq)
    idx_at: list = []
    for i, v in enumerate(seq):
        j = bisect.bisect_left(tails, v)
        if j == len(tails):
            tails.append(v); idx_at.append(i)
        else:
            tails[j] = v; idx_at[j] = i
        prev[i] = idx_at[j - 1] if j else -1
    keep = set()
    i = idx_at[-1] if idx_at else -1
    while i >= 0:
        keep.add(i); i = prev[i]
    return [order_old[i] for i in range(len(seq)) if i not in keep]


def _col_values(rows, col) -> Counter:
    return Counter(str(r.values.get(col)) for r in rows if r.values.get(col))


def _col_order(rows) -> list:
    """행들의 열 이름을 머리글 순서대로 합친다. 첫 행에서 빈 칸이던 열을 뒤에 붙이면 열 순서가 틀어져
    값 하나 채워진 날 '열 위치 이동'이 나던 것 (리뷰10 퍼즈 105) — 새 열은 그 행에서 뒤따르는
    아는 열 앞에 끼운다."""
    order: list = []
    for r in rows:
        cols = list(r.values)
        for k, c in enumerate(cols):
            if c in order:
                continue
            nxt = next((x for x in cols[k + 1:] if x in order), None)
            if nxt is None:
                order.append(c)
            else:
                order.insert(order.index(nxt), c)
    return order


def align_columns(old_rows, new_rows):
    """열 이름 변경·열 추가·열 삭제를 먼저 알아본다 → (옛 행들, 새 행들, 열 단위 항목).

    머리글 한 칸을 '일자'→'개정일'로 바꾸면 전 행이 "일자 삭제 + 개정일 추가"로, 열 하나를 더하면
    전 행이 "값 변경"으로 도배됐다 (2026-09-06 블라인드 양식 시험 08·17·24·28·29). 이름이 바뀐 열은
    값 분포가 거의 같은(80% 이상) 옛 열과 짝지어 새 이름으로 맞추고, 대부분 행에 값이 있는 열의
    추가·삭제는 한 건으로 요약한다. 드문드문 채워진 열(비고 한 칸)은 그대로 행 단위로 본다."""
    from watcher.extract.base import Row
    if not old_rows or not new_rows:
        return old_rows, new_rows, []
    o_cols = _col_order(old_rows)
    n_cols = _col_order(new_rows)
    only_o = [c for c in o_cols if c not in n_cols]
    only_n = [c for c in n_cols if c not in o_cols]
    where = old_rows[0].where.split("!", 1)[0] if "!" in old_rows[0].where else ""
    items: list[ChangeItem] = []
    common = [c for c in o_cols if c in n_cols]
    n_idx = {c: i for i, c in enumerate(n_cols)}
    moved = _moved_keys(common, n_idx)
    if moved:
        o_idx = {c: i for i, c in enumerate(o_cols)}
        moved = [c for c in moved if o_idx[c] != n_idx[c]]
    if moved:
        if len(moved) <= 3:
            for c in moved:
                items.append(ChangeItem("COL_MOVED", c, f"{o_idx[c] + 1}번째 열", f"{n_idx[c] + 1}번째 열",
                                        where or "표", label="열 위치 이동 — 값은 그대로"))
        else:
            items.append(ChangeItem("COL_MOVED", "열 순서", f"{len(moved)}열 자리 바뀜", "재배치", where or "표"))
    rename: dict = {}
    used_n: set = set()
    for a in only_o:
        va = _col_values(old_rows, a)
        if sum(va.values()) < 3:
            continue                        # 값이 거의 없는 열은 이름 변경 판정 대상이 아니다
        best, best_s = None, 0.0
        for b in only_n:
            if b in used_n:
                continue
            vb = _col_values(new_rows, b)
            inter = sum((va & vb).values())
            s = inter / max(sum(va.values()), sum(vb.values()))
            if s > best_s:
                best, best_s = b, s
        if best is not None and (best_s >= 0.8 or (best_s >= 0.5 and len(only_o) == 1 and len(only_n) == 1)):
            rename[a] = best
            used_n.add(best)
            items.append(ChangeItem("COL_RENAMED", best, a, best, where or "표",
                                    label=f"열 이름 변경 — 값은 {int(best_s * 100)}% 그대로"))
    n_old, n_new = len(old_rows), len(new_rows)
    drop_o = []
    for c in only_o:
        if c in rename:
            continue
        filled = sum(1 for r in old_rows if r.values.get(c))
        if filled >= max(3, n_old * 0.5):
            drop_o.append(c)
            sample = [f"{r.key}: {r.values[c]}" for r in old_rows if r.values.get(c)][:5]
            items.append(ChangeItem("COL_REMOVED", c,
                                    f"값 있는 행 {filled}개 — " + ", ".join(sample) + (" …" if filled > 5 else ""),
                                    None, where or "표", label=f"열 삭제 — {filled}행"))
    drop_n = []
    for c in only_n:
        if c in used_n:
            continue
        filled = sum(1 for r in new_rows if r.values.get(c))
        if filled >= max(3, n_new * 0.5):
            drop_n.append(c)
            sample = [f"{r.key}: {r.values[c]}" for r in new_rows if r.values.get(c)][:5]
            items.append(ChangeItem("COL_ADDED", c, None,
                                    f"값 있는 행 {filled}개 — " + ", ".join(sample) + (" …" if filled > 5 else ""),
                                    where or "표", label=f"열 추가 — {filled}행"))
    if not (rename or drop_o or drop_n):
        return old_rows, new_rows, items

    def fix_old(r):
        v = {rename.get(k, k): x for k, x in r.values.items() if k not in drop_o}
        return Row(key=r.key, values=v, where=r.where)

    def fix_new(r):
        v = {k: x for k, x in r.values.items() if k not in drop_n}
        return Row(key=r.key, values=v, where=r.where)
    return [fix_old(r) for r in old_rows], [fix_new(r) for r in new_rows], items


def _sheet_of(r) -> str:
    return r.where.split("!", 1)[0] if "!" in r.where else ""


def _diff_rows(old_rows, new_rows, kind_prefix: str) -> list[ChangeItem]:
    """표 비교 입구. 시트가 여럿이면 시트끼리 먼저 짝짓고(이름 같음 → 값이 가장 닮은 것) 시트마다
    따로 비교한다 — 시트마다 같은 키(일자)가 있어 뒤섞이고, 시트 하나를 지우면 그 행 전부가
    '삭제'로 도배되던 것 (2026-09-06 블라인드 2차 09·25)."""
    if kind_prefix != "ROW" or not (old_rows or new_rows):
        return _diff_rows_one(old_rows, new_rows, kind_prefix)
    so = list(dict.fromkeys(_sheet_of(r) for r in old_rows))
    sn = list(dict.fromkeys(_sheet_of(r) for r in new_rows))
    if len(so) <= 1 and len(sn) <= 1:
        out = _diff_rows_one(old_rows, new_rows, kind_prefix)
        if so and sn and so[0] and sn[0] and so[0] != sn[0]:
            # 시트가 하나뿐이어도 이름이 바뀐 사실은 남긴다 — 'BOM'→'BOM_최종'이
            # "글자·표·그림 동일"로 단언됐다 (검토19 감지 ⑪)
            out.insert(0, ChangeItem("SHEET_RENAMED", sn[0], so[0], sn[0], sn[0],
                                     label="표 제목 변경" if "·" in so[0] or "·" in sn[0]
                                     else "시트 이름 변경"))
        return out
    by_o = {s: [r for r in old_rows if _sheet_of(r) == s] for s in so}
    by_n = {s: [r for r in new_rows if _sheet_of(r) == s] for s in sn}
    pairs = [(s, s) for s in so if s in by_n]
    rest_o = [s for s in so if s not in by_n]
    rest_n = [s for s in sn if s not in by_o]

    def sig(rows):
        return {tuple(sorted(r.values.items())) for r in rows}
    cand = []
    for a in rest_o:
        for b in rest_n:
            ka, kb = sig(by_o[a]), sig(by_n[b])
            if ka and kb:
                cand.append((len(ka & kb) / min(len(ka), len(kb)), a, b))
    renamed = []
    for ratio, a, b in sorted(cand, reverse=True):
        if a in rest_o and b in rest_n and ratio >= 0.5:
            rest_o = [s for s in rest_o if s != a]
            rest_n = [s for s in rest_n if s != b]
            renamed.append((a, b))
    items: list[ChangeItem] = []
    for a, b in renamed:
        items.append(ChangeItem("SHEET_RENAMED", b, a, b, b,
                                label="표 제목 변경" if "·" in a or "·" in b else "시트 이름 변경"))
    for a in rest_o:
        keys = [r.key for r in by_o[a]][:5]
        items.append(ChangeItem("SHEET_REMOVED", a, f"{len(by_o[a])}행 ({', '.join(keys)}{' …' if len(by_o[a]) > 5 else ''})",
                                None, a, label="시트 삭제"))
    for b in rest_n:
        keys = [r.key for r in by_n[b]][:5]
        twin = next((s for s in list(so) + [x for x in sn if x != b]
                     if (by_o.get(s) or by_n.get(s)) and sig(by_o.get(s) or by_n.get(s)) == sig(by_n[b])), None)
        items.append(ChangeItem("SHEET_ADDED", b, None,
                                f"{len(by_n[b])}행 ({', '.join(keys)}{' …' if len(by_n[b]) > 5 else ''})"
                                + (f" — '{twin}' 시트와 내용 같음(복사본)" if twin else ""),
                                b, label="시트 추가"))
    for a, b in pairs + renamed:
        items += _diff_rows_one(by_o[a], by_n[b], kind_prefix)
    return items


def _diff_rows_one(old_rows, new_rows, kind_prefix: str) -> list[ChangeItem]:
    global _SEQ_COLS
    _SEQ_COLS = sequential_cols(old_rows, new_rows) if kind_prefix == "ROW" else set()
    col_items: list[ChangeItem] = []
    if kind_prefix == "ROW" and old_rows and new_rows:
        old_rows, new_rows, col_items = align_columns(old_rows, new_rows)
        col = choose_key_col(old_rows, new_rows)
        if col is not None:
            old_rows, new_rows = _rekey(old_rows, col), _rekey(new_rows, col)
        # 두 판이 서로 다른 키(한쪽은 품번, 다른 쪽은 입고번호+LOT 조합)로 읽혀 거의 안 맞으면 키를 버리고
        # 위치 정렬로 — 키가 달라 전 행이 삭제+추가로 갈리던 것 (2026-09-06 블라인드 3차 17)
        n_min = min(len(old_rows), len(new_rows))
        if n_min >= 2 and _pair_count(old_rows, new_rows) < 0.3 * n_min:
            from watcher.extract.base import Row
            old_rows = [r if _is_total(r) else Row(key=r.where, values=r.values, where=r.where) for r in old_rows]
            new_rows = [r if _is_total(r) else Row(key=r.where, values=r.values, where=r.where) for r in new_rows]
    return col_items + _diff_rows_body(old_rows, new_rows, kind_prefix)


def _diff_rows_body(old_rows, new_rows, kind_prefix: str) -> list[ChangeItem]:

    # 행번호 키가 지배적이면(=TAG 없는 표) 위치 정렬 방식으로
    def positional_ratio(rows):
        return (sum(1 for r in rows if _POS_KEY.match(r.key)) / len(rows)) if rows else 0
    if kind_prefix == "ROW" and old_rows and new_rows \
            and (positional_ratio(old_rows) > 0.5 or positional_ratio(new_rows) > 0.5):
        # 한쪽만 행번호 키(행이 둘로 갈려 품번이 겹치는 등)면 둘 다 위치 정렬로 — 키가 다른 채로
        # 비교하면 전 행이 삭제+추가가 된다 (2026-09-06 블라인드 3차 17)
        # 다중 시트 파일은 시트별로 따로 위치 정렬 — 시트를 한 줄로 이으면
        # 앞 시트의 행 증감이 뒤 시트 전체를 밀어 오탐이 된다 (2026-08-26)
        def sheet_of(r) -> str:
            return r.where.split("!", 1)[0] if "!" in r.where else ""

        o_sheets = list(dict.fromkeys(sheet_of(r) for r in old_rows))
        n_sheets = list(dict.fromkeys(sheet_of(r) for r in new_rows))
        # 이름이 같은 시트끼리, 남은 시트는 순서대로 — 시트 이름만 바꾼 파일(Sheet1→BOM_rev2)이
        # 전 행 삭제+추가로 보이던 것 (2026-09-06 양식 시험)
        pairs = [(s, s) for s in o_sheets if s in n_sheets]
        rest_o = [s for s in o_sheets if s not in n_sheets]
        rest_n = [s for s in n_sheets if s not in o_sheets]
        pairs += list(zip(rest_o, rest_n))
        pairs += [(s, None) for s in rest_o[len(rest_n):]] + [(None, s) for s in rest_n[len(rest_o):]]
        if len(pairs) > 1 or (pairs and pairs[0][0] != pairs[0][1]):
            items: list[ChangeItem] = []
            for so, sn in pairs:
                items += _diff_rows_positional(
                    [r for r in old_rows if so is not None and sheet_of(r) == so],
                    [r for r in new_rows if sn is not None and sheet_of(r) == sn], kind_prefix)
            return items
        return _diff_rows_positional(old_rows, new_rows, kind_prefix)

    old_by = _keyed(old_rows)
    new_by = _keyed(new_rows)
    items = []
    added_keys = sorted(new_by.keys() - old_by.keys())
    removed_keys = sorted(old_by.keys() - new_by.keys())
    # 키 칸(품명 등) 하나만 고친 행은 신규+삭제가 아니라 그 칸의 변경이다 — 나머지 값이 전부 같은
    # 삭제·신규 짝을 찾는다 (리뷰10 퍼즈: 품명이 키인 표에서 품명 오타 수정이 '새 품목'으로 보이던 것)
    for okey in list(removed_keys):
        o = old_by[okey]
        for nkey in list(added_keys):
            n = new_by[nkey]
            diff_cols = [c for c in set(o.values) | set(n.values) if not same_value(o.values.get(c), n.values.get(c))]
            if len(diff_cols) == 1 and len(o.values) >= 2 and o.where == n.where:
                col = diff_cols[0]
                items.append(ChangeItem(f"{kind_prefix}_CHANGED", f"{okey}.{col}", o.values.get(col), n.values.get(col),
                                        n.where, label=_row_label(n.values)))
                removed_keys = [k for k in removed_keys if k != okey]
                added_keys = [k for k in added_keys if k != nkey]
                break
    for key in added_keys:
        r = new_by[key]
        items.append(ChangeItem(f"{kind_prefix}_ADDED", key, None, str(r.values),
                                r.where, label=_row_label(r.values)))
    for key in removed_keys:
        r = old_by[key]
        items.append(ChangeItem(f"{kind_prefix}_REMOVED", key, str(r.values), None,
                                r.where, label=_row_label(r.values)))
    # 행 순서: 공통 키의 순서가 바뀌었으면 — 몇 행이면 각각 '이동', 많으면 '재정렬' 한 건
    # (2026-09-06 블라인드 양식 시험 09·11·27: 실무자는 순서 변경도 알고 싶어 한다)
    reorder_note = None
    common = [k for k in old_by if k in new_by and not _is_total(old_by[k])]
    n_pos = {k: i for i, k in enumerate(new_by)}
    moved = _moved_keys(common, n_pos)
    if moved:
        o_pos = {k: i for i, k in enumerate(old_by)}
        moved = [k for k in moved if o_pos[k] != n_pos[k]]
    if moved:
        if len(moved) <= 3:
            for k in moved:
                items.append(ChangeItem(f"{kind_prefix}_MOVED", k, old_by[k].where, new_by[k].where,
                                        new_by[k].where, label=_row_label(new_by[k].values)))
        else:
            # 정렬만 바꾼 표 — 값은 그대로라 변경으로 세지 않고 참고로만 (2026-09-06 블라인드 2차 28).
            # 다른 변경이 하나라도 있으면 '내용 변경 없음'이 거짓이 되고 파일 전체가 접힌다 (리뷰10 차단-2)
            # → 뒤에서 값 변경이 나오면 이 참고를 뺀다
            reorder_note = ChangeItem("CHECK_SKIPPED", "참고", None,
                                      f"행 순서만 바뀜 — {len(moved)}행 자리 바뀜, 내용 변경 없음",
                                      new_rows[0].where.split("!", 1)[0] if "!" in new_rows[0].where else "표")
            items.append(reorder_note)
    for key in sorted(old_by.keys() & new_by.keys()):
        o, n = old_by[key], new_by[key]
        if o.values != n.values:
            label = _row_label(n.values) or _row_label(o.values)
            for col in sorted(o.values.keys() | n.values.keys()):
                ov, nv = o.values.get(col), n.values.get(col)
                if same_value(ov, nv) or col in _SEQ_COLS:
                    continue
                if _ORDINAL_COL.match(str(col).strip()) \
                        or strip_leading_no(ov) == strip_leading_no(nv):
                    continue        # 순번만 밀린 것은 변경이 아니다
                items.append(ChangeItem(f"{kind_prefix}_CHANGED", f"{key}.{col}",
                                        ov, nv, n.where, label=label))
    if reorder_note is not None and any(i is not reorder_note and i.kind != "CHECK_SKIPPED" for i in items):
        items = [i for i in items if i is not reorder_note]
        items.append(ChangeItem(f"{kind_prefix}_MOVED", "행 순서", None, f"{len(moved)}행 자리 바뀜 (값은 위 항목 외 그대로)",
                                new_rows[0].where.split("!", 1)[0] if "!" in new_rows[0].where else "표",
                                label="행 순서 재정렬"))
    return items


_LINE_LABEL = re.compile(
    r"^\s*((?:제\s*\d{1,3}\s*[조항호])|(?:\d{1,3}(?:[.\-]\d{1,3})*[.)])|(?:\d{1,3}(?:\.\d{1,3})+)|(?:[A-Z]{2,8}\s*\d{1,3}[.:])|"
    r"(?:[①-⑳㉑-㉟⑴-⒇⒈-⒛])|(?:[•·▪▫◦‣∙‧\-–—])|(?:\(\d+\))|(?:[가-힣]\.)|"
    r"(?:[가-힣A-Za-z][가-힣A-Za-z /]{1,14}:))(?=\s|$)")
# 번호·기호 이름표는 재부여될 수 있다(①→② / • 는 어느 항목이나 같다) — 나머지 글자로 짝짓는다
_NUMERIC_LABEL = re.compile(r"^\s*(제\s*\d+|\d|[①-⑳㉑-㉟⑴-⒇⒈-⒛]|[•·▪▫◦‣∙‧\-–—]|\(\d+\)|[가-힣]\.)")


def _page_of(where: str) -> str:
    m = _PAGE_WHERE.match(where or "")
    return m.group(1) if m else ""


_SHEET_OF = re.compile(r"^\s*(?:SHEET|SH\.?|PAGE|PG\.?|쪽|페이지|장)?\s*:?\s*\d{1,3}\s*(?:OF|/)\s*(\d{1,3})\s*(?:쪽|페이지|장)?\s*$", re.I)


def _after_label(text: str) -> str:
    m = _LINE_LABEL.match(text or "")
    return " ".join((text[m.end():] if m else text or "").split())


def _line_label(text: str) -> str | None:
    """줄 머리의 항목 이름표 — '4.', '3-1.', '제6조', 'NOTE 2.', '변경 사유:'. 같은 이름표의 삭제+추가는
    문장을 크게 고쳐도 한 항목의 '변경'이다 (2026-09-06 블라인드 양식 시험 35·37·38)."""
    m = _LINE_LABEL.match(text or "")
    return "".join(m.group(1).split()).upper() if m else None


def _moved_labelled_lines(old_lines, new_lines) -> list[ChangeItem]:
    """'제8조 …'처럼 이름표가 붙은 줄이 그대로인 채 자리만 옮겨졌으면 '이동'으로 — 계약서 조항 순서
    (2026-09-06 블라인드 채점: 문단 이동 0/1). 이름표 없는 줄의 재배치는 여전히 소음으로 보고 무시."""
    def labelled(lines):
        out = {}
        for i, t in enumerate(lines):
            lb = _line_label(t.text)
            if not lb:
                continue
            # 번호 이름표는 재부여될 수 있으니 나머지 글자로 짝짓고, 글자 이름표는 이름표 자체로
            k = ("R", _after_label(t.text)) if _NUMERIC_LABEL.match(t.text) else ("L", lb)
            if k[1] and k not in out:
                out[k] = (i, t)
        return out
    lo, ln = labelled(old_lines), labelled(new_lines)
    common = [k for k, (i, t) in sorted(lo.items(), key=lambda kv: kv[1][0])
              if k in ln and (k[0] == "R" or ln[k][1].text == t.text)]
    if len(common) < 2:
        return []
    n_pos = {lb: ln[lb][0] for lb in common}
    moved = _moved_keys(common, n_pos)
    if not moved:
        return []
    if len(moved) > 3:
        return [ChangeItem("TEXT_MOVED", "문단 순서", f"{len(moved)}개 항목 자리 바뀜", "재배치", new_lines[0].where)]
    return [ChangeItem("TEXT_MOVED", ln[lb][1].text[:30], lo[lb][1].where, ln[lb][1].where, ln[lb][1].where,
                       label="내용은 그대로, 자리만 이동") for lb in moved]


def _tag_of(text: str) -> str | None:
    tags = find_tags(text)  # 제외 접두(도면번호 등)를 거친 첫 태그
    return tags[0] if tags else None


def _excess_instances(lines, own_counts: Counter, other_counts: Counter) -> list:
    """상대쪽보다 많은 만큼(N−M개)만 골라낸다 — 전 인스턴스를 지목하면
    아직 존재하는 줄을 삭제됐다고 보고하는 거짓 근거가 된다."""
    taken: Counter = Counter()
    out = []
    for t in lines:
        excess = own_counts[t.text] - other_counts[t.text]
        if taken[t.text] < excess:
            taken[t.text] += 1
            out.append(t)
    return out


# where가 "N페이지 M행" 꼴이면 페이지 정보가 있는 문서 (pdf.py 형식)
_PAGE_WHERE = re.compile(r"^(\d+)페이지")
# 페이지 짝짓기 최소 유사도 — 이보다 다르면 같은 도면의 개정판이 아니라 다른 페이지
_PAGE_SIM_MIN = 0.3
# 페이지 짝짓기 전수 비교 상한 (P×Q). 넘으면 순서대로 짝짓는다 (성능 보호)
_PAGE_PAIR_CAP = 40_000


def _pages(lines) -> dict[int, list]:
    """TextLine들을 페이지 번호로 묶는다. 페이지 정보 없는 줄은 0번 묶음."""
    out: dict[int, list] = {}
    for t in lines:
        m = _PAGE_WHERE.match(t.where)
        out.setdefault(int(m.group(1)) if m else 0, []).append(t)
    return out


def _page_added(pno: int, lines) -> ChangeItem:
    return ChangeItem("PAGE_ADDED", f"{pno}페이지", None,
                      f"페이지 추가 (텍스트 {len(lines)}줄)", lines[0].where)


def _page_removed(pno: int, lines) -> ChangeItem:
    return ChangeItem("PAGE_REMOVED", f"{pno}페이지",
                      f"페이지 삭제 (텍스트 {len(lines)}줄)", None, lines[0].where)


def _pair_changed_pages(old_ids, new_ids, op, np_) -> list[ChangeItem]:
    """내용이 달라진 페이지들을 토큰 겹침 비율로 짝짓는다.
    (재출력 시 페이지 순서가 밀리거나 바뀌어도 같은 도면끼리 비교되도록.
    비율 분모는 작은 쪽 — 한 줄짜리 페이지의 값 변경도 짝지어지게)"""
    items: list[ChangeItem] = []
    if len(old_ids) * len(new_ids) > _PAGE_PAIR_CAP:
        for i, j in zip(old_ids, new_ids):
            items += _diff_text_lines(op[i], np_[j])
        for i in old_ids[len(new_ids):]:
            items.append(_page_removed(i, op[i]))
        for j in new_ids[len(old_ids):]:
            items.append(_page_added(j, np_[j]))
        return items

    otok = {i: {tok for t in op[i] for tok in t.text.split()} for i in old_ids}
    ntok = {j: {tok for t in np_[j] for tok in t.text.split()} for j in new_ids}
    sims = []
    for i in old_ids:
        for j in new_ids:
            inter = len(otok[i] & ntok[j])
            floor = min(len(otok[i]), len(ntok[j])) or 1
            sims.append((inter / floor, i, j))
    used_o, used_n, pairs = set(), set(), []
    for sim, i, j in sorted(sims, key=lambda s: (-s[0], abs(s[1] - s[2]))):
        if sim < _PAGE_SIM_MIN:
            break
        if i in used_o or j in used_n:
            continue
        used_o.add(i)
        used_n.add(j)
        pairs.append((i, j))
    for i, j in sorted(pairs, key=lambda p: p[1]):
        items += _diff_text_lines(op[i], np_[j])
    for i in old_ids:
        if i not in used_o:
            items.append(_page_removed(i, op[i]))
    for j in new_ids:
        if j not in used_n:
            items.append(_page_added(j, np_[j]))
    return items


def _diff_pages(op: dict, np_: dict) -> list[ChangeItem]:
    """페이지 단위 본문 diff. 도면 세트 PDF는 페이지 하나가 별개 도면이므로
    문서 전체를 한 풀로 섞으면 ①페이지 간 이동이 무변경으로 오인되고
    ②문서가 클수록 다른 페이지의 같은 단어가 진짜 변경을 상쇄해 삼킨다
    (2026-08-23 실사용 발견: 131페이지 도면 세트에서 변경 2/3가 유실).

    1단계: 내용이 완전히 같은 페이지끼리 상쇄 (순서 이동은 변경이 아님).
    2단계: 남은 페이지를 유사도로 짝지어 페이지별 줄 diff.
    3단계: 짝 못 찾은 페이지는 페이지 추가/삭제로 보고."""
    osig = {i: tuple(sorted(t.text for t in op[i])) for i in sorted(op)}
    nsig = {j: tuple(sorted(t.text for t in np_[j])) for j in sorted(np_)}
    n_avail = Counter(nsig.values())
    rem_old = []
    for i, s in osig.items():
        if n_avail[s] > 0:
            n_avail[s] -= 1
        else:
            rem_old.append(i)
    o_avail = Counter(osig.values())
    rem_new = []
    for j, s in nsig.items():
        if o_avail[s] > 0:
            o_avail[s] -= 1
        else:
            rem_new.append(j)
    return _pair_changed_pages(rem_old, rem_new, op, np_)


def page_anchors(old: Document, new: Document) -> dict[int, int]:
    """글자로 확실한 페이지 대응 {옛 쪽: 새 쪽} — 그림 정렬의 앵커 (검토19 2차 감지 N2).
    ①내용이 완전히 같은 쪽은 순서대로 ②남은 쪽은 낱말 겹침(Jaccard ≥ 0.5)이 큰 순으로, 단조 증가만."""
    try:
        op, np_ = _pages(old.raw_texts), _pages(new.raw_texts)
    except Exception:
        return {}
    if len(op) <= 1 and len(np_) <= 1:
        return {}
    osig = {i: tuple(sorted(t.text for t in op[i])) for i in op}
    nsig = {j: tuple(sorted(t.text for t in np_[j])) for j in np_}
    out: dict[int, int] = {}
    used_j: set = set()
    for i in sorted(osig):
        if not osig[i]:
            continue
        for j in sorted(nsig):
            if j not in used_j and nsig[j] == osig[i] and all(j > b for a, b in out.items() if a < i):
                out[i] = j
                used_j.add(j)
                break
    ow = {i: {w for t in op[i] for w in t.text.split()} for i in op if i not in out}
    nw = {j: {w for t in np_[j] for w in t.text.split()} for j in np_ if j not in used_j}
    cands = sorted(((len(ow[i] & nw[j]) / max(1, len(ow[i] | nw[j])), i, j)
                    for i in ow for j in nw if ow[i] and nw[j]), reverse=True)
    for s, i, j in cands:
        if s < 0.5 or i in out or j in used_j:
            continue
        if any((a < i) != (b < j) for a, b in out.items()):     # 단조 증가 유지
            continue
        out[i] = j
        used_j.add(j)
    return out


def _diff_texts(old: Document, new: Document) -> list[ChangeItem]:
    """본문 줄 diff. 페이지 정보가 있는 다중 페이지 문서는 페이지끼리 짝지어
    비교하고, 그 외에는 문서 전체를 한 번에 비교한다."""
    op, np_ = _pages(old.raw_texts), _pages(new.raw_texts)
    if len(op) > 1 or len(np_) > 1:
        return _group_repeats(_diff_pages(op, np_), page_count=max(len(op), len(np_)))
    return _group_repeats(_diff_text_lines(old.raw_texts, new.raw_texts))


def _diff_text_lines(old_lines, new_lines) -> list[ChangeItem]:
    """한 비교 단위(문서 전체 또는 페이지 한 쌍)의 줄 diff.
    같은 태그를 가진 삭제+추가 줄은 '변경' 한 건으로 짝짓는다.

    재배치 소음 상쇄: PDF는 같은 내용도 재출력 시 줄 나뉨이 달라져 삭제+추가
    수백 쌍이 생긴다(2026-08-23 실사용 발견). 삭제/추가 줄의 단어 풀을 서로 빼서,
    '실제로 사라진/새로 생긴 단어'를 하나도 안 담은 줄은 줄바꿈·이동으로 보고
    보고하지 않는다. (단어가 우연히 다른 줄에 있는 진짜 삭제는 묻힐 수 있는
    트레이드오프 — 내용 보존이 확인되므로 감수. 페이지 단위로 좁혀 부작용 최소화)"""
    old_counts = Counter(t.text for t in old_lines)
    new_counts = Counter(t.text for t in new_lines)
    removed = _excess_instances(old_lines, old_counts, new_counts)
    added = _excess_instances(new_lines, new_counts, old_counts)
    # 항목 번호만 바뀐 줄('3.1.2 필름 폭' → '3.1.3 필름 폭')은 재부여 — 변경이 아니다
    # (2026-09-06 블라인드 2차 31·37)
    def _renum(t) -> bool:
        return bool(_line_label(t.text)) and bool(_NUMERIC_LABEL.match(t.text))
    rest_a = Counter(_after_label(t.text) for t in added if _renum(t))
    drop_r, drop_a = set(), set()
    for t in removed:
        k = _after_label(t.text)
        if _renum(t) and k and rest_a.get(k, 0) > 0:
            rest_a[k] -= 1
            drop_r.add(id(t))
            for a in added:
                if id(a) not in drop_a and _renum(a) and _after_label(a.text) == k:
                    drop_a.add(id(a)); break
    removed = [t for t in removed if id(t) not in drop_r]
    added = [t for t in added if id(t) not in drop_a]
    # OCR 글줄끼리는 혼동 문자(O/0·I/1·S/5·B/8)와 구두점을 지워 같으면 같은 줄 — 재스캔의 기울기·밝기 차이가
    # 매번 글자 변경·Rev 미갱신 경고를 내던 것 (리뷰12 중간-B)
    if any(_is_ocr(t.where) for t in removed) and any(_is_ocr(t.where) for t in added):
        from watcher.ocr import normalize
        pool: dict = {}
        for a in added:
            if _is_ocr(a.where):
                pool.setdefault(normalize(a.text), []).append(a)
        drop_r2, drop_a2 = set(), set()
        for r in removed:
            if not _is_ocr(r.where):
                continue
            k = normalize(r.text)
            if k and pool.get(k):
                a = pool[k].pop(0)
                drop_r2.add(id(r)); drop_a2.add(id(a))
        # 유사도 짝짓기는 쓰지 않는다 — 0.85 규칙이 M12x40→45·8EA→6EA·체결→용접 같은 진짜 변경을 삼켰다
        # (리뷰13 치명-2). 흔들림은 혼동 문자 정규화로만 흡수한다

        # 짝이 없는 짧은 OCR 조각(정규화 8자 이하, 숫자 없거나 한글이 절반 이상)은 그림을 글자로 읽은 잡음으로
        # 본다 — 재스캔마다 생겼다 사라지는 '이 조 리 도'·'커 0 프' 같은 조각. 숫자·긴 줄은 변경으로 남긴다
        def _noise(t) -> bool:
            # '이 조 리 도'·'• 커 0 프'처럼 한 글자씩 끊긴 조각만 — 토큰이 모두 2자 이하이고 전체 8자 이하.
            # '승인'·'폐기'는 한 토큰이라 2자 규칙에 걸리므로 낱말 하나짜리는 남긴다 (리뷰13 낮음-4)
            k = normalize(t.text)
            if not _is_ocr(t.where) or len(k) > 8:
                return False
            toks = [x for x in str(t.text).split() if normalize(x)]
            return len(toks) >= 2 and all(len(normalize(x)) <= 2 for x in toks)
        removed = [t for t in removed if id(t) not in drop_r2 and not _noise(t)]
        added = [t for t in added if id(t) not in drop_a2 and not _noise(t)]
    # 'SHEET 1 OF 4' → 'SHEET 1 OF 3' — 쪽수가 바뀌면 전 페이지가 함께 바뀌는 줄. 양쪽에 다 있으면
    # 재부여로 본다 (2026-09-06 사용성 4차 ④-3: 2쪽 지운 도면이 글자 변경 3줄로)
    tot_r = {_SHEET_OF.match(t.text).group(1) for t in removed if _SHEET_OF.match(t.text)}
    tot_a = {_SHEET_OF.match(t.text).group(1) for t in added if _SHEET_OF.match(t.text)}
    if tot_r and tot_a and tot_r != tot_a:            # 전체 쪽수(m)가 바뀐 경우만 — 같은 쪽수에서 번호만 바뀌면 진짜 변경
        removed = [t for t in removed if not _SHEET_OF.match(t.text)]
        added = [t for t in added if not _SHEET_OF.match(t.text)]

    # 태그 단위 짝짓기를 낱말 상쇄보다 **먼저** 한다 — 두 줄 사이에서 값이 맞바뀌면
    # (M-101 5.5kW ↔ M-102 7.5kW) 낱말 집합은 같아 상쇄에서 전부 사라지고 "내용 변경
    # 없음"이 됐다 (검토19 감지 ①). 재출력 줄바꿈 조각(태그 없는 짧은 줄로 갈라진 낱말)은
    # 여전히 상쇄에 맡긴다: 달라진 낱말이 전부 태그 없는 조각에서 나오면 짝짓지 않는다
    tag_pairs: list = []
    if removed and added:
        rm_by_tag0: dict = {}
        for t in removed:
            tag = _tag_of(t.text)
            if tag and tag not in rm_by_tag0:
                rm_by_tag0[tag] = t
        frag_ad_lines = [t.text.split() for t in added if not _tag_of(t.text)]
        frag_rm_lines = [t.text.split() for t in removed if not _tag_of(t.text)]

        def _covered(tok, frags, base_toks) -> bool:
            # 줄바꿈 조각으로 보려면 그 조각 줄의 **모든** 낱말이 짝 후보 줄의 낱말이어야 한다 —
            # 'SPARE MOTOR 5.5kW' 같은 남의 줄에 낱말이 있다고 조각으로 봐, 태그 줄과
            # 비태그 줄 사이의 값 맞바꿈이 "변경 없음"이 됐다 (검토19 2차 감지 N3)
            return any(tok in fl and all(x in base_toks for x in fl) for fl in frags)
        used_r0: set = set()
        used_a0: set = set()
        for a in added:
            tag = _tag_of(a.text)
            o = rm_by_tag0.get(tag) if tag else None
            if o is None or id(o) in used_r0:
                continue
            if " ".join(o.text.split()) == " ".join(a.text.split()):
                continue
            o_toks, a_toks = o.text.split(), a.text.split()
            o_only = [x for x in o_toks if x not in a_toks]
            a_only = [x for x in a_toks if x not in o_toks]
            wrap_noise = (all(_covered(x, frag_ad_lines, o_toks) for x in o_only)
                          and all(_covered(x, frag_rm_lines, a_toks) for x in a_only))
            if wrap_noise:
                continue
            used_r0.add(id(o))
            used_a0.add(id(a))
            tag_pairs.append(ChangeItem("TEXT_CHANGED", tag, o.text, a.text, a.where))
        removed = [t for t in removed if id(t) not in used_r0]
        added = [t for t in added if id(t) not in used_a0]

    rm_tokens = Counter(tok for t in removed for tok in t.text.split())
    ad_tokens = Counter(tok for t in added for tok in t.text.split())
    real_rm = rm_tokens - ad_tokens
    real_ad = ad_tokens - rm_tokens
    # 문단 끝에 덧붙인 수정("…기준)" → "…기준) ※ 고객 요청…")은 삭제 줄의 낱말이
    # 전부 추가 줄에 들어 있어 '줄바꿈 소음'으로 버려지고 TEXT_ADDED만 남았다
    # (2026-09-03 검토: 사양서·계약서). 실제 낱말 증감이 있는 쌍 가운데 접두/유사한
    # 삭제+추가는 '변경' 한 건으로 짝짓는다. 순수 재배치(양쪽 다 새 낱말 없음)는 제외
    pre: list = list(tag_pairs)
    if removed and added and len(removed) * len(added) <= 40000:
        from difflib import SequenceMatcher
        used_r: set = set()
        used_a: set = set()
        for r in removed:
            if _tag_of(r.text):
                continue
            r_real = any(tok in real_rm for tok in r.text.split())
            r_label = _line_label(r.text)
            best = None
            for a in added:
                if id(a) in used_a or _tag_of(a.text):
                    continue
                if not (r_real or any(tok in real_ad for tok in a.text.split())):
                    continue
                shorter, longer = sorted((len(r.text), len(a.text)))
                if r_label and r_label == _line_label(a.text) and (
                        not _NUMERIC_LABEL.match(r.text) or SequenceMatcher(
                            None, _after_label(r.text), _after_label(a.text)).ratio() >= 0.5):
                    ratio = 1.0                     # "4. 출하 일정은 …" ↔ "4. 출하 일정은 …" 같은 항목;
                    # '종합 판정: 합격' → '종합 판정: 재검사'는 값이 통째로 바뀌어도 그 항목의 변경
                elif (a.text.startswith(r.text) or r.text.startswith(a.text)) \
                        and shorter >= 0.6 * longer:   # 재출력 줄바꿈 조각은 접두가 아니다
                    ratio = 1.0
                else:
                    ratio = SequenceMatcher(None, r.text, a.text).ratio()
                if ratio >= 0.75 and (best is None or ratio > best[0]):
                    best = (ratio, a)
            if best is not None:
                used_r.add(id(r))
                used_a.add(id(best[1]))
                pre.append(ChangeItem("TEXT_CHANGED", r.text[:30], r.text, best[1].text,
                                      best[1].where))
        removed = [t for t in removed if id(t) not in used_r]
        added = [t for t in added if id(t) not in used_a]
    removed = [t for t in removed if any(tok in real_rm for tok in t.text.split())]
    rm_tags = {_tag_of(t.text) for t in removed if _tag_of(t.text)}
    added = [t for t in added if any(tok in real_ad for tok in t.text.split())
             or (_tag_of(t.text) and _tag_of(t.text) in rm_tags)]
    # 같은 자리(같은 페이지)에 짧은 줄 하나가 사라지고 하나가 생겼으면 그 값의 변경 —
    # 도면 치수 '320' → '340' (2026-09-06 블라인드 2차 44)
    if len(removed) == 1 and len(added) == 1 and len(removed[0].text) <= 12 and len(added[0].text) <= 12 \
            and _page_of(removed[0].where) == _page_of(added[0].where) \
            and not _tag_of(removed[0].text) and not _tag_of(added[0].text):
        pre.append(ChangeItem("TEXT_CHANGED", removed[0].text[:30], removed[0].text, added[0].text, added[0].where))
        removed, added = [], []

    items = pre
    items += _moved_labelled_lines(old_lines, new_lines)
    paired: set = set()
    removed_by_tag = {}
    for t in removed:
        tag = _tag_of(t.text)
        if tag and tag not in removed_by_tag:
            removed_by_tag[tag] = t
    for t in added:
        tag = _tag_of(t.text)
        if tag and tag in removed_by_tag and removed_by_tag[tag] not in paired:
            o = removed_by_tag[tag]
            paired.add(o)
            items.append(ChangeItem("TEXT_CHANGED", tag, o.text, t.text, t.where))
        else:
            items.append(ChangeItem("TEXT_ADDED", tag or t.text[:30], None, t.text, t.where))
    for t in removed:
        if t not in paired:
            key = _tag_of(t.text) or t.text[:30]
            items.append(ChangeItem("TEXT_REMOVED", key, t.text, None, t.where))
    return items


def _group_repeats(items: list[ChangeItem], page_count: int = 0) -> list[ChangeItem]:
    """같은 텍스트의 추가/삭제 반복을 1건으로 묶는다 ('외 N곳' 표기).
    페이지마다 반복되는 표제란 라벨·회사명이 페이지 수 변화로 수십 건씩
    나열되던 소음 제거 (2026-08-23 실사용 발견: 331건 → 고유 121종).

    페이지 절반 이상에서 반복된 변경은 '전 페이지 공통'으로 표시한다 —
    표제란·테두리 양식 변경이 회로 변경과 섞여 보고서를 도배하는 것 구분용."""
    order: list = []          # 첫 등장 순서의 (그룹키 또는 원본 항목)
    first: dict[tuple, ChangeItem] = {}
    counts: Counter = Counter()
    for i in items:
        if i.kind in ("TEXT_ADDED", "TEXT_REMOVED", "TEXT_CHANGED"):
            gkey = (i.kind, i.old, i.new)
            counts[gkey] += 1
            if gkey not in first:
                first[gkey] = i
                order.append(gkey)
        else:
            order.append(i)
    out: list[ChangeItem] = []
    for entry in order:
        if isinstance(entry, ChangeItem):
            out.append(entry)
            continue
        i, n = first[entry], counts[entry]
        where = i.where if n == 1 else f"{i.where} 외 {n - 1}곳"
        if page_count >= 4 and n >= (page_count + 1) // 2:
            where += " — 전 페이지 공통(표제란·양식 변경 가능성)"
        out.append(ChangeItem(i.kind, i.key, i.old, i.new, where))
    return out


_REORDER_NOTE = re.compile(r"^행 순서만 바뀜 — (\d+)행 자리 바뀜")


# 표제란 **칸 한 줄**만 — 라벨 + 콜론 + 짧은 값 하나로 끝나는 줄. 'REVISION NOTE: …'·'DATE OF TEST: …' 같은
# 본문 문장까지 걸러 변경을 삼켰다 (검토21 재검증 N1, 원칙 5)
_TITLE_LINE = re.compile(
    r"^\s*(DWG\.?[ ._]*NO\.?|DRAWING\s*NO\.?|도면\s*번호|PROJECT|프로젝트|REV(?:ISION)?\.?|리비전|DATE|일자)"
    r"\s*[:：]\s*\S{1,24}\s*$",
    re.IGNORECASE)
_PAGE_OF = re.compile(r"(\d+)페이지")


def _field_page(doc: Document):
    """표제란 필드가 놓인 쪽 번호 (PDF 세트) — 없으면 None."""
    for f in (doc.fields or {}).values():
        m = _PAGE_OF.search(str(getattr(f, "where", "") or ""))
        if m:
            return m.group(1)
    return None


def diff_documents(old: Document, new: Document) -> list[ChangeItem]:
    items = _diff_fields(old, new)
    items += _diff_rows(old.rows, new.rows, "ROW")
    items += _diff_rows(old.revision_history, new.revision_history, "REVROW")
    texts = _diff_texts(old, new)
    # 도면 세트 PDF는 표제란 줄을 본문에도 두므로(pdf.py) 표제란이 있는 쪽의 라벨 줄 변경은
    # FIELD_CHANGED와 겹친다 — 글자 쪽을 걸러 한 번만 말한다 (검토21 감지 차단 3)
    pages = {p for p in (_field_page(old), _field_page(new)) if p}
    # 여러 쪽 문서에서만 — 한 쪽 PDF는 표제란 줄을 본문에 두지 않으므로 걸러낼 것이 없고, 걸러내면
    # 본문의 'REV: C' 같은 줄 변경을 잃는다 (검토21 재검증 N1)
    if pages and (len(_pages(old.raw_texts)) > 1 or len(_pages(new.raw_texts)) > 1):
        texts = [i for i in texts
                 if not (i.kind in ("TEXT_ADDED", "TEXT_REMOVED", "TEXT_CHANGED")
                         and any(str(i.where or "").startswith(f"{p}페이지") for p in pages)
                         and _TITLE_LINE.match(str(i.new or i.old or "")))]
    items += texts
    # '행 순서만 바뀜 … 내용 변경 없음' 참고는 문서 전체에 다른 변경이 없을 때만 참이다 — 다른 시트의
    # 값 변경·제목 변경이 있으면 그 파일이 통째로 접혔다 (리뷰11 중간-G)
    notes = [i for i in items if i.kind == "CHECK_SKIPPED" and i.key == "참고" and _REORDER_NOTE.match(str(i.new or ""))]
    if notes and any(i.kind in CONTENT_KINDS for i in items):
        items = [i for i in items if i not in notes]
        for n in notes:
            cnt = _REORDER_NOTE.match(str(n.new)).group(1)
            items.append(ChangeItem("ROW_MOVED", "행 순서", None, f"{cnt}행 자리 바뀜 (값은 위 항목 외 그대로)",
                                    n.where, label="행 순서 재정렬"))
    # 옆으로 놓인 표의 제목 변경은 '표 제목 변경' 한 건이다 — 같은 글자의 TEXT_CHANGED를 겹쳐 내지 않는다 (리뷰11 낮음-N)
    renames = [(i.old.split("·", 1)[1], i.new.split("·", 1)[1]) for i in items
               if i.kind == "SHEET_RENAMED" and "·" in str(i.old or "") and "·" in str(i.new or "")]
    if renames:
        items = [i for i in items if not (i.kind == "TEXT_CHANGED" and any(
            a in str(i.old or "") and b in str(i.new or "") for a, b in renames))]
    return items


def content_items(items: list[ChangeItem]) -> list[ChangeItem]:
    """'내용' 변경만 (표제란·리비전 블록 제외). Rev 일관성 판단의 기준.
    페이지 전체가 살짝 어긋난 그림 변경(재스캔·기울기)은 근거가 못 된다 (2026-09-06 사용성 5차)."""
    return [i for i in items if i.kind in CONTENT_KINDS
            and not (i.kind == "PAGE_VISUAL_CHANGED" and "전체가 살짝 어긋남" in str(i.where or ""))]
