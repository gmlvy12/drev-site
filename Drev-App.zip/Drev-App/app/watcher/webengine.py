# -*- coding: utf-8 -*-
"""창 엔진(WebView2)이 이 PC에서 정말 쓸 수 있는지 (2026-09-02).

회사 PC에서 창은 로딩·클릭 불가인데 같은 주소를 브라우저로 열면 정상이었다.
pywebview는 WebView2 런타임이 없거나 .NET Framework가 4.6.2 미만이면 **조용히
구형 IE 엔진(MSHTML)** 으로 창을 띄운다 — 우리 화면(CSS 변수·fetch·details)은
IE에서 깨져 정확히 "로딩처럼 보이고 클릭이 안 되는" 창이 된다. 집 PC에는
런타임이 있어 티가 안 났다.

여기서는 pywebview와 **같은 기준**으로 미리 판정해, IE로 떨어질 상황이면
창을 열지 않고 사람에게 이유와 해결책(런타임 설치)을 준다. 레지스트리 읽기만.
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

RUNTIME_KEY = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"     # Evergreen 런타임
BETA_KEY = "{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}"
DOTNET_MIN_RELEASE = 394802                                 # .NET Framework 4.6.2
BOOTSTRAPPER = "MicrosoftEdgeWebview2Setup.exe"             # MS 배포 허용 설치기
BOOTSTRAPPER_URL = "https://go.microsoft.com/fwlink/p/?LinkId=2124703"


def _reg_value(root_name: str, path: str, name: str):
    try:
        import winreg
        with winreg.OpenKey(getattr(winreg, root_name), path) as k:
            v, _ = winreg.QueryValueEx(k, name)
            return v
    except Exception:
        return None


def webview2_version() -> str | None:
    """설치된 WebView2 런타임 버전. 없으면 None. (pywebview와 같은 위치를 본다)"""
    if sys.platform != "win32":
        return None
    x86 = platform.machine().lower() in ("x86", "i386", "i686")
    for key in (RUNTIME_KEY, BETA_KEY):
        for root in ("HKEY_LOCAL_MACHINE", "HKEY_CURRENT_USER"):
            sub = (rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{key}"
                   if (x86 or root == "HKEY_CURRENT_USER") else
                   rf"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{key}")
            v = _reg_value(root, sub, "pv")
            if v and str(v).strip() not in ("", "0.0.0.0"):
                return str(v).strip()
    return None


def dotnet_release() -> int:
    """설치된 .NET Framework 4.x Release 번호 (없으면 0)."""
    if sys.platform != "win32":
        return 0
    v = _reg_value("HKEY_LOCAL_MACHINE",
                   r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full", "Release")
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        return 0


def engine_check() -> tuple[bool, str]:
    """(창 엔진을 써도 되는가, 사람에게 보여줄 이유)."""
    if sys.platform != "win32":
        return False, "윈도우가 아닙니다"
    rel = dotnet_release()
    if rel and rel < DOTNET_MIN_RELEASE:
        return False, (f".NET Framework가 오래되었습니다(Release {rel} < 4.6.2) — "
                       f"이 상태에서는 창이 구형 IE 엔진으로 열려 화면이 깨집니다")
    ver = webview2_version()
    if not ver:
        return False, ("WebView2 런타임이 이 PC에 없습니다 — 이 상태에서는 창이 "
                       "구형 IE 엔진으로 열려 화면이 깨집니다(로딩처럼 보이고 클릭 불가)")
    return True, f"WebView2 {ver}"


def bootstrapper_path(app_dir: Path | None = None) -> Path | None:
    """설치본에 동봉된 런타임 설치기 경로 (없으면 None)."""
    base = app_dir or Path.cwd()
    for cand in (base / BOOTSTRAPPER, base / "python" / BOOTSTRAPPER):
        if cand.is_file():
            return cand
    return None


def no_proxy_args() -> str:
    """창 엔진에 넘길 추가 인자 — 127.0.0.1만 보는 창이 회사 프록시를 타지 않게.

    WebView2 로더가 환경변수 WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS를 읽는다."""
    cur = os.environ.get("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "")
    if "--no-proxy-server" in cur:
        return cur
    return (cur + " --no-proxy-server").strip()


# 창 엔진(Edge WebView2)이 스스로 하는 바깥 통신을 줄이는 인수 (2026-10-19 구매 평가 2차 IT 심사: 창 모드에서
# msedgewebview2.exe가 Microsoft 주소 443에 1회 연결 실측). 화면은 127.0.0.1만 보므로 백그라운드 네트워킹·구성요소
# 업데이트·SmartScreen(평판 조회)·번역·자동완성 서버 통신·진단 보고가 필요 없다. 런타임 자체의 자동 업데이트는
# Edge Update 서비스 몫이라 이 인수로는 끌 수 없다 — 그 사실은 설정 화면·사이트 보안 검토 자료에 적는다.
QUIET_ARGS = (
    "--no-proxy-server",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-domain-reliability",
    "--disable-client-side-phishing-detection",
    "--disable-sync",
    "--no-pings",
    "--metrics-recording-only",
    "--disable-breakpad",
    "--disable-features=msSmartScreenProtection,OptimizationHints,Translate,msEdgeTranslate,"
    "MediaRouter,AutofillServerCommunication,msEdgeShoppingAssistant",
)


def window_browser_args(cur: str | None = None) -> str:
    """창 엔진 추가 인자 — 프록시 우회(no_proxy_args) + 바깥 통신 줄이기(QUIET_ARGS). 이미 있는 인자는 두 번 넣지 않는다.
    사용자가 환경변수로 --disable-features를 이미 줬으면 우리 것은 넣지 않는다(뒤 값이 앞 값을 덮어 그쪽 설정이 사라지지 않게)."""
    cur = os.environ.get("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "") if cur is None else cur
    out = cur.split()
    for a in QUIET_ARGS:
        name = a.split("=", 1)[0]
        if any(x.split("=", 1)[0] == name for x in out):
            continue
        out.append(a)
    return " ".join(out).strip()


def describe() -> str:
    """진단 한 줄 — 시작 로그·설정 화면에 그대로 찍는다."""
    ok, why = engine_check()
    return (f"창 엔진: {'사용 가능' if ok else '사용 불가'} — {why}; "
            f".NET Release {dotnet_release()}; "
            f"프록시 env {'있음' if any(os.environ.get(k) for k in ('HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy')) else '없음'}")
