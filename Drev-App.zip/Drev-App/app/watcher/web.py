# -*- coding: utf-8 -*-
"""로컬 웹 대시보드 (127.0.0.1 전용, 표준 라이브러리만).

exe 더블클릭 진입점: 서버를 띄우고 기본 브라우저를 연다.
사이드바 카테고리(대시보드/도면/BOM/문서/프로젝트/이력/설정)로 분리 조회,
[지금 검사] 실행, 감시 제외 폴더 관리, 확인(/ack) 링크 처리까지 한 포트에서 담당.
외부 노출 없음 — 산출물이 브라우저 밖으로 나가지 않는다.
"""

from __future__ import annotations

import argparse
import functools
import hmac as _hmac
import html
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from http.server import ThreadingHTTPServer
from pathlib import Path, PurePosixPath
import urllib.parse
import urllib.request

import yaml
from urllib.parse import parse_qs, quote, urlparse

from watcher import __version__
from watcher.ack_server import make_handler
from watcher.consistency import CODE_LABEL
from watcher.state import KIND_LABEL, CorruptDatabase, State

# 문서 유형 카테고리 (파일럿: PDF 도면 중심이라 pdf는 도면으로 분류)
from watcher.extract import FORMATS as _FORMATS  # noqa: E402  형식 레지스트리에서 파생

CATEGORIES = {
    "도면": tuple(e for e, f in _FORMATS.items() if f["kind"] == "도면"),
    "BOM": tuple(e for e, f in _FORMATS.items() if f["kind"] == "표"),
    "문서": tuple(e for e, f in _FORMATS.items() if f["kind"] == "문서"),
}

# 도면 세부 유형: 파일명·폴더명 키워드로 분류 (config drawing_types로 교체 가능).
# 회사마다 부르는 이름이 달라 키워드 사전 방식 — 어디에도 안 걸리면 "기타 도면"
DRAWING_SUBTYPES = {
    "P&ID": ["P&ID", "PID", "PNID", "P&amp;ID", "계장"],
    "단선도": ["단선도", "단결선", "SLD", "SINGLE LINE", "ONELINE", "ONE-LINE"],
    "결선도": ["결선도", "배선도", "WIRING", "CONNECTION"],
    "회로도": ["회로도", "SCHEMATIC", "CIRCUIT"],
    "배치도": ["배치도", "레이아웃", "LAYOUT", "설치도", "ARRANGEMENT", "GA"],
    "외형도": ["외형도", "치수도", "OUTLINE", "DIMENSION"],
}
SUBTYPE_ETC = "기타 도면"


def _drawing_subtype(path: str, mapping: dict | None = None) -> str:
    """경로(파일명+폴더명) 전체에서 키워드를 찾아 도면 세부 유형을 정한다."""
    up = path.upper()
    for sub, keys in (mapping or DRAWING_SUBTYPES).items():
        if any(k.upper() in up for k in keys):
            return sub
    return SUBTYPE_ETC

_E = lambda s: html.escape(str(s), quote=True)  # noqa: E731

CSS = """
/* 디자인 토큰 — 라이트 기본, [data-theme=dark]에서 재정의 (정의부는 대문자 HEX:
   본문 인라인 스타일의 소문자 hex 일괄 치환과 충돌하지 않게 하기 위한 규칙) */
:root{
  --bg:#F2F4F8; --panel:#FFFFFF; --panel2:#F7F8FB; --hover:#EEF0F6;
  --border:#E3E6EE; --border2:#C9CEDB; --line:#EEF0F5;
  --text:#171C26; --text2:#2A303C; --text3:#454D5E;
  --muted:#596273; --muted2:#6C7890;   /* 2026-09-02 대비 상향 */
  --link:#4353E8; --accent:#4353E8; --accent2:#5B6CF5; --on-accent:#FFFFFF;
  --ok:#0F8A3D; --ok-strong:#0F7A37;
  --warn:#B97800; --warn2:#9A6700; --warn3:#8A5A05;
  --bad:#C62F2F; --bad2:#B02A2A;
  --tag-add:#E2F5E9; --tag-mod:#FBF0D9; --tag-rm:#FBE7E7; --tag-done:#E5E9FD;
  --note-warn:#FFF8E5; --note-info:#E8ECFE;
  --shadow:0 1px 3px rgba(23,28,38,.06), 0 1px 2px rgba(23,28,38,.04);
  --shadow-lg:0 8px 24px rgba(23,28,38,.10);
}
[data-theme=dark]{
  --bg:#0C0E12; --panel:#14171D; --panel2:#1A1E26; --hover:#212634;
  --border:#232833; --border2:#333B4A; --line:#1E242F;
  --text:#E6E9EF; --text2:#CBD1DC; --text3:#ADB5C4;
  --muted:#AAB2C1; --muted2:#8E97A8;   /* 2026-09-02 대비 상향 — 검은 바탕 회색 글씨 */
  --link:#93A0FA; --accent:#5D6EF5; --accent2:#7C8CF8; --on-accent:#FFFFFF;
  --ok:#3FB950; --ok-strong:#4ADE80;
  --warn:#E3B341; --warn2:#E0B75E; --warn3:#EAB94E;
  --bad:#F47067; --bad2:#F47067;
  --tag-add:rgba(63,185,80,.14); --tag-mod:rgba(227,179,65,.14);
  --tag-rm:rgba(244,112,103,.15); --tag-done:rgba(124,140,248,.16);
  --note-warn:#2E2612; --note-info:#1B2140;
  --shadow:0 1px 3px rgba(0,0,0,.45);
  --shadow-lg:0 10px 28px rgba(0,0,0,.55);
}
*{margin:0;box-sizing:border-box;
  font-family:'Pretendard','Malgun Gothic','Segoe UI Variable','Segoe UI',sans-serif}
html{color-scheme:light}
html[data-theme=dark]{color-scheme:dark}
body{background:var(--bg);color:var(--text);display:flex;min-height:100vh;
  -webkit-font-smoothing:antialiased;transition:background .25s}
a{text-decoration:none;color:inherit}
::selection{background:var(--accent);color:var(--on-accent)}
/* overflow-y가 없으면 글자를 키웠을 때 맨 아래 [⚙ 보기 설정]이 화면 밖으로 나가고,
   사이드바가 fixed라 페이지 스크롤로도 닿지 않는다 — 키운 글자를 되돌릴 길이 사라졌다
   (2026-09-08 검토17 차단 R1: 1366×768에서도 1600×900에서도 갇힘) */
.side{width:216px;background:var(--panel);border-right:1px solid var(--border);
  padding:18px 12px;position:fixed;top:0;bottom:0;display:flex;flex-direction:column;
  overflow-y:auto;overscroll-behavior:contain}
.logo{font-weight:800;font-size:17px;color:var(--link);padding:6px 10px 16px;
  letter-spacing:-.2px}
.logo small{display:block;color:var(--muted);font-weight:400;font-size:12px;
  margin-top:3px;letter-spacing:0}
/* 사이드바 상시 검색 — 어느 화면에서든 바로 검색 (2026-08-29 요청) */
/* 왼쪽 메뉴 맨 위의 업데이트 자리 — 새 버전이 있으면 그 자리가 설치 단추가 된다 (2026-09-07) */
.side-upd{display:block;width:calc(100% - 12px);margin:0 6px 10px;padding:7px 10px;border-radius:9px;
 border:1px solid var(--border);background:var(--panel2);color:var(--muted);font-size:12px;
 text-align:center;cursor:pointer;text-decoration:none;box-sizing:border-box}
.side-upd:hover{border-color:var(--border2);color:var(--text)}
.side-upd.new{border-color:var(--accent);background:var(--accent);color:#fff;font-weight:600;font-size:13px}
.side-upd.new:hover{filter:brightness(1.08);color:#fff}
.side-upd.busy{border-color:var(--accent);color:var(--accent);cursor:default}
/* 키보드만 쓰는 사람이 사이드바 메뉴 28개를 지나지 않고 본문으로 (조작성 검토 치명-3) */
.skip{position:absolute;left:-9999px;top:0;z-index:200;background:var(--accent);color:#fff;
 padding:8px 14px;border-radius:0 0 8px 0;text-decoration:none;font-size:13px}
.skip:focus{left:0}
/* 매일 가장 많이 누르는 단추가 58×23px이라 손이 자주 빗나갔다 (검토 중간, WCAG 24×24 미만) */
.ackq button{min-height:26px;padding:3px 12px}
.pick-label{font-size:11px;color:var(--muted);margin:8px 0 3px;padding:0 2px}
.dense-pick button.on{background:var(--accent);color:#fff;border-color:var(--accent)}
.side-shell{display:block;margin:0 6px 8px;padding:5px 10px;border-radius:9px;font-size:11.5px;
 text-align:center;text-decoration:none;color:var(--warn2);border:1px dashed var(--warn2)}
.side-shell:hover{background:var(--hover)}
.side-search{margin:0 6px 12px}
.side-search input{width:100%;border:1px solid var(--border);border-radius:9px;
  padding:7px 11px;font-size:12.5px;background:var(--panel2);color:var(--text)}
.side-search input:focus{outline:2px solid var(--accent2);border-color:var(--accent)}
.nav{flex:1}
.nav a{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:9px;min-height:36px;
  color:var(--text3);font-size:14px;margin-bottom:2px;
  transition:background .15s,color .15s}
.nav a svg{width:16px;height:16px;flex:none;opacity:.75}
/* 묶음 이름표 — 메뉴 18개가 한 덩어리라 무엇이 어디 있는지 안 보였다 (검토22 U6, 2026-09-17 요청) */
.nav .grp{font-size:11px;color:var(--muted);letter-spacing:.6px;padding:12px 12px 4px;text-transform:uppercase}
.nav details.grp-fold{margin:0}
.nav details.grp-fold summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:10px;
  padding:9px 12px;min-height:36px;border-radius:9px;color:var(--text3);font-size:14px}
.nav details.grp-fold summary::-webkit-details-marker{display:none}
.nav details.grp-fold summary svg{width:16px;height:16px;flex:none;opacity:.75}
.nav details.grp-fold summary:hover{background:var(--hover);color:var(--text)}
.nav details.grp-fold summary .tri{margin-left:auto;font-size:11px;opacity:.7;transition:transform .15s}
.nav details.grp-fold[open] summary .tri{transform:rotate(90deg)}
.nav details.grp-fold a{padding-left:34px;font-size:13.5px}
.nav a.on svg,.nav a:hover svg{opacity:1}
.nav a:hover{background:var(--hover);color:var(--text)}
.nav a.on{background:var(--accent);color:var(--on-accent);font-weight:700}
.theme-btn{margin:10px 6px 2px;padding:8px 12px;border-radius:10px;font-size:12.5px;
  border:1px solid var(--border);background:var(--panel2);color:var(--muted);
  cursor:pointer;transition:background .15s,color .15s;
  display:flex;align-items:center;gap:8px;justify-content:center}
.theme-btn svg{width:14px;height:14px;flex:none}
.theme-btn:hover{background:var(--hover);color:var(--text)}
.dense-pick{display:flex;gap:4px;margin:6px 6px 2px}
.dense-pick button{flex:1;font-size:12px;padding:5px 0;border-radius:8px;
  border:1px solid var(--border);background:var(--panel2);color:var(--muted);
  cursor:pointer}
.dense-pick button:hover{background:var(--hover);color:var(--text)}
/* min-width:0이 없으면 flex 항목이 내용 폭 밑으로 못 줄어 화면 밖으로 밀린다 —
   1280 창을 125%로 확대한 폭(1026px)에서 가로 스크롤이 생기던 원인 (조작성 검토 치명-5) */
.main{margin-left:216px;flex:1;min-width:0;padding:22px 30px;max-width:1680px}
/* 글이 주인 화면(도움말·설명)은 읽기 좋은 폭을 유지 */
.readable{max-width:900px}
/* flex-wrap이 없어 921~1074px 구간(=1280 창의 125% 확대)에서 [지금 검사]가 화면 밖으로
   나가고 가로 스크롤이 생겼다 (2026-09-08 조작성 검토 치명-5) */
.topbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;
  margin-bottom:18px;gap:12px}
.topbar h1{font-size:20px;font-weight:800;letter-spacing:-.3px}
.btn{background:var(--accent);
  color:var(--on-accent);border:none;border-radius:9px;
  padding:8px 16px;font-size:13px;cursor:pointer;font-weight:700;
  transition:filter .15s,transform .05s}
.btn:hover{filter:brightness(1.08)}
.btn:active{transform:translateY(1px)}
.btn.gray{background:var(--panel2);color:var(--text2);border:1px solid var(--border);
  box-shadow:none}
.btn.red{background:var(--bad);color:#fff;box-shadow:none}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;
  margin-bottom:12px}
.card{background:var(--panel);border-radius:12px;padding:13px 16px;
  border:1px solid var(--border);box-shadow:var(--shadow);
  transition:box-shadow .2s,transform .2s,border-color .15s}
a.card:hover{box-shadow:var(--shadow-lg);transform:translateY(-1px);
  border-color:var(--accent)}
.card .k{color:var(--muted);font-size:12px;margin-bottom:4px}
.card .v{font-size:27px;font-weight:800;letter-spacing:-.8px;line-height:1.1;
  font-variant-numeric:tabular-nums}
.card .v small{font-size:12px;color:var(--muted);font-weight:400;letter-spacing:0}
.card .v.warn{color:var(--warn)}.card .v.bad{color:var(--bad)}.card .v.ok{color:var(--ok)}
.panel{background:var(--panel);border-radius:12px;padding:13px 16px;margin-bottom:12px;
  border:1px solid var(--border);box-shadow:var(--shadow);overflow-x:auto}
.panel h2{font-size:13.5px;margin-bottom:10px;color:var(--text);font-weight:700;
  letter-spacing:0;padding-bottom:6px;border-bottom:1px solid var(--line)}
/* fr 칸은 내용보다 좁아지지 않는다(min-width:auto) — 폭이 줄면 격자가 상자를 뚫고 나가
   가로 스크롤이 생겼다. minmax(0,…)로 줄어들 수 있게 (2026-09-08 조작성 검토 치명-5) */
.grid2{display:grid;grid-template-columns:minmax(0,3fr) minmax(0,2fr);gap:12px;align-items:start}
table{width:100%;border-collapse:collapse;font-size:13.5px}
th{color:var(--muted);font-weight:600;text-align:left;padding:6px 10px;
  border-bottom:1px solid var(--border);font-size:10.5px;letter-spacing:.6px;
  text-transform:uppercase;background:var(--panel2);white-space:nowrap}
td{padding:6px 10px;border-bottom:1px solid var(--line);
  font-variant-numeric:tabular-nums}
tr{transition:background .1s}
tr:hover td{background:var(--panel2)}
.tag{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;
  font-weight:600;white-space:nowrap}
.tag.added{background:var(--tag-add);color:var(--ok-strong)}
.tag.modified{background:var(--tag-mod);color:var(--warn3)}
.tag.removed{background:var(--tag-rm);color:var(--bad2)}
.tag.na{background:var(--hover);color:var(--muted)}
.tag.done{background:var(--hover);color:var(--muted)}
.tag.done::before{content:"✓ ";font-weight:800}
.bar{height:8px;border-radius:999px;background:var(--border);overflow:hidden}
.bar i{display:block;height:100%;background:var(--accent)}
.proj{display:flex;align-items:center;gap:10px;padding:7px 0}
.proj .nm{width:110px;font-weight:600;font-size:13.5px}
.proj .bar{flex:1}
.proj .pc{width:110px;text-align:right;color:var(--muted);font-size:12.5px}
.muted{color:var(--muted2);font-size:13px}
form.inline{display:inline}
.wdel{background:#fee2e2;color:#991b1b;text-decoration:line-through;border-radius:3px;padding:0 2px}
.wins{background:#dcfce7;color:#166534;font-weight:700;border-radius:3px;padding:0 2px}
input[type=text],input[type=password]{border:1px solid var(--border2);
  border-radius:8px;padding:8px 10px;font-size:13.5px;
  background:var(--panel);color:var(--text)}
input[type=text]:focus,input[type=password]:focus{outline:2px solid var(--accent2);
  outline-offset:0;border-color:var(--accent)}
input::placeholder{color:var(--muted2)}
button{font-family:inherit}
details summary{color:var(--muted);cursor:pointer}
.chart{display:flex;align-items:flex-end;gap:6px;height:120px;padding-top:6px}
.chart .col{flex:1;display:flex;flex-direction:column;justify-content:flex-end;
  align-items:center;gap:4px;height:100%}
.chart .col i{width:100%;border-radius:6px 6px 0 0;background:var(--accent)}
.chart .col b{font-size:10.5px;color:var(--muted2);font-weight:400}
select.projsel{border:1px solid var(--border2);border-radius:10px;padding:8px 12px;
  font-size:13.5px;background:var(--panel);color:var(--text);max-width:280px}
.filterbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.filterbar label{font-size:12.5px;color:var(--muted)}
code{background:var(--panel2);border:1px solid var(--line);border-radius:6px;
  padding:1px 5px;font-size:12.5px;color:var(--text)}
/* 표 변경(BOM·인터락 등) — 행 단위로 묶어 보여주는 화면용 표 (2026-08-31).
   메일용 표는 고정 색이라 다크 화면에서 글씨가 묻혔다 */
.rtab{width:100%;border-collapse:collapse;font-size:13px}
.rtab th{white-space:nowrap}
.rtab td{padding:7px 10px;border-bottom:1px solid var(--line);
  vertical-align:top;color:var(--text)}
.rtab td:first-child{white-space:nowrap;width:1%}
.rtab td:nth-child(2){white-space:nowrap;width:1%}
.rtab .cchg{padding:2px 0;line-height:1.55}
.rtab .cchg b{color:var(--text2);font-weight:700}
.rtab .from{color:var(--muted);text-decoration:line-through}
.rtab .to{color:var(--text);font-weight:700}
.rtab .subt{margin-top:5px;border-collapse:collapse;font-size:12px;width:auto}
.rtab .subt td{padding:2px 10px 2px 0;border-bottom:none}
.rtab .subt td.c1{color:var(--muted);white-space:nowrap}
/* 위치 칸이 글자 하나씩 세로로 눌리던 문제 — 최소 폭을 준다 (2026-08-31) */
.rtab td.loc{min-width:130px;white-space:normal;font-size:12px}
.rtab td.val{word-break:break-word;min-width:160px}
.rtab td:last-child{white-space:nowrap;width:1%}
.rtab td:last-child .btn{white-space:nowrap}
/* 화면마다 뒤로가기 — 창 안에는 브라우저 버튼이 없다 (2026-09-02) */
.backbtn{background:none;border:1px solid var(--border2);color:var(--muted);
  border-radius:9px;padding:5px 12px;font-size:12.5px;cursor:pointer;
  margin-bottom:14px;font-family:inherit}
.backbtn:hover{background:var(--hover);color:var(--text);
  border-color:var(--muted2)}
/* 목록에서 바로 누르는 확인 버튼 (2026-09-02) */
.ackbtn{border:none;cursor:pointer;font:inherit;line-height:1.5}
.ackbtn:hover{background:var(--tag-done);color:var(--link)}
.ackbar{margin:0 0 8px;font-size:12px}
.ackbar input{padding:3px 8px;border-radius:7px;border:1px solid var(--border2);
  background:var(--bg2);color:var(--text);font-size:12px}
/* 화면 설명문 — 접으면 화면이 조용해진다 (2026-09-01) */
.intro{position:relative;padding-right:22px}
/* 변경 상세 머리 — 파일 이름이 회색 한 줄에 묻혀 있었다 (2026-09-17) */
.chg-head{background:var(--panel);border-radius:12px;padding:16px 18px;margin-bottom:12px;border:1px solid var(--border)}
.chg-head .fname{font-size:22px;font-weight:800;letter-spacing:-.3px;word-break:break-all}
.chg-head .cpath{color:var(--muted2);font-size:13px;margin-top:4px;word-break:break-all}
.chg-head .chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.chip{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--border2);border-radius:999px;
  padding:3px 10px;font-size:12.5px;color:var(--text3);background:var(--panel2)}
.chip b{color:var(--text)}
.ackbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.ackbar input[type=text]{border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font:inherit}
.intro-x{position:absolute;right:0;top:-2px;background:none;border:none;
  color:var(--muted2);cursor:pointer;font-size:12px;padding:2px 4px;
  border-radius:6px}
.intro-x:hover{background:var(--hover);color:var(--text)}
html[data-tips=off] .intro{display:none}
/* 목록 행의 [열기][폴더]는 마우스를 올렸을 때만 — 매 행에 떠 있으면 소음 */
td .rowact{opacity:0;transition:opacity .12s}
tr:hover td .rowact,td .rowact:focus-within{opacity:1}
/* 유형처럼 짧은 값은 줄바꿈으로 깨지지 않게 ('Interlock'이 세로로 쪼개짐) */
td .kindcell{white-space:nowrap}
/* 사이드바 보기 설정 — 매일 쓰는 기능이 아니라 접어둔다 */
.viewtools > summary{list-style:none;cursor:pointer;color:var(--muted);
  font-size:12px;padding:7px 12px;border-radius:9px}
.viewtools > summary::-webkit-details-marker{display:none}
.viewtools > summary:hover{background:var(--hover);color:var(--text)}
/* 열 너비 손잡이 — 머리글 오른쪽 경계 (2026-09-01) */
th{position:relative}
.colgrip{position:absolute;top:0;right:-3px;width:7px;height:100%;
  cursor:col-resize;user-select:none}
.colgrip:hover{background:var(--accent);opacity:.55;border-radius:2px}
/* 행 간격 — 촘촘/보통/넓게 */
/* 글자 크기 — 본문 글자의 96%가 12~12.5px이고 [넓게]는 행 높이만 키웠다(글자는 그대로).
   창(WebView2)은 Ctrl+/-가 막혀 있어 브라우저 확대에 기댈 수도 없다 (2026-09-08 조작성 검토 치명-4·5).
   zoom은 글자·여백·표를 함께 키워 레이아웃이 무너지지 않는다. */
html[data-fs=big]{zoom:1.15}
html[data-fs=huge]{zoom:1.3}
html[data-dense=tight] td{padding:3px 8px;font-size:12px}
html[data-dense=tight] .pfile{padding:1px 0}
html[data-dense=wide] td{padding:11px 12px;line-height:1.75}
html[data-dense=wide] .rtab td{padding:12px 12px}
/* 글자가 잘리지 않게 — 사용자가 열을 좁히면 줄바꿈으로 흐른다 */
td{overflow-wrap:anywhere}
::-webkit-scrollbar{width:10px;height:10px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:999px}
::-webkit-scrollbar-track{background:transparent}
/* 패널 내부 스크롤 — 항목이 많아도 잘라내지 않고 그 자리에서 내려 본다
   (2026-08-28 요청). 표 머리글은 스크롤 중에도 고정 */
.scrolly{max-height:420px;overflow-y:auto;overscroll-behavior:contain}
.scrolly.sm{max-height:280px}
.scrolly th{position:sticky;top:0;z-index:1}

/* 프로젝트 카드 홈 (2026-08-27) */
.pcards{display:grid;gap:12px;
  grid-template-columns:repeat(auto-fill,minmax(330px,1fr))}
.pcard{background:var(--panel2);border:1px solid var(--border);border-radius:12px;
  padding:14px;display:flex;flex-direction:column;gap:4px;
  transition:box-shadow .2s,transform .2s}
.pcard:hover{box-shadow:var(--shadow-lg);transform:translateY(-1px)}
.pc-head{display:flex;justify-content:space-between;align-items:center;gap:8px;
  margin-bottom:2px}
.pc-head a{font-weight:700;font-size:14.5px;color:var(--link)}
.pfile{font-size:12.5px;padding:3px 0;white-space:nowrap;overflow:hidden;
  text-overflow:ellipsis}
.pc-more{margin-top:auto;padding-top:8px;font-size:12px;color:var(--muted);
  align-self:flex-end}
.pc-more:hover{color:var(--link)}
/* 도움말 가독성 (2026-08-27) */
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
.step{display:flex;gap:12px;background:var(--panel2);border:1px solid var(--border);
  border-radius:12px;padding:14px;font-size:13.5px;line-height:1.65}
.step b{flex:0 0 30px;height:30px;border-radius:999px;background:var(--accent);
  color:var(--on-accent);display:flex;align-items:center;justify-content:center;
  font-size:15px}
details.qa{border-bottom:1px solid var(--line);padding:4px 0}
details.qa:last-child{border-bottom:none}
details.qa summary{padding:9px 4px;font-size:13.5px;font-weight:600;color:var(--text2);
  list-style:none;cursor:pointer}
details.qa summary::before{content:'▸ ';color:var(--muted2)}
details.qa[open] summary::before{content:'▾ '}
details.qa p,details.qa ul{font-size:13.5px;line-height:1.75;color:var(--text3);
  padding:2px 8px 10px 20px;margin:0}
details.qa ul{padding-left:38px}
dl.terms{display:grid;grid-template-columns:110px 1fr;gap:8px 14px;font-size:13.5px;
  line-height:1.6;margin:0}
dl.terms dt{font-weight:700;color:var(--text2)}
dl.terms dd{margin:0;color:var(--text3)}
/* 좁은 창 대응: 사이드바가 상단 가로 메뉴로 접히고, 2단 패널은 1단으로 */
@media (max-width: 920px){
  body{display:block}
  .side{position:static;width:auto;border-right:none;
    border-bottom:1px solid var(--border);
    padding:10px 14px;display:flex;flex-direction:row;align-items:center;gap:12px;
    flex-wrap:wrap}
  .logo{padding:0;font-size:15px}
  .logo small{display:none}
  .side-search{margin:0;flex:1;min-width:150px}
  .nav{display:flex;flex-wrap:wrap;gap:2px;flex:unset}
  .nav a{padding:6px 10px;font-size:13px;margin-bottom:0;white-space:nowrap}
  .theme-btn{margin:0}
  .main{margin-left:0;padding:14px 12px}
  .grid2{grid-template-columns:1fr}
  .topbar{flex-wrap:wrap;gap:10px}
  .cards{grid-template-columns:repeat(auto-fit,minmax(140px,1fr))}
  .card .v{font-size:22px}
}
"""

# 사이드바 선형(스트로크) 아이콘 — 문자 기호(▦⚙)가 촌스럽다는 피드백으로 교체
# (2026-08-29). 외부 리소스 금지 원칙이라 인라인 SVG, currentColor로 테마 자동 추종.
def _ic(inner: str) -> str:
    return (f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" '
            f'aria-hidden="true">{inner}</svg>')


_NAV_ICON = {
    "dash": _ic('<rect x="3" y="3" width="7" height="7" rx="1.5"/>'
                '<rect x="14" y="3" width="7" height="7" rx="1.5"/>'
                '<rect x="14" y="14" width="7" height="7" rx="1.5"/>'
                '<rect x="3" y="14" width="7" height="7" rx="1.5"/>'),
    "issues": _ic('<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0'
                  ' 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>'
                  '<line x1="12" y1="9" x2="12" y2="13"/>'
                  '<line x1="12" y1="17" x2="12.01" y2="17"/>'),
    "brief": _ic('<rect x="2" y="4" width="20" height="16" rx="2"/>'
                 '<polyline points="22,6 12,13 2,6"/>'),
    "dwg": _ic('<rect x="3" y="3" width="18" height="18" rx="2"/>'
               '<line x1="3" y1="9" x2="21" y2="9"/>'
               '<line x1="9" y1="21" x2="9" y2="9"/>'),
    "bom": _ic('<line x1="8" y1="6" x2="21" y2="6"/>'
               '<line x1="8" y1="12" x2="21" y2="12"/>'
               '<line x1="8" y1="18" x2="21" y2="18"/>'
               '<line x1="3" y1="6" x2="3.01" y2="6"/>'
               '<line x1="3" y1="12" x2="3.01" y2="12"/>'
               '<line x1="3" y1="18" x2="3.01" y2="18"/>'),
    "doc": _ic('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 '
               '2-2V8z"/><polyline points="14,2 14,8 20,8"/>'
               '<line x1="8" y1="13" x2="16" y2="13"/>'
               '<line x1="8" y1="17" x2="13" y2="17"/>'),
    "proj": _ic('<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 '
                '2-2h5l2 3h9a2 2 0 0 1 2 2z"/>'),
    "organize": _ic('<polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"/>'),
    "folder": _ic('<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>'),
    "history": _ic('<circle cx="12" cy="12" r="10"/>'
                   '<polyline points="12,6 12,12 16,14"/>'),
    "settings": _ic('<line x1="4" y1="21" x2="4" y2="14"/>'
                    '<line x1="4" y1="10" x2="4" y2="3"/>'
                    '<line x1="12" y1="21" x2="12" y2="12"/>'
                    '<line x1="12" y1="8" x2="12" y2="3"/>'
                    '<line x1="20" y1="21" x2="20" y2="16"/>'
                    '<line x1="20" y1="12" x2="20" y2="3"/>'
                    '<line x1="1" y1="14" x2="7" y2="14"/>'
                    '<line x1="9" y1="8" x2="15" y2="8"/>'
                    '<line x1="17" y1="16" x2="23" y2="16"/>'),
    "help": _ic('<circle cx="12" cy="12" r="10"/>'
                '<path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>'
                '<line x1="12" y1="17" x2="12.01" y2="17"/>'),
    "theme": _ic('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'),
    "search": _ic('<circle cx="11" cy="11" r="8"/>'
                  '<line x1="21" y1="21" x2="16.65" y2="16.65"/>'),
    "support": _ic('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 '
                   '2-2h14a2 2 0 0 1 2 2z"/>'),
}

# 문서 분류 메뉴는 고정하지 않는다 — 확장자만 보고 엑셀을 전부 BOM에 묶던 문제
# (2026-08-31). 실제 문서 유형(폴더 지정·규칙)에서 뽑아 NAV_DOC 자리에 끼운다
NAV = [("/", "dash", "대시보드"), ("/issues", "issues", "검토 필요"),
       ("/tags", "search", "태그 검색"), ("/briefs", "brief", "브리핑"),
       ("__DOCTYPES__", "doc", ""), ("/projects", "proj", "프로젝트"),
       ("/organize", "organize", "정리 제안"),
       ("/tree", "folder", "폴더 구조"),
       ("/history", "history", "전체 이력"), ("/settings", "settings", "설정"),
       ("/help", "help", "도움말"), ("/support", "support", "의견 보내기")]

# 문의 접수 주소 — 폼 서비스(Formspree 등) 개설 시 입력. 비어 있으면
# 사용자 PC의 기본 메일 앱으로 전송(내용을 채워서 연다). 산출물이 아니라
# 사용자가 직접 쓴 문의만 전송된다 (원칙 1과 충돌 없음)
SUPPORT_FORM_URL = ""
SUPPORT_MAIL = "hello.everydayeng@gmail.com"


def _parse_utc(iso: str) -> datetime:
    """저장된 ISO 문자열(UTC) → 시간대 정보가 있는 datetime. 오프셋이 없으면 UTC로 간주."""
    if not ("+" in iso[10:] or iso.endswith("Z")):
        iso = iso + "+00:00"
    return datetime.fromisoformat(iso)


@functools.lru_cache(maxsize=8192)
def _mtime_str(ts, fmt: str = "%Y-%m-%d %H:%M") -> str:
    """파일 저장(수정) 시각(epoch) → 이 PC 지역 시간 표시."""
    try:
        return datetime.fromtimestamp(float(ts)).strftime(fmt)
    except (TypeError, ValueError, OSError, OverflowError):
        return "—"


def _local(iso: str | None, fmt: str = "%Y-%m-%d %H:%M") -> str:
    """UTC ISO 문자열 → 이 PC의 지역 시간 표시. (같은 검사의 수만 건은 시각이
    같다 — 대시보드 한 번에 9만 번 변환하던 것을 캐시. 2026-09-02 회사 규모)

    UTC 그대로 보여주면 아침 9시 전 변경이 '어제'로 찍히고 '오늘 변경'이
    0건으로 보인다 (2026-08-25 UX 검토)."""
    if not iso:
        return ""
    try:
        return _parse_utc(iso).astimezone().strftime(fmt)
    except ValueError:
        return iso[:16]


def _local_date(iso: str | None) -> str:
    return _local(iso, "%Y-%m-%d")


_DOC_NAV: tuple[float, list] = (0.0, [])
_PATHS_FN = None                   # WebApp이 자기 조회 함수를 여기에 건다
_HINTS_FN = None                   # 내용 단서 조회 함수 (2026-09-02)


def _refresh_hints() -> None:
    """검사 때 저장된 내용 단서를 분류기에 싣는다 — 메뉴 캐시와 같은 수명."""
    from watcher import doctype as _dt
    if _HINTS_FN is None:
        return
    try:
        h = _HINTS_FN()
    except Exception:
        return
    _dt.HINTS.clear()
    _dt.HINTS.update(h)


_PATHS_GEN = 0            # watched_paths 캐시 세대 — 검사 후 바뀐다
_STARTUP_POLL_UNTIL = 0.0  # run_web이 정한다 — 이 시각까지 화면이 새 판 유무를 잠깐 되묻는다


def invalidate_doc_nav() -> None:
    """문서 유형 메뉴 캐시를 비운다 (검사 완료·분류 규칙 변경 직후)."""
    global _DOC_NAV
    _DOC_NAV = (0.0, [])
    global _PATHS_GEN                     # 감시 경로 캐시도 함께 (같은 수명)
    _PATHS_GEN += 1


def _doctype_nav(cfg: dict | None = None, paths_fn=None) -> list:
    """현재 감시 중인 문서 유형으로 메뉴 항목을 만든다 (60초 캐시).

    확장자 기준 고정 메뉴(도면/BOM/문서)로는 인터락 시트가 BOM에 묶인다 —
    실제 유형으로 나눈다 (2026-08-31 사용자 지적)."""
    import time as _t
    from collections import Counter
    from watcher.doctype import UNKNOWN, kind_of
    global _DOC_NAV
    if _t.time() - _DOC_NAV[0] < 60 and _DOC_NAV[1]:
        return _DOC_NAV[1]
    from watcher.doctype import canonical
    paths_fn = paths_fn or _PATHS_FN
    try:
        _refresh_hints()
        labels = [kind_of(p, cfg if cfg is not None else _LAST_CFG)
                  for p in (paths_fn() if paths_fn else [])]
    except Exception:
        labels = []
    # 같은 종류가 한글·영문으로 갈리지 않게 묶는다. 대표 이름은 **정규 이름**을 쓴다 —
    # '많이 쓰는 표기'를 쓰면 한국어 화면의 주 메뉴가 'Drawing'인데 같은 화면 표의
    # 유형 칸은 '도면'이라, 같은 개념이 한 화면에서 두 이름으로 불렸다
    # (2026-09-09 웹 검토 중간 4. 표 쪽 _cat_display는 이미 정규 이름을 쓴다)
    counts = Counter(canonical(lb) for lb in labels)
    icon = {"도면": "dwg", "BOM": "bom"}
    items = []
    # 검사마다 개수가 엎치락뒤치락해 메뉴 자리가 바뀌던 것 (2026-09-05 재검토) — 많이 쓰는
    # 7개를 고르되 자리는 유형 중요도·이름순으로 고정
    top = [name for name, _n in counts.most_common(7)]
    from watcher.doctype import doc_rank
    for name in sorted(top, key=lambda n: (doc_rank(n), n)):
        if name == UNKNOWN and len(counts) > 1:
            continue                       # '기타'는 있을 때만 맨 뒤에
        items.append((f"/cat?c={quote(name)}", icon.get(name, "doc"), name))
    if UNKNOWN in counts:
        items.append((f"/cat?c={quote(UNKNOWN)}", "doc", UNKNOWN))
    if not items:                          # 아직 검사 전
        items = [("/cat?c=도면", "dwg", "도면"), ("/cat?c=표", "bom", "표"),
                 ("/cat?c=문서", "doc", "문서")]
    _DOC_NAV = (_t.time(), items)
    return items


def _intro(text: str) -> str:
    """화면 제목 아래 한 줄 설명 — 익숙해지면 접을 수 있다 (2026-09-01).

    처음에는 펼쳐져 있고, 한 번 접으면 그 뒤로는 접힌 채로 기억한다."""
    return (f'<p class="intro muted" style="margin:-8px 0 14px">{text} '
            f'<button class="intro-x" onclick="pwHideTips()" '
            f'title="설명 숨기기 (설정에서 다시 켤 수 있습니다)">✕</button></p>')


_APP_REF = None      # 사이드바의 업데이트 자리가 상태를 물어볼 곳 (한 프로세스에 화면 앱 하나)

# 지금 이 프로그램이 사람에게 보이는 모습. run_web이 분기하는 그 자리에서 확정한다.
#   "window"  자체 창          "browser" 기본 브라우저 탭      "headless" 화면 없이(검사만)
# 화면 문구는 **이 값 하나**만 본다 — `engine_check()`는 "이 PC에 WebView2가 있나"라서
# 설정에서 직접 브라우저를 고른 사람을 못 가린다 (2026-09-08 사용성 8차 중간-3)
SHELL = "window"


def _shell() -> str:
    return SHELL


def browser_shell() -> bool:
    return SHELL == "browser"


def _engine_line() -> str:
    """창 엔진 진단 한 줄 — 설정 화면에 그대로 보여 준다.

    창이 안 뜨고 브라우저로 열리는 이유는 거의 언제나 여기에 적힌다(대개 WebView2 런타임 없음).
    예전에는 시작 로그에만 남아, 콘솔 없는 조립본에서는 볼 길이 없었다 (2026-09-07 사용자
    "바로 브라우저로 열리네 뭐가 문제일까?")."""
    try:
        from watcher import webengine as _we
        ok, why = _we.engine_check()
        if ok:
            return f"사용 가능 — {why}"
        # 설치판·포터블판 어느 쪽도 런타임을 동봉하지 않는다 — 없는 말을 하지 않는다
        return (f"사용 불가 — {why}. 이 상태에서는 창 대신 브라우저로 열립니다(기능은 같습니다). "
                f"창으로 쓰시려면 'Microsoft Edge WebView2 Runtime'을 설치하세요 — "
                f"회사 PC라면 전산 담당자에게 요청해야 할 수 있습니다.")
    except BaseException:
        return "확인하지 못했습니다"


def _engine_ok() -> bool:
    """자체 창으로 떠 있나 — 아니면 브라우저 탭이라, 업데이트 중 끊김을 미리 알려야 한다."""
    try:
        from watcher import webengine as _we
        return bool(_we.engine_check()[0])
    except BaseException:
        return True


def _side_shell() -> str:
    """브라우저 탭으로 열렸다는 **사라지지 않는** 표식.

    사유는 `last_msg`라 한 번 보면 사라졌다 — 새로고침 한 번이면 화면 어디에도 '브라우저'라는
    낱말이 없어, 다음 날 아침 연 사람은 이게 정상인지 고장인지 알 길이 없었다
    (2026-09-08 사용성 8차 중간-1)."""
    if not browser_shell():
        return ""
    why = _browser_reason()
    return (f'<a class="side-shell" href="/settings#screen" '
            f'title="{why} Drev를 브라우저 탭으로 엽니다. 고장이 아니며 기능은 모두 같습니다. '
            f'눌러서 자세히 보기.">🌐 브라우저 탭으로 열림</a>')


def _side_update() -> str:
    """왼쪽 메뉴 맨 위의 업데이트 자리.

    예전에는 설정에 들어가 [업데이트 확인]을 누르고, 다시 대시보드로 나와 배너의
    [지금 업데이트]를 눌러야 했다 — 두 화면을 오가야 끝났다 (2026-09-07 사용자 지적).
    여기서는 새 버전이 있으면 그 자리가 바로 설치 단추가 되고, 없으면 조용한 확인 단추다."""
    app = _APP_REF
    if app is None:
        return ""
    try:
        # 이 자리는 **설정 파일도 DB도 새로 읽지 않는다** — 사이드바는 모든 화면에 나오므로,
        # 여기서 나는 오류는 화면 전체를 죽인다. 설정이 사라지면 load_config가 SystemExit을
        # 던지는데 그것까지 잡아야 한다 (2026-09-07: 이 자리를 넣고 실제로 그렇게 됐다).
        from watcher import selfupdate as _su
        if _su.busy():
            pct = int(_su.PROGRESS.get("pct", 0) or 0)
            return (f'<a class="side-upd busy" href="/" title="진행 상황은 대시보드에서">'
                    f'⬆ 업데이트 중 {pct}%</a>')
        tok = app._tok()
        info = app.update_info
        if info:
            ver = _E(str(info.get("version", "")))
            # 메뉴 맨 위·[대시보드] 바로 위라 잘못 누르기 쉽다 — 설치만 한 번 묻는다
            # (2026-09-08 사용성 8차 낮음-2)
            ask = ("지금 새 판으로 교체할까요?\\n\\n화면이 잠깐 끊겼다 저절로 돌아옵니다. "
                   "이력·설정은 그대로입니다.")
            return (f'<form method="post" action="/update/apply" '
                    f'onsubmit="return confirm(&quot;{ask}&quot;)">{tok}'
                    f'<button class="side-upd new" title="새 판을 받아 이 폴더를 그대로 교체하고 '
                    f'다시 시작합니다 — 이력·설정은 그대로입니다">⬆ 새 버전 v{ver} 설치</button>'
                    f'</form>')
        return (f'<form method="post" action="/update/check">{tok}'
                f'<button class="side-upd" title="지금 새 버전이 있는지 확인합니다 — '
                f'보던 화면 그대로 돌아옵니다">업데이트 확인</button></form>')
    except BaseException:
        return ""


def _browser_reason() -> str:
    """왜 브라우저 탭으로 열렸나 — 실행 옵션·설정·엔진 없음을 가른다. 전에는 무조건
    "설정에서 고르셔서"라 단정해 PW_BROWSER로 연 사람에게 거짓이었다 (검토19 구매자 ⑧)."""
    if not _engine_ok():
        return "이 PC에는 창 엔진(WebView2)이 없어"
    if os.environ.get("PW_BROWSER") == "1":
        return "실행 옵션(PW_BROWSER=1)으로"
    try:
        if _APP_REF is not None and str(_APP_REF.cfg().get("ui") or "") == "browser":
            return "설정에서 '기본 브라우저'를 고르셔서"
    except BaseException:          # load_config는 SystemExit을 올린다
        pass
    return "창을 열 수 없어"


def _relaunch_hint() -> str:
    """다시 여는 방법 — 포터블에는 바탕화면 아이콘이 없다 (검토19 구매자 ⑧)."""
    try:
        from watcher import selfupdate as _su
        if _su.portable_root() is not None:
            return "압축을 푼 폴더의 Drev.exe를 한 번 더 누르세요"
    except Exception:
        pass
    return "바탕화면의 [Drev]를 한 번 더 누르세요"


def _footer_note() -> str:
    """화면 맨 아래 한 줄 — 브라우저 탭에서 "창을 닫으면 종료됩니다"는 거짓말이었다.
    브라우저 모드 첫 화면에서는 위쪽 안내("이 탭을 닫아도 계속 돕니다")와 정면으로 충돌해,
    처음 쓰는 사람이 어느 쪽을 믿을지 몰랐다 (2026-09-08 사용성 8차 치명-3)."""
    if browser_shell():
        return ("이 화면은 브라우저 탭에 열려 있습니다 — <b>탭을 닫아도 Drev는 계속 돌면서 "
                f"매일 검사합니다.</b> 다시 보려면 {_relaunch_hint()}"
                "(같은 주소로 탭이 다시 열립니다). 완전히 끄려면 "
                "<a href=\"/settings#quit\" style=\"color:var(--link)\">[설정 → 프로그램 종료]</a>"
                "를 누르세요.")
    return ("이 화면은 Drev 실행 중에만 동작합니다 — 창을 닫으면 프로그램이 종료됩니다 "
            "(검사 진행분은 저장되어 다음 검사가 이어받습니다). "
            "설정의 [프로그램 종료]로도 끌 수 있습니다.")


def _deny_page(title: str, body: str) -> str:
    """거부 화면 — 사이드바도 토큰도 없는 맨 페이지.

    `_page()`로 그리면 사이드바의 업데이트 폼에 CSRF 토큰이 실린다. 그 화면은 Host를 속인
    요청에도 나가므로, 바깥 출처가 토큰을 받아 가 방어가 통째로 뚫렸다 (2026-09-07 검토15 B2)."""
    return (f'<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">'
            f'<title>{_E(title)} — Drev</title>'
            f'<style>body{{font-family:system-ui,sans-serif;margin:40px;line-height:1.6;'
            f'color:#222;background:#fff}}a{{color:#2b5fd9}}</style></head><body>{body}'
            # 창 모드에는 주소창도 뒤로가기도 없다 — 돌아갈 길 한 줄은 있어야 한다 (검토17 R4)
            f'<p style="margin-top:24px"><a href="/">← Drev 대시보드로</a></p>'
            f'</body></html>')


def _page(title: str, active: str, body: str, msg: str = "",
          auto_refresh: bool = False, doc_nav: list | None = None,
          back: bool = True) -> str:
    def _a(href, icon, label):
        return (f'<a href="{href}" class="{"on" if href == active else ""}"'
                f'{" aria-current=\"page\"" if href == active else ""}>'
                f'{_NAV_ICON[icon]}<span>{_E(label)}</span></a>')     # 폴더 유형 이름은 사용자 입력 (검토21 웹 H)
    docs_items = doc_nav if doc_nav is not None else _doctype_nav()
    docs_open = any(href == active for href, _i, _l in docs_items)
    groups = [("오늘", [n for n in NAV if n[0] in ("/", "/issues", "/briefs")]),
              ("찾기", [n for n in NAV if n[0] in ("/tags", "/projects", "/history")]),
              ("__DOCS__", docs_items),
              ("관리", [n for n in NAV if n[0] in ("/tree", "/organize", "/settings")]),
              ("도움", [n for n in NAV if n[0] in ("/help", "/support")])]
    parts = []
    for name, its in groups:
        if name == "__DOCS__":
            if its:
                parts.append(f'<details class="grp-fold"{" open" if docs_open else ""}>'
                             f'<summary>{_NAV_ICON["doc"]}<span>문서 유형별 이력</span><span class="tri">▶</span></summary>'
                             + "".join(_a(h, i, l) for h, i, l in its) + '</details>')
            continue
        parts.append(f'<div class="grp">{name}</div>' + "".join(_a(h, i, l) for h, i, l in its))
    nav = "".join(parts)
    # role=status/aria-live — "확인 저장됨" 같은 결과 문구를 스크린리더가 읽게 (검토19 웹 U3, v0.53 남긴 것)
    notice = (f'<div class="panel" role="status" aria-live="polite" style="color:var(--link)">'
              f'{_E(msg)}</div>' if msg else "")
    # 창 안에는 브라우저 뒤로가기가 없다 — 화면마다 하나씩 둔다 (2026-09-02
    # 사용자: "다시 돌아가기가 헷갈리네"). 첫 화면에는 돌아갈 곳이 없어 뺀다.
    # active로 판별하면 안 된다 — 변경 상세는 사이드바에 '대시보드'를 켜두려고
    # active="/"를 쓰는데, 정작 그 화면에 뒤로가기가 가장 필요하다
    back = ("" if not back else
            '<button class="backbtn" onclick="pwBack()" '
            'title="이전 화면으로 (Alt+←, 마우스 뒤로 버튼)">← 뒤로</button>')
    # 검사 중일 때만 자동 새로고침 — 끝나면 결과 화면으로 저절로 넘어간다
    # 5초마다 화면을 통째로 다시 부르면 마우스가 로딩 커서로 깜빡이고 스크롤·
    # 입력이 날아간다 (2026-09-02 회사 실사용). 상태만 물어보고 끝났을 때 한 번만
    # 새로고침한다. 자바스크립트가 막힌 환경을 위해 <noscript>에 옛 방식을 남긴다.
    refresh = ("""<noscript><meta http-equiv="refresh" content="10"></noscript>
<script>
(function(){var n=0;
function tick(){fetch('/status',{cache:'no-store'}).then(function(r){return r.json();})
.then(function(s){if(!s.busy){location.reload();return;}
pwProg(s.progress);
/* 10분이 지나면 뜸하게(15초) 묻되 멈추지는 않는다 — 전에는 120회 뒤 그만 물어, 긴 검사가
   끝나도 화면이 "검사 중"에 얼어 있었다 (2026-09-14 실사용 "검사 돌리다 그냥 멈췄다" 후보) */
setTimeout(tick,(++n>120)?15000:5000);}).catch(function(){setTimeout(tick,5000);});}
setTimeout(tick,5000);})();
/* 진행 패널은 화면을 다시 부르지 않고 값만 갱신 (재검토 M4) */
function pwProg(p){if(!p)return;var e=document.getElementById('pw-prog');if(!e)return;
 var ph=e.querySelector('.ph'),cnt=e.querySelector('.cnt'),bar=e.querySelector('.bar i'),
     cur=e.querySelector('.cur'),wr=e.querySelector('.curwarn');
 if(ph)ph.textContent=p.phase||'';
 if(p.total){var pct=Math.min(100,Math.floor(p.done*100/Math.max(p.total,1)));
  if(cnt)cnt.textContent=p.done.toLocaleString()+' / '+p.total.toLocaleString()+'개 ('+pct+'%)';
  if(bar)bar.style.width=pct+'%';}
 else if(cnt){cnt.textContent=p.done?(p.done.toLocaleString()+'개 확인'):'살펴보는 중';}
 if(cur){cur.textContent=p.current?('지금: '+p.current+' ('+p.elapsed+'초째)'):'';
  cur.style.color=(p.current&&p.elapsed>=120)?'var(--bad)':'';}
 if(wr){wr.hidden=!(p.current&&p.elapsed>=120);}}
</script>""" if auto_refresh else "")
    # 시작 직후 첫 화면은 버전 확인보다 먼저 그려질 수 있다 — 왼쪽 메뉴 자리가 조용한
    # [업데이트 확인]이면 잠깐 /status를 물어, 새 판이 확인되면 그 자리만 [설치]로 갈아 끼운다.
    # 화면 전체를 다시 부르지 않고, 시작 뒤 3분 동안만 — 평소 화면은 아무것도 묻지 않는다
    # (2026-09-11 "자동 업데이트가 안되는중"; 2026-09-02 '한가한 화면은 폴링 없음' 유지)
    import time as _t
    updjs = ""
    if _t.time() < _STARTUP_POLL_UNTIL and _APP_REF is not None and not _APP_REF.update_info:
        updjs = """<script>
(function(){var s=document.getElementById('side-upd-slot');if(!s||s.querySelector('.new,.busy'))return;
var waits=[3000,5000,7000,15000,30000,60000],i=0;
function ask(){fetch('/status',{cache:'no-store'}).then(function(r){return r.json();})
.then(function(st){if(st.update){return fetch('/update/slot',{cache:'no-store'}).then(function(r){return r.text();})
 .then(function(h){s.innerHTML=h;
  });}
 if(i<waits.length){setTimeout(ask,waits[i++]);}}).catch(function(){if(i<waits.length){setTimeout(ask,waits[i++]);}});}
setTimeout(ask,waits[i++]);})();
</script>"""
    return f"""<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">{refresh}{updjs}
<title>{_E(title)} — Drev</title>
<script>(function(){{var t=localStorage.getItem('pw-theme');
document.documentElement.dataset.theme=t||'dark';}})();
function pwTheme(){{var h=document.documentElement;
var n=h.dataset.theme==='dark'?'light':'dark';
h.dataset.theme=n;localStorage.setItem('pw-theme',n);}}
/* 클립보드는 브라우저·정책에 따라 막힌다 — 막혔으면 글을 골라 주고 그렇다고 말한다.
   전에는 .catch가 없어 눌러도 아무 일이 안 일어났다 (2026-09-09 웹 검토 낮음 11) */
function pwCopy(btn,id){{var el=document.getElementById(id);if(!el)return;
 var txt=el.innerText;var done=function(){{btn.innerText='복사됨';}};
 var fail=function(){{btn.innerText='복사 안 됨 — 글을 선택해 Ctrl+C';
  try{{var r=document.createRange();r.selectNodeContents(el);
   var s=window.getSelection();s.removeAllRanges();s.addRange(r);}}catch(e){{}}
 }};
 try{{if(navigator.clipboard&&navigator.clipboard.writeText){{
  navigator.clipboard.writeText(txt).then(done).catch(fail);}}else{{fail();}}
 }}catch(e){{fail();}}}}
/* 매일 보는 '오늘 확인할 것'에는 걸러내기가 없어 48행을 눈으로 훑어야 했다 (2026-09-09).
   data-name이 없는 표라 행의 글자 전체로 거른다. 머리글 행은 남긴다. */
function pwFilterText(inp,tid){{var q=inp.value.trim().toLowerCase();
var tb=document.getElementById(tid);if(!tb)return;var n=0;
tb.querySelectorAll('tr').forEach(function(tr,i){{
 if(i===0||!tr.querySelector('td'))return;
 var hit=!q||tr.textContent.toLowerCase().indexOf(q)>=0;
 tr.style.display=hit?'':'none';if(hit){{n++;
  /* 맞은 행이 접힌 칸 안에 있으면 펼친다 — "2건 보임"인데 화면엔 아무것도 없던 것 */
  var d=tr.closest('details');if(d&&q)d.open=true;}}}});
var c=document.getElementById(tid+'-cnt');
if(c)c.textContent=q?(n+'건 보임'):'';
pwClearSel();}}
/* 걸러내면 고른 행이 바뀐다 — pwSel은 '몇 번째'라서, 비우지 않으면 강조된 행과 A가 확인하는
   행이 어긋난다. 다른 파일에 "확인함"이 남고 확인 기록은 지울 수 없다 (2026-09-09 검토18 차단 F7) */
function pwClearSel(){{document.querySelectorAll('tr.pw-sel').forEach(function(r){{
 r.classList.remove('pw-sel');}});pwSel=-1;}}
function pwFilterRows(inp,tid){{var q=inp.value.toLowerCase();
document.querySelectorAll('#'+tid+' tr[data-name]').forEach(function(tr){{
tr.style.display=tr.dataset.name.indexOf(q)>=0?'':'none';}});pwClearSel();}}
/* 행 간격 — 표가 빽빽해 읽기 힘들거나, 더 많이 보고 싶을 때 (2026-09-01) */
(function(){{var f=localStorage.getItem('pw-fs');
if(f&&f!=='normal')document.documentElement.dataset.fs=f;}})();
function pwFs(v){{if(v==='normal')delete document.documentElement.dataset.fs;
else document.documentElement.dataset.fs=v;
localStorage.setItem('pw-fs',v);pwMarkPicks();}}
/* 지금 고른 것에 표시 — 없으면 무엇이 켜져 있는지 알 수 없었다 (2026-09-08 사용성 9차) */
function pwMarkPicks(){{
 var fs=localStorage.getItem('pw-fs')||'normal',dn=localStorage.getItem('pw-dense')||'normal';
 var f=document.getElementById('fs-pick'),d=document.getElementById('dense-pick');
 if(f)f.querySelectorAll('button').forEach(function(b){{b.classList.toggle('on',b.dataset.v===fs);}});
 if(d)d.querySelectorAll('button').forEach(function(b){{b.classList.toggle('on',b.dataset.v===dn);}});}}
document.addEventListener('DOMContentLoaded',pwMarkPicks);
(function(){{var d=localStorage.getItem('pw-dense');
document.documentElement.dataset.dense=d||'normal';}})();
function pwDense(v){{document.documentElement.dataset.dense=v;
localStorage.setItem('pw-dense',v);pwMarkPicks();}}
/* 열 너비 — 머리글 경계를 끌어 조절하고 화면별로 기억한다.
   글자가 잘려 보이던 칸을 사용자가 직접 넓힐 수 있게 (2026-09-01 요청) */
function pwCols(){{
 var key=function(ti,ci){{return 'pw-col:'+location.pathname+':'+ti+':'+ci;}};
 document.querySelectorAll('table').forEach(function(tb,ti){{
  var hs=tb.querySelectorAll('tr:first-child > th');
  if(!hs.length) return;
  hs.forEach(function(th,ci){{
   var w=localStorage.getItem(key(ti,ci));
   if(w) th.style.width=w;
   if(ci===hs.length-1) return;
   var g=document.createElement('span');
   g.className='colgrip';
   g.title='끌어서 열 너비 조절 (더블클릭하면 원래대로)';
   /* 스크롤 상자의 머리글은 sticky — relative로 덮으면 고정이 풀린다 (검토22 재검증 U2 ⑤).
      sticky도 위치 지정 요소라 손잡이(absolute)의 기준이 된다 */
   if(getComputedStyle(th).position!=='sticky') th.style.position='relative';
   th.appendChild(g);
   g.addEventListener('mousedown',function(e){{
    e.preventDefault();e.stopPropagation();
    /* 화면을 확대(zoom)하면 pageX는 확대된 좌표, offsetWidth는 배치 좌표라 손과 어긋난다 */
    var z=parseFloat(getComputedStyle(document.documentElement).zoom)||1;
    var x0=e.pageX,w0=th.offsetWidth;
    document.body.style.userSelect='none';
    function mv(ev){{var w=Math.max(48,w0+(ev.pageX-x0)/z);
     th.style.width=w+'px';}}
    function up(){{document.removeEventListener('mousemove',mv);
     document.removeEventListener('mouseup',up);
     document.body.style.userSelect='';
     localStorage.setItem(key(ti,ci),th.style.width);}}
    document.addEventListener('mousemove',mv);
    document.addEventListener('mouseup',up);}});
   g.addEventListener('dblclick',function(e){{e.preventDefault();
    th.style.width='';localStorage.removeItem(key(ti,ci));}});
  }});
 }});
}}
function pwColsReset(){{
 Object.keys(localStorage).filter(function(k){{
  return k.indexOf('pw-col:')===0;}}).forEach(function(k){{
  localStorage.removeItem(k);}});
 location.reload();
}}
document.addEventListener('DOMContentLoaded',pwCols);
/* 뒤로가기 — 기록이 없으면(링크로 바로 열린 화면) 대시보드로 (2026-09-02) */
function pwBack(){{if(history.length>1){{history.back();}}else{{location.href='/';}}}}
document.addEventListener('keydown',function(e){{
if(e.altKey&&e.key==='ArrowLeft'){{e.preventDefault();pwBack();}}}});
/* 목록에서 바로 확인 — 이름은 한 번만 적으면 기억한다 (2026-09-02) */
function pwAckName(){{var i=document.getElementById('ackname');return i?i.value.trim():'';}}
document.addEventListener('DOMContentLoaded',function(){{
var i=document.getElementById('ackname');if(!i)return;
i.value=localStorage.getItem('pw-ack-name')||i.value;
i.addEventListener('change',function(){{localStorage.setItem('pw-ack-name',i.value.trim());}});
document.querySelectorAll('form.ackq').forEach(function(f){{
f.addEventListener('submit',function(e){{var n=pwAckName();
if(!n){{e.preventDefault();i.focus();
i.placeholder='이름을 먼저 적어주세요';return false;}}
localStorage.setItem('pw-ack-name',n);
f.by.value=n;f.back.value=location.pathname+location.search;}});}});}});
/* 화면 설명문 접기 — 익숙해진 사람에게는 소음이다 (2026-09-01) */
(function(){{var h=localStorage.getItem('pw-tips');
if(h==='off')document.documentElement.dataset.tips='off';}})();
function pwHideTips(){{document.documentElement.dataset.tips='off';
localStorage.setItem('pw-tips','off');}}
function pwShowTips(){{document.documentElement.removeAttribute('data-tips');
localStorage.removeItem('pw-tips');}}</script>
{_UI_EXTRAS_HEAD}
<style>{CSS}</style></head><body>
<a class="skip" href="#main">본문으로 건너뛰기</a>
<div class="side"><div class="logo"><b>Drev</b><small>산출물 변경 감시 v{__version__}</small></div>
{_side_shell()}<div id="side-upd-slot">{_side_update()}</div>
<form class="side-search" method="get" action="/tags">
<input type="text" name="q" placeholder="태그·파일명 검색" aria-label="검색"></form>
<div class="nav">{nav}</div>
<details class="viewtools"><summary>⚙ 보기 설정</summary>
<button class="theme-btn" onclick="pwTheme()">{_NAV_ICON["theme"]}<span>다크/라이트 전환</span></button>
<div class="pick-label">글자 크기 <span class="muted">— 화면 전체가 커집니다</span></div>
<div class="dense-pick" id="fs-pick">
<button onclick="pwFs('normal')" data-v="normal">가</button>
<button onclick="pwFs('big')" data-v="big" style="font-size:15px">가</button>
<button onclick="pwFs('huge')" data-v="huge" style="font-size:18px">가</button></div>
<div class="pick-label">표 행 간격 <span class="muted">— 글자 크기와는 다릅니다</span></div>
<div class="dense-pick" id="dense-pick">
<button onclick="pwDense('tight')" data-v="tight">촘촘</button>
<button onclick="pwDense('normal')" data-v="normal">보통</button>
<button onclick="pwDense('wide')" data-v="wide">넓게</button></div>
<button class="theme-btn" onclick="pwColsReset()" style="margin-top:0"
  title="끌어서 바꾼 열 너비를 모두 원래대로">열 너비 초기화</button>
<button class="theme-btn" onclick="pwShowTips()" style="margin-top:0"
  title="각 화면의 설명문을 다시 보이게">화면 설명 다시 보기</button></details></div>
<div class="main" id="main" tabindex="-1">{back}{notice}{body}
<p class="muted" style="margin-top:22px">{_footer_note()}</p></div>{_UI_PAL_DIV}{_TREE_DRAWER}</body></html>"""


# 폴더 구조 서랍 — 화면 오른쪽 가장자리의 탭에 마우스를 올리면 감시 폴더의 가지가
# 펼쳐진다. 어느 화면에서든 수시로 보라고 메뉴가 아니라 가장자리에 둔다 (2026-09-04 요청
# "오른쪽에 화살표 만들어서 마우스를 갖다대면… 메뉴에 넣지 말고"). 탭을 클릭하면 고정.
# 내용은 처음 열 때 한 번만 /tree?frag=1 로 받아온다
_TREE_DRAWER = """
<style>
.pw-tree{position:fixed;right:0;top:6vh;z-index:40;display:flex;align-items:flex-start;
 pointer-events:none}
.pw-tree-tab{pointer-events:auto;cursor:pointer;width:34px;height:110px;border:1px solid var(--border);
 border-right:none;border-radius:10px 0 0 10px;background:var(--panel,var(--bg));color:var(--muted);
 display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;
 box-shadow:-2px 2px 8px rgba(0,0,0,.18);font-size:11px;writing-mode:vertical-rl;text-orientation:upright}
.pw-tree-tab svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;
 stroke-linecap:round;stroke-linejoin:round}
.pw-tree-tab .arr{writing-mode:horizontal-tb;font-size:12px}
.pw-tree-panel{pointer-events:auto;width:0;max-height:88vh;min-height:60vh;overflow:hidden;border:1px solid var(--border);
 border-right:none;border-radius:10px 0 0 10px;background:var(--panel,var(--bg));
 box-shadow:-4px 4px 16px rgba(0,0,0,.22);transition:width .18s ease;opacity:0}
.pw-tree:hover .pw-tree-panel,.pw-tree.pin .pw-tree-panel{width:min(520px,80vw);opacity:1;overflow:auto}
.pw-tree:not(:hover):not(.pin) .pw-tree-panel{border:none;pointer-events:none;min-height:0}
.pw-tree:hover .pw-tree-tab,.pw-tree.pin .pw-tree-tab{color:var(--link)}
.pw-tree-head{position:sticky;top:0;z-index:1;background:var(--panel,var(--bg));padding:8px 12px;
 border-bottom:1px solid var(--border);font-weight:600;display:flex;justify-content:space-between;
 align-items:center;font-size:13px}
.pw-tree-head a{color:var(--link);font-weight:400;font-size:12px}
.pw-tree-body{padding:6px 8px;font-size:13px;min-width:320px}
@media print{.pw-tree{display:none}
 html[data-fs]{zoom:1}}          /* 화면에서 키운 글자를 종이까지 끌고 가지 않는다 (검토17 R8) */
/* 탐색기 모양 트리 — 한 줄 24px, 삼각형·폴더 아이콘·안내선, 마우스 올리면 밝게 */
.tree{font-size:13px;line-height:1}
.tree details{margin:0}
.tree summary{list-style:none;display:flex;align-items:center;gap:5px;height:24px;padding:0 6px;
 border-radius:4px;white-space:nowrap;cursor:pointer;user-select:none}
.tree summary::-webkit-details-marker{display:none}
.tree summary:hover,.tree .file:hover{background:rgba(127,127,127,.14)}
.tree summary.sel{background:rgba(93,120,255,.22)}
.tree .tri{width:12px;flex:none;display:inline-block;font-size:11px;color:var(--muted);
 transition:transform .12s;text-align:center}
.tree details[open] > summary .tri{transform:rotate(90deg)}
.tree .ic,.tree-list .ic,.tree-crumbs .ic{width:16px;height:16px;flex:none}
.tree .nm{overflow:hidden;text-overflow:ellipsis}
.tree .meta,.tree-list .meta{margin-left:auto;font-size:11px;color:var(--muted);padding-left:10px;
 display:flex;gap:6px;align-items:center;flex:none}
.tree .bd{font-size:10px;border:1px solid var(--border);border-radius:3px;padding:0 4px;color:var(--muted)}
.tree .bd.na{color:var(--warn2);border-color:var(--warn2)}
/* 감시 램프 — 켜짐(초록)=감시 중, 꺼짐(빨강)=이 폴더를 뺐음, 테두리만=상위 폴더 때문에 빠짐 */
.tree .lamp,.tree-list .lamp,.tree-crumbs .lamp{width:8px;height:8px;border-radius:50%;flex:none;
 background:var(--ok);box-sizing:border-box}
.tree .lamp.off,.tree-list .lamp.off,.tree-crumbs .lamp.off{background:var(--bad)}
.tree .lamp.sub,.tree-list .lamp.sub,.tree-crumbs .lamp.sub{background:transparent;border:2px solid var(--bad)}
.tree summary.excl .nm,.tree-list .file.excl .nm{opacity:.55;text-decoration:line-through}
/* 폴더 이름 오른쪽의 작은 [빼기]/[다시 감시] — 감시 중인 폴더는 올리거나 고르면 보이고,
   뺀 폴더의 [다시 감시]는 늘 보인다(되돌리는 길이 눈에 띄게). 2026-09-14 사용자 요청 */
.tree .xb{font:inherit;font-size:10.5px;line-height:15px;padding:0 6px;margin-left:2px;border:1px solid var(--border2);
  border-radius:4px;background:transparent;color:var(--muted);cursor:pointer;opacity:0;flex:none;transition:opacity .12s}
.tree summary:hover .xb,.tree summary.sel .xb,.tree .xb:focus-visible,.tree .xb.on{opacity:1}
.tree .xb.on{color:var(--on-accent);background:var(--accent);border-color:var(--accent)}
.tree .xb:hover{border-color:var(--accent);color:var(--text)}
.tree .xb.on:hover{color:var(--on-accent)}
.tree .xb:disabled{opacity:.6;cursor:default}
.tree-legend{font-size:12px;color:var(--muted);display:flex;gap:14px;align-items:center;margin:6px 0 8px;flex-wrap:wrap}
.tree-legend span{display:flex;gap:5px;align-items:center}
.tree-legend .lamp{width:8px;height:8px;border-radius:50%;background:var(--ok);box-sizing:border-box}
.tree-legend .lamp.off{background:var(--bad)}
.tree-legend .lamp.sub{background:transparent;border:2px solid var(--bad)}
.tree details > *:not(summary){margin-left:12px;padding-left:6px;border-left:1px dotted var(--border)}
.tree .files:empty{display:none}
.tree .file,.tree-list .file{display:flex;align-items:center;gap:5px;height:22px;padding:0 6px 0 22px;
 border-radius:4px;white-space:nowrap}
.tree-list .file{padding-left:6px}
.tree .file .act,.tree-list .file .act,.tree-crumbs .act{font-size:11px;padding:1px 7px;margin-left:6px;border-radius:6px;
 border:1px solid var(--border2);background:var(--panel2);color:var(--muted);cursor:pointer;flex:none;visibility:hidden}
.tree .file:hover .act,.tree-list .file:hover .act,.tree-crumbs .act{visibility:visible}
.tree-list .file[data-open]{cursor:default}
.tree .file .nm{color:var(--muted)}
.tree-panes{display:flex;gap:14px;align-items:flex-start}
.tree-left{flex:0 0 min(46%,520px);max-height:75vh;overflow:auto}
.tree-right{flex:1;min-width:0;max-height:75vh;overflow:auto}
.tree-tools{margin:0 0 8px}.tree-tools button{font-size:12px;padding:3px 10px}
.tree-crumbs{display:flex;align-items:center;gap:6px;font-size:14px}
.tree-list{display:flex;flex-direction:column}
.tree-list .nm{flex:1;overflow:hidden;text-overflow:ellipsis}
</style>
<div id="pw-tree" class="pw-tree" onmouseenter="pwTreeLoad()">
 <div class="pw-tree-tab" onclick="pwTreePin()" tabindex="0" role="button"
  onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();pwTreeLoad();pwTreePin();}"
  title="폴더 구조 — 마우스를 올리면 펼쳐지고, 클릭하면 고정됩니다">
  <span class="arr">◀</span>
  <svg viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
  <span>폴더</span></div>
 <div class="pw-tree-panel"><div class="pw-tree-head"><span>폴더 구조</span>
  <span><a href="#" onclick="pwTreeAll('pw-tree-body',true);return false">전체 펼치기</a> ·
  <a href="#" onclick="pwTreeAll('pw-tree-body',false);return false">전체 접기</a> ·
  <a href="/tree">전체 화면</a> · <a href="#" onclick="pwTreeReload();return false">새로고침</a></span></div>
  <div style="padding:6px 12px 2px"><input type="text" id="pw-tree-q" placeholder="폴더 이름으로 찾기…"
   aria-label="폴더 이름으로 찾기"
   oninput="pwTreeFilter(this.value)" style="width:100%;padding:6px 9px;border:1px solid var(--border2);
   border-radius:8px;background:var(--panel2,var(--bg));color:var(--text);font-size:13px"></div>
  <div class="pw-tree-body" id="pw-tree-body">마우스를 올리면 불러옵니다…</div></div>
</div>
<script>
(function(){var p=localStorage.getItem('pw-tree-pin');
if(p==='1'){document.getElementById('pw-tree').classList.add('pin');pwTreeLoad();}})();
var pwTreeLoaded=false,pwTreeBulk=false;
function pwTreeLoad(force){
 if(pwTreeLoaded&&!force)return;pwTreeLoaded=true;
 var b=document.getElementById('pw-tree-body');b.textContent='불러오는 중…';
 fetch('/tree?frag=1',{cache:'no-store'}).then(function(r){return r.text();})
 .then(function(h){b.innerHTML=h;})
 .catch(function(){b.textContent='불러오지 못했습니다 — 새로고침을 눌러주세요.';pwTreeLoaded=false;});}
function pwTreeReload(){pwTreeLoad(true);}
/* 서랍의 [빼기]·[다시 감시하기]는 그 자리에서 처리한다 — 화면이 통째로 넘어가면
   보던 자리와 펼친 폴더를 잃는다 (2026-09-10 "최대한 편하고 쉽게"). 누른 뒤에는
   펼쳐 둔 폴더와 스크롤을 그대로 되살린다. */
function pwTreeAct(form,ev){
 if(ev){ev.preventDefault();}
 var body=document.getElementById('pw-tree-body');
 /* 서랍 밖(전체 화면의 왼쪽 트리)에서 눌렸으면 보통 제출로 넘긴다 — 그 자리 처리는
    서랍 본문만 다시 그리므로 다른 곳에서는 "적용 중…"에 멈춘다 (검토18 웹 ①) */
 if(!body||!form.closest||!form.closest('#pw-tree-body')){
  var aj=form.querySelector('input[name=ajax]');if(aj){aj.remove();}return true;}
 var opened=[],loaded={},sc=body.scrollTop;
 body.querySelectorAll('details[open]').forEach(function(d){opened.push(d.dataset.key);
  if(d.dataset.loaded){loaded[d.dataset.key]=1;}});
 var btn=form.querySelector('button');var was=btn?btn.textContent:'';
 if(btn){btn.disabled=true;btn.textContent='적용 중…';}
 var msg='';
 fetch(form.action,{method:'POST',body:new URLSearchParams(new FormData(form)),
                    headers:{'Content-Type':'application/x-www-form-urlencoded'}})
 .then(function(r){if(!r.ok){throw new Error(r.status);}return r.text();})
 .then(function(t){msg=t||'';
  return fetch('/tree?frag=1',{cache:'no-store'}).then(function(x){return x.text();});})
 .then(function(h){
  body.innerHTML=h;
  opened.forEach(function(k){
   var d=body.querySelector('details[data-key="'+(window.CSS&&CSS.escape?CSS.escape(k):k)+'"]');
   if(!d){return;}
   d.open=true;
   /* 파일 목록까지 펼쳐 보던 폴더는 다시 받아 온다 — 안 그러면 열려 있는데 텅 비고
      [다시 감시하기]도 없다 (검토18 웹 ②). 800ms 가드를 지나가려고 클릭 시각을 세운다 */
   if(loaded[k]){pwTreeClickAt=Date.now();pwTreeFiles(d);}});
  body.scrollTop=sc;
  var q=document.getElementById('pw-tree-q');
  if(q&&q.value){pwTreeFilter(q.value);}
  if(msg){var tmp=document.createElement('div');tmp.innerHTML=msg;pwOpenNote(tmp.textContent);}})
 .catch(function(){ if(btn){btn.disabled=false;btn.textContent=was;}
  alert('적용하지 못했습니다 — 화면을 새로고침한 뒤 다시 눌러주세요.');});
 return false;}
/* 폴더 이름으로 좁히기 — 폴더가 수백 개인 서버에서 눈으로 훑지 않게 */
function pwTreeFilter(q){
 var body=document.getElementById('pw-tree-body');if(!body)return;
 q=(q||'').trim().toLowerCase();
 body.querySelectorAll('details').forEach(function(d){
  var nm=d.querySelector(':scope > summary .nm');
  var hit=!q||(nm&&nm.textContent.toLowerCase().indexOf(q)>=0);
  d.dataset.hit=hit?'1':'';});
 /* 걸린 폴더의 조상과 자손은 보이게, 나머지는 감춘다 — "임시"를 찾은 사람은 그 안
    폴더를 보려는 것이다 (검토18 웹 ⑪) */
 body.querySelectorAll('details').forEach(function(d){
  var show=!q||d.dataset.hit==='1'||d.querySelector('details[data-hit="1"]')
   ||(d.parentElement&&d.parentElement.closest&&d.parentElement.closest('details[data-hit="1"]'));
  d.style.display=show?'':'none';
  if(q&&show&&d.querySelector('details[data-hit="1"]')){d.open=true;}});}
function pwTreePin(){var d=document.getElementById('pw-tree');d.classList.toggle('pin');
 localStorage.setItem('pw-tree-pin',d.classList.contains('pin')?'1':'0');}
/* 전체 펼치기/접기 — 펼칠 때 폴더마다 파일 목록을 받아오지 않는다(큰 서버에서 무겁다);
   파일은 폴더를 직접 클릭해 펼칠 때 나온다 */
function pwTreeAll(id,open){var c=document.getElementById(id);if(!c)return;pwTreeBulk=true;
 c.querySelectorAll('details').forEach(function(d){d.open=open;});
 setTimeout(function(){pwTreeBulk=false;},0);}
/* 폴더를 펼치면 그 폴더 바로 아래 파일을 한 번만 받아 트리 안에 끼운다 */
var pwTreeClickAt=0;
document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('.tree summary'))pwTreeClickAt=Date.now();},true);
function pwTreeFiles(d){if(!d.open||pwTreeBulk||d.dataset.loaded)return;
 if(Date.now()-pwTreeClickAt>800)return;      /* 사람이 방금 클릭한 폴더만 (재검토 H2) */
 d.dataset.loaded='1';
 var b=d.querySelector(':scope > .files');if(!b)return;
 /* 서랍 안에서만 그 자리 처리 단추를 받는다 — 전체 화면의 왼쪽 트리는 같은 조각을
    쓰지만 거기서는 단추가 서랍 본문만 다시 그려 멈춘다 (검토18 웹 ①) */
 var inDrawer=d.closest&&d.closest('#pw-tree-body')?'&drawer=1':'';
 fetch('/tree?files='+encodeURIComponent(d.dataset.key)+inDrawer,{cache:'no-store'})
 .then(function(r){return r.text();}).then(function(h){
  var t=document.createElement('div');t.innerHTML=h;
  var src=t.querySelector('.tree-list');
  /* 껍데기(.tree-list)는 버리고 파일 줄만 담으므로, 거기 실린 토큰을 옮겨 싣는다 —
     안 옮기면 서랍에서 연 파일만 403이 나고 '새로고침하라'는 문구가 떴다 (2026-09-07) */
  if(src&&src.dataset.tok){b.dataset.tok=src.dataset.tok;}
  var sw=t.querySelector('.watch-in-drawer');
  if(sw){/* 누른 뒤 지금 보던 화면으로 돌아온다 (서랍은 어느 화면에서든 열린다) */
   sw.querySelectorAll('input[name=back]').forEach(function(i){
    i.value=location.pathname+location.search;});
   b.appendChild(sw);}
  var only=t.querySelectorAll('.tree-list .file:not([data-key])');   /* 파일만 — 하위 폴더는 이미 가지에 있다 */
  only.forEach(function(f){b.appendChild(f);});})
 .catch(function(){d.dataset.loaded='';});}
/* 폴더 클릭 = 선택(오른쪽 패널에 내용) — 삼각형 클릭은 펼치기만 */
function pwTreeSel(s,ev){
 var tri=ev&&ev.target&&ev.target.classList&&ev.target.classList.contains('tri');
 var right=document.getElementById('tree-right');
 if(!right){return;}                       /* 서랍: 기본 동작(펼치기/접기)만 */
 if(!tri){ev.preventDefault();}
 document.querySelectorAll('.tree summary.sel').forEach(function(x){x.classList.remove('sel');});
 s.classList.add('sel');
 right.innerHTML='<p class="muted">불러오는 중…</p>';
 fetch('/tree?files='+encodeURIComponent(s.dataset.key)+'&full=1',{cache:'no-store'})
 .then(function(r){return r.text();}).then(function(h){right.innerHTML=h;})
 .catch(function(){right.innerHTML='<p class="muted">불러오지 못했습니다.</p>';});}
/* 폴더 이름 옆 [빼기]/[다시 감시] — 그 자리에서 보내고, 트리만 다시 받아 펼침 상태·스크롤을 지킨다.
   서랍(#pw-tree-body)과 전체 화면(#tree-root) 둘 다에서 쓴다 */
function pwTreeX(ev,b){
 if(ev){ev.preventDefault();ev.stopPropagation();}
 /* /tree 화면에서 서랍을 열면 id="tree-root"가 둘(본문·서랍)이다 — 누른 쪽으로 보내고, 답이 오면
    화면의 모든 트리를 함께 갱신한다(각각의 펼침·선택·스크롤은 지킨다) (재검토 5-④) */
 var mine=b.closest('#tree-root');
 var tok=(mine&&mine.dataset&&mine.dataset.tok)||'';
 var was=b.textContent;b.disabled=true;b.textContent='적용 중…';
 var body='t='+encodeURIComponent(tok)+'&path='+encodeURIComponent(b.dataset.path)+'&ajax=1';
 fetch(b.dataset.act==='add'?'/exclude/add':'/exclude/del',{method:'POST',body:body,
   headers:{'Content-Type':'application/x-www-form-urlencoded'}})
 .then(function(r){if(!r.ok){throw new Error(r.status);}return r.text();})
 .then(function(msg){return fetch('/tree?frag=1',{cache:'no-store'}).then(function(x){return x.text();})
  .then(function(h){
   var tmp=document.createElement('div');tmp.innerHTML=h;var fresh=tmp.firstElementChild;
   var trees=[];document.querySelectorAll('#tree-root').forEach(function(t){trees.push(t);});
   var selKey=null;
   trees.forEach(function(old){
    var box=old.closest('#pw-tree-body')||old.closest('.tree-left')||old.parentElement;
    var opened=[],loaded={},sc=box.scrollTop,sk=null;
    old.querySelectorAll('details[open]').forEach(function(d){opened.push(d.dataset.key);
     if(d.dataset.loaded){loaded[d.dataset.key]=1;}});
    var ss=old.querySelector('summary.sel');if(ss){sk=ss.dataset.key;if(!old.closest('#pw-tree-body')){selKey=sk;}}
    var nu=fresh.cloneNode(true);old.replaceWith(nu);
    /* 펼침만 되살린다 — 단추 클릭 직후라 800ms 가드가 열려 있어, 그대로 열면 펼친 폴더마다 파일 조각
       (서랍에서는 [빼기] 폼까지)을 다시 받아 줄줄이 뜬다. 파일까지 보던 폴더만 다시 받는다 */
    pwTreeClickAt=0;
    opened.forEach(function(k){nu.querySelectorAll('details').forEach(function(d){
     if(d.dataset.key===k){d.open=true;if(loaded[k]){pwTreeClickAt=Date.now();pwTreeFiles(d);pwTreeClickAt=0;}}});});
    if(sk){nu.querySelectorAll('summary').forEach(function(x){if(x.dataset.key===sk){x.classList.add('sel');}});}
    box.scrollTop=sc;});
   var q=document.getElementById('pw-tree-q');if(q&&q.value){pwTreeFilter(q.value);}
   /* 전체 화면: 오른쪽 패널에 같은 폴더의 옛 [빼기] 폼이 남지 않게 다시 받는다 */
   var right=document.getElementById('tree-right');
   if(right&&selKey){fetch('/tree?files='+encodeURIComponent(selKey)+'&full=1',{cache:'no-store'})
    .then(function(r){return r.text();}).then(function(t){right.innerHTML=t;}).catch(function(){});}
   var m=document.createElement('div');m.innerHTML=msg||'';pwOpenNote(m.textContent||'적용했습니다');});})
 .catch(function(){b.disabled=false;b.textContent=was;
  pwOpenNote('적용하지 못했습니다 — 화면을 새로고침한 뒤 다시 눌러주세요.');});}
/* 파일·폴더 열기 — 감시 PC의 기본 프로그램/탐색기로. 화면을 새로 그리지 않고 결과만 한 줄 */
function pwOpen(ev,key,w){if(ev){ev.stopPropagation();ev.preventDefault();}
 var el=ev&&ev.target?ev.target.closest('.tree-list, .tree-crumbs, .files'):null;
 var list=el&&el.classList.contains('tree-list')?el:(el?el.parentElement.querySelector('.tree-list'):null);
 var tok=(list&&list.dataset.tok)||(el&&el.dataset.tok)||'';
 var body='t='+encodeURIComponent(tok)+'&k='+encodeURIComponent(key)+'&w='+encodeURIComponent(w)+'&ajax=1';
 fetch('/open',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
 .then(function(r){if(!r.ok){throw new Error(r.status);}return r.text();}).then(function(t){pwOpenNote(t);})
 .catch(function(){pwOpenNote('열지 못했습니다 — 화면을 새로고침한 뒤 다시 시도해주세요.');});}
function pwOpenNote(t){var n=document.getElementById('pw-open-note');
 if(!n){n=document.createElement('div');n.id='pw-open-note';n.style.cssText='position:fixed;left:50%;bottom:18px;transform:translateX(-50%);background:var(--panel2);border:1px solid var(--border2);color:var(--text);padding:8px 14px;border-radius:10px;font-size:13px;z-index:99;box-shadow:0 8px 24px rgba(0,0,0,.35)';document.body.appendChild(n);}
 n.textContent=t||'열었습니다';n.style.display='block';clearTimeout(n._t);n._t=setTimeout(function(){n.style.display='none';},2500);}
/* 오른쪽 패널의 하위 폴더 더블클릭 = 트리에서 그 폴더를 펼치고 선택 */
function pwTreeGo(el){var key=el.dataset.key;var s=null;
 document.querySelectorAll('#tree-root summary').forEach(function(x){if(x.dataset.key===key)s=x;});
 if(!s)return;var d=s.parentElement;
 while(d&&d.tagName==='DETAILS'){d.open=true;d=d.parentElement.closest('details');}
 pwTreeSel(s,{target:null,preventDefault:function(){}});s.scrollIntoView({block:'nearest'});}
</script>"""


# 웹에서만 켜지는 보조 UI (2026-09-05 UI 리서치 반영). 브리핑 HTML(메일)은 그대로 둔다.
# ② 전/후 사진: '변경 전'·'변경 후' 두 장이 나란히 있는 곳을 찾아 2-up / 스와이프 / 겹침 모드를
#    붙인다 (GitHub 이미지 비교의 세 모드). 작은 배선 이동은 겹침에서 가장 잘 보인다.
# ③ 단축키: /(검색) · J/K(행 이동) · Enter(열기) · A(확인) · Ctrl+K(명령 팔레트) · ?(도움)
_UI_EXTRAS = """
<style>
.pw-cmp-bar{display:flex;gap:6px;align-items:center;margin:4px 0 6px;font-size:12px}
.pw-cmp-bar button{font-size:12px;padding:3px 10px;border-radius:7px;border:1px solid var(--border);
 background:var(--panel2);color:var(--muted);cursor:pointer}
.pw-cmp-bar button.on{background:var(--accent);color:var(--on-accent);border-color:var(--accent)}
.pw-cmp-bar input[type=range]{width:160px}
.pw-cmp-stage{position:relative;overflow:hidden;border:1px solid var(--border2);border-radius:6px;
 background:#fff;user-select:none}
.pw-cmp-stage img{display:block;width:100%;height:auto}
.pw-cmp-stage .top{position:absolute;inset:0}
.pw-cmp-stage .top img{position:absolute;left:0;top:0;width:100%}
.pw-cmp-stage .handle{position:absolute;top:0;bottom:0;width:2px;background:var(--accent);
 box-shadow:0 0 0 1px rgba(255,255,255,.6)}
.pw-cmp-stage .handle::after{content:"◀ ▶";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
 background:var(--accent);color:#fff;font-size:10px;padding:2px 5px;border-radius:9px;white-space:nowrap}
.pw-cmp-lab{position:absolute;top:6px;font-size:11px;font-weight:700;padding:1px 6px;border-radius:5px;
 background:rgba(0,0,0,.55);color:#fff}
tr.pw-sel td{background:var(--hover)!important;box-shadow:inset 3px 0 0 var(--accent)}
#pw-pal{position:fixed;inset:0;background:rgba(0,0,0,.35);display:none;z-index:60;align-items:flex-start;
 justify-content:center;padding-top:12vh}
#pw-pal.on{display:flex}
#pw-pal .box{width:min(560px,92vw);background:var(--panel);border:1px solid var(--border2);border-radius:12px;
 box-shadow:var(--shadow-lg);overflow:hidden}
#pw-pal input{width:100%;border:none;border-bottom:1px solid var(--border);padding:12px 14px;font-size:15px;
 background:var(--panel);color:var(--text);outline:none}
#pw-pal .list{max-height:50vh;overflow:auto;padding:6px}
#pw-pal .it{display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border-radius:8px;
 font-size:13px;cursor:pointer}
#pw-pal .it.on,#pw-pal .it:hover{background:var(--hover)}
#pw-pal .it kbd,.pw-keys kbd{font-family:inherit;font-size:11px;border:1px solid var(--border2);border-radius:5px;
 padding:0 5px;color:var(--muted);background:var(--panel2)}
#pw-pal .hint{padding:6px 12px;font-size:11.5px;color:var(--muted);border-top:1px solid var(--border)}
</style>
<div id="pw-pal" onclick="if(event.target===this)pwPal(false)"><div class="box">
 <input id="pw-pal-in" placeholder="이동·동작 검색 (예: 설정, 검사, 프로젝트 이름)…" autocomplete="off">
 <div class="list" id="pw-pal-list"></div>
 <div class="hint">↑↓ 이동 · Enter 실행 · Esc 닫기 · 단축키: <kbd>/</kbd> 검색 <kbd>J</kbd><kbd>K</kbd> 행 이동 <kbd>Enter</kbd> 열기 <kbd>A</kbd> 확인 <kbd>Ctrl+K</kbd> 이 창</div>
</div></div>
<script>
/* ② 전/후 사진 비교 모드 */
function pwCmpInit(){
 var labs=Array.prototype.slice.call(document.querySelectorAll('div'));
 labs.forEach(function(d){
  if(d.dataset.pwcmp)return;
  var kids=Array.prototype.filter.call(d.children,function(c){return c.tagName==='DIV'&&c.querySelector('img');});
  if(kids.length!==2)return;
  var t0=(kids[0].textContent||''),t1=(kids[1].textContent||'');
  var pair=(t0.indexOf('변경 전')>=0&&t1.indexOf('변경 후')>=0)||(t0.indexOf('이전 판')>=0&&t1.indexOf('새 판')>=0);
  if(!pair)return;
  d.dataset.pwcmp='1';
  var a=kids[0].querySelector('img'),b=kids[1].querySelector('img');
  var bar=document.createElement('div');bar.className='pw-cmp-bar';
  bar.innerHTML='<button class="on" data-m="2up">나란히</button><button data-m="swipe">스와이프</button>'
   +'<button data-m="onion">겹침</button><input type="range" min="0" max="100" value="50" style="display:none">'
   +'<span class="muted" style="font-size:11.5px">겹침: 작은 이동이 잘 보입니다</span>';
  var stage=document.createElement('div');stage.className='pw-cmp-stage';stage.style.display='none';
  stage.innerHTML='<img src="'+a.src+'"><div class="top"><img src="'+b.src+'"></div><div class="handle"></div>'
   +'<span class="pw-cmp-lab" style="left:6px">이전</span><span class="pw-cmp-lab" style="right:6px">새</span>';
  d.parentNode.insertBefore(bar,d);d.parentNode.insertBefore(stage,d.nextSibling);
  function fit(){var w=Math.max(a.naturalWidth||0,b.naturalWidth||0);if(w)stage.style.maxWidth=w+'px';}
  fit();a.addEventListener('load',fit);b.addEventListener('load',fit);
  var range=bar.querySelector('input'),top=stage.querySelector('.top'),topImg=top.querySelector('img'),
      handle=stage.querySelector('.handle'),mode='2up';
  function apply(){var v=+range.value;
   if(mode==='swipe'){top.style.clipPath='inset(0 0 0 '+v+'%)';top.style.opacity='1';handle.style.display='';handle.style.left=v+'%';}
   else if(mode==='onion'){top.style.clipPath='none';top.style.opacity=(v/100).toFixed(2);handle.style.display='none';}}
  bar.querySelectorAll('button').forEach(function(btn){btn.onclick=function(){
   mode=btn.dataset.m;bar.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===btn);});
   var two=mode==='2up';d.style.display=two?'':'none';stage.style.display=two?'none':'';
   range.style.display=two?'none':'';apply();};});
  range.oninput=apply;
  stage.addEventListener('mousemove',function(e){if(mode!=='swipe'||e.buttons!==1&&!stage.dataset.drag)return;
   var r=stage.getBoundingClientRect();range.value=Math.max(0,Math.min(100,(e.clientX-r.left)/r.width*100));apply();});
  stage.addEventListener('mousedown',function(){stage.dataset.drag='1';});
  document.addEventListener('mouseup',function(){delete stage.dataset.drag;});
 });}
document.addEventListener('DOMContentLoaded',pwCmpInit);
/* ③ 단축키: 표의 행을 J/K로 오가고 Enter로 열고 A로 확인 */
var pwSel=-1;
/* 접힌 <details> 안의 행은 offsetParent가 null이 아니다 — 그것까지 걸러야 J/K가 안 보이는
   자리에 멈추지 않고, 거기서 A를 눌러 접힌 건이 확인되는 일이 없다 (검토18 F8) */
function pwRows(){return Array.prototype.slice.call(document.querySelectorAll('table tr[data-name]')).filter(function(r){return r.offsetParent!==null&&!r.closest('details:not([open])');});}
function pwSelect(i){var rows=pwRows();if(!rows.length)return;pwSel=Math.max(0,Math.min(rows.length-1,i));
 rows.forEach(function(r,j){r.classList.toggle('pw-sel',j===pwSel);});
 rows[pwSel].scrollIntoView({block:'nearest'});}
/* 글자를 치고 있는 중인가 — 링크·단추는 제외한다. Tab으로 옮기면 반드시 링크에 멈추는데,
   그것까지 '타자 중'으로 치면 키보드 이동과 단축키를 동시에 못 쓴다 (조작성 검토 치명-2) */
function pwTyping(e){var t=e.target;return t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT'||t.isContentEditable);}
/* 한글 입력 상태에서는 e.key가 'Process'로 온다 — 자판 **위치**(e.code)로 봐야 한국어로
   쓰는 사람에게도 듣는다 (조작성 검토 치명-1). 화살표도 함께 받는다 */
function pwKey(e,code,key){return e.code===code||(e.key&&e.key.toLowerCase()===key);}
document.addEventListener('keydown',function(e){
 if((e.ctrlKey||e.metaKey)&&pwKey(e,'KeyK','k')){e.preventDefault();pwPal(true);return;}
 if(pwTyping(e)||e.ctrlKey||e.metaKey||e.altKey)return;
 var pal=document.getElementById('pw-pal');
 if(pal.classList.contains('on')){return;}
 /* 자판마다 Slash 자리가 다르다 — 글자가 '/'거나 자리가 Slash면 둘 다 받는다 (검토17 R7) */
 if(e.key==='/'||(e.code==='Slash'&&!e.shiftKey)){e.preventDefault();var s=document.querySelector('.side-search input');if(s){s.focus();s.select();}return;}
 if(e.key==='?'||(e.code==='Slash'&&e.shiftKey)){e.preventDefault();pwPal(true);return;}
 if(pwKey(e,'KeyJ','j')||e.key==='ArrowDown'){e.preventDefault();pwSelect(pwSel+1);return;}
 if(pwKey(e,'KeyK','k')||e.key==='ArrowUp'){e.preventDefault();pwSelect(pwSel-1);return;}
 /* 단추·링크에 포커스가 있으면 그 자리의 Enter/글자는 그쪽 것이다 — 가로채면
    [지금 검사]에 포커스를 두고 Enter를 눌렀을 때 엉뚱한 상세 화면으로 갔다 (검토17 R2) */
 var onCtl=e.target&&e.target.closest&&e.target.closest('a,button');
 if(e.key==='Enter'){if(onCtl||pwSel<0)return;var r=pwRows()[pwSel];var a=r&&r.querySelector('a[href*="/change?id="]');if(a){e.preventDefault();location.href=a.getAttribute('href');}return;}
 if(pwKey(e,'KeyA','a')){if(onCtl||pwSel<0)return;var r=pwRows()[pwSel];var f=r&&r.querySelector('form.ackq');
  if(f){e.preventDefault();var btn=f.querySelector('button');if(btn)btn.click();}return;}
});
/* ③ 명령 팔레트: 메뉴 + 동작 + 프로젝트 */
var pwPalItems=null,pwPalIdx=0;
function pwPalBuild(){if(pwPalItems)return pwPalItems;var it=[];
 document.querySelectorAll('.nav a').forEach(function(a){it.push({t:a.textContent.trim(),s:'이동',go:a.getAttribute('href')});});
 var scan=document.querySelector('form[action="/scan"] button');if(scan)it.push({t:'지금 검사 시작',s:'동작',act:function(){scan.click();}});
 var stop=document.querySelector('form[action$="/stop"] button');if(stop)it.push({t:'검사 중지',s:'동작',act:function(){stop.click();}});
 it.push({t:'다크/라이트 전환',s:'보기',act:function(){pwTheme();}});
 it.push({t:'글자 크게 (확대)',s:'보기',act:function(){pwFs('big');}});
 it.push({t:'글자 아주 크게 (많이 확대)',s:'보기',act:function(){pwFs('huge');}});
 it.push({t:'글자 크기 원래대로',s:'보기',act:function(){pwFs('normal');}});
 it.push({t:'표 행 간격 촘촘/보통/넓게',s:'보기',act:function(){var n={tight:'normal',normal:'wide',wide:'tight'};pwDense(n[document.documentElement.dataset.dense||'normal']);}});
 it.push({t:'폴더 구조 전체 화면',s:'이동',go:'/tree'});
 it.push({t:'뒤로',s:'이동',act:function(){pwBack();}});
 document.querySelectorAll('a[href^="/project?name="],a[href^="/?p="]').forEach(function(a){var n=a.textContent.trim();
  if(n&&n.length<60&&!it.some(function(x){return x.go===a.getAttribute('href');}))it.push({t:'프로젝트 '+n,s:'프로젝트',go:a.getAttribute('href')});});
 pwPalItems=it;return it;}
function pwPal(open){var p=document.getElementById('pw-pal'),i=document.getElementById('pw-pal-in');
 p.classList.toggle('on',!!open);if(open){i.value='';pwPalRender('');setTimeout(function(){i.focus();},0);}}
function pwEsc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function pwPalRender(q){var list=document.getElementById('pw-pal-list');q=q.toLowerCase();
 var items=pwPalBuild().filter(function(x){return !q||x.t.toLowerCase().indexOf(q)>=0;}).slice(0,14);
 pwPalIdx=Math.min(pwPalIdx,Math.max(0,items.length-1));
 list.innerHTML=items.map(function(x,j){return '<div class="it'+(j===pwPalIdx?' on':'')+'" data-j="'+j+'"><span>'+pwEsc(x.t)+'</span><kbd>'+pwEsc(x.s)+'</kbd></div>';}).join('')
  ||'<div class="it muted">일치하는 항목이 없습니다</div>';
 list.querySelectorAll('.it[data-j]').forEach(function(el){el.onclick=function(){pwPalGo(items[+el.dataset.j]);};});
 list.dataset.n=items.length;window.pwPalCur=items;}
function pwPalGo(x){if(!x)return;pwPal(false);if(x.go)location.href=x.go;else if(x.act)x.act();}
document.addEventListener('DOMContentLoaded',function(){var i=document.getElementById('pw-pal-in');if(!i)return;
 i.addEventListener('input',function(){pwPalIdx=0;pwPalRender(i.value);});
 i.addEventListener('keydown',function(e){var items=window.pwPalCur||[];
  if(e.key==='Escape'){pwPal(false);}
  else if(e.key==='ArrowDown'){e.preventDefault();pwPalIdx=Math.min(items.length-1,pwPalIdx+1);pwPalRender(i.value);}
  else if(e.key==='ArrowUp'){e.preventDefault();pwPalIdx=Math.max(0,pwPalIdx-1);pwPalRender(i.value);}
  else if(e.key==='Enter'){e.preventDefault();pwPalGo(items[pwPalIdx]);}});});
</script>"""


# head에는 style·script만, 팔레트 div는 body 끝으로 (재검토 L1: head 안의 div가 본문으로 밀렸다)
_pal_a = _UI_EXTRAS.index('<div id="pw-pal"')
_pal_b = _UI_EXTRAS.index('</div></div>\n', _pal_a) + len('</div></div>\n')
_UI_PAL_DIV = _UI_EXTRAS[_pal_a:_pal_b]
_UI_EXTRAS_HEAD = _UI_EXTRAS[:_pal_a] + _UI_EXTRAS[_pal_b:]


def _ext_category(path: str) -> str:
    ext = PurePosixPath(path).suffix.lower()
    for cat, exts in CATEGORIES.items():
        if ext in exts:
            return cat
    return "기타"


def _row_values(s: str | None) -> list[tuple[str, str]]:
    """diff가 str(dict)로 남긴 행 값을 (열, 값) 목록으로. 빈 값은 버린다."""
    import ast
    try:
        d = ast.literal_eval(s or "")
        return [(str(k), str(v)) for k, v in d.items() if str(v).strip()]
    except (ValueError, SyntaxError):
        return [("", s)] if s else []


def _row_summary(vals: list[tuple[str, str]], keep: int = 5) -> str:
    """행 요약 — 앞쪽 열 몇 개만. 열이 수십 개인 시트(인터락 등)에서 한 줄이
    화면을 뒤덮던 문제 (2026-08-31 사용자 지적: '좀 더 정리가 잘되게')."""
    head = vals[:keep]
    out = " · ".join(f'<span class="muted">{_E(k)}</span> {_E(v[:60])}'
                     for k, v in head)
    if len(vals) > keep:
        rest = "".join(f'<tr><td class="c1">{_E(k)}</td><td>{_E(v)}</td></tr>'
                       for k, v in vals[keep:])
        out += (f'<details style="margin-top:4px"><summary class="muted" '
                f'style="cursor:pointer;font-size:12px">나머지 {len(vals)-keep}개 열 '
                f'보기</summary><table class="subt">{rest}</table></details>')
    return out or '<span class="muted">—</span>'


# 구매와 무관한 표들 — 한글·영문 표기 양쪽 (2026-09-01: 영문 파일명은 영문 이름)
_NON_PURCHASE = {"인터락", "Interlock", "점검표", "Checklist",
                 "배선표", "Cable List", "사양서", "Spec",
                 "시퀀스", "Sequence"}


def _impact_label(path: str) -> str:
    """행 변경 요약 줄의 이름 — 구매와 무관한 표에까지 '발주 영향'이라 쓰지 않는다.
    (2026-08-31: 인터락 시트가 BOM으로 표시되던 문제와 같은 뿌리)"""
    from watcher.brief import sheet_kind
    return "변경 요약" if sheet_kind(path) in _NON_PURCHASE else "발주 영향"


def _web_row_table(items, extra_cell=None) -> str:
    """화면용 표(BOM·인터락 등) 변경 — 같은 행의 열 변경을 한 줄로 묶어 보여준다.

    메일용 _row_diff_table은 색을 고정 hex로 박아 다크 화면에서 글자가 안 보이고
    (2026-08-31 '안 보이는 글씨도 있고'), 값 변경을 열마다 한 줄씩 뿌려 수백 줄이
    됐다. 화면은 테마 색을 쓰고 행 단위로 묶는다."""
    groups: dict[str, list] = {}
    order: list[str] = []
    for i in items:
        gid = (i.key.rpartition(".")[0] or i.key) if i.kind == "ROW_CHANGED" \
            else f"{i.kind}|{i.key}"
        if gid not in groups:
            groups[gid] = []
            order.append(gid)
        groups[gid].append(i)

    trs = []
    for gid in order:
        g = groups[gid]
        first = g[0]
        extra = (f'<td>{extra_cell(first)}</td>') if extra_cell else ""
        label = (f'<div class="muted" style="font-size:12px">{_E(first.label)}</div>'
                 if getattr(first, "label", None) else "")
        where = _E(first.where or "")
        if first.kind == "ROW_CHANGED":
            cols = "".join(
                f'<div class="cchg"><b>{_E(i.key.rpartition(".")[2])}</b> '
                f'<span class="from">{_wdiff(i.old, i.new)[0]}</span> → '
                f'<span class="to">{_wdiff(i.old, i.new)[1]}</span>'
                f'{_delta(i.old, i.new)}</div>' for i in g)
            trs.append(f'<tr><td><span class="tag modified">값 변경</span>'
                       f'<div class="muted" style="font-size:12px;margin-top:3px">'
                       f'{len(g)}개 열</div></td>'
                       f'<td><code>{_E(gid)}</code>{label}</td>'
                       f'<td class="val">{cols}</td>'
                       f'<td class="loc muted">{where}</td>{extra}</tr>')
        elif first.kind == "ROW_ADDED":
            trs.append(f'<tr><td><span class="tag added">행 추가</span></td>'
                       f'<td><code>{_E(first.key)}</code>{label}</td>'
                       f'<td class="val">{_row_summary(_row_values(first.new))}</td>'
                       f'<td class="loc muted">{where}</td>{extra}</tr>')
        elif first.kind == "ROW_REMOVED":
            trs.append(f'<tr><td><span class="tag removed">행 삭제</span></td>'
                       f'<td><code>{_E(first.key)}</code>{label}</td>'
                       f'<td style="text-decoration:line-through;opacity:.75">'
                       f'{_row_summary(_row_values(first.old))}</td>'
                       f'<td class="loc muted">{where}</td>{extra}</tr>')
    if not trs:
        return ""
    return (f'<div class="scrolly"><table class="rtab">'
            f'<tr><th>구분</th><th>행</th><th>바뀐 내용</th><th>위치</th>'
            + ("<th></th>" if extra_cell else "") + "</tr>"
            + "".join(trs) + "</table></div>")


_WEB_ITEM_KIND = {
    "NEW_REVISION_OF": ("이전 판", "na"),
    "FIELD_CHANGED": ("값 변경", "modified"),
    "FIELD_ADDED": ("값 추가", "added"),
    "FIELD_REMOVED": ("값 삭제", "removed"),
    "TEXT_CHANGED": ("글자 변경", "modified"),
    "TEXT_ADDED": ("글자 추가", "added"),
    "TEXT_REMOVED": ("글자 삭제", "removed"),
    "PAGE_VISUAL_CHANGED": ("그림 변경", "done"),
    "PAGE_ADDED": ("페이지 추가", "added"),
    "COL_RENAMED": ("열 이름 변경", "na"),
    "COL_ADDED": ("열 추가", "added"),
    "COL_REMOVED": ("열 삭제", "removed"),
    "ROW_MOVED": ("행 이동", "na"),
    "COL_MOVED": ("열 이동", "na"),
    "PAGE_MOVED": ("페이지 순서", "na"),
    "TEXT_MOVED": ("문단 이동", "na"),
    "SHEET_ADDED": ("시트 추가", "added"),
    "SHEET_REMOVED": ("시트 삭제", "removed"),
    "SHEET_RENAMED": ("시트 이름 변경", "na"),
    "PAGE_REMOVED": ("페이지 삭제", "removed"),
    # 메일만 고치고 화면 표에는 REVROW_ADDED가 그대로 찍혔다 (2026-09-05 재검토)
    "REVROW_ADDED": ("리비전 행 추가", "added"),
    "REVROW_REMOVED": ("리비전 행 삭제", "removed"),
    "REVROW_CHANGED": ("리비전 행 변경", "modified"),
    "CHECK_SKIPPED": ("참고", "na"),
}


def _fmt_val(v) -> str:
    from watcher.brief import fmt_val
    return fmt_val(v)


_WD = 'class="wdel"'
_WI = 'class="wins"'


def _wdiff(old, new) -> tuple[str, str]:
    from watcher.brief import word_diff_html
    return word_diff_html(old, new, esc=_E, del_attr=_WD, ins_attr=_WI)


def _web_item_table(items, cap_of=None, extra_cell=None) -> str:
    """개별 변경 항목의 화면용 표 — 메일용(고정 밝은 색) 대신 테마 색을 쓴다.

    다크 화면에서 밝은 배경 위에 어두운 글씨가 그대로 찍혀 일부 칸이 검은
    박스로 보이던 문제 (2026-08-31 '안 보이는 글씨도 있고')."""
    from watcher.brief import render_capture
    if not items:
        return ""
    ncols = 5 + (1 if extra_cell else 0)
    trs = []
    for i in items:
        label, cls = _WEB_ITEM_KIND.get(i.kind, (i.kind, "na"))
        x = f"<td>{extra_cell(i)}</td>" if extra_cell else ""
        if i.kind in ("TEXT_CHANGED", "FIELD_CHANGED", "REVROW_CHANGED"):
            o_html, n_html = _wdiff(i.old, i.new)     # 바뀐 낱말만 표시 (2026-09-06)
        else:
            o_html, n_html = _E(_fmt_val(i.old)), _E(_fmt_val(i.new))
        trs.append(
            f'<tr><td><span class="tag {cls}">{_E(label)}</span></td>'
            f'<td><code>{_E(i.key)}</code></td>'
            f'<td class="from">{o_html}</td>'
            f'<td class="to val">{n_html}{_delta(i.old, i.new)}</td>'
            f'<td class="loc muted">{_E(i.where)}</td>{x}</tr>')
        cap = cap_of(i) if cap_of else None
        if cap:
            block = render_capture(cap)
            if block:
                trs.append(f'<tr><td colspan="{ncols}">{block}</td></tr>')
    return (f'<div class="scrolly"><table class="rtab">'
            f'<tr><th>구분</th><th>항목</th><th>이전</th><th>새 값</th>'
            f'<th>위치</th>' + ("<th></th>" if extra_cell else "") + "</tr>"
            + "".join(trs) + "</table></div>")


def _delta(old: str | None, new: str | None) -> str:
    """수량처럼 숫자면 증감 배지."""
    try:
        d = float(new) - float(old)      # type: ignore[arg-type]
    except (TypeError, ValueError):
        return ""
    if d == 0:
        return ""
    col = "var(--ok)" if d > 0 else "var(--bad)"
    return (f' <span style="color:{col};font-weight:700;font-size:12px">'
            f'{"+" if d > 0 else ""}{d:g}</span>')


_LAMP = {
    "watched":   ("",    "감시 중"),
    "root":      ("",    "감시 폴더 — 여기서는 뺄 수 없습니다"),
    "direct":    ("off", "감시에서 뺀 폴더"),
    "inherited": ("sub", "상위 폴더가 빠져 함께 빠짐"),
}


def exclude_state_of(key: str, labels: list, raw_excludes: list) -> tuple[str, str]:
    """폴더 하나의 감시 상태 → (상태, 그렇게 만든 제외 항목 원문).

    'direct'    = 이 폴더가 제외 목록에 있다 — 여기서 바로 되돌릴 수 있다.
    'inherited' = 상위 폴더가 빠져 딸려 나갔다 — 되돌리려면 그 상위 항목을 풀어야 한다.
    'watched'   = 감시 중. 감시 폴더(루트) 자신은 언제나 감시 중이다.

    제외 항목은 '라벨/상대경로'(그 감시 폴더에만)와 라벨 없는 형식(모든 감시 폴더에)
    두 가지다 — cli._excludes_for와 같은 규칙으로 읽는다 (2026-09-07)."""
    key = (key or "").strip("/")
    label, _, rel = key.partition("/")
    if label in labels and not rel:
        # 감시 폴더 자신 — 제외 목록에 라벨만 적으면 `_excludes_for`가 버려서 아무 일도 안 일어난다.
        # 예전에는 [빼기] 단추가 뜨고 "뺐습니다"까지 말한 뒤 다음 검사에서 전부 그대로 스캔됐다
        # (2026-09-07 사용성 7차 치명 A). 감시 폴더는 설정에서 통째로 지우는 것 말고는 뺄 수 없다.
        return ("root", "")
    if not rel or label not in labels:
        return ("watched", "")
    inherited = ""
    for raw in raw_excludes:
        e = str(raw).strip("/")
        head = e.split("/", 1)[0]
        if head == label and "/" in e:
            cand = e.split("/", 1)[1]
        elif head not in labels:
            cand = e
        else:
            continue                       # 다른 감시 폴더 몫
        cand = cand.strip("/").strip()     # is_excluded와 같은 다듬기 — 조각에 공백이 끼면
        if not cand:                       # 램프는 초록인데 검사는 빼던 것 (2026-09-07 운영 검토 2)
            continue
        if rel == cand:
            return ("direct", str(raw))    # 직접 지정이 우선 — 여기서 되돌린다
        if rel.startswith(cand + "/") and not inherited:
            inherited = str(raw)
    return ("inherited", inherited) if inherited else ("watched", "")


def kind_of_dir(d: str, paths, cfg) -> str:
    """그 폴더에서 가장 많이 나온 자동 분류 이름 — 지정 전 참고용."""
    from collections import Counter
    from watcher.doctype import kind_of
    c = Counter(kind_of(p, cfg) for p in paths
                if str(PurePosixPath(p).parent) == d)
    return c.most_common(1)[0][0] if c else "-"


_LAST_CFG: dict | None = None      # 마지막으로 읽은 설정 (표시용 분류에만 사용)


# 추출 엔진이 내는 영문 오류를 현장 사용자가 읽을 수 있게 한 줄 덧붙인다.
# xlsx 쪽은 감싸고 있었는데 pdf 쪽은 원문이 그대로 화면에 나왔다 (웹 검토 중간 8)
_ENGINE_HINTS = (
    ("Data format error", "PDF 구조가 깨져 있습니다 — 다시 저장(인쇄)해 주시면 비교됩니다"),
    ("PDFium", "PDF를 읽는 엔진이 이 파일을 열지 못했습니다"),
    ("not a zip file", "xlsx/docx 파일이 손상됐거나 저장이 끊겼습니다"),
    ("Password", "암호가 걸린 파일입니다 — 암호를 풀어 저장하면 비교됩니다"),
    ("Permission denied", "파일이 다른 프로그램에 잠겨 있습니다"),
)


def _plain_engine_error(text: str) -> str:
    """영문 엔진 오류에 한국어 설명을 덧붙인다 (원문도 남긴다 — 문의에 필요하다)."""
    s = str(text or "")
    for mark, say in _ENGINE_HINTS:
        if mark.lower() in s.lower():
            return f"{s} · {say}"
    return s


def _ellipsis(name: str, keep: int = 34) -> str:
    """긴 파일 이름을 줄이되 **확장자와 잘렸다는 표시를 남긴다**.

    전에는 36자에서 그냥 잘려 말줄임표도, 확장자도, 마우스 설명도 없었다 —
    대시보드에서 어떤 파일인지 알 수 없었다 (2026-09-09 웹 검토 중간 7)."""
    s = str(name or "")
    if len(s) <= keep:
        return s
    stem, dot, ext = s.rpartition(".")
    if dot and len(ext) <= 5:
        head = max(6, keep - len(ext) - 2)
        return f"{stem[:head]}….{ext}"
    return s[:keep - 1] + "…"


_DIR_SIZE: dict = {}            # {폴더: (잰 시각, 바이트, 파일 수)}


def _dir_size_cached(path: Path, ttl: float = 300.0) -> tuple[int, int]:
    """폴더 크기 — 5분 캐시. 설정 화면이 매 렌더마다 브리핑 폴더를 전수 조사해,
    파일 12,000개(240MB)에서 화면 한 장이 110ms → 1,450ms가 됐다
    (2026-09-09 배포 후 검토 중간 6)."""
    from watcher.cli import dir_size
    key = str(path)
    got = _DIR_SIZE.get(key)
    if got and time.time() - got[0] < ttl:
        return got[1], got[2]
    size, n = dir_size(path)
    _DIR_SIZE[key] = (time.time(), size, n)
    return size, n


def _cat_display(path: str, cfg: dict | None = None) -> str:
    """목록에 보여줄 문서 구분 — 사용자가 만든 규칙까지 반영한다 (2026-08-31).
    사이드바 분류/필터(도면·BOM·문서)는 그대로 두고 표시만 실제 성격으로."""
    from watcher.doctype import canonical, kind_of
    # 영문 폴더의 'Drawing'·'Purchase Order'가 한글 '도면'·'발주서'와 따로 떠 같은 종류가
    # 둘로 보였다 (2026-09-05 전체 검토) — 표시는 정규 이름 하나로
    return canonical(kind_of(path, cfg if cfg is not None else _LAST_CFG))


def _kind_tag(kind: str) -> str:
    return f'<span class="tag {kind}">{KIND_LABEL[kind]}</span>'


def _move_tag(r: dict) -> str:
    """이동(이름·위치 변경)으로 접힌 행은 '이동' 태그 — 삭제+추가 두 줄이 아니라 한 줄."""
    if r.get("moved_from"):
        return (f'<span class="tag na" title="이전: {_E(r["moved_from"])}">이동</span>')
    return _kind_tag(r["kind"])


def _login_name() -> str:
    """확인자 이름 기본값 — 설정의 '확인자 이름'이 있으면 그것(2026-09-05: 개발 PC 로그인명이
    이력·메일에 남았다), 없으면 윈도우 로그인 계정."""
    name = str((_LAST_CFG or {}).get("ack_name") or "").strip()
    return name or os.environ.get("USERNAME") or os.environ.get("USER") or ""


def _doc_rank(path: str) -> int:
    """돈·납기·규격이 걸린 유형이 앞에 온다 — 회의록·참고자료는 뒤 (2026-09-05)."""
    from watcher.doctype import doc_rank
    try:
        return doc_rank(_cat_display(path))
    except Exception:
        return 50


def _ack_default(cookie: str = "") -> str:
    """확인 폼에 미리 채울 이름 — 설정의 '확인자 이름'이 먼저, 없으면 최근 확인자(쿠키),
    그것도 없으면 로그인명. 대시보드는 김팀장, 상세는 로그인명으로 같은 사람이 두 이름으로
    기록되던 것 (2026-09-05 사용성 재검토)."""
    name = str((_LAST_CFG or {}).get("ack_name") or "").strip()
    return name or (cookie or "").strip() or _login_name()


def _ack_tag(r: dict, tok: str | None = None) -> str:
    """확인 칸. 미확인이면 눌러서 바로 확인되는 버튼이다 (2026-09-02).

    알약 모양이라 눌릴 것처럼 생겼는데 아무 일도 없던 것 — 이제 한 번 누르면
    확인 처리된다. 확인자 이름은 목록 위 칸에 한 번만 적으면 기억된다."""
    if r["ack_by"]:
        note = f" — {r['ack_note']}" if r["ack_note"] else ""
        return f'<span class="tag done">확인</span> {_E(r["ack_by"])}{_E(note)}'
    if r.get("baseline"):
        # 첫 검사 때 등록된 파일 — 변경이 아니라 확인을 요구하지 않는다
        return ('<span class="tag na" title="첫 검사(기준선) 때 등록된 파일 — 실제 '
                '변경이 아닙니다">첫 등록</span>')
    if not tok:
        return '<span class="tag na">미확인</span>'
    also = r.get("also_id")
    return (f'<form class="inline ackq" method="post" action="/ack/quick">'
            f'<input type="hidden" name="t" value="{tok}">'
            f'<input type="hidden" name="id" value="{r["change_id"]}">'
            + (f'<input type="hidden" name="also" value="{also}">' if also else "")
            + f'<input type="hidden" name="by" value="">'
            f'<input type="hidden" name="back" value="">'
            f'<button class="tag na ackbtn" title="눌러서 확인 처리합니다'
            f'{" (이동 전·후 두 건 함께)" if also else ""}">'
            f'미확인</button></form>')


def _path_html(path: str) -> str:
    """긴 경로의 표시용: 파일명 굵게 + 바로 위 폴더 1~2단계만 회색.
    깊은 서버 경로가 화면을 다 차지하던 문제 (2026-08-28 검토). 전체 경로는
    셀의 title 툴팁으로."""
    parts = path.split("/")
    name = parts[-1]
    # 바로 위 폴더 한 단계만 — 목록에는 프로젝트 열이 따로 있어 상위 경로는
    # 매 행 반복되는 소음이었다 (2026-09-01 화면 점검). 전체 경로는 툴팁으로
    crumb = parts[-2] if len(parts) >= 2 else ""
    pre = (f'<span class="muted" style="font-size:12px">{_E(crumb)}/</span>'
           if crumb else "")
    return f"{pre}<b>{_E(name)}</b>"


def _app_for(ext: str):
    """확장자에 연결된 프로그램(실행 파일 또는 스토어 앱 ProgId). 없으면 None — 이때 ShellExecute는
    파일을 여는 대신 '이 파일을 열 방법 선택' 창(OpenWith.exe)을 띄운다 (2026-09-06 사용자: "안 열려, 이상한
    오류 같은 창만 뜨고" — 연결이 지워진 PC의 .dxf)."""
    if not ext:
        return None
    try:
        import ctypes
        from ctypes import wintypes
        buf = ctypes.create_unicode_buffer(1024)
        n = wintypes.DWORD(1024)
        # ASSOCF_VERIFY(0x40): 지워진 CAD의 옛 연결(실행 파일 없음)은 연결이 아니다 (리뷰13 낮음-8)
        hr = ctypes.windll.shlwapi.AssocQueryStringW(0x40, 2, ext, None, buf, ctypes.byref(n))   # ASSOCSTR_EXECUTABLE
        exe = buf.value if hr == 0 else ""
        if exe and not exe.lower().endswith("openwith.exe") and Path(exe).is_file():
            return exe
    except Exception:
        pass
    try:                                     # 스토어 앱(사진·메모장 등)은 사용자 선택 키에만 있다 — ProgId에 open 동사가 있어야 (리뷰13 중간-2)
        import winreg
        key = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\" + ext + "\\UserChoice"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as k:
            prog = winreg.QueryValueEx(k, "ProgId")[0]
        if not prog or prog == "Unknown":
            return None
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, prog + "\\Shell\\open"):
            return prog
    except OSError:
        return None


# [열기]로 실행되면 안 되는 형식 — 문서가 아니라 프로그램·스크립트 (검토19 웹 S2)
_EXEC_EXTS = frozenset((
    ".exe", ".com", ".scr", ".pif", ".bat", ".cmd", ".vbs", ".vbe", ".js", ".jse",
    ".wsf", ".wsh", ".hta", ".ps1", ".psm1", ".msi", ".msix", ".msp", ".lnk", ".reg",
    ".jar", ".py", ".pyw", ".url", ".inf", ".cpl", ".appx", ".application",
    # 검토21 웹 D — 실제로 os.startfile까지 가던 21종: 바로가기·설정 파일 위장, 스크립트, 라이브러리, 디스크 이미지
    ".settingcontent-ms", ".scf", ".xll", ".msc", ".chm", ".appref-ms", ".website", ".library-ms",
    ".diagcab", ".diagcfg", ".ppkg", ".sct", ".ws", ".wsc", ".psc1", ".psc2", ".psd1", ".ps1xml",
    ".ps2", ".ps2xml", ".mht", ".mhtml", ".dll", ".ocx", ".sys", ".drv", ".iso", ".img", ".vhd", ".vhdx",
    ".xbap", ".gadget", ".job", ".mst", ".vb", ".vbscript", ".pl", ".rb", ".sh", ".theme", ".themepack",
    ".deskthemepack", ".msh", ".msh1", ".msh2", ".mshxml", ".jnlp", ".hlp", ".grp", ".ade", ".adp",
    ".mda", ".mdb", ".mde", ".mdt", ".mdw", ".mdz", ".bas", ".cer", ".crt", ".der", ".pem", ".udl"))


def open_target(target: Path) -> str:
    """이 PC의 기본 프로그램으로 파일(또는 폴더)을 연다 — 결과 문구를 돌려준다.
    파일 형식에 연결된 프로그램이 없으면 '열 방법 선택' 창을 띄우지 않고 파일이 있는 폴더를 연다."""
    target = Path(target)
    if target.is_file() and target.suffix.lower() in _EXEC_EXTS:
        # 공유 파일서버에는 누구나 파일을 둘 수 있다 — 'P26-001_긴급.exe'를 도면인 줄
        # 알고 [열기]를 누르면 그 자리에서 실행됐다(검토19 웹 S2, .vbs로 실증). 실행류는
        # 열지 않고 폴더만 연다
        try:
            os.startfile(str(target.parent))
        except OSError as e:
            return f"열지 못했습니다: {e}"
        return (f"{target.suffix.lower()} 파일은 실행 파일이라 안전을 위해 Drev가 직접 열지 "
                f"않습니다 — 파일이 있는 폴더를 열었습니다")
    if target.is_file():
        ext = target.suffix.lower()
        if _app_for(ext) is None:
            try:
                os.startfile(str(target.parent))
            except OSError as e:
                return f"열지 못했습니다: {e}"
            return (f"이 PC에는 {ext} 파일을 여는 프로그램이 없어 파일이 있는 폴더를 열었습니다 — "
                    f"프로그램을 설치하거나 다른 PC에서 여세요 (Windows 설정 › 앱 › 기본 앱에서 {ext} 연결)")
    before = _openwith_pids()
    try:
        os.startfile(str(target))
    except OSError as e:
        return f"열지 못했습니다: {e}"
    if target.is_file():
        # 연결이 있어 보여도 Windows가 '열 방법 선택' 창을 띄우는 경우(스토어 앱 깨짐 등) — 그 창이 새로 떴으면
        # 파일 대신 폴더를 열어 준다. 창은 닫지 않는다(남의 프로세스를 끝내지 않는 원칙)
        import time as _t
        _t.sleep(1.2)
        if _openwith_pids() - before:
            try:
                os.startfile(str(target.parent))
            except OSError:
                pass
            return (f"이 PC에서 {target.suffix.lower()} 파일을 여는 프로그램이 응답하지 않아 파일이 있는 폴더를 열었습니다 — "
                    f"Windows 설정 › 앱 › 기본 앱에서 {target.suffix.lower()} 연결을 확인하세요")
    return f"열기를 요청했습니다: {target.name}"


def _openwith_pids() -> set:
    """'열 방법 선택' 창(OpenWith.exe) 프로세스 ID 집합 — 열기 전후를 비교해 그 창이 떴는지 안다."""
    try:
        import subprocess as _sp
        r = _sp.run(["tasklist", "/FI", "IMAGENAME eq OpenWith.exe", "/FO", "CSV", "/NH"], capture_output=True,
                    encoding="mbcs", errors="replace", timeout=5, creationflags=0x08000000)
        out = set()
        for line in (r.stdout or "").splitlines():
            parts = [x.strip('"') for x in line.split('","')]
            if len(parts) >= 2 and parts[0].lower() == "openwith.exe" and parts[1].isdigit():
                out.add(int(parts[1]))
        return out
    except Exception:
        return set()


def _js(s: str) -> str:
    """JS 문자열 리터럴 — 속성 안에 넣으므로 따옴표·꺾쇠도 이스케이프."""
    import json as _json
    return _E(_json.dumps(str(s), ensure_ascii=False))


def _open_cell(key: str, tok: str) -> str:
    """파일·폴더 바로 열기 버튼 — 목록에서 파일까지 찾아가는 수고 제거 (2026-08-29)."""
    return (f"<td style='white-space:nowrap'>"
            f'<form class="inline rowact" method="post" action="/open">'
            f'<input type="hidden" name="t" value="{tok}">'
            f'<input type="hidden" name="k" value="{_E(key)}">'
            f'<button class="btn gray" name="w" value="f" title="이 PC 기본 '
            f'프로그램으로 파일 열기" style="font-size:12px;padding:2px 7px">'
            f'열기</button> '
            f'<button class="btn gray" name="w" value="d" title="파일이 있는 '
            f'폴더 열기" style="font-size:12px;padding:2px 7px">폴더</button>'
            f'</form></td>')


def _confirm(msg: str) -> str:
    """되돌릴 수 없는 동작 앞에 확인 창을 띄운다 (2026-09-01 요청).

    무엇이 사라지는지 대상 이름을 문구에 넣어 준다. 따옴표·역슬래시는 공백으로
    눕힌다 (str.replace는 읽기전용 가드가 파일 이동 API로 오인하므로 문자
    단위로 처리 — 코드베이스 관례). 속성은 큰따옴표, JS 문자열은 &quot; 엔티티."""
    bad = set("'\"\\\n\r")
    safe = "".join(" " if ch in bad else ch for ch in msg)
    return f' onsubmit="return confirm(&quot;{_E(safe)}&quot;)"'


def _by_project_grid(rows: list[dict], tok: str, base_href: str,
                     per: int = 8) -> str:
    """프로젝트별로 칸을 나눠 보여준다 — 한 표에 다 쏟으면 찾기 어렵다는
    피드백 반영 (2026-09-01). 넓은 화면에서는 여러 칸이 가로로 배치된다."""
    if not rows:
        return ('<div class="panel"><p class="muted">해당 항목이 '
                '없습니다.</p></div>')
    by: dict[str, list] = {}
    for r in rows:
        by.setdefault(r["project"] or "미분류", []).append(r)
    order = sorted(by.items(), key=lambda kv: kv[1][0]["detected_at"], reverse=True)
    cards = ""
    for name, rs in order:
        real = sum(1 for r in rs if not r.get("baseline"))
        base_n = len(rs) - real
        unacked = sum(1 for r in rs if not r["ack_by"] and not r.get("baseline"))
        # 머리글은 '변경 2건'인데 본문에 기준선 행까지 4줄이 나와 숫자가 안 맞았다
        # (2026-09-09 웹 검토 중간 5). 둘을 각각 말하고, 변경을 먼저 보여 준다
        cnt = (f"{real}건" + (f" · 첫 등록 {base_n}건" if base_n else "")
               if real else f"첫 등록 {len(rs)}건")
        head = (f'<div class="pc-head">'
                f'<a href="/project?name={quote(name)}">{_E(name)}</a>'
                f'<span class="muted" style="font-size:12px">{cnt}'
                + (f' · <b style="color:var(--warn)">미확인 {unacked}</b>'
                   if unacked else "") + '</span></div>')
        shown = sorted(rs, key=lambda r: bool(r.get("baseline")))[:per]
        items = "".join(
            f'<div class="pfile"><a href="/change?id={r["change_id"]}" '
            f'title="{_E(r["path"])}">'
            + ('<span class="tag na">첫 등록</span> ' if r.get("baseline")
               else _kind_tag(r["kind"]) + " ")
            + f'{_path_html(r["path"])}</a> '
            f'<span class="muted" style="font-size:12px">'
            f'{_E(_local(r["detected_at"], "%m-%d"))}</span></div>'
            for r in shown)
        more = (f'<a class="pc-more" href="{base_href}'
                f'{"&" if "?" in base_href else "?"}p={quote(name)}">'
                f'외 {len(rs) - per}건 →</a>' if len(rs) > per else "")
        cards += f'<div class="pcard">{head}{items}{more}</div>'
    return f'<div class="pcards">{cards}</div>'


_SIDE_NOTES: tuple = (0.0, {}, None)


def _side_note_map(db_path) -> dict:
    """참고 메모 표(변경 id → 문구). 30초 캐시 — 목록마다 다시 읽지 않게."""
    import time as _t
    global _SIDE_NOTES
    # 다른 프로세스(예약 검사)가 DB를 바꿔도 알아채게 변경 최대 id를 키에 넣는다 — 검사 직후
    # 30초 동안 옛 분류가 보였다 (파일럿 모의 3차 ④)
    try:
        with State(db_path) as _st:
            _gen = _st.conn.execute("SELECT MAX(id) FROM changes").fetchone()[0]
    except Exception:
        _gen = None
    try:
        key = (str(Path(db_path).resolve()), _PATHS_GEN, _gen)   # 상대 경로 's.db'가 테스트마다 같아 섞였다
    except OSError:
        key = (str(db_path), _PATHS_GEN, _gen)
    if len(_SIDE_NOTES) > 2 and _SIDE_NOTES[2] == key and _t.time() - _SIDE_NOTES[0] < 30:
        return _SIDE_NOTES[1]
    try:
        with State(db_path) as st:
            m = st.side_notes()
    except Exception:
        m = {}
    _SIDE_NOTES = (_t.time(), m, key)     # DB·검사 세대별 캐시 — 다른 DB의 값을 돌려주지 않게
    return m


from watcher.brief import _QUIET_WORDS, is_quiet as _is_quiet  # noqa: E402  화면·메일 같은 규칙


def _quiet_project(name: str) -> bool:
    """임시·공용·아카이브 성격의 프로젝트인가 — cli의 규칙 하나를 화면도 쓴다 (검토21 파일럿 14)."""
    from watcher.cli import _QUIET_PROJECT
    return bool(_QUIET_PROJECT.search(name or ""))


def _fold_moves(rows: list[dict], notes: dict) -> tuple[list[dict], dict]:
    """같은 지문의 '삭제 + 추가'(이름·위치 변경)를 한 행으로 접는다 — 폴더 이름 하나 바꾼 날
    확인 8~16회가 되던 것 (2026-09-05 전체 검토). 돌려주는 값: (접은 행들, {추가 id: 삭제 id}).
    접힌 추가 행에는 r["moved_from"]이 붙고, 확인 칩은 두 건을 한 번에 확인한다."""
    removed_by_path: dict = {}
    for r in rows:
        if r["kind"] == "removed":
            removed_by_path.setdefault(r["path"], []).append(r)
    also: dict = {}
    hide: set = set()
    moved_prev: dict = {}          # 확인 기록이 여럿이라 같은 변경이 여러 행이면 모두 '이동'으로
    out = []
    for r in rows:
        note = notes.get(r["change_id"], "") or ""
        if r["kind"] == "added" and "이름·위치만 바뀜 — 이전: " in note:
            prev = note.split("이름·위치만 바뀜 — 이전: ", 1)[1].split(" (내용 동일")[0].strip()
            if r["change_id"] in moved_prev:
                r = dict(r)
                r["moved_from"] = moved_prev[r["change_id"]]
            else:
                cands = [x for x in removed_by_path.get(prev, [])
                         if x["snapshot_id"] == r["snapshot_id"] and x["change_id"] not in hide]
                if cands:
                    x = cands[0]
                    hide.add(x["change_id"])
                    also[r["change_id"]] = x["change_id"]
                    moved_prev[r["change_id"]] = prev
                    r = dict(r)
                    r["moved_from"] = prev
                    # 짝의 확인 상태 — 어느 쪽이든 확인됐으면 확인 (메일 링크는 추가 쪽만
                    # 확인하므로 '둘 다'를 요구하면 영원히 미확인이었다, 코드 검토)
                    r["ack_by"] = r["ack_by"] or x["ack_by"]
        out.append(r)
    return [r for r in out if r["change_id"] not in hide], also


def _side_chip(note: str) -> str:
    """목록에 붙는 작은 표시 — 복사본/빈 파일을 훑으면서 알아보게."""
    if not note:
        return ""
    label = ("복사본" if "복사본" in note else
             "빈 파일" if "빈 파일" in note else "참고")
    return (f' <span class="tag na" title="{_E(note)}" '
            f'style="font-size:12px;padding:1px 7px">{label}</span>')


def _rows_table(rows: list[dict], limit: int = 200,
                table_id: str | None = None, tok: str | None = None,
                notes: dict | None = None) -> str:
    notes = notes or {}
    rows, also = _fold_moves(rows, notes)
    for r in rows:
        if r["change_id"] in also:
            r["also_id"] = also[r["change_id"]]
    trs = "".join(
        f"<tr data-name=\"{_E((r['path'] + ' ' + (r['project'] or '')).lower())}\">"
        f"<td>#{r['change_id']}</td>"
        f"<td style='white-space:nowrap' title=\"검사 {_E(_local(r['detected_at']))}"
        f"{(' · 저장 ' + _E(_mtime_str(r.get('mtime')))) if r.get('mtime') else ''}\">"
        f"{_E(_local(r['detected_at'], '%m-%d %H:%M'))}"
        f"{('<br><span class=\"muted\" style=\"font-size:11px\">저장 ' + _E(_mtime_str(r.get('mtime'), '%m-%d %H:%M')) + '</span>') if r.get('mtime') else ''}</td>"
        f"<td>{_move_tag(r)}</td>"
        f"<td><span class=\"kindcell\">{_E(_cat_display(r['path']))}</span></td>"
        f"<td style='white-space:nowrap'>"
        f"<a href='/?p={quote(r['project'] or '미분류')}' "
        f"style='color:var(--link)'>{_E(r['project'] or '미분류')}</a></td>"
        f"<td title=\"{_E(r['path'])}\">"
        f"<a href='/change?id={r['change_id']}' style='color:var(--link)'>"
        f"{_path_html(r['path'])}</a>"
        f"{_side_chip(notes.get(r['change_id'], ''))}</td>"
        f"<td>{_ack_tag(r, tok)}</td>"
        + (_open_cell(r['path'], tok) if tok else "") + "</tr>"
        for r in rows[:limit])
    # 검색칸은 **화면에 그려진 줄만** 훑는다 — DB에 있는 줄을 넣어도 안 나와서,
    # 사람이 "없다"고 결론냈다 (2026-09-09 웹 검토 중간 6). 그 사실을 여기서 말한다
    more = (f'<p class="muted" style="margin-top:8px">외 {len(rows) - limit}건 생략 — '
            f'위 검색칸은 <b>화면에 나온 {limit}건</b>만 찾습니다. 전체에서 찾으려면 '
            f'[엑셀 내려받기]를 쓰거나 프로젝트·유형으로 먼저 좁혀주세요.</p>'
            if len(rows) > limit else "")
    tid = f' id="{table_id}"' if table_id else ""
    # 확인자 이름은 한 번만 — 브라우저가 기억한다 (2026-09-02)
    namebar = (f'<div class="ackbar muted">확인자 이름 '
               f'<input id="ackname" size="10" placeholder="예: 김대리" '
               f'value="{_E(_login_name())}" '
               f'title="목록에서 [미확인]을 누를 때 이 이름으로 기록됩니다"> '
               f'<span style="font-size:12px">— 적어두면 목록의 '
               f'[미확인]을 눌러 바로 확인됩니다</span></div>' if tok else "")
    return (namebar
            + f"<table{tid}><tr><th>번호</th><th>일시</th><th>구분</th><th>유형</th>"
            f"<th>프로젝트</th><th>파일</th><th>확인</th>"
            + ("<th></th>" if tok else "")
            + f"</tr>{trs}</table>{more}"
            if rows else '<p class="muted">해당 항목이 없습니다.</p>')


def _trend_chart(rows: list[dict], days: int = 14) -> str:
    today = date.today()
    span = [today - timedelta(days=i) for i in range(days - 1, -1, -1)]
    counts = Counter(_local_date(r["detected_at"]) for r in rows)
    mx = max([counts.get(d.isoformat(), 0) for d in span] + [1])
    cols = "".join(
        f'<div class="col"><i style="height:{max(4, round(counts.get(d.isoformat(), 0) / mx * 100))}%"'
        f' title="{d.isoformat()}: {counts.get(d.isoformat(), 0)}건"></i>'
        f"<b>{d.strftime('%d')}</b></div>"
        for d in span)
    return f'<div class="chart">{cols}</div>'


def _proj_of(r: dict) -> str:
    return r["project"] or "미분류"


def _filter_bar(base: str, projects: list[str], current: str | None,
                extra: str = "") -> str:
    """모든 화면 공용 프로젝트 선택 드롭다운. 선택 즉시 해당 프로젝트로 필터."""
    opts = f'<option value="">전체 프로젝트 ({len(projects)}개)</option>'
    for p in projects:
        sel = " selected" if p == current else ""
        opts += f'<option value="{_E(p)}"{sel}>{_E(p)}</option>'
    return (f'<div class="filterbar"><label>프로젝트</label>'
            f'<select class="projsel" onchange="location=\'{base}?{extra}p=\''
            f'+encodeURIComponent(this.value)">{opts}</select></div>')


# 배포 사이트의 버전 안내 파일 주소 — 사이트 개설 시 채운다 (2026-08-29).
# 형식: {"version": "0.28.0", "url": "다운로드 페이지", "notes": "한 줄 요약"}
# config update_url로 덮어쓸 수 있고, update_check: false로 확인 자체를 끌 수 있다.
UPDATE_URL = "https://drev.co.kr/version.json"   # 구 주소(gmlvy12.github.io)는 301로 여기로 온다
LAST_CHECK_FAILED = False        # 마지막 버전 확인이 통신 실패였나 (재시도 판단용)
# version.json에 portable 주소가 없을 때의 기본값 (자동 업데이트용)
PORTABLE_URL = ("https://github.com/gmlvy12/drev-site/releases/latest/"
                "download/Drev-Portable.zip")
EXE_URL = ("https://github.com/gmlvy12/drev-site/releases/latest/"
           "download/Drev.exe")


def check_update(cur_version: str, url: str) -> dict | None:
    """새 버전이 있으면 {version, url, notes}, 아니면 None. 실패도 None(조용).
    버전 숫자 파일 하나만 GET — 산출물·사용 정보는 아무것도 보내지 않는다 (원칙 1)."""
    global LAST_CHECK_FAILED
    if not url:
        return None
    import json as _json
    import time as _time
    import urllib.request as _rq
    # 사이트가 Cache-Control: max-age=600을 주므로 회사 프록시가 10분 넘게 옛 파일을
    # 돌려준다 — 매번 다른 주소로, 캐시 금지 헤더와 함께 (2026-09-02 "업데이트
    # 하라고 안 뜨네"). 회사 프록시는 느리다 — 5초는 짧았다
    sep = "&" if "?" in url else "?"
    req = _rq.Request(f"{url}{sep}t={int(_time.time())}",
                      headers={"Cache-Control": "no-cache", "Pragma": "no-cache",
                               "User-Agent": f"Drev/{cur_version}"})
    try:
        with _rq.urlopen(req, timeout=12) as r:
            info = _json.load(r)
        LAST_CHECK_FAILED = False
    except Exception:
        LAST_CHECK_FAILED = True          # 실패는 '새 버전 없음'과 다르다 — 곧 재시도
        return None

    def _t(v):
        return tuple(int(x) for x in str(v).split(".") if x.isdigit())

    try:
        if _t(info.get("version", "0")) > _t(cur_version):
            return {"version": str(info.get("version")),
                    "url": str(info.get("url", "")),
                    "portable": str(info.get("portable", "")),
                    "exe": str(info.get("exe", "")),
                    "app": str(info.get("app", "")),
                    "runtime": str(info.get("runtime", "")),
                    "notes": str(info.get("notes", ""))[:200],
                    # 지문 칸이 이상해도 새 버전 알림 자체는 살린다 (2026-09-02 재검토)
                    "sha256": (dict(info["sha256"])
                               if isinstance(info.get("sha256"), dict) else {})}
    except (TypeError, ValueError):
        return None
    return None


def _upd_busy() -> bool:
    """자동 업데이트가 진행 중인지 — 진행 중엔 화면을 자동 갱신한다."""
    from watcher import selfupdate as _su
    return _su.busy()


_EV_TAIL = re.compile(r"^(?P<body>.*)\s\((?P<where>[^()]*),\s*(?P<path>[^()]*)\)$")


def _root_key(path: str) -> str:
    """경로 키의 첫 마디 = 감시 폴더 이름 (cli가 루트 표시명으로 키를 만든다)."""
    return path.split("/", 1)[0] if path else ""


def _ev_parse(ev: str) -> dict:
    """근거 한 줄을 (제목 / 값 / 위치 / 파일)로 쪼갠다.

    근거는 `BOM: X-12 SPEC=SUS304 (행 5, .../BOM.xlsx)` 꼴로 만들어진다
    (consistency.py). 쪼개야 좌우로 나란히 놓고 비교할 수 있다."""
    head, sep, rest = ev.partition(": ")
    # 제목 상한 60: "P26-001-E-101 [Rev A, 2026-08-01]"처럼 Rev 스탬프가 붙으면
    # 30자를 넘겨 좌우 비교 카드가 사라졌다 (2026-09-02 재검토)
    if not sep or len(head) > 60:
        head, rest = "", ev
    m = _EV_TAIL.match(rest)
    if not m:
        return {"head": head, "value": rest, "where": "", "path": ""}
    return {"head": head, "value": m.group("body").strip(),
            "where": m.group("where").strip(), "path": m.group("path").strip()}


def _mark_diff(a: str, b: str) -> str:
    """a에서 b에 없는 낱말만 색으로 — 어디가 다른지 눈으로 찾지 않게."""
    other = set(b.split())
    out = []
    for tok in a.split():
        if tok and tok not in other:
            out.append('<span style="background:var(--tag-rm);color:var(--bad2);'
                       'border-radius:4px;padding:0 4px">' + _E(tok) + "</span>")
        else:
            out.append(_E(tok))
    return " ".join(out)


def _compare_cards(evs, links: dict) -> str:
    """근거가 '이쪽 vs 저쪽' 한 쌍이면 좌우로 나란히 놓는다 (2026-09-02).

    도면-BOM 불일치·도면 간 태그 불일치가 여기 해당한다. 줄글로 두 줄
    찍어두면 어디가 다른지 사람이 찾아야 한다. 한 쌍이 아니면 빈 문자열 —
    호출부가 기존 표로 넘어간다."""
    if len(evs) != 2:
        return ""
    a, b = _ev_parse(evs[0]), _ev_parse(evs[1])
    if not (a["path"] and b["path"] and a["head"] and b["head"]):
        return ""
    cells = ""
    for one, other in ((a, b), (b, a)):
        cid = links.get(one["path"])
        go = (f'<a class="btn gray" style="font-size:12px;padding:3px 9px;'
              f'margin-top:8px;display:inline-block" href="/change?id={cid}">'
              f'전/후 비교 보기</a>' if cid else "")
        cells += (
            f'<td style="width:50%;vertical-align:top;padding:10px 12px;'
            f'border:1px solid var(--border2);border-radius:10px">'
            f'<div class="muted" style="font-size:12px;margin-bottom:4px">'
            f'{_E(one["head"])}</div>'
            f'<div style="font-size:14px;line-height:1.6">'
            f'{_mark_diff(one["value"], other["value"])}</div>'
            f'<div class="muted" style="font-size:12px;margin-top:6px" '
            f'title="{_E(one["path"])}">{_E(one["where"])} · '
            f'{_E(one["path"].split("/")[-1])}</div>{go}</td>')
    return (f'<table style="width:100%;border-collapse:separate;'
            f'border-spacing:10px 0;margin:2px 0 8px"><tr>{cells}</tr></table>')


_LEAD_BRACKET = re.compile(r"^\s*\[[^\]]*\]\s*")
_HANGUL_AFTER = re.compile(r"(?<=[A-Za-z0-9])(?=[가-힣])")


def _tag_in_msg(msg: str) -> str | None:
    """검토 필요 문장에서 기기 태그 하나 — 묶음 키. 맨 앞 [프로젝트] 라벨은 태그가
    아니므로 떼고 보고, 태그 규칙은 추출기와 같은 것(TAG_RE, 회사 설정 반영)을 쓴다
    (2026-09-02 재검토: SW-100 같은 프로젝트명이 태그로 잡혀 전부 한 묶음이 됐고,
    3P-100 같은 태그는 못 잡아 뒤의 사양값 GMC-22를 태그로 삼았다)."""
    from watcher.extract.base import find_tags
    text = _LEAD_BRACKET.sub("", msg or "", count=1)
    # "M-101의"처럼 조사가 붙으면 태그 규칙의 낱말 경계가 안 잡힌다 — 한글 앞에 띄움
    text = _HANGUL_AFTER.sub(" ", text)
    tags = find_tags(text)
    return tags[0] if tags else None
_REV_DATE = re.compile(r"\[(?:Rev ([^,\]]+))?(?:, )?(\d{4}-\d{2}-\d{2})?\]")


def _older_side(items_) -> str:
    """검토 필요 묶음에서 '확인할 것' 한 줄 — 근거에 실린 Rev·날짜로 더 오래된 쪽을
    고른다. 날짜가 둘 다 있을 때만 말한다 (짐작하지 않는다, 원칙 4)."""
    seen = {}
    for i in items_:
        for ev in i.get("evidence") or []:
            d = _ev_parse(ev)
            m = _REV_DATE.search(d.get("head", "") + " " + d.get("value", ""))
            if d.get("path") and m and m.group(2):
                seen.setdefault(d["path"], (m.group(2), m.group(1) or ""))
    if len(seen) < 2:
        return ""
    oldest = min(seen.items(), key=lambda kv: kv[1][0])
    newest = max(seen.items(), key=lambda kv: kv[1][0])
    if oldest[1][0] == newest[1][0]:
        return ""
    name = oldest[0].split("/")[-1]
    rev = f"Rev {oldest[1][1]}, " if oldest[1][1] else ""
    return (f"{name} 갱신 여부 — {rev}{oldest[1][0]}로 가장 오래된 판 "
            f"(가장 최근 판은 {newest[0].split('/')[-1]}, {newest[1][0]})")


def _pick_canonical(names) -> str:
    """대표로 삼을 이름 — 프로젝트 번호 꼴(P26-001)을 우선한다.

    번호가 없으면 가장 짧은 이름. 사람이 화면에서 바꿀 수 있으므로 추천값일 뿐."""
    from watcher.project import PROJECT_NO_RE
    for n in names:
        if PROJECT_NO_RE.search(n or ""):
            return n
    return min(names, key=lambda n: (len(n), n)) if names else ""


def _port_owner_pid(port: int, netstat_text: str | None = None) -> int | None:
    """127.0.0.1:port를 LISTENING 중인 프로세스의 PID (netstat -ano). 모르면 None."""
    if netstat_text is None:
        if sys.platform != "win32":
            return None
        try:
            r = subprocess.run(["netstat", "-ano", "-p", "tcp"], capture_output=True, timeout=15,
                               creationflags=0x08000000)
            netstat_text = r.stdout.decode("mbcs", "replace")
        except Exception:
            return None
    for line in netstat_text.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0].upper() == "TCP" and parts[1].endswith(f":{port}") \
                and parts[3].upper() == "LISTENING":
            try:
                return int(parts[4])
            except ValueError:
                return None
    return None


def _is_drev_process(pid: int) -> bool:
    """그 PID가 Drev(또는 우리 파이썬)인지 — 엉뚱한 프로그램을 죽이지 않게."""
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                           capture_output=True, timeout=15, creationflags=0x08000000)
        name = r.stdout.decode("mbcs", "replace").split(",")[0].strip('"').lower()
    except Exception:
        return False
    return name in ("drev.exe", "python.exe", "pythonw.exe", "project-watcher.exe")


def _kill_pid(pid: int) -> None:
    """PID로만 끝낸다 (이미지 이름으로 죽이지 않는다) — 자손(CAD)까지."""
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True,
                       timeout=20, creationflags=0x08000000)


class WebApp:
    """라우팅과 데이터 조회. 핸들러 클래스에서 인스턴스 하나를 공유한다."""

    def __init__(self, config_path: str):
        self.config_path = config_path
        self._scan_lock = threading.Lock()
        self.scanning = False
        self._scan_started = None
        self.last_msg = ""
        self.update_info: dict | None = None   # 새 버전 정보 (없으면 None)
        global _APP_REF
        _APP_REF = self                        # 사이드바의 업데이트 자리가 여기를 본다
        self.port: int | None = None           # 이 인스턴스가 여는 포트
        self.others: list[dict] = []           # 함께 떠 있는 다른 판들
        self._others_at = 0.0                  # 마지막 탐지 시각
        self._update_at = 0.0                  # 마지막 새 버전 확인 시각
        self.first_check = threading.Event()   # 시작 후 첫 버전 확인이 끝났나 (첫 화면이 기다린다)
        global _PATHS_FN, _HINTS_FN            # 문서 유형 메뉴 생성용
        _PATHS_FN = self.watched_paths
        _HINTS_FN = self.doc_hints

    # ---- 다른 판 감지 (2026-08-31) -----------------------------------------
    # 구버전이 살아 있는 줄 모르고 새 판을 실행하면 화면이 섞여 "새 기능이
    # 사라졌다"로 보였다. 이제 새 판이 먼저 알아채고 정리 버튼을 준다.

    def probe_port(self, p: int, timeout: float = 1.0) -> str | None:
        """그 포트에 다른 판의 Drev가 있으면 버전, 없으면 None."""
        import re as _re
        import urllib.request as _u
        if self.port and p == self.port:
            return None
        base = f"http://127.0.0.1:{p}"
        try:                           # 새 판은 신원표(/version)가 있다
            with _NOPROXY.open(base + "/version", timeout=timeout) as r:
                txt = r.read(64).decode("utf-8", "replace").strip()
            if txt.startswith("Drev "):
                ver = txt.split(" ", 1)[1]
                return None if ver == __version__ else ver
            return None
        except Exception:
            pass
        try:                           # 옛 판은 화면에서 버전을 읽는다
            with _NOPROXY.open(base + "/", timeout=timeout) as r:
                body = r.read(60000).decode("utf-8", "replace")
        except Exception:
            return None
        if "Drev" in body or "Project Watcher" in body:
            m = _re.search(r"v(\d+\.\d+\.\d+)", body)
            return m.group(1) if m else "?"
        return None

    def scan_others(self) -> list[dict]:
        """127.0.0.1의 이웃 포트에서 돌고 있는 다른 Drev를 찾는다(빠른 실패)."""
        import time as _t
        found = [{"port": p, "version": v}
                 for p in range(8765, 8776)
                 if (v := self.probe_port(p)) is not None]
        self.others, self._others_at = found, _t.time()
        return found

    def refresh_others_async(self, max_age: float = 20.0) -> None:
        """화면을 열 때마다 가볍게 다시 확인 — 뒤늦게 뜬 옛 판도 잡는다."""
        import time as _t
        if _t.time() - self._others_at > max_age:
            self._others_at = _t.time()        # 중복 스레드 방지
            threading.Thread(target=self.scan_others, daemon=True).start()

    def quit_other(self, port: int) -> str:
        """다른 판에게 스스로 종료하라고 요청한다 (그 판의 /quit 사용).

        먼저 정상 종료를 부탁하고 몇 초 기다린다. 그래도 살아 있으면(옛 판이 CAD 변환에
        걸려 멈춤 등) 그 포트를 쥔 프로세스가 Drev일 때만 PID로 강제 종료한다 — 회사 PC에서
        "종료했다는데 계속 뜬다"(2026-09-04). 새 판은 미보고 스냅샷을 되돌리므로 강제 종료로
        변경이 유실되지 않는다."""
        import re as _re
        import urllib.parse as _up
        import urllib.request as _u
        port = int(port)
        base = f"http://127.0.0.1:{port}"
        try:
            with _NOPROXY.open(base + "/settings", timeout=2) as r:
                page = r.read(200000).decode("utf-8", "replace")
            m = _re.search(r'name="t" value="([0-9a-f]+)"', page)
            data = _up.urlencode({"t": m.group(1) if m else ""}).encode()
            try:
                _NOPROXY.open(base + "/quit", data=data, timeout=2).read(10)
            except Exception:
                pass               # 종료 응답 중 연결이 끊기는 건 정상
        except Exception as e:
            return f"이전 판을 종료하지 못했습니다: {e}"
        # 확인은 그 포트 하나만 — 전체 재탐색은 느려서 버튼이 멈춘 것처럼 보인다.
        # 정상 종료는 검사 마무리(스냅샷 롤백)에 몇 초 걸릴 수 있어 3초까지 기다린다
        import time as _t
        still = None
        for _ in range(6):
            _t.sleep(0.5)
            still = self.probe_port(port, timeout=1)
            if not still:
                break
        forced = False
        if still:
            pid = _port_owner_pid(port)
            # 자기 자신(같은 프로세스가 이웃 포트를 연 경우·테스트)은 절대 죽이지 않는다
            if pid and pid not in (os.getpid(), os.getppid()) and _is_drev_process(pid):
                _kill_pid(pid)
                forced = True
                for _ in range(6):
                    _t.sleep(0.5)
                    still = self.probe_port(port, timeout=1)
                    if not still:
                        break
        self.others = [o for o in self.others if o["port"] != port]
        if still:
            self.others.append({"port": port, "version": still})
            return ("이전 판이 아직 살아 있습니다 — 종료 요청에 응답하지 않습니다. 작업 관리자에서 "
                    "Drev를 끝내거나 PC를 다시 시작한 뒤 새 판을 실행해주세요.")
        if forced:
            return ("이전 판이 응답하지 않아 강제로 종료했습니다. 검사 중이었다면 다음 검사가 "
                    "같은 변경을 다시 감지합니다.")
        return "이전 판을 종료했습니다."

    def dup_banner(self) -> str:
        """옛 판이 함께 떠 있으면 띄우는 경고 — 첫 화면·대시보드 공용.

        첫 실행 화면에도 반드시 붙여야 한다: 옛 판이 남아 있는 상황이 정확히
        '새로 받아 처음 켜는 순간'이기 때문 (2026-08-31 실사고)."""
        self.refresh_others_async()

        def _num(v):
            return tuple(int(x) for x in str(v or "").split(".") if x.isdigit())

        out = ""
        for o in self.others:
            # 버전을 대조하지 않고 전부 '이전 판'이라 부르고 종료를 권했다 — 파일서버를
            # 둘로 나눠 일부러 두 판을 띄운 경우 서로를 죽이라고 권한다
            # (2026-09-09 웹 검토 낮음 10). 아는 만큼만 말한다
            them, mine = _num(o["version"]), _num(__version__)
            if them and mine and them < mine:
                what = f'<b>이전 판 Drev v{_E(o["version"])}</b>'
                why = ("두 개가 같이 떠 있으면 화면이 섞이고 프로그램 폴더도 "
                       "삭제되지 않습니다.")
                btn = "이전 판 종료"
            elif them and mine and them > mine:
                what = f'<b>더 새 판 Drev v{_E(o["version"])}</b>'
                why = ("이 창이 옛 판입니다 — 그쪽 창을 쓰세요. 아래 단추는 "
                       "저쪽(새 판) 창을 닫습니다. 이 창은 오른쪽 위 X로 닫으세요.")
                btn = "저쪽 창 종료"
            else:
                what = (f'<b>Drev{" v" + _E(o["version"]) if o["version"] else ""}</b>'
                        f' 하나가 더')
                why = ("같은 PC에서 둘을 같이 쓰면 검사가 서로를 기다리고 화면이 "
                       "섞입니다. 일부러 두 개를 쓰는 중이면 이 알림은 무시하세요.")
                btn = "저쪽 창 종료"
            out += (f'<div class="panel" style="border-left:4px solid var(--bad)">'
                    f'⚠ {what}가 함께 실행 중입니다 (포트 {o["port"]}). {why} '
                    f'<form class="inline" method="post" action="/other/quit">'
                    f'{self._tok()}<input type="hidden" name="port" value="{o["port"]}">'
                    f'<button class="btn red" style="font-size:12px;padding:4px 12px">'
                    f'{btn}</button></form> '
                    f'<span class="muted">지금 보고 계신 화면은 v{__version__}입니다'
                    f'</span></div>')
        return out

    def update_banner(self) -> str:
        """새 버전 안내 — 포터블판이면 버튼 하나로 자동 교체까지 (2026-08-31).

        수동 덮어쓰기는 윈도우 압축 풀기가 폴더를 겹쳐 만들고 두 번째 다운로드에
        "(1)"을 붙이는 탓에 실제로는 옛 판이 남는 사고로 이어졌다."""
        from watcher import selfupdate as _su
        pr = _su.PROGRESS
        if _su.busy():
            return (f'<div class="panel" style="border-left:4px solid var(--accent)">'
                    f'⬆ <b>업데이트 중</b> — {_E(pr.get("msg", ""))}'
                    f'<div class="bar" style="margin-top:8px"><i style="width:'
                    f'{int(pr.get("pct", 0))}%"></i></div>'
                    + ('<p style="margin-top:6px"><b>이 탭을 그대로 두고 기다려 주세요. '
                       '아무것도 누르지 마세요.</b></p>'
                       '<p class="muted" style="margin-top:4px">교체하는 몇 초 동안 화면이 잠깐 멈춘 것처럼 '
                       '보입니다. 새 판이 준비되면 이 탭이 저절로 새로고침됩니다(길어도 1분). '
                       '이력·설정은 그대로입니다. 혹시 "연결할 수 없음"이 뜨면 1분 뒤 새로고침(F5)을 '
                       '한 번만 눌러 주세요.</p>'
                       if browser_shell() else
                       '<p class="muted" style="margin-top:6px">교체 단계에서 창이 잠깐 닫혔다가 '
                       '새 판으로 다시 열립니다. 이력·설정은 그대로입니다.</p>')
                    + '</div>')
        err = ""
        if pr.get("error"):
            err = (f'<div class="panel" style="border-left:4px solid var(--bad)">'
                   f'⚠ {_E(pr["error"])} — 아래 [다운로드 페이지 열기]로 직접 '
                   f'받으셔도 됩니다.</div>')
        if not self.update_info:
            return err
        ui = self.update_info
        auto = ""
        if _su.portable_root() is not None or _su.installed_exe() is not None:
            # 사이드바와 이름·확인 절차를 맞춘다 — 같은 동작을 네 이름으로 부르고 있었고
            # 배너 쪽만 확인 없이 바로 교체를 시작했다 (2026-09-08 사용성 9차)
            _ask = ("지금 새 판으로 교체할까요?\\n\\n화면이 잠깐 끊겼다 저절로 돌아옵니다. "
                    "이력·설정은 그대로입니다.")
            auto = (f'<form class="inline" method="post" action="/update/apply" '
                    f'onsubmit="return confirm(&quot;{_ask}&quot;)">'
                    f'{self._tok()}<button class="btn" style="font-size:12px;'
                    f'padding:4px 12px">⬆ 새 버전 설치</button></form> ')
            howto = ('<p class="muted" style="margin-top:6px">[지금 업데이트]를 '
                     '누르면 프로그램이 새 판을 받아 <b>이 폴더를 그대로 교체</b>하고 '
                     '다시 시작합니다 — 압축을 풀거나 폴더를 옮기실 필요가 없고, '
                     '이력(state.db)·설정은 그대로 유지됩니다.</p>')
        else:
            howto = ('<p class="muted" style="margin-top:6px">받으신 뒤에는 '
                     '<b>이 프로그램을 먼저 닫고</b> 새 설치본을 실행(또는 기존 '
                     '폴더에 덮어쓰기)해 주세요. 이력(state.db)은 유지됩니다.</p>')
        return (err +
                f'<div class="panel" id="upd-banner" style="border-left:4px solid var(--accent)">'
                f'⬆ <b>새 버전 v{_E(ui["version"])}</b>가 나왔습니다'
                + (f' — {_E(ui["notes"])}' if ui.get("notes") else "")
                + f' {auto}'
                  f'<form class="inline" method="post" action="/update/open">'
                  f'{self._tok()}<button class="btn gray" style="font-size:12px;'
                  f'padding:4px 12px">다운로드 페이지 열기</button></form> '
                  f'<span class="muted">현재 v{__version__}</span>{howto}</div>')

    def scan_running_elsewhere(self) -> bool:
        """다른 프로세스(예약 검사)가 검사 잠금을 쥐고 있나."""
        try:
            if not self.db().exists():
                return False
            with State(self.db()) as st:
                pid = st.run_lock_holder()
            return pid is not None and pid != os.getpid()
        except BaseException:
            # load_config는 설정이 없으면 SystemExit을 낸다 — except Exception으로는
            # 안 잡혀 단추 한 번에 창이 죽었다 (2026-09-08 같은 사고를 사이드바에서 겪음).
            # 알 수 없으면 막지 않는다 — 업데이트를 영구히 못 하게 하면 더 나쁘다
            return False

    def start_update(self) -> str:
        """자동 업데이트 시작 (백그라운드). 상태는 배너로 보여준다."""
        from watcher import selfupdate as _su
        if _su.busy():
            return "이미 업데이트를 진행 중입니다."
        if self.scan_state() == "scanning":
            # 검사 중 교체·재시작은 스냅샷만 남기고 브리핑을 못 보내 그날 변경이
            # 유실됐다 (2026-09-04 검토 ops H2)
            return "검사가 진행 중입니다 — 검사가 끝난 뒤 다시 눌러주세요."
        # 위 검사는 **이 프로세스의 스레드**만 본다. 07:00 예약 검사는 별도
        # 프로세스(pythonw entry.py run)여서 그대로 통과했고, 아침에 출근해
        # [새 버전 설치]를 누르면 돌고 있던 그 검사가 보고 단계에서 죽어
        # 그날 브리핑이 한 통도 안 나갔다 (2026-09-09 자동 실행 검토 차단 1).
        # 잠금은 DB에 있으니 그것을 본다
        if self.scan_running_elsewhere():
            return ("자동 실행(예약) 검사가 진행 중입니다 — 끝난 뒤 다시 눌러주세요. "
                    "지금 교체하면 그날 브리핑이 나가지 못합니다.")
        ui = self.update_info or {}
        root = _su.portable_root()
        if root is not None:                     # 포터블: 폴더(또는 앱만) 교체
            target = _su.run_update
            sha = ui.get("sha256") or {}
            args = (root, ui.get("portable") or PORTABLE_URL,
                    ui.get("version", ""), True,
                    ui.get("app", ""), ui.get("runtime", ""),
                    sha.get("app", ""), sha.get("portable", ""))
        else:
            exe = _su.installed_exe()            # 설치판: 실행 파일 교체
            if exe is None:
                return ("이 실행 형태는 자동 교체를 지원하지 않습니다 — "
                        "다운로드 페이지에서 받아주세요.")
            exe_ver = str(ui.get("exe_version") or ui.get("version") or "")
            if exe_ver != str(ui.get("version") or ""):
                # 실행 검사를 못 한 판은 exe를 올리지 않고 지난 판을 가리킨다 — 그대로 받으면
                # 지문은 맞고 버전 대조에서 매번 실패한다 (검토19 운영 ②)
                return (f"이번 판(v{ui.get('version')})은 설치판용 실행 파일이 검사되지 않아 "
                        f"자동 교체를 제공하지 않습니다 — 다운로드 페이지에서 포터블판을 "
                        f"받아 쓰시거나 다음 판을 기다려 주세요.")
            target = _su.run_update_exe
            args = (exe, ui.get("exe") or EXE_URL, ui.get("version", ""), True,
                    (ui.get("sha256") or {}).get("exe", ""))
        threading.Thread(target=target, args=args, daemon=True).start()
        return "업데이트를 시작했습니다 — 잠시 후 프로그램이 다시 시작됩니다."

    def refresh_update_async(self, max_age: float = 900.0) -> None:
        """화면을 열 때 오래됐으면 조용히 다시 확인 — 앱을 며칠 켜두는 현장에서
        시작 시 1회만 확인하면 새 판이 나와도 모른다 (2026-08-31 사용자 지적)."""
        import time as _t
        if not self.cfg().get("update_check", True):
            return
        if _t.time() - self._update_at > max_age:
            self._update_at = _t.time()
            threading.Thread(target=self.refresh_update, daemon=True).start()

    def refresh_update(self) -> dict | None:
        cfg = self.cfg()
        url = cfg.get("update_url") or UPDATE_URL
        import time as _t
        from watcher.selfupdate import url_ok
        if url and not url_ok(url):
            # config의 update_url에 제한이 없어 평문 http·사내 경로도 받았다
            # (2026-09-09 업데이트 검토 중간 6). 버전 정보가 교체 주소를 정한다
            print(f"경고: update_url이 허용되지 않은 주소라 무시합니다: {url}",
                  file=sys.stderr)
            self.update_info = None
            self._update_at = _t.time()
            return None
        self.update_info = check_update(__version__, url)
        # 통신 실패였으면 2시간 뒤가 아니라 다음 화면에서 곧 다시 본다 —
        # 회사 프록시가 한 번 막으면 반나절 동안 알림이 안 떴다 (2026-09-02)
        self._update_at = 0.0 if LAST_CHECK_FAILED else _t.time()
        return self.update_info

    def save_alias(self, into: str, sources) -> str:
        """앞으로의 검사에서도 같은 프로젝트로 묶이게 별칭 사전에 적는다.

        이력만 합치면 다음 검사에서 또 갈린다 — 두 곳을 함께 손봐야 끝난다."""
        path = Path(self.cfg().get("aliases") or "aliases.yaml")
        try:
            with open(path, "rb") as f:
                data = yaml.safe_load(f) or {}
        except FileNotFoundError:
            data = {}
        except (OSError, yaml.YAMLError) as e:
            return f"별칭 사전을 읽지 못했습니다({e}) — 이력만 합쳤습니다."
        cur = [str(x) for x in (data.get(into) or [])]
        for n in sources:
            if n and n != into and n not in cur:
                cur.append(n)
        data[into] = cur
        try:
            with open(path, "w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, allow_unicode=True, sort_keys=True)
        except OSError as e:
            return f"별칭 사전을 저장하지 못했습니다({e}) — 이력만 합쳤습니다."
        return ""

    def remove_alias(self, into: str, sources) -> str:
        """합치기를 되돌릴 때 그때 적은 별칭 줄을 걷어낸다.

        이걸 남겨두면 다음 검사에서 그대로 다시 합쳐져, 되돌리기가 듣지 않는
        것처럼 보인다 (2026-09-02)."""
        path = Path(self.cfg().get("aliases") or "aliases.yaml")
        try:
            with open(path, "rb") as f:
                data = yaml.safe_load(f) or {}
        except FileNotFoundError:
            return ""
        except (OSError, yaml.YAMLError) as e:
            return f" (별칭 사전을 읽지 못했습니다: {e})"
        cur = [str(x) for x in (data.get(into) or [])]
        left = [x for x in cur if x not in set(sources)]
        if left == cur:
            return ""
        if left:
            data[into] = left
        else:
            data = {k: v for k, v in data.items() if k != into}
        try:
            with open(path, "w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, allow_unicode=True, sort_keys=True)
        except OSError as e:
            return f" (별칭 사전을 저장하지 못했습니다: {e})"
        return ""

    def save_ui_mode(self, mode: str) -> str:
        mode = "browser" if str(mode).strip().lower() == "browser" else "window"
        self._save_key("ui", mode)
        return ("다음 실행부터 기본 브라우저로 엽니다." if mode == "browser"
                else "다음 실행부터 자체 창으로 엽니다.")

    def pop_msg(self) -> str:
        """알림 메시지는 1회만 표시 — 다음 화면까지 남아 혼란 주던 문제 수정."""
        m, self.last_msg = self.last_msg, ""
        return m

    def last_scan(self) -> tuple[str | None, int]:
        """(마지막 검사 시각 ISO(UTC), 그때 파일 수). 검사 이력 없으면 (None, 0)."""
        if not self.db().exists():
            return None, 0
        with State(self.db()) as st:
            row = st.conn.execute(
                "SELECT id, run_at FROM snapshots ORDER BY id DESC LIMIT 1").fetchone()
            if not row:
                return None, 0
        # 타일과 같은 수(제외 폴더 제외) — 스냅샷 행을 그대로 세어 같은 화면 윗줄 "파일 135개
        # 확인" vs 타일 129로 어긋났다 (파일럿 모의 5차 ②)
        return row[1], self.file_count()

    def scan_trouble(self) -> dict | None:
        """직전 검사가 감시 폴더에 닿지 못했나 — cmd_run이 state.db에 남긴 기록."""
        import json

        from watcher.cli import SCAN_TROUBLE_KEY
        try:
            if not self.db().exists():
                return None
            with State(self.db()) as st:
                raw = st.get_meta(SCAN_TROUBLE_KEY)
            return json.loads(raw) if raw else None
        except Exception:
            return None

    def trouble_banner(self) -> str:
        """감시 폴더에 닿지 못한 사실을 **지속 배너**로. 한 번 스쳐 사라지는 문구로는
        자동 실행이 며칠 실패한 것을 아무도 몰랐다 (2026-09-09 웹 검토 차단 1)."""
        mail_html = self.mail_trouble_banner()
        tr = self.scan_trouble()
        if not tr or not tr.get("missing"):
            return mail_html
        paths = "".join(f"<li><code>{_E(str(m))}</code></li>" for m in tr["missing"])
        if tr.get("fatal"):
            head = ("⛔ <b>직전 검사가 아무 폴더도 열지 못해 그대로 끝났습니다</b> — "
                    "그 사이의 변경은 감지되지 않았습니다.")
        else:
            head = ("⚠ <b>직전 검사가 아래 감시 폴더를 열지 못했습니다</b> — "
                    "그 폴더의 기록은 이전 상태로 이월했고, 변경은 감지되지 않았습니다.")
        return mail_html + (
            f'<div class="panel" style="background:var(--note-warn);color:var(--warn2)">'
            f'{head}<ul style="margin:6px 0 4px">{paths}</ul>'
            f'<div class="muted">네트워크 드라이브라면 연결을, 지운 폴더라면 '
            f'<a href="/settings">설정</a>에서 목록을 고쳐주세요. 고친 뒤 '
            f'[▶ 지금 검사]가 한 번 성공하면 이 알림은 사라집니다.</div></div>')

    def mail_trouble_banner(self) -> str:
        """직전 검사의 메일 자동 발송이 실패했으면 지속 배너 — 전에는 stderr에만 남아 다음 날
        화면에 흔적이 없었다 (검토19 운영 ③). 다음 성공 발송에 사라진다."""
        import json

        from watcher.cli import MAIL_TROUBLE_KEY
        try:
            if not self.db().exists() or not (self.cfg().get("mail") or {}).get("enabled"):
                return ""
            with State(self.db()) as st:
                raw = st.get_meta(MAIL_TROUBLE_KEY)
            tr = json.loads(raw) if raw else None
        except Exception:
            return ""
        if not tr:
            return ""
        return (f'<div class="panel" style="background:var(--note-warn);color:var(--warn2)">'
                f'⚠ <b>직전 검사의 브리핑 메일 자동 발송이 실패했습니다</b> '
                f'({tr.get("count", 1)}통) — {_E(_plain_engine_error(str(tr.get("why") or "")))}'
                f'<div class="muted">브리핑과 .eml 초안은 저장됐습니다(브리핑 메뉴). '
                f'<a href="/settings#mail">설정 › 메일</a>에서 서버·비밀번호를 확인하고 '
                f'[시험 발송]을 눌러 보세요. 다음 발송이 성공하면 이 알림은 사라집니다.</div></div>')

    def scan_health(self) -> str:
        """대시보드용 '살아있음' 신호 — 마지막 검사 시각/파일 수, 25시간 넘으면 경고.
        조용한 것(변경 0건)과 멈춘 것(검사 자체가 안 돎)을 구분해준다 (2026-08-25 UX 검토)."""
        trouble = self.trouble_banner()
        run_at, n = self.last_scan()
        if run_at is None:
            return trouble
        try:
            hours = (datetime.now(timezone.utc)
                     - _parse_utc(run_at)).total_seconds() / 3600
        except ValueError:
            hours = 0
        # n은 '지금 감시 중'인 수(제외 폴더 제외) — "N개 확인"이라 쓰면 제외 직후~다음 검사 전엔
        # 그 검사가 실제로 훑은 수(134)와 다른 문장이 된다 (파일럿 모의 6차 관찰)
        line = f'마지막 검사: <b>{_local(run_at)}</b> · 지금 감시 중 파일 {n}개'
        # 사람이 마지막으로 확인·처리한 시각 — "마지막 검사"만 있어 '누가 언제 봤나'가 없었다
        # (2026-09-15 사용자: "최근 검토한 시간도 나타내주면")
        try:
            with State(self.db()) as st:
                rv = st.last_review()
        except Exception:
            rv = None
        line += (f' · 최근 확인: <b>{_E(_local(rv["at"]))}</b> {_E(rv["by"])}'
                 f'<span class="muted"> ({rv["what"]})</span>' if rv else
                 ' · <span class="muted">아직 아무도 확인하지 않았습니다</span>')
        if hours > 25 and trouble and "직전 검사가" in trouble:
            # 직전 검사가 돌았으나 폴더를 열지 못한 경우 — "검사가 N시간째 없습니다"와 모순된다
            # (검토21 파일럿 중간 9ⓒ). 그 사실은 위 ⛔ 배너가 이미 말한다
            return trouble + f'<div class="panel">{line}</div>'
        if hours > 25:
            return (trouble
                    + f'<div class="panel" style="background:var(--note-warn);color:var(--warn2)">'
                    f'⚠ {line} — <b>검사가 {int(hours)}시간째 없습니다.</b> '
                    f'매일 자동 실행이 멈췄을 수 있습니다 (PC가 꺼져 있었거나 '
                    f'로그오프 상태면 그날 검사는 건너뜁니다). '
                    f'[▶ 지금 검사]를 눌러 확인해보세요.</div>')
        return trouble + f'<div class="panel" style="color:var(--text3)">{line}</div>'

    # ------------------------------------------------------------ 데이터
    def cfg(self) -> dict:
        from watcher.cli import load_config
        c = load_config(Path(self.config_path))
        global _LAST_CFG          # 표시용 분류가 사용자 규칙을 쓰도록 (2026-08-31)
        _LAST_CFG = c
        return c

    def db(self) -> Path:
        return Path(self.cfg()["state_db"])

    def catch_up_missed_scan(self) -> bool:
        """오늘 예약 시각이 지났는데 오늘 검사가 없고 예약이 등록돼 있으면 지금 한 번 돌린다.
        돌렸으면 True. 감시 폴더가 없거나 이미 검사 중이면 아무것도 안 한다."""
        try:
            cfg = self.cfg()
            if not cfg.get("roots") or not cfg.get("catch_up_missed_scan", True):
                return False
            hhmm = str(cfg.get("schedule_time") or "07:00")
            hh, mm = (int(x) for x in hhmm.split(":")[:2])
            from datetime import time as _dtime
            now = datetime.now().astimezone()
            # (읽기 전용 가드가 '.replace(' 호출을 전부 막으므로 combine으로 만든다)
            due = datetime.combine(now.date(), _dtime(hh, mm)).astimezone()
            if now < due + timedelta(minutes=20):        # 예약 시각+20분 전이면 스케줄러 몫
                return False
            run_at, _n = self.last_scan()
            if run_at:
                if _parse_utc(run_at).astimezone() >= due:
                    return False                          # 오늘 예약분(또는 그 뒤 수동)이 이미 돌았다
            tr = self.scan_trouble()
            if tr and tr.get("fatal") and not all(Path(r).is_dir() for r in cfg["roots"]):
                try:
                    if _parse_utc(tr["at"]).astimezone() >= due:
                        return False      # 오늘 이미 '감시 폴더 없음'으로 끝난 검사가 있고 아직 안 닿는다 —
                except (KeyError, ValueError, TypeError):   # 창마다 '검사 못 함' 메일을 반복하지 않는다 (1회차 10).
                    pass                                    # 낮에 복구됐으면 보충한다 (2회차 A5)
            from watcher.cli import schedule_status
            if not schedule_status():
                return False                              # 예약이 없는 집은 사람이 누른다
            if self.scan_state() == "scanning" or self.scan_running_elsewhere():
                return False
            print(f"[scan] 오늘 {hhmm} 예약 검사가 돌지 못해 창에서 대신 검사합니다 "
                  f"(마지막 검사 {_local(run_at) if run_at else '없음'})", flush=True)
            self.last_msg = (f"오늘 {hhmm} 예약 검사가 돌지 못해(PC가 꺼져 있었거나 로그인 전) "
                             f"지금 대신 검사합니다.")
            self._catch_up_note = f"(오늘 {hhmm} 예약분을 대신한 검사)"   # 완료 문구에 덧붙인다 (3회차 B7)
            self.start_scan()
            return True
        except Exception as e:
            print(f"[scan] 놓친 예약 검사 보충 실패(무시): {e}", flush=True)
            return False

    def next_real_unacked(self, cid: int) -> int | None:
        """[확인하고 다음]의 다음 건 — 같은 검사분 먼저, 없으면 다른 검사분으로. 이동·재저장·복사본
        (그 밖의 알림)과 첫 등록은 건너뛴다 (검토25 화면 3-1·3-2). 후보 200건까지만 본다."""
        notes_h = _side_note_map(self.db())
        base_id = self.baseline_id()
        rows_, _ = _fold_moves(self.rows(), notes_h)
        by_id = {r["change_id"]: r for r in rows_}

        def _real(i: int) -> bool:
            r = by_id.get(i)
            if r is None or r.get("ack_by") or self.is_baseline_add(r, base_id):
                return False
            return not (r.get("moved_from") or _is_quiet(notes_h.get(i, "") or ""))
        with State(self.db()) as st:
            for same_run in (True, False):
                cur, seen = cid, 0
                while seen < 5000:                        # 이동 200장 넘는 폴더 이름 변경 뒤에도 (1회차 6)
                    nxt = st.next_unacked(cur, same_run=same_run)
                    if nxt is None or nxt == cid or nxt in {cur}:
                        break
                    if _real(nxt):
                        return nxt
                    cur, seen = nxt, seen + 1
        return None

    def _resolver(self, roots, paths=None):
        """검사와 같은 귀속기 — 검사가 배운 폴더 다수결 표(DB meta)까지 싣는다. 없으면 검사와
        화면이 같은 파일을 다른 프로젝트라 부른다 (검토22 실용 D1)."""
        from watcher.cli import _load_folder_votes, make_resolver
        r = make_resolver(self.cfg(), roots, paths)
        try:
            with State(self.db()) as st:
                r.folder_votes = _load_folder_votes(st)
        except Exception:
            pass
        return r

    def csrf(self) -> str:
        """폼 위조(CSRF) 방지 토큰 — 모든 대시보드 POST에 요구 (2026-08-25 리뷰).
        127.0.0.1 바인딩은 CSRF를 못 막는다: 요청이 사용자 브라우저에서 나간다."""
        if not getattr(self, "_csrf", None):
            with State(self.db()) as st:
                self._csrf = st.csrf_token()
        return self._csrf

    def _tok(self) -> str:
        """POST 폼에 심는 CSRF 토큰 hidden 필드."""
        return f'<input type="hidden" name="t" value="{self.csrf()}">'

    _paths_cache: tuple = (-1, 0.0, [], None)

    def _snapshot_gen(self):
        """최신 스냅샷 id — 07:00 배치(CLI)가 검사를 끝내도 이 프로세스의 invalidate_doc_nav()는
        불리지 않아, 열어둔 화면이 1분간 옛 수를 보여줬다 (파일럿 모의 5차 ④). 캐시 키에 넣는다."""
        try:
            if not self.db().exists():
                return None
            with State(self.db()) as st:
                return st.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()[0]
        except Exception:
            return None

    def doc_hints(self) -> dict:
        """검사 때 내용에서 읽어 둔 유형 단서 {경로: (유형, 근거)}."""
        try:
            if not self.db().exists():
                return {}
            with State(self.db()) as st:
                return st.hints()
        except Exception:
            return {}

    def watched_paths(self) -> list[str]:
        """지금 감시 중인 파일 경로 — 문서 유형 메뉴·현황에 쓴다 (최신 스냅샷).

        60초 캐시 — 대시보드 한 번에 폴더 제안·미확인 폴더가 각각 4만 경로를
        DB에서 다시 읽고 있었다 (2026-09-02). 검사가 끝나면 invalidate_doc_nav()가
        함께 비운다."""
        import time as _t
        gen, at, cached, snap = self._paths_cache
        if cached and gen == _PATHS_GEN and _t.time() - at < 60 \
                and snap == self._snapshot_gen():
            return cached
        try:
            if not self.db().exists():
                return []
            with State(self.db()) as st:
                out = list(st._latest_rows())   # {경로: (해시,크기,시각)} — 키가 경로
                snap = st.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()[0]
        except Exception:
            return []
        self._paths_cache = (_PATHS_GEN, _t.time(), out, snap)
        return out

    def _exclude_rules(self) -> dict:
        """라벨별 제외 규칙 — 검사(cmd_run)와 같은 해석."""
        try:
            from watcher.cli import _excludes_for, _root_labels
            cfg = self.cfg()
            roots = [Path(r) for r in cfg["roots"]]
            labels = _root_labels(roots)
            return {lb: _excludes_for(lb, labels, cfg.get("exclude") or []) for lb in labels}
        except Exception:
            return {}

    def present_paths(self) -> list[str]:
        """지금 감시 중인 파일 — 제외 폴더의 파일은 뺀다. 스냅샷에는 제외 직전 검사의 파일이
        남아 있어 타일·'파일 N개 확인'·유형 목록이 검사 로그와 어긋났다 (파일럿 모의 4·5차).
        화면에 수를 쓰는 곳은 모두 이것을 센다."""
        from watcher.scan import is_excluded
        ex_by = self._exclude_rules()
        paths = self.watched_paths()
        if not any(ex_by.values()):
            return list(paths)
        out = []
        for p in paths:
            lb, _, rel = p.partition("/")
            if ex_by.get(lb) and is_excluded(rel, ex_by[lb]):
                continue
            out.append(p)
        return out

    def rows(self) -> list[dict]:
        if not self.db().exists():
            return []
        with State(self.db()) as st:
            out = list(reversed(st.history()))  # 최신순
            first = st.first_snapshot_by_root()
            ext_base = st.ext_baseline()
        # history()는 changes LEFT JOIN acks라 **확인 1건당 행 1개** — 두 사람이 확인한 변경이 상세·유형·
        # 이력·프로젝트 목록에서 2건으로 세어졌다(대시보드만 접고 있었다). 화면이 보는 행은 여기서
        # **변경 단위 하나**로 접는다: 최신순이라 첫 행이 가장 최근 확인 (검토21 코드 §1-A)
        seen_ids: set = set()
        uniq = []
        for r in out:
            if r["change_id"] in seen_ids:
                continue
            seen_ids.add(r["change_id"])
            uniq.append(r)
        out = uniq
        # 별칭 사전(aliases.yaml)은 검사 때만 적용돼 화면엔 옛 이름(KD-2, KD-2호기 검사기)이 프로젝트
        # 둘로 남았다 (검토21 파일럿 중간 11) — 화면도 정규 이름으로 본다
        res = self._alias_resolver()
        if res is not None:
            for r in out:
                c = res.canonical(r["project"]) if r["project"] else None
                if c and c != r["project"]:
                    r["project"] = c
        # 기준선(감시 폴더의 첫 검사에서 생긴 '추가')은 실제 변경이 아니다 — 한 곳에서
        # 표시해 두고 모든 화면이 같은 규칙으로 센다 (2026-09-02: 대시보드 18/10/16/13/7
        # 불일치). 폴더 단위로 본다 — 나중에 추가한 감시 폴더의 첫 등록도 기준선이고,
        # 나중에 켠 확장자의 첫 등록도 그렇다 (2026-09-10 검토18)
        for r in out:
            r["baseline"] = State.is_first_registration(
                r["kind"], r["path"], r.get("snapshot_id"), first, ext_base)
        return out

    def _pre_tag(self, i: dict) -> str:
        """첫 검사(기준선)에서 잡힌 검토 필요 — 설치 전부터 있던 불일치다. 오늘 생긴 것처럼 읽혀
        첫날 '오늘 확인할 것'이 수천 건이 됐다 (검토21 설치 중간 7)."""
        try:
            if i.get("snapshot_id") is not None and i.get("snapshot_id") == self.baseline_id():
                return (' <span class="tag na" title="첫 검사에서 발견 — 설치 전부터 있던 상태">'
                        '설치 전부터</span>')
        except Exception:
            pass
        return ""

    def _alias_resolver(self):
        """aliases.yaml의 별칭 사전 — 파일 수정 시각으로 캐시."""
        try:
            p = Path(self.cfg().get("aliases") or "aliases.yaml")
            mt = p.stat().st_mtime if p.exists() else None
        except OSError:
            return None
        cached = getattr(self, "_alias_cache", None)
        if cached and cached[0] == (str(p), mt):
            return cached[1]
        res = None
        if mt is not None:
            try:
                from watcher.project import ProjectResolver
                res = ProjectResolver.load(p)
            except Exception:
                res = None
        self._alias_cache = ((str(p), mt), res)
        return res

    def baseline_id(self) -> int | None:
        """기준선(첫 검사) 스냅샷 id — 그때의 '추가' 대량 건은 미확인 집계에서 뺀다."""
        if not self.db().exists():
            return None
        with State(self.db()) as st:
            return st.first_snapshot_id()

    @staticmethod
    def is_baseline_add(r: dict, base_id: int | None) -> bool:
        if "baseline" in r:              # rows()가 폴더 단위로 판정해 둔 값이 기준
            return bool(r["baseline"])
        return base_id is not None and r["kind"] == "added" \
            and r.get("snapshot_id") == base_id

    def _ext_note(self) -> str:
        """카드 아래 한 줄 — 어떤 확장자를 지켜보는지 (그 밖의 파일은 세지 않는다)."""
        from watcher.scan import DEFAULT_EXTENSIONS
        exts = [str(e).lower().lstrip(".") for e in (self.cfg().get("extensions") or DEFAULT_EXTENSIONS)]
        shown = " ".join(exts[:6]) + (f" 외 {len(exts) - 6}종" if len(exts) > 6 else "")
        return f"감시 확장자: {shown} — 그 밖의 파일은 세지 않습니다 (설정에서 추가)"

    def file_count(self) -> int:
        """감시 중인 산출물 수 — 제외 폴더의 파일은 세지 않는다. 스냅샷에 남은 제외 파일까지
        세어 타일 135개 vs 검사 129개로 어긋났다 (파일럿 모의 4차)."""
        if not self.db().exists():
            return 0
        return len(self.present_paths())

    def issue_rows(self, project: str | None = None) -> list[dict]:
        if not self.db().exists():
            return []
        with State(self.db()) as st:
            return st.issues(project)

    # ------------------------------------------------------------ 동작
    def start_scan(self) -> None:
        def work():
            from watcher.cli import cmd_run
            args = argparse.Namespace(config=self.config_path, root=None,
                                      state_db=None, brief_dir=None, dry_run=False)
            # 창에서 누른 검사의 시작·끝·실패를 로그에 남긴다 — 전에는 실패가 화면에 한 번 스치는
            # 문구뿐이라, "검사 돌리다 그냥 멈췄다"(2026-09-14 실사용)를 로그로 되짚을 수 없었다
            _t0 = time.time()
            _cu = getattr(self, "_catch_up_note", "")
            print(f"[scan] {'놓친 예약 검사 보충' if _cu else '창에서 [지금 검사]'} · {time.strftime('%Y-%m-%d %H:%M:%S')}", flush=True)
            rc = None
            try:
                rc = cmd_run(args)
                self.last_msg = (
                    f"검사 완료 — 목록이 갱신되었습니다. {_cu}".strip() if rc == 0 else
                    "검사를 중단했습니다 — 변경은 유실되지 않으며 다음 검사가 "
                    "다시 감지합니다." if rc == 3 else
                    "다른 검사(자동 실행 또는 다른 창)가 이미 진행 중입니다 — 끝난 뒤 "
                    "다시 눌러주세요." if rc == 4 else
                    "검사 실패 — 콘솔/로그를 확인하세요. (변경은 유실되지 않음)")
            except BaseException as e:          # SystemExit·MemoryError까지 — 스레드가 조용히 죽지 않게
                import traceback
                self.last_msg = f"검사 실패: {e}"
                print(f"[scan] 실패: {type(e).__name__}: {e}", flush=True)
                traceback.print_exc()
                if not isinstance(e, Exception):
                    raise
            finally:
                print(f"[scan] 끝 rc={rc} · {time.time() - _t0:.1f}초 · {time.strftime('%H:%M:%S')}", flush=True)
                self._catch_up_note = ""
                self.scanning = False
                # 검사로 유형 구성이 바뀔 수 있다 — 메뉴 캐시를 즉시 비운다
                # (2026-09-01: 첫 검사 뒤에도 메뉴가 기본값에 머물러 인터락이
                #  보이지 않던 문제)
                invalidate_doc_nav()

        # 확인→시작을 한 락 안에서 — 동시 POST /scan 두 개가 같은 state.db에
        # cmd_run을 겹쳐 돌리는 것 방지 (2026-08-25 리뷰)
        with self._scan_lock:
            t = getattr(self, "_scan_thread", None)
            if self.scanning and t is not None and t.is_alive():
                return
            self.scanning = True
            self._scan_thread = threading.Thread(target=work, daemon=True)
            self._scan_thread.start()

    served = 0                     # 내준 화면 수 — 창이 정말 떴는지의 증거 (2026-09-07)

    def finish_before_exit(self, timeout: float = 30.0) -> None:
        """종료 직전: 검사가 돌고 있으면 멈춤을 요청하고 스냅샷 롤백까지 기다린다 —
        곧장 죽이면 스냅샷만 남고 브리핑이 안 나가 그날 변경이 영구 유실됐다
        (2026-09-04 검토 ops H2·core H1)."""
        if self.scan_state() != "scanning":
            return
        from watcher.cli import request_stop
        request_stop()
        t = getattr(self, "_scan_thread", None)
        if t is not None:
            t.join(timeout)

    def stop_scan(self) -> str:
        """돌고 있는 검사를 멈춘다 — 파일 하나를 마친 지점에서 협조적으로 (2026-09-02)."""
        from watcher.cli import request_stop
        if self.scan_state() != "scanning":
            return "지금 돌고 있는 검사가 없습니다."
        request_stop()
        return "멈추는 중 — 지금 보던 파일까지만 마치고 멈춥니다."

    def scan_state(self) -> str:
        """'idle' | 'scanning' | 'stale'.

        판정 기준은 경과 시간이 아니라 작업 스레드 생존 여부다 — 시간 기준(600초)은
        캡처 생성 등으로 오래 걸리는 정상 검사를 '죽었다'고 오판하고 플래그를 풀어
        동시 실행을 유발했다 (2026-08-25 리뷰). stale = 플래그는 켜져 있는데
        스레드가 죽어 있음 (비정상 종료)."""
        if not self.scanning:
            return "idle"
        t = getattr(self, "_scan_thread", None)
        if t is not None and t.is_alive():
            return "scanning"
        self.scanning = False
        self.last_msg = ("직전 검사가 비정상 종료된 것 같습니다. "
                         "다시 [지금 검사]를 눌러주세요.")
        return "stale"

    def _save_key(self, key: str, value) -> None:
        import yaml
        p = Path(self.config_path)
        with open(p, "rb") as f:
            data = yaml.safe_load(f) or {}
        data[key] = value
        if key == "roots":
            data.pop("root_path", None)  # 구버전 키와의 이중 진실 방지
        p.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False),
                     encoding="utf-8")

    def exclude_state(self, key: str) -> tuple[str, str]:
        """폴더 하나의 감시 상태 — WebApp에서 쓰는 겉면 (트리는 exclude_state_of를 직접 쓴다)."""
        from watcher.cli import _root_labels
        cfg = self.cfg()
        labels = _root_labels([Path(r) for r in cfg["roots"]])
        return exclude_state_of(key, labels, list(cfg.get("exclude") or []))

    def save_excludes(self, excludes: list[str]) -> None:
        self._save_key("exclude", excludes)

    def save_roots(self, roots: list[str]) -> None:
        self._save_key("roots", roots)

    def save_doc_types(self, rules: list[dict]) -> None:
        self._save_key("doc_types", rules)
        invalidate_doc_nav()          # 규칙이 바뀌면 메뉴도 즉시 다시 만든다

    def save_doc_folders(self, rules: list[dict]) -> None:
        self._save_key("doc_folders", rules)
        invalidate_doc_nav()

    # 이름만 봐도 감시 대상이 아닐 법한 폴더들 (제안일 뿐, 자동 제외는 하지 않는다)
    SKIP_HINTS = ("temp", "tmp", "임시", "개인", "personal", "backup", "백업",
                  "지난", "old", "구자료", "보관", "archive", "test", "테스트")

    def suggest_excludes(self, limit: int = 8) -> list[tuple[str, int]]:
        """감시에서 빼는 게 나을 법한 폴더 후보 — 이미 제외했거나 무시한 건 뺀다."""
        from collections import Counter
        cfg = self.cfg()
        ex = {e.strip("/") for e in (cfg.get("exclude") or [])}
        ignored = {e.strip("/") for e in (cfg.get("exclude_ignored") or [])}
        cnt: Counter = Counter()
        for p_ in self.watched_paths():
            d = p_.rpartition("/")[0] or "."      # pathlib보다 10배 빠르다
            # 제외 항목은 '라벨/경로'일 수도, 라벨 없는 공통 경로('임시')일 수도 있다 — 검사와
            # 같은 두 해석으로 본다. 라벨 붙은 것만 비교해 이미 뺀 폴더를 계속 권했다 (파일럿 모의 ⑤)
            d_nolabel = d.split("/", 1)[1] if "/" in d else ""
            if any(d == e or d.startswith(e + "/") or (d_nolabel and (d_nolabel == e or d_nolabel.startswith(e + "/")))
                   for e in ex | ignored):
                continue
            low = d.lower()
            if any(h in low for h in self.SKIP_HINTS):
                cnt[d] += 1
        return cnt.most_common(limit)

    def unconfirmed_folders(self, limit: int = 40) -> list[dict]:
        """자동 추정만 되어 있고 사람이 확인하지 않은 폴더 (파일 많은 순).

        자동 분류를 믿고 쓰되 **한 번은 사람이 훑어 확정**하게 하는 흐름
        (2026-09-01 요청: "자동 구분하면서 확인해주는 방법"). 확정하면 그 폴더는
        추정에 흔들리지 않고, 새 폴더가 생기면 다시 확인을 요청한다."""
        from collections import Counter
        from watcher.doctype import classify, folder_rules
        cfg = self.cfg()
        assigned = {f for f, _n in folder_rules(cfg)}
        later = set(cfg.get("doc_folders_later") or [])
        by_dir: dict[str, list] = {}
        for p_ in self.present_paths():      # 제외한 폴더는 확인을 청하지 않는다
            by_dir.setdefault(p_.rpartition("/")[0] or ".", []).append(p_)
        out = []
        for d, files in sorted(by_dir.items(), key=lambda x: -len(x[1])):
            if d in later or any(d == a or d.startswith(a + "/") for a in assigned):
                continue                      # 이미 확정했거나 미룬 폴더
            guesses: Counter = Counter()
            why_of: dict = {}
            for f in files:
                k, why = classify(f, cfg)
                guesses[k] += 1
                why_of.setdefault(k, why)
            kind, _n = guesses.most_common(1)[0]
            out.append({"folder": d, "count": len(files), "guess": kind,
                        "why": why_of.get(kind, ""), "mixed": len(guesses) > 1,
                        "samples": [PurePosixPath(f).name for f in files[:3]]})
            if len(out) >= limit:
                break
        return out

    def page_doctype_review(self) -> str:
        """문서 유형 확인 화면 — 자동 추정을 사람이 한 줄씩 확정한다."""
        items = self.unconfirmed_folders()
        if not items:
            body = (f'<div class="topbar"><h1>문서 유형 확인</h1></div>'
                    + _intro("자동 분류를 사람이 한 번 확인해 두는 화면입니다.")
                    + '<div class="panel"><p>확인할 폴더가 없습니다 — 모든 폴더의 '
                      '유형이 확정되어 있습니다. 새 폴더가 생기면 여기에 나타납니다.'
                      '</p><p class="muted" style="margin-top:6px">'
                      '<a href="/settings" style="color:var(--link)">설정</a>에서 '
                      '언제든 바꿀 수 있습니다.</p></div>')
            return _page("문서 유형 확인", "/doctype/review", body, self.pop_msg())
        rows = ""
        for it in items:
            rows += (
                f'<tr><td><code>{_E(it["folder"])}</code>'
                f'<div class="muted" style="font-size:12px;margin-top:3px">'
                f'{it["count"]}개 · {_E(", ".join(it["samples"]))}</div></td>'
                f'<td><span class="tag done">{_E(it["guess"])}</span>'
                f'<div class="muted" style="font-size:12px;margin-top:3px">'
                f'{_E(it["why"])}{" · 섞여 있음" if it["mixed"] else ""}</div></td>'
                f'<td style="width:340px">'
                f'<form class="inline" method="post" action="/doctype/confirm">'
                f'{self._tok()}'
                f'<input type="hidden" name="path" value="{_E(it["folder"])}">'
                f'<input type="hidden" name="name" value="{_E(it["guess"])}">'
                f'<button class="btn" style="font-size:12px;padding:4px 12px">'
                f'맞음</button></form> '
                f'<form class="inline" method="post" action="/doctype/confirm">'
                f'{self._tok()}'
                f'<input type="hidden" name="path" value="{_E(it["folder"])}">'
                f'<input type="text" name="name" placeholder="다른 이름" '
                f'style="width:110px;font-size:12px">'
                f'<button class="btn gray" style="font-size:12px;padding:4px 10px">'
                f'지정</button></form> '
                f'<form class="inline" method="post" action="/doctype/later">'
                f'{self._tok()}'
                f'<input type="hidden" name="path" value="{_E(it["folder"])}">'
                f'<button class="btn gray" style="font-size:12px;padding:4px 10px" '
                f'title="자동 추정 그대로 두고 목록에서 숨깁니다">나중에</button>'
                f'</form></td></tr>')
        body = (f'<div class="topbar"><h1>문서 유형 확인</h1>'
                f'<form class="inline" method="post" action="/doctype/confirm_all">'
                f'{self._tok()}<button class="btn">추정대로 전부 확정</button>'
                f'</form></div>'
                + _intro("자동으로 추정한 유형을 한 번만 확인해 두면, 이후로는 "
                         "파일명이 어떻든 그 폴더는 확정한 유형으로 분류됩니다.")
                + f'<div class="panel"><table>'
                f'<tr><th>폴더 (파일 수 · 예시)</th><th>자동 추정</th><th></th></tr>'
                f'{rows}</table>'
                f'<p class="muted" style="margin-top:10px">[맞음]은 추정값을 그대로 '
                f'확정합니다. 회사에서 다르게 부르면 오른쪽 칸에 그 이름을 적어 '
                f'[지정]하세요. 확정 내용은 [설정]에서 언제든 바꿀 수 있습니다.</p>'
                f'</div>')
        return _page("문서 유형 확인", "/doctype/review", body, self.pop_msg())

    def doctype_panel(self) -> str:
        """문서 유형 규칙 — 회사마다 양식·부르는 이름이 달라 사용자가 정한다.

        규칙만 주는 게 아니라 **지금 감시 중인 파일이 어떻게 분류됐는지**와
        **규칙에 안 걸린 파일**을 함께 보여준다 — 우리가 모르는 사내 양식을
        사용자가 발견해 규칙으로 만들 수 있게 (2026-08-31 요청)."""
        from watcher.doctype import UNKNOWN, summarize, user_rules
        cfg = self.cfg()
        rules = user_rules(cfg)
        rows = "".join(
            f'<tr><td><b>{_E(r["name"])}</b></td>'
            f'<td>{_E(", ".join(r["keywords"]) or "-")}</td>'
            f'<td>{_E(", ".join(r["exts"]) or "모든 형식")}</td>'
            f'<td style="width:80px"><form class="inline" method="post" '
            f'action="/doctype/del">{self._tok()}'
            f'<input type="hidden" name="name" value="{_E(r["name"])}">'
            f'<button class="btn gray">삭제</button></form></td></tr>'
            for r in rules) or ('<tr><td class="muted" colspan="4">내 규칙 없음 — '
                                '아래에서 추가하면 기본 규칙보다 먼저 적용됩니다'
                                '</td></tr>')
        # 제외한 폴더(서버/임시)가 "6개 자동: 도면"으로 남아 있던 것 (파일럿 모의 5차 ⑤)
        paths = self.present_paths()
        counts0, unknown = summarize(paths, cfg)
        # Drawing 6 · 도면 11이 따로 서던 집계 — 정규 이름으로 합친다 (2026-09-05 재검토)
        from watcher.doctype import canonical as _canon
        counts: dict = {}
        for k0, v0 in counts0.items():
            counts[_canon(k0)] = counts.get(_canon(k0), 0) + v0
        chips = " ".join(
            f'<span class="tag {"na" if k == UNKNOWN else "done"}" '
            f'style="margin:2px 3px">{_E(k)} {v}</span>'
            for k, v in sorted(counts.items(), key=lambda x: -x[1]))
        unk = ""
        if unknown:
            lis = "".join(
                f'<li style="margin:3px 0"><code>{_E(PurePosixPath(u).name)}</code>'
                f' <span class="muted">{_E(str(PurePosixPath(u).parent))}</span></li>'
                for u in unknown[:12])
            unk = (f'<details style="margin-top:10px"><summary style="cursor:pointer;'
                   f'color:var(--warn)">규칙에 안 걸린 파일 {len(unknown)}개 — '
                   f'어떤 양식인지 보고 규칙을 만들어 보세요</summary>'
                   f'<ul style="padding-left:18px;font-size:12.5px;margin-top:6px">'
                   f'{lis}</ul></details>')
        # 폴더로 구분 — 실무에서 가장 흔한 정리 방식 (2026-08-31 사용자)
        from collections import Counter as _C
        from watcher.doctype import folder_rules
        fr = dict(folder_rules(cfg))
        dircount = _C(str(PurePosixPath(x).parent) for x in paths)
        frows = ""
        for d, n in dircount.most_common(20):
            cur = fr.get(d, "")
            auto = "" if cur else _E(_canon(kind_of_dir(d, paths, cfg)))
            frows += (
                f'<tr><td><code>{_E(d)}</code> '
                f'<span class="muted">{n}개</span></td>'
                f'<td>{f"<b>{_E(cur)}</b>" if cur else f"<span class=muted>자동: {auto}</span>"}</td>'
                f'<td style="width:230px">'
                f'<form class="inline" method="post" action="/doctype/folder">'
                f'{self._tok()}<input type="hidden" name="path" value="{_E(d)}">'
                f'<input type="text" name="name" value="{_E(cur)}" '
                f'placeholder="이 폴더의 유형" style="width:130px;font-size:12px">'
                f'<button class="btn gray" style="font-size:12px;padding:3px 9px">'
                f'{"변경" if cur else "지정"}</button></form>'
                + (f'<form class="inline" method="post" action="/doctype/folder">'
                   f'{self._tok()}<input type="hidden" name="path" value="{_E(d)}">'
                   f'<input type="hidden" name="name" value="">'
                   f'<button class="btn gray" style="font-size:12px;padding:3px 9px">'
                   f'해제</button></form>' if cur else "")
                + '</td></tr>')
        folder_panel = (
            f'<div class="panel"><h2>폴더로 문서 유형 구분</h2>'
            f'<p class="muted" style="margin:0 0 10px">유형별로 폴더를 나눠 쓰신다면 '
            f'여기서 폴더에 이름을 붙이세요 — 그 폴더(하위 포함)의 파일은 모두 그 '
            f'유형이 됩니다. 파일명 추측보다 정확하고, 지정하지 않은 폴더는 '
            f'자동 추정으로 남습니다.</p>'
            f'<table><tr><th>폴더 (파일 수)</th><th>현재 유형</th><th></th></tr>'
            f'{frows or "<tr><td class=muted colspan=3>검사 후 폴더가 표시됩니다</td></tr>"}'
            f'</table></div>')
        return (folder_panel
                + f'<div class="panel"><h2>이름(키워드)으로 구분</h2>'
                f'<p class="muted" style="margin:0 0 10px">파일명(우선)과 폴더명에서 '
                f'키워드를 찾아 유형을 정합니다. 회사에서 부르는 이름 그대로 '
                f'만드세요 — 내 규칙이 기본 규칙보다 먼저 적용됩니다.</p>'
                f'<table><tr><th>유형</th><th>키워드</th><th>형식 제한</th><th></th></tr>'
                f'{rows}</table>'
                f'<form method="post" action="/doctype/add" style="margin-top:10px;'
                f'display:flex;gap:8px;flex-wrap:wrap">{self._tok()}'
                f'<input type="text" name="name" placeholder="유형 이름 (예: 작업지시서)" '
                f'style="min-width:170px" required>'
                f'<input type="text" name="keywords" style="flex:1;min-width:240px" '
                f'placeholder="키워드 쉼표로 (예: 작업지시, W/O, 지시서)" required>'
                f'<input type="text" name="exts" style="min-width:150px" '
                f'placeholder="형식 제한 (선택: xlsx, pdf)">'
                f'<button class="btn">규칙 추가</button></form>'
                f'<p style="margin-top:14px;font-size:13px">지금 감시 중인 파일 '
                f'{len(paths)}개의 분류: {chips or "<span class=muted>없음</span>"}</p>'
                f'{unk}</div>')

    def abs_path_of(self, key: str):
        """이력의 경로 키('라벨/상대경로') → 실제 파일 경로."""
        from watcher.cli import _root_labels
        cfg = self.cfg()
        roots = [Path(r) for r in cfg["roots"] if Path(r).is_dir()]
        for root, label in zip(roots, _root_labels(roots)):
            if key.startswith(label + "/"):
                rel = PurePosixPath(key[len(label) + 1:])
                # '라벨/../바깥/파일'로 감시 폴더 밖을 열거나 추출하던 것 (2026-09-04 검토
                # web H1) — 상위 이동 조각을 거부하고, 실제 경로가 폴더 안인지 확인한다
                if any(part in ("..", ".") for part in rel.parts) or rel.is_absolute():
                    return None
                p = root / rel
                try:
                    if not p.resolve().is_relative_to(root.resolve()) and not self._known_path(key):
                        return None            # 밖을 가리키는 링크라도 스캐너가 기록한 파일이면 연다 (리뷰13 중간-1: DFS)
                except (OSError, ValueError):
                    return None
                # 검사가 기록한 파일만 연다 — 루트 안이면 감시 확장자가 아니든(메모.txt) 제외 폴더든
                # 열어 주던 것 (검토21 웹 D). 화면의 [열기]는 언제나 이력의 경로 키에서 온다
                if p.is_file() and self._known_path(key):
                    return p
        return None

    def _known_path(self, key: str, as_dir: bool = False) -> bool:
        """최신 스냅샷에 있는 경로 키인가 — 정션·DFS 링크 아래 파일은 실경로가 감시 폴더 밖이지만
        스캐너가 '안쪽'으로 판정해 기록한 것이라 열기도 허용한다."""
        try:
            rows = self._tree_rows()
        except Exception:
            return False
        if as_dir:
            pfx = key.rstrip("/") + "/"
            return any(p.startswith(pfx) for p in rows)
        return key in rows

    def abs_dir_of(self, key: str):
        """폴더 키('라벨/상대경로' 또는 '라벨') → 감시 폴더 안의 실제 폴더 경로. 밖이면 None."""
        from watcher.cli import _root_labels
        cfg = self.cfg()
        roots = [Path(r) for r in cfg["roots"] if Path(r).is_dir()]
        key = (key or "").strip("/")
        for root, label in zip(roots, _root_labels(roots)):
            if key == label:
                return root
            if key.startswith(label + "/"):
                rel = PurePosixPath(key[len(label) + 1:])
                if any(part in ("..", ".") for part in rel.parts) or rel.is_absolute():
                    return None
                p = root / rel
                try:
                    if not p.resolve().is_relative_to(root.resolve()) and not self._known_path(key, as_dir=True):
                        return None
                except (OSError, ValueError):
                    return None
                if p.is_dir():
                    return p
        return None

    def save_mail(self, form: dict) -> None:
        cfg = self.cfg()
        old = cfg.get("mail") or {}
        get = lambda k: (form.get(k, [""])[0] or "").strip()  # noqa: E731
        try:  # 숫자가 아니면 500 대신 기존 값 유지 (2026-08-25 리뷰)
            port = int(get("smtp_port") or 25)
        except ValueError:
            port = old.get("smtp_port", 25)
        mail = {
            "enabled": form.get("enabled", [""])[0] == "on",
            "smtp_host": get("smtp_host"),
            "smtp_port": port,
            "starttls": form.get("starttls", [""])[0] == "on",
            "ssl": form.get("use_ssl", [""])[0] == "on",
            "sender": get("sender"),
            "recipients": [r.strip() for r in
                           get("recipients").split(",") if r.strip()],
        }
        if get("username"):
            mail["username"] = get("username")
            # 비밀번호 칸이 비어 있으면 기존 값 유지 (수정 화면에서 항상 다시 안 치게).
            # 평문으로 놓이지 않게 이 PC·계정만 풀 수 있는 DPAPI로 감싼다 (2026-09-05)
            from watcher.secret import protect
            mail["password"] = protect(get("password") or old.get("password", ""))
        self._save_key("mail", mail)
        if "ack_name" in form:
            self._save_key("ack_name", get("ack_name")[:40])
        if get("ack_url"):
            u = urlparse(get("ack_url"))
            try:
                # 화면은 127.0.0.1에만 열린다 — 다른 호스트를 적으면 브리핑의 확인 링크가 그 호스트로
                # 만들어져 수신자가 누르면 변경 번호·토큰이 밖으로 나간다 (검토21 원칙 낮음 5)
                ok = (u.scheme in ("http", "https") and bool(u.hostname) and (u.port or 8765) > 0
                      and u.hostname.lower() in ("127.0.0.1", "localhost", "::1"))
            except ValueError:                 # 포트가 숫자가 아님
                ok = False
            if ok:
                self._save_key("ack_url", get("ack_url"))
            else:
                # 잘못 저장되면 다음 실행부터 창이 안 떴다 (2026-09-04 검토 web M2)
                self.last_msg = ("확인 링크 주소가 올바른 형식이 아니라 저장하지 않았습니다 "
                                 "— 예: http://127.0.0.1:8765")

    def test_mail(self) -> str:
        """저장된 설정으로 테스트 메일 1통. 결과 메시지를 돌려준다."""
        from watcher import mail as mail_mod
        cfg = self.cfg()
        mc = dict(cfg.get("mail") or {})
        mc["enabled"] = True  # 켜기 전에도 시험할 수 있게
        if not mc.get("recipients"):
            return "테스트 실패: 수신자가 비어 있습니다."
        html_body = ("<html><body style='font-family:sans-serif'>"
                     "<h3>Drev 테스트 메일</h3>"
                     "<p>이 메일이 보이면 발송 설정이 정상입니다.</p></body></html>")
        try:
            ok = mail_mod.send_brief(mc, "[Drev] 테스트 메일", html_body)
        except Exception as e:
            return f"테스트 실패: {e}"
        return ("테스트 메일 발송 완료 — 수신함을 확인하세요: "
                + ", ".join(mc["recipients"])) if ok else "테스트 실패: 발송되지 않음"

    # ------------------------------------------------------------ 페이지
    def page_support(self, kind: str = "bug") -> str:
        """앱 안 의견 보내기 — 버그 신고·개선 제안·문의를 한 화면에서 (2026-08-31).

        메일 앱을 띄우는 방식은 거기서 포기하게 된다는 실사용 피드백을 반영해,
        보낼 수 있는 경로를 순서대로 시도한다: ①접수 서버 ②앱에 설정된 사내
        메일(SMTP) ③마지막 수단으로 메일 앱. 어느 쪽이든 실패하면 내용을 파일로
        남기고 화면에서 복사할 수 있게 한다 — 쓴 글이 사라지지 않도록."""
        kinds = (("bug", "🐞 버그 신고", "잘못 동작한 것"),
                 ("idea", "💡 개선 제안", "이랬으면 좋겠다"),
                 ("ask", "💬 문의", "궁금한 것"))
        kind = kind if kind in [k for k, _, _ in kinds] else "bug"
        tabs = "".join(
            f'<a href="/support?kind={k}" class="btn '
            f'{"" if k == kind else "gray"}" style="text-decoration:none;'
            f'margin-right:6px">{label}</a>' for k, label, _ in kinds)
        ph = {"bug": ("무엇을 하다가, 무엇이 일어났나요?\n\n"
                      "예) 설정에서 폴더를 추가하고 [지금 검사]를 눌렀더니 "
                      "화면이 '검사 중'에서 안 넘어갑니다."),
              "idea": ("어떤 점이 불편하고, 어떻게 되면 좋을까요?\n\n"
                       "예) 변경이 수백 건일 때 프로젝트별로 접어서 보고 싶습니다."),
              "ask": "궁금한 점을 적어주세요."}[kind]
        _m = self.cfg().get("mail") or {}
        can_send = bool(SUPPORT_FORM_URL) or bool(_m.get("smtp_host")
                                                  and _m.get("sender"))
        via = ("[보내기]를 누르면 그대로 접수됩니다 — 메일 앱은 열리지 않습니다."
               if can_send else
               "지금은 접수 창구가 설정되어 있지 않아, [보내기]를 누르면 내용을 "
               "파일로 저장하고 복사 버튼을 드립니다 (메일 앱도 함께 열어 봅니다).")
        logbox = ""
        if kind == "bug":
            logbox = ('<p style="margin-top:10px"><label class="muted" '
                      'style="font-size:12.5px"><input type="checkbox" name="log" '
                      'value="1" checked> 최근 진단 기록 함께 보내기 '
                      '(프로그램 시작·업데이트·오류 줄만 — 경로·파일 이름·프로젝트 번호·'
                      '인용 문구는 가리고, 도면 내용은 들어 있지 않습니다)</label></p>')
        body = (f'<div class="topbar"><h1>의견 보내기</h1></div>'
                + _intro("버그든 제안이든 한 줄이라도 좋습니다 — 실제로 읽고 "
                         "다음 판에 반영합니다.")
                + f'<div class="panel" style="max-width:680px">'
                f'<p style="margin-bottom:12px">{tabs}</p>'
                f'<form method="post" action="/support/send">{self._tok()}'
                f'<input type="hidden" name="kind" value="{kind}">'
                f'<p><textarea name="msg" required autofocus '
                f'placeholder="{_E(ph)}" style="width:100%;min-height:170px;'
                f'background:var(--panel);color:var(--text);border:1px solid '
                f'var(--border2);border-radius:8px;padding:10px 12px;'
                f'font-family:inherit;font-size:13.5px;line-height:1.6">'
                f'</textarea></p>{logbox}'
                f'<p style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">'
                f'<input type="text" name="who" placeholder="이름 / 회사 (선택)" '
                f'style="flex:1;min-width:180px">'
                f'<input type="text" name="reply" '
                f'placeholder="회신 받을 이메일 (선택)" style="flex:1;min-width:180px">'
                f'</p>'
                f'<button class="btn" style="margin-top:12px;padding:10px 22px">'
                f'보내기</button></form>'
                f'<p class="muted" style="margin-top:12px">{via}<br>'
                f'보내는 것은 위에 쓴 내용과 프로그램 버전(v{__version__})'
                f'{"·최근 진단 기록(시작·업데이트·오류 줄)" if kind == "bug" else ""}'
                f'뿐입니다 — 진단 기록의 경로·파일 이름·프로젝트 번호는 가리며, 검사 결과·도면·BOM 내용은 보내지 않습니다.'
                f'</p></div>')
        return _page("의견 보내기", "/support", body, self.pop_msg())

    def save_feedback(self, subject: str, body: str) -> str:
        """보낸 내용을 파일로 남긴다 — 전송이 실패해도 쓴 글이 사라지지 않게."""
        base = (Path(sys.executable).parent if getattr(sys, "frozen", False)
                else Path.cwd())
        d = base / "feedback"
        d.mkdir(exist_ok=True)
        from datetime import datetime
        name = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        (d / name).write_text(subject + "\n\n" + body, encoding="utf-8")
        return f"feedback/{name}"

    def send_feedback_mail(self, subject: str, body: str) -> bool:
        """앱에 설정된 사내 메일(SMTP)로 바로 보낸다 — 메일 앱을 열지 않는다.

        브리핑용 SMTP 설정을 그대로 쓰되 수신자는 지원 주소 하나로 바꾼다."""
        m = dict(self.cfg().get("mail") or {})
        if not (m.get("smtp_host") and m.get("sender")):
            return False
        m["enabled"] = True
        m["recipients"] = [SUPPORT_MAIL]
        from watcher.mail import send_brief
        html = ("<html><body><pre style=\"font-family:inherit;"
                "white-space:pre-wrap\">" + _E(body) + "</pre></body></html>")
        return bool(send_brief(m, subject, html))

    def install_panel(self) -> str:
        """[이 PC에 설치] — 포터블을 설치된 프로그램처럼 만든다 (2026-08-31).

        설치판 exe는 서명이 없어 일부 PC(스마트 앱 컨트롤)에서 막히지만, 이
        방식은 서명된 파이썬으로 돌아 어디서든 된다."""
        from watcher import install as _ins
        from watcher import selfupdate as _su
        root = _su.portable_root()
        if root is None:
            return ""                     # 설치판·개발 실행은 대상 아님
        if (root / "unins000.exe").exists():
            # Inno 설치판은 제거 목록에 자기 항목({GUID}_is1)이 있다 — 여기서 또 등록하면
            # '앱 및 기능'에 Drev가 둘 (검토19 운영 ⑨)
            return ""
        target = _ins.default_target()
        here = _ins.is_installed_at(root, target)
        if here:
            return (f'<div class="panel"><h2>설치 상태</h2>'
                    f'<p style="margin-bottom:8px">이 PC에 설치되어 있습니다 — '
                    f'<code>{_E(str(target))}</code></p>'
                    f'<form class="inline" method="post" action="/install/run">'
                    f'{self._tok()}<button class="btn gray">바로가기 다시 만들기'
                    f'</button></form> '
                    f'<form class="inline" method="post" action="/install/undo" onsubmit="return confirm(&quot;바로가기와 프로그램 목록 등록을 정리합니다. 이력·설정은 남습니다. 계속할까요?&quot;)">'
                    f'{self._tok()}<button class="btn gray">등록 해제</button></form>'
                    f'<p class="muted" style="margin-top:6px">등록 해제는 '
                    f'바로가기와 제거 목록만 정리합니다 — <b>이력·설정은 그대로 '
                    f'남습니다</b>(완전히 지우려면 위 폴더를 삭제하세요).</p></div>')
        return (f'<div class="panel" style="border-left:4px solid var(--accent)">'
                f'<h2>이 PC에 설치</h2>'
                f'<p style="margin-bottom:8px">지금은 <code>{_E(str(root))}</code>'
                f'에서 실행 중입니다. 설치하면 <code>{_E(str(target))}</code>로 '
                f'옮기고 <b>시작 메뉴·바탕화면 아이콘</b>을 만들며 '
                f'<b>프로그램 목록</b>에 등록합니다.</p>'
                f'<form class="inline" method="post" action="/install/run">'
                f'{self._tok()}<button class="btn">이 PC에 설치</button></form>'
                f'<p class="muted" style="margin-top:6px">설정·이력은 그대로 '
                f'따라갑니다. 설치 후 프로그램이 새 위치에서 다시 열리며, '
                f'원래 폴더(내려받은 압축 푼 자리)는 지우셔도 됩니다.</p></div>')

    def recent_log(self, lines: int = 20) -> str:
        """오류 기록 최근 몇 줄 — 버그 신고에 붙인다. 파일 경로는 지운다."""
        import re as _re
        try:
            base = (Path(sys.executable).parent if getattr(sys, "frozen", False)
                    else Path.cwd())
            lg = base / "watcher.log"
            if not lg.exists():
                return ""
            from watcher.logfile import tail_lines
            txt = tail_lines(lg, 400)      # 통째로 읽으면 52MB에서 232MB를 썼다
        except OSError:
            return ""
        # 창 모드에서는 검사 출력 전체가 watcher.log에 쌓인다 — '[수정] 경로',
        # '키: 구값 -> 신값' 같은 줄은 감시 데이터다. 진단 줄(시작·업데이트·오류·
        # 경고·예외)만 허용 목록으로 고른다 (2026-09-02 전체 검토: PRINCIPLE 1)
        allow = ("[start]", "[update]", "오류", "경고", "Traceback", "File ",
                 "사유:", "검사 실패", "검사를 중단")
        exc_line = _re.compile(r"^[A-Za-z_][\w.]*(Error|Exception|Warning)\b")
        # 어떤 줄이든 경로·파일명 토큰은 가린다 — '경고: 추출 실패 <감시 경로>'처럼
        # 허용 접두 뒤에 감시 데이터가 실리는 줄이 있다 (2026-09-02 재검토)
        path_tok = _re.compile(r"\S*[\\/]\S*")
        # 확장자 고정 목록(pdf|dxf|…)만 가려 SECRET_PLC_MAIN.gxw·현장사진.png가 그대로 나갔다
        # (검토21 원칙 중간 1) — 확장자 모양이면 전부, 프로젝트 번호·따옴표 안 문구도 가린다
        file_tok = _re.compile(r"\S+\.[A-Za-z0-9]{1,8}\b")
        proj_tok = _re.compile(r"\b[A-Za-z]{0,3}\d{2}-\d{3}[A-Za-z0-9_-]*\b")
        quoted = _re.compile(r"['\"“”‘’][^'\"“”‘’]{1,80}['\"“”‘’]")
        out = []
        for ln in reversed(txt[-400:]):
            st = ln.strip()
            if not st or not (st.startswith(allow) or exc_line.match(st)):
                continue
            st = path_tok.sub("(경로 가림)", st)
            st = file_tok.sub("(파일 가림)", st)
            st = proj_tok.sub("(프로젝트 가림)", st)
            st = quoted.sub("(인용 가림)", st)
            out.append(st[:200])
            if len(out) >= lines:
                break
        return "\n".join(reversed(out))

    # ── 폴더 구조 (탐색기 모양, 2026-09-04) ────────────────────────────────────
    _ICO_FOLDER = ('<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">'
                   '<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" '
                   'fill="#f3c04b" stroke="#c99a1e" stroke-width="1"/></svg>')
    _ICO_FILE = ('<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">'
                 '<path d="M6 2h8l5 5v15H6z" fill="#e8ecf3" stroke="#8a93a6" stroke-width="1"/>'
                 '<path d="M14 2v5h5" fill="none" stroke="#8a93a6" stroke-width="1"/></svg>')

    def _tree_rows(self):
        """최신 스냅샷 {경로: (해시, 크기, 수정시각)} — 파일 목록·트리 공용.
        60초 캐시: 폴더마다 4만 행을 다시 읽어 서랍 한 번에 40초가 걸렸다 (재검토 H2)."""
        import time as _t
        cached = getattr(self, "_tree_rows_cache", None)
        if cached and cached[0] == _PATHS_GEN and _t.time() - cached[1] < 60:
            return cached[2]
        if not self.db().exists():
            return {}
        with State(self.db()) as st:
            rows = st._latest_rows()
        # 제외한 폴더의 파일도 남긴다 — 트리는 뺀 폴더를 램프로 보여 주고 되살리는 자리다. 수를 셀 때만
        # 제외분을 빼 타일과 맞춘다 (검토21 웹 차단 B, 재검증 W2)
        self._tree_rows_cache = (_PATHS_GEN, _t.time(), rows)
        return rows

    def _watch_switch(self, key: str, state: str, by: str,
                      inline: bool = False) -> str:
        """이 폴더를 감시에서 빼거나 다시 넣는 단추 (2026-09-07 사용자 요청).
        상위 폴더 때문에 빠진 폴더는 그 상위 항목을 풀어야 하므로, 무엇을 풀지 이름으로 밝힌다."""
        back = "/tree?sel=" + quote(key)     # 누른 뒤 그 폴더로 돌아온다 (7차 중간-F)
        # 서랍에서는 화면을 넘기지 않고 그 자리에서 (2026-09-10 "최대한 편하고 쉽게")
        act = ' onsubmit="return pwTreeAct(this,event)"' if inline else ""
        # 서랍 요청은 303 대신 결과 문구를 돌려받는다 — 전에는 fetch가 303을 따라가
        # 돌아갈 화면 전체를 받아 버려 "뺐습니다"도 "그런 폴더가 없어 등록하지
        # 않았습니다"도 사람에게 한 번도 보이지 않았다 (검토18 웹 ③)
        ajax = '<input type="hidden" name="ajax" value="1">' if inline else ""
        if state == "root":
            return ('<div class="muted" style="margin:6px 0 2px;font-size:12px">'
                    '이 폴더가 <b>감시 폴더</b>입니다 — 여기서는 뺄 수 없습니다. '
                    '아예 감시를 그만두려면 <a href="/settings#roots" style="color:var(--link)">'
                    '설정 › 감시 폴더</a>에서 지우세요. 아래 하위 폴더는 하나씩 뺄 수 있습니다.</div>')
        if state == "watched":
            # 확인 대화상자는 두지 않는다 — 램프로 상태가 보이고 되돌리기가 한 번이다 (2026-09-07)
            return (f'<form method="post" action="/exclude/add" class="inline"{act} style="margin:10px 0 2px">'
                    f'{self._tok()}{ajax}'
                    f'<input type="hidden" name="path" value="{_E(key)}">'
                    f'<input type="hidden" name="back" value="{back}">'
                    f'<button class="btn gray">이 폴더를 감시에서 빼기</button>'
                    f'<span class="muted" style="font-size:12px;margin-left:8px">'
                    f'다음 검사부터 적용됩니다 — 파일은 그대로 둡니다.</span></form>')
        if state == "direct":
            return (f'<form method="post" action="/exclude/del" class="inline"{act} style="margin:10px 0 2px">'
                    f'{self._tok()}{ajax}'
                    f'<input type="hidden" name="path" value="{_E(by)}">'
                    f'<input type="hidden" name="back" value="{back}">'
                    f'<button class="btn">이 폴더를 다시 감시하기</button>'
                    f'<span class="muted" style="font-size:12px;margin-left:8px">'
                    f'지금은 감시에서 빠져 있습니다.</span></form>')
        # 경로를 단추 안에 넣으면 긴 한글 경로에서 화면 밖으로 나갔다 (7차 중간-E)
        return (f'<form method="post" action="/exclude/del"{act} style="margin:10px 0 2px">'
                f'{self._tok()}{ajax}'
                f'<input type="hidden" name="path" value="{_E(by)}">'
                f'<input type="hidden" name="back" value="{back}">'
                f'<div class="muted" style="font-size:12px;margin-bottom:4px">'
                f'이 폴더는 상위 폴더가 빠져 함께 빠졌습니다 — 되돌리려면 그 항목을 풀어야 합니다: '
                f'<b style="word-break:break-all">{_E(by)}</b></div>'
                f'<button class="btn">상위 폴더를 다시 감시하기</button></form>')

    def _lamp(self, state: str) -> str:
        cls, tip = _LAMP[state]
        return f'<span class="lamp {cls}" title="{tip}"></span>'

    def tree_files(self, key: str, full: bool = False, drawer: bool = False) -> str:
        """폴더 하나의 내용 조각 — 바로 아래 하위 폴더(파일 수)와 파일(크기·수정 시각).
        트리에서 폴더를 펼치거나 고를 때만 받아온다 (2026-09-04 요청 "파일들도 뭐가 있는지").
        full=True면 전체 화면 오른쪽 패널용(머리글: 경로·프로젝트 귀속)."""
        key = (key or "").strip("/")
        if not key:
            return '<p class="muted">폴더를 고르면 내용이 여기 보입니다.</p>'
        rows = self._tree_rows()
        pfx = key + "/"
        files, subs = [], {}
        # 감시 중인 폴더의 수에는 제외된 파일을 넣지 않는다 — 뺀 폴더 자체를 열었을 때는 그 안을 다 보여 준다
        # (재검증 W2: 루트 "파일 135개" vs 타일 130)
        key_watched = self.exclude_state(key)[0] in ("watched", "root")   # 루트도 감시 중 (재검증 2차 W2)
        present = set(self.present_paths()) if key_watched else None
        for p, v in rows.items():
            if not p.startswith(pfx):
                continue
            if present is not None and p not in present:
                continue
            rest = p[len(pfx):]
            if "/" in rest:
                d = rest.split("/", 1)[0]
                subs[d] = subs.get(d, 0) + 1
            else:
                files.append((rest, v))
        files.sort(key=lambda x: x[0].lower())

        def _sz(n: int) -> str:
            return f"{n / 1048576:.1f}MB" if n >= 1048576 else f"{max(1, n // 1024)}KB"
        out = ""
        state, by = self.exclude_state(key)
        if drawer and not full:
            # 서랍(오른쪽 슬라이드)에서도 여기서 바로 뺄 수 있어야 한다 — 폴더를 보다가
            # "이건 빼야겠다" 싶은 순간이 바로 서랍을 열었을 때인데, 전에는 배지만
            # 보이고 되돌릴 방법이 없어 [폴더 구조] 화면으로 가야 했다
            # (2026-09-10 사용자: "오른쪽 폴더 열었을때 검사 제외 등 기능은 어디있어?")
            # 서랍에서는 그 자리에서 처리한다 — 화면이 넘어가면 보던 자리를 잃는다.
            # `drawer` 표식이 없으면 넣지 않는다 — 같은 조각을 [폴더 구조] 전체 화면의
            # 왼쪽 트리도 받는데, 거기 끼어든 서랍용 단추는 누르면 "적용 중…"에서
            # 영영 멈췄다 (검토18 웹 ①)
            out += (f'<div class="watch-in-drawer">'
                    f'{self._watch_switch(key, state, by, inline=True)}</div>')
        if full:
            from watcher.cli import _root_labels, make_resolver
            cfg = self.cfg()
            roots = [Path(r) for r in cfg["roots"]]
            resolver = self._resolver(roots, list(rows))
            proj, why = resolver.attribute(key + "/_", None)
            crumbs = " › ".join(_E(x) for x in key.split("/"))
            # 토큰을 머리글에도 싣는다 — 감시 대상 파일이 없는 폴더는 아래 목록(.tree-list)이 통째로
            # 없어 [탐색기에서 열기]가 빈 토큰을 보내고 403 → "새로고침하라"는 토스트만 떴다 (2026-09-07)
            out += (f'<div class="tree-crumbs" data-tok="{self.csrf()}">'
                    f'{self._lamp(state)}{self._ICO_FOLDER}<b>{crumbs}</b> '
                    f'<button type="button" class="act" onclick="pwOpen(event,{_js(key)},\'dir\')" '
                    f'title="Windows 탐색기에서 이 폴더 열기 — 파일을 옮기거나 지우는 일은 여기서 하세요">탐색기에서 열기</button></div>'
                    + self._watch_switch(key, state, by)
                    + f'<div class="muted" style="font-size:12px;margin:2px 0 10px">'
                    f'파일 {len(files) + sum(subs.values())}개 (바로 아래 {len(files)}) · 하위 폴더 {len(subs)}개'
                    + (f' · 프로젝트 <b>{_E(proj)}</b> <span class="muted">({_E(why)})</span>'
                       if proj and why != "미분류" else "") + "</div>")
        if not files and not subs:
            return out + '<p class="muted">이 폴더에는 감시 대상 파일이 없습니다.</p>'
        li = ""
        from watcher.cli import _root_labels as _rl
        _cfg = self.cfg()
        _labels = _rl([Path(r) for r in _cfg["roots"]])
        _raw = list(_cfg.get("exclude") or [])
        for d, n in sorted(subs.items(), key=lambda kv: kv[0].lower()):
            dk = key + "/" + d
            # 하위 폴더마다 설정을 다시 읽으면 400개에 0.2초가 든다 (2026-09-07 운영 검토 낮음)
            dstate = exclude_state_of(dk, _labels, _raw)[0]
            li += (f'<div class="file{" excl" if dstate != "watched" else ""}" data-key="{_E(dk)}" '
                   f'ondblclick="pwTreeGo(this)" '
                   f'title="더블클릭하면 이 폴더로">{self._lamp(dstate)}{self._ICO_FOLDER}<span class="nm">{_E(d)}</span>'
                   f'<span class="meta">파일 {n}</span>'
                   f'<button type="button" class="act" onclick="pwOpen(event,{_js(dk)},\'dir\')" '
                   f'title="Windows 탐색기에서 이 폴더 열기 — 옮기거나 지우는 일은 탐색기에서">탐색기</button></div>')
        for name, v in files:
            fk = key + "/" + name
            # 파일 하나만 뺀 경우도 보이게 — 취소선 CSS는 있었는데 붙이는 곳이 없었다 (7차 중간-J)
            fstate = exclude_state_of(fk, _labels, _raw)[0]
            fmark = ('<span class="bd na">제외</span>' if fstate == "direct"
                     else '<span class="bd na">상위 제외</span>' if fstate == "inherited" else "")
            li += (f'<div class="file{" excl" if fstate in ("direct", "inherited") else ""}" '
                   f'data-open="{_E(fk)}" ondblclick="pwOpen(event,{_js(fk)},\'f\')" '
                   f'title="더블클릭하면 이 PC의 기본 프로그램으로 엽니다">{self._ICO_FILE}<span class="nm">{_E(name)}</span>'
                   f'<span class="meta">{fmark}{_sz(int(v[1]))} · '
                   f'{datetime.fromtimestamp(v[2]).strftime("%Y-%m-%d %H:%M")}</span>'
                   f'<button type="button" class="act" onclick="pwOpen(event,{_js(fk)},\'f\')" title="기본 프로그램으로 열기">열기</button>'
                   f'<button type="button" class="act" onclick="pwOpen(event,{_js(fk)},\'d\')" title="파일이 있는 폴더를 탐색기에서 열기">폴더</button></div>')
        # 열기는 감시 PC 안에서만 — 토큰은 조각마다 실어 보낸다 (브라우저 새로고침 없이 fetch로 보냄)
        return out + f'<div class="tree-list" data-tok="{self.csrf()}">{li}</div>'

    def page_tree(self, open_depth: int = 2, frag: bool = False, sel: str = "") -> str:
        """폴더 구조 보기 — 감시 중인 폴더의 가지를 윈도우 탐색기처럼: 왼쪽 트리(삼각형·
        폴더 아이콘·안내선), 오른쪽에 고른 폴더의 내용 (2026-09-04 요청 "폴더 가지들을
        확인" → "실제 윈도우 창처럼"). 최신 검사 기록(스냅샷)만 읽는다 — 파일서버를
        다시 훑지 않고, 원칙 2대로 읽기만. frag=True면 서랍용 트리만."""
        from watcher.cli import _excludes_for, _root_labels, make_resolver
        from watcher.doctype import looks_like_doctype_folder
        from watcher.scan import is_excluded
        cfg = self.cfg()
        roots = [Path(r) for r in cfg["roots"]]
        labels = _root_labels(roots)
        paths = self.watched_paths()           # 뺀 폴더도 가지로 보인다(램프 off) — 되살리는 자리
        present = set(self.present_paths())    # 수는 감시 중인 파일만 — 루트 "서버 135" vs 타일 130 (재검증 W2)
        resolver = self._resolver(roots, paths)
        head = ('<div class="topbar"><h1>폴더 구조</h1></div>'
                '<p class="muted tip" style="margin-top:0">최근 검사에 잡힌 파일로 그린 가지입니다. '
                '왼쪽에서 폴더를 고르면 오른쪽에 내용이 보입니다. 폴더에 마우스를 올리면 프로젝트 귀속을 '
                '알려줍니다. 파일서버를 다시 읽지 않습니다. '
                '<a href="/pick?to=root" style="color:var(--link)">드라이브부터 찾아보기 →</a></p>'
                '<div class="tree-legend"><b>램프</b>'
                '<span><i class="lamp"></i> 감시 중</span>'
                '<span><i class="lamp off"></i> 이 폴더를 뺐음</span>'
                '<span><i class="lamp sub"></i> 상위 폴더 때문에 빠짐</span>'
                '<span class="muted">폴더에 마우스를 올리면 이름 옆에 [빼기]가, 뺀 폴더에는 '
                '[다시 감시]가 보입니다 — 다음 검사부터 적용됩니다.</span>'
                '<a href="/settings#exclude" style="color:var(--link)">뺀 폴더 목록 →</a></div>')
        if not paths:
            empty = ('<div class="panel"><p>아직 검사 기록이 없습니다 '
                     '— [지금 검사]를 한 번 돌리면 여기에 가지가 그려집니다.</p></div>')
            if frag:
                return empty
            return _page("폴더 구조", "/tree", head + empty, self.pop_msg())

        # 라벨 → 중첩 사전 {폴더명: {...}} + 파일 수
        trees: dict = {}
        for p in paths:
            parts = p.split("/")
            cnt = 1 if p in present else 0         # 제외된 파일은 가지만 만들고 세지 않는다
            node = trees.setdefault(parts[0], {"_n": 0, "_d": 0, "_c": {}})
            node["_n"] += cnt
            for seg in parts[1:-1]:
                node = node["_c"].setdefault(seg, {"_n": 0, "_d": 0, "_c": {}})
                node["_n"] += cnt
            node["_d"] += cnt                      # 이 폴더 바로 아래의 파일

        raw_excl = list(cfg.get("exclude") or [])

        def render(label: str, rel: str, name: str, node: dict, depth: int, excl) -> str:
            key = f"{label}/{rel}" if rel else label
            proj, why = resolver.attribute(f"{key}/_", None)
            state, _by = exclude_state_of(key, labels, raw_excl)
            is_excl = bool(rel) and is_excluded(rel, excl)
            typed = looks_like_doctype_folder(name, cfg) if rel else False
            tip = f"파일 {node['_n']}개"
            if proj and why != "미분류":
                tip += f" · 프로젝트 {proj} ({why})"
            if typed:
                tip += " · 유형 폴더"
            if is_excl:
                tip += (" · 감시 제외(이 폴더)" if state == "direct"
                        else " · 감시 제외(상위 폴더 때문)")
            # 배지가 둘 다 '제외'면 "여기서 되돌릴 수 있나"가 색·툴팁에만 남는다 (7차 중간-I)
            badge = ('<span class="bd na">제외</span>' if state == "direct"
                     else '<span class="bd na">상위 제외</span>' if state == "inherited"
                     else '<span class="bd">유형</span>' if typed else "")
            n_dir = len(node["_c"])
            kids = "".join(
                render(label, f"{rel}/{k}" if rel else k, k, v, depth + 1, excl)
                for k, v in sorted(node["_c"].items(), key=lambda kv: kv[0].lower()))
            tri = '<span class="tri">▸</span>' if n_dir else '<span class="tri"></span>'
            # 폴더 이름 오른쪽의 작은 단추 — 오른쪽 패널까지 가지 않고 그 자리에서 넣고 뺀다
            # (2026-09-14 사용자 요청). 상위 때문에 빠진 폴더는 그 상위에서만 되돌릴 수 있어 단추 없음
            if rel and state == "watched":
                xb = (f'<button type="button" class="xb" data-act="add" data-path="{_E(key)}" '
                      f'title="이 폴더를 감시에서 빼기 — 다음 검사부터, 파일은 그대로 둡니다" '
                      f'onclick="pwTreeX(event,this)">빼기</button>')
            elif state == "direct":
                xb = (f'<button type="button" class="xb on" data-act="del" data-path="{_E(_by)}" '
                      f'title="이 폴더를 다시 감시하기 — 다음 검사부터" '
                      f'onclick="pwTreeX(event,this)">다시 감시</button>')
            else:
                xb = ""
            summary = (f'<summary class="tr{" excl" if is_excl else ""}'
                       f'{" sel" if sel == key else ""}" data-key="{_E(key)}" '
                       f'title="{_E(tip)}" '
                       f'onclick="pwTreeSel(this,event)">{tri}{self._lamp(state)}{self._ICO_FOLDER}'
                       f'<span class="nm">{_E(name)}</span>{xb}'
                       f'<span class="meta">{badge}{node["_n"]}</span></summary>')
            # 고른 폴더의 조상은 펼쳐 둔다 — 빼기·다시 감시 뒤 그 자리로 돌아오게 (7차 중간-F)
            on_path = bool(sel) and (sel == key or sel.startswith(key + "/"))
            opened = " open" if n_dir and (depth < open_depth or on_path) else ""
            return (f'<details{opened} data-key="{_E(key)}" ontoggle="pwTreeFiles(this)">{summary}'
                    f'<div class="files"></div>{kids}</details>')

        body = ""
        for r_path, label in zip(roots, labels):
            node = trees.get(label)
            if node is None:
                continue
            excl = _excludes_for(label, labels, cfg["exclude"])
            body += (f'<div class="tree-root" title="{_E(str(r_path))}">'
                     + render(label, "", label, node, 0, excl) + "</div>")
        tree = f'<div class="tree" id="tree-root" data-tok="{self.csrf()}">{body}</div>'
        if frag:
            return tree
        tools = ('<div class="tree-tools">'
                 '<button class="btn gray" onclick="pwTreeAll(\'tree-root\',true)">전체 펼치기</button> '
                 '<button class="btn gray" onclick="pwTreeAll(\'tree-root\',false)">전체 접기</button></div>')
        right = (self.tree_files(sel, full=True) if sel
                 else '<p class="muted">왼쪽에서 폴더를 고르면 내용이 여기 보입니다.</p>')
        panes = (f'<div class="tree-panes"><div class="panel tree-left">{tools}{tree}</div>'
                 f'<div class="panel tree-right" id="tree-right">{right}</div></div>')
        return _page("폴더 구조", "/tree", head + panes, self.pop_msg())

    def page_pick(self, path: str, to: str) -> str:
        """폴더 찾아보기 — 경로를 타이핑하지 않고 클릭으로 고른다 (2026-08-30
        요청). 드라이브 목록부터 시작, 폴더명 클릭=들어가기, [이 폴더 선택]=
        대상 폼(to: onboard|root)으로 제출. 읽기 전용 목록만 — 원칙 2."""
        to = to if to in ("onboard", "root") else "onboard"
        action = "/onboard" if to == "onboard" else "/root/add"
        path = (path or "").strip()

        def pick_btn(p: str, label: str = "이 폴더 선택") -> str:
            return (f'<form class="inline" method="post" action="{action}">'
                    f'{self._tok()}'
                    f'<input type="hidden" name="path" value="{_E(p)}">'
                    f'<button class="btn" style="font-size:12px;padding:4px 12px">'
                    f'{label}</button></form>')

        jump = (f'<form class="inline" method="get" action="/pick">'
                f'<input type="hidden" name="to" value="{to}">'
                f'<input type="text" name="path" value="{_E(path)}" '
                f'placeholder="직접 이동: \\\\서버\\공유  또는  D:\\projects" '
                f'style="min-width:340px">'
                f'<button class="btn gray">이동</button></form>')

        rows = ""
        note = ""
        if not path:
            import string
            drives = [f"{c}:\\" for c in string.ascii_uppercase
                      if Path(f"{c}:\\").exists()]
            rows = "".join(
                f'<tr><td><a href="/pick?to={to}&amp;path={quote(d)}" '
                f'style="color:var(--link);font-weight:700">💾 {_E(d)}</a></td>'
                f"<td style='width:120px'>{pick_btn(d)}</td></tr>"
                for d in drives)
            cur = ("드라이브를 고르거나, 네트워크 폴더(\\\\서버\\공유)는 위 칸에 "
                   "입력하고 [이동]을 누르세요.")
        else:
            p = Path(path)
            if not p.is_dir():
                note = (f'<p style="color:var(--warn)">폴더를 열 수 없습니다: '
                        f'{_E(path)} — 경로를 확인하거나 권한(네트워크 로그인)을 '
                        f'확인해주세요.</p>')
                cur = _E(path)
            else:
                try:
                    subs = sorted(
                        [d for d in p.iterdir() if d.is_dir()
                         and not d.name.startswith((".", "$"))],
                        key=lambda x: x.name.lower())[:400]
                except OSError as e:
                    subs, note = [], (f'<p style="color:var(--warn)">하위 폴더를 '
                                      f'읽을 수 없습니다: {_E(str(e))}</p>')
                up = str(p.parent) if p.parent != p else ""
                rows = ""
                if up:
                    rows += (f'<tr><td><a href="/pick?to={to}&amp;path={quote(up)}" '
                             f'class="muted">⬆ 상위 폴더로</a></td><td></td></tr>')
                rows += "".join(
                    f'<tr><td><a href="/pick?to={to}&amp;path={quote(str(d))}" '
                    f'style="color:var(--link)">📁 {_E(d.name)}</a></td>'
                    f"<td style='width:120px'>{pick_btn(str(d))}</td></tr>"
                    for d in subs)
                if not subs and not note:
                    rows += ('<tr><td class="muted">하위 폴더 없음</td>'
                             '<td></td></tr>')
                cur = (f'현재 위치: <b>{_E(path)}</b> {pick_btn(path)}')
        body = (f'<div class="topbar"><h1>감시할 폴더 찾아보기</h1>{jump}</div>'
                + _intro("폴더 이름을 클릭하면 들어가고, [이 폴더 선택]을 누르면 "
                         "그 폴더로 결정됩니다. 목록은 읽기만 합니다.")
                + f'<div class="panel"><p style="margin:0 0 10px">{cur}</p>{note}'
                f'<div class="scrolly" style="max-height:520px">'
                f'<table>{rows}</table></div></div>'
                + f'<div class="panel"><p><a href="/" style="color:var(--link)">'
                  f'← 돌아가기</a></p></div>')
        return _page("폴더 찾아보기", "/", body, self.pop_msg())

    def page_onboarding(self) -> str:
        """최초 가동 화면 — 감시 폴더가 없으면 대시보드 대신 이걸 보여준다.
        입력 하나 + 버튼 하나로 '추가 + 첫 검사'까지 (2026-08-30 사용자 제안)."""
        body = f"""
<div style="max-width:640px;margin:8vh auto 0">
  {self.dup_banner()}
  <div class="panel" style="padding:34px 36px;text-align:center">
    <h1 style="font-size:24px;margin-bottom:10px">Drev 시작하기</h1>
    <p class="muted" style="margin-bottom:22px">감시할 파일서버 폴더 하나만
    알려주세요 — 나머지는 자동입니다. 폴더 안의 파일은 <b>읽기만</b> 하며
    절대 수정·이동·삭제하지 않습니다.</p>
    <form method="post" action="/onboard">{self._tok()}
      <input type="text" name="path" required autofocus
        placeholder="예: \\\\서버\\설계부  또는  D:\\projects"
        style="width:100%;font-size:15px;padding:13px 16px;margin-bottom:12px">
      <button class="btn" style="width:100%;font-size:15px;padding:13px">
        다음 → (폴더 확인 후 첫 검사)</button>
    </form>
    <form method="post" action="/pick/native" style="margin-top:12px">
      {self._tok()}<input type="hidden" name="to" value="onboard">
      <button class="btn gray" style="width:100%;padding:11px;font-size:14px">
        📁 폴더 찾아보기 (윈도우 폴더 선택 창)</button></form>
    <p style="margin-top:8px"><a href="/pick?to=onboard" class="muted"
      style="font-size:12.5px">창이 안 뜨면 — 목록에서 고르기</a></p>
    <p class="muted" style="margin-top:16px;font-size:12.5px">
    첫 검사는 파일 수에 따라 몇 분~몇 시간 걸릴 수 있고, 진행률이 화면에
    표시됩니다. 폴더는 나중에 [설정]에서 더 추가하거나 제외할 수 있습니다.</p>
  </div>
</div>"""
        return _page("시작하기", "/", body, self.pop_msg())

    def page_dashboard(self, proj: str | None = None,
                       view: str = "cards") -> str:
        if not self.cfg()["roots"]:
            return self.page_onboarding()
        """홈 화면. view: 'cards'=프로젝트별 변경 카드(기본) / 'classic'=전체 요약.
        큰틀을 사용자가 고를 수 있게 상단 토글로 전환·기억 (2026-08-27 요청)."""
        # 이동(삭제+추가)은 한 건 — 카드 '오늘 변경 35' / 미확인 31 / 오늘 확인할 것 22가
        # 서로 다른 수를 말하던 것 (2026-09-05 재검토). 여기서 한 번 접어 아래 전부가 같은 행을 본다
        _notes_all = _side_note_map(self.db())
        all_rows, _also_all = _fold_moves(self.rows(), _notes_all)
        projects = sorted({_proj_of(r) for r in all_rows})
        rows = [r for r in all_rows if _proj_of(r) == proj] if proj else all_rows
        today = date.today().isoformat()
        today_rows = [r for r in rows if _local_date(r["detected_at"]) == today
                      and not r.get("baseline")]
        _seen_t: set = set()               # 확인 기록이 여럿이면 행도 여럿 — 변경 단위로 센다
        today_rows = [r for r in today_rows
                      if not (r["change_id"] in _seen_t or _seen_t.add(r["change_id"]))]
        base_id = self.baseline_id()
        # 기준선(첫 검사) '추가' 대량 건은 실제 변경이 아니므로 미확인 수에서 제외 —
        # 설치 첫날부터 '미확인 1,000건' 빨간불이 뜨던 문제 (2026-08-26 신입 검토)
        unacked = [r for r in rows
                   if not r["ack_by"] and not self.is_baseline_add(r, base_id)]

        # 타일도 '오늘 확인할 것' 카드와 같은 분해(주요 / 그 밖의 알림)를 단다 — 한 화면에
        # 14와 16이 근거 없이 병존하던 것, 검토 7~16에 이어 재발 (검토19 웹 U1)
        def _quiet_of(rs):
            return [r for r in rs if r.get("moved_from")
                    or _is_quiet(_notes_all.get(r["change_id"], ""))]
        today_quiet = _quiet_of(today_rows)
        unacked_quiet = _quiet_of(unacked)

        def _split_tile(rs, quiet):
            n = len(rs) - len(quiet)
            tail = (f'<div class="muted" style="font-size:11.5px;margin-top:2px">'
                    f'+그 밖의 알림 {len(quiet)}건 (이동·복사본·재저장)</div>' if quiet else '')
            return n, tail
        n_today, today_tail = _split_tile(today_rows, today_quiet)
        n_unacked, unacked_tail = _split_tile(unacked, unacked_quiet)
        iss = self.issue_rows(proj)
        st_state = self.scan_state()
        scan_state = " (검사 중...)" if st_state == "scanning" else ""
        title = _E(proj) if proj else "대시보드"

        issue_panel = ""
        if iss:
            lis = "".join(
                f'<div class="proj" style="align-items:flex-start">'
                f'<span class="tag removed" style="margin-top:2px;white-space:nowrap">'
                f'{_E(CODE_LABEL.get(i["code"], i["code"]))}</span>{self._pre_tag(i)}'
                f'<div style="flex:1;font-size:13px;padding-left:10px">{_E(i["message"])}'
                f'<div class="muted" title="{_E(i["path"])}">'
                f'{_path_html(i["path"])} · {_E(_local_date(i["detected_at"]))}</div>'
                f"</div></div>"
                for i in iss[:30])
            issue_panel = (
                f'<div class="panel"><h2>검토 필요 — 최근 {min(len(iss), 30)}건 '
                f'<a href="/issues{f"?p={quote(proj)}" if proj else ""}" '
                f'style="font-weight:400;font-size:12.5px;text-transform:none">'
                f'· 전체 {len(iss)}건 보기 →</a></h2>'
                f'<div class="scrolly sm">{lis}</div></div>')

        if proj:
            real = [r for r in rows if not r.get("baseline")] or rows   # 첫 등록만 있으면 그것으로
            cats = Counter(_ext_category(r["path"]) for r in real)
            side_panel = ("<h2>문서 유형 구성</h2>" + "".join(
                f'<div class="proj"><span class="nm">{_E(c)}</span>'
                f'<div class="bar"><i style="width:{round(n / max(len(real), 1) * 100)}%"></i></div>'
                f'<div class="pc">{n}건</div></div>'
                for c, n in cats.most_common())) or "<h2>문서 유형 구성</h2>"
            fourth_card = (f'<div class="card"><div class="k">검토 필요 누적</div>'
                           f'<div class="v {"bad" if iss else "ok"}">{len(iss)}'
                           f'<small> 건</small></div></div>')
        else:
            # 수십 개 규모 대비: 미확인 있는 것 → 최근 움직인 것 순
            stats = self.project_stats()
            stats.sort(key=lambda d: (d["unacked"] > 0, d["last"]), reverse=True)
            # 프로젝트마다 전체 이력을 다시 훑지 않는다 — 300개 × 4만 건이면
            # 한 화면에 1,440만 번 비교였다 (2026-09-02 회사 규모 프로파일)
            by_proj: dict[str, list] = {}
            for r in all_rows:
                by_proj.setdefault(_proj_of(r), []).append(r)
            proj_bars = ""
            for st_p in stats:  # 전부 — 많으면 패널 안에서 스크롤 (2026-08-28)
                p = st_p["name"]
                # 이동·재저장·복사본은 확인할 것이 아니다 — 프로젝트 목록은 7(+7)인데 막대는 14/14였다
                # (검토25 화면 3-3). project_stats와 같은 분해(total·quiet·unacked)
                n_real, n_quiet = st_p["total"], st_p["quiet"]
                done = max(0, n_real - st_p["unacked"])
                pct = round(done / n_real * 100) if n_real else 0
                proj_bars += (
                    f'<div class="proj"><a class="nm" href="/?p={quote(p)}" '
                    f'style="color:var(--link)">{_E(p)}</a>'
                    f'<div class="bar"><i style="width:{pct}%"></i></div>'
                    f'<div class="pc">확인 {done}/{n_real}'
                    + (f' <span class="muted">(+{n_quiet})</span>' if n_quiet else "")
                    + (f' ({pct}%)' if n_real else "") + '</div></div>')
            more_link = (f'<p style="margin-top:8px"><a href="/projects" '
                         f'style="color:var(--link);font-size:12.5px">프로젝트 '
                         f'화면에서 검색·정렬 →</a></p>'
                         if len(stats) > 8 else "")
            side_panel = ("<h2>주요 프로젝트 (미확인·최근 활동 순)</h2>"
                          + (f'<div class="scrolly sm">{proj_bars}</div>'
                             if proj_bars else
                             '<p class="muted">아직 데이터가 없습니다.</p>')
                          + more_link)
            fourth_card = (f'<div class="card"><div class="k">검토 필요 누적</div>'
                           f'<div class="v {"bad" if iss else "ok"}">{len(iss)}'
                           f'<small> 건</small></div></div>')

            # ── 프로젝트 카드형 본문: 프로젝트별 변경사항을 카드로 (기본 큰틀)
            pcards = ""
            for st_p in stats[:60]:  # 많으면 스크롤 (2026-08-28)
                p = st_p["name"]
                pr = [r for r in by_proj.get(p, []) if not r.get("baseline")]
                today_n = sum(1 for r in pr
                              if _local_date(r["detected_at"]) == today)
                seen_ids: set = set()
                files = ""
                for r in pr:  # 변경 단위 dedup 후 최근 3건
                    if r["change_id"] in seen_ids:
                        continue
                    seen_ids.add(r["change_id"])
                    if len(seen_ids) > 3:
                        break
                    _nm = PurePosixPath(r["path"]).name
                    files += (
                        f'<div class="pfile">{_move_tag(r)} '
                        f'<a href="/change?id={r["change_id"]}" '
                        f'title="{_E(_nm)}" '          # 잘린 이름은 마우스로 전체 확인
                        f'style="color:var(--link)">'
                        f'{_E(_ellipsis(_nm))}</a>'
                        f'<span class="muted"> {_E(_local(r["detected_at"], "%m/%d"))}'
                        f"</span></div>")
                badge = (f'<span class="tag removed">미확인 {st_p["unacked"]}</span>'
                         if st_p["unacked"] else
                         '<span class="tag added">확인 완료</span>')
                if today_n:
                    badge = (f'<span class="tag modified">오늘 {today_n}</span> '
                             + badge)
                pcards += (
                    f'<div class="pcard">'
                    f'<div class="pc-head"><a href="/project?name={quote(p)}">{_E(p)}</a>'
                    f'<span>{badge}</span></div>'
                    + (f'<div class="muted" style="margin-bottom:6px">최근 변경 '
                       f'{_E(_local(st_p["last_real"]))}'
                       + (f' · 최근 확인 {_E(_local(st_p["last_ack"]))}' if st_p.get("last_ack") else "")
                       + '</div>'
                       if st_p.get("last_real") else
                       f'<div class="muted" style="margin-bottom:6px">첫 등록 '
                       f'{_E(_local(st_p["last"]))} · 아직 변경 없음</div>')
                    + f'{files}'
                    f'<a class="pc-more" href="/project?name={quote(p)}">'
                    f'유형별로 보기 →</a></div>')
            # A그래픽+B밀도 하이브리드 (2026-08-28 시안 선택): 좌 최근 변경 표 /
            # 우 검토 필요+주요 프로젝트 — 한 화면에서 오늘 상황이 끝나게
            recent_panel = (
                f'<div class="panel"><h2>최근 변경 '
                f'<a href="/history" style="font-weight:400;font-size:12px;'
                f'text-transform:none;letter-spacing:0">전체 이력 →</a></h2>'
                f'<div class="scrolly">{_rows_table(rows, 100, notes=_side_note_map(self.db()))}</div></div>')
            right_col = (issue_panel
                         + f'<div class="panel">{side_panel}</div>')
            cards_main = (
                f'<div class="grid2"><div>{recent_panel}</div>'
                f'<div>{right_col}</div></div>'
                f'<div class="panel"><h2>프로젝트별 변경사항 '
                f'<a href="/projects" style="font-weight:400;font-size:12.5px">'
                f'전체 {len(stats)}개 프로젝트 보기 →</a> · '
                f'<a href="/briefs" style="font-weight:400;font-size:12.5px">'
                f'브리핑 보기</a></h2>'
                + (f'<div class="scrolly" style="max-height:600px">'
                   f'<div class="pcards">{pcards}</div></div>' if pcards else
                   ('<p class="muted">첫 검사가 진행 중입니다 — 끝나면 여기에 프로젝트별로 '
                    '정리됩니다.</p>' if st_state == "scanning" else
                    '<p class="muted">아직 변경 기록이 없습니다 — [지금 검사]로 시작하세요.</p>'))
                + "</div>")

        classic_main = f"""<div class="grid2">
  <div class="panel"><h2>최근 14일 변경 추이</h2>{_trend_chart(rows)}</div>
  <div class="panel">{side_panel}</div>
</div>
<div class="panel"><h2>최근 변경
  <a href="/briefs" style="font-weight:400;font-size:12.5px;text-transform:none">무엇이 어떻게 바뀌었는지 상세 → 브리핑 보기</a></h2>
<div class="scrolly">{_rows_table(rows, 100, notes=_side_note_map(self.db()))}</div></div>"""
        if proj:
            main_body, view_toggle = classic_main, ""
        else:
            main_body = classic_main if view == "classic" else cards_main
            def _vt(v, label):
                on = (view == v) or (v == "cards" and view != "classic")
                st = ("background:var(--accent);color:var(--on-accent)" if on
                      else "background:var(--panel2);color:var(--muted)")
                return (f'<a href="/?view={v}" style="{st};padding:7px 12px;'
                        f'border-radius:8px;font-size:12.5px;border:1px solid '
                        f'var(--border)">{label}</a>')
            view_toggle = (f'<span style="display:inline-flex;gap:4px" '
                           f'title="홈 화면 큰틀 선택 (기억됩니다)">'
                           f'{_vt("cards", "프로젝트 카드")}'
                           f'{_vt("classic", "전체 요약")}</span>')

        # 검사 중 진행률 패널 — 단계·개수·% 막대 (2026-08-28 사용자 요청:
        # "몇 개 검토 중인지, 얼마나 진행됐는지 보이게")
        scan_panel = ""
        if st_state == "scanning":
            from watcher.cli import PROGRESS
            ph, done, total = (PROGRESS["phase"], PROGRESS["done"],
                               PROGRESS["total"])
            cur, since = PROGRESS.get("current") or "", PROGRESS.get("since") or 0.0
            import time as _time
            el = int(_time.time() - since) if cur else 0
            # '지금:' 줄과 오래 걸림 경고는 **항상** 그려 둔다(빈 채로라도) — pwProg가 몇 초마다
            # 이 자리를 갈아 끼우기 때문. 예전에는 전체 수를 아는 분기에만 #pw-prog가 있어서
            # 첫 검사 화면이 숫자에 얼어붙은 채 멈춘 것과 구분이 안 됐다 (7차 치명 B)
            cur_line = (f'<div class="muted cur" style="margin-top:4px;font-size:12px">'
                        + (f'지금: {_E(cur)} ({el}초째)' if cur else "") + '</div>'
                        + f'<div class="curwarn" style="margin-top:4px;font-size:12px;'
                          f'color:var(--bad)"{"" if el >= 120 else " hidden"}>'
                        # 훑는 중일 수도, 파일 하나에 걸린 것일 수도 있다 — 둘 다 맞는 말로 (7차 중간-D)
                          '오래 걸리고 있습니다 — 폴더가 아주 많거나, 파일 하나가 너무 크거나 깨졌을 수 '
                          '있습니다. 그대로 두셔도 되고, [검사 중지]를 누르면 여기까지 기록하고 멈춥니다.'
                          '</div>')
            if ph:
                pct = min(100, done * 100 // max(total, 1)) if total else 0
                cnt = (f"{done:,} / {total:,}개 ({pct}%)" if total
                       else (f"{done:,}개 확인" if done else "살펴보는 중"))
                bar = (f'<div class="bar" style="height:9px;border-radius:5px;'
                       f'background:var(--hover);margin-top:6px">'
                       f'<i style="display:block;height:9px;border-radius:5px;'
                       f'background:var(--link);width:{pct}%"></i></div>' if total else "")
                tail = ("" if total else
                        ' <span class="muted">(전체 수는 확인이 끝나면 표시됩니다)</span>')
                prog = (f'<div id="pw-prog" style="margin-top:8px"><b class="ph">{_E(ph)}</b> '
                        f'<span class="cnt">{cnt}</span>{tail}{bar}{cur_line}</div>')
            else:
                prog = ""
            scan_panel = (
                '<div class="panel" style="background:var(--note-info);'
                'color:var(--link)">검사 중입니다… (검사 항목 수에 따라 오래 '
                '걸릴 수 있습니다) 이 화면은 몇 초마다 자동 갱신됩니다.'
                + prog + '</div>')
        # 새 버전 알림 배너 (2026-08-29 — 중소기업은 인터넷 연결이 기본이라는
        # 사용자 판단으로 기본 ON, config update_check: false로 끔)
        self.refresh_update_async()
        upd = self.update_banner()
        # 감시하지 않아도 될 법한 폴더 제안 — 개인폴더·temp까지 감시되어
        # 놀라는 일을 줄인다 (2026-09-01 처음 쓰는 사람 관점 점검)
        skipish = self.suggest_excludes()
        if skipish:
            btns = " ".join(
                f'<form class="inline" method="post" action="/exclude/add">{self._tok()}'
                f'<input type="hidden" name="path" value="{_E(d)}">'
                f'<input type="hidden" name="back" value="/">'
                f'<button class="btn gray" style="font-size:12px;padding:3px 10px" '
                f'title="파일 {n}개">{_E(d)} 제외</button></form>'
                for d, n in skipish[:4])
            upd += (f'<div class="panel" style="border-left:4px solid var(--muted2)">'
                    f'🗂 <b>감시하지 않아도 될 폴더가 있어 보입니다</b> — 개인 폴더·임시 폴더는 '
                    f'빼두면 알림이 조용해집니다. 한 번 누르면 제외됩니다: {btns}'
                    + (f' <a href="/settings#exclude" style="color:var(--link);font-size:12px">'
                       f'외 {len(skipish) - 4}개 →</a>' if len(skipish) > 4 else "")
                    + '</div>')
        # 문서 유형 확인 유도 — 자동 추정을 사람이 한 번 훑게 (2026-09-01)
        unconf = self.unconfirmed_folders(limit=6)
        if unconf:
            upd += (f'<div class="panel" style="border-left:4px solid var(--warn)">'
                    f'📂 <b>문서 유형이 확인되지 않은 폴더 {len(unconf)}개'
                    f'{"+" if len(unconf) >= 6 else ""}</b> — 한 번만 확인해 두면 '
                    f'이후 분류가 흔들리지 않습니다. '
                    f'<a class="btn" href="/doctype/review" '
                    f'style="text-decoration:none;font-size:12px;padding:4px 12px">'
                    f'확인하기</a></div>')
        # 다른 판이 함께 떠 있으면 먼저 알린다 — 화면이 섞이는 사고 예방
        dup = self.dup_banner()
        # '오늘 확인할 것' — 결정에 필요한 것만 위에, 나머지는 아래 (2026-09-05 UI 리서치:
        # progressive disclosure). 오늘 잡힌 미확인 변경 + 열린 검토 필요(최근 7일)
        todo_rows = [r for r in unacked if _local_date(r["detected_at"]) == today]
        seen_c: set = set()
        todo_rows = [r for r in todo_rows if not (r["change_id"] in seen_c or seen_c.add(r["change_id"]))]
        # 우선순위: 검토 필요 → 수정(내용 비교됨) → 추가 → 삭제, 이동·복사본·재저장·빈 파일은
        # 접힌 "그 밖의 알림" — 폴더 이름 하나 바꾼 날 삭제 5건이 앞에 서서 모터 5.5→7.5kW가
        # 첫 화면에 안 보이던 것 (2026-09-05 전체 검토)
        _notes = _side_note_map(self.db())
        todo_rows, _also = _fold_moves(todo_rows, _notes)
        _also = {**_also_all, **_also}          # 위에서 이미 접힌 짝도 한 번에 확인
        for r in todo_rows:
            if r["change_id"] in _also:
                r["also_id"] = _also[r["change_id"]]
        quiet_rows = [r for r in todo_rows if r.get("moved_from") or _is_quiet(_notes.get(r["change_id"], ""))]
        quiet_ids = {r["change_id"] for r in quiet_rows}
        _order = {"modified": 0, "added": 1, "removed": 2}
        # 8행 안에 경로순이라 전장BOM·발주서·계약서가 "전체 →" 뒤로 밀리고, 같은 날 두 번
        # 검사하면 앞 검사분이 앞을 차지했다 (2026-09-05 재검토) — 이번 검사분 먼저,
        # 그 안에서 도면·BOM·발주서·계약서·사양서 순
        _latest = max((r.get("snapshot_id") or 0 for r in todo_rows), default=0)
        # 변경의 무게(사양·표 행 > Rev > 글자·그림 > 날짜·크기)로 먼저 — '임시/계산.xlsx 크기
        # 변경'이 모터 사양 변경보다 위에 섰다 (파일럿 모의 2차 day8)
        _sums: dict = {}
        try:
            with State(self.db()) as _st:
                _sums = _st.change_summaries([r["change_id"] for r in todo_rows])
        except Exception:
            _sums = {}
        todo_rows = sorted((r for r in todo_rows if r["change_id"] not in quiet_ids),
                           key=lambda r: (_sums.get(r["change_id"], (5, ""))[0],
                                          (r.get("snapshot_id") or 0) != _latest,
                                          _order.get(r["kind"], 3),
                                          _doc_rank(r["path"]), r["path"].lower()))
        week_ago = (date.today() - timedelta(days=7)).isoformat()
        todo_iss = [i for i in iss if not i.get("resolved_at") and _local_date(i["detected_at"]) >= week_ago]
        if todo_rows or todo_iss or quiet_rows:
            tok = self.csrf()
            # '무엇이 어떻게' 한 줄 — 파일명만 보여 줘 눌러 봐야 알았다 (파일럿 모의 ⑦)
            _heads: dict = {k: h for k, (_w, h) in _sums.items() if h}

            def _todo_tr(r):
                _h = _heads.get(r["change_id"])
                return (f'<tr data-name="{_E(r["path"].lower())}"><td>{_move_tag(r)}</td>'
                        f'<td><a href="/change?id={r["change_id"]}" style="color:var(--link)">'
                        f'{_path_html(r["path"])}</a>{_side_chip(_notes.get(r["change_id"], ""))}'
                        + (f'<div class="muted" style="font-size:12px">{_E(_h)}</div>' if _h else '') + '</td>'
                        f'<td class="muted" style="white-space:nowrap">{_E(r["project"] or "미분류")}</td>'
                        f'<td style="white-space:nowrap">{_ack_tag(r, tok)}</td></tr>')
            lines = "".join(_todo_tr(r) for r in todo_rows[:8])
            if quiet_rows:
                lines += (f'<tr><td colspan="4" style="padding:0"><details><summary class="muted" '
                          f'style="padding:6px 10px;cursor:pointer">그 밖의 알림 {len(quiet_rows)}건 '
                          f'— 이동·복사본·재저장·빈 파일 (내용 변경 아님)</summary><table>'
                          + "".join(_todo_tr(r) for r in quiet_rows[:20])
                          + '</table></details></td></tr>')
            ilines = "".join(
                f'<tr data-name="{_E(i["path"].lower())}"><td><span class="tag removed">'
                f'{_E(CODE_LABEL.get(i["code"], i["code"]))}</span>{self._pre_tag(i)}</td>'
                f'<td colspan="2"><a href="/issues" style="color:var(--link)">{_E(i["message"][:90])}</a>'
                f'<div class="muted">{_path_html(i["path"])}</div></td>'
                f'<td class="muted" style="white-space:nowrap">{_E(_local_date(i["detected_at"]))}</td></tr>'
                for i in todo_iss[:5])
            more = ""
            if len(todo_rows) > 8:
                more = (f'<a href="/history{f"?p={quote(proj)}" if proj else ""}" '
                        f'style="color:var(--link);font-size:12.5px">미확인 {len(todo_rows)}건 전체 →</a> ')
            if len(todo_iss) > 5:
                more += (f'<a href="/issues{f"?p={quote(proj)}" if proj else ""}" '
                         f'style="color:var(--link);font-size:12.5px">최근 7일 검토 필요 {len(todo_iss)}건 전체 →</a>')
            namebar = ""
            if todo_rows:
                namebar = (f'<div class="ackbar muted" style="margin-bottom:6px">확인자 이름 '
                           f'<input id="ackname" size="10" placeholder="예: 김대리" '
                           f'value="{_E(_login_name())}" '
                           f'title="[미확인]을 누를 때 이 이름으로 기록됩니다"></div>')
            emls = self.todays_emls()
            eml_line = ""
            if emls:
                eml_line = (f'<p class="muted" style="margin:0 0 6px">오늘 메일 초안 {len(emls)}통 — '
                            + " · ".join(
                                f'<a href="/brief/open?f={quote(e.name)}&back=/" style="color:var(--link)">'
                                f'{_E(e.stem[len("brief_"):])}</a>' for e in emls[:6])
                            + (" · <a href=\"/briefs\" style=\"color:var(--link)\">전체 →</a>"
                               if len(emls) > 6 else "") + "</p>")
            todo_panel = (
                f'<div class="panel" style="border-left:4px solid var(--accent)">'
                f'<h2>오늘 확인할 것 <span style="font-weight:400;text-transform:none;letter-spacing:0">'
                f'— 변경 {len(todo_rows)}건'
                + (f' (+그 밖의 알림 {len(quiet_rows)}건)' if quiet_rows else "")
                + f' · 최근 7일 검토 필요 {len(todo_iss)}건</span></h2>{eml_line}{namebar}'
                f'<div style="display:flex;gap:8px;align-items:center;margin:6px 0 4px">'
                f'<input type="text" placeholder="파일·프로젝트·구분으로 걸러내기" '
                "oninput=\"pwFilterText(this,'todo-t')\" aria-label=\"오늘 확인할 것 걸러내기\" "
                f'style="border:1px solid var(--border2);border-radius:8px;padding:5px 10px;'
                f'flex:1;max-width:340px;font-size:13px">'
                f'<span class="muted" id="todo-t-cnt" style="font-size:12px"></span></div>'
                f'<table id="todo-t"><tr><th>구분</th><th>파일</th><th>프로젝트</th><th>확인</th></tr>'
                f'{lines}{ilines}</table>'
                f'{more}</div>')
        else:
            todo_panel = ('<div class="panel" style="border-left:4px solid var(--ok)">'
                          '<b>오늘 확인할 것 없음</b> <span class="muted">— 새 변경도, 열린 검토 필요도 없습니다.</span></div>')
        body = f"""
<div class="topbar"><h1>{title}{scan_state}</h1>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
  {view_toggle}
  {_filter_bar('/', projects, proj)}
  {(f'<form class="inline" method="post" action="/scan/stop">{self._tok()}'
    f'<button class="btn red" title="지금 보던 파일까지만 마치고 멈춥니다 — '
    f'기록은 되돌려져 다음 검사가 이어받습니다">■ 검사 중지</button></form>')
   if st_state == 'scanning' else
   (f'<form class="inline" method="post" action="/scan">{self._tok()}'
    f'<button class="btn">▶ 지금 검사</button></form>')}</div></div>
{dup}
{todo_panel}
{upd}
{self.root_split_nudge(all_rows)}
{scan_panel}
{_intro(f"{_E(proj)} 프로젝트의 변경과 확인 현황입니다." if proj else
        "감시 폴더에서 일어난 변경과 확인 현황의 요약입니다. 위 드롭다운으로 프로젝트 하나만 골라 볼 수 있습니다.")}
{self.scan_health()}
{'' if (all_rows or st_state == 'scanning') else '''<div class="panel"><h2>처음이신가요? 3단계면 됩니다</h2>
<p>① <a href="/settings" style="color:var(--link)"><b>설정</b></a>에서 감시 폴더가 맞는지 확인 →
② 우상단 <b>[▶ 지금 검사]</b> 클릭 (첫 검사는 기준선 — 비교의 출발점이 되는 첫 기록이라
전부 '추가'로 쌓입니다) →
③ 다음부터는 바뀐 것만 여기와 브리핑에 올라옵니다. 자세한 것은 왼쪽
<a href="/help" style="color:var(--link)"><b>도움말</b></a>.</p></div>'''}
<div class="cards">
  <div class="card" id="card-total"><div class="k">{'프로젝트 변경 누적' if proj else '감시 중인 산출물'}</div>
    <div class="v">{(next((f'{s_["total"]}<small> 건</small>' + (f' <small class="muted">(+{s_["quiet"]})</small>' if s_["quiet"] else "") for s_ in self.project_stats() if s_["name"] == proj), "0<small> 건</small>")) if proj else f'{self.file_count()}<small> 개</small>'}</div>
    {'' if proj else f'<div class="muted" style="font-size:11.5px;margin-top:2px">{_E(self._ext_note())}</div>'}</div>
  <div class="card" id="card-today"><div class="k">오늘 변경</div>
    <div class="v {'warn' if today_rows else ''}">{n_today}<small> 건</small></div>{today_tail}</div>
  <a class="card" id="card-unacked" style="text-decoration:none;display:block"
     href="/history?ack=none{f'&amp;p={quote(proj)}' if proj else ''}">
    <div class="k">미확인 변경 <span class="muted">(클릭해 모아보기)</span></div>
    <div class="v {'bad' if unacked else 'ok'}">{n_unacked}<small> 건</small></div>{unacked_tail}</a>
  {fourth_card}
</div>
{issue_panel if (proj or view == "classic") else ''}
{main_body}"""
        return _page(title, "/", body, self.pop_msg(),
                     auto_refresh=(st_state == "scanning"
                                   or _upd_busy()),
                     back=False)          # 첫 화면 — 돌아갈 곳이 없다

    def page_issues(self, proj: str | None = None) -> str:
        all_rows = self.rows()
        projects = sorted({_proj_of(r) for r in all_rows})
        iss = self.issue_rows(proj)
        # 파일별로 묶고 근거를 표로 — 줄글 반복이 읽기 힘들다는 검토 반영 (2026-08-28)
        # 원인 단위로 묶는다 — MCCB-01 3건(도면 간 1 + 도면-BOM 2)이 도면 한 장 때문일
        # 때 파일별로 흩어져 있으면 배분 전에 손으로 다시 묶어야 한다 (2026-09-02)
        groups: dict = {}
        for i in iss[:100]:
            tag = _tag_in_msg(i["message"] or "")
            key = (i["project"] or "", tag) if tag else i["path"]
            groups.setdefault(key, []).append(i)
        # 근거에 적힌 파일들의 전/후 비교 화면으로 갈 수 있게 미리 찾아둔다
        # (2026-09-02: "말로만 써있으니 시각적으로 비교할 수가 없다")
        want = {i["path"] for i in iss[:100]}
        for i in iss[:100]:
            for ev in i["evidence"]:
                p = _ev_parse(ev)["path"]
                if p:
                    want.add(p)
        try:
            with State(self.db()) as st:
                links = st.changes_for_paths(sorted(want))
        except Exception:
            links = {}

        def _ev_rows(evs) -> str:
            out = []
            for ev in evs:
                head, sep, rest = ev.partition(": ")
                if sep and len(head) <= 60:
                    out.append(
                        f'<tr><td style="white-space:nowrap;color:var(--muted);'
                        f'font-size:12.5px;width:1%;padding-right:14px">'
                        f'{_E(head)}</td>'
                        f'<td style="font-size:13px">{_E(rest)}</td></tr>')
                else:
                    out.append(f'<tr><td colspan="2" style="font-size:13px">'
                               f'{_E(ev)}</td></tr>')
            return "".join(out)

        blocks = ""
        for gkey, items_ in groups.items():
            path = items_[0]["path"]
            tag = gkey[1] if isinstance(gkey, tuple) else None
            inner = ""
            paired = False        # 좌우 카드가 나오면 제목 줄 버튼은 중복
            todo = _older_side(items_)
            if todo:
                inner += (f'<p style="margin:6px 0 2px"><b>확인할 것:</b> {_E(todo)}</p>')

            def _side_by_side(i, links) -> str:
                nonlocal paired
                html = _compare_cards(i["evidence"], links)
                paired = paired or bool(html)
                return html

            for i in items_:
                inner += (
                    f'<div style="margin:12px 0 4px">'
                    f'<span class="tag removed">'
                    f'{_E(CODE_LABEL.get(i["code"], i["code"]))}</span>{self._pre_tag(i)} '
                    f'<strong>{_E(i["message"])}</strong> '
                    f'<span class="muted" style="font-size:12px">'
                    f'{_E(_local(i["detected_at"]))}</span></div>'
                    + (_side_by_side(i, links)
                       or f'<table style="margin:0 0 6px">'
                          f'{_ev_rows(i["evidence"])}</table>')
                    + f'<form class="inline" method="post" action="/issue/close">'
                    f'{self._tok()}'
                    f'<input type="hidden" name="id" value="{i["issue_id"]}">'
                    f'<input type="text" name="by" placeholder="처리자 이름(선택)" '
                    f'size="16">'
                    f'<button class="btn gray" style="font-size:12px;'
                    f'padding:4px 10px">처리함 (목록에서 닫기)</button></form>')
            head_html = (f'<b>태그 {_E(tag)}</b> · 관련 파일 '
                         f'{len({x["path"] for x in items_})}개' if tag else _path_html(path))
            blocks += (
                f'<div class="panel" style="border-left:4px solid var(--bad)">'
                f'<div title="{_E(path)}" style="font-size:14.5px">'
                f'{head_html} '
                f'<span class="muted" style="font-size:12px">· '
                f'{_E(items_[0]["project"] or "미분류")} · '
                f'{len(items_)}건</span>'
                + (f' <a class="btn gray" style="font-size:12px;'
                   f'padding:3px 9px;margin-left:6px" '
                   f'href="/change?id={links[path]}">전/후 비교 보기</a>'
                   if links.get(path) and not paired else "")
                + f'</div>{inner}</div>')
        more = (f'<p class="muted">외 {len(iss) - 100}건 생략</p>' if len(iss) > 100 else "")
        # 처리된 것도 남긴다 — PM이 '누가 정리했는지'를 봐야 한다 (2026-09-02)
        done_html = ""
        try:
            with State(self.db()) as st:
                done = st.issues(proj, resolved=True)[:50]
        except Exception:
            done = []
        if done:
            drs = "".join(
                f'<tr><td>{_E(_local(d["resolved_at"]))}</td>'
                f'<td>{_E(d["resolved_by"] or "—")}</td>'
                f'<td title="{_E(d["path"])}">{_path_html(d["path"])}</td>'
                f'<td>{_E(CODE_LABEL.get(d["code"], d["code"]))} — {_E(d["message"])}</td></tr>'
                for d in done)
            done_html = (f'<div class="panel"><details><summary style="cursor:pointer;'
                         f'color:var(--muted)">처리됨 {len(done)}건 — 누가 언제</summary>'
                         f'<table style="margin-top:8px"><tr><th>처리 일시</th><th>처리자</th>'
                         f'<th>파일</th><th>내용</th></tr>{drs}</table></details></div>')
        empty = ('<div class="panel"><p class="muted">검토 필요가 없습니다 — '
                 '검사에서 의심 정황이 발견되면 여기에 쌓입니다.</p></div>')
        body = (f'<div class="topbar"><h1>검토 필요{f" — {_E(proj)}" if proj else ""}'
                f' <span class="muted">누적 {len(iss)}건</span></h1>'
                + _filter_bar("/issues", projects, proj) + "</div>"
                + _intro("검사가 잡아낸 의심 정황입니다 — 내용은 바뀌었는데 Rev 그대로, "
                         "Rev만 갱신, 도면-BOM 불일치, 도면 간 사양 불일치. 근거와 함께 기록됩니다.")
                + (blocks + more if iss else empty) + done_html)
        return _page("검토 필요", "/issues", body, self.pop_msg())

    def subtype_map(self) -> dict:
        custom = self.cfg().get("drawing_types")
        return custom if isinstance(custom, dict) and custom else DRAWING_SUBTYPES

    def page_cat(self, cat: str, proj: str | None = None,
                 subtype: str | None = None, view: str = "") -> str:
        # 이동(삭제+추가)은 한 건 — 다른 화면과 같은 접기 (파일럿 모의 4차: 칩 36 vs 행 24)
        all_rows, _ = _fold_moves(self.rows(), _side_note_map(self.db()))
        projects = sorted({_proj_of(r) for r in all_rows})
        from watcher.doctype import canonical, kind_of
        cfg = self.cfg()
        # 표기가 달라도 같은 종류면 함께 보여준다 (도면 ↔ Drawing)
        rows = [r for r in all_rows
                if canonical(kind_of(r["path"], cfg)) == canonical(cat)]
        if not rows and cat in ("도면", "BOM", "문서"):
            rows = [r for r in all_rows if _ext_category(r["path"]) == cat]
        if proj:
            rows = [r for r in rows if _proj_of(r) == proj]
        group = view != "list"

        chips = ""
        if cat == "도면" and rows:
            mapping = self.subtype_map()
            # 칩은 **아래 목록에 나오는 행**을 센다 — 전체 칩만 기준선을 빼서 전체 1 / 세부 칩 합 16
            # 이었다 (파일럿 모의 5차 ③). 그중 변경·첫 등록이 몇인지는 옆에 밝힌다
            n_live = sum(1 for r in rows if not r.get("baseline"))
            n_base = len(rows) - n_live
            counts = Counter(_drawing_subtype(r["path"], mapping) for r in rows)
            base_q = f"c={quote(cat)}" + (f"&p={quote(proj)}" if proj else "")
            def chip(label, n, t):
                on = (t or None) == (subtype or None)
                style = ("background:var(--accent);color:#fff" if on
                         else "background:var(--border);color:var(--text2)")
                href = f"/cat?{base_q}" + (f"&t={quote(t)}" if t else "")
                return (f'<a href="{href}" class="pill" '
                        f'style="{style};margin-right:6px">{_E(label)} {n}</a>')
            chips = ('<div style="margin:0 0 14px">'
                     + chip("전체", len(rows), "")
                     + "".join(chip(s, n, s) for s, n in counts.most_common())
                     + (f'<span class="muted" style="font-size:12px">— 변경 {n_live}건 · '
                        f'첫 등록 {n_base}건 (첫 등록은 변경으로 세지 않습니다)</span>'
                        if n_base else "")
                     + '</div>')
            if subtype:
                rows = [r for r in rows
                        if _drawing_subtype(r["path"], mapping) == subtype]

        # 보기 전환: 프로젝트별 칸(기본) / 한 목록. 선택은 URL로 유지된다
        base_q = f"c={quote(cat)}" + (f"&p={quote(proj)}" if proj else "") + \
                 (f"&t={quote(subtype)}" if subtype else "")
        view_toggle = ""
        if not proj:
            view_toggle = (
                f'<div style="margin:0 0 12px">'
                f'<span class="muted" style="font-size:12px;margin-right:8px">보기</span>'
                f'<a class="pill" href="/cat?{base_q}" style="margin-right:8px;'
                + ("background:var(--accent);color:#fff" if group
                   else "background:var(--border);color:var(--text2)")
                + f'">프로젝트별</a>'
                f'<a class="pill" href="/cat?{base_q}&v=list" style="'
                + ("background:var(--border);color:var(--text2)" if group
                   else "background:var(--accent);color:#fff")
                + f'">한 목록</a></div>')

        # 유형 기준으로 바뀐 뒤로는 확장자 목록이 의미가 없다 — 건수와 근거를
        # 대신 보여준다 (2026-09-01: 제목에 빈 괄호가 나오던 문제)
        exts = ", ".join(CATEGORIES.get(cat, ())) or f"{len(rows)}건"
        title_extra = (f' — {_E(proj)}' if proj else '') + \
                      (f' — {_E(subtype)}' if subtype else '')
        body = (f'<div class="topbar"><h1>{_E(cat)}{title_extra}'
                + f' <span class="muted">({_E(exts)})</span></h1>'
                + _filter_bar("/cat", projects, proj, extra=f"c={quote(cat)}&")
                + "</div>"
                + _intro(f"{_E(cat)}으로 분류된 파일의 변경 기록입니다 — 분류 "
                         f"기준은 [설정]의 폴더 지정·이름 규칙을 따릅니다."
                         + (" 아래 칩으로 도면 세부 유형(파일명·폴더명 기준)을 골라 볼 수 있습니다."
                            if cat == "도면" else ""))
                + chips
                + view_toggle
                + (_by_project_grid(rows, self.csrf(), f"/cat?c={quote(cat)}")
                   if group and not proj else
                   f'<div class="panel">{_rows_table(rows, tok=self.csrf(), notes=_side_note_map(self.db()))}</div>'))
        return _page(cat, f"/cat?c={cat}", body, self.pop_msg())

    def project_stats(self) -> list[dict]:
        """프로젝트별 요약 — 최근 변경 최신순 (수십 개 규모에서 '움직인 것'이 위로)."""
        by: dict[str, list[dict]] = {}
        base_id = self.baseline_id()
        rows_, _ = _fold_moves(self.rows(), _side_note_map(self.db()))   # 이동은 한 건
        for r in rows_:
            by.setdefault(r["project"] or "미분류", []).append(r)
        out = []
        notes_ = _side_note_map(self.db())

        def _quiet_row(r) -> bool:          # 이동·재저장·복사본·일자만 갱신 — 대시보드와 같은 분해
            return bool(r.get("moved_from")) or _is_quiet(notes_.get(r["change_id"], "") or "")
        for p, rs in by.items():
            out.append({
                "name": p, "total": sum(1 for r in rs if not r.get("baseline") and not _quiet_row(r)),
                "quiet": sum(1 for r in rs if not r.get("baseline") and _quiet_row(r)),
                # 미확인은 대시보드와 같은 것만 센다 — 폴더 이름 변경 39건이 프로젝트 목록에선
                # 미확인 42, 대시보드에선 15로 갈렸다 (검토21 파일럿 중간 9ⓑ·14)
                "unacked": sum(1 for r in rs if not r["ack_by"]
                               and not self.is_baseline_add(r, base_id) and not _quiet_row(r)),
                "archived": _quiet_project(p),
                # 기준선 등록은 변경이 아니다 — 첫 검사만 있는 프로젝트에 '최근 변경
                # 오늘'이라 쓰던 것 (2026-09-09 배포 후 검토 중간 5, 2026-09-02 결정)
                "last": rs[0]["detected_at"],
                "last_real": next((r["detected_at"] for r in rs
                                   if not r.get("baseline")), None),
                # 그 프로젝트에서 사람이 마지막으로 확인한 시각 (2026-09-15 요청)
                "last_ack": max((r["ack_at"] for r in rs if r.get("ack_at")), default=None),
            })
        # 임시·공용·아카이브 성격은 뒤로 — 살아 있는 프로젝트 위에 '아카이브'가 앉아 있었다 (검토21 파일럿 14)
        out.sort(key=lambda d: (not d["archived"], d["last"]), reverse=True)
        return out

    def page_project_remove(self, name: str) -> str:
        """프로젝트 정리 확인 화면 — 무엇이 사라지는지 파일명까지 보여준다."""
        with State(self.db()) as st:
            files = st.project_files(name)
            n_changes = len(st.conn.execute(
                "SELECT id FROM changes WHERE IFNULL(project,'미분류') = ?",
                (name,)).fetchall())
        if not files and not n_changes:
            return _page("프로젝트 정리", "/projects",
                         '<div class="panel"><p>그 프로젝트의 기록이 없습니다.</p>'
                         '<p><a href="/projects" style="color:var(--link)">'
                         '프로젝트 목록으로</a></p></div>', self.pop_msg())
        lis = "".join(
            f'<li style="margin:2px 0"><code>{_E(PurePosixPath(f).name)}</code> '
            f'<span class="muted" style="font-size:12px">'
            f'{_E(str(PurePosixPath(f).parent))}</span></li>' for f in files[:15])
        more = (f'<li class="muted">외 {len(files) - 15}개</li>'
                if len(files) > 15 else "")
        body = (f'<div class="topbar"><h1>프로젝트 정리 — {_E(name)}</h1></div>'
                + _intro("잘못 묶였거나 더는 볼 필요 없는 프로젝트의 기록을 "
                         "지웁니다.")
                + f'<div class="panel" style="border-left:4px solid var(--bad)">'
                f'<h2>정말 지울까요?</h2>'
                f'<p style="margin-bottom:8px">프로젝트 <b>{_E(name)}</b>의 '
                f'<b>변경 이력 {n_changes}건</b>과 그에 달린 확인 기록·메모가 '
                f'사라집니다. <b>되돌릴 수 없습니다.</b></p>'
                f'<p class="muted" style="margin-bottom:10px">'
                f'⚠ 감시 대상 파일은 <b>그대로 있습니다</b> — 이 프로그램은 '
                f'산출물 파일을 절대 수정·삭제하지 않습니다. 지워지는 것은 '
                f'Drev가 쌓아둔 기록뿐입니다. 다음 검사에서 이 파일들이 다시 '
                f'잡히면 새 기록이 생깁니다.</p>'
                f'<details open><summary style="cursor:pointer;color:var(--muted)">'
                f'대상 파일 {len(files)}개</summary>'
                f'<ul style="padding-left:18px;font-size:13px;margin-top:6px">'
                f'{lis}{more}</ul></details>'
                f'<form method="post" action="/project/remove/do" '
                f'style="margin-top:14px"{_confirm(f"{name} 기록을 지웁니다. 되돌릴 수 없습니다. 계속할까요?")}>'
                f'{self._tok()}'
                f'<input type="hidden" name="name" value="{_E(name)}">'
                f'<label class="muted" style="display:block;margin-bottom:10px">'
                f'<input type="checkbox" name="exclude" value="1"> '
                f'이 프로젝트의 폴더를 앞으로 감시에서도 제외 (설정에서 되돌릴 수 '
                f'있습니다)</label>'
                f'<button class="btn red">기록 지우기</button> '
                f'<a class="btn gray" href="/projects" '
                f'style="text-decoration:none">취소</a></form></div>')
        return _page("프로젝트 정리", "/projects", body, self.pop_msg())

    def page_project_remove_many(self, names: list) -> str:
        """여러 프로젝트를 한 번에 정리 — 확인 화면 (2026-09-03 사용자 요청:
        "선택한 프로젝트 한번에 정리"). 프로젝트마다 지워질 이력·파일 수를 보여준다."""
        names = [n for n in dict.fromkeys(names) if n]
        if not names:
            return _page("프로젝트 정리", "/projects",
                         '<div class="panel"><p>정리할 프로젝트를 왼쪽 체크박스에서 골라주세요.</p>'
                         '<p><a href="/projects" style="color:var(--link)">프로젝트 목록으로</a>'
                         '</p></div>', self.pop_msg())
        if len(names) == 1:
            return self.page_project_remove(names[0])
        rows, tot_c, tot_f = [], 0, 0
        with State(self.db()) as st:
            for n in names:
                files = st.project_files(n)
                nc = len(st.conn.execute(
                    "SELECT id FROM changes WHERE IFNULL(project,'미분류') = ?", (n,)).fetchall())
                tot_c += nc
                tot_f += len(files)
                rows.append(f"<tr><td><b>{_E(n)}</b></td><td>{nc}건</td><td>{len(files)}개</td></tr>")
        hidden = "".join(f'<input type="hidden" name="name" value="{_E(n)}">' for n in names)
        body = (f'<div class="topbar"><h1>프로젝트 정리 — {len(names)}개</h1></div>'
                + _intro("고른 프로젝트들의 기록을 한 번에 지웁니다. 잘못 묶였거나 더는 볼 필요 "
                         "없는 것들을 정리할 때 쓰세요.")
                + f'<div class="panel" style="border-left:4px solid var(--bad)">'
                f'<h2>정말 지울까요?</h2>'
                f'<table><tr><th>프로젝트</th><th>변경 이력</th><th>파일</th></tr>'
                f'{"".join(rows)}</table>'
                f'<p style="margin:10px 0 8px">합계 <b>변경 이력 {tot_c}건</b>과 그에 달린 '
                f'확인 기록·메모가 사라집니다. <b>되돌릴 수 없습니다.</b></p>'
                f'<p class="muted" style="margin-bottom:10px">⚠ 감시 대상 파일 {tot_f}개는 '
                f'<b>그대로 있습니다</b> — 지워지는 것은 Drev가 쌓아둔 기록뿐입니다. 다음 '
                f'검사에서 이 파일들이 다시 잡히면 새 기록이 생깁니다.</p>'
                f'<form method="post" action="/project/remove/do"'
                f'{_confirm(f"{len(names)}개 프로젝트의 기록을 지웁니다. 되돌릴 수 없습니다. 계속할까요?")}>'
                f'{self._tok()}{hidden}'
                f'<label class="muted" style="display:block;margin-bottom:10px">'
                f'<input type="checkbox" name="exclude" value="1"> '
                f'이 프로젝트들의 폴더를 앞으로 감시에서도 제외 (설정에서 되돌릴 수 있습니다)</label>'
                f'<button class="btn red">{len(names)}개 기록 지우기</button> '
                f'<a class="btn gray" href="/projects" style="text-decoration:none">취소</a>'
                f'</form></div>')
        return _page("프로젝트 정리", "/projects", body, self.pop_msg())

    def page_project(self, name: str) -> str:
        n_issues = len(self.issue_rows(name))   # 프로젝트의 검토 필요 (2026-09-02)
        """프로젝트 하나를 문서 유형별로 갈라 보여준다 (2026-09-01 요청).

        한 목록에 도면·인터락·BOM이 뒤섞여 나오면 찾기 어렵다. 유형마다 칸을
        두고 최근 변경·미확인 수를 함께 보여, 어느 종류에서 무슨 일이 있었는지
        한눈에 들어오게 한다."""
        from collections import Counter
        from watcher.doctype import kind_of
        cfg = self.cfg()
        # 대시보드·프로젝트 목록과 같은 접기 — 이 화면만 이동 1건을 삭제+추가 2건으로 세어 목록 20 /
        # 상세 40 / 칩 36 / 이력 40으로 같은 사건에 숫자가 넷이었다 (파일럿 모의 4차)
        rows, _ = _fold_moves([r for r in self.rows() if (r["project"] or "미분류") == name],
                              _side_note_map(self.db()))
        if not rows:
            body = (f'<div class="topbar"><h1>{_E(name)}</h1></div>'
                    + '<div class="panel"><p class="muted">이 프로젝트의 변경 '
                      '기록이 없습니다.</p><p style="margin-top:6px">'
                      '<a href="/projects" style="color:var(--link)">'
                      '프로젝트 목록으로</a></p></div>')
            return _page(_E(name), "/projects", body, self.pop_msg())

        from watcher.doctype import canonical
        by: dict[str, list] = {}
        labels: dict[str, Counter] = {}
        for r in rows:
            lb = kind_of(r["path"], cfg)
            key = canonical(lb)
            by.setdefault(key, []).append(r)
            labels.setdefault(key, Counter())[lb] += 1
        # 칸 이름은 사이드바·이력과 같은 표기(canonical) — 'I/O List'와 'I/O 리스트'가 화면마다
        # 다르던 것 (2026-09-06 사용성 3차 ④-11; 2026-09-02의 '우세한 표기' 결정을 되돌림)
        order = sorted(by.items(), key=lambda kv: (-len(kv[1]), kv[0]))
        notes_ = _side_note_map(self.db())

        def _quiet_row(r) -> bool:
            return bool(r.get("moved_from")) or _is_quiet(notes_.get(r["change_id"], "") or "")
        # 미확인은 대시보드와 같은 분해 — 이동·재저장은 '그 밖의 알림' (검토21 파일럿 중간 9ⓑ)
        unacked_all = sum(1 for r in rows if not r["ack_by"] and not r.get("baseline") and not _quiet_row(r))
        quiet_all = sum(1 for r in rows if not r.get("baseline") and _quiet_row(r))
        present = set(self.present_paths())

        cards = ""
        for kind, rs in order:
            unack = sum(1 for r in rs if not r["ack_by"] and not r.get("baseline"))
            # 지금 있는 파일만 — 변경 기록의 경로 집합은 옮긴 파일의 옛 경로(첫 등록)까지 세어
            # 도면 12장이 "파일 24"였다 (파일럿 모의 5차 ①)
            files = len({r["path"] for r in rs} & present)
            # 목록은 숫자가 세는 것(기준선 제외)만 — "변경 2" 밑에 첫 등록까지 행 3개가 있었다
            n_kind = sum(1 for r in rs if not r.get("baseline"))
            shown = [r for r in rs if not r.get("baseline")] or rs
            items = "".join(
                f'<div class="pfile"><a href="/change?id={r["change_id"]}" '
                f'title="{_E(r["path"])}">{_move_tag(r) if r.get("moved_from") else _kind_tag(r["kind"])} '
                f'{_path_html(r["path"])}</a> '
                f'<span class="muted" style="font-size:12px">'
                f'{_E(_local(r["detected_at"], "%m-%d"))}</span></div>'
                for r in shown[:6])
            more = (f'<a class="pc-more" href="/cat?c={quote(kind)}'
                    f'&p={quote(name)}">전체 {n_kind}건 보기 →</a>'
                    if n_kind > 6 else
                    f'<a class="pc-more" href="/cat?c={quote(kind)}'
                    f'&p={quote(name)}">유형 전체 보기 →</a>')
            cards += (
                f'<div class="pcard"><div class="pc-head">'
                f'<a href="/cat?c={quote(kind)}&p={quote(name)}">{_E(kind)}</a>'
                f'<span class="muted" style="font-size:12px">파일 {files} · '
                f'변경 {sum(1 for r in rs if not r.get("baseline"))}'
                + (f' · <b style="color:var(--warn)">미확인 {unack}</b>'
                   if unack else "") + '</span></div>'
                f'{items}{more}</div>')

        chips = " ".join(
            f'<a class="pill" href="/cat?c={quote(k)}&p={quote(name)}" '
            f'style="background:var(--border);color:var(--text2);'
            f'text-decoration:none;margin-right:6px">{_E(k)} '
            f'{sum(1 for r in v if not r.get("baseline"))}</a>'
            for k, v in order)
        last = _local(rows[0]["detected_at"])
        body = (f'<div class="topbar"><h1>{_E(name)} '
                f'<span class="muted">프로젝트</span></h1>'
                f'<div style="display:flex;gap:8px;flex-wrap:wrap">'
                f'<a class="btn gray" href="/?p={quote(name)}" '
                f'style="text-decoration:none">대시보드에서 보기</a>'
                f'<a class="btn gray" href="/history?p={quote(name)}" '
                f'style="text-decoration:none">전체 이력</a></div></div>'
                + _intro("문서 유형별로 나눠 봅니다 — 어느 종류에서 무슨 일이 "
                         "있었는지 한눈에 확인하고, 칸을 눌러 그 유형만 파고들 "
                         "수 있습니다.")
                + f'<div class="cards">'
                f'<div class="card"><div class="k">문서 유형</div>'
                f'<div class="v">{len(order)}<small>종</small></div></div>'
                f'<div class="card"><div class="k">변경 누적</div>'
                # 이동·재저장은 '그 밖의 알림' — 대시보드·프로젝트 목록과 같은 분해 (test_numbers_agree)
                f'<div class="v">{sum(1 for r in rows if not r.get("baseline") and not _quiet_row(r))}'
                f'<small>건</small>{f" <span class=muted style=font-size:12px>(+{quiet_all})</span>" if quiet_all else ""}</div></div>'
                f'<div class="card"><div class="k">미확인</div>'
                f'<div class="v {"warn" if unacked_all else "ok"}">'
                f'{unacked_all}<small>건</small></div></div>'
                f'<a class="card" href="/issues?p={quote(name)}" style="text-decoration:none">'
                f'<div class="k">검토 필요</div>'
                f'<div class="v {"bad" if n_issues else "ok"}">'
                f'{n_issues}<small>건</small></div></a>'
                f'<div class="card"><div class="k">최근 변경</div>'
                f'<div class="v" style="font-size:16px;padding-top:6px">'
                f'{_E(last)}</div></div></div>'
                f'<div class="panel"><h2>유형 바로가기</h2>{chips}</div>'
                f'<div class="pcards">{cards}</div>')
        return _page(_E(name), "/projects", body, self.pop_msg())

    def page_projects(self) -> str:
        stats = self.project_stats()
        trs = "".join(
            f"<tr data-name='{_E(p['name'].lower())}'>"
            f"<td style='width:1%'><input type='checkbox' name='name' "
            f"value=\"{_E(p['name'])}\" title='합칠 프로젝트 고르기'></td>"
            f"<td><a href='/project?name={quote(p['name'])}' "
            f"style='color:var(--link);font-weight:600'>{_E(p['name'])}</a>"
            + (" <span class='tag na' title='임시·공용·아카이브 성격 — 메일 초안은 만들지 않습니다'>보관·공용</span>"
               if p.get("archived") else "") + "</td>"
            f"<td>{_E(_local(p['last']))}</td>"
            f"<td>{p['total']}" + (f" <span class='muted'>(+{p['quiet']})</span>" if p.get("quiet") else "") + "</td>"
            + (f"<td><span class='tag removed'>{p['unacked']}</span></td>"
               if p["unacked"] else "<td class='muted'>0</td>")
            + (f"<td style='width:90px'><a class='btn gray' "
               f"style='font-size:12px;padding:3px 9px;text-decoration:none' "
               f"href='/project/remove?name={quote(p['name'])}'>정리</a></td>")
            + "</tr>"
            for p in stats)
        search = ('<input type="text" id="proj-q" placeholder="프로젝트 검색…" '
                  'oninput="pwFilterRows(this,\'proj-table\')" '
                  'style="min-width:220px">') if len(stats) > 8 else ""
        # 같은 프로젝트가 이름만 달리 잡히는 일이 흔하다 — 골라서 합친다
        # (2026-09-02 회사 실사용: "같은 프로젝트인데 다른 프로젝트인거처럼")
        merge_bar = (f'<div class="ackbar muted" style="display:flex;gap:8px;'
                     f'align-items:center;flex-wrap:wrap">'
                     f'<span>왼쪽에서 고르고 →</span>'
                     f'<button class="btn gray" style="font-size:12px;'
                     f'padding:4px 12px" title="같은 프로젝트가 여러 이름으로 갈렸을 때 — '
                     f'2개 이상">선택한 프로젝트 합치기</button>'
                     # 여러 프로젝트를 한 번에 정리 (2026-09-03 사용자 요청)
                     f'<button class="btn gray" style="font-size:12px;padding:4px 12px" '
                     f'formaction="/project/remove/many" formmethod="post" '
                     f'title="고른 프로젝트들의 기록을 한 번에 지웁니다 (확인 화면 있음)">'
                     f'선택한 프로젝트 정리</button></div>'
                     if len(stats) > 1 else "")
        body = (f'<div class="topbar"><h1>프로젝트 '
                f'<span class="muted">{len(stats)}개</span></h1>{search}</div>'
                + _intro("최근에 움직인 프로젝트가 위로 옵니다. 이름을 클릭하면 그 프로젝트만 봅니다.")
                + '<div class="panel">'
                + f'<form method="post" action="/project/merge">{self._tok()}'
                + merge_bar
                + '<table id="proj-table"><tr><th></th><th>프로젝트</th>'
                '<th>최근 변경</th>'
                f"<th>변경 누적</th><th>미확인</th><th></th></tr>{trs}</table>"
                "</form></div>"
                + self.root_split_nudge()
                + self._merge_history())
        return _page("프로젝트", "/projects", body, self.pop_msg())

    def _merge_history(self) -> str:
        """최근 합치기 — 잘못 합쳤으면 여기서 되돌린다."""
        if not self.db().exists():
            return ""
        try:
            with State(self.db()) as st:
                ms = st.merges(10)
        except Exception:
            return ""
        if not ms:
            return ""
        rows = "".join(
            f"<tr><td>{_E(_local(m['at']))}</td>"
            f"<td><b>{_E(m['into'])}</b> ← {_E(', '.join(m['sources']))}</td>"
            f"<td>{m['rows']}건</td>"
            f'<td><form class="inline" method="post" action="/project/merge/undo">'
            f'{self._tok()}<input type="hidden" name="id" value="{m["merge_id"]}">'
            f'<button class="btn gray" style="font-size:12px;padding:3px 9px">'
            f'되돌리기</button></form></td></tr>'
            for m in ms)
        return (f'<div class="panel"><details><summary style="cursor:pointer;'
                f'color:var(--muted)">합친 기록 {len(ms)}건 — 되돌리기</summary>'
                f'<table style="margin-top:8px"><tr><th>일시</th><th>합침</th>'
                f'<th>이력</th><th></th></tr>{rows}</table>'
                f'<p class="muted" style="font-size:12px">되돌리면 이력의 이름이 '
                f'원래대로 돌아가고, 다음 검사에서도 합쳐지지 않습니다 '
                f'(별칭 사전의 줄도 함께 지웁니다).</p>'
                f'</details></div>')

    def page_merge_confirm(self, names: list) -> str:
        """무엇이 무엇으로 합쳐지는지 보여주고 한 번 묻는다."""
        names = [n for n in dict.fromkeys(names) if n]
        if len(names) < 2:
            return _page("프로젝트 합치기", "/projects",
                         '<div class="panel"><h1>합칠 프로젝트를 2개 이상 '
                         '골라주세요</h1><p class="muted">프로젝트 목록에서 '
                         '왼쪽 칸을 체크한 뒤 [선택한 프로젝트 합치기]를 '
                         '누르세요.</p><p><a class="btn" href="/projects">'
                         '목록으로</a></p></div>')
        stats = {p["name"]: p for p in self.project_stats()}
        best = _pick_canonical(names)
        picks = "".join(
            f'<label style="display:block;margin:6px 0">'
            f'<input type="radio" name="into" value="{_E(n)}"'
            f'{" checked" if n == best else ""}> <b>{_E(n)}</b> '
            f'<span class="muted">— 변경 {stats.get(n, {}).get("total", 0)}건</span>'
            f'</label>' for n in names)
        hidden = "".join(f'<input type="hidden" name="name" value="{_E(n)}">'
                         for n in names)
        body = (f'<div class="topbar"><h1>프로젝트 합치기</h1></div>'
                f'<div class="panel"><p>고른 {len(names)}개를 한 프로젝트로 '
                f'모읍니다. <b>남길 이름</b>을 고르세요 — 나머지 이름의 이력이 '
                f'이 이름 아래로 들어갑니다.</p>'
                f'<form method="post" action="/project/merge/do">{self._tok()}'
                f'{hidden}{picks}'
                f'<p class="muted" style="font-size:12.5px">앞으로의 검사에서도 '
                f'같은 프로젝트로 잡히도록 별칭 사전에 함께 적습니다. 잘못 합쳤으면 '
                f'프로젝트 목록의 [합친 기록]에서 되돌릴 수 있습니다.</p>'
                f'<button class="btn">합치기</button> '
                f'<a class="btn gray" href="/projects">취소</a></form></div>')
        return _page("프로젝트 합치기", "/projects", body)



    def page_history(self, proj: str | None = None,
                     ack_filter: str | None = None) -> str:
        all_rows = self.rows()
        projects = sorted({_proj_of(r) for r in all_rows})
        rows = [r for r in all_rows if _proj_of(r) == proj] if proj else all_rows
        bulk = ""
        if ack_filter == "none":  # 미확인 모아보기 (대시보드 카드에서 진입)
            base_id = self.baseline_id()
            # 제목·[모두 확인] 단추의 수도 표와 같은 접기(이동 1건)로 — 제목 96 vs 표 192행/대시보드 74
            # (검토21 웹 차단 A). _rows_table은 안에서 다시 접지만 이미 접힌 행은 그대로다
            notes_h = _side_note_map(self.db())
            rows, _ = _fold_moves(rows, notes_h)
            rows = [r for r in rows if not r["ack_by"]]
            n_base = sum(1 for r in rows if self.is_baseline_add(r, base_id))
            # 대시보드와 같은 분해 — 이동·재저장·복사본은 '그 밖의 알림'이지 미확인 변경이 아니다
            # (test_numbers_agree: 제목 1 vs 대시보드 0(+1))
            n_quiet = sum(1 for r in rows if not self.is_baseline_add(r, base_id)
                          and (r.get("moved_from") or _is_quiet(notes_h.get(r["change_id"], "") or "")))
            # 첫 등록은 확인 대상이 아니다(_ack_tag) — 그런데 표와 [모두 확인] 단추에는 들어 있어
            # "미확인 0건" 제목 아래 126행과 "126건 모두 확인 처리" 큰 단추가 떴다
            # (검토22 UI 차단 3). 표·단추에서 빼고 안내문으로만 말한다
            rows = [r for r in rows if not self.is_baseline_add(r, base_id)]
            base_note = (f" 첫 검사 때 등록된 {n_base}건은 '첫 등록'이라 확인 대상이 아니며 "
                         f"이 표에 없습니다 (전체 이력에서 볼 수 있습니다)." if n_base else "")
            title = (f"미확인 변경 {len(rows) - n_quiet}건"
                     + (f" (+그 밖의 알림 {n_quiet}건)" if n_quiet else ""))
            intro = ("아직 아무도 [확인함]을 남기지 않은 변경입니다. 파일을 클릭해 "
                     "내용을 보고 확인을 남기세요. 전부 이미 아는 변경이면 아래에서 "
                     "한 번에 확인 처리할 수 있습니다." + base_note)
            if not rows:
                bulk = ('<div class="panel"><p style="margin:0"><b>확인할 변경이 없습니다.</b> '
                        '<span class="muted">새 변경은 다음 검사 뒤 여기에 모입니다.</span></p></div>')
            if rows:
                # 화면에 보여 준 id를 그대로 실어 보낸다 — POST 때 DB를 다시 조회하면
                # 그 사이 검사가 돈 경우 **사용자가 본 적 없는 변경**까지 확인 처리된다.
                # 창을 켜 둔 채 07:00 배치가 도는 게 기본 동작이라 흔한 경로다
                # (2026-09-09 확인 검토 차단 A1). 확인 기록은 지울 수 없다.
                _shown = ",".join(str(r["change_id"]) for r in rows)
                bulk = (f'<div class="panel"><form method="post" action="/ack/bulk">'
                        f'{self._tok()}'
                        f'<input type="hidden" name="ids" value="{_shown}">'
                        f'<input type="hidden" name="p" value="{_E(proj or "")}">'
                        f'<input type="text" name="by" placeholder="확인자 이름" required value="{_E(_login_name())}" '
                        f'style="padding:8px 10px;border:1px solid var(--border2);'
                        f'border-radius:8px">'
                        f'<input type="text" name="note" placeholder="메모(선택, 예: 회의에서 공유함)" '
                        f'style="padding:8px 10px;border:1px solid var(--border2);'
                        f'border-radius:8px;width:240px">'
                        # 제목은 '미확인 5건'인데 단추는 '10건 모두'라 같은 화면이 두 숫자를
                        # 주장했다 — 첫 등록이 몇 건 섞였는지 단추에도 밝힌다
                        # (2026-09-09 웹 검토 차단 3). 확인 기록은 지울 수 없으므로 많으면 되묻는다
                        f'<button class="btn"'
                        f'{f" onclick=\"return confirm(&#39;{len(rows)}건을 모두 확인 처리합니다. 확인 기록은 지울 수 없습니다. 계속할까요?&#39;)\"" if len(rows) > 20 else ""}'
                        f'>이 목록 {len(rows)}건 모두 확인 처리</button>'
                        f'<div class="muted" style="margin-top:6px">잘못 눌렀다면 각 변경에 '
                        f"'정정' 메모로 새 확인을 남겨주세요 (기록은 지워지지 않습니다)."
                        f"</div></form></div>")
        else:
            title = f"전체 이력{f' — {_E(proj)}' if proj else ''}"
            intro = "모든 변경 기록과, 누가 언제 어떤 메모로 확인했는지의 전체 이력입니다."
        # 수만 건 규모 대비: 파일명·프로젝트 즉시 검색 (2026-08-29).
        # 500건이 넘으면 이 칸이 찾는 범위를 안내문에 못박는다 — DB에 있는 파일명을
        # 넣어도 안 나와 "없다"고 결론내던 것 (2026-09-09 웹 검토 중간 6)
        _ph = ("화면에 나온 500건에서 찾기…" if len(rows) > 500
               else "파일명·프로젝트 검색…")
        search = (f'<input type="text" placeholder="{_ph}" '
                  'oninput="pwFilterRows(this,\'hist-t\')" '
                  'style="min-width:240px">') if len(rows) > 20 else ""
        xlsx_btn = (f'<a class="btn gray" style="text-decoration:none" '
                    f'href="/export{f"?p={quote(proj)}" if proj else ""}" '
                    f'title="변경·확인 이력 전체를 엑셀 파일로 저장">'
                    f'엑셀 내려받기</a>')
        body = (f'<div class="topbar"><h1>{title}</h1>'
                f'<div style="display:flex;gap:10px;align-items:center;'
                f'flex-wrap:wrap">{search}{xlsx_btn}'
                + _filter_bar("/history", projects, proj,
                              extra="ack=none&" if ack_filter == "none" else "")
                + "</div></div>" + _intro(intro)
                + f'<div class="panel">'
                f'{_rows_table(rows, 500, table_id="hist-t", tok=self.csrf(),
                              notes=_side_note_map(self.db()))}'
                f'</div>' + bulk)
        # 탭·방문기록에서 '전체 이력'과 '미확인 모아보기'가 구분되지 않던 것 (웹 검토 낮음)
        return _page("미확인 변경" if ack_filter == "none" else "전체 이력",
                     "/history", body, self.pop_msg())

    def file_evidence(self, change) -> str:
        """파일 수준 근거 표 — 내용 비교가 없거나 실패해도 이것만은 보여 준다(원칙 4)."""
        if change is None:
            return ""
        try:
            with State(self.db()) as st:
                facts = st.file_facts(change.path)
                mt_new, mt_old = st.change_mtimes(change.id) if change.id is not None else (None, None)
        except Exception:
            facts, mt_new, mt_old = [], None, None
        # 최신 스냅샷 기록(file_facts)은 '지금 파일'의 것이다 — 옛 변경(기준선·첫 등록)의 근거 표가 오늘 판을
        # '이번 판'이라 불렀다 (검토27 A-1). 그 변경의 판과 일치하는 기록만 쓰고, 시각은 변경 기록의 것을 앞세운다
        facts = [f for f in facts if f.get("sha256") in (change.new_sha256, change.old_sha256)]
        facts.sort(key=lambda f: f.get("sha256") != change.new_sha256)     # 이번 판 먼저

        def _size(n) -> str:
            try:
                n = int(n)
            except (TypeError, ValueError):
                return "—"
            return f"{n:,}바이트" + (f" ({n / 1048576:.1f}MB)" if n >= 1048576 else "")

        def _mtime(v) -> str:
            try:
                return datetime.fromtimestamp(float(v)).strftime("%Y-%m-%d %H:%M:%S")
            except (TypeError, ValueError, OSError):
                return "—"
        rows = [f'<tr><td>지문(SHA-256)</td><td><code>{_E((change.old_sha256 or "—")[:16])}'
                f'</code> → <code>{_E((change.new_sha256 or "—")[:16])}</code></td></tr>',
                f'<tr><td>파일 경로</td><td><code>{_E(change.path)}</code></td></tr>']
        if mt_new or mt_old:
            rows.append(f'<tr><td>저장(수정) 시각</td><td>이번 판 {_mtime(mt_new) if mt_new else "—"}'
                        + (f' · 이전 판 {_mtime(mt_old)}' if mt_old else "") + '</td></tr>')
        elif not facts:
            # 저장 시각 기록(v0.57.8)보다 앞선 변경 — 지문 외엔 남은 기록이 없다 (검토28 B 낮음)
            rows.append('<tr><td>크기·저장 시각</td><td class="muted">이 변경은 저장 시각을 기록하기 전(v0.57.8 이전) '
                        '것이라 남은 기록이 없습니다 — 지문만 확정됩니다</td></tr>')
        for f in facts:
            which = "이번" if f.get("sha256") == change.new_sha256 else "이전"
            rows.append(f'<tr><td>{which} 판 크기</td>'
                        f'<td>{_size(f["size"])} '
                        f'<span class="muted">(검사 {_E(_local(f["run_at"]))}, 저장 {_mtime(f["mtime"])})</span>'
                        f'</td></tr>')
        return ('<div class="scrolly" style="margin-top:8px"><table class="rtab">'
                '<tr><th>근거</th><th>값</th></tr>' + "".join(rows) + '</table></div>'
                '<p class="muted">내용을 비교하지 못했더라도 <b>바뀐 사실</b>은 위 지문으로 '
                '확정됩니다. 무엇이 바뀌었는지는 [파일 열기]로 확인하세요.</p>')

    def page_preview(self, key: str) -> str:
        """추출 미리보기: 파일 하나를 즉석 추출해 표제란·귀속 결과를 보여준다."""
        back = '<p><a href="/settings" style="color:var(--link)">← 설정으로</a></p>'
        if not key:
            return _page("추출 미리보기", "/settings",
                         f'<div class="topbar"><h1>추출 미리보기</h1></div>'
                         f'<div class="panel"><p>설정 화면에서 파일을 선택하세요.</p>{back}</div>')
        ap = self.abs_path_of(key)
        if ap is None:
            return _page("추출 미리보기", "/settings",
                         f'<div class="topbar"><h1>추출 미리보기</h1></div>'
                         f'<div class="panel"><p>파일을 찾을 수 없습니다: {_E(key)}</p>'
                         f'<p class="muted">최근 검사에 잡힌 경로(자동완성 목록)를 사용하세요.</p>'
                         f"{back}</div>")
        from watcher.cli import _root_labels
        from watcher.extract import extract
        from watcher.project import ProjectResolver
        cfg = self.cfg()
        from watcher.extract import pdf as _pdf_mod
        from watcher.extract import xlsx as _xlsx_mod          # 미리보기도 설정한 키 열로
        _xlsx_mod.USER_KEY_COLS = tuple(str(c).strip() for c in (cfg.get("key_columns") or []) if str(c).strip())
        _pdf_mod.OCR_ENABLED = bool(cfg.get("ocr", True))      # 미리보기도 검사와 같은 OCR 설정으로 (사용성 5차)
        _pdf_mod._ctx.max_pages = 3                              # 이 요청 스레드만 3쪽 (리뷰12 운영 낮음-4 / 리뷰13 낮음-7)
        try:
            doc = extract(ap)
        except Exception as e:
            _pdf_mod._ctx.max_pages = _pdf_mod.OCR_MAX_PAGES
            return _page("추출 미리보기", "/settings",
                         f'<div class="topbar"><h1>추출 미리보기</h1></div>'
                         f'<div class="panel"><p>추출 실패: {_E(e)}</p>{back}</div>')

        _pdf_mod._ctx.max_pages = _pdf_mod.OCR_MAX_PAGES
        resolver = self._resolver([r for r in cfg["roots"] if Path(r).is_dir()])
        proj, how = resolver.attribute(key, doc)

        if doc is None:
            body_main = ('<div class="panel"><p>이 파일 형식은 내용 추출 대상이 아닙니다 '
                         '(파일 수준 변경 감지만 됩니다).</p></div>')
        else:
            fields = "".join(
                f"<tr><td><strong>{_E(f.name)}</strong></td><td>{_E(f.value)}</td>"
                f"<td class='muted'>{_E(f.where)}</td></tr>"
                for f in doc.fields.values()) or \
                ('<tr><td colspan="3" style="color:var(--warn3)">표제란을 찾지 못했습니다 — '
                 "도면 양식이 다르면 알려주세요. 파일명·폴더 기준으로는 계속 감시됩니다."
                 "</td></tr>")
            revrows = "".join(
                f"<tr><td>{_E(r.key)}</td><td>{_E(r.values.get('DATE', ''))}</td>"
                f"<td>{_E(r.values.get('DESCRIPTION', ''))}</td></tr>"
                for r in doc.revision_history)
            sample = "".join(f"<li>{_E(t.text)} <span class='muted'>({_E(t.where)})</span></li>"
                             for t in doc.raw_texts[:8])
            n_rows = len(doc.rows)
            ocr_note = ("" if not any("OCR" in str(getattr(x, "where", "")) for x in list(doc.fields.values()) + list(doc.raw_texts)) else
                        '<div class="panel" style="border-left:4px solid var(--warn)"><b>OCR 추정값</b> — 이 파일의 글자는 '
                        'Windows OCR로 그림에서 읽은 것이라 O/0·I/1처럼 틀릴 수 있습니다. 위치의 "OCR"이 그 표시입니다.</div>')
            body_main = ocr_note + f"""
<div class="panel"><h2>표제란 추출 결과</h2>
<table><tr><th>필드</th><th>값</th><th>위치</th></tr>{fields}</table></div>
{f'<div class="panel"><h2>리비전 블록</h2><table><tr><th>Rev</th><th>일자</th><th>내용</th></tr>{revrows}</table></div>' if revrows else ''}
{f'<div class="panel"><h2>표 데이터</h2><p>{n_rows}행 인식 (BOM 비교 대상)</p></div>' if n_rows else ''}
<div class="panel"><h2>본문 텍스트 표본 (총 {len(doc.raw_texts)}줄)</h2>
<ul style="font-size:13px">{sample}</ul></div>"""

        body = (f'<div class="topbar"><h1>추출 미리보기</h1></div>'
                + _intro(f"{_E(key)} — 이 파일에서 무엇을 읽어내는지 보여줍니다.")
                + f'<div class="panel"><h2>소속 프로젝트 (어느 프로젝트 것인지)</h2>'
                f"<p><strong>{_E(proj)}</strong> <span class='muted'>(근거: {_E(how)})</span></p></div>"
                + body_main + f'<div class="panel">{back}</div>')
        return _page("추출 미리보기", "/settings", body)

    def page_change(self, change_id_s: str, ack_name: str = "") -> str:
        """변경 1건 상세: 무엇이 어떻게 바뀌었나 + 위치 캡처. 목록에서 클릭해 진입.
        ack_name: 최근 확인자 이름(쿠키) — 매번 재입력하지 않게 미리 채운다."""
        try:
            change_id = int(change_id_s)
            if not (0 <= change_id < 2 ** 62):
                raise ValueError(change_id_s)             # sqlite OverflowError로 연결이 끊겼다 (1회차 7)
        except ValueError:
            return _page("변경 상세", "/", '<div class="panel"><p>잘못된 번호입니다.</p></div>')
        with State(self.db()) as st:
            change = st.get_change(change_id)
            detail = st.change_detail(change_id)
            acks = st.acks_of(change_id)     # 전체 이력을 올리지 않는다 (색인 질의)
            newx = st.load_extract(change.new_sha256) if change else None
            # 짝 상태 + 직접 지정 후보 (2026-08-29 수동 짝짓기)
            mp, prevk, prev_why, cands, same_copy = None, None, "", [], []
            if change is not None:
                from watcher.cli import find_prev_version
                mp = st.manual_pair(change.path)
                prevk, _ps, prev_why = find_prev_version(st, change.path)
                ext0 = PurePosixPath(change.path).suffix.lower()
                par0 = str(PurePosixPath(change.path).parent)
                latest = st._latest_rows()
                cands = [k for k in latest
                         if k != change.path
                         and PurePosixPath(k).suffix.lower() == ext0]
                # 내용이 똑같은 다른 파일(복사본) — 요약은 "X와 같은 복사본"이라면서 아래는
                # "이전 판을 찾지 못했습니다"라 모순으로 읽혔다 (파일럿 모의 5차 ⑤)
                same_copy = [k for k, v in latest.items()
                             if k != change.path and change.new_sha256
                             and v[0] == change.new_sha256]
                # 같은 폴더 파일이 먼저 뜨게 — 대부분의 지정은 같은 폴더 안
                cands.sort(key=lambda k: (str(PurePosixPath(k).parent) != par0, k))
                cands = cands[:400]
        if change is None:
            return _page("변경 상세", "/",
                         f'<div class="panel"><p>변경 #{change_id}이 없습니다.</p></div>')
        # 실무 언어(도면번호·Rev)와 공식 개정 사유 — 표제란·리비전 블록에서
        # 이미 읽어둔 값을 앞세운다 (설계 10년차 검토, 2026-08-28)
        flds = (newx or {}).get("fields") or {}
        dwg = (flds.get("DWG_NO") or {}).get("value")
        cur_rev = (flds.get("REV") or {}).get("value")
        revhist = (newx or {}).get("revision_history") or []
        rev_note = (revhist[-1].get("values", {}).get("DESCRIPTION")
                    if revhist else None)
        # 사람이 직접 남긴 '놓친 변경' 기록 — 상세가 없어도 남길 수 있다 (미탐 대응)
        user_notes = (detail or {}).get("user_notes") or []

        if acks:
            ack_html = "".join(
                f'<span class="tag done">확인</span> {_E(a["ack_by"])}'
                + (f' — {_E(a["ack_note"])}' if a["ack_note"] else "")
                + f' <span class="muted">({_E(_local(a["ack_at"]))})</span><br>'
                for a in acks)
            ack_html += ('<form method="post" action="/change/ack" style="margin-top:10px">'
                         f'{self._tok()}'
                         f'<input type="hidden" name="id" value="{change_id}">'
                         '<input type="hidden" name="back" class="ackback" value="">'
                         f'<input type="text" name="by" placeholder="이름" required '
                         f'value="{_E(_ack_default(ack_name))}" '
                         'style="border:1px solid var(--border2);border-radius:8px;padding:6px 10px">'
                         '<input type="text" name="note" placeholder="메모(선택)" '
                         'style="border:1px solid var(--border2);border-radius:8px;padding:6px 10px;width:220px">'
                         '<button class="btn gray">확인 추가</button></form>')
        else:
            ack_html = (
                '<span class="tag na">미확인</span>'
                '<form method="post" action="/change/ack" style="margin-top:10px">'
                f'{self._tok()}'
                f'<input type="hidden" name="id" value="{change_id}">'
                f'<input type="text" name="by" placeholder="확인자 이름" required '
                f'value="{_E(_ack_default(ack_name))}" '
                'style="border:1px solid var(--border2);border-radius:8px;padding:8px 10px">'
                '<input type="text" name="note" placeholder="한 줄 메모 (선택)" '
                'style="border:1px solid var(--border2);border-radius:8px;padding:8px 10px;width:260px">'
                '<button class="btn">확인함</button>'
                '<button class="btn gray" name="go" value="next" style="margin-left:6px" '
                'title="이 건을 확인하고 아직 확인하지 않은 다음 변경으로 바로 넘어갑니다">'
                '확인하고 다음 →</button></form>')

        # 확인 단추가 표 뒤 맨 아래에만 있어 큰 변경(표 500행)은 스크롤 50번 뒤에야 나왔다
        # (검토22 UI 차단 2) — 미확인이면 요약 바로 아래에도 같은 단추를 둔다
        is_base = any(r["change_id"] == change_id and r.get("baseline") for r in self.rows())
        ack_top = ("" if (acks or is_base) else
                   f'<div class="panel" id="ack-top" style="border-left:4px solid var(--accent)">'
                   f'<p style="margin:0 0 6px"><b>확인</b> <span class="muted">— 아래 근거를 보고 '
                   f'누르세요. 표가 길면 같은 단추가 맨 아래에도 있습니다.</span></p>'
                   f'<div class="ackbar">{ack_html}</div></div>')

        if detail is None:
            reason = ("삭제된 파일은 내용 비교가 없습니다 — 마지막 판까지의 이력은 "
                      "위 파일명으로 전체 이력에서 볼 수 있습니다."
                      if change.kind == "removed" else
                      "이전 판이 없는 새 파일이라 비교할 대상이 없습니다 — 내용은 [파일 열기]로 확인하세요."
                      if change.kind == "added" else
                      "첫 등록(기준선)이거나 내용 추출 대상이 아닌 파일입니다.")
            body_main = (f'<div class="panel"><p class="muted">이 변경에는 내용 비교 '
                         f"기록이 없습니다 — {reason}</p>"
                         f"{self.file_evidence(change)}</div>")
        else:
            from watcher.brief import (_row_diff_table, item_diff_table,
                                       split_display_items)
            from watcher.diff import ChangeItem
            all_items = [ChangeItem(**d) for d in detail["items"]]
            caps = detail["captures"]
            dismissed = detail.get("dismissed") or {}
            idx_of = {id(it): ix for ix, it in enumerate(all_items)}
            # 오탐으로 숨긴 항목은 화면·요약에서 제외 (복원 가능 — 원칙 5)
            items = [it for ix, it in enumerate(all_items)
                     if str(ix) not in dismissed]
            hidden = [(ix, it) for ix, it in enumerate(all_items)
                      if str(ix) in dismissed]

            ocr_notice = ('<div class="panel" style="border-left:4px solid var(--warn)"><b>OCR 추정값</b> — 이 파일의 글자는 '
                          'Windows OCR로 그림에서 읽은 것이라 O/0·I/1처럼 틀릴 수 있습니다. 전/후 사진으로 확인하세요.</div>'
                          if any("OCR" in str(it.where or "") for it in items) else "")

            def cap_of(i):
                # 신형 키(kind|key) 우선, 구형 저장분은 key만으로 폴백
                return caps.get(f"{i.kind}|{i.key}") or caps.get(i.key)

            def _dismiss_form(i) -> str:
                return (f'<form class="inline" method="post" action="/change/dismiss">'
                        f'{self._tok()}'
                        f'<input type="hidden" name="id" value="{change_id}">'
                        f'<input type="hidden" name="idx" value="{idx_of[id(i)]}">'
                        f'<button class="btn gray" title="오탐이면 숨깁니다 (복원 가능)" '
                        f'style="font-size:12px;padding:2px 8px">오탐 삭제</button></form>')

            # 로컬 화면은 넉넉히(400) — '전체 볼 곳'이 여기다
            notice_items, regular, commons, row_items, omitted = \
                split_display_items(items, cap_of, 400)

            # 보고용 한 줄 요약 — 신입이 선배에게 그대로 전달할 수 있게 (2026-08-26)
            vis_n = sum(1 for i in items if i.kind == "PAGE_VISUAL_CHANGED")
            txt_n = sum(1 for i in items if i.kind.startswith("TEXT_"))
            row_n = sum(1 for i in items if i.kind.startswith("ROW_"))
            rev_i = next((i for i in items
                          if i.kind == "FIELD_CHANGED" and i.key == "REV"), None)
            parts = []
            if rev_i:
                parts.append(f"Rev {rev_i.old}→{rev_i.new}")
            if vis_n:
                parts.append(f"그림 변경 위치 {vis_n}곳")
            if txt_n:
                parts.append(f"글자 변경 {txt_n}건")
            if row_n:
                from watcher.brief import table_label as _tl
                parts.append(f"{_tl(change.path)} 변경 {row_n}건")
            if user_notes:
                parts.append(f"사람 기록 {len(user_notes)}건")
            head = (f"도면 {dwg}" if dwg else PurePosixPath(change.path).name)
            if not parts:
                # 내용을 못 읽는 파일 — "내용 비교 기록 참조"는 참조할 것이 없는 빈 말이었다
                # (파일럿 모의 4차). 크기·저장 시각이나 참고 문구를 그대로 쓴다
                parts += [f"{i.key} {i.old} → {i.new}" for i in items
                          if i.kind == "FIELD_CHANGED" and i.key in ("파일 크기", "저장 시각")]
                if not parts:
                    note = next((str(i.new) for i in items
                                 if i.kind == "CHECK_SKIPPED" and i.key == "참고" and i.new), None)
                    if note:
                        parts.append(note.split(" — ")[0])
            summary_text = (f"{head}: "
                            f"{', '.join(parts) if parts else '변경 사실만 기록됨 (내용 비교 불가)'}")
            if dwg:
                summary_text += f" ({PurePosixPath(change.path).name})"
            # 리비전 행이 이번 변경에서 새로 생겼을 때만 — 옛 행을 인용하면 되돌림에서
            # 반대 방향 사유("5.5->7.5")가 보고서에 실린다 (2026-09-03 검토)
            if rev_note and any(i.kind == "REVROW_ADDED" for i in items):
                summary_text += f" · 개정 사유: {rev_note}"

            body_main = ocr_notice + (
                f'<div class="panel"><h2>보고용 요약</h2>'
                f'<p id="chg-summary" style="margin:0">{_E(summary_text)}</p>'
                # .catch가 없어 클립보드가 막히면 아무 반응 없이 끝났다 —
                # 눌렀는데 아무 일도 안 일어나는 단추다 (2026-09-09 웹 검토 낮음 11)
                f'<button class="btn gray" style="margin-top:8px" '
                f'onclick="pwCopy(this,\'chg-summary\')">요약 복사</button></div>')
            body_main += "".join(
                f'<div class="panel" style="background:var(--note-warn);color:var(--warn2)">'
                f'<b>{_E(i.key)}</b> — {_E(_plain_engine_error(i.new or ""))}</div>'
                for i in notice_items)  # 검사 한계 고지는 안내 박스로
            # 비교를 못 한 건에는 파일 수준 근거라도 붙인다 — 전에는 엔진 오류 한 줄이
            # 전부였고 지문·크기·수정 시각이 어디에도 없었다 (웹 검토 중간 8)
            # 못 읽는 형식의 새 문구("…읽지 못합니다")에도 붙인다 — 지문은 이 판에만 있다 (검토18 ⑤)
            if any("수행 못 함" in str(i.new or "") or i.where == "파일 수준 감시"
                   for i in notice_items):
                body_main += (f'<div class="panel"><h2>파일 수준 근거</h2>'
                              f'{self.file_evidence(change)}</div>')
            if regular:
                body_main += (f'<div class="panel"><h2>바뀐 내용</h2>'
                              f'{_web_item_table(regular, cap_of=cap_of, extra_cell=_dismiss_form)}'
                              f'</div>')
            if commons:
                body_main += (f'<div class="panel"><details><summary style="cursor:pointer;'
                              f'color:var(--muted)">전 페이지 공통 변경(표제란·양식류) '
                              f'{len(commons)}건 — 펼쳐 보기</summary>'
                              f'{_web_item_table(commons, cap_of=cap_of, extra_cell=_dismiss_form)}'
                              f'</details></div>')
            if row_items:
                from watcher.brief import bom_impact_line, table_label
                body_main += (f'<div class="panel">'
                              f'<h2>{_E(table_label(change.path))} 변경</h2>'
                              f"{bom_impact_line(row_items, web=True, label=_impact_label(change.path))}"
                              f"{_web_row_table(row_items, extra_cell=_dismiss_form)}"
                              f"</div>")
            if omitted:
                body_main += (f'<div class="panel"><p class="muted">외 {omitted}건 생략 — '
                              "변경이 매우 많은 문서라 일부만 표시했습니다."
                              "</p></div>")
            if hidden:
                his = "".join(
                    f'<li style="margin:4px 0"><code>{_E(it.key)}</code>: '
                    f'{_E(it.old or "—")} &rarr; {_E(it.new or "—")} '
                    f'<span class="muted">— {_E(dismissed[str(ix)].get("by", "-"))}'
                    f' 숨김 {_E(_local(dismissed[str(ix)].get("at")))}</span> '
                    f'<form class="inline" method="post" action="/change/restore">'
                    f'{self._tok()}'
                    f'<input type="hidden" name="id" value="{change_id}">'
                    f'<input type="hidden" name="idx" value="{ix}">'
                    f'<button class="btn gray" style="font-size:12px;padding:2px 8px">'
                    f'복원</button></form></li>'
                    for ix, it in hidden)
                body_main += (f'<div class="panel"><details><summary style="cursor:pointer;'
                              f'color:var(--muted)">오탐으로 숨긴 항목 {len(hidden)}건 — '
                              f'펼쳐 보기 / 복원</summary>'
                              f'<ul style="padding-left:18px;font-size:13px">{his}</ul>'
                              f'</details></div>')
            if not body_main:
                body_main = '<div class="panel"><p class="muted">기록된 상세 항목이 없습니다.</p></div>'

        # 놓친 변경 기록 패널 — 프로그램이 인식 못한 변경을 사람이 보완한다
        # (오탐 숨김의 반대쪽. 기록은 /notes 리포트에 모여 감지 개선 신호가 된다)
        nls = "".join(
            f'<li style="margin:6px 0"><span class="tag modified">사람 기록</span> '
            f'<b>{_E(n.get("where") or "위치 미지정")}</b> — {_E(n.get("text", ""))} '
            f'<span class="muted">{_E(n.get("by", "-"))} · '
            f'{_E(_local(n.get("at")))}</span> '
            f'<form class="inline" method="post" action="/change/note/del">'
            f'{self._tok()}'
            f'<input type="hidden" name="id" value="{change_id}">'
            f'<input type="hidden" name="idx" value="{ix}">'
            f'<button class="btn gray" style="font-size:12px;padding:2px 8px">'
            f'삭제</button></form></li>'
            for ix, n in enumerate(user_notes))
        note_panel = (
            '<div class="panel"><h2>놓친 변경 기록</h2>'
            '<p class="muted" style="margin-top:0">프로그램이 잡지 못한 변경을 직접 '
            '남기는 곳입니다. 보고용 요약에 "사람 기록"으로 함께 집계되고, '
            '<a href="/notes" style="color:var(--link)">놓친 변경 리포트</a>에 모여 '
            '감지를 개선하는 신호가 됩니다.</p>'
            + (f'<ul style="padding-left:18px;font-size:13.5px">{nls}</ul>' if nls else "")
            + f'<form method="post" action="/change/note/add">{self._tok()}'
              f'<input type="hidden" name="id" value="{change_id}">'
              '<input type="text" name="where" maxlength="100" '
              'placeholder="위치 (예: 3페이지 우상단)" '
              'style="border:1px solid var(--border2);border-radius:8px;padding:6px 10px">'
              '<input type="text" name="text" maxlength="300" '
              'placeholder="무엇이 바뀌었나" required '
              'style="border:1px solid var(--border2);border-radius:8px;padding:6px 10px;'
              'width:280px">'
              '<button class="btn">기록</button></form></div>')

        # 직접 확인 도구 — 소급 재비교·민감 재비교·전/후 나란히 보기·원본 열기.
        # 감지가 놓쳐도 사람이 원본까지 갈 길을 항상 열어둔다 (미탐 대응, 2026-08-27)
        # 배치 원칙(2026-08-29): ①지금 무엇과 비교되나(상태 한 줄) ②아니면 직접
        # 지정 ③그 다음에 동작 버튼 — 보자마자 이해되는 순서로.
        if prevk:
            if mp and mp["prev_key"] == prevk:
                how = (f'<span class="tag done">사람 지정</span> '
                       f'<span class="muted">{_E(mp["by"])} · '
                       f'{_E(_local(mp["at"], "%m-%d"))}</span> '
                       f'<form class="inline" method="post" '
                       f'action="/change/pair/clear">{self._tok()}'
                       f'<input type="hidden" name="id" value="{change_id}">'
                       f'<button class="btn gray" style="font-size:12px;'
                       f'padding:2px 8px">지정 해제</button></form>')
            else:
                how = '<span class="tag na">자동 인식</span>'
            pair_line = (f'이전 판: <b title="{_E(prevk)}">'
                         f'{_E(PurePosixPath(prevk).name)}</b> {how}')
        else:
            if change.old_sha256:
                # 덮어쓴 파일: 이전 판 '파일'은 없지만 비교는 기록으로 했다 — 바로 위 비교
                # 결과와 모순으로 읽히던 문구 (2026-09-05 전체 검토)
                pair_line = ('<span class="muted">같은 이름으로 덮어쓴 파일이라 이전 판 파일은 '
                             '따로 없습니다 — 비교는 검사 때 기록한 이전 판 내용·그림으로 했습니다. '
                             '다른 파일을 이전 판으로 지정하려면 아래에서 고르세요.</span>')
            elif same_copy:
                pair_line = (f'<span class="muted">비교할 이전 판이 없습니다 — 이 파일은 '
                             f'<b title="{_E(same_copy[0])}">{_E(PurePosixPath(same_copy[0]).name)}</b>'
                             f'와 내용이 같은 복사본이라 차이가 없습니다. 다른 파일과 비교하려면 '
                             f'아래에서 고르세요.</span>')
            else:
                pair_line = (f'<span style="color:var(--warn)">이전 판을 찾지 '
                             f'못했습니다</span> <span class="muted">— '
                             f'{_E(prev_why)}</span>')
        pick_form = (
            f'<form method="post" action="/change/pair/set" '
            f'style="margin-top:6px">{self._tok()}'
            f'<input type="hidden" name="id" value="{change_id}">'
            f'<input type="text" name="prev" list="prevpick" required '
            f'placeholder="이전 판 파일 선택 (입력하면 자동완성)" '
            f'style="width:420px;max-width:100%">'
            f'<datalist id="prevpick">'
            + "".join(f'<option value="{_E(k)}">' for k in cands)
            + '</datalist> <button class="btn">지정하고 비교</button>'
            f'<div class="muted" style="margin-top:4px">같은 확장자만 지정 '
            f'가능하고, 폴더가 달라도 됩니다. 잘못 지정하면 [지정 해제]로 '
            f'되돌립니다.</div></form>')
        if prevk:
            picker = (f'<details style="margin:4px 0 10px"><summary '
                      f'class="muted" style="font-size:12.5px;cursor:pointer">'
                      f'다른 파일을 이전 판으로 직접 지정</summary>'
                      f'{pick_form}</details>')
        else:
            picker = f'<div style="margin:4px 0 10px">{pick_form}</div>'
        has_pair = detail is not None and any(
            d.get("kind") == "NEW_REVISION_OF" for d in detail["items"])
        is_pdf = change.path.lower().endswith(".pdf")
        tools = []
        if change.kind in ("added", "modified"):
            if not has_pair:
                tools.append(
                    f'<form class="inline" method="post" action="/change/recompare">'
                    f'{self._tok()}'
                    f'<input type="hidden" name="id" value="{change_id}">'
                    f'<button class="btn">이전 판 찾아 다시 비교</button></form> '
                    f'<span class="muted">같은 폴더에서 이 파일의 이전 판(날짜·버전 '
                    f'표기 제외 이름 동일)을 찾아 소급 비교합니다.</span><br>')
            if is_pdf:
                tools.append(
                    f'<a class="btn gray" style="text-decoration:none" '
                    f'href="/compare?id={change_id}&amp;page=1">전/후 페이지 나란히 보기'
                    f'</a> <span class="muted">감지 결과와 무관하게 두 판의 전체 '
                    f'페이지를 눈으로 직접 비교합니다.</span><br>')
                tools.append(
                    f'<form class="inline" method="post" action="/change/recompare">'
                    f'{self._tok()}'
                    f'<input type="hidden" name="id" value="{change_id}">'
                    f'<input type="hidden" name="sens" value="1">'
                    f'<button class="btn gray">더 민감하게 다시 비교</button></form> '
                    f'<span class="muted">작은 점·가는 선 수준의 미세 변경까지 '
                    f'잡습니다 — 오탐이 늘면 [오탐 삭제]로 정리하세요.</span><br>')
            tools.append(
                f'<form class="inline" method="post" action="/change/open">'
                f'{self._tok()}'
                f'<input type="hidden" name="id" value="{change_id}">'
                f'<button class="btn gray" name="which" value="new">원본 열기</button> '
                f'<button class="btn gray" name="which" value="old">이전 판 열기</button> '
                f'<button class="btn gray" name="which" value="folder">폴더 열기</button>'
                f'</form> <span class="muted">이 PC의 기본 프로그램으로 엽니다'
                + ('.' if is_pdf else ' — DXF는 CAD에서 두 판을 직접 비교하세요.')
                + '</span>')
        tools.append(
            f'<br><form class="inline" method="post" action="/exclude/file" onsubmit="return confirm(&quot;이 파일을 감시에서 뺍니다. (설정에서 되돌릴 수 있습니다) 계속할까요?&quot;)">'
            f'{self._tok()}'
            f'<input type="hidden" name="key" value="{_E(change.path)}">'
            f'<button class="btn gray" title="관리할 필요 없는 파일이면 감시에서 '
            f'뺍니다 (설정에서 언제든 되돌릴 수 있습니다)">이 파일 감시 안 함'
            f'</button></form> <span class="muted">관리 대상이 아니면 빼두세요 — '
            f'다음 검사부터 알림이 오지 않고, [설정]에서 되돌릴 수 있습니다.</span>')
        # 매일 쓰는 사람에겐 버튼 6개가 잡음 — 접힌 '고급'으로 (2026-09-05 전체 검토)
        recmp = (f'<div class="panel"><details><summary style="font-size:12px;font-weight:700;'
                 f'text-transform:uppercase;letter-spacing:.7px;cursor:pointer">고급 — 직접 확인 도구'
                 f' <span class="muted" style="text-transform:none;letter-spacing:0;font-weight:400">'
                 f'(이전 판 지정 · 다시 비교 · 더 민감하게 · 원본 열기)</span></summary>'
                 f'<p style="margin:8px 0 2px;font-size:13.5px">{pair_line}</p>'
                 f'{picker}'
                 f'<p style="line-height:2.4;margin:0">{"".join(tools)}</p></details></div>'
                 if tools else "")
        dwg_line = ""
        if dwg or cur_rev:
            dwg_line = (" · " + (f"도면 <b>{_E(dwg)}</b>" if dwg else "")
                        + (f" Rev <b>{_E(cur_rev)}</b>" if cur_rev else ""))
        # 문서를 언제 고쳤나 — 검사 시각과 별개인 파일 저장 시각 (2026-09-17 사용자 요청). 그 변경이
        # 기록된 순간의 값(changes.mtime) — 최신 스냅샷의 값은 다른 판의 시각이었다 (5회차 B1-2)
        try:
            with State(self.db()) as st:
                _mt_new, _mt_old = st.change_mtimes(change_id)
        except Exception:
            _mt_new, _mt_old = None, None
        facts_ = ([{"mtime": _mt_new}] if _mt_new else []) + ([{"mtime": _mt_old}] if _mt_old else [])
        if _mt_new and change.kind != "removed":
            dwg_line += f" · 저장 <b>{_E(_mtime_str(_mt_new))}</b>"
            if _mt_old:
                dwg_line += f' <span class="muted">(이전 판 {_E(_mtime_str(_mt_old))})</span>'
        _pp = PurePosixPath(change.path)
        _chips = [f'<span class="chip">프로젝트 <b>{_E(change.project or "미분류")}</b></span>']
        if dwg:
            _chips.append(f'<span class="chip">도면 <b>{_E(dwg)}</b></span>')
        if cur_rev:
            _chips.append(f'<span class="chip">Rev <b>{_E(cur_rev)}</b></span>')
        if facts_ and facts_[0].get("mtime") and change.kind != "removed":
            _chips.append(f'<span class="chip">저장 <b>{_E(_mtime_str(facts_[0]["mtime"]))}</b>'
                          + (f' <span class="muted">(이전 판 {_E(_mtime_str(facts_[1]["mtime"]))})</span>'
                             if len(facts_) > 1 and facts_[1].get("mtime") else "") + '</span>')
        _chips.append(f'<span class="chip">변경 번호 <b>#{change_id}</b></span>')
        head_card = (f'<div class="chg-head"><div class="fname">{_kind_tag(change.kind)} {_E(_pp.name)}</div>'
                     f'<div class="cpath">{_E(" › ".join(_pp.parts[:-1]))}</div>'
                     f'<div class="chips">{"".join(_chips)}</div></div>')
        body = (head_card
                # 보러 온 것(바뀐 내용)이 먼저, 확인, 도구는 맨 뒤 (2026-09-02 처음 보는 사람
                # 검토: 상세 9개 전부 경고문+버튼 6개로 시작해 길을 잃는다).
                # 미확인이면 확인 단추 한 벌을 요약 아래에도 (검토22 UI 차단 2)
                + ack_top
                + body_main
                + f'<div class="panel"><h2>확인 상태</h2><p>{ack_html}</p>'
                  '<p class="muted" style="margin-top:8px">잘못 눌렀다면: 확인 기록은 '
                  "지워지지 않으니, '정정' 메모를 담아 새 확인을 남겨주세요.</p></div>"
                + recmp
                + note_panel
                + '<div class="panel"><p><a href="javascript:history.back()" '
                'style="color:var(--link)">← 뒤로</a></p></div>'
                # 확인한 뒤 들어온 목록으로 돌아가게 — 같은 출처의 이전 화면 경로를 싣는다
                + '<script>(function(){try{var r=document.referrer;if(!r)return;var u=new URL(r);'
                'if(u.origin!==location.origin||u.pathname==="/change")return;'
                'document.querySelectorAll("input.ackback").forEach(function(i){i.value=u.pathname+u.search;});'
                '}catch(e){}})();</script>')
        return _page(f"변경 #{change_id}", "/", body, self.pop_msg())

    def export_xlsx(self, proj: str | None = None) -> bytes:
        """변경·확인 이력 전체를 엑셀로 — 주간 보고·결재 첨부용 (2026-08-29 요청).
        디스크에 쓰지 않고 메모리로 만들어 브라우저 다운로드로만 전달."""
        import io

        from openpyxl import Workbook
        with State(self.db()) as st:
            rows = st.history(proj)
            notes: dict[int, list[str]] = {}
            for n in st.list_user_notes():
                notes.setdefault(n["change_id"], []).append(
                    f'[{n.get("where") or "-"}] {n["text"]} ({n.get("by", "-")})')
        wb = Workbook()
        ws = wb.active
        ws.title = "변경 이력"
        header = ["번호", "일시", "구분", "유형", "프로젝트", "폴더", "파일명",
                  "확인자", "확인 일시", "확인 메모", "놓친 변경 기록(사람)"]
        ws.append(header)

        for r in rows:
            p = PurePosixPath(r["path"])
            ws.append([
                r["change_id"], _local(r["detected_at"]),
                KIND_LABEL.get(r["kind"], r["kind"]), _cat_display(r["path"]),
                r["project"] or "미분류", str(p.parent), p.name,
                r["ack_by"] or "", _local(r["ack_at"]) if r["ack_at"] else "",
                r["ack_note"] or "",
                " / ".join(notes.get(r["change_id"], []))])
            # '=HYPERLINK(...)' 같은 파일명·메모가 수식 셀이 됐다 (검토25 화면 3-5) — 글자로 못박는다
            for cell in ws[ws.max_row]:
                if isinstance(cell.value, str) and cell.data_type != "s":
                    cell.data_type = "s"
        widths = [7, 17, 8, 8, 14, 40, 34, 10, 17, 24, 30]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w
        buf = io.BytesIO()
        wb.save(buf)
        return buf.getvalue()

    def diagnose(self, paths, snap: dict) -> list[dict]:
        """최신 스냅샷에 있는 파일들의 '지금 상태' 판정 (2026-09-02).

        snap: {경로: (해시, 크기, 수정시각)}. 판정은 디스크의 현재 파일과 비교."""
        import os as _os
        import time as _t
        last_iso, _n = self.last_scan()
        out = []
        for p in paths:
            sha, size, mtime = snap.get(p, (None, None, None))
            ap = self.abs_path_of(p)
            row = {"path": p, "verdict": "", "detail": ""}
            if ap is None:
                row["verdict"] = "지금 파일이 없음"
                row["detail"] = ("삭제·이동됐거나 네트워크 연결이 끊긴 상태입니다. "
                                 "다음 검사에서 '삭제'로 잡힙니다.")
            else:
                try:
                    st_ = ap.stat()
                except OSError as e:
                    row["verdict"] = "읽을 수 없음"
                    row["detail"] = f"{e.__class__.__name__}: 권한·잠김·연결 문제 — 다음 검사에서 재시도"
                    out.append(row)
                    continue
                if size is not None and st_.st_size == size and st_.st_mtime == mtime:
                    row["verdict"] = "검사 시점과 동일"
                    # 크기·시각 보존 덮어쓰기(robocopy /COPY:DAT 등)는 내용이 바뀌어도 여기 걸린다 —
                    # "바뀐 것이 없다"고 단정하지 않는다 (검토21 원칙 중간 4)
                    row["detail"] = ("크기·수정시각이 마지막 검사와 같아 내용을 다시 읽지 않았습니다 — "
                                     "주 1회 전체 확인 때 읽습니다. 지금 확인하려면 [더 민감하게 다시 비교].")
                else:
                    when = _t.strftime("%m-%d %H:%M", _t.localtime(st_.st_mtime))
                    row["verdict"] = "검사 이후 수정됨"
                    row["detail"] = (f"파일 수정시각 {when} — 마지막 검사"
                                     f"({_local(last_iso, '%m-%d %H:%M') if last_iso else '없음'}) "
                                     f"뒤에 바뀌었습니다. [지금 검사]를 돌리면 잡힙니다.")
                try:                                   # 잠김 여부(읽기 시도만)
                    with open(ap, "rb") as f:
                        f.read(1)
                except OSError:
                    row["verdict"] += " · 지금 잠김"
                    row["detail"] += " 지금은 다른 프로그램이 열어 두어 읽을 수 없습니다."
            out.append(row)
        return out

    def diagnose_input(self, q: str) -> dict | None:
        """검색어가 경로/파일명이면 감시 대상인지부터 본다 — 스냅샷에 없는 파일용."""
        from watcher.scan import is_artifact, is_excluded
        cfg = self.cfg()
        exts = tuple(cfg.get("extensions") or [])
        # str.replace는 읽기전용 가드가 이동 API로 오인 — split/join (코드베이스 관례)
        name = "/".join(q.split("\\")).rsplit("/", 1)[-1]
        if "." not in name:
            return None
        ext = "." + name.rsplit(".", 1)[-1].lower()
        if ext not in exts:
            # 전에는 "config.yaml의 extensions에 추가하면"이라 적어, 설정 화면에서
            # 버튼 하나로 되는 일을 파일을 열어 고치라는 말로 읽혔다 (2026-09-10)
            from watcher.scan import EXT_PRESETS, preset_of
            grp = preset_of(ext)
            how = (f"설정 › 감시 확장자에서 '{EXT_PRESETS[grp][0]}' 묶음을 누르면"
                   if grp else "설정 › 감시 확장자에 추가하면")
            return {"verdict": "감시 대상 확장자가 아님",
                    "detail": (f"'{ext}'는 검사하지 않습니다. 현재 감시 확장자: "
                               f"{', '.join(exts)}. {how} 다음 검사부터 "
                               f"바뀐 사실·크기·저장 시각·이름 변경이 잡힙니다."),
                    "link": "/settings#ext", "link_text": "설정 › 감시 확장자 열기"}
        full = "/".join(q.split("\\"))
        from watcher.cli import _excludes_for, _root_labels
        roots = [Path(r) for r in cfg["roots"]]
        labels = _root_labels(roots)
        for r, label in zip(cfg["roots"], labels):
            rp = "/".join(str(r).split("\\")).rstrip("/")
            if full.lower().startswith(rp.lower() + "/"):
                rel = full[len(rp) + 1:]
                # 제외 규칙은 '라벨/경로'(그 폴더만)와 라벨 없는 형식(공통)이 섞여
                # 있다 — 검사와 같은 변환을 거쳐 이 폴더 몫만 적용한다
                ex_here = _excludes_for(label, labels, cfg.get("exclude") or [])
                if is_excluded(rel, ex_here):
                    return {"verdict": "제외 폴더 안에 있음",
                            "detail": f"'{rel}'는 설정의 제외 규칙에 걸립니다."}
                if not Path(full).exists():
                    return {"verdict": "그 경로에 파일이 없음",
                            "detail": "경로 오타이거나 이동·삭제된 파일입니다."}
                return {"verdict": "감시 대상 — 아직 검사되지 않음",
                        "detail": "다음 [지금 검사]에서 '추가'로 잡힙니다."}
        if "/" in full:
            return {"verdict": "감시 폴더 밖",
                    "detail": f"감시 폴더: {', '.join(cfg['roots'])}. 그 아래가 아닙니다."}
        return None

    def _diag_html(self, diag: list, extra: dict | None, last_iso) -> str:
        if not diag and not extra:
            return ""
        trs = "".join(
            f'<tr><td title="{_E(d["path"])}">{_path_html(d["path"])}</td>'
            f'<td style="white-space:nowrap"><b>{_E(d["verdict"])}</b></td>'
            f'<td class="muted">{_E(d["detail"])}</td></tr>' for d in diag)
        ex = (f'<p><b>{_E(extra["verdict"])}</b> — {_E(extra["detail"])}'
              + (f' <a href="{_E(extra["link"])}" style="color:var(--link)">{_E(extra.get("link_text") or "설정으로")}</a>'
                 if extra.get("link") else "") + '</p>'
              if extra else "")
        last = (f'마지막 검사: {_E(_local(last_iso))}' if last_iso else '아직 검사한 적 없음')
        return (f'<div class="panel"><h2>검출 진단 <span class="muted">— {last}</span></h2>'
                f'{ex}'
                + (f'<table><tr><th>파일</th><th>판정</th><th>설명</th></tr>{trs}</table>'
                   if trs else "")
                + '<p class="muted" style="font-size:12px;margin-top:8px">검사는 하루 1회'
                  '(또는 [지금 검사])라, 그 사이의 변경은 다음 검사에서 잡힙니다. 크기와 '
                  '수정시각이 완전히 같은 덮어쓰기는 변경으로 보지 않습니다.</p></div>')

    def page_tags(self, q: str) -> str:
        """태그·텍스트 검색 — "M-101 어디 들어가지?"에 답한다 (2026-08-29 설계
        검토 반영). 최신 스냅샷의 추출 내용 전체에서 찾고, 결과에서 바로 열기."""
        import re as _re
        q = (q or "").strip()
        form = (f'<form method="get" action="/tags" class="inline">'
                f'<input type="text" name="q" value="{_E(q)}" '
                f'placeholder="태그·텍스트 (예: M-101, 5.5kW)" '
                f'style="min-width:260px" autofocus>'
                f'<button class="btn">검색</button></form>')
        head = (f'<div class="topbar"><h1>태그 검색</h1>{form}</div>'
                + _intro("기기 태그(M-101)나 아무 텍스트를 넣으면, 그 글자가 든 "
                         "도면·BOM·문서를 감시 대상 전체에서 찾아줍니다. 파일을 "
                         "바로 열거나 변경 이력으로 이동할 수 있습니다. 파일명을 넣으면 "
                         "그 파일이 지금 어떤 상태인지(검사 이후 수정·잠김·미검사)도 "
                         "알려줍니다."))
        if not q:
            return _page("태그 검색", "/tags", head
                         + '<div class="panel"><p class="muted">예: 모터 태그 '
                           '<code>M-101</code>을 검색하면 그 태그가 등장하는 '
                           '도면과 BOM이 전부 나옵니다 — 사양 변경 때 영향 범위 '
                           '확인용.</p></div>', self.pop_msg())
        ql = q.lower()
        results = []
        truncated = False
        with State(self.db()) as st:
            rows = st._latest_rows()
            cur = {v[0] for v in rows.values()}
            hit = set()
            for pat in {q, q.upper(), q.lower()}:  # sqlite LIKE는 영문만 대소문자 무시
                esc = _re.sub(r"([%_\\\\])", r"\\\1", pat)   # 사용자 입력의 %·_는 글자
                hit |= {s for (s,) in st.conn.execute(
                    "SELECT sha256 FROM extracts WHERE doc_json LIKE ? ESCAPE '\\'",
                    (f"%{esc}%",)) if s in cur}
            # 흔한 검색어("5.5kW")는 수만 문서에 다 걸린다 — 문서 로드에
            # 개수·시간 예산을 걸어 화면이 2분씩 멈추지 않게 (2026-08-30
            # 3.5만 파일 실측 114초 → 예산제). 예산 초과 시 일부만 표시 안내.
            import time as _t
            _t0, _loaded = _t.time(), 0
            for path, (sha, _sz, _mt) in rows.items():
                if len(results) >= 300 or _loaded >= 800 \
                        or _t.time() - _t0 > 5:
                    truncated = True
                    break
                name_hit = ql in path.lower()   # 파일명·폴더명 일치도 검색
                n, first = 0, ""
                if sha in hit:
                    _loaded += 1
                    d = st.load_extract(sha)
                    if d and d.get("fields") is not None:
                        lines = [t["text"] for t in d.get("raw_texts", [])
                                 if ql in t["text"].lower()]
                        n = (len(lines)
                             + sum(1 for f in d.get("fields", {}).values()
                                   if ql in str(f.get("value", "")).lower())
                             + sum(1 for r0 in d.get("rows", [])
                                   if ql in str(r0.get("values", "")).lower()
                                   or ql in str(r0.get("key", "")).lower()))
                        first = lines[0] if lines else ""
                if not n and not name_hit:
                    continue
                c = st.conn.execute(
                    "SELECT id FROM changes WHERE path=? ORDER BY id DESC LIMIT 1",
                    (path,)).fetchone()
                results.append((path, n, first, c[0] if c else None))
        # 내용 일치(출현 많은 순)가 먼저, 파일명만 일치는 뒤에
        results.sort(key=lambda r: (-r[1], r[0]))
        # 검출 진단 — 파일명이 맞는 것들은 "지금 어떤 상태인지"까지 (2026-09-02)
        diag = self.diagnose([r[0] for r in results if ql in r[0].lower()][:10], rows)
        diag_html = self._diag_html(diag, self.diagnose_input(q) if not diag else None,
                                    self.last_scan()[0])
        tok = self.csrf()
        trs = "".join(
            f'<tr><td title="{_E(path)}">'
            + (f"<a href='/change?id={cid}' style='color:var(--link)'>"
               f"{_path_html(path)}</a>" if cid else _path_html(path))
            # 프로젝트 폴더까지 — 동명 파일 다섯이 같은 줄로 보였다 (검토21 설치 중간 8)
            + f'<div class="muted" style="font-size:11px">{_E("/".join(path.split("/")[:-1][:3]))}</div>'
            + f'</td><td>{_E(_cat_display(path))}</td>'
            f'<td style="text-align:right;white-space:nowrap">'
            + (f'{n}곳' if n else '<span class="muted">파일명 일치</span>') + '</td>'
            f'<td class="muted" style="max-width:380px;overflow:hidden;'
            f'text-overflow:ellipsis;white-space:nowrap">{_E(first[:80])}</td>'
            + _open_cell(path, tok) + "</tr>"
            for path, n, first, cid in results[:200])
        if results:
            trunc_note = (' <span class="muted">— 검색어가 매우 흔해 일부만 '
                          '보여드립니다. 더 구체적으로(예: 태그 전체) 입력하면 '
                          '정확해집니다.</span>' if truncated else
                          (' <span class="muted">(상위 200개 표시)</span>'
                           if len(results) > 200 else ''))
            body = (f'<div class="panel"><h2>"{_E(q)}" — 파일 '
                    f'{len(results)}개{"+" if truncated else ""}에서 발견'
                    f'{trunc_note}</h2>'
                    f'<div class="scrolly" style="max-height:560px">'
                    f'<table><tr><th>파일</th><th>유형</th><th>출현</th>'
                    f'<th>첫 일치 내용</th><th></th></tr>{trs}</table></div></div>'
                    + diag_html)
        else:
            body = (f'<div class="panel"><p class="muted">"{_E(q)}"를 찾지 '
                    f'못했습니다 — 파일명과 추출된 내용(DXF·PDF·XLSX)에서 '
                    f'찾습니다. 검사가 아직 안 돈 파일은 검색되지 않습니다.'
                    f'</p></div>' + diag_html)
        return _page("태그 검색", "/tags", head + body, self.pop_msg())

    def page_compare(self, change_id_s: str, page_s: str) -> str:
        """전/후 전체 페이지 나란히 보기 (PDF 전용) — 감지가 놓친 변경도 사람이
        직접 훑을 수 있는 안전망 (미탐 대응, 2026-08-27)."""
        try:
            change_id = int(change_id_s)
        except ValueError:
            return _page("나란히 보기", "/",
                         '<div class="panel"><p>잘못된 번호입니다.</p></div>')
        try:
            pno = max(1, int(page_s or "1"))
        except ValueError:
            pno = 1
        with State(self.db()) as st:
            change = st.get_change(change_id)
            if change is None:
                return _page("나란히 보기", "/",
                             f'<div class="panel"><p>변경 #{change_id}이 없습니다.</p></div>')
            from watcher.cli import find_prev_version
            prev_key, _sha, why = find_prev_version(st, change.path)
        head = ('<div class="topbar"><h1>전/후 나란히 보기</h1></div>'
                + _intro(_E(change.path)))
        back = (f'<div class="panel"><p><a href="/change?id={change_id}" '
                f'style="color:var(--link)">← 변경 상세로</a></p></div>')

        def _fail(msg: str) -> str:
            return _page("나란히 보기", "/",
                         head + f'<div class="panel"><p>{msg}</p></div>' + back)

        ext = PurePosixPath(change.path).suffix.lower()
        if ext not in (".pdf", ".dxf", ".dwg"):
            return _fail("나란히 보기는 도면(PDF·DXF·DWG)만 지원합니다.")
        # 같은 이름으로 덮어쓴 도면은 파일명 짝이 없다 — 검사 때 기록한 이전 판 그림으로
        # 나란히 놓는다. 가장 급한 'Rev 미갱신' 도면에서 안 열리던 것 (2026-09-03 검토)
        with State(self.db()) as st:
            rec_old = st.load_renders(change.old_sha256) if change.old_sha256 else None
            rec_new = st.load_renders(change.new_sha256) if change.new_sha256 else None
        if prev_key is not None:
            prev_abs = self.abs_path_of(prev_key)
            new_abs = self.abs_path_of(change.path) if ext != ".dwg" else rec_new
            if ext == ".dwg" and prev_key.lower().endswith(".dwg"):
                with State(self.db()) as st:
                    prev_abs = st.load_renders(_sha)
        elif rec_old is not None:
            prev_abs = rec_old
            new_abs = self.abs_path_of(change.path) if ext != ".dwg" else rec_new
        else:
            return _fail(_E(why) + " 이전 판의 그림 기록도 없어 나란히 놓을 수 없습니다.")
        if new_abs is None or prev_abs is None:
            return _fail("원본 파일에 접근할 수 없습니다 — 감시 폴더 연결(네트워크 "
                         "드라이브 등)을 확인해주세요.")
        from watcher.capture import page_pair_images
        # 페이지가 빠져 번호가 밀린 판은 검사 때 만든 짝 지도로 같은 페이지를 놓는다 (2026-09-06)
        page_map = None
        try:
            with State(self.db()) as st:
                d_ = st.change_detail(change_id)
            page_map = ((d_ or {}).get("captures") or {}).get("PAGE_MAP")
        except Exception:
            page_map = None
        # 지도에 없는 번호 = 이전 판에 없는(새로 끼어든) 페이지 — 같은 번호의 엉뚱한 옛 페이지를 놓지 않는다 (리뷰10)
        old_pno = (page_map.get(str(pno), 0) if page_map else None)
        res = page_pair_images(prev_abs, new_abs, pno, old_pno=old_pno) if page_map \
            else page_pair_images(prev_abs, new_abs, pno)
        if res is None and pno > 1:            # 범위 밖이면 1페이지로 되돌려 시도
            pno, res = 1, page_pair_images(prev_abs, new_abs, 1)
        if res is None:
            return _fail("페이지를 그리지 못했습니다 — 파일이 잠겨 있거나 손상됐을 "
                         "수 있습니다. 잠시 후 다시 시도해주세요.")
        b64_old, b64_new, total = res

        def _nav(p: int, label: str) -> str:
            if 1 <= p <= total:
                return (f'<a class="btn gray" style="text-decoration:none" '
                        f'href="/compare?id={change_id}&amp;page={p}">{label}</a>')
            return f'<span class="btn gray" style="opacity:.4">{label}</span>'

        pager = (f'<div class="panel" style="text-align:center">'
                 f'{_nav(pno - 1, "← 이전 페이지")} '
                 f'<b style="margin:0 10px">{pno} / {total} 페이지</b> '
                 f'{_nav(pno + 1, "다음 페이지 →")}</div>')

        def _col(title: str, name: str, b64: str) -> str:
            if not b64:                        # 이전 판에 없는(새로 끼어든) 페이지
                return (f'<div style="flex:1;min-width:320px">'
                        f'<h2 style="font-size:14px;margin-top:0">{title} '
                        f'<span class="muted">{_E(name)}</span></h2>'
                        f'<div class="muted" style="padding:40px 16px;border:1px dashed var(--border2);'
                        f'border-radius:8px;text-align:center">이전 판에는 없는 페이지입니다 (추가)</div></div>')
            return (f'<div style="flex:1;min-width:320px">'
                    f'<h2 style="font-size:14px;margin-top:0">{title} '
                    f'<span class="muted">{_E(name)}</span></h2>'
                    f'<img src="data:image/jpeg;base64,{b64}" alt="{title}" '
                    f'style="width:100%;border:1px solid var(--border2);'
                    f'border-radius:8px"></div>')

        body = (head + pager
                + '<div class="panel"><div style="display:flex;gap:14px;flex-wrap:wrap">'
                + _col("이전 판", (PurePosixPath(prev_key).name if prev_key
                                  else "이전 검사 때 기록한 그림 (같은 파일)")
                       + (f" · {old_pno}페이지" if old_pno and old_pno != pno else ""), b64_old)
                + _col("새 판", PurePosixPath(change.path).name, b64_new)
                + '</div><p class="muted" style="margin-bottom:0">같은 페이지를 두 판에서 '
                  '그대로 그린 그림입니다 — 감지 결과와 무관하게 전체를 직접 비교할 수 '
                  '있습니다. 놓친 변경을 찾으면 변경 상세의 [놓친 변경 기록]에 '
                  '남겨주세요.</p></div>'
                + back)
        return _page(f"나란히 보기 #{change_id}", "/", body)

    def page_notes(self) -> str:
        """놓친 변경 리포트 — 사람이 보완한 기록을 모아, 어떤 파일·양식에서
        프로그램이 자주 놓치는지 본다 (미탐 대응, 2026-08-27)."""
        with State(self.db()) as st:
            notes = st.list_user_notes()
        head = ('<div class="topbar"><h1>놓친 변경 리포트</h1></div>'
                + _intro("프로그램이 못 잡아 사람이 직접 남긴 변경 기록입니다. "
                         "특정 양식·확장자에 몰려 있으면 그쪽 감지를 보완할 신호입니다."))
        if not notes:
            return _page("놓친 변경 리포트", "/", head
                         + '<div class="panel"><p class="muted">아직 기록이 없습니다 — '
                           '변경 상세 화면의 [놓친 변경 기록]에서 남길 수 있습니다.'
                           '</p></div>')
        by_ext = Counter(PurePosixPath(n["path"]).suffix.lower() or "(확장자 없음)"
                         for n in notes)
        by_proj = Counter(n["project"] for n in notes)
        stat = ('<div class="panel"><h2>어디서 많이 놓쳤나</h2>'
                '<p style="margin:6px 0">파일 유형: '
                + " ".join(f'<span class="tag na">{_E(k)} {v}건</span>'
                           for k, v in by_ext.most_common())
                + '</p><p style="margin:6px 0">프로젝트: '
                + " ".join(f'<span class="tag done">{_E(k)} {v}건</span>'
                           for k, v in by_proj.most_common(10))
                + '</p></div>')
        trs = "".join(
            f'<tr><td class="muted" style="white-space:nowrap">'
            f'{_E(_local(n.get("at")))}</td>'
            f'<td><a href="/change?id={n["change_id"]}" style="color:var(--link)">'
            f'{_E(PurePosixPath(n["path"]).name)}</a><br>'
            f'<span class="muted">{_E(n["project"])}</span></td>'
            f'<td><b>{_E(n.get("where") or "위치 미지정")}</b> — '
            f'{_E(n.get("text", ""))}<br>'
            f'<span class="muted">{_E(n.get("by", "-"))}</span></td></tr>'
            for n in notes[:200])
        table = (f'<div class="panel"><h2>기록 {len(notes)}건'
                 + (f' <span class="muted">(최근 200건 표시)</span>'
                    if len(notes) > 200 else '')
                 + f'</h2><table><tr><th>언제</th><th>파일</th><th>내용</th></tr>'
                 f'{trs}</table></div>')
        return _page("놓친 변경 리포트", "/", head + stat + table, self.pop_msg())

    def brief_dir(self) -> Path:
        return Path(self.cfg()["brief_dir"])

    def page_briefs(self) -> str:
        """브리핑 목록: 클릭하면 화면에서 바로 열린다."""
        bdir = self.brief_dir()
        briefs = sorted(bdir.glob("brief_*.html"),
                        key=lambda p: p.stat().st_mtime, reverse=True) \
            if bdir.is_dir() else []
        trs = []
        for b in briefs[:120]:
            stem = b.stem[len("brief_"):]          # 20260822_P24-031 | weekly_20260824
            weekly = stem.startswith("weekly_")
            if weekly:
                stem = stem[len("weekly_"):]
            date_s, _, proj = stem.partition("_")
            # 같은 날 두 번째 브리핑의 시각 접미(_0818, _0818_2)는 프로젝트가 아니다
            proj = re.sub(r"(?:^|_)\d{4}(?:_\d+)?$", "", proj)
            preview = proj.endswith("_미리보기")
            if preview:
                proj = proj[:-len("_미리보기")]
            base = proj.endswith("_기준선")
            if base:
                proj = proj[:-len("_기준선")]
            date_fmt = f"{date_s[:4]}-{date_s[4:6]}-{date_s[6:8]}" if len(date_s) == 8 else date_s
            label = (f"{date_fmt} 주간 요약" if weekly else
                     f"{date_fmt}{' — ' + proj if proj else ' (변경 없음 기록)'}"
                     + (" (기준선 등록)" if base else "") + (" (미리보기)" if preview else ""))
            size_mb = b.stat().st_size / 1e6
            size_s = (f"{size_mb:.1f}MB · 사진 포함, 여는 데 잠시 걸림"
                      if size_mb >= 1 else f"{b.stat().st_size // 1024}KB")
            eml = b.with_suffix(".eml")
            eml_cell = (f"<a href='/brief/open?f={quote(eml.name)}' style='color:var(--link)'>"
                        f"메일 초안 열기</a>" if eml.is_file() else "<span class='muted'>—</span>")
            trs.append(
                f"<tr><td><a href='/brief?f={quote(b.name)}' "
                f"style='color:var(--link);font-weight:600'>{_E(label)}</a></td>"
                f"<td>{eml_cell}</td>"
                f"<td class='muted'>{_E(size_s)}</td>"
                f"<td class='muted'>{_E(b.name)}</td></tr>")
        table = ("<table><tr><th>브리핑</th><th>메일</th><th>크기</th><th>파일명</th></tr>"
                 + "".join(trs) + "</table>") if trs else \
            '<p class="muted">아직 브리핑이 없습니다 — [지금 검사]를 실행하면 생깁니다.</p>'
        body = ('<div class="topbar"><h1>브리핑</h1></div>'
                + _intro("검사 때마다 만들어지는 일일 보고서입니다. 클릭하면 바로 열립니다 — "
                         "변경 상세(무엇이 어떻게 바뀌었나)와 위치 캡처는 여기에 있습니다.")
                + f'<div class="panel">{table}</div>')
        return _page("브리핑", "/briefs", body)

    def brief_file(self, name: str, ext: str = ".html") -> Path | None:
        """브리핑 파일 안전 확인 (폴더 밖 접근 차단). ext='.eml'이면 메일 초안."""
        if not name.startswith("brief_") or not name.endswith(ext) or "/" in name \
                or "\\" in name or ".." in name:
            return None
        p = self.brief_dir() / name
        return p if p.is_file() else None

    def todays_emls(self) -> list[Path]:
        """오늘 만들어진 메일 초안(.eml) — 대시보드에서 바로 열 수 있게 (2026-09-05)."""
        bdir = self.brief_dir()
        if not bdir.is_dir():
            return []
        stamp = date.today().strftime("%Y%m%d")
        return sorted(bdir.glob(f"brief_{stamp}*.eml"), key=lambda p: p.stat().st_mtime, reverse=True)

    def _attributions(self) -> dict:
        """최신 스냅샷의 각 파일 → (프로젝트, 근거). 표제란은 저장된 추출본에서 읽는다."""
        from watcher.cli import _root_labels
        from watcher.extract.base import Document
        from watcher.project import ProjectResolver
        if not self.db().exists():
            return {}
        cfg = self.cfg()
        resolver = self._resolver([r for r in cfg["roots"] if Path(r).is_dir()])
        out = {}
        with State(self.db()) as st:
            snap = st.latest_snapshot()  # {path: sha256}
            if not resolver.folder_votes:
                # 아직 검사가 표를 저장하지 않은 DB(구판에서 올라온 직후) — 여기서 배운다
                for path, sha in snap.items():
                    ed = st.load_extract(sha)
                    if ed and "doc_type" in ed:
                        resolver.learn(path, Document.from_dict(ed))
            for path, sha in snap.items():
                ed = st.load_extract(sha)
                # 추출 실패 캐시({"extract_failed": …})는 문서가 아니다 — 손상 파일이
                # 하나라도 있으면 정리 제안 화면이 통째로 죽던 것 (2026-09-03 검토)
                doc = Document.from_dict(ed) if ed and "doc_type" in ed else None
                out[path] = resolver.attribute(path, doc)
        return out

    def page_organize(self) -> str:
        from watcher.cli import _root_labels
        from watcher.organize import suggest_moves
        from watcher.project import ProjectResolver
        cfg = self.cfg()
        resolver = self._resolver([r for r in cfg["roots"] if Path(r).is_dir()])
        labels = resolver.root_labels

        def folder_project(folder: str):
            # 폴더 경로에 '실제 프로젝트 번호/별칭'이 있을 때만 그 프로젝트로 인정.
            # (폴더구조 폴백은 자기 이름을 반환해 순환·소음이 되므로 쓰지 않는다)
            return resolver._find_in(folder)

        sugg = suggest_moves(self._attributions(), folder_project)
        if sugg:
            rows = "".join(
                f'<tr><td>{_E(PurePosixPath(s.path).name)}</td>'
                f'<td><span class="tag done">{_E(s.project)}</span> '
                f'<span class="muted">({_E(s.how)})</span></td>'
                f'<td>{_E(s.current_folder)}</td>'
                f'<td class="muted">{_E(s.reason)}</td></tr>'
                for s in sugg)
            table = ('<table><tr><th>파일</th><th>소속 프로젝트</th>'
                     f'<th>현재 폴더</th><th>제안</th></tr>{rows}</table>')
        else:
            table = ('<p class="muted">정리 제안이 없습니다 — 소속이 확실한 파일들이 '
                     '모두 제 프로젝트 폴더에 있거나, 아직 판단 근거가 부족합니다.</p>')
        body = ('<div class="topbar"><h1>정리 제안</h1></div>'
                + _intro("표제란·파일명으로 프로젝트가 확실한데 다른 폴더에 있는 파일을 "
                         "알려드립니다. 옮기는 것은 담당자가 판단해 직접 하세요 — "
                         "이 프로그램은 파일을 절대 이동·수정하지 않습니다.")
                + f'<div class="panel">{table}</div>'
                + '<div class="panel"><p class="muted">왜 제안만 하나요? 자동으로 옮기면 '
                  '오분류 한 건이 도면 유실 사고가 됩니다. 근거를 보고 사람이 결정하는 것이 '
                  '안전합니다.</p></div>')
        return _page("정리 제안", "/organize", body)

    def page_help(self) -> str:
        body = """
<div class="topbar"><h1>도움말</h1></div>
{intro}
<div class="panel">
<p style="font-size:14.5px;line-height:1.7;margin:0">지정한 폴더를 하루 1회 훑어
<b>도면·BOM·문서가 무엇이 어떻게 바뀌었는지</b>를 근거(전/후 사진)와 함께 정리합니다.<br>
파일은 <b>읽기만</b> 하고 절대 수정하지 않으며, 회사 밖으로 내보내지 않습니다.
평소처럼 폴더에 저장만 하면 됩니다.</p></div>

<div class="panel"><h2>아침 5분, 이렇게 쓰세요</h2>
<div class="steps">
  <div class="step"><b>1</b><div><strong>대시보드 확인</strong><br>
    "마지막 검사" 시각과 <span style="color:var(--bad)">미확인 변경</span> 숫자를 봅니다.
    0건이면 끝 — 감시는 정상입니다.</div></div>
  <div class="step"><b>2</b><div><strong>변경 클릭 → 내용 보기</strong><br>
    파일명을 클릭하면 무엇이 어떻게 바뀌었는지 전/후 사진과 함께 나옵니다.
    잘못 잡힌 항목은 [오탐 삭제]로 걷어냅니다.</div></div>
  <div class="step"><b>3</b><div><strong>[확인함] 남기기</strong><br>
    봤다는 기록입니다. [요약 복사]로 팀에 전달하면 보고 끝.</div></div>
</div></div>

<div class="panel"><h2>자주 묻는 질문</h2>
<details class="qa"><summary>변경이 0건인데 고장인가요?</summary>
<p>대시보드의 "마지막 검사" 시각이 최근이면 정상입니다 — 정말 변경이 없었던 것입니다.
브리핑에도 "파일 N개 검사함"이 남습니다.</p></details>
<details class="qa"><summary>두 판을 넣었는데 비교가 안 돼요</summary>
<p>같은 도면의 판으로 인정되는 조건은 3가지입니다:</p>
<ul><li>① <b>같은 폴더</b>에 있고</li>
<li>② <b>같은 확장자</b>(PDF↔PDF, DXF↔DXF)이고</li>
<li>③ 날짜·버전 표기(<code>_20260827</code>, <code>_rev2</code>, <code>(2차수정)</code>,
<code>_승인용</code> 등)를 뺀 <b>이름이 같아야</b> 합니다.</li></ul>
<p>여러 판을 한꺼번에 넣어도 날짜순으로 줄줄이 비교됩니다. 비교가 빠진 판은
그 변경을 클릭해 <b>[이전 판 찾아 다시 비교]</b> 버튼을 누르면 소급 비교됩니다.</p></details>
<details class="qa"><summary>"미분류" 프로젝트가 떠요</summary>
<p>어느 프로젝트 것인지 판정 못 한 파일입니다. 폴더명이 프로젝트 번호와 다르면 생깁니다 —
aliases.yaml에 별칭 한 줄을 추가하면 해결됩니다 (예: <code>P24-031: [세척기 2호기]</code>).</p></details>
<details class="qa"><summary>[확인함]·[처리함]·[오탐 삭제]를 잘못 눌렀어요</summary>
<p>오탐 삭제는 화면 아래 "숨긴 항목"에서 <b>[복원]</b>하면 됩니다.
확인 기록은 지워지지 않으니 '정정' 메모로 새 확인을 남기세요.
검토 필요(처리함)는 같은 내용이 재검출되면 다시 올라옵니다.</p></details>
<details class="qa"><summary>키보드만으로 쓸 수 있나요? (단축키)</summary>
<p>표에서 <b>↑ ↓</b>(또는 <b>J K</b>)로 행을 옮기고, <b>Enter</b>로 그 변경의 상세를 엽니다.
<b>A</b>는 고른 행을 바로 [확인함]으로 처리합니다. <b>/</b>는 왼쪽 위 검색창으로 갑니다.
<b>Ctrl+K</b>(또는 <b>?</b>)를 누르면 모든 화면·동작을 이름으로 찾아 실행하는 창이 열립니다.
<b>Alt+←</b>는 이전 화면입니다.</p>
<p>한글 입력 상태에서도 그대로 듣습니다(자판 위치로 알아봅니다). Tab으로 링크·단추를 옮겨 다닌 뒤에도
단축키가 계속 듣고, 글자를 입력하는 칸 안에서만 잠시 멈춥니다. 화면 맨 처음에서 Tab을 한 번 누르면
<b>[본문으로 건너뛰기]</b>가 나와 왼쪽 메뉴를 지나칠 수 있습니다.</p></details>
<details class="qa"><summary>글자가 작아요 / 화면을 키우고 싶어요</summary>
<p>왼쪽 아래 <b>[⚙ 보기 설정]</b>을 누르면 <b>가 / 가 / 가</b> 세 단추가 있습니다 — 화면 전체(글자·표·단추)를
함께 키웁니다. 프로그램 창에서는 Ctrl+휠로도 확대됩니다. 그 아래 [촘촘·보통·넓게]는 표의 <b>행 간격</b>만
바꾸는 것이라 글자 크기와는 다릅니다. 고른 값은 이 PC에 기억됩니다.</p></details>
<details class="qa"><summary>프로그램 창이 아니라 브라우저 탭으로 열려요</summary>
<p>고장이 아닙니다. Drev는 자체 창을 띄울 때 Windows의 창 구성요소(WebView2)를 씁니다.
그게 없거나 회사 정책에 막힌 PC에서는, 깨진 창을 띄우는 대신 <b>기본 브라우저 탭으로 엽니다.</b>
기능은 창으로 열 때와 완전히 같고 화면도 같습니다. 왼쪽 메뉴 맨 위에 <b>🌐 브라우저 탭으로 열림</b>이
보이면 지금 이 상태이고, 그걸 누르면 사유가 나옵니다(설정 › 화면 여는 방식).</p>
<p><b>탭을 닫아도 꺼지지 않습니다.</b> Drev는 뒤에서 계속 돌며 매일 검사합니다. 화면을 다시 보려면
바탕화면의 [Drev]를 한 번 더 누르세요 — 같은 주소로 탭이 다시 열립니다. 주소를 즐겨찾기에 넣어 두셔도
됩니다. <b>완전히 끄려면</b> 설정 › 프로그램 종료를 누르세요.</p>
<p>업데이트할 때는 교체하는 몇 초 동안 화면이 멈춘 것처럼 보입니다. <b>그대로 두고 기다리시면</b>
새 판이 준비될 때 이 탭이 저절로 새로고침됩니다(길어도 1분). 그 사이에 다른 곳을 누르지 마세요.
혹시 "연결할 수 없음"이 뜨면 1분 뒤 새로고침(F5)을 한 번만 누르시면 됩니다.</p></details>
<details class="qa"><summary>특정 폴더를 검사에서 빼고 싶어요 (참고자료·외주 폴더 등)</summary>
<p>오른쪽 [폴더] 서랍에서 그 폴더를 펼치면 맨 위에 <b>[이 폴더를 감시에서 빼기]</b>가 있습니다. 누르면 그 자리에서
바로 처리되고 램프가 회색으로 바뀝니다. 되돌리려면 같은 자리의 [이 폴더를 다시 감시하기]를 누르세요.
폴더가 많으면 서랍 위 칸에 폴더 이름을 쳐서 좁힐 수 있습니다. 설정 › 감시 제외에서 목록으로도 관리됩니다.
빠진 폴더의 파일은 삭제 알림 없이 조용히 감시에서만 빠지고, 이력은 지워지지 않습니다.</p></details>
<details class="qa"><summary>PLC 프로그램·3D 모델처럼 Drev가 내용을 못 읽는 파일도 관리되나요?</summary>
<p>됩니다. 설정 › 감시 확장자에서 <b>PLC 프로그램·HMI·로봇·3D 모델·NC·전장 CAD</b> 묶음을 한 번 누르면 그 형식들이
모두 감시에 들어갑니다. 안의 글자·표는 못 읽지만 <b>언제 바뀌었는지, 크기와 저장 시각이 어떻게 변했는지, 이름이
바뀌었는지</b>는 브리핑에 실리고 이력이 남습니다. 같은 이름에 날짜·Rev를 붙여 저장한 새 판도 이전 판과 짝지어 보여
줍니다.</p></details>
<details class="qa"><summary>폴더 구조에서 파일을 열 수 있나요? 옮기거나 지우는 건요?</summary>
<p>폴더 구조(오른쪽 서랍 또는 전체 화면)에서 파일을 더블클릭하거나 [열기]를 누르면 이 PC의 기본 프로그램으로 열리고,
[폴더]·[탐색기]는 그 폴더를 Windows 탐색기에서 엽니다. 연결된 프로그램이 없는 형식이면 폴더를 열어 줍니다.
옮기기·지우기는 Drev 안에 없습니다 — Drev는 감시 대상 파일을 읽기만 하는 것이 원칙이라 그런 코드 자체가 없습니다.
탐색기에서 하시면 다음 검사가 이동·삭제를 알아봅니다.</p></details>
<details class="qa"><summary>글자를 못 읽는다는 PDF가 있어요</summary>
<p>CAD에서 SHX 글꼴로 출력한 PDF나 스캔본은 글자가 그림입니다. Windows 한국어 OCR이 있는 PC에서는
그 글자를 읽어 표제란(도면번호·Rev)과 글자 변경을 비교하되 'OCR 추정값'으로 표시합니다(설정 › 고급).
OCR이 없거나 껐으면 변경 사실과 그림 비교만 하며 화면에 그 사유가 표시됩니다. 같은 종이를 다시 스캔한 판은
기울기·밝기 차이로 '페이지 전체가 살짝 어긋남' 한 줄이 나올 수 있고, 혼동되는 글자(O/0·I/1)는 변경으로 세지 않습니다.
가장 정확한 길은 CAD에서 TrueType 글꼴로 출력하거나 DXF를 함께 두는 것입니다.</p></details>
</div>

<div class="panel"><h2>용어 한 장</h2>
<dl class="terms">
<dt>Rev</dt><dd>도면 개정 번호 — 표제란의 REV 칸(A, B, C…). 고쳐서 다시 내면 올라갑니다</dd>
<dt>표제란</dt><dd>도면 우하단 정보 칸 — 도면번호·프로젝트·Rev·날짜</dd>
<dt>BOM</dt><dd>자재 목록표 — 어떤 부품이 몇 개 들어가는지 적은 엑셀</dd>
<dt>태그</dt><dd>기기 이름표 — M-101(모터), X-12(릴레이)처럼 도면과 BOM을 잇는 식별자</dd>
<dt>기준선</dt><dd>첫 검사 때 파일을 감시 대상으로 등록한 기록 — '첫 등록'으로 표시되고 변경으로 세지 않습니다</dd>
<dt><span class="tag added">추가</span></dt><dd>처음 나타난 파일</dd>
<dt><span class="tag modified">수정</span></dt><dd>내용이 바뀐 파일 — 이전 판과 비교됩니다</dd>
<dt><span class="tag removed">삭제</span></dt><dd>사라진 파일</dd>
<dt><span class="tag na">미확인</span></dt><dd>아직 아무도 [확인함]을 안 남긴 변경</dd>
<dt>검토 필요</dt><dd>의심 정황 — Rev 미갱신, 도면-BOM 불일치 등. 처리 후 [처리함]으로 닫습니다</dd>
</dl></div>

<div class="panel"><h2>관리자용</h2>
<details class="qa"><summary>자동 실행이 잘 도는지 확인하려면</summary>
<p>대시보드 맨 위 "마지막 검사" 시각을 보세요 — 25시간 넘게 없으면 노란 경고가 뜹니다.
실행 기록은 프로그램 폴더의 watcher.log. 자동 실행은 그 시각에 PC가
로그인돼 있어야 돌며, 절전 중이면 깨우고 그 시각을 놓치면 다음에 켜질 때 바로 돕니다.</p></details>
<details class="qa"><summary>네트워크 폴더 감시</summary>
<p>자동 실행에서도 접근되려면 Z: 드라이브 문자 대신 &#92;&#92;서버&#92;공유 형식(UNC)으로
등록하세요. "폴더를 찾을 수 없습니다"는 오타 또는 접근 권한 문제입니다.</p></details>
<details class="qa"><summary>메일로 브리핑 보내기</summary>
<p>검사 후 briefs 폴더의 <b>.eml 파일을 더블클릭</b>하면 받는사람·본문·사진이 채워진
메일 초안이 열립니다 — [보내기]만 누르면 됩니다. 프로그램은 설정에서 SMTP 자동 발송을 켠 경우에만 스스로 보냅니다.</p></details>
<details class="qa"><summary>백업 · 다른 PC로 이전 · 되살리기</summary>
<p><code>config.yaml</code>(설정), <code>aliases.yaml</code>(프로젝트 별칭 사전 — 있으면. 빼면 프로젝트가 다시 갈립니다), <code>state.db</code>(모든 이력)를 복사하면 끝입니다.
같은 폴더에 <code>state.db-wal</code>이 있으면 <b>그것도 함께</b> 복사하세요 — 빼면 가장
최근 검사 한 번이 빠집니다. 검사 중이 아닐 때 복사하세요.</p>
<p><b>이력이 깨졌거나 사라졌을 때</b>: <code>state.db</code> 옆 <code>backups</code>
폴더에 주 1회 사본이 4개까지 순환 보관됩니다. 순서대로 하세요.</p>
<ol style="margin:4px 0 4px 18px;line-height:1.8">
<li>Drev를 닫습니다.</li>
<li>지금 <code>state.db</code>를 <code>state.db.문제</code>처럼 다른 이름으로 옮겨 둡니다
(지우지 마세요).</li>
<li><b>같은 폴더에 <code>state.db-wal</code>이나 <code>state.db-shm</code>이 남아 있으면
지웁니다.</b> 이 단계를 건너뛰면 되살아나지 않습니다 — 그 두 파일은 깨지기 직전의
마지막 기록이라 새로 놓은 백업 위에 다시 얹힙니다. 오류도 나지 않아 알아채기
어렵습니다. (정전·강제 종료로 꺼졌을 때만 남고, 정상 종료면 없습니다.)</li>
<li>날짜가 맞는 <code>state_backup_N.db</code>를 <b>복사해서</b> <code>state.db</code>로 이름을 바꿉니다 — 원본 사본은 그대로 두어야 그 주에 다시 깨져도 되돌릴 수 있습니다. 가장 최근의 검증된 사본은 <code>state_backup_N.db.new</code>일 수 있습니다.</li>
<li>Drev를 켜고 [지금 검사]를 한 번 누릅니다 — 그동안의 변경을 다시 잡습니다.</li>
</ol>
<p>되살린 뒤 <b>변경 건수가 백업 시점과 맞는지 확인하세요</b>. 숫자가 그대로면
3번을 안 한 것입니다.</p>
<p class="muted">Drev는 이력 파일이 깨진 것을 발견하면 <b>백업을 덮지 않고</b> 건너뛰고, 이력이 갑자기 줄었으면 경고만 남기고 백업은 합니다(사람이 지운 것일 수 있어서) — 그 주 슬롯 하나만 덮이고 나머지 세 사본은 남습니다. 백업은 먼저 옆 파일(.new)에 쓰고 검증한 뒤 슬롯에 넣습니다. 또 이력이 갑자기 줄거나 깨진 것을 발견하면 <b>백업을 덮지 않고</b>
건너뜁니다 — 사고가 난 주에도 지난 사본이 남아 있습니다.</p></details>
<details class="qa"><summary>오래된 기록 정리</summary>
<p>보존 기간(설정, 기본 90일)이 지나면 전/후 사진·상세만 지워지고
변경 이력·확인 기록은 계속 남습니다.</p></details>
<details class="qa"><summary>프로그램이 변경을 놓쳤을 때</summary>
<p>변경 상세 화면에서 ①[더 민감하게 다시 비교]로 미세 변경까지 재검사,
②[전/후 페이지 나란히 보기]로 두 판을 눈으로 직접 비교, ③그래도 못 잡은 변경은
[놓친 변경 기록]에 남기세요. 기록은 <a href="/notes">놓친 변경 리포트</a>에 모여
어떤 양식에서 자주 놓치는지 보여줍니다.</p></details>
</div>

<div class="panel"><h2>알아두면 좋은 규칙</h2>
<ul style="line-height:1.9;padding-left:20px;margin:0">
<li><b>날짜 붙인 새 파일도 비교됩니다</b> — 판넬도면_20260810 옆에 _20260820을 넣으면
같은 도면의 새 판으로 자동 인식. 띄어쓰기·대소문자 차이는 무시합니다</li>
<li><b>이름이 달라 못 엮은 판은 직접 지정</b> — 변경 상세의 [이전 판 직접 지정]에서
파일을 골라 짝지으면 즉시 비교되고, 이후에도 그 짝을 기억합니다</li>
<li><b>폴더가 곧 프로젝트</b> — 감시 폴더 바로 아래 첫 폴더명이 프로젝트가 되고,
표제란에 프로젝트 번호가 있으면 그게 우선</li>
<li><b>저장만 누른 파일은 안 잡힙니다</b> — 내용이 실제로 바뀌어야 변경</li>
<li><b>잠긴 파일은 건너뜁니다</b> — "읽지 못한 파일"로 표시되고 다음 검사에서 재시도.
삭제로 오인하지 않습니다</li>
</ul></div>"""
        return _page("도움말", "/help", body.format(
            intro=_intro("궁금한 항목을 클릭해 펼쳐 보세요.")))

    def root_project_status(self, path: str) -> tuple[str, str]:
        """(상태, 이름) — 'declared' 지정됨 / 'auto' 이름에서 자동 / 'split' 하위 폴더별."""
        from watcher.cli import make_resolver
        cfg = self.cfg()
        declared = cfg.get("root_projects") or {}
        if path in declared:
            return ("declared", str(declared[path] or "")) if declared[path] else ("split", "")
        label = self.root_label_of(path)
        if label is None:
            return "split", ""
        rp = make_resolver(cfg, list(cfg["roots"])).root_projects.get(label)
        return ("auto", rp) if rp else ("split", "")

    def set_root_project(self, path: str, name: str) -> str:
        """감시 폴더 전체를 프로젝트 하나로 — 설정 저장 + 이미 갈린 이력 합치기.

        합치기는 되돌릴 수 있는 기록으로 남긴다 (프로젝트 화면 [합친 기록])."""
        name = (name or "").strip()
        label = self.root_label_of(path)
        if label is None:
            return "그 폴더는 감시 목록에 없습니다."
        rp = dict(self.cfg().get("root_projects") or {})
        rp[path] = name                       # ""이면 '하위 폴더별'로 되돌리는 뜻
        self._save_key("root_projects", rp)
        invalidate_doc_nav()
        if not name:
            return "이 폴더는 다시 하위 폴더별로 프로젝트를 나눕니다 (다음 검사부터)."
        merged = {"changes": 0, "issues": 0}
        if self.db().exists():
            with State(self.db()) as st:
                pre = label + "/"
                others = sorted({r[0] for r in st.conn.execute(
                    "SELECT DISTINCT IFNULL(project,'미분류') FROM changes "
                    "WHERE substr(path,1,?) = ?", (len(pre), pre))} - {name})
                if others:
                    # 이 폴더 아래만 — 다른 감시 폴더의 같은 이름 이력은 건드리지 않는다
                    merged = st.merge_projects(name, others, path_prefix=pre)
        return (f"'{path}' 전체를 프로젝트 '{name}'(으)로 봅니다 — 갈려 있던 이력 "
                f"{merged['changes']}건을 합쳤습니다 (프로젝트 화면 [합친 기록]에서 "
                f"되돌릴 수 있음). 다음 검사부터도 같은 프로젝트로 잡힙니다.")

    def root_split_nudge(self, rows: list | None = None) -> str:
        """감시 폴더의 하위 폴더들이 프로젝트로 잡힌 흔적이 있으면 한 번 묻는다.

        판정: 그 폴더 아래 이력의 프로젝트 이름이 3개 이상이고, 그 이름들이 전부
        바로 아래 폴더 이름과 같다 — '폴더 구조' 규칙이 만든 모양이다 (2026-09-02)."""
        cfg = self.cfg()
        declared = cfg.get("root_projects") or {}
        rows = self.rows() if rows is None else rows   # 대시보드는 이미 읽은 것을 넘긴다
        if not rows:
            return ""
        out = ""
        for r_path in cfg["roots"]:
            if r_path in declared:
                continue
            label = self.root_label_of(r_path)
            if not label:
                continue
            status, auto_name = self.root_project_status(r_path)
            projs, subs = set(), set()
            for r in rows:
                pth = r["path"]
                if not pth.startswith(label + "/"):
                    continue
                projs.add(_proj_of(r))
                parts = pth.split("/")
                if len(parts) >= 3:
                    subs.add(parts[1])
            if len(projs) >= 3 and projs <= subs and status == "auto":
                # 구조·이름으로 이미 프로젝트 하나로 안다 — 앞으로의 검사는 맞게
                # 잡히지만, 예전 검사에서 갈린 이력은 합쳐야 화면이 하나가 된다
                n_rows = sum(1 for r in rows if r["path"].startswith(label + "/")
                             and _proj_of(r) in projs)
                out += (f'<div class="panel" style="border-left:4px solid var(--warn)">'
                        f'📁 <b>{_E(r_path)}</b>는 프로젝트 하나(<b>{_E(auto_name)}</b>)로 '
                        f'인식됩니다. 예전 검사에서 하위 폴더별로 갈린 이력 {n_rows}건을 '
                        f'합칠까요? '
                        f'<form class="inline" method="post" action="/root/asproject">'
                        f'{self._tok()}<input type="hidden" name="path" value="{_E(r_path)}">'
                        f'<input type="hidden" name="name" value="{_E(auto_name)}">'
                        f'<button class="btn" style="font-size:12px;padding:4px 12px">'
                        f'이력 합치기</button></form> '
                        f'<span class="muted" style="font-size:12px">되돌릴 수 있습니다 '
                        f'(프로젝트 화면 [합친 기록]).</span></div>')
                continue
            by_folder = projs <= subs
            # 하위 폴더가 그대로 프로젝트가 된 모양(3개 이상)이거나, 어디서 왔든
            # 프로젝트가 5개 이상 — 파일명·표제란에서 갈린 경우도 사람이 "이 폴더는
            # 하나"라고 말할 수 있어야 한다 (2026-09-02: "프로젝트 그대로 40개 유지")
            if status == "split" and ((len(projs) >= 3 and by_folder) or len(projs) >= 5):
                from watcher.project import PROJECT_NO_RE
                m = PROJECT_NO_RE.search(Path(r_path).name)
                guess = m.group() if m else Path(r_path).name
                sample = _E(", ".join(sorted(projs)[:4])) + (" …" if len(projs) > 4 else "")
                lead = (f'바로 아래 폴더 {len(projs)}개가 각각 프로젝트로 잡혔습니다'
                        if by_folder else
                        f'아래에서 프로젝트가 {len(projs)}개로 잡혔습니다')
                # 한 번만 묻는 질문 — 흔한 답(여러 프로젝트)을 앞에, 예외(폴더 전체가 하나)를 뒤에.
                # "이름을 적고 묶어주세요"에 '서버'가 선입력돼 팀장이 무슨 뜻인지 몰랐다 (파일럿 모의 day1)
                out += (f'<div class="panel" style="border-left:4px solid var(--warn)">'
                        f'📁 <b>{_E(r_path)}</b> {lead} ({sample}). <b>한 번만 확인해 주세요:</b> '
                        f'하위 폴더들이 각각 다른 프로젝트가 맞으면 (보통 그렇습니다) '
                        f'<form class="inline" method="post" action="/root/asproject">'
                        f'{self._tok()}<input type="hidden" name="path" value="{_E(r_path)}">'
                        f'<input type="hidden" name="name" value="">'
                        f'<button class="btn" style="font-size:12px;padding:4px 12px">'
                        f'여러 프로젝트가 맞음</button></form> '
                        f'<span class="muted" style="font-size:12px">— 반대로 이 폴더 전체가 프로젝트 '
                        f'하나(예: 폴더 이름이 프로젝트 번호)라면 이름을 적고 </span>'
                        f'<form class="inline" method="post" action="/root/asproject">'
                        f'{self._tok()}<input type="hidden" name="path" value="{_E(r_path)}">'
                        f'<input type="text" name="name" value="{_E(guess)}" size="14"> '
                        f'<button class="btn gray" style="font-size:12px;padding:4px 12px">'
                        f'프로젝트 하나로 묶기</button></form></div>')
        return out

    def root_label_of(self, path: str) -> str | None:
        """감시 폴더 경로 → 기록의 경로 접두어(라벨). 검사와 같은 규칙."""
        from watcher.cli import _root_labels
        roots = list(self.cfg()["roots"])
        if path not in roots:
            return None
        return _root_labels([Path(r) for r in roots])[roots.index(path)]

    def guess_root_kind(self, path: str) -> tuple[str, str, list]:
        """폴더를 추가하기 전 미리 보기: ('one'|'multi', 추천 이름, 바로 아래 폴더들).

        추천은 기본값일 뿐 — 답은 사람이 한다 (2026-09-02). 바로 아래 폴더가 도면·
        구매 같은 종류 이름이면 '하나', 번호·고객사 이름이면 '여럿'."""
        from watcher.doctype import looks_like_doctype_folder
        from watcher.project import PROJECT_NO_RE, ProjectResolver
        p = Path(path)
        subs: list[str] = []
        try:
            with os.scandir(p) as it:
                for e in it:
                    if e.is_dir() and not e.name.startswith((".", "~$")):
                        subs.append(e.name)
                    if len(subs) >= 200:
                        break
        except OSError:
            pass
        subs.sort()
        cfg = self.cfg()
        resolver = ProjectResolver.load(cfg.get("aliases") or "aliases.yaml")
        m = PROJECT_NO_RE.search(p.name)
        if m or resolver.canonical(p.name):
            return "one", (resolver.canonical(p.name) or m.group()), subs
        if any(resolver._find_in(s) for s in subs):
            return "multi", "", subs
        typed = sum(1 for s in subs if looks_like_doctype_folder(s, cfg))
        if len(subs) >= 2 and typed / len(subs) >= 0.6:
            return "one", p.name, subs
        if not subs:                       # 파일만 있는 폴더 — 프로젝트 하나
            return "one", p.name, subs
        return "multi", "", subs

    def page_root_confirm(self, path: str, to: str) -> str:
        """감시 폴더 추가 전 확인 — 이 폴더가 프로젝트 하나인지 여럿인지 (2026-09-02)."""
        to = "onboard" if (to == "onboard" and not self.cfg()["roots"]) else "root"
        path = (path or "").strip().strip('"')
        if not path or not Path(path).is_dir():
            return _page("감시 폴더 추가", "/settings",
                         f'<div class="panel"><p>폴더를 찾을 수 없습니다: {_E(path)}</p>'
                         f'<p><a class="btn" href="{"/" if to == "onboard" else "/settings"}">'
                         f'돌아가기</a></p></div>')
        kind, name, subs = self.guess_root_kind(path)
        preview = ("".join(f'<li>{_E(s)}/</li>' for s in subs[:12])
                   + (f'<li class="muted">… 외 {len(subs) - 12}개</li>' if len(subs) > 12 else ""))
        # 드라이브 루트(C:\)·사용자 프로필은 $Recycle.Bin·Program Files까지 훑게 된다 — 경고 없이
        # [이대로 시작]을 주던 것 (검토21 설치 중간 3)
        warn = ""
        try:
            rp = Path(path).resolve()
            if rp.parent == rp or rp == Path.home() or rp == Path.home().parent:
                warn = ('<p style="color:var(--warn2)"><b>드라이브 전체(또는 사용자 폴더)입니다.</b> '
                        '시스템·프로그램 폴더까지 검사하게 되어 느리고 잡음이 많습니다 — 도면·문서가 있는 '
                        '하위 폴더(예: 설계부, 프로젝트)를 고르는 것을 권합니다.</p>')
        except OSError:
            pass
        body = (f'<div class="topbar"><h1>이 폴더는 어떤 폴더인가요?</h1></div>'
                f'<div class="panel"><p><b>{_E(path)}</b></p>{warn}'
                f'<p class="muted">바로 아래 폴더: {len(subs)}개</p>'
                f'<ul style="columns:2;margin:6px 0 14px 18px;font-size:13px">{preview or "<li class=muted>(하위 폴더 없음)</li>"}</ul>'
                f'<form method="post" action="/root/confirm/do">{self._tok()}'
                f'<input type="hidden" name="path" value="{_E(path)}">'
                f'<input type="hidden" name="to" value="{to}">'
                f'<label style="display:block;margin:8px 0"><input type="radio" name="mode" '
                f'value="one"{" checked" if kind == "one" else ""}> <b>프로젝트 하나</b> '
                f'<span class="muted">— 이 폴더 전체가 한 프로젝트. 아래는 도면·구매·사양서 '
                f'같은 종류별 폴더</span><br>'
                f'<span style="margin-left:22px">프로젝트 이름: '
                f'<input type="text" name="name" value="{_E(name or Path(path).name)}" '
                f'size="24"></span></label>'
                f'<label style="display:block;margin:8px 0"><input type="radio" name="mode" '
                f'value="multi"{" checked" if kind == "multi" else ""}> <b>여러 프로젝트</b> '
                f'<span class="muted">— 바로 아래 폴더 하나하나가 프로젝트 '
                f'(예: P26-001 A사/, P26-002 B사/). 여러 수주 폴더가 모인 상위 폴더면 '
                f'이쪽</span></label>'
                f'<p class="muted" style="font-size:12.5px">추천 값은 폴더 안을 보고 고른 '
                f'기본값입니다. 나중에 [설정]의 감시 폴더 줄에서 언제든 바꿀 수 있습니다.</p>'
                f'<button class="btn">{"이대로 시작 (첫 검사)" if to == "onboard" else "이대로 추가"}'
                f'</button> <a class="btn gray" href="{"/" if to == "onboard" else "/settings"}">'
                f'취소</a></form></div>')
        return _page("감시 폴더 추가", "/settings", body, self.pop_msg())

    def add_root_confirmed(self, path: str, to: str, mode: str, name: str) -> str:
        """확인을 거친 추가 — 감시 폴더 + '하나/여럿' 지정을 함께 저장한다."""
        path = (path or "").strip().strip('"')
        if not path or not Path(path).is_dir():
            return f"폴더를 찾을 수 없습니다: {path}"
        key = str(Path(path))
        if to == "onboard" and self.cfg()["roots"]:
            to = "root"                    # 이미 감시 중이면 '추가'다 — 목록을 갈아치우지 않는다
        roots = [] if to == "onboard" else list(self.cfg()["roots"])
        # 설정에는 슬래시·백슬래시 표기가 섞여 있다 — 경로로 비교
        if any(Path(r) == Path(path) for r in roots):
            return "이미 감시 중인 폴더입니다."
        roots.append(key)
        self.save_roots(roots)
        rp = dict(self.cfg().get("root_projects") or {})
        # 'C:\'는 .name이 빈 문자열 — 프로젝트 하나를 골랐는데 이름 없이 저장돼 하위 폴더별로 처리됐다
        rp[key] = (name or Path(path).name or Path(path).anchor.rstrip("\\/")).strip() if mode == "one" else ""
        self._save_key("root_projects", rp)
        invalidate_doc_nav()
        how = (f"프로젝트 하나 '{rp[key]}'" if mode == "one" else "여러 프로젝트(하위 폴더별)")
        # 기록을 남긴 채 뺐다가 다시 넣은 폴더는 첫 검사가 아니다 — "첫 검사(기준선)"라 말하지 않는다
        # (검토20 B-1). 기록이 없으면 새 폴더의 첫 등록은 기준선으로 기록된다
        fresh = self.baseline_id() is None
        if to == "onboard":
            self.start_scan()
            return (f"감시 시작: {path} ({how}) — "
                    + ("첫 검사(기준선)가 진행 중입니다." if fresh else
                       "검사가 진행 중입니다 (이 폴더의 첫 등록은 변경이 아니라 기준선으로 기록됩니다)."))
        return (f"감시 폴더 추가됨: {path} ({how}) — [지금 검사]로 "
                + ("기준선을 만드세요." if fresh else "등록하세요 (이 폴더의 첫 등록은 변경이 아니라 기준선입니다)."))

    def page_root_remove(self, path: str) -> str:
        """감시 폴더 제거 확인 — 그 아래 기록을 지울지 남길지 고른다 (2026-09-02)."""
        label = self.root_label_of(path)
        if label is None:
            return _page("감시 폴더 제거", "/settings",
                         '<div class="panel"><p>그 폴더는 감시 목록에 없습니다.</p>'
                         '<p><a class="btn" href="/settings">설정으로</a></p></div>')
        st_ = {"files": 0, "changes": 0, "acks": 0, "issues": 0}
        count_err = ""
        if self.db().exists():
            try:
                with State(self.db()) as st:
                    st_ = st.prefix_stats(label)
            except Exception as e:
                # 세는 데 실패해도 화면은 나와야 한다 — 전에는 연결이 그냥 끊겨
                # 사용자가 빈 화면을 봤다 (2026-09-09 저장 검토 차단 2)
                count_err = str(e)
        stats_html = (
            f'<p style="color:var(--warn2)">이 폴더에 쌓인 기록이 몇 건인지 세지 '
            f'못했습니다 ({_E(count_err)}) — 감시 중단은 그래도 됩니다.</p>'
            if count_err else
            f'<p>이 폴더 아래에 쌓인 <b>검사 기록</b>: 파일 {st_["files"]}개, '
            f'변경 {st_["changes"]}건, 확인 {st_["acks"]}건, 검토 필요 '
            f'{st_["issues"]}건</p>')
        last_note = ""
        if len(self.cfg().get("roots") or []) <= 1:
            last_note = ('<p style="color:var(--warn2)"><b>마지막 감시 폴더입니다.</b> 빼면 감시 '
                         '폴더가 없어 검사가 멈추고 시작 화면으로 돌아갑니다 — 잘못 등록한 폴더를 '
                         '다시 등록하려는 것이면 그렇게 하셔도 됩니다 (기록까지 삭제 → 다시 추가).</p>')
        body = (f'<div class="topbar"><h1>감시 폴더 제거</h1></div>'
                f'<div class="panel"><p><b>{_E(path)}</b> 을(를) 감시 목록에서 뺍니다. '
                f'서버의 파일은 그대로입니다 — 이 프로그램은 파일을 건드리지 않습니다.</p>'
                f'{last_note}{stats_html}'
                f'<form method="post" action="/root/del/do">{self._tok()}'
                f'<input type="hidden" name="path" value="{_E(path)}">'
                f'<button class="btn red" name="purge" value="1" '
                f'onclick="return confirm(&quot;이 폴더 아래 기록 {st_["changes"]}건을 '
                f'지웁니다. 되돌릴 수 없습니다. 계속할까요?&quot;)">기록까지 삭제</button> '
                f'<button class="btn gray" name="purge" value="0">감시만 중단 (기록 유지)'
                f'</button> <a class="btn gray" href="/settings">취소</a></form>'
                f'<p class="muted" style="font-size:12.5px;margin-top:10px">기록을 남기면 '
                f'이력·프로젝트 화면에 이 폴더의 파일이 계속 보입니다. 폴더를 통째로 '
                f'옮기거나 없앤 경우라면 지우는 쪽이 맞습니다.</p></div>')
        return _page("감시 폴더 제거", "/settings", body)

    def dwg_test(self) -> str:
        """[DWG 변환 시험] — 감시 중인 DWG 하나로 변환→읽기까지 돌려 결과 문장."""
        from watcher.convert import test_convert
        if not self.db().exists():
            return "아직 검사한 적이 없어 시험할 DWG가 없습니다 — [지금 검사] 후 다시 눌러주세요."
        with State(self.db()) as st:
            keys = [k for k in sorted(st.latest_snapshot().keys()) if k.lower().endswith(".dwg")]
            st.set_meta("dwg_backoff_until", None)      # 사람이 다시 시도하면 건너뛰기 해제
        for key in keys[:5]:
            ap = self.abs_path_of(key)
            if ap is not None:
                ok, msg = test_convert(self.cfg(), ap)
                return ("✔ " if ok else "✖ ") + msg
        return "감시 중인 DWG 파일이 없거나 지금 접근할 수 없습니다."

    _REACH: dict = {}              # {경로: (판정시각, 닿는가)}

    @staticmethod
    def reachable(path: str, timeout: float = 1.2) -> bool | None:
        """폴더에 닿는가. True/False/None(시간 안에 답이 없음).

        끊긴 네트워크 경로의 is_dir()은 윈도우에서 수십 초 멈춘다 — 화면을 그리다
        굳지 않게 스레드에 맡기고 기다리는 시간을 끊는다. 판정은 20초만 재사용한다."""
        now = time.time()
        got = WebApp._REACH.get(path)
        if got and now - got[0] < 20:
            return got[1]
        out: list = []

        def _look():
            try:
                out.append(Path(path).is_dir())
            except OSError:
                out.append(False)
        th = threading.Thread(target=_look, daemon=True)
        th.start()
        th.join(timeout)
        ans = out[0] if out else None
        # 시간 초과도 캐시한다 — 전에는 응답 없는 경로가 매 렌더마다 1.2초를 새로 물고
        # is_dir()에 갇힌 데몬 스레드를 하나씩 더 만들었다 (2026-09-09 배포 후 검토)
        WebApp._REACH[path] = (now, ans)
        return ans

    def storage_panel(self) -> str:
        """지금 디스크를 얼마나 쓰고 있나 — 전에는 어디에도 안 나와서, 브리핑 폴더가
        수십 GB가 되도록 아무도 몰랐다 (2026-09-09 저장 검토 차단 4·중간 6)."""
        try:
            cfg = self.cfg()
            db = Path(cfg["state_db"])
            rep = {"bytes": db.stat().st_size if db.exists() else 0, "free_bytes": 0}
            if db.exists():
                with State(db) as st:
                    rep = st.space_report()
            bsize, bn = _dir_size_cached(Path(cfg["brief_dir"]))
            bk, _ = _dir_size_cached(db.parent / "backups")
        except BaseException:      # 설정이 없으면 load_config가 SystemExit을 낸다
            return ""

        def mb(n: int) -> str:
            return f"{n / 1024 ** 3:.1f}GB" if n >= 1024 ** 3 else f"{n / 1048576:.0f}MB"

        free = (f' (그 중 빈 공간 {mb(rep["free_bytes"])} — 다음 검사에서 회수)'
                if rep["free_bytes"] > 32 * 1048576 else "")
        days = int(cfg.get("retention_days", 90) or 0)
        note = ("" if days else
                '<div class="muted" style="color:var(--warn2)">보존 기간이 '
                "'정리 안 함'(0)입니다 — 이력 파일이 계속 커집니다.</div>")
        return (f'<div class="muted" style="margin-top:10px;border-top:1px solid '
                f'var(--border);padding-top:8px">지금 쓰는 공간 — 이력 파일 '
                f'<b>{mb(rep["bytes"])}</b>{free} · 백업 <b>{mb(bk)}</b> · '
                f'브리핑 <b>{mb(bsize)}</b>({bn}개)<br>'
                f'브리핑 폴더: <code>{_E(str(Path(cfg["brief_dir"])))}</code> — '
                f'Drev는 파일을 지우지 않습니다. 오래된 브리핑은 직접 정리하세요.'
                f'</div>{note}')

    def page_settings(self) -> str:
        cfg = self.cfg()
        roots = list(cfg["roots"])
        multi = len(roots) > 1
        def _rp_cell(r: str) -> str:
            st_, nm = self.root_project_status(r)
            label = {"declared": f"프로젝트 하나: <b>{_E(nm)}</b>",
                     "auto": f"프로젝트 하나 (자동 인식): <b>{_E(nm)}</b>",
                     "split": "하위 폴더별로 프로젝트 구분"}[st_]
            return (f'<div class="muted" style="font-size:12px;margin-top:4px">{label} · '
                    f'<form class="inline" method="post" action="/root/asproject">'
                    f'{self._tok()}<input type="hidden" name="path" value="{_E(r)}">'
                    f'<input type="text" name="name" size="12" value="{_E(nm)}" '
                    f'placeholder="프로젝트 이름"> '
                    f'<button class="btn gray" style="font-size:12px;padding:2px 8px">'
                    f'프로젝트 하나로</button></form>'
                    + (f' <form class="inline" method="post" action="/root/asproject">'
                       f'{self._tok()}<input type="hidden" name="path" value="{_E(r)}">'
                       f'<input type="hidden" name="name" value="">'
                       f'<button class="btn gray" style="font-size:12px;padding:2px 8px">'
                       f'하위 폴더별로</button></form>' if st_ != "split" else "")
                    + "</div>")

        def _reach_cell(r: str) -> str:
            """닿지 않는 폴더를 평소와 똑같은 행으로 보여 주던 것 (웹 검토 차단 1)."""
            ok = self.reachable(r)
            if ok is True:
                return ""
            if ok is None:
                return ('<span class="tag na" title="응답이 느립니다 — 네트워크 드라이브일 수 있습니다">'
                        '응답 느림</span> ')
            return ('<span class="tag bad" title="이 폴더를 열지 못합니다 — 검사가 건너뜁니다">'
                    '접근 불가</span> ')

        root_rows = "".join(
            f"<tr><td>{_reach_cell(r)}{_E(r)}{_rp_cell(r)}</td>"
            f"<td class='muted' style='width:120px'>{_E(Path(r).name) if multi else ''}</td>"
            f"<td style='width:90px'>"
            # 마지막 폴더도 뺄 수 있다 — 잘못 등록한 유일한 폴더를 되돌릴 길이 UI에 없었다
            # (2026-09-11 실사용 첫날). 폴더가 없으면 시작 화면으로 돌아가고 검사는 멈춘다
            + (f'<a class="btn gray" style="text-decoration:none" '
               f'href="/root/remove?path={quote(r)}">제거</a>')
            + "</td></tr>"
            for r in roots) or '<tr><td class="muted" colspan="3">감시 폴더 없음</td></tr>'
        excludes = list(cfg.get("exclude") or [])
        items = "".join(
            f'<tr><td><span class="tag na">'
            f'{"파일" if "." in PurePosixPath(e).name else "폴더"}</span> '
            f'{_E(e)}</td><td style="width:110px">'
            f'<form class="inline" method="post" action="/exclude/del">{self._tok()}'
            f'<input type="hidden" name="path" value="{_E(e)}">'
            f'<button class="btn gray">다시 감시</button></form></td></tr>'
            for e in excludes) or ('<tr><td class="muted" colspan="2">'
                                   '제외한 폴더·파일이 없습니다</td></tr>')
        install_panel = self.install_panel()
        doctype_panel = self.doctype_panel()
        mail = cfg.get("mail") or {}
        from watcher.cli import schedule_start_time, schedule_status, schedule_target
        sched_on = schedule_status()
        sched_target = schedule_target() if sched_on else None
        # 시각도 등록된 작업에서 읽는다 — config만 보면 구판·수동으로 바뀐 시각을 모른다 (검토19 운영 ⑦)
        sched_time = ((schedule_start_time() if sched_on else None)
                      or str(cfg.get("schedule_time") or "07:00"))
        sched_broken = bool(sched_on and sched_target and not Path(sched_target).exists())
        # 등록된 작업이 **이 설치본**을 가리키는지 — 포터블로 시험하다 설치판으로 갈아탄 PC에서 화면은
        # "등록됨"인데 07시엔 옛 폴더가 돌았다 (검토21 설치 중간 4)
        sched_foreign = False
        if sched_on and sched_target and not sched_broken:
            try:
                from watcher import selfupdate as _su2
                _root2 = _su2.install_root() or Path.cwd()
                sched_foreign = not str(Path(sched_target).resolve()).lower().startswith(
                    str(_root2.resolve()).lower().rstrip("\\") + "\\")
            except OSError:
                sched_foreign = False
        # v0.49.1 이전 판이 등록한 배치(.bat) 작업 — 창이 뜨고 절전·배터리 조건이 없다. 업데이트가
        # 재등록하지 않으므로 화면이 새 동작을 단정하면 안 된다 (리뷰10 중간-5)
        sched_legacy = bool(sched_on and sched_target and not sched_broken
                            and sched_target.lower().endswith((".bat", ".cmd")))
        # 예전 판이 평문으로 둔 비밀번호는 화면을 여는 김에 감싸 둔다 (2026-09-05)
        pw_note = ""
        try:
            from watcher.secret import available, is_protected, protect
            _m = dict(cfg.get("mail") or {})
            if _m.get("password") and not is_protected(_m["password"]):
                if available():
                    _m["password"] = protect(_m["password"])
                    if is_protected(_m["password"]):
                        self._save_key("mail", _m)
                        pw_note = " (저장돼 있던 비밀번호를 방금 암호화했습니다)"
                else:
                    pw_note = " (이 운영체제에서는 암호화되지 않아 평문으로 남습니다)"
        except Exception:
            pass
        try:
            from watcher import ocr as _ocr
            _ok, _why = _ocr.status()
            ocr_state = (f'<span class="tag done">사용 가능</span> 언어 {_E(_ocr.language() or "?")}' if _ok
                         else f'<span class="tag na">사용 불가</span> — {_E(_why)}')
        except Exception as e:
            ocr_state = f'<span class="tag na">사용 불가</span> {_E(str(e)[:80])}'
        pend = getattr(self, "pending_exclude", None)
        pending_ex = (
            f'<form method="post" action="/exclude/add" class="inline" style="margin-top:8px">'
            f'{self._tok()}<input type="hidden" name="path" value="{_E(pend)}">'
            f'<input type="hidden" name="force" value="1">'
            f'<span class="tag na">없는 경로</span> <code>{_E(pend)}</code> '
            f'<button class="btn gray" style="font-size:12px;padding:3px 10px">그래도 등록</button></form>'
            if pend else "")
        from watcher.extract import READABLE_EXTS as extractable   # 한 곳에서만 정의 (검토18 ④)
        # 감시 확장자 편집 — PLC(.gxw 등)·한글(.hwp) 등 어떤 형식이든 파일 수준
        # 감시는 사용자가 직접 추가 (2026-08-29 PLC 검토에서 범용화)
        exts = [str(e).lower() for e in (cfg.get("extensions") or [])]
        from watcher.scan import EXT_PRESETS, preset_of
        # 묶음 칩 — 타자 없이 한 번에 켜고 끈다 (2026-09-10 "최대한 편하고 쉽게")
        chips = []
        for key, (label, why, g_exts) in EXT_PRESETS.items():
            have = sum(1 for e in g_exts if e in exts)
            full = have == len(g_exts)
            chips.append(
                f'<form class="inline" method="post" action="/ext/preset" '
                f'style="margin:0 6px 6px 0">{self._tok()}'
                f'<input type="hidden" name="name" value="{_E(key)}">'
                f'<input type="hidden" name="on" value="{"0" if full else "1"}">'
                f'<button class="btn {"gray" if full else ""}" '
                f'style="font-size:13px;padding:5px 11px" '
                f'title="{_E(why)} — {_E(", ".join(g_exts[:10]))}'
                f'{" …" if len(g_exts) > 10 else ""}">'
                f'{"✓ " if full else "+ "}{_E(label)} '
                f'<span style="opacity:.7">({have}/{len(g_exts)})</span>'
                f'</button></form>')
        ext_chips = "".join(chips)
        ext_by_group: dict[str, int] = {}
        for e in exts:
            k = preset_of(e)
            if k:
                ext_by_group[k] = ext_by_group.get(k, 0) + 1
        def _del_btn(e: str) -> str:
            return (f'<form class="inline" method="post" action="/ext/del">{self._tok()}'
                    f'<input type="hidden" name="ext" value="{_E(e)}">'
                    f'<button class="btn gray">제거</button></form>' if len(exts) > 1
                    else '<span class="muted">최소 1개</span>')

        def _note(e: str) -> str:
            if e in extractable:
                return '<span class="muted">(내용 비교 지원)</span>'
            if e == ".dwg":
                return '<span class="muted">(변환 프로그램이 있으면 내용 비교 — 아래 DWG 도면 항목)</span>'
            return '<span class="muted">(변경 사실·크기·저장 시각만)</span>'
        # 묶음으로 들어온 확장자는 표에서 접는다 — 106개가 한 줄씩 펼쳐지면 못 읽는다.
        # 접힌 줄을 펼치면 낱개 [제거]가 있다 — 전에는 묶음 멤버 하나를 뺄 길이 화면에
        # 없었고, 160자에서 잘라 "40개"라며 28개만 보였다 (검토18 웹 ⑤⑥)
        loose = [e for e in exts if not preset_of(e)]
        folded = ""
        for k, n in sorted(ext_by_group.items()):
            members = [e for e in exts if preset_of(e) == k]
            inner = "".join(
                f'<div style="display:flex;align-items:center;gap:8px;padding:2px 0">'
                f'<code>{_E(e)}</code>{_del_btn(e)}</div>' for e in members)
            folded += (f'<tr><td colspan="2"><details><summary class="muted" '
                       f'style="cursor:pointer;font-size:12px">↳ {_E(EXT_PRESETS[k][0])} 묶음 '
                       f'{n}개 — 펼치면 하나씩 뺄 수 있습니다</summary>'
                       f'<div style="padding:4px 0 2px 14px">{inner}</div></details></td></tr>')
        ext_rows = "".join(
            f"<tr><td><code>{_E(e)}</code> {_note(e)}</td><td style='width:90px'>{_del_btn(e)}</td></tr>"
            for e in loose) + folded
        from watcher.convert import ODA_URL, status as dwg_status
        dwg_ok, dwg_msg = dwg_status(cfg)
        snap_paths = []
        if self.db().exists():
            with State(self.db()) as st:
                snap_paths = sorted(st.latest_snapshot().keys())
        n_dwg = sum(1 for p_ in snap_paths if p_.lower().endswith(".dwg"))
        dwg_test = (f'<form class="inline" method="post" action="/dwg/test">{self._tok()}'
                    f'<button class="btn gray" title="감시 중인 DWG 하나를 실제로 변환해 봅니다 '
                    f'(원본은 읽기만, 결과는 임시 폴더)">DWG 변환 시험</button></form> '
                    f'<span class="muted" style="font-size:12px">감시 중 DWG {n_dwg}개</span>'
                    if n_dwg else '<span class="muted" style="font-size:12px">감시 중인 DWG 없음</span>')
        file_options = "".join(
            f'<option value="{_E(p)}">' for p in snap_paths
            if PurePosixPath(p).suffix.lower() in extractable)[:40000]
        body = f"""
<div class="topbar"><h1>설정</h1></div>
{_intro("무엇을 감시할지 정합니다. 저장 즉시 적용되며, 감시 대상 파일은 절대 수정되지 않습니다.")}
<div class="panel" style="padding:8px 14px;display:flex;gap:14px;flex-wrap:wrap;font-size:13px">
<b class="muted">바로 가기</b>
<a href="#watch" style="color:var(--link)">감시 대상</a>
<a href="#who" style="color:var(--link)">확인자</a>
<a href="#ext" style="color:var(--link)">감시 확장자</a>
<a href="#keys" style="color:var(--link)">표 키 열</a>
<a href="#ocr" style="color:var(--link)">OCR</a>
<a href="#mail" style="color:var(--link)">메일·알림</a>
<a href="#auto" style="color:var(--link)">자동 실행·업데이트</a>
<a href="#screen" style="color:var(--link)">화면 여는 방식</a>
<a href="#advanced" style="color:var(--link)">고급</a></div>
<div class="panel" id="watch"><h2>감시 폴더 (각각 추가/제거 가능)</h2>
<table><tr><th>경로</th><th>{'구분 라벨' if multi else ''}</th><th></th></tr>{root_rows}</table>
<form method="post" action="/root/add" style="margin-top:10px">{self._tok()}
  <input type="text" name="path" placeholder="폴더 전체 경로 (예: \\\\fileserver\\도면서버 또는 D:\\projects)" size="46">
  <button class="btn">폴더 추가</button>
  </form>
<form class="inline" method="post" action="/pick/native" style="margin-top:10px">
  {self._tok()}<input type="hidden" name="to" value="root">
  <button class="btn gray">📁 찾아보기 (폴더 선택 창)</button></form>
<a href="/pick?to=root" class="muted" style="font-size:12px;margin-left:8px">
목록으로 고르기</a>
<p class="muted" style="margin-top:6px">여러 폴더를 감시하면 경로 앞에 폴더명 라벨이 붙어 구분됩니다.
폴더를 제거하면 그 안의 파일들은 삭제 알림 없이 감시에서만 빠집니다. 다음 검사부터 적용.</p></div>
{install_panel}
{doctype_panel}
<div class="panel" id="who"><h2>확인자 이름</h2>
<form method="post" action="/ackname/save" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">{self._tok()}
  <input type="text" name="ack_name" size="20" value="{_E(str(cfg.get('ack_name') or ''))}"
    placeholder="예: 김대리 (비우면 Windows 로그인명)">
  <button class="btn">저장</button>
  <span class="muted">변경을 확인할 때 이력·메일에 남는 이름입니다.</span></form></div>
<div class="panel" id="exclude"><h2>감시 제외 (폴더·파일)</h2>
<p class="muted" style="margin:0 0 8px">관리할 필요 없는 폴더나 파일을 빼둔 목록입니다.
[다시 감시]를 누르면 다음 검사부터 원래대로 돌아옵니다 — 그동안의 이력은 지워지지 않습니다.</p>
<table>{items}</table>
{pending_ex}
<form method="post" action="/exclude/add" style="margin-top:10px">{self._tok()}
  <input type="text" name="path" placeholder="루트 기준 폴더 경로 (예: 참고자료/외주)" size="42">
  <button class="btn">추가</button></form>
<p class="muted" style="margin-top:6px">다음 검사부터 적용됩니다. 제외해도 삭제 알림은
나가지 않고, 감시에서만 조용히 빠집니다. 경로는 / 또는 \\ 어느 쪽으로 적어도 됩니다.</p></div>
<div class="panel" id="ext"><h2>감시 확장자 (어떤 파일을 지켜볼지)</h2>
<p class="muted" style="margin-top:0">묶음을 누르면 그 형식들이 한 번에 켜지고, ✓ 표시된 묶음을 다시 누르면
그 묶음이 넣은 것만 빠집니다. 다음 검사부터 적용. <b>내용을 못 읽는 형식도</b> 바뀐 사실·크기·저장 시각·이름 변경은
관리합니다.</p>
<div style="display:flex;flex-wrap:wrap;margin-bottom:4px">{ext_chips}</div>
<table>{ext_rows}</table>
<form method="post" action="/ext/add" style="margin-top:10px">{self._tok()}
  <input type="text" name="ext" placeholder="예: gxw (PLC), hwp — 점은 안 붙여도 됨" size="30">
  <button class="btn">추가</button></form>
<p class="muted" style="margin-top:6px">내용 비교(글자·표·그림)는 dxf·pdf·xlsx·docx·hwpx를 지원하고,
dwg는 변환 프로그램이 있을 때 됩니다. 그 외 확장자는 <b>"언제 어떤 파일이 바뀌었나"</b>(파일 수준)와 판 짝짓기·이력·확인·바로 열기가
됩니다 — PLC 프로그램(.gxw, .xgwx 등)도 이렇게 감시할 수 있습니다. 다음 검사부터 적용.</p></div>
<div class="panel"><h2>DWG 도면 (변환 프로그램)</h2>
<p style="margin-top:0">현재: {'<span class="tag done">사용 가능</span>' if dwg_ok else '<span class="tag na">없음</span>'} {_E(dwg_msg)}</p>
<form method="post" action="/dwg/save">{self._tok()}
  <input type="text" name="conv" size="56" value="{_E(cfg.get('dwg_converter') or '')}"
    placeholder="비우면 자동 탐지 (ODA File Converter · AutoCAD)">
  <button class="btn gray">저장</button></form>
<p style="margin-top:8px">{dwg_test}</p>
<p class="muted" style="margin-top:6px">DWG는 비공개 형식이라 Drev 혼자서는 글자·선을 읽지 못하고
파일 안의 <b>미리보기 그림(저해상도)</b>과 변경 사실만 봅니다. 이 PC에 <b>ODA File Converter</b>
(<a href="{ODA_URL}" target="_blank" style="color:var(--link)">opendesign.com</a> — 비회원은 비상업용만, <b>회사에서 쓰려면 ODA 회원 필요</b>)나
<b>AutoCAD</b>가 있으면 자동으로 찾고, 없으면 <b>Windows가 .dwg에 지정한 기본 앱</b>(CADian·ZWCAD 등)에
스크립트를 넘겨 DXF로 저장하게 해 글자·표제란·그림 비교까지 합니다. 이때 CAD가 <b>'SHX 파일 누락'</b> 같은
대화상자를 띄우면 변환이 멈춥니다 — CAD를 직접 열어 [누락된 SHX 파일을 무시하고 계속] + '현재 선택한 내용을
항상 수행'을 한 번 켜 두세요 (Drev는 3분간 결과가 없으면 자동으로 중단하고 이 사유를 남깁니다). 기본 앱 방식은 프로그램마다 다를 수 있으니
[DWG 변환 시험]으로 확인하세요. CADian·ZWCAD 등 ODA 계열 CAD로 만든 DWG도 ODA File Converter로 됩니다. 다른 프로그램은 명령을 직접 적을 수
있습니다 — 예: <code>"C:\\프로그램\\conv.exe" "{{in}}" "{{out}}"</code>
({{in}}=DWG 복사본, {{out}}=만들 DXF). <code>off</code>를 적으면 쓰지 않습니다.
변환은 Drev 임시 폴더에서만 하며 원본은 읽기만 합니다. 다음 검사부터 적용.</p></div>
<div class="panel" id="auto"><h2>매일 자동 실행 (아침 브리핑)</h2>
<p style="margin-top:0">현재 상태: {'<span class="tag na">등록은 있으나 가리키는 파일이 없음</span> — 프로그램을 옮기셨다면 아래 [자동 실행 등록]을 다시 눌러주세요' if sched_broken else
                                    f'<span class="tag warn">예전 방식으로 등록됨</span> 매일 {_E(sched_time)} — 검은 창이 잠깐 뜨고, 절전 중이거나 배터리 상태면 실행되지 않습니다. 아래 [자동 실행 등록]을 다시 눌러 창 없는 방식으로 바꿔주세요' if sched_legacy else
                                    f'<span class="tag warn">다른 폴더의 Drev가 등록됨</span> 매일 {_E(sched_time)} — 등록된 작업은 <code>{_E(sched_target or "")}</code>를 실행합니다. 지금 열린 이 Drev를 돌리려면 아래 [자동 실행 등록]을 다시 눌러주세요' if sched_foreign else
                                    f'<span class="tag done">등록됨</span> 매일 {_E(sched_time)} 자동 검사'
                                    if sched_on else '<span class="tag na">등록 안 됨</span> — 지금은 [지금 검사]를 눌러야만 검사합니다'}</p>
{'<form class="inline" method="post" action="/schedule/unregister">' + self._tok()
 + '<button class="btn gray">자동 실행 해제</button></form>' if sched_on and not sched_broken and not sched_legacy else
 '<form class="inline" method="post" action="/schedule/register">' + self._tok()
 + '매일 <select name="time" style="padding:5px 8px;border-radius:8px;border:1px solid var(--border2);background:var(--panel);color:var(--text)">'
 + "".join(f'<option value="{h:02d}:{m:02d}"{" selected" if f"{h:02d}:{m:02d}" == sched_time else ""}>{h:02d}:{m:02d}</option>'
           for h in range(5, 13) for m in (0, 30))
 + '</select>에 <button class="btn">자동 실행 등록</button></form>'}
{'<form class="inline" method="post" action="/schedule/unregister" style="margin-left:8px">' + self._tok()
 + '<button class="btn gray">예전 등록 해제</button></form>' if sched_legacy else ''}
<p class="muted" style="margin-top:6px">등록하면 Windows 작업 스케줄러에 ProjectWatcher 작업이 생깁니다.
<b>로그인된 상태</b>면 절전 중이어도 깨워서 실행하고, 그 시각을 놓쳤으면(꺼져 있었음) 다음에 켜질 때
바로 실행합니다. 배터리 상태에서도 돌고 창은 뜨지 않습니다. 완전히 꺼진 채 하루가 지나면 그날은 건너뜁니다.
실행 기록은 이 폴더의 watcher.log에 남습니다 (실행마다 '=== 날짜 시각 ===' 구분선이 찍힙니다). 감시 폴더가 네트워크 위치면
Z:\\ 드라이브 문자 대신 \\\\서버\\공유 형식으로 등록해야 자동 실행에서도 접근됩니다.</p></div>
<div class="panel"><h2>업데이트</h2>
<p style="margin-top:0">현재 버전: <b>v{__version__}</b>
{f' · <span style="color:var(--accent)">새 버전 v{_E(self.update_info["version"])} 사용 가능 — 왼쪽 메뉴 맨 위의 [설치]를 누르세요</span>' if self.update_info else ''}</p>
<form class="inline" method="post" action="/update/check">{self._tok()}
  <button class="btn">지금 업데이트 확인</button></form>
<form class="inline" method="post" action="/update/toggle" style="margin-left:8px">{self._tok()}
  <input type="hidden" name="on" value="{'0' if cfg.get('update_check', True) else '1'}">
  <button class="btn gray">{'시작 시 자동 확인 끄기' if cfg.get('update_check', True) else '시작 시 자동 확인 켜기'}</button></form>
<p class="muted" style="margin-top:6px">{'시작할 때 자동으로 확인합니다' if cfg.get('update_check', True) else '<b>자동 확인이 꺼져 있습니다</b> — 위 [지금 업데이트 확인]으로만 조회합니다'}
— 버전 숫자 파일(drev.co.kr/version.json) 하나만 조회하며 도면·경로·사용 정보는 아무것도 보내지 않습니다.
첫 실행 전에 미리 끄려면 프로그램 폴더에 config.yaml을 만들어 <code>update_check: false</code> 한 줄을 넣으세요.</p>
<p style="margin-top:10px"><b>무인 자동 설치</b>: {_auto_update_state_html(cfg, sched_on)}
<form class="inline" method="post" action="/update/auto" style="margin-left:8px">{self._tok()}
  <input type="hidden" name="on" value="{'0' if cfg.get('auto_update', True) else '1'}">
  <button class="btn gray">{'무인 자동 설치 끄기' if cfg.get('auto_update', True) else '무인 자동 설치 켜기'}</button></form>
<span class="muted">(config.yaml <code>auto_update: false</code>와 같음)</span></p></div>
<div class="panel" id="screen"><h2>화면 여는 방식</h2>
<p style="margin-top:0">지금 이 화면은 <b>{'기본 브라우저 탭' if browser_shell() else '프로그램 창'}</b>으로 열려 있습니다.
{f"— {_E(_browser_reason())} 그렇게 열렸습니다" if browser_shell() else ''}</p>
<p style="margin-top:0">이 PC의 창 엔진: <b>{_E(_engine_line())}</b></p>
<form method="post" action="/ui/save">{self._tok()}
  <label style="display:block;margin:4px 0"><input type="radio" name="ui" value="window"
    {"checked" if ui_mode(cfg) == "window" else ""}> <b>자체 창</b>
    <span class="muted">— 프로그램 창에 표시{'. 이 PC에서는 지금 쓸 수 없습니다(WebView2 필요) — 골라 두시면 설치된 뒤 자동으로 창으로 열립니다' if not _engine_ok() else ''}</span></label>
  <label style="display:block;margin:4px 0"><input type="radio" name="ui" value="browser"
    {"checked" if ui_mode(cfg) == "browser" else ""}> <b>기본 브라우저</b>
    <span class="muted">— 크롬·엣지 탭으로 표시 (창이 멎거나 클릭이 안 될 때)</span></label>
  <button class="btn gray" style="margin-top:6px">저장</button>
  <span class="muted" style="font-size:12px">다음 실행부터 적용</span></form>
<form class="inline" method="post" action="/open/browser" style="margin-top:10px">{self._tok()}
  <button class="btn gray">지금 브라우저에서 열기</button></form>
<p class="muted" style="margin-top:6px">회사 PC의 보안 소프트웨어·정책이 프로그램 창(WebView2)만
막는 경우가 있습니다. 브라우저에서는 정상인데 창이 계속 로딩 중이면 브라우저 모드로 쓰세요 —
기능은 같고, 주소는 <code>http://127.0.0.1:{self.port or 8765}/</code>입니다.</p></div>
<div class="panel" id="quit"><h2>프로그램 종료</h2>
<form class="inline" method="post" action="/quit">{self._tok()}
  <button class="btn red">프로그램 종료</button></form>
<p class="muted" style="margin-top:6px">{'<b>브라우저 탭을 닫는 것만으로는 꺼지지 않습니다</b> — Drev는 뒤에서 계속 돌며 매일 검사합니다. 완전히 끄려면 이 단추를 누르세요. ' if browser_shell() else '창을 닫는 것과 같습니다 — '}검사 중이어도 즉시
종료되며, 진행분은 저장되어 다음 검사가 이어받습니다.</p></div>
<div class="panel" id="keys"><h2>표의 행 식별 열 (BOM·발주서·자재표)</h2>
<form method="post" action="/keys/save" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">{self._tok()}
  <input type="text" name="key_columns" size="44" value="{_E(', '.join(str(c) for c in (cfg.get('key_columns') or [])))}"
    placeholder="예: 품번, PART NO, 자재코드 (쉼표로, 앞이 우선)">
  <button class="btn">저장</button></form>
<p class="muted" style="margin-top:6px"><b>보통은 비워 둡니다.</b> 비교할 때 두 판을 같이 보고 행이 가장 많이
맞춰지는 열(품번·자재코드류)을 양식마다 알아서 고릅니다. 그래도 특정 양식이 "행 삭제 + 추가"로만 보이면
그 양식의 열 이름을 여기 적어 강제할 수 있습니다 (쉼표로, 앞이 우선). 바꾸면 다음 검사에서 엑셀을 다시 읽습니다.</p></div>
<div class="panel" id="advanced"><h2>기록 보존 기간</h2>
<form method="post" action="/retention/save">{self._tok()}
  변경 상세(전/후 사진 포함)를
  <input type="text" name="days" size="5" value="{int(cfg.get('retention_days', 90) or 0)}">
  일 지나면 정리 (0 = 정리 안 함)
  <button class="btn gray">저장</button></form>
<p class="muted" style="margin-top:6px">지워지는 것: 기간이 지난 변경의 전/후 사진·상세
목록, 그 변경의 이전 판 페이지 그림(나란히 보기용), 옛 검사들의 파일 목록. 현재 판의 기록은
기간과 무관하게 남아 몇 달 뒤 변경도 비교됩니다. <b>남는 것: 변경 이력·확인 기록·최신 검사 상태</b> —
오래 잠자던 파일이 나중에 바뀌어도 감지·비교는 그대로 됩니다.</p>
{self.storage_panel()}</div>
<div class="panel" id="ocr"><h2>글자 없는 PDF 읽기 (Windows OCR)</h2>
<p style="margin-top:0">현재: {ocr_state if cfg.get('ocr', True) else '<span class="tag na">꺼짐</span> (설정)'}</p>
<form method="post" action="/ocr/save">{self._tok()}
  <label><input type="checkbox" name="on" value="1"{' checked' if cfg.get('ocr', True) else ''}> 스캔본·SHX 글꼴로 출력한 도면 PDF의 글자를 Windows 내장 OCR로 읽어 표제란(도면번호·Rev)과 글자 변경을 비교</label>
  <button class="btn gray">저장</button></form>
<p class="muted" style="margin-top:6px">OCR은 이 PC 안에서만 돌고 아무것도 밖으로 보내지 않습니다. 읽은 글자는 추정값이라 브리핑에 'OCR 추정값'
표시와 전/후 사진이 함께 붙습니다. Windows 한국어 언어팩이 있어야 하며(국내 PC는 기본), 없으면 예전처럼 '읽지 못함'으로 남깁니다. 다음 검사부터 적용.</p></div>
<div class="panel"><h2>파일 하나 시간 상한</h2>
<form method="post" action="/timeout/save">{self._tok()}
  파일 하나의 내용 읽기·그림 만들기가
  <input type="text" name="seconds" size="5" value="{int(cfg.get('extract_timeout') or 300)}">
  초 안에 끝나지 않으면 그 파일은 건너뜁니다 (1~7200, 기본 300)
  <button class="btn gray">저장</button></form>
<p class="muted" style="margin-top:6px">건너뛴 파일은 "변경 사실만 감시"로 남고 다음에 바뀌면 다시 시도합니다.
수만 행 엑셀·수백 장 PDF가 많으면 늘리고(예: 900), 검사가 자주 길어지면 줄이세요. 다음 검사부터 적용.</p></div>
<div class="panel"><h2>추출 미리보기 (파일 하나 시험)</h2>
<p class="muted" style="margin-top:0">도면을 하나 골라, 표제란 추출과 소속 프로젝트 판정이
제대로 되는지 그 자리에서 확인합니다. 설치한 날 실제 도면 한 장으로 꼭 한 번 돌려보세요.</p>
<form method="get" action="/preview" style="margin-top:8px">
  <input type="text" name="path" list="files" size="52"
    placeholder="파일 선택 또는 경로 입력 (예: 도면서버/P24-031/DWG-E-001.dxf)">
  <datalist id="files">{file_options}</datalist>
  <button class="btn">추출해 보기</button></form></div>
<div class="panel" id="mail"><h2>메일 브리핑</h2>
<p style="margin-top:0"><b>기본 방식 — 메일 초안 만들기:</b> 검사가 끝나면 briefs 폴더에
브리핑 HTML과 함께 <b>메일 초안 파일(.eml)</b>이 만들어집니다. 더블클릭하면 Outlook 등
메일 프로그램에서 받는사람·제목·본문(사진 포함)이 채워진 채 열리고, <b>[보내기]만 누르면
됩니다.</b> 서버 설정이 필요 없고, 이 프로그램이 스스로 메일을 보내는 일은 없습니다.</p>
<form method="post" action="/mail/save">{self._tok()}
<table style="min-width:0">
<tr><td style="width:130px">받는 사람들</td><td><input type="text" name="recipients" size="52"
  value="{_E(', '.join(mail.get('recipients', [])))}"
  placeholder="a@회사, b@회사 (쉼표로 구분)">
  <div class="muted" style="margin-top:2px">메일 초안의 '받는 사람' 칸에 미리 채워집니다.
  비워두면 보낼 때 직접 입력.</div></td></tr>
<tr><td>확인 링크 주소</td><td><input type="text" name="ack_url" size="34"
  value="{_E(cfg['ack_url'])}">
  <div class="muted" style="margin-top:2px">현재 버전은 보안상 이 PC(127.0.0.1)에서만
  화면이 열립니다 — <b>확인 링크는 이 PC에서 누를 때만 동작</b>하고, 메일 수신자
  PC에서는 열리지 않습니다. 수신자는 회신으로 확인을 남기고, 기록은 이 화면에서
  담당자가 남기는 운영을 권장합니다.</div></td></tr>
</table>
<div style="border-top:1px solid var(--border);margin:12px 0 10px;padding-top:10px">
<span class="muted"><b>선택 — SMTP 자동 발송</b> (사내 메일서버가 있는 경우만.
모르면 위의 초안 방식을 쓰세요)</span></div>
<table style="min-width:0">
<tr><td style="width:130px">자동 발송 사용</td><td>
  <input type="checkbox" name="enabled" {'checked' if mail.get('enabled') else ''}> 켜기
  <span class="muted">(꺼져 있어도 브리핑·메일 초안은 briefs 폴더에 저장됩니다)</span></td></tr>
<tr><td>SMTP 서버</td><td><input type="text" name="smtp_host" size="24"
  value="{_E(mail.get('smtp_host', ''))}" placeholder="mail.회사도메인">
  포트 <input type="text" name="smtp_port" size="5" value="{_E(mail.get('smtp_port', 25))}">
  <label><input type="checkbox" name="starttls"
  {'checked' if mail.get('starttls') else ''}> STARTTLS(587)</label>
  <label><input type="checkbox" name="use_ssl"
  {'checked' if mail.get('ssl') else ''}> SSL(465)</label>
  <div class="muted" style="margin-top:2px">하이웍스·네이버웍스 등 그룹웨어는 대부분
  SSL(465)입니다. 그룹웨어는 '앱 비밀번호' 발급이 필요할 수 있습니다.</div></td></tr>
<tr><td>보내는 주소</td><td><input type="text" name="sender" size="30"
  value="{_E(mail.get('sender', ''))}" placeholder="watcher@회사도메인"></td></tr>
<tr><td>로그인(선택)</td><td><input type="text" name="username" size="18"
  value="{_E(mail.get('username', ''))}" placeholder="계정">
  <input type="password" name="password" size="18" placeholder="비밀번호(변경 시만 입력)">
  <div class="muted" style="margin-top:4px">비밀번호는 이 PC의 이 Windows 계정만 풀 수 있게
  암호화(DPAPI)해 config.yaml에 저장됩니다 — 다른 PC로 옮기거나 계정이 바뀌면 다시 입력하세요.{pw_note}</div></td></tr>
</table>
<div style="margin-top:10px">
  <button class="btn">저장</button>
  <button class="btn gray" formaction="/mail/test">저장된 설정으로 테스트 발송 (최대 10초)</button>
</div></form></div>"""
        return _page("설정", "/settings", body, self.pop_msg())


def make_web_handler(app: WebApp, db_path: Path):
    AckHandler = make_handler(db_path)

    class Handler(AckHandler):
        def _html(self, code: int, page: str,
                  set_cookie: str | None = None) -> None:
            data = page.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            if set_cookie:
                self.send_header("Set-Cookie", set_cookie)
            self.end_headers()
            self.wfile.write(data)

        def _redirect(self, to: str, set_cookie: str | None = None) -> None:
            # 내부 경로만, 헤더 주입(CR/LF)·프로토콜 상대(//, /\) 차단 (2026-09-02 검토)
            to = _safe_back(to)
            self.send_response(303)
            self.send_header("Location", to)
            if set_cookie:
                self.send_header("Set-Cookie", set_cookie)
            self.end_headers()

        def _cookie(self, name: str) -> str:
            from http.cookies import SimpleCookie
            from urllib.parse import unquote
            c = SimpleCookie(self.headers.get("Cookie", ""))
            # 저장 시 quote()로 넣으므로 읽을 때 되돌린다 (한글 이름이 %EA..로 보이던 문제)
            return unquote(c[name].value) if name in c else ""

        def _host_ok(self) -> bool:
            """Host가 이 PC(127.0.0.1·localhost)가 아니면 거부 — 외부 웹페이지가 DNS
            리바인딩으로 로컬 화면을 읽고 조작하는 길을 막는다 (2026-09-04 검토 web M1)."""
            host = (self.headers.get("Host") or "").strip().lower()
            if not host:
                return True
            name = host.rsplit(":", 1)[0] if not host.startswith("[") else host.split("]")[0] + "]"
            return name in ("127.0.0.1", "localhost", "[::1]", "::1")

        def _origin_ok(self) -> bool:
            """POST가 이 화면 자신에게서 왔는가 — Origin은 브라우저가 붙이고 페이지가 못 고친다.

            없으면 통과시킨다(브라우저가 아닌 호출·옛 브라우저). 있으면 이 PC여야 한다."""
            origin = (self.headers.get("Origin") or "").strip()
            if not origin or origin.lower() == "null":
                return True
            try:
                host = (urlparse(origin).hostname or "").lower()
            except ValueError:
                return False
            return host in ("127.0.0.1", "localhost", "::1")

        def _corrupt_page(self, e) -> None:
            # 깨진 이력 파일 — 전에는 응답 없이 연결이 끊겨 빈 창만 남았다 (검토19 운영 ①)
            return self._html(503, _deny_page(
                "이력 파일이 깨졌습니다",
                "<h1>이력 파일(state.db)이 깨져 열 수 없습니다</h1>"
                f"<p>{_E(str(e))}</p>"
                "<p>Drev를 끝낸 뒤 backups 폴더의 사본으로 되살리세요 — 순서는 "
                "<a href=\"/help#restore\">도움말 › 백업 · 다른 PC로 이전 · 되살리기</a>에 "
                "있습니다(도움말은 이력 없이도 열립니다).</p>"))

        def do_GET(self) -> None:
            try:
                return self._do_GET()
            except CorruptDatabase as e:
                return self._corrupt_page(e)
            except sqlite3.DatabaseError as e:
                if "malformed" in str(e) or "not a database" in str(e):
                    return self._corrupt_page(e)
                raise

        def do_POST(self) -> None:
            try:
                return self._do_POST()
            except CorruptDatabase as e:
                return self._corrupt_page(e)
            except sqlite3.DatabaseError as e:
                if "malformed" in str(e) or "not a database" in str(e):
                    return self._corrupt_page(e)
                if "locked" in str(e) or "busy" in str(e):
                    # 07:00 예약 검사가 15초 넘게 쓰는 사이의 확인·저장 — 빈 응답·traceback 대신
                    # 사유를 말한다 (검토21 웹 G)
                    # 전체 화면 틀(_page)은 메뉴를 그리며 DB를 다시 연다 — 같은 잠금에 또 걸린다.
                    # 최소 HTML로 답한다
                    return self._html(503, (
                        '<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><title>잠시 뒤 다시 — Drev</title></head>'
                        '<body style="font-family:Malgun Gothic,Segoe UI,sans-serif;padding:28px;max-width:640px">'
                        '<h2>지금은 저장하지 못했습니다</h2>'
                        '<p><b>이력 파일을 다른 검사가 쓰고 있어</b> 몇 초 뒤 뒤로 가서 다시 눌러 주세요. '
                        '검사 결과는 유실되지 않습니다.</p>'
                        '<p><a href="/">대시보드로</a></p></body></html>'))
                raise

        def _do_GET(self) -> None:
            global _APP_REF
            _APP_REF = app                 # 사이드바가 '지금 이 앱'을 보게
            # 내용 단서는 본문을 그리기 **전에** 싣는다 — 메뉴를 만들 때만 실어서 프로세스 첫 화면의
            # 본문(유형 열·분류 수)은 단서 없이 분류됐다 (검토21 웹 C)
            _refresh_hints()
            if not self._host_ok():
                return self._html(421, _deny_page(
                    "요청 차단",
                    "<h1>이 주소로는 열 수 없습니다</h1>"
                    "<p>http://127.0.0.1 로 접속하세요.</p>"))
            url = urlparse(self.path)
            q = parse_qs(url.query)
            if url.path not in ("/status", "/version", "/favicon.ico"):
                # 창이 '화면'을 받아 갔다는 증거만 센다 — 살아 있는 브라우저 탭의 상태 폴링까지
                # 세면 창 엔진 사망 판정이 무력해진다 (7차 중간-G, 창 생존 판정은 engine_died)
                app.served += 1
            if url.path == "/ack":
                # 메일의 [확인했음 기록] 링크가 근거·이름 기본값·[확인하고 다음]·돌아갈 곳이
                # 없는 맨 폼(ack_server)으로 떨어졌다 (검토22 UI 차단 1). 브리핑 링크에만 있는
                # 토큰이 맞을 때만 변경 상세로 넘긴다 — 상세에는 근거와 확인 단추가 다 있다.
                # 번호·토큰이 틀리면 ack_server의 기존 오류 화면(400/403/404)을 그대로 낸다
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return super().do_GET()
                tok = q.get("t", [""])[0]
                with State(app.db()) as st:
                    ok = (st.get_change(cid) is not None
                          and _hmac.compare_digest(tok, st.ack_token(cid)))
                if not ok:
                    return super().do_GET()
                app.last_msg = "메일 링크로 들어왔습니다 — 바뀐 내용을 보고 [확인함]을 누르세요."
                return self._redirect(f"/change?id={cid}")
            if url.path == "/status":
                # 검사·업데이트가 아직 도는지만 알려주는 작은 답 — 화면을
                # 통째로 다시 부르지 않기 위해 (2026-09-02)
                import json as _json
                busy = (app.scan_state() == "scanning") or _upd_busy()
                from watcher.cli import PROGRESS
                import time as _time
                pr = {"phase": PROGRESS.get("phase") or "", "done": PROGRESS.get("done") or 0,
                      "total": PROGRESS.get("total") or 0, "current": PROGRESS.get("current") or "",
                      "elapsed": int(_time.time() - (PROGRESS.get("since") or _time.time()))}
                # 새 판 유무도 함께 — 시작 직후 첫 화면은 버전 확인이 끝나기 전에 그려져
                # [설치] 단추가 없었다; 화면이 뒤늦게 갈아 끼운다 (2026-09-11)
                upd = str((app.update_info or {}).get("version") or "")
                body = _json.dumps({"busy": busy, "progress": pr, "update": upd}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                return self.wfile.write(body)
            if url.path == "/update/slot":
                # 왼쪽 메뉴 맨 위 자리만 조각으로 — 첫 화면이 그려진 뒤 새 판을 알게 되면
                # 화면 전체를 다시 부르지 않고 그 자리만 [설치] 단추로 바꾼다 (2026-09-11)
                return self._html(200, _side_update())
            if url.path == "/version":
                # 중복 실행 판별용 신원표 — 다른 판이 포트를 잡고 있을 때
                # 그 화면으로 끌려가지 않기 위해 쓴다 (2026-08-31)
                import watcher as _w
                body = f"Drev {_w.__version__}".encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                return self.wfile.write(body)
            proj = q.get("p", [None])[0] or None
            if url.path == "/":
                # 홈 큰틀: URL 파라미터 > 쿠키 > 기본(카드) — 선택은 기억된다
                view = (q.get("view", [None])[0]
                        or self._cookie("pw_view") or "cards")
                # 쿠키 헤더에 원시로 들어갔다 — %0d%0a로 임의 헤더·본문을 끼워 넣을 수
                # 있었다(응답 분할, 검토19 웹 S1). 영문 소문자·밑줄 20자만
                if not re.fullmatch(r"[a-z_]{1,20}", str(view)):
                    view = "cards"
                ck = (f"pw_view={view}; Path=/; Max-Age=31536000; SameSite=Strict"
                      if q.get("view") else None)
                return self._html(200, app.page_dashboard(proj, view=view),
                                  set_cookie=ck)
            if url.path == "/root/confirm":
                return self._html(200, app.page_root_confirm(
                    q.get("path", [""])[0], q.get("to", ["root"])[0]))
            if url.path == "/root/remove":
                return self._html(200, app.page_root_remove(q.get("path", [""])[0]))
            if url.path == "/issues":
                return self._html(200, app.page_issues(proj))
            if url.path == "/cat":
                return self._html(200, app.page_cat(
                    q.get("c", ["도면"])[0], proj,
                    q.get("t", [None])[0] or None,
                    q.get("v", [""])[0]))
            if url.path == "/projects":
                return self._html(200, app.page_projects())
            if url.path == "/project":       # 프로젝트 상세 (유형별로 갈라 보기)
                nm = q.get("name", [""])[0]
                if not nm:
                    return self._redirect("/projects")
                return self._html(200, app.page_project(nm))
            if url.path == "/history":
                return self._html(200, app.page_history(
                    proj, ack_filter=q.get("ack", [None])[0]))
            if url.path == "/project/remove":
                return self._html(200, app.page_project_remove(
                    q.get("name", [""])[0]))
            if url.path == "/doctype/review":
                return self._html(200, app.page_doctype_review())
            if url.path == "/settings":
                return self._html(200, app.page_settings())
            if url.path == "/preview":
                return self._html(200, app.page_preview(q.get("path", [""])[0]))
            if url.path == "/organize":
                return self._html(200, app.page_organize())
            if url.path == "/change":
                return self._html(200, app.page_change(
                    q.get("id", [""])[0], ack_name=self._cookie("ack_by")))
            if url.path == "/compare":
                return self._html(200, app.page_compare(
                    q.get("id", [""])[0], q.get("page", ["1"])[0]))
            if url.path == "/notes":
                return self._html(200, app.page_notes())
            if url.path == "/tags":
                return self._html(200, app.page_tags(q.get("q", [""])[0]))
            if url.path == "/tree":
                if q.get("files", [""])[0]:
                    return self._html(200, app.tree_files(
                        q["files"][0], full=q.get("full", [""])[0] == "1",
                        drawer=q.get("drawer", [""])[0] == "1"))
                return self._html(200, app.page_tree(frag=q.get("frag", [""])[0] == "1",
                                                    sel=q.get("sel", [""])[0]))
            if url.path == "/pick":
                return self._html(200, app.page_pick(
                    q.get("path", [""])[0], q.get("to", ["onboard"])[0]))
            if url.path == "/support":
                return self._html(200, app.page_support(
                    q.get("kind", ["bug"])[0]))
            if url.path == "/export":
                data = app.export_xlsx(proj)
                fname = ("변경이력_" + date.today().strftime("%Y%m%d")
                         + (f"_{proj}" if proj else "") + ".xlsx")
                self.send_response(200)
                self.send_header("Content-Type",
                                 "application/vnd.openxmlformats-officedocument"
                                 ".spreadsheetml.sheet")
                self.send_header("Content-Disposition",
                                 f"attachment; filename*=UTF-8''{quote(fname)}")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            if url.path == "/briefs":
                return self._html(200, app.page_briefs())
            if url.path == "/brief/open":
                # 메일 초안(.eml)을 기본 메일 프로그램으로 — 탐색기에서 briefs 폴더를 찾던 것.
                # 다른 사이트의 링크·이미지가 이 주소를 부르면 메일 프로그램이 떠 버린다 (검토25 화면 3-6)
                # — 브라우저가 붙이는 Sec-Fetch-Site가 같은 출처가 아니면 거부
                sfs = (self.headers.get("Sec-Fetch-Site") or "").lower()
                if sfs and sfs not in ("same-origin", "none"):
                    return self._html(403, "<p>다른 페이지에서 연 요청은 처리하지 않습니다.</p>")
                ef = app.brief_file(q.get("f", [""])[0], ext=".eml")
                if ef is None:
                    app.last_msg = "메일 초안 파일을 찾지 못했습니다."
                else:
                    try:
                        os.startfile(str(ef))
                        app.last_msg = f"메일 초안을 열었습니다: {ef.name} — 메일 프로그램에서 [보내기]"
                    except OSError as e:
                        app.last_msg = f"열지 못했습니다: {e}"
                back = _safe_back(q.get("back", [""])[0] or "")
                return self._redirect(back if back != "/" or q.get("back") else "/briefs")
            if url.path == "/brief":
                bf = app.brief_file(q.get("f", [""])[0])
                if bf is None:
                    return self._html(404, _page("없음", "", "<h1>브리핑이 없습니다.</h1>"))
                return self._html(200, bf.read_text(encoding="utf-8"))
            if url.path == "/help":
                return self._html(200, app.page_help())
            self._html(404, _page("없음", "", "<h1>페이지가 없습니다.</h1>"))

        def _do_POST(self) -> None:
            global _APP_REF
            _APP_REF = app                 # GET에만 있어 화면이 남의 앱 상태를 그리던 것
            if not self._origin_ok():
                # 토큰이 새어 나간 뒤에도 남는 방어 한 겹 — 브라우저가 스스로 붙이는 값이라
                # 바깥 페이지가 위조할 수 없다 (2026-09-07 검토15 B2)
                return self._html(403, _deny_page(
                    "요청 차단", "<h1>다른 사이트에서 온 요청입니다</h1>"))
            if not self._host_ok():
                return self._html(421, _deny_page(
                    "요청 차단", "<h1>이 주소로는 열 수 없습니다</h1>"))
            url = urlparse(self.path)
            if url.path == "/ack":
                return super().do_POST()
            try:
                length = int(self.headers.get("Content-Length", 0))
            except ValueError:
                return self._html(400, _page("잘못된 요청", "", "<h1>잘못된 요청입니다</h1>"))
            if length < 0 or length > 1_000_000:
                # 위조된 길이로 작업 스레드를 붙들어 두거나(999,999,999) 큰 본문을 통째로
                # 파싱하게 하던 것 (검토19 웹 S3). 폼은 1MB면 넘친다
                return self._html(413, _page("잘못된 요청", "", "<h1>요청이 너무 큽니다</h1>"))
            # 폼이 아닌 본문(잘못 만든 요청·다른 인코딩)이 오면 예외가 나 연결이 그냥 끊겼다 —
            # 화면에는 사유 없이 "새로고침하라"만 떴다 (2026-09-07 로그에서 확인)
            q = parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
            # CSRF 검증 — /ack는 자체 변경별 토큰을 쓰므로 제외 (2026-08-25 리뷰)
            if q.get("t", [""])[0] != app.csrf():
                # 토큰이 틀린 요청에 토큰을 돌려주지 않는다 (검토15 B2)
                return self._html(403, _deny_page(
                    "요청 차단",
                    "<h1>잘못된 요청입니다</h1>"
                    "<p>보안 토큰이 맞지 않습니다. 대시보드 화면을 새로고침한 뒤 "
                    "다시 시도해주세요.</p>"))
            if url.path == "/scan/stop":
                app.last_msg = app.stop_scan()
                return self._redirect("/")
            if url.path == "/scan":
                if not app.cfg()["roots"]:
                    app.last_msg = ("먼저 [설정]에서 감시할 폴더를 추가해주세요 "
                                    "— 그다음 [지금 검사]가 동작합니다.")
                    return self._redirect("/settings")
                app.start_scan()
                return self._redirect("/")
            if url.path == "/update/check":
                # 어디서 눌렀든 그 화면으로 돌아온다 — 설정으로 튕기면 확인하러 갔다가
                # 다시 나와야 했다 (2026-09-07 사용자 지적)
                _ref = self.headers.get("Referer") or "/settings"
                _back = _safe_back(_ref if _ref.startswith("/") else
                                   ("/" + _ref.split("/", 3)[3] if _ref.count("/") >= 3 else "/settings"))
                cfg_url = app.cfg().get("update_url") or UPDATE_URL
                if not cfg_url:
                    app.last_msg = ("업데이트 채널이 아직 설정되지 않았습니다 — "
                                    "배포 사이트가 열리면 자동으로 연결됩니다.")
                elif app.refresh_update():
                    app.last_msg = (f"새 버전 v{app.update_info['version']}가 있습니다 — "
                                    f"왼쪽 메뉴 맨 위의 [설치]를 누르면 됩니다.")
                elif LAST_CHECK_FAILED:
                    # 통신 실패를 '최신입니다'라고 말하던 것 — 프록시가 막는 회사 PC에서는 거짓말이다
                    # (2026-09-08 사용성 8차 중간-6). 단추를 메뉴 맨 위로 올려 볼 빈도가 늘었다
                    app.last_msg = (f"새 버전을 확인하지 못했습니다 — 인터넷에 닿지 못했습니다"
                                    f"(회사 방화벽·프록시일 수 있습니다). 지금 쓰시는 판은 "
                                    f"v{__version__}입니다. 잠시 뒤 다시 눌러 보시거나, 전산 "
                                    f"담당자에게 배포 주소 접속을 요청하세요.")
                else:
                    app.last_msg = f"지금이 최신 버전입니다 (v{__version__})."
                return self._redirect(_back)
            if url.path == "/update/open":
                # version.json은 어떤 주소든 줄 수 있다 — 브라우저로 열기 전에 본다
                from watcher.selfupdate import url_ok as _uok
                if app.update_info and app.update_info.get("url"):
                    if not _uok(app.update_info["url"]):
                        app.last_msg = ("다운로드 주소가 공식 배포처가 아니라 열지 "
                                        "않았습니다.")
                    else:
                        import webbrowser
                        webbrowser.open(app.update_info["url"])
                        app.last_msg = "다운로드 페이지를 기본 브라우저로 열었습니다."
                return self._redirect("/")
            if url.path == "/update/apply":
                app.last_msg = app.start_update()
                return self._redirect("/")
            if url.path == "/other/quit":
                try:
                    app.last_msg = app.quit_other(int(q.get("port", ["0"])[0]))
                except (TypeError, ValueError):
                    app.last_msg = "포트 번호가 올바르지 않습니다."
                return self._redirect("/")
            if url.path == "/support/send":
                # 보낼 수 있는 경로를 순서대로: ①접수 서버 ②사내 SMTP
                # ③메일 앱. 어디서 막히든 내용을 파일로 남기고 복사할 수 있게
                # 한다 — "메일 보내려다 그냥 포기"를 없애기 위함 (2026-08-31)
                kind = (q.get("kind", ["ask"])[0] or "ask")[:8]
                who = (q.get("who", [""])[0] or "").strip()[:80]
                reply = (q.get("reply", [""])[0] or "").strip()[:120]
                msg = (q.get("msg", [""])[0] or "").strip()[:4000]
                if not msg:
                    return self._redirect(f"/support?kind={kind}")
                label = {"bug": "버그 신고", "idea": "개선 제안"}.get(kind, "문의")
                from watcher import __version__ as _v
                tail = (f"\n\n--\n종류: {label} / 보낸 사람: {who or '-'} / "
                        f"회신: {reply or '-'} / Drev v{_v}")
                if kind == "bug" and q.get("log"):
                    lg = app.recent_log()
                    if lg:
                        tail += f"\n\n[최근 기록]\n{lg}"
                full = msg + tail
                subject = f"[Drev {label}] {who or '무명'}"
                sent, how = False, ""
                if SUPPORT_FORM_URL:
                    try:
                        import urllib.request as _rq
                        data = urllib.parse.urlencode(
                            {"name": who, "email": reply, "kind": label,
                             "message": full}).encode()
                        req = _rq.Request(SUPPORT_FORM_URL, data=data,
                                          headers={"Accept": "application/json"})
                        _rq.urlopen(req, timeout=15)
                        sent, how = True, "접수"
                    except Exception:
                        pass
                if not sent:                      # 사내 메일 설정이 있으면 그걸로
                    try:
                        sent = app.send_feedback_mail(subject, full)
                        how = "메일 발송"
                    except Exception:
                        sent = False
                saved = app.save_feedback(subject, full)
                if sent:
                    app.last_msg = (f"보냈습니다 — 감사합니다! ({how}) "
                                    f"보낸 내용은 {saved}에도 남겼습니다.")
                else:
                    try:
                        mailto = ("mailto:" + SUPPORT_MAIL + "?"
                                  + urllib.parse.urlencode(
                                      {"subject": subject, "body": full},
                                      quote_via=urllib.parse.quote))
                        os.startfile(mailto)
                        app.last_msg = (f"내용을 {saved}에 저장했습니다. 메일 앱도 "
                                        f"열었습니다 — 안 열렸다면 그 파일을 "
                                        f"{SUPPORT_MAIL}로 보내주세요.")
                    except OSError:
                        app.last_msg = (f"내용을 {saved}에 저장했습니다 — "
                                        f"이 파일을 {SUPPORT_MAIL}로 보내주세요.")
                return self._redirect(f"/support?kind={kind}")
            if url.path == "/quit":
                # 종료 — 검사 중이면 멈춤 요청 뒤 스냅샷 롤백까지 기다리고 끝낸다
                # (즉시 죽이면 그날 변경이 유실됐다, 2026-09-04 검토).
                # 브라우저 폴백 모드에서 창 X 대신 쓰는 종료 스위치
                self._html(200, _page("종료됨", "", '<div class="panel">'
                           "<p>Drev를 종료했습니다 — 이 탭은 닫으셔도 "
                           "됩니다. 다시 시작하려면 프로그램을 더블클릭하세요."
                           "</p></div>"))

                def _bye():
                    app.finish_before_exit()
                    os._exit(0)
                threading.Timer(0.6, _bye).start()
                return
            if url.path == "/onboard":
                # 최초 가동: 폴더 추가 + 첫 검사까지 한 번에
                path = q.get("path", [""])[0].strip().strip('"')
                if not path:
                    app.last_msg = "폴더 경로를 입력해주세요."
                    return self._redirect("/")
                if not Path(path).is_dir():
                    app.last_msg = (f"폴더를 찾을 수 없습니다: {path} — 경로를 "
                                    f"복사해 붙여넣어 보세요. 네트워크 폴더는 "
                                    f"\\\\서버\\공유 형식이 안전합니다.")
                    return self._redirect("/")
                # 첫 시작도 확인을 거친다 — 이 폴더가 프로젝트 하나인지 여럿인지
                return self._redirect(f"/root/confirm?to=onboard&path={quote(path)}")
            if url.path == "/pick/native":
                # 윈도우 폴더 선택 창 — 경로를 타이핑하지 않게 (2026-08-31 요청).
                # 이 PC 화면에 모달로 뜨며, 창을 못 띄우면 목록 방식으로 보낸다
                to = q.get("to", ["root"])[0]
                from watcher import folderdlg
                # 이미 감시 중인 폴더가 있으면 거기서 시작 — 매번 내 PC부터
                # 훑지 않게 (2026-09-01)
                _roots = [r for r in (app.cfg().get("roots") or [])
                          if Path(r).is_dir()]
                picked = folderdlg.choose_folder(
                    start=str(Path(_roots[0]).parent) if _roots else None)
                if not picked:
                    if not folderdlg.available():
                        app.last_msg = "이 환경에서는 폴더 선택 창을 띄울 수 없어 목록으로 엽니다."
                        return self._redirect(f"/pick?to={to}")
                    app.last_msg = "폴더 선택을 취소했습니다."
                    return self._redirect("/" if to == "onboard" else "/settings")
                if to != "onboard" and str(Path(picked)) in list(app.cfg()["roots"]):
                    app.last_msg = "이미 감시 중인 폴더입니다."
                    return self._redirect("/settings")
                # 선택창에서 고른 뒤에도 확인 화면 — 프로젝트 하나인지 여럿인지
                return self._redirect(f"/root/confirm?to={to}&path={quote(str(picked))}")
            if url.path == "/root/confirm/do":
                to = q.get("to", ["root"])[0]
                app.last_msg = app.add_root_confirmed(
                    q.get("path", [""])[0], to, q.get("mode", ["one"])[0],
                    q.get("name", [""])[0])
                return self._redirect("/" if to == "onboard" else "/settings")
            if url.path == "/root/add":
                # 바로 저장하지 않는다 — '프로젝트 하나/여럿'을 확인받는다 (2026-09-02)
                path = q.get("path", [""])[0].strip().strip('"')
                roots = list(app.cfg()["roots"])
                if not path:
                    app.last_msg = "폴더 경로를 입력해주세요."
                elif not Path(path).is_dir():
                    app.last_msg = f"폴더를 찾을 수 없습니다: {path}"
                elif str(Path(path)) in roots:
                    app.last_msg = "이미 감시 중인 폴더입니다."
                else:
                    return self._redirect(f"/root/confirm?to=root&path={quote(path)}")
                return self._redirect("/settings")
            if url.path == "/root/asproject":
                app.last_msg = app.set_root_project(q.get("path", [""])[0],
                                                    q.get("name", [""])[0])
                return self._redirect("/settings" if "settings" in
                                      (self.headers.get("Referer") or "") else "/")
            if url.path in ("/root/del", "/root/del/do"):
                path = q.get("path", [""])[0]
                purge = q.get("purge", ["0"])[0] == "1"
                label = app.root_label_of(path)      # 목록에서 빼기 전에 계산
                roots = [r for r in app.cfg()["roots"] if r != path]
                if label is None:
                    app.last_msg = "그 폴더는 감시 목록에 없습니다."
                    return self._redirect("/settings")
                app.save_roots(roots)
                if purge:
                    try:
                        with State(db_path) as st:
                            r = st.purge_prefix(label)
                        invalidate_doc_nav()
                        app.last_msg = (f"감시 폴더 제거됨: {path} — 기록도 지웠습니다 "
                                        f"(파일 {r['files']}개, 변경 {r['changes']}건, "
                                        f"확인 {r['acks']}건, 검토 필요 {r['issues']}건)")
                    except Exception as e:
                        # 감시 목록에서는 이미 빠졌다 — 그 사실과 실패를 같이 말한다.
                        # 전에는 연결이 끊겨 사용자가 아무것도 못 봤다 (저장 검토 차단 2)
                        app.last_msg = (f"감시 폴더 제거됨: {path} — 다만 쌓인 기록은 "
                                        f"지우지 못했습니다: {e}")
                else:
                    app.last_msg = f"감시 폴더 제거됨: {path} (기록은 남김)"
                # 그 폴더의 '프로젝트 하나/하위 폴더별' 선택도 같이 지운다 — 다시 추가할 때
                # 새로 고른 값이 쓰이게 (2026-09-11 실사용 첫날)
                rp = dict(app.cfg().get("root_projects") or {})
                gone = [k for k in rp if k == path or Path(k) == Path(path)]   # 표기(슬래시·백슬래시) 무관
                if gone:
                    for k in gone:
                        rp.pop(k)
                    app._save_key("root_projects", rp)
                if not roots:
                    app.last_msg += (" — 이제 감시 폴더가 없어 검사가 멈춥니다. 아래 [폴더 추가]로 "
                                     "다시 등록하세요.")
                return self._redirect("/settings")
            if url.path == "/change/ack":
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/")
                by = (q.get("by", [""])[0] or "").strip()
                note = (q.get("note", [""])[0] or "").strip()
                saved = False
                if by:
                    with State(db_path) as st:
                        saved = st.add_ack(cid, by, note)
                if not by:
                    app.last_msg = "확인자 이름을 먼저 적어주세요."
                    return self._redirect(f"/change?id={cid}")
                if not saved:
                    app.last_msg = "확인 처리 실패 — 그 변경을 찾지 못했습니다."
                    return self._redirect("/")
                # 확인자 이름을 기억해 다음부터 미리 채운다 (매번 재입력 불편 해소)
                cookie = (f"ack_by={quote(by)}; Path=/; Max-Age=31536000; "
                          f"SameSite=Strict") if by else None
                # 확인한 뒤에는 목록으로 돌아간다 — 상세에 머물러 매번 뒤로가기 (2026-09-05)
                back = _safe_back(q.get("back", [""])[0] or "")
                nxt = None
                if by and q.get("go", [""])[0] == "next":
                    # [확인하고 다음] — 목록을 거치지 않고 다음 미확인 건으로 (2026-09-09).
                    # 같은 검사분에서 끝나면 다른 검사분으로 이어간다 — 전에는 하루 경계에서 대시보드로
                    # 튕기며 "모두 확인했습니다"(미확인 8건 남은 채)라 했다 (검토25 화면 3-1).
                    # 이동·재저장·복사본(그 밖의 알림)은 확인 대상이 아니라 건너뛴다 (3-2)
                    nxt = app.next_real_unacked(cid)
                if by:
                    name = ""
                    with State(db_path) as st:
                        ch = st.get_change(cid)
                        if ch is not None:
                            name = PurePosixPath(ch.path).name
                    app.last_msg = (f"확인 처리했습니다 — {name or f'변경 #{cid}'}, {by}"
                                    + ("" if nxt else " · 확인할 변경이 더 없습니다"
                                       if q.get("go", [""])[0] == "next" else ""))
                if nxt:
                    return self._redirect(f"/change?id={nxt}", set_cookie=cookie)
                return self._redirect(back if by and back else f"/change?id={cid}",
                                      set_cookie=cookie)
            if url.path == "/keys/save":
                raw = (q.get("key_columns", [""])[0] or "")
                cols = [c.strip()[:40] for c in ",".join(raw.split("，")).split(",") if c.strip()][:12]
                app._save_key("key_columns", cols)
                app.last_msg = (f"행 식별 열을 저장했습니다: {', '.join(cols)} — 다음 검사에서 엑셀을 다시 읽습니다."
                                if cols else "행 식별 열을 비웠습니다 — 자동 선택으로 돌아갑니다.")
                return self._redirect("/settings#keys")
            if url.path == "/ackname/save":
                name = (q.get("ack_name", [""])[0] or "").strip()[:40]
                app._save_key("ack_name", name)
                app.last_msg = (f"확인자 이름을 '{name}'(으)로 저장했습니다." if name
                                else "확인자 이름을 비웠습니다 — Windows 로그인명을 씁니다.")
                return self._redirect("/settings#who")
            if url.path == "/mail/save":
                app.save_mail(q)
                app.last_msg = "메일 설정이 저장되었습니다."
                return self._redirect("/settings")
            if url.path == "/mail/test":
                app.save_mail(q)  # 화면에 입력된 값 그대로 저장 후 시험
                app.last_msg = app.test_mail()
                return self._redirect("/settings")
            if url.path == "/install/run":
                from watcher import install as _ins
                from watcher import selfupdate as _su
                root = _su.portable_root()
                if root is None:
                    app.last_msg = "이 실행 형태는 설치 기능을 지원하지 않습니다."
                    return self._redirect("/settings")
                try:
                    r = _ins.install(root, __version__)
                except Exception as e:
                    app.last_msg = f"설치에 실패했습니다: {e}"
                    return self._redirect("/settings")
                made = [n for n, ok in (("바탕화면", r["desktop"]),
                                        ("시작 메뉴", r["startmenu"]),
                                        ("프로그램 목록", r["registered"])) if ok]
                if r["moved"]:
                    # 옛 폴더를 가리키는 자동 실행 등록을 새 위치로 옮긴다 — 안내대로 원래
                    # 폴더를 지우면 매일 검사가 조용히 끊기고 설정 화면은 '등록됨'이었다
                    # (2026-09-04 검토 ops H1)
                    try:
                        from watcher.cli import schedule_register, schedule_status
                        if schedule_status():
                            schedule_register(str(app.cfg().get("schedule_time") or "07:00"),
                                              root=Path(r["target"]))
                    except Exception as e:
                        print(f"자동 실행 재등록 실패: {e}", file=sys.stderr)
                    # 새 위치에서 다시 열고 이 인스턴스는 종료 (두 판 동시 실행 방지)
                    app.last_msg = "설치 완료"
                    try:
                        from watcher.selfupdate import child_env
                        subprocess.Popen([str(r["target"] / "Drev.exe")],
                                         close_fds=True,
                                         stdin=subprocess.DEVNULL,
                                         stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL,
                                         env=child_env(),
                                         creationflags=0x00000008 | 0x00000200)
                        threading.Timer(1.2, lambda: os._exit(0)).start()
                        return self._html(200, _page(
                            "설치 완료", "/settings",
                            f'<div class="panel"><h2>설치했습니다</h2>'
                            f'<p>{_E(str(r["target"]))} 로 옮기고 '
                            f'{", ".join(made) or "바로가기"}에 등록했습니다.</p>'
                            f'<p class="muted">새 위치에서 프로그램이 다시 열립니다 '
                            f'— 이 창은 닫으셔도 됩니다. 내려받아 압축을 푼 원래 '
                            f'폴더는 지우셔도 됩니다.</p></div>'))
                    except Exception as e:
                        app.last_msg = (f"설치는 됐지만 새 위치에서 실행하지 "
                                        f"못했습니다({e}) — 시작 메뉴의 Drev를 "
                                        f"실행해주세요.")
                else:
                    app.last_msg = (f"{', '.join(made) or '바로가기'} 등록을 "
                                    f"다시 만들었습니다.")
                return self._redirect("/settings")
            if url.path == "/install/undo":
                from watcher import install as _ins
                r = _ins.uninstall()
                app.last_msg = (f"바로가기 {r['shortcuts']}개와 프로그램 목록 "
                                f"등록을 정리했습니다 — 이력·설정은 "
                                f"{r['folder']} 에 그대로 남아 있습니다.")
                return self._redirect("/settings")
            if url.path == "/project/remove/many":
                return self._html(200, app.page_project_remove_many(q.get("name", [])))
            if url.path == "/project/remove/do":
                # 하나든 여럿이든 같은 길 — 여러 개는 확인 화면이 name을 여러 개 보낸다
                names = [n.strip() for n in dict.fromkeys(q.get("name", [])) if n.strip()]
                if not names:
                    return self._redirect("/projects")
                files: list = []
                n_changes = 0
                try:
                    with State(app.db()) as st:
                        for name in names:
                            files += st.project_files(name)
                            n_changes += st.delete_project(name)["changes"]
                except Exception as e:
                    app.last_msg = f"프로젝트 기록을 지우지 못했습니다: {e}"
                    return self._redirect("/projects")
                extra = ""
                if q.get("exclude"):
                    from collections import Counter
                    dirs = Counter(str(PurePosixPath(f).parent) for f in files)
                    ex = list(app.cfg().get("exclude") or [])
                    for d, _n in dirs.most_common():
                        if d and d not in ex:
                            ex.append(d)
                    app.save_excludes(ex)
                    extra = f" · 폴더 {len(dirs)}개를 감시에서 제외했습니다"
                who = names[0] if len(names) == 1 else f"{names[0]} 외 {len(names) - 1}개"
                # 없는 이름에도 "지웠습니다 — 변경 0건"이라 답하던 것 (웹 검토 낮음 9)
                app.last_msg = ((f"{who} 기록을 지웠습니다 — 변경 {n_changes}건"
                                 f"{extra}. 파일은 그대로 있습니다.") if n_changes else
                                (f"{who}: 지울 기록이 없었습니다 — 그런 이름의 "
                                 f"프로젝트 기록을 찾지 못했습니다.{extra}"))
                return self._redirect("/projects")
            if url.path in ("/doctype/confirm", "/doctype/confirm_all",
                            "/doctype/later"):
                from watcher.doctype import folder_rules
                rules = [{"path": p_, "name": n_}
                         for p_, n_ in folder_rules(app.cfg())]
                if url.path == "/doctype/confirm_all":
                    for it in app.unconfirmed_folders(limit=200):
                        rules.append({"path": it["folder"], "name": it["guess"]})
                    app.save_doc_folders(rules)
                    app.last_msg = ("추정대로 전부 확정했습니다 — "
                                    "[설정]에서 바꿀 수 있습니다.")
                elif url.path == "/doctype/later":
                    path_ = (q.get("path", [""])[0] or "").strip()
                    later = list(app.cfg().get("doc_folders_later") or [])
                    if path_ and path_ not in later:
                        later.append(path_)
                    app._save_key("doc_folders_later", later)
                    app.last_msg = f"나중에 확인: {path_}"
                else:
                    path_ = (q.get("path", [""])[0] or "").strip()
                    name = (q.get("name", [""])[0] or "").strip()[:30]
                    if not (path_ and name):
                        app.last_msg = "유형 이름을 입력해주세요."
                        return self._redirect("/doctype/review")
                    rules = [r for r in rules if r["path"] != path_]
                    rules.append({"path": path_, "name": name})
                    app.save_doc_folders(rules)
                    app.last_msg = f"확정: {path_} → {name}"
                return self._redirect("/doctype/review")
            if url.path == "/doctype/folder":
                from watcher.doctype import folder_rules
                path_ = (q.get("path", [""])[0] or "").strip().strip("/")
                name = (q.get("name", [""])[0] or "").strip()[:30]
                rules = [{"path": p_, "name": n_}
                         for p_, n_ in folder_rules(app.cfg()) if p_ != path_]
                if name:
                    rules.append({"path": path_, "name": name})
                    app.last_msg = f"폴더 유형 지정: {path_} → {name}"
                else:
                    app.last_msg = f"폴더 유형 지정 해제: {path_}"
                app.save_doc_folders(rules)
                return self._redirect("/settings")
            if url.path in ("/doctype/add", "/doctype/del"):
                from watcher.doctype import user_rules
                cfg = app.cfg()
                rules = user_rules(cfg)
                if url.path == "/doctype/del":
                    name = (q.get("name", [""])[0] or "").strip()
                    rules = [r for r in rules if r["name"] != name]
                    app.last_msg = f"규칙을 삭제했습니다: {name}"
                else:
                    name = (q.get("name", [""])[0] or "").strip()[:30]
                    kws = [k.strip() for k in
                           (q.get("keywords", [""])[0] or "").split(",") if k.strip()]
                    exts = [e.strip().lstrip("*").lower() for e in
                            (q.get("exts", [""])[0] or "").split(",") if e.strip()]
                    exts = [e if e.startswith(".") else "." + e for e in exts]
                    if not name or not kws:
                        app.last_msg = "유형 이름과 키워드를 모두 입력해주세요."
                        return self._redirect("/settings")
                    rules = [r for r in rules if r["name"] != name]
                    rules.append({"name": name, "keywords": kws, "exts": exts})
                    app.last_msg = (f"규칙 추가: {name} ← {', '.join(kws)}"
                                    f"{' (' + ', '.join(exts) + ')' if exts else ''}")
                app.save_doc_types(rules)
                return self._redirect("/settings")
            if url.path == "/exclude/file":
                # 관리 대상이 아닌 파일을 감시에서 뺀다 (2026-08-31 요청).
                # 제외 목록은 폴더와 같은 곳에 저장되어 [설정]에서 되돌릴 수 있다
                key = (q.get("key", [""])[0] or "").strip().strip("/")
                cfg = app.cfg()
                excludes = list(cfg.get("exclude") or [])
                if not key:
                    app.last_msg = "대상 파일을 알 수 없습니다."
                elif key in excludes:
                    app.last_msg = "이미 감시에서 빠진 파일입니다."
                else:
                    excludes.append(key)
                    app.save_excludes(excludes)
                    app.last_msg = (f"감시에서 뺐습니다: {key} — "
                                    f"[설정]에서 언제든 되돌릴 수 있습니다.")
                return self._redirect(q.get("back", ["/settings"])[0]
                                      if q.get("back") else "/settings")
            if url.path == "/exclude/add":
                # 백슬래시 입력도 수용 (매칭은 / 기준이라 조용히 무시되던 문제)
                path = "/".join(q.get("path", [""])[0].strip().split("\\")).strip("/")
                back = _safe_back(q.get("back", ["/settings#exclude"])[0] or "/settings#exclude")
                cfg = app.cfg()
                excludes = list(cfg.get("exclude") or [])
                if path and path not in excludes:
                    # 라벨 없는 경로는 모든 감시 폴더에 공통 적용된다 — 어느 폴더에도 없으면
                    # 오타일 수 있으니 등록하지 않고 한 번 더 묻는다 (경고만 하고 등록되던 것,
                    # 2026-09-05 재검토). [그래도 등록](force)이면 그대로 넣는다
                    roots_ = [Path(r) for r in cfg["roots"] if Path(r).is_dir()]
                    exists = app.abs_dir_of(path) is not None or any(
                        (r_ / PurePosixPath(path)).is_dir() or (r_ / PurePosixPath(path)).is_file()
                        for r_ in roots_)
                    from watcher.cli import _root_labels
                    if path in _root_labels([Path(r) for r in cfg["roots"]]):
                        # 라벨만 적힌 항목은 _excludes_for가 버린다 — 넣어봐야 아무 일도 안 일어난다
                        app.last_msg = (f"'{path}'은(는) 감시 폴더 자체입니다 — 제외 목록으로는 뺄 수 "
                                        f"없습니다. 감시를 그만두려면 설정 › 감시 폴더에서 지우세요.")
                        if q.get("ajax", [""])[0] == "1":
                            return self._html(200, _E(app.pop_msg() or ""))
                        return self._redirect(back)
                    bad = (path.startswith("/") or ":" in path.split("/", 1)[0]
                           or any(seg in ("..", ".") for seg in path.split("/")))
                    if bad:
                        app.last_msg = "제외 경로는 감시 폴더 기준 상대 경로여야 합니다 (예: 참고자료/외주)."
                        if q.get("ajax", [""])[0] == "1":
                            return self._html(200, _E(app.pop_msg() or ""))
                        return self._redirect("/settings#exclude")
                    if exists or q.get("force", [""])[0] == "1":
                        excludes.append(path)
                        app.save_excludes(excludes)
                        app.pending_exclude = None
                        app.last_msg = f"'{path}'을(를) 감시에서 뺐습니다 — 다음 검사부터 적용됩니다."
                    else:
                        app.pending_exclude = path
                        app.last_msg = (f"'{path}' — 지금 감시 폴더 안에 그런 폴더·파일이 없어 등록하지 "
                                        f"않았습니다. 오타가 아니면 [감시 제외] 칸의 [그래도 등록]을 "
                                        f"누르세요 (경로는 '하위폴더' 또는 '감시폴더이름/하위폴더' 꼴)")
                        back = "/settings#exclude"
                if q.get("ajax", [""])[0] == "1":       # 서랍 — 문구만 돌려주고 화면은 그대로
                    return self._html(200, _E(app.pop_msg() or ""))
                return self._redirect(back)
            if url.path == "/update/toggle":
                # 전산 담당이 파일을 열지 않고도 끌 수 있게 (검토19 구매자 ①)
                on = q.get("on", ["1"])[0] == "1"
                app._save_key("update_check", on)
                app.last_msg = ("시작할 때 새 버전을 자동으로 확인합니다." if on else
                                "시작 시 자동 확인을 껐습니다 — 이제 Drev는 스스로 인터넷에 "
                                "아무것도 요청하지 않습니다(메일 발송은 별도 설정).")
                return self._redirect("/settings#auto")
            if url.path == "/update/auto":
                # 예약 검사 뒤 무인 교체 — 기본 ON, 전산 담당이 화면에서 끌 수 있게 (2026-09-11)
                on = q.get("on", ["1"])[0] == "1"
                app._save_key("auto_update", on)
                app.last_msg = ("예약 검사(자동 실행) 뒤 새 판을 스스로 설치합니다." if on else
                                "무인 자동 설치를 껐습니다 — 새 판은 창의 [설치]를 눌러야 적용됩니다.")
                return self._redirect("/settings#auto")
            if url.path == "/ext/preset":
                # 확장자를 하나씩 타자로 넣게 하지 말고 묶음으로 (2026-09-10 "최대한
                # 편하고 쉽게"). 끌 때는 그 묶음의 확장자만 빼고 직접 넣은 것은 둔다
                from watcher.scan import EXT_PRESETS
                key = (q.get("name", [""])[0] or "").strip()
                on = q.get("on", ["1"])[0] == "1"
                grp = EXT_PRESETS.get(key)
                if not grp:
                    app.last_msg = "그런 확장자 묶음이 없습니다."
                    return self._redirect("/settings#ext")
                label, _, g_exts = grp
                cfg_now = app.cfg()
                exts = [str(x).lower() for x in (cfg_now.get("extensions") or [])]
                # 묶음이 실제로 **새로** 넣은 것만 기억해 둔다 — 끌 때 그것만 뺀다.
                # 전에는 묶음 멤버를 전부 빼서, 사용자가 예전에 손으로 넣어 두었던
                # .gxw까지 말없이 사라졌다 (검토18 웹 ④). 기록이 없으면(예전 판에서
                # 켠 묶음) 묶음 전체를 빼되 그 사실을 문구로 말한다
                added_by = dict(cfg_now.get("ext_preset_added") or {})
                if on:
                    add = [e for e in g_exts if e not in exts]
                    app._save_key("extensions", exts + add)
                    added_by[key] = add
                    app._save_key("ext_preset_added", added_by)
                    app.last_msg = (
                        f"'{label}' {len(g_exts)}개 확장자를 감시에 넣었습니다"
                        f"{f' (새로 {len(add)}개)' if add else ' (이미 모두 있었음)'} — "
                        f"내용은 못 읽지만 바뀐 사실·크기·저장 시각·이름 변경을 "
                        f"관리합니다. 다음 검사부터 적용.")
                else:
                    rec = added_by.get(key)
                    drop = set(rec) if rec is not None else set(g_exts)
                    kept = [x for x in exts if x in g_exts and x not in drop]
                    left = [x for x in exts if x not in drop]
                    if not left:
                        app.last_msg = "감시 확장자는 최소 1개 필요합니다."
                    else:
                        app._save_key("extensions", left)
                        added_by.pop(key, None)
                        app._save_key("ext_preset_added", added_by)
                        n = len(exts) - len(left)
                        tail = (f" 직접 넣어 두셨던 {', '.join(kept)}은(는) 그대로 둡니다."
                                if kept else
                                (" (이 묶음이 넣은 것만 뺐습니다)" if rec is not None else
                                 " — 손으로 넣었던 것도 이 묶음에 속하면 함께 빠졌습니다. "
                                 "필요하면 아래 칸에서 다시 추가하세요."))
                        app.last_msg = (f"'{label}' 묶음을 감시에서 뺐습니다 ({n}개).{tail} "
                                        f"다음 검사부터 적용.")
                return self._redirect("/settings#ext")
            if url.path in ("/ext/add", "/ext/del"):
                e = (q.get("ext", [""])[0] or "").strip().lower().lstrip("*")
                if e and not e.startswith("."):
                    e = "." + e
                exts = [str(x).lower()
                        for x in (app.cfg().get("extensions") or [])]
                if url.path.endswith("add"):
                    # 읽기 전용 감시기에는 replace/unlink 같은 이름을 아예 두지
                    # 않는다 (tests/test_readonly.py) — 한 글자씩 본다
                    # 영문·숫자·밑줄만 — 유니코드 isalnum은 'ㄱㄴ'·전각 숫자도 통과시켜
                    # 오타를 걸러 주려던 뜻이 무색했다 (검토18 웹 ⑩)
                    body_ = e[1:]
                    ok_ext = (all(c.isascii() and (c.isalnum() or c == "_") for c in body_)
                              and body_.strip("_") != "")
                    if not (2 <= len(e) <= 11 and ok_ext):
                        app.last_msg = "확장자 형식이 이상합니다 — 예: gxw 또는 .gxw"
                    elif e in exts:
                        app.last_msg = f"이미 감시 중인 확장자입니다: {e}"
                    else:
                        app._save_key("extensions", exts + [e])
                        app.last_msg = (f"감시 확장자 추가됨: {e} — 다음 검사부터 "
                                        f"이 형식의 파일도 감시합니다.")
                else:
                    if len(exts) <= 1:
                        app.last_msg = "감시 확장자는 최소 1개 필요합니다."
                    else:
                        app._save_key("extensions", [x for x in exts if x != e])
                        app.last_msg = f"감시 확장자 제거됨: {e}"
                return self._redirect("/settings#ext")   # 같은 패널로 돌아온다 (검토18 웹 ⑨)
            if url.path == "/exclude/del":
                path = q.get("path", [""])[0]
                back = _safe_back(q.get("back", ["/settings"])[0] or "/settings")
                excludes = [e for e in (app.cfg().get("exclude") or []) if e != path]
                app.save_excludes(excludes)
                app.last_msg = (f"'{path}'을(를) 다시 감시합니다 — 다음 검사부터 적용됩니다."
                                if path else "제외 항목을 지웠습니다.")
                if q.get("ajax", [""])[0] == "1":       # 서랍 — 문구만 돌려주고 화면은 그대로
                    return self._html(200, _E(app.pop_msg() or ""))
                return self._redirect(back)
            if url.path == "/change/recompare":
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/")
                from watcher.cli import recompare_change
                sens = q.get("sens", [""])[0] == "1"
                with State(db_path) as st:
                    ok, msg = recompare_change(st, cid, app.abs_path_of,
                                               sensitive=sens)
                app.last_msg = msg
                return self._redirect(f"/change?id={cid}")
            if url.path in ("/change/note/add", "/change/note/del"):
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/")
                with State(db_path) as st:
                    if url.path == "/change/note/add":
                        # 한 줄 메모 용도 — 과도한 붙여넣기로 DB가 붓지 않게 자른다
                        text = (q.get("text", [""])[0] or "").strip()[:300]
                        if text:
                            st.add_user_note(cid,
                                             (q.get("where", [""])[0] or "").strip()[:100],
                                             text, self._cookie("ack_by") or "-")
                            app.last_msg = ("놓친 변경을 기록했습니다 — 요약에 "
                                            "'사람 기록'으로 함께 집계됩니다.")
                    else:
                        try:
                            st.delete_user_note(cid, int(q.get("idx", [""])[0]))
                            app.last_msg = "기록을 삭제했습니다."
                        except ValueError:
                            pass
                return self._redirect(f"/change?id={cid}")
            if url.path in ("/change/pair/set", "/change/pair/clear"):
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/")
                from watcher.cli import recompare_change
                with State(db_path) as st:
                    ch = st.get_change(cid)
                    if ch is None:
                        return self._redirect("/")
                    if url.path.endswith("clear"):
                        st.clear_manual_pair(ch.path)
                        app.last_msg = ("이전 판 지정을 해제했습니다 — 자동 "
                                        "인식 규칙으로 돌아갑니다.")
                    else:
                        prev = (q.get("prev", [""])[0] or "").strip()
                        rows = st._latest_rows()
                        my_ext = PurePosixPath(ch.path).suffix.lower()
                        if prev not in rows:
                            app.last_msg = ("지정 실패: 목록에서 파일을 골라주세요 "
                                            "(감시 중인 파일만 가능).")
                        elif prev == ch.path:
                            app.last_msg = "지정 실패: 자기 자신은 이전 판이 될 수 없습니다."
                        elif PurePosixPath(prev).suffix.lower() != my_ext:
                            app.last_msg = ("지정 실패: 같은 확장자 파일만 이전 판으로 "
                                            "지정할 수 있습니다 (비교 소음 방지).")
                        else:
                            st.set_manual_pair(ch.path, prev,
                                               self._cookie("ack_by") or "-")
                            ok, msg = recompare_change(st, cid, app.abs_path_of)
                            app.last_msg = f"이전 판을 직접 지정했습니다. {msg}"
                return self._redirect(f"/change?id={cid}")
            if url.path == "/open":
                # 목록에서 파일·폴더 바로 열기 (경로 키 기반, 2026-08-29).
                # abs_path_of가 감시 폴더 안 실존 파일로만 해석 — 임의 경로 불가
                key = q.get("k", [""])[0]
                w_ = q.get("w", ["f"])[0]
                p = app.abs_dir_of(key) if w_ == "dir" else app.abs_path_of(key)
                if p is None:
                    app.last_msg = ("파일에 접근할 수 없습니다 — 삭제되었거나 "
                                    "감시 폴더 연결을 확인해주세요.")
                else:
                    target = p.parent if w_ == "d" else p
                    app.last_msg = open_target(target)
                if q.get("ajax", [""])[0] == "1":       # 폴더 구조의 열기 — 화면을 새로 그리지 않는다
                    msg = app.pop_msg() or ""
                    return self._html(200, _E(msg))
                ref = self.headers.get("Referer") or "/"
                if not ref.startswith(("http://127.0.0.1", "http://localhost", "/")):
                    ref = "/"
                return self._redirect(ref)
            if url.path == "/change/open":
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/")
                which = q.get("which", ["new"])[0]
                with State(db_path) as st:
                    ch = st.get_change(cid)
                    prev_key = None
                    if ch is not None and which == "old":
                        from watcher.cli import find_prev_version
                        prev_key, _s, _why = find_prev_version(st, ch.path)
                if ch is None:
                    return self._redirect("/")
                target = None
                if which == "old":
                    target = app.abs_path_of(prev_key) if prev_key else None
                    if target is None:
                        app.last_msg = "이전 판을 찾지 못해 열 수 없습니다."
                else:
                    p = app.abs_path_of(ch.path)
                    if p is None:
                        app.last_msg = ("파일에 접근할 수 없습니다 — 감시 폴더 "
                                        "연결을 확인해주세요.")
                    else:
                        target = p.parent if which == "folder" else p
                if target is not None:
                    # 127.0.0.1 전용 화면에서 이 PC의 기본 프로그램으로 여는 것 —
                    # 파일 자체는 읽기만 한다 (원칙 2)
                    app.last_msg = open_target(target)
                return self._redirect(f"/change?id={cid}")
            if url.path in ("/change/dismiss", "/change/restore"):
                try:
                    cid = int(q.get("id", [""])[0])
                    idx = int(q.get("idx", [""])[0])
                except ValueError:
                    return self._redirect("/")
                with State(db_path) as st:
                    if url.path == "/change/dismiss":
                        st.dismiss_change_item(cid, idx,
                                               self._cookie("ack_by") or "-")
                        app.last_msg = ("항목을 오탐으로 숨겼습니다 — 아래 "
                                        "'숨긴 항목'에서 복원할 수 있습니다.")
                    else:
                        st.restore_change_item(cid, idx)
                        app.last_msg = "항목을 복원했습니다."
                return self._redirect(f"/change?id={cid}")
            if url.path == "/ack/bulk":
                by = (q.get("by", [""])[0] or "").strip()
                note = (q.get("note", [""])[0] or "").strip()
                p = (q.get("p", [""])[0] or "") or None
                shown = {int(x) for x in (q.get("ids", [""])[0] or "").split(",")
                         if x.strip().isdigit()}
                extra = 0
                if by:
                    with State(db_path) as st:
                        rows = st.history(p)
                        seen: dict[int, bool] = {}
                        for r in rows:  # 변경 단위로 접어 미확인만
                            seen[r["change_id"]] = seen.get(r["change_id"], False) \
                                or bool(r["ack_by"])
                        ids = [cid for cid, acked in seen.items() if not acked]
                        if shown:
                            # 화면이 보여 준 것만 — 그 사이 새로 생긴 변경은 손대지 않는다
                            extra = len([c for c in ids if c not in shown])
                            ids = [c for c in ids if c in shown]
                        n = st.add_ack_bulk(ids, by, note or "일괄 확인")
                    app.last_msg = (f"{n}건을 일괄 확인 처리했습니다."
                                    + (f" 그 사이 새로 생긴 {extra}건은 그대로 두었습니다 — "
                                       f"화면을 새로고침해 확인하세요." if extra else ""))
                return self._redirect("/history?ack=none"
                                      + (f"&p={quote(p)}" if p else ""))
            if url.path == "/ack/quick":
                # 목록에서 한 번 눌러 확인 — 열지 않고도 끝나게 (2026-09-02)
                back = _safe_back(q.get("back", ["/"])[0])
                by = (q.get("by", [""])[0] or "").strip()[:40]
                try:
                    cid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect(back)
                if not by:
                    app.last_msg = ("확인자 이름을 먼저 적어주세요 — "
                                    "목록 위 [확인자 이름] 칸입니다.")
                    return self._redirect(back)
                also_ids = []
                for a in q.get("also", []):
                    try:
                        also_ids.append(int(a))
                    except ValueError:
                        pass
                with State(db_path) as st:
                    ok = st.add_ack(cid, by, "")
                    main_c = st.get_change(cid)
                    kept = []
                    for a in also_ids:            # 이동 쌍의 삭제 쪽도 함께 (2026-09-05)
                        pair = st.get_change(a)
                        # 진짜 짝(같은 지문의 삭제)일 때만 — 임의 id를 같이 확인시키지 못하게
                        if (main_c and pair and pair.kind == "removed"
                                and pair.old_sha256 and pair.old_sha256 == main_c.new_sha256):
                            st.add_ack(a, by, "이동 전 경로 — 함께 확인")
                            kept.append(a)
                    also_ids = kept
                _nm = PurePosixPath(main_c.path).name if main_c else f"변경 #{cid}"
                app.last_msg = (f"확인 처리했습니다 — {_nm}"
                                + (" (이동 전 경로 포함)" if also_ids else "")
                                + f", {by}" if ok
                                else "확인 처리 실패 — 대상 변경을 찾지 못했습니다.")
                return self._redirect(back)
            if url.path == "/project/merge":
                return self._html(200, app.page_merge_confirm(q.get("name", [])))
            if url.path == "/project/merge/do":
                names = [n for n in dict.fromkeys(q.get("name", [])) if n]
                into = (q.get("into", [""])[0] or "").strip()
                if len(names) < 2 or into not in names:
                    app.last_msg = "합칠 프로젝트를 2개 이상 골라주세요."
                    return self._redirect("/projects")
                with State(db_path) as st:
                    r = st.merge_projects(into, [n for n in names if n != into])
                warn = app.save_alias(into, [n for n in names if n != into])
                app.last_msg = (
                    f"{len(names)}개를 '{into}'로 합쳤습니다 — 이력 "
                    f"{r['changes']}건, 검토 필요 {r['issues']}건. "
                    + (warn or "앞으로의 검사에서도 같은 프로젝트로 잡힙니다."))
                return self._redirect("/projects")
            if url.path == "/project/merge/undo":
                try:
                    mid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/projects")
                with State(db_path) as st:
                    rec = next((m for m in st.merges(50)
                                if m["merge_id"] == mid), None)
                    n = st.undo_merge(mid)
                warn = ""
                if rec:                       # 별칭도 함께 되돌린다
                    warn = app.remove_alias(rec["into"], rec["sources"])
                app.last_msg = (f"합치기를 되돌렸습니다 — 이력 {n}건이 원래 "
                                f"이름으로 돌아갔고, 다음 검사에서도 갈린 채로 "
                                f"둡니다.{warn}")
                return self._redirect("/projects")
            if url.path == "/issue/close":
                try:
                    iid = int(q.get("id", [""])[0])
                except ValueError:
                    return self._redirect("/issues")
                with State(db_path) as st:
                    done = st.resolve_issue(iid, (q.get("by", [""])[0] or "").strip())
                app.last_msg = ("검토 필요를 처리함으로 표시했습니다. 같은 내용이 다시 "
                                "검출되면 새로 올라옵니다." if done else
                                "그 검토 필요 항목을 찾지 못했습니다 — 이미 처리됐거나 "
                                "정리된 기록일 수 있습니다.")
                return self._redirect("/issues")
            if url.path == "/ui/save":
                app.last_msg = app.save_ui_mode(q.get("ui", ["window"])[0])
                return self._redirect("/settings")
            if url.path == "/open/browser":
                # 창이 멎었을 때의 비상구 — 같은 화면을 기본 브라우저로 (2026-09-02)
                import webbrowser
                webbrowser.open(f"http://127.0.0.1:{app.port or 8765}/")
                app.last_msg = "기본 브라우저에서 열었습니다 — 거기서 이어서 쓰세요."
                return self._redirect("/settings")
            if url.path == "/ocr/save":
                on = (q.get("on", [""])[0] or "") == "1"
                app._save_key("ocr", on)
                app.last_msg = ("글자 없는 PDF를 OCR로 읽습니다 — 다음 검사부터 적용" if on
                                else "OCR을 끕니다 — 글자 없는 PDF는 변경 사실과 그림만 봅니다")
                return self._redirect("/settings")
            if url.path == "/timeout/save":
                try:
                    secs = int((q.get("seconds", [""])[0] or "").strip())
                    if not (1 <= secs <= 7200):
                        raise ValueError
                    app._save_key("extract_timeout", secs)
                    app.last_msg = f"파일 하나 시간 상한 저장됨: {secs}초 — 다음 검사부터 적용"
                except ValueError:
                    app.last_msg = "시간 상한은 1~7200 사이의 초 단위 숫자로 입력해주세요."
                return self._redirect("/settings")
            if url.path == "/retention/save":
                try:
                    days = int((q.get("days", [""])[0] or "").strip())
                    if days < 0:
                        raise ValueError
                    app._save_key("retention_days", days)
                    app.last_msg = (f"보존 기간 저장됨: {days}일"
                                    if days else "보존 기간 저장됨: 정리 안 함")
                except ValueError:
                    app.last_msg = "보존 기간은 0 이상의 숫자로 입력해주세요."
                return self._redirect("/settings")
            if url.path == "/dwg/test":
                import threading as _th

                def _bg():
                    app.last_msg = app.dwg_test()
                _th.Thread(target=_bg, daemon=True).start()
                app.last_msg = "DWG 변환 시험 중… 몇 초~1분 뒤 이 화면을 새로고침하면 결과가 보입니다."
                return self._redirect("/settings")
            if url.path == "/dwg/save":
                app._save_key("dwg_converter", (q.get("conv", [""])[0] or "").strip())
                from watcher.convert import status as _dwg_status
                _ok, _msg = _dwg_status(app.cfg())
                app.last_msg = "DWG 변환 설정 저장됨 — " + _msg
                return self._redirect("/settings")
            if url.path == "/schedule/register":
                from watcher.cli import schedule_register
                tsel = (q.get("time", ["07:00"])[0] or "07:00").strip()
                if not re.fullmatch(r"\d{2}:\d{2}", tsel):
                    tsel = "07:00"
                ok, msg = schedule_register(tsel)
                if ok:
                    app._save_key("schedule_time", tsel)
                app.last_msg = msg
                return self._redirect("/settings")
            if url.path == "/schedule/unregister":
                from watcher.cli import schedule_unregister
                ok, msg = schedule_unregister()
                app.last_msg = msg
                return self._redirect("/settings")
            self._html(404, _page("없음", "", "<h1>페이지가 없습니다.</h1>"))

    return Handler


# 자기 자신(127.0.0.1)에게 보내는 요청 전용 — 회사 프록시를 타지 않는다.
# 윈도우 프록시 예외 `<local>`은 점이 있는 127.0.0.1을 예외로 치지 않아,
# 이웃 포트 탐색·이전 판 종료가 프록시로 나갔다가 타임아웃으로 돌아왔다 (2026-09-02)
_NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _safe_back(to: str) -> str:
    """리다이렉트 대상은 이 앱 안의 경로여야 한다. 아니면 첫 화면으로.

    제어문자를 **먼저** 걷어낸다 — 뒤에 하면 '/\t/evil.com'이 '//evil.com'이 된다
    (2026-09-02 재검토에서 실측)."""
    to = "".join(ch for ch in (to or "") if ch >= " " and ch != "\x7f").strip()
    if not to.startswith("/") or to.startswith("//") or to.startswith("/\\"):
        return "/"
    return to


class _QuietServer(ThreadingHTTPServer):
    """브라우저가 새로고침·이탈로 연결을 끊을 때의 무해한 예외를 조용히 삼킨다.
    검사 중 5초 자동 갱신 화면에서 WinError 10053 트레이스백이 콘솔을 도배해
    사용자가 오류로 오인하던 문제 (2026-08-28 실PC 4만 파일 검사 로그).

    또한 포트 독점을 강제한다: 윈도우는 SO_REUSEADDR가 켜져 있으면 두 프로세스가
    같은 포트에 나란히 바인딩되고, 요청을 누가 받을지가 불확실해진다. 실제로
    구버전이 살아 있는 채 새 판을 실행했더니 충돌이 감지되지 않고 화면만 구버전이
    응답해, 새 기능이 사라진 것처럼 보였다 (2026-08-31 실측)."""

    allow_reuse_address = False

    def server_bind(self) -> None:
        if os.name == "nt":
            import socket as _s
            try:    # 다른 프로세스의 동시 바인딩을 커널 수준에서 차단
                self.socket.setsockopt(_s.SOL_SOCKET, _s.SO_EXCLUSIVEADDRUSE, 1)
            except OSError:
                pass
        super().server_bind()

    def handle_error(self, request, client_address) -> None:
        import sys as _sys
        exc = _sys.exception()
        if isinstance(exc, (ConnectionAbortedError, ConnectionResetError,
                            BrokenPipeError, TimeoutError)):
            return
        super().handle_error(request, client_address)


def make_web_server(config_path: str, host: str = "127.0.0.1",
                    port: int = 8765) -> ThreadingHTTPServer:
    app = WebApp(config_path)
    db_path = Path(app.cfg()["state_db"])
    srv = _QuietServer((host, port), make_web_handler(app, db_path))
    srv.app = app  # run_web 등 바깥에서 앱 상태(업데이트 확인 등)에 접근용
    app.port = srv.server_address[1]   # 다른 판 감지 시 자기 자신 제외용
    return srv


def _bind_with_retry(config_path: str, port: int, url: str, wait: float = 8.0):
    """기본 포트를 잡는다. 이미 잡혀 있으면 **응답이 없을 때만** 잠깐 기다렸다 다시 시도한다.

    업데이트는 새 판을 띄우고 옛 판을 끝낸다 — 그 몇 초 동안 포트가 아직 옛 판 것이라
    새 판이 곧장 8766으로 비켜섰다. 창 모드에서는 옛 창이 함께 사라져 티가 안 났지만,
    **브라우저 모드에서는 8765를 보던 탭이 영영 '연결할 수 없음'으로 남는다**
    (2026-09-07 사용자: "브라우저에서 업데이트 하면 페이지 연결이 안된다고 뜸").

    지금 듣고 있는 프로그램이 잡고 있으면 기다리지 않고 바로 올려보낸다 — 두 번째로 켤 때마다
    서 있으면 안 된다. 호출부가 '이미 실행 중' 안내를 맡는다."""
    import time as _t
    try:
        return make_web_server(config_path, port=port)
    except OSError:
        pass
    # 연결이 받아들여지면 누군가 **지금** 듣고 있다는 뜻 — 기다려도 안 놓아준다.
    # 연결이 거부되면 소켓이 닫히는 중(끝나는 판이 놓아주는 중)이라 기다릴 값어치가 있다.
    # 예전에는 응답 없는 프로그램이 잡고 있을 때 3초+8초를 서 있었다 (검토15 운영 ③-b)
    import socket as _sock
    listening = False
    try:
        with _sock.create_connection(("127.0.0.1", port), timeout=0.5):
            listening = True
    except OSError:
        listening = False
    if listening:
        # 화면 수(`served`)를 올리지 않는 주소로 묻는다 — '/'로 물으면 창 생존 판정이
        # 자기 요청을 세어 오판한다 (검토15 운영 ③)
        who = "다른 프로그램"
        try:
            with _NOPROXY.open(url + "version", timeout=1.5) as r:
                if b"Drev" in r.read(64):
                    who = "살아 있는 다른 판"
        except Exception:
            pass
        if who == "살아 있는 다른 판" and os.environ.get("DREV_TAKEOVER") == "1":
            # 업데이트가 띄운 새 판이다 — 옛 판이 곧 비켜주니 기다린다 (검토15 운영 B3)
            wait = max(wait, 12.0)
            print(f"[start] 옛 판이 {port}을 놓아주기를 기다립니다…", flush=True)
        else:
            # urllib의 URLError는 OSError의 하위라, 예외로 신호를 주고받으면 뒤집힌다 — 깃발로
            raise OSError(f"포트 {port}을 {who}이(가) 쓰고 있습니다")
    deadline = _t.time() + wait
    while True:
        try:
            return make_web_server(config_path, port=port)
        except OSError as e:
            if _t.time() >= deadline:
                # 날것의 WinError 10048이 그대로 올라오던 것 (검토17 운영 M4)
                raise OSError(f"포트 {port}이 계속 사용 중입니다 — 옆 포트로 엽니다 ({e})") from e
            _t.sleep(0.4)


def _window_box() -> tuple[int, int, int, int]:
    """창 크기와 위치 (가로, 세로, x, y) — 주 모니터의 작업 영역 안에 놓는다.

    2026-09-01 실사고: 크기만 정하고 위치를 맡겼더니 다중 모니터 환경에서
    (2552, -8) 같은 화면 밖으로 떠 "멈춘 것처럼 클릭이 안 되는" 상태가 됐다.
    작업 표시줄을 제외한 영역에 맞추고 위치까지 직접 지정한다."""
    fallback = (1280, 880, 60, 40)
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        try:                       # 고해상도(배율) 화면에서 실제 픽셀로 읽기
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

        class RECT(ctypes.Structure):
            _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                        ("right", wintypes.LONG), ("bottom", wintypes.LONG)]

        wa = RECT()
        if not u.SystemParametersInfoW(0x0030, 0, ctypes.byref(wa), 0):
            return fallback
        aw, ah = wa.right - wa.left, wa.bottom - wa.top
        if aw < 800 or ah < 600:
            return fallback
        # 콘텐츠 최대 폭(사이드바 216 + 본문 1680 + 여백)보다 크게 열지 않는다
        w = max(1000, min(int(aw * 0.9), 1960, aw - 40))
        h = max(680, min(int(ah * 0.92), 1400, ah - 30))
        x = wa.left + (aw - w) // 2
        y = wa.top + (ah - h) // 2
        return w, h, x, y
    except Exception:
        return fallback


def _window_size() -> tuple[int, int]:
    """가로·세로만 필요할 때 (이전 이름 유지)."""
    w, h, _x, _y = _window_box()
    return w, h


def window_alive(hwnd: int, timeout_ms: int = 2000) -> bool:
    """그 창이 살아서 메시지에 답하는가 (2026-09-02).

    멎은 창을 앞으로 가져오면 화면은 떴는데 클릭이 안 되는 상태가 된다 —
    업데이트 직후 이전 판이 안 죽었을 때 실제로 겪었다. 답이 없으면 그 창에
    붙지 말고 우리 창을 새로 띄운다."""
    try:
        import ctypes
        res = ctypes.c_size_t(0)
        # WM_NULL을 보내고 SMTO_ABORTIFHUNG(0x2)으로 멎은 창을 골라낸다
        ok = ctypes.windll.user32.SendMessageTimeoutW(
            hwnd, 0, 0, 0, 0x0002, timeout_ms, ctypes.byref(res))
        return bool(ok)
    except Exception:
        return False


def _window_of_port(hwnd: int, port: int) -> bool:
    """그 창이 이 주소(포트)를 쓰는 프로세스의 창인가.

    창 제목은 모든 판이 같아서, 제목만으로 찾으면 남의 판을 앞으로 가져오게 된다."""
    try:
        import ctypes
        from ctypes import wintypes
        pid = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return False
        import subprocess
        out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True,
                             text=True, encoding="mbcs", errors="replace", timeout=3,
                             creationflags=0x08000000).stdout or ""
        for line in out.splitlines():
            f = line.split()
            if len(f) >= 5 and f[3].upper() == "LISTENING" and f[1].endswith(f":{port}"):
                return f[-1] == str(pid.value)
    except Exception:
        return True                    # 확인할 수 없으면 예전처럼 (판단 보류)
    return True


def _existing_window_ok() -> bool:
    """이미 떠 있는 Drev 창이 살아 있는가. 창을 못 찾으면 판단 보류(True)."""
    try:
        import ctypes
        h = ctypes.windll.user32.FindWindowW(None, "Drev — 산출물 변경 감시")
    except Exception:
        return True
    return True if not h else window_alive(h)


def ui_mode(cfg: dict | None) -> str:
    """화면을 어디에 여는가 — 'window'(자체 창) | 'browser'(기본 브라우저).

    창(WebView2)이 회사 PC의 보안 정책에 걸려 멎는 경우가 있다 (2026-09-02).
    환경변수 PW_BROWSER=1은 예전부터 있던 개발용 스위치 — 같은 뜻으로 친다."""
    if os.environ.get("PW_BROWSER") == "1":
        return "browser"
    v = str((cfg or {}).get("ui") or "window").strip().lower()
    return "browser" if v == "browser" else "window"


def webview_profile() -> str | None:
    """창 엔진의 고정 프로필 폴더. 못 만들면 None(→ 엔진 기본 임시 프로필)."""
    try:
        d = Path.cwd() / ".webview"
        d.mkdir(exist_ok=True)
        return str(d)
    except OSError:
        return None


def _webview_procs_using(prof: str) -> int:
    """그 프로필 폴더를 쓰는 창 엔진 프로세스(msedgewebview2.exe) 수.

    이름 변경으로 잠금을 떠보는 방식은 쓰지 않는다 — 이 모듈은 이동·삭제 API를
    갖지 않는다(PRINCIPLE 2, tests/test_readonly.py). 읽기만 하는 프로세스 목록으로 본다."""
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "(Get-CimInstance Win32_Process -Filter \"Name='msedgewebview2.exe'\")"
             ".CommandLine"],
            capture_output=True, text=True, timeout=8, stdin=subprocess.DEVNULL,
            creationflags=0x08000000)
    except Exception:
        return 0
    key = prof.lower()
    return sum(1 for ln in (r.stdout or "").splitlines() if key in ln.lower())


def profile_locked(prof: str) -> bool:
    """이전 판의 창 엔진이 아직 이 프로필을 쓰고 있는가 (업데이트 직후)."""
    if not Path(prof).exists():
        return False
    return _webview_procs_using(prof) > 0


WINDOW_TITLE = "Drev — 산출물 변경 감시"
_ICON_HANDLES: dict = {}
_CAPTION_BG = 0x00261E1A      # COLORREF(0x00BBGGRR) = 사이트 틀 색 #1a1e26
_CAPTION_FG = 0x00EFE9E6      # #e6e9ef


def icon_path() -> Path | None:
    """앱 아이콘(.ico) — 포터블·설치판은 app/watcher/assets, exe는 동봉 데이터."""
    p = Path(__file__).resolve().parent / "assets" / "drev.ico"
    return p if p.is_file() else None


def style_window(hwnd: int) -> bool:
    """제목 표시줄을 사이트 화면 틀과 같게: 어두운 제목 표시줄(Windows 10 1809+), 사이트 틀 색(Windows 11),
    파란 'D' 아이콘. 기본 창틀·창 동작은 그대로 둔다 (2026-09-06 — 틀을 통째로 그리는 안은 스냅·끌기·
    원격 데스크톱에서 어색해져 접음). 실패는 조용히 넘긴다(모양일 뿐)."""
    if not hwnd:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        dwm = ctypes.windll.dwmapi
        dark = ctypes.c_int(1)
        for attr in (20, 19):                        # DWMWA_USE_IMMERSIVE_DARK_MODE (1809~1903은 19)
            if dwm.DwmSetWindowAttribute(wintypes.HWND(hwnd), attr, ctypes.byref(dark), 4) == 0:
                break
        bg, fg = wintypes.DWORD(_CAPTION_BG), wintypes.DWORD(_CAPTION_FG)
        dwm.DwmSetWindowAttribute(wintypes.HWND(hwnd), 35, ctypes.byref(bg), 4)   # DWMWA_CAPTION_COLOR (Win11)
        dwm.DwmSetWindowAttribute(wintypes.HWND(hwnd), 36, ctypes.byref(fg), 4)   # DWMWA_TEXT_COLOR
        ico = icon_path()
        if ico is not None:
            u = ctypes.windll.user32
            u.LoadImageW.restype = wintypes.HANDLE
            u.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
            u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
            for which, size in ((0, 16), (1, 32)):   # ICON_SMALL, ICON_BIG
                h = _ICON_HANDLES.get(size)
                if not h:
                    h = u.LoadImageW(None, str(ico), 1, size, size, 0x10)   # IMAGE_ICON, LR_LOADFROMFILE — 한 번만 (핸들 누수 방지)
                    if h:
                        _ICON_HANDLES[size] = h
                if h:
                    u.SendMessageW(wintypes.HWND(hwnd), 0x80, which, h)  # WM_SETICON
        return True
    except Exception:
        return False


def style_on_shown(win) -> None:
    """pywebview 창 객체의 shown 이벤트에 걸어 그 창의 핸들로 꾸민다 — 제목으로 첫 창을 찾으면 업데이트 직후
    남아 있는 이전 창을 꾸밀 수 있다 (리뷰13 낮음-5). 실패하면 제목 찾기(_style_window_soon)가 받친다."""
    def _on_shown():
        try:
            h = int(win.native.Handle)          # WinForms 창 핸들
        except Exception:
            h = 0
        if not h or not style_window(h):
            _style_window_soon()
    try:
        win.events.shown += _on_shown
    except Exception:
        _style_window_soon()


def _style_window_soon(title: str = WINDOW_TITLE, timeout: float = 15.0) -> None:
    """창이 뜨는 즉시 style_window — webview.start()가 블록하므로 곁 스레드가 창 핸들을 기다린다."""
    import threading as _th
    import time as _t

    def _go():
        try:
            import ctypes
            end = _t.time() + timeout
            while _t.time() < end:
                h = ctypes.windll.user32.FindWindowW(None, title)
                if h:
                    style_window(h)
                    return
                _t.sleep(0.2)
        except Exception:
            pass
    _th.Thread(target=_go, daemon=True, name="drev-window-style").start()


def engine_died(lived: float, served: int, floor: float = 8.0) -> bool:
    """창이 닫힌 뒤: 사람이 끈 것인가, 창 엔진(WebView2)이 죽은 것인가.

    엔진이 죽으면 화면을 한 장도 받아 가지 못한다 — 그때만 브라우저로 살려 둔다
    (2026-08-30 "다시 꺼지네" 방어). 시간만 보던 예전 규칙은 8초 안에 X를 누른 사람까지
    엔진 사망으로 몰아, 끄려는데 브라우저가 뜨고 프로그램은 계속 살아 있었다
    (2026-09-07 사용자 "drev를 끄면 꼭 브라우저에서 한번 켜주네")."""
    return lived < floor and served == 0


def _start_webview():
    """창 엔진 시작 — 고정 프로필로. 매번 임시 폴더에 새 프로필을 만들면
    회사 PC의 보안 소프트웨어가 실행 때마다 수천 파일을 검사한다 (2026-09-02).

    이전 판의 창 엔진이 아직 프로필을 쥐고 있으면(업데이트 직후) 잠깐 기다리고,
    그래도 잠겨 있으면 이번만 임시 프로필로 연다 — 무한 대기보다 낫다."""
    import time as _t

    import webview
    from watcher import webengine as _we
    ok, why = _we.engine_check()
    if not ok:
        # pywebview는 이 상황에서 조용히 구형 IE 엔진으로 창을 띄운다 — 화면이
        # 깨져 "로딩처럼 보이고 클릭 불가"가 된다. 대신 브라우저로 간다
        raise RuntimeError(why)
    os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = _we.no_proxy_args()
    prof = webview_profile()
    if prof:
        for _ in range(16):                      # 최대 8초
            if not profile_locked(prof):
                break
            _t.sleep(0.5)
        else:
            print("[start] 창 프로필이 다른 프로세스에 잠겨 있어 이번만 임시 "
                  "프로필로 엽니다 (이전 판의 창 엔진이 아직 종료 중)")
            prof = None
    if not any(getattr(w, "_drev_styled", False) for w in getattr(webview, "windows", [])):
        _style_window_soon()                   # 창 객체에 이벤트를 못 건 경우의 받침
    if prof:
        webview.start(private_mode=False, storage_path=prof)
    else:
        webview.start()


def parent_process_name() -> str:
    """부모 프로세스 이름 — 손으로 켰으면 explorer.exe, 업데이트 재실행이면 그 외.
    자동 재실행된 창만 멎는 문제의 원인을 로그로 잡기 위해 (2026-09-02)."""
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        nt = ctypes.windll.ntdll

        class PBI(ctypes.Structure):
            _fields_ = [("Reserved1", ctypes.c_void_p), ("PebBaseAddress", ctypes.c_void_p),
                        ("Reserved2", ctypes.c_void_p * 2), ("UniqueProcessId", ctypes.c_void_p),
                        ("InheritedFromUniqueProcessId", ctypes.c_void_p)]
        pbi = PBI()
        # 64비트에서 HANDLE/NTSTATUS 형을 정확히 — 안 주면 -1 핸들이 잘려 실패한다
        k.GetCurrentProcess.restype = ctypes.c_void_p
        nt.NtQueryInformationProcess.restype = ctypes.c_long
        nt.NtQueryInformationProcess.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong,
            ctypes.POINTER(ctypes.c_ulong)]
        k.OpenProcess.restype = ctypes.c_void_p
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.QueryFullProcessImageNameW.argtypes = [
            ctypes.c_void_p, wintypes.DWORD, ctypes.c_wchar_p,
            ctypes.POINTER(wintypes.DWORD)]
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        h = k.GetCurrentProcess()
        if nt.NtQueryInformationProcess(h, 0, ctypes.byref(pbi),
                                        ctypes.sizeof(pbi), None) != 0:
            return "?"
        ppid = int(pbi.InheritedFromUniqueProcessId or 0)
        ph = k.OpenProcess(0x1000, False, ppid)           # QUERY_LIMITED_INFORMATION
        if not ph:
            return f"pid {ppid} (종료됨)"
        buf = ctypes.create_unicode_buffer(1024)
        n = wintypes.DWORD(1024)
        ok = k.QueryFullProcessImageNameW(ph, 0, buf, ctypes.byref(n))
        k.CloseHandle(ph)
        return Path(buf.value).name if ok else f"pid {ppid}"
    except Exception:
        return "?"


def startup_diag() -> str:
    """시작 진단 한 줄 — watcher.log에 남긴다. 다음엔 추측 대신 로그로 잡는다."""
    from watcher import webengine as _we
    keys = [k for k in os.environ
            if k.startswith(("WEBVIEW2_", "PYTHONNET", "_PYI", "DOTNET_", "PYTHON"))]
    return (f"[start] v{__version__} 부모={parent_process_name()} "
            f"환경={','.join(sorted(keys)) or '-'} {_we.describe()}")


def _auto_update_state_html(cfg: dict, sched_on: bool) -> str:
    """설정 화면의 무인 자동 설치 한 줄 — 설정값만 보고 '켜짐'이라 하면 거짓인 경우가 있다:
    업데이트 확인이 꺼졌거나, 예약 검사가 없거나, 자동 교체가 안 되는 실행 형태 (검토20 중간 1)."""
    from watcher import selfupdate as _su
    if not cfg.get("auto_update", True):
        return "<b>꺼짐</b> — 새 판은 왼쪽 메뉴의 [설치]를 눌러야 적용됩니다."
    on = '<span style="color:var(--ok,#2a7)">켜짐</span>'
    if not cfg.get("update_check", True):
        return (f"{on}이지만 <b>동작하지 않습니다</b> — 위의 새 버전 확인이 꺼져 있어 새 판을 알 수 없습니다. "
                f"[시작 시 자동 확인 켜기]를 누르면 동작합니다.")
    if _su.install_root() is None:
        return (f"{on}이지만 <b>이 실행 형태에서는 동작하지 않습니다</b> — 포터블·설치판(Drev.exe + python 폴더)에서만 "
                f"스스로 교체합니다.")
    if not sched_on:
        return (f"{on} — 다만 <b>자동 실행(예약 검사)이 등록되어 있지 않아</b> 아직 동작할 기회가 없습니다. "
                f"위 [자동 실행 등록]을 하면 예약 검사가 끝난 뒤 새 판을 스스로 받아 검증하고 교체합니다.")
    return (f"{on} — 자동 실행(예약) 검사가 끝난 뒤 새 판이 있으면 스스로 받아 검증하고 교체합니다. "
            f"창이 떠 있으면 다음 예약 검사 때 다시 시도하고, 실패하면 이전 판으로 되돌린 뒤 같은 판은 "
            f"{_su.FAILED_RETRY_DAYS}일간 다시 받지 않습니다. 이력·설정은 건드리지 않습니다.")


def consume_auto_updated(root) -> str:
    """예약 검사 뒤 무인 교체가 남긴 표식을 읽고 지운다 — 버전 문자열(없으면 빈 문자열)."""
    if root is None:
        return ""
    from watcher.selfupdate import AUTO_MARK, _rm
    p = Path(root) / AUTO_MARK
    try:
        if not p.exists():
            return ""
        ver = p.read_text(encoding="utf-8", errors="replace").strip()[:20]
        _rm(p)                     # 프로그램 폴더의 표식 파일 하나 — 산출물이 아니다
        return ver
    except OSError:
        return ""


def last_update_failure(root, within_lines: int = 400) -> str:
    """지난 교체가 실패로 끝났으면 그 사유. 성공/기록 없음이면 빈 문자열.

    watcher.log의 `[update]` 줄만 본다. 마지막 `[update]` 줄이 실패면 알린다 —
    그 뒤에 성공 줄이 있으면 이미 해결된 것이다."""
    if root is None:
        return ""
    try:
        from watcher.logfile import tail_lines
        lines = tail_lines(Path(root) / "watcher.log", within_lines)
    except OSError:
        return ""
    # 예열·다시 시작 줄은 실패 뒤에도 찍힌다 — 결과를 말하는 줄만 본다
    marks = [ln for ln in lines if ln.startswith("[update]")
             and any(k in ln for k in ("교체 완료", "교체 실패", "다시 시작하지 못했"))]
    if not marks:
        return ""
    last = marks[-1]
    if "교체 실패" not in last and "다시 시작하지 못했" not in last:
        return ""
    return last[len("[update]"):].strip()[:300]


def _message_box(title: str, text: str) -> None:
    """콘솔이 없는 창 모드에서 사람에게 한 줄 알리는 최후 수단 (Windows MessageBox)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x10)   # MB_ICONERROR
    except Exception:
        pass


def run_web(config_path: str = "config.yaml", open_browser: bool = True) -> int:
    import sys

    # 주의: 여기서 os를 지역 import하면 함수 전체에서 전역 os가 가려져
    # 비-frozen(포터블) 실행이 UnboundLocalError로 죽는다 (2026-08-30 실측)
    if getattr(sys, "frozen", False):
        os.chdir(Path(sys.executable).parent)
    # 예약 검사 뒤 자동 업데이트가 **교체 중**이면 창을 열지 않는다 — 이때 켜진 창의 정리가
    # 교체 원본·되돌리기 재료를 지워 app/이 사라질 수 있었다 (검토20 차단 1)
    try:
        from watcher import selfupdate as _su0
        _r0 = _su0.install_root()
        if _r0 is not None and _su0.applying_pid(_r0) is not None:
            print("자동 업데이트가 새 판으로 교체하는 중입니다 — 30초쯤 뒤에 다시 열어 주세요.")
            _message_box("Drev 업데이트 중",
                         "예약 검사 뒤 자동 업데이트가 새 판으로 교체하는 중입니다.\n"
                         "30초쯤 뒤에 Drev를 다시 열어 주세요. 이력·설정은 그대로입니다.")
            return 0
    except Exception:
        pass
    # 첫 실행: config가 없으면 GUI 폴더 선택으로 생성 (tkinter는 대화상자만 사용)
    if not Path(config_path).exists():
        made = False
        try:
            import tkinter as tk
            from watcher.gui import _ensure_config
            r = tk.Tk()
            r.withdraw()
            made = _ensure_config(r)
            r.destroy()
        except Exception:
            pass
        if not made and not Path(config_path).exists():
            if sys.stdin is None or not sys.stdin.isatty():
                # 창 모드/포터블: tkinter(폴더 선택창)도 콘솔도 없다 — 임베디드
                # 파이썬엔 tkinter가 없어 첫 실행이 조용히 죽던 문제 (2026-08-30
                # 실PC). 빈 설정으로 화면을 띄우고 '설정→감시 폴더 추가'로 잇는다
                Path(config_path).write_text("roots: []\n", encoding="utf-8")
                print("첫 실행: 빈 설정 생성 — 화면의 [설정]에서 감시 폴더를 "
                      "추가하세요.")
            else:
                from watcher.cli import run_wizard
                return run_wizard()

    from watcher.cli import ConfigError, load_config
    try:
        cfg = load_config(Path(config_path))
    except ConfigError as e:
        # 창 모드에는 콘솔이 없어 '더블클릭해도 안 뜸'만 남았다 — 무엇을 고칠지 창으로
        # 알려주고 끝낸다 (2026-09-04 검토 ops M1)
        print(f"오류: {e}", file=sys.stderr)
        _message_box("Drev — 설정 파일 오류", f"{e}\n\n파일: {Path(config_path).resolve()}")
        return 2
    try:
        port = urlparse(cfg["ack_url"]).port or 8765
    except ValueError:                       # 포트가 숫자가 아닌 주소가 저장돼 있어도 뜬다
        port = 8765
    url = f"http://127.0.0.1:{port}/"
    try:
        server = _bind_with_retry(config_path, port, url)
    except OSError:
        # 포트 선점 — 우리 인스턴스인지 확인 후 안내 (다른 프로그램이면 오도 방지)
        import watcher as _w
        ours = same_ver = False
        try:
            import urllib.request
            with _NOPROXY.open(url, timeout=3) as r:
                body0 = r.read(4096).decode("utf-8", "replace")
                ours = ("Drev" in body0 or "Project Watcher" in body0)
        except Exception:
            pass
        if ours:
            # 같은 판인지까지 확인한다. 구버전이 포트를 잡고 있는데 그냥 붙으면
            # 새 판을 실행해도 구버전 화면이 브라우저로 열려 "새 기능이 없다"로
            # 보인다 — 실제로 발생(2026-08-31, v0.29.3이 v0.30.2를 가림).
            try:
                import urllib.request
                with _NOPROXY.open(url + "version", timeout=3) as r:
                    same_ver = r.read(64).decode("utf-8", "replace").strip() \
                        == f"Drev {_w.__version__}"
            except Exception:
                same_ver = False      # /version 자체가 없으면 옛 판
        if ours and same_ver and _existing_window_ok():
            # 이미 실행 중 — 기존 창을 앞으로 가져온다 (2026-08-30 사용자:
            # "원래 열려 있던 창이 그대로 열리면 되는 거 아니야?"). 창을
            # 못 찾으면(브라우저 폴백 모드 등) 새 창/브라우저로 연다.
            print(f"이미 실행 중입니다: {url}")
            try:
                import ctypes
                u = ctypes.windll.user32
                h = u.FindWindowW(None, "Drev — 산출물 변경 감시")
                if h and not _window_of_port(h, port):
                    # 제목만 보고 찾으면 이 PC의 **다른** Drev 창을 앞으로 가져오고 정작 자기
                    # 화면은 안 연다 — 업데이트 도중 두 판이 공존할 때가 정확히 그 상황이다
                    # (2026-09-08 사용성 8차 낮음-5, 검토자 실측)
                    print("찾은 창이 이 주소의 판이 아니라 새로 엽니다.")
                    h = 0
                if h and not window_alive(h):
                    # 멎은 창 — 붙으면 "켜졌는데 클릭이 안 됨"이 된다
                    print("기존 창이 응답하지 않아 새 창으로 엽니다.")
                    h = 0
                if h:
                    u.ShowWindow(h, 9)          # SW_RESTORE (최소화 해제)
                    u.SetForegroundWindow(h)
                    print("기존 창을 앞으로 가져왔습니다.")
                    return 0
            except Exception:
                pass
            if open_browser and ui_mode(cfg) == "window":
                try:
                    import webview
                    _w, _h, _x, _y = _window_box()
                    _win = webview.create_window("Drev — 산출물 변경 감시", url,
                                                 width=_w, height=_h, x=_x, y=_y,
                                                 min_size=(900, 600))
                    _win._drev_styled = True
                    style_on_shown(_win)
                    _start_webview()
                    return 0
                except Exception:
                    pass
            if open_browser:
                import webbrowser
                webbrowser.open(url)
            return 0
        # 다른 판(또는 다른 프로그램)이 포트를 잡고 있다 — 그 화면에 끌려가지
        # 말고, 빈 포트를 찾아 우리 창을 띄운다 (2026-08-31)
        server = None
        for _p in range(port + 1, port + 11):
            try:
                server = make_web_server(config_path, port=_p)
            except OSError:
                continue
            port, url = _p, f"http://127.0.0.1:{_p}/"
            print(f"기본 포트가 사용 중이라 이 판은 {url} 로 엽니다."
                  + (" (다른 판의 Drev가 실행 중입니다)" if ours else ""))
            break
        if server is None:
            print(f"오류: 포트 {port}~{port + 10}이 모두 사용 중입니다. "
                  f"실행 중인 Drev를 종료한 뒤 다시 실행해주세요.",
                  file=sys.stderr)
            return 1
    # 창 모드 (2026-08-29): 브라우저 대신 자체 창(WebView2)에 화면을 담는다 —
    # 일반 프로그램처럼 보이고, X 닫기 = 즉시 종료(검사 중 포함 — 사용자 결정:
    # 멈춘 것 같아 끄는 경우가 있으므로. 진행분은 저장되고 스냅샷은 롤백되어
    # 다음 검사가 이어받는다). PW_BROWSER=1 또는 WebView2 불가 PC는 브라우저 폴백.
    # 시작 시 새 버전 확인 (백그라운드, 기본 ON — update_check: false로 끔)
    if cfg.get("update_check", True):
        def _update_loop():
            import time as _t
            while True:
                try:
                    server.app.refresh_update()
                except Exception:
                    pass
                finally:
                    server.app.first_check.set()
                _t.sleep(6 * 3600)     # 하루 4번이면 충분 (버전 파일 하나만 GET)
        threading.Thread(target=_update_loop, daemon=True).start()
    else:
        server.app.first_check.set()
    # 함께 떠 있는 다른 판 감지 — 화면이 섞이기 전에 배너로 알린다 (2026-08-31)
    threading.Thread(target=server.app.scan_others, daemon=True).start()
    # 지난 자동 업데이트의 작업 폴더·되돌리기용 잔재 정리 (조용히)
    from watcher import selfupdate as _su
    _root = _su.portable_root()
    if _root is None:
        _ex = _su.installed_exe()
        _root = _ex.parent if _ex is not None else None
    if _root is not None:
        # 지난 업데이트가 실패로 끝났으면 사유를 한 번 알린다 — 로그에만 있으면
        # 사용자에겐 "눌렀는데 그대로"로만 보인다 (2026-09-02 회사 실사용)
        _why = last_update_failure(_root)
        _auto_ver = consume_auto_updated(_root)
        if _auto_ver:
            server.app.last_msg = (f"예약 검사 뒤 v{_auto_ver}으로 자동 갱신되었습니다 — "
                                   f"이력·설정은 그대로입니다. (끄려면 설정 › 업데이트)")
        if _why and "원복 불완전" in _why:
            server.app.last_msg = (
                f"지난 업데이트가 실패했고 되돌리기도 완전하지 않습니다 — {_why}. "
                f"다운로드 페이지에서 설치 파일로 덮어써 주세요 (설정·이력은 유지됩니다).")
        elif _why and "자동 업데이트" in _why:
            # 사람이 누른 것처럼 읽히지 않게 — 예약 검사 뒤 무인 교체의 실패 (검토20 낮음)
            server.app.last_msg = (
                f"지난 예약 검사 뒤 자동 업데이트가 적용되지 않아 이전 판 그대로입니다 — {_why}. "
                f"왼쪽 메뉴의 [설치]로 바로 다시 시도하거나, 다운로드 페이지에서 설치 파일로 덮어써 주세요.")
        elif _why:
            server.app.last_msg = (
                f"지난 업데이트가 적용되지 않아 이전 판으로 되돌렸습니다 — {_why}. "
                f"다시 시도하거나, 다운로드 페이지에서 설치 파일로 덮어써 주세요.")
        threading.Thread(target=_su.cleanup, args=(_root,), daemon=True).start()
    try:
        print(startup_diag())
    except Exception:
        pass

    def _backfill():
        # 내용 단서 소급 — 업데이트 직후 다음 검사까지 화면이 그대로인 것 방지
        try:
            from watcher.doctype import content_hint
            db = Path(server.app.cfg()["state_db"])
            if not db.exists():
                return
            with State(db) as st:
                n = st.backfill_hints(content_hint)
            if n:
                print(f"[start] 문서 유형 내용 단서 {n}건 소급 생성")
                invalidate_doc_nav()
        except Exception as e:
            print(f"[start] 단서 소급 생성 실패(무시): {e}")
    threading.Thread(target=_backfill, daemon=True).start()
    # 오늘 예약 검사가 돌지 못했으면(재부팅 뒤 로그인 화면·절전 — '로그온 시에만 실행' 작업은 놓친
    # 회차를 되살리지 않는다) 창이 뜨는 김에 대신 돌린다 (2026-09-16 실사용: 02:36 재부팅 → 07:00
    # 건너뜀 → 11:27 로그인 뒤에도 안 돎). 잠금은 검사가 알아서 본다
    threading.Thread(target=server.app.catch_up_missed_scan, daemon=True).start()
    # 첫 화면이 그려지기 전에 버전 확인이 끝나도록 잠깐(최대 2.5초) 기다린다 — 창이 먼저 뜨고
    # 확인이 뒤에 끝나 첫 화면에 [설치] 단추가 없었다; 사람은 "자동 업데이트가 안 된다"고
    # 읽었다 (2026-09-11). 느린 망이면 화면 쪽 /status 조회가 뒤늦게 갈아 끼운다
    if open_browser:
        server.app.first_check.wait(2.5)
        if cfg.get("update_check", True):
            global _STARTUP_POLL_UNTIL
            import time as _t2
            _STARTUP_POLL_UNTIL = _t2.time() + 180
    if open_browser and ui_mode(cfg) == "browser":
        # 설정에서 고른 브라우저 모드 — 창 엔진을 아예 띄우지 않는다
        threading.Thread(target=server.serve_forever, daemon=True).start()
        global SHELL
        SHELL = "browser"                  # 설정에서 직접 고른 브라우저 모드
        print(f"Drev 브라우저 모드: {url}")
        import webbrowser
        webbrowser.open(url)
        server.app.last_msg = ("브라우저 모드로 열렸습니다 — 이 탭을 닫아도 "
                               "프로그램은 계속 돕니다. 끄려면 [설정 → 프로그램 종료].")
        import time as _time
        try:
            while True:
                _time.sleep(3600)
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
        return 0
    if open_browser and ui_mode(cfg) == "window":
        threading.Thread(target=server.serve_forever, daemon=True).start()
        print(f"Drev 창 실행: {url}")
        try:
            import time as _t

            import webview
            _w, _h, _x, _y = _window_box()
            _win = webview.create_window("Drev — 산출물 변경 감시", url,
                                         width=_w, height=_h, x=_x, y=_y,
                                         min_size=(900, 600))
            _win._drev_styled = True
            style_on_shown(_win)
            # 이 함수 안에서 앱은 `server.app`이다 — 맨 이름 `app`은 여기 없다.
            # 2026-09-07: `app.served`라고 적었다가 창을 띄우기도 전에 NameError가 나
            # v0.51.6~0.51.9가 **어느 PC에서도 창으로 뜨지 못했다**(브라우저로 새고 곧 죽음)
            _t0, _served0 = _t.time(), server.app.served
            _start_webview()
            # 창을 띄우기 **전에** 기준을 찍는다 — 진단 스크립트나 다른 판이 한 번 두드린 것까지
            # 세면 창 엔진 사망 방어가 영영 꺼진다 (2026-09-07 운영 검토 4)
            if engine_died(_t.time() - _t0, server.app.served - _served0):
                raise RuntimeError("창이 비정상적으로 즉시 닫힘")
            print("창이 닫혀 종료합니다.")
            server.app.finish_before_exit()
            os._exit(0)
        except SystemExit:
            raise
        except Exception as e:
            print(f"창 모드를 열 수 없어({e}) 브라우저로 엽니다.",
                  file=sys.stderr)
            SHELL = "browser"              # 창을 못 띄워 브라우저로 — 화면 문구가 이 값을 본다
            # 사유를 **먼저** 적어 둔다 — 브라우저가 먼저 떠 첫 화면을 받아 가면 사유가 사라진다
            # (2026-09-08 사용성 8차 중간-1)
            # 콘솔이 없는 조립본에서는 위 문구가 아무 데도 안 보인다 — 화면에도 사유를 남긴다
            # (2026-09-07: 브라우저가 왜 떴는지 알 길이 없었다). 사유를 그대로 싣는다 —
            # 대개 "WebView2 런타임이 이 PC에 없습니다"이고, 그러면 할 일이 정해진다
            server.app.last_msg = (f"Drev 창을 열지 못해 기본 브라우저로 열었습니다 — {e}. "
                            f"프로그램은 계속 돌고 있고 기능은 모두 그대로입니다. "
                            f"창으로 쓰시려면 설정 › 화면에서 진단을 확인하세요. "
                            f"끄려면 [설정 › 프로그램 종료].")
            import webbrowser
            webbrowser.open(url)
        import time as _time
        try:  # 브라우저 폴백: 설정의 [프로그램 종료] 버튼으로 끈다
            while True:
                _time.sleep(3600)
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
        return 0

    print(f"Drev 화면: {url}  (이 창을 닫으면 화면이 종료됩니다)")
    if open_browser:
        import webbrowser
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0
