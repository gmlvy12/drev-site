# -*- coding: utf-8 -*-
"""변경 한 줄 — 규칙 기반(템플릿)만, AI 없음 (2026-11-17 R1, DECISIONS 같은 날).

두 가지를 한 곳에 둔다:
- headline(items): 가장 무거운 변경 한 줄 + '외 N건' — 화면 '오늘 확인할 것'·대장·사내망이 쓰던 State._headline_of 그대로
- summarize(...): 변경 기록 한 줄 요약 — `[도면] E-101 (P24-031): Rev A → B, M-101 5.5kW → 7.5kW`

요약에는 ChangeItem(change_details.items_json)의 old/new에 있는 값만 쓴다. 검토 필요 줄([확인 필요])의 값은 그 변경으로 열린
검토 필요(issues)의 문구·근거에 있는 값만 쓴다. 옳다/그르다는 판단하지 않는다(원칙 6) — 무엇이 어떻게 바뀌었는지만.
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath

from watcher.rowkey import split_row_cell

MAX_PARTS = 3            # 항목이 많으면 앞 3개 + '외 N건'
_VAL_MAX = 40            # 값 하나의 글자 상한 — 넘으면 '…'로 자른다(앞부분은 원래 값 그대로)
ARROW = " → "


def _s(v, n: int = 40) -> str:
    return " ".join(str(v or "").split())[:n]


def _v(v) -> str:
    """요약에 싣는 값 — 공백만 접고, 길면 앞부분 + '…'. 앞부분은 원래 값의 글자 그대로라 대조할 수 있다."""
    s = " ".join(str(v or "").split())
    return s if len(s) <= _VAL_MAX else s[:_VAL_MAX].rstrip() + "…"


def _v_pair(o, n) -> tuple[str, str]:
    """짝 값 둘을 _v로 — 둘 다 잘려 같은 글이 되면(앞 40자가 같고 뒤에서만 다름) 처음 달라지는 자리 둘레를 원래 글자 그대로 '…'로
    감싸 보인다('…베어링 6309ZZ(이전 …베어링 6308ZZ)'). '지금(이전 …)' 꼴에서 이전과 지금이 글자까지 같게 보여 '같은 값인데 왜
    변경?'으로 읽혔다 (검토 Z1 M2). '지금(이전 …)' 꼴(was)에서만 쓴다 — 화살표 꼴은 저장 글과 글자까지 같아야 was_line이 맞춘다."""
    a, b = " ".join(str(o if o is not None else "").split()), " ".join(str(n if n is not None else "").split())
    va, vb = _v(a), _v(b)
    if va != vb or a == b:
        return va, vb
    i = 0
    while i < min(len(a), len(b)) and a[i] == b[i]:
        i += 1
    st = max(0, i - 12)
    sp = a.rfind(" ", 0, st + 1)                      # 낱말 머리에서 시작 — 너무 멀면(낱말이 길면) 그냥 12자 앞
    if sp >= 0 and i - (sp + 1) <= 24:
        st = sp + 1

    def win(s: str) -> str:
        part = s[st:st + _VAL_MAX].rstrip()
        return ("…" if st > 0 else "") + part + ("…" if st + _VAL_MAX < len(s) else "")
    return win(a), win(b)


def _vv(o, n, was: bool) -> tuple[str, str]:
    """요약 조각의 값 짝 — 화살표 꼴은 _v 둘(저장 글과 같게), '지금(이전 …)' 꼴은 _v_pair."""
    return _v_pair(o, n) if was else (_v(o), _v(n))


# ─────────────────────────── '지금(이전 …)' 꼴 (검토 Y2, 2026-11-22) ───────────────────────────
# 한 줄 자리(대장 '바뀐 것 요약'·오늘 화면·툴팁·메일 제목)는 화살표 대신 '지금(이전 …)'. 저장된 한 줄 글을 다시 쪼개면 값 속 쉼표·쌍점·
# 줄표와 낱말 수가 다른 짝에서 이전 값이 다른 값으로 보였다(Y2 H1 — 'M-502 MOTOR 5.5kW MOTOR 7.5kW(이전 4P 380V)'). 그래서 항목
# (ChangeItem old/new)에서 바로 만든다 — 화살표 꼴과 같은 함수·같은 재료(was=True만 다르다).

def was_pair(o, n, key: str = "") -> str:
    """값 짝 한 줄 — '바뀐 곳 지금(이전 …)'. 값이 이미 '(이전 …)'를 품으면 겹친 괄호가 읽히지 않아 '이전 X · 지금 Y' (Y2 L2)."""
    o, n = str(o if o is not None else "").strip(), str(n if n is not None else "").strip()
    body = f"이전 {o} · 지금 {n}" if ("(이전 " in o or "(이전 " in n) else f"{n}(이전 {o})"
    return f"{key} {body}" if key else body


def _pair_text(key: str, o: str, n: str, was: bool) -> str:
    """'바뀐 곳 이전 → 지금' 또는 '바뀐 곳 지금(이전 …)' — key는 앞에 붙는 말(없으면 '')."""
    if was:
        return was_pair(o, n, key)
    return (f"{key} " if key else "") + f"{o}{ARROW}{n}"


def as_item_dict(it) -> dict | None:
    """항목 하나를 dict로 — 저장 JSON(dict)과 ChangeItem 객체 모두."""
    if isinstance(it, dict):
        return it
    if it is None or not hasattr(it, "kind"):
        return None
    return {k: getattr(it, k, None) for k in ("kind", "key", "old", "new", "where", "label")}


# ─────────────────────────── 가장 무거운 한 줄 (옛 State._headline_of) ───────────────────────────

def _text_was(key: str, o: str, n: str) -> str:
    """글줄 짝의 '지금(이전 …)' — 태그 줄('M-502 MOTOR 5.5kW 4P 380V' → 'M-502 MOTOR 7.5kW')은 태그를 바뀐 곳으로 한 번만:
    'M-502 MOTOR 7.5kW(이전 MOTOR 5.5kW 4P 380V)'. 낱말 수가 달라도 항목 값에서 바로 떼므로 이전 값이 바뀌지 않는다 (Y2 H1)."""
    if key and o.startswith(key + " ") and n.startswith(key + " "):
        ro, rn = o[len(key):].strip(), n[len(key):].strip()
        if ro and rn:
            return was_pair(ro, rn, key)
    return was_pair(o, n)


def headline(items: list, with_weight: bool = False, was: bool = False):
    """상세 항목 목록에서 가장 무거운 변경 한 줄. 사양·표 행 > Rev > 글자·그림 > 날짜·크기 > 참고.
    with_weight면 (무게, 한 줄)을 돌려준다. was: 값 짝을 화살표 대신 '지금(이전 …)'으로(항목 값에서 바로 — 저장 글을 다시 쪼개지 않는다)."""
    best, best_w = "", 99
    n_rest = 0
    for it in items:
        it = as_item_dict(it)
        if it is None:
            continue
        k, key = it.get("kind", ""), _s(it.get("key"))
        # 값 상한 40자 — '지금(이전 …)' 꼴은 잘린 값 끝에 '…'(잘린 문장이 온전한 값처럼 읽히지 않게, 요약 조각 _v와 같은 규칙)
        o, n = _v_pair(it.get("old"), it.get("new")) if was else (_s(it.get("old")), _s(it.get("new")))
        if k.startswith("ROW_"):
            # 키는 '행키.열'(X-11.수량) — 품명 라벨만 쓰면 "RELAY · RELAY 24VDC: 2 → 4"처럼
            # 무엇의 수량인지 안 보였다 (파일럿 모의 3차 ③)
            rk, sep, col = split_row_cell(key)
            head = f"{rk} {col}".strip() if sep else key
            lab = _s(it.get("label"))
            from watcher.brief import _group_digits     # 대시보드·이력 한 줄도 천 단위 — 메일·상세만 고쳐졌다 (검토56 ④16)
            o, n = _group_digits(o), _group_digits(n)
            w, txt = 0, ((f"{head}: " + (was_pair(o, n) if was else f"{o} → {n}"))
                         + (f" ({lab})" if lab and lab != head else "")
                         if k == "ROW_CHANGED" and o and n
                         else f"{key} 행 {'추가' if k.endswith('ADDED') else '삭제' if k.endswith('REMOVED') else '변경'}"
                              + (f" ({lab})" if lab else ""))
        elif k == "TEXT_CHANGED":
            w, txt = (0 if any(ch.isdigit() for ch in o + n) else 2), (_text_was(key, o, n) if was else f"{o} → {n}")
        elif k == "FIELD_CHANGED" and key.split("#", 1)[0] == "REV" and n and it.get("label") != "새 표제란":
            # 메일·상세와 같은 말 — 둘째 표제란도 Rev, 빈칸→A는 첫 기재 (검토38 R5 중간 6)
            w, txt = 1, (f"Rev {n} 첫 기재" if o in ("", "-", "—") else _pair_text("Rev", o, n, was))
        elif k == "FIELD_CHANGED":
            w, txt = (3 if key in ("DATE", "파일 크기", "저장 시각") else 2), _pair_text(key, o or ("(빈칸)" if was else o),
                                                                                  n or ("(빈칸)" if was else n), was)
        elif k in ("TEXT_ADDED", "TEXT_REMOVED"):
            w, txt = 2, f"글자 {'추가' if k.endswith('ADDED') else '삭제'}: {n or o}"
        elif k == "PAGE_VISUAL_CHANGED":
            w, txt = 2, f"그림 변경 ({key})"
        elif k == "EMBED_CHANGED":
            w, txt = 1, key            # '문서 안 그림 교체' (검토71 R4)
        elif k == "NEW_REVISION_OF":
            w, txt = 2, _pair_text("이전 판", o, n, was)
        elif k == "CHECK_SKIPPED" and ("추출 실패" in key or (key == "내용 비교" and "수행 못 함" in n)):
            # 읽지 못한 파일이 목록에서 '저장 시각 … → …'만 보여 다시 저장한 것으로 읽혔다 (검토65 B8·D-6) — 그것부터
            from watcher.brief import _unread_label
            w, txt = 0, f"내용 읽지 못함 — {_unread_label(str(it.get('new') or ''))}"
        elif k == "CHECK_SKIPPED" and key == "참고":
            w, txt = 4, n
        else:
            continue
        if w < best_w:
            best, best_w = txt, w
        n_rest += 1
    if best and n_rest > 1:
        best += f" 외 {n_rest - 1}건"
    if with_weight:
        return (best_w if best else 5, best)
    return best


# ─────────────────────────── 숨긴 항목 빼기 ───────────────────────────

def visible_items(items, dismissed) -> list:
    """[잘못 잡힘 숨기기](dismissed_json)로 숨긴 항목을 뺀 목록 — 저장값은 그대로 두고 **보여 줄 때만** 뺀다 (pv2 C6).
    dismissed: {'항목 번호': {...}} (문자열 열쇠) 또는 번호 묶음."""
    if not dismissed:
        return list(items or [])
    gone = {str(k) for k in dismissed}
    return [it for i, it in enumerate(items or []) if str(i) not in gone]


# ─────────────────────────── 변경 한 줄 요약 ───────────────────────────

_NO_REV = ("", "-", "—")


def _rev_item(it) -> bool:
    return (it.get("kind") == "FIELD_CHANGED" and str(it.get("key") or "").split("#", 1)[0] == "REV"
            and it.get("new") not in (None, "") and it.get("label") != "새 표제란")


def _part(it, has_rev: bool, was: bool = False) -> str | None:
    """항목 하나 → 요약 조각. 값은 항목의 old/new 그대로(공백 접기·길이 자르기만). was: 값 짝을 '지금(이전 …)'으로."""
    k = str(it.get("kind") or "")
    key = " ".join(str(it.get("key") or "").split())
    o, n = it.get("old"), it.get("new")
    if _rev_item(it):
        return f"Rev {_v(n)} 첫 기재" if str(o or "").strip() in _NO_REV else _pair_text("Rev", *_vv(o, n, was), was)
    if k == "FIELD_CHANGED":
        if was:
            vo, vn = _v_pair(o, n)
            return was_pair(vo or "(빈칸)", vn or "(빈칸)", key)
        return f"{key} {_v(o)}{ARROW}{_v(n)}"
    if k == "TEXT_CHANGED":
        so, sn = " ".join(str(o or "").split()), " ".join(str(n or "").split())
        # 태그 줄('M-101 5.5kW' → 'M-101 7.5kW')은 태그를 한 번만: 'M-101 5.5kW → 7.5kW'
        if key and so.startswith(key + " ") and sn.startswith(key + " "):
            ro, rn = so[len(key):].strip(), sn[len(key):].strip()
            if ro and rn:
                return _pair_text(key, *_vv(ro, rn, was), was)
        return _pair_text("", *_vv(so, sn, was), was)
    if k in ("TEXT_ADDED", "TEXT_REMOVED"):
        return f"글자 {'추가' if k.endswith('ADDED') else '삭제'}: {_v(n if k.endswith('ADDED') else o)}"
    if k == "ROW_CHANGED":
        rk, sep, col = split_row_cell(key)
        head = f"{rk} {col}".strip() if sep else key
        # 빈칸 ↔ 값(수식 계산값이 생기거나 사라짐·칸 비움)은 빈 글자 대신 '(빈칸)' — 'SPEC  → 15kW'로 값이 빠진 듯 보였다 (V1-2)
        vo, vn = _vv(o, n, was)
        return _pair_text(head, vo or "(빈칸)", vn or "(빈칸)", was)
    if k in ("ROW_ADDED", "ROW_REMOVED"):
        return f"{key} 행 {'추가' if k.endswith('ADDED') else '삭제'}"
    if k == "REVROW_ADDED":
        return None if has_rev else f"개정표 {key} 행 추가"
    if k in ("REVROW_REMOVED", "REVROW_CHANGED"):
        return f"개정표 {key} 행 {'삭제' if k.endswith('REMOVED') else '변경'}"
    if k == "PAGE_VISUAL_CHANGED":
        return f"그림 변경 ({key})"
    if k == "NEW_REVISION_OF":
        return _pair_text("이전 판", *_vv(o, n, was), was)
    if k in ("COL_RENAMED", "SHEET_RENAMED") and o and n:
        from watcher.brief import _ITEM_KIND
        return _pair_text(_ITEM_KIND[k][0], *_vv(o, n, was), was)
    if k in ("EMBED_CHANGED", "PAGE_ADDED", "PAGE_REMOVED", "COL_ADDED", "COL_REMOVED", "COL_MOVED", "ROW_MOVED",
             "PAGE_MOVED", "TEXT_MOVED", "SHEET_ADDED", "SHEET_REMOVED", "COL_RENAMED", "SHEET_RENAMED"):
        from watcher.brief import _ITEM_KIND
        lab = _ITEM_KIND.get(k, (k,))[0]
        return f"{lab} ({key})" if key and key != lab else lab
    if k == "CHECK_SKIPPED" and ("추출 실패" in key or (key == "내용 비교" and "수행 못 함" in str(n or ""))):
        from watcher.brief import _unread_label
        return f"내용 읽지 못함 — {_unread_label(str(n or ''))}"
    return None


def _short_path(p: str, ref: str = "") -> str:
    """다른 경로를 알아볼 만큼만 — 이름 + (폴더가 다르면) 끝에서부터 ref(이 변경의 경로) 폴더와 처음 달라지는 폴더까지.
    같은 폴더면 'E-202_old.dxf', 폴더가 다르면 '도면/E-3.dxf'·'P1/도면/E-3.dxf'. ref가 없으면 이름만
    (V1-10: 같은 이름 이동이 '이전: E-3.dxf'로 보여 어디서 왔는지 몰랐다)."""
    a = [x for x in "/".join(str(p or "").split("\\")).split("/") if x]
    b = [x for x in "/".join(str(ref or "").split("\\")).split("/") if x]
    if not a:
        return str(p or "")
    if not b:
        return a[-1]
    da, db = a[:-1], b[:-1]
    n = 0
    while n < len(da) and n < len(db) and da[-1 - n] == db[-1 - n]:
        n += 1
    if n == len(da) == len(db):
        return a[-1]                                 # 같은 폴더 — 이름만
    return "/".join(da[-(n + 1):] + [a[-1]]) if da else a[-1]


_SUFFIX_PAREN = re.compile(r"\s*\((?:내용 동일|다른 이름·다른 폴더라 이동으로 묶지 않았습니다)\)\s*$")


def _restored_mark() -> str:
    """되살린 파일의 참고 머리 — 검사(cli.RESTORED_MARK)가 저장 글에 다는 표식 하나를 읽는다(판정은 거기)."""
    from watcher.cli import RESTORED_MARK
    return RESTORED_MARK


# 바이트까지 같게 되살린 파일의 참고 — 검사는 상세를 두지 않고(cli._compare_modified), 화면·사내망·대장이 기록에서 만든다:
# 'MM-DD 삭제(#id)와 같은 내용 — 되살아남' (change_ledger.added_notes, rv0676 WE2). 글은 그 함수 하나가 만들고 여기서는 알아보기만
SAME_RESTORED = re.compile(r"^(?:(\d{1,2})-(\d{1,2}) )?삭제\(#(\d+)\)와 같은 내용 — 되살아남")


def restored_text(t) -> str:
    """되살림을 말하는 글인가 — 두 꼴 (Z3a M1, 판단은 여기 하나):
    ① 검사가 저장한 참고 '되살림 — MM-DD 검사에서 없어졌던 파일이 …'(cli.RESTORED_MARK — 값을 바꿔 되살림·비교 못 함)
    ② 기록에서 만든 'MM-DD 삭제(#id)와 같은 내용 — 되살아남'(바이트까지 같게 되살림 — 그 뒤 ' · 출도본 …'이 붙을 수 있다).
    맞으면 공백을 접은 그 글, 아니면 ''. 같은 이름의 다른 도면·다른 폴더에 다시 생김·다른 이름·옮기며 수정은 두 꼴 어디에도 없다."""
    s = " ".join(str(t or "").split())
    if s.startswith(_restored_mark()) or SAME_RESTORED.match(s):
        return s
    return ""


def restored_note(items, note: str = "") -> str:
    """지웠다가 같은 자리에 되살린 파일(pv2 B-2)의 참고 글 — 없으면 ''. items: ChangeItem 또는 dict 목록(저장 참고 ①),
    note: 기록에서 만든 참고(② — summary.restored_adds·change_ledger.added_notes) 또는 행에 찍힌 참고 문구. 둘 중 하나면 된다."""
    mark = _restored_mark()
    for it in items or ():
        d = as_item_dict(it) if not isinstance(it, dict) else it
        if not d or d.get("kind") != "CHECK_SKIPPED" or d.get("key") != "참고":
            continue
        t = " ".join(str(d.get("new") or "").split())
        if t.startswith(mark):
            return t
    return restored_text(note)


_RESTORED_WHEN = re.compile(r"^되살림 — (\d{1,2})-(\d{1,2}) 검사에서 없어졌던 파일")


def restored_short(items, note: str = "", when: str = "") -> str:
    """되살린 파일 한 마디 — '되살림 (11월 13일에 없어졌던 파일)'. 날짜를 못 읽으면 '되살림'. 아니면 ''.
    when: 화면이 기록(없어진 검사 시각)에서 만든 날짜 글('2025년 12월 31일') — 있으면 그것(저장 글의 'MM-DD'에는 연도가 없어 해를
    넘긴 기록이 올해 것으로 읽혔다, Z3a M3·L5). 변경 종류 저장값은 '추가' 그대로 — 보일 때만 '되살림'(기록은 덧붙임만, Y1 P3b)."""
    t = restored_note(items, note)
    if not t:
        return ""
    if when:
        return f"되살림 ({when}에 없어졌던 파일)"
    m = _RESTORED_WHEN.match(t) or SAME_RESTORED.match(t)
    return f"되살림 ({int(m.group(1))}월 {int(m.group(2))}일에 없어졌던 파일)" if (m and m.group(1)) else "되살림"


def is_restored(kind: str, items=None, note: str = "") -> bool:
    """지웠다 같은 자리에 되살린 '추가'인가 — 두 꼴 모두(restored_text). 화면·사내망의 '되살림' 판단은 이 함수 하나."""
    return kind == "added" and bool(restored_note(items, note))


def kind_label(kind: str, items=None, note: str = "") -> str:
    """변경 종류 이름 — '수정'·'추가'·'삭제', 되살린 파일의 '추가'는 '되살림'. 화면·사내망·대장·메일이 같이 쓴다."""
    from watcher.state import KIND_LABEL
    if is_restored(kind, items, note):
        return "되살림"
    return KIND_LABEL.get(kind, kind)


def restored_adds(st, ids=None, cfg=None) -> dict:
    """같은 자리에서 지웠다 되살린 '추가' — {변경 id: {"note": 참고 글, "pair": 짝 삭제 기록 id|None, "gone": 없어진 검사 시각(ISO)}}.
    읽기만 한다. 같은 경로의 바로 앞 기록이 '삭제'인 '추가' 가운데(검사 cli._restored_paths와 같은 짝)
    - 바이트까지 같으면 change_ledger.added_notes가 만든 'MM-DD 삭제(#id)와 같은 내용 — 되살아남'(이동 짝은 그 함수가 뺀다 — rv0676 RS1)
    - 아니면 검사가 저장한 참고가 cli.RESTORED_MARK로 시작할 때만(같은 자리의 다른 도면은 검사가 '새 파일'로 적었다 — Z2 낮음 4).
    ids: 이 추가들만(문서함·사내망 몇 줄). 없으면 기록 전부 — 화면이 세대마다 한 번 읽어 둔다(web.WebApp._rs_all).
    바이트까지 같게 되살린 파일은 상세가 없어, 참고 글만 보는 화면들이 '새 문서'로 불렀다(Z3a M1) — 판단 재료를 기록에서 모은다."""
    import json
    import sqlite3
    cand: list = []          # (추가 id, 경로, 지금 지문, 앞 기록 id, 앞 기록 종류, 앞 기록 지문(삭제 전), 앞 기록 시각)
    if ids is None:
        try:
            cand = st.conn.execute(
                "SELECT id, path, new_sha256, pid, pk, posha, pat FROM (SELECT id, kind, path, new_sha256, "
                "LAG(id) OVER w AS pid, LAG(kind) OVER w AS pk, LAG(old_sha256) OVER w AS posha, LAG(detected_at) OVER w AS pat "
                "FROM changes WINDOW w AS (PARTITION BY path ORDER BY id)) WHERE kind = 'added' AND pk = 'removed'").fetchall()
        except sqlite3.OperationalError as e:      # 창 함수가 없는 옛 SQLite — 추가마다 앞 기록을 찾는다(드물다)
            if "locked" in str(e).lower() or "busy" in str(e).lower():
                raise
            ids = [r[0] for r in st.conn.execute("SELECT id FROM changes WHERE kind = 'added'")]
    if ids is not None:
        want = sorted({int(i) for i in ids if isinstance(i, int) or str(i).isdigit()})
        for k in range(0, len(want), 400):
            part = want[k:k + 400]
            for cid, path, sha in st.conn.execute(
                    f"SELECT id, path, new_sha256 FROM changes WHERE kind = 'added' AND id IN ({','.join('?' * len(part))})", part):
                prev = st.conn.execute("SELECT id, kind, old_sha256, detected_at FROM changes WHERE path = ? AND id < ? "
                                       "ORDER BY id DESC LIMIT 1", (path, cid)).fetchone()
                if prev and prev[1] == "removed":
                    cand.append((cid, path, sha, prev[0], prev[1], prev[2], prev[3]))
    if not cand:
        return {}
    out: dict = {}
    same = [c for c in cand if c[2] and c[5] == c[2]]
    if same:
        from watcher.change_ledger import added_notes
        notes = added_notes(st, [{"id": c[0], "kind": "added", "path": c[1], "new_sha256": c[2]} for c in same], cfg)
        for c in same:
            t, pair = notes.get(c[0], ("", None))
            first = str(t or "").split(" · ", 1)[0]
            if pair is not None and SAME_RESTORED.match(first):
                out[c[0]] = {"note": first, "pair": int(pair), "gone": c[6]}
    other = [c for c in cand if c[0] not in out and not (c[2] and c[5] == c[2])]
    for k in range(0, len(other), 400):
        part = other[k:k + 400]
        by = {c[0]: c for c in part}
        for cid, js in st.conn.execute(
                f"SELECT change_id, items_json FROM change_details WHERE change_id IN ({','.join('?' * len(part))}) "
                "AND instr(items_json, 'CHECK_SKIPPED') > 0", list(by)):
            try:
                its = json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            t = restored_note(its if isinstance(its, list) else [])
            if t:
                out[int(cid)] = {"note": t, "pair": None, "gone": by[cid][6]}
    return out


def _note_short(items, path: str = "") -> str:
    """'참고' 문구(다시 저장만·이동·복사본 …)의 짧은 꼴 — 화면 문구의 첫 마디. 없으면 ''.
    이동·같은 내용의 새 파일은 다른 쪽 경로를 짧게 붙인다 — [삭제] 줄이 이 참고를 버려 진짜 삭제처럼 읽혔다 (V1-10)."""
    from watcher.brief import _MOVE_MARK
    rs = restored_short(items)
    if rs:
        return rs
    for it in items:
        if it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
            note = " ".join(str(it.get("new") or "").split())
            if note.startswith(_MOVE_MARK.strip()):
                prev = note[len(_MOVE_MARK):].strip()
                same = "(내용 동일)" in prev
                prev = _SUFFIX_PAREN.sub("", prev).strip()
                if not prev:
                    return "이름·위치만 바뀜"
                return f"이름·위치만 바뀜 (이전: {_short_path(prev, path)}{', 내용 동일' if same else ''})"
            m = re.match(r"^삭제됨 — 같은 내용의 새 파일 있음: (.+?)( 외 \d+곳)?(?: \(다른 이름·다른 폴더라 이동으로 묶지 않았습니다\))?$", note)
            if m:
                return f"같은 내용의 새 파일 있음: {_short_path(m.group(1), path)}{m.group(2) or ''}"
            m = re.match(r"^(.+?)\(으\)로 (옮겨짐|옮겨지며 내용도 바뀜) — ", note)
            if m:
                return f"{_short_path(m.group(1), path)}(으)로 {m.group(2)}"
            m = re.match(r"^(.+?)에서 옮겨짐 — ", note)
            if m:
                return f"{_short_path(m.group(1), path)}에서 옮겨짐"
            return note.split(" — ", 1)[0].strip()
    return ""


def _kind_tag(path: str) -> str:
    """머리 꼬리표 — 문서 종류(설정 없는 기본 규칙). 모르면 확장자로. 영문 표기('Drawing')는 한국어 이름으로 (V3-11)."""
    from watcher.doctype import UNKNOWN, canonical, kind_of
    ext = PurePosixPath(path).suffix.lower()
    try:
        k = canonical(kind_of(path))
    except Exception:            # noqa: BLE001 — 요약이 분류 규칙 오류로 죽지 않게
        k = UNKNOWN
    if k and k != UNKNOWN:
        return k
    if ext in (".dxf", ".dwg", ".pdf"):
        return "도면"
    if ext in (".xlsx", ".xlsm"):
        return "표"
    if ext in (".docx", ".hwpx"):
        return "문서"
    return "파일"


def _subject(tag: str, path: str, project) -> str:
    stem = PurePosixPath(path).stem or PurePosixPath(path).name
    proj = str(project or "").strip()
    known = proj and proj != "미분류"
    if tag == "BOM" and known:
        return proj                                  # `[BOM] P24-031: MCCB-01 QTY 2 → 3`
    return f"{stem} ({proj})" if known else stem


_ORDER_ONLY = ("ROW_MOVED", "COL_MOVED", "PAGE_MOVED", "TEXT_MOVED")
_LOW_FIELDS = ("DATE", "파일 크기", "저장 시각")


def _weight(it) -> float:
    """요약 조각의 무게 — headline()과 같은 차례: 값·사양·표 행 값(0) > Rev·문서 안 그림 교체(1) > 글자 추가·삭제·그 밖 칸(2)
    > 그림 변경(2.5) > 순서·날짜·크기·저장 시각(3). 같은 무게는 저장 순서 그대로 (V1-6·V3-2: 행 이동·파일 크기·저장 시각·그림
    변경이 값 변경을 '외 N건'으로 밀어냈다)."""
    k = str(it.get("kind") or "")
    key = str(it.get("key") or "")
    if _rev_item(it):
        return 1
    if k in ("ROW_CHANGED", "ROW_ADDED", "ROW_REMOVED"):
        return 0
    if k == "TEXT_CHANGED":
        return 0 if any(ch.isdigit() for ch in f"{it.get('old') or ''}{it.get('new') or ''}") else 2
    if k == "CHECK_SKIPPED":
        return 0                                     # '내용 읽지 못함'만 조각이 된다
    if k == "EMBED_CHANGED":
        return 1
    if k == "PAGE_VISUAL_CHANGED":
        return 2.5
    if k in _ORDER_ONLY or (k == "FIELD_CHANGED" and key.split("#", 1)[0] in _LOW_FIELDS):
        return 3
    return 2


def body_parts(items, was: bool = False) -> tuple[list, int]:
    """(앞 조각 최대 3개, 나머지 수). 무게순(_weight), 같은 무게는 저장 순서대로. was: 조각을 '지금(이전 …)' 꼴로(고르기·세기는 같다)."""
    has_rev = any(_rev_item(it) for it in items)
    parts = []
    for it in items:
        p = _part(it, has_rev)
        if p:
            parts.append((_weight(it), p, _part(it, has_rev, was=True) if was else p))
    parts = [(p, pw) for _o, p, pw in sorted(parts, key=lambda x: x[0])]
    seen, uniq = set(), []
    for p, pw in parts:                              # 같은 조각 둘(같은 글줄 두 곳)은 한 번만 — 수는 그대로 센다
        if p not in seen:
            seen.add(p)
            uniq.append(pw)
    return uniq[:MAX_PARTS], max(0, len(parts) - min(len(uniq), MAX_PARTS))


def _body(items, path: str = "", was: bool = False) -> str:
    parts, rest = body_parts(items, was)
    if not parts:
        return _note_short(items, path)
    return ", ".join(parts) + (f" 외 {rest}건" if rest else "")


def item_pairs(items) -> list:
    """항목들이 한 줄 글에 남길 수 있는 화살표 조각과 그 '지금(이전 …)' 꼴 [(화살표 조각, 지금 꼴)] — 요약 조각(_part)·가장 무거운
    한 줄(headline)·Rev 확인 필요 머리(issue_line) 꼴 모두. 긴 것부터 (was_line이 저장 글에서 정확히 같은 조각만 바꾼다)."""
    out: dict = {}
    its = [d for d in (as_item_dict(it) for it in (items or ())) if d is not None]
    for it in its:
        for has_rev in (False, True):
            a, w = _part(it, has_rev), _part(it, has_rev, was=True)
            if a and w and a != w and "→" in a:
                out.setdefault(a, w)
        a, w = headline([it]), headline([it], was=True)
        if a and w and a != w and "→" in a:
            out.setdefault(a, w)
            lab = _s(it.get("label"))
            if lab and a.endswith(f" ({lab})"):           # 오늘 화면은 끝 이름표 괄호를 떼고 보인다
                out.setdefault(a[:-len(lab) - 3], w[:-len(lab) - 3] if w.endswith(f" ({lab})") else w)
    return sorted(out.items(), key=lambda kv: -len(kv[0]))


_PIECE_L = r"(?:^|(?<=: )|(?<=, )|(?<= — )|(?<=\] ))"
_PIECE_R = r"(?=$|, | 외 \d| — | \()"


def was_line(line, items=None) -> str:
    """저장된 한 줄 글(기록 요약·가장 무거운 한 줄·목차 조각)을 보일 때만 화살표 없이. items(그 변경의 항목)가 있으면 항목에서 만든
    화살표 조각과 **글자까지 같은 곳만** 그 '지금(이전 …)' 꼴로 바꾼다 — 글을 다시 쪼개 이전 값을 짐작하지 않는다(Y2 H1). 맞는 조각이
    없는 나머지(옛 꼴·항목 없는 기록)는 brief의 보수적 규칙(확실한 꼴만, 아니면 원문 그대로). 저장 글은 그대로."""
    s = str(line or "")
    if "→" not in s:
        return s
    pairs = item_pairs(items) if items else []
    segs: list = []                                   # [(글, 바꾼 조각인가)]
    if pairs:
        rx = re.compile(_PIECE_L + "(?:" + "|".join(re.escape(a) for a, _w in pairs) + ")" + _PIECE_R)
        table = dict(pairs)
        pos = 0
        for m in rx.finditer(s):
            if m.start() > pos:
                segs.append((s[pos:m.start()], False))
            segs.append((table[m.group(0)], True))
            pos = m.end()
        if pos < len(s):
            segs.append((s[pos:], False))
    else:
        segs = [(s, False)]
    from watcher.brief import _unarrow_summary_safe
    return "".join(t if done or "→" not in t else _unarrow_summary_safe(t) for t, done in segs)


# 검토 필요 → [확인 필요] 줄. 우선순위: 도면-BOM 불일치 > Rev 미갱신 > Rev만 갱신 > 그 밖
_ISSUE_ORDER = {"BOM_MISMATCH": 0, "CONTENT_CHANGED_REV_SAME": 1, "REV_CHANGED_CONTENT_SAME": 2}
_REV_SAME = re.compile(r"Rev가 (\S+) 그대로")
# 근거 줄 'BOM: Q-1 SPEC=MCCB 3P 50AF (30AT) (BOM!행9, 경로)' — 사양 끝은 **위치 괄호**('시트!행N, 경로') 앞이다. 첫 괄호에서 자르면
# 사양의 '(30AT)'가 잘려 'BOM MCCB 3P 50AF'로 거짓 값이 나갔다 (V1-3). 위치 꼴을 못 찾으면 마지막 괄호 앞까지
_BOM_EV = re.compile(r"^BOM:\s*(\S+)\s+SPEC=(.*?)\s\((?=[^()]*![^()]*,\s)")
_BOM_EV_ANY = re.compile(r"^BOM:\s*(\S+)\s+SPEC=(.*)\s\(")


def _content_count(items) -> int:
    from watcher.diff import CONTENT_KINDS, ORDER_KINDS
    return sum(1 for it in items if it.get("kind") in CONTENT_KINDS and it.get("kind") not in ORDER_KINDS)


def _mismatch_bits(message: str, evidence) -> tuple | None:
    """도면-BOM 불일치 근거 → (태그, 도면 값, BOM 값). 근거 줄의 글자 그대로만 — 못 읽으면 None."""
    tag = spec = dwg = None
    for ln in evidence or ():
        t = " ".join(str(ln).split())
        m = _BOM_EV.match(t) or _BOM_EV_ANY.match(t)
        if m and spec is None:
            tag, spec = m.group(1), m.group(2).strip()
            continue
        if dwg is None and t.startswith(("도면", "문서", "출도본")) and ": " in t:
            body = t.split(": ", 1)[1]
            ci = body.rfind(", ")
            pi = body.rfind(" (", 0, ci) if ci > 0 else -1
            dwg = (body[:pi] if pi > 0 else body).strip()
    if not (tag and spec and dwg):
        return None
    if dwg.startswith(tag + " "):
        dwg = dwg[len(tag):].strip()
    return tag, dwg, spec


CONFIRM = "[확인 필요] "
_TAG_IN_MSG = re.compile(r"\]\s*([^:\s\]]+):")


def issue_line(issue: dict, items, path: str, values: bool = True, was: bool = False) -> str:
    """검토 필요 하나 → '[확인 필요] …' 꼴의 머리(꼬리표 빼고). issue: {code, message, evidence(list), cited(기본 참)}.

    values: 검토 필요 문구·근거의 **값**을 실어도 되나 — 근거 줄은 이슈가 열려 있는 동안 최신 판 값으로 갱신된다. 그 변경을 기록하는
    순간(검사 직후)에만 참이고, 나중에 다시 만들 때(저장 요약이 없는 옛 행)는 거짓 — 값 없이 코드 이름표만 (V1-1: 합치기·숨김 뒤
    옛 변경 #3(5.5→7.5kW)에 'M-101: 도면 15kW'가 붙었다). 이 변경 자신의 항목에서 나온 값(Rev A → B)은 언제나 싣는다.
    cited 거짓: 근거에 인용되지 않았지만 같은 태그를 건드린 같은 검사의 다른 변경(V1-7) — 도면 값은 인용된 도면의 것이라 싣지 않고
    BOM 값만."""
    code = str(issue.get("code") or "")
    stem = PurePosixPath(path).stem or PurePosixPath(path).name
    if code == "BOM_MISMATCH":
        bits = _mismatch_bits(issue.get("message") or "", issue.get("evidence") or ())
        m = _TAG_IN_MSG.search(str(issue.get("message") or ""))
        tag = m.group(1) if m else (bits[0] if bits else "")
        if bits and values:
            btag, dwg, spec = bits
            if issue.get("cited", True):
                return f"{btag}: 도면 {_v(dwg)} / BOM {_v(spec)}"
            return f"{btag}: 도면-BOM 불일치 (BOM {_v(spec)})"
        from watcher.consistency import CODE_LABEL
        lab = CODE_LABEL.get(code, code)
        return f"{tag}: {lab}" if tag else lab
    if code == "CONTENT_CHANGED_REV_SAME":
        n = _content_count(items)
        m = _REV_SAME.search(str(issue.get("message") or "")) if values else None
        return (f"{stem}: 내용 {n}곳 변경, Rev 미갱신" if n else f"{stem}: 내용 변경, Rev 미갱신") + (f" ({m.group(1)})" if m else "")
    if code == "REV_CHANGED_CONTENT_SAME":
        rev = next((it for it in items if _rev_item(it)), None)
        if rev is not None and str(rev.get("old") or "").strip() not in _NO_REV:
            return f"{stem}: {_pair_text('Rev', _v(rev.get('old')), _v(rev.get('new')), was)}, 내용 변경 없음"
        return f"{stem}: Rev만 바뀜, 내용 변경 없음"
    from watcher.consistency import CODE_LABEL
    return f"{stem}: {CODE_LABEL.get(code, code)}"


def _sorted_issues(issues) -> list:
    return sorted((i for i in issues or () if isinstance(i, dict)),
                  key=lambda i: (_ISSUE_ORDER.get(str(i.get("code") or ""), 9), i.get("id") or 0))


def summarize(kind: str, path: str, project, items, issues=(), *, values: bool = True, head: str | None = None,
              n_hidden: int = 0) -> str:
    """변경 한 줄 요약. kind: added/modified/removed. items: 보여 줄 항목(dict). issues: 이 변경으로 열린 검토 필요(dict).

    values: issue_line 참고. head: 저장해 둔 '[확인 필요] …' 머리 — 주면 검토 필요 줄은 그 글 그대로 쓰고(근거 값이 기록 시점 것),
    issues는 꼴(무엇을 뒤에 붙이나)만 정한다. ''이면 저장 때 검토 필요가 없던 변경이다. n_hidden: 항목을 전부 숨겼으면 숨긴 수
    — 본문 자리에 '표시할 변경 없음'을 두고 [확인 필요] 머리는 남긴다 (V1-8)."""
    path = str(path or "")
    items = [it for it in (items or []) if isinstance(it, dict)]
    name = PurePosixPath(path).name or path
    body = _body(items, path) or (empty_note(n_hidden) if n_hidden and not items else "")
    tag = ""                     # 문서 종류는 필요할 때만 — 첫 등록 수만 건의 [추가]에 분류 규칙을 돌리지 않는다
    if kind == "removed":
        line = f"[삭제] {name}" + (f" — {body}" if body else "")
    elif kind == "added" and not body_parts(items)[0]:
        line = f"[추가] {name}" + (f" — {body}" if body else "")
    else:
        tag = _kind_tag(path)
        line = f"[{tag}] {_subject(tag, path, project)}: " + (body or "내용 변경 기록 없음")
    iss = _sorted_issues(issues)
    if head == "" or (head is None and not iss):
        return line
    if head is None:
        head = CONFIRM + issue_line(iss[0], items, path, values)
        if len(iss) > 1:
            head += f" 외 확인 필요 {len(iss) - 1}건"
    code0 = str(iss[0].get("code")) if iss else ""
    if code0 == "REV_CHANGED_CONTENT_SAME" and len(iss) == 1:
        return head                                  # 그 줄이 곧 이 변경의 내용이다 (바뀐 값이 Rev뿐)
    if code0 == "CONTENT_CHANGED_REV_SAME" and len(iss) == 1:
        # 무엇이 바뀌었는지(구값 → 신값)를 뒤에 — 링크형 메일·목록에서 요약만 봐도 근거가 있게 (원칙 4, R3 보고)
        if body_parts(items)[0]:
            return head + " — " + _body(items, path)
        return head + (" — " + body if n_hidden and body else "")
    # 무엇이 바뀌어 열렸는지 뒤에 그대로 — 꼬리표는 앞의 [확인 필요] 하나만
    # ([추가]·[삭제]는 그 말이 뜻이라 남긴다)
    tail = line[len(tag) + 3:] if tag and line.startswith(f"[{tag}] ") else line
    tail_subj, _sep, tail_body = tail.partition(": ") if tag else ("", "", "")
    if tail_body and tail_body in head:              # 'Rev A → B, 내용 변경 없음 외 … — E-106: Rev A → B' 같은 되풀이를 막는다
        return head
    head_subj = head[len(CONFIRM):].split(": ", 1)[0] if head.startswith(CONFIRM) else ""
    if tail_body and head_subj and (tail_subj == head_subj or tail_subj.startswith(head_subj + " (")):
        # 머리와 꼬리의 주어가 같으면 꼬리는 값만 — 'E-106: Rev가 거꾸로 감 — E-106 (P26-101): Rev A → B'처럼 이름이 두 번 (V2-6)
        return head + " — " + tail_body
    return head + " — " + tail


def stored_head(line: str, kind: str, path: str, project, items, issues=()) -> str | None:
    """저장해 둔 요약에서 '[확인 필요] …' 머리만 — 검토 필요가 없던 줄이면 None.
    저장 때와 같은 재료(그때의 항목 전부·그때의 프로젝트)로 꼬리를 붙여 보아 저장 줄과 똑같아지는 머리를 고른다(값 안에 ' — '가 있어도
    맞게). 맞는 것이 없으면(그 뒤 요약 규칙이 바뀐 옛 줄) 첫 ' — ' 앞."""
    s = str(line or "")
    if not s.startswith(CONFIRM):
        return None
    cuts = [m.start() for m in re.finditer(" — ", s)]
    for c in cuts + [len(s)]:
        h = s[:c]
        try:
            if summarize(kind, path, project, items, issues, head=h) == s:
                return h
        except Exception:        # noqa: BLE001 — 머리 고르기가 화면을 죽이지 않게
            break
    return s[:cuts[0]] if cuts else s


def empty_note(n_hidden: int) -> str:
    return f"표시할 변경 없음 (잘못 잡힘으로 숨긴 항목 {n_hidden}건)"
