# -*- coding: utf-8 -*-
"""내용 추출·페이지 그림을 **자식 프로세스**에서 돌린다 — 시간 상한을 강제하기 위해 (2026-09-05).

같은 프로세스 안에서 파일을 열면 PDF·DXF 하나가 라이브러리 안에서 멈출 때 그날 검사 전체가
멈춘다(회사 PC에서 두 번 겪음). 독 파일 표식(`extract_in_progress`)은 *다음* 검사부터
건너뛰는 장치라 첫날은 잃는다. 여기서는 파일마다 상한(기본 300초)을 두고, 넘으면 자식을
통째로 끝내고 새로 띄운다. 파일마다 프로세스를 새로 만들지 않고(임포트 비용) 하나를 오래 쓴다.

프로토콜: stdin 한 줄 JSON 요청 → stdout 한 줄 JSON 응답.
  {"op": "extract", "path": "..."}            → {"ok": true, "doc": {...}|null}
  {"op": "render", "path": "...", "kind": "file"|"dxf"} → {"ok": true, "pages": [...]}
  {"op": "ping"}                                → {"ok": true}
  실패 → {"ok": false, "error": "...", "error_type": "BadZipFile"}
자식은 감시 대상 파일을 **읽기만** 한다(추출기·렌더러가 엄격 모듈). 이 모듈도 자기 stdout에
print만 한다 — 파일을 쓰지 않는다.
"""

from __future__ import annotations

import base64
import collections
import json
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path

EXTRACT_TIMEOUT = 300          # 초 — config `extract_timeout`으로 조정
_NO_WINDOW = 0x08000000        # CREATE_NO_WINDOW


class ExtractTimeout(Exception):
    """파일 하나가 상한을 넘겨 자식을 끝냈다."""


class RemoteError(Exception):
    """자식 안에서 난 예외. error_type에 원래 예외 이름을 남긴다 (OSError면 캐시하지 않기 위해)."""

    def __init__(self, message: str, error_type: str = ""):
        super().__init__(message)
        self.error_type = error_type

    @property
    def transient(self) -> bool:
        return self.error_type in ("OSError", "PermissionError", "FileNotFoundError",
                                   "IsADirectoryError", "TimeoutError", "BlockingIOError")


# ───────────────────────────── 자식 쪽

def _handle(req: dict) -> dict:
    op = req.get("op")
    if op == "ping":
        return {"ok": True}
    if op == "config":                      # 설정값 전달 (표의 키 열, OCR 사용 여부)
        from watcher.extract import pdf as _pdf
        from watcher.extract import xlsx as _x
        _x.USER_KEY_COLS = tuple(str(c) for c in (req.get("key_cols") or []) if str(c).strip())
        _pdf.OCR_ENABLED = bool(req.get("ocr", True))
        return {"ok": True}
    if op == "sleep":                       # 시험용 — 멈춘 파일 흉내
        import time
        time.sleep(float(req.get("seconds", 1)))
        return {"ok": True}
    path = Path(req.get("path", ""))
    if op == "extract":
        from watcher.extract import extract
        doc = extract(path)
        return {"ok": True, "doc": doc.to_dict() if doc is not None else None}
    if op == "render":
        from watcher.render import render_dxf, render_file
        pages = render_dxf(path) if req.get("kind") == "dxf" else render_file(path)
        return {"ok": True, "pages": [
            {"width_pt": p.width_pt, "height_pt": p.height_pt, "meta": p.meta,
             "png": base64.b64encode(p.png).decode("ascii")} for p in pages]}
    return {"ok": False, "error": f"모르는 요청: {op}", "error_type": "ValueError"}


def serve() -> int:
    """`drev extract-worker` — 부모가 끝나면(stdin EOF) 같이 끝난다."""
    # PyInstaller exe는 PYTHONUTF8/PYTHONIOENCODING을 반영하지 않아 파이프가 cp949로 열린다 —
    # 한글 경로는 못 찾고 한글 내용은 깨졌다 (리뷰10 차단). 환경과 무관하게 UTF-8로 고정한다.
    # 깨진 인코딩(서로게이트)이 오류 문구에 실려도 죽지 않게 errors=replace
    for s in (sys.stdin, sys.stdout, sys.stderr):
        try:
            if s is not None:
                s.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            resp = _handle(req)
        except Exception as e:  # 어떤 파일이 어떻게 깨졌든 자식은 살아서 다음 파일을 받는다
            resp = {"ok": False, "error": str(e)[:2000], "error_type": type(e).__name__}
        try:
            print(json.dumps(resp, ensure_ascii=False), file=out, flush=True)
        except (ValueError, TypeError, UnicodeEncodeError) as e:
            print(json.dumps({"ok": False, "error": f"응답 직렬화 실패: {e}",
                              "error_type": type(e).__name__}), file=out, flush=True)
    return 0


# ───────────────────────────── 부모 쪽

def worker_command() -> list[str]:
    """자식을 띄우는 명령 — 자동 실행 배치(_daily_bat_text)와 같은 판단."""
    exe = Path(sys.executable)
    if getattr(sys, "frozen", False):
        return [str(exe), "extract-worker"]
    if exe.name.lower().startswith("drev"):
        root = exe.parent                    # 포터블·설치판: 루트의 pythonw 사본
        py = root / "python" / "python.exe"
        entry = root / "app" / "entry.py"
        if py.is_file() and entry.is_file():
            return [str(py), str(entry), "extract-worker"]
    return [str(exe), "-m", "watcher.cli", "extract-worker"]


def _attach_job(proc):
    """부모가 갑자기 죽어도(강제 종료·os._exit) 자식이 멈춘 파일을 붙든 채 남지 않게 —
    Windows Job Object에 넣고 KILL_ON_JOB_CLOSE (리뷰10 중간-2). 못 만들면 None (동작은 그대로)."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        k32.CreateJobObjectW.restype = wintypes.HANDLE
        k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        k32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        k32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        k32.CloseHandle.argtypes = [wintypes.HANDLE]

        class _IoCounters(ctypes.Structure):
            _fields_ = [(n, ctypes.c_ulonglong) for n in
                        ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                         "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

        class _BasicLimit(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong),
                        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD),
                        ("SchedulingClass", wintypes.DWORD)]

        class _ExtLimit(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", _BasicLimit), ("IoInfo", _IoCounters),
                        ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                        ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

        job = k32.CreateJobObjectW(None, None)
        if not job:
            return None
        info = _ExtLimit()
        info.BasicLimitInformation.LimitFlags = 0x2000          # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not k32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)) \
                or not k32.AssignProcessToJobObject(job, wintypes.HANDLE(int(proc._handle))):
            k32.CloseHandle(job)
            return None
        return job
    except Exception:
        return None


def _close_job(job) -> None:
    if job:
        try:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(job)
        except Exception:
            pass


class ExtractWorker:
    """자식 하나를 오래 쓰는 클라이언트. 상한을 넘기면 죽이고 다음 요청에서 다시 띄운다.
    cancel: 참을 돌려주면 기다리던 요청을 끊고 자식을 죽인다 ([검사 중지]가 상한까지 안 먹던 것, 리뷰10 중간-3)."""

    def __init__(self, timeout: float = EXTRACT_TIMEOUT, command: list[str] | None = None,
                 cancel=None):
        self.timeout = float(timeout)
        self.command = command or worker_command()
        self.cancel = cancel
        self.proc: subprocess.Popen | None = None
        self._q: queue.Queue | None = None
        self._job = None
        self._spawned = False
        self._err_tail: collections.deque = collections.deque(maxlen=40)
        self._cfg_req: dict | None = None
        self.restarts = 0
        self.timeouts = 0

    # ── 수명
    def _spawn(self) -> None:
        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        repo = Path(__file__).resolve().parent.parent
        if not getattr(sys, "frozen", False):
            env["PYTHONPATH"] = str(repo) + os.pathsep + env.get("PYTHONPATH", "")
        self.proc = subprocess.Popen(
            self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
            bufsize=1, env=env,
            creationflags=_NO_WINDOW if sys.platform == "win32" else 0)
        if self._spawned:
            self.restarts += 1               # 두 번째 띄움부터 '다시 띄움' (리뷰10 낮음-9: 늘 0이던 것)
        self._spawned = True
        self._job = _attach_job(self.proc)
        q: queue.Queue = queue.Queue()
        proc = self.proc
        tail = self._err_tail
        tail.clear()

        def _pump():
            try:
                for ln in proc.stdout:
                    q.put(ln)
            except (ValueError, OSError):
                pass
            q.put(None)                      # EOF

        def _pump_err():                     # 자식이 못 뜬 이유(ImportError 등)의 마지막 몇 줄 (리뷰10 낮음-10)
            try:
                for ln in proc.stderr:
                    tail.append(ln.rstrip()[:300])
            except (ValueError, OSError):
                pass

        threading.Thread(target=_pump, daemon=True, name="drev-worker-reader").start()
        threading.Thread(target=_pump_err, daemon=True, name="drev-worker-stderr").start()
        self._q = q

    def _ensure(self) -> None:
        if self.proc is None or self.proc.poll() is not None:
            self._spawn()
            if self._cfg_req is not None:
                # 상한 초과로 다시 띄운 자식은 기본값(OCR 켬·키 열 없음)으로 돌아간다 — 설정을 다시 보낸다
                # (리뷰12 운영 중간-2: 재기동 뒤 끈 OCR이 다시 켜지고 엑셀 키 열이 사라짐)
                try:
                    resp = self._raw_request(self._cfg_req, timeout=60)
                except Exception:
                    resp = {}
                if not resp.get("ok"):
                    self.kill()                  # 설정 없는 자식으로 읽으면 안 된다 — 다음 요청이 다시 띄운다
                    raise RemoteError("다시 띄운 추출 프로세스에 설정을 전하지 못함", "ConfigLost")

    def last_error_lines(self) -> str:
        return " | ".join(list(self._err_tail)[-3:])

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def kill(self) -> None:
        p = self.proc
        self.proc = None
        job, self._job = self._job, None
        if p is None or p.poll() is not None:
            _close_job(job)
            return
        try:
            from watcher.convert import _kill_tree
            _kill_tree(p.pid)
        except Exception:
            pass
        try:
            p.kill()
        except OSError:
            pass
        try:
            p.wait(timeout=10)
        except Exception:
            pass
        _close_job(job)                      # KILL_ON_JOB_CLOSE — 손자까지 확실히

    def close(self) -> None:
        p = self.proc
        if p is not None and p.poll() is None:
            try:
                p.stdin.close()              # EOF → 자식이 스스로 끝난다
                p.wait(timeout=5)
            except Exception:
                self.kill()
        self.proc = None
        job, self._job = self._job, None
        _close_job(job)

    # ── 요청
    def request(self, req: dict, timeout: float | None = None) -> dict:
        self._ensure()
        return self._raw_request(req, timeout)

    def _raw_request(self, req: dict, timeout: float | None = None) -> dict:
        assert self.proc is not None and self._q is not None
        try:
            print(json.dumps(req, ensure_ascii=False), file=self.proc.stdin, flush=True)
        except (OSError, ValueError) as e:
            self.kill()
            raise RemoteError(f"추출 프로세스에 보내지 못함: {e}", "BrokenPipe")
        limit = float(timeout if timeout is not None else self.timeout)
        deadline = time.monotonic() + limit
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self.timeouts += 1
                self.kill()
                raise ExtractTimeout(f"{int(limit)}초 안에 끝나지 않아 중단")
            try:
                line = self._q.get(timeout=min(1.0, remaining))
                break
            except queue.Empty:
                if self.cancel is not None and self.cancel():
                    self.kill()
                    raise RemoteError("검사 중지 요청으로 추출을 끊음", "Cancelled")
        if line is None:
            tail = self.last_error_lines()
            self.kill()
            raise RemoteError("추출 프로세스가 도중에 끝남 (메모리 부족이나 라이브러리 충돌일 수 있음)"
                              + (f" — 마지막 출력: {tail[:400]}" if tail else ""), "WorkerDied")
        try:
            resp = json.loads(line)
        except ValueError:
            self.kill()
            raise RemoteError(f"추출 프로세스 응답을 읽지 못함: {line[:120]!r}", "BadResponse")
        if not resp.get("ok"):
            raise RemoteError(str(resp.get("error", "")), str(resp.get("error_type", "")))
        return resp

    def configure(self, key_cols, ocr: bool = True) -> bool:
        self._cfg_req = {"op": "config", "key_cols": list(key_cols or []), "ocr": bool(ocr)}
        try:
            return bool(self.request(dict(self._cfg_req), timeout=60).get("ok"))
        except Exception:
            return False

    def ping(self, timeout: float = 60.0) -> bool:
        try:
            return bool(self.request({"op": "ping"}, timeout=timeout).get("ok"))
        except Exception:
            return False

    def extract(self, path):
        from watcher.extract.base import Document
        d = self.request({"op": "extract", "path": str(path)}).get("doc")
        return Document.from_dict(d) if d is not None else None

    def render(self, path, kind: str = "file") -> list:
        from watcher.render import PageRender
        pages = self.request({"op": "render", "path": str(path), "kind": kind}).get("pages") or []
        return [PageRender(float(p["width_pt"]), float(p["height_pt"]),
                           base64.b64decode(p["png"]), p.get("meta") or {}) for p in pages]

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
