# -*- coding: utf-8 -*-
"""의견·담당 — 감시 화면(web.py)과 사내망(forms/collab.py)이 같이 쓰는 글·모양 (2026-11-23 사내망 협업 다듬기, DECISIONS 같은 날).

- 의견은 사람 글이라 근거(이전 / 지금 / 위치)와 겉모습으로 구별한다(원칙 4): 근거 표·[이전]/[지금] 두 줄을 쓰지 않고,
  쓴 사람·때 머리 + 본문(여러 줄)을 왼쪽 선 있는 말 칸으로. 확인([확인함])과는 다른 동작 — 의견을 달아도 확인되지 않는다.
- 같은 사실은 화면마다 같은 수: 목록의 '의견 N'·상세의 '의견 N건'은 State.comment_counts / comments_of 하나.
- 이 모듈은 읽거나 쓰지 않는다(글·HTML만). 값은 부르는 쪽이 State에서 읽어 넘긴다.
"""

from __future__ import annotations

import html
from datetime import datetime

from watcher.state import COMMENT_MAX, ack_origin, person_label

E = html.escape

LEAD = ("사람이 남긴 글입니다. 근거·[확인함]과는 따로입니다. "
        "고치거나 지울 수 없습니다. 잘못 썼으면 '정정' 의견을 새로 남기세요.")
NONE_TEXT = "아직 의견이 없습니다."
PLACEHOLDER = "예: 협력사에 새 판 보냄 — 다음 납품분부터 적용"

# 감시 화면·사내망 같은 모양 (ds 색 변수 — 두 서버가 같은 이름을 쓴다). 인라인 style 없음(사내망 CSP)
CSS = """
/* ── 의견·담당 (2026-11-23 사내망 협업) — 사람 글은 근거 표와 다른 꼴: 왼쪽 선 말 칸 ── */
ol.ds-cm-list{list-style:none;margin:0 0 14px;padding:0;display:grid;gap:10px}
li.ds-cm-i{border-left:3px solid var(--ds-border2);background:var(--ds-surface2);border-radius:0 8px 8px 0;padding:9px 14px}
li.ds-cm-i.ds-cm-res{border-left-color:var(--ds-green-line)}
.ds-cm-who{display:flex;flex-wrap:wrap;gap:4px 10px;align-items:baseline;font-size:14px;color:var(--ds-muted)}
.ds-cm-who b{color:var(--ds-text);font-size:14.5px}
.ds-cm-body{font-size:15.5px;line-height:1.55;color:var(--ds-text);margin-top:3px;overflow-wrap:anywhere}
.ds-cm-none{margin:0 0 12px}
textarea.ds-cm-ta{min-height:76px;resize:vertical;line-height:1.5}
.ds-cm-form .ds-btns{display:flex;gap:8px;flex-wrap:wrap}
.ds-cm-n{display:inline-block;font-size:13px;font-weight:700;color:var(--ds-muted);white-space:nowrap}
.ds-as-n{display:inline-block;font-size:13px;color:var(--ds-muted);white-space:nowrap}
.ds-as-log{margin-top:8px}
.ds-as-log summary{cursor:pointer;font-size:14px;color:var(--ds-primary-ink);font-weight:700}
.ds-as-form select{width:100%;margin-bottom:8px}
"""


def when(iso) -> str:
    """UTC ISO → 이 PC 시각 '11월 23일 14:02'(올해가 아니면 연도) — 감시 화면 _ds_when_iso와 같은 꼴."""
    if not iso:
        return ""
    try:
        d = datetime.fromisoformat(str(iso))
        if d.tzinfo is None:                         # 저장 시각은 UTC ISO — 꼬리가 없으면 UTC로 본다(감시 화면 _parse_utc와 같다)
            d = datetime.fromisoformat(str(iso) + "+00:00")
        d = d.astimezone()
    except (TypeError, ValueError, OverflowError, OSError):
        return ""
    t = f"{d.month}월 {d.day}일 {d:%H:%M}"
    return t if d.year == datetime.now().year else f"{d.year}년 {t}"


def body_html(body) -> str:
    """본문 여러 줄 — 줄마다 이스케이프하고 <br>로 잇는다."""
    return "<br>".join(E(x) for x in str(body or "").split("\n"))


def items_html(cms) -> str:
    """의견 목록 (오래된 것부터) — 쓴 사람 · 때 · (처리 메모) / 본문."""
    lis = "".join(
        f'<li class="ds-cm-i{" ds-cm-res" if c.get("kind") == "resolve" else ""}" id="cm-{int(c["id"])}">'
        f'<div class="ds-cm-who"><b>{E(person_label(c.get("by")))}</b><span>{E(when(c.get("at")))}</span>'
        + ('<span class="ds-tg green">처리 메모</span>' if c.get("kind") == "resolve" else "")
        + f'</div><div class="ds-cm-body">{body_html(c.get("body"))}</div></li>' for c in cms or ())
    return f'<ol class="ds-cm-list">{lis}</ol>' if lis else ""


def card(cms, form_html: str = "", *, extra: str = "", lead: bool = True) -> str:
    """'의견' 카드 — 감시 화면·사내망 변경 상세·사내망 확인 필요 하나 보기가 같은 꼴(제목 '의견', 수 'N건')."""
    n = len(cms or ())
    return (f'<section class="ds-card ds-cm" id="cm" aria-labelledby="cm-h"><div class="ds-card-h"><h2 id="cm-h">의견</h2>'
            f'<span class="ds-s">{n}건</span></div><div class="ds-card-b">'
            + (items_html(cms) if n else f'<p class="ds-sm ds-cm-none">{NONE_TEXT}</p>')
            + form_html + extra
            + (f'<p class="ds-sm">{E(LEAD)}</p>' if lead else "") + '</div></section>')


def textarea(field_id: str = "cm-body") -> str:
    return (f'<label class="ds-lbl" for="{field_id}">의견</label>'
            f'<textarea class="ds-inp ds-cm-ta" id="{field_id}" name="body" rows="3" maxlength="{COMMENT_MAX}" required '
            f'placeholder="{E(PLACEHOLDER)}"></textarea>')


def count_mark(n) -> str:
    """목록의 작은 표시 '의견 N' (0이면 빈 글)."""
    n = int(n or 0)
    return f'<span class="ds-cm-n" title="사람이 남긴 의견 {n}건">의견 {n}</span>' if n > 0 else ""


def assignee_name(a) -> str:
    """지금 담당 → 보일 이름 '김철수' (담당 없음이면 '')."""
    if not a or not a.get("assignee"):
        return ""
    return ack_origin(a["assignee"])[0]


def assignee_mark(a) -> str:
    """목록의 작은 표시 '담당 김철수' (없으면 빈 글)."""
    nm = assignee_name(a)
    return f'<span class="ds-as-n" title="사내망에서 정한 담당자">담당 {E(nm)}</span>' if nm else ""


def assignee_text(a) -> str:
    """파일 정보·상세의 '담당' 값 — '김철수 · 11월 23일 관리자 지정'."""
    nm = assignee_name(a)
    if not nm:
        return ""
    by = person_label(a.get("by"))
    w = when(a.get("at"))
    return nm + (f" · {w} {by} 지정" if (w or by) else "")


def log_html(log) -> str:
    """담당 기록(바뀐 차례) — 접힌 목록. 두 줄 이상일 때만."""
    if not log or len(log) < 2:
        return ""
    lis = "".join(
        f'<li><span>{E(ack_origin(x["assignee"])[0]) if x.get("assignee") else "담당 해제"}</span>'
        f'<span class="ds-m">{E(when(x.get("at")))} · {E(person_label(x.get("by")))}</span></li>' for x in reversed(log))
    return (f'<details class="ds-as-log"><summary>담당 기록 {len(log)}건</summary>'
            f'<ul class="ds-list">{lis}</ul></details>')
