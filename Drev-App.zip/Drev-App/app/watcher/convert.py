# -*- coding: utf-8 -*-
"""DWG → DXF 변환 — 감시 PC에 설치된 CAD·변환 프로그램을 빌려 쓴다.

Drev는 DWG(오토데스크 비공개 바이너리)를 직접 읽지 못한다. 대신 PC에 설치된
프로그램을 찾아 자기 임시 폴더에서 DXF로 바꾸고, 그 DXF로 글자·표제란·그림 비교를
한다. 어느 회사의 어떤 CAD든 통하도록 세 갈래:
  ① ODA File Converter — 비회원은 비상업용만(회사 사용은 ODA 회원 필요). CADian·ZWCAD·GstarCAD 등 ODA 계열 CAD로 만든 DWG는
     물론 오토캐드 DWG도 읽는다. 라이선스 자리를 쓰지 않는다 (기본 권장)
  ② AutoCAD의 accoreconsole — 창 없이 스크립트로 저장 (오토캐드가 있는 PC)
  ③ 사용자가 적는 명령 한 줄 ({in}=DWG 복사본, {out}=만들 DXF)

원본은 읽기만 한다 — DWG를 임시 폴더로 복사한 뒤 복사본을 변환한다 (CAD가 도면을
열 때 옆에 만드는 잠금 파일 .dwl이 서버에 생기지 않게). 임시 폴더는 with 블록이
끝나면 통째로 정리된다. 회사 밖으로 나가는 것은 없다 (원칙 1·2).
accoreconsole 스크립트는 오토캐드 문서 기준으로 작성했고 실제 오토캐드로는 아직
검증하지 못했다 (2026-09-03) — 첫 고객 PC에서 확인이 필요하다.
"""
from __future__ import annotations

import contextlib
import glob
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ODA_URL = "https://www.opendesign.com/guestfiles/oda_file_converter"
TIMEOUT = 180                 # 외부 프로그램은 반드시 시간 상한 (도면 하나 기준)
BATCH_MAX = 100               # 한 번의 CAD·ODA 실행에 맡기는 최대 장수
SCAN_MAX = 500                # 검사 한 번에 변환하는 최대 장수 — 나머지는 다음 검사로
SCAN_SECONDS = 3600           # 검사 한 번의 변환 총 시간 상한
STALL_SECONDS = 180           # 결과 파일이 이만큼 안 나오면 대화상자에서 멈춘 것으로 본다


class ConvertCancelled(RuntimeError):
    """사람이 [검사 중지]를 눌러 변환을 끊은 것 — CAD 묶음이 끝나길 기다리지 않는다."""


class ConvertStalled(RuntimeError):
    """CAD가 대화상자(SHX 글꼴 누락 등)에서 답을 기다리며 멈춘 것 — 사람이 한 번 답해 둬야
    한다 (2026-09-04 회사 PC: 'SHX 파일 누락' 창에서 30분을 기다렸다 강제 종료되는 것이
    '멈춘 것처럼 보이고 CAD가 켰다 꺼졌다'로 보였다)."""


STALL_HINT = ("CAD가 대화상자에서 멈춘 것 같습니다({sec}초 동안 결과 파일 없음). 오토캐드 계열의 "
              "'SHX 파일 누락' 창이면 CAD를 직접 열어 [누락된 SHX 파일을 무시하고 계속]을 고르고 "
              "'현재 선택한 내용을 항상 수행'에 체크해 두세요 — 그다음부터 창이 뜨지 않습니다. "
              "대화상자가 없는 ODA File Converter는 회사에서 쓰려면 ODA 회원이어야 합니다")
_NO_WINDOW = 0x08000000       # CREATE_NO_WINDOW — 검사 중 콘솔 창이 번쩍이지 않게
OFF_WORDS = ("off", "none", "없음", "사용안함", "사용 안 함")


def _program_dirs() -> list[Path]:
    out: list[Path] = []
    for key in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
        v = os.environ.get(key)
        if v and Path(v) not in out:
            out.append(Path(v))
    return out


# 오토캐드 계열(스크립트 /b 로 SAVEAS 가능)로 알려진 실행 파일 이름 — 기본 앱이 이것이면
# 스크립트 변환을 시도한다. 확실치 않은 것도 [DWG 변환 시험]이 결과를 바로 알려준다
_CAD_EXES = {"acad.exe", "acadlt.exe", "icad.exe", "cadian.exe", "zwcad.exe", "gcad.exe",
             "bricscad.exe", "progecad.exe", "nanocad.exe", "draftsight.exe"}


def _default_app_exe() -> Path | None:
    """Windows가 .dwg에 지정한 기본 앱의 실행 파일 (레지스트리). 없으면 None.
    사용자 선택(UserChoice) > 확장자 기본 ProgId > OpenWithProgids 순으로 본다
    (2026-09-03: "해당 확장자의 기본 어플이 다 지정되어 있을 텐데")."""
    if sys.platform != "win32":
        return None
    import re as _re
    import winreg
    progids: list[str] = []
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.dwg\UserChoice") as k:
            progids.append(winreg.QueryValueEx(k, "ProgId")[0])
    except OSError:
        pass
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, ".dwg") as k:
            v = winreg.QueryValue(k, None)
            if v:
                progids.append(v)
    except OSError:
        pass
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r".dwg\OpenWithProgids") as k:
            i = 0
            while True:
                try:
                    progids.append(winreg.EnumValue(k, i)[0])
                    i += 1
                except OSError:
                    break
    except OSError:
        pass
    for pid in progids:
        if not pid:
            continue
        for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_CLASSES_ROOT):
            try:
                sub = ("Software\\Classes\\" if root == winreg.HKEY_CURRENT_USER else "") + pid + "\\shell\\open\\command"
                with winreg.OpenKey(root, sub) as k:
                    cmd = winreg.QueryValue(k, None) or ""
            except OSError:
                continue
            m = _re.match(r'\s*"([^"]+\.exe)"|\s*(.+?\.exe)(?=\s|$)', cmd, _re.IGNORECASE)
            if m:
                exe = Path(m.group(1) or m.group(2))
                if exe.is_file():
                    return exe
    return None


def _from_default_app(exe: Path) -> dict | None:
    """기본 앱 → 변환기. 오토캐드면 옆의 accoreconsole(창 없음), 그 밖의 CAD는 스크립트."""
    low = exe.name.lower()
    if low in ("acad.exe", "acadlt.exe"):
        core = exe.with_name("accoreconsole.exe")
        if core.is_file():
            return {"kind": "accoreconsole", "exe": str(core), "name": exe.parent.name}
    if low in _CAD_EXES:
        return {"kind": "cadscript", "exe": str(exe),
                "name": f"기본 앱 {exe.parent.name} ({exe.name})"}
    return None


def detect() -> dict | None:
    """설치된 변환 프로그램 자동 탐지 → {'kind', 'exe', 'name'} 또는 None.
    ODA File Converter(라이선스 자리 안 씀) > 오토캐드 accoreconsole > Windows .dwg 기본 앱."""
    oda, acad = [], []
    for pf in _program_dirs():
        oda += glob.glob(str(pf / "ODA" / "*" / "ODAFileConverter.exe"))
        acad += glob.glob(str(pf / "Autodesk" / "AutoCAD *" / "accoreconsole.exe"))
    if oda:
        exe = sorted(oda, key=lambda e: Path(e).parent.name)[-1]
        return {"kind": "oda", "exe": exe, "name": Path(exe).parent.name}
    if acad:
        exe = sorted(acad, key=lambda e: Path(e).parent.name)[-1]
        return {"kind": "accoreconsole", "exe": exe, "name": Path(exe).parent.name}
    try:
        app = _default_app_exe()
    except Exception:
        app = None
    return _from_default_app(app) if app else None


def _setting(cfg: dict | None) -> str:
    """dwg_converter 설정값을 문자열로. YAML은 따옴표 없는 off/no를 불리언으로 읽는다."""
    raw = (cfg or {}).get("dwg_converter")
    if raw is False:
        return "off"
    if raw is None or raw is True:
        return ""
    return str(raw).strip()


def resolve(cfg: dict | None) -> dict | None:
    """설정값 dwg_converter → 변환기. 비움/auto = 자동 탐지, off = 안 씀,
    exe 경로(ODAFileConverter.exe / accoreconsole.exe), 또는 {in} {out} 명령."""
    v = _setting(cfg)
    if not v or v.lower() == "auto":
        return detect()
    if v.lower() in OFF_WORDS:
        return None
    if "{in}" in v and "{out}" in v:
        return {"kind": "custom", "exe": v, "name": "직접 지정한 명령"}
    p = Path(v)
    if not p.is_file():
        return None
    low = p.name.lower()
    if low == "odafileconverter.exe":
        return {"kind": "oda", "exe": str(p), "name": p.parent.name}
    if low == "accoreconsole.exe":
        return {"kind": "accoreconsole", "exe": str(p), "name": p.parent.name}
    got = _from_default_app(p)             # 직접 지정한 CAD 실행 파일(acad.exe, cadian.exe …)
    if got:
        return got
    return {"kind": "cadscript", "exe": str(p), "name": f"{p.parent.name} ({p.name})"}


def status(cfg: dict | None) -> tuple[bool, str]:
    """설정 화면용 한 줄: (사용 가능?, 설명)."""
    conv = resolve(cfg)
    if conv is not None:
        where = conv["exe"] if conv["kind"] != "custom" else "명령: " + conv["exe"]
        how = {"oda": "폴더째 변환, 창 최소화", "accoreconsole": "창 없음",
               "cadscript": "스크립트 방식 — CAD 창이 최소화로 잠깐 뜸, [DWG 변환 시험]으로 확인",
               "custom": "직접 지정한 명령"}.get(conv["kind"], "")
        return True, f"{conv['name']} — {where}" + (f" ({how})" if how else "")
    v = _setting(cfg)
    if v.lower() in OFF_WORDS:
        return False, "사용 안 함 (설정) — DWG는 미리보기 그림과 변경 사실만"
    if v and v.lower() != "auto":
        return False, f"지정한 프로그램을 찾을 수 없습니다: {v}"
    return False, ("변환 프로그램 없음 — DWG는 미리보기 그림(저해상도)과 변경 사실만 "
                   "봅니다. ODA File Converter(회사 사용은 ODA 회원 필요)나 오토캐드가 있으면 글자·그림 비교까지 됩니다")


def _batch_timeout(n: int) -> int:
    """한 번의 실행에 n장을 맡길 때의 시간 상한 — 장당 20초 + 여유 60초, 최대 30분."""
    return min(1800, 60 + 20 * max(1, n))


def _progress_mark(watch: Path | None):
    """진행 지표 — 결과 폴더의 (0바이트 아닌 파일 수, 가장 최근 수정 시각)."""
    if watch is None:
        return None
    try:
        n, latest = 0, 0.0
        with os.scandir(watch) as it:
            for e in it:
                try:
                    st = e.stat()
                except OSError:
                    continue
                if st.st_size > 0:
                    n += 1
                    latest = max(latest, st.st_mtime)
        return (n, latest)
    except OSError:
        return None


def _run(cmd, cwd: Path, shell: bool = False, timeout: int | None = None,
         minimized: bool = False, watch: Path | None = None,
         stall: int | None = None, cancel=None,
         dialogs: bool = False) -> subprocess.CompletedProcess:
    """외부 프로그램 실행. minimized: 창을 띄우는 프로그램(CAD·ODA)은 최소화된 채 시작해
    작업 중인 화면을 가리지 않게 (2026-09-03: "캐드가 혼자 켜졌다 꺼졌다").
    watch: 결과 폴더 — 여기에 새 파일이 stall초 동안 안 생기면 대화상자에서 멈춘 것으로
    보고 바로 끝낸다(ConvertStalled). 시간이 아니라 진행 지표로 판정한다."""
    flags = _NO_WINDOW if sys.platform == "win32" else 0
    kw: dict = {}
    if minimized and sys.platform == "win32":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7                  # SW_SHOWMINNOACTIVE — 최소화, 포커스 안 뺏음
        kw["startupinfo"] = si
        flags = 0
    if isinstance(cmd, str):
        # 사용자 명령 한 줄 — shell 없이 쪼개서 실행. shell=True면 타임아웃 때 cmd.exe만
        # 죽고 손자(변환기)가 파이프를 쥔 채 남아 검사가 매달렸다 (2026-09-03 재검토)
        import shlex
        cmd = shlex.split(cmd, posix=False)
        cmd = [x[1:-1] if len(x) >= 2 and x[0] == x[-1] == '"' else x for x in cmd]
    proc = subprocess.Popen(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            creationflags=flags, **kw)
    limit = timeout or TIMEOUT
    # 몇 장짜리 묶음은 시간 상한(60+20n)이 180초보다 짧아 멈춤 판정·SHX 안내·백오프가 전혀
    # 안 나왔다 (재검토 ⑤) — 멈춤 판정을 상한보다 먼저 두되 최소 20초
    stall = min(stall or STALL_SECONDS, max(limit - 5, 20))
    started = time.monotonic()
    last_progress = started
    mark = _progress_mark(watch)
    # CAD가 띄우는 대화상자(글꼴 누락 등)에 대신 답한다 — 사람 없이 끝까지 가게 (2026-09-05)
    dw = None
    if dialogs:
        from watcher.dialogs import DialogWatcher
        dw = DialogWatcher(proc.pid).start()

    def _finish():
        if dw is not None:
            dw.stop()
            DIALOG_LOG.extend(dw.answered)
            UNKNOWN_DIALOGS.extend(dw.unknown)

    def _stop(exc):
        _kill_tree(proc.pid)
        try:
            proc.communicate(timeout=10)
        except Exception:
            pass
        _finish()
        if isinstance(exc, ConvertStalled) and dw is not None and dw.unknown:
            title, btns = dw.unknown[-1]
            exc = ConvertStalled(f"{exc} — 멈춘 대화상자: '{title}' (버튼: {', '.join(btns) or '없음'})")
        raise exc

    polling = watch is not None or cancel is not None
    done = False
    try:
        while True:
            try:
                out, err = proc.communicate(timeout=2 if polling else limit)
                break
            except subprocess.TimeoutExpired as e:
                now = time.monotonic()
                if now - started > limit:
                    _stop(e)
                if cancel is not None and cancel():
                    # [검사 중지] — 묶음(최대 30분)이 끝나길 기다리지 않고 바로 끊는다 (2026-09-04)
                    _stop(ConvertCancelled("검사 중지 요청으로 DWG 변환을 중단했습니다"))
                if watch is not None:
                    m = _progress_mark(watch)
                    if m != mark:
                        mark, last_progress = m, now
                    elif now - last_progress > stall:
                        _stop(ConvertStalled(STALL_HINT.format(sec=int(stall))))
        done = True
    finally:
        if done:
            _finish()          # _stop 경로는 자기 안에서 이미 정리했다
        elif dw is not None and dw._t.is_alive():
            dw.stop()          # 예상 못 한 예외 — 감시 스레드가 남지 않게 (재검토 ⑩)
    return subprocess.CompletedProcess(cmd, proc.returncode, out, err)


# 이번 변환에서 자동으로 답한 대화상자 [(제목, 버튼)] / 모르는 대화상자 [(제목, [버튼…])]
DIALOG_LOG: list = []
UNKNOWN_DIALOGS: list = []


def _kill_tree(pid: int) -> None:
    """프로세스와 그 자손을 함께 끝낸다 — CAD가 띄운 도우미가 남지 않게."""
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True,
                       timeout=20, creationflags=_NO_WINDOW)
    else:
        import signal
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass


def _tail(b: bytes) -> str:
    """외부 프로그램 출력의 마지막 300자 — 실패 사유를 화면에 보여주기 위해."""
    s = ""
    for enc in ("utf-8", "mbcs", "cp949"):
        try:
            s = b.decode(enc)
            break
        except Exception:
            continue
    if not s:
        s = b.decode("latin-1", "replace")
    s = " ".join(s.split())
    return s[-300:]


_ENC = "mbcs" if sys.platform == "win32" else "utf-8"


def _cad_script(pairs) -> str:
    """오토캐드 호환 CAD의 스크립트(/b): 도면들을 차례로 열어 DXF로 저장하고 끝낸다 —
    검사당 CAD를 한 번만 켠다 (2026-09-03: 장마다 켜졌다 꺼지던 것)."""
    # 경로는 따옴표로 — 스크립트에서 공백은 Enter라 "C:\Users\홍 길동\…"이 줄로 끊긴다
    # (2026-09-03 재검토). FILEDIA는 사용자 설정(레지스트리)에 남으므로 끝에 되돌린다
    body = "".join(f'_.OPEN\n"{src}"\n_.SAVEAS\nDXF\n16\n"{out}"\n_.CLOSE\n' for src, out in pairs)
    # 끝의 답은 반드시 N(저장 안 함) — 우리 사본은 이미 DXF로 저장돼 물을 게 없고, 만에 하나
    # 남의 도면이 걸려도 절대 저장하지 않는다 (2026-09-03 "도면이 바뀔까 봐 걱정")
    # PROXYNOTICE 0: 타사 응용 객체(프록시) 알림 창도 스크립트를 세운다 — 끄고 끝에 원복
    return "FILEDIA\n0\nPROXYNOTICE\n0\n" + body + "FILEDIA\n1\nPROXYNOTICE\n1\n_.QUIT\n_N\n"


def _cad_running(exe: str) -> bool:
    """그 CAD가 이미 실행 중인가 — 한 번에 하나만 뜨는 CAD는 스크립트가 작업 중인 창으로
    넘어가 그 도면에 손댈 수 있다. 실행 중이면 이번 검사의 변환은 건너뛴다 (2026-09-03)."""
    if sys.platform != "win32":
        return False
    name = Path(exe).name
    try:
        r = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {name}", "/NH"],
                           capture_output=True, timeout=20, creationflags=_NO_WINDOW)
    except Exception:
        return True                 # 판정을 못 하면 실행 중으로 본다 — 안전한 쪽으로
    return name.lower().encode() in (r.stdout or b"").lower()


def _convert_batch(conv: dict, pairs: list, work: Path, cancel=None) -> list:
    """(src, out) 쌍들을 변환. 돌려주는 값: 실행 결과 목록 — 한 번에 처리한 방식이면 1개,
    장마다 실행한 방식이면 쌍 수만큼."""
    kind = conv["kind"]
    n = len(pairs)
    if kind == "oda":
        # 사용법: 입력 폴더, 출력 폴더, 출력 버전, 출력 형식, 하위 폴더 포함, 감사, 필터
        # — 폴더째 넘기므로 원래 한 번에 처리된다
        src0, out0 = pairs[0]
        return [_run([conv["exe"], str(src0.parent), str(out0.parent), "ACAD2018", "DXF",
                      "0", "1", "*.dwg"], work, timeout=_batch_timeout(n), minimized=True,
                     watch=out0.parent, cancel=cancel)]
    if kind == "cadscript":
        if _cad_running(conv["exe"]):
            raise RuntimeError(f"{Path(conv['exe']).name}이(가) 실행 중이라 작업 중인 도면에 영향을 "
                               f"주지 않도록 이번 검사에서는 DWG 변환을 건너뜁니다 — 다음 검사에 다시 시도")
        script = work / "save_dxf.scr"
        script.write_text(_cad_script(pairs), encoding=_ENC)
        return [_run([conv["exe"], "/b", str(script)], work, timeout=_batch_timeout(n),
                     minimized=True, watch=pairs[0][1].parent, cancel=cancel, dialogs=True)]
    results = []
    for src, out in pairs:
        if kind == "accoreconsole":
            script = work / f"{src.stem}.scr"
            script.write_text(f'FILEDIA\n0\n_.SAVEAS\nDXF\n16\n"{out}"\nFILEDIA\n1\n_.QUIT\n',
                              encoding=_ENC)
            results.append(_run([conv["exe"], "/i", str(src), "/s", str(script), "/l", "en-US"],
                                work, cancel=cancel))
        else:                               # custom
            cmd = str(conv["exe"]).format(**{"in": str(src), "out": str(out)})
            results.append(_run(cmd, work, shell=True, cancel=cancel))
    return results


def sweep_temp(max_age_hours: float = 24.0) -> int:
    """지난 실행이 강제 종료되며 남긴 우리 임시 폴더(%TEMP%\\drev-dwg-*)를 치운다 — 한 묶음이
    DWG+DXF 수 GB일 수 있다 (재검토 ⑥). Drev 자신의 임시 폴더만, 하루 지난 것만, 이름 규칙이
    맞는 것만. 감시 대상 파일과는 무관(원칙 2). 돌려주는 값: 치운 폴더 수."""
    base = Path(tempfile.gettempdir())
    n = 0
    cutoff = time.time() - max_age_hours * 3600
    try:
        entries = list(base.iterdir())
    except OSError:
        return 0
    for d in entries:
        try:
            if not d.is_dir() or not d.name.startswith("drev-dwg-") or d.stat().st_mtime > cutoff:
                continue
            cmd = (["cmd", "/c", "rd", "/s", "/q", str(d)] if sys.platform == "win32"
                   else ["rm", "-rf", str(d)])
            subprocess.run(cmd, capture_output=True, timeout=120,
                           creationflags=_NO_WINDOW if sys.platform == "win32" else 0)
            n += 1
        except Exception:
            continue
    return n


@contextlib.contextmanager
def converted_many(dwgs, conv: dict, cancel=None, progress=None):
    """with converted_many(paths, conv) as got: … — {원본 경로: 임시 DXF 경로 또는 실패 사유(str)}.
    CAD·ODA는 검사당 한 번만 실행된다. 블록이 끝나면 임시 폴더째 정리.
    cancel(): True면 즉시 중단 ([검사 중지]). progress(done, total): 묶음마다 진행 표시."""
    dwgs = [Path(x) for x in dwgs]
    got: dict = {}
    if not dwgs:
        yield got
        return
    # 검사당 상한 — 첫 검사에서 3,000장을 한꺼번에 임시 폴더에 복사하면 15GB·수 시간
    # (2026-09-04 검토 extract H-3). 나머지는 실패로 남기지 않고 다음 검사로 넘긴다
    # (실패는 캐시되지 않는다)
    DIALOG_LOG.clear()
    UNKNOWN_DIALOGS.clear()
    deferred = dwgs[SCAN_MAX:]
    dwgs = dwgs[:SCAN_MAX]
    for dwg in deferred:
        got[dwg] = f"이번 검사의 DWG 변환 상한({SCAN_MAX}장)을 넘어 다음 검사에서 변환합니다"
    # 백신·인덱서가 임시 DXF를 잠깐 잡고 있어도 정리 오류가 검사를 죽이지 않게 (재검토)
    with tempfile.TemporaryDirectory(prefix="drev-dwg-", ignore_cleanup_errors=True) as td:
        work = Path(td)
        (work / "out").mkdir()
        started = time.monotonic()
        err = None
        results: list = []
        pairs: list = []
        # 묶음 단위로 복사 → 변환 → 사본 정리: 임시 용량은 한 묶음의 DWG + 결과 DXF
        for k in range(0, len(dwgs), BATCH_MAX):
            chunk = dwgs[k:k + BATCH_MAX]
            if progress is not None and err is None:
                try:
                    progress(k, len(dwgs))
                except Exception:
                    pass
            if err is not None:
                results += [None] * len(chunk)
                pairs += [(None, work / "out" / f"d{k + j}.dxf") for j in range(len(chunk))]
                continue
            if time.monotonic() - started > SCAN_SECONDS:
                err = f"이번 검사의 DWG 변환 총 시간 상한({SCAN_SECONDS // 60}분)을 넘어 나머지는 다음 검사에서 변환합니다"
                results += [None] * len(chunk)
                pairs += [(None, work / "out" / f"d{k + j}.dxf") for j in range(len(chunk))]
                continue
            with tempfile.TemporaryDirectory(prefix="in-", dir=work,
                                             ignore_cleanup_errors=True) as tin:
                cpairs = []
                for j, dwg in enumerate(chunk):
                    src = Path(tin) / f"d{k + j}.dwg"     # 짧은 이름 — 한글·공백 경로 문제 회피
                    src.write_bytes(dwg.read_bytes())     # 원본은 읽기만
                    cpairs.append((src, work / "out" / f"d{k + j}.dxf"))
                pairs += cpairs
                try:
                    res = _convert_batch(conv, cpairs, work, cancel=cancel)
                    if res and len(res) < len(cpairs):     # 폴더째 한 번에 돌린 방식: 결과 1개
                        res = res + [res[-1]] * (len(cpairs) - len(res))
                    results += res
                except ConvertCancelled as e:
                    err = str(e)
                    results += [None] * len(cpairs)
                except ConvertStalled as e:
                    err = f"{conv['name']}: {e}"
                    results += [None] * len(cpairs)
                except subprocess.TimeoutExpired:
                    err = f"{conv['name']}이(가) {_batch_timeout(len(cpairs))}초 안에 끝나지 않았습니다"
                    results += [None] * len(cpairs)
                except FileNotFoundError as e:
                    err = f"프로그램을 실행할 수 없습니다: {e}"
                    results += [None] * len(cpairs)
                except Exception as e:          # 변환기 문제로 검사 전체가 죽지 않게
                    err = f"변환 실행 오류: {e}"
                    results += [None] * len(cpairs)
        for i, (dwg, (src, out)) in enumerate(zip(dwgs, pairs)):
            if out.is_file() and out.stat().st_size > 0:
                got[dwg] = out
                continue
            r = results[i] if i < len(results) else None
            if r is None:
                got[dwg] = err or "변환 실행 오류"
                continue
            made = sorted(x.name for x in (work / "out").iterdir())
            detail = ""
            outp = (r.stderr or b"") + (r.stdout or b"")
            detail = (f"종료 코드 {r.returncode}"
                      + (f", 출력: {_tail(outp)}" if outp else ""))
            detail += (f", 만들어진 파일: {made}" if made else ", 출력 폴더 비어 있음")
            # 사유가 화면에 남지 않으면 '있는데도 안 된다'만 남는다 (2026-09-03 회사 실사용)
            got[dwg] = f"변환 결과 DXF가 만들어지지 않았습니다 ({conv['name']} — {detail})"
        yield got


@contextlib.contextmanager
def converted(dwg: Path, conv: dict):
    """with converted(dwg, conv) as dxf: … — 임시 폴더 안의 DXF. 블록이 끝나면 정리."""
    with converted_many([dwg], conv) as got:
        res = got[Path(dwg)]
        if not isinstance(res, Path):
            raise RuntimeError(res)
        yield res


def test_convert(cfg: dict | None, dwg: Path) -> tuple[bool, str]:
    """설정 화면의 [DWG 변환 시험] — 실제 DWG 하나로 변환→읽기까지 돌려 결과를 문장으로.
    '있는데도 안 된다'를 세 갈래(못 찾음 / 변환 실패 / 읽기 실패)로 가른다 (2026-09-03)."""
    conv = resolve(cfg)
    if conv is None:
        return False, "변환 프로그램을 찾지 못했습니다 — " + status(cfg)[1]
    try:
        with converted(dwg, conv) as dxf:
            from watcher.extract import extract
            doc = extract(dxf)
            n_text = len(doc.raw_texts) if doc else 0
            fields = ", ".join(f"{k}={v.value}" for k, v in (doc.fields.items() if doc else [])) or "없음"
            return True, (f"변환 성공 ({conv['name']}) — {dwg.name}: 글줄 {n_text}개, "
                          f"표제란 {fields}. 다음 검사부터 DWG도 글자·그림 비교됩니다")
    except Exception as e:
        return False, f"변환 실패 ({conv['name']}) — {e}"
