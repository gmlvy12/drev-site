# -*- coding: utf-8 -*-
"""변경 위치 캡처 + 페이지 시각 변경 감지.

형상의 '의미 해석'은 하지 않는다(PRINCIPLE 7, 2026-08-24 개정) — 어느 페이지가
시각적으로 달라졌다는 사실과 전/후 이미지까지만 제시하고, 무엇이 어떻게
바뀌었는지의 해석은 사람 몫이다.
읽기 전용: 원본 파일에는 절대 쓰지 않으며, 빨간 박스는 렌더된 이미지 위에만 그린다.
캡처는 최선 노력(best-effort)이다 — 실패해도 감시·브리핑은 계속된다.
엔진: pypdfium2 + Pillow (허용적 라이선스 — 2026-08-26 AGPL 교체 결정).
"""

from __future__ import annotations

import base64
import io
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from watcher.render import PAGE_NUM_WORD as _PAGE_NUM_WORD, VIS_DPI, dxf_units_at, render_dxf

# 페이지 시각 비교 파라미터
_VIS_DPI = VIS_DPI      # 감지용 렌더 해상도 — 기록해 둔 그림(render.py)과 픽셀 단위로 맞춘다
_VIS_PIXEL_MIN = 40     # 이보다 큰 명도 차이만 '다른 픽셀' (안티앨리어싱 소음 제거)
_VIS_BLOCK = 16         # 변경 픽셀 뭉침 판정 블록(px)
_VIS_BLOCK_MIN_PX = 8   # 블록 안 변경 픽셀이 이 이상이면 '변경 블록'
_VIS_CLUSTER_MIN = 2    # 인접 변경 블록이 이 이상 뭉치면 '변경 위치' (점 소음 제거)
_PAGE_CACHE = 24        # 동시에 열어 두는 페이지 수 (여닫기 5ms/쪽)
_TITLE_ZONE_MARK = "표제란 자리"   # diff.TITLE_ZONE과 같은 말 (순환 import를 피해 따로)
_VIS_REGIONS_PER_PAGE = 3   # 페이지당 보고할 변경 위치 수 상한
_VIS_CROP_PAD = 60      # 변경 위치 주변 여백(pt)
_VIS_JPG_QUALITY = 70
_DXF_CROP_PX = 4600    # 변경 위치를 잘라 쓸 DXF 렌더 해상도 (긴 변, px)
_DXF_CROP_MIN_W = 540  # 잘라낸 그림의 최소 너비 — 이보다 작으면 키운다


@dataclass(frozen=True)
class _Region:
    """페이지 위 사각 영역 — 좌상단 원점(pt). 렌더 이미지 좌표와 방향이 같다."""
    x0: float
    y0: float
    x1: float
    y1: float


# 메일에 실리는 사진의 최대 변 길이(px). A1 도면 한 장이 4769×3368px JPEG 두 장이 되어
# .eml 하나가 5MB였다 — 메일 서버·모바일에서 막히는 크기다 (2026-09-09 브리핑 검토 차단 4).
# 사람이 화면에서 보는 크기는 540~900px이라 이 이상은 전달되지도 않는다.
_MAIL_MAX_SIDE = 1600



def _mark_box(draw, box) -> None:
    """바뀐 자리 표시 — 굵은 테두리 + 왼쪽 위 모서리의 꽉 찬 네모. 2px 빨간 선만이라 축소된 사진에서 흑백 도면 선과 섞였고 적록
    색약에게는 색으로만 구별됐다 (검토65 C4). 그림 위 표식일 뿐 원본은 건드리지 않는다."""
    x0, y0, x1, y1 = box
    x0, x1 = min(x0, x1), max(x0, x1)
    y0, y1 = min(y0, y1), max(y0, y1)
    w = max(3, int(round(draw.im.size[0] / 400)))
    draw.rectangle([x0, y0, x1, y1], outline=(220, 33, 33), width=w)
    k = w * 3
    draw.rectangle([x0 - w, y0 - w, x0 - w + k, y0 - w + k], fill=(220, 33, 33))

def _fit_for_mail(pil_img):
    """긴 변을 _MAIL_MAX_SIDE로 줄인다 — 작은 그림은 그대로."""
    w, h = pil_img.width, pil_img.height
    if max(w, h) <= _MAIL_MAX_SIDE:
        return pil_img
    k = _MAIL_MAX_SIDE / max(w, h)
    from PIL import Image as _Im
    return pil_img.resize((max(1, int(w * k)), max(1, int(h * k))), _Im.LANCZOS)


def _jpeg_b64(pil_img, quality: int = _VIS_JPG_QUALITY) -> str:
    buf = io.BytesIO()
    _fit_for_mail(pil_img).convert("RGB").save(buf, format="JPEG", quality=quality)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _png_b64(pil_img) -> str:
    buf = io.BytesIO()
    _fit_for_mail(pil_img).save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


# 같은 도면의 사진 여러 장 — 도면은 한 번만 그린다. 전에는 사진 한 장마다 도면
# 전체를 4600px로 다시 그려 장당 0.55초였다(엔티티 3천 개 기준). 그래서 파일당
# 4장에서 끊었고, 사용자는 "변경마다 사진이 하나씩 붙어야지"라고 했다 (2026-09-10).
_DXF_RENDER: dict = {}          # {(경로, mtime, 크기): (이미지, meta)}
_DXF_TEXTS: dict = {}           # {(경로, mtime, 크기): [(정규화 글자, 좌표, 높이, 레이어)]}
import threading as _threading  # noqa: E402
_DXF_LOCK = _threading.RLock()


def _dxf_key(path: Path):
    try:
        st = path.stat()
    except OSError:
        return None
    return (str(path), st.st_mtime_ns, st.st_size)


def _dxf_render_cached(path: Path):
    """도면 전체 래스터 — 파일이 그대로면 다시 그리지 않는다 (한 파일분만 들고 있다)."""
    from watcher.render import dxf_image
    key = _dxf_key(path)
    if key is None:
        return None
    # 두 장까지 들고, 같은 도면을 동시에 두 번 그리지 않게 잠근다 — 나란히 보기(도면 두 장)는 한 장만 들고 있어 볼 때마다 둘 다
    # 다시 그렸고, 그릴 수 없는 도면(None)은 캐시 적중이 안 돼 매번 전개 추정을 다시 했다 (검토48 E 중간 1)
    with _DXF_LOCK:
        if key in _DXF_RENDER:
            got = _DXF_RENDER.pop(key)
            _DXF_RENDER[key] = got           # 최근 사용을 뒤로
            return got
        try:
            got = dxf_image(path, max_px=_DXF_CROP_PX)
        except Exception as e:           # noqa: BLE001  — 전개 규모 초과 등: 사진 없이 글자 근거만
            if "그림 기록 상한" not in str(e):
                raise
            got = None
        while len(_DXF_RENDER) >= 2:
            _DXF_RENDER.pop(next(iter(_DXF_RENDER)))
        _DXF_RENDER[key] = got
        return got


def _dxf_texts_cached(path: Path) -> list:
    """도면의 글자 엔티티 목록 (정규화된 글자, x, y, 높이, 레이어).

    그림은 한 번만 그리게 고쳤는데 **파일 파싱은 사진마다 다시 하고 있었다** —
    엔티티 2만 개짜리에서 장당 0.93초였고, PDF(0.03초)보다 30배 느린 이유가
    그것이었다 (2026-09-10 실측). 글자 목록도 파일 단위로 한 번만 읽는다."""
    key = _dxf_key(path)
    if key is None:
        return []
    got = _DXF_TEXTS.get(key)
    if got is not None:
        return got
    import ezdxf
    out = []
    try:
        msp = ezdxf.readfile(str(path)).modelspace()
    except Exception:                            # noqa: BLE001
        while len(_DXF_TEXTS) >= 2:  # 두 장까지 (검토48 E 중간 1)
            _DXF_TEXTS.pop(next(iter(_DXF_TEXTS)))
        _DXF_TEXTS[key] = out
        return out
    def _text_entities():
        for e in msp.query("TEXT MTEXT"):
            yield e
        # 블록 속성(ATTRIB) 표제란 — 실무 도면의 다수. 이걸 안 훑어 Rev 변경 사진이
        # 없었다 (검토19 감지 ⑧). 그림 비교 마스크는 이미 ATTRIB를 본다
        for ins_ in msp.query("INSERT"):
            try:
                for a in (getattr(ins_, "attribs", None) or ()):
                    yield a
            except Exception:                    # noqa: BLE001
                continue
    for e in _text_entities():
        try:
            val = e.plain_text() if e.dxftype() == "MTEXT" else e.dxf.text
        except Exception:                        # noqa: BLE001
            val = getattr(e.dxf, "text", "")
        val = _norm(val)
        if not val:
            continue
        try:
            ins = e.dxf.insert
            out.append((val, float(ins.x), float(ins.y),
                        float(getattr(e.dxf, "height", 0) or 3.0),
                        str(getattr(e.dxf, "layer", "") or "")))
        except Exception:                        # noqa: BLE001
            continue
    while len(_DXF_TEXTS) >= 2:  # 두 장까지 (검토48 E 중간 1)
        _DXF_TEXTS.pop(next(iter(_DXF_TEXTS)))
    _DXF_TEXTS[key] = out
    return out


def _norm(s) -> str:
    return " ".join(str(s or "").split())


def _find_entity(rows, target_text: str):
    """바뀐 글줄이 그려진 DXF 엔티티를 찾는다 (없으면 None).

    전에는 **줄의 첫 토큰과 통째로 같은** 엔티티만 찾았다. 그래서 현장에서 가장 흔한
    두 모양에서 전/후 사진이 조용히 안 나왔다 (2026-09-10 사용자 신고로 재현):
    - `M-101 MOTOR 7.5kW`가 한 엔티티 → 첫 토큰 `M-101`과 안 같다 → None
    - 표제란 한 칸 `REV: B` → 마찬가지로 None
    글자 변경은 보고되는데 사진만 없으니 "글로만 비교된다"로 보였다.

    이제 겹치는 정도로 고른다: ①줄 전체와 같은 엔티티 ②줄을 품거나 줄에 담기는
    엔티티 중 가장 많이 겹치는 것 ③첫 토큰을 낱말로 품은 엔티티. 낱말 경계를 보므로
    `M-1`이 `M-101`에 걸리지는 않는다."""
    import re as _re
    want = _norm(target_text)
    if not want:
        return None
    token = want.split()[0]
    exact = whole = part = None
    best = 0
    tok_re = _re.compile(r"(?<![0-9A-Za-z])" + _re.escape(token) + r"(?![0-9A-Za-z])")
    # 한 글자 값('C')은 부분 문자열로 'PROJE**C**T'에 먼저 걸려 엉뚱한 줄에 박스가 갔다
    # (검토19 2차 브리핑 ①). 3자 미만은 정확히 같은 줄이거나 '라벨: 값' 꼴만 인정한다
    short = len(want) < 3
    label_re = (_re.compile(r"^[A-Za-z가-힣 ._/-]{1,14}[:.]?\s*" + _re.escape(want) + r"$")
                if short else None)
    for row in rows:
        val = row[0]
        if val == want:
            exact = row
            break
        if short:
            if label_re.search(val) and whole is None:
                whole = row
            continue
        if val in want or want in val:
            n = min(len(val), len(want))
            if n > best:
                best, whole = n, row
        elif part is None and tok_re.search(val):
            part = row
    return exact or whole or part


def _dxf_crop(path: Path, target_text: str, pad: float = 55.0) -> dict | None:
    """DXF에서 target 텍스트(줄의 첫 토큰) 주변을 잘라낸 PNG + 빨간 박스.

    2026-09-09까지는 이 자리에서 SVG를 직접 만들어 넣었는데 두 가지가 틀렸다
    (브리핑 검토 차단 3):
    - `image/svg+xml`은 아웃룩·대부분의 웹메일이 지워 버린다 — 전/후 사진이 안 보였다.
    - 손으로 LINE·LWPOLYLINE·CIRCLE·ARC·TEXT만 그려서 블록·해치·치수·MTEXT가 빠졌다.
      표제란이 블록이면 변경 위치 주변이 텅 빈 그림으로 나왔다.
    이제 그림 비교와 **같은 렌더러**(render.dxf_image)로 도면 전체를 래스터로 그린 뒤
    그 자리만 잘라낸다 — 화면·메일이 보는 그림이 같아지고 빠지는 요소가 없다."""
    from PIL import Image, ImageDraw

    target = _find_entity(_dxf_texts_cached(Path(path)), target_text)
    if target is None:
        return None
    _val, tx, ty, th, layer = target

    r = _dxf_render_cached(Path(path))
    if r is None:
        return None
    img, meta = r

    def px(x: float, y: float) -> tuple[float, float]:
        """도면 좌표 → 픽셀 (dxf_image의 변환과 같은 식)."""
        return (meta["pad"] + (x - meta["x0"]) * meta["scale"],
                meta["pad"] + (meta["y1"] - y) * meta["scale"])

    cx0, cy1 = px(tx - pad, ty - pad * 0.55)     # y는 뒤집혀 아래쪽이 큰 픽셀
    cx1, cy0 = px(tx + pad * 2.2, ty + pad * 0.55)
    L = max(0, int(min(cx0, cx1)))
    R = min(img.width, int(max(cx0, cx1)) + 1)
    T = max(0, int(min(cy0, cy1)))
    B = min(img.height, int(max(cy0, cy1)) + 1)
    if R - L < 8 or B - T < 8:                   # 글자가 너무 작아 잘라낼 게 없으면 전체
        L, T, R, B = 0, 0, img.width, img.height
    crop = img.crop((L, T, R, B)).convert("RGB")

    # 변경 위치 하이라이트 — 잘라낸 **그림 위에만** 그린다 (원본은 읽기 전용)
    bw = max(len(target_text) * th * 0.9, th * 6)     # 0.75는 글줄 끝 글자가 테두리 밖이었다 (검토48 C 낮음 9)
    bx0, by1 = px(tx, ty - th * 0.6)
    bx1, by0 = px(tx + bw, ty + th * 1.4)
    draw = ImageDraw.Draw(crop)
    _mark_box(draw, [min(bx0, bx1) - L, min(by0, by1) - T, max(bx0, bx1) - L, max(by0, by1) - T])

    if crop.width < _DXF_CROP_MIN_W:             # 작은 도면은 읽을 만한 크기로 키운다
        k = _DXF_CROP_MIN_W / crop.width
        crop = crop.resize((_DXF_CROP_MIN_W, max(1, int(crop.height * k))), Image.LANCZOS)

    return {
        "mime": "image/png",
        "b64": _png_b64(crop),
        "caption": f"변경 위치: 레이어 {layer}, 좌표 ({tx:.0f}, {ty:.0f})",
    }


def _render_region(page, region: _Region, scale: float = 2.0,
                   box: _Region | None = None):
    """페이지의 region(좌상단 원점 pt)만 렌더한 PIL 이미지. box가 있으면 빨간 테두리.
    원본 PDF는 읽기만 하고, 표시는 렌더된 픽셀 위에만 한다."""
    from PIL import ImageDraw

    w, h = page.get_size()
    x0 = max(0.0, region.x0)
    y0 = max(0.0, region.y0)
    x1 = min(float(w), region.x1)
    y1 = min(float(h), region.y1)
    # pdfium crop = (왼쪽, 아래, 오른쪽, 위)에서 잘라낼 양 — 아래 원점 좌표계
    crop = (x0, h - y1, w - x1, y0)
    from watcher.render import bitmap_pil
    img = bitmap_pil(page.render(scale=scale, crop=crop))
    if box is not None:
        draw = ImageDraw.Draw(img)
        _mark_box(draw, [(box.x0 - x0 - 4) * scale, (box.y0 - y0 - 4) * scale,
                         (box.x1 - x0 + 4) * scale, (box.y1 - y0 + 4) * scale])
    return img


def _pdf_png(path: Path, target_text: str) -> dict | None:
    """PDF에서 target 줄을 찾아 주변을 잘라 PNG + 빨간 박스 (렌더 이미지 위에만 표시)."""
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(Path(path).read_bytes())  # 핸들 즉시 반납
    try:
        for pno in range(1, len(pdf) + 1):
            page = pdf[pno - 1]
            textpage = page.get_textpage()
            found = textpage.search(target_text, match_case=True).get_next()
            if found is None:
                textpage.close()
                page.close()
                continue
            idx, cnt = found
            n = textpage.count_rects(idx, cnt)
            if not n:
                textpage.close()
                page.close()
                continue
            left, bottom, right, top = textpage.get_rect(0)
            _, h = page.get_size()
            box = _Region(left, h - top, right, h - bottom)  # 좌상단 원점으로 변환
            area = _Region(box.x0 - 170, box.y0 - 70, box.x1 + 170, box.y1 + 70)
            img = _render_region(page, area, scale=2.0, box=box)
            out = {
                "mime": "image/png",
                "b64": _png_b64(img),
                "caption": f"변경 위치: {pno}페이지, 좌표 ({box.x0:.0f}, {box.y0:.0f})",
            }
            textpage.close()
            page.close()
            return out
    finally:
        pdf.close()
    return None


def _one(abs_path: Path, text: str) -> dict | None:
    try:
        ext = Path(abs_path).suffix.lower()
        if ext == ".dxf":
            return _dxf_crop(Path(abs_path), text)
        if ext == ".pdf":
            return _pdf_png(Path(abs_path), text)
    except Exception:
        return None  # 캡처 실패는 감시를 막지 않는다
    return None


def capture_for(abs_path: Path, new_text: str) -> dict | None:
    """변경된 줄(new_text)의 위치 캡처(신버전). 지원 유형이 아니거나 실패하면 None."""
    return _one(abs_path, new_text) if new_text else None


def _box_crop(path, box) -> dict | None:
    """OCR 글줄의 자리(pno, x0, y0, x1, y1 pt)를 여유를 두고 잘라 낸다 — 스캔본은 글자 검색이 안 된다."""
    src = None
    try:
        src = _source(Path(path))
        pno, x0, y0, x1, y1 = box
        pad_x, pad_y = max(40.0, (x1 - x0) * 0.5), max(20.0, (y1 - y0) * 1.5)
        w, h = src.size(pno)
        rect = _Region(max(0.0, x0 - pad_x), max(0.0, y0 - pad_y), min(w, x1 + pad_x), min(h, y1 + pad_y))
        out = _region_crop(src, pno, rect, "")
        out["caption"] = f"{pno}페이지 OCR 자리 ({x0:.0f}, {y0:.0f}) 부근"
        return out
    except Exception:
        return None
    finally:
        if src is not None:
            try:
                src.close()
            except Exception:
                pass


def capture_pair(new_path: Path, new_text: str,
                 old_path: Path | None = None,
                 old_text: str | None = None, box=None) -> dict | None:
    """전/후 캡처 쌍. 결과 dict:
      {'after': {...}, 'before': {...}|None}
    old_path가 있으면(판 짝짓기 = 이전 파일이 남아 있는 경우) 전 사진도 만든다.
    덮어쓰기라 구버전 파일이 없으면 before=None (후 사진만).
    box: OCR로 읽은 글줄의 자리(pno, x0, y0, x1, y1) — 있으면 글자 검색 대신 그 자리를 자른다."""
    if box:
        after = _box_crop(new_path, box)
        if after is None:
            return None
        before = _box_crop(old_path, box) if old_path is not None and Path(old_path).is_file() else None
        return {"after": after, "before": before}
    after = _one(new_path, new_text) if new_text else None
    if after is None:
        return None
    before = None
    if old_path is not None and Path(old_path).is_file():
        before = _one(Path(old_path), old_text or new_text)
    return {"after": after, "before": before}


def _gray_array(page, dpi: int = _VIS_DPI):
    """페이지 전체를 그레이스케일 numpy 배열로."""
    from watcher.render import bitmap_array
    return bitmap_array(page.render(scale=dpi / 72.0, grayscale=True))


def _block_hits(mask, block_min: int) -> set:
    """참/거짓 픽셀 그림을 _VIS_BLOCK 칸 블록으로 나눠 참 픽셀이 block_min 이상인 블록 {(bx, by)}.
    한 칸 8픽셀(참 = 바이트 1)을 64비트 정수 하나로 보고 켜진 비트를 세어 더한다 — bool 덧셈(쪽 크기 int64)과 같은 수."""
    import numpy as np
    h, w = mask.shape
    gh, gw = h // _VIS_BLOCK + 1, w // _VIS_BLOCK + 1
    padded = np.zeros((gh * _VIS_BLOCK, gw * _VIS_BLOCK), dtype=bool)
    padded[:h, :w] = mask
    if _VIS_BLOCK % 8 == 0 and hasattr(np, "bitwise_count"):
        per8 = np.bitwise_count(padded.view(np.uint64))         # (gh·B, gw·B/8) — 8픽셀마다 참 개수
        sums = per8.reshape(gh, _VIS_BLOCK, gw, _VIS_BLOCK // 8).sum(axis=(1, 3), dtype=np.int64)
    else:
        sums = padded.reshape(gh, _VIS_BLOCK, gw, _VIS_BLOCK).sum(axis=(1, 3))
    ys, xs = np.nonzero(sums >= block_min)
    return {(int(x), int(y)) for x, y in zip(xs, ys)}


def _changed_blocks(a, b, pixel_min: int = _VIS_PIXEL_MIN,
                    block_min: int = _VIS_BLOCK_MIN_PX, loose=None, drop=None):
    """두 그레이 렌더(numpy 2D)의 '변경 블록' 좌표 집합 {(bx, by)}.
    loose: 픽셀 마스크(bool) — 그 자리는 2픽셀까지 어긋남을 허용한다(같은 글줄이 같은 자리에 있는 곳, 검토68 B5).
    drop: 픽셀 마스크(bool) — 그 자리의 차이는 세지 않는다(배치만 바뀜으로 설명된 픽셀, _layout_drop)."""
    import numpy as np
    h, w = a.shape
    a16, b16 = a.astype(np.int16), b.astype(np.int16)
    # 1픽셀 허용 — 좌표가 1ulp(420 → 419.99999999999994)만 달라도, 다른 프로그램이 글자를 6e-5pt 옆에 놓아도 선·글자가 한 픽셀
    # 밀려 그려져 '그림 변경'과 거짓 Rev 미갱신이 났다 (검토66 C1·C2). 상대 그림의 3×3 이웃 어디와도 다를 때만 '다른 픽셀'
    def _nb(x, r=1):
        # (2r+1)² 이웃 최솟값·최댓값 — 가로 한 번·세로 한 번으로 나눠(같은 값) 제자리에서 줄인다. (2r+1)²장을 쌓아 줄이면
        # 쪽 크기 int16 배열 9~25장을 새로 만들었다
        p = np.pad(x, r, mode="edge")
        lo, hi = p[:, 0:w].copy(), p[:, 0:w].copy()
        for dx in range(1, 2 * r + 1):
            np.minimum(lo, p[:, dx:dx + w], out=lo)
            np.maximum(hi, p[:, dx:dx + w], out=hi)
        vlo, vhi = lo[0:h].copy(), hi[0:h].copy()
        for dy in range(1, 2 * r + 1):
            np.minimum(vlo, lo[dy:dy + h], out=vlo)
            np.maximum(vhi, hi[dy:dy + h], out=vhi)
        return vlo, vhi
    bmin, bmax = _nb(b16)
    amin, amax = _nb(a16)
    mask = (((a16 < bmin - pixel_min) | (a16 > bmax + pixel_min))
            | ((b16 < amin - pixel_min) | (b16 > amax + pixel_min)))
    if loose is not None and loose.shape == mask.shape and loose.any():
        # 같은 글줄 자리 — 낱말마다 따로 그린 재출력은 한글 글자가 0.1pt 옆에 놓여 글리프 힌팅이 2픽셀까지 달라졌다
        # (검토68 B5: 무변경 재출력에 그림 변경 2블록 → 거짓 'Rev 미갱신')
        bmin2, bmax2 = _nb(b16, 2)
        amin2, amax2 = _nb(a16, 2)
        mask2 = (((a16 < bmin2 - pixel_min) | (a16 > bmax2 + pixel_min))
                 | ((b16 < amin2 - pixel_min) | (b16 > amax2 + pixel_min)))
        if LAYOUT_ALIGN:
            # 같은 글을 겹쳐 그리거나(굵게 보임) 글리프 힌팅만 다른 자리 — 명도만 다르고 잉크 자리는 같다. 한쪽의 뚜렷한 잉크가 다른
            # 쪽 2픽셀 안에 잉크로 있으면 다른 픽셀로 세지 않는다 (2026-10-23 뒤흔들기 C5 double)
            mask2 = mask2 & (((b16 < 180) & (amin2 >= 230)) | ((a16 < 180) & (bmin2 >= 230)))
        mask = np.where(loose, mask2, mask)
    if drop is not None and drop.shape == mask.shape:
        mask = mask & ~drop
    return _block_hits(mask, block_min)


def _clusters(blocks: set, cluster_min: int = _VIS_CLUSTER_MIN) -> list:
    """인접(8방향) 변경 블록을 뭉쳐 위치별 블록 묶음 목록으로. 큰 묶음 순."""
    seen: set = set()
    out = []
    for start in blocks:
        if start in seen:
            continue
        group, todo = [], [start]
        seen.add(start)
        while todo:
            bx, by = todo.pop()
            group.append((bx, by))
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    nb = (bx + dx, by + dy)
                    if nb in blocks and nb not in seen:
                        seen.add(nb)
                        todo.append(nb)
        if len(group) >= cluster_min:
            out.append(group)
    out.sort(key=len, reverse=True)
    return out


class _PdfSource:
    """PDF 파일의 페이지 공급원 — 감지용 그레이 렌더·확대 크롭을 pdfium으로 만든다."""

    def __init__(self, path: Path):
        import pypdfium2 as pdfium
        # 메모리로 읽고 파일은 즉시 놓아준다 — 긴 렌더 동안 파일을 잡고 있으면
        # 탐색기에서 이동·이름변경이 거부돼 "폴더 먹통"으로 체감된다 (2026-08-27)
        self._doc = pdfium.PdfDocument(Path(path).read_bytes())
        self._open: dict = {}              # 연 페이지 (최근 것만 들고 있는다)
        self._size: dict = {}
        self._thumb: dict = {}

    def __len__(self):
        return len(self._doc)

    def _page(self, pno: int):
        """한 페이지를 여는 데 5ms가 든다 — 131쪽 한 쌍이면 여닫기만 9초였다 (2026-09-07).
        쪽마다 크기·잉크·렌더를 잇달아 물어보므로 최근 것 몇 개만 들고 있으면 대부분 다시 열지 않는다.

        **돌려준 핸들을 들고 있다가 다른 쪽을 요청하면 안 된다** — 상한을 넘으면 가장 오래 안 쓴
        핸들이 닫히고, 닫힌 핸들을 쓰면 ArgumentError가 나 그 파일이 통째로 '비교 못 함'이 된다.
        지금 호출부는 모두 한 표현식 안에서 바로 소비한다 (2026-09-07 추출 검토 ④)."""
        page = self._open.pop(pno, None)
        if page is None:
            page = self._doc[pno - 1]
        self._open[pno] = page             # 방금 쓴 것을 맨 뒤로 — 가장 오래 안 쓴 것부터 닫는다
        if len(self._open) > _PAGE_CACHE:
            old = next(iter(self._open))
            if old != pno:
                try:
                    self._open.pop(old).close()
                except Exception:
                    pass
        return page

    def size(self, pno: int):
        got = self._size.get(pno)
        if got is None:
            got = self._size[pno] = tuple(float(v) for v in self._page(pno).get_size())
        return got

    def gray(self, pno: int):
        # 방금 그린 쪽 둘만 들고 있는다 — 같은 쪽을 맞춤·비교에서 거듭 묻는다(그릴 때마다 렌더)
        cache = self.__dict__.setdefault("_gray_lru", {})
        g = cache.pop(pno, None)
        if g is None:
            g = _gray_array(self._page(pno))
        cache[pno] = g
        while len(cache) > 2:
            cache.pop(next(iter(cache)))
        return g

    def crop(self, pno: int, area: _Region, box: _Region | None):
        return _render_region(self._page(pno), area, scale=2.0, box=box)

    def where(self, pno: int, rect: _Region) -> str:
        return f"{pno}페이지 좌표 ({rect.x0:.0f}, {rect.y0:.0f}) 부근"

    def annots(self, pno: int):
        """쪽의 메모·도장 주석 [[이름표, x0, y0, x1, y1]] (검토20 r07 7)."""
        try:
            from watcher.render import page_annots
            return page_annots(self._page(pno))
        except Exception:                                   # noqa: BLE001
            return None

    def text_boxes(self, pno: int, texts, title_boxes=()) -> list:
        """페이지에서 texts(바뀐 글줄)가 놓인 사각형들(pt, 좌상단 원점). title_boxes는 DXF만 쓴다."""
        out: list = []
        page = self._page(pno)
        try:
            # /Rotate 쪽 — 글자 사각형은 돌리기 전 좌표라 그린 그림(돌린 뒤)에 맞게 옮긴다. 안 옮기면 바뀐 표제란 글자가 가려지지
            # 않아 회전 쪽의 Rev 올림이 덤 '그림 변경'이 됐다 (검토68 B1·B11). 줄 묶음도 추출기와 같은 글자판으로
            from watcher.extract.pdf import _page_textpage
            rot = int(page.get_rotation() or 0) % 360
            tp = _page_textpage(page)
            w, h = page.get_size()
            if rot in (90, 270):
                w, h = h, w                                  # 돌리기 전 크기
            def _put(left, bottom, right, top):
                if rot == 90:
                    out.append(_Region(bottom, left, top, right))
                elif rot == 180:
                    out.append(_Region(w - right, bottom, w - left, top))
                elif rot == 270:
                    out.append(_Region(h - top, w - right, h - bottom, w - left))
                else:
                    out.append(_Region(left, h - top, right, h - bottom))
            try:
                for txt in texts:
                    if len(txt) < 2:
                        continue
                    s = tp.search(txt, match_case=True)
                    for _ in range(50):
                        f = s.get_next()
                        if f is None:
                            break
                        idx, cnt = f
                        for r in range(tp.count_rects(idx, cnt)):
                            _put(*tp.get_rect(r))
                # 추출기와 같은 줄 묶기(그리는 순서와 상관없는 글줄)로도 — 따로 그린 칸('개정'·'1')을 이은 글줄 '개정 1'은 글자 찾기로
                # 못 찾아 Rev 올림 칸이 덤 '그림 변경'이 됐다 (2026-10-20 PDF 대량 시험 N7·N10). 글줄 전체가 같을 때만
                try:
                    from watcher.extract.pdf import page_text_lines
                    want = {" ".join(str(t).split()) for t in texts if len(str(t).strip()) >= 2}
                    for lt, bx in (page_text_lines(tp, page) or []):
                        if bx and " ".join(str(lt).split()) in want:
                            x0, y0, x1, y1 = bx
                            _put(x0, h - y1, x1, h - y0)
                except Exception:
                    pass
            finally:
                tp.close()
        except Exception:
            return out
        return out

    def full_page(self, pno: int):
        from watcher.render import bitmap_pil
        return bitmap_pil(self._page(pno).render(scale=110 / 72.0))

    def thumb(self, pno: int):
        """페이지 짝짓기용 작은 그레이 그림 (약 12dpi) — 전체 렌더보다 훨씬 싸다.
        짝짓기와 '전체 어긋남' 판정에서 같은 쪽을 다시 묻는다 — 한 번만 그린다."""
        import numpy as np
        got = self._thumb.get(pno)
        if got is None:
            from watcher.render import bitmap_pil
            got = self._thumb[pno] = np.asarray(
                bitmap_pil(self._page(pno).render(scale=12 / 72.0, grayscale=True)).convert("L"))
        return got

    def words(self, pno: int) -> set:
        """페이지 글자 낱말 집합 — 도면 세트처럼 틀이 같은 페이지를 잉크 분포로 못 가를 때
        (2026-09-06 블라인드 2차 38: 4쪽을 2쪽으로 옮긴 세트)."""
        page = self._page(pno)
        try:
            tp = page.get_textpage()
            try:
                # 'SHEET 2 OF 4'의 숫자처럼 쪽이 밀리면 함께 바뀌는 낱말은 짝짓기에 쓰지 않는다
                return {w for w in tp.get_text_range().split() if not _PAGE_NUM_WORD.match(w)}
            finally:
                tp.close()
        except Exception:
            return set()

    def close(self) -> None:
        for page in list(self._open.values()):
            try:
                page.close()
            except Exception:
                pass
        self._open.clear()
        self._doc.close()


class _RenderSource:
    """기록해 둔 페이지 그림(render.PageRender 목록)의 공급원 — 같은 이름으로
    덮어써져 파일이 사라진 이전 판, 그리고 DXF(파일에서 방금 렌더)의 페이지."""

    def __init__(self, pages, dxf_path=None):
        self._pages = list(pages)
        self._imgs: dict = {}
        self._dxf_path = dxf_path          # 파일에서 방금 그린 DXF면 글자 위치를 알 수 있다

    def __len__(self):
        return len(self._pages)

    def meta(self, pno: int = 1) -> dict:
        return (self._pages[pno - 1].meta or {}) if self._pages else {}

    def _img(self, pno: int):
        img = self._imgs.get(pno)
        if img is None:
            from PIL import Image
            decode = Image.open      # 메모리 버퍼(BytesIO)의 PNG 해독 — 파일을 열지 않는다
            img = decode(io.BytesIO(self._pages[pno - 1].png)).convert("L")
            img.load()
            self._imgs[pno] = img
        return img

    def size(self, pno: int):
        pg = self._pages[pno - 1]
        return (float(pg.width_pt), float(pg.height_pt))

    def gray(self, pno: int):
        import numpy as np
        return np.asarray(self._img(pno))

    def crop(self, pno: int, area: _Region, box: _Region | None, scale: float = 2.0):
        from PIL import ImageDraw
        k = _VIS_DPI / 72.0                      # pt → 기록 그림 px
        w, h = self.size(pno)
        x0, y0 = max(0.0, area.x0), max(0.0, area.y0)
        x1, y1 = min(w, area.x1), min(h, area.y1)
        part = self._img(pno).crop((int(x0 * k), int(y0 * k),
                                    int(math.ceil(x1 * k)), int(math.ceil(y1 * k))))
        part = part.resize((max(1, int(part.width * scale / k)),
                            max(1, int(part.height * scale / k)))).convert("RGB")
        if box is not None:
            _mark_box(ImageDraw.Draw(part), [(box.x0 - x0 - 4) * scale, (box.y0 - y0 - 4) * scale,
                                             (box.x1 - x0 + 4) * scale, (box.y1 - y0 + 4) * scale])
        return part

    def annots(self, pno: int):
        """기록 때 함께 저장한 메모·도장 주석 자리 — 옛 기록(그 전 판)·DXF는 None(모름)."""
        got = self.meta(pno).get("annots")
        return got if isinstance(got, list) else None

    def where(self, pno: int, rect: _Region) -> str:
        meta = self.meta(pno)
        if meta.get("thumb"):                    # DWG 미리보기 — 좌표는 의미가 없다
            return "미리보기 그림 (저해상도 — 변환 프로그램이 있으면 정확한 위치까지)"
        if "scale" in meta:                      # DXF: 사람이 CAD에서 찾아갈 도면 좌표
            ux, uy = dxf_units_at(meta, (rect.x0 + rect.x1) / 2, (rect.y0 + rect.y1) / 2)
            return f"도면 좌표 ({ux:.0f}, {uy:.0f}) 부근"
        return f"{pno}페이지 좌표 ({rect.x0:.0f}, {rect.y0:.0f}) 부근"

    def full_page(self, pno: int):
        img = self._img(pno)
        k = 110 / _VIS_DPI
        return img.resize((max(1, int(img.width * k)), max(1, int(img.height * k)))).convert("RGB")

    def thumb(self, pno: int):
        import numpy as np
        img = self._img(pno)
        k = 12 / _VIS_DPI
        return np.asarray(img.resize((max(1, int(img.width * k)), max(1, int(img.height * k)))))

    def words(self, pno: int) -> set:
        # 검사 때 그림과 함께 저장한 낱말 (v0.50.7부터). 그전 기록은 비어 있어 잉크 분포로만 짝짓는다
        return set(self.meta(pno).get("words") or [])

    def text_boxes(self, pno: int, texts, title_boxes=()) -> list:
        """바뀐 글줄(TEXT/MTEXT)의 자리 — 렌더 좌표(pt)로. 파일이 있으면 파일에서 읽고, 기록된 옛 판이면
        기록 때 함께 저장한 글자 자리(meta['tboxes'])에서 고른다 — 지워진 글줄의 자리는 새 판엔 없어
        '그림 변경'으로 찍혔다 (검토21 재검증 D9: 옛 판은 기록뿐이라 마스크가 비었다).
        title_boxes(DXF 도면 좌표 표제란 틀)가 있으면 바뀐 표제란 칸 값(TitleValue)은 그 틀 안에서만 가린다."""
        meta = self.meta(pno)
        if not texts:
            return []
        syms = {str(t) for t in texts if isinstance(t, RevSymbol)}
        boxes = [tuple(map(float, bx)) for bx in (title_boxes or ()) if bx and len(bx) == 4] if "scale" in meta else []
        tvals = [t for t in texts if isinstance(t, TitleValue)] if boxes else []
        tmatch = _text_matcher(tvals) if tvals else None
        syms |= {str(t) for t in tvals}         # 틀 밖이어도 개정표 행 글 옆이면 개정 기호로 가린다 (아래 syms 규칙)
        matches = _text_matcher([t for t in texts if not isinstance(t, RevSymbol)
                                 and not (tvals and isinstance(t, TitleValue))])
        if self._dxf_path:
            if pno != 1 or "scale" not in meta:
                return []
            rows = dxf_text_boxes(self._dxf_path, meta, None)
        else:
            # 기록된 판(DXF·PDF 모두) — 기록 때 저장한 글자 자리에서 고른다 (재검증 2차: PDF 옛 판도)
            rows = []
            for entry in meta.get("tboxes") or []:
                try:
                    txt, x0, y0, x1, y1 = entry
                    rows.append((" ".join(str(txt).split()), _Region(float(x0), float(y0), float(x1), float(y1))))
                except (TypeError, ValueError):
                    continue
        out = [r for t, r in rows if matches(t)]
        if tmatch is not None:
            # 바뀐 표제란 칸 값('C')은 표제란 틀 안에서만 — 도면 어디서든 가리면 본문 'DETAIL C'의 'C'를 옮긴 그림 변경까지
            # 사라졌다 (검토69 B V6: Rev B→C인 날 본문 'C' 이동이 '그림 동일')
            def _in_title(r) -> bool:
                ux, uy = dxf_units_at(meta, (r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)
                for x0, y0, x1, y1 in boxes:
                    px_, py_ = max((x1 - x0) * 0.03, 1.0), max((y1 - y0) * 0.03, 1.0)
                    if x0 - px_ <= ux <= x1 + px_ and y0 - py_ <= uy <= y1 + py_:
                        return True
                return False
            out.extend(r for t, r in rows if not matches(t) and tmatch(t) and _in_title(r))
        if syms:
            # 개정 기호('C')는 같은 행의 개정표 글(일자·설명)이 가려진 자리 옆일 때만 — 글자로 찾으면 도면 어디서든 맞아 본문
            # 'DETAIL C'의 'C'를 옮긴 그림 변경까지 가렸다 (검토69 B V6c)
            for t, r in rows:
                if t in syms and not matches(t) and r not in out:
                    hh = max(1.0, r.y1 - r.y0)
                    if any(abs((q.y0 + q.y1) / 2 - (r.y0 + r.y1) / 2) <= hh and max(0.0, q.x0 - r.x1, r.x0 - q.x1) <= 200
                           for q in out):
                        out.append(r)
        return out

    def close(self) -> None:
        self._imgs.clear()


class RevSymbol(str):
    """개정표 행 기호('C') — 가림 후보로 넘기되 DXF에서는 같은 행 개정표 글 옆에서만 찾는다 (cli._changed_texts)."""


class TitleValue(str):
    """바뀐 표제란 칸 값 — 가림 후보로 넘기되 DXF에서는 표제란 틀(title_boxes) 안에서만 찾는다 (cli._changed_texts).
    틀을 모르면(표제란 틀 못 찾음·PDF) 보통 글처럼 어디서든 가린다."""


def _text_matcher(texts):
    """바뀐 글줄 집합에 대한 일치 판정 — 글자 객체 하나가 바뀐 줄의 낱말이면 그 자리도 글자 변경이다."""
    want = {" ".join(str(x).split()) for x in texts}
    longs = [x for x in want if len(x) >= 4]

    def _matches(txt: str) -> bool:
        # 추출기는 한 줄의 글자 객체들("M-101", "7.5kW")을 "M-101 7.5kW"로 합친다 —
        # 객체 하나가 바뀐 줄의 낱말이면 그 자리도 글자 변경이다
        return (txt in want or any(x in txt for x in longs)
                or (len(txt) >= 3 and any(
                    re.search(r"(?<!\S)" + re.escape(txt) + r"(?!\S)", x) for x in longs)))
    return _matches


_DXF_SCAN: dict = {}            # {(경로, mtime, 크기): {"doc": ezdxf 문서|None, "boxes": {meta 열쇠: [...]}, "geom": [...]}}


def _dxf_scan(dxf_path) -> dict | None:
    """DXF를 파일 단위로 한 번만 읽는다 — 그림 비교 한 번에 글자 자리(_all_text_rects 네 번·text_boxes 두 번)를 위해
    ezdxf.readfile을 여섯 번 불러 글자 3,000개 A1이 14초→47초가 됐다 (검토69 성능 a). 두 장까지 들고 있다."""
    key = _dxf_key(Path(dxf_path))
    if key is None:
        return None
    with _DXF_LOCK:
        got = _DXF_SCAN.get(key)
        if got is None:
            import ezdxf
            try:
                doc = ezdxf.readfile(str(dxf_path))
            except Exception:                           # noqa: BLE001
                doc = None
            got = {"doc": doc, "boxes": {}, "geom": None}
            while len(_DXF_SCAN) >= 2:
                _DXF_SCAN.pop(next(iter(_DXF_SCAN)))
            _DXF_SCAN[key] = got
        return got


def dxf_text_boxes(dxf_path, meta: dict, matches=None) -> list:
    """DXF의 글자 객체(TEXT/ATTRIB/MTEXT) 자리 — (글자, 렌더 좌표 pt 사각형) 목록.
    matches가 None이면 전부(기록용), 아니면 일치하는 것만. 파일·틀(meta)마다 한 번만 계산한다."""
    if "scale" not in (meta or {}):
        return []
    scan = _dxf_scan(dxf_path)
    if scan is None or scan["doc"] is None:
        return []
    allb = _dxf_boxes_kinds(scan, meta)[0]
    if matches is None:
        return list(allb)
    return [(t, r) for t, r in allb if matches(t)]


def _dxf_boxes_kinds(scan: dict, meta: dict) -> tuple:
    mkey = (meta.get("scale"), meta.get("x0"), meta.get("y1"), meta.get("pad"))
    with _DXF_LOCK:
        got = scan["boxes"].get(mkey)
    if got is None:
        got = _dxf_text_boxes_all(scan["doc"], meta)
        with _DXF_LOCK:
            scan["boxes"][mkey] = got
    return got


def dxf_text_fmts(dxf_path, meta: dict) -> list:
    """dxf_text_boxes(…, None)과 같은 순서의 서식 지문 — (서식, 크기 서식) 짝. 글꼴(STYLE)·색·MTEXT 서식 코드(\\f \\C 굵게)만
    다르고 글자·자리·크기가 같은 글을 '서식만 바뀜'으로 가르려고 (검토20 r03 4)."""
    scan = _dxf_scan(dxf_path)
    if "scale" not in (meta or {}) or scan is None or scan["doc"] is None:
        return []
    got = _dxf_boxes_kinds(scan, meta)
    return list(got[2]) if len(got) > 2 else []


def dxf_text_kinds(dxf_path, meta: dict) -> list:
    """dxf_text_boxes(…, None)과 같은 순서의 엔티티 꼴 목록 ('T'·'M'·'MF')."""
    scan = _dxf_scan(dxf_path)
    if "scale" not in (meta or {}) or scan is None or scan["doc"] is None:
        return []
    return list(_dxf_boxes_kinds(scan, meta)[1])


def _dxf_text_boxes_all(doc, meta: dict) -> tuple:
    """(글자 자리 목록, 그 엔티티 꼴 목록) — 꼴: 'T'(TEXT·ATTRIB), 'M'(MTEXT), 'MF'(서식 코드 든 MTEXT)."""
    out: list = []
    kinds: list = []
    fmts: list = []          # (서식 지문, 크기 서식) — 글자 자리와 같은 순서 (검토20 r03 4)
    matches = None
    k = 72.0 / _VIS_DPI
    _font_of: dict = {}

    def _style_font(e) -> str:
        nm = str(e.dxf.get("style", "Standard") or "Standard")
        got = _font_of.get(nm)
        if got is None:
            try:
                st = doc.styles.get(nm)
                got = f"{nm}|{st.dxf.get('font', '')}|{st.dxf.get('bigfont', '')}|{st.dxf.get('flags', 0)}" if st is not None else nm
            except Exception:                           # noqa: BLE001
                got = nm
            _font_of[nm] = got
        return got

    def _color_of(e) -> str:
        try:
            return f"{e.dxf.get('color', 256)}|{e.dxf.get('true_color', '')}"
        except Exception:                               # noqa: BLE001
            return ""

    def _box(x0: float, y0: float, x1: float, y1: float, rot: float = 0.0, cx: float = 0.0, cy: float = 0.0,
             ocs=None) -> _Region:
        if (rot and abs(rot) % 360 > 1e-6) or ocs is not None:
            # 돌린 글자 — 제자리 상자를 삽입점 둘레로 돌린 네 꼭짓점의 둘레 상자 (뒤흔들기 DXF C1: 돌려 그린 도면의 바뀐 Rev
            # 칸이 가려지지 않아 덤 '그림 변경'이 되고 'Rev만 갱신'이 사라졌다)
            c_, s_ = math.cos(math.radians(rot or 0.0)), math.sin(math.radians(rot or 0.0))
            pts = [(cx + (x - cx) * c_ - (y - cy) * s_, cy + (x - cx) * s_ + (y - cy) * c_)
                   for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))]
            if ocs is not None:
                # 거울 삽입·돌출 -Z 글자 — 상자는 OCS에서 세운 뒤 세계 좌표로 (검토20 r03 5: x 부호가 반대였다)
                pts = [(float(w_[0]), float(w_[1])) for w_ in (ocs.to_wcs((p_[0], p_[1], 0.0)) for p_ in pts)]
            x0, x1 = min(p_[0] for p_ in pts), max(p_[0] for p_ in pts)
            y0, y1 = min(p_[1] for p_ in pts), max(p_[1] for p_ in pts)
        px0 = (x0 - meta["x0"]) * meta["scale"] + meta["pad"]
        px1 = (x1 - meta["x0"]) * meta["scale"] + meta["pad"]
        py0 = (meta["y1"] - y1) * meta["scale"] + meta["pad"]
        py1 = (meta["y1"] - y0) * meta["scale"] + meta["pad"]
        return _Region(px0 * k, py0 * k, px1 * k, py1 * k)

    try:
        from ezdxf.lldxf.encoding import decode_dxf_unicode, has_dxf_unicode
    except Exception:                                   # noqa: BLE001
        decode_dxf_unicode = has_dxf_unicode = None

    def _plain(e) -> str:
        # 추출기와 같은 글자로 — R2000·R12의 '\U+C6A9'(한글)·'%%c'(Ø)를 그대로 두면 바뀐 글줄('STACK Φ350 …')과 맞지 않아
        # 그 자리가 가려지지 않고 덤 '그림 변경'이 났다 (벤치 dxf68 F04·A10)
        try:
            s = e.plain_text()
        except Exception:                               # noqa: BLE001
            s = e.dxf.text if e.dxftype() != "MTEXT" else e.text
        s = str(s or "")
        if decode_dxf_unicode is not None and has_dxf_unicode(s):
            s = decode_dxf_unicode(s)
        return s

    import unicodedata as _ud

    def _units(s: str) -> float:
        # 한글·한자(전각)는 그린 폭이 글자 높이의 약 1.4배다(맑은 고딕 실측 1.38) — 0.85로 세면 한글 글줄 변경의 뒤 절반이
        # 가림 밖으로 나가 덤 '그림 변경'이 났다 (검토68 A9)
        return sum(1.45 if _ud.east_asian_width(c) in ("W", "F") else 0.85 for c in s.rstrip())

    def _text_like(e):   # TEXT·ATTRIB: 삽입점 좌하단
        raw = _plain(e)
        txt = " ".join(raw.split())
        if txt and (matches is None or matches(txt)):
            ins = e.dxf.insert
            h = float(e.dxf.height or 3.0)
            # 폭은 공백을 접기 전의 원문 길이로 — "B    2026-09-04  WIRING ADDED"처럼
            # 칸을 띄운 리비전 행이 실제보다 4~5자 짧게 가려져 꼬리 글자가 '그림 변경'
            # 으로 찍히고 'Rev만 갱신' 판정을 막았다 (2026-09-04 사용자 관점 검토 #1).
            # 폭 계수·정렬도 반영하고 좌우로 한 글자씩 여유를 둔다
            try:
                wf = float(e.dxf.get("width", 1.0) or 1.0)
            except Exception:
                wf = 1.0
            units = _units(raw)
            w = max(units * h * wf, h) + 2 * h
            x_left = ins.x - h
            try:
                halign = int(e.dxf.get("halign", 0) or 0)
                ap = e.dxf.get("align_point", None)
                if halign in (1, 4) and ap is not None:       # 가운데
                    x_left = ap.x - w / 2
                elif halign == 2 and ap is not None:          # 오른쪽
                    x_left = ap.x - w + h
                elif halign in (3, 5) and ap is not None:     # 정렬·맞춤: 두 점 사이
                    x_left = min(ins.x, ap.x) - h
                    w = abs(ap.x - ins.x) + 2 * h
            except Exception:
                pass
            try:
                rot = float(e.dxf.get("rotation", 0) or 0)
            except Exception:                               # noqa: BLE001
                rot = 0.0
            ocs = None
            try:
                ex = e.dxf.get("extrusion", None)
                if ex is not None and (abs(float(ex[0])) > 1e-9 or abs(float(ex[1])) > 1e-9 or float(ex[2]) < 0):
                    ocs = e.ocs()
            except Exception:                               # noqa: BLE001
                ocs = None
            out.append((txt, _box(x_left, ins.y - h * 0.3, x_left + w, ins.y + h * 1.2, rot, ins.x, ins.y, ocs=ocs)))
            kinds.append("T")
            try:
                fmts.append((f"T|{_style_font(e)}|{_color_of(e)}|{float(e.dxf.get('oblique', 0) or 0):g}", ""))
            except Exception:                           # noqa: BLE001
                fmts.append(("", ""))

    from watcher.extract.dxf import const_attdefs

    def _const_like(c) -> None:
        # 블록 정의의 상수 속성 글자 — 추출기가 본문 글자로 읽으므로 그 자리도 글자 자리다 (검토20 r03 2)
        txt = " ".join(str(c[0]).split())
        if not txt or (matches is not None and not matches(txt)):
            return
        h = float(c[4] or 3.0)
        x, y = float(c[6]), float(c[7])            # 세계 좌표
        w = max(_units(str(c[0])) * h, h) + 2 * h
        out.append((txt, _box(x - h, y - h * 0.3, x - h + w, y + h * 1.2, float(c[5] or 0.0), x, y)))
        kinds.append("T")
        fmts.append(("", ""))

    nested_cache: dict = {}

    def _has_nested(name: str) -> bool:
        # 블록 정의 안에 속성 든 블록 삽입이 있나 — 있을 때만 펼친다(심볼 라이브러리 도면을 통째로 펼치지 않게)
        got = nested_cache.get(name)
        if got is None:
            got = nested_cache[name] = False             # 자기 자신을 품는 블록에서 돌지 않게
            try:
                blk = doc.blocks.get(name)
                if blk is not None:
                    for sub in blk.query("INSERT"):
                        if getattr(sub, "attribs", None) or _has_nested(str(sub.dxf.name)):
                            got = True
                            break
            except Exception:                           # noqa: BLE001
                got = False
            nested_cache[name] = got
        return got

    budget = [20_000]

    def _nested_attribs(ins, depth: int) -> None:
        # 틀 블록 안에 중첩한 표제란 블록(A3 틀 → 표제란)의 속성 — 최상위 삽입의 속성만 상자로 삼아 바뀐 REV·DATE 칸의 픽셀 차이가
        # '그림 변경'으로 남았다(거짓 'Rev 미갱신'·'Rev만 갱신' 침묵, 검토20 r03 1). 추출기의 블록 전개처럼 하위 삽입을 펼친다
        if depth <= 0 or budget[0] <= 0 or not _has_nested(str(getattr(ins.dxf, "name", "") or "")):
            return
        try:
            for ve in ins.virtual_entities():
                budget[0] -= 1
                if budget[0] <= 0:
                    return
                if ve.dxftype() == "INSERT":
                    for a in getattr(ve, "attribs", None) or []:
                        _text_like(a)
                    for c in const_attdefs(doc, ve, {str(getattr(a.dxf, "tag", "") or "").strip().upper()
                                                     for a in (getattr(ve, "attribs", None) or [])}):
                        _const_like(c)
                    _nested_attribs(ve, depth - 1)
        except Exception:                               # noqa: BLE001
            return

    for e in doc.modelspace():
        try:
            kind = e.dxftype()
            if kind == "TEXT":
                _text_like(e)
            elif kind == "INSERT":
                # 실무 도면의 표제란은 블록 속성(ATTRIB)이다 (2026-09-03 재검토)
                for a in e.attribs:
                    _text_like(a)
                for c in const_attdefs(doc, e, {str(getattr(a.dxf, "tag", "") or "").strip().upper() for a in e.attribs}):
                    _const_like(c)
                _nested_attribs(e, 3)
            elif kind == "MTEXT":
                plain = _plain(e)
                txt = " ".join(plain.split())
                if not txt or (matches is not None and not matches(txt)):
                    continue
                ins = e.dxf.insert
                h = float(e.dxf.char_height or 3.0)
                # 문단(\P)마다 한 줄, 폭이 정해져 있으면 그 폭에서 접힌다. 서식 코드('\fArial|b1;')를 글자 수로 세고
                # 한글 폭을 0.8로 쳐서, 여러 줄 MTEXT 표제란의 'REV: B'·한글 주석의 뒤쪽이 가림 밖으로 나갔다 (벤치 dxf68 A07·B06)
                paras = [p for p in plain.split("\n")] or [plain]
                widths = [_units(p) * h for p in paras]
                wid = float(e.dxf.get("width", 0) or 0)
                if wid > 0:
                    # 폭 추정은 낱말 단위 접힘·글자 크기 서식('\H1.2x;')을 모른다 — 넉넉히(1.2배) 세어 접힌 끝줄('F종')까지 가린다
                    nlines = sum(max(1, math.ceil(u * 1.2 / wid)) for u in widths)
                    w = wid if max(widths) > wid else max(max(widths), h)
                else:
                    # 폭 0인 MTEXT도 그리는 쪽(글꼴·'\H1.2x;' 서식)이 끝을 다음 줄로 넘길 때가 있다 — 한 줄 여유
                    # (벤치 fmt66 D14: '{\H1.2x;\L주기:\l} 전동기 절연등급 F종'의 'F종'이 아랫줄로)
                    nlines, w = len(paras) + (1 if max(widths) >= 8 * h else 0), max(max(widths), h)
                try:
                    lsf = float(e.dxf.get("line_spacing_factor", 1.0) or 1.0)
                except Exception:                       # noqa: BLE001
                    lsf = 1.0
                height = h + (nlines - 1) * h * 1.67 * lsf
                try:
                    ap = int(e.dxf.get("attachment_point", 1) or 1)
                except Exception:                       # noqa: BLE001
                    ap = 1
                col, row = (ap - 1) % 3, min(2, (ap - 1) // 3)
                x_left = ins.x - (0.0, w / 2, w)[col]
                y_top = ins.y + (0.0, height / 2, height)[row]
                try:
                    rot = float(e.get_rotation())
                except Exception:                       # noqa: BLE001
                    rot = 0.0
                out.append((txt, _box(x_left - h, y_top - height - h * 0.4, x_left + w + h, y_top + h * 0.3, rot, ins.x, ins.y)))
                _raw = re.sub(r"\\P", "", str(e.text or ""))
                kinds.append("MF" if ("{" in _raw or re.search(r"\\[A-OQ-Za-z]", _raw)) else "M")
                try:
                    # 크기·간격 서식(\\H 높이·\\W 폭·\\T 자간)은 진짜 변경이다 — 따로 두어 그것이 같을 때만 '서식만'으로 (검토61 T47 보호)
                    _sz = "".join(re.findall(r"\\[HWT][^;]*;", str(e.text or ""))) + f"|{h:g}|{float(e.dxf.get('width', 0) or 0):g}"
                    fmts.append((f"M|{_style_font(e)}|{_color_of(e)}|{str(e.text or '')}", _sz))
                except Exception:                       # noqa: BLE001
                    fmts.append(("", ""))
        except Exception:
            continue
    if len(fmts) != len(out):
        fmts = [("", "")] * len(out)
    return out, kinds, fmts


_GEOM_TYPES = {"LINE", "LWPOLYLINE", "POLYLINE", "CIRCLE", "ARC", "ELLIPSE", "SPLINE", "SOLID", "TRACE", "3DFACE"}


def _dxf_geom(dxf_path) -> list:
    """DXF 모형 공간의 글자 아닌 도형을 꺾은선 목록으로 [[(x, y), …], …] (도면 좌표) — 블록 참조는 한 단계 풀어서.
    글자 가림(마스크)이 그 자리의 **새 도형**(취소선·작은 원·새 선)까지 지우지 않게 쓴다 (검토69 B V4·V4b·V5)."""
    scan = _dxf_scan(dxf_path)
    if scan is None or scan["doc"] is None:
        return []
    with _DXF_LOCK:
        if scan["geom"] is not None:
            return scan["geom"]
    out: list = []

    def _add(e, depth=0):
        kind = e.dxftype()
        try:
            if kind == "LINE":
                out.append([(e.dxf.start.x, e.dxf.start.y), (e.dxf.end.x, e.dxf.end.y)])
            elif kind == "LWPOLYLINE":
                pts = [(p[0], p[1]) for p in e.get_points("xy")]
                if e.closed and pts:
                    pts.append(pts[0])
                if len(pts) >= 2:
                    out.append(pts)
            elif kind in ("CIRCLE", "ARC"):
                c, r = e.dxf.center, float(e.dxf.radius)
                a0, a1 = (0.0, 360.0) if kind == "CIRCLE" else (float(e.dxf.start_angle), float(e.dxf.end_angle))
                if a1 <= a0:
                    a1 += 360.0
                n = max(8, min(256, int((a1 - a0) / 6)))
                out.append([(c.x + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
                             c.y + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)])
            elif kind in ("POLYLINE", "ELLIPSE", "SPLINE"):
                try:
                    from ezdxf import path as _ezpath
                    pts = [(v.x, v.y) for v in _ezpath.make_path(e).flattening(0.05)]
                except Exception:                       # noqa: BLE001
                    pts = []
                if len(pts) >= 2:
                    out.append(pts)
            elif kind in ("SOLID", "TRACE", "3DFACE"):
                vs = [e.dxf.get(f"vtx{i}") for i in range(4)]
                pts = [(v.x, v.y) for v in vs if v is not None]
                if len(pts) >= 2:
                    out.append(pts + [pts[0]])
            elif kind == "INSERT" and depth < 2:
                for v in e.virtual_entities():
                    if v.dxftype() in _GEOM_TYPES or v.dxftype() == "INSERT":
                        _add(v, depth + 1)
        except Exception:                               # noqa: BLE001
            return
    try:
        for e in scan["doc"].modelspace():
            if e.dxftype() in _GEOM_TYPES or e.dxftype() == "INSERT":
                _add(e)
                if len(out) > 200_000:
                    break
    except Exception:                                   # noqa: BLE001
        pass
    with _DXF_LOCK:
        scan["geom"] = out
    return out


def _geom_new_blocks(src, pno: int, old_gray, cand: set, dys=(0,)) -> set:
    """새 판 DXF의 글자 아닌 도형이 지나가는데 옛 그림엔 그 자리(1픽셀 이웃, dys 중 어느 밀림으로든)에 잉크가 없는 블록 —
    거기 픽셀 차이는 글자 다시 그림·행 밀림이 아니라 **새로 그린 도형**이다. cand(가릴 후보 블록)만 본다."""
    if not cand or not isinstance(src, _RenderSource) or not src._dxf_path or pno != 1:
        return set()
    meta = src.meta(pno)
    if "scale" not in meta:
        return set()
    import numpy as np
    geom = _dxf_geom(src._dxf_path)
    if not geom:
        return set()
    s, x0, y1, pad = float(meta["scale"]), float(meta["x0"]), float(meta["y1"]), float(meta["pad"])
    h, w = old_gray.shape
    ink = old_gray < 230
    # 1픽셀 이웃까지 잉크로 (안티앨리어싱·반올림)
    ip = np.pad(ink, 1, mode="constant", constant_values=False)
    ink_d = np.logical_or.reduce([ip[1 + oy:1 + oy + h, 1 + ox:1 + ox + w] for oy in (-1, 0, 1) for ox in (-1, 0, 1)])
    bx0 = min(b[0] for b in cand) * _VIS_BLOCK
    bx1 = (max(b[0] for b in cand) + 1) * _VIS_BLOCK
    by0 = min(b[1] for b in cand) * _VIS_BLOCK
    by1 = (max(b[1] for b in cand) + 1) * _VIS_BLOCK
    miss: Counter = Counter()
    for pts in geom:
        arr = np.asarray(pts, dtype=float)
        px = (arr[:, 0] - x0) * s + pad
        py = (y1 - arr[:, 1]) * s + pad
        if px.max() < bx0 - 1 or px.min() > bx1 + 1 or py.max() < by0 - 1 or py.min() > by1 + 1:
            continue
        for i in range(len(arr) - 1):
            ax, ay, bx, by = px[i], py[i], px[i + 1], py[i + 1]
            if max(ax, bx) < bx0 - 1 or min(ax, bx) > bx1 + 1 or max(ay, by) < by0 - 1 or min(ay, by) > by1 + 1:
                continue
            n = int(max(abs(bx - ax), abs(by - ay))) + 1
            if n > 20000:
                n = 20000
            t = np.linspace(0.0, 1.0, n + 1)
            xs = np.rint(ax + (bx - ax) * t).astype(int)
            ys = np.rint(ay + (by - ay) * t).astype(int)
            ok = (xs >= 0) & (xs < w) & (ys >= 0) & (ys < h)
            xs, ys = xs[ok], ys[ok]
            if not len(xs):
                continue
            blk = set(zip((xs // _VIS_BLOCK).tolist(), (ys // _VIS_BLOCK).tolist()))
            if not (blk & cand):
                continue
            lack = np.ones(len(xs), dtype=bool)
            for dy in dys:
                yy = ys + int(dy)
                okk = (yy >= 0) & (yy < h)
                hit = np.zeros(len(xs), dtype=bool)
                hit[okk] = ink_d[yy[okk], xs[okk]]
                lack &= ~hit
            for bxx, byy in zip((xs[lack] // _VIS_BLOCK).tolist(), (ys[lack] // _VIS_BLOCK).tolist()):
                if (bxx, byy) in cand:
                    miss[(bxx, byy)] += 1
    return {b for b, c in miss.items() if c >= 3}


def attach_text_boxes(dxf_path, pages) -> None:
    """기록할 DXF 그림에 글자 자리를 함께 저장 — 이 판이 나중에 '옛 판'이 됐을 때 지워진 글줄의
    자리를 가릴 수 있게 (검토21 재검증 D9). 글자 최대 3,000개까지."""
    try:
        if not pages or "scale" not in (pages[0].meta or {}):
            return
        boxes = dxf_text_boxes(dxf_path, pages[0].meta, None)[:3000]
        pages[0].meta["tboxes"] = [[t, round(r.x0, 1), round(r.y0, 1), round(r.x1, 1), round(r.y1, 1)]
                                   for t, r in boxes]
        # 엔티티 꼴(TEXT·MTEXT·서식 MTEXT)도 — 다음 판과 비교할 때 'TEXT를 서식 MTEXT로 바꿔 다시 그림'과 '같은 TEXT의 글자 크기
        # 변경'을 가른다 (검토69). tboxes와 같은 순서·길이
        pages[0].meta["tkinds"] = dxf_text_kinds(dxf_path, pages[0].meta)[:len(boxes)]
        # 서식 지문도 — 다음 판과 비교할 때 글꼴·색·굵기만 바뀐 글자를 가른다 (검토20 r03 4). 옛 기록엔 없다(그때는 가리지 않는다)
        _f = dxf_text_fmts(dxf_path, pages[0].meta)[:len(boxes)]
        if len(_f) == len(boxes):
            pages[0].meta["tfmts"] = [list(x) for x in _f]
    except Exception:
        pass


def _block_rect(b, scale: float) -> _Region:
    return _Region(b[0] * _VIS_BLOCK * scale, b[1] * _VIS_BLOCK * scale,
                   (b[0] + 1) * _VIS_BLOCK * scale, (b[1] + 1) * _VIS_BLOCK * scale)


def _group_rect(group, scale: float) -> _Region:
    xs = [g[0] for g in group]
    ys = [g[1] for g in group]
    return _Region(min(xs) * _VIS_BLOCK * scale, min(ys) * _VIS_BLOCK * scale,
                   (max(xs) + 1) * _VIS_BLOCK * scale, (max(ys) + 1) * _VIS_BLOCK * scale)


def _overlaps(a: _Region, b: _Region, pad: float = 8.0) -> bool:
    return not (a.x1 + pad < b.x0 or b.x1 + pad < a.x0 or a.y1 + pad < b.y0 or b.y1 + pad < a.y0)


def _line_boxes(src, pno: int) -> list:
    """쪽의 글줄 자리 [(글줄, _Region)] — PDF 파일은 지금 읽고, 기록된 옛 PDF 판은 기록 때 저장한 자리(meta['tboxes']).
    DXF는 빈 목록(이 처리를 하지 않는다)."""
    try:
        if isinstance(src, _PdfSource):
            from watcher.render import page_text_boxes
            if int(src._page(pno).get_rotation() or 0) % 360:
                return []                       # 회전 쪽은 기록된 글자 자리(돌리기 전 좌표)와 그림 좌표가 다르다
            rows = page_text_boxes(src._page(pno), float(src.size(pno)[1]))
        elif isinstance(src, _RenderSource) and not src._dxf_path and "scale" not in src.meta(pno):
            rows = src.meta(pno).get("tboxes") or []
        else:
            return []
        out = []
        for e in rows:
            t, x0, y0, x1, y1 = e
            out.append((" ".join(str(t).split()), _Region(float(x0), float(y0), float(x1), float(y1))))
        return out
    except Exception:
        return []


def _same_text_mask(os_, ns_, opno: int, pno: int, shape, blocks: set, scale: float, a=None, b=None,
                    hl_out: set | None = None, long_rects=()):
    """옛 판과 새 판에서 **같은 글줄이 같은 자리(1pt 안)**에 있는 사각형들의 픽셀 마스크 — 바뀐 블록이 그 자리에
    닿을 때만 만든다(없으면 None). 글자가 같은 자리의 픽셀 차이는 글자를 그리는 방식(낱말마다 따로·글꼴 별칭)의
    차이다 (검토68 B5). 다른 글줄·움직인 글줄은 넣지 않는다.
    a·b(옛·새 그레이)를 주면 한쪽에만 있는 가로선(취소선·밑줄)이 지나는 자리는 마스크에서 빼고, hl_out에 그 선이 지나는
    블록을 더한다(바뀐 블록이 없어도) — 빽빽한 낱말('1500') 위 짧은 취소선은 1픽셀 비교에서도 블록마다 바뀐 픽셀이 8개가 안 돼
    아예 안 잡혔다 (갈래 C C70_S1)."""
    if not blocks and (a is None or b is None or hl_out is None):
        return None
    nb_ = _line_boxes(ns_, pno)
    ob = _line_boxes(os_, opno)
    if LAYOUT_ALIGN:
        # 추출기와 같은 줄 묶기 글줄도 — 글자를 두 번 겹쳐 그리거나 차례를 바꿔 그린 판은 그린 순서 글줄(tboxes)이 서로 맞지 않아
        # 같은 자리의 같은 글이 '그림 변경'으로 남았다 (2026-10-23 뒤흔들기 C5)
        _nl, _ol = _layout_line_boxes(ns_, pno), _layout_line_boxes(os_, opno)
        if _nl and _ol:
            nb_, ob = list(nb_) + _nl, list(ob) + _ol
    lay_ids = {id(r) for _t, r in (_nl or [])} if LAYOUT_ALIGN and _nl and _ol else set()

    def _long(r) -> bool:
        return id(r) in lay_ids or any(_overlaps(r, q, pad=0.0) and min(r.y1, q.y1) - max(r.y0, q.y0) > 0.5 * (r.y1 - r.y0)
                                       for q in long_rects)
    if not nb_ or not ob:
        return None
    tol = 1.0
    by_text: dict = {}
    for t, r in ob:
        by_text.setdefault(t, []).append(r)
    # 끝(x1)은 글줄 길이의 3%까지 — 다른 프로그램의 TJ 커닝은 글자 사이를 조금씩 밀어 줄 끝이 1~2pt 어긋난다
    # (벤치 fmt66 P11: 'DWG NO: E-101'이 1.4pt 길어져 덤 '그림 변경')
    same = [r for t, r in nb_
            if any(abs(r.x0 - q.x0) <= tol and abs(r.y0 - q.y0) <= tol
                   and abs(r.x1 - q.x1) <= max(tol, 0.03 * (r.x1 - r.x0))
                   and abs(r.y1 - q.y1) <= tol for q in by_text.get(t, ()))]
    if not same:
        return None
    touch = bool(blocks) and any(_overlaps(_block_rect(bk, scale), r, pad=0.0) for bk in blocks for r in same)
    if not touch and hl_out is None:
        return None
    import numpy as np
    m = np.zeros(shape, dtype=bool)
    h, w = shape
    for r in same:
        x0, y0 = max(0, int(r.x0 / scale)), max(0, int(r.y0 / scale))
        x1, y1 = min(w, int(math.ceil(r.x1 / scale)) + 1), min(h, int(math.ceil(r.y1 / scale)) + 1)
        if x1 > x0 and y1 > y0:
            m[y0:y1, x0:x1] = True
            if a is not None and b is not None:
                # 추출기 글줄(칸 사이를 이은 표 행)·자간을 다시 잡은 글줄은 글자 아랫부분이 이어져 짧은 '가로선'으로 보인다 — 줄
                # 길이의 절반 넘게 이어진 선(취소선·밑줄)만
                mr = max(20, (x1 - x0) // 2) if _long(r) else None
                for ly, sx0, sx1 in _new_hline_segs(a[y0:y1, x0:x1], b[y0:y1, x0:x1], min_run=mr):
                    m[y0 + max(0, ly - 1):y0 + ly + 3, x0 + max(0, sx0 - 2):x0 + sx1 + 2] = False
                    if hl_out is not None:
                        py = y0 + ly
                        hl_out.update((bx, py // _VIS_BLOCK) for bx in range((x0 + sx0) // _VIS_BLOCK,
                                                                              (x0 + sx1 - 1) // _VIS_BLOCK + 1))
    return m if touch else None


_HLINE_INK = 200        # 가로선 찾기에서 '잉크'로 보는 명도 상한 (0.3pt 가는 선의 안티앨리어싱 회색까지)
_HLINE_OLD_MAX = 0.6    # 다른 판의 같은 칸들(±2px 줄)이 이보다 덜 덮였으면 '새로 그은 선'


def _new_hline_segs(oa, ob, min_run: int | None = None) -> list:
    """글줄 자리(같은 크기 두 조각)에서 한쪽 판에만 있는 **가로선** 조각들 [(줄 y, x0, x1)] (조각 안 픽셀 좌표).
    한 픽셀 줄(두 줄 y·y+1 중 하나라도 잉크)에서 잉크가 글줄 높이의 1.5배(12px 이상) 넘게 끊김 없이 이어진 구간을 찾고, 다른 판의
    같은 칸들이 같은 높이(±2px)에서 60%도 안 덮였으면 새로 그은 선이다. 글자 획은 같은 글이 같은 자리에 있으니 두 판에 다 있어
    걸리지 않는다(밑줄 글자 '____'·글자 가로획도 두 판에 같이 있다). 글자 위 취소선이 같은 글줄 2px 느슨한 비교에 '글자 잉크'로
    가려져 '글자·표·그림 동일'이 됐다 (검토69 B V3)."""
    import numpy as np
    hh, ww = oa.shape
    if hh < 2 or ww < 12:
        return []
    min_run = max(12, int(1.5 * hh)) if min_run is None else min_run

    def two(g):
        ink = g < _HLINE_INK
        return ink[:-1] | ink[1:]                    # 0.8pt 선은 두 픽셀 줄에 걸쳐 회색으로 나뉜다

    ia, ib = two(oa), two(ob)
    n = ia.shape[0]
    out: list = []
    for new_, old_ in ((ib, ia), (ia, ib)):
        for y in range(n):
            row = new_[y]
            if int(row.sum()) < min_run:
                continue
            d = np.diff(np.concatenate(([0], row.astype(np.int8), [0])))
            starts, ends = np.nonzero(d == 1)[0], np.nonzero(d == -1)[0]
            for x0, x1 in zip(starts, ends):
                if x1 - x0 < min_run:
                    continue
                cov = float(old_[max(0, y - 2):y + 3, x0:x1].mean(axis=1).max())
                if cov < _HLINE_OLD_MAX:
                    out.append((y, int(x0), int(x1)))
    return out


def _all_text_rects(src, pno: int) -> list:
    """쪽의 모든 글자 자리 [(글줄, _Region)] — PDF(파일·기록), DXF(파일·기록 tboxes) 모두. 표 행 밀림 판정용."""
    return _all_text_rects_k(src, pno)[0]


def _all_text_rects_k(src, pno: int) -> tuple:
    """(_all_text_rects, 같은 순서의 엔티티 꼴 목록 — 꼴을 모르면 None)."""
    if isinstance(src, _RenderSource) and src._dxf_path:
        meta = src.meta(pno)
        if pno != 1 or "scale" not in meta:
            return [], None
        try:
            rows = [(" ".join(t.split()), r) for t, r in dxf_text_boxes(src._dxf_path, meta, None)[:3000]]
            kinds = dxf_text_kinds(src._dxf_path, meta)[:len(rows)]
            return rows, (kinds if len(kinds) == len(rows) else None)
        except Exception:                                   # noqa: BLE001
            return [], None
    if isinstance(src, _RenderSource):
        out, kinds = [], []
        tk = src.meta(pno).get("tkinds")
        tb = src.meta(pno).get("tboxes") or []
        if not isinstance(tk, list) or len(tk) != len(tb):
            tk = None
        for k, e in enumerate(tb):
            try:
                t, x0, y0, x1, y1 = e
                out.append((" ".join(str(t).split()), _Region(float(x0), float(y0), float(x1), float(y1))))
                kinds.append(tk[k] if tk is not None else None)
            except (TypeError, ValueError):
                continue
        return out, (kinds if tk is not None else None)
    return _line_boxes(src, pno), None


def _added_text_rects(ot: list, nt: list) -> list:
    """한쪽 판에만 **더 많이** 있는 글자 객체의 자리 — 그 판의 그 글자 상자만. 개정표에 행을 붙이면 새 행의 설명·작성자
    ('재발행'·'김도현')는 윗 행과 같은 글이라 글줄 대칭차(cli._changed_texts)에서 지워져 가려지지 않았고, 행 밀림의 맞닿음 근거도
    없어 머리글이 밀린 자리가 덤 '그림 변경'이 됐다 (대량 시험 DXF C9, 2026-10-20). 같은 글이 다른 판의 같은 자리(1pt)에 있는
    객체는 넣지 않는다 — 글자로 찾아 어디서든 가리지 않는다(검토69: 넓은 가림이 진짜 그림 변경을 숨김)."""
    def same_place(r, q) -> bool:
        return abs(q.x0 - r.x0) <= 1 and abs(q.y0 - r.y0) <= 1
    oc = Counter(t for t, _ in ot)
    nc = Counter(t for t, _ in nt)
    out: list = []
    for one, other, c_one, c_other in ((nt, ot, nc, oc), (ot, nt, oc, nc)):
        by_text: dict = {}
        for t, q in other:
            by_text.setdefault(t, []).append(q)
        cand: dict = {}
        for t, r in one:
            if not t.strip() or c_one[t] <= c_other.get(t, 0):
                continue
            if any(same_place(r, q) for q in by_text.get(t, ())):
                continue
            cand.setdefault(t, []).append(r)
        for t, rs in cand.items():
            # 늘어난 개수만큼만 — 다른 판의 같은 글에서 가장 먼 것부터(옮겨 간 같은 글은 가까이 짝이 있다)
            k = c_one[t] - c_other.get(t, 0)
            qs = by_text.get(t, ())

            def far(r):
                return min((abs(q.x0 - r.x0) + abs(q.y0 - r.y0) for q in qs), default=float("inf"))
            out.extend(sorted(rs, key=far, reverse=True)[:k])
    return out


def _text_fmts(src, pno: int, n: int):
    """_all_text_rects(src, pno)와 같은 순서의 서식 지문 목록(길이 n) — 모르면(옛 기록·PDF) None."""
    try:
        if isinstance(src, _RenderSource) and src._dxf_path:
            meta = src.meta(pno)
            if pno != 1 or "scale" not in meta:
                return None
            f = dxf_text_fmts(src._dxf_path, meta)[:n]
        elif isinstance(src, _RenderSource):
            f = src.meta(pno).get("tfmts")
            if not isinstance(f, list) or len(f) != len(src.meta(pno).get("tboxes") or []):
                return None
            f = f[:n]
        else:
            return None
        return [tuple(x) if isinstance(x, (list, tuple)) and len(x) == 2 else ("", "") for x in f] if len(f) == n else None
    except Exception:                                       # noqa: BLE001
        return None


FORMAT_ONLY_MASK = True     # 시험용 끔 스위치 — 끄면 서식만 바뀐 글자도 그림 변경으로 남는다(고치기 전)


def _format_only_rects(ot: list, nt: list, ofmts, nfmts) -> tuple:
    """글자·자리·크기는 같고 서식(글꼴 STYLE·색·MTEXT \\f \\C 굵게)만 바뀐 글자의 자리 → (자리 목록, 그 글 목록).
    회사가 CAD 표준 글꼴을 바꾼 날 모든 도면이 '그림 변경 → Rev 미갱신'에 올랐다 (검토20 r03 4). 크기(\\H·높이)·자리 변화는
    진짜 변경이라 가리지 않는다(검토61 T47) — 자리 상자가 1pt 안에서 같고 크기 서식이 같을 때만."""
    if not FORMAT_ONLY_MASK or not ofmts or not nfmts:
        return [], []

    def same_place(r, q) -> bool:
        return abs(q.x0 - r.x0) <= 1 and abs(q.y0 - r.y0) <= 1 and abs(q.x1 - r.x1) <= 1 and abs(q.y1 - r.y1) <= 1
    by_text: dict = {}
    for i, (t, q) in enumerate(ot):
        by_text.setdefault(t, []).append(i)
    rects, texts = [], []
    for j, (t, r) in enumerate(nt):
        if len("".join(t.split())) < 2 or not nfmts[j][0]:
            continue
        for i in by_text.get(t, ()):
            q = ot[i][1]
            if not same_place(r, q) or not ofmts[i][0]:
                continue
            fo, fn = ofmts[i], nfmts[j]
            if fo[0] != fn[0] and fo[1] == fn[1] and fo[0][:2] == fn[0][:2]:     # 같은 엔티티 꼴(TEXT↔TEXT·MTEXT↔MTEXT)
                rects += [r, q]
                texts.append(t)
            break
    return rects, texts


def _rerendered_text_rects(ot: list, nt: list, okinds=None, nkinds=None) -> list:
    """글자는 그대로인데 그리는 꼴만 바뀐 자리 — 다른 CAD가 TEXT 여러 개를 서식 MTEXT 하나로 바꿔 쓰면('주기:' +
    '전동기 절연등급 F종' → '{\\L주기:\\l} 전동기 절연등급 F종') 글자 크기·밑줄·간격이 달라져 픽셀이 바뀐다. 한 쪽의 글줄
    하나와, 그와 겹치는 다른 쪽 글줄들을 이어 붙인 글(띄어쓰기 빼고)이 같으면 그 자리들을 돌려준다 (벤치 fmt66 D14).
    같은 글이 같은 자리(1pt)에 그대로 있는 것은 넣지 않는다 — 그 자리 픽셀은 원래 같다."""
    def key(s: str) -> str:
        return "".join(s.split())

    def same_place(r, q) -> bool:
        return abs(q.x0 - r.x0) <= 1 and abs(q.y0 - r.y0) <= 1 and abs(q.x1 - r.x1) <= 1 and abs(q.y1 - r.y1) <= 1

    cell = 50.0
    out: list = []
    for one, many, k_one, k_many in ((nt, ot, nkinds, okinds), (ot, nt, okinds, nkinds)):
        # 격자 색인 — 글자 3,000개 도면에서 n×m 겹침 검사가 그림 비교 시간을 세 배로 늘렸다 (검토69 성능 a)
        grid: dict = {}
        by_text: dict = {}
        for idx, (t2, q) in enumerate(many):
            by_text.setdefault(t2, []).append(q)
            for gx in range(int((q.x0 - 2) // cell), int((q.x1 + 2) // cell) + 1):
                for gy in range(int((q.y0 - 2) // cell), int((q.y1 + 2) // cell) + 1):
                    grid.setdefault((gx, gy), []).append(idx)
        for ti, (t, r) in enumerate(one):
            k = key(t)
            if len(k) < 2:
                continue
            if any(same_place(r, q) for q in by_text.get(t, ())):
                continue                        # 같은 글이 같은 자리 — 그 자리 픽셀은 원래 같다
            idxs = {i for gx in range(int((r.x0 - 2) // cell), int((r.x1 + 2) // cell) + 1)
                    for gy in range(int((r.y0 - 2) // cell), int((r.y1 + 2) // cell) + 1)
                    for i in grid.get((gx, gy), ())}
            hits = [(many[i][0], many[i][1], i) for i in sorted(idxs) if _overlaps(r, many[i][1], pad=2.0)]
            # 한 덩이 ↔ **여러** 글줄일 때만 — 같은 글 하나가 크기·자리만 바뀐 것(글자 높이 4→6, ' 55kW')은 다시 그림이
            # 아니라 진짜 변경이다. 하나↔하나까지 가려 '내용 변경 없음(그림 동일)'으로 조용해졌다 (검토61 A T47·T04, 검토66 C144)
            if len(hits) < 2:
                # 하나↔하나는 엔티티 꼴이 TEXT ↔ 서식 MTEXT로 바뀐 것(다른 CAD 변환, fmt66 D14)일 때만 — 꼴을 모르면(옛 기록)
                # 가리지 않는다
                if not (len(hits) == 1 and k_one is not None and k_many is not None
                        and {k_one[ti], k_many[hits[0][2]]} == {"T", "MF"}):
                    continue
            hits.sort(key=lambda h: (round(h[1].y0 / 4), h[1].x0))
            if "".join(key(h[0]) for h in hits) == k:
                out.append(r)
                out.extend(h[1] for h in hits)
    return out


_SHIFT_MAX_PT = 150.0     # 표 한 행 높이로 볼 수 있는 밀림의 상한(pt)
_WIDE_SHIFT_PT = 300.0    # 옆 열 밀림 근거를 찾는 가로 범위(pt) — 0이면 끔 (대량 시험 DXF C9)
_INK = 170                 # 행 밀림 판정에서 '잉크'로 보는 명도 상한


def _shift_candidates(rect: _Region, ot: list, nt: list, scale: float, spacing: bool = True) -> list:
    """묶음 근처 글자에서 '행 밀림' 후보 dy(px, 새 판 y ↔ 옛 판 y+dy) — ①같은 글줄이 옛 판·새 판에서 옮겨 간 거리,
    ②묶음과 가로로 겹치는 글줄들의 줄 간격(행 높이). spacing=False면 ①만 — 행이 실제로 밀렸다는 증거(같은 글줄이 dy만큼
    옮겨 감)가 있을 때만. DXF는 ①만 쓴다: 글줄 간격만으로 '밀림'을 지어 그 간격만큼 옮긴 심볼·지운 표 선이 사라졌다
    (검토69 r7·B V2c)."""
    def near(r: _Region) -> bool:
        return (r.x1 >= rect.x0 - 20 and r.x0 <= rect.x1 + 20
                and r.y1 >= rect.y0 - _SHIFT_MAX_PT and r.y0 <= rect.y1 + _SHIFT_MAX_PT)
    cands: set = set()
    on = Counter(t for t, _ in ot)
    nn = Counter(t for t, _ in nt)
    o1 = {t: r for t, r in ot if on[t] == 1 and near(r)}
    o_all: dict = {}
    for t, r in ot:
        if near(r):
            o_all.setdefault(t, []).append(r)
    for t, r in nt:
        q = o1.get(t)
        if q is not None and nn[t] == 1 and near(r) and abs(q.x0 - r.x0) <= 2.0:
            d = q.y0 - r.y0
            if 2 * scale <= abs(d) <= _SHIFT_MAX_PT:
                cands.add(int(round(d / scale)))
        elif near(r) and (on[t] > 1 or nn[t] > 1):
            # 같은 글이 쪽에 여럿('REV'·'DATE'는 표제란 라벨이자 개정표 머리글) — 같은 왼쪽 끝의 옛 글이 하나뿐이고 제자리에는
            # 없을 때만 그 글이 옮겨 간 것으로 본다. 개정표에 행을 붙여 머리글이 한 행 올라간 자리가 덤 '그림 변경'이 됐다
            # (대량 시험 DXF C9, 2026-10-20)
            col = [q2 for q2 in o_all.get(t, ()) if abs(q2.x0 - r.x0) <= 2.0]
            if len(col) == 1 and not any(abs(q2.y0 - r.y0) <= 1.0 for q2 in col) \
                    and sum(1 for t2, r2 in nt if t2 == t and abs(r2.x0 - r.x0) <= 2.0 and near(r2)) == 1:
                d = col[0].y0 - r.y0
                if 2 * scale <= abs(d) <= _SHIFT_MAX_PT:
                    cands.add(int(round(d / scale)))
    if not cands and not spacing and _WIDE_SHIFT_PT > 0:
        # 같은 표의 옆 열 — 수량 열('4'·'1'·'2')처럼 같은 글이 여럿이라 ①이 비면, 같은 높이 띠(행 높이 범위)에서 가로 300pt 안의
        # 하나뿐인 글 **둘 이상**이 같은 거리만큼 옮겨 갔을 때만 그 거리를 후보로 (대량 시험 DXF C9 칸마다 글자인 부품표, 2026-10-20).
        # 후보일 뿐 — 양방향 픽셀 대조·바뀐 글줄 맞닿음·새 도형 관문은 그대로 거친다
        def wide(r: _Region) -> bool:
            return (r.x1 >= rect.x0 - _WIDE_SHIFT_PT and r.x0 <= rect.x1 + _WIDE_SHIFT_PT
                    and r.y1 >= rect.y0 - _SHIFT_MAX_PT and r.y0 <= rect.y1 + _SHIFT_MAX_PT)
        ow = {t: r for t, r in ot if on[t] == 1 and wide(r)}
        votes: Counter = Counter()
        for t, r in nt:
            q = ow.get(t)
            if q is not None and nn[t] == 1 and wide(r) and abs(q.x0 - r.x0) <= 2.0:
                d = q.y0 - r.y0
                if 2 * scale <= abs(d) <= _SHIFT_MAX_PT:
                    votes[int(round(d / scale))] += 1
        cands.update(k for k, n in votes.items() if n >= 2)
    if spacing:
        for lst in (ot, nt):
            ys = sorted({round(r.y0, 1) for _t, r in lst if near(r)})
            for y_a, y_b in zip(ys, ys[1:]):
                d = y_b - y_a
                if 2 * scale <= d <= _SHIFT_MAX_PT:
                    k = int(round(d / scale))
                    cands.update((k, -k))
    else:
        # ③ 표 끝에 붙인(지운) 행 — 한쪽에만 있는 글이 다른 쪽에선 **빈 자리**에 놓였고, 같은 쪽의 바로 위·아래 행(같은 왼쪽 끝)과
        # 한 행 간격 d만큼 떨어져 있으면 그 표가 d만큼 늘었다(줄었다). 아래로 자라는 개정표에 행을 붙이면 옮겨 간 글줄이 없어
        # ①이 비었다 (held69 D07). 제자리 글자 변경('M-102'→'M-109')은 빈 자리가 아니라 여기 들지 않는다 (검토69 r7)
        for one, other in ((nt, ot), (ot, nt)):
            other_keys = Counter(t for t, _ in other)
            one_keys = Counter(t for t, _ in one)
            for t, r in one:
                if not near(r) or one_keys[t] <= other_keys.get(t, 0):
                    continue
                if any(_overlaps(r, q, pad=0.0) for _t2, q in other):
                    continue
                for _t2, q in one:
                    if q is r or abs(q.x0 - r.x0) > 2.0:
                        continue
                    d = r.y0 - q.y0
                    if 2 * scale <= abs(d) <= _SHIFT_MAX_PT and not any(
                            abs(q2.x0 - q.x0) <= 2.0 and 0 < abs(q2.y0 - q.y0) < abs(d) - 1 and (q2.y0 - q.y0) * d > 0
                            for _t3, q2 in one):
                        k = int(round(d / scale))
                        cands.update((k, -k))
    out: set = set()
    for k in cands:
        out.update((k - 1, k, k + 1))
    out.discard(0)
    return sorted(out, key=abs)[:40]


def _rect_mask(shape, rects, scale: float, dy_px: int = 0, pad_px: int = 1):
    import numpy as np
    h, w = shape
    m = np.zeros(shape, dtype=bool)
    for r in rects:
        x0 = max(0, int(r.x0 / scale) - pad_px)
        x1 = min(w, int(math.ceil(r.x1 / scale)) + pad_px + 1)
        y0 = max(0, int(r.y0 / scale) - pad_px - dy_px)
        y1 = min(h, int(math.ceil(r.y1 / scale)) + pad_px + 1 - dy_px)
        if x1 > x0 and y1 > y0:
            m[y0:y1, x0:x1] = True
    return m


def _rect_mask_win(win, rect_sets, scale: float, pad_px: int = 1):
    """창(win = 픽셀 x0, y0, x1, y1) 크기의 가림 — 쪽 전체 크기로 만들면 묶음×dy마다 A1 한 장 크기 배열을 채워 느렸다
    (검토69 성능 a). rect_sets = [(사각형 목록, dy_px), …]."""
    import numpy as np
    wx0, wy0, wx1, wy1 = win
    m = np.zeros((max(0, wy1 - wy0), max(0, wx1 - wx0)), dtype=bool)
    for rects, dy_px in rect_sets:
        for r in rects:
            x0 = max(wx0, int(r.x0 / scale) - pad_px)
            x1 = min(wx1, int(math.ceil(r.x1 / scale)) + pad_px + 1)
            y0 = max(wy0, int(r.y0 / scale) - pad_px - dy_px)
            y1 = min(wy1, int(math.ceil(r.y1 / scale)) + pad_px + 1 - dy_px)
            if x1 > x0 and y1 > y0:
                m[y0 - wy0:y1 - wy0, x0 - wx0:x1 - wx0] = True
    return m


def _group_window(shape, group):
    h, w = shape
    xs = [g[0] for g in group]
    ys = [g[1] for g in group]
    return (min(xs) * _VIS_BLOCK, min(ys) * _VIS_BLOCK,
            min(w, (max(xs) + 1) * _VIS_BLOCK), min(h, (max(ys) + 1) * _VIS_BLOCK))


def _shifted_same(dst, src, group, dy: int, ignore, inplace_ignore=None, line_min_run: int = 12) -> bool:
    """묶음 블록마다 dst[y, x] ≈ src[y + dy, x] (1픽셀 허용, ignore 자리는 빼고) — 바뀐 블록이 하나도 안 남으면 참.
    ignore는 묶음 창(_group_window) 크기의 가림."""
    import numpy as np
    h, w = dst.shape
    x0, y0, x1, y1 = _group_window(dst.shape, group)
    # 1픽셀 이웃까지 보려고 한 칸 넓혀 자른다. 페이지 밖은 흰 종이
    sy0, sy1 = y0 + dy - 1, y1 + dy + 1
    sx0, sx1 = x0 - 1, x1 + 1
    if sy0 < -2 or sy1 > h + 2:
        return False
    hh, ww = y1 - y0, x1 - x0
    s = np.full((hh + 2, ww + 2), 255, dtype=np.int16)
    cy0, cy1, cx0, cx1 = max(0, sy0), min(h, sy1), max(0, sx0), min(w, sx1)
    if cy1 > cy0 and cx1 > cx0:
        s[cy0 - sy0:cy1 - sy0, cx0 - sx0:cx1 - sx0] = src[cy0:cy1, cx0:cx1]
    d = dst[y0:y1, x0:x1].astype(np.int16)
    if d.shape != (hh, ww):
        return False
    # 밀린 선은 소수점 자리에 놓여 안티앨리어싱 농도가 달라진다(1픽셀 검정 ↔ 2픽셀 회색) — 명도 차가 아니라 '잉크가 1픽셀
    # 이웃 안에 있나'를 양쪽으로 본다
    ink_s = s < _INK
    ink_d = d < _INK
    s_dil = np.logical_or.reduce([ink_s[1 + oy:1 + oy + hh, 1 + ox:1 + ox + ww]
                                  for oy in (-1, 0, 1) for ox in (-1, 0, 1)])
    dp = np.pad(ink_d, 1, mode="constant", constant_values=False)
    d_dil = np.logical_or.reduce([dp[1 + oy:1 + oy + hh, 1 + ox:1 + ox + ww]
                                  for oy in (-1, 0, 1) for ox in (-1, 0, 1)])
    bad = (ink_d & ~s_dil) | (ink_s[1:1 + hh, 1:1 + ww] & ~d_dil)
    # 제자리에서 같은 픽셀은 애초에 바뀐 것이 아니다 — 밀린 머리글 위로 지나가는 다른 선(움직이지 않음)을 '설명 안 됨'으로
    # 세지 않게, 제자리에서도 다르고 밀어도 다른 픽셀만 남긴다 (벤치 pdf68 B32)
    i0 = np.zeros((hh + 2, ww + 2), dtype=bool)
    ry0, ry1, rx0, rx1 = max(0, y0 - 1), min(h, y1 + 1), max(0, x0 - 1), min(w, x1 + 1)
    i0[ry0 - (y0 - 1):ry1 - (y0 - 1), rx0 - (x0 - 1):rx1 - (x0 - 1)] = src[ry0:ry1, rx0:rx1] < _INK
    i_dil =np.logical_or.reduce([i0[1 + oy:1 + oy + hh, 1 + ox:1 + ox + ww]
                                  for oy in (-1, 0, 1) for ox in (-1, 0, 1)])
    # 제자리 차이는 1픽셀 이웃까지 넓혀 겹친다 — 밀림 후보 dy±1에서 지운 가는 선의 '제자리 차이'(옛 선 자리)와 '밀어도 차이'
    # (한 줄 아래)가 한 픽셀 엇갈려 교집합이 비고, 지운 표 안 가로선이 '밀림으로 설명됨'이 됐다 (검토69 B V2c)
    _ip = (ink_d & ~i_dil) | (i0[1:1 + hh, 1:1 + ww] & ~d_dil)
    if inplace_ignore is not None and inplace_ignore.shape == _ip.shape:
        # 제자리 차이에서 글자 자리(두 판 글자 상자, 제자리)는 뺀다 — 밀린 글줄의 옛 글자 잉크가 1픽셀 이웃으로 그 옆을 지나는 **고정된**
        # 선에 닿아 '설명 안 됨'으로 남았다 (대량 시험 DXF C9 부품표 위 대각선, 2026-10-20). DXF 묶음에서만 준다.
        # 다만 한쪽 판에만 있는 가로·세로 선(글자 상자 안을 지나는 밑줄·칸 선을 지움·그음)의 자리는 빼지 않는다 — 그 선은 글자가 아니다
        keep = np.zeros(_ip.shape, dtype=bool)
        if hh >= 2 and ww >= 2:
            ga = src[y0:y1, x0:x1] if (y1 <= h and x1 <= w) else None
            if ga is not None and ga.shape == d.shape:
                for (yy, xa, xb) in _new_hline_segs(ga, d, min_run=line_min_run):
                    keep[max(0, yy - 2):yy + 4, max(0, xa - 2):xb + 2] = True
                for (xx, ya, yb) in _new_hline_segs(ga.T, d.T, min_run=line_min_run):
                    keep[max(0, ya - 2):yb + 2, max(0, xx - 2):xx + 4] = True
        _ip &= ~(inplace_ignore & ~keep)
        # 같은 까닭으로 글자 상자 가림(ignore)도 그 선 자리는 가리지 않는다 — 밀린 행 글자 상자 안의 밑줄을 지운 것이 '밀림'으로
        # 설명돼 사라졌다 (adv71 M71_17)
        ignore = ignore & ~keep
    bp = np.pad(_ip, 1, mode="constant", constant_values=False)
    bad &= np.logical_or.reduce([bp[1 + oy:1 + oy + hh, 1 + ox:1 + ox + ww] for oy in (-1, 0, 1) for ox in (-1, 0, 1)])
    bad &= ~ignore
    for bx, by in group:
        ly, lx = by * _VIS_BLOCK - y0, bx * _VIS_BLOCK - x0
        if int(bad[ly:ly + _VIS_BLOCK, lx:lx + _VIS_BLOCK].sum()) >= _VIS_BLOCK_MIN_PX:
            return False
    return True


def _row_shift_explained(a, b, group, scale: float, anchors: list, ot: list, nt: list,
                         spacing: bool = True, gate_src=None) -> bool:
    return _row_shift_dy(a, b, group, scale, anchors, ot, nt, spacing=spacing, gate_src=gate_src) is not None


def _row_shift_dy(a, b, group, scale: float, anchors: list, ot: list, nt: list,
                  spacing: bool = True, gate_src=None, near_explained=None):
    """표 행을 더하거나 지운 자리의 픽셀 변화인가 — 그 아래(위) 행들이 한 행 높이만큼 밀려 표 테두리·머리글이 함께
    움직인다. 글자 변경(anchors: 바뀐 글줄 자리)에 맞닿은 묶음이, 글자를 빼고 보면 옛 판을 한 행 높이 dy만큼 민 그림과
    **양방향으로** 같으면(새 판 ≈ 옛 판을 민 것, 옛 판 ≈ 새 판을 거꾸로 민 것) 글자 변경으로 이미 설명된 변화다
    (벤치 pdf68 B21·B22·B34·B39·dxf68 E07: 부품표·개정표 행 추가·삭제가 덤 '그림 변경' 2~5곳).
    양방향을 보는 이유: 지운 그림은 새 판에선 빈 종이라 한쪽만 보면 아래 빈 종이와 늘 같다.
    구멍 하나를 더 그린 것처럼 민 그림에 없는 선은 남는다 — 그림 변경은 계속 잡힌다 (pdf68 B26).
    gate_src(새 판 DXF)가 있으면 민 옛 그림에도 제자리 옛 그림에도 없는 새 도형이 지나는 묶음은 설명하지 않는다.
    돌려주는 값: 설명한 밀림 dy(px) 또는 None.
    near_explained = [(사각형, dy)]: 이미 같은 dy로 설명된 묶음들 — 주면 '바뀐 글줄에 맞닿음' 대신 '같은 dy로 설명된 묶음에 맞닿음'을
    보고 그 dy만 시험한다(가림은 anchors 그대로)."""
    xs = [g[0] for g in group]
    ys = [g[1] for g in group]
    rect = _Region(min(xs) * _VIS_BLOCK * scale, min(ys) * _VIS_BLOCK * scale,
                   (max(xs) + 1) * _VIS_BLOCK * scale, (max(ys) + 1) * _VIS_BLOCK * scale)
    cands = _shift_candidates(rect, ot, nt, scale, spacing=spacing)
    if near_explained is not None:
        cands = [k for k in cands if any(k == d for _r, d in near_explained)]
    if not cands:
        return None
    win = _group_window(b.shape, group)
    # 창 근처 글자 자리만 — 쪽 전체 글자(3,000개)를 dy마다 칠하지 않는다
    reach = _SHIFT_MAX_PT + 4 * scale

    def _near(r):
        return (r.x1 >= rect.x0 - 4 and r.x0 <= rect.x1 + 4
                and r.y1 >= rect.y0 - reach and r.y0 <= rect.y1 + reach)
    n_rects = [r for _t, r in nt if _near(r)] + [r for r in anchors if _near(r)]
    o_rects = [r for _t, r in ot if _near(r)] + [r for r in anchors if _near(r)]
    # 한쪽 판에만 있는 선으로 볼 최소 길이(px) — 글자 획(글자 높이 이하)이 아니라 글자 높이의 3배 넘게 이어진 것만
    _hs = sorted((r.y1 - r.y0) / scale for r in n_rects + o_rects if r.y1 > r.y0)
    _lmr = max(12, int(3 * 0.67 * _hs[len(_hs) // 2])) if _hs else 12
    for dy in cands:
        dpt = abs(dy) * scale
        # 바뀐 글줄에 맞닿아야 — 행 하나 높이(+여유) 안. 가로는 같은 행의 옆 칸(테두리·칸 선)까지
        hx = max(40.0, 3 * dpt)
        reach_to = anchors if near_explained is None else [r for r, d in near_explained if d == dy]
        if not any(r.x1 >= rect.x0 - hx and r.x0 <= rect.x1 + hx
                   and max(0.0, r.y0 - rect.y1, rect.y0 - r.y1) <= 1.5 * dpt + 4 for r in reach_to):
            continue
        ign_f = _rect_mask_win(win, [(n_rects, 0), (o_rects, dy)], scale)
        ign_i = _rect_mask_win(win, [(n_rects, 0), (o_rects, 0)], scale) if gate_src is not None else None
        if not _shifted_same(b, a, group, dy, ign_f, ign_i, _lmr):
            continue
        ign_r = _rect_mask_win(win, [(o_rects, 0), (n_rects, -dy)], scale)
        if not _shifted_same(a, b, group, -dy, ign_r, ign_i, _lmr):
            continue
        if gate_src is not None and _geom_new_blocks(gate_src, 1, a, set(group), dys=(0, dy)):
            continue
        return dy
    return None


def _source(x, fit: dict | None = None, renders=None):
    """비교 대상 → 페이지 공급원. PDF 경로 / DXF 경로 / 기록 그림 목록(PageRender).
    DXF는 fit(이전 판의 틀)이 있으면 같은 틀로 그려 픽셀 단위 비교가 되게 한다. renders(이 파일 판을 기록할 때 그린 그림)가
    그 틀과 같은 틀이면 다시 그리지 않고 그 그림을 쓴다 (render.same_frame_render — 결과 같음)."""
    if isinstance(x, (str, Path)):
        p = Path(x)
        if p.suffix.lower() == ".dxf":
            from watcher.render import same_frame_render
            pages = same_frame_render(renders, fit) if renders else None
            return _RenderSource(pages if pages is not None else render_dxf(p, fit=fit), dxf_path=p)
        return _PdfSource(p)
    return _RenderSource(x)


def _snap_to_lines(src, pno: int, area: _Region) -> _Region:
    """자르는 틀의 위·아래 가장자리가 글줄 한가운데를 지나면 그 줄이 다 들어오게 넓힌다 — E-104 사진 맨 위 'M-103 MOTOR'가
    반만 잘려 보였다 (ux20 mail 11). 넓히기만 하고(한 줄 높이 + 4pt까지), 글자 자리를 모르면 그대로."""
    try:
        rows = _all_text_rects(src, pno)
    except Exception:                                   # noqa: BLE001
        return area
    y0, y1 = area.y0, area.y1
    for _t, r in rows or ():
        hgt = r.y1 - r.y0
        if hgt <= 0 or hgt > 60 or r.x1 < area.x0 or r.x0 > area.x1:
            continue
        if r.y0 < area.y0 < r.y1:
            y0 = min(y0, r.y0 - 4)
        if r.y0 < area.y1 < r.y1:
            y1 = max(y1, r.y1 + 4)
    return _Region(area.x0, max(0.0, y0), area.x1, y1) if (y0, y1) != (area.y0, area.y1) else area


def _region_crop(src, pno: int, rect: _Region, label: str) -> dict:
    """변경 위치 주변을 확대해 잘라낸 이미지 + 빨간 박스 (렌더 이미지 위에만 표시)."""
    area = _Region(rect.x0 - _VIS_CROP_PAD, rect.y0 - _VIS_CROP_PAD,
                   rect.x1 + _VIS_CROP_PAD, rect.y1 + _VIS_CROP_PAD)
    area = _snap_to_lines(src, pno, area)
    img = src.crop(pno, area, rect)
    return {
        "mime": "image/jpeg",
        "b64": _jpeg_b64(img),
        "caption": f"{pno}페이지 변경 위치 확대 ({label})",
    }


_ALIGN_SIM = 0.75          # 이 이상 닮아야 같은 페이지로 짝짓는다 (잉크 분포 기준)


def _ink_sig(thumb, n: int = 24):
    """작은 그림 → n×n 잉크(어두움) 분포. 크기가 달라도 같은 격자로 맞춘다."""
    import numpy as np
    a = 255.0 - np.asarray(thumb, dtype=np.float32)
    h, w = a.shape[:2]
    if h < n or w < n:
        from PIL import Image
        a = 255.0 - np.asarray(Image.fromarray(np.asarray(thumb)).resize((max(n, w), max(n, h))),
                               dtype=np.float32)
        h, w = a.shape[:2]
    a = a[: h - h % n, : w - w % n]
    return a.reshape(n, h // n, n, w // n).mean(axis=(1, 3))


WHITE_NORM = True          # 시험용 끔 스위치 (검토20 r07 4)
_WHITE_GAP = 12            # 두 판의 바탕 밝기 차가 이 이상일 때만 맞춘다(벡터 PDF·같은 스캐너 판은 그대로)


def _white_level(g) -> float:
    """그레이 그림의 바탕(흰 점) 밝기 — 화소 대부분이 바탕이라 상위 분위(75%)로 잰다. 큰 그림은 솎아 잰다."""
    import numpy as np
    s = np.asarray(g)
    step = max(1, int((s.size / 400_000) ** 0.5))
    return float(np.percentile(s[::step, ::step], 75))


def _white_norm(a, b):
    """바탕 밝기가 다른 두 판(어둡게 다시 뜬 스캔)을 흰 점에 맞춰 늘린다 → (a, b). 절대 명도 차(_VIS_PIXEL_MIN)로 비교하면 바탕
    255→195인 재스캔이 쪽 전체 변경이 됐다 (검토20 r07 4: 밝기 -60이 '페이지 전체 어긋남', -25+기울기+배율은 그림 변경 36곳).
    바탕 차가 _WHITE_GAP 미만이면 손대지 않는다."""
    if not WHITE_NORM:
        return a, b
    try:
        import numpy as np
        wa, wb = _white_level(a), _white_level(b)
        if abs(wa - wb) < _WHITE_GAP or min(wa, wb) < 64:
            return a, b

        def _stretch(g, w):
            if w >= 254.5:
                return g
            return np.clip(np.asarray(g, dtype=np.float32) * (255.0 / w), 0, 255).astype(np.uint8)
        return _stretch(a, wa), _stretch(b, wb)
    except Exception:                                   # noqa: BLE001
        return a, b


def _sig_sim_ink(a, b) -> float:
    import numpy as np
    tot = float(a.sum() + b.sum())
    if tot < 1e-6:
        return 1.0                           # 둘 다 빈 페이지
    return max(0.0, 1.0 - float(np.abs(a - b).sum()) / tot)


WIDE_SHIFT_NOTE = "페이지 전체가 살짝 어긋남 — 재스캔·스캔 기울기·전체 이동일 수 있습니다 (사진으로 확인)"


_ORDER_BUDGET = 60_000     # 쪽수 × 쪽당 평균 낱말 수의 상한 (아래 설명)


def _same_order_by_words(ow: list, nw: list) -> bool:
    """쪽 순서가 그대로인가를 글자만으로 판정 — 맞으면 축소판(잉크 분포)을 그릴 필요가 없다.

    기준은 '번호끼리 닮았나'가 아니라 '제자리가 가장 닮았나'다. 개정으로 글이 바뀐 쪽도 제자리가
    1등이면 순서는 그대로고, 순서를 바꾼 쪽은 다른 자리가 1등이 되어 바로 걸린다
    (블라인드 2차 38: 4쪽을 2쪽으로 옮긴 도면 세트). 비기면 판단을 미루고 축소판을 그린다 —
    같은 글이 반복되는 서식 쪽이 그렇다. 한 쪽이라도 글이 적으면(스캔본·그림 쪽) 쓰지 않는다.

    글자는 쪽당 7ms, 축소판은 30ms다 — 131쪽 한 쌍에서 8초가 걸리던 자리
    (2026-09-07 사용자 "검사하니까 좀 많이 느려지기는하네").

    다만 이 판정 자체는 쪽수²×낱말 수라, 글이 빽빽한 긴 문서에서는 아끼려던 축소판보다 비싸진다
    (검토 실측: 300쪽×1500낱말에서 판정에만 26.7초, 축소판은 18초). 그런 문서는 애초에 축소판을
    그려도 되므로 예산을 넘으면 바로 예전 길로 보낸다 — 이 최적화가 겨냥한 벡터 도면은 쪽당
    낱말이 100개 안팎이라 예산 안에 넉넉히 든다 (2026-09-07 추출 검토 ③)."""
    if len(ow) != len(nw):
        return False                       # 호출부는 쪽수가 같을 때만 부르지만 혼자서도 안전하게
    if any(len(x) < 5 for x in ow) or any(len(y) < 5 for y in nw):
        return False
    n = len(ow)
    if n * (sum(len(x) for x in ow) // max(1, n)) > _ORDER_BUDGET:
        return False

    def jac(x: set, y: set) -> float:
        return len(x & y) / max(1, len(x | y))

    for k in range(n):
        dia = jac(ow[k], nw[k])
        if any(jac(ow[k], nw[j]) >= dia for j in range(n) if j != k):
            return False
        if any(jac(ow[i], nw[k]) >= dia for i in range(n) if i != k):
            return False
    return True


def align_pages(os_, ns_, thr: float = _ALIGN_SIM, anchors: dict | None = None) -> tuple[list, list, list]:
    """두 판의 페이지를 내용으로 짝짓는다 → (짝 [(옛, 새)], 옛에만 있는 쪽, 새에만 있는 쪽).

    번호끼리(1↔1, 2↔2) 맞추면 한 쪽이 빠졌을 때 그 뒤가 전부 '바뀜'으로 보였다
    (2026-09-06 사용자: "페이지 삭제로 번호가 당겨지면 그 뒤가 신규로 인식"). 순서를 지키는
    정렬(DP)로 삭제·삽입을 흡수하고, 같은 번호가 충분히 닮았으면 그대로 쓴다."""
    no, nn = len(os_), len(ns_)
    if no == 0 or nn == 0:
        return [], list(range(1, no + 1)), list(range(1, nn + 1))
    if no == nn == 1:
        return [(1, 1)], [], []
    # 글자부터 읽는다 — 한 쪽에 1ms다. 축소판은 그려야 해서 30ms고, 131쪽 한 쌍이면 그것만 8초였다
    # (2026-09-07 사용자 "검사하니까 좀 많이 느려지기는하네"). 벡터 도면은 해상도를 낮춰도 렌더가 안 싸진다.
    ow = [os_.words(i) for i in range(1, no + 1)] if hasattr(os_, "words") else [set()] * no
    nw = [ns_.words(j) for j in range(1, nn + 1)] if hasattr(ns_, "words") else [set()] * nn
    if no == nn and _same_order_by_words(ow, nw):
        return [(k + 1, k + 1) for k in range(no)], [], []
    osig = [_ink_sig(os_.thumb(i)) for i in range(1, no + 1)]
    nsig = [_ink_sig(ns_.thumb(j)) for j in range(1, nn + 1)]

    def _sig_sim(a, b, i=None, j=None):        # 잉크 분포 + (있으면) 낱말 겹침
        s = _sig_sim_ink(a, b)
        if i is not None and j is not None and ow[i] and nw[j]:
            jac = len(ow[i] & nw[j]) / max(1, len(ow[i] | nw[j]))
            # 테두리·표제란이 같은 표준 양식은 잉크 분포가 다 닮아 번호 순 짝을 택했다 — 글이 넉넉하면
            # 낱말 쪽을 더 믿는다 (2026-09-06 사용성 3차 ④-1: 2쪽 지운 도면이 4쪽·2쪽 두 번 '삭제')
            w = 0.65 if min(len(ow[i]), len(nw[j])) >= 5 else 0.5
            s = (1 - w) * s + w * jac
        return s
    if no == nn:
        # 쪽수가 같으면 번호 그대로 — 크게 고친 페이지를 '다른 페이지'로 오인하지 않게.
        # 단, 번호끼리는 안 닮았는데 다른 자리에 거의 같은 페이지가 있으면(순서 바꿈) 그 짝으로
        # (2026-09-06 블라인드 2차 38: 4쪽을 2쪽으로 옮긴 도면 세트가 9곳 그림 변경으로)
        # 글자 대응이 쪽 전부를 하나씩 덮는 순열이면 그것을 쓴다 — 덮어쓴 파일은 옛 판이 기록 그림이라 잉크 서명이
        # 파일과 달라(같은 쪽끼리 0.35) 순서 바꿈을 영영 못 알아봤다 (검토61 B15)
        if anchors:
            _perm = {int(a): int(b) for a, b in anchors.items()}
            if (sorted(_perm) == list(range(1, no + 1)) and sorted(_perm.values()) == list(range(1, nn + 1))
                    and any(a != b for a, b in _perm.items())):
                return sorted(_perm.items()), [], []
        ident = [_sig_sim(osig[k], nsig[k], k, k) for k in range(no)]
        # 가장 닮은 쌍부터 차례로 배정(순열) — 번호 그대로보다 확실히 나을 때만 채택
        allp = sorted(((_sig_sim(osig[i], nsig[j], i, j), i, j) for i in range(no) for j in range(nn)), reverse=True)
        used_i: set = set()
        used_j: set = set()
        assign: dict = {}
        for s, i, j in allp:
            if i in used_i or j in used_j:
                continue
            assign[i] = (j, s); used_i.add(i); used_j.add(j)
        if (any(assign[i][0] != i for i in range(no))
                and all(s >= 0.8 for _, s in assign.values())
                and sum(s for _, s in assign.values()) > sum(ident) + 0.05 * no):
            return sorted((i + 1, assign[i][0] + 1) for i in range(no)), [], []
        return [(k + 1, k + 1) for k in range(no)], [], []
    sim = [[_sig_sim(osig[i], nsig[j], i, j) for j in range(nn)] for i in range(no)]
    # 순서 보존 최대 유사도 합 (LCS꼴). 짝은 thr 이상일 때만
    best = [[0.0] * (nn + 1) for _ in range(no + 1)]
    for i in range(1, no + 1):
        for j in range(1, nn + 1):
            s = sim[i - 1][j - 1]
            cand = best[i - 1][j - 1] + s if s >= thr else -1.0
            best[i][j] = max(best[i - 1][j], best[i][j - 1], cand)
    pairs = []
    i, j = no, nn
    while i > 0 and j > 0:
        s = sim[i - 1][j - 1]
        if s >= thr and abs(best[i][j] - (best[i - 1][j - 1] + s)) < 1e-9:
            pairs.append((i, j)); i -= 1; j -= 1
        elif best[i - 1][j] >= best[i][j - 1]:
            i -= 1
        else:
            j -= 1
    pairs.reverse()
    if anchors:
        # 글자 비교가 이미 정한 페이지 대응이 잉크 정렬보다 믿을 만하다 — 잉크 분포가 비슷한
        # 도면 세트에서 그림만 있는 쪽의 삭제를 놓치거나 남은 쪽을 삭제라 했다 (검토19 2차 N2).
        # 앵커(옛→새)는 단조 증가하는 것만 쓰고, 앵커에 걸린 쪽은 잉크 짝을 덮어쓴다
        good = []
        last_j = 0
        for i_, j_ in sorted((int(a), int(b)) for a, b in anchors.items()):
            if 1 <= i_ <= no and 1 <= j_ <= nn and j_ > last_j:
                good.append((i_, j_))
                last_j = j_
        if good:
            ai = {a for a, _ in good}
            aj = {b for _, b in good}
            pairs = sorted([p for p in pairs if p[0] not in ai and p[1] not in aj] + good)
    po = {a for a, _ in pairs}
    pn = {b for _, b in pairs}
    old_only = [k for k in range(1, no + 1) if k not in po]
    new_only = [k for k in range(1, nn + 1) if k not in pn]
    # 양쪽에 짝 없는 페이지가 남으면 순서대로 '크게 바뀐 같은 페이지'로 본다 — 진짜 추가·삭제는
    # 쪽수 차이만큼만 남는다 (그림을 크게 고친 페이지가 삭제+추가로 갈리지 않게)
    while old_only and new_only:
        i, j = old_only.pop(0), new_only.pop(0)
        pairs.append((i, j))
    pairs.sort()
    return pairs, old_only, new_only


# ── 배치만 바뀜·쪽 전체 맞춰 비교 (2026-10-23 PDF 뒤흔들기 C5·C18·C1·C17) ─────────────────────────────────────────────
# 같은 글줄(추출기의 줄 묶기 — 기록 meta['lboxes'])을 두 판에서 짝지어 ① 쪽 전체 닮음 변환(작은 기울기·이동·축척·90° 돌림)을
# 찾으면 옛 판 그림을 그 변환으로 옮겨 놓고 비교하고, ② 자리만 옮긴 글줄 덩어리(표제란·개정표·부품표를 다른 모서리로)는 옛 자리
# (지금 비었음)와 새 자리(옛 그림을 그만큼 옮긴 것과 같음)의 픽셀을 '배치만 바뀜'으로 설명한다. 설명은 픽셀로 확인한다 —
# 옮긴 덩어리 안이라도 옛 그림을 옮겨 놓은 것과 다른 픽셀(새로 그은 선·지운 도형)은 그대로 '그림 변경'으로 남는다(원칙 5).
# 설명된 묶음은 '배치만 바뀜' 표식을 단 그림 변경 한 줄(전/후 사진)로 남고 Rev 판단의 내용에서 빠진다(diff.LAYOUT_ZONE).
LAYOUT_ALIGN = True
LAYOUT_AWAY = True                     # 쪽을 나눠 다른 쪽으로 옮겨 간 글줄의 옛 자리(빈 곳)도 배치
LAYOUT_RESTYLE = True                  # 쪽 전체 글꼴·크기만 바꿔 같은 자리에 다시 그린 글줄도 '배치만 바뀜'
LAYOUT_ZONE_MARK = "배치만 바뀜"        # diff.LAYOUT_ZONE과 같은 말
_LAY_TOL = 2.0                         # 같은 자리로 보는 글줄 가운데 차(pt)
_LAY_MIN_PAIRS = 3
_ALIGN_PIXEL_MIN = 70
_ALIGN_REFINE = True                   # 고른 쪽 변환의 이동을 ±1픽셀 다듬기                  # 옮겨 놓은 옛 그림과의 비교 — 다시 뽑은 안티앨리어싱 차이를 견딘다


def _layout_line_boxes(src, pno: int):
    """[(글줄, _Region)] — 추출기와 같은 줄 묶기 글줄. PDF 파일은 지금 짓고, 기록은 meta['lboxes']. 없으면(옛 기록·회전 쪽·DXF) None."""
    try:
        if isinstance(src, _PdfSource):
            cache = src.__dict__.setdefault("_lboxes", {})
            if pno not in cache:
                from watcher.render import page_layout_boxes
                cache[pno] = page_layout_boxes(src._page(pno))
            rows = cache[pno]
        elif isinstance(src, _RenderSource) and not src._dxf_path and "scale" not in src.meta(pno):
            rows = src.meta(pno).get("lboxes")
            if rows is None:
                return None
        else:
            return None
        return [(" ".join(str(t).split()), _Region(float(x0), float(y0), float(x1), float(y1))) for t, x0, y0, x1, y1 in rows]
    except Exception:                                   # noqa: BLE001
        return None


def _sim_fit(P: list, Q: list):
    """P→Q 닮음 변환 최소제곱 (a, b, tx, ty): x' = a·x − b·y + tx, y' = b·x + a·y + ty. 점이 한데 모여 있으면 None."""
    n = len(P)
    if n < 2:
        return None
    mx, my = sum(p[0] for p in P) / n, sum(p[1] for p in P) / n
    nx, ny = sum(q[0] for q in Q) / n, sum(q[1] for q in Q) / n
    S = sum((p[0] - mx) ** 2 + (p[1] - my) ** 2 for p in P)
    if S < 1e-6:
        return None
    a = sum((p[0] - mx) * (q[0] - nx) + (p[1] - my) * (q[1] - ny) for p, q in zip(P, Q)) / S
    b = sum((p[0] - mx) * (q[1] - ny) - (p[1] - my) * (q[0] - nx) for p, q in zip(P, Q)) / S
    return a, b, nx - (a * mx - b * my), ny - (b * mx + a * my)


def _sim_apply(G, x: float, y: float) -> tuple:
    a, b, tx, ty = G
    return a * x - b * y + tx, b * x + a * y + ty


def _sim_inv(G):
    a, b, tx, ty = G
    d = a * a + b * b
    ia, ib = a / d, -b / d
    return ia, ib, -(ia * tx - ib * ty), -(ib * tx + ia * ty)


_SIM_ID = (1.0, 0.0, 0.0, 0.0)


def _sim_compose(G1, G2):
    """G1∘G2 — G2를 먼저, 그다음 G1."""
    a1, b1, tx1, ty1 = G1
    a2, b2, tx2, ty2 = G2
    return (a1 * a2 - b1 * b2, a1 * b2 + b1 * a2, a1 * tx2 - b1 * ty2 + tx1, b1 * tx2 + a1 * ty2 + ty1)


def _sim_rect(G, r: _Region) -> _Region:
    pts = [_sim_apply(G, x, y) for x in (r.x0, r.x1) for y in (r.y0, r.y1)]
    return _Region(min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))


def _fit_global(P: list, Q: list, tols: list, s_page, min_ratio: float = 0.5):
    """P→Q 쪽 전체 닮음 변환 (G, 맞는 짝 번호) — 두 짝으로 정한 변환 가운데 가장 많은 짝을 설명하는 것(정해진 차례로 고른다).
    축척은 1(여백만 바꿈·옮김·돌림)과 쪽 크기 비(통째로 키움) 가운데 맞춘 값에 3% 안으로 가까운 것으로 고정한다 — 글자 크기만
    살짝 바꾼 판(fs_micro)은 글줄 가운데가 축척처럼 움직여 쪽 끝에서 10pt 넘게 어긋났다. 짝의 절반을 못 맞추면 (None, [])."""
    N = len(P)

    def inliers(g):
        return [k for k in range(N) if math.hypot(*(u - v for u, v in zip(_sim_apply(g, *P[k]), Q[k]))) <= tols[k]]

    def fix_scale(g, idx):
        """축척을 1 또는 쪽 크기 비(3% 안이면)로 고정하고 그 짝들로 이동을 다시 맞춘다."""
        sg = math.hypot(g[0], g[1])
        cs = [c for c in ((1.0, s_page) if s_page else (1.0,)) if abs(sg / c - 1) < 0.03]
        if not cs:
            return g
        s0 = min(cs, key=lambda c: abs(sg / c - 1))
        th = math.atan2(g[1], g[0])
        a_, b_ = s0 * math.cos(th), s0 * math.sin(th)
        m = len(idx)
        mpx, mpy = sum(P[k][0] for k in idx) / m, sum(P[k][1] for k in idx) / m
        mqx, mqy = sum(Q[k][0] for k in idx) / m, sum(Q[k][1] for k in idx) / m
        return a_, b_, mqx - (a_ * mpx - b_ * mpy), mqy - (b_ * mpx + a_ * mpy)
    # 축척을 고정한 변환을 먼저 — 짝이 몇 안 되면 축척·회전을 자유롭게 둔 변환이 따로 옮긴 표 행까지 '맞는 짝'으로 품어 버린다
    need = max(_LAY_MIN_PAIRS, min_ratio * N)
    step = max(1, N // 24)
    cand = [(i, j) for i in range(0, N, step) for j in range(i + 1, N, step)][:600]
    G, best = None, []
    for fixed in (True, False):
        bg, bi = None, []
        for i, j in cand:
            g = _sim_fit([P[i], P[j]], [Q[i], Q[j]])
            if g is None or not (0.2 <= math.hypot(g[0], g[1]) <= 5.0):
                continue
            gg = fix_scale(g, [i, j]) if fixed else g
            if fixed and gg is g:
                continue
            inl = inliers(gg)
            if len(inl) > len(bi):
                bg, bi = gg, inl
        if bg is not None and len(bi) >= need:
            G, best = bg, bi
            # 맞은 짝들로 다시 맞추고 한 번 더
            for _ in range(2):
                g2 = _sim_fit([P[k] for k in best], [Q[k] for k in best])
                if g2 is None:
                    break
                g2 = fix_scale(g2, best) if fixed else g2
                inl = inliers(g2)
                if len(inl) < len(best):
                    break
                G, best = g2, inl
            break
    if G is None:
        return None, []
    same = inliers(G)
    if len(same) < max(_LAY_MIN_PAIRS, min_ratio * N):
        return None, []
    return G, same


def _ink_mismatch(x, y) -> int:
    """잉크가 서로 1픽셀 안에 없는 픽셀 수 (2×2 최솟값으로 줄여 센다) — 맞춤 후보 고르기용."""
    import numpy as np
    h, w = (min(x.shape[0], y.shape[0]) // 2) * 2, (min(x.shape[1], y.shape[1]) // 2) * 2

    def pool(z):
        z = z[:h, :w]
        return np.minimum(np.minimum(z[0::2, 0::2], z[1::2, 0::2]), np.minimum(z[0::2, 1::2], z[1::2, 1::2]))
    return int((~_ink_same(pool(x), pool(y), 1)).sum())


def _ink_mismatcher(y):
    """_ink_mismatch(x, y)를 같은 y에 거듭 셀 때 — y 쪽 줄임·넓힘을 한 번만 한다(결과는 같다). x 크기가 y와 다르면 그대로 센다."""
    import numpy as np
    h, w = (y.shape[0] // 2) * 2, (y.shape[1] // 2) * 2

    def pool(z):
        # 2×2 최솟값 — 위아래 행 짝을 먼저(행이 이어진 메모리), 그다음 좌우 열 짝 (_ink_mismatch의 pool과 같은 값)
        z = z[:h, :w]
        r = np.minimum(z[0::2], z[1::2])
        return np.minimum(r[:, 0::2], r[:, 1::2])
    py = pool(y)
    y_dark, y_near = py < 180, _dilate(py < 230, 1)

    def from_pooled(px) -> int:
        return int(np.count_nonzero((y_dark & ~_dilate(px < 230, 1)) | ((px < 180) & ~y_near)))

    def mismatch(x) -> int:
        if x.shape != y.shape:
            return _ink_mismatch(x, y)
        return from_pooled(pool(x))
    mismatch.from_pooled = from_pooled          # 이미 2×2로 줄인 x (y를 줄인 것과 같은 크기)
    return mismatch


class _WarpMemo:
    """같은 옛 쪽 그림을 같은 변환으로 거듭 옮길 때(맞춤 후보 고르기 → 점수) 방금 옮긴 것을 다시 쓴다 — 결과는 같다.
    한 쪽 짝(옛 쪽·새 쪽) 동안만 쓰고, 큰 도면 쪽은 수십 MB라 마지막 둘만 든다. 변환은 부호 있는 0까지 같아야 같은 것으로 본다."""

    def __init__(self, keep: int = 2):
        self.keep, self.got = keep, {}

    def warp(self, a, G, shape, scale: float):
        key = (tuple(float(v).hex() for v in G), tuple(int(v) for v in shape), float(scale).hex())
        out = self.got.pop(key, None)
        if out is None:
            out = _warp_gray(a, G, shape, scale)
        self.got[key] = out
        while len(self.got) > self.keep:
            self.got.pop(next(iter(self.got)))
        return out


def _align_picker(a, b, scale: float, warps: "_WarpMemo | None" = None):
    """쪽 닮음 변환 후보 가운데 옛 그림(a)을 옮겨 새 그림(b)에 가장 잘 겹치는 것을 골라 이동을 ±1픽셀 다듬는 함수.
    warps: 같은 옛 쪽 그림(a와 같은 값)을 쓰는 점수 함수와 나눠 쓰는 옮김 기억(_WarpMemo) — 없으면 이 함수만 쓴다."""
    import numpy as np
    _mis: list = []
    if warps is None:
        warps = _WarpMemo()

    def mis_b(x) -> int:
        if not _mis:
            _mis.append(_ink_mismatcher(b))
        return _mis[0](x)

    def pick(cands, against_identity: bool = False):
        if len(cands) == 1 and not against_identity and not _ALIGN_REFINE:
            return cands[0]
        best, bsc = None, None
        for g in dict.fromkeys(cands):
            sc = mis_b(warps.warp(a, g, b.shape, scale))
            if bsc is None or sc < bsc:
                best, bsc = g, sc
        if best is None:
            return None
        if against_identity and a.shape == b.shape and bsc * 2 > mis_b(a):
            return None                                 # 그대로 두는 것보다 절반 넘게 줄지 않으면 쪽 전체 이동이 아니다
        W = warps.warp(a, best, b.shape, scale)
        h, w = b.shape
        bdx, bdy = 0, 0
        # ±1픽셀 옮긴 그림(빈 곳 255)을 2×2로 줄인 것 = 둘레에 255를 한 줄 두른 W를 짝수·홀수 자리에서 2×2로 줄인 넷 가운데 하나를
        # 한 칸 밀어 자른 것 — 옮긴 그림 여덟 장을 만들어 줄이는 대신 줄인 것 넷으로 (같은 값)
        h2, w2 = h // 2, w // 2
        Wp = np.pad(W, 1, mode="constant", constant_values=255)
        rows = (np.minimum(Wp[0:2 * h2 + 2:2], Wp[1:2 * h2 + 2:2]),         # 짝: 쪽 둘레 행 (2i, 2i+1), i = 0..h2
                np.minimum(Wp[1:2 * h2 + 1:2], Wp[2:2 * h2 + 2:2]))         # 홀: (2i+1, 2i+2), i = 0..h2-1
        quad = {}
        for ry, R in enumerate(rows):
            quad[(ry, 0)] = np.minimum(R[:, 0:2 * w2 + 2:2], R[:, 1:2 * w2 + 2:2])
            quad[(ry, 1)] = np.minimum(R[:, 1:2 * w2 + 1:2], R[:, 2:2 * w2 + 2:2])

        def cut(d):             # 옮김 d(+1·0·-1) → (짝 0 / 홀 1, 시작 칸)
            return (1, 0) if d == 0 else (0, 0) if d > 0 else (0, 1)
        for dy in range(-1, 2):
            for dx in range(-1, 2):
                if not dx and not dy:
                    continue
                (py_, oy), (px_, ox) = cut(dy), cut(dx)
                sc = _mis[0].from_pooled(quad[(py_, px_)][oy:oy + h2, ox:ox + w2])
                if sc < bsc:
                    bsc, bdx, bdy = sc, dx, dy
        return (best[0], best[1], best[2] + bdx * scale, best[3] + bdy * scale)
    return pick


def _layout_prepare(os_, ns_, opno: int, pno: int, pick=None, score=None, hints=()):
    """두 판 쪽의 같은 글줄 짝으로 {G: 쪽 전체 닮음 변환(없으면 None), clusters: [(옛 자리(변환 뒤), 새 자리, (dx, dy), 옛 자리)],
    restyled: [(옛 자리, 새 자리)]}. 짝이 모자라거나 설명할 것이 없으면 None.
    쪽 전체 변환 후보 — 그대로(None)·글줄 점 세 가지(왼쪽 가운데: 글꼴·크기를 살짝 바꿔도 그대로, 왼쪽 위, 가운데: 90° 돌림)로 맞춘
    닮음 변환·가장 많은 글줄 무리의 평행 이동 — 가운데 score(설명하고 남은 그림 변경 블록 수)가 가장 작은 것. score가 없으면
    글줄 절반 넘게 맞는 첫 후보. pick: 고른 변환의 이동을 픽셀 단위로 다듬는다. hints: 같은 옛 쪽을 나눠 받은 다른 새 쪽의 쪽
    변환 — 같은 글줄이 몇 줄 안 남은 나눈 쪽은 스스로 변환을 못 찾는다(쪽 전체를 옮긴 판의 바닥글 선이 '그림 변경'으로 남았다)."""
    ol, nl = _layout_line_boxes(os_, opno), _layout_line_boxes(ns_, pno)
    if not ol or not nl:
        return None

    def key(t):
        return "".join(t.split())
    oc = Counter(key(t) for t, _ in ol)
    nc = Counter(key(t) for t, _ in nl)
    om = {key(t): r for t, r in ol if oc[key(t)] == 1}
    pairs = [(om[key(t)], r) for t, r in nl if nc[key(t)] == 1 and len(key(t)) >= 2 and key(t) in om]
    if len(pairs) < _LAY_MIN_PAIRS and not (LAYOUT_AWAY and len(ns_) > len(os_)):
        return None
    # 쪽을 나눈 판 — 이 쪽의 옛 글줄 가운데 새 판의 **다른 쪽**으로 옮겨 간 줄(그 자리는 비었다)
    away: list = []
    if LAYOUT_AWAY and len(ns_) > len(os_):
        try:
            nkeys = {key(t) for t, _ in nl}
            other = set()
            for q in range(1, len(ns_) + 1):
                if q != pno:
                    other |= {key(t) for t, _ in (_layout_line_boxes(ns_, q) or [])}
            away = [r for t, r in ol if key(t) not in nkeys and key(t) in other and len(key(t)) >= 2]
        except Exception:                               # noqa: BLE001
            away = []

    def tol(o, n):
        return max(_LAY_TOL, 0.15 * min(o.y1 - o.y0, n.y1 - n.y0, o.x1 - o.x0, n.x1 - n.x0))
    N = len(pairs)
    tols = [tol(*pr) for pr in pairs]
    pts_modes = [([(o.x0, (o.y0 + o.y1) / 2) for o, _n in pairs], [(n.x0, (n.y0 + n.y1) / 2) for _o, n in pairs]),
                 ([(o.x0, o.y0) for o, _n in pairs], [(n.x0, n.y0) for _o, n in pairs]),
                 ([((o.x0 + o.x1) / 2, (o.y0 + o.y1) / 2) for o, _n in pairs],
                  [((n.x0 + n.x1) / 2, (n.y0 + n.y1) / 2) for _o, n in pairs])]

    def same_under(G) -> list:
        out = []
        for k in range(N):
            for PP, QQ in pts_modes:
                po = PP[k] if G is None else _sim_apply(G, *PP[k])
                if math.hypot(po[0] - QQ[k][0], po[1] - QQ[k][1]) <= tols[k]:
                    out.append(k)
                    break
        return out
    ident = same_under(None)
    if N < _LAY_MIN_PAIRS:
        # 쪽을 나눠 같은 글줄이 몇 줄만 남은 쪽 — 쪽 전체 변환은 찾지 않고 다시 그린 줄·다른 쪽으로 옮긴 줄만
        if not away:
            return None
        best = (_layout_for(None, pairs, ident, ol, nl, oc, nc, key, away)
                or {"G": None, "clusters": [], "restyled": [], "away": list(away), "removed": []})
        if hints and score is not None:
            try:
                isc = score(best)
                for G in hints:
                    if G is None or isc == 0:
                        continue
                    lay = _layout_for(G, pairs, same_under(G), ol, nl, oc, nc, key, away)
                    sc = score(lay) if lay is not None else None
                    if sc is not None and sc * 2 <= isc:
                        best, isc = lay, sc
            except Exception:                           # noqa: BLE001
                pass
        return best
    cands: list = []
    if len(ident) * 2 < N or score is not None:
        try:
            (ow, oh), (nw, nh) = os_.size(opno), ns_.size(pno)
            s_page = math.sqrt((nw * nh) / max(1e-6, ow * oh))
        except Exception:                               # noqa: BLE001
            s_page = None
        for PP, QQ in pts_modes:
            g, inl = _fit_global(PP, QQ, tols, s_page, min_ratio=0.5 if score is None else 0.3)
            if g is not None:
                cands.append((len(inl), g))
                if score is not None and s_page and abs(s_page - 1) > 0.005:
                    # 축척을 다른 후보(1 ↔ 쪽 크기 비)로 바꾼 것도 — 여백만 바꾼 쪽은 쪽 크기가 줄어도 내용 축척은 1이다
                    sg = math.hypot(g[0], g[1])
                    alt = 1.0 if abs(sg - s_page) < abs(sg - 1.0) else s_page
                    cx = sum(p[0] for p in PP) / len(PP)
                    cy = sum(p[1] for p in PP) / len(PP)
                    gx, gy = _sim_apply(g, cx, cy)
                    a_, b_ = g[0] * alt / sg, g[1] * alt / sg
                    cands.append((len(inl) - 1, (a_, b_, gx - (a_ * cx - b_ * cy), gy - (b_ * cx + a_ * cy))))
        if score is not None:
            # 가장 많은 글줄 무리의 평행 이동 (여백·머리글을 함께 바꿔 본문만 따로 옮긴 판)
            groups: dict = {}
            for (o, n) in pairs:
                groups.setdefault((round((n.x0 - o.x0) / 2), round((n.y0 - o.y0) / 2)), []).append((n.x0 - o.x0, n.y0 - o.y0))
            for gk, ds in sorted(groups.items(), key=lambda kv: -len(kv[1]))[:4]:
                if gk != (0, 0):
                    cands.append((len(ds), (1.0, 0.0, sum(d[0] for d in ds) / len(ds), sum(d[1] for d in ds) / len(ds))))
    cands.sort(key=lambda c: -c[0])
    uniq: list = []
    for _n, g in cands:
        if not any(all(abs(u - v) < 1e-6 for u, v in zip(g, q)) for q in uniq):
            uniq.append(g)
    if score is None:
        G = None if len(ident) * 2 >= N else (uniq[0] if uniq else None)
        if G is not None and pick is not None:
            try:
                G = pick([G]) or G
            except Exception:                           # noqa: BLE001
                pass
        return _layout_for(G, pairs, same_under(G) if G is not None else ident, ol, nl, oc, nc, key, away)
    best, bsc, isc = None, None, None
    hints = [g for g in hints if g is not None]
    for G in [None] + uniq[:6] + hints:
        if G is not None and not any(G is h for h in hints):
            # 쪽 전체 변환은 그대로 둘 때보다 제자리 글줄이 늘어날 때만 후보다 — 몇 줄의 이동을 쪽 전체로 넓혀 진짜 그림 변경을 '맞춰
            # 놓고 보니 같다'로 지우지 않게
            if len(same_under(G)) <= len(ident):
                continue
            if pick is not None:
                try:
                    G = pick([G]) or G
                except Exception:                       # noqa: BLE001
                    pass
        lay = _layout_for(G, pairs, same_under(G) if G is not None else ident, ol, nl, oc, nc, key, away)
        try:
            sc = score(lay if lay is not None else {"G": None, "clusters": [], "restyled": []})
        except Exception:                               # noqa: BLE001
            sc = None
        if sc is None:
            continue
        if G is None:
            isc = sc
        # 그대로 둔 것보다 남는 그림 변경이 절반 밑으로 줄어야 쪽 전체 변환을 쓴다
        if bsc is None or (sc < bsc and (isc is None or sc * 2 <= isc)):
            best, bsc = lay, sc
        if bsc == 0:
            break                                       # 다 설명됐다 — 남은 후보는 볼 것 없다
    return best


def _layout_for(G, pairs: list, same: list, ol: list, nl: list, oc, nc, key, away=()):
    """쪽 변환 G를 정한 뒤 자리만 옮긴 글줄 덩어리·같은 자리에 다시 그린 글줄."""
    N = len(pairs)
    # 자리만 옮긴 글줄 덩어리 — 옛 자리(쪽 변환 뒤)와 새 자리의 차이 벡터로 묶는다. 크기가 그대로인(글자를 다시 쓴 것이 아닌) 줄만
    moved = []
    for k in range(N):
        if k in same:
            continue
        o, n = pairs[k]
        og = _sim_rect(G, o) if G is not None else o
        if abs((og.x1 - og.x0) - (n.x1 - n.x0)) > max(2.0, 0.06 * (n.x1 - n.x0)) \
                or abs((og.y1 - og.y0) - (n.y1 - n.y0)) > max(2.0, 0.15 * (n.y1 - n.y0)):
            continue
        moved.append((og, n, (n.x0 - og.x0, n.y0 - og.y0), o))
    clusters: list = []     # (옛 자리(쪽 변환 뒤), 새 자리, 옮긴 거리, 옛 자리(옛 판 좌표))
    for og, n, d, o in sorted(moved, key=lambda m: (round(m[2][0]), round(m[2][1]))):
        for c in clusters:
            if abs(c[2][0] - d[0]) <= _LAY_TOL and abs(c[2][1] - d[1]) <= _LAY_TOL:
                c[0].append(og)
                c[1].append(n)
                c[3].append(o)
                break
        else:
            clusters.append(([og], [n], d, [o]))
    # 덩어리는 두 줄 이상이거나 — 글줄 하나만 다른 줄과 자리를 맞바꾼 것(주기 두 줄 맞바꿈 adv71 C71-10)은 배치가 아니라 내용 차례다. 쪽 번호 바닥글
    # ('- 1 -'·'Page 1/2' — 구분선과 함께 바닥 여백을 따라 옮긴다)·띠 표제란 한 줄('DWG NO: …  REV: …' — 표제 칸 둘 이상)만은
    # 한 줄이어도
    try:
        from watcher.diff import page_mark_norm
    except Exception:                                   # noqa: BLE001
        page_mark_norm = None
    pm_keys = {key(t) for t, _ in nl if page_mark_norm is not None and "#P#" in page_mark_norm(t)}
    try:
        from watcher.extract.pdf import _MULTI_FIELD_RE
        pm_keys |= {key(t) for t, _ in nl if len(_MULTI_FIELD_RE.findall(t)) >= 2}
    except Exception:                                   # noqa: BLE001
        pass
    nkey = {id(r): key(t) for t, r in nl}

    def swapped(c) -> bool:
        """한 줄 덩어리가 다른 옮긴 줄과 자리를 맞바꿨나 — 새 자리가 다른 줄의 옛 자리이거나 옛 자리가 다른 줄의 새 자리."""
        og, n = c[0][0], c[1][0]
        for og2, n2, _d, _o in moved:
            if n2 is n:
                continue
            if _overlaps(n, og2, pad=1.0) or _overlaps(og, n2, pad=1.0):
                return True
        return False
    # 한 줄이어도 다른 옮긴 줄과 자리를 맞바꾸지 않았으면(제목 한 줄이 위로 올라감) 배치다 — 맞바꿈은 내용 차례(C71-10)
    kept_c = [c for c in clusters if len(c[0]) >= 2 or nkey.get(id(c[1][0])) in pm_keys or not swapped(c)]
    swapped_ids = {id(n) for c in clusters if c not in kept_c for n in c[1]}
    clusters = kept_c
    # 글꼴·글자 크기·자간만 바꿔 같은 자리에서 다시 그린 글줄 — 읽기 시작 모서리는 같고 길이만 다르다. 크게 다른 길이(0.5~2배)는
    # 쪽 전체 글꼴 바꿈일 때만 — 한 줄 안에서 글자 하나만 옮긴 것('DETAIL C'의 C, adv69 V6b)은 아니다
    restyled: list = []
    removed: list = []
    if LAYOUT_RESTYLE:
        starts = []
        # 여러 번 나오는 글(같은 도면명 두 곳)은 같은 모서리 자리의 짝끼리만
        dup: list = []
        by_o: dict = {}
        for t, r in ol:
            if oc[key(t)] > 1:
                by_o.setdefault(key(t), []).append(r)
        for t, r in nl:
            if nc[key(t)] > 1 and key(t) in by_o:
                cq = []
                for q in by_o[key(t)]:
                    qg = _sim_rect(G, q) if G is not None else q
                    if min(abs(qg.x0 - r.x0), abs(qg.x1 - r.x1)) <= 2.5 and min(abs(qg.y0 - r.y0), abs(qg.y1 - r.y1)) <= 2.5:
                        cq.append(q)
                if len(cq) == 1:
                    dup.append((cq[0], r))
        for o, n in pairs + dup:
            og = _sim_rect(G, o) if G is not None else o
            hh = min(n.y1 - n.y0, n.x1 - n.x0)
            t_ = max(2.5, 0.2 * hh)
            # 한 모서리(읽기 시작 자리)가 그대로 — 가로 글줄은 왼쪽(위·가운데·아래), 세로 띠 글줄은 아래나 위
            if (abs(og.x0 - n.x0) <= t_ or abs(og.x1 - n.x1) <= t_) \
                    and (abs(og.y0 - n.y0) <= t_ or abs(og.y1 - n.y1) <= t_
                         or abs((og.y0 + og.y1) / 2 - (n.y0 + n.y1) / 2) <= max(t_, 0.25 * hh)):
                starts.append((og, n, (n.x1 - n.x0) / max(0.1, og.x1 - og.x0), (n.y1 - n.y0) / max(0.1, og.y1 - og.y0)))
        diff_ = [x for x in starts if abs(x[2] - 1) > 0.005 or abs(x[3] - 1) > 0.005]
        big_ = [x for x in diff_ if abs(x[2] - 1) > 0.03 or abs(x[3] - 1) > 0.03]
        # 쪽 전체 글꼴 바꿈 = 3% 넘게 길이가 바뀐 줄이 셋 이상·같은 자리 줄의 4분의 1 이상
        wide_ = len(big_) >= _LAY_MIN_PAIRS and len(big_) >= 0.25 * len(starts) and len(starts) >= 0.5 * N
        # 쪽에서 둘 이상 줄의 길이가 바뀌었으면(자간·낱말 간격을 다시 잡은 출력) 길이가 그대로인 같은 자리 줄도 — 칸마다 따로 놓인 표
        # 행은 끝 칸 자리가 그대로라 줄 길이는 같아도 낱말 사이가 밀렸다
        respaced = len(diff_) >= 2
        restyled = [(og, n) for og, n, rw, rh in (starts if respaced else diff_)
                    if (wide_ and 0.5 <= rw <= 2.0 and 0.6 <= rh <= 1.6) or (abs(rw - 1) <= 0.1 and abs(rh - 1) <= 0.1)]
        # 쪽 전체 글꼴을 바꾸면서 자리도 옮긴 글줄(머리글을 바닥으로) — 글자가 같고 길이가 글꼴 바꿈 범위 안이면 옛 자리(빈 곳)와
        # 새 자리(새 글꼴 글자)를 따로
        # (쪽 전체 글꼴 바꿈이 아니어도 길이 ±12%·높이 ±20% 안이면 — 자간·글자 크기를 살짝 바꾸며 옮긴 줄)
        st = {id(x[1]) for x in starts}
        for k, (o, n) in enumerate(pairs):
            if id(n) in st or k in same or id(n) in swapped_ids or any(n in c[1] for c in clusters):
                continue
            og = _sim_rect(G, o) if G is not None else o
            rw = (n.x1 - n.x0) / max(0.1, og.x1 - og.x0)
            rh = (n.y1 - n.y0) / max(0.1, og.y1 - og.y0)
            if (wide_ and 0.5 <= rw <= 2.0 and 0.6 <= rh <= 1.6) or (abs(rw - 1) <= 0.12 and abs(rh - 1) <= 0.2):
                removed.append((og, n))
        # 쪽 전체를 맞춰 비교한 쪽(돌림·축척·이동)은 다시 그리며 글꼴·자간까지 바꾼 출력이 대부분이다 — 같은 글자의 글줄은 길이가
        # 0.5~2배여도 옛 자리(빈 곳)·새 자리(글자 상자)로 설명한다(맞춤이 없는 쪽에는 쓰지 않는다)
        if G is not None:
            done_n = {id(n) for _o, n in restyled + removed} | swapped_ids
            for o, n in pairs + dup:
                if id(n) in done_n:
                    continue
                og = _sim_rect(G, o)
                rw = (n.x1 - n.x0) / max(0.1, og.x1 - og.x0)
                rh = (n.y1 - n.y0) / max(0.1, og.y1 - og.y0)
                if 0.5 <= rw <= 2.0 and 0.5 <= rh <= 2.0:
                    removed.append((og, n))
    if G is None and not clusters and not restyled and not away and not removed:
        return None
    return {"G": G, "clusters": clusters, "restyled": restyled, "away": list(away), "removed": removed}


def _align_radius(G) -> int:
    """맞춘 비교의 허용 이웃(px) — 글자 자리로 정한 변환은 쪽 끝에서 1~2pt 어긋날 수 있어 3픽셀, 크게 키운 쪽은 그만큼 더(최대 8)."""
    return 2 if G is None else min(8, 3 + int(round(2 * max(0.0, math.hypot(G[0], G[1]) - 1))))


def _layout_scorer(a0, b0, scale: float, warps: "_WarpMemo | None" = None):
    """후보 배치 설명의 점수 — 설명하고 남은 그림 변경 블록 수(작을수록 좋다). 크기가 달라 겹칠 수 없으면 None.
    warps: 맞춤 후보 고르기(_align_picker)와 나눠 쓰는 옮김 기억 — a0은 그쪽 a와 같은 값이어야 한다."""
    if warps is None:
        warps = _WarpMemo()
    near: dict = {}         # (그림, r) → _dilate(그림 < 230, r) — 후보마다 같은 새 그림(옮기지 않은 옛 그림)을 다시 넓히지 않게

    def near_of(which, img, r):
        if (which, r) not in near:
            near[(which, r)] = _dilate(img < 230, r)
        return near[(which, r)]

    def score(lay):
        G = lay.get("G")
        r = _align_radius(G)
        if G is None:
            if a0.shape != b0.shape:
                return None
            aa = a0
        else:
            aa = warps.warp(a0, G, b0.shape, scale)
        drop = _layout_drop(aa, b0, lay, scale, r=r, a_raw=a0 if G is not None else None)
        return len(_ink_changed_blocks(aa, b0, drop=drop, r=r, near_a=near_of("a", a0, r) if G is None else None,
                                       near_b=near_of("b", b0, r)))
    return score


def _warp_gray(a, G, shape, scale: float):
    """옛 판 그레이를 쪽 닮음 변환 G(pt)로 옮겨 새 판 크기(shape)에 — 빈 곳은 흰색."""
    import numpy as np
    from PIL import Image
    ia, ib, itx, ity = _sim_inv(G)
    # 출력 픽셀 (X, Y) → pt (X·s, Y·s) → 옛 pt → 옛 픽셀 (÷s): 계수는 그대로, 이동만 픽셀로
    data = (ia, -ib, itx / scale, ib, ia, ity / scale)
    src = Image.fromarray(np.asarray(a, dtype=np.uint8))
    s = math.hypot(G[0], G[1])
    if s < 0.9:
        # 줄여 옮길 때 가장 가까운 픽셀만 고르면 1픽셀 가는 선(표 틀)이 사라진다 — 먼저 잉크를 넓혀 둔다
        from PIL import ImageFilter
        k = 3 if s >= 0.5 else 5 if s >= 0.3 else 7
        src = src.filter(ImageFilter.MinFilter(k))
    img = src.transform((int(shape[1]), int(shape[0])), Image.AFFINE, data,
                                                                    resample=Image.NEAREST, fillcolor=255)
    return np.asarray(img)


def _dilate(m, r: int):
    """참/거짓 그림을 (2r+1)² 네모로 넓힘 — 가로 한 번·세로 한 번(따로 나눠 4r번 연산)."""
    if r <= 0:
        return m.copy()
    # 바깥을 0으로 채운 사본(np.pad) 없이 잘라 붙여 OR — 같은 결과, 쪽 크기 사본 두 벌을 덜 만든다
    if r >= 4:
        return _dilate_axis(_dilate_axis(m, r, 1), r, 0)
    import numpy as np
    row = np.empty_like(m)                       # 첫 OR은 사본 없이 바로 써 넣는다
    np.bitwise_or(m[:, 1:], m[:, :-1], out=row[:, 1:])
    row[:, :1] = m[:, :1]
    row[:, :-1] |= m[:, 1:]
    for d in range(2, r + 1):
        row[:, d:] |= m[:, :-d]
        row[:, :-d] |= m[:, d:]
    out = np.empty_like(row)
    np.bitwise_or(row[1:], row[:-1], out=out[1:])
    out[:1] = row[:1]
    out[:-1] |= row[1:]
    for d in range(2, r + 1):
        out[d:, :] |= row[:-d, :]
        out[:-d, :] |= row[d:, :]
    return out


def _dilate_axis(m, r: int, ax: int):
    """한 방향(ax)으로 반지름 r 넓힘 — 반지름 k로 넓힌 것을 ±s 옮겨 OR 하면 반지름 k+s(s ≤ 2k+1이면 빈틈 없음)라 반지름을 1·4·…로
    키워 log r 번에. 옮긴 중간 자리가 그림 밖으로 나가도 빠짐이 없게 양끝에 r칸 0(거짓)을 붙여 센 뒤 잘라 낸다 — 2r번 OR 한 것과 같다."""
    import numpy as np
    n = m.shape[ax]
    pad = [(0, 0), (0, 0)]
    pad[ax] = (r, r)
    cur = np.pad(m, pad, mode="constant")

    def sl(a, b):
        return (slice(a, b), slice(None)) if ax == 0 else (slice(None), slice(a, b))
    k = 0
    while k < r:
        s = 1 if k == 0 else min(2 * k + 1, r - k)
        nxt = np.empty_like(cur)
        np.bitwise_or(cur[sl(s, None)], cur[sl(None, -s)], out=nxt[sl(s, None)])
        nxt[sl(None, s)] = cur[sl(None, s)]
        nxt[sl(None, -s)] |= cur[sl(s, None)]
        cur, k = nxt, k + s
    return np.ascontiguousarray(cur[sl(r, r + n)])


def _ink_same(x, y, r: int = 2):
    """x와 y의 잉크가 서로 r픽셀 안에 있는가(픽셀마다) — 한쪽의 뚜렷한 잉크(180 밑)가 다른 쪽 r픽셀 안에 옅은 잉크(230 밑)로라도 있다."""
    import numpy as np
    h, w = x.shape

    def dil(m):
        return _dilate(m, r)
    return ~(((y < 180) & ~dil(x < 230)) | ((x < 180) & ~dil(y < 230)))


def _px_same(x, y, r: int = 2, tol: int = 60):
    """x와 y가 픽셀마다 같은가(서로의 r픽셀 이웃 명도 범위 ± tol 안) — 옮겨 다시 그린 자리의 안티앨리어싱을 견딘다."""
    import numpy as np
    h, w = x.shape
    x16, y16 = x.astype(np.int16), y.astype(np.int16)

    def nb(z):
        p = np.pad(z, r, mode="edge")
        sh = [p[r + dy:r + dy + h, r + dx:r + dx + w] for dy in range(-r, r + 1) for dx in range(-r, r + 1)]
        return np.minimum.reduce(sh), np.maximum.reduce(sh)
    ymin, ymax = nb(y16)
    xmin, xmax = nb(x16)
    return (x16 >= ymin - tol) & (x16 <= ymax + tol) & (y16 >= xmin - tol) & (y16 <= xmax + tol)


def _ink_changed_blocks(a, b, drop=None, r: int = 2, block_min: int = _VIS_BLOCK_MIN_PX, near_a=None, near_b=None):
    """맞춰 놓은 옛 그림(a)과 새 그림(b)의 잉크 비교 — 한쪽의 뚜렷한 잉크(명도 180 밑)가 다른 쪽 r픽셀 안에 옅은 잉크(230 밑)조차
    없을 때만 다른 픽셀. 0.5~3° 돌려 다시 그린 가는 선은 안티앨리어싱 명도가 픽셀마다 달라 명도 비교로는 선을 따라 점선처럼
    '그림 변경'이 남았다. 새로 그은 선·지운 도형은 다른 쪽에 잉크가 아예 없어 그대로 잡힌다.
    near_a·near_b: 이미 센 _dilate(a < 230, r)·_dilate(b < 230, r) (같은 그림을 거듭 견줄 때 — 같은 값)"""
    if near_a is None:
        near_a = _dilate(a < 230, r)
    if near_b is None:
        near_b = _dilate(b < 230, r)
    mask = ((b < 180) & ~near_a) | ((a < 180) & ~near_b)
    if drop is not None and drop.shape == mask.shape:
        mask = mask & ~drop
    return _block_hits(mask, block_min)


def _runs_rows(z):
    """참/거짓 그림(2차원)의 행마다 끊김 없는 참 구간 — (시작 열, 끝 열(끝 다음)) 배열 둘. 모든 행의 구간을 행 차례로 잇는다."""
    import numpy as np
    k, w = z.shape
    p = np.zeros((k, w + 2), dtype=np.int8)
    p[:, 1:-1] = z
    d = np.diff(p, axis=1)
    return np.nonzero(d == 1)[1], np.nonzero(d == -1)[1]


def _frame_extend(img, box: tuple, grow: int, minrun: int, bounded=False) -> tuple:
    """글줄 덩어리 자리(px, (y0, y1, x0, x1))를 그 자리를 지나는 긴 가로·세로 선(표 틀)의 끝까지 넓힌다 — 최대 grow px.
    부품표·개정표는 끝 칸 글자 뒤로 틀이 수십 pt 더 이어져, 글줄 자리만으로는 옮긴 표의 오른쪽 틀이 '그림 변경'으로 남았다.
    bounded면 grow 창 밖으로는 넓히지 않는다("y"면 위아래로만·"x"면 좌우로만 — 새 표 행은 가로 칸 선을 표 너비까지 따라가되 쪽 테두리 세로선을
    따라 쪽 높이로 넓어지지 않게) — 옮긴 곳에 잉크가 있는지 따로 확인하지 않는 설명(다른 쪽으로 옮긴 글줄의 빈 자리·
    늘어난 표 틀)에 쓴다. 표제란이 쪽 테두리에 붙어 있으면 테두리 선을 따라 쪽 전체로 넓어져 지운 도형까지 '배치'로 숨겼다."""
    import numpy as np
    h, w = img.shape
    y0, y1, x0, x1 = box
    wy0, wy1, wx0, wx1 = max(0, y0 - grow), min(h, y1 + grow), max(0, x0 - grow), min(w, x1 + grow)
    if wy1 <= wy0 or wx1 <= wx0:
        return box
    ny0, ny1, nx0, nx1 = y0, y1, x0, x1
    # 선은 끝까지 따라간다(머리글·바닥글 구분선·세로 띠 표제란 선은 쪽 너비·높이) — 옛 자리 설명은 그 잉크가 옮긴 자리에
    # 그대로 있을 때만이라(_layout_drop) 넓어진 자리에서 지운 도형은 남는다
    # (행·열마다 돌던 것을 한 번에 — 결과는 같다. 뒤흔들기 PDF에서 한 쪽에 수천 번 불려 그림 비교의 5분의 1을 썼다)
    ra, rb = max(y0, wy0), min(y1, wy1)
    ca, cb = max(x0, wx0), min(x1, wx1)
    if rb > ra:
        z = img[ra:rb] < 160
        z = z[np.add.reduce(z.view(np.uint8), axis=1, dtype=np.uint32) >= minrun]   # 잉크가 minrun보다 적은 행에는 그만한 선이 없다
        if len(z):
            s_, e_ = _runs_rows(z)
            sel = (e_ - s_ >= minrun) & (s_ < x1) & (e_ > x0)
            if sel.any():
                nx0, nx1 = min(nx0, int(s_[sel].min())), max(nx1, int(e_[sel].max()))
    if cb > ca:
        z = img[:, ca:cb] < 160
        z = z[:, np.add.reduce(z.view(np.uint8), axis=0, dtype=np.uint32) >= minrun]
        if z.shape[1]:
            s_, e_ = _runs_rows(np.ascontiguousarray(z.T))
            sel = (e_ - s_ >= minrun) & (s_ < y1) & (e_ > y0)
            if sel.any():
                ny0, ny1 = min(ny0, int(s_[sel].min())), max(ny1, int(e_[sel].max()))
    if bounded:
        if bounded != "x":
            ny0, ny1 = max(ny0, wy0), min(ny1, wy1)
        if bounded != "y":
            nx0, nx1 = max(nx0, wx0), min(nx1, wx1)
    return max(0, ny0 - 2), min(h, ny1 + 2), max(0, nx0 - 2), min(w, nx1 + 2)


LAYOUT_FRAME_STRETCH = True
LAYOUT_SPLIT_PAIR = True        # 쪽 나눔: 짝 없는 새 쪽도 옛 쪽과 맞대고, 비운 그림은 형제 쪽 같은 자리 잉크로 확인


def _straight(m, L: int):
    """참/거짓 그림에서 가로나 세로로 L픽셀 넘게 끊김 없이 이어진 잉크 픽셀(곧은 선) — 이웃 1픽셀까지."""
    import numpy as np
    m = np.asarray(m, dtype=bool)

    def run(z, ax):
        # ax 방향으로 L칸 넘게 이어진 참 픽셀 — 누적합(쪽 전체 int32를 몇 번씩) 대신 참/거짓 AND·OR를 두 배씩 늘려(log L번)
        n = z.shape[ax]
        if n < L:
            return np.zeros_like(z)

        def sl(a, b):
            return (slice(a, b), slice(None)) if ax == 0 else (slice(None), slice(a, b))
        # 시작 자리 j: [j, j+L) 가 다 잉크 — 길이 k 구간 판정을 겹쳐 길이 2k로 (마지막은 L-k만큼 겹친다)
        e, k = z, 1
        while 2 * k <= L:
            e = e[sl(None, -k)] & e[sl(k, None)]
            k *= 2
        if k < L:
            e = e[sl(None, -(L - k))] & e[sl(L - k, None)]
        # 픽셀 j는 시작 자리 j-L+1..j 가운데 하나라도 있으면 선 위
        d = np.zeros_like(z)
        d[sl(0, n - L + 1)] = e
        # 제자리 OR — 겹치는 자리의 입력은 numpy가 OR 전 값으로 읽는다(겹침 없는 연산과 같다고 보장)
        k = 1
        while 2 * k <= L:
            d[sl(k, None)] |= d[sl(None, -k)]
            k *= 2
        if k < L:
            d[sl(L - k, None)] |= d[sl(None, -(L - k))]
        return d
    out = run(m, 1) | run(m, 0)
    return _dilate(out, 1)


def _layout_drop(a, b, lay: dict, scale: float, r: int = 2, a_raw=None):
    """자리만 옮긴 덩어리로 설명되는 픽셀(새 판 좌표, bool) — 새 자리: 옛 그림(a, 이미 쪽 변환을 맞춘 것)을 덩어리만큼 옮긴 것과
    같은 픽셀, 옛 자리: 새 판이 흰(비운) 픽셀. 덩어리가 없으면 None."""
    import numpy as np
    if not lay or a.shape != b.shape or not (lay.get("clusters") or lay.get("restyled") or lay.get("away")
                                             or lay.get("removed") or lay.get("sib") is not None):
        return None
    h, w = b.shape

    def px(r: _Region):
        return (max(0, int(r.y0 / scale)), min(h, int(math.ceil(r.y1 / scale)) + 1),
                max(0, int(r.x0 / scale)), min(w, int(math.ceil(r.x1 / scale)) + 1))
    areas = []
    inA = np.zeros((h, w), dtype=bool)
    G = lay.get("G")
    for olds, news, (dx, dy), raws in lay["clusters"]:
        hs = sorted(r.y1 - r.y0 for r in news)
        hmed = hs[len(hs) // 2]
        pad, vpad = max(4.0, 0.9 * hmed), max(4.0, 1.6 * hmed)       # 위아래는 머리글·바닥글 구분선까지
        grow, minrun = int(max(40.0, 4 * hmed) / scale), max(12, int(2.5 * hmed / scale))
        if G is not None and a_raw is not None:
            # 쪽을 돌린 판 — 표 틀 찾기는 돌리기 전 옛 그림(가로·세로 선이 곧은)에서 하고 그 자리를 쪽 변환으로 옮긴다
            ra = raws
            hr, wr = a_raw.shape
            A0 = (max(0, int((min(q.y0 for q in ra) - vpad) / scale)), min(hr, int(math.ceil((max(q.y1 for q in ra) + vpad) / scale)) + 1),
                  max(0, int((min(q.x0 for q in ra) - pad) / scale)), min(wr, int(math.ceil((max(q.x1 for q in ra) + pad) / scale)) + 1))
            As = []
            for _bd in ("y", "x"):
                y0_, y1_, x0_, x1_ = _frame_extend(a_raw, A0, grow, minrun, bounded=_bd)
                As.append(px(_sim_rect(G, _Region(x0_ * scale, y0_ * scale, x1_ * scale, y1_ * scale))))
        else:
            A = px(_Region(min(r.x0 for r in olds) - pad, min(r.y0 for r in olds) - vpad,
                           max(r.x1 for r in olds) + pad, max(r.y1 for r in olds) + vpad))
            # 표 틀(긴 가로·세로 선)이 글줄 자리 밖으로 이어지면 그 끝까지 — 옛 판 그림에서 잰다. 가로선은 좌우로·세로선은 위아래로만
            # 넓힌 띠 둘로 — 한 사각형으로 합치면 쪽 테두리에 붙은 표제란이 가로·세로 테두리를 따라 쪽 전체가 되어, 옮긴 자리 잉크와
            # 우연히 겹친 지운 도형까지 '배치'로 숨겼다 (뒤흔들기 B00-049, 원칙 5)
            As = [_frame_extend(a, A, grow, minrun, bounded=_bd) for _bd in ("y", "x")]
        ix, iy = int(round(dx / scale)), int(round(dy / scale))
        for A in As:
            B = (max(0, A[0] + iy), min(h, A[1] + iy), max(0, A[2] + ix), min(w, A[3] + ix))
            areas.append((A, B, ix, iy))
            if A[1] > A[0] and A[3] > A[2]:
                inA[A[0]:A[1], A[2]:A[3]] = True
    E = np.zeros((h, w), dtype=bool)

    def shifted(src, y0, y1, x0, x1, dy, dx):
        # src를 (dy, dx)만큼 옮긴 그림(빈 곳 255)의 [y0:y1, x0:x1] 창만 — 쪽 크기 사본을 만들어 자르던 것과 같은 값
        out = np.full((y1 - y0, x1 - x0), 255, dtype=src.dtype)
        qy0, qy1 = max(y0 - dy, 0), min(y1 - dy, h)
        qx0, qx1 = max(x0 - dx, 0), min(x1 - dx, w)
        if qy1 > qy0 and qx1 > qx0:
            out[qy0 + dy - y0:qy1 + dy - y0, qx0 + dx - x0:qx1 + dx - x0] = src[qy0:qy1, qx0:qx1]
        return out
    for A, B, ix, iy in areas:
        # 새 자리: 옛 그림을 덩어리만큼 옮긴 것과 같고, 그 자리에 옛 판 잉크가 없었거나(빈 곳으로 옮김) 그 잉크도 옮긴 덩어리의
        # 옛 자리일 때만 — 옮겨 온 덩어리가 그 자리의 옛 그림을 덮어 지운 것은 설명하지 않는다
        y0, y1, x0, x1 = B
        if y1 > y0 and x1 > x0:
            # 옛 잉크를 새 판이 비운 픽셀은 새 자리 설명이 아니다 — 옮긴 곳에 잉크가 있는지 보는 옛 자리 규칙(아래)만 설명한다.
            # 둘 다 흰 픽셀까지 '같다'로 넣으면 조금 옮긴 덩어리 자리 안에서 지운 원이 통째 '배치'가 됐다 (뒤흔들기 B00-049, 원칙 5)
            E[y0:y1, x0:x1] |= (_ink_same(shifted(a, y0, y1, x0, x1, iy, ix), b[y0:y1, x0:x1], r)
                                & ((a[y0:y1, x0:x1] >= 200) | inA[y0:y1, x0:x1])
                                & ~((a[y0:y1, x0:x1] < 180) & (b[y0:y1, x0:x1] >= 200)))
        # 옛 자리: 새 판에서 비었고(흰), 그 자리의 옛 잉크는 옮긴 자리(새 판)에 잉크로 있다 — 지운 도형은 옮긴 자리에 없어 남는다
        y0, y1, x0, x1 = A
        if y1 > y0 and x1 > x0:
            # bb[p] = b[p + d] (그 창만)
            went = _ink_same(a[y0:y1, x0:x1], shifted(b, y0, y1, x0, x1, -iy, -ix), r) | (a[y0:y1, x0:x1] >= 180)
            E[y0:y1, x0:x1] |= (b[y0:y1, x0:x1] >= 200) & went
    # 다른 쪽으로 옮겨 간 글줄(쪽 나눔)의 옛 자리 — 새 판에서 비었을 때만(표 틀까지)
    for o in lay.get("away") or ():
        hh = min(o.y1 - o.y0, o.x1 - o.x0)          # 글줄 굵기 — 세로 글줄(돌린 쪽)의 길이로 재면 쪽 전체로 넓어졌다
        if G is not None and a_raw is not None:
            hr, wr = a_raw.shape
            A0 = (max(0, int((o.y0 - 0.9 * hh) / scale)), min(hr, int(math.ceil((o.y1 + 0.9 * hh) / scale)) + 1),
                  max(0, int((o.x0 - 0.9 * hh) / scale)), min(wr, int(math.ceil((o.x1 + 0.9 * hh) / scale)) + 1))
            y0_, y1_, x0_, x1_ = _frame_extend(a_raw, A0, int(max(40.0, 4 * hh) / scale), max(12, int(2.5 * hh / scale)),
                                               bounded=("y" if o.x1 - o.x0 >= o.y1 - o.y0 else "x"))   # 옛 그림 좌표의 글줄 방향
            y0, y1, x0, x1 = px(_sim_rect(G, _Region(x0_ * scale, y0_ * scale, x1_ * scale, y1_ * scale)))
        else:
            # 글줄 방향으로는 표 틀 끝까지(쪽 너비 띠 표제란), 그 직각으로는 창 안까지만 — 쪽 테두리에 붙은 표제란이 테두리 선을
            # 따라 쪽 전체로 넓어지지 않게
            y0, y1, x0, x1 = _frame_extend(a, px(_Region(o.x0 - 0.9 * hh, o.y0 - 0.9 * hh, o.x1 + 0.9 * hh, o.y1 + 0.9 * hh)),
                                           int(max(40.0, 4 * hh) / scale), max(12, int(2.5 * hh / scale)),
                                           bounded=("y" if o.x1 - o.x0 >= o.y1 - o.y0 else "x"))
        if y1 > y0 and x1 > x0:
            E[y0:y1, x0:x1] |= b[y0:y1, x0:x1] >= 200
    # 글꼴·자간을 바꿔 칸이 늘거나 준 표 — 그 글줄이 든 표 틀 범위 안에서 **곧은 선**(가로·세로로 길게 이어진 잉크) 픽셀만은
    # 틀이 늘거나 줄며 옮겨진 것이다(맞춘 쪽에서만 — 글자 길이가 3% 넘게 달라진 줄의 표)
    if G is not None and LAYOUT_FRAME_STRETCH:
        boxes = []
        for o, n in list(lay.get("restyled") or []) + list(lay.get("removed") or []):
            rw = (n.x1 - n.x0) / max(0.1, o.x1 - o.x0)
            rh = (n.y1 - n.y0) / max(0.1, o.y1 - o.y0)
            if abs(rw - 1) <= 0.03 and abs(rh - 1) <= 0.03:
                continue
            th = min(n.y1 - n.y0, n.x1 - n.x0)
            box = px(_Region(min(o.x0, n.x0) - th, min(o.y0, n.y0) - th, max(o.x1, n.x1) + th, max(o.y1, n.y1) + th))
            minrun = max(12, int(2.5 * th / scale))
            # 글줄 방향으로는 표 틀 끝까지(칸이 늘어난 표의 끝 선), 그 직각으로는 창 안까지만
            _bd = "y" if n.x1 - n.x0 >= n.y1 - n.y0 else "x"
            y0, y1, x0, x1 = _frame_extend(b, box, int(max(40.0, 4 * th) / scale), minrun, bounded=_bd)
            ya0, ya1, xa0, xa1 = _frame_extend(a, box, int(max(40.0, 4 * th) / scale), minrun, bounded=_bd)
            boxes.append(((min(y0, ya0), max(y1, ya1), min(x0, xa0), max(x1, xa1)), minrun))
        if boxes:
            # 곧은 선 그림은 쪽에 한 번(글줄마다 다시 셈하면 큰 도면에서 몇 초씩 걸렸다) — 선 길이 기준은 글줄들 가운데값
            mr = sorted(m_ for _b, m_ in boxes)[len(boxes) // 2]
            # 상자마다 선 길이(mr)+1 만큼 둘레를 붙여 잘라 센다 — 상자 안 픽셀의 판정(선 L칸 창·1픽셀 넓힘)은 그 둘레 밖을 보지
            # 않아 쪽 전체로 센 것과 같다
            win = []
            for (y0, y1, x0, x1), _m in dict.fromkeys(boxes):
                if y1 > y0 and x1 > x0:
                    win.append(((y0, y1, x0, x1), (max(0, y0 - mr - 1), min(h, y1 + mr + 1), max(0, x0 - mr - 1), min(w, x1 + mr + 1))))
            # 겹치는 창은 둘을 덮는 사각형이 두 창 넓이 합보다 크지 않으면 하나로 — 어느 창으로 세어도 상자 안 값은 같다
            groups = [[c, [bx]] for bx, c in win]
            merged = True
            while merged and len(groups) > 1:
                merged = False
                for i in range(len(groups)):
                    for j in range(i + 1, len(groups)):
                        (p0, p1, p2, p3), (q0, q1, q2, q3) = groups[i][0], groups[j][0]
                        u = (min(p0, q0), max(p1, q1), min(p2, q2), max(p3, q3))
                        if (u[1] - u[0]) * (u[3] - u[2]) <= (p1 - p0) * (p3 - p2) + (q1 - q0) * (q3 - q2):
                            groups[i] = [u, groups[i][1] + groups[j][1]]
                            del groups[j]
                            merged = True
                            break
                    if merged:
                        break
            for (cy0, cy1, cx0, cx1), bxs in groups:
                st = _straight(a[cy0:cy1, cx0:cx1] < 180, mr) | _straight(b[cy0:cy1, cx0:cx1] < 180, mr)
                for (y0, y1, x0, x1) in bxs:
                    E[y0:y1, x0:x1] |= st[y0 - cy0:y1 - cy0, x0 - cx0:x1 - cx0]
    # 글꼴을 바꾸며 자리도 옮긴 글줄 — 옛 자리는 비었을 때만, 새 자리는 글자 상자 안(한쪽에만 그은 가로선은 빼고)
    for o, n in lay.get("removed") or ():
        y0, y1, x0, x1 = px(_Region(o.x0 - 1, o.y0 - 1, o.x1 + 1, o.y1 + 1))
        if y1 > y0 and x1 > x0:
            E[y0:y1, x0:x1] |= b[y0:y1, x0:x1] >= 200
        y0, y1, x0, x1 = px(_Region(n.x0 - 1, n.y0 - 1, n.x1 + 1, n.y1 + 1))
        if y1 > y0 and x1 > x0:
            win = np.ones((y1 - y0, x1 - x0), dtype=bool)
            for ly, sx0, sx1 in (_new_hline_segs(a[y0:y1, x0:x1], b[y0:y1, x0:x1], min_run=max(20, (x1 - x0) // 2)) if x1 - x0 >= y1 - y0 else ()):
                win[max(0, ly - 1):ly + 3, max(0, sx0 - 2):sx1 + 2] = False
            E[y0:y1, x0:x1] |= win
    # 같은 자리에 글꼴만 바꿔 다시 그린 글줄 — 옛·새 글자 상자 안, 한쪽에만 그은 가로선(취소선·밑줄)은 빼고
    for o, n in lay.get("restyled") or ():
        y0, y1, x0, x1 = px(_Region(min(o.x0, n.x0) - 1, min(o.y0, n.y0) - 1, max(o.x1, n.x1) + 1, max(o.y1, n.y1) + 1))
        if y1 <= y0 or x1 <= x0:
            continue
        win = np.ones((y1 - y0, x1 - x0), dtype=bool)
        for ly, sx0, sx1 in (_new_hline_segs(a[y0:y1, x0:x1], b[y0:y1, x0:x1], min_run=max(20, (x1 - x0) // 2)) if x1 - x0 >= y1 - y0 else ()):
            win[max(0, ly - 1):ly + 3, max(0, sx0 - 2):sx1 + 2] = False
        E[y0:y1, x0:x1] |= win
    # 쪽 나눔 — 이 쪽에서 비운 옛 잉크가 같은 옛 쪽을 나눠 받은 다른 새 쪽의 같은 자리에 있으면 그리로 옮긴 것이다
    sib = lay.get("sib")
    if sib is not None and sib.shape == b.shape:
        E |= (b >= 200) & _dilate(sib < 180, r)
    return E


def visual_page_diff(old, new, capture_top: int | None = None,
                     sensitive: bool = False, ignore_texts=(), ignore_boxes=(),
                     anchors: dict | None = None, title_boxes=(), new_renders=None,
                     strong_px: int = 0, _natural: bool = False, split: bool = False) -> tuple[list, dict] | None:
    """두 판의 페이지별 픽셀 비교 → 변경 '위치' 목록.

    old/new: PDF 경로, DXF 경로, 또는 검사 때 기록해 둔 페이지 그림 목록
    (render.PageRender). 같은 이름으로 덮어써 이전 판 파일이 없어도 기록으로
    비교한다 (2026-09-02: "도면 변경점을 거의 못 잡고 스샷도 없다").

    전체 면적 비율이 아니라 변경 픽셀의 뭉침(블록 클러스터)으로 판정한다 —
    가는 배선 한 가닥의 추가/삭제도 위치로 잡히고, 점 소음은 걸러진다
    (2026-08-24 실사용 피드백: 면적 기준은 글자만 잡고 배선 변경을 놓침).

    돌려주는 값: ([(key, where)], {key: {'before':…, 'after':…}})
      key   = "17페이지 위치1" (ChangeItem.key와 캡처 키로 공용)
      where = "17페이지 좌표 (x, y) 부근" / DXF는 "도면 좌표 (x, y) 부근"
    모든 위치에 전/후 확대 사진 첨부 (기본). capture_top을 주면 변경이 큰
    순으로 그 수만 첨부.
    ignore_texts: 글자 비교가 이미 잡은 새 글줄들 — 그 자리의 픽셀 차이는 '그림
    변경'이 아니다. 표제란·리비전 블록 글자가 그림 변경 3곳으로 부풀고, 'Rev만
    갱신' 판정이 DXF에서 절대 안 나오던 원인 (2026-09-03 검토).
    실패하면 None — '시각 변경 없음'([], {})과 구분해 호출부가 '비교 못 함'을
    고지할 수 있게 (2026-08-26 리뷰: 침묵 실패는 원칙 4 위반).
    new_renders: 새 판(DXF 파일)을 기록할 때 그린 그림 — 옛 판 틀과 같으면 다시 그리지 않는다.
    strong_px: 0보다 크면 묶음 안에 뚜렷이 바뀐 픽셀(회색 차 80 넘음)이 이만큼 있는 묶음만 — 스캔본 민감 비교에서 재스캔
    잡음(차 20대 픽셀 몇 개)을 거른다 (2026-10-20 PDF 대량 시험 O2).
    _natural: DXF 새 판을 옛 판 틀이 아니라 제 범위로 그려 견준다(전체 이동·축척 재비교 — 아래 _moved_only)."""
    os_ = ns_ = None
    try:
        os_ = _source(old)
        fit = os_.meta() if isinstance(os_, _RenderSource) else None
        ns_ = _natural_source(new, new_renders) if _natural else _source(new, fit=fit, renders=new_renders)
    except Exception:
        if os_ is not None:
            os_.close()
        return None
    try:
        scale = 72.0 / _VIS_DPI  # 렌더 px → pt
        pairs, old_only, new_only = align_pages(os_, ns_, anchors=anchors)
        # 이전 판이 '기록'(파일당 MAX_PAGES쪽까지)이고 새 판이 그보다 길면, 상한 밖 페이지는
        # 비교 대상이 아니지 '추가된 페이지'가 아니다 — 40쪽 PDF에서 31~40쪽이 "이전 판에
        # 없는 페이지 (추가)"로 지어졌다 (검토19 브리핑 ①)
        beyond_note = ""
        if isinstance(os_, _RenderSource):
            from watcher.render import MAX_PAGES as _MAXP
            if len(os_) >= _MAXP and len(ns_) > len(os_):
                beyond = [p for p in new_only if p > _MAXP]
                if beyond:
                    new_only = [p for p in new_only if p <= _MAXP]
                    beyond_note = (f"{_MAXP + 1}쪽 이후 {len(beyond)}쪽은 그림 기록 상한 밖이라 "
                                   f"비교하지 않았습니다 (글자 비교는 읽은 쪽까지)")
        page_total = len(pairs)
        # 쪽을 나눈 판(글자 비교가 '쪽 나눔'으로 본 판) — 짝 없는 새 쪽도 글줄을 나눠 준 옛 쪽과 맞대 본다. 짝 지은 쪽에서 비운
        # 그림이 그 쪽으로 옮겨 갔는지(같은 자리 잉크)는 형제 쪽 잉크로 확인하고(_layout_drop 'sib'), 옮겨 간 그림의 편집은
        # 이 맞댐에서 남는다 — 전에는 비운 자리를 '다른 쪽으로 옮긴 글줄'로 통째 지워 옮긴 그림의 편집을 숨겼다(원칙 5)
        sibs: dict = {}
        if split and LAYOUT_SPLIT_PAIR and LAYOUT_ALIGN and not sensitive and len(ns_) > len(os_) and new_only:
            try:
                _ok_t = {op: {"".join(t.split()) for t, _r in (_layout_line_boxes(os_, op) or [])}
                         for op in range(1, len(os_) + 1)}
                for p_ in list(new_only):
                    _nt_ = {"".join(t.split()) for t, _r in (_layout_line_boxes(ns_, p_) or [])}
                    _nt_ = {t for t in _nt_ if len(t) >= 3}
                    if not _nt_:
                        continue
                    _n, op = max((len(_nt_ & ts), op) for op, ts in _ok_t.items())
                    if _n >= 2 and _n >= 0.5 * len(_nt_):
                        pairs.append((op, p_))
                        new_only = [q for q in new_only if q != p_]
                for i_, j_ in pairs:
                    sibs.setdefault(i_, []).append(j_)
                sibs = {i_: js for i_, js in sibs.items() if len(js) > 1}
            except Exception:                       # noqa: BLE001
                sibs = {}
        old_of = {j: i for i, j in pairs}          # 새 판 페이지 → 이전 판 페이지
        _lay_cache: dict = {}

        _orig_pairs = set(pairs[:page_total])

        def _prep(op_, p_):
            if (op_, p_) not in _lay_cache:
                try:
                    # 나눠 받은 쪽(짝 없던 새 쪽)은 같은 옛 쪽의 원래 짝이 찾은 쪽 변환도 후보로
                    _h = ([(_prep(op_, q) or {}).get("G") for q in sibs.get(op_, ()) if (op_, q) in _orig_pairs]
                          if (op_, p_) not in _orig_pairs else [])
                    _wm = _WarpMemo()           # 고르기·점수가 같은 옛 쪽 그림을 같은 변환으로 옮긴 것을 나눠 쓴다
                    _lay_cache[(op_, p_)] = _layout_prepare(
                        os_, ns_, op_, p_, pick=_align_picker(os_.gray(op_), ns_.gray(p_), scale, warps=_wm),
                        score=_layout_scorer(os_.gray(op_), ns_.gray(p_), scale, warps=_wm), hints=[g for g in _h if g])
                except Exception:                   # noqa: BLE001
                    _lay_cache[(op_, p_)] = None
            return _lay_cache[(op_, p_)]
        found = []      # (pno, _Region(pt, 좌상단 원점), 블록수)  pno = 새 판 페이지 번호
        wide = []       # 페이지 전체가 어긋난 페이지 (재스캔·기울기)
        overflow: dict = {}   # 상한(_VIS_REGIONS_PER_PAGE) 밖으로 버린 위치 수 {pno: n} (검토42 B 차단 1)
        title_rects: set = set()   # 표제란 틀 안 묶음의 (pno, id(rect)) — where에 '표제란 자리'를 단다
        size_diff = []  # 페이지 크기 자체가 바뀐 페이지
        rotated = []    # 내용은 같고 방향만 돌아간 페이지
        aligned: dict = {}     # 쪽 전체를 맞춰 비교한 쪽 {pno: 닮음 변환 G (옛 pt → 새 pt)}
        lay_gone: dict = {}    # 배치만 바뀜으로 설명된 블록 {pno: set} (맞춘 쪽은 빈 집합이라도 표지)
        _fmt_rects: dict = {}  # 서식만 바뀐 글자 자리 {pno: (자리 목록, 글 목록)} (검토20 r03 4)
        annot_rects: dict = {}  # 메모·도장 주석 자리 묶음 {(pno, id(rect)): 이름표} (검토20 r07 7)
        fmt_only: dict = {}    # 그 자리로 실제 그림 차이를 가린 쪽 {pno: 글 목록}
        for opno, pno in pairs:
            _lay = None
            _same_px = False
            if os_.size(opno) == ns_.size(pno):
                try:
                    _a0, _b0 = os_.gray(opno), ns_.gray(pno)
                    _same_px = _a0.shape == _b0.shape and bool((_a0 == _b0).all())
                except Exception:                   # noqa: BLE001
                    _same_px = False
            if _same_px:
                continue                            # 픽셀까지 같은 쪽 — 맞춤·배치 설명이 필요 없다
            if LAYOUT_ALIGN and not sensitive:
                _lay = _prep(opno, pno)
            if sibs.get(opno) and _lay is not None:
                try:
                    _sg = []
                    _Gp = _lay.get("G") or _SIM_ID
                    for q in sibs[opno]:
                        if q == pno:
                            continue
                        _gq = ns_.gray(q)
                        if _gq.shape == ns_.gray(pno).shape:
                            _sg.append(_gq)                 # 같은 자리 그대로 옮긴 나눔
                        _lq = _prep(opno, q)
                        _Gq = (_lq or {}).get("G") or _SIM_ID
                        if _Gq != _SIM_ID or _Gp != _SIM_ID:
                            # 형제 쪽을 쪽 전체 맞춤으로 옮겨 간 판 — 그 쪽 그림을 옛 판 좌표를 거쳐 이 쪽 좌표로
                            _sg.append(_warp_gray(_gq, _sim_compose(_Gp, _sim_inv(_Gq)), ns_.gray(pno).shape, scale))
                    if _sg:
                        import numpy as np
                        _lay = dict(_lay, sib=np.minimum.reduce(_sg))
                except Exception:                   # noqa: BLE001
                    pass
            _G = _lay["G"] if _lay else None
            if _G is not None and tuple(os_.size(opno))[::-1] == tuple(ns_.size(pno)):
                # 쪽을 90°로 돌리기만 한 판은 맞춤 비교('배치만 바뀜')가 아니라 '방향이 돌아갔습니다' 안내로 (아래 회전 판정 — 매트릭스
                # 'PDF 90도 회전')
                try:
                    import numpy as np
                    a0, b0 = os_.gray(opno), ns_.gray(pno)
                    if any(np.rot90(a0, k).shape == b0.shape
                           and int(np.abs(np.rot90(a0, k).astype(int) - b0.astype(int)).max()) <= _VIS_PIXEL_MIN for k in (1, 3)):
                        rotated.append(pno)
                        continue
                except Exception:                   # noqa: BLE001
                    pass
            if _G is not None:
                # 쪽 전체가 돌아가거나 옮겨지거나 크기가 바뀐 판 — 옛 판 그림을 맞춰 놓고 비교한다 (크기가 달라도)
                try:
                    a = _warp_gray(os_.gray(opno), _G, ns_.gray(pno).shape, scale)
                except Exception:                   # noqa: BLE001
                    _G = _lay = None
            if _G is None and os_.size(opno) != ns_.size(pno):
                # 가로·세로가 맞바뀌었으면 회전만 된 것일 수 있다 — 돌려서 같으면 '내용
                # 변경'은 아니다 (2026-09-06 블라인드 3차 41: 스캔 방향만 바뀐 성적서가
                # '크기 변경'으로 잡히던 것). 다만 **아무 말도 안 하면 안 된다** —
                # 전에는 "내용 변경 없음 — 다시 저장되기만 했습니다"로 끝나서, 도면을
                # 일부러 돌려 놓아도 사용자가 그냥 넘겼다 (2026-09-10 매트릭스 실측).
                # 내용이 같다는 사실과 방향이 바뀌었다는 사실을 함께 말한다.
                if tuple(os_.size(opno))[::-1] == tuple(ns_.size(pno)):
                    import numpy as np
                    a0, b0 = os_.gray(opno), ns_.gray(pno)
                    if any(np.rot90(a0, k).shape == b0.shape and int(np.abs(np.rot90(a0, k).astype(int) - b0.astype(int)).max()) <= _VIS_PIXEL_MIN
                           for k in (1, 3)):
                        rotated.append(pno)
                        continue
                size_diff.append(pno)
                continue
            b = ns_.gray(pno)
            if _G is None:
                a = os_.gray(opno)
            else:
                aligned[pno] = _G
                lay_gone.setdefault(pno, set())
            if a.shape != b.shape:
                size_diff.append(pno)
                continue
            a, b = _white_norm(a, b)           # 바탕 밝기가 다른 재스캔 (검토20 r07 4)
            if (a == b).all():
                continue
            # 민감 모드: 임계값 절반 — 놓친 미세 변경 재탐색용 (오탐은
            # 사람이 [오탐 삭제]로 걷어낸다, 2026-08-27 미탐 대응)
            _lay_kept = None
            if sensitive:
                blocks = _changed_blocks(a, b, pixel_min=20, block_min=4)
            elif _G is not None:
                _r = _align_radius(_G)
                _drop = _layout_drop(a, b, _lay, scale, r=_r, a_raw=os_.gray(opno))
                blocks = _ink_changed_blocks(a, b, drop=_drop, r=_r)
                if _drop is not None:
                    lay_gone[pno] = _ink_changed_blocks(a, b, r=_r) - blocks
            else:
                blocks = _changed_blocks(a, b)
                # 같은 글줄이 같은 자리에 있는 곳은 2픽셀 어긋남까지 허용해 다시 센다 (검토68 B5). 그 글줄 위를 새로 가로지르는
                # 선(취소선·밑줄)은 따로 찾아 그 블록을 바뀐 블록으로 둔다 (_new_hline_segs)
                _hl: set = set()
                # 자간·글꼴만 바꿔 다시 그린 글줄(배치 설명의 restyled)은 짧은 가로 이음을 취소선으로 보지 않는다
                _lr = [n for _o, n in ((_lay or {}).get("restyled") or [])]
                _loose = _same_text_mask(os_, ns_, opno, pno, a.shape, blocks, scale, a, b, hl_out=_hl, long_rects=_lr)
                if _loose is not None:
                    blocks = _changed_blocks(a, b, loose=_loose)
                # 자리만 옮긴 글줄 덩어리(표제란·개정표·부품표를 다른 모서리로)·같은 자리에 다시 그린 글줄로 설명되는 블록 —
                # 다른 거름(바뀐 글줄 가림·행 밀림)을 다 거친 뒤 남은 묶음 가운데 통째로 설명되는 것만 '배치만 바뀜'으로 (아래)
                _lay_kept = None
                if blocks and _lay is not None and (_lay.get("clusters") or _lay.get("restyled") or _lay.get("away")
                                                    or _lay.get("removed") or _lay.get("sib") is not None):
                    _drop = _layout_drop(a, b, _lay, scale)
                    if _drop is not None:
                        _lay_kept = _changed_blocks(a, b, loose=_loose, drop=_drop) | _hl
                blocks = blocks | _hl
            cmin = 1 if sensitive else _VIS_CLUSTER_MIN
            pw, ph = ns_.size(pno)
            # 배치만 바뀜으로 설명되는 블록은 '쪽 전체 어긋남' 판정에서 뺀다 — 표제란을 반대 모서리로 옮기면 바뀐 블록의 테두리가
            # 쪽을 다 덮어 '전체가 살짝 어긋남'으로 접혀 'Rev만 갱신'이 사라졌다
            _wb = _lay_kept if _lay_kept is not None else blocks
            if _wb and not sensitive:
                # 재스캔·1° 기울기·평행이동은 바뀐 블록이 페이지에 흩어져 뭉치지 않는다 — 합집합이 60% 넘고
                # 잉크 분포가 거의 같으면 페이지 전체 어긋남 한 줄로 (리뷰13 중간-3: 기울기 ≤1°가 위치 3곳)
                xs_ = [b[0] for b in _wb]
                ys_ = [b[1] for b in _wb]
                ux0, uy0 = min(xs_) * _VIS_BLOCK * scale, min(ys_) * _VIS_BLOCK * scale
                ux1, uy1 = (max(xs_) + 1) * _VIS_BLOCK * scale, (max(ys_) + 1) * _VIS_BLOCK * scale
                # 판정이 '바뀐 블록의 bbox가 페이지 60%를 덮나'뿐이라, 진짜 변경이 **두 곳**이어도
                # 좌상단·우하단이면 통째로 접혔다 — 미탐과 거짓 'Rev만 갱신'을 동시에 만들었다
                # (2026-09-09 비교 검토 차단). 재스캔·기울기는 페이지 전면의 잉크를 흔들어
                # 바뀐 블록이 **많다**. 그 밀도를 함께 본다.
                gh_, gw_ = a.shape[0] // _VIS_BLOCK + 1, a.shape[1] // _VIS_BLOCK + 1
                spread = len(_wb) >= max(24, int(0.05 * gh_ * gw_))
                if spread and (ux1 - ux0) * (uy1 - uy0) >= 0.6 * pw * ph:
                    try:
                        _ta, _tb = _white_norm(os_.thumb(opno), ns_.thumb(pno))
                        same_ink = _sig_sim_ink(_ink_sig(_ta), _ink_sig(_tb)) >= 0.9
                    except Exception:
                        same_ink = False
                    if same_ink:
                        wide.append((pno, _Region(ux0, uy0, ux1, uy1), len(_wb)))
                        continue
            # 새 판뿐 아니라 **옛 판**에서도 찾는다 — 지워진 글줄의 자리는 새 판엔 없어 '그림 변경'으로
            # 찍혔다 (검토21 감지 중간 9·브리핑 차단 5)
            masks = (list(ns_.text_boxes(pno, ignore_texts, title_boxes=title_boxes))
                     + [(r if _G is None else _sim_rect(_G, r))
                        for r in os_.text_boxes(opno, ignore_texts, title_boxes=title_boxes)]) if ignore_texts else []
            # OCR로 읽은 글줄의 자리 — 스캔본은 글자 검색이 안 되므로 추출기가 준 사각형으로 (2026-09-06 사용성 5차:
            # Rev 글자 자체가 '그림 변경'으로 세어져 'Rev만 갱신' 판정이 사라지고 가짜 'Rev 미갱신'이 났다)
            masks += [_Region(x0, y0, x1, y1) for (bp, x0, y0, x1, y1) in ignore_boxes if bp == pno]
            if _G is not None and ignore_texts:
                # 맞춰 비교한 쪽 — 한쪽 판에만 있는 글줄(글자 비교가 이미 잡은 추가·삭제 줄: 개정표 새 행 등)의 자리. 글자판 찾기는
                # 글자를 뒤섞어 그린 판·'REV 3 · …' 꼴 항목 글로는 못 찾았다
                try:
                    _o2, _n2 = _layout_line_boxes(os_, opno) or [], _layout_line_boxes(ns_, pno) or []
                    _ok = {"".join(t.split()) for t, _r in _o2}
                    _nk = {"".join(t.split()) for t, _r in _n2}
                    for t, r in _n2:
                        if "".join(t.split()) in _ok:
                            continue
                        # 새 행이면 그 행의 칸 선(위아래 가로선·세로 칸 선)까지 — 칸 선 따라 넓힌 자리
                        hh = min(r.y1 - r.y0, r.x1 - r.x0)          # 글줄 굵기(세로 글줄은 가로 폭)
                        y0_, y1_, x0_, x1_ = _frame_extend(
                            b, (max(0, int((r.y0 - 0.8 * hh) / scale)), int(math.ceil((r.y1 + 0.8 * hh) / scale)) + 1,
                                max(0, int((r.x0 - 0.8 * hh) / scale)), int(math.ceil((r.x1 + 0.8 * hh) / scale)) + 1),
                            int(max(20.0, 2 * hh) / scale), max(12, int(2.5 * hh / scale)),
                            bounded=("y" if r.x1 - r.x0 >= r.y1 - r.y0 else True))
                        masks.append(_Region(x0_ * scale, y0_ * scale, x1_ * scale, y1_ * scale))
                    masks += [_sim_rect(_G, r) for t, r in _o2 if "".join(t.split()) not in _nk]
                except Exception:                           # noqa: BLE001
                    pass
            if ignore_texts and isinstance(ns_, _PdfSource):
                # 글자판 검색은 칸마다 따로 놓인 표 행('B 2026-10-06 펌프 양정 변경 LJW')을 한 문자열로 못 찾는다 — 글줄 자리
                # (기록된 옛 판과 같은 방식)로도 찾는다 (벤치 pdf68 B32: 개정표 새 행이 덤 '그림 변경')
                _m = _text_matcher(ignore_texts)
                masks += [r for t, r in _line_boxes(ns_, pno) if _m(t)]
            _is_dxf = isinstance(ns_, _RenderSource) and bool(ns_._dxf_path)
            _ot = _nt = None
            if blocks and not sensitive and "scale" in (ns_.meta(pno) if isinstance(ns_, _RenderSource) else {}):
                try:
                    (_ot, _ok), (_nt, _nk) = _all_text_rects_k(os_, opno), _all_text_rects_k(ns_, pno)
                    masks += _rerendered_text_rects(_ot, _nt, _ok, _nk)
                    if _G is None:
                        _fo, _fot = _format_only_rects(_ot, _nt, _text_fmts(os_, opno, len(_ot)), _text_fmts(ns_, pno, len(_nt)))
                        if _fo:
                            masks += _fo
                            _fmt_rects[pno] = (_fo, _fot)
                    if _is_dxf and masks:
                        # 새로 생긴·없어진 글자 객체(개정표 새 행의 같은 설명 등) — 글자 변경이 이미 있는 판에서만 (C9)
                        masks += _added_text_rects(_ot, _nt)
                except Exception:                           # noqa: BLE001
                    pass
            if masks:
                # 글자 변경 자리의 블록만 뺀다 — 클러스터째 버리면 바뀐 글줄 바로 옆을
                # 지나는 배선 변경까지 사라진다 (2026-09-03 재검토)
                _hid = {b for b in blocks
                        if any(_overlaps(_block_rect(b, scale), m, pad=2.0) for m in masks)}
                # DXF: 가린 자리에 **새 도형**(취소선·작은 원·새 선)이 지나가면 그 블록은 남긴다 — 글자 자리 가림이 글자 위
                # 취소선·끝 옆 원·폭 여유 안의 새 선까지 지웠다 (검토69 B V4·V4b·V5)
                if _hid and _is_dxf and not sensitive:
                    try:
                        _hid -= _geom_new_blocks(ns_, pno, a, _hid)
                    except Exception:                       # noqa: BLE001
                        pass
                if pno in _fmt_rects and _hid:
                    _fr, _ft = _fmt_rects[pno]
                    if any(_overlaps(_block_rect(b_, scale), m_, pad=2.0) for b_ in _hid for m_ in _fr):
                        fmt_only[pno] = _ft
                blocks = blocks - _hid
            _all_groups = _clusters(blocks, cluster_min=cmin)
            if strong_px > 0 and _all_groups:
                import numpy as np
                _bs = _VIS_BLOCK

                def _strong(g):
                    xs_g, ys_g = [q[0] for q in g], [q[1] for q in g]
                    win_a = a[min(ys_g) * _bs:(max(ys_g) + 1) * _bs, min(xs_g) * _bs:(max(xs_g) + 1) * _bs]
                    win_b = b[min(ys_g) * _bs:(max(ys_g) + 1) * _bs, min(xs_g) * _bs:(max(xs_g) + 1) * _bs]
                    return int((np.abs(win_a.astype(int) - win_b.astype(int)) > 80).sum()) >= strong_px
                _all_groups = [g for g in _all_groups if _strong(g)]
            if _all_groups and masks and not sensitive and _G is None:
                # 표 행 추가·삭제로 밀린 테두리·머리글 — 글자 변경으로 이미 설명된다 (_row_shift_explained)
                try:
                    if _ot is None:
                        _ot, _nt = _all_text_rects(os_, opno), _all_text_rects(ns_, pno)
                    if _ot and _nt:
                        _expl: list = []                    # (묶음 사각형, 설명한 dy)
                        _left = []
                        for g in _all_groups:
                            dy_ = _row_shift_dy(a, b, g, scale, masks, _ot, _nt, spacing=not _is_dxf,
                                                gate_src=ns_ if _is_dxf else None)
                            if dy_ is None:
                                _left.append(g)
                            else:
                                _expl.append((_group_rect(g, scale), dy_))
                        if _is_dxf and _expl and _left:
                            # DXF: 바뀐 글줄에서 먼 같은 표의 칸(수량 열 '4'→'2'처럼 한 글자 값이 한 행씩 밀린 자리)은 바뀐 글줄에
                            # 맞닿지 않아 덤 '그림 변경'이 됐다 (held69 D08). 같은 dy로 이미 설명된 묶음에 맞닿은 묶음만, 그 dy 하나로
                            # 다시 본다 — 양방향 픽셀 대조·새 도형 관문은 그대로다
                            _left = [g for g in _left
                                     if _row_shift_dy(a, b, g, scale, masks, _ot, _nt, spacing=False,
                                                      gate_src=ns_, near_explained=_expl) is None]
                        _all_groups = _left
                except Exception:                           # noqa: BLE001
                    pass
            if _G is None and not sensitive and _all_groups and _lay_kept is not None:
                _left = [g for g in _all_groups if any(q in _lay_kept for q in g)]
                _gone = [q for g in _all_groups if not any(q in _lay_kept for q in g) for q in g]
                if _gone:
                    lay_gone[pno] = set(_gone)
                    _all_groups = _left
            # 표제란 틀(도면 좌표) 안의 묶음과 본문 묶음을 따로 센다 — 한데 세면 틀을 바꾼 날 큰 표제란 묶음이 상한을
            # 다 차지해 본문 결선 변경이 목록에서 빠졌다 (검토42 B 차단 1). 상한 밖 개수도 본문 묶음만으로
            _meta = ns_.meta(pno) if title_boxes and hasattr(ns_, "meta") else {}

            def _in_title(group) -> bool:
                if not _meta or "scale" not in _meta:
                    return False
                # 중심점 하나가 아니라 묶음 **전체**가 틀 안이어야 — 틀 안으로 들어간 본문 배선이 중심 때문에 '표제란
                # 자리'로 빠졌다 (검토42 B 중간 6)
                ax = min(g[0] for g in group) * _VIS_BLOCK * scale
                bx = (max(g[0] for g in group) + 1) * _VIS_BLOCK * scale
                ay = min(g[1] for g in group) * _VIS_BLOCK * scale
                by = (max(g[1] for g in group) + 1) * _VIS_BLOCK * scale
                (ux0, uy1), (ux1, uy0) = dxf_units_at(_meta, ax, ay), dxf_units_at(_meta, bx, by)
                # 묶음 경계는 픽셀 블록 단위로 반올림된다 — 틀만 바꾼 날 틀 전체 묶음이 블록 한 칸(0.4)만큼 삐져나와
                # 본문 변경이 되어 거짓 'Rev 미갱신'이 났다 (검토42 B T01b). 여유를 블록 한 칸 이상으로
                blk = abs(dxf_units_at(_meta, _VIS_BLOCK * scale, 0)[0] - dxf_units_at(_meta, 0, 0)[0])
                for x0, y0, x1, y1 in title_boxes:
                    px_, py_ = max((x1 - x0) * 0.03, blk), max((y1 - y0) * 0.03, blk)
                    if x0 - px_ <= ux0 and ux1 <= x1 + px_ and y0 - py_ <= uy0 and uy1 <= y1 + py_:
                        return True
                return False
            _tg = [g for g in _all_groups if _in_title(g)]
            _bg = [g for g in _all_groups if not _in_title(g)] if _tg else _all_groups
            _ann = _annot_changes(os_, ns_, opno, pno) if (_G is None and ANNOT_ZONE) else []
            if len(_bg) > _VIS_REGIONS_PER_PAGE:
                overflow[pno] = len(_bg) - _VIS_REGIONS_PER_PAGE
            _tg_ids = {id(g) for g in _tg}
            for group in _bg[:_VIS_REGIONS_PER_PAGE] + _tg[:_VIS_REGIONS_PER_PAGE]:
                xs = [g[0] for g in group]
                ys = [g[1] for g in group]
                rect = _Region(min(xs) * _VIS_BLOCK * scale,
                               min(ys) * _VIS_BLOCK * scale,
                               (max(xs) + 1) * _VIS_BLOCK * scale,
                               (max(ys) + 1) * _VIS_BLOCK * scale)
                # 페이지의 60% 넘게 덮는 한 덩어리 = 전체가 살짝 어긋남(재스캔·기울기·전체 이동) — 위치 하나로
                # 접고 내용 변경으로 세지 않는다 (2026-09-06 사용성 5차 (d): 재스캔이 가짜 4건 + Rev 미갱신)
                if (rect.x1 - rect.x0) * (rect.y1 - rect.y0) >= 0.6 * pw * ph:
                    wide.append((pno, rect, len(group)))
                    continue
                found.append((pno, rect, len(group)))
                if id(group) in _tg_ids:
                    title_rects.add((pno, id(rect)))
                if _ann:
                    _lab = _in_annot(rect, _ann, _VIS_BLOCK * scale)
                    if _lab:
                        annot_rects[(pno, id(rect))] = _lab

        # 같은 자리(중심 좌표 32pt 격자)가 여러 페이지에서 반복 = 표제란·양식 변경.
        # 페이지마다 나열하면 진짜 개별 변경이 묻힌다 (2026-08-24 실사용: 131페이지
        # 전부에 날짜 갱신 위치가 찍혀 182곳 나열) → 공통 1건으로 묶는다
        loc_groups: dict = {}
        for pno, rect, size in found:
            gkey = (int((rect.x0 + rect.x1) / 2 // 32),
                    int((rect.y0 + rect.y1) / 2 // 32))
            loc_groups.setdefault(gkey, []).append((pno, rect, size))
        common_min = max(4, (page_total + 1) // 2)
        indiv, commons = [], []
        for lst in loc_groups.values():
            pnos = sorted({p for p, _, _ in lst})
            if len(pnos) >= common_min:
                commons.append((pnos, lst[0][1], max(s for _, _, s in lst)))
            else:
                indiv.extend(lst)

        regions, cap_order = [], []  # cap_order: (우선순위, 블록수, key, pno, rect)
        per_page_no: Counter = Counter()
        def _shift(pno: int) -> str:
            o = old_of.get(pno)
            return f" (이전 판 {o}페이지)" if o is not None and o != pno else ""

        for pno, rect, size in sorted(indiv, key=lambda f: (f[0], -f[2])):
            per_page_no[pno] += 1
            key = f"{pno}페이지 위치{per_page_no[pno]}"
            regions.append((key, ns_.where(pno, rect) + _shift(pno)
                            + (" (쪽 전체를 맞춰 비교)" if pno in aligned else "")
                            + (f" · {_TITLE_ZONE_MARK}" if (pno, id(rect)) in title_rects else "")
                            + (f" · {ANNOT_ZONE_MARK} ({annot_rects[(pno, id(rect))]})" if (pno, id(rect)) in annot_rects
                               else "")))
            cap_order.append((0, size, key, pno, rect))
        for pno in size_diff:
            regions.append((f"{pno}페이지", f"{pno}페이지 (페이지 크기 변경){_shift(pno)}"))
        # 배치만 바뀜 — 자리만 옮긴 글줄 덩어리로 설명된 묶음·쪽 전체를 맞춰 비교한 쪽 (Rev 판단의 내용 아님, 전/후 사진은 남긴다)
        for pno in sorted(lay_gone):
            gone = lay_gone[pno]
            if pno in {p for p, _, _ in wide}:
                continue
            what = ("쪽 전체가 돌아가거나 옮겨지거나 크기가 바뀜 — 옛 판을 맞춰 놓고 비교했습니다"
                    if pno in aligned else "같은 글자·표가 자리만 옮김")
            key = f"{pno}페이지 배치"
            regions.append((key, f"{pno}페이지 — {what}{_shift(pno)} · {LAYOUT_ZONE_MARK}"))
            if gone:
                xs_g, ys_g = [q[0] for q in gone], [q[1] for q in gone]
                rect = _Region(min(xs_g) * _VIS_BLOCK * scale, min(ys_g) * _VIS_BLOCK * scale,
                               (max(xs_g) + 1) * _VIS_BLOCK * scale, (max(ys_g) + 1) * _VIS_BLOCK * scale)
                cap_order.append((3, len(gone), key, pno, rect))
        # 상한 밖으로 버린 위치가 있으면 그 사실을 한 줄로 — 말없이 버리면 표제란 틀을 바꾼 날 큰 표제란 묶음 셋이
        # 자리를 다 차지해 본문 결선 20선이 '틀만 바뀜 — 본문 그림은 같습니다'로 접혔다 (검토42 B 차단 1).
        # 좌표 없는 위치라 '표제란 자리'로 걸러지지 않고 내용 변경으로 센다
        # 여러 쪽에 같은 자리가 반복되면(양식 변경) 이미 '공통위치'로 접혔다 — 쪽마다 '외 N곳'을 또 달면 8쪽 세트가 8줄이
        # 됐다 (검토43 A 중간 3). 공통 자리가 있는 쪽들의 넘침은 한 줄로 합친다
        _wide_p = {p for p, _, _ in wide}
        _ov = {p: n for p, n in overflow.items() if p not in _wide_p}
        _common_p = {p for pnos, _r, _s in commons for p in pnos}
        _merged = {p: n for p, n in _ov.items() if p in _common_p}
        if len(_merged) >= 2:
            tot = sum(_merged.values())
            regions.append((f"여러 페이지 외 {tot}곳",
                            f"{len(_merged)}개 페이지 — 위 위치들 말고도 그림 변경 모두 {tot}곳 "
                            f"(사진은 큰 것만, 도면을 열어 확인)"))
            _ov = {p: n for p, n in _ov.items() if p not in _merged}
        for pno in sorted(_ov):
            regions.append((f"{pno}페이지 외 {_ov[pno]}곳",
                            f"{pno}페이지 — 위 {_VIS_REGIONS_PER_PAGE}곳 말고도 그림 변경 {_ov[pno]}곳 "
                            f"(사진은 큰 것만, 도면을 열어 확인){_shift(pno)}"))
        if len({p for p, _, _ in wide}) < len(wide):
            # 같은 쪽의 '전체 어긋남'은 한 건 — 쪽 판정과 묶음 판정이 각각 더해 같은 where 두 줄·'그림 변경 위치 2곳'이 됐다 (검토20 r07 8)
            _w1: dict = {}
            for w_ in wide:
                if w_[0] not in _w1 or w_[2] > _w1[w_[0]][2]:
                    _w1[w_[0]] = w_
            wide = [w_ for w_ in wide if _w1.get(w_[0]) is w_]
        wide_pages = {p for p, _, _ in wide}
        if wide_pages:                     # 그 페이지의 작은 위치들은 어긋남의 조각 — 한 줄로 접는다 (리뷰13 ④-4)
            regions = [(k, w) for k, w in regions if not any(k.startswith(f"{p}페이지 위치") for p in wide_pages)]
            cap_order = [c for c in cap_order if not (c[0] == 0 and c[3] in wide_pages)]
        for pno, rect, size in wide:
            key = f"{pno}페이지 전체"
            regions.append((key, WIDE_SHIFT_NOTE + _shift(pno)))
            cap_order.append((2, size, key, pno, rect))
        # 짝이 없는 페이지 = 추가/삭제 — regions(그림 변경)가 아니라 caps에 실어 보낸다.
        # 뒤 페이지들은 번호가 밀렸을 뿐 '변경'이 아니다
        for ci, (pnos, rect, size) in enumerate(
                sorted(commons, key=lambda c: -len(c[0])), start=1):
            key = f"공통위치{ci}"
            regions.append((key,
                            f"좌표 ({rect.x0:.0f}, {rect.y0:.0f}) 부근 — "
                            f"{len(pnos)}개 페이지 반복 (표제란·양식 변경 가능성)"))
            cap_order.append((1, size, key, pnos[0], rect))

        caps: dict = {}
        if beyond_note:
            caps["PAGES_BEYOND"] = {"where": beyond_note}
        for _pri, _size, key, pno, rect in sorted(
                cap_order, key=lambda c: (c[0], -c[1]))[:capture_top]:
            try:
                _orect = rect if pno not in aligned else _sim_rect(_sim_inv(aligned[pno]), rect)
                caps[key] = {
                    "before": _region_crop(os_, old_of.get(pno, pno), _orect, "이전 판"),
                    "after": _region_crop(ns_, pno, rect, "새 판"),
                }
            except Exception:
                continue
        # 빠진 페이지·새 페이지는 그 페이지 전체를 근거로 (원칙 4)
        for k, opno in enumerate(old_only):
            cap = {"where": f"이전 판 {opno}페이지 — 새 판에 없음 (삭제)"}
            if k < (capture_top or 5):
                try:
                    cap["before"] = {"mime": "image/jpeg", "b64": _jpeg_b64(os_.full_page(opno), quality=60),
                                     "caption": f"이전 판 {opno}페이지 (새 판에 없음)"}
                    cap["after"] = None
                except Exception:
                    pass
            caps[f"PAGE_REMOVED|{opno}페이지"] = cap
        for k, pno in enumerate(new_only):
            cap = {"where": f"새 판 {pno}페이지 — 이전 판에 없는 페이지 (추가)"}
            if k < (capture_top or 5):
                try:
                    cap["before"] = None
                    cap["after"] = {"mime": "image/jpeg", "b64": _jpeg_b64(ns_.full_page(pno), quality=60),
                                    "caption": f"새 판 {pno}페이지 (이전 판에 없음)"}
                except Exception:
                    pass
            caps[f"PAGE_ADDED|{pno}페이지"] = cap
        if pairs and (old_only or new_only or any(i != j for i, j in pairs)):
            caps["PAGE_MAP"] = {str(j): i for i, j in pairs}   # 나란히 보기가 같은 페이지를 놓게
        if len(os_) == len(ns_):
            for i, j in pairs:
                if i != j:
                    caps[f"PAGE_MOVED|{j}페이지"] = {"where": f"이전 판 {i}페이지 → 새 판 {j}페이지 (순서 바뀜)"}
        elif PAGE_MOVED_ANY_COUNT:
            # 쪽 수가 달라진 판도 순서가 거꾸로 된 쪽은 알린다 — 앞에 쪽이 끼어 번호만 밀린 쪽(i→i+1)은 아니다 (검토20 r07 6)
            for i, j in _moved_pairs(pairs[:page_total]):
                caps[f"PAGE_MOVED|{j}페이지"] = {"where": f"이전 판 {i}페이지 → 새 판 {j}페이지 (순서 바뀜)"}
        # 이전 판 틀 **밖에** 새로 그린 내용은 아예 안 그려져 '그림 동일'로 보였다 —
        # 도면 옆에 구역을 통째로 더 그려도 0픽셀 차이였다 (2026-09-10 매트릭스 실측).
        # 픽셀로는 영영 안 보이므로 틀을 벗어난 사실 자체를 알린다
        if rotated:
            caps["PAGE_ROTATED"] = {"pages": rotated}
        if fmt_only:
            _ft = sorted({t_ for ts in fmt_only.values() for t_ in ts})
            caps["FORMAT_ONLY"] = {"n": len(_ft), "texts": _ft[:3]}
        try:
            grew = float(ns_.meta(1).get("outside") or 0)
        except Exception:                              # noqa: BLE001
            grew = 0.0
        if grew > 0:
            caps["AREA_GREW"] = {"where": f"이전 판 대비 약 {grew * 100:.0f}% 바깥",
                                 "pct": grew}
        if (not _natural and (grew > 0 or wide) and isinstance(os_, _RenderSource) and isinstance(ns_, _RenderSource)
                and ns_._dxf_path and "scale" in os_.meta(1)):
            alt = _moved_only(old, new, regions, dict(capture_top=capture_top, sensitive=sensitive, ignore_texts=ignore_texts,
                                                      ignore_boxes=ignore_boxes, anchors=anchors, title_boxes=title_boxes,
                                                      new_renders=new_renders, strong_px=strong_px))
            if alt is not None:
                return alt
        return regions, caps
    except Exception:
        return None
    finally:
        if os_ is not None:
            os_.close()
        if ns_ is not None:
            ns_.close()


PAGE_MOVED_ANY_COUNT = True     # 시험용 끔 스위치 (검토20 r07 6)
ANNOT_ZONE = True               # 시험용 끔 스위치 (검토20 r07 7)
ANNOT_ZONE_MARK = "주석 자리"     # diff.ANNOT_ZONE과 같은 말 — 메모·도장 주석 자리 그림 변경(문서 내용 아님, Rev 판단 제외)


def _annot_changes(os_, ns_, opno: int, pno: int) -> list:
    """두 판에서 달라진(새로 붙었거나 떼었거나 옮긴) 메모·도장 주석 [[이름표, x0, y0, x1, y1]]. 어느 판이든 주석 기록을 모르면
    (옛 기록·DXF) 빈 목록 — 모르는데 '주석'이라 하지 않는다. 두 판에 같은 자리 그대로 있는 주석은 넣지 않는다(그 밑 내용 변경을
    가리지 않게)."""
    try:
        an = ns_.annots(pno) if hasattr(ns_, "annots") else None
        ao = os_.annots(opno) if hasattr(os_, "annots") else None
    except Exception:                                       # noqa: BLE001
        return []
    if an is None or ao is None:
        return []

    def key(x):
        return (str(x[0]), round(float(x[1])), round(float(x[2])), round(float(x[3])), round(float(x[4])))
    ko, kn = {key(x) for x in ao}, {key(x) for x in an}
    return [x for x in an if key(x) not in ko] + [x for x in ao if key(x) not in kn]


def _in_annot(rect: _Region, anns: list, pad: float):
    """묶음 사각형이 달라진 주석 자리(블록 한 칸 여유) 안에 통째로 들면 그 주석 이름표, 아니면 None."""
    for a in anns:
        try:
            lab, x0, y0, x1, y1 = a
        except (TypeError, ValueError):
            continue
        if x0 - pad <= rect.x0 and rect.x1 <= x1 + pad and y0 - pad <= rect.y0 and rect.y1 <= y1 + pad:
            return str(lab)
    return None


def _moved_pairs(pairs: list) -> list:
    """쪽 짝 (옛 i, 새 j) 가운데 순서가 거꾸로 된 짝 — 새 쪽 차례로 놓은 옛 번호의 가장 긴 증가 부분열 밖의 짝, 그리고 그 짝과
    맞바뀐 짝이 하나뿐이면 그 짝도(두 쪽 맞바꿈). 쪽 삽입·삭제로 번호만 밀린 짝은 들지 않는다."""
    ps = sorted(pairs, key=lambda q: q[1])
    n = len(ps)
    if n < 2:
        return []
    import bisect
    tails, tail_idx, prev = [], [], [-1] * n
    for k, (i, _j) in enumerate(ps):
        pos = bisect.bisect_left(tails, i)
        if pos == len(tails):
            tails.append(i)
            tail_idx.append(k)
        else:
            tails[pos] = i
            tail_idx[pos] = k
        prev[k] = tail_idx[pos - 1] if pos > 0 else -1
    keep, k = set(), tail_idx[-1] if tail_idx else -1
    while k >= 0:
        keep.add(k)
        k = prev[k]
    moved = {k for k in range(n) if k not in keep}
    extra = set()
    for m in moved:
        inv = [k for k in keep if (ps[k][0] - ps[m][0]) * (ps[k][1] - ps[m][1]) < 0]
        if len(inv) == 1:
            extra.add(inv[0])
    return [ps[k] for k in sorted(moved | extra)]


# 조용한 말(옮겨짐·재저장…)을 쓰지 않는다 — 이 줄이 Rev 올림·글자 변경이 함께 있는 판을 '조용한 변경'으로 접으면 안 된다
MOVED_NOTE = "도면 전체가 자리를 옮겼거나 배율만 바뀌었습니다 — 제 범위로 맞춰 다시 그려 그림을 견줬습니다"


def _natural_source(new, renders=None):
    """DXF 새 판을 옛 판 틀 없이 제 범위로 그린 공급원. renders(이 판을 기록할 때 틀 없이 그린 그림)가 있으면 그것을 쓴다."""
    if isinstance(new, (str, Path)):
        p = Path(new)
        return _RenderSource(renders if renders else render_dxf(p), dxf_path=p)
    return _RenderSource(new)


def _moved_only(old, new, regions: list, kw: dict):
    """옛 판 틀로 그린 비교가 '도면 범위 넓어짐'·'전체 어긋남'을 냈을 때, 새 판을 제 범위로 그려 다시 견준다. 도면 전체를 평행 이동
    했거나(원점 옮김·1e6 좌표) 배율만 바꾼(mm↔inch 25.4배) 판은 보이는 그림이 같은데 옛 판 틀 밖으로 나가 '도면 범위가 넓어졌다 +
    Rev 미갱신'이 났다(뒤흔들기 DXF C5, 2026-10-23). 제 범위 그림끼리 크기가 같고 다시 견준 결과가 범위 넓어짐·전체 어긋남·크기 변경
    없이 위치 수도 늘지 않을 때만 그 결과를 쓴다 — 진짜 도형을 더해 범위가 넓어진 판은 제 범위 그림의 배율이 달라져 전체가 어긋나므로
    예전 결과('도면 범위' 항목)가 그대로 남는다."""
    # 제 범위 그림이 멀리 떨어진 잡선·글자를 잘라 냈으면(clipped) 그 잘린 것이 바로 이번 변경일 수 있다 — 멀리 잡선 하나를 더한 판·
    # 글자 하나를 멀리 옮긴 판이 '같은 그림'이 됐다 (매트릭스 '멀리 잡선'·'글자가 자리만 옮겨감'). 잘라 낸 그림이면 다시 견주지 않는다
    try:
        pages = kw.get("new_renders") or (render_dxf(Path(new)) if isinstance(new, (str, Path)) else list(new))
    except Exception:                                   # noqa: BLE001
        return None
    if not pages or any((pg.meta or {}).get("clipped") for pg in pages):
        return None
    try:
        alt = visual_page_diff(old, new, _natural=True, **dict(kw, new_renders=pages))
    except Exception:                                   # noqa: BLE001
        return None
    if alt is None:
        return None
    r2, c2 = alt
    if "AREA_GREW" in c2 or any(re.fullmatch(r"\d+페이지( 전체)?", str(k)) or " 외 " in str(k) for k, _w in r2):
        return None
    # 옛 틀 결과의 '전체 어긋남'은 진짜 변경 몇 곳을 삼킨다 — 제 범위 결과가 몇 곳(옛 결과 + 3 이하)이면 그쪽이 맞다
    if len(r2) > len([k for k, _w in regions if not str(k).endswith("페이지 전체")]) + 3:
        return None
    c2 = dict(c2)
    c2["DRAWING_MOVED"] = {"where": MOVED_NOTE}
    return r2, c2


def page_pair_images(old, new, pno: int, old_pno: int | None = None) -> tuple[str, str, int] | None:
    """두 판의 같은 페이지 전체를 JPEG(base64)로 — 전/후 나란히 육안 비교용.
    감지가 놓친 변경도 사람이 직접 훑을 수 있는 안전망 (2026-08-27 미탐 대응).
    old/new: PDF·DXF 경로 또는 기록해 둔 페이지 그림(PageRender 목록) — 같은 이름으로
    덮어쓴 도면도 기록 그림으로 나란히 놓는다 (2026-09-03 검토).
    돌려주는 값: (구판 b64, 신판 b64, 공통 페이지 수). 실패/범위 밖이면 None."""
    os_ = ns_ = None
    try:
        os_ = _source(old)
        fit = os_.meta() if isinstance(os_, _RenderSource) else None
        ns_ = _source(new, fit=fit)
        if old_pno is None:
            total = min(len(os_), len(ns_))
            if not (1 <= pno <= total):
                return None
            old_pno = pno
        else:
            total = len(ns_)                 # 페이지 짝 지도가 있으면 새 판 기준으로 넘긴다
            if not (1 <= pno <= total):
                return None
        old_b64 = (_jpeg_b64(os_.full_page(old_pno), quality=72)
                   if old_pno and 1 <= old_pno <= len(os_) else "")
        return (old_b64, _jpeg_b64(ns_.full_page(pno), quality=72), total)
    except Exception:
        return None
    finally:
        if os_ is not None:
            os_.close()
        if ns_ is not None:
            ns_.close()
