# -*- coding: utf-8 -*-
"""변경 위치 캡처 + 페이지 시각 변경 감지.

형상의 '의미 해석'은 하지 않는다(PRINCIPLE 7, 2026-08-24 개정) — 어느 페이지가
시각적으로 달라졌다는 사실과 전/후 이미지까지만 제시하고, 무엇이 어떻게
바뀌었는지의 해석은 사람 몫이다.
읽기 전용: 원본 파일에는 절대 쓰지 않으며, 빨간 박스는 렌더된 이미지 위에만 그린다.
캡처는 최선 노력(best-effort)이다 — 실패해도 감시·브리핑은 계속된다.
엔진: pypdfium2 + Pillow (허용적 라이선스 — 2026-08-26 AGPL 교체 결정).
"""

from __future__ import annotations

import base64
import io
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from watcher.render import PAGE_NUM_WORD as _PAGE_NUM_WORD, VIS_DPI, dxf_units_at, render_dxf

# 페이지 시각 비교 파라미터
_VIS_DPI = VIS_DPI      # 감지용 렌더 해상도 — 기록해 둔 그림(render.py)과 픽셀 단위로 맞춘다
_VIS_PIXEL_MIN = 40     # 이보다 큰 명도 차이만 '다른 픽셀' (안티앨리어싱 소음 제거)
_VIS_BLOCK = 16         # 변경 픽셀 뭉침 판정 블록(px)
_VIS_BLOCK_MIN_PX = 8   # 블록 안 변경 픽셀이 이 이상이면 '변경 블록'
_VIS_CLUSTER_MIN = 2    # 인접 변경 블록이 이 이상 뭉치면 '변경 위치' (점 소음 제거)
_PAGE_CACHE = 24        # 동시에 열어 두는 페이지 수 (여닫기 5ms/쪽)
_VIS_REGIONS_PER_PAGE = 3   # 페이지당 보고할 변경 위치 수 상한
_VIS_CROP_PAD = 60      # 변경 위치 주변 여백(pt)
_VIS_JPG_QUALITY = 70
_DXF_CROP_PX = 4600    # 변경 위치를 잘라 쓸 DXF 렌더 해상도 (긴 변, px)
_DXF_CROP_MIN_W = 540  # 잘라낸 그림의 최소 너비 — 이보다 작으면 키운다


@dataclass(frozen=True)
class _Region:
    """페이지 위 사각 영역 — 좌상단 원점(pt). 렌더 이미지 좌표와 방향이 같다."""
    x0: float
    y0: float
    x1: float
    y1: float


# 메일에 실리는 사진의 최대 변 길이(px). A1 도면 한 장이 4769×3368px JPEG 두 장이 되어
# .eml 하나가 5MB였다 — 메일 서버·모바일에서 막히는 크기다 (2026-09-09 브리핑 검토 차단 4).
# 사람이 화면에서 보는 크기는 540~900px이라 이 이상은 전달되지도 않는다.
_MAIL_MAX_SIDE = 1600


def _fit_for_mail(pil_img):
    """긴 변을 _MAIL_MAX_SIDE로 줄인다 — 작은 그림은 그대로."""
    w, h = pil_img.width, pil_img.height
    if max(w, h) <= _MAIL_MAX_SIDE:
        return pil_img
    k = _MAIL_MAX_SIDE / max(w, h)
    from PIL import Image as _Im
    return pil_img.resize((max(1, int(w * k)), max(1, int(h * k))), _Im.LANCZOS)


def _jpeg_b64(pil_img, quality: int = _VIS_JPG_QUALITY) -> str:
    buf = io.BytesIO()
    _fit_for_mail(pil_img).convert("RGB").save(buf, format="JPEG", quality=quality)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _png_b64(pil_img) -> str:
    buf = io.BytesIO()
    _fit_for_mail(pil_img).save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


# 같은 도면의 사진 여러 장 — 도면은 한 번만 그린다. 전에는 사진 한 장마다 도면
# 전체를 4600px로 다시 그려 장당 0.55초였다(엔티티 3천 개 기준). 그래서 파일당
# 4장에서 끊었고, 사용자는 "변경마다 사진이 하나씩 붙어야지"라고 했다 (2026-09-10).
_DXF_RENDER: dict = {}          # {(경로, mtime, 크기): (이미지, meta)}
_DXF_TEXTS: dict = {}           # {(경로, mtime, 크기): [(정규화 글자, 좌표, 높이, 레이어)]}


def _dxf_key(path: Path):
    try:
        st = path.stat()
    except OSError:
        return None
    return (str(path), st.st_mtime_ns, st.st_size)


def _dxf_render_cached(path: Path):
    """도면 전체 래스터 — 파일이 그대로면 다시 그리지 않는다 (한 파일분만 들고 있다)."""
    from watcher.render import dxf_image
    key = _dxf_key(path)
    if key is None:
        return None
    got = _DXF_RENDER.get(key)
    if got is None:
        try:
            got = dxf_image(path, max_px=_DXF_CROP_PX)
        except Exception as e:           # noqa: BLE001  — 전개 규모 초과 등: 사진 없이 글자 근거만
            if "그림 기록 상한" not in str(e):
                raise
            got = None
        _DXF_RENDER.clear()     # 한 파일의 사진들은 연달아 만들어진다 — 하나면 충분
        _DXF_RENDER[key] = got
    return got


def _dxf_texts_cached(path: Path) -> list:
    """도면의 글자 엔티티 목록 (정규화된 글자, x, y, 높이, 레이어).

    그림은 한 번만 그리게 고쳤는데 **파일 파싱은 사진마다 다시 하고 있었다** —
    엔티티 2만 개짜리에서 장당 0.93초였고, PDF(0.03초)보다 30배 느린 이유가
    그것이었다 (2026-09-10 실측). 글자 목록도 파일 단위로 한 번만 읽는다."""
    key = _dxf_key(path)
    if key is None:
        return []
    got = _DXF_TEXTS.get(key)
    if got is not None:
        return got
    import ezdxf
    out = []
    try:
        msp = ezdxf.readfile(str(path)).modelspace()
    except Exception:                            # noqa: BLE001
        _DXF_TEXTS.clear()
        _DXF_TEXTS[key] = out
        return out
    def _text_entities():
        for e in msp.query("TEXT MTEXT"):
            yield e
        # 블록 속성(ATTRIB) 표제란 — 실무 도면의 다수. 이걸 안 훑어 Rev 변경 사진이
        # 없었다 (검토19 감지 ⑧). 그림 비교 마스크는 이미 ATTRIB를 본다
        for ins_ in msp.query("INSERT"):
            try:
                for a in (getattr(ins_, "attribs", None) or ()):
                    yield a
            except Exception:                    # noqa: BLE001
                continue
    for e in _text_entities():
        try:
            val = e.plain_text() if e.dxftype() == "MTEXT" else e.dxf.text
        except Exception:                        # noqa: BLE001
            val = getattr(e.dxf, "text", "")
        val = _norm(val)
        if not val:
            continue
        try:
            ins = e.dxf.insert
            out.append((val, float(ins.x), float(ins.y),
                        float(getattr(e.dxf, "height", 0) or 3.0),
                        str(getattr(e.dxf, "layer", "") or "")))
        except Exception:                        # noqa: BLE001
            continue
    _DXF_TEXTS.clear()          # 한 파일분만 (연달아 만들어진다)
    _DXF_TEXTS[key] = out
    return out


def _norm(s) -> str:
    return " ".join(str(s or "").split())


def _find_entity(rows, target_text: str):
    """바뀐 글줄이 그려진 DXF 엔티티를 찾는다 (없으면 None).

    전에는 **줄의 첫 토큰과 통째로 같은** 엔티티만 찾았다. 그래서 현장에서 가장 흔한
    두 모양에서 전/후 사진이 조용히 안 나왔다 (2026-09-10 사용자 신고로 재현):
    - `M-101 MOTOR 7.5kW`가 한 엔티티 → 첫 토큰 `M-101`과 안 같다 → None
    - 표제란 한 칸 `REV: B` → 마찬가지로 None
    글자 변경은 보고되는데 사진만 없으니 "글로만 비교된다"로 보였다.

    이제 겹치는 정도로 고른다: ①줄 전체와 같은 엔티티 ②줄을 품거나 줄에 담기는
    엔티티 중 가장 많이 겹치는 것 ③첫 토큰을 낱말로 품은 엔티티. 낱말 경계를 보므로
    `M-1`이 `M-101`에 걸리지는 않는다."""
    import re as _re
    want = _norm(target_text)
    if not want:
        return None
    token = want.split()[0]
    exact = whole = part = None
    best = 0
    tok_re = _re.compile(r"(?<![0-9A-Za-z])" + _re.escape(token) + r"(?![0-9A-Za-z])")
    # 한 글자 값('C')은 부분 문자열로 'PROJE**C**T'에 먼저 걸려 엉뚱한 줄에 박스가 갔다
    # (검토19 2차 브리핑 ①). 3자 미만은 정확히 같은 줄이거나 '라벨: 값' 꼴만 인정한다
    short = len(want) < 3
    label_re = (_re.compile(r"^[A-Za-z가-힣 ._/-]{1,14}[:.]?\s*" + _re.escape(want) + r"$")
                if short else None)
    for row in rows:
        val = row[0]
        if val == want:
            exact = row
            break
        if short:
            if label_re.search(val) and whole is None:
                whole = row
            continue
        if val in want or want in val:
            n = min(len(val), len(want))
            if n > best:
                best, whole = n, row
        elif part is None and tok_re.search(val):
            part = row
    return exact or whole or part


def _dxf_crop(path: Path, target_text: str, pad: float = 55.0) -> dict | None:
    """DXF에서 target 텍스트(줄의 첫 토큰) 주변을 잘라낸 PNG + 빨간 박스.

    2026-09-09까지는 이 자리에서 SVG를 직접 만들어 넣었는데 두 가지가 틀렸다
    (브리핑 검토 차단 3):
    - `image/svg+xml`은 아웃룩·대부분의 웹메일이 지워 버린다 — 전/후 사진이 안 보였다.
    - 손으로 LINE·LWPOLYLINE·CIRCLE·ARC·TEXT만 그려서 블록·해치·치수·MTEXT가 빠졌다.
      표제란이 블록이면 변경 위치 주변이 텅 빈 그림으로 나왔다.
    이제 그림 비교와 **같은 렌더러**(render.dxf_image)로 도면 전체를 래스터로 그린 뒤
    그 자리만 잘라낸다 — 화면·메일이 보는 그림이 같아지고 빠지는 요소가 없다."""
    from PIL import Image, ImageDraw

    target = _find_entity(_dxf_texts_cached(Path(path)), target_text)
    if target is None:
        return None
    _val, tx, ty, th, layer = target

    r = _dxf_render_cached(Path(path))
    if r is None:
        return None
    img, meta = r

    def px(x: float, y: float) -> tuple[float, float]:
        """도면 좌표 → 픽셀 (dxf_image의 변환과 같은 식)."""
        return (meta["pad"] + (x - meta["x0"]) * meta["scale"],
                meta["pad"] + (meta["y1"] - y) * meta["scale"])

    cx0, cy1 = px(tx - pad, ty - pad * 0.55)     # y는 뒤집혀 아래쪽이 큰 픽셀
    cx1, cy0 = px(tx + pad * 2.2, ty + pad * 0.55)
    L = max(0, int(min(cx0, cx1)))
    R = min(img.width, int(max(cx0, cx1)) + 1)
    T = max(0, int(min(cy0, cy1)))
    B = min(img.height, int(max(cy0, cy1)) + 1)
    if R - L < 8 or B - T < 8:                   # 글자가 너무 작아 잘라낼 게 없으면 전체
        L, T, R, B = 0, 0, img.width, img.height
    crop = img.crop((L, T, R, B)).convert("RGB")

    # 변경 위치 하이라이트 — 잘라낸 **그림 위에만** 그린다 (원본은 읽기 전용)
    bw = max(len(target_text) * th * 0.75, th * 6)
    bx0, by1 = px(tx, ty - th * 0.6)
    bx1, by0 = px(tx + bw, ty + th * 1.4)
    draw = ImageDraw.Draw(crop)
    draw.rectangle([(min(bx0, bx1) - L, min(by0, by1) - T),
                    (max(bx0, bx1) - L, max(by0, by1) - T)],
                   outline=(220, 33, 33), width=2)

    if crop.width < _DXF_CROP_MIN_W:             # 작은 도면은 읽을 만한 크기로 키운다
        k = _DXF_CROP_MIN_W / crop.width
        crop = crop.resize((_DXF_CROP_MIN_W, max(1, int(crop.height * k))), Image.LANCZOS)

    return {
        "mime": "image/png",
        "b64": _png_b64(crop),
        "caption": f"변경 위치: 레이어 {layer}, 좌표 ({tx:.0f}, {ty:.0f})",
    }


def _render_region(page, region: _Region, scale: float = 2.0,
                   box: _Region | None = None):
    """페이지의 region(좌상단 원점 pt)만 렌더한 PIL 이미지. box가 있으면 빨간 테두리.
    원본 PDF는 읽기만 하고, 표시는 렌더된 픽셀 위에만 한다."""
    from PIL import ImageDraw

    w, h = page.get_size()
    x0 = max(0.0, region.x0)
    y0 = max(0.0, region.y0)
    x1 = min(float(w), region.x1)
    y1 = min(float(h), region.y1)
    # pdfium crop = (왼쪽, 아래, 오른쪽, 위)에서 잘라낼 양 — 아래 원점 좌표계
    crop = (x0, h - y1, w - x1, y0)
    img = page.render(scale=scale, crop=crop).to_pil()
    if box is not None:
        draw = ImageDraw.Draw(img)
        draw.rectangle(
            [(box.x0 - x0 - 4) * scale, (box.y0 - y0 - 4) * scale,
             (box.x1 - x0 + 4) * scale, (box.y1 - y0 + 4) * scale],
            outline=(220, 33, 33), width=2)
    return img


def _pdf_png(path: Path, target_text: str) -> dict | None:
    """PDF에서 target 줄을 찾아 주변을 잘라 PNG + 빨간 박스 (렌더 이미지 위에만 표시)."""
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(Path(path).read_bytes())  # 핸들 즉시 반납
    try:
        for pno in range(1, len(pdf) + 1):
            page = pdf[pno - 1]
            textpage = page.get_textpage()
            found = textpage.search(target_text, match_case=True).get_next()
            if found is None:
                textpage.close()
                page.close()
                continue
            idx, cnt = found
            n = textpage.count_rects(idx, cnt)
            if not n:
                textpage.close()
                page.close()
                continue
            left, bottom, right, top = textpage.get_rect(0)
            _, h = page.get_size()
            box = _Region(left, h - top, right, h - bottom)  # 좌상단 원점으로 변환
            area = _Region(box.x0 - 170, box.y0 - 70, box.x1 + 170, box.y1 + 70)
            img = _render_region(page, area, scale=2.0, box=box)
            out = {
                "mime": "image/png",
                "b64": _png_b64(img),
                "caption": f"변경 위치: {pno}페이지, 좌표 ({box.x0:.0f}, {box.y0:.0f})",
            }
            textpage.close()
            page.close()
            return out
    finally:
        pdf.close()
    return None


def _one(abs_path: Path, text: str) -> dict | None:
    try:
        ext = Path(abs_path).suffix.lower()
        if ext == ".dxf":
            return _dxf_crop(Path(abs_path), text)
        if ext == ".pdf":
            return _pdf_png(Path(abs_path), text)
    except Exception:
        return None  # 캡처 실패는 감시를 막지 않는다
    return None


def capture_for(abs_path: Path, new_text: str) -> dict | None:
    """변경된 줄(new_text)의 위치 캡처(신버전). 지원 유형이 아니거나 실패하면 None."""
    return _one(abs_path, new_text) if new_text else None


def _box_crop(path, box) -> dict | None:
    """OCR 글줄의 자리(pno, x0, y0, x1, y1 pt)를 여유를 두고 잘라 낸다 — 스캔본은 글자 검색이 안 된다."""
    src = None
    try:
        src = _source(Path(path))
        pno, x0, y0, x1, y1 = box
        pad_x, pad_y = max(40.0, (x1 - x0) * 0.5), max(20.0, (y1 - y0) * 1.5)
        w, h = src.size(pno)
        rect = _Region(max(0.0, x0 - pad_x), max(0.0, y0 - pad_y), min(w, x1 + pad_x), min(h, y1 + pad_y))
        out = _region_crop(src, pno, rect, "")
        out["caption"] = f"{pno}페이지 OCR 자리 ({x0:.0f}, {y0:.0f}) 부근"
        return out
    except Exception:
        return None
    finally:
        if src is not None:
            try:
                src.close()
            except Exception:
                pass


def capture_pair(new_path: Path, new_text: str,
                 old_path: Path | None = None,
                 old_text: str | None = None, box=None) -> dict | None:
    """전/후 캡처 쌍. 결과 dict:
      {'after': {...}, 'before': {...}|None}
    old_path가 있으면(판 짝짓기 = 이전 파일이 남아 있는 경우) 전 사진도 만든다.
    덮어쓰기라 구버전 파일이 없으면 before=None (후 사진만).
    box: OCR로 읽은 글줄의 자리(pno, x0, y0, x1, y1) — 있으면 글자 검색 대신 그 자리를 자른다."""
    if box:
        after = _box_crop(new_path, box)
        if after is None:
            return None
        before = _box_crop(old_path, box) if old_path is not None and Path(old_path).is_file() else None
        return {"after": after, "before": before}
    after = _one(new_path, new_text) if new_text else None
    if after is None:
        return None
    before = None
    if old_path is not None and Path(old_path).is_file():
        before = _one(Path(old_path), old_text or new_text)
    return {"after": after, "before": before}


def _gray_array(page, dpi: int = _VIS_DPI):
    """페이지 전체를 그레이스케일 numpy 배열로."""
    return page.render(scale=dpi / 72.0, grayscale=True).to_numpy()


def _changed_blocks(a, b, pixel_min: int = _VIS_PIXEL_MIN,
                    block_min: int = _VIS_BLOCK_MIN_PX):
    """두 그레이 렌더(numpy 2D)의 '변경 블록' 좌표 집합 {(bx, by)}."""
    import numpy as np
    h, w = a.shape
    mask = (np.abs(a.astype(np.int16) - b.astype(np.int16)) > pixel_min)
    gh, gw = h // _VIS_BLOCK + 1, w // _VIS_BLOCK + 1
    padded = np.zeros((gh * _VIS_BLOCK, gw * _VIS_BLOCK), dtype=bool)
    padded[:h, :w] = mask
    sums = padded.reshape(gh, _VIS_BLOCK, gw, _VIS_BLOCK).sum(axis=(1, 3))
    ys, xs = np.nonzero(sums >= block_min)
    return {(int(x), int(y)) for x, y in zip(xs, ys)}


def _clusters(blocks: set, cluster_min: int = _VIS_CLUSTER_MIN) -> list:
    """인접(8방향) 변경 블록을 뭉쳐 위치별 블록 묶음 목록으로. 큰 묶음 순."""
    seen: set = set()
    out = []
    for start in blocks:
        if start in seen:
            continue
        group, todo = [], [start]
        seen.add(start)
        while todo:
            bx, by = todo.pop()
            group.append((bx, by))
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    nb = (bx + dx, by + dy)
                    if nb in blocks and nb not in seen:
                        seen.add(nb)
                        todo.append(nb)
        if len(group) >= cluster_min:
            out.append(group)
    out.sort(key=len, reverse=True)
    return out


class _PdfSource:
    """PDF 파일의 페이지 공급원 — 감지용 그레이 렌더·확대 크롭을 pdfium으로 만든다."""

    def __init__(self, path: Path):
        import pypdfium2 as pdfium
        # 메모리로 읽고 파일은 즉시 놓아준다 — 긴 렌더 동안 파일을 잡고 있으면
        # 탐색기에서 이동·이름변경이 거부돼 "폴더 먹통"으로 체감된다 (2026-08-27)
        self._doc = pdfium.PdfDocument(Path(path).read_bytes())
        self._open: dict = {}              # 연 페이지 (최근 것만 들고 있는다)
        self._size: dict = {}
        self._thumb: dict = {}

    def __len__(self):
        return len(self._doc)

    def _page(self, pno: int):
        """한 페이지를 여는 데 5ms가 든다 — 131쪽 한 쌍이면 여닫기만 9초였다 (2026-09-07).
        쪽마다 크기·잉크·렌더를 잇달아 물어보므로 최근 것 몇 개만 들고 있으면 대부분 다시 열지 않는다.

        **돌려준 핸들을 들고 있다가 다른 쪽을 요청하면 안 된다** — 상한을 넘으면 가장 오래 안 쓴
        핸들이 닫히고, 닫힌 핸들을 쓰면 ArgumentError가 나 그 파일이 통째로 '비교 못 함'이 된다.
        지금 호출부는 모두 한 표현식 안에서 바로 소비한다 (2026-09-07 추출 검토 ④)."""
        page = self._open.pop(pno, None)
        if page is None:
            page = self._doc[pno - 1]
        self._open[pno] = page             # 방금 쓴 것을 맨 뒤로 — 가장 오래 안 쓴 것부터 닫는다
        if len(self._open) > _PAGE_CACHE:
            old = next(iter(self._open))
            if old != pno:
                try:
                    self._open.pop(old).close()
                except Exception:
                    pass
        return page

    def size(self, pno: int):
        got = self._size.get(pno)
        if got is None:
            got = self._size[pno] = tuple(float(v) for v in self._page(pno).get_size())
        return got

    def gray(self, pno: int):
        return _gray_array(self._page(pno))

    def crop(self, pno: int, area: _Region, box: _Region | None):
        return _render_region(self._page(pno), area, scale=2.0, box=box)

    def where(self, pno: int, rect: _Region) -> str:
        return f"{pno}페이지 좌표 ({rect.x0:.0f}, {rect.y0:.0f}) 부근"

    def text_boxes(self, pno: int, texts) -> list:
        """페이지에서 texts(바뀐 글줄)가 놓인 사각형들(pt, 좌상단 원점)."""
        out: list = []
        page = self._page(pno)
        try:
            tp = page.get_textpage()
            _, h = page.get_size()
            try:
                for txt in texts:
                    if len(txt) < 2:
                        continue
                    s = tp.search(txt, match_case=True)
                    for _ in range(50):
                        f = s.get_next()
                        if f is None:
                            break
                        idx, cnt = f
                        for r in range(tp.count_rects(idx, cnt)):
                            left, bottom, right, top = tp.get_rect(r)
                            out.append(_Region(left, h - top, right, h - bottom))
            finally:
                tp.close()
        except Exception:
            return out
        return out

    def full_page(self, pno: int):
        return self._page(pno).render(scale=110 / 72.0).to_pil()

    def thumb(self, pno: int):
        """페이지 짝짓기용 작은 그레이 그림 (약 12dpi) — 전체 렌더보다 훨씬 싸다.
        짝짓기와 '전체 어긋남' 판정에서 같은 쪽을 다시 묻는다 — 한 번만 그린다."""
        import numpy as np
        got = self._thumb.get(pno)
        if got is None:
            got = self._thumb[pno] = np.asarray(
                self._page(pno).render(scale=12 / 72.0, grayscale=True).to_pil().convert("L"))
        return got

    def words(self, pno: int) -> set:
        """페이지 글자 낱말 집합 — 도면 세트처럼 틀이 같은 페이지를 잉크 분포로 못 가를 때
        (2026-09-06 블라인드 2차 38: 4쪽을 2쪽으로 옮긴 세트)."""
        page = self._page(pno)
        try:
            tp = page.get_textpage()
            try:
                # 'SHEET 2 OF 4'의 숫자처럼 쪽이 밀리면 함께 바뀌는 낱말은 짝짓기에 쓰지 않는다
                return {w for w in tp.get_text_range().split() if not _PAGE_NUM_WORD.match(w)}
            finally:
                tp.close()
        except Exception:
            return set()

    def close(self) -> None:
        for page in list(self._open.values()):
            try:
                page.close()
            except Exception:
                pass
        self._open.clear()
        self._doc.close()


class _RenderSource:
    """기록해 둔 페이지 그림(render.PageRender 목록)의 공급원 — 같은 이름으로
    덮어써져 파일이 사라진 이전 판, 그리고 DXF(파일에서 방금 렌더)의 페이지."""

    def __init__(self, pages, dxf_path=None):
        self._pages = list(pages)
        self._imgs: dict = {}
        self._dxf_path = dxf_path          # 파일에서 방금 그린 DXF면 글자 위치를 알 수 있다

    def __len__(self):
        return len(self._pages)

    def meta(self, pno: int = 1) -> dict:
        return (self._pages[pno - 1].meta or {}) if self._pages else {}

    def _img(self, pno: int):
        img = self._imgs.get(pno)
        if img is None:
            from PIL import Image
            decode = Image.open      # 메모리 버퍼(BytesIO)의 PNG 해독 — 파일을 열지 않는다
            img = decode(io.BytesIO(self._pages[pno - 1].png)).convert("L")
            img.load()
            self._imgs[pno] = img
        return img

    def size(self, pno: int):
        pg = self._pages[pno - 1]
        return (float(pg.width_pt), float(pg.height_pt))

    def gray(self, pno: int):
        import numpy as np
        return np.asarray(self._img(pno))

    def crop(self, pno: int, area: _Region, box: _Region | None, scale: float = 2.0):
        from PIL import ImageDraw
        k = _VIS_DPI / 72.0                      # pt → 기록 그림 px
        w, h = self.size(pno)
        x0, y0 = max(0.0, area.x0), max(0.0, area.y0)
        x1, y1 = min(w, area.x1), min(h, area.y1)
        part = self._img(pno).crop((int(x0 * k), int(y0 * k),
                                    int(math.ceil(x1 * k)), int(math.ceil(y1 * k))))
        part = part.resize((max(1, int(part.width * scale / k)),
                            max(1, int(part.height * scale / k)))).convert("RGB")
        if box is not None:
            ImageDraw.Draw(part).rectangle(
                [(box.x0 - x0 - 4) * scale, (box.y0 - y0 - 4) * scale,
                 (box.x1 - x0 + 4) * scale, (box.y1 - y0 + 4) * scale],
                outline=(220, 33, 33), width=2)
        return part

    def where(self, pno: int, rect: _Region) -> str:
        meta = self.meta(pno)
        if meta.get("thumb"):                    # DWG 미리보기 — 좌표는 의미가 없다
            return "미리보기 그림 (저해상도 — 변환 프로그램이 있으면 정확한 위치까지)"
        if "scale" in meta:                      # DXF: 사람이 CAD에서 찾아갈 도면 좌표
            ux, uy = dxf_units_at(meta, (rect.x0 + rect.x1) / 2, (rect.y0 + rect.y1) / 2)
            return f"도면 좌표 ({ux:.0f}, {uy:.0f}) 부근"
        return f"{pno}페이지 좌표 ({rect.x0:.0f}, {rect.y0:.0f}) 부근"

    def full_page(self, pno: int):
        img = self._img(pno)
        k = 110 / _VIS_DPI
        return img.resize((max(1, int(img.width * k)), max(1, int(img.height * k)))).convert("RGB")

    def thumb(self, pno: int):
        import numpy as np
        img = self._img(pno)
        k = 12 / _VIS_DPI
        return np.asarray(img.resize((max(1, int(img.width * k)), max(1, int(img.height * k)))))

    def words(self, pno: int) -> set:
        # 검사 때 그림과 함께 저장한 낱말 (v0.50.7부터). 그전 기록은 비어 있어 잉크 분포로만 짝짓는다
        return set(self.meta(pno).get("words") or [])

    def text_boxes(self, pno: int, texts) -> list:
        """바뀐 글줄(TEXT/MTEXT)의 자리 — 렌더 좌표(pt)로. 파일이 있으면 파일에서 읽고, 기록된 옛 판이면
        기록 때 함께 저장한 글자 자리(meta['tboxes'])에서 고른다 — 지워진 글줄의 자리는 새 판엔 없어
        '그림 변경'으로 찍혔다 (검토21 재검증 D9: 옛 판은 기록뿐이라 마스크가 비었다)."""
        meta = self.meta(pno)
        if not texts:
            return []
        matches = _text_matcher(texts)
        if self._dxf_path:
            if pno != 1 or "scale" not in meta:
                return []
            return [r for _t, r in dxf_text_boxes(self._dxf_path, meta, matches)]
        # 기록된 판(DXF·PDF 모두) — 기록 때 저장한 글자 자리에서 고른다 (재검증 2차: PDF 옛 판도)
        out: list = []
        for entry in meta.get("tboxes") or []:
            try:
                txt, x0, y0, x1, y1 = entry
            except (TypeError, ValueError):
                continue
            if matches(" ".join(str(txt).split())):
                out.append(_Region(float(x0), float(y0), float(x1), float(y1)))
        return out

    def close(self) -> None:
        self._imgs.clear()


def _text_matcher(texts):
    """바뀐 글줄 집합에 대한 일치 판정 — 글자 객체 하나가 바뀐 줄의 낱말이면 그 자리도 글자 변경이다."""
    want = {" ".join(str(x).split()) for x in texts}
    longs = [x for x in want if len(x) >= 4]

    def _matches(txt: str) -> bool:
        # 추출기는 한 줄의 글자 객체들("M-101", "7.5kW")을 "M-101 7.5kW"로 합친다 —
        # 객체 하나가 바뀐 줄의 낱말이면 그 자리도 글자 변경이다
        return (txt in want or any(x in txt for x in longs)
                or (len(txt) >= 3 and any(
                    re.search(r"(?<!\S)" + re.escape(txt) + r"(?!\S)", x) for x in longs)))
    return _matches


def dxf_text_boxes(dxf_path, meta: dict, matches=None) -> list:
    """DXF의 글자 객체(TEXT/ATTRIB/MTEXT) 자리 — (글자, 렌더 좌표 pt 사각형) 목록.
    matches가 None이면 전부(기록용), 아니면 일치하는 것만."""
    import ezdxf
    out: list = []
    if "scale" not in (meta or {}):
        return out
    try:
        doc = ezdxf.readfile(str(dxf_path))
    except Exception:
        return out
    k = 72.0 / _VIS_DPI

    def _box(x0: float, y0: float, x1: float, y1: float) -> _Region:
        px0 = (x0 - meta["x0"]) * meta["scale"] + meta["pad"]
        px1 = (x1 - meta["x0"]) * meta["scale"] + meta["pad"]
        py0 = (meta["y1"] - y1) * meta["scale"] + meta["pad"]
        py1 = (meta["y1"] - y0) * meta["scale"] + meta["pad"]
        return _Region(px0 * k, py0 * k, px1 * k, py1 * k)

    def _text_like(e):   # TEXT·ATTRIB: 삽입점 좌하단
        raw = str(e.dxf.text)
        txt = " ".join(raw.split())
        if txt and (matches is None or matches(txt)):
            ins = e.dxf.insert
            h = float(e.dxf.height or 3.0)
            # 폭은 공백을 접기 전의 원문 길이로 — "B    2026-09-04  WIRING ADDED"처럼
            # 칸을 띄운 리비전 행이 실제보다 4~5자 짧게 가려져 꼬리 글자가 '그림 변경'
            # 으로 찍히고 'Rev만 갱신' 판정을 막았다 (2026-09-04 사용자 관점 검토 #1).
            # 폭 계수·정렬도 반영하고 좌우로 한 글자씩 여유를 둔다
            try:
                wf = float(e.dxf.get("width", 1.0) or 1.0)
            except Exception:
                wf = 1.0
            w = max(len(raw.rstrip()) * h * 0.85 * wf, h) + 2 * h
            x_left = ins.x - h
            try:
                halign = int(e.dxf.get("halign", 0) or 0)
                ap = e.dxf.get("align_point", None)
                if halign in (1, 4) and ap is not None:       # 가운데
                    x_left = ap.x - w / 2
                elif halign == 2 and ap is not None:          # 오른쪽
                    x_left = ap.x - w + h
                elif halign in (3, 5) and ap is not None:     # 정렬·맞춤: 두 점 사이
                    x_left = min(ins.x, ap.x) - h
                    w = abs(ap.x - ins.x) + 2 * h
            except Exception:
                pass
            out.append((txt, _box(x_left, ins.y - h * 0.3, x_left + w, ins.y + h * 1.2)))

    for e in doc.modelspace():
        try:
            kind = e.dxftype()
            if kind == "TEXT":
                _text_like(e)
            elif kind == "INSERT":
                # 실무 도면의 표제란은 블록 속성(ATTRIB)이다 (2026-09-03 재검토)
                for a in e.attribs:
                    _text_like(a)
            elif kind == "MTEXT":
                txt = " ".join(str(e.text).split())
                if not txt or (matches is not None and not matches(txt)):
                    continue
                ins = e.dxf.insert
                h = float(e.dxf.char_height or 3.0)
                width = float(e.dxf.width or 0) or min(len(txt), 60) * h * 0.8
                lines = max(1, int(len(txt) * h * 0.8 / max(width, h)) + 1)
                out.append((txt, _box(ins.x, ins.y - lines * h * 1.3, ins.x + width, ins.y)))
        except Exception:
            continue
    return out


def attach_text_boxes(dxf_path, pages) -> None:
    """기록할 DXF 그림에 글자 자리를 함께 저장 — 이 판이 나중에 '옛 판'이 됐을 때 지워진 글줄의
    자리를 가릴 수 있게 (검토21 재검증 D9). 글자 최대 3,000개까지."""
    try:
        if not pages or "scale" not in (pages[0].meta or {}):
            return
        boxes = dxf_text_boxes(dxf_path, pages[0].meta, None)[:3000]
        pages[0].meta["tboxes"] = [[t, round(r.x0, 1), round(r.y0, 1), round(r.x1, 1), round(r.y1, 1)]
                                   for t, r in boxes]
    except Exception:
        pass


def _block_rect(b, scale: float) -> _Region:
    return _Region(b[0] * _VIS_BLOCK * scale, b[1] * _VIS_BLOCK * scale,
                   (b[0] + 1) * _VIS_BLOCK * scale, (b[1] + 1) * _VIS_BLOCK * scale)


def _overlaps(a: _Region, b: _Region, pad: float = 8.0) -> bool:
    return not (a.x1 + pad < b.x0 or b.x1 + pad < a.x0 or a.y1 + pad < b.y0 or b.y1 + pad < a.y0)


def _source(x, fit: dict | None = None):
    """비교 대상 → 페이지 공급원. PDF 경로 / DXF 경로 / 기록 그림 목록(PageRender).
    DXF는 fit(이전 판의 틀)이 있으면 같은 틀로 그려 픽셀 단위 비교가 되게 한다."""
    if isinstance(x, (str, Path)):
        p = Path(x)
        if p.suffix.lower() == ".dxf":
            return _RenderSource(render_dxf(p, fit=fit), dxf_path=p)
        return _PdfSource(p)
    return _RenderSource(x)


def _region_crop(src, pno: int, rect: _Region, label: str) -> dict:
    """변경 위치 주변을 확대해 잘라낸 이미지 + 빨간 박스 (렌더 이미지 위에만 표시)."""
    area = _Region(rect.x0 - _VIS_CROP_PAD, rect.y0 - _VIS_CROP_PAD,
                   rect.x1 + _VIS_CROP_PAD, rect.y1 + _VIS_CROP_PAD)
    img = src.crop(pno, area, rect)
    return {
        "mime": "image/jpeg",
        "b64": _jpeg_b64(img),
        "caption": f"{pno}페이지 변경 위치 확대 ({label})",
    }


_ALIGN_SIM = 0.75          # 이 이상 닮아야 같은 페이지로 짝짓는다 (잉크 분포 기준)


def _ink_sig(thumb, n: int = 24):
    """작은 그림 → n×n 잉크(어두움) 분포. 크기가 달라도 같은 격자로 맞춘다."""
    import numpy as np
    a = 255.0 - np.asarray(thumb, dtype=np.float32)
    h, w = a.shape[:2]
    if h < n or w < n:
        from PIL import Image
        a = 255.0 - np.asarray(Image.fromarray(np.asarray(thumb)).resize((max(n, w), max(n, h))),
                               dtype=np.float32)
        h, w = a.shape[:2]
    a = a[: h - h % n, : w - w % n]
    return a.reshape(n, h // n, n, w // n).mean(axis=(1, 3))


def _sig_sim_ink(a, b) -> float:
    import numpy as np
    tot = float(a.sum() + b.sum())
    if tot < 1e-6:
        return 1.0                           # 둘 다 빈 페이지
    return max(0.0, 1.0 - float(np.abs(a - b).sum()) / tot)


WIDE_SHIFT_NOTE = "페이지 전체가 살짝 어긋남 — 재스캔·스캔 기울기·전체 이동일 수 있습니다 (사진으로 확인)"


_ORDER_BUDGET = 60_000     # 쪽수 × 쪽당 평균 낱말 수의 상한 (아래 설명)


def _same_order_by_words(ow: list, nw: list) -> bool:
    """쪽 순서가 그대로인가를 글자만으로 판정 — 맞으면 축소판(잉크 분포)을 그릴 필요가 없다.

    기준은 '번호끼리 닮았나'가 아니라 '제자리가 가장 닮았나'다. 개정으로 글이 바뀐 쪽도 제자리가
    1등이면 순서는 그대로고, 순서를 바꾼 쪽은 다른 자리가 1등이 되어 바로 걸린다
    (블라인드 2차 38: 4쪽을 2쪽으로 옮긴 도면 세트). 비기면 판단을 미루고 축소판을 그린다 —
    같은 글이 반복되는 서식 쪽이 그렇다. 한 쪽이라도 글이 적으면(스캔본·그림 쪽) 쓰지 않는다.

    글자는 쪽당 7ms, 축소판은 30ms다 — 131쪽 한 쌍에서 8초가 걸리던 자리
    (2026-09-07 사용자 "검사하니까 좀 많이 느려지기는하네").

    다만 이 판정 자체는 쪽수²×낱말 수라, 글이 빽빽한 긴 문서에서는 아끼려던 축소판보다 비싸진다
    (검토 실측: 300쪽×1500낱말에서 판정에만 26.7초, 축소판은 18초). 그런 문서는 애초에 축소판을
    그려도 되므로 예산을 넘으면 바로 예전 길로 보낸다 — 이 최적화가 겨냥한 벡터 도면은 쪽당
    낱말이 100개 안팎이라 예산 안에 넉넉히 든다 (2026-09-07 추출 검토 ③)."""
    if len(ow) != len(nw):
        return False                       # 호출부는 쪽수가 같을 때만 부르지만 혼자서도 안전하게
    if any(len(x) < 5 for x in ow) or any(len(y) < 5 for y in nw):
        return False
    n = len(ow)
    if n * (sum(len(x) for x in ow) // max(1, n)) > _ORDER_BUDGET:
        return False

    def jac(x: set, y: set) -> float:
        return len(x & y) / max(1, len(x | y))

    for k in range(n):
        dia = jac(ow[k], nw[k])
        if any(jac(ow[k], nw[j]) >= dia for j in range(n) if j != k):
            return False
        if any(jac(ow[i], nw[k]) >= dia for i in range(n) if i != k):
            return False
    return True


def align_pages(os_, ns_, thr: float = _ALIGN_SIM, anchors: dict | None = None) -> tuple[list, list, list]:
    """두 판의 페이지를 내용으로 짝짓는다 → (짝 [(옛, 새)], 옛에만 있는 쪽, 새에만 있는 쪽).

    번호끼리(1↔1, 2↔2) 맞추면 한 쪽이 빠졌을 때 그 뒤가 전부 '바뀜'으로 보였다
    (2026-09-06 사용자: "페이지 삭제로 번호가 당겨지면 그 뒤가 신규로 인식"). 순서를 지키는
    정렬(DP)로 삭제·삽입을 흡수하고, 같은 번호가 충분히 닮았으면 그대로 쓴다."""
    no, nn = len(os_), len(ns_)
    if no == 0 or nn == 0:
        return [], list(range(1, no + 1)), list(range(1, nn + 1))
    if no == nn == 1:
        return [(1, 1)], [], []
    # 글자부터 읽는다 — 한 쪽에 1ms다. 축소판은 그려야 해서 30ms고, 131쪽 한 쌍이면 그것만 8초였다
    # (2026-09-07 사용자 "검사하니까 좀 많이 느려지기는하네"). 벡터 도면은 해상도를 낮춰도 렌더가 안 싸진다.
    ow = [os_.words(i) for i in range(1, no + 1)] if hasattr(os_, "words") else [set()] * no
    nw = [ns_.words(j) for j in range(1, nn + 1)] if hasattr(ns_, "words") else [set()] * nn
    if no == nn and _same_order_by_words(ow, nw):
        return [(k + 1, k + 1) for k in range(no)], [], []
    osig = [_ink_sig(os_.thumb(i)) for i in range(1, no + 1)]
    nsig = [_ink_sig(ns_.thumb(j)) for j in range(1, nn + 1)]

    def _sig_sim(a, b, i=None, j=None):        # 잉크 분포 + (있으면) 낱말 겹침
        s = _sig_sim_ink(a, b)
        if i is not None and j is not None and ow[i] and nw[j]:
            jac = len(ow[i] & nw[j]) / max(1, len(ow[i] | nw[j]))
            # 테두리·표제란이 같은 표준 양식은 잉크 분포가 다 닮아 번호 순 짝을 택했다 — 글이 넉넉하면
            # 낱말 쪽을 더 믿는다 (2026-09-06 사용성 3차 ④-1: 2쪽 지운 도면이 4쪽·2쪽 두 번 '삭제')
            w = 0.65 if min(len(ow[i]), len(nw[j])) >= 5 else 0.5
            s = (1 - w) * s + w * jac
        return s
    if no == nn:
        # 쪽수가 같으면 번호 그대로 — 크게 고친 페이지를 '다른 페이지'로 오인하지 않게.
        # 단, 번호끼리는 안 닮았는데 다른 자리에 거의 같은 페이지가 있으면(순서 바꿈) 그 짝으로
        # (2026-09-06 블라인드 2차 38: 4쪽을 2쪽으로 옮긴 도면 세트가 9곳 그림 변경으로)
        ident = [_sig_sim(osig[k], nsig[k], k, k) for k in range(no)]
        # 가장 닮은 쌍부터 차례로 배정(순열) — 번호 그대로보다 확실히 나을 때만 채택
        allp = sorted(((_sig_sim(osig[i], nsig[j], i, j), i, j) for i in range(no) for j in range(nn)), reverse=True)
        used_i: set = set()
        used_j: set = set()
        assign: dict = {}
        for s, i, j in allp:
            if i in used_i or j in used_j:
                continue
            assign[i] = (j, s); used_i.add(i); used_j.add(j)
        if (any(assign[i][0] != i for i in range(no))
                and all(s >= 0.8 for _, s in assign.values())
                and sum(s for _, s in assign.values()) > sum(ident) + 0.05 * no):
            return sorted((i + 1, assign[i][0] + 1) for i in range(no)), [], []
        return [(k + 1, k + 1) for k in range(no)], [], []
    sim = [[_sig_sim(osig[i], nsig[j], i, j) for j in range(nn)] for i in range(no)]
    # 순서 보존 최대 유사도 합 (LCS꼴). 짝은 thr 이상일 때만
    best = [[0.0] * (nn + 1) for _ in range(no + 1)]
    for i in range(1, no + 1):
        for j in range(1, nn + 1):
            s = sim[i - 1][j - 1]
            cand = best[i - 1][j - 1] + s if s >= thr else -1.0
            best[i][j] = max(best[i - 1][j], best[i][j - 1], cand)
    pairs = []
    i, j = no, nn
    while i > 0 and j > 0:
        s = sim[i - 1][j - 1]
        if s >= thr and abs(best[i][j] - (best[i - 1][j - 1] + s)) < 1e-9:
            pairs.append((i, j)); i -= 1; j -= 1
        elif best[i - 1][j] >= best[i][j - 1]:
            i -= 1
        else:
            j -= 1
    pairs.reverse()
    if anchors:
        # 글자 비교가 이미 정한 페이지 대응이 잉크 정렬보다 믿을 만하다 — 잉크 분포가 비슷한
        # 도면 세트에서 그림만 있는 쪽의 삭제를 놓치거나 남은 쪽을 삭제라 했다 (검토19 2차 N2).
        # 앵커(옛→새)는 단조 증가하는 것만 쓰고, 앵커에 걸린 쪽은 잉크 짝을 덮어쓴다
        good = []
        last_j = 0
        for i_, j_ in sorted((int(a), int(b)) for a, b in anchors.items()):
            if 1 <= i_ <= no and 1 <= j_ <= nn and j_ > last_j:
                good.append((i_, j_))
                last_j = j_
        if good:
            ai = {a for a, _ in good}
            aj = {b for _, b in good}
            pairs = sorted([p for p in pairs if p[0] not in ai and p[1] not in aj] + good)
    po = {a for a, _ in pairs}
    pn = {b for _, b in pairs}
    old_only = [k for k in range(1, no + 1) if k not in po]
    new_only = [k for k in range(1, nn + 1) if k not in pn]
    # 양쪽에 짝 없는 페이지가 남으면 순서대로 '크게 바뀐 같은 페이지'로 본다 — 진짜 추가·삭제는
    # 쪽수 차이만큼만 남는다 (그림을 크게 고친 페이지가 삭제+추가로 갈리지 않게)
    while old_only and new_only:
        i, j = old_only.pop(0), new_only.pop(0)
        pairs.append((i, j))
    pairs.sort()
    return pairs, old_only, new_only


def visual_page_diff(old, new, capture_top: int | None = None,
                     sensitive: bool = False, ignore_texts=(), ignore_boxes=(),
                     anchors: dict | None = None) -> tuple[list, dict] | None:
    """두 판의 페이지별 픽셀 비교 → 변경 '위치' 목록.

    old/new: PDF 경로, DXF 경로, 또는 검사 때 기록해 둔 페이지 그림 목록
    (render.PageRender). 같은 이름으로 덮어써 이전 판 파일이 없어도 기록으로
    비교한다 (2026-09-02: "도면 변경점을 거의 못 잡고 스샷도 없다").

    전체 면적 비율이 아니라 변경 픽셀의 뭉침(블록 클러스터)으로 판정한다 —
    가는 배선 한 가닥의 추가/삭제도 위치로 잡히고, 점 소음은 걸러진다
    (2026-08-24 실사용 피드백: 면적 기준은 글자만 잡고 배선 변경을 놓침).

    돌려주는 값: ([(key, where)], {key: {'before':…, 'after':…}})
      key   = "17페이지 위치1" (ChangeItem.key와 캡처 키로 공용)
      where = "17페이지 좌표 (x, y) 부근" / DXF는 "도면 좌표 (x, y) 부근"
    모든 위치에 전/후 확대 사진 첨부 (기본). capture_top을 주면 변경이 큰
    순으로 그 수만 첨부.
    ignore_texts: 글자 비교가 이미 잡은 새 글줄들 — 그 자리의 픽셀 차이는 '그림
    변경'이 아니다. 표제란·리비전 블록 글자가 그림 변경 3곳으로 부풀고, 'Rev만
    갱신' 판정이 DXF에서 절대 안 나오던 원인 (2026-09-03 검토).
    실패하면 None — '시각 변경 없음'([], {})과 구분해 호출부가 '비교 못 함'을
    고지할 수 있게 (2026-08-26 리뷰: 침묵 실패는 원칙 4 위반)."""
    os_ = ns_ = None
    try:
        os_ = _source(old)
        fit = os_.meta() if isinstance(os_, _RenderSource) else None
        ns_ = _source(new, fit=fit)
    except Exception:
        if os_ is not None:
            os_.close()
        return None
    try:
        scale = 72.0 / _VIS_DPI  # 렌더 px → pt
        pairs, old_only, new_only = align_pages(os_, ns_, anchors=anchors)
        # 이전 판이 '기록'(파일당 MAX_PAGES쪽까지)이고 새 판이 그보다 길면, 상한 밖 페이지는
        # 비교 대상이 아니지 '추가된 페이지'가 아니다 — 40쪽 PDF에서 31~40쪽이 "이전 판에
        # 없는 페이지 (추가)"로 지어졌다 (검토19 브리핑 ①)
        beyond_note = ""
        if isinstance(os_, _RenderSource):
            from watcher.render import MAX_PAGES as _MAXP
            if len(os_) >= _MAXP and len(ns_) > len(os_):
                beyond = [p for p in new_only if p > _MAXP]
                if beyond:
                    new_only = [p for p in new_only if p <= _MAXP]
                    beyond_note = (f"{_MAXP + 1}쪽 이후 {len(beyond)}쪽은 그림 기록 상한 밖이라 "
                                   f"비교하지 않았습니다 (글자 비교는 전체)")
        page_total = len(pairs)
        old_of = {j: i for i, j in pairs}          # 새 판 페이지 → 이전 판 페이지
        found = []      # (pno, _Region(pt, 좌상단 원점), 블록수)  pno = 새 판 페이지 번호
        wide = []       # 페이지 전체가 어긋난 페이지 (재스캔·기울기)
        size_diff = []  # 페이지 크기 자체가 바뀐 페이지
        rotated = []    # 내용은 같고 방향만 돌아간 페이지
        for opno, pno in pairs:
            if os_.size(opno) != ns_.size(pno):
                # 가로·세로가 맞바뀌었으면 회전만 된 것일 수 있다 — 돌려서 같으면 '내용
                # 변경'은 아니다 (2026-09-06 블라인드 3차 41: 스캔 방향만 바뀐 성적서가
                # '크기 변경'으로 잡히던 것). 다만 **아무 말도 안 하면 안 된다** —
                # 전에는 "내용 변경 없음 — 다시 저장되기만 했습니다"로 끝나서, 도면을
                # 일부러 돌려 놓아도 사용자가 그냥 넘겼다 (2026-09-10 매트릭스 실측).
                # 내용이 같다는 사실과 방향이 바뀌었다는 사실을 함께 말한다.
                if tuple(os_.size(opno))[::-1] == tuple(ns_.size(pno)):
                    import numpy as np
                    a0, b0 = os_.gray(opno), ns_.gray(pno)
                    if any(np.rot90(a0, k).shape == b0.shape and int(np.abs(np.rot90(a0, k).astype(int) - b0.astype(int)).max()) <= _VIS_PIXEL_MIN
                           for k in (1, 3)):
                        rotated.append(pno)
                        continue
                size_diff.append(pno)
                continue
            a, b = os_.gray(opno), ns_.gray(pno)
            if a.shape != b.shape:
                size_diff.append(pno)
                continue
            if (a == b).all():
                continue
            # 민감 모드: 임계값 절반 — 놓친 미세 변경 재탐색용 (오탐은
            # 사람이 [오탐 삭제]로 걷어낸다, 2026-08-27 미탐 대응)
            if sensitive:
                blocks = _changed_blocks(a, b, pixel_min=20, block_min=4)
            else:
                blocks = _changed_blocks(a, b)
            cmin = 1 if sensitive else _VIS_CLUSTER_MIN
            pw, ph = ns_.size(pno)
            if blocks and not sensitive:
                # 재스캔·1° 기울기·평행이동은 바뀐 블록이 페이지에 흩어져 뭉치지 않는다 — 합집합이 60% 넘고
                # 잉크 분포가 거의 같으면 페이지 전체 어긋남 한 줄로 (리뷰13 중간-3: 기울기 ≤1°가 위치 3곳)
                xs_ = [b[0] for b in blocks]
                ys_ = [b[1] for b in blocks]
                ux0, uy0 = min(xs_) * _VIS_BLOCK * scale, min(ys_) * _VIS_BLOCK * scale
                ux1, uy1 = (max(xs_) + 1) * _VIS_BLOCK * scale, (max(ys_) + 1) * _VIS_BLOCK * scale
                # 판정이 '바뀐 블록의 bbox가 페이지 60%를 덮나'뿐이라, 진짜 변경이 **두 곳**이어도
                # 좌상단·우하단이면 통째로 접혔다 — 미탐과 거짓 'Rev만 갱신'을 동시에 만들었다
                # (2026-09-09 비교 검토 차단). 재스캔·기울기는 페이지 전면의 잉크를 흔들어
                # 바뀐 블록이 **많다**. 그 밀도를 함께 본다.
                gh_, gw_ = a.shape[0] // _VIS_BLOCK + 1, a.shape[1] // _VIS_BLOCK + 1
                spread = len(blocks) >= max(24, int(0.05 * gh_ * gw_))
                if spread and (ux1 - ux0) * (uy1 - uy0) >= 0.6 * pw * ph:
                    try:
                        same_ink = _sig_sim_ink(_ink_sig(os_.thumb(opno)), _ink_sig(ns_.thumb(pno))) >= 0.9
                    except Exception:
                        same_ink = False
                    if same_ink:
                        wide.append((pno, _Region(ux0, uy0, ux1, uy1), len(blocks)))
                        continue
            # 새 판뿐 아니라 **옛 판**에서도 찾는다 — 지워진 글줄의 자리는 새 판엔 없어 '그림 변경'으로
            # 찍혔다 (검토21 감지 중간 9·브리핑 차단 5)
            masks = (list(ns_.text_boxes(pno, ignore_texts))
                     + list(os_.text_boxes(opno, ignore_texts))) if ignore_texts else []
            # OCR로 읽은 글줄의 자리 — 스캔본은 글자 검색이 안 되므로 추출기가 준 사각형으로 (2026-09-06 사용성 5차:
            # Rev 글자 자체가 '그림 변경'으로 세어져 'Rev만 갱신' 판정이 사라지고 가짜 'Rev 미갱신'이 났다)
            masks += [_Region(x0, y0, x1, y1) for (bp, x0, y0, x1, y1) in ignore_boxes if bp == pno]
            if masks:
                # 글자 변경 자리의 블록만 뺀다 — 클러스터째 버리면 바뀐 글줄 바로 옆을
                # 지나는 배선 변경까지 사라진다 (2026-09-03 재검토)
                blocks = {b for b in blocks
                          if not any(_overlaps(_block_rect(b, scale), m, pad=2.0) for m in masks)}
            for group in _clusters(blocks, cluster_min=cmin)[:_VIS_REGIONS_PER_PAGE]:
                xs = [g[0] for g in group]
                ys = [g[1] for g in group]
                rect = _Region(min(xs) * _VIS_BLOCK * scale,
                               min(ys) * _VIS_BLOCK * scale,
                               (max(xs) + 1) * _VIS_BLOCK * scale,
                               (max(ys) + 1) * _VIS_BLOCK * scale)
                # 페이지의 60% 넘게 덮는 한 덩어리 = 전체가 살짝 어긋남(재스캔·기울기·전체 이동) — 위치 하나로
                # 접고 내용 변경으로 세지 않는다 (2026-09-06 사용성 5차 (d): 재스캔이 가짜 4건 + Rev 미갱신)
                if (rect.x1 - rect.x0) * (rect.y1 - rect.y0) >= 0.6 * pw * ph:
                    wide.append((pno, rect, len(group)))
                    continue
                found.append((pno, rect, len(group)))

        # 같은 자리(중심 좌표 32pt 격자)가 여러 페이지에서 반복 = 표제란·양식 변경.
        # 페이지마다 나열하면 진짜 개별 변경이 묻힌다 (2026-08-24 실사용: 131페이지
        # 전부에 날짜 갱신 위치가 찍혀 182곳 나열) → 공통 1건으로 묶는다
        loc_groups: dict = {}
        for pno, rect, size in found:
            gkey = (int((rect.x0 + rect.x1) / 2 // 32),
                    int((rect.y0 + rect.y1) / 2 // 32))
            loc_groups.setdefault(gkey, []).append((pno, rect, size))
        common_min = max(4, (page_total + 1) // 2)
        indiv, commons = [], []
        for lst in loc_groups.values():
            pnos = sorted({p for p, _, _ in lst})
            if len(pnos) >= common_min:
                commons.append((pnos, lst[0][1], max(s for _, _, s in lst)))
            else:
                indiv.extend(lst)

        regions, cap_order = [], []  # cap_order: (우선순위, 블록수, key, pno, rect)
        per_page_no: Counter = Counter()
        def _shift(pno: int) -> str:
            o = old_of.get(pno)
            return f" (이전 판 {o}페이지)" if o is not None and o != pno else ""

        for pno, rect, size in sorted(indiv, key=lambda f: (f[0], -f[2])):
            per_page_no[pno] += 1
            key = f"{pno}페이지 위치{per_page_no[pno]}"
            regions.append((key, ns_.where(pno, rect) + _shift(pno)))
            cap_order.append((0, size, key, pno, rect))
        for pno in size_diff:
            regions.append((f"{pno}페이지", f"{pno}페이지 (페이지 크기 변경){_shift(pno)}"))
        wide_pages = {p for p, _, _ in wide}
        if wide_pages:                     # 그 페이지의 작은 위치들은 어긋남의 조각 — 한 줄로 접는다 (리뷰13 ④-4)
            regions = [(k, w) for k, w in regions if not any(k.startswith(f"{p}페이지 위치") for p in wide_pages)]
            cap_order = [c for c in cap_order if not (c[0] == 0 and c[3] in wide_pages)]
        for pno, rect, size in wide:
            key = f"{pno}페이지 전체"
            regions.append((key, WIDE_SHIFT_NOTE + _shift(pno)))
            cap_order.append((2, size, key, pno, rect))
        # 짝이 없는 페이지 = 추가/삭제 — regions(그림 변경)가 아니라 caps에 실어 보낸다.
        # 뒤 페이지들은 번호가 밀렸을 뿐 '변경'이 아니다
        for ci, (pnos, rect, size) in enumerate(
                sorted(commons, key=lambda c: -len(c[0])), start=1):
            key = f"공통위치{ci}"
            regions.append((key,
                            f"좌표 ({rect.x0:.0f}, {rect.y0:.0f}) 부근 — "
                            f"{len(pnos)}개 페이지 반복 (표제란·양식 변경 가능성)"))
            cap_order.append((1, size, key, pnos[0], rect))

        caps: dict = {}
        if beyond_note:
            caps["PAGES_BEYOND"] = {"where": beyond_note}
        for _pri, _size, key, pno, rect in sorted(
                cap_order, key=lambda c: (c[0], -c[1]))[:capture_top]:
            try:
                caps[key] = {
                    "before": _region_crop(os_, old_of.get(pno, pno), rect, "이전 판"),
                    "after": _region_crop(ns_, pno, rect, "새 판"),
                }
            except Exception:
                continue
        # 빠진 페이지·새 페이지는 그 페이지 전체를 근거로 (원칙 4)
        for k, opno in enumerate(old_only):
            cap = {"where": f"이전 판 {opno}페이지 — 새 판에 없음 (삭제)"}
            if k < (capture_top or 5):
                try:
                    cap["before"] = {"mime": "image/jpeg", "b64": _jpeg_b64(os_.full_page(opno), quality=60),
                                     "caption": f"이전 판 {opno}페이지 (새 판에 없음)"}
                    cap["after"] = None
                except Exception:
                    pass
            caps[f"PAGE_REMOVED|{opno}페이지"] = cap
        for k, pno in enumerate(new_only):
            cap = {"where": f"새 판 {pno}페이지 — 이전 판에 없는 페이지 (추가)"}
            if k < (capture_top or 5):
                try:
                    cap["before"] = None
                    cap["after"] = {"mime": "image/jpeg", "b64": _jpeg_b64(ns_.full_page(pno), quality=60),
                                    "caption": f"새 판 {pno}페이지 (이전 판에 없음)"}
                except Exception:
                    pass
            caps[f"PAGE_ADDED|{pno}페이지"] = cap
        if pairs and (old_only or new_only or any(i != j for i, j in pairs)):
            caps["PAGE_MAP"] = {str(j): i for i, j in pairs}   # 나란히 보기가 같은 페이지를 놓게
        if len(os_) == len(ns_):
            for i, j in pairs:
                if i != j:
                    caps[f"PAGE_MOVED|{j}페이지"] = {"where": f"이전 판 {i}페이지 → 새 판 {j}페이지 (순서 바뀜)"}
        # 이전 판 틀 **밖에** 새로 그린 내용은 아예 안 그려져 '그림 동일'로 보였다 —
        # 도면 옆에 구역을 통째로 더 그려도 0픽셀 차이였다 (2026-09-10 매트릭스 실측).
        # 픽셀로는 영영 안 보이므로 틀을 벗어난 사실 자체를 알린다
        if rotated:
            caps["PAGE_ROTATED"] = {"pages": rotated}
        try:
            grew = float(ns_.meta(1).get("outside") or 0)
        except Exception:                              # noqa: BLE001
            grew = 0.0
        if grew > 0:
            caps["AREA_GREW"] = {"where": f"이전 판 대비 약 {grew * 100:.0f}% 바깥",
                                 "pct": grew}
        return regions, caps
    except Exception:
        return None
    finally:
        if os_ is not None:
            os_.close()
        if ns_ is not None:
            ns_.close()


def page_pair_images(old, new, pno: int, old_pno: int | None = None) -> tuple[str, str, int] | None:
    """두 판의 같은 페이지 전체를 JPEG(base64)로 — 전/후 나란히 육안 비교용.
    감지가 놓친 변경도 사람이 직접 훑을 수 있는 안전망 (2026-08-27 미탐 대응).
    old/new: PDF·DXF 경로 또는 기록해 둔 페이지 그림(PageRender 목록) — 같은 이름으로
    덮어쓴 도면도 기록 그림으로 나란히 놓는다 (2026-09-03 검토).
    돌려주는 값: (구판 b64, 신판 b64, 공통 페이지 수). 실패/범위 밖이면 None."""
    os_ = ns_ = None
    try:
        os_ = _source(old)
        fit = os_.meta() if isinstance(os_, _RenderSource) else None
        ns_ = _source(new, fit=fit)
        if old_pno is None:
            total = min(len(os_), len(ns_))
            if not (1 <= pno <= total):
                return None
            old_pno = pno
        else:
            total = len(ns_)                 # 페이지 짝 지도가 있으면 새 판 기준으로 넘긴다
            if not (1 <= pno <= total):
                return None
        old_b64 = (_jpeg_b64(os_.full_page(old_pno), quality=72)
                   if old_pno and 1 <= old_pno <= len(os_) else "")
        return (old_b64, _jpeg_b64(ns_.full_page(pno), quality=72), total)
    except Exception:
        return None
    finally:
        if os_ is not None:
            os_.close()
        if ns_ is not None:
            ns_.close()
