# -*- coding: utf-8 -*-
"""루트 순회 → 산출물 폴더 자동 탐지 → 파일별 sha256.

읽기 전용 원칙: 이 모듈은 산출물 파일을 'rb'로만 연다.
쓰기·이동·삭제 API를 절대 사용하지 않는다 (tests/test_readonly.py가 강제).
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
import os
from pathlib import Path
from typing import Iterable

# 산출물 확장자 기본값. 파일럿은 도면·BOM 중심이지만 문서 유형 독립 원칙에 따라
# 확장자 목록은 config로 교체 가능하다.
# 구형 오피스·한글·파워포인트도 파일 수준(해시) 변경은 잡는다 — 내용 추출은 없어도
# "바뀌었다"는 사실은 알려야 한다 (2026-09-02: 검출이 안 된다는 신고의 후보 하나)
DEFAULT_EXTENSIONS = (".dwg", ".dxf", ".pdf", ".xlsx", ".xls", ".docx", ".doc",
                      ".hwpx", ".hwp", ".pptx", ".ppt")

# 내용을 읽지는 못해도 "언제 누가 무엇을 덮어썼나"는 알아야 하는 형식 묶음.
# PLC·HMI·로봇 프로그램은 제조 현장에서 도면만큼 자주 바뀌는데 전부 비공개 이진
# 형식이라 Drev가 안을 못 본다. 그래도 변경 사실·크기·저장 시각·이름 변경은
# 관리할 수 있으므로, 설정 화면에서 한 번 눌러 켤 수 있게 묶어 둔다
# (2026-09-10 요청: "직접 확인이 불가능한 확장자들 … PLC 프로그램 등은
#  저장 날짜나 파일명 변경된거 정도는 관리가 가능하면 좋겠네")
#
# 목록 원칙 (2026-09-10 검토18 도메인 검토 반영):
#  - 벤더 문서로 확인된 것만. 못 찾은 것(.gx2 .gxws .xgt .cim .got .cvd .epj .cce)은 뺐다
#  - .txt .csv .png .jpg 같은 범용 확장자는 어느 묶음에도 넣지 않는다 — 한 번 누르면
#    비전 검사기가 매일 떨어뜨리는 이미지 수천 장·로그가 전부 감시에 들어와 첫 검사가
#    시간 단위가 된다. 필요하면 아래 칸에서 하나씩 넣는다
#  - 폴더형 프로젝트(지멘스 TIA .ap1x·STEP7 .s7p, EPLAN .elk, GX Developer .gpj,
#    키엔스 .kpr)는 겉의 stub 파일이 저장 때 안 바뀔 수 있어 실데이터 파일(.plf 등)과
#    보관본(.zap1x .zw1)을 함께 넣는다
EXT_PRESETS: dict[str, tuple[str, str, tuple[str, ...]]] = {
    "plc": ("PLC 프로그램",
            "미쓰비시·LS·지멘스·오므론·AB·슈나이더·키엔스·파나소닉 등 PLC 프로젝트 파일 "
            "(지멘스 TIA·STEP7처럼 폴더형이면 보관본·실데이터까지 함께 봅니다)", (
        ".gxw", ".gx3", ".gpj",                           # 미쓰비시 GX Works2/3·GX Developer(폴더형)
        ".xgwx", ".xgp",                                  # LS ELECTRIC XG5000
        ".zap13", ".zap14", ".zap15", ".zap15_1", ".zap16", ".zap17", ".zap18",
        ".zap19", ".zap20",                               # 지멘스 TIA Portal 보관본(단일 파일)
        ".ap13", ".ap14", ".ap15", ".ap15_1", ".ap16", ".ap17", ".ap18",
        ".ap19", ".ap20", ".plf", ".s7p",                 # 지멘스 TIA(폴더형 stub + PEData.plf)·STEP7
        ".cxp", ".smc", ".smc2",                          # 오므론 CX-Programmer·Sysmac Studio
        ".acd", ".rss", ".rsp", ".l5x", ".l5k",           # 로크웰(AB) Studio 5000·RSLogix
        ".stu", ".sta", ".xef", ".zef",                   # 슈나이더 Control Expert/Unity
        ".kpr",                                           # 키엔스 KV STUDIO(폴더형)·LS KGLWIN
        ".pce", ".fp",                                    # 파나소닉 FPWIN Pro/GR
        ".pdw", ".isp", ".dvp",                           # 파텍·델타
        ".plcproj", ".tsproj", ".tnzip", ".tpzip", ".tcpou",   # 벡호프 TwinCAT 3
        ".pro", ".project",                               # 코드시스 V2.3 / V3 (다른 도구와 겹칠 수 있음)
    )),
    "hmi": ("HMI·터치패널",
            "GT Designer·EasyBuilder·GP-Pro·XP-Builder·M2I·WinCC·FactoryTalk View 화면 프로젝트", (
        ".gtw", ".gtx", ".gtxs",                          # 미쓰비시 GT Designer3
        ".emtp", ".mtp", ".cmp",                          # 웨인텍 EasyBuilder Pro/8000
        ".prx", ".prw",                                   # 프로페이스 GP-Pro EX/PB3
        ".xpd",                                           # LS ELECTRIC XP-Builder
        ".dpx", ".dpx4",                                  # M2I XDesignerPlus
        ".ipp",                                           # 오므론 CX-Designer
        ".pdl", ".mcp", ".hmi",                           # 지멘스 WinCC / WinCC flexible
        ".apa", ".mer",                                   # 로크웰 FactoryTalk View
    )),
    "robot": ("로봇·비전",
              "야스카와·ABB·화낙·쿠카·UR·현대 로봇 프로그램, 코그넥스 비전 설정", (
        ".jbi",                                           # 야스카와 INFORM
        ".mod", ".prg",                                   # ABB RAPID (미쓰비시 MELFA·엡손도 .prg)
        ".tp", ".ls",                                     # 화낙 TP 바이너리·ASCII
        ".src",                                           # 쿠카 KRL (.dat은 범용이라 제외)
        ".urp",                                           # 유니버설로봇
        ".job",                                           # 코그넥스 In-Sight·HD현대로보틱스 Hi5/Hi6
        ".vpp",                                           # 코그넥스 VisionPro
    )),
    "cad3d": ("3D 모델",
              "솔리드웍스·인벤터·카티아·NX·솔리드엣지·STEP 등 3차원 모델 "
              "(Creo의 .prt.3 꼴은 확장자가 숫자라 잡지 못합니다)", (
        ".sldprt", ".sldasm", ".slddrw", ".sldlfp",       # 솔리드웍스
        ".step", ".stp", ".iges", ".igs", ".x_t", ".x_b", ".jt", ".sat",   # 중립 포맷
        ".ipt", ".iam", ".idw", ".ipn",                   # 인벤터
        ".catpart", ".catproduct", ".catdrawing",         # 카티아
        ".prt", ".asm",                                   # NX (.asm은 어셈블리 소스와 겹칠 수 있음)
        ".par", ".psm", ".dft",                           # 솔리드엣지
        ".3dm", ".f3d",                                   # 라이노·퓨전360
    )),
    "nc": ("NC·가공 데이터", "CNC 가공 프로그램(G코드·지멘스·하이덴하인·오쿠마)과 마스터캠 프로젝트", (
        ".nc", ".tap", ".cnc", ".gcode", ".eia", ".ptp",
        ".mpf", ".spf",                                   # 지멘스 840D 메인/서브
        ".min",                                           # 오쿠마 OSP
        ".mcam", ".emcam", ".mcx",                        # 마스터캠
    )),
    "ecad": ("전장 CAD", "EPLAN·E3·알티움·KiCad·Eagle 전기 설계 프로젝트", (
        ".elk", ".ell", ".zw1", ".elp",                   # EPLAN P8 (폴더형 stub + 백업/패킹)
        ".e3s",                                           # 주켄 E3.series
        ".pcbdoc", ".schdoc", ".prjpcb",                  # 알티움
        ".kicad_sch", ".kicad_pcb", ".kicad_pro",         # KiCad
        ".sch", ".brd",                                   # Eagle 등
    )),
    "etc": ("압축본·DWF", "외주·고객이 보낸 압축본(내용은 못 보고 바뀐 사실만), Autodesk 설계 검토 파일", (
        ".zip", ".7z", ".rar", ".dwf", ".dwfx",
    )),
}


def preset_of(ext: str) -> str:
    """확장자가 어느 묶음에 속하나 (없으면 빈 문자열)."""
    e = str(ext).lower()
    if not e.startswith("."):
        e = "." + e
    for key, (_, _, exts) in EXT_PRESETS.items():
        if e in exts:
            return key
    return ""

# CAD·오피스 임시파일 소음 제거 (DECISIONS 2026-08-20: 하루 1회 배치 이유이기도 함)
SKIP_NAME_PREFIXES = ("~$", ".")
SKIP_SUFFIXES = (".bak", ".tmp", ".dwl", ".dwl2", ".sv$")

_HASH_CHUNK = 1024 * 1024

# 파일명 끝의 날짜/버전 표기: _20260815, _260309(YYMMDD), -2026.08.15, v2, rev3,
# (20260815), 최종, 수정2, (2차수정), 승인용, R1, IFA ... — 현장에서 리비전을
# 덮어쓰지 않고 '표기 붙인 새 파일'로 저장하는 문화 대응 (2026-08-26 설계 검토 보강).
# 6자리는 월(01-12)·일(01-31)이 유효할 때만 날짜로 본다(부품번호 오탐 방지).
# rev 뒤는 숫자 또는 '문자 하나+숫자'만 — REVIEW/REVISED 꼬리 오인 방지 (2026-08-25)
# v2·R1은 앞 글자가 영문이면 판 표기가 아니다 — TR1/TR2·MOTOR2·HV1이 서로의 개정판으로
# 짝지어져 거짓 근거의 알림이 나가던 것 (2026-09-02 재검토 실측)
_VER_TOKEN = re.compile(
    r"[\s\-_.(]*(?:20\d{6}"
    r"|\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])"
    r"|20\d{2}[-._]\d{1,2}[-._]\d{1,2}"
    r"|\d{2}[-._](?:0?[1-9]|1[0-2])[-._](?:0?[1-9]|[12]\d|3[01])"
    r"|(?<![A-Za-z])[vV]\d+|[rR][eE][vV][\s\-_.]?(?:\d{1,4}[A-Za-z]?|[A-Za-z]\d{0,3})"
    r"|(?<![A-Za-z])[rR]\d{1,2}"
    r"|\d*차?\s*(?:수정|개정)(?:본|판)?\d*"
    r"|(?:진짜|찐)?\s*최종본?"
    r"|검토용|승인용|배포용|공람용|시공용|발행용|제출용"
    r"|IFA|IFC|AFC|IFR"
    r"|[fF]inal)\)?\s*$")


def revision_stem(filename: str) -> str:
    """파일명에서 확장자와 끝의 날짜/버전 표기를 걷어낸 '도면 이름'.
    예: '판넬도면_rev2_20260815.dxf' → '판넬도면' — 같은 stem이면 같은 도면의 다른 판."""
    stem = filename.rsplit(".", 1)[0] if "." in filename else filename
    prev = None
    while prev != stem:
        prev = stem
        stem = _VER_TOKEN.sub("", stem)
        # '(2차수정)'을 반쯤 벗기다 만 '이름(2차' 꼴 — 짝 잃은 여는 괄호 꼬리 수습
        stem = re.sub(r"\([^)]*$", "", stem)
    return stem.strip(" -_.")


def pair_key(filename: str) -> str:
    """판 짝짓기용 비교 키 — revision_stem에서 공백을 걷고 대소문자를 무시한다.
    재저장하며 '판넬도면'↔'판넬 도면', 'PANEL'↔'panel'처럼 달라진 판을 같은
    도면으로 본다 (2026-08-28 사용자 제안 — 같은 폴더 조건이 있어 위험이 낮다).
    밑줄·하이픈은 걷지 않는다: M-101과 M101은 도면번호 체계상 다를 수 있다."""
    return re.sub(r"\s+", "", revision_stem(filename)).casefold()


@dataclass(frozen=True)
class FileRecord:
    """스캔 시점의 파일 한 개 스냅샷. path는 루트 기준 상대 경로(POSIX 구분자)."""
    path: str
    sha256: str
    size: int
    mtime: float


def is_artifact(path: Path, extensions: Iterable[str] = DEFAULT_EXTENSIONS) -> bool:
    name = path.name
    if any(name.startswith(p) for p in SKIP_NAME_PREFIXES):
        return False
    if any(name.lower().endswith(s) for s in SKIP_SUFFIXES):
        return False
    return path.suffix.lower() in {e.lower() for e in extensions}


def find_artifact_dirs(root: Path, extensions: Iterable[str] = DEFAULT_EXTENSIONS) -> list[Path]:
    """산출물 파일을 1개 이상 직접 포함한 폴더 목록 (루트 기준 정렬)."""
    dirs: set[Path] = set()
    for p in Path(root).rglob("*"):
        if p.is_file() and is_artifact(p, extensions):
            dirs.add(p.parent)
    return sorted(dirs)


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:  # 읽기 전용: 'rb' 외의 모드 금지
        while chunk := f.read(_HASH_CHUNK):
            h.update(chunk)
    return h.hexdigest()


def is_excluded(rel_posix: str, excludes: Iterable[str]) -> bool:
    """루트 기준 상대 경로가 제외 폴더 아래인지 (GUI '감시 제외' 설정)."""
    for ex in excludes:
        ex = ex.strip("/").strip()
        if ex and (rel_posix == ex or rel_posix.startswith(ex + "/")):
            return True
    return False


def _walk_files(root: Path, errors: list | None = None, activity=None):
    """루트 아래 파일을 결정적 순서로 낸다 — 링크(정션·DFS)는 따라가되 **순환·중복은
    막는다**.

    rglob은 정션을 따라가 `a/b/loop → a` 하나면 같은 파일이 64번 기록됐다(2026-09-02
    실측). 링크를 아예 건너뛰면 파일서버의 DFS 링크 아래 실제 폴더가 '삭제'로 보고된다
    (재검토에서 지적). 그래서 실제 경로(realpath)의 방문 집합으로 판단한다: 이미 지난
    실제 폴더를 다시 가리키는 링크만 건너뛰고 errors에 남긴다."""
    def _real(p: str) -> str:
        try:
            return os.path.normcase(os.path.realpath(p))
        except OSError:
            return os.path.normcase(p)

    _REPARSE = 0x400            # FILE_ATTRIBUTE_REPARSE_POINT

    def _is_link(p: str) -> bool:
        """심볼릭 링크·정션만이 아니라 **모든 재분석 지점**을 링크로 본다.

        `islink`/`isjunction`은 SYMLINK·MOUNT_POINT 태그만 참이라 DFS 링크
        (IO_REPARSE_TAG_DFS)에 거짓이었다. 예전에는 폴더마다 realpath를 불러 `visited`에
        실제 경로가 들어갔으므로 나중 정션을 걸렀는데, 이제 링크가 아닌 폴더는 겉보기 경로를
        넣으므로 못 걸러 같은 파일이 두 번 기록됐다 (2026-09-07 운영 검토 1)."""
        try:
            attrs = getattr(os.lstat(p), "st_file_attributes", 0)
            if attrs:
                return bool(attrs & _REPARSE)
        except OSError:
            return False
        except ValueError:
            pass
        try:
            return os.path.islink(p) or os.path.isjunction(p)   # 윈도우가 아닌 곳
        except OSError:
            return False

    root_real = _real(str(root))
    visited = {root_real}                 # 실제 경로로 이미 들어간(들어갈) 폴더들
    # 폴더마다 realpath를 부르면 사내 파일서버(SMB)에서는 경로 깊이만큼 왕복이 생겨
    # 폴더 수만 개짜리 서버의 첫 검사가 몇 시간이 된다 (2026-09-07). 링크가 아닌 폴더의
    # 실제 경로는 '부모의 실제 경로 + 이름'과 같으므로 물어보지 않고 이어 붙인다.
    real_of = {str(root): root_real}

    def _dir_error(err: OSError) -> None:
        # os.walk는 폴더 목록을 못 읽으면 조용히 건너뛴다 — 권한 없는 폴더·순단이면
        # 그 아래 전부가 '삭제'로 나갔다 (2026-09-04 검토 core H3). 폴더 오류는
        # 끝에 '/'를 붙여 errors에 남기고, 호출부가 그 아래 이전 기록을 이월한다
        if errors is None:
            return
        bad = getattr(err, "filename", None) or str(root)
        try:
            rel = "/".join(os.path.relpath(bad, root).split("\\"))
        except ValueError:
            rel = "."
        rel = "" if rel in (".", "") else rel
        errors.append((rel + "/", f"폴더를 읽지 못함: {err.strerror or err}"))

    ndirs = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True, onerror=_dir_error):
        base_real = real_of.pop(dirpath, None) or _real(dirpath)
        ndirs += 1
        if activity is not None:
            # 산출물이 한 건도 없는 폴더가 수천 개여도 화면이 살아 있게, 그리고 이 사이에도
            # [검사 중지]가 듣게 한다 — 중지 확인이 진행 표시 안에 있다 (2026-09-07)
            activity(f"폴더 {ndirs:,}개째 훑는 중: {dirpath}")
        keep = []
        for d in sorted(dirnames):
            full = os.path.join(dirpath, d)
            if _is_link(full):
                real = _real(full)
                # 링크가 이미 지난 실제 폴더나 감시 트리 안쪽(직접 돌게 됨)을 가리키면
                # 건너뛴다 — 순환(a/b/loop→a)과 중복이 여기 해당. 바깥의 실제 폴더
                # (DFS 링크)는 따라간다
                inside = (real == root_real or real.startswith(root_real + os.sep)
                          or any(real == v or real.startswith(v + os.sep) for v in visited))
                if inside:
                    if errors is not None:
                        rel = "/".join(os.path.relpath(full, root).split("\\"))
                        errors.append((rel, "순환·중복 링크 폴더는 건너뜁니다 (같은 파일이 두 번 기록되지 않게)"))
                    continue
            else:
                real = os.path.normcase(os.path.join(base_real, d))
            visited.add(real)
            real_of[full] = real
            keep.append(d)
        dirnames[:] = keep
        # 못 들어간 폴더(권한 없음)는 os.walk가 dirpath로 오지 않아 pop되지 않는다 —
        # 수만 폴더에서 조금씩 쌓이므로 지금 걷어낸다 (2026-09-07 운영 검토 낮음)
        if len(real_of) > 4096:
            for k in [k for k in real_of if not k.startswith(dirpath)][:2048]:
                real_of.pop(k, None)
        for f in sorted(filenames):
            yield Path(dirpath) / f


def scan(root: Path, extensions: Iterable[str] = DEFAULT_EXTENSIONS,
         errors: list | None = None,
         excludes: Iterable[str] = (),
         prev: dict | None = None,
         progress=None, activity=None) -> list[FileRecord]:
    """루트 아래 모든 산출물 파일의 스냅샷. 경로 기준 정렬로 결과 재현 가능.

    읽지 못한 파일(잠김·권한)은 스캔을 중단시키지 않고 errors에 (경로, 사유)로
    수집된다 — 파일 1개 때문에 전체 감시가 죽으면 안 된다.
    excludes: 감시에서 뺄 루트 기준 상대 폴더 경로 목록.
    prev: 직전 스냅샷 {상대경로: (sha256, size, mtime)}. 크기·수정시각이 같으면
    파일을 다시 읽지 않고 저장된 해시를 재사용한다 — 수천 파일 서버에서 매일
    전체를 재해싱하면 시간 단위가 걸리므로. 저장이 일어나면 mtime이 반드시
    바뀌기 때문에 감지 정확도는 그대로다.
    """
    root = Path(root)
    records: list[FileRecord] = []
    for p in _walk_files(root, errors, activity=activity):
        if not (p.is_file() and is_artifact(p, extensions)):
            continue
        rel = p.relative_to(root).as_posix()
        if is_excluded(rel, excludes):
            continue
        try:
            st = p.stat()
            pv = prev.get(rel) if prev else None
            if pv is not None and pv[1] == st.st_size and pv[2] == st.st_mtime:
                sha = pv[0]  # 변동 없음 → 재해싱 생략
            else:
                if activity is not None:
                    activity(rel)          # 큰 파일 하나에서 오래 걸리면 그 이름이 화면에 뜬다
                sha = sha256_of(p)
        except OSError as e:
            if errors is not None:
                errors.append((rel, str(e)))
            continue
        records.append(FileRecord(path=rel, sha256=sha, size=st.st_size,
                                  mtime=st.st_mtime))
        if progress is not None:
            progress(len(records))  # 대용량 서버 첫 해싱이 '멈춘 것'처럼 보이지 않게
    return records
