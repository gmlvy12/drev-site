# -*- coding: utf-8 -*-
"""루트 순회 → 산출물 폴더 자동 탐지 → 파일별 sha256.

읽기 전용 원칙: 이 모듈은 산출물 파일을 'rb'로만 연다.
쓰기·이동·삭제 API를 절대 사용하지 않는다 (tests/test_readonly.py가 강제).
"""

from __future__ import annotations

import hashlib
import re
import stat
import unicodedata
from dataclasses import dataclass
import os
from pathlib import Path
from typing import Iterable

from watcher.longpath import LONG_PATH_NOTE, LONG_PREFIX, os_path, plain, too_long_error

# 산출물 확장자 기본값. 파일럿은 도면·BOM 중심이지만 문서 유형 독립 원칙에 따라
# 확장자 목록은 config로 교체 가능하다.
# 구형 오피스·한글·파워포인트도 파일 수준(해시) 변경은 잡는다 — 내용 추출은 없어도
# "바뀌었다"는 사실은 알려야 한다 (2026-09-02: 검출이 안 된다는 신고의 후보 하나)
DEFAULT_EXTENSIONS = (".dwg", ".dxf", ".pdf", ".xlsx", ".xlsm", ".xls", ".docx", ".doc",
                      ".hwpx", ".hwp", ".pptx", ".ppt")

# 내용을 읽지는 못해도 "언제 누가 무엇을 덮어썼나"는 알아야 하는 형식 묶음.
# PLC·HMI·로봇 프로그램은 제조 현장에서 도면만큼 자주 바뀌는데 전부 비공개 이진
# 형식이라 Drev가 안을 못 본다. 그래도 변경 사실·크기·저장 시각·이름 변경은
# 관리할 수 있으므로, 설정 화면에서 한 번 눌러 켤 수 있게 묶어 둔다
# (2026-09-10 요청: "직접 확인이 불가능한 확장자들 … PLC 프로그램 등은
#  저장 날짜나 파일명 변경된거 정도는 관리가 가능하면 좋겠네")
#
# 목록 원칙 (2026-09-10 검토18 도메인 검토 반영):
#  - 벤더 문서로 확인된 것만. 못 찾은 것(.gx2 .gxws .xgt .cim .got .cvd .epj .cce)은 뺐다
#  - .txt .csv .png .jpg 같은 범용 확장자는 어느 묶음에도 넣지 않는다 — 한 번 누르면
#    비전 검사기가 매일 떨어뜨리는 이미지 수천 장·로그가 전부 감시에 들어와 첫 검사가
#    시간 단위가 된다. 필요하면 아래 칸에서 하나씩 넣는다
#  - 폴더형 프로젝트(지멘스 TIA .ap1x·STEP7 .s7p, EPLAN .elk, GX Developer .gpj,
#    키엔스 .kpr)는 겉의 stub 파일이 저장 때 안 바뀔 수 있어 실데이터 파일(.plf 등)과
#    보관본(.zap1x .zw1)을 함께 넣는다
EXT_PRESETS: dict[str, tuple[str, str, tuple[str, ...]]] = {
    "plc": ("PLC 프로그램",
            "미쓰비시·LS·지멘스·오므론·AB·슈나이더·키엔스·파나소닉 등 PLC 프로젝트 파일 "
            "(지멘스 TIA·STEP7처럼 폴더형이면 보관본·실데이터까지 함께 봅니다)", (
        ".gxw", ".gx3", ".gpj",                           # 미쓰비시 GX Works2/3·GX Developer(폴더형)
        ".xgwx", ".xgp",                                  # LS ELECTRIC XG5000
        ".zap13", ".zap14", ".zap15", ".zap15_1", ".zap16", ".zap17", ".zap18",
        ".zap19", ".zap20",                               # 지멘스 TIA Portal 보관본(단일 파일)
        ".ap13", ".ap14", ".ap15", ".ap15_1", ".ap16", ".ap17", ".ap18",
        ".ap19", ".ap20", ".plf", ".s7p",                 # 지멘스 TIA(폴더형 stub + PEData.plf)·STEP7
        ".cxp", ".smc", ".smc2",                          # 오므론 CX-Programmer·Sysmac Studio
        ".acd", ".rss", ".rsp", ".l5x", ".l5k",           # 로크웰(AB) Studio 5000·RSLogix
        ".stu", ".sta", ".xef", ".zef",                   # 슈나이더 Control Expert/Unity
        ".kpr",                                           # 키엔스 KV STUDIO(폴더형)·LS KGLWIN
        ".pce", ".fp",                                    # 파나소닉 FPWIN Pro/GR
        ".pdw", ".isp", ".dvp",                           # 파텍·델타
        ".plcproj", ".tsproj", ".tnzip", ".tpzip", ".tcpou",   # 벡호프 TwinCAT 3
        ".pro", ".project",                               # 코드시스 V2.3 / V3 (다른 도구와 겹칠 수 있음)
    )),
    "hmi": ("HMI·터치패널",
            "GT Designer·EasyBuilder·GP-Pro·XP-Builder·M2I·WinCC·FactoryTalk View 화면 프로젝트", (
        ".gtw", ".gtx", ".gtxs",                          # 미쓰비시 GT Designer3
        ".emtp", ".mtp", ".cmp",                          # 웨인텍 EasyBuilder Pro/8000
        ".prx", ".prw",                                   # 프로페이스 GP-Pro EX/PB3
        ".xpd",                                           # LS ELECTRIC XP-Builder
        ".dpx", ".dpx4",                                  # M2I XDesignerPlus
        ".ipp",                                           # 오므론 CX-Designer
        ".pdl", ".mcp", ".hmi",                           # 지멘스 WinCC / WinCC flexible
        ".apa", ".mer",                                   # 로크웰 FactoryTalk View
    )),
    "robot": ("로봇·비전",
              "야스카와·ABB·화낙·쿠카·UR·현대 로봇 프로그램, 코그넥스 비전 설정", (
        ".jbi",                                           # 야스카와 INFORM
        ".mod", ".prg",                                   # ABB RAPID (미쓰비시 MELFA·엡손도 .prg)
        ".tp", ".ls",                                     # 화낙 TP 바이너리·ASCII
        ".src",                                           # 쿠카 KRL (.dat은 범용이라 제외)
        ".urp",                                           # 유니버설로봇
        ".job",                                           # 코그넥스 In-Sight·HD현대로보틱스 Hi5/Hi6
        ".vpp",                                           # 코그넥스 VisionPro
    )),
    "cad3d": ("3D 모델",
              "솔리드웍스·인벤터·카티아·NX·솔리드엣지·STEP 등 3차원 모델 "
              "(Creo의 .prt.3 꼴은 확장자가 숫자라 잡지 못합니다)", (
        ".sldprt", ".sldasm", ".slddrw", ".sldlfp",       # 솔리드웍스
        ".step", ".stp", ".iges", ".igs", ".x_t", ".x_b", ".jt", ".sat",   # 중립 포맷
        ".ipt", ".iam", ".idw", ".ipn",                   # 인벤터
        ".catpart", ".catproduct", ".catdrawing",         # 카티아
        ".prt", ".asm",                                   # NX (.asm은 어셈블리 소스와 겹칠 수 있음)
        ".par", ".psm", ".dft",                           # 솔리드엣지
        ".3dm", ".f3d",                                   # 라이노·퓨전360
    )),
    "nc": ("NC·가공 데이터", "CNC 가공 프로그램(G코드·지멘스·하이덴하인·오쿠마)과 마스터캠 프로젝트", (
        ".nc", ".tap", ".cnc", ".gcode", ".eia", ".ptp",
        ".mpf", ".spf",                                   # 지멘스 840D 메인/서브
        ".min",                                           # 오쿠마 OSP
        ".mcam", ".emcam", ".mcx",                        # 마스터캠
    )),
    "ecad": ("전장 CAD", "EPLAN·E3·알티움·KiCad·Eagle 전기 설계 프로젝트", (
        ".elk", ".ell", ".zw1", ".elp",                   # EPLAN P8 (폴더형 stub + 백업/패킹)
        ".e3s",                                           # 주켄 E3.series
        ".pcbdoc", ".schdoc", ".prjpcb",                  # 알티움
        ".kicad_sch", ".kicad_pcb", ".kicad_pro",         # KiCad
        ".sch", ".brd",                                   # Eagle 등
    )),
    "etc": ("압축본·DWF", "외주·고객이 보낸 압축본(내용은 못 보고 바뀐 사실만), Autodesk 설계 검토 파일", (
        ".zip", ".7z", ".rar", ".dwf", ".dwfx",
    )),
}


def preset_of(ext: str) -> str:
    """확장자가 어느 묶음에 속하나 (없으면 빈 문자열)."""
    e = str(ext).lower()
    if not e.startswith("."):
        e = "." + e
    for key, (_, _, exts) in EXT_PRESETS.items():
        if e in exts:
            return key
    return ""

# CAD·오피스 임시파일 소음 제거 (DECISIONS 2026-08-20: 하루 1회 배치 이유이기도 함)
SKIP_NAME_PREFIXES = ("~$", ".")
SKIP_SUFFIXES = (".bak", ".tmp", ".dwl", ".dwl2", ".sv$")

_HASH_CHUNK = 1024 * 1024

# 파일명 끝의 날짜/버전 표기: _20260815, _260309(YYMMDD), -2026.08.15, v2, rev3,
# (20260815), 최종, 수정2, (2차수정), 승인용, R1, IFA ... — 현장에서 리비전을
# 덮어쓰지 않고 '표기 붙인 새 파일'로 저장하는 문화 대응 (2026-08-26 설계 검토 보강).
# 6자리는 월(01-12)·일(01-31)이 유효할 때만 날짜로 본다(부품번호 오탐 방지).
# rev 뒤는 숫자 또는 '문자 하나+숫자'만 — REVIEW/REVISED 꼬리 오인 방지 (2026-08-25)
# v2·R1은 앞 글자가 영문이면 판 표기가 아니다 — TR1/TR2·MOTOR2·HV1이 서로의 개정판으로
# 짝지어져 거짓 근거의 알림이 나가던 것 (2026-09-02 재검토 실측)
_VER_TOKEN = re.compile(
    r"[\s\-_.(]*(?:20\d{6}"
    r"|\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])"
    r"|20\d{2}[-._]\d{1,2}[-._]\d{1,2}"
    r"|\d{2}[-._](?:0?[1-9]|1[0-2])[-._](?:0?[1-9]|[12]\d|3[01])"
    r"|(?<![A-Za-z])[vV]\d+|[rR][eE][vV][\s\-_.]?(?:\d{1,4}[A-Za-z]?|[A-Za-z]\d{0,3})"
    r"|(?<![A-Za-z])[rR]\d{1,2}"
    # '_RA'→'_RB'(R + 대문자 한 글자) — 구분자 바로 뒤의 대문자 R일 때만 ('LOOP_RA'·'헤드풀리_RB'). 새 이름 판을 짝짓지 못해 삭제 +
    # 새 도면이 됐다 (2026-10-20 PDF 대량 시험 N2, 19건). 'PUMP_RTD'처럼 두 글자 넘는 꼬리는 아니다. 개정 글자에 안 쓰는 I·O와
    # 수신(RX)은 빼고
    r"|(?<=[\s\-_.(])R[A-HJ-NP-WYZ]"
    r"|\(\s*[A-Za-z]\d{0,2}\s*\)"
    # '(1차)'→'(2차)' 괄호 안 차수 — 문서 대량 시험 C4 41건(회의록 '7차(1차)'→'7차(2차)'). 괄호 없는 '7차'·'8차'는 다른 회의라 아니다
    r"|\(\s*\d{1,2}\s*차\s*\)"
    # 끝의 '_A'·' B'(대문자 한 글자) — 앞이 한글·숫자일 때만. 'SPEC-7004_납품사양서_A'→'_B' 새 이름 판을 짝짓지 못했다
    # (검토68 B6). 앞이 영문('PANEL_A'·'MCC_B')이면 구역·반쪽 이름일 수 있어 판 표기가 아니다(TR1/TR2 규칙과 같은 뜻),
    # 하이픈('E-101-A')은 도면번호 시트 표기일 수 있어 받지 않는다
    r"|(?<=[0-9가-힣][_\s])[A-Z]"
    r"|\d*차?\s*(?:수정|개정)(?:본|판)?\d*"
    r"|(?:진짜|찐)?\s*최+종본?\d*(?:\s*\(\d{1,2}\))?"          # '최최종'·'최종2' — '최'가 남아 짝을 못 지었다 (검토39 P4 중간 2)
    r"|(?<=[\s\-_.(])(?:진짜|찐|확정)"     # '_최종_진짜'·'_최종_확정'·'_최종(1)' — 새 도면으로만 알렸다 (검토66 B3)
    r"|검토용|승인용|배포용|공람용|시공용|발행용|제출용"
    r"|IFA|IFC|AFC|IFR"
    # 소문자 'E-101_ifc'도 — 구분자 바로 뒤일 때만('Pacific'·'tarifc'는 이름) (재검토 2026-10-28 S4)
    r"|(?<=[\s\-_.(])(?:ifa|ifc|afc|ifr)"
    r"|[fF]inal)\)?\s*$")


def revision_stem(filename: str) -> str:
    """파일명에서 확장자와 끝의 날짜/버전 표기를 걷어낸 '도면 이름'.
    예: '판넬도면_rev2_20260815.dxf' → '판넬도면' — 같은 stem이면 같은 도면의 다른 판."""
    stem = filename.rsplit(".", 1)[0] if "." in filename else filename
    prev = None
    while prev != stem:
        prev = stem
        stem = _VER_TOKEN.sub("", stem)
        # '(2차수정)'을 반쯤 벗기다 만 '이름(2차' 꼴 — 짝 잃은 여는 괄호 꼬리 수습
        stem = re.sub(r"\([^)]*$", "", stem)
    return stem.strip(" -_.")


def rev_shape(rv) -> tuple | None:
    """표제란 Rev의 모양 — 같은 모양끼리만 순서를 말할 수 있다. 'A'·'AB'는 글자, '0'·'12'는 숫자,
    'P1'·'A2'는 (접두 글자, 숫자), 그 밖('IFC'·'B-1')은 저마다 다른 모양. 길이부터 견주면 'P2'(예비)가
    'A'(발행)보다, 'A1'이 'B'보다 새 판이 됐다 (검토36 A N1)."""
    import unicodedata as _ud
    rv = _ud.normalize("NFKC", str(rv or "")).strip().upper()     # 전각 'Ａ'가 'B'보다 새 판이 됐다 (검토37 A 낮음)
    if not rv:
        return None
    if rv.isdigit():
        return ("D",)
    if rv.isalpha() and len(rv) <= 2:
        return ("L",)
    m = re.fullmatch(r"([A-Z]{1,3})(\d{1,3})", rv)
    if m:
        return ("P", m.group(1))
    # 그 밖은 **꼴**로 묶는다(글자 → A, 숫자 → 9) — 값마다 다른 모양으로 두면 같은 체계의 '1.0'과 '1.1',
    # 'B-1'과 'B-2'도 섞임이 되어 Rev 비교가 꺼지고, 구판을 다시 저장한 날 현행이 치워졌다 (검토36 E 중간 1)
    return ("X", re.sub(r"[A-Z]+", "A", re.sub(r"\d+", "9", rv)))


def rev_key(rv) -> tuple:
    """같은 모양 안에서의 순서 — 숫자는 값, 글자는 (길이, 글자: A<…<Z<AA), 접두+숫자는 숫자,
    그 밖(1.1·B-2)은 숫자·글자 조각별로."""
    import unicodedata as _ud
    rv = _ud.normalize("NFKC", str(rv or "")).strip().upper()
    sh = rev_shape(rv)
    if sh == ("D",):
        return (int(rv),)
    if sh == ("L",):
        return (len(rv), rv)
    if sh and sh[0] == "P":
        return (int(re.sub(r"\D", "", rv)),)
    return tuple((0, int(p)) if p.isdigit() else (1, len(p), p) for p in re.findall(r"\d+|[A-Z]+", rv))


def ver_rank(filename: str) -> tuple:
    """파일 이름의 판 표기(revision_stem이 걷어낸 꼬리)의 순서 — 'revB' > 'revA', '2' > '1',
    날짜 꼬리표(20260916)는 '그날의 사본'이라 표기 없는 현행보다 **낮다**. (0,날짜) < (1,0) 무표기 < (2,n) 숫자 < (3,..) 문자."""
    stem = filename.rsplit(".", 1)[0] if "." in filename else filename
    base = revision_stem(filename)
    tail = stem[len(base):] if stem.startswith(base) else stem
    core = re.sub(r"(?i)^[\s\-_.(]*(rev(?:ision)?|r|v)?[\s\-_.]*", "", tail).strip(" -_.()")
    if re.fullmatch(r"(20\d{6}|20\d{2}[-._]\d{1,2}[-._]\d{1,2}|\d{6})", core):
        return (0, int(re.sub(r"\D", "", core) or 0), "")
    if not core:
        return (1, 0, "")
    if core.isdigit():
        return (2, int(core), "")
    return (3, len(core), core.upper())


def pair_key(filename: str) -> str:
    """판 짝짓기용 비교 키 — revision_stem에서 공백을 걷고 대소문자를 무시한다.
    재저장하며 '판넬도면'↔'판넬 도면', 'PANEL'↔'panel'처럼 달라진 판을 같은
    도면으로 본다 (2026-08-28 사용자 제안 — 같은 폴더 조건이 있어 위험이 낮다).
    밑줄·하이픈은 걷지 않는다: M-101과 M101은 도면번호 체계상 다를 수 있다."""
    # 맥에서 올린 이름(NFD — 자모가 풀린 꼴)도 같은 이름이다 — 화면엔 똑같이 보이는데 짝을 못 지어 '[추가]'로만 나갔다 (검토66 B4)
    return re.sub(r"\s+", "", unicodedata.normalize("NFC", revision_stem(filename))).casefold()


@dataclass(frozen=True)
class FileRecord:
    """스캔 시점의 파일 한 개 스냅샷. path는 루트 기준 상대 경로(POSIX 구분자)."""
    path: str
    sha256: str
    size: int
    mtime: float


def is_artifact(path: Path, extensions: Iterable[str] = DEFAULT_EXTENSIONS) -> bool:
    name = path.name
    if any(name.startswith(p) for p in SKIP_NAME_PREFIXES):
        return False
    if any(name.lower().endswith(s) for s in SKIP_SUFFIXES):
        return False
    return path.suffix.lower() in {e.lower() for e in extensions}


# 클라우드 자리표시자 속성 — RECALL_ON_DATA_ACCESS(0x400000)·RECALL_ON_OPEN(0x40000)·OFFLINE(0x1000) (검토20 r15-6)
CLOUD_PLACEHOLDER_ATTRS = 0x400000 | 0x40000 | 0x1000
CLOUD_PLACEHOLDER_NOTE = ("클라우드 자리표시자 — 내용 읽지 않음 (OneDrive·SharePoint에서 아직 내려받지 않은 파일이라 읽으면 "
                          "내려받아집니다. 이 PC에 '항상 유지'로 받아 두면 다음 검사부터 비교합니다)")
WRITING_NOTE = "검사하는 동안 파일이 바뀌는 중(쓰는 중)이라 다음 검사로 미룹니다"


def _ignorable_stat_error(e: OSError) -> bool:
    """Path.is_file()이 '아님'으로 삼키던 오류 — 나열 뒤 지워짐·이름 꼴 문제. 그 밖(네트워크 끊김 등)은 알린다."""
    import errno as _errno
    return (getattr(e, "errno", None) in (_errno.ENOENT, _errno.ENOTDIR, _errno.EBADF, _errno.ELOOP)
            or getattr(e, "winerror", None) in (21, 123, 1921))


def _long_unreadable(e: OSError, p) -> bool:
    """긴 경로의 '없음'이 정말 지워진 것인지, 길이 탓에 못 연 것인지 — 부모 폴더 목록에 이름이 아직 있으면(또는 목록도 못 읽으면)
    길이 탓으로 본다. 짧은 경로는 늘 거짓(예전처럼 '나열 뒤 지워짐')."""
    if not too_long_error(e, p):
        return False
    try:
        return Path(p).name in os.listdir(os_path(str(Path(p).parent)))
    except OSError:
        return True


def _err_text(e: OSError, p) -> str:
    """읽지 못한 사유 글 — 긴 경로 탓이면 '경로가 너무 길어 읽지 못함', 오류 글에 실린 확장 경로 접두는 떼어 화면·메일로 새지 않게 (pv2 D-1)."""
    if too_long_error(e, p):
        return LONG_PATH_NOTE
    fn = str(getattr(e, "filename", "") or "")
    if fn.startswith(LONG_PREFIX):
        return f"{e.strerror or type(e).__name__}: {plain(fn)}"
    return str(e)


def find_artifact_dirs(root: Path, extensions: Iterable[str] = DEFAULT_EXTENSIONS) -> list[Path]:
    """산출물 파일을 1개 이상 직접 포함한 폴더 목록 (루트 기준 정렬)."""
    dirs: set[Path] = set()
    for p in Path(root).rglob("*"):
        if p.is_file() and is_artifact(p, extensions):
            dirs.add(p.parent)
    return sorted(dirs)


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(os_path(path), "rb") as f:  # 읽기 전용: 'rb' 외의 모드 금지 (긴 경로는 확장 접두로 — pv2 D-1)
        while chunk := f.read(_HASH_CHUNK):
            h.update(chunk)
    return h.hexdigest()


def is_excluded(rel_posix: str, excludes: Iterable[str]) -> bool:
    """루트 기준 상대 경로가 제외 폴더 아래인지 (GUI '감시 제외' 설정).
    윈도우 경로는 대소문자를 가리지 않고 손으로 적은 설정은 역슬래시를 쓴다 — 'archive'·'백업\\'·'a\\b'가 'Archive/'·'백업/'·
    'a/b/'를 빼지 못해 제외한 폴더가 매일 검사·알림에 들어왔다 (재검토 2026-10-28 S2). 견줄 때만 접는다(설정 값은 그대로)."""
    rel = "/".join(str(rel_posix).split("\\")).casefold()
    for ex in excludes:
        ex = "/".join(str(ex).split("\\")).strip("/").strip().casefold()
        if ex and (rel == ex or rel.startswith(ex + "/")):
            return True
    return False


def _walk(top: str, onerror):
    """os.walk(top, followlinks=True, onerror=…)와 같은 순서·같은 약속(위에서 아래로, dirnames를 고치면 그 아래를 건너뜀)으로 걷되,
    폴더 목록은 길면 확장 경로 접두를 붙여 읽는다(watcher.longpath.os_path). 내는 dirpath는 늘 접두 없는 꼴이라 경로 키·화면에
    접두가 새지 않는다. os.walk는 260자를 넘는 폴더를 '경로를 찾을 수 없음'으로 건너뛰어 그 아래 도면이 기록에서 빠졌다 (pv2 D-1)."""
    stack = [top]
    while stack:
        cur = stack.pop()
        dirs: list = []
        nondirs: list = []
        try:
            with os.scandir(os_path(cur)) as it:
                for entry in it:
                    try:
                        is_dir = entry.is_dir()          # followlinks=True — 링크 폴더도 폴더로(순환은 호출부가 막는다)
                    except OSError:
                        is_dir = False
                    (dirs if is_dir else nondirs).append(entry.name)
        except OSError as e:
            try:
                e.filename = cur                         # 접두 없는 꼴로 알린다
            except (AttributeError, TypeError):
                pass
            onerror(e)
            continue
        yield cur, dirs, nondirs
        for d in reversed(dirs):
            stack.append(os.path.join(cur, d))


def _walk_files(root: Path, errors: list | None = None, activity=None):
    """루트 아래 파일을 결정적 순서로 낸다 — 링크(정션·DFS)는 따라가되 **순환·중복은
    막는다**.

    rglob은 정션을 따라가 `a/b/loop → a` 하나면 같은 파일이 64번 기록됐다(2026-09-02
    실측). 링크를 아예 건너뛰면 파일서버의 DFS 링크 아래 실제 폴더가 '삭제'로 보고된다
    (재검토에서 지적). 그래서 실제 경로(realpath)의 방문 집합으로 판단한다: 이미 지난
    실제 폴더를 다시 가리키는 링크만 건너뛰고 errors에 남긴다."""
    def _real(p: str) -> str:
        try:
            # 긴 경로는 접두를 붙여 묻고 떼어 견준다 — 방문 집합은 늘 접두 없는 꼴 (pv2 D-1)
            return os.path.normcase(plain(os.path.realpath(os_path(p))))
        except OSError:
            return os.path.normcase(p)

    _REPARSE = 0x400            # FILE_ATTRIBUTE_REPARSE_POINT

    def _is_link(p: str) -> bool:
        """심볼릭 링크·정션만이 아니라 **모든 재분석 지점**을 링크로 본다.

        `islink`/`isjunction`은 SYMLINK·MOUNT_POINT 태그만 참이라 DFS 링크
        (IO_REPARSE_TAG_DFS)에 거짓이었다. 예전에는 폴더마다 realpath를 불러 `visited`에
        실제 경로가 들어갔으므로 나중 정션을 걸렀는데, 이제 링크가 아닌 폴더는 겉보기 경로를
        넣으므로 못 걸러 같은 파일이 두 번 기록됐다 (2026-09-07 운영 검토 1)."""
        try:
            attrs = getattr(os.lstat(os_path(p)), "st_file_attributes", 0)
            if attrs:
                return bool(attrs & _REPARSE)
        except OSError:
            return False
        except ValueError:
            pass
        try:
            return os.path.islink(p) or os.path.isjunction(p)   # 윈도우가 아닌 곳
        except OSError:
            return False

    root_real = _real(str(root))
    visited = {root_real}                 # 실제 경로로 이미 들어간(들어갈) 폴더들
    # 폴더마다 realpath를 부르면 사내 파일서버(SMB)에서는 경로 깊이만큼 왕복이 생겨
    # 폴더 수만 개짜리 서버의 첫 검사가 몇 시간이 된다 (2026-09-07). 링크가 아닌 폴더의
    # 실제 경로는 '부모의 실제 경로 + 이름'과 같으므로 물어보지 않고 이어 붙인다.
    real_of = {str(root): root_real}

    def _dir_error(err: OSError) -> None:
        # os.walk는 폴더 목록을 못 읽으면 조용히 건너뛴다 — 권한 없는 폴더·순단이면
        # 그 아래 전부가 '삭제'로 나갔다 (2026-09-04 검토 core H3). 폴더 오류는
        # 끝에 '/'를 붙여 errors에 남기고, 호출부가 그 아래 이전 기록을 이월한다
        if errors is None:
            return
        bad = getattr(err, "filename", None) or str(root)
        try:
            rel = "/".join(os.path.relpath(bad, root).split("\\"))
        except ValueError:
            rel = "."
        rel = "" if rel in (".", "") else rel
        if too_long_error(err, bad):
            errors.append((rel + "/", LONG_PATH_NOTE))
        else:
            errors.append((rel + "/", f"폴더를 읽지 못함: {err.strerror or err}"))

    ndirs = 0
    for dirpath, dirnames, filenames in _walk(str(root), _dir_error):
        base_real = real_of.pop(dirpath, None) or _real(dirpath)
        ndirs += 1
        if activity is not None:
            # 산출물이 한 건도 없는 폴더가 수천 개여도 화면이 살아 있게, 그리고 이 사이에도
            # [검사 중지]가 듣게 한다 — 중지 확인이 진행 표시 안에 있다 (2026-09-07)
            activity(f"폴더 {ndirs:,}개째 훑는 중: {dirpath}")
        keep = []
        for d in sorted(dirnames):
            full = os.path.join(dirpath, d)
            if _is_link(full):
                real = _real(full)
                # 링크가 이미 지난 실제 폴더나 감시 트리 안쪽(직접 돌게 됨)을 가리키면
                # 건너뛴다 — 순환(a/b/loop→a)과 중복이 여기 해당. 바깥의 실제 폴더
                # (DFS 링크)는 따라간다
                inside = (real == root_real or real.startswith(root_real + os.sep)
                          or any(real == v or real.startswith(v + os.sep) for v in visited))
                if inside:
                    if errors is not None:
                        rel = "/".join(os.path.relpath(full, root).split("\\"))
                        errors.append((rel, "순환·중복 링크 폴더는 건너뜁니다 (같은 파일이 두 번 기록되지 않게)"))
                    continue
            else:
                real = os.path.normcase(os.path.join(base_real, d))
            visited.add(real)
            real_of[full] = real
            keep.append(d)
        dirnames[:] = keep
        # 못 들어간 폴더(권한 없음)는 os.walk가 dirpath로 오지 않아 pop되지 않는다 —
        # 수만 폴더에서 조금씩 쌓이므로 지금 걷어낸다 (2026-09-07 운영 검토 낮음)
        if len(real_of) > 4096:
            for k in [k for k in real_of if not k.startswith(dirpath)][:2048]:
                real_of.pop(k, None)
        for f in sorted(filenames):
            yield Path(dirpath) / f


def scan(root: Path, extensions: Iterable[str] = DEFAULT_EXTENSIONS,
         errors: list | None = None,
         excludes: Iterable[str] = (),
         prev: dict | None = None,
         progress=None, activity=None) -> list[FileRecord]:
    """루트 아래 모든 산출물 파일의 스냅샷. 경로 기준 정렬로 결과 재현 가능.

    읽지 못한 파일(잠김·권한)은 스캔을 중단시키지 않고 errors에 (경로, 사유)로
    수집된다 — 파일 1개 때문에 전체 감시가 죽으면 안 된다.
    excludes: 감시에서 뺄 루트 기준 상대 폴더 경로 목록.
    prev: 직전 스냅샷 {상대경로: (sha256, size, mtime)}. 크기·수정시각이 같으면
    파일을 다시 읽지 않고 저장된 해시를 재사용한다 — 수천 파일 서버에서 매일
    전체를 재해싱하면 시간 단위가 걸리므로. 저장이 일어나면 mtime이 반드시
    바뀌기 때문에 감지 정확도는 그대로다.
    """
    root = Path(root)
    records: list[FileRecord] = []
    exts = {e.lower() for e in extensions}
    for p in _walk_files(root, errors, activity=activity):
        # 이름만으로 거를 수 있는 것을 먼저 거른다 — 전에는 산출물이 아닌 파일까지 모두 is_file()(stat)을 불렀고,
        # 산출물은 is_file()·stat() 두 번이었다. 10만 파일 SMB에서 파일당 왕복 2회(검토20 r15-3) → 산출물만 stat 한 번.
        # (목록의 DirEntry 값은 쓰지 않는다 — NTFS 디렉터리 항목의 크기·시각은 하드 링크로 고친 파일·쓰는 중인 파일에서
        # 늦게 갱신돼, 그 값으로 '변동 없음'을 판정하면 변경을 놓칠 수 있다. 원칙 5)
        if not is_artifact(p, exts):
            # 이름 끝이 공백·점('x.pdf ')인 파일은 Windows 경로 정규화가 끝을 떼어 열 수 없다 — 오류 없이 조용히
            # 빠졌다 (고장 주입 2026-10-26 F3). 감시 확장자면 '읽지 못한 파일'로 알린다(읽기 전용 — 이름은 사람이 고친다)
            if errors is not None and p.name != p.name.rstrip(" .") and p.name.rstrip(" .") \
                    and is_artifact(p.with_name(p.name.rstrip(" .")), exts):
                errors.append((p.relative_to(root).as_posix() if p.is_relative_to(root) else str(p),
                               "파일 이름 끝이 공백이나 점이라 Windows에서 열 수 없어 건너뜁니다 — 이름 끝의 공백·점을 지워 주세요"))
            continue
        # 공유 폴더가 검사 도중 끊기면 stat이 WinError 64를 올린다 — 잡지 않으면 브리핑도 배너도 없이 그날 검사가
        # 통째로 죽고, 멀쩡한 다른 감시 폴더의 변경까지 보고되지 않았다 (검토34 C M8). 못 읽은 파일로 넘기면 다음 검사가
        # 이월 처리한다. 나열 뒤 사라진 파일(없음)은 전처럼 조용히 빠진다(Path.is_file이 삼키던 오류)
        try:
            st = os_path(p).stat()
        except OSError as e:
            if errors is not None and (not _ignorable_stat_error(e) or _long_unreadable(e, p)):
                # 260자 넘는 경로의 '없음'은 나열 뒤 지워진 것이 아니라 길이 탓이다 — 조용히 빼면 도면이 기록에서 빠지고 다음 날
                # '삭제'로 보고됐다 (pv2 D-1). 접두로도 못 읽으면 '경로가 너무 길어 읽지 못함'으로 남겨 이전 기록을 이월한다
                errors.append((p.relative_to(root).as_posix() if p.is_relative_to(root) else str(p), _err_text(e, p)))
            continue
        if not stat.S_ISREG(st.st_mode):
            continue
        rel = p.relative_to(root).as_posix()
        if any(0xD800 <= ord(ch) <= 0xDFFF for ch in rel):
            # 깨진 UTF-16 이름(맥·리눅스 공유 클라이언트가 남김) 하나가 이력 저장에서 UnicodeEncodeError로 그날 검사 전체를
            # 죽였다 (검토64 D1) — 그 파일만 '이름을 읽을 수 없음'으로 알리고 건너뛴다
            if errors is not None:
                errors.append((rel.encode("utf-8", "backslashreplace").decode("utf-8"),
                               "파일 이름에 읽을 수 없는 글자가 있어 건너뜀 — 파일 이름을 다시 지어 주세요"))
            continue
        if is_excluded(rel, excludes):
            continue
        try:
            pv = prev.get(rel) if prev else None
            if pv is not None and pv[1] == st.st_size and pv[2] == st.st_mtime:
                sha = pv[0]  # 변동 없음 → 재해싱 생략
            elif getattr(st, "st_file_attributes", 0) & CLOUD_PLACEHOLDER_ATTRS:
                # OneDrive·SharePoint 'Files On-Demand' 자리표시자 — 읽으면 그 자리에서 내려받는다(디스크·회선). 감시는 읽기
                # 전용·부작용 없음이 원칙이라 내용을 읽지 않고 '읽지 못한 파일'로 이월한다 (검토20 r15-6)
                if errors is not None:
                    errors.append((rel, CLOUD_PLACEHOLDER_NOTE))
                continue
            else:
                if activity is not None:
                    activity(rel)          # 큰 파일 하나에서 오래 걸리면 그 이름이 화면에 뜬다
                sha = sha256_of(p)
                # 해싱하는 사이 파일이 커지거나 다시 저장되면 기록할 크기·시각(해싱 전)과 지문(도중 내용)이 서로 다른
                # 순간의 것이 된다 — 반쪽 파일이 '이전 판'으로 남았다(검토20 r15-5). 다시 보고 바뀌었으면 쓰는 중으로 이월
                st2 = os_path(p).stat()
                if st2.st_size != st.st_size or st2.st_mtime != st.st_mtime:
                    if errors is not None:
                        errors.append((rel, WRITING_NOTE))
                    continue
        except OSError as e:
            if errors is not None:
                errors.append((rel, _err_text(e, p)))
            continue
        records.append(FileRecord(path=rel, sha256=sha, size=st.st_size,
                                  mtime=st.st_mtime))
        if progress is not None:
            progress(len(records))  # 대용량 서버 첫 해싱이 '멈춘 것'처럼 보이지 않게
    return records
