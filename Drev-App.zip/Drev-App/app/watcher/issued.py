# -*- coding: utf-8 -*-
"""출도(발행) 폴더 · 출도 후 변경 · 발주 후 변경 (기능 검토 2026-11-02 J2·J8).

구매 결정 장면 — 외주처가 옛 판을 들고 있다, 이미 발주한 사양이 바뀌었다 — 이 지금 기능에 비어 있었다(DECISIONS 2026-11-02).
원칙 6 안: 의미(옳다/그르다)는 판단하지 않고 사실만 잇는다.
  · 출도 폴더에 들어온 판을 그 도면번호의 '출도본'으로 기록하고, 그 뒤 원본이 바뀌었는데 더 새 출도본이 없으면 '출도 후 변경'.
  · 발주서 행의 태그·품번을 기록하고, 발주 뒤 도면·BOM에서 그 태그·품번의 값이 바뀌면 그 변경에 '발주 후 변경' 표지.
감시는 읽기 전용 — 이 모듈은 state.db에만 쓴다. 금액 칸은 담지도 견주지도 않는다(DECISIONS 2026-10-19).
출도 폴더는 사용자가 정한다(설정 issued_folders). 폴더 이름 추정(suggest_issued_folders)은 화면의 제안일 뿐이다.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime, timezone
from pathlib import PurePosixPath

from watcher.rowkey import split_row_cell

ISSUED_NAME_RE = re.compile(r"출도|발행|발송|배포|송부|issued?(?![a-z])|(?<![a-z])ifc(?![a-z])|for[\s_-]*construction",
                            re.IGNORECASE)
# 출도 낱말이 있어도 출도본 폴더가 아닌 것 — '발행 전 검토'·'고객 발송 사진'·'배포자료'·'출도 예정'·'출도대기' (제안에서만 뺀다,
# 사용자가 직접 정한 폴더는 그대로) (재검토 rr066 judge 9)
_NOT_ISSUED_TAIL = re.compile(r"전\s*검토|사진|자료|예정|대기|준비")
POST_ISSUE_CODE = "POST_ISSUE_CHANGE"
PO_MARK_KEY = "발주 후 변경"
# 머리글 정규식은 head_key로 접은 글에 쓴다 — '품 명'·'금 액'처럼 띄어 쓴 머리글이 발주서로 안 잡히거나 규격을 잃었다 (ux24 PO3)
# 금액 칸 — 담지도 견주지도 않는다 (DECISIONS 2026-10-19). '제조원'·'공급원'은 돈이 아니라 회사 (ux24 PO4)
# '원'은 돈 표시로 쓰인 낱말만 — 머리글 전체이거나 괄호·구분 뒤('(원)'·'단가(원)'·'단위:원')에, 앞말은 금액 자릿수(천·백만·억 등)만.
# 뒷말 금지 목록으로는 전원·광원·열원·동력원·차원이 돈 칸이 되어 사양 변경의 표지가 사라졌다 (ux26 PO2). head_key는 괄호를 접지 않는다
# VAT·TOTAL은 낱말일 때만 — ELEVATION·ELEVATOR·TOTAL LENGTH는 돈이 아니라 사양 (ux26 머리글)
# 'OO가' 값 이름은 앞말을 적는다 — '[가-힣]*가$'로는 평가·추가·사양 추가·부가(기능)가 돈 칸이 된다. 뒤에 한글이 이어지면(판매가능수량) 돈이 아니다 (rv0676 JG1)
# 새 돈 낱말(할인·환율·정가·누계)은 앞뒤 한글 경계로 막으면 현금할인·적용환율·소비자정가·총누계·누계액 같은 돈 칸이 사양 칸이 됐다
# (rv0676 re2). 그래서 낱말은 넓게 두고 사양 쪽 낱말만 적어 뺀다: 분할인도·분할인수·할인대상, 순환율·교환율·변환율·전환율·치환율,
# 정가동(률)·조정가·수정가·설정가·측정가(능). 누계는 합계처럼 무엇의 누계인지(운전·시간·가동·횟수) 적혀 있으면 돈이 아니다(_MEASURE_WORD)
# HEAT/ION EXCHANGE RATE·DISCOUNTINUED는 사양 (rv0676 RJ1)
_PRICE_WORD = (r"(?:견적|매입|납품|판매|구매|입찰|계약|낙찰|소비자|도매|소매|매출|기준|제안|권장)가(?:액|격)?(?![가-힣])|"
               r"(?<![가-힣])(?:소비자|판매|권장|기준)?정가(?:액|격|표)?(?![가-힣])")
# 정가·환율·누계는 사양 쪽 예외 목록으로 두니 고정가변·정가속도·반환율·귀환율·누계 유량·누계 생산량이 돈 칸이 되어 표지가 숨었다
# (rv0676 re3). 이 셋은 앞뒤 한글 경계로 되돌리고, 확실한 돈 꼴(소비자정가·적용환율·총누계·누계액)만 경계 안 앞말·뒷말로 적는다
_MONEY_WORD = (r"금액|단가|가격|공급가|원가|부가세|세액|총액|(?<![분역])할인(?!대상)|"
               r"(?<![가-힣])(?:적용|기준|고시|매입|매도|송금|결제|대고객)?환율|(?<![A-Z])VAT(?![A-Z])|AMOUNT|PRICE|COST|"
               r"DISCOUNT(?!INU)|(?<![A-Z])EXCHANGERATE|(?<![A-Z])FXRATE|"
               + _PRICE_WORD + r"|(?:^|[(（\[［:：/]|단위)(?:[십백천]?[만억]|[십백천])?원[)）\]］]?$")
_SUM_WORD = r"합계|소계|총계|(?<![가-힣])총?누계(?:금?액)?(?![가-힣A-Z])|TOTAL(?![A-Z])"   # 누계 SHOT·누계 CYCLE은 사양 (re3)      # 무엇의 합인지 안 적혔을 때만 돈 — money_head
_AMOUNT_HEAD = re.compile(_MONEY_WORD + "|" + _SUM_WORD, re.IGNORECASE)     # 돈 낱말이 든 머리글(합계 포함). 판정은 money_head로
_MONEY_ONLY = re.compile(_MONEY_WORD, re.IGNORECASE)
_QTY_WORD = r"수량|QTY|Q'TY|QUANTITY"                    # 어디에 들어도 수량 칸 — 수량(EA)·발주수량·QTY(EA)
_UNIT_WORD = re.compile(r"단위|UNIT|UOM", re.IGNORECASE)  # 머리글 전체일 때만 — UNIT TYPE·DRIVE UNIT·단위중량·UNIT WEIGHT는 규격 칸 (ux26 PO4)
_QTY_HEAD = re.compile(_QTY_WORD + "|" + _UNIT_WORD.pattern, re.IGNORECASE)    # fullmatch로 쓴다 — 규격 자리에 싣지 않는 칸 (ux24 PO7)
# 합계가 무엇의 합인지 말하는 낱말 — 합계수량·수량합계·중량합계·합계(EA)는 돈이 아니다 (rv0676 JG2)
_MEASURE_WORD = re.compile(_QTY_WORD + r"|중량|무게|길이|면적|부피|체적|WEIGHT|LENGTH|[(（](?:EA|KG|TON|SETS?|PCS?)[)）]|"
                           r"운전|시간|가동|횟수|기동|HOURS?|TIME", re.IGNORECASE)     # 누계 운전시간·운전누계·누계시간 (rv0676 RJ1)


def money_head(hk: str) -> bool:
    """접은 머리글(head_key)이 돈 칸인가 — 담지도 견주지도 않는다 (DECISIONS 2026-10-19). '합계'·'소계'·'TOTAL'은 수량·중량 낱말이
    함께 있으면 돈이 아니다: '합계수량'이 돈 규칙에 먼저 걸려 수량 변경 표지가 빠졌다 (rv0676 JG2). '합계금액'·'합계'는 돈."""
    hk = str(hk or "")
    if _MONEY_ONLY.search(hk):
        return True
    return bool(re.search(_SUM_WORD, hk, re.IGNORECASE)) and not _MEASURE_WORD.search(hk)


def qty_head(hk: str) -> bool:
    """접은 머리글이 수량 칸인가(단위 칸은 빼고) — 수량(EA)·QTY(EA)·수 량·발주수량·합계수량·EA. 발주 표지(po_mark_changes)와
    메일 '발주 영향' 합계(brief.bom_impact)가 함께 쓴다 — 둘의 규칙이 달라 '수량(EA)'를 메일에서만 못 셌다 (rv0676 JG4)."""
    hk = str(hk or "")
    return bool(re.search(_QTY_WORD, hk, re.IGNORECASE) or re.fullmatch(r"EA", hk, re.IGNORECASE))


# 돈도 사양도 아닌 사람 칸 — 바뀌어도 발주 표지를 내지 않는다 (ux25 e2-3). 표지를 숨기는 쪽의 실수가 더 위험해 사람을 뜻하는 말만 적는다:
# 'BY'는 앞말을 적어 막고(STANDBY·DRIVEN BY는 사양), 끝에 서명·성명 꼬리만 허용한다 — 설계압력·확인압력·승인도번호·검사압력은 사양 (ux26 PO3)
# 결재란 낱말(승인·결재·제도·서명·성명)은 머리글 전체일 때만 — 형식승인·승인도번호는 사양. 검토·작성·설계·검사 홑낱말은 칸 이름이 사양일 수 있어
# 넣지 않고 '-자'만. 영어 결재란(CHECKED·APPROVED·DRAWN…)은 BY 없이도, 앞에 영문자가 붙지 않을 때만(COLD DRAWN·DATE APPROVED는 아님).
# 날짜 칸(승인일·결재일·APPROVED DATE)은 사람 칸이 아니다 — 납기처럼 표지를 그대로 둔다 (rv0676 JG3)
_PERSON_EN = r"CHECKED|CHK'?D|APPROVED|APP'?D|DRAWN|DESIGNED|REVIEWED|PREPARED|INSPECTED"
_PERSON_HEAD = re.compile(r"(?:(?:검사|담당|작업|구매|검수)원|"
                          r"(?:검사|담당|작업|확인|승인|검토|작성|설계|제도|결재|기안|요청|검수|입회|구매|발주)자|담당|"
                          r"^(?:승인|결재|제도|서명|성명)|INSPECTOR|"
                          r"(?:(?<![A-Z])|(?<=PROJECT)|(?<=SITE)|(?<=LEAD))(?:ENGINEER|BUYER|DESIGNER|DRAFTER|DRAFTSMAN|CHECKER|APPROVER|REVIEWER|REQUESTER|PURCHASER)|"
                          r"(?:" + _PERSON_EN + r"|ORDERED|REQUESTED|REQ)BY|(?<![A-Z])(?:" + _PERSON_EN + r"))"
                          r"(?:[(（]?(?:서명|성명|이름|SIGN|SIGNATURE|NAME)[)）]?)?$", re.IGNORECASE)
_PART_HEAD = re.compile(r"품번|품목\s*코드|자재\s*코드|부품\s*번호|PART\s*(?:NO|NUMBER|#)|P/?N$|ITEM\s*(?:NO|CODE)|CODE\s*NO",
                        re.IGNORECASE)
_SPEC_HEAD = re.compile(r"규격|사양|SPEC|MODEL|모델|형식|정격|용량|RATING", re.IGNORECASE)
_NAME_HEAD = re.compile(r"품명|DESCRIPTION|명칭", re.IGNORECASE)          # 사양 칸이 없을 때만 보이는 이름
_DATE_RE = re.compile(r"(20\d{2})[-./년\s]+(\d{1,2})[-./월\s]+(\d{1,2})")


def _fold(s) -> str:
    return unicodedata.normalize("NFKC", str(s or "")).strip().casefold()


def issued_folders(cfg: dict | None) -> list[str]:
    """설정의 출도 폴더 목록 — 폴더 이름('출도') 또는 감시 폴더 기준 경로('P26-001/출도'). 옛 설치본에는 키가 없다(빈 목록)."""
    v = (cfg or {}).get("issued_folders")
    if isinstance(v, (str, bytes)):
        v = [v]
    if not isinstance(v, (list, tuple)):
        return []
    out = []
    for e in v:
        s = "/".join(_fold(e).split("\\")).strip("/ ")      # 읽기 전용 검사가 .replace 이름을 막는다 (test_readonly)
        if s and s not in out:
            out.append(s)
    return out


def in_issued_folder(path: str, cfg: dict | None) -> str | None:
    """이 경로가 출도 폴더 안이면 맞은 항목, 아니면 None. 이름 항목은 경로의 **폴더** 한 마디와 같아야 하고, 경로 항목은 그 마디들이
    이어서 나와야 한다(감시 폴더 라벨은 있어도 없어도)."""
    entries = issued_folders(cfg)
    if not entries:
        return None
    parts = [_fold(p) for p in PurePosixPath(str(path or "")).parent.parts]
    if not parts:
        return None
    for e in entries:
        ep = [x for x in e.split("/") if x]
        if not ep:
            continue
        n = len(ep)
        if any(parts[k:k + n] == ep for k in range(0, len(parts) - n + 1)):
            return e
    return None


def suggest_issued_folders(paths, cfg: dict | None = None, limit: int = 12) -> list[tuple[str, int]]:
    """감시 중인 파일 경로에서 출도·발행·Issued·IFC 같은 이름의 폴더를 찾아 (폴더 이름, 파일 수) — 제안만 한다(확정은 사용자)."""
    have = set(issued_folders(cfg))
    cnt: dict = {}
    shown: dict = {}
    for p in paths or ():
        seen = set()
        for part in PurePosixPath(str(p)).parent.parts[1:]:       # 감시 폴더 라벨은 빼고
            if ISSUED_NAME_RE.search(part) and not _NOT_ISSUED_TAIL.search(part):
                k = _fold(part)
                if k in have or k in seen:
                    continue
                seen.add(k)
                cnt[k] = cnt.get(k, 0) + 1
                shown.setdefault(k, part)
    return sorted(((shown[k], n) for k, n in cnt.items()), key=lambda t: (-t[1], t[0]))[:limit]


def doc_key(path: str, doc) -> str | None:
    """출도본과 원본을 잇는 도면번호 — 표제란 도면번호가 있으면 그것, 없으면 판 짝짓기와 같은 이름 줄기(Rev·날짜 꼬리 뺌)."""
    f = (getattr(doc, "fields", None) or {}).get("DWG_NO") if doc is not None else None
    v = getattr(f, "value", None) if f is not None else None
    if v and str(v).strip():
        return re.sub(r"\s+", "", _fold(v))
    from watcher.scan import pair_key
    k = pair_key(PurePosixPath(str(path)).name)
    return k or None


def _date_of(ts) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%m-%d")
    except (TypeError, ValueError, OSError, OverflowError):
        return "날짜 모름"


# ── 출도본 기록 · 출도 후 변경 ─────────────────────────────────────────────────────────────────

def record_issued(state, rd, project_of=None) -> int:
    """출도 폴더 안 파일의 처음 보는 판을 출도본으로 기록한다(귀속 함께 — 같은 프로젝트의 원본만 잇는다). 기록한 수."""
    cfg = getattr(rd, "cfg", None) or {}
    if not issued_folders(cfg):
        return 0
    have = {(p, s) for p, s in state.conn.execute("SELECT path, sha256 FROM issued_copies")}
    now = datetime.now(timezone.utc).isoformat()
    n = 0
    for r in rd.records or ():
        if (r.path, r.sha256) in have or not in_issued_folder(r.path, cfg):
            continue
        try:
            doc = rd.docs.get(r.path)
        except Exception:
            doc = None
        key = doc_key(r.path, doc)
        if not key:
            continue
        rev = getattr(doc, "revision", None) if doc is not None else None
        proj = _project(project_of, r.path, doc)
        state.conn.execute(
            "INSERT OR IGNORE INTO issued_copies (key, path, sha256, rev, saved, snapshot_id, at, project) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (key, r.path, r.sha256, rev, r.mtime, rd.snapshot_id, now, proj))
        n += 1
    if n:
        state.conn.commit()
    return n


def _project(project_of, path, doc):
    if project_of is None:
        return None
    try:
        return project_of(path, doc) or None
    except Exception:
        return None


def _same_scope(ipath: str, iproj, path: str, proj) -> bool:
    """출도본과 원본이 같은 프로젝트인가 — 둘 다 귀속이 있으면 귀속으로, 하나라도 없으면(옛 행·미분류) 같은 감시 폴더의 첫
    마디(경로 앞 두 마디)로. 키가 도면번호뿐이라 P26-091/작업/E-101 편집이 P26-090/출도/E-101을 근거로 카드가 됐다
    (재검토 rr066 judge 2)."""
    if iproj and proj:
        return _fold(iproj) == _fold(proj)
    return PurePosixPath(str(ipath)).parts[:2] == PurePosixPath(str(path)).parts[:2]


def _latest_issued(state) -> dict:
    """도면번호 → 출도본 목록 [(snapshot_id, path, sha, rev, saved, id, project)], 나중 것이 앞."""
    out: dict = {}
    for key, path, sha, rev, saved, snap, iid, proj in state.conn.execute(
            "SELECT key, path, sha256, rev, saved, snapshot_id, id, project FROM issued_copies"):
        out.setdefault(key, []).append((snap or 0, path, sha, rev, saved, iid, proj))
    for v in out.values():
        v.sort(key=lambda e: (e[0], e[5]), reverse=True)
    return out


def _pick_issued(latest: dict, key, path: str, proj) -> tuple | None:
    """그 원본과 같은 프로젝트의 가장 나중 출도본."""
    for e in (latest.get(key) or ()) if key else ():
        if _same_scope(e[1], e[6], path, proj):
            return e
    return None


def _rev_lower(a, b) -> bool:
    """출도본 Rev a가 원본 Rev b보다 낮은가 — 같은 모양끼리만 견준다(모르면 낮다고 하지 않는다)."""
    from watcher.scan import rev_key, rev_shape
    a, b = str(a or "").strip(), str(b or "").strip()
    if not a or not b:
        return False
    sa, sb = rev_shape(a), rev_shape(b)
    try:
        return sa is not None and sa == sb and rev_key(a) < rev_key(b)
    except TypeError:
        return False


def resolve_reissued(state, rd, latest: dict | None = None) -> int:
    """열린 '출도 후 변경' 가운데 그 뒤 같은 프로젝트의 새 출도본이 들어온 것을 닫는다 — 새 출도가 곧 해소다. 그 출도본의 Rev가
    원본 지금 Rev보다 낮으면(옛 판을 늦게 플롯해 넣음) 해소가 아니다. 닫은 수."""
    latest = _latest_issued(state) if latest is None else latest
    if not latest:
        return 0
    now = datetime.now(timezone.utc).isoformat()
    n = 0
    for iid, path, snap, proj in state.conn.execute(
            "SELECT id, path, snapshot_id, project FROM issues WHERE code = ? AND resolved_at IS NULL",
            (POST_ISSUE_CODE,)).fetchall():
        try:
            doc = rd.docs.get(path)
        except Exception:
            doc = None
        key = doc_key(path, doc)
        cur = _pick_issued(latest, key, path, proj)
        if cur is None or (cur[0] or 0) <= (snap or 0):
            continue
        if doc is not None and _rev_lower(cur[3], getattr(doc, "revision", None)):
            continue
        why = f"자동 해소 — 새 출도본이 들어옴 ({PurePosixPath(cur[1]).name}" + (f", Rev {cur[3]}" if cur[3] else "") + ")"
        state.conn.execute("UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?", (now, why, iid))
        n += 1
    if n:
        state.conn.commit()
    return n


def _issued_doc(state, sha, path):
    try:
        d = state.load_extract(sha, path)
        if not d or d.get("extract_failed") or d.get("fields") is None:
            return None
        from watcher.extract.base import Document
        return Document.from_dict(d)
    except Exception:
        return None


def _norm_v(s) -> str:
    return re.sub(r"\s+", " ", _fold(s)).strip()


def _issued_value(idoc, cur_doc, it) -> tuple[str | None, str]:
    """변경 항목 it의 같은 자리 값을 출도본에서 — (출도본 값 또는 None, 이름표). 같은 칸(표제란 칸·표 행 열)이면 그 값, 태그가
    있으면 출도본에서 그 태그 조각. 못 찾으면 None — 원본 직전 값을 출도본 값이라 적지 않는다 (재검토 rr066 judge 3, 원칙 4)."""
    if idoc is None:
        return None, ""
    kind, key = str(getattr(it, "kind", "") or ""), str(getattr(it, "key", "") or "")
    try:
        if kind.startswith("FIELD_"):
            f = (idoc.fields or {}).get(key)
            return (str(f.value) if f is not None and f.value is not None else None), key
        if kind.startswith("ROW_"):
            rk, sep, col = split_row_cell(key)
            if sep:
                for row in idoc.rows or ():
                    if str(row.key) == rk and col in (row.values or {}):
                        v = row.values.get(col)
                        return (str(v) if v is not None else None), f"{rk} {col}"
            return None, ""
        from watcher.consistency import _tag_segment, tag_lines_with_specs
        from watcher.extract.base import find_tags
        old, new = str(it.old or ""), str(it.new or "")
        # 글자 자체에 든 태그만 '그 태그 조각'으로 견준다. 이름표(label)·이웃 줄로 짐작한 태그는 그 줄의 태그가 아니다 — 태그 없는
        # 'CABLE: CV 4SQ→6SQ'가 가까운 INV-11에 묶여 'INV-11 출도본 INVERTER 5.5kW → 원본 지금 CABLE: CV 6SQ x 4C'로 짝이 틀렸다
        # (ux21 daily 2)
        tags = list(dict.fromkeys(find_tags(f"{old} {new}".upper())))
        near = not tags
        if near:
            tags = list(dict.fromkeys(find_tags(str(getattr(it, "label", "") or "").upper())))
        if not tags and cur_doc is not None and new.strip():
            tags = [t for t, lines in tag_lines_with_specs(cur_doc).items()
                    if any(new.strip() in str(getattr(ln, "text", "") or "") for ln in lines)]
        tag = tags[0] if len(tags) == 1 else ""
        if tag and not near:
            for ln in tag_lines_with_specs(idoc).get(tag) or ():
                seg = _tag_segment(tag, str(getattr(ln, "text", "") or "")).strip(" :：-")
                if seg:
                    return seg, tag
        # 같은 형식의 출도본(DXF 원본을 그대로 복사해 둔 출도본 등)이면 출도본 → 원본 지금 판을 견주어 같은 자리의 값을 읽는다 —
        # 사양 글자가 태그와 따로 놓인 도면은 태그 줄에 값이 없다
        if cur_doc is not None and getattr(idoc, "doc_type", None) == getattr(cur_doc, "doc_type", None):
            from watcher.diff import content_items, diff_documents
            same = [x for x in content_items(diff_documents(idoc, cur_doc))
                    if str(getattr(x, "key", "")) == key and str(getattr(x, "where", "")) == str(getattr(it, "where", ""))]
            shown = "" if near else tag     # 짐작한 태그를 값 앞에 적지 않는다 — 'TR-11: 출도본 CABLE: CV 4SQ x 4C → …'로 읽혔다 (ux23 a 3)
            if len(same) == 1 and str(same[0].new or "") == new:
                return str(same[0].old or ""), shown
            if not same and any(new.strip() and new.strip() in str(getattr(ln, "text", "") or "")
                                for ln in (idoc.raw_texts or ())):
                return new, shown           # 출도본에도 지금 값 그대로 있다 — 출도본과 어긋난 값이 아니다
        if near:
            got = _near_value(idoc, tag, old, new, guessed=bool(tags))
            if got is not None:
                return got
            return None, ""
        return None, tag
    except Exception:
        return None, ""


def _head(s: str) -> str:
    """글줄의 머리 — 숫자 든 낱말 앞까지('CABLE: CV 6SQ x 4C' → 'CABLE: CV', 'MOTOR 7.5kW' → 'MOTOR'). 접어서 견준다."""
    out = []
    for w in _norm_v(s).split(" "):
        if re.search(r"\d", w):
            break
        out.append(w)
    return " ".join(out).strip(" :：-")


def _near_value(idoc, tag: str, old: str, new: str, guessed: bool = False):
    """태그 없는 글자 변경의 출도본 값 — 짐작한 태그(이웃 줄)의 줄이나 출도본 전체 글줄에서 **같은 줄**을 찾는다: 원본 직전 값과
    똑같은 줄, 아니면 머리('CABLE: CV')가 같은 줄이 하나뿐일 때. 못 찾으면 None — 다른 줄 값을 출도본 값이라 적지 않는다 (원칙 4).
    태그를 짐작했으면(guessed — 하나로 못 고른 경우 포함) 머리 맞춤은 그 태그 줄 안에서만, 전체 글줄은 정확 일치만: INV-11 케이블 변경에
    INV-12의 'CABLE: CV 10SQ x 4C'를 출도본 값으로 냈다 (ux22 judge 2)."""
    from watcher.consistency import _tag_segment, tag_lines_with_specs
    fo, head = _norm_v(old), _head(new or old)
    pools = []
    if tag:
        pools.append([(ln, _tag_segment(tag, str(getattr(ln, "text", "") or "")).strip(" :：-"))
                      for ln in tag_lines_with_specs(idoc).get(tag) or ()])
    pools.append([(ln, str(getattr(ln, "text", "") or "").strip()) for ln in (idoc.raw_texts or ())])
    for k, pool in enumerate(pools):
        segs = [(ln, s) for ln, s in pool if s]
        in_tag = bool(tag) and k == 0      # 짐작한 태그의 줄 안에서는 머리 없는 값 줄('100AF 100AT 3P')끼리도 견준다

        def _name(lns):     # 출도본 줄에 그 태그가 함께 적혀 있을 때만 이름표로 — 이웃 태그를 이름처럼 달지 않는다
            return tag if tag and any(tag in str(getattr(ln, "text", "") or "").upper() for ln in lns) else ""
        exact = [(ln, s) for ln, s in segs if fo and _norm_v(s) == fo]
        if exact:
            return exact[0][1], _name([ln for ln, _s in exact])
        if (guessed or tag) and not in_tag:
            continue
        # 머리가 숫자로 시작하는 줄('100AF 125AT 3P')은 머리로 가리지 않는다 — 머리가 비어 아무 줄이나 맞는다
        if in_tag or (len(head) >= 2 and re.search(r"[A-Za-z가-힣]", head)):
            same = [(ln, s) for ln, s in segs if _head(s) == head]
            if len({_norm_v(s) for _ln, s in same}) == 1:
                return same[0][1], _name([ln for ln, _s in same])
    return None


def _issued_gap(state, isha, ipath, doc, path, carry=True) -> str | None:
    """출도본과 원본 지금 판의 어긋난 값 한 마디('100→125AT' 외 N건) — 이번 검사에 글자·표 변경이 없을 때 머리글용.
    같은 형식이면 둘을 바로 견주고, 아니면 열린 '출도 후 변경'의 머리 값을 이어 쓴다(carry — 재저장 날만. 값이 모두 출도본으로 돌아온 날
    어제 머리를 이어 쓰면 머리는 '5.5→7.5kW'인데 근거는 '출도본과 같음'이었다, ux23 vz-check 3). 모르면 None."""
    from watcher.brief import short_pair
    try:
        idoc = _issued_doc(state, isha, ipath)
        if idoc is not None and doc is not None and getattr(idoc, "doc_type", None) == getattr(doc, "doc_type", None):
            from watcher.diff import content_items, diff_documents
            items = content_items(diff_documents(idoc, doc))
            if items:
                return short_pair(items[0].old, items[0].new, 30) + (f" 외 {len(items) - 1}건" if len(items) > 1 else "")
            return None
        if not carry:
            return None
        row = state.conn.execute("SELECT message FROM issues WHERE code = ? AND path = ? AND resolved_at IS NULL "
                                 "ORDER BY id DESC LIMIT 1", (POST_ISSUE_CODE, path)).fetchone()
        m = re.search(r"원본에서 바뀐 값\(([^()]*)\)", (row[0] if row else "") or "")
        prev = m.group(1).split(" — 이번 검사는 다시 저장만")[0].strip() if m else ""
        return prev if prev and prev not in ("글자·표 변경 없음", SAME_AS_ISSUED) else None
    except Exception:
        return None


_SQUARE = str.maketrans("()", "[]")
SAME_AS_ISSUED = "출도본과 같음"


def post_issue_issues(state, rd, project_of=None) -> list:
    """출도 뒤 원본이 바뀌었는데 더 새 출도본이 없는 파일의 검토 필요. 근거: 출도본(이름·Rev·날짜·경로), 원본에서 바뀐 값
    (출도본 값 → 원본 지금 값, 위치 — 출도본에서 못 찾은 값은 그렇다고 적고 원본 직전 값 → 지금 값). 같은 검사에 새 출도본이 들어온
    도면은 그것이 새 출도다 — 단 그 출도본 Rev가 원본 지금 Rev보다 낮으면 새 출도가 아니다(옛 판을 늦게 넣음)."""
    cfg = getattr(rd, "cfg", None) or {}
    if not issued_folders(cfg) or getattr(rd, "is_baseline", False):
        return []
    latest = _latest_issued(state)
    resolve_reissued(state, rd, latest)
    if not latest:
        return []
    from watcher.brief import short_pair
    from watcher.consistency import Issue, _fmt_item
    from watcher.diff import content_items
    open_rows = state.conn.execute(
        "SELECT id, path, message FROM issues WHERE code = ? AND resolved_at IS NULL", (POST_ISSUE_CODE,)).fetchall()
    open_paths = {p for _id, p, _m in open_rows}
    for iid, _p, msg in open_rows:     # 옛 판이 남긴 머리 값의 괄호도 []로 — 새 문구와 같은 대조 키가 되어 같은 건으로 이어진다 (ux22 judge 3)
        m = re.fullmatch(r"(.*원본에서 바뀐 값\()(.*)(\)이 새 출도본에 없습니다\.)", msg or "", re.S)
        if m and re.search(r"[()]", m.group(2)):
            state.conn.execute("UPDATE issues SET message = ? WHERE id = ?",
                               (m.group(1) + m.group(2).translate(_SQUARE) + m.group(3), iid))
    out = []
    for c in rd.changes or ():
        if c.kind != "modified" or in_issued_folder(c.path, cfg):
            continue
        try:
            doc = rd.docs.get(c.path)
        except Exception:
            doc = None
        key = doc_key(c.path, doc)
        if not key or key not in latest:
            continue
        iss = _pick_issued(latest, key, c.path, _project(project_of, c.path, doc))
        if iss is None or iss[2] == c.new_sha256:
            continue
        if (iss[0] or 0) >= (rd.snapshot_id or 0) and not _rev_lower(iss[3], getattr(doc, "revision", None)):
            continue                     # 같은 검사에 들어온 새 출도본 — 그것이 새 출도다
        content = content_items((rd.details or {}).get(c.path) or [])
        if not content and c.path not in open_paths:
            continue
        _snap, ipath, isha, rev, saved, _iid, _ip = iss
        date = _date_of(saved)
        idoc = _issued_doc(state, isha, ipath) if content else None
        lines, same_lines, pairs, unknown = [], [], [], []
        for i in content:
            iv, name = _issued_value(idoc, doc, i)
            if iv is not None:
                nv = str(i.new or "")
                if name and name in nv.upper():          # 태그 줄이면 그 태그 조각만 — 'M-101 7.5kW 4P' → '7.5kW 4P'
                    from watcher.consistency import _tag_segment
                    nv = _tag_segment(name, nv).strip(" :：-") or nv
                pairs.append((iv, nv, name))
                where = getattr(i, "where", "") or ""
                if _norm_v(iv) == _norm_v(nv):           # 출도본과 같아진 값 — '바뀐 값'처럼 적지 않고 어긋난 줄 뒤로 (ux23 a 5)
                    same_lines.append(f"{name + ': ' if name else ''}{nv or '—'} — {SAME_AS_ISSUED} ({where})")
                else:
                    lines.append(f"{name + ': ' if name else ''}출도본 {iv or '—'} → 원본 지금 {nv or '—'} ({where})")
            else:
                unknown.append(i)
                lines.append("출도본 값 확인 불가 — 원본 직전 값 → 지금 값: " + _fmt_item(i))
        lines += same_lines
        if content and len(pairs) == len(content) and all(_norm_v(a) == _norm_v(b) for a, b, _n in pairs) \
                and c.path not in open_paths:
            continue                     # 바뀐 값이 모두 출도본과 같아졌다 — 출도본과 어긋난 것이 없다
        if content:
            # 머리 한 줄은 출도본과 **다른** 값으로 — 같아진 값은 앞세우지도 수에 세지도 않는다. 출도본 값을 모르는 줄은 어긋났을 수 있어 센다 (ux23 a 5)
            diffs = [p for p in pairs if _norm_v(p[0]) != _norm_v(p[1])]
            gaps = len(diffs) + len(unknown)
            if gaps:
                first = diffs[0] if diffs else (unknown[0].old, unknown[0].new, "")
                summary = short_pair(first[0], first[1], 30) + (f" 외 {gaps - 1}건" if gaps > 1 else "")
            else:       # 이미 열려 있던 건의 바뀐 값이 모두 출도본과 같아진 날 — 다른 곳이 어긋나 있으면 그 값으로
                summary = _issued_gap(state, isha, ipath, doc, c.path, carry=False) or SAME_AS_ISSUED
        else:
            # 이번 검사는 내용 없는 재저장 — 머리는 출도본과 지금 다른 값으로 남긴다. '바뀐 값(글자·표 변경 없음)이 새 출도본에
            # 없습니다'는 무엇이 어긋났는지 말하지 않았다 (ux21 daily 4). 괄호는 쓰지 않는다 — 문구 괄호 안이 대조 키에서 빠지는 값 자리다
            gap = _issued_gap(state, isha, ipath, doc, c.path)
            summary = (f"{gap} — 이번 검사는 다시 저장만" if gap else "글자·표 변경 없음")
        # 값의 괄호는 []로 — 문구 괄호 안 전체가 대조 키에서 빠지는 값 자리인데, 값에 괄호가 들면(MOTOR (4P)) 값이 키에 남아 재저장 날 키가
        # 달라지고 _issued_gap도 머리를 못 읽는다 (ux22 judge 3)
        summary = summary.translate(_SQUARE)
        ev = [f"출도본: {PurePosixPath(ipath).name} — Rev {rev or '-'} · 저장 {date} ({ipath})",
              "원본에서 바뀐 값 (출도본 값 → 원본 지금 값, 위치):" if content else "이번 변경: 글자·표 변경 없음 — 새 출도본이 아직 없습니다"]
        _now_rev = getattr(doc, "revision", None) if doc is not None else None
        if _now_rev and rev and _rev_lower(rev, _now_rev):
            ev.insert(1, f"원본은 지금 Rev {_now_rev} — 출도본(Rev {rev})보다 새 판입니다")
        ev += lines[:5]
        if len(content) > 5:
            ev.append(f"외 {len(content) - 5}건 — 변경 상세에 모두 있습니다")
        out.append(Issue(POST_ISSUE_CODE, c.path,
                         f"출도 후 변경 — 출도본은 Rev {rev or '-'}({date} 출도), 원본에서 바뀐 값({summary})이 "
                         f"새 출도본에 없습니다.", tuple(ev)))
    return out


# ── 발주서 행 · 발주 후 변경 ────────────────────────────────────────────────────────────────────

# 이름에 '발주'가 있어도 발주서가 아닌 엑셀 — 현황판·예정표·목록·대장·계획 (재검토 rr066 judge 7)
_NOT_PO_NAME = re.compile(r"현황|예정|목록|대장|계획")
# 발주서임을 말하는 내용 제목 — 'PO NO'·'P/O No.'·'발주번호'·'PURCHASE ORDER'·'발 주 서'
_PO_TITLE = re.compile(r"(?<![A-Z])P\s*/?\s*O\s*\.?\s*(?:NO|#|번호)|발\s*주\s*(?:번\s*호|서)|PURCHASE\s*ORDER", re.IGNORECASE)


def _po_content(doc) -> bool:
    """발주서라고 볼 내용 근거 — 돈 칸(금액·단가 머리)·돈 줄·발주서 제목 중 하나."""
    from watcher.doctype import money_head_line, money_line
    from watcher.extract.base import head_key
    for row in (getattr(doc, "rows", None) or ())[:400]:
        vals = getattr(row, "values", None) or {}
        if any(money_head(head_key(h)) and str(v or "").strip() for h, v in vals.items()):
            return True
        if any(_PO_TITLE.search(str(h or "")) for h in vals):
            return True
    texts = [str(getattr(t, "text", "") or "") for t in (getattr(doc, "raw_texts", None) or ())[:400]]
    texts += [f"{k} {getattr(f, 'value', '')}" for k, f in (getattr(doc, "fields", None) or {}).items()]
    return any(_PO_TITLE.search(t) or money_line(t) or money_head_line(t) for t in texts)


def is_po(path: str, doc, cfg: dict | None) -> bool:
    """발주서 엑셀인가. 이름·폴더('발주')만으로 정하지 않는다 — '자재 발주 현황.xlsx'·'발주 예정 목록.xlsx'(금액 없음)가 발주서로
    기록돼 발주일=처음 본 날로 '발주 후 변경' 표지가 붙었다 (재검토 rr066 judge 7). 내용(doc)이 없으면 '읽어 볼 만한가'만 답한다."""
    if PurePosixPath(str(path)).suffix.lower() not in (".xlsx", ".xlsm"):
        return False
    if _NOT_PO_NAME.search(PurePosixPath(str(path)).stem):
        return False
    try:
        from watcher.doctype import canonical, commercial_kind, kind_of
        named = canonical(kind_of(path, cfg) or "") == "발주서"
        if doc is None:
            return named
        if not (named or commercial_kind(path, doc) == "발주서"):
            return False
        return _po_content(doc)
    except Exception:
        return False


def _po_rows(doc) -> list[tuple[str, str, str]]:
    """발주서 행 → [(행 자리, 태그·품번(접은 꼴), 사양 글)]. 금액 칸은 뺀다."""
    from watcher.extract.base import ROWKEY_TAG_KEYS, find_tags, head_key
    out = []
    for row in getattr(doc, "rows", None) or ():
        vals = getattr(row, "values", None) or {}
        keys: list = []
        spec, name, other = "", "", []
        for h, v in vals.items():
            sv, hk = str(v or "").strip(), head_key(h)
            if not sv or money_head(hk):
                continue
            if hk in ROWKEY_TAG_KEYS or _PART_HEAD.search(hk):
                keys.append(sv)
            elif _SPEC_HEAD.search(hk) and not spec:
                spec = sv
            elif _NAME_HEAD.search(hk) and not name:
                name = sv
            elif not _QTY_HEAD.fullmatch(hk):
                other.append(sv)
            keys += find_tags(sv)
        keys = [k for k in dict.fromkeys(re.sub(r"\s+", "", _fold(k)) for k in keys) if len(k) >= 3]
        if not keys:
            continue
        where = str(getattr(row, "where", "") or "")
        shown = spec or name or next((o for o in other if not re.fullmatch(r"[\d.,]+", o)), "")    # 수량 숫자는 규격 자리에 싣지 않는다 (ux23 final 3)
        for k in keys:
            out.append((where, k, shown[:60]))
    return out


# 발주일의 출처 꼬리 — po_lines.ordered는 'YYYY-MM-DD|칸'(시트 날짜 칸) 또는 'YYYY-MM-DD|저장'(파일 저장 시각으로 추정), 모르면 NULL.
# 꼬리 없는 옛 값은 예전 판이 '처음 본 검사일'로 채웠을 수 있어 한 번 다시 읽는다(record_po)
OD_SHEET, OD_SAVED = "칸", "저장"
PO_GEN_KEY = "po_lines_gen"          # 마지막으로 모든 발주서를 다시 읽은 추출 세대 (ux25 E3)


def _order_date(state, path: str, doc, mtime: float | None = None) -> str | None:
    """발주일 — 시트의 날짜 칸이 먼저, 없으면 파일 저장 시각(이 경로가 기록된 가장 이른 판의 수정 시각), 그것도 없으면 None(발주일
    모름). 처음 본 검사일(MIN(detected_at))을 발주일로 쓰면 설치 첫날 검사일이 모든 발주서의 발주일이 됐다 (ux20 daily 4)."""
    f = (getattr(doc, "fields", None) or {}).get("DATE") if doc is not None else None
    m = _DATE_RE.search(str(getattr(f, "value", "") or "")) if f is not None else None
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))).strftime("%Y-%m-%d") + "|" + OD_SHEET
        except ValueError:
            pass
    ts = [t for t in (mtime,) if t]
    try:
        row = state.conn.execute("SELECT MIN(mtime) FROM files WHERE path = ?", (path,)).fetchone()
        if row and row[0]:
            ts.append(float(row[0]))
    except Exception:
        pass
    ts = [t for t in ts if t > 0]
    if ts:
        try:
            return datetime.fromtimestamp(min(ts)).strftime("%Y-%m-%d") + "|" + OD_SAVED
        except (OverflowError, OSError, ValueError):
            pass
    return None


def order_day(od) -> str:
    """po_lines.ordered → 'YYYY-MM-DD' (모르면 '')."""
    return str(od or "")[:10] if re.match(r"\d{4}-\d{2}-\d{2}", str(od or "")) else ""


def order_phrase(od) -> str:
    """발주 후 변경 표지에 싣는 발주일 말 — 추정이면 추정이라고 밝힌다."""
    day = order_day(od)
    if not day:
        return "발주일 모름"
    if str(od).endswith("|" + OD_SAVED):
        return f"발주일 칸 없음 · 파일 저장 {day[5:]}"
    return f"{day[5:]} 발주"


def _kept_po(state, path: str, ordered, proj) -> tuple:
    """파일은 그대로인데 세대가 올라 다시 읽을 때 옛 기록을 잃지 않는다 — (발주일, 프로젝트, 처음 기록한 검사).
    시트 날짜 칸이 새로 읽혔으면 그것을, 아니면 옛 발주일과 견줘 믿을 만한 쪽·이른 쪽을. 꼬리 없는 옛 값은 처음 본 검사일일 수 있어 쓰지 않는다."""
    rows = state.conn.execute("SELECT ordered, project, snapshot_id FROM po_lines WHERE path = ?", (path,)).fetchall()
    old = next((o for o, _p, _s in rows if order_day(o) and "|" in str(o)), None)
    if old and not str(ordered or "").endswith("|" + OD_SHEET) \
            and (str(old).endswith("|" + OD_SHEET) or not order_day(ordered) or order_day(old) < order_day(ordered)):
        ordered = old
    return ordered, proj or next((p for _o, p, _s in rows if p), None), min((s for _o, _p, s in rows if s), default=None)


def record_po(state, rd, project_of=None) -> int:
    """발주서의 행(태그·품번·사양·발주일)을 기록한다 — 바뀐 발주서·처음 보는 발주서만 다시 읽는다. 기록한 발주서 수.
    추출 세대가 달라진 검사에서는 기록된 발주서를 모두 한 번 다시 읽는다 — 파일이 안 바뀌면 옛 판이 규격 자리에 박은 품명·'EA'가 그대로
    남아 '발주서 값과 같아진 변경'을 못 가렸다 (ux25 E3). 읽지 못한 발주서가 있으면 표식을 남기지 않아 다음 검사가 이어 한다."""
    cfg = getattr(rd, "cfg", None) or {}
    # 지워진(또는 옮겨진) 발주서의 행은 지운다 — 지운 파일을 근거로 '발주 후 변경' 표지가 붙었다 (재검토 rr066 judge 8).
    # 옮긴 발주서는 새 경로에서 다시 읽는다(아래 '오늘 바뀐 파일'). 못 읽은·이월된 파일은 스냅샷에 남아 지우지 않는다
    gone = {c.path for c in (rd.changes or ()) if c.kind == "removed"}
    # 옛 판이 이름만으로 발주서로 기록한 현황판·예정표·목록 — 파일이 안 바뀌면 다시 읽지 않으므로 여기서 거둔다
    gone |= {p for (p,) in state.conn.execute("SELECT DISTINCT path FROM po_lines")
             if _NOT_PO_NAME.search(PurePosixPath(str(p)).stem)}
    if gone:
        for p_ in gone:
            state.conn.execute("DELETE FROM po_lines WHERE path = ?", (p_,))
        state.conn.commit()
    have = {p: s for p, s in state.conn.execute("SELECT path, MAX(sha256) FROM po_lines GROUP BY path")}
    # 꼬리 없는 옛 발주일(예전 판 — 처음 본 검사일이었을 수 있다)은 파일이 안 바뀌어도 한 번 다시 읽는다 (ux20 daily 4)
    legacy = {p for (p,) in state.conn.execute(
        "SELECT DISTINCT path FROM po_lines WHERE ordered IS NOT NULL AND ordered NOT LIKE '%|%'")}
    changed = {c.path for c in (rd.changes or ()) if c.kind in ("added", "modified")}
    from watcher.cli import _CACHE_VER
    gen = str(_CACHE_VER)
    regen = set(have) if state.get_meta(PO_GEN_KEY) != gen else set()
    undone = set(regen)
    n = 0
    for r in rd.records or ():
        if PurePosixPath(r.path).suffix.lower() not in (".xlsx", ".xlsm"):
            continue
        if have.get(r.path) == r.sha256 and r.path not in legacy and r.path not in regen:
            continue
        # 이름·폴더로 발주서인 것, 아니면 오늘 바뀌었거나 이미 발주서로 기록된 것만 내용을 읽는다 — 엑셀마다 날마다 기록을 올리지 않게
        if not (is_po(r.path, None, cfg) or r.path in changed or r.path in have):
            continue
        try:
            doc = rd.docs.get(r.path)
        except Exception:
            doc = None
        if doc is None or not is_po(r.path, doc, cfg):
            if doc is not None and r.path in have:   # 고쳐서 더는 발주서가 아니다 — 옛 행을 남기지 않는다(못 읽은 날은 그대로)
                state.conn.execute("DELETE FROM po_lines WHERE path = ?", (r.path,))
                undone.discard(r.path)
                n += 1
            continue
        rows = _po_rows(doc)
        ordered = _order_date(state, r.path, doc, getattr(r, "mtime", None))
        proj = None
        if project_of is not None:
            try:
                proj = project_of(r.path, doc)
            except Exception:
                proj = None
        first = rd.snapshot_id
        if r.path in regen and have.get(r.path) == r.sha256:
            ordered, proj, first = _kept_po(state, r.path, ordered, proj)
        keep = {(w, k) for w, k, _s in rows}
        for w, k in state.conn.execute("SELECT row, tag FROM po_lines WHERE path = ?", (r.path,)).fetchall():
            if (w, k) not in keep:
                state.conn.execute("DELETE FROM po_lines WHERE path = ? AND row = ? AND tag = ?", (r.path, w, k))
        for w, k, sp in rows:
            state.conn.execute("INSERT OR IGNORE INTO po_lines (path, row, tag, spec, ordered, snapshot_id, project, sha256) "
                               "VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (r.path, w, k, sp, ordered, first, proj, r.sha256))
            state.conn.execute("UPDATE po_lines SET spec = ?, ordered = ?, project = ?, sha256 = ? "
                               "WHERE path = ? AND row = ? AND tag = ?", (sp, ordered, proj, r.sha256, r.path, w, k))
        undone.discard(r.path)
        n += 1
    if n:
        state.conn.commit()
    if not undone and state.get_meta(PO_GEN_KEY) != gen:
        state.set_meta(PO_GEN_KEY, gen)
    return n


def _row_label(where: str) -> str:
    m = re.search(r"행\s*(\d+)", where or "")
    return f"{m.group(1)}행" if m else (where or "")


_VALUE_UNIT = re.compile(r"(?<![0-9a-z가-힣.\-])(\d+(?:\.\d+)?)\s*(mm2|[a-z가-힣㎟㎾]+)")     # '5.5kw'·'100at'·'4sq' — 'ie3'·'m-101'은 값이 아니다
# 물건을 가르는 단위만 — 전압·극·심·수량·길이는 어느 품목에나 붙어 겹쳐도 같은 물건이라는 뜻이 아니다 (ux23 vz-check 2)
_COMMON_UNITS = frozenset({"v", "kv", "p", "c", "ea", "hz", "mm", "m", "개", "식", "set", "t", "상", "극", "심", "볼트", "대"})
# 같은 뜻의 표기 — '5.5kW급'·'4SQx4C'·'4㎟'·'100암페어'가 다른 단위로 보여 진짜 변경을 놓쳤다 (ux23 po-check 1)
_UNIT_FAMILY = {"a": "at", "af": "at", "암페어": "at", "hp": "kw", "w": "kw", "킬로와트": "kw", "㎾": "kw", "mm2": "sq", "㎟": "sq", "스퀘어": "sq"}


def _head_words(s: str) -> set:
    # 'G/M'·'G/V'는 한 낱말 — {g, m}으로 쪼개면 'GEARED MOTOR'의 머리글자와 못 만났다 (ux24 PO2)
    return set(re.findall(r"[a-z가-힣]+", re.sub(r"(?<![a-z])([a-z])/([a-z])(?![a-z])", r"\1\2", _head(s))))


def _unit_of(u: str) -> str:
    m = re.match(r"[a-z]+(?=[가-힣]|$)", u)          # 'kw급'·'at용' → 'kw'·'at'
    u = m.group(0) if m and u not in _UNIT_FAMILY else u
    if len(u) > 1 and u.endswith("x") and u.isascii():
        u = u[:-1]                                   # '4SQx4C' — 'sqx'가 아니라 'sq'
    return _UNIT_FAMILY.get(u, u)


def _spec_values(s: str) -> list:
    """[(숫자, 단위)] — 물건을 가르는 단위만."""
    out = [(n, _unit_of(u)) for n, u in _VALUE_UNIT.findall(_norm_v(s))]
    return [(n, u) for n, u in out if u not in _COMMON_UNITS and u != "x"]


def _spec_units(s: str) -> set:
    return {u for _n, u in _spec_values(s)}


def _all_values(s: str) -> set:
    return {(n, _unit_of(u)) for n, u in _VALUE_UNIT.findall(_norm_v(s))}


def _same_word(a: str, b: str) -> bool:
    """영문 머리말이 같은 말인가 — 같거나 줄임말('MTR'·'MOTOR', 'TR'·'TRANSFORMER'). 짧은 말의 부분 글자는 치지 않는다('MC'는 'MCCB'가 아니다, ux23 po-check 2)."""
    if a == b:
        return True
    short, long_ = sorted((a, b), key=len)
    if len(short) >= 2 and len(long_) > 4 and long_.startswith(short):
        return True                                  # 'TR'·'TRANSFORMER', 'SW'·'SWITCH' — 'MCCB'처럼 긴 쪽도 줄임말이면 다른 말 (ux23 final 1)
    if len(short) < 3 or short[0] != long_[0]:
        return False
    it = iter(long_)
    return all(ch in it for ch in short)


def _initials(s: str) -> str:
    """영문 머리말 낱말들의 머리글자 — 'MAGNETIC CONTACTOR' → 'mc', 'CURRENT TRANSFORMER' → 'ct'. 낱말이 하나면 없다."""
    words = [w for w in re.findall(r"[a-z가-힣]+", _head(s)) if w.isascii()]
    return "".join(w[0] for w in words) if len(words) > 1 else ""


def _label_fits_po(spec: str, line: str, tag: str) -> bool:
    return _label_fit(spec, line, tag) > 0


def _label_fit(spec: str, line: str, tag: str) -> int:
    """0 인정 안 함 · 1 인정 · 2 2자 줄임말 짐작으로만 인정 (표지 차례에 쓴다).
    이름표(이웃 글자로 짐작한 태그)가 이 발주 행과 **다른 물건**이라는 근거가 없으면 인정한다 — 발주 뒤 바뀐 것을 놓치는 쪽이 더 비싸고, 인정한
    표지는 '짐작'이라고 밝힌다. 영문 머리말이 양쪽에 있으면 그것으로 판단한다: 다른 말이면 다른 물건('MOTOR'↔'INVERTER', 'MC'↔'MCCB'), 같은 말이면
    같은 물건 — 단 줄에 규격에 없는 말이 더 있고 단위도 안 겹치면 딸린 물건('MOTOR BASE PLATE t12'), 머리글자로만 같으면 단위가 겹쳐야('MC 22A'↔
    'MOTOR CABLE 4SQ'는 다른 물건, ux24 PO1). 2자 줄임말↔풀어 쓴 낱말은 글자로 못 견주니 단위가 겹칠 때만 같은 물건('MC 22A'↔'CONTACTOR 22A', PO2).
    못 견주면(한글 — 모터·전동기처럼 같은 뜻이 여럿이다) 단위로: 안 겹치면 다른 물건('100AT 3P'↔'CV 4SQ', ux23 a 2), 줄에 단위가 없으면 규격의
    숫자가 줄에 있을 때만."""
    su, lu = _spec_units(spec), _spec_units(line)
    latin = lambda ws: {w for w in ws if w.isascii()}      # noqa: E731
    ws, wl = latin(_head_words(spec)), latin(_head_words(line))
    if ws and wl:
        names = ws | {str(tag).partition("-")[0].lstrip("0123456789")}
        same = any(_same_word(a, b) for a in names for b in wl) or _initials(line) in names or _initials(spec) in wl
        if not same:
            short_form = any(min(len(a), len(b)) == 2 and max(len(a), len(b)) > 4 for a in ws for b in wl)  # 'MCCB'처럼 긴 쪽도 줄임말이면 다른 말
            return 2 if short_form and su & lu else 0
        return int(not su or bool(su & lu) or wl <= names)
    if su and lu:
        return int(bool(su & lu))
    if su:
        # 줄이 값뿐이면 규격의 값과 견준다 — 'MOTOR 5.5kW 4P 380V' 옆 '380V'→'440V'. 공통 단위라도 값까지 같으면 그 행의 값이다 (ux23 final 2)
        if not wl and _all_values(spec) & _all_values(line):
            return 1
        return int(bool({n for n, _u in _spec_values(spec)} & set(re.findall(r"\d+(?:\.\d+)?", _norm_v(line)))))
    return 1


_VALUE_PIECE = re.compile(r"(?<![a-wyz가-힣0-9.])(\d+(?:\.\d+)?)\s*(mm2|[a-z가-힣]*)")     # '100/5a'의 100·'300x400'의 400도 값, 'ie3'·'t12'는 아니다


def _value_pieces(s: str) -> set:
    """글의 값 {(숫자, 단위)} — 태그는 빼고, 표기만 다른 단위는 접는다(100A·100AT, 4㎟·4SQ). AF·HP는 다른 값이라 접지 않는다."""
    from watcher.extract.base import find_tags
    t = _norm_v(s).upper()
    for tg in find_tags(t):
        t = " ".join(t.split(tg))
    return {(n, u if u in ("af", "hp") else _unit_of(u)) for n, u in _VALUE_PIECE.findall(t.lower())}


def _back_to_po(old: str, new: str, spec: str) -> bool:
    """이 변경이 도면을 발주서 값에 맞춘 것인가 — 새로 들어온 값이 있고 새 글의 값이 모두 발주 규격에 있을 때만 (ux24 RD2).
    단위 없는 맨 숫자뿐이면 수량일 수 있어 같다고 보지 않는다."""
    n = _value_pieces(new)
    return bool(n - _value_pieces(old)) and n <= _value_pieces(spec) and any(u for _v, u in n)


def _label_pieces(label: str) -> dict:
    """이름표 'M-101: 5.5kW → 7.5kW; MCCB-11: …'(diff.spec_tag_labels) → {접은 태그: [옛 글, 새 글]}."""
    from watcher.extract.base import find_tags
    out: dict = {}
    for part in str(label or "").split("; "):
        name, _c, body = part.partition(": ")
        if find_tags(name.strip().upper()) == [name.strip().upper()]:
            out.setdefault(re.sub(r"\s+", "", _fold(name)), []).extend(body.removesuffix(" (새로)").split(" → "))
    return out


# 원본 후보에서 빼는 보관 폴더 — 구판·OLD·archive·백업에 남은 옛 판은 지금의 원본이 아니다. 원본을 지우고 옛 Rev 보관본만 남았을 때
# pair_key가 Rev 꼬리를 떼어 그것을 원본으로 보고 사본의 표지를 숨겼다 (rv0676 RJ2). 넓게 빼는 쪽이 안전하다(빼면 표지가 난다).
# '구버전BOM'·'백업_2025'처럼 보관 낱말 뒤에 글자가 붙은 폴더도 (rv0676 re2) — '백업전원' 같은 사양 이름 폴더가 빠져도 표지가 날 뿐이다
_ARCHIVE_DIR = re.compile(r"구판|옛판|이전판|폐기|superseded|obsolete|(?<![a-z])void(?![a-z])|"
                          r"^(?:\d{1,4}[\s_.\-]+|[\s_\-.~#@]+)?(?:구버전|옛버전|이전버전|백업|archive|backup)", re.IGNORECASE)
# 출도 폴더 뒤의 판·날짜 폴더(출도/RevB/·출도/2026-11/) — 원본 경로에 없어도 된다. 그 밖의 뒤 마디(프로젝트·고객 폴더)는 원본 경로에 있어야
_REV_DIR = re.compile(r"(?:rev\.?\s*[a-z0-9]{1,3}|r\d{1,2}|\d{4}(?:[-._]?\d{1,2}){0,2}|\d{6})", re.IGNORECASE)


def _issued_cut(path: str, cfg) -> tuple | None:
    """출도 폴더 안 경로 → (출도 폴더 앞 마디들, 출도 폴더 뒤 마디들), 접은 꼴. in_issued_folder와 같은 차례로 맞춘다."""
    parts = [_fold(p) for p in PurePosixPath(str(path or "")).parent.parts]
    for e in issued_folders(cfg):
        ep = [x for x in e.split("/") if x]
        n = len(ep)
        for k in range(0, len(parts) - n + 1) if ep else ():
            if parts[k:k + n] == ep:
                return tuple(parts[:k + n - 1]), tuple(parts[k + n:])      # 경로형 항목(P26-031/출도)의 앞 마디는 범위에 넣는다
    return None


def _usable_dwg_no(v, path: str, projects, dirs: bool = True) -> str | None:
    """원본↔사본을 이을 만한 도면번호 — '-'·'1'처럼 3자 미만이거나 프로젝트 번호와 같은 자리표시 값은 쓰지 않는다(그런 값이 같은 다른
    도면이 원본이 되어 표지가 숨었다, rv0676 RJ2). dirs면 그 경로의 폴더 이름과 같은 값도(사본 쪽만 — 원본은 도면/E-101/E-101.dxf처럼
    도면번호 이름 폴더에 두는 일이 흔해 그 검사로 원본을 놓쳤다, rv0676 re2)."""
    def bare(s):                                      # 'P26-031'·'p26 031'·'P26_031'을 한 꼴로
        return re.sub(r"[^0-9a-z가-힣]", "", _fold(s))
    k = re.sub(r"\s+", "", _fold(v)) if v is not None else ""
    b = bare(k)
    if len(b) < 3:
        return None
    if any(b == bare(p) for p in projects if p):
        return None
    for seg in PurePosixPath(str(path)).parent.parts if dirs else ():
        f = bare(seg)
        if f == b or (f.startswith(b) and not re.match(r"[0-9a-z]", f[len(b):])):
            return None
    return k


def _stored_dwg_no(state, sha) -> str | None:
    """추출 기록의 표제란 도면번호만 — 문서 전체를 읽지 않는다(LazyDocs로 모든 기록을 읽어 캐시를 밀어냈다, rv0676 RJ4).
    다른 추출기 묶음으로 저장된 'sha:묶음' 열쇠도 본다(state.save_extract)."""
    if not sha:
        return None
    try:
        rows = state.conn.execute("SELECT sha256, json_extract(doc_json, '$.fields.DWG_NO.value') FROM extracts "
                                  "WHERE sha256 = ? OR (sha256 > ? AND sha256 < ?)", (sha, sha + ":", sha + ";")).fetchall()
    except Exception:
        return None
    rows.sort(key=lambda r: r[0] != sha)
    return next((r[1] for r in rows if r[1] is not None), None)


def in_archive_folder(path: str) -> bool:
    """감시 폴더 라벨 아래 폴더 마디에 구판·백업·보관·임시 류 이름이 있나 (_ARCHIVE_DIR·QUIET_NAME_RE)."""
    from watcher.project import QUIET_NAME_RE
    segs = PurePosixPath(str(path)).parent.parts
    return any(_ARCHIVE_DIR.search(s) or QUIET_NAME_RE.search(s) for s in segs[1:])


def _originals(rd, cfg) -> list:
    """이번 검사의 출도 폴더 밖·보관 폴더 밖 파일 [(경로, 접은 폴더 마디, 지문)]. 한 검사에 한 번."""
    out = []
    recs = [(r.path, getattr(r, "sha256", None)) for r in (getattr(rd, "records", None) or ())]
    recs += [(p, None) for p in (getattr(rd, "carry_paths", None) or ())]
    for p, sha in recs:
        if in_issued_folder(p, cfg):
            continue
        if in_archive_folder(p):
            continue
        segs = PurePosixPath(str(p)).parent.parts
        out.append((p, tuple(_fold(s) for s in segs), sha))
    return out


def _has_original(state, rd, cfg, path: str, mine, project_of, originals: list) -> bool:
    """이 출도 사본의 원본이 이번 검사에 있나. 애매하면 없다고 본다 — 표지를 숨기는 쪽이 더 위험하다(겹치는 쪽을 고른다).
    범위: 출도 폴더 앞 마디 아래, 그리고 출도 폴더 뒤 마디(프로젝트·고객 폴더, 판·날짜 폴더는 빼고)가 원본 경로에도 있어야 한다 — 앞 마디가
    둘 이상이어도(서버/설계부/출도/삼성 3공장의 원본으로 서버/설계부/LG배터리가 잡혔다, rv0676 re2). 같은 프로젝트(귀속을 알면).
    거기서 못 찾으면 앞 마디를 한 마디씩 줄여 가며 귀속이 **둘 다 있고 같을 때만** 찾는다(서버/P26-031/납품/출도의 원본 서버/P26-031/도면).
    잇는 열쇠: 같은 이름 줄기, 또는 쓸 만한 같은 도면번호. 부서별 서버에서 첫 두 마디로 찾다가 다른 프로젝트 파일이 원본이 됐다 (RJ2)."""
    from watcher.scan import pair_key
    cut = _issued_cut(path, cfg)
    if cut is None:
        return False
    pre, rest = cut
    need = tuple(x for x in rest if not _REV_DIR.fullmatch(x))
    name = pair_key(PurePosixPath(str(path)).name)
    try:
        doc = (rd.docs or {}).get(path)
    except Exception:
        doc = None
    f = (getattr(doc, "fields", None) or {}).get("DWG_NO") if doc is not None else None
    ck = _usable_dwg_no(getattr(f, "value", None), path, [mine])
    theirs_of: dict = {}

    def theirs(p):
        if p not in theirs_of:
            try:
                theirs_of[p] = (project_of(p, None) or "") if project_of is not None else ""
            except Exception:
                theirs_of[p] = ""
        return theirs_of[p]

    def bare(s):
        return re.sub(r"[^0-9a-z가-힣]", "", _fold(s))
    levels = [(pre, False)]
    bm = bare(mine) if mine else ""
    if bm and re.search(r"\d", bm):                   # 번호 꼴 귀속만 — 귀속기가 부서 폴더('설계부')를 프로젝트로 잡으면 고객 폴더를 넘었다
        for j in range(len(pre) - 1, 0, -1):          # 출도 폴더가 프로젝트 폴더의 형제 폴더 아래(P26-031/납품/출도)면 프로젝트 폴더까지만 줄인다
            f = bare(pre[j - 1])
            if f == bm or (f.startswith(bm) and not re.match(r"[0-9a-z]", f[len(bm):])):
                levels.append((pre[:j], True))
                break
    for scope, strict in levels:
        if not strict and len(scope) < 2 and not need and not mine:
            continue                                  # 범위를 가를 마디도 귀속도 없다
        for p, segs, sha in originals:
            if segs[:len(scope)] != scope or not all(x in segs for x in need):
                continue
            same = pair_key(PurePosixPath(str(p)).name) == name
            if not same and ck:
                same = _usable_dwg_no(_stored_dwg_no(state, sha), p, [mine], dirs=False) == ck
            if not same:
                continue
            if project_of is not None:
                t = theirs(p)
                if mine and t and _fold(mine) != _fold(t):
                    continue                          # 다른 프로젝트의 같은 이름 — 원본이 아니다
                if (strict or (len(scope) < 2 and not need)) and not (mine and t):
                    continue
            elif strict:
                continue
            return True
    return False


def po_mark_changes(state, rd, project_of=None) -> int:
    """발주 뒤 도면·BOM에서 발주서 행의 태그·품번 값이 바뀐 변경에 '발주 후 변경' 표지를 단다. 단 변경 수.
    글자 변경은 글자 속 태그·품번만 곧바로 짝짓고, 이름표로 짐작한 태그는 _label_fit을 지나야 한다. 표 행의 열쇠·이름표는 그 행 자신의 값이다.
    새 값이 그 발주 행 규격과 같으면 표지를 달지 않는다(_back_to_po) — 변경 자체는 그대로 남는다. 수량·단위 칸은 규격의 글과 견주지 않는다.
    표지는 수에 상한 없이 **모두** 상세에 넣는다(줄 차례: 곧바로 잡은 태그 → 같은 낱말 → 2자 줄임말 짐작) — 넘친 표지를 버렸더니 변경 상세·메일·대장
    어디에도 없었다(원칙 4, ux25 E1). 접는 곳은 메일 한 곳(brief._details_rows_mail)이다. 앞에 끼워 항목 상한에 잘리지 않게 하고, 어느 태그의
    표지인지는 label에 남긴다(메일 머리 끝말이 읽는다, ux25 E4)."""
    rows = state.conn.execute("SELECT path, row, tag, spec, ordered, snapshot_id, project FROM po_lines").fetchall()
    if not rows:
        return 0
    from watcher.brief import short_pair
    from watcher.consistency import strip_commerce
    from watcher.diff import ChangeItem
    from watcher.extract.base import find_tags, head_key
    today = datetime.now().strftime("%Y-%m-%d")
    by_tag: dict = {}
    for path, w, k, sp, od, snap, proj in rows:
        # 발주가 이 검사 **전**이어야 '발주 후' — 같은 검사에서 처음 본 발주서는 발주일이 오늘보다 앞설 때만
        if (snap or 0) >= (rd.snapshot_id or 0) and not (order_day(od) and order_day(od) < today):
            continue
        by_tag.setdefault(k, []).append((path, w, sp, od, proj))
    if not by_tag:
        return 0
    part_keys = [k for k in by_tag if not find_tags(k.upper())]
    po_paths = {r[0] for r in rows}
    cfg = getattr(rd, "cfg", None) or {}
    originals = None
    n = 0
    for c in rd.changes or ():
        if c.kind != "modified" or c.path in po_paths:
            continue
        items = (rd.details or {}).get(c.path)
        if not items:
            continue
        mine = None
        if in_issued_folder(c.path, cfg):
            if originals is None:
                originals = _originals(rd, cfg)
            if project_of is not None:
                try:
                    mine = project_of(c.path, (rd.docs or {}).get(c.path)) or ""
                except Exception:
                    mine = ""
            if _has_original(state, rd, cfg, c.path, mine, project_of, originals):
                continue                              # 원본이 있는 출도 사본 — 표지는 원본에. 같은 Rev 재복사에 또 붙어 할 일이 겹쳤다 (rv0676 WE1)
        hits: list = []
        for it in list(items):
            kind = getattr(it, "kind", "")
            if kind not in ("TEXT_CHANGED", "ROW_CHANGED"):
                continue
            key = str(getattr(it, "key", "") or "")
            cell = head_key(split_row_cell(key)[2]) if kind == "ROW_CHANGED" else ""
            if cell and (money_head(cell) or _PERSON_HEAD.search(cell)):
                continue                              # 금액 칸·사람 칸은 견주지 않는다
            old, new = str(it.old or ""), str(it.new or "")
            if strip_commerce(old) == strip_commerce(new):
                continue
            label = str(getattr(it, "label", "") or "")
            # 발주 뒤 바뀐 수량이 규격 글 속 숫자('… 100M')와 같다고 맞춘 것이 아니다 (ux25 E2). '수량(EA)'·'발주수량'도 수량 칸 (e2-1)
            qty_cell = bool(cell and (qty_head(cell) or _UNIT_WORD.fullmatch(cell)))
            text = f"{key} {old} {new} {label}" if kind == "ROW_CHANGED" else f"{old} {new}"
            found = {re.sub(r"\s+", "", _fold(t)) for t in find_tags(text.upper())}
            ft = _fold(text)
            found |= {k for k in part_keys if re.search(r"(?<![0-9a-z가-힣-])" + re.escape(k) + r"(?![0-9a-z가-힣])", ft)}
            # DXF의 사양 글자만 바뀐 줄은 태그가 따로 있다 — 이름표('M-101: 5.5kW → 7.5kW', cli._pair_spec_tags)는 짐작이라 발주 행마다 따져 본다
            guessed = {} if kind == "ROW_CHANGED" else {k: v for k, v in _label_pieces(label).items() if k not in found}
            for k in sorted((found | set(guessed)) & set(by_tag)):
                for po in by_tag[k]:
                    rank = 0
                    if k in guessed:
                        rank = min((f for f in (_label_fit(po[2], s_, k) for s_ in guessed[k]) if f), default=0)
                        if not rank:
                            continue                  # 이웃 태그일 뿐 — 변경 자체는 상세에 이름표와 함께 남는다
                    if not qty_cell and _back_to_po(strip_commerce(old), strip_commerce(new), po[2]):
                        continue                      # 도면이 발주서에 맞춰졌다 — 업체에 알릴 '발주 뒤 바뀐 값'이 아니다 (ux24 RD2)
                    if mine is None and project_of is not None:
                        try:
                            mine = project_of(c.path, (rd.docs or {}).get(c.path)) or ""
                        except Exception:
                            mine = ""
                    if po[4] and mine and _fold(po[4]) != _fold(mine):
                        continue                      # 다른 프로젝트의 같은 태그 — 다른 기기다
                    if (not po[4] or not mine) and PurePosixPath(po[0]).parts[:2] != PurePosixPath(c.path).parts[:2]:
                        continue
                    hits.append((rank, k, po, it, k in guessed))
        if not hits:
            continue
        have = {str(getattr(i, "new", "")) for i in items if getattr(i, "key", "") == PO_MARK_KEY}
        marks: list = []
        for _rank, k, (ppath, w, sp, od, _pj), it, by_guess in sorted(hits, key=lambda h: h[0]):
            line = (f"{PurePosixPath(ppath).name} {_row_label(w)}({(sp or k.upper())[:24]}, {order_phrase(od)}) — 발주 뒤 바뀐 값: "
                    f"{short_pair(it.old or '(빈 값)', it.new or '(빈 값)', 40)} ({getattr(it, 'where', '') or ''})"
                    + (f" — 태그 없는 글줄이라 이웃 {k.upper()}로 짐작, 같은 품목인지 확인" if by_guess else ""))
            if line in have:
                continue
            have.add(line)
            marks.append(ChangeItem("CHECK_SKIPPED", PO_MARK_KEY, None, line, "발주 대조", label=k))
        if marks:
            items[0:0] = marks
            n += 1
    return n


def po_marked(items) -> bool:
    """이 변경에 '발주 후 변경' 표지가 있나 — 구매 담당 수신자 분기용."""
    return any(getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == PO_MARK_KEY for i in (items or ()))


def track(state, rd, project_of=None) -> None:
    """검사 한 회분: 출도본·발주서 기록 → 출도 후 변경 이슈(rd.issues에 더함) → 발주 후 변경 표지. 실패해도 검사는 이어간다."""
    import sys
    try:
        record_issued(state, rd, project_of)
        rd.issues += post_issue_issues(state, rd, project_of)
    except Exception as e:                       # 부가 판정 — 이것 때문에 검사·메일이 되돌려지면 안 된다
        print(f"경고: 출도 후 변경 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
    try:
        record_po(state, rd, project_of)
        po_mark_changes(state, rd, project_of)
    except Exception as e:
        print(f"경고: 발주 후 변경 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
