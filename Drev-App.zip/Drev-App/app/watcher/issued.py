# -*- coding: utf-8 -*-
"""출도(발행) 폴더 · 출도 후 변경 · 발주 후 변경 (기능 검토 2026-11-02 J2·J8).

구매 결정 장면 — 외주처가 옛 판을 들고 있다, 이미 발주한 사양이 바뀌었다 — 이 지금 기능에 비어 있었다(DECISIONS 2026-11-02).
원칙 6 안: 의미(옳다/그르다)는 판단하지 않고 사실만 잇는다.
  · 출도 폴더에 들어온 판을 그 도면번호의 '출도본'으로 기록하고, 그 뒤 원본이 바뀌었는데 더 새 출도본이 없으면 '출도 후 변경'.
  · 발주서 행의 태그·품번을 기록하고, 발주 뒤 도면·BOM에서 그 태그·품번의 값이 바뀌면 그 변경에 '발주 후 변경' 표지.
감시는 읽기 전용 — 이 모듈은 state.db에만 쓴다. 금액 칸은 담지도 견주지도 않는다(DECISIONS 2026-10-19).
출도 폴더는 사용자가 정한다(설정 issued_folders). 폴더 이름 추정(suggest_issued_folders)은 화면의 제안일 뿐이다.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime, timezone
from pathlib import PurePosixPath

ISSUED_NAME_RE = re.compile(r"출도|발행|발송|배포|송부|issued?(?![a-z])|(?<![a-z])ifc(?![a-z])|for[\s_-]*construction",
                            re.IGNORECASE)
POST_ISSUE_CODE = "POST_ISSUE_CHANGE"
PO_MARK_KEY = "발주 후 변경"
# 금액 칸 — 담지도 견주지도 않는다 (DECISIONS 2026-10-19)
_AMOUNT_HEAD = re.compile(r"금액|단가|가격|합계|공급가|부가세|세액|VAT|AMOUNT|PRICE|TOTAL|COST|원\s*$", re.IGNORECASE)
_PART_HEAD = re.compile(r"품번|품목\s*코드|자재\s*코드|부품\s*번호|PART\s*(?:NO|NUMBER|#)|P/?N$|ITEM\s*(?:NO|CODE)|CODE\s*NO",
                        re.IGNORECASE)
_SPEC_HEAD = re.compile(r"규격|사양|SPEC|MODEL|모델|형식|정격|용량|RATING", re.IGNORECASE)
_NAME_HEAD = re.compile(r"품명|DESCRIPTION|명칭", re.IGNORECASE)          # 사양 칸이 없을 때만 보이는 이름
_DATE_RE = re.compile(r"(20\d{2})[-./년\s]+(\d{1,2})[-./월\s]+(\d{1,2})")


def _fold(s) -> str:
    return unicodedata.normalize("NFKC", str(s or "")).strip().casefold()


def issued_folders(cfg: dict | None) -> list[str]:
    """설정의 출도 폴더 목록 — 폴더 이름('출도') 또는 감시 폴더 기준 경로('P26-001/출도'). 옛 설치본에는 키가 없다(빈 목록)."""
    v = (cfg or {}).get("issued_folders")
    if isinstance(v, (str, bytes)):
        v = [v]
    if not isinstance(v, (list, tuple)):
        return []
    out = []
    for e in v:
        s = "/".join(_fold(e).split("\\")).strip("/ ")      # 읽기 전용 검사가 .replace 이름을 막는다 (test_readonly)
        if s and s not in out:
            out.append(s)
    return out


def in_issued_folder(path: str, cfg: dict | None) -> str | None:
    """이 경로가 출도 폴더 안이면 맞은 항목, 아니면 None. 이름 항목은 경로의 **폴더** 한 마디와 같아야 하고, 경로 항목은 그 마디들이
    이어서 나와야 한다(감시 폴더 라벨은 있어도 없어도)."""
    entries = issued_folders(cfg)
    if not entries:
        return None
    parts = [_fold(p) for p in PurePosixPath(str(path or "")).parent.parts]
    if not parts:
        return None
    for e in entries:
        ep = [x for x in e.split("/") if x]
        if not ep:
            continue
        n = len(ep)
        if any(parts[k:k + n] == ep for k in range(0, len(parts) - n + 1)):
            return e
    return None


def suggest_issued_folders(paths, cfg: dict | None = None, limit: int = 12) -> list[tuple[str, int]]:
    """감시 중인 파일 경로에서 출도·발행·Issued·IFC 같은 이름의 폴더를 찾아 (폴더 이름, 파일 수) — 제안만 한다(확정은 사용자)."""
    have = set(issued_folders(cfg))
    cnt: dict = {}
    shown: dict = {}
    for p in paths or ():
        seen = set()
        for part in PurePosixPath(str(p)).parent.parts[1:]:       # 감시 폴더 라벨은 빼고
            if ISSUED_NAME_RE.search(part):
                k = _fold(part)
                if k in have or k in seen:
                    continue
                seen.add(k)
                cnt[k] = cnt.get(k, 0) + 1
                shown.setdefault(k, part)
    return sorted(((shown[k], n) for k, n in cnt.items()), key=lambda t: (-t[1], t[0]))[:limit]


def doc_key(path: str, doc) -> str | None:
    """출도본과 원본을 잇는 도면번호 — 표제란 도면번호가 있으면 그것, 없으면 판 짝짓기와 같은 이름 줄기(Rev·날짜 꼬리 뺌)."""
    f = (getattr(doc, "fields", None) or {}).get("DWG_NO") if doc is not None else None
    v = getattr(f, "value", None) if f is not None else None
    if v and str(v).strip():
        return re.sub(r"\s+", "", _fold(v))
    from watcher.scan import pair_key
    k = pair_key(PurePosixPath(str(path)).name)
    return k or None


def _date_of(ts) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%m-%d")
    except (TypeError, ValueError, OSError, OverflowError):
        return "날짜 모름"


# ── 출도본 기록 · 출도 후 변경 ─────────────────────────────────────────────────────────────────

def record_issued(state, rd) -> int:
    """출도 폴더 안 파일의 처음 보는 판을 출도본으로 기록한다. 기록한 수."""
    cfg = getattr(rd, "cfg", None) or {}
    if not issued_folders(cfg):
        return 0
    have = {(p, s) for p, s in state.conn.execute("SELECT path, sha256 FROM issued_copies")}
    now = datetime.now(timezone.utc).isoformat()
    n = 0
    for r in rd.records or ():
        if (r.path, r.sha256) in have or not in_issued_folder(r.path, cfg):
            continue
        try:
            doc = rd.docs.get(r.path)
        except Exception:
            doc = None
        key = doc_key(r.path, doc)
        if not key:
            continue
        rev = getattr(doc, "revision", None) if doc is not None else None
        state.conn.execute(
            "INSERT OR IGNORE INTO issued_copies (key, path, sha256, rev, saved, snapshot_id, at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (key, r.path, r.sha256, rev, r.mtime, rd.snapshot_id, now))
        n += 1
    if n:
        state.conn.commit()
    return n


def _latest_issued(state) -> dict:
    """도면번호 → 가장 나중에 본 출도본 (snapshot_id, path, sha, rev, saved)."""
    out: dict = {}
    for key, path, sha, rev, saved, snap, iid in state.conn.execute(
            "SELECT key, path, sha256, rev, saved, snapshot_id, id FROM issued_copies"):
        cur = out.get(key)
        if cur is None or ((snap or 0), iid) > ((cur[0] or 0), cur[5]):
            out[key] = (snap or 0, path, sha, rev, saved, iid)
    return out


def resolve_reissued(state, rd, latest: dict | None = None) -> int:
    """열린 '출도 후 변경' 가운데 그 뒤 새 출도본이 들어온 것을 닫는다 — 새 출도가 곧 해소다. 닫은 수."""
    latest = _latest_issued(state) if latest is None else latest
    if not latest:
        return 0
    now = datetime.now(timezone.utc).isoformat()
    n = 0
    for iid, path, snap in state.conn.execute(
            "SELECT id, path, snapshot_id FROM issues WHERE code = ? AND resolved_at IS NULL", (POST_ISSUE_CODE,)).fetchall():
        try:
            doc = rd.docs.get(path)
        except Exception:
            doc = None
        key = doc_key(path, doc)
        cur = latest.get(key) if key else None
        if cur is None or (cur[0] or 0) <= (snap or 0):
            continue
        why = f"자동 해소 — 새 출도본이 들어옴 ({PurePosixPath(cur[1]).name}" + (f", Rev {cur[3]}" if cur[3] else "") + ")"
        state.conn.execute("UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?", (now, why, iid))
        n += 1
    if n:
        state.conn.commit()
    return n


def post_issue_issues(state, rd) -> list:
    """출도 뒤 원본이 바뀌었는데 더 새 출도본이 없는 파일의 검토 필요. 근거: 출도본(이름·Rev·날짜·경로), 원본에서 바뀐 값
    (출도본 쪽 값 → 원본 값, 위치). 같은 검사에 새 출도본이 들어온 도면은 그것이 새 출도다."""
    cfg = getattr(rd, "cfg", None) or {}
    if not issued_folders(cfg) or getattr(rd, "is_baseline", False):
        return []
    latest = _latest_issued(state)
    resolve_reissued(state, rd, latest)
    if not latest:
        return []
    from watcher.brief import short_pair
    from watcher.consistency import Issue, _fmt_item
    from watcher.diff import content_items
    open_paths = {p for (p,) in state.conn.execute(
        "SELECT path FROM issues WHERE code = ? AND resolved_at IS NULL", (POST_ISSUE_CODE,))}
    out = []
    for c in rd.changes or ():
        if c.kind != "modified" or in_issued_folder(c.path, cfg):
            continue
        try:
            doc = rd.docs.get(c.path)
        except Exception:
            doc = None
        key = doc_key(c.path, doc)
        iss = latest.get(key) if key else None
        if iss is None or (iss[0] or 0) >= (rd.snapshot_id or 0) or iss[2] == c.new_sha256:
            continue
        content = content_items((rd.details or {}).get(c.path) or [])
        if not content and c.path not in open_paths:
            continue
        _snap, ipath, _sha, rev, saved, _iid = iss
        date = _date_of(saved)
        if content:
            first = content[0]
            summary = short_pair(first.old, first.new, 30) + (f" 외 {len(content) - 1}건" if len(content) > 1 else "")
        else:
            summary = "글자·표 변경 없음"
        ev = [f"출도본: {PurePosixPath(ipath).name} — Rev {rev or '-'} · 저장 {date} ({ipath})",
              "원본에서 바뀐 값 (출도본 쪽 값 → 원본 값, 위치):" if content else "이번 변경: 글자·표 변경 없음 — 새 출도본이 아직 없습니다"]
        ev += [_fmt_item(i) for i in content[:5]]
        if len(content) > 5:
            ev.append(f"외 {len(content) - 5}건 — 변경 상세에 모두 있습니다")
        out.append(Issue(POST_ISSUE_CODE, c.path,
                         f"출도 후 변경 — 출도본은 Rev {rev or '-'}({date} 출도), 원본에서 바뀐 값({summary})이 "
                         f"새 출도본에 없습니다.", tuple(ev)))
    return out


# ── 발주서 행 · 발주 후 변경 ────────────────────────────────────────────────────────────────────

def is_po(path: str, doc, cfg: dict | None) -> bool:
    if PurePosixPath(str(path)).suffix.lower() not in (".xlsx", ".xlsm"):
        return False
    try:
        from watcher.doctype import canonical, commercial_kind, kind_of
        if canonical(kind_of(path, cfg) or "") == "발주서":
            return True
        return doc is not None and commercial_kind(path, doc) == "발주서"
    except Exception:
        return False


def _po_rows(doc) -> list[tuple[str, str, str]]:
    """발주서 행 → [(행 자리, 태그·품번(접은 꼴), 사양 글)]. 금액 칸은 뺀다."""
    from watcher.extract.base import ROWKEY_TAG_KEYS, find_tags, head_key
    out = []
    for row in getattr(doc, "rows", None) or ():
        vals = getattr(row, "values", None) or {}
        keys: list = []
        spec, name, other = "", "", []
        for h, v in vals.items():
            sv = str(v or "").strip()
            if not sv or _AMOUNT_HEAD.search(str(h or "")):
                continue
            if head_key(h) in ROWKEY_TAG_KEYS or _PART_HEAD.search(str(h or "")):
                keys.append(sv)
            elif _SPEC_HEAD.search(str(h or "")) and not spec:
                spec = sv
            elif _NAME_HEAD.search(str(h or "")) and not name:
                name = sv
            else:
                other.append(sv)
            keys += find_tags(sv)
        keys = [k for k in dict.fromkeys(re.sub(r"\s+", "", _fold(k)) for k in keys) if len(k) >= 3]
        if not keys:
            continue
        where = str(getattr(row, "where", "") or "")
        shown = spec or name or (other[0] if other else "")
        for k in keys:
            out.append((where, k, shown[:60]))
    return out


def _order_date(state, path: str, doc) -> str:
    f = (getattr(doc, "fields", None) or {}).get("DATE") if doc is not None else None
    m = _DATE_RE.search(str(getattr(f, "value", "") or "")) if f is not None else None
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))).strftime("%Y-%m-%d")
        except ValueError:
            pass
    row = state.conn.execute("SELECT MIN(detected_at) FROM changes WHERE path = ?", (path,)).fetchone()
    try:
        if row and row[0]:
            return datetime.fromisoformat(row[0]).astimezone().strftime("%Y-%m-%d")
    except (TypeError, ValueError):
        pass
    return datetime.now().strftime("%Y-%m-%d")


def record_po(state, rd, project_of=None) -> int:
    """발주서의 행(태그·품번·사양·발주일)을 기록한다 — 바뀐 발주서·처음 보는 발주서만 다시 읽는다. 기록한 발주서 수."""
    cfg = getattr(rd, "cfg", None) or {}
    have = {p: s for p, s in state.conn.execute("SELECT path, MAX(sha256) FROM po_lines GROUP BY path")}
    changed = {c.path for c in (rd.changes or ()) if c.kind in ("added", "modified")}
    n = 0
    for r in rd.records or ():
        if PurePosixPath(r.path).suffix.lower() not in (".xlsx", ".xlsm"):
            continue
        if have.get(r.path) == r.sha256:
            continue
        # 이름·폴더로 발주서인 것, 아니면 오늘 바뀌었거나 이미 발주서로 기록된 것만 내용을 읽는다 — 엑셀마다 날마다 기록을 올리지 않게
        if not (is_po(r.path, None, cfg) or r.path in changed or r.path in have):
            continue
        try:
            doc = rd.docs.get(r.path)
        except Exception:
            doc = None
        if doc is None or not is_po(r.path, doc, cfg):
            continue
        rows = _po_rows(doc)
        ordered = _order_date(state, r.path, doc)
        proj = None
        if project_of is not None:
            try:
                proj = project_of(r.path, doc)
            except Exception:
                proj = None
        keep = {(w, k) for w, k, _s in rows}
        for w, k in state.conn.execute("SELECT row, tag FROM po_lines WHERE path = ?", (r.path,)).fetchall():
            if (w, k) not in keep:
                state.conn.execute("DELETE FROM po_lines WHERE path = ? AND row = ? AND tag = ?", (r.path, w, k))
        for w, k, sp in rows:
            state.conn.execute("INSERT OR IGNORE INTO po_lines (path, row, tag, spec, ordered, snapshot_id, project, sha256) "
                               "VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (r.path, w, k, sp, ordered, rd.snapshot_id, proj, r.sha256))
            state.conn.execute("UPDATE po_lines SET spec = ?, ordered = ?, project = ?, sha256 = ? "
                               "WHERE path = ? AND row = ? AND tag = ?", (sp, ordered, proj, r.sha256, r.path, w, k))
        n += 1
    if n:
        state.conn.commit()
    return n


def _row_label(where: str) -> str:
    m = re.search(r"행\s*(\d+)", where or "")
    return f"{m.group(1)}행" if m else (where or "")


def po_mark_changes(state, rd, project_of=None) -> int:
    """발주 뒤 도면·BOM에서 발주서 행의 태그·품번 값이 바뀐 변경에 '발주 후 변경' 표지를 단다. 단 변경 수."""
    rows = state.conn.execute("SELECT path, row, tag, spec, ordered, snapshot_id, project FROM po_lines").fetchall()
    if not rows:
        return 0
    from watcher.brief import short_pair
    from watcher.consistency import strip_commerce
    from watcher.diff import ChangeItem
    from watcher.extract.base import find_tags
    today = datetime.now().strftime("%Y-%m-%d")
    by_tag: dict = {}
    for path, w, k, sp, od, snap, proj in rows:
        # 발주가 이 검사 **전**이어야 '발주 후' — 같은 검사에서 처음 본 발주서는 발주일이 오늘보다 앞설 때만
        if (snap or 0) >= (rd.snapshot_id or 0) and not (od and od < today):
            continue
        by_tag.setdefault(k, []).append((path, w, sp, od, proj))
    if not by_tag:
        return 0
    part_keys = [k for k in by_tag if not find_tags(k.upper())]
    po_paths = {r[0] for r in rows}
    n = 0
    for c in rd.changes or ():
        if c.kind != "modified" or c.path in po_paths:
            continue
        items = (rd.details or {}).get(c.path)
        if not items:
            continue
        mine = None
        hits: list = []
        for it in list(items):
            kind = getattr(it, "kind", "")
            if kind not in ("TEXT_CHANGED", "ROW_CHANGED"):
                continue
            key = str(getattr(it, "key", "") or "")
            if kind == "ROW_CHANGED" and _AMOUNT_HEAD.search(key.rpartition(".")[2]):
                continue                              # 금액 칸은 견주지 않는다
            old, new = str(it.old or ""), str(it.new or "")
            if strip_commerce(old) == strip_commerce(new):
                continue
            # DXF의 사양 글자만 바뀐 줄은 태그가 따로 있다 — 이름표('M-101: 5.5kW → 7.5kW', cli._pair_spec_tags)도 본다
            text = (f"{key} {old} {new}" if kind == "ROW_CHANGED" else f"{old} {new}") + " " + str(getattr(it, "label", "") or "")
            found = {re.sub(r"\s+", "", _fold(t)) for t in find_tags(text.upper())}
            ft = _fold(text)
            found |= {k for k in part_keys if re.search(r"(?<![0-9a-z가-힣-])" + re.escape(k) + r"(?![0-9a-z가-힣])", ft)}
            for k in sorted(found & set(by_tag)):
                for po in by_tag[k]:
                    if mine is None and project_of is not None:
                        try:
                            mine = project_of(c.path, (rd.docs or {}).get(c.path)) or ""
                        except Exception:
                            mine = ""
                    if po[4] and mine and _fold(po[4]) != _fold(mine):
                        continue                      # 다른 프로젝트의 같은 태그 — 다른 기기다
                    if (not po[4] or not mine) and PurePosixPath(po[0]).parts[:2] != PurePosixPath(c.path).parts[:2]:
                        continue
                    hits.append((k, po, it))
        if not hits:
            continue
        have = {str(getattr(i, "new", "")) for i in items if getattr(i, "key", "") == PO_MARK_KEY}
        added = 0
        for k, (ppath, w, sp, od, _pj), it in hits:
            od_s = (od or "")[5:] or "날짜 모름"
            line = (f"{PurePosixPath(ppath).name} {_row_label(w)}({(sp or k.upper())[:24]}, {od_s} 발주) — 발주 뒤 바뀐 값: "
                    f"{short_pair(it.old, it.new, 40)} ({getattr(it, 'where', '') or ''})")
            if line in have or added >= 3:
                continue
            have.add(line)
            items.append(ChangeItem("CHECK_SKIPPED", PO_MARK_KEY, None, line, "발주 대조"))
            added += 1
        if added:
            n += 1
    return n


def po_marked(items) -> bool:
    """이 변경에 '발주 후 변경' 표지가 있나 — 구매 담당 수신자 분기용."""
    return any(getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == PO_MARK_KEY for i in (items or ()))


def track(state, rd, project_of=None) -> None:
    """검사 한 회분: 출도본·발주서 기록 → 출도 후 변경 이슈(rd.issues에 더함) → 발주 후 변경 표지. 실패해도 검사는 이어간다."""
    import sys
    try:
        record_issued(state, rd)
        rd.issues += post_issue_issues(state, rd)
    except Exception as e:                       # 부가 판정 — 이것 때문에 검사·메일이 되돌려지면 안 된다
        print(f"경고: 출도 후 변경 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
    try:
        record_po(state, rd, project_of)
        po_mark_changes(state, rd, project_of)
    except Exception as e:
        print(f"경고: 발주 후 변경 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
