# -*- coding: utf-8 -*-
"""출도(발행) 폴더 · 출도 후 변경 · 발주 후 변경 (기능 검토 2026-11-02 J2·J8).

구매 결정 장면 — 외주처가 옛 판을 들고 있다, 이미 발주한 사양이 바뀌었다 — 이 지금 기능에 비어 있었다(DECISIONS 2026-11-02).
원칙 6 안: 의미(옳다/그르다)는 판단하지 않고 사실만 잇는다.
  · 출도 폴더에 들어온 판을 그 도면번호의 '출도본'으로 기록하고, 그 뒤 원본이 바뀌었는데 더 새 출도본이 없으면 '출도 후 변경'.
  · 발주서 행의 태그·품번을 기록하고, 발주 뒤 도면·BOM에서 그 태그·품번의 값이 바뀌면 그 변경에 '발주 후 변경' 표지.
감시는 읽기 전용 — 이 모듈은 state.db에만 쓴다. 금액 칸은 담지도 견주지도 않는다(DECISIONS 2026-10-19).
출도 폴더는 사용자가 정한다(설정 issued_folders). 폴더 이름 추정(suggest_issued_folders)은 화면의 제안일 뿐이다.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime, timezone
from pathlib import PurePosixPath

ISSUED_NAME_RE = re.compile(r"출도|발행|발송|배포|송부|issued?(?![a-z])|(?<![a-z])ifc(?![a-z])|for[\s_-]*construction",
                            re.IGNORECASE)
# 출도 낱말이 있어도 출도본 폴더가 아닌 것 — '발행 전 검토'·'고객 발송 사진'·'배포자료'·'출도 예정'·'출도대기' (제안에서만 뺀다,
# 사용자가 직접 정한 폴더는 그대로) (재검토 rr066 judge 9)
_NOT_ISSUED_TAIL = re.compile(r"전\s*검토|사진|자료|예정|대기|준비")
POST_ISSUE_CODE = "POST_ISSUE_CHANGE"
PO_MARK_KEY = "발주 후 변경"
# 금액 칸 — 담지도 견주지도 않는다 (DECISIONS 2026-10-19)
_AMOUNT_HEAD = re.compile(r"금액|단가|가격|합계|공급가|부가세|세액|VAT|AMOUNT|PRICE|TOTAL|COST|원\s*$", re.IGNORECASE)
_PART_HEAD = re.compile(r"품번|품목\s*코드|자재\s*코드|부품\s*번호|PART\s*(?:NO|NUMBER|#)|P/?N$|ITEM\s*(?:NO|CODE)|CODE\s*NO",
                        re.IGNORECASE)
_SPEC_HEAD = re.compile(r"규격|사양|SPEC|MODEL|모델|형식|정격|용량|RATING", re.IGNORECASE)
_NAME_HEAD = re.compile(r"품명|DESCRIPTION|명칭", re.IGNORECASE)          # 사양 칸이 없을 때만 보이는 이름
_DATE_RE = re.compile(r"(20\d{2})[-./년\s]+(\d{1,2})[-./월\s]+(\d{1,2})")


def _fold(s) -> str:
    return unicodedata.normalize("NFKC", str(s or "")).strip().casefold()


def issued_folders(cfg: dict | None) -> list[str]:
    """설정의 출도 폴더 목록 — 폴더 이름('출도') 또는 감시 폴더 기준 경로('P26-001/출도'). 옛 설치본에는 키가 없다(빈 목록)."""
    v = (cfg or {}).get("issued_folders")
    if isinstance(v, (str, bytes)):
        v = [v]
    if not isinstance(v, (list, tuple)):
        return []
    out = []
    for e in v:
        s = "/".join(_fold(e).split("\\")).strip("/ ")      # 읽기 전용 검사가 .replace 이름을 막는다 (test_readonly)
        if s and s not in out:
            out.append(s)
    return out


def in_issued_folder(path: str, cfg: dict | None) -> str | None:
    """이 경로가 출도 폴더 안이면 맞은 항목, 아니면 None. 이름 항목은 경로의 **폴더** 한 마디와 같아야 하고, 경로 항목은 그 마디들이
    이어서 나와야 한다(감시 폴더 라벨은 있어도 없어도)."""
    entries = issued_folders(cfg)
    if not entries:
        return None
    parts = [_fold(p) for p in PurePosixPath(str(path or "")).parent.parts]
    if not parts:
        return None
    for e in entries:
        ep = [x for x in e.split("/") if x]
        if not ep:
            continue
        n = len(ep)
        if any(parts[k:k + n] == ep for k in range(0, len(parts) - n + 1)):
            return e
    return None


def suggest_issued_folders(paths, cfg: dict | None = None, limit: int = 12) -> list[tuple[str, int]]:
    """감시 중인 파일 경로에서 출도·발행·Issued·IFC 같은 이름의 폴더를 찾아 (폴더 이름, 파일 수) — 제안만 한다(확정은 사용자)."""
    have = set(issued_folders(cfg))
    cnt: dict = {}
    shown: dict = {}
    for p in paths or ():
        seen = set()
        for part in PurePosixPath(str(p)).parent.parts[1:]:       # 감시 폴더 라벨은 빼고
            if ISSUED_NAME_RE.search(part) and not _NOT_ISSUED_TAIL.search(part):
                k = _fold(part)
                if k in have or k in seen:
                    continue
                seen.add(k)
                cnt[k] = cnt.get(k, 0) + 1
                shown.setdefault(k, part)
    return sorted(((shown[k], n) for k, n in cnt.items()), key=lambda t: (-t[1], t[0]))[:limit]


def doc_key(path: str, doc) -> str | None:
    """출도본과 원본을 잇는 도면번호 — 표제란 도면번호가 있으면 그것, 없으면 판 짝짓기와 같은 이름 줄기(Rev·날짜 꼬리 뺌)."""
    f = (getattr(doc, "fields", None) or {}).get("DWG_NO") if doc is not None else None
    v = getattr(f, "value", None) if f is not None else None
    if v and str(v).strip():
        return re.sub(r"\s+", "", _fold(v))
    from watcher.scan import pair_key
    k = pair_key(PurePosixPath(str(path)).name)
    return k or None


def _date_of(ts) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%m-%d")
    except (TypeError, ValueError, OSError, OverflowError):
        return "날짜 모름"


# ── 출도본 기록 · 출도 후 변경 ─────────────────────────────────────────────────────────────────

def record_issued(state, rd, project_of=None) -> int:
    """출도 폴더 안 파일의 처음 보는 판을 출도본으로 기록한다(귀속 함께 — 같은 프로젝트의 원본만 잇는다). 기록한 수."""
    cfg = getattr(rd, "cfg", None) or {}
    if not issued_folders(cfg):
        return 0
    have = {(p, s) for p, s in state.conn.execute("SELECT path, sha256 FROM issued_copies")}
    now = datetime.now(timezone.utc).isoformat()
    n = 0
    for r in rd.records or ():
        if (r.path, r.sha256) in have or not in_issued_folder(r.path, cfg):
            continue
        try:
            doc = rd.docs.get(r.path)
        except Exception:
            doc = None
        key = doc_key(r.path, doc)
        if not key:
            continue
        rev = getattr(doc, "revision", None) if doc is not None else None
        proj = _project(project_of, r.path, doc)
        state.conn.execute(
            "INSERT OR IGNORE INTO issued_copies (key, path, sha256, rev, saved, snapshot_id, at, project) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (key, r.path, r.sha256, rev, r.mtime, rd.snapshot_id, now, proj))
        n += 1
    if n:
        state.conn.commit()
    return n


def _project(project_of, path, doc):
    if project_of is None:
        return None
    try:
        return project_of(path, doc) or None
    except Exception:
        return None


def _same_scope(ipath: str, iproj, path: str, proj) -> bool:
    """출도본과 원본이 같은 프로젝트인가 — 둘 다 귀속이 있으면 귀속으로, 하나라도 없으면(옛 행·미분류) 같은 감시 폴더의 첫
    마디(경로 앞 두 마디)로. 키가 도면번호뿐이라 P26-091/작업/E-101 편집이 P26-090/출도/E-101을 근거로 카드가 됐다
    (재검토 rr066 judge 2)."""
    if iproj and proj:
        return _fold(iproj) == _fold(proj)
    return PurePosixPath(str(ipath)).parts[:2] == PurePosixPath(str(path)).parts[:2]


def _latest_issued(state) -> dict:
    """도면번호 → 출도본 목록 [(snapshot_id, path, sha, rev, saved, id, project)], 나중 것이 앞."""
    out: dict = {}
    for key, path, sha, rev, saved, snap, iid, proj in state.conn.execute(
            "SELECT key, path, sha256, rev, saved, snapshot_id, id, project FROM issued_copies"):
        out.setdefault(key, []).append((snap or 0, path, sha, rev, saved, iid, proj))
    for v in out.values():
        v.sort(key=lambda e: (e[0], e[5]), reverse=True)
    return out


def _pick_issued(latest: dict, key, path: str, proj) -> tuple | None:
    """그 원본과 같은 프로젝트의 가장 나중 출도본."""
    for e in (latest.get(key) or ()) if key else ():
        if _same_scope(e[1], e[6], path, proj):
            return e
    return None


def _rev_lower(a, b) -> bool:
    """출도본 Rev a가 원본 Rev b보다 낮은가 — 같은 모양끼리만 견준다(모르면 낮다고 하지 않는다)."""
    from watcher.scan import rev_key, rev_shape
    a, b = str(a or "").strip(), str(b or "").strip()
    if not a or not b:
        return False
    sa, sb = rev_shape(a), rev_shape(b)
    try:
        return sa is not None and sa == sb and rev_key(a) < rev_key(b)
    except TypeError:
        return False


def resolve_reissued(state, rd, latest: dict | None = None) -> int:
    """열린 '출도 후 변경' 가운데 그 뒤 같은 프로젝트의 새 출도본이 들어온 것을 닫는다 — 새 출도가 곧 해소다. 그 출도본의 Rev가
    원본 지금 Rev보다 낮으면(옛 판을 늦게 플롯해 넣음) 해소가 아니다. 닫은 수."""
    latest = _latest_issued(state) if latest is None else latest
    if not latest:
        return 0
    now = datetime.now(timezone.utc).isoformat()
    n = 0
    for iid, path, snap, proj in state.conn.execute(
            "SELECT id, path, snapshot_id, project FROM issues WHERE code = ? AND resolved_at IS NULL",
            (POST_ISSUE_CODE,)).fetchall():
        try:
            doc = rd.docs.get(path)
        except Exception:
            doc = None
        key = doc_key(path, doc)
        cur = _pick_issued(latest, key, path, proj)
        if cur is None or (cur[0] or 0) <= (snap or 0):
            continue
        if doc is not None and _rev_lower(cur[3], getattr(doc, "revision", None)):
            continue
        why = f"자동 해소 — 새 출도본이 들어옴 ({PurePosixPath(cur[1]).name}" + (f", Rev {cur[3]}" if cur[3] else "") + ")"
        state.conn.execute("UPDATE issues SET resolved_at = ?, resolved_by = ? WHERE id = ?", (now, why, iid))
        n += 1
    if n:
        state.conn.commit()
    return n


def _issued_doc(state, sha, path):
    try:
        d = state.load_extract(sha, path)
        if not d or d.get("extract_failed") or d.get("fields") is None:
            return None
        from watcher.extract.base import Document
        return Document.from_dict(d)
    except Exception:
        return None


def _norm_v(s) -> str:
    return re.sub(r"\s+", " ", _fold(s)).strip()


def _issued_value(idoc, cur_doc, it) -> tuple[str | None, str]:
    """변경 항목 it의 같은 자리 값을 출도본에서 — (출도본 값 또는 None, 이름표). 같은 칸(표제란 칸·표 행 열)이면 그 값, 태그가
    있으면 출도본에서 그 태그 조각. 못 찾으면 None — 원본 직전 값을 출도본 값이라 적지 않는다 (재검토 rr066 judge 3, 원칙 4)."""
    if idoc is None:
        return None, ""
    kind, key = str(getattr(it, "kind", "") or ""), str(getattr(it, "key", "") or "")
    try:
        if kind.startswith("FIELD_"):
            f = (idoc.fields or {}).get(key)
            return (str(f.value) if f is not None and f.value is not None else None), key
        if kind.startswith("ROW_"):
            rk, sep, col = key.rpartition(".")
            if sep:
                for row in idoc.rows or ():
                    if str(row.key) == rk and col in (row.values or {}):
                        v = row.values.get(col)
                        return (str(v) if v is not None else None), f"{rk} {col}"
            return None, ""
        from watcher.consistency import _tag_segment, tag_lines_with_specs
        from watcher.extract.base import find_tags
        old, new = str(it.old or ""), str(it.new or "")
        tags = list(dict.fromkeys(find_tags(f"{old} {new} {getattr(it, 'label', '') or ''}".upper())))
        if not tags and cur_doc is not None and new.strip():
            tags = [t for t, lines in tag_lines_with_specs(cur_doc).items()
                    if any(new.strip() in str(getattr(ln, "text", "") or "") for ln in lines)]
        tag = tags[0] if len(tags) == 1 else ""
        if tag:
            for ln in tag_lines_with_specs(idoc).get(tag) or ():
                seg = _tag_segment(tag, str(getattr(ln, "text", "") or "")).strip(" :：-")
                if seg:
                    return seg, tag
        # 같은 형식의 출도본(DXF 원본을 그대로 복사해 둔 출도본 등)이면 출도본 → 원본 지금 판을 견주어 같은 자리의 값을 읽는다 —
        # 사양 글자가 태그와 따로 놓인 도면은 태그 줄에 값이 없다
        if cur_doc is not None and getattr(idoc, "doc_type", None) == getattr(cur_doc, "doc_type", None):
            from watcher.diff import content_items, diff_documents
            same = [x for x in content_items(diff_documents(idoc, cur_doc))
                    if str(getattr(x, "key", "")) == key and str(getattr(x, "where", "")) == str(getattr(it, "where", ""))]
            if len(same) == 1 and str(same[0].new or "") == new:
                return str(same[0].old or ""), tag
            if not same and any(new.strip() and new.strip() in str(getattr(ln, "text", "") or "")
                                for ln in (idoc.raw_texts or ())):
                return new, tag             # 출도본에도 지금 값 그대로 있다 — 출도본과 어긋난 값이 아니다
        return None, tag
    except Exception:
        return None, ""


def post_issue_issues(state, rd, project_of=None) -> list:
    """출도 뒤 원본이 바뀌었는데 더 새 출도본이 없는 파일의 검토 필요. 근거: 출도본(이름·Rev·날짜·경로), 원본에서 바뀐 값
    (출도본 값 → 원본 지금 값, 위치 — 출도본에서 못 찾은 값은 그렇다고 적고 원본 직전 값 → 지금 값). 같은 검사에 새 출도본이 들어온
    도면은 그것이 새 출도다 — 단 그 출도본 Rev가 원본 지금 Rev보다 낮으면 새 출도가 아니다(옛 판을 늦게 넣음)."""
    cfg = getattr(rd, "cfg", None) or {}
    if not issued_folders(cfg) or getattr(rd, "is_baseline", False):
        return []
    latest = _latest_issued(state)
    resolve_reissued(state, rd, latest)
    if not latest:
        return []
    from watcher.brief import short_pair
    from watcher.consistency import Issue, _fmt_item
    from watcher.diff import content_items
    open_paths = {p for (p,) in state.conn.execute(
        "SELECT path FROM issues WHERE code = ? AND resolved_at IS NULL", (POST_ISSUE_CODE,))}
    out = []
    for c in rd.changes or ():
        if c.kind != "modified" or in_issued_folder(c.path, cfg):
            continue
        try:
            doc = rd.docs.get(c.path)
        except Exception:
            doc = None
        key = doc_key(c.path, doc)
        if not key or key not in latest:
            continue
        iss = _pick_issued(latest, key, c.path, _project(project_of, c.path, doc))
        if iss is None or iss[2] == c.new_sha256:
            continue
        if (iss[0] or 0) >= (rd.snapshot_id or 0) and not _rev_lower(iss[3], getattr(doc, "revision", None)):
            continue                     # 같은 검사에 들어온 새 출도본 — 그것이 새 출도다
        content = content_items((rd.details or {}).get(c.path) or [])
        if not content and c.path not in open_paths:
            continue
        _snap, ipath, isha, rev, saved, _iid, _ip = iss
        date = _date_of(saved)
        idoc = _issued_doc(state, isha, ipath) if content else None
        lines, pairs = [], []
        for i in content:
            iv, name = _issued_value(idoc, doc, i)
            if iv is not None:
                nv = str(i.new or "")
                if name and name in nv.upper():          # 태그 줄이면 그 태그 조각만 — 'M-101 7.5kW 4P' → '7.5kW 4P'
                    from watcher.consistency import _tag_segment
                    nv = _tag_segment(name, nv).strip(" :：-") or nv
                pairs.append((iv, nv, name))
                lines.append(f"{name + ': ' if name else ''}출도본 {iv or '—'} → 원본 지금 {nv or '—'} ({getattr(i, 'where', '') or ''})")
            else:
                lines.append("출도본 값 확인 불가 — 원본 직전 값 → 지금 값: " + _fmt_item(i))
        if content and len(pairs) == len(content) and all(_norm_v(a) == _norm_v(b) for a, b, _n in pairs) \
                and c.path not in open_paths:
            continue                     # 바뀐 값이 모두 출도본과 같아졌다 — 출도본과 어긋난 것이 없다
        if content:
            first = pairs[0] if pairs else (content[0].old, content[0].new, "")
            summary = short_pair(first[0], first[1], 30) + (f" 외 {len(content) - 1}건" if len(content) > 1 else "")
        else:
            summary = "글자·표 변경 없음"
        ev = [f"출도본: {PurePosixPath(ipath).name} — Rev {rev or '-'} · 저장 {date} ({ipath})",
              "원본에서 바뀐 값 (출도본 값 → 원본 지금 값, 위치):" if content else "이번 변경: 글자·표 변경 없음 — 새 출도본이 아직 없습니다"]
        _now_rev = getattr(doc, "revision", None) if doc is not None else None
        if _now_rev and rev and _rev_lower(rev, _now_rev):
            ev.insert(1, f"원본은 지금 Rev {_now_rev} — 출도본(Rev {rev})보다 새 판입니다")
        ev += lines[:5]
        if len(content) > 5:
            ev.append(f"외 {len(content) - 5}건 — 변경 상세에 모두 있습니다")
        out.append(Issue(POST_ISSUE_CODE, c.path,
                         f"출도 후 변경 — 출도본은 Rev {rev or '-'}({date} 출도), 원본에서 바뀐 값({summary})이 "
                         f"새 출도본에 없습니다.", tuple(ev)))
    return out


# ── 발주서 행 · 발주 후 변경 ────────────────────────────────────────────────────────────────────

# 이름에 '발주'가 있어도 발주서가 아닌 엑셀 — 현황판·예정표·목록·대장·계획 (재검토 rr066 judge 7)
_NOT_PO_NAME = re.compile(r"현황|예정|목록|대장|계획")
# 발주서임을 말하는 내용 제목 — 'PO NO'·'P/O No.'·'발주번호'·'PURCHASE ORDER'·'발 주 서'
_PO_TITLE = re.compile(r"(?<![A-Z])P\s*/?\s*O\s*\.?\s*(?:NO|#|번호)|발\s*주\s*(?:번\s*호|서)|PURCHASE\s*ORDER", re.IGNORECASE)


def _po_content(doc) -> bool:
    """발주서라고 볼 내용 근거 — 돈 칸(금액·단가 머리)·돈 줄·발주서 제목 중 하나."""
    from watcher.doctype import money_head_line, money_line
    for row in (getattr(doc, "rows", None) or ())[:400]:
        vals = getattr(row, "values", None) or {}
        if any(_AMOUNT_HEAD.search(str(h or "")) and str(v or "").strip() for h, v in vals.items()):
            return True
        if any(_PO_TITLE.search(str(h or "")) for h in vals):
            return True
    texts = [str(getattr(t, "text", "") or "") for t in (getattr(doc, "raw_texts", None) or ())[:400]]
    texts += [f"{k} {getattr(f, 'value', '')}" for k, f in (getattr(doc, "fields", None) or {}).items()]
    return any(_PO_TITLE.search(t) or money_line(t) or money_head_line(t) for t in texts)


def is_po(path: str, doc, cfg: dict | None) -> bool:
    """발주서 엑셀인가. 이름·폴더('발주')만으로 정하지 않는다 — '자재 발주 현황.xlsx'·'발주 예정 목록.xlsx'(금액 없음)가 발주서로
    기록돼 발주일=처음 본 날로 '발주 후 변경' 표지가 붙었다 (재검토 rr066 judge 7). 내용(doc)이 없으면 '읽어 볼 만한가'만 답한다."""
    if PurePosixPath(str(path)).suffix.lower() not in (".xlsx", ".xlsm"):
        return False
    if _NOT_PO_NAME.search(PurePosixPath(str(path)).stem):
        return False
    try:
        from watcher.doctype import canonical, commercial_kind, kind_of
        named = canonical(kind_of(path, cfg) or "") == "발주서"
        if doc is None:
            return named
        if not (named or commercial_kind(path, doc) == "발주서"):
            return False
        return _po_content(doc)
    except Exception:
        return False


def _po_rows(doc) -> list[tuple[str, str, str]]:
    """발주서 행 → [(행 자리, 태그·품번(접은 꼴), 사양 글)]. 금액 칸은 뺀다."""
    from watcher.extract.base import ROWKEY_TAG_KEYS, find_tags, head_key
    out = []
    for row in getattr(doc, "rows", None) or ():
        vals = getattr(row, "values", None) or {}
        keys: list = []
        spec, name, other = "", "", []
        for h, v in vals.items():
            sv = str(v or "").strip()
            if not sv or _AMOUNT_HEAD.search(str(h or "")):
                continue
            if head_key(h) in ROWKEY_TAG_KEYS or _PART_HEAD.search(str(h or "")):
                keys.append(sv)
            elif _SPEC_HEAD.search(str(h or "")) and not spec:
                spec = sv
            elif _NAME_HEAD.search(str(h or "")) and not name:
                name = sv
            else:
                other.append(sv)
            keys += find_tags(sv)
        keys = [k for k in dict.fromkeys(re.sub(r"\s+", "", _fold(k)) for k in keys) if len(k) >= 3]
        if not keys:
            continue
        where = str(getattr(row, "where", "") or "")
        shown = spec or name or (other[0] if other else "")
        for k in keys:
            out.append((where, k, shown[:60]))
    return out


# 발주일의 출처 꼬리 — po_lines.ordered는 'YYYY-MM-DD|칸'(시트 날짜 칸) 또는 'YYYY-MM-DD|저장'(파일 저장 시각으로 추정), 모르면 NULL.
# 꼬리 없는 옛 값은 예전 판이 '처음 본 검사일'로 채웠을 수 있어 한 번 다시 읽는다(record_po)
OD_SHEET, OD_SAVED = "칸", "저장"


def _order_date(state, path: str, doc, mtime: float | None = None) -> str | None:
    """발주일 — 시트의 날짜 칸이 먼저, 없으면 파일 저장 시각(이 경로가 기록된 가장 이른 판의 수정 시각), 그것도 없으면 None(발주일
    모름). 처음 본 검사일(MIN(detected_at))을 발주일로 쓰면 설치 첫날 검사일이 모든 발주서의 발주일이 됐다 (ux20 daily 4)."""
    f = (getattr(doc, "fields", None) or {}).get("DATE") if doc is not None else None
    m = _DATE_RE.search(str(getattr(f, "value", "") or "")) if f is not None else None
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))).strftime("%Y-%m-%d") + "|" + OD_SHEET
        except ValueError:
            pass
    ts = [t for t in (mtime,) if t]
    try:
        row = state.conn.execute("SELECT MIN(mtime) FROM files WHERE path = ?", (path,)).fetchone()
        if row and row[0]:
            ts.append(float(row[0]))
    except Exception:
        pass
    ts = [t for t in ts if t > 0]
    if ts:
        try:
            return datetime.fromtimestamp(min(ts)).strftime("%Y-%m-%d") + "|" + OD_SAVED
        except (OverflowError, OSError, ValueError):
            pass
    return None


def order_day(od) -> str:
    """po_lines.ordered → 'YYYY-MM-DD' (모르면 '')."""
    return str(od or "")[:10] if re.match(r"\d{4}-\d{2}-\d{2}", str(od or "")) else ""


def order_phrase(od) -> str:
    """발주 후 변경 표지에 싣는 발주일 말 — 추정이면 추정이라고 밝힌다."""
    day = order_day(od)
    if not day:
        return "발주일 모름"
    if str(od).endswith("|" + OD_SAVED):
        return f"발주일 칸 없음 · 파일 저장 {day[5:]}"
    return f"{day[5:]} 발주"


def record_po(state, rd, project_of=None) -> int:
    """발주서의 행(태그·품번·사양·발주일)을 기록한다 — 바뀐 발주서·처음 보는 발주서만 다시 읽는다. 기록한 발주서 수."""
    cfg = getattr(rd, "cfg", None) or {}
    # 지워진(또는 옮겨진) 발주서의 행은 지운다 — 지운 파일을 근거로 '발주 후 변경' 표지가 붙었다 (재검토 rr066 judge 8).
    # 옮긴 발주서는 새 경로에서 다시 읽는다(아래 '오늘 바뀐 파일'). 못 읽은·이월된 파일은 스냅샷에 남아 지우지 않는다
    gone = {c.path for c in (rd.changes or ()) if c.kind == "removed"}
    # 옛 판이 이름만으로 발주서로 기록한 현황판·예정표·목록 — 파일이 안 바뀌면 다시 읽지 않으므로 여기서 거둔다
    gone |= {p for (p,) in state.conn.execute("SELECT DISTINCT path FROM po_lines")
             if _NOT_PO_NAME.search(PurePosixPath(str(p)).stem)}
    if gone:
        for p_ in gone:
            state.conn.execute("DELETE FROM po_lines WHERE path = ?", (p_,))
        state.conn.commit()
    have = {p: s for p, s in state.conn.execute("SELECT path, MAX(sha256) FROM po_lines GROUP BY path")}
    # 꼬리 없는 옛 발주일(예전 판 — 처음 본 검사일이었을 수 있다)은 파일이 안 바뀌어도 한 번 다시 읽는다 (ux20 daily 4)
    legacy = {p for (p,) in state.conn.execute(
        "SELECT DISTINCT path FROM po_lines WHERE ordered IS NOT NULL AND ordered NOT LIKE '%|%'")}
    changed = {c.path for c in (rd.changes or ()) if c.kind in ("added", "modified")}
    n = 0
    for r in rd.records or ():
        if PurePosixPath(r.path).suffix.lower() not in (".xlsx", ".xlsm"):
            continue
        if have.get(r.path) == r.sha256 and r.path not in legacy:
            continue
        # 이름·폴더로 발주서인 것, 아니면 오늘 바뀌었거나 이미 발주서로 기록된 것만 내용을 읽는다 — 엑셀마다 날마다 기록을 올리지 않게
        if not (is_po(r.path, None, cfg) or r.path in changed or r.path in have):
            continue
        try:
            doc = rd.docs.get(r.path)
        except Exception:
            doc = None
        if doc is None or not is_po(r.path, doc, cfg):
            if doc is not None and r.path in have:   # 고쳐서 더는 발주서가 아니다 — 옛 행을 남기지 않는다(못 읽은 날은 그대로)
                state.conn.execute("DELETE FROM po_lines WHERE path = ?", (r.path,))
                n += 1
            continue
        rows = _po_rows(doc)
        ordered = _order_date(state, r.path, doc, getattr(r, "mtime", None))
        proj = None
        if project_of is not None:
            try:
                proj = project_of(r.path, doc)
            except Exception:
                proj = None
        keep = {(w, k) for w, k, _s in rows}
        for w, k in state.conn.execute("SELECT row, tag FROM po_lines WHERE path = ?", (r.path,)).fetchall():
            if (w, k) not in keep:
                state.conn.execute("DELETE FROM po_lines WHERE path = ? AND row = ? AND tag = ?", (r.path, w, k))
        for w, k, sp in rows:
            state.conn.execute("INSERT OR IGNORE INTO po_lines (path, row, tag, spec, ordered, snapshot_id, project, sha256) "
                               "VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (r.path, w, k, sp, ordered, rd.snapshot_id, proj, r.sha256))
            state.conn.execute("UPDATE po_lines SET spec = ?, ordered = ?, project = ?, sha256 = ? "
                               "WHERE path = ? AND row = ? AND tag = ?", (sp, ordered, proj, r.sha256, r.path, w, k))
        n += 1
    if n:
        state.conn.commit()
    return n


def _row_label(where: str) -> str:
    m = re.search(r"행\s*(\d+)", where or "")
    return f"{m.group(1)}행" if m else (where or "")


def po_mark_changes(state, rd, project_of=None) -> int:
    """발주 뒤 도면·BOM에서 발주서 행의 태그·품번 값이 바뀐 변경에 '발주 후 변경' 표지를 단다. 단 변경 수."""
    rows = state.conn.execute("SELECT path, row, tag, spec, ordered, snapshot_id, project FROM po_lines").fetchall()
    if not rows:
        return 0
    from watcher.brief import short_pair
    from watcher.consistency import strip_commerce
    from watcher.diff import ChangeItem
    from watcher.extract.base import find_tags
    today = datetime.now().strftime("%Y-%m-%d")
    by_tag: dict = {}
    for path, w, k, sp, od, snap, proj in rows:
        # 발주가 이 검사 **전**이어야 '발주 후' — 같은 검사에서 처음 본 발주서는 발주일이 오늘보다 앞설 때만
        if (snap or 0) >= (rd.snapshot_id or 0) and not (order_day(od) and order_day(od) < today):
            continue
        by_tag.setdefault(k, []).append((path, w, sp, od, proj))
    if not by_tag:
        return 0
    part_keys = [k for k in by_tag if not find_tags(k.upper())]
    po_paths = {r[0] for r in rows}
    n = 0
    for c in rd.changes or ():
        if c.kind != "modified" or c.path in po_paths:
            continue
        items = (rd.details or {}).get(c.path)
        if not items:
            continue
        mine = None
        hits: list = []
        for it in list(items):
            kind = getattr(it, "kind", "")
            if kind not in ("TEXT_CHANGED", "ROW_CHANGED"):
                continue
            key = str(getattr(it, "key", "") or "")
            if kind == "ROW_CHANGED" and _AMOUNT_HEAD.search(key.rpartition(".")[2]):
                continue                              # 금액 칸은 견주지 않는다
            old, new = str(it.old or ""), str(it.new or "")
            if strip_commerce(old) == strip_commerce(new):
                continue
            # DXF의 사양 글자만 바뀐 줄은 태그가 따로 있다 — 이름표('M-101: 5.5kW → 7.5kW', cli._pair_spec_tags)도 본다
            text = (f"{key} {old} {new}" if kind == "ROW_CHANGED" else f"{old} {new}") + " " + str(getattr(it, "label", "") or "")
            found = {re.sub(r"\s+", "", _fold(t)) for t in find_tags(text.upper())}
            ft = _fold(text)
            found |= {k for k in part_keys if re.search(r"(?<![0-9a-z가-힣-])" + re.escape(k) + r"(?![0-9a-z가-힣])", ft)}
            for k in sorted(found & set(by_tag)):
                for po in by_tag[k]:
                    if mine is None and project_of is not None:
                        try:
                            mine = project_of(c.path, (rd.docs or {}).get(c.path)) or ""
                        except Exception:
                            mine = ""
                    if po[4] and mine and _fold(po[4]) != _fold(mine):
                        continue                      # 다른 프로젝트의 같은 태그 — 다른 기기다
                    if (not po[4] or not mine) and PurePosixPath(po[0]).parts[:2] != PurePosixPath(c.path).parts[:2]:
                        continue
                    hits.append((k, po, it))
        if not hits:
            continue
        have = {str(getattr(i, "new", "")) for i in items if getattr(i, "key", "") == PO_MARK_KEY}
        added = 0
        for k, (ppath, w, sp, od, _pj), it in hits:
            line = (f"{PurePosixPath(ppath).name} {_row_label(w)}({(sp or k.upper())[:24]}, {order_phrase(od)}) — 발주 뒤 바뀐 값: "
                    f"{short_pair(it.old, it.new, 40)} ({getattr(it, 'where', '') or ''})")
            if line in have or added >= 3:
                continue
            have.add(line)
            items.append(ChangeItem("CHECK_SKIPPED", PO_MARK_KEY, None, line, "발주 대조"))
            added += 1
        if added:
            n += 1
    return n


def po_marked(items) -> bool:
    """이 변경에 '발주 후 변경' 표지가 있나 — 구매 담당 수신자 분기용."""
    return any(getattr(i, "kind", "") == "CHECK_SKIPPED" and getattr(i, "key", "") == PO_MARK_KEY for i in (items or ()))


def track(state, rd, project_of=None) -> None:
    """검사 한 회분: 출도본·발주서 기록 → 출도 후 변경 이슈(rd.issues에 더함) → 발주 후 변경 표지. 실패해도 검사는 이어간다."""
    import sys
    try:
        record_issued(state, rd, project_of)
        rd.issues += post_issue_issues(state, rd, project_of)
    except Exception as e:                       # 부가 판정 — 이것 때문에 검사·메일이 되돌려지면 안 된다
        print(f"경고: 출도 후 변경 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
    try:
        record_po(state, rd, project_of)
        po_mark_changes(state, rd, project_of)
    except Exception as e:
        print(f"경고: 발주 후 변경 확인 실패(검사는 계속): {type(e).__name__}: {e}", file=sys.stderr)
