# -*- coding: utf-8 -*-
"""양식함 자동 비교의 '근거 표' 만들기 — 감시 엔진(extract → diff_documents)의 결과를 사람이 읽는 줄로 (F3, 2026-10-28).

- 이 모듈은 추출 자식 프로세스(watcher/worker.py의 form_compare·form_summary 요청) 안에서 돈다. 파일을 읽지도 쓰지도 않는다 —
  이미 추출된 Document와 ChangeItem만 받아 JSON으로 보낼 수 있는 사전으로 바꾼다.
- 저장소(store)·쓰기 문(guard)을 import 하지 않는다 — 감시 쪽 자식이 양식함 쓰기 문을 쥐지 않게.
- 값은 그대로 글자로 돌려준다(HTML 아님). 화면은 server.py가 html.escape 해서 그린다.
"""

from __future__ import annotations

from difflib import SequenceMatcher

# 항목 종류 → (화면 이름, 색 갈래). 감시 화면(web._WEB_ITEM_KIND)과 같은 말 — web.py는 import하지 않고 옮겨 적는다.
#   add 추가 / mod 변경 / rm 삭제 / info 이동·참고
KIND_TEXT = {
    "FIELD_CHANGED": ("값 변경", "mod"),
    "FIELD_ADDED": ("값 추가", "add"),
    "FIELD_REMOVED": ("값 삭제", "rm"),
    "ROW_ADDED": ("행 추가", "add"),
    "ROW_REMOVED": ("행 삭제", "rm"),
    "ROW_CHANGED": ("행 값 변경", "mod"),
    "ROW_MOVED": ("행 순서", "info"),
    "TEXT_CHANGED": ("글자 변경", "mod"),
    "TEXT_ADDED": ("글자 추가", "add"),
    "TEXT_REMOVED": ("글자 삭제", "rm"),
    "TEXT_MOVED": ("문단 이동", "info"),
    "COL_RENAMED": ("열 이름 변경", "mod"),
    "COL_ADDED": ("열 추가", "add"),
    "COL_REMOVED": ("열 삭제", "rm"),
    "COL_MOVED": ("열 이동", "info"),
    "SHEET_ADDED": ("시트 추가", "add"),
    "SHEET_REMOVED": ("시트 삭제", "rm"),
    "SHEET_RENAMED": ("시트 이름 변경", "mod"),
    "PAGE_ADDED": ("페이지 추가", "add"),
    "PAGE_REMOVED": ("페이지 삭제", "rm"),
    "PAGE_MOVED": ("페이지 순서", "info"),
    "PAGE_VISUAL_CHANGED": ("그림 변경", "mod"),
    "EMBED_CHANGED": ("그림·개체 변경", "mod"),
    "REVROW_ADDED": ("개정표 행 추가", "add"),
    "REVROW_REMOVED": ("개정표 행 삭제", "rm"),
    "REVROW_CHANGED": ("개정표 행 변경", "mod"),
}
_WORD_KINDS = ("FIELD_CHANGED", "TEXT_CHANGED", "ROW_CHANGED", "REVROW_CHANGED", "COL_RENAMED", "SHEET_RENAMED")
MAX_VALUE = 2000            # 한 칸 글자 상한 — 근거 표가 끝없이 길어지지 않게
MAX_ROWS = 500              # 근거 표 줄 상한 (넘으면 '외 N건')


def _text(v) -> str:
    """값 → 글자. 리비전 행처럼 사전이면 '칸: 값 · …'. 비면 ''."""
    if v is None:
        return ""
    if isinstance(v, str) and v.startswith("{") and v.endswith("}"):
        try:
            import ast
            parsed = ast.literal_eval(v)
            if isinstance(parsed, dict):
                v = parsed
        except Exception:
            pass
    if isinstance(v, dict):
        s = " · ".join(f"{k}: {x}" for k, x in v.items() if x not in (None, ""))
    elif isinstance(v, (list, tuple)):
        s = " · ".join(str(x) for x in v)
    else:
        s = str(v)
    return s if len(s) <= MAX_VALUE else s[:MAX_VALUE] + "…"


def word_segments(old: str, new: str) -> tuple[list, list]:
    """두 글자의 낱말 단위 차이 → ([[조각, 바뀜?], …] 이전, 같은 꼴 새 값). 낱말 하나짜리 긴 값은 글자 단위.
    화면은 바뀐 조각만 따로 강조한다 (감시 화면의 word_diff_html과 같은 생각)."""
    if not old or not new or old == new:
        return [[old, False]] if old else [], [[new, False]] if new else []
    ot, nt = old.split(), new.split()
    char_mode = len(ot) <= 1 and len(nt) <= 1 and max(len(old), len(new)) > 8 \
        and not any(ch.isdigit() for ch in old + new)
    if char_mode:
        ot, nt, joiner = list(old), list(new), ""
    else:
        joiner = " "
    if len(ot) * len(nt) > 250000:
        return [[old, True]], [[new, True]]
    sm = SequenceMatcher(None, ot, nt, autojunk=False)
    os_, ns_ = [], []

    def push(side, text, changed):
        # 낱말 사이 띄어쓰기는 바뀌지 않은 조각 쪽에 붙인다 — 강조 칸이 공백부터 칠해지지 않게
        if not text:
            return
        if side and side[-1][1] == changed:
            side[-1][0] += joiner + text
        elif side and changed:
            side[-1][0] += joiner
            side.append([text, True])
        elif side:
            side.append([joiner + text, False])
        else:
            side.append([text, changed])
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            push(os_, joiner.join(ot[i1:i2]), False)
            push(ns_, joiner.join(nt[j1:j2]), False)
            continue
        push(os_, joiner.join(ot[i1:i2]), True)
        push(ns_, joiner.join(nt[j1:j2]), True)
    return os_, ns_


def _name_of(i) -> str:
    """항목 이름 — 표제란 칸은 사람이 읽는 이름, 긴 글줄 열쇠는 낱말 경계에서 자른다."""
    k = str(getattr(i, "key", "") or "")
    if i.kind == "FIELD_CHANGED" or i.kind.startswith("FIELD_"):
        from watcher.diff import field_label
        return field_label(k)
    if i.kind.startswith("TEXT_") and len(k) >= 30:
        cut = k.rfind(" ", 0, 30)
        return (k[:cut] if cut >= 10 else k[:30]).rstrip(" ,.:;") + "…"
    return k


def describe(items) -> tuple[list, list]:
    """ChangeItem 목록 → (근거 표 줄들, 참고 글들).

    줄: {kind, kind_label, tone, name, label, old, new, where, old_parts, new_parts}.
    '참고'(CHECK_SKIPPED — 검사 한계 고지)는 표가 아니라 참고 글로 뺀다. 진짜 내용 변경이 먼저, 표제란·개정표는 뒤로."""
    rows, notes = [], []
    for i in items:
        if i.kind == "CHECK_SKIPPED":
            t = _text(i.new) or _text(i.old)
            if t:
                notes.append(t)
            continue
        label, tone = KIND_TEXT.get(i.kind, (i.kind, "info"))
        old, new = _text(i.old), _text(i.new)
        if i.kind in _WORD_KINDS and old and new:
            op, np_ = word_segments(old, new)
        else:
            op, np_ = ([[old, False]] if old else []), ([[new, False]] if new else [])
        rows.append({"kind": i.kind, "kind_label": label, "tone": tone, "name": _name_of(i),
                     "label": _text(getattr(i, "label", None)), "old": old, "new": new,
                     "where": _text(i.where), "old_parts": op, "new_parts": np_})
    rows.sort(key=lambda r: 1 if (r["kind"].startswith(("FIELD_", "REVROW_"))) else 0)
    if len(rows) > MAX_ROWS:
        more = len(rows) - MAX_ROWS
        rows = rows[:MAX_ROWS]
        notes.append(f"변경이 많아 앞의 {MAX_ROWS}건만 보입니다 (외 {more}건) — 파일을 내려받아 확인하세요")
    return rows, notes


def summarize(doc) -> dict:
    """새 양식 요약 — 비교할 이전 판이 없을 때 검토자가 무엇이 든 양식인지 알게.
    {doc_type, sheets, headers: [[시트, [칸…]]…], fields: [[이름, 값]…], lines: [글줄…], row_count, notes}"""
    from watcher.diff import field_label
    headers = []
    for sheet, cols in list((getattr(doc, "headers", None) or {}).items())[:6]:
        cs = [str(c) for c in (cols or []) if str(c or "").strip()][:16]
        if cs:
            headers.append([str(sheet), cs])
    if not headers and doc.rows:                          # 머리글 정보가 없는 형식(워드 표 등)은 첫 행의 칸 이름
        cols = [str(c) for c in (doc.rows[0].values or {}).keys()][:16]
        if cols:
            headers.append(["표", cols])
    sheets = []
    for r in doc.rows or []:
        s = str(r.key).split("!", 1)[0] if "!" in str(r.key) else ""
        if s and s not in sheets:
            sheets.append(s)
    for s, _ in headers:
        if s not in sheets and s != "표":
            sheets.append(s)
    fields = [[field_label(k), _text(f.value)[:200]] for k, f in list((doc.fields or {}).items())[:10]
              if _text(f.value).strip()]
    lines = []
    for t in doc.raw_texts or []:
        s = " ".join(str(t.text or "").split())
        if s and s not in lines:
            lines.append(s[:200])
        if len(lines) >= 10:
            break
    return {"doc_type": str(doc.doc_type or ""), "sheets": sheets[:12], "headers": headers, "fields": fields,
            "lines": lines, "row_count": len(doc.rows or []), "notes": [str(n)[:300] for n in (doc.notes or [])][:5]}
