# -*- coding: utf-8 -*-
"""양식함 쓰기의 유일한 문 (FORMS.md 5절, 2026-10-28 F1).

Drev 안에서 파일을 쓰는·지우는 코드는 감시와 무관한 이 모듈 하나뿐이다. 허용 뿌리(보관소
`forms_store`, 선택적 현행 미러) 밖으로는 한 바이트도 쓰지 못한다:

- 경로는 **resolve 뒤** 뿌리 안인지 비교한다(대소문자·슬래시 차이 무시, 드라이브가 다르면 거부).
- 뿌리 아래 경로 성분 가운데 심볼릭 링크·정션(재분석 지점)이 하나라도 있으면 거부한다.
- 성분 이름은 '..'·'.'·예약 이름(CON·NUL·COM1…)·제어문자·금지 문자(<>:"/\\|?*)·
  끝 공백·끝 점을 거부한다. `\\\\?\\`·`\\\\.\\` 장치 경로와 드라이브 상대 경로(`C:abc`)도 거부한다.
- 쓰기는 원자적이다: 같은 폴더의 임시 파일에 쓰고 fsync 한 뒤 os.replace (또는 덮어쓰지 않는 이름 바꾸기).
- 지우기·덮어쓰기는 **Drev가 둔 파일만** — 호출하는 쪽이 기대 지문(sha256)을 대야 하고, 다르면 거부한다.
- 폴더 지우기는 허용 뿌리 안의 **빈 폴더 하나**만(remove_empty_dir, 2026-10-28 보안 F7) — 비었는지는 os.rmdir가 판정한다.

tests/test_readonly.py 는 이 모듈만 좁은 예외로 둔다(쓰기 이름 몇 개만 허용, 나머지 금지는 그대로).
"""

from __future__ import annotations

import hashlib
import os
import re
import secrets
import stat
import sys
import unicodedata
from pathlib import Path

FILE_ATTRIBUTE_REPARSE_POINT = 0x400

# 끝 공백·점과 함께 Windows가 이름으로 받지 않거나 장치로 해석하는 것들
_RESERVED = ({"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$", "CLOCK$"}
             | {f"COM{i}" for i in "123456789¹²³"}
             | {f"LPT{i}" for i in "123456789¹²³"})
_BAD_CHARS = set('<>:"/\\|?*')
_DEVICE_PREFIXES = ("\\\\?\\", "\\\\.\\", "//?/", "//./", "\\??\\")
MAX_NAME = 200
# 디스크를 꽉 채워 감시 DB·윈도우가 멎지 않게 남겨 둘 여유 (2026-10-28 F1)
RESERVE_BYTES = 64 * 1024 * 1024
_TMP_PREFIX = ".drev-tmp-"


class GuardError(Exception):
    """허용되지 않은 쓰기 — 경로가 뿌리 밖이거나 이름·형태가 위험하다."""


class GuardExists(GuardError):
    """덮어쓰지 않는 쓰기에서 같은 이름의 파일이 이미 있다."""


class GuardNoSpace(GuardError):
    """디스크 여유가 모자란다."""


def check_name(name) -> str:
    """경로 성분 하나(폴더·파일 이름)를 검사해 그대로 돌려준다. 위험하면 GuardError."""
    if not isinstance(name, str) or not name:
        raise GuardError("이름이 비어 있습니다")
    if len(name) > MAX_NAME:
        raise GuardError(f"이름이 너무 깁니다 ({len(name)}자, 최대 {MAX_NAME}자)")
    for ch in name:
        cat = unicodedata.category(ch)
        # Cc 제어문자, Cf 서식 문자(오른쪽→왼쪽 덮어쓰기 'abc‮fdp.exe' 같은 속임), 줄·문단 구분자
        if ch in _BAD_CHARS or cat in ("Cc", "Cf", "Zl", "Zp"):
            raise GuardError(f"이름에 쓸 수 없는 글자가 있습니다: {ch!r}")
    if name in (".", ".."):
        raise GuardError("'.'·'..' 은 이름으로 쓸 수 없습니다")
    if name[-1] in " .":
        raise GuardError("이름 끝에 공백이나 점을 둘 수 없습니다")
    if name[0] == " ":
        raise GuardError("이름 앞에 공백을 둘 수 없습니다")
    stem = name.split(".", 1)[0].rstrip(" ").upper()
    if stem in _RESERVED:
        raise GuardError(f"Windows 예약 이름은 쓸 수 없습니다: {name}")
    if name.startswith(_TMP_PREFIX):
        raise GuardError("Drev 임시 파일 이름은 쓸 수 없습니다")
    return name


def clean_filename(raw) -> str:
    """올린 파일 이름 → 보관용 이름. 경로 성분('C:\\a\\b.xlsx', '../x')을 떼고 NFC로 맞춘 뒤 검사한다."""
    if not isinstance(raw, str):
        raise GuardError("파일 이름이 없습니다")
    base = re.split(r"[\\/]", raw)[-1].strip()
    base = unicodedata.normalize("NFC", base)
    return check_name(base)


def _is_reparse(p: str) -> bool:
    """심볼릭 링크·정션 등 재분석 지점이면 True. 없는 경로는 False."""
    try:
        st = os.lstat(p)
    except FileNotFoundError:
        return False
    if stat.S_ISLNK(st.st_mode):
        return True
    return bool(getattr(st, "st_file_attributes", 0) & FILE_ATTRIBUTE_REPARSE_POINT)


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(p))


def _within(child: str, parent: str) -> bool:
    c, r = _norm(child), _norm(parent)
    try:
        return os.path.commonpath([c, r]) == r
    except ValueError:          # 드라이브가 다르다
        return False


def _rel_parts(child: str, root: str) -> list[str]:
    rel = os.path.relpath(child, root)
    return [] if rel == "." else rel.split(os.sep)


def _raw_parts(s: str) -> list[str]:
    return [x for x in re.split(r"[\\/]+", s) if x != ""]


def free_bytes(path) -> int:
    """path가 있는 디스크의 남은 바이트."""
    p = os.fspath(path)
    if sys.platform == "win32":
        import ctypes
        free = ctypes.c_ulonglong(0)
        ok = ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(p), ctypes.byref(free),
                                                        None, None)
        if not ok:
            raise GuardError(f"디스크 여유를 알 수 없습니다: {p}")
        return int(free.value)
    st = os.statvfs(p)
    return int(st.f_bavail * st.f_frsize)


def sha256_of(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class Guard:
    """허용 뿌리 목록을 쥔 쓰기 문. 모든 쓰기·지우기 메서드는 경로를 먼저 검사한다."""

    def __init__(self, roots, *, create=()):
        want = {_norm(os.path.abspath(os.fspath(c))) for c in create}
        self._roots: list[tuple[str, str]] = []      # (적힌 모양 abspath, 실제 경로 realpath)
        for r in roots:
            s = os.fspath(r)
            self._reject_spoof(s)
            given = os.path.abspath(s)
            if _norm(given) in want and not os.path.isdir(given):
                os.makedirs(given, exist_ok=True)
            if not os.path.isdir(given):
                raise GuardError(f"허용 뿌리 폴더가 없습니다: {given}")
            self._roots.append((given, os.path.realpath(given)))
        if not self._roots:
            raise GuardError("허용 뿌리가 하나도 없습니다")
        self.reserve_bytes = RESERVE_BYTES

    @property
    def roots(self) -> list[Path]:
        return [Path(g) for g, _ in self._roots]

    @staticmethod
    def _reject_spoof(s: str) -> None:
        if not isinstance(s, str) or not s:
            raise GuardError("경로가 비어 있습니다")
        if "\x00" in s:
            raise GuardError("경로에 NUL 문자가 있습니다")
        if s.startswith(_DEVICE_PREFIXES):
            raise GuardError(f"장치 경로는 쓸 수 없습니다: {s}")
        if not os.path.isabs(s):          # 'C:abc'(드라이브 상대)·상대 경로
            raise GuardError(f"절대 경로가 아닙니다: {s}")

    def _match_root(self, absn: str) -> tuple[str, str]:
        for given, real in self._roots:
            if _within(absn, given):
                return given, real
        raise GuardError(f"허용된 폴더 밖입니다: {absn}")

    def _verify(self, absn: str, given: str, real: str) -> None:
        """뿌리 아래 성분 이름·재분석 지점·resolve 결과를 확인한다 (쓰기 직전에도 다시 부른다)."""
        if _norm(os.path.realpath(given)) != _norm(real):
            raise GuardError(f"허용 뿌리가 바뀌었습니다(링크로 바뀜?): {given}")
        cur = given
        for part in _rel_parts(absn, given):
            check_name(part)
            cur = os.path.join(cur, part)
            if _is_reparse(cur):
                raise GuardError(f"링크·정션을 지나는 경로는 쓸 수 없습니다: {cur}")
        if not _within(os.path.realpath(absn), real):
            raise GuardError(f"허용된 폴더 밖으로 이어집니다: {absn}")

    def check(self, path) -> Path:
        """절대 경로 하나를 검사해 정규화된 Path로. 뿌리 밖·'..'·링크·위험한 이름이면 GuardError."""
        s = os.fspath(path)
        self._reject_spoof(s)
        if any(x in (".", "..") for x in _raw_parts(s)):
            raise GuardError(f"'.'·'..' 이 든 경로는 쓸 수 없습니다: {s}")
        absn = os.path.abspath(s)
        # Windows는 끝 점·공백을 말없이 떼어 낸다('abc.' → 'abc') — 뗀 흔적이 있으면 거부
        if _norm(os.path.normpath(s)) != _norm(absn):
            raise GuardError(f"이름 끝에 공백이나 점이 있는 경로는 쓸 수 없습니다: {s}")
        given, real = self._match_root(absn)
        self._verify(absn, given, real)
        return Path(absn)

    def target(self, root, *parts: str) -> Path:
        """등록된 뿌리 + 이름 성분들 → 검사된 경로. 성분은 이름 하나씩(구분자 없음)이어야 한다."""
        r = os.path.abspath(os.fspath(root))
        for given, _ in self._roots:
            if _norm(given) == _norm(r):
                break
        else:
            raise GuardError(f"등록되지 않은 뿌리입니다: {r}")
        for part in parts:
            check_name(part)
        return self.check(os.path.join(given, *parts))

    def contains(self, path) -> bool:
        try:
            self.check(path)
            return True
        except GuardError:
            return False

    # ── 쓰기 ────────────────────────────────────────────────────────────

    def make_dirs(self, path, *, created: list | None = None) -> Path:
        """뿌리 아래 폴더를 위에서부터 하나씩 만든다. 만들 때마다 링크로 바뀌지 않았는지 본다.
        created: (선택) 이번에 새로 만든 폴더의 절대 경로를 위에서부터 차례로 더한다 — 'Drev가 만든 폴더' 기록용(미러)."""
        p = self.check(path)
        given, real = self._match_root(str(p))
        cur = given
        for part in _rel_parts(str(p), given):
            cur = os.path.join(cur, part)
            if not os.path.isdir(cur):
                try:
                    os.mkdir(cur)
                    if created is not None:
                        created.append(cur)
                except FileExistsError:
                    if not os.path.isdir(cur):
                        raise GuardError(f"같은 이름의 파일이 있어 폴더를 만들 수 없습니다: {cur}")
            if _is_reparse(cur):
                raise GuardError(f"링크·정션을 지나는 경로는 쓸 수 없습니다: {cur}")
        self._verify(str(p), given, real)
        return p

    def remove_empty_dir(self, path) -> bool:
        """(대기 파일 정리·현행 미러용, 2026-10-28 보안 F7) 허용 뿌리 **안**의 **빈** 폴더 하나만 지운다.

        - 뿌리 자신은 지우지 않는다. 링크·정션·파일이면 거부한다(GuardError).
        - 비었는지는 OS가 판정한다(os.rmdir는 안에 무엇이든 있으면 실패) — 안에 무엇이 생겼으면 False.
        - 없으면 False. 지웠으면 True. 위 폴더까지 거슬러 지우지 않는다(부르는 쪽이 한 단계씩 정한다)."""
        p = self.check(path)
        given, _ = self._match_root(str(p))
        if _norm(str(p)) == _norm(given):
            raise GuardError(f"허용 뿌리 자체는 지우지 않습니다: {p}")
        if not os.path.lexists(p):
            return False
        if _is_reparse(str(p)) or not os.path.isdir(p):
            raise GuardError(f"폴더가 아닙니다(파일·링크): {p}")
        self.check(p)                                     # 지우기 직전에 다시 (그사이 링크로 바뀌지 않았는지)
        try:
            os.rmdir(p)
        except OSError:
            if os.path.isdir(p):
                return False                                  # 비지 않았다(또는 쓰는 중) — 그대로 둔다
            raise
        return True

    def _space_ok(self, folder: str, size: int) -> None:
        free = free_bytes(folder)
        if free < size + self.reserve_bytes:
            raise GuardNoSpace(f"디스크 여유가 모자랍니다 (남은 {free // (1024 * 1024)}MB)")

    def _write_tmp(self, folder: str, data: bytes) -> str:
        tmp = os.path.join(folder, _TMP_PREFIX + secrets.token_hex(8))
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | (os.O_BINARY if os.name == "nt" else 0)
        fd = os.open(tmp, flags, 0o644)
        try:
            view = memoryview(data)
            while view:
                n = os.write(fd, view)
                view = view[n:]
            os.fsync(fd)
        except BaseException:
            os.close(fd)
            self._drop_tmp(tmp)
            raise
        os.close(fd)
        return tmp

    @staticmethod
    def _drop_tmp(tmp: str) -> None:
        try:
            os.unlink(tmp)
        except OSError:
            pass

    def write_atomic(self, path, data: bytes, *, overwrite: bool = True,
                     make_parents: bool = True, created: list | None = None) -> Path:
        """같은 폴더 임시 파일에 쓰고 fsync → os.replace. overwrite=False면 이미 있을 때 GuardExists.

        덮어쓰기가 허용돼도 기존 것이 폴더·링크면 거부한다. Drev가 둔 파일인지 확인이 필요한
        덮어쓰기는 replace_file을 쓴다."""
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise GuardError("쓸 내용은 bytes여야 합니다")
        p = self.check(path)
        if make_parents:
            self.make_dirs(p.parent, created=created)
        folder = str(p.parent)
        if not os.path.isdir(folder):
            raise GuardError(f"폴더가 없습니다: {folder}")
        if os.path.lexists(p):
            if _is_reparse(str(p)) or not os.path.isfile(p):
                raise GuardError(f"파일이 아닌 것(폴더·링크)이 같은 이름으로 있습니다: {p}")
            if not overwrite:
                raise GuardExists(f"이미 있습니다: {p}")
        self._space_ok(folder, len(data))
        tmp = self._write_tmp(folder, bytes(data))
        try:
            self.check(p)                        # 쓰는 동안 경로가 바뀌지 않았는지 다시
            if overwrite:
                os.replace(tmp, p)
            elif os.name == "nt":
                os.rename(tmp, p)                # Windows: 대상이 있으면 실패 = 덮어쓰지 않음
            else:
                os.link(tmp, p)                  # 대상이 있으면 FileExistsError
                self._drop_tmp(tmp)
        except FileExistsError:
            self._drop_tmp(tmp)
            raise GuardExists(f"이미 있습니다: {p}")
        except BaseException:
            self._drop_tmp(tmp)
            raise
        return p

    def write_new(self, path, data: bytes) -> Path:
        """새 파일만 쓴다(판 파일 — 한 번 쓰면 바꾸지 않는다). 이미 있으면 GuardExists."""
        return self.write_atomic(path, data, overwrite=False)

    def _owned(self, p: Path, expected_sha256) -> None:
        if not expected_sha256:
            raise GuardError(f"Drev가 둔 파일인지 확인할 지문이 없어 손대지 않습니다: {p}")
        if _is_reparse(str(p)) or not os.path.isfile(p):
            raise GuardError(f"일반 파일이 아닙니다: {p}")
        if sha256_of(p) != str(expected_sha256).lower():
            raise GuardError(f"Drev가 둔 파일이 아닙니다(내용이 다름) — 손대지 않습니다: {p}")

    def replace_file(self, path, data: bytes, *, expected_sha256=None, created: list | None = None) -> Path:
        """(현행 미러용) 파일 교체. 없으면 새로 쓰고, 있으면 Drev가 둔 그 파일(지문 일치)일 때만 바꾼다.
        created: (선택) 새로 만든 위 폴더들을 더할 목록 (make_dirs)."""
        p = self.check(path)
        if os.path.lexists(p):
            self._owned(p, expected_sha256)
        return self.write_atomic(p, data, overwrite=True, created=created)

    def remove_file(self, path, *, expected_sha256) -> bool:
        """(현행 미러·대기 파일용) Drev가 둔 파일(지문 일치)만 지운다. 없으면 False."""
        p = self.check(path)
        if not os.path.lexists(p):
            return False
        self._owned(p, expected_sha256)
        self.check(p)
        os.unlink(p)
        return True
