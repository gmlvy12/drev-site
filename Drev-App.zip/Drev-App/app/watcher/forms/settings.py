# -*- coding: utf-8 -*-
"""양식함 설정 — config.yaml `forms:` 묶음 읽기·검사 (2026-10-28 F4).

```yaml
forms:
  enabled: false          # 기본 꺼짐 — 꺼 두면 Drev는 양식함 전과 똑같다
  host: "0.0.0.0"         # 사내망 주소(예: 192.168.0.10) 또는 0.0.0.0(모든 사내망 주소). 공인 주소는 거부
  port: 8766
  mirror_root: ""         # (선택) 현행 미러 폴더 — 승인된 현행 판을 폴더 구조대로 둔다
  max_upload_mb: 50
  compare_timeout: 60     # 자동 비교 한 번의 상한(초)
  notify: false           # 승인·반려·새 현행 판 메일 알림 (감시의 사내 SMTP 설정을 쓴다)
  audit_max_rows: 200000  # 감사 기록 보존 상한(행) — 넘으면 오래된 것부터 지운다 (2026-10-28 보안 F1)
  pending_keep_days: 90   # 반려·취소된 제출의 대기 파일 보존 기간(일) — 지나면 지운다 (보안 F7)
  review_months_default: 12  # 양식 정기 검토 주기 기본값(개월), 0 = 끔 — 양식마다 덮어쓸 수 있다 (F7 문서 관리 대장)
  backup_enabled: true    # 매일 forms.db·판 파일 백업 (2026-10-30) — 양식함이 켜져 있을 때만 돈다
  backup_dir: ""          # 백업 폴더 — 비우면 <데이터 폴더>\\forms_backup. 다른 디스크·\\\\서버\\공유 권장 (있는 폴더여야 한다)
  backup_keep: 4          # forms.db 사본 슬롯 수 (1~30) — 판 파일 사본은 지우지 않고 쌓는다
  backup_hour: 3          # 이 시(0~23) 뒤 그날 첫 정리 때 백업
  digest_weekday: 끔      # 주간 알림(검토 기한·검토 대기) 요일 — 끔(기본) / 월~금. 사내 SMTP가 설정돼 있을 때만 보낸다
  digest_hour: 8          # 주간 알림을 보내는 시(0~23)
```
옛 config(이 묶음 없음)·깨진 값은 꺼짐·기본값으로 읽는다 — 설정 하나가 이상하다고 감시가 멎지 않게.
이 모듈은 아무것도 쓰지 않는다(읽기·검사만). 바깥 주소에 묻지 않는다 — 사내망 주소 후보는 이 PC의 이름 풀이로만 얻는다.
"""

from __future__ import annotations

import ipaddress
import os
import socket
from pathlib import Path

from watcher.forms.store import FormsError

DEFAULT_PORT = 8766
DEFAULTS = {"enabled": False, "host": "0.0.0.0", "port": DEFAULT_PORT, "mirror_root": "",
            "max_upload_mb": 50, "compare_timeout": 60, "notify": False,
            "audit_max_rows": 200_000, "pending_keep_days": 90, "review_months_default": 12,
            # 백업·주간 알림 (2026-10-30)
            "backup_enabled": True, "backup_dir": "", "backup_keep": 4, "backup_hour": 3,
            "digest_weekday": "끔", "digest_hour": 8}   # 주간 알림은 기본 꺼짐 — 업데이트로 메일이 새로 가지 않게
# 숫자 설정의 범위 — (아래, 위, 화면 이름). 범위 밖이면 기본값으로 읽고, 화면은 out_of_range로 알린다 (2026-10-30 검토)
NUMERIC = {"port": (1024, 65535, "포트"), "max_upload_mb": (1, 2048, "올리기 상한(MB)"),
           "compare_timeout": (5, 3600, "자동 비교 상한(초)"), "audit_max_rows": (1000, 10_000_000, "감사 기록 보존 상한(행)"),
           "pending_keep_days": (1, 3650, "대기 파일 보존(일)"), "review_months_default": (0, 120, "정기 검토 주기(개월)"),
           "backup_keep": (1, 30, "백업 사본 수"), "backup_hour": (0, 23, "백업 시각(시)"),
           "digest_hour": (0, 23, "주간 알림 시각(시)")}
WEEKDAYS = ("월", "화", "수", "목", "금")
DIGEST_OFF = "끔"
TASK_NAME = "DrevForms"
FIREWALL_RULE = "Drev Forms"


def _on(v, default: bool) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "on", "예", "켬"):
        return True
    if s in ("false", "0", "no", "off", "아니오", "끔", ""):
        return False
    return default


def _int(v, default: int, lo: int, hi: int) -> int:
    try:
        n = int(str(v).strip())
    except (TypeError, ValueError):
        return default
    return n if lo <= n <= hi else default


def forms_settings(cfg: dict | None) -> dict:
    """config 사전 → 양식함 설정(기본값 채움). 묶음이 없거나 사전이 아니면 꺼짐."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        raw = {}
    out = dict(DEFAULTS)
    out["enabled"] = _on(raw.get("enabled"), False)
    out["notify"] = _on(raw.get("notify"), False)
    out["host"] = str(raw.get("host") or DEFAULTS["host"]).strip()
    for key, (lo, hi, _label) in NUMERIC.items():
        out[key] = _int(raw.get(key), DEFAULTS[key], lo, hi)
    mr = raw.get("mirror_root")
    out["mirror_root"] = str(mr).strip() if mr else ""
    out["backup_enabled"] = _on(raw.get("backup_enabled"), True)
    bd = raw.get("backup_dir")
    out["backup_dir"] = str(bd).strip().strip('"') if bd else ""
    out["digest_weekday"] = weekday_text(raw.get("digest_weekday"))
    return out


def weekday_text(v, default: str = "끔") -> str:
    """주간 알림 요일 → '끔' 또는 '월'~'금'. 0~4(월=0)·'월요일'도 받는다. 모르는 값은 기본값(끔)."""
    if v is None:
        return default
    if v is False:
        return DIGEST_OFF
    s = str(v).strip()
    if s.lower() in ("끔", "off", "false", "no", "아니오", "none", ""):
        return DIGEST_OFF
    if s.endswith("요일"):
        s = s[:-2]
    if s in WEEKDAYS:
        return s
    if isinstance(v, int) or s.isdecimal():
        try:
            n = int(s)
        except ValueError:
            return default
        if 0 <= n < len(WEEKDAYS):
            return WEEKDAYS[n]
    return default


def weekday_index(v) -> int | None:
    """'월'~'금' → 0~4, '끔' → None."""
    t = weekday_text(v)
    return WEEKDAYS.index(t) if t in WEEKDAYS else None


def out_of_range(cfg: dict | None) -> list[str]:
    """config.yaml에 적힌 숫자 가운데 범위 밖이거나 숫자가 아닌 것 — forms_settings는 말없이 기본값으로 읽으므로
    설정 화면이 이 목록을 보여 준다 (2026-10-30 검토: 손으로 고친 값이 조용히 바뀌지 않게)."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        return []
    out = []
    for key, (lo, hi, label) in NUMERIC.items():
        v = raw.get(key)
        if v is None or v == "":
            continue
        try:
            n = int(str(v).strip())
        except (TypeError, ValueError):
            out.append(f"{label}: '{v}'은(는) 숫자가 아니라 기본값 {DEFAULTS[key]}(으)로 쓰고 있습니다 ({lo}~{hi})")
            continue
        if not lo <= n <= hi:
            out.append(f"{label}: {n}은(는) 범위({lo}~{hi}) 밖이라 기본값 {DEFAULTS[key]}(으)로 쓰고 있습니다")
    return out


def check_int(value, key: str) -> int:
    """화면에서 받은 숫자 하나 검사 — 숫자가 아니거나 범위 밖이면 FormsError(기본값으로 바꿔 저장하지 않는다)."""
    lo, hi, label = NUMERIC[key]
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        raise FormsError(f"{label}은(는) 숫자로 적어 주세요 ({lo}~{hi})")
    if not lo <= n <= hi:
        raise FormsError(f"{label}은(는) {lo}~{hi} 사이로 적어 주세요")
    return n


def check_host(host: str) -> str:
    """바인드 주소 검사 — server.check_bind_host 와 같은 규칙(IP 글자만, 공인 주소 거부)."""
    from watcher.forms.server import check_bind_host
    return check_bind_host(host)


def check_port(port) -> int:
    try:
        n = int(str(port).strip())
    except (TypeError, ValueError):
        raise FormsError("포트는 숫자로 적어 주세요 (기본 8766)")
    if not 1024 <= n <= 65535:
        raise FormsError("포트는 1024~65535 사이로 적어 주세요 (기본 8766)")
    if n == 8765:
        raise FormsError("8765는 감시 화면이 쓰는 포트입니다 — 다른 포트(기본 8766)를 쓰세요")
    return n


def check_mirror_root(path) -> str:
    """현행 미러 폴더 — 비워도 된다. 절대 경로(드라이브 또는 \\\\서버\\공유)이고 지금 있는 폴더여야 한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("현행 미러 폴더는 전체 경로로 적어 주세요 (예: \\\\서버\\공용\\양식\\현행 또는 D:\\양식\\현행)")
    if not Path(s).is_dir():
        raise FormsError(f"현행 미러 폴더가 없습니다: {s} — 먼저 폴더를 만들어 주세요")
    return s


def lan_addresses() -> list[str]:
    """이 PC의 사내망(사설) IPv4 주소 후보 — 이름 풀이만 쓴다(바깥에 묻지 않는다). 루프백·자동 사설(169.254) 제외."""
    out: list[str] = []
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
    except OSError:
        infos = []
    for info in infos:
        ip = info[4][0]
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_private and not a.is_loopback and not a.is_link_local and ip not in out:
            out.append(ip)
    return out


def access_urls(host: str, port: int, lan: list[str] | None = None) -> list[str]:
    """직원들이 열 주소 — 특정 주소면 그것, 0.0.0.0이면 사내망 주소 후보마다."""
    h = str(host or "").strip()
    if h in ("0.0.0.0", "::", ""):
        cands = lan if lan is not None else lan_addresses()
        return [f"http://{ip}:{int(port)}/" for ip in cands]
    if h in ("127.0.0.1", "localhost", "::1"):
        return []
    return [f"http://{h}:{int(port)}/"]


def base_url(host: str, port: int, lan: list[str] | None = None) -> str:
    """메일 알림의 '양식함에서 열기' 주소 — 정할 수 없으면 빈 글자(링크 없이 보낸다)."""
    urls = access_urls(host, port, lan)
    return urls[0].rstrip("/") if urls else ""


def firewall_command(port: int, program: str = "") -> str:
    """포터블판 안내용 — 관리자 권한 명령 프롬프트에 붙여 넣을 한 줄(사내망=개인·도메인 프로필만). Drev는 실행하지 않는다."""
    prog = f' program="{program}"' if program else ""
    return (f'netsh advfirewall firewall add rule name="{FIREWALL_RULE} (TCP {int(port)})" dir=in action=allow '
            f'protocol=TCP localport={int(port)} profile=private,domain{prog}')


def firewall_remove_command(port: int) -> str:
    return f'netsh advfirewall firewall delete rule name="{FIREWALL_RULE} (TCP {int(port)})"'


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def _within(child: str, parent: str) -> bool:
    c, r = _norm(child), _norm(parent)
    try:
        return os.path.commonpath([c, r]) == r
    except ValueError:              # 드라이브가 다르다
        return False


def check_backup_dir(path, data_dir, *, must_exist: bool = True) -> str:
    """백업 폴더 (2026-10-30) — 비우면 기본(<데이터 폴더>\\forms_backup). 절대 경로(드라이브 또는 \\\\서버\\공유).
    데이터 폴더 아래면 없어도 된다(백업 때 만든다). 그 밖(다른 디스크·공유)이면 지금 있는 폴더여야 한다.
    데이터 폴더 자체·보관소(forms_store) 안은 거부한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("백업 폴더는 전체 경로로 적어 주세요 (예: D:\\Drev백업\\양식함 또는 \\\\서버\\백업\\양식함)")
    d = str(data_dir)
    if _norm(s) == _norm(d):
        raise FormsError("Drev 데이터 폴더 자체는 백업 폴더로 쓸 수 없습니다 — 그 아래 폴더나 다른 디스크를 고르세요")
    if _within(d, s):
        raise FormsError("Drev 데이터 폴더를 품은 위 폴더는 백업 폴더로 쓸 수 없습니다 — 그 아래 폴더나 다른 디스크를 고르세요")
    if _within(s, os.path.join(d, "forms_store")):
        raise FormsError("보관소(forms_store) 안은 백업 폴더로 쓸 수 없습니다")
    if must_exist and not _within(s, d) and not Path(s).is_dir():
        raise FormsError(f"백업 폴더가 없습니다: {s} — 먼저 폴더를 만들어 주세요")
    return s


def paths_overlap(a, b) -> bool:
    """두 폴더가 같거나 한쪽이 다른 쪽 안인가 (링크를 풀어 본다)."""
    try:
        x, y = os.path.realpath(str(a)), os.path.realpath(str(b))
    except (OSError, ValueError):
        return False
    return _within(x, y) or _within(y, x)


def backup_dir_problem(backup_dir, data_dir, *, mirror_root="", watch_roots=()) -> str:
    """실제로 쓸 백업 폴더 전체 검사 — 문제가 있으면 까닭 한 줄, 없으면 ''. 설정 화면 검사와 같은 규칙을 백업할 때마다 다시 본다
    (config.yaml은 손으로 고칠 수 있다 — 2026-10-30 검토). 폴더가 아직 없는 것(공유 끊김)은 여기서 보지 않고 백업이 실패로 적는다."""
    s = str(backup_dir or "")
    d = str(data_dir)
    if not s:
        return "백업 폴더가 정해지지 않았습니다"
    try:
        check_backup_dir(s, d, must_exist=False)
    except FormsError as e:
        return str(e)
    if mirror_root and paths_overlap(s, mirror_root):
        return "백업 폴더와 현행 미러 폴더가 겹칩니다 — 미러는 직원들이 여는 곳이라 백업(계정 정보 포함)을 둘 수 없습니다"
    for r in watch_roots or ():
        if r and _within(os.path.realpath(s), os.path.realpath(str(r))):
            return f"백업 폴더가 감시 폴더 안에 있습니다({r}) — 감시 밖의 폴더를 골라 주세요"
    return ""
