# -*- coding: utf-8 -*-
"""양식함 설정 — config.yaml `forms:` 묶음 읽기·검사 (2026-10-28 F4).

```yaml
forms:
  enabled: false          # 기본 꺼짐 — 꺼 두면 Drev는 양식함 전과 똑같다
  host: "0.0.0.0"         # 사내망 주소(예: 192.168.0.10) 또는 0.0.0.0(모든 사내망 주소). 공인 주소는 거부
  port: 8766
  mirror_root: ""         # (선택) 현행 미러 폴더 — 승인된 현행 판을 폴더 구조대로 둔다
  max_upload_mb: 50
  compare_timeout: 60     # 자동 비교 한 번의 상한(초)
  notify: false           # 승인·반려·새 현행 판 메일 알림 (감시의 사내 SMTP 설정을 쓴다)
  audit_max_rows: 200000  # 감사 기록 보존 상한(행) — 넘으면 오래된 것부터 지운다 (2026-10-28 보안 F1)
  pending_keep_days: 90   # 반려·취소된 제출의 대기 파일 보존 기간(일) — 지나면 지운다 (보안 F7)
  review_months_default: 12  # 양식 정기 검토 주기 기본값(개월), 0 = 끔 — 양식마다 덮어쓸 수 있다 (F7 문서 관리 대장)
  backup_enabled: true    # 매일 forms.db·판 파일 백업 (2026-10-30) — 양식함이 켜져 있을 때만 돈다
  backup_dir: ""          # 백업 폴더 — 비우면 <데이터 폴더>\\forms_backup. 다른 디스크·\\\\서버\\공유 권장 (있는 폴더여야 한다)
  backup_keep: 4          # forms.db 사본 슬롯 수 (1~30) — 판 파일 사본은 지우지 않고 쌓는다
  backup_hour: 3          # 이 시(0~23) 뒤 그날 첫 정리 때 백업
  digest_weekday: 월      # 주간 알림(검토 기한·검토 대기) 요일 — 월(기본, 2026-10-30) / 화~금 / 끔. 사내 SMTP가 설정돼 있을 때만 보낸다
                          #   이 줄이 없거나 값이 비어 있으면(`digest_weekday:`·`~` = YAML null) 월요일,
                          #   '끔'·off·false·no·빈 따옴표('')가 적혀 있으면 꺼진 채로 둔다
  digest_hour: 8          # 주간 알림을 보내는 시(0~23)
```
옛 config(이 묶음 없음)·깨진 값은 꺼짐·기본값으로 읽는다 — 설정 하나가 이상하다고 감시가 멎지 않게.
이 모듈은 아무것도 쓰지 않는다(읽기·검사만). 바깥 주소에 묻지 않는다 — 사내망 주소 후보는 이 PC의 이름 풀이로만 얻는다.
"""

from __future__ import annotations

import ipaddress
import os
import re
import socket
from pathlib import Path

from watcher.forms.store import FormsError

DEFAULT_PORT = 8766
DEFAULTS = {"enabled": False, "host": "0.0.0.0", "port": DEFAULT_PORT, "mirror_root": "",
            "max_upload_mb": 50, "compare_timeout": 60, "notify": False,
            "audit_max_rows": 200_000, "pending_keep_days": 90, "review_months_default": 12,
            # 백업·주간 알림 (2026-10-30)
            "backup_enabled": True, "backup_dir": "", "backup_keep": 4, "backup_hour": 3,
            "digest_weekday": "월", "digest_hour": 8}   # 주간 알림 기본 월요일 (2026-10-30 사용자 결정 — 전에는 끔)
# 숫자 설정의 범위 — (아래, 위, 화면 이름). 범위 밖이면 기본값으로 읽고, 화면은 out_of_range로 알린다 (2026-10-30 검토)
NUMERIC = {"port": (1024, 65535, "포트"), "max_upload_mb": (1, 2048, "올리기 상한(MB)"),
           "compare_timeout": (5, 3600, "자동 비교 상한(초)"), "audit_max_rows": (1000, 10_000_000, "감사 기록 보존 상한(행)"),
           "pending_keep_days": (1, 3650, "대기 파일 보존(일)"), "review_months_default": (0, 120, "정기 검토 주기(개월)"),
           "backup_keep": (1, 30, "백업 사본 수"), "backup_hour": (0, 23, "백업 시각(시)"),
           "digest_hour": (0, 23, "주간 알림 시각(시)")}
WEEKDAYS = ("월", "화", "수", "목", "금")
DIGEST_OFF = "끔"
DIGEST_DEFAULT = DEFAULTS["digest_weekday"]      # 적혀 있지 않을 때(옛 config 포함). 명시적인 '끔'은 끔 그대로
TASK_NAME = "DrevForms"
FIREWALL_RULE = "Drev Forms"


def _on(v, default: bool) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "on", "예", "켬"):
        return True
    if s in ("false", "0", "no", "off", "아니오", "끔", ""):
        return False
    return default


def _int(v, default: int, lo: int, hi: int) -> int:
    try:
        n = int(str(v).strip())
    except (TypeError, ValueError):
        return default
    return n if lo <= n <= hi else default


def forms_settings(cfg: dict | None) -> dict:
    """config 사전 → 양식함 설정(기본값 채움). 묶음이 없거나 사전이 아니면 꺼짐."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        raw = {}
    out = dict(DEFAULTS)
    out["enabled"] = _on(raw.get("enabled"), False)
    out["notify"] = _on(raw.get("notify"), False)
    out["host"] = str(raw.get("host") or DEFAULTS["host"]).strip()
    for key, (lo, hi, _label) in NUMERIC.items():
        out[key] = _int(raw.get(key), DEFAULTS[key], lo, hi)
    mr = raw.get("mirror_root")
    out["mirror_root"] = str(mr).strip() if mr else ""
    out["backup_enabled"] = _on(raw.get("backup_enabled"), True)
    bd = raw.get("backup_dir")
    out["backup_dir"] = str(bd).strip().strip('"') if bd else ""
    out["digest_weekday"] = weekday_text(raw.get("digest_weekday"))
    return out


def weekday_text(v, default: str = DIGEST_DEFAULT) -> str:
    """주간 알림 요일 → '끔' 또는 '월'~'금'. 0~4(월=0)·'월요일'도 받는다.
    None(config에 줄이 없음, 또는 값 없이 `digest_weekday:`·`~` — YAML null)과 모르는 값은 기본값(월, 2026-10-30),
    명시적인 끔('끔'·off·false·no·빈 따옴표 '')은 끔 그대로 — 전에 기본이 끔이던 때 [저장]한 설정은 '끔'이 적혀 있어
    업데이트해도 꺼진 채다."""
    if v is None:
        return default
    if v is False:
        return DIGEST_OFF
    s = str(v).strip()
    if s.lower() in ("끔", "off", "false", "no", "아니오", "none", ""):
        return DIGEST_OFF
    if s.endswith("요일"):
        s = s[:-2]
    if s in WEEKDAYS:
        return s
    if isinstance(v, int) or s.isdecimal():
        try:
            n = int(s)
        except ValueError:
            return default
        if 0 <= n < len(WEEKDAYS):
            return WEEKDAYS[n]
    return default


def weekday_index(v) -> int | None:
    """'월'~'금' → 0~4, '끔' → None."""
    t = weekday_text(v)
    return WEEKDAYS.index(t) if t in WEEKDAYS else None


def out_of_range(cfg: dict | None) -> list[str]:
    """config.yaml에 적힌 숫자 가운데 범위 밖이거나 숫자가 아닌 것 — forms_settings는 말없이 기본값으로 읽으므로
    설정 화면이 이 목록을 보여 준다 (2026-10-30 검토: 손으로 고친 값이 조용히 바뀌지 않게)."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        return []
    out = []
    for key, (lo, hi, label) in NUMERIC.items():
        v = raw.get(key)
        if v is None or v == "":
            continue
        try:
            n = int(str(v).strip())
        except (TypeError, ValueError):
            out.append(f"{label}: '{v}'은(는) 숫자가 아니라 기본값 {DEFAULTS[key]}(으)로 쓰고 있습니다 ({lo}~{hi})")
            continue
        if not lo <= n <= hi:
            out.append(f"{label}: {n}은(는) 범위({lo}~{hi}) 밖이라 기본값 {DEFAULTS[key]}(으)로 쓰고 있습니다")
    return out


def check_int(value, key: str) -> int:
    """화면에서 받은 숫자 하나 검사 — 숫자가 아니거나 범위 밖이면 FormsError(기본값으로 바꿔 저장하지 않는다)."""
    lo, hi, label = NUMERIC[key]
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        raise FormsError(f"{label}은(는) 숫자로 적어 주세요 ({lo}~{hi})")
    if not lo <= n <= hi:
        raise FormsError(f"{label}은(는) {lo}~{hi} 사이로 적어 주세요")
    return n


def check_host(host: str) -> str:
    """바인드 주소 검사 — server.check_bind_host 와 같은 규칙(IP 글자만, 공인 주소 거부)."""
    from watcher.forms.server import check_bind_host
    return check_bind_host(host)


def check_port(port) -> int:
    try:
        n = int(str(port).strip())
    except (TypeError, ValueError):
        raise FormsError("포트는 숫자로 적어 주세요 (기본 8766)")
    if not 1024 <= n <= 65535:
        raise FormsError("포트는 1024~65535 사이로 적어 주세요 (기본 8766)")
    if n == 8765:
        raise FormsError("8765는 감시 화면이 쓰는 포트입니다 — 다른 포트(기본 8766)를 쓰세요")
    return n


def check_mirror_root(path) -> str:
    """현행 미러 폴더 — 비워도 된다. 절대 경로(드라이브 또는 \\\\서버\\공유)이고 지금 있는 폴더여야 한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("현행 미러 폴더는 전체 경로로 적어 주세요 (예: \\\\서버\\공용\\양식\\현행 또는 D:\\양식\\현행)")
    if not Path(s).is_dir():
        raise FormsError(f"현행 미러 폴더가 없습니다: {s} — 먼저 폴더를 만들어 주세요")
    return s


def lan_addresses() -> list[str]:
    """이 PC의 사내망(사설) IPv4 주소 후보 — 이름 풀이만 쓴다(바깥에 묻지 않는다). 루프백·자동 사설(169.254) 제외."""
    out: list[str] = []
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
    except OSError:
        infos = []
    for info in infos:
        ip = info[4][0]
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_private and not a.is_loopback and not a.is_link_local and ip not in out:
            out.append(ip)
    return out


def access_urls(host: str, port: int, lan: list[str] | None = None) -> list[str]:
    """직원들이 열 주소 — 특정 주소면 그것, 0.0.0.0이면 사내망 주소 후보마다."""
    h = str(host or "").strip()
    if h in ("0.0.0.0", "::", ""):
        cands = lan if lan is not None else lan_addresses()
        return [f"http://{ip}:{int(port)}/" for ip in cands]
    if h in ("127.0.0.1", "localhost", "::1"):
        return []
    return [f"http://{h}:{int(port)}/"]


def base_url(host: str, port: int, lan: list[str] | None = None) -> str:
    """메일 알림의 '양식함에서 열기' 주소 — 정할 수 없으면 빈 글자(링크 없이 보낸다)."""
    urls = access_urls(host, port, lan)
    return urls[0].rstrip("/") if urls else ""


def firewall_command(port: int, program: str = "") -> str:
    """포터블판 안내용 — 관리자 권한 명령 프롬프트에 붙여 넣을 한 줄(사내망=개인·도메인 프로필만). Drev는 실행하지 않는다."""
    prog = f' program="{program}"' if program else ""
    return (f'netsh advfirewall firewall add rule name="{FIREWALL_RULE} (TCP {int(port)})" dir=in action=allow '
            f'protocol=TCP localport={int(port)} profile=private,domain{prog}')


def firewall_remove_command(port: int) -> str:
    return f'netsh advfirewall firewall delete rule name="{FIREWALL_RULE} (TCP {int(port)})"'


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def _within(child: str, parent: str) -> bool:
    c, r = _norm(child), _norm(parent)
    try:
        return os.path.commonpath([c, r]) == r
    except ValueError:              # 드라이브가 다르다
        return False


def check_backup_dir(path, data_dir, *, must_exist: bool = True) -> str:
    """백업 폴더 (2026-10-30) — 비우면 기본(<데이터 폴더>\\forms_backup). 절대 경로(드라이브 또는 \\\\서버\\공유).
    데이터 폴더 아래면 없어도 된다(백업 때 만든다). 그 밖(다른 디스크·공유)이면 지금 있는 폴더여야 한다.
    데이터 폴더 자체·보관소(forms_store) 안은 거부한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("백업 폴더는 전체 경로로 적어 주세요 (예: D:\\Drev백업\\양식함 또는 \\\\서버\\백업\\양식함)")
    d = str(data_dir)
    if _norm(s) == _norm(d):
        raise FormsError("Drev 데이터 폴더 자체는 백업 폴더로 쓸 수 없습니다 — 그 아래 폴더나 다른 디스크를 고르세요")
    if _within(d, s):
        raise FormsError("Drev 데이터 폴더를 품은 위 폴더는 백업 폴더로 쓸 수 없습니다 — 그 아래 폴더나 다른 디스크를 고르세요")
    if _within(s, os.path.join(d, "forms_store")):
        raise FormsError("보관소(forms_store) 안은 백업 폴더로 쓸 수 없습니다")
    if must_exist and not _within(s, d) and not Path(s).is_dir():
        raise FormsError(f"백업 폴더가 없습니다: {s} — 먼저 폴더를 만들어 주세요")
    return s


def paths_overlap(a, b) -> bool:
    """두 폴더가 같거나 한쪽이 다른 쪽 안인가 (링크를 풀어 본다)."""
    try:
        x, y = os.path.realpath(str(a)), os.path.realpath(str(b))
    except (OSError, ValueError):
        return False
    return _within(x, y) or _within(y, x)


def backup_dir_problem(backup_dir, data_dir, *, mirror_root="", watch_roots=()) -> str:
    """실제로 쓸 백업 폴더 전체 검사 — 문제가 있으면 까닭 한 줄, 없으면 ''. 설정 화면 검사와 같은 규칙을 백업할 때마다 다시 본다
    (config.yaml은 손으로 고칠 수 있다 — 2026-10-30 검토). 폴더가 아직 없는 것(공유 끊김)은 여기서 보지 않고 백업이 실패로 적는다."""
    s = str(backup_dir or "")
    d = str(data_dir)
    if not s:
        return "백업 폴더가 정해지지 않았습니다"
    try:
        check_backup_dir(s, d, must_exist=False)
    except FormsError as e:
        return str(e)
    if mirror_root and paths_overlap(s, mirror_root):
        return "백업 폴더와 현행 미러 폴더가 겹칩니다 — 미러는 직원들이 여는 곳이라 백업(계정 정보 포함)을 둘 수 없습니다"
    for r in watch_roots or ():
        if r and _within(os.path.realpath(s), os.path.realpath(str(r))):
            return f"백업 폴더가 감시 폴더 안에 있습니다({r}) — 감시 밖의 폴더를 골라 주세요"
    return ""


# ── 백업이 데이터와 같은 디스크인가 (2026-10-30 사용자 결정) ────────────────────────────
# 기본 백업 폴더(<데이터 폴더>\forms_backup)는 데이터와 같은 디스크라 디스크가 고장 나면 원본과 백업을 함께 잃는다.
# 기본 위치는 바꾸지 않고 백업도 막지 않는다 — 관리자 화면·설정 칸·주간 알림(관리자, 한 번)에 경고만.
# 판정은 볼륨(드라이브) 단위라 한 디스크의 두 파티션은 잡지 못한다 — 문구는 '같은 드라이브(볼륨)', 화면에 SAME_DISK_HINT (검토 7).

def _is_unc(p: str) -> bool:
    s = str(p or "")
    return s.startswith(("\\\\", "//")) and not s.startswith(("\\\\?\\", "\\\\.\\"))


def _existing(p: str) -> str | None:
    """p 자신이나 가장 가까운 있는 위 폴더 (아직 없는 기본 백업 폴더도 그 디스크를 알게). 못 찾으면 None."""
    cur = os.path.abspath(str(p))
    for _ in range(64):
        if os.path.exists(cur):
            return cur
        up = os.path.dirname(cur)
        if up == cur:
            return None
        cur = up
    return None


def _volume(p: str):
    """볼륨 식별자 — os.stat().st_dev(Windows는 볼륨 일련번호, 폴더에 붙인 디스크도 구별). 알 수 없으면 None. (시험이 바꿔 끼운다)"""
    q = _existing(p)
    if q is None:
        return None
    try:
        return os.stat(q).st_dev
    except OSError:
        return None


def _drive(p: str) -> str:
    return os.path.splitdrive(os.path.abspath(str(p)))[0].upper()


def _unc_host(p: str) -> str:
    """\\\\서버\\공유 경로의 서버 이름(접음). UNC가 아니면 ''."""
    if not _is_unc(p):
        return ""
    parts = [x for x in re.split(r"[\\/]+", str(p)) if x]     # str.replace는 test_readonly 이름 검사에 걸린다
    return parts[0].casefold() if parts else ""


def _is_self_unc(p: str) -> bool:
    """\\\\localhost\\…·\\\\127.0.0.1\\…·\\\\<이 PC 이름>\\… — 공유 꼴이지만 이 PC다 (어느 디스크인지는 관리자 API 없이 알 수 없다)."""
    host = _unc_host(p)
    if not host:
        return False
    if host in ("localhost", "::1", "0:0:0:0:0:0:0:1") or host.startswith("127."):
        return True
    try:
        me = socket.gethostname().casefold()
    except OSError:
        return False
    return bool(me) and (host == me or host.split(".", 1)[0] == me.split(".", 1)[0])


SELF_SHARE = "이 PC"                     # same_disk가 돌려주는 표시 — 백업 폴더가 이 PC 자신의 공유 경로


def same_disk(backup_dir, data_dir) -> str | None:
    """백업 폴더가 데이터 폴더와 같은 드라이브(볼륨)이면 드라이브 이름('C:', 모르면 ''), 다르면 None.
    판정은 볼륨 단위다 — 한 실제 디스크의 두 파티션(C:·D:)은 다른 것으로 본다(잡지 못함, 화면에 따로 안내).
    \\\\서버\\공유는 다른 디스크로 친다. 다만 \\\\localhost\\…·\\\\127.0.0.1\\…·\\\\<이 PC 이름>\\…은 이 PC라 SELF_SHARE('이 PC').
    경로가 아직 없으면 있는 위 폴더로 보고, 볼륨을 알 수 없으면 드라이브 글자로 비교한다."""
    b, d = str(backup_dir or ""), str(data_dir or "")
    if not b or not d:
        return None
    if _is_unc(d):
        return None
    if _is_unc(b):
        return SELF_SHARE if _is_self_unc(b) else None
    vb, vd = _volume(b), _volume(d)
    if vb is not None and vd is not None:
        same = vb == vd
    else:
        db, dd = _drive(b), _drive(d)
        same = bool(db) and db == dd
    return _drive(d) if same else None


# 볼륨 단위 판정이 잡지 못하는 경우 — 설정 칸·관리자 백업 화면에 늘 한 줄 (2026-10-30 검토 7)
SAME_DISK_HINT = "C:와 D:가 한 디스크의 두 파티션이면 잡지 못합니다 — 다른 실제 디스크나 다른 PC의 공유 폴더를 권합니다."


def same_disk_warning(backup_dir, data_dir) -> str:
    """같은 드라이브(볼륨)거나 이 PC의 공유 경로면 경고 한 줄, 아니면 ''."""
    drive = same_disk(backup_dir, data_dir)
    if drive is None:
        return ""
    if drive == SELF_SHARE:
        return ("백업 폴더가 이 PC 자신의 공유 경로(\\\\localhost·\\\\이 PC 이름)입니다. 이 PC가 고장 나면 원본과 백업을 함께 "
                "잃을 수 있습니다 — 다른 PC의 \\\\서버\\공유 폴더나 다른 실제 디스크로 바꾸세요.")
    where = f"같은 드라이브(볼륨) {drive}" if drive else "같은 드라이브(볼륨)"
    return (f"백업 폴더가 데이터와 {where}에 있습니다. 그 디스크가 고장 나면 원본과 백업을 함께 잃습니다 — "
            f"다른 실제 디스크나 다른 PC의 \\\\서버\\공유 폴더로 바꾸세요.")
