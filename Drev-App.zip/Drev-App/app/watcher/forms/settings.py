# -*- coding: utf-8 -*-
"""양식함 설정 — config.yaml `forms:` 묶음 읽기·검사 (2026-10-28 F4).

```yaml
forms:
  enabled: false          # 기본 꺼짐 — 꺼 두면 Drev는 양식함 전과 똑같다
  host: "0.0.0.0"         # 사내망 주소(예: 192.168.0.10) 또는 0.0.0.0(모든 사내망 주소). 공인 주소는 거부
  port: 8766
  mirror_root: ""         # (선택) 현행 미러 폴더 — 승인된 현행 판을 폴더 구조대로 둔다
  max_upload_mb: 50
  compare_timeout: 60     # 자동 비교 한 번의 상한(초)
  notify: false           # 승인·반려·새 현행 판 메일 알림 (감시의 사내 SMTP 설정을 쓴다)
  audit_max_rows: 200000  # 감사 기록 보존 상한(행) — 넘으면 오래된 것부터 지운다 (2026-10-28 보안 F1)
  pending_keep_days: 90   # 반려·취소된 제출의 대기 파일 보존 기간(일) — 지나면 지운다 (보안 F7)
```
옛 config(이 묶음 없음)·깨진 값은 꺼짐·기본값으로 읽는다 — 설정 하나가 이상하다고 감시가 멎지 않게.
이 모듈은 아무것도 쓰지 않는다(읽기·검사만). 바깥 주소에 묻지 않는다 — 사내망 주소 후보는 이 PC의 이름 풀이로만 얻는다.
"""

from __future__ import annotations

import ipaddress
import os
import socket
from pathlib import Path

from watcher.forms.store import FormsError

DEFAULT_PORT = 8766
DEFAULTS = {"enabled": False, "host": "0.0.0.0", "port": DEFAULT_PORT, "mirror_root": "",
            "max_upload_mb": 50, "compare_timeout": 60, "notify": False,
            "audit_max_rows": 200_000, "pending_keep_days": 90}
TASK_NAME = "DrevForms"
FIREWALL_RULE = "Drev Forms"


def _on(v, default: bool) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "on", "예", "켬"):
        return True
    if s in ("false", "0", "no", "off", "아니오", "끔", ""):
        return False
    return default


def _int(v, default: int, lo: int, hi: int) -> int:
    try:
        n = int(str(v).strip())
    except (TypeError, ValueError):
        return default
    return n if lo <= n <= hi else default


def forms_settings(cfg: dict | None) -> dict:
    """config 사전 → 양식함 설정(기본값 채움). 묶음이 없거나 사전이 아니면 꺼짐."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        raw = {}
    out = dict(DEFAULTS)
    out["enabled"] = _on(raw.get("enabled"), False)
    out["notify"] = _on(raw.get("notify"), False)
    out["host"] = str(raw.get("host") or DEFAULTS["host"]).strip()
    out["port"] = _int(raw.get("port"), DEFAULT_PORT, 1024, 65535)
    out["max_upload_mb"] = _int(raw.get("max_upload_mb"), 50, 1, 2048)
    out["compare_timeout"] = _int(raw.get("compare_timeout"), 60, 5, 3600)
    out["audit_max_rows"] = _int(raw.get("audit_max_rows"), 200_000, 1000, 10_000_000)
    out["pending_keep_days"] = _int(raw.get("pending_keep_days"), 90, 1, 3650)
    mr = raw.get("mirror_root")
    out["mirror_root"] = str(mr).strip() if mr else ""
    return out


def check_host(host: str) -> str:
    """바인드 주소 검사 — server.check_bind_host 와 같은 규칙(IP 글자만, 공인 주소 거부)."""
    from watcher.forms.server import check_bind_host
    return check_bind_host(host)


def check_port(port) -> int:
    try:
        n = int(str(port).strip())
    except (TypeError, ValueError):
        raise FormsError("포트는 숫자로 적어 주세요 (기본 8766)")
    if not 1024 <= n <= 65535:
        raise FormsError("포트는 1024~65535 사이로 적어 주세요 (기본 8766)")
    if n == 8765:
        raise FormsError("8765는 감시 화면이 쓰는 포트입니다 — 다른 포트(기본 8766)를 쓰세요")
    return n


def check_mirror_root(path) -> str:
    """현행 미러 폴더 — 비워도 된다. 절대 경로(드라이브 또는 \\\\서버\\공유)이고 지금 있는 폴더여야 한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("현행 미러 폴더는 전체 경로로 적어 주세요 (예: \\\\서버\\공용\\양식\\현행 또는 D:\\양식\\현행)")
    if not Path(s).is_dir():
        raise FormsError(f"현행 미러 폴더가 없습니다: {s} — 먼저 폴더를 만들어 주세요")
    return s


def lan_addresses() -> list[str]:
    """이 PC의 사내망(사설) IPv4 주소 후보 — 이름 풀이만 쓴다(바깥에 묻지 않는다). 루프백·자동 사설(169.254) 제외."""
    out: list[str] = []
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
    except OSError:
        infos = []
    for info in infos:
        ip = info[4][0]
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_private and not a.is_loopback and not a.is_link_local and ip not in out:
            out.append(ip)
    return out


def access_urls(host: str, port: int, lan: list[str] | None = None) -> list[str]:
    """직원들이 열 주소 — 특정 주소면 그것, 0.0.0.0이면 사내망 주소 후보마다."""
    h = str(host or "").strip()
    if h in ("0.0.0.0", "::", ""):
        cands = lan if lan is not None else lan_addresses()
        return [f"http://{ip}:{int(port)}/" for ip in cands]
    if h in ("127.0.0.1", "localhost", "::1"):
        return []
    return [f"http://{h}:{int(port)}/"]


def base_url(host: str, port: int, lan: list[str] | None = None) -> str:
    """메일 알림의 '양식함에서 열기' 주소 — 정할 수 없으면 빈 글자(링크 없이 보낸다)."""
    urls = access_urls(host, port, lan)
    return urls[0].rstrip("/") if urls else ""


def firewall_command(port: int, program: str = "") -> str:
    """포터블판 안내용 — 관리자 권한 명령 프롬프트에 붙여 넣을 한 줄(사내망=개인·도메인 프로필만). Drev는 실행하지 않는다."""
    prog = f' program="{program}"' if program else ""
    return (f'netsh advfirewall firewall add rule name="{FIREWALL_RULE} (TCP {int(port)})" dir=in action=allow '
            f'protocol=TCP localport={int(port)} profile=private,domain{prog}')


def firewall_remove_command(port: int) -> str:
    return f'netsh advfirewall firewall delete rule name="{FIREWALL_RULE} (TCP {int(port)})"'
