# -*- coding: utf-8 -*-
"""양식함 설정 — config.yaml `forms:` 묶음 읽기·검사 (2026-10-28 F4).

```yaml
forms:
  enabled: false          # 기본 꺼짐 — 꺼 두면 Drev는 양식함 전과 똑같다
  boxes: true             # 양식 기능(올리기·승인·판·내려받기). false = 사내망 기록 열람만 — 로그인·계정·변경 기록만 남고
                          #   양식 메뉴·경로는 없는 것(404)과 같다 (2026-11-17 R3). 줄이 없으면 켬(지금 동작 그대로)
  host: "0.0.0.0"         # 사내망 주소(예: 192.168.0.10) 또는 0.0.0.0(모든 사내망 주소). 공인 주소는 거부
  port: 8766
  mirror_root: ""         # (선택) 현행 미러 폴더 — 승인된 현행 판을 폴더 구조대로 둔다
  max_upload_mb: 50
  compare_timeout: 60     # 자동 비교 한 번의 상한(초)
  notify: false           # 승인·반려·새 현행 판 메일 알림 (감시의 사내 SMTP 설정을 쓴다)
  audit_max_rows: 200000  # 감사 기록 보존 상한(행) — 넘으면 오래된 것부터 지운다 (2026-10-28 보안 F1)
  pending_keep_days: 90   # 반려·취소된 제출의 대기 파일 보존 기간(일) — 지나면 지운다 (보안 F7)
  review_months_default:  # 양식 정기 검토 주기 기본값(개월), 0 = 끔 — 양식마다 덮어쓸 수 있다 (F7 문서 관리 대장).
                          #   적지 않으면(2026-11-02 기능 검토 F2-10) 새 설치는 0(끔), 이 판 전에 양식이 있던 설치는 12 그대로
  backup_enabled: true    # 매일 forms.db·판 파일 백업 (2026-10-30) — 양식함이 켜져 있을 때만 돈다
  backup_dir: ""          # 백업 폴더 — 비우면 <데이터 폴더>\\forms_backup. 다른 디스크·\\\\서버\\공유 권장 (있는 폴더여야 한다)
  backup_keep: 4          # forms.db 사본 슬롯 수 (1~30) — 판 파일 사본은 지우지 않고 쌓는다
  backup_hour: 3          # 이 시(0~23) 뒤 그날 첫 정리 때 백업
  digest_weekday: 월      # 주간 알림(검토 기한·검토 대기) 요일 — 월(기본, 2026-10-30) / 화~금 / 끔. 사내 SMTP가 설정돼 있을 때만 보낸다
                          #   이 줄이 없거나 값이 비어 있으면(`digest_weekday:`·`~` = YAML null) 월요일,
                          #   '끔'·off·false·no·빈 따옴표('')가 적혀 있으면 꺼진 채로 둔다
  digest_hour: 8          # 주간 알림을 보내는 시(0~23)
```
옛 config(이 묶음 없음)·깨진 값은 꺼짐·기본값으로 읽는다 — 설정 하나가 이상하다고 감시가 멎지 않게.
이 모듈은 아무것도 쓰지 않는다(읽기·검사만). 바깥 주소에 묻지 않는다 — 사내망 주소 후보는 이 PC의 이름 풀이로만 얻는다.
"""

from __future__ import annotations

import ipaddress
import os
import re
import socket
from pathlib import Path

from watcher.forms.store import FormsError

DEFAULT_PORT = 8766
DEFAULTS = {"enabled": False, "boxes": True, "host": "0.0.0.0", "port": DEFAULT_PORT, "mirror_root": "",
            "max_upload_mb": 50, "compare_timeout": 60, "notify": False,
            "audit_max_rows": 200_000, "pending_keep_days": 90,
            # None = 적지 않음 — forms.db가 정한다(새 설치 0, 이 판 전 설치 12 — store._review_seed, F2-10)
            "review_months_default": None,
            # 백업·주간 알림 (2026-10-30)
            "backup_enabled": True, "backup_dir": "", "backup_keep": 4, "backup_hour": 3,
            "digest_weekday": "월", "digest_hour": 8}   # 주간 알림 기본 월요일 (2026-10-30 사용자 결정 — 전에는 끔)
# 숫자 설정의 범위 — (아래, 위, 화면 이름). 범위 밖이면 기본값으로 읽고, 화면은 out_of_range로 알린다 (2026-10-30 검토)
NUMERIC = {"port": (1024, 65535, "포트"), "max_upload_mb": (1, 2048, "올리기 상한(MB)"),
           "compare_timeout": (5, 3600, "자동 비교 상한(초)"), "audit_max_rows": (1000, 10_000_000, "감사 기록 보존 상한(행)"),
           "pending_keep_days": (1, 3650, "대기 파일 보존(일)"), "review_months_default": (0, 120, "정기 검토 주기(개월)"),
           "backup_keep": (1, 30, "백업 사본 수"), "backup_hour": (0, 23, "백업 시각(시)"),
           "digest_hour": (0, 23, "주간 알림 시각(시)")}
WEEKDAYS = ("월", "화", "수", "목", "금")
DIGEST_OFF = "끔"
DIGEST_DEFAULT = DEFAULTS["digest_weekday"]      # 적혀 있지 않을 때(옛 config 포함). 명시적인 '끔'은 끔 그대로
TASK_NAME = "DrevForms"
FIREWALL_RULE = "Drev Forms"


def _on(v, default: bool) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "on", "예", "켬"):
        return True
    if s in ("false", "0", "no", "off", "아니오", "끔", ""):
        return False
    return default


def _int(v, default: int, lo: int, hi: int) -> int:
    try:
        n = int(str(v).strip())
    except (TypeError, ValueError):
        return default
    return n if lo <= n <= hi else default


def forms_settings(cfg: dict | None) -> dict:
    """config 사전 → 양식함 설정(기본값 채움). 묶음이 없거나 사전이 아니면 꺼짐."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        raw = {}
    out = dict(DEFAULTS)
    out["enabled"] = _on(raw.get("enabled"), False)
    out["boxes"] = _on(raw.get("boxes"), True)           # 키 없음·모르는 값 = 켬 (지금 동작 유지)
    out["notify"] = _on(raw.get("notify"), False)
    out["host"] = str(raw.get("host") or DEFAULTS["host"]).strip()
    for key, (lo, hi, _label) in NUMERIC.items():
        out[key] = _int(raw.get(key), DEFAULTS[key], lo, hi)
    mr = raw.get("mirror_root")
    out["mirror_root"] = str(mr).strip() if mr else ""
    out["backup_enabled"] = _on(raw.get("backup_enabled"), True)
    bd = raw.get("backup_dir")
    out["backup_dir"] = str(bd).strip().strip('"') if bd else ""
    out["digest_weekday"] = weekday_text(raw.get("digest_weekday"))
    return out


def records_only(fs: dict) -> bool:
    """사내망 서버를 켰지만 양식 기능은 끈 '기록 열람만' 상태인가 (2026-11-17 R3)."""
    return bool(fs.get("enabled")) and not fs.get("boxes", True)


def weekday_text(v, default: str = DIGEST_DEFAULT) -> str:
    """주간 알림 요일 → '끔' 또는 '월'~'금'. 0~4(월=0)·'월요일'도 받는다.
    None(config에 줄이 없음, 또는 값 없이 `digest_weekday:`·`~` — YAML null)과 모르는 값은 기본값(월, 2026-10-30),
    명시적인 끔('끔'·off·false·no·빈 따옴표 '')은 끔 그대로 — 전에 기본이 끔이던 때 [저장]한 설정은 '끔'이 적혀 있어
    업데이트해도 꺼진 채다."""
    if v is None:
        return default
    if v is False:
        return DIGEST_OFF
    s = str(v).strip()
    if s.lower() in ("끔", "off", "false", "no", "아니오", "none", ""):
        return DIGEST_OFF
    if s.endswith("요일"):
        s = s[:-2]
    if s in WEEKDAYS:
        return s
    if isinstance(v, int) or s.isdecimal():
        try:
            n = int(s)
        except ValueError:
            return default
        if 0 <= n < len(WEEKDAYS):
            return WEEKDAYS[n]
    return default


def weekday_index(v) -> int | None:
    """'월'~'금' → 0~4, '끔' → None."""
    t = weekday_text(v)
    return WEEKDAYS.index(t) if t in WEEKDAYS else None


def out_of_range(cfg: dict | None) -> list[str]:
    """config.yaml에 적힌 숫자 가운데 범위 밖이거나 숫자가 아닌 것 — forms_settings는 말없이 기본값으로 읽으므로
    설정 화면이 이 목록을 보여 준다 (2026-10-30 검토: 손으로 고친 값이 조용히 바뀌지 않게)."""
    raw = (cfg or {}).get("forms")
    if not isinstance(raw, dict):
        return []
    out = []
    for key, (lo, hi, label) in NUMERIC.items():
        v = raw.get(key)
        if v is None or v == "":
            continue
        try:
            n = int(str(v).strip())
        except (TypeError, ValueError):
            out.append(f"{label}: '{v}'은(는) 숫자가 아니라 기본값 {_dflt_text(key)}(으)로 쓰고 있습니다 ({lo}~{hi})")
            continue
        if not lo <= n <= hi:
            out.append(f"{label}: {n}은(는) 범위({lo}~{hi}) 밖이라 기본값 {_dflt_text(key)}(으)로 쓰고 있습니다")
    return out


def _dflt_text(key: str) -> str:
    d = DEFAULTS[key]
    return "(새 설치 0 = 끔, 이전 설치 12)" if d is None else str(d)


def check_int(value, key: str) -> int:
    """화면에서 받은 숫자 하나 검사 — 숫자가 아니거나 범위 밖이면 FormsError(기본값으로 바꿔 저장하지 않는다)."""
    lo, hi, label = NUMERIC[key]
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        raise FormsError(f"{label}은(는) 숫자로 적어 주세요 ({lo}~{hi})")
    if not lo <= n <= hi:
        raise FormsError(f"{label}은(는) {lo}~{hi} 사이로 적어 주세요")
    return n


def check_host(host: str) -> str:
    """바인드 주소 검사 — server.check_bind_host 와 같은 규칙(IP 글자만, 공인 주소 거부)."""
    from watcher.forms.server import check_bind_host
    return check_bind_host(host)


def check_port(port) -> int:
    try:
        n = int(str(port).strip())
    except (TypeError, ValueError):
        raise FormsError("포트는 숫자로 적어 주세요 (기본 8766)")
    if not 1024 <= n <= 65535:
        raise FormsError("포트는 1024~65535 사이로 적어 주세요 (기본 8766)")
    if n == 8765:
        raise FormsError("8765는 감시 화면이 쓰는 포트입니다 — 다른 포트(기본 8766)를 쓰세요")
    return n


def check_mirror_root(path) -> str:
    """현행 미러 폴더 — 비워도 된다. 절대 경로(드라이브 또는 \\\\서버\\공유)이고 지금 있는 폴더여야 한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("현행 미러 폴더는 전체 경로로 적어 주세요 (예: \\\\서버\\공용\\양식\\현행 또는 D:\\양식\\현행)")
    if not Path(s).is_dir():
        raise FormsError(f"현행 미러 폴더가 없습니다: {s} — 먼저 폴더를 만들어 주세요")
    return s


def lan_addresses() -> list[str]:
    """이 PC의 사내망(사설) IPv4 주소 후보 — 이름 풀이만 쓴다(바깥에 묻지 않는다). 루프백·자동 사설(169.254) 제외."""
    out: list[str] = []
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
    except OSError:
        infos = []
    for info in infos:
        ip = info[4][0]
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_private and not a.is_loopback and not a.is_link_local and ip not in out:
            out.append(ip)
    return out


def access_urls(host: str, port: int, lan: list[str] | None = None) -> list[str]:
    """직원들이 열 주소 — 특정 주소면 그것, 0.0.0.0이면 사내망 주소 후보마다."""
    h = str(host or "").strip()
    if h in ("0.0.0.0", "::", ""):
        cands = lan if lan is not None else lan_addresses()
        return [f"http://{ip}:{int(port)}/" for ip in cands]
    if h in ("127.0.0.1", "localhost", "::1"):
        return []
    return [f"http://{h}:{int(port)}/"]


def base_url(host: str, port: int, lan: list[str] | None = None) -> str:
    """메일 알림의 '양식함에서 열기' 주소 — 정할 수 없으면 빈 글자(링크 없이 보낸다)."""
    urls = access_urls(host, port, lan)
    return urls[0].rstrip("/") if urls else ""


def lan_changes_base(cfg: dict | None, lan: list[str] | None = None) -> str:
    """브리핑 메일의 [사내망에서 보기·확인] 링크 기준 주소 (갈래 N, 2026-11-02 — FORMS.md 11절).
    양식함이 켜져 있고 사내망 주소(설정의 주소·포트, 0.0.0.0이면 이 PC의 사내망 주소)가 있을 때만 'http://주소:포트', 아니면 ''
    (그러면 메일은 지금처럼 링크 없이 나간다). 127.0.0.1에만 열린 양식함은 다른 PC에서 못 여니 ''."""
    fs = forms_settings(cfg)
    if not fs["enabled"]:
        return ""
    try:
        check_host(fs["host"])          # 공인 주소·IP 아닌 글자는 서버가 열리지 않는다 — 그 주소의 링크는 죽은 링크 (V3-4)
        return base_url(fs["host"], fs["port"], lan)
    except (OSError, ValueError, FormsError):
        return ""


def watch_recipients(cfg: dict | None) -> dict:
    """감시 메일 받는 사람 — {'*': 모든 통을 받는 주소(always_recipients), '': 프로젝트별 수신자가 없는 프로젝트의 받는 사람(recipients),
    프로젝트: 그 프로젝트 받는 사람(전체 수신자를 대체 — cli._recipients_for와 같은 규칙)}. 사내망 변경 열람의 기본 범위 제안용
    (읽기만 — 자동 부여 없음)."""
    cfg = cfg or {}
    mail = cfg.get("mail") if isinstance(cfg.get("mail"), dict) else {}

    def _l(v):
        return [str(a) for a in (v if isinstance(v, (list, tuple)) else [v] if v else [])]
    out = {"*": _l(mail.get("always_recipients")), "": _l(mail.get("recipients"))}
    projects = cfg.get("projects") if isinstance(cfg.get("projects"), dict) else {}
    for name, pc in projects.items():
        if isinstance(pc, dict) and pc.get("recipients"):
            out[str(name)] = _l(pc["recipients"])
    return out


def firewall_command(port: int, program: str = "") -> str:
    """포터블판 안내용 — 관리자 권한 명령 프롬프트에 붙여 넣을 한 줄(사내망=개인·도메인 프로필만). Drev는 실행하지 않는다."""
    prog = f' program="{program}"' if program else ""
    return (f'netsh advfirewall firewall add rule name="{FIREWALL_RULE} (TCP {int(port)})" dir=in action=allow '
            f'protocol=TCP localport={int(port)} profile=private,domain{prog}')


def firewall_remove_command(port: int) -> str:
    return f'netsh advfirewall firewall delete rule name="{FIREWALL_RULE} (TCP {int(port)})"'


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def _within(child: str, parent: str) -> bool:
    c, r = _norm(child), _norm(parent)
    try:
        return os.path.commonpath([c, r]) == r
    except ValueError:              # 드라이브가 다르다
        return False


def check_backup_dir(path, data_dir, *, must_exist: bool = True) -> str:
    """백업 폴더 (2026-10-30) — 비우면 기본(<데이터 폴더>\\forms_backup). 절대 경로(드라이브 또는 \\\\서버\\공유).
    데이터 폴더 아래면 없어도 된다(백업 때 만든다). 그 밖(다른 디스크·공유)이면 지금 있는 폴더여야 한다.
    데이터 폴더 자체·보관소(forms_store) 안은 거부한다."""
    s = str(path or "").strip().strip('"')
    if not s:
        return ""
    if s.startswith(("\\\\?\\", "\\\\.\\")) or not os.path.isabs(s):
        raise FormsError("백업 폴더는 전체 경로로 적어 주세요 (예: D:\\Drev백업\\양식함 또는 \\\\서버\\백업\\양식함)")
    d = str(data_dir)
    if _norm(s) == _norm(d):
        raise FormsError("Drev 데이터 폴더 자체는 백업 폴더로 쓸 수 없습니다 — 그 아래 폴더나 다른 디스크를 고르세요")
    if _within(d, s):
        raise FormsError("Drev 데이터 폴더를 품은 위 폴더는 백업 폴더로 쓸 수 없습니다 — 그 아래 폴더나 다른 디스크를 고르세요")
    if _within(s, os.path.join(d, "forms_store")):
        raise FormsError("보관소(forms_store) 안은 백업 폴더로 쓸 수 없습니다")
    if must_exist and not _within(s, d) and not Path(s).is_dir():
        raise FormsError(missing_backup_dir_message(s))
    return s


def missing_backup_dir_message(path) -> str:
    """백업 폴더가 아직 없을 때 사람에게 보일 한 줄 — 설정 저장·백업 실패·감사 기록·Drev 설정 칸이 같이 쓴다.
    (Guard의 '허용 뿌리 폴더가 없습니다'가 그대로 새던 것, 2026-10-31 실사용 검토)"""
    return f"백업 폴더가 없습니다 — 그 폴더를 먼저 만들어 주세요 (데이터 폴더 밖 경로는 Drev가 만들지 않습니다): {path}"


def paths_overlap(a, b) -> bool:
    """두 폴더가 같거나 한쪽이 다른 쪽 안인가 (링크를 풀어 본다)."""
    try:
        x, y = os.path.realpath(str(a)), os.path.realpath(str(b))
    except (OSError, ValueError):
        return False
    return _within(x, y) or _within(y, x)


_LOOPBACK_V4 = re.compile(r"^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
_ADMIN_SHARE = re.compile(r"^\\\\([^\\]+)\\([A-Za-z])\$(?=\\|$)")


def _same_pc_host(host: str) -> bool:
    """UNC 서버 이름이 이 PC 자신인가 — localhost·127.x.x.x·이 PC 이름만(이름 풀이·네트워크 없음).
    다른 서버 이름의 별칭(DNS 별칭·IP↔이름)은 판정하지 않는다."""
    h = (host or "").lower()
    if h == "localhost" or _LOOPBACK_V4.match(h):
        return True
    me = (os.environ.get("COMPUTERNAME") or "").lower()
    return bool(me) and h == me


def _canon_path(p: str) -> str:
    """같은 폴더의 다른 표기를 한 글자로 — 비교용(정규화 결과로 파일을 열지 않는다).

    realpath만으로는 \\\\?\\C:\\… 접두(확장 경로)·\\\\localhost\\C$\\…(이 PC의 관리 공유)·\\\\127.0.0.1\\C$ 가 C:\\… 와 다른
    글자로 남아, 감시 폴더 안을 '밖'으로 보고 백업·미러가 감시 폴더 안에 생겼다 (rv0678 B-2). 접두를 벗기고, 이 PC 자신의
    관리 공유(X$)는 드라이브 글자로 바꾼다."""
    s = str(p).translate({ord("/"): "\\"})     # (replace는 읽기 전용 검사가 os.replace와 가리지 못한다)
    low = s.lower()
    if low.startswith("\\\\?\\unc\\"):
        s = "\\\\" + s[8:]
    elif low.startswith(("\\\\?\\", "\\\\.\\")):
        s = s[4:]
    m = _ADMIN_SHARE.match(s)
    if m and _same_pc_host(m.group(1)):
        s = m.group(2) + ":" + (s[m.end():] or "\\")
    return os.path.normcase(s).rstrip("\\/")


def inside_watch_root(folder, watch_roots) -> str:
    """folder가 감시 폴더 가운데 하나와 같거나 그 안이면 그 감시 폴더(글자), 아니면 ''. 링크를 풀어(realpath) 대소문자 없이 본다
    (panel._inside_watch와 같은 규칙). \\\\?\\ 접두와 이 PC 자신의 관리 공유(\\\\localhost\\C$ 등)는 드라이브 글자로 맞춰 본다 (rv0678 B-2)."""
    try:
        f = _canon_path(os.path.realpath(str(folder)))
    except (OSError, ValueError):
        return ""
    for r in watch_roots or ():
        if not r:
            continue
        try:
            rr = _canon_path(os.path.realpath(str(r)))
        except (OSError, ValueError):
            continue
        if f == rr or f.startswith(rr + os.sep):
            return str(r)
    return ""


def mirror_root_problem(mirror_root, watch_roots) -> str:
    """현행 미러 폴더가 감시 폴더와 같거나 그 안인가 — 문제가 있으면 까닭 한 줄, 없으면 ''.
    설정 화면만 막고 있었다 — config.yaml을 손으로 고치거나 미러를 정한 뒤 그 위 폴더를 감시에 더하면 양식함이 감시 공유 안에
    현행 판을 쓰고 다음 날 감시가 그것을 '변경'으로 브리핑했다 (검토20 r04-1). 서버 시작·미러 동기화마다 다시 본다."""
    if not mirror_root:
        return ""
    r = inside_watch_root(mirror_root, watch_roots)
    if r:
        return (f"현행 미러 폴더({mirror_root})가 감시 폴더({r}) 안에 있어 현행 미러를 껐습니다 — 감시 밖의 폴더로 바꾸세요"
                " (Drev PC의 감시 화면 설정 › 고급 설정 › 양식함)")
    return ""


def backup_dir_problem(backup_dir, data_dir, *, mirror_root="", watch_roots=()) -> str:
    """실제로 쓸 백업 폴더 전체 검사 — 문제가 있으면 까닭 한 줄, 없으면 ''. 설정 화면 검사와 같은 규칙을 백업할 때마다 다시 본다
    (config.yaml은 손으로 고칠 수 있다 — 2026-10-30 검토). 폴더가 아직 없는 것(공유 끊김)은 여기서 보지 않고 백업이 실패로 적는다."""
    s = str(backup_dir or "")
    d = str(data_dir)
    if not s:
        return "백업 폴더가 정해지지 않았습니다"
    try:
        check_backup_dir(s, d, must_exist=False)
    except FormsError as e:
        return str(e)
    if mirror_root and paths_overlap(s, mirror_root):
        return "백업 폴더와 현행 미러 폴더가 겹칩니다 — 미러는 직원들이 여는 곳이라 백업(계정 정보 포함)을 둘 수 없습니다"
    for r in watch_roots or ():
        if r and _within(os.path.realpath(s), os.path.realpath(str(r))):
            return f"백업 폴더가 감시 폴더 안에 있습니다({r}) — 감시 밖의 폴더를 골라 주세요"
    return ""


# ── 백업이 데이터와 같은 디스크인가 (2026-10-30 사용자 결정) ────────────────────────────
# 기본 백업 폴더(<데이터 폴더>\forms_backup)는 데이터와 같은 디스크라 디스크가 고장 나면 원본과 백업을 함께 잃는다.
# 기본 위치는 바꾸지 않고 백업도 막지 않는다 — 관리자 화면·설정 칸·주간 알림(관리자, 한 번)에 경고만.
# 판정은 볼륨(드라이브) 단위라 한 디스크의 두 파티션은 잡지 못한다 — 문구는 '같은 드라이브(볼륨)', 화면에 SAME_DISK_HINT (검토 7).

def _is_unc(p: str) -> bool:
    s = str(p or "")
    return s.startswith(("\\\\", "//")) and not s.startswith(("\\\\?\\", "\\\\.\\"))


def _existing(p: str) -> str | None:
    """p 자신이나 가장 가까운 있는 위 폴더 (아직 없는 기본 백업 폴더도 그 디스크를 알게). 못 찾으면 None."""
    cur = os.path.abspath(str(p))
    for _ in range(64):
        if os.path.exists(cur):
            return cur
        up = os.path.dirname(cur)
        if up == cur:
            return None
        cur = up
    return None


def _volume(p: str):
    """볼륨 식별자 — os.stat().st_dev(Windows는 볼륨 일련번호, 폴더에 붙인 디스크도 구별). 알 수 없으면 None. (시험이 바꿔 끼운다)"""
    q = _existing(p)
    if q is None:
        return None
    try:
        return os.stat(q).st_dev
    except OSError:
        return None


def _drive(p: str) -> str:
    return os.path.splitdrive(os.path.abspath(str(p)))[0].upper()


def _unc_host(p: str) -> str:
    """\\\\서버\\공유 경로의 서버 이름(접음). UNC가 아니면 ''."""
    if not _is_unc(p):
        return ""
    parts = [x for x in re.split(r"[\\/]+", str(p)) if x]     # str.replace는 test_readonly 이름 검사에 걸린다
    return parts[0].casefold() if parts else ""


def _is_self_unc(p: str) -> bool:
    """\\\\localhost\\…·\\\\127.0.0.1\\…·\\\\<이 PC 이름>\\… — 공유 꼴이지만 이 PC다 (어느 디스크인지는 관리자 API 없이 알 수 없다)."""
    host = _unc_host(p)
    if not host:
        return False
    if host in ("localhost", "::1", "0:0:0:0:0:0:0:1") or host.startswith("127."):
        return True
    try:
        me = socket.gethostname().casefold()
    except OSError:
        return False
    return bool(me) and (host == me or host.split(".", 1)[0] == me.split(".", 1)[0])


SELF_SHARE = "이 PC"                     # same_disk가 돌려주는 표시 — 백업 폴더가 이 PC 자신의 공유 경로


def same_disk(backup_dir, data_dir) -> str | None:
    """백업 폴더가 데이터 폴더와 같은 드라이브(볼륨)이면 드라이브 이름('C:', 모르면 ''), 다르면 None.
    판정은 볼륨 단위다 — 한 실제 디스크의 두 파티션(C:·D:)은 다른 것으로 본다(잡지 못함, 화면에 따로 안내).
    \\\\서버\\공유는 다른 디스크로 친다. 다만 \\\\localhost\\…·\\\\127.0.0.1\\…·\\\\<이 PC 이름>\\…은 이 PC라 SELF_SHARE('이 PC').
    경로가 아직 없으면 있는 위 폴더로 보고, 볼륨을 알 수 없으면 드라이브 글자로 비교한다."""
    b, d = str(backup_dir or ""), str(data_dir or "")
    if not b or not d:
        return None
    if _is_unc(d):
        return None
    if _is_unc(b):
        return SELF_SHARE if _is_self_unc(b) else None
    vb, vd = _volume(b), _volume(d)
    if vb is not None and vd is not None:
        same = vb == vd
    else:
        db, dd = _drive(b), _drive(d)
        same = bool(db) and db == dd
    return _drive(d) if same else None


# 볼륨 단위 판정이 잡지 못하는 경우 — 설정 칸·관리자 백업 화면에 늘 한 줄 (2026-10-30 검토 7)
SAME_DISK_HINT = "C:와 D:가 한 디스크의 두 파티션이면 잡지 못합니다 — 다른 실제 디스크나 다른 PC의 공유 폴더를 권합니다."


def same_disk_warning(backup_dir, data_dir) -> str:
    """같은 드라이브(볼륨)거나 이 PC의 공유 경로면 경고 한 줄, 아니면 ''."""
    drive = same_disk(backup_dir, data_dir)
    if drive is None:
        return ""
    if drive == SELF_SHARE:
        return ("백업 폴더가 이 PC 자신의 공유 경로(\\\\localhost·\\\\이 PC 이름)입니다. 이 PC가 고장 나면 원본과 백업을 함께 "
                "잃을 수 있습니다 — 다른 PC의 \\\\서버\\공유 폴더나 다른 실제 디스크로 바꾸세요.")
    where = f"같은 드라이브(볼륨) {drive}" if drive else "같은 드라이브(볼륨)"
    return (f"백업 폴더가 데이터와 {where}에 있습니다. 그 디스크가 고장 나면 원본과 백업을 함께 잃습니다 — "
            f"다른 실제 디스크나 다른 PC의 \\\\서버\\공유 폴더로 바꾸세요.")
