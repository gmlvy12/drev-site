# -*- coding: utf-8 -*-
"""사내망 변경 확인·열람 (기능 검토 갈래 N, 2026-11-02 — FORMS.md 11절, DECISIONS 같은 날 둘째 줄).

켜 둔 양식함 서버 안에서, 양식함 계정으로 로그인한 사람이 관리자가 허락한 범위(전체 또는 고른 프로젝트)의 감시 변경을 본다:
근거 표(이전 / 새 값 / 위치)·전/후 사진·검토 필요(읽기만)·설계 변경 대장 엑셀, 그리고 [확인함 + 한 줄 메모].

- state.db에 쓰는 것은 확인 기록(acks) 한 줄 — 기존 State.add_ack. ~~그 밖(설정·검사·삭제·오탐 숨김·검토 필요 닫기)은 감시 PC에서만~~ →
  2026-11-23 사내망 협업(forms/collab.py): 의견·담당(덧붙임만)·[처리함](권한 있는 계정, State.resolve_issue)까지 네 가지. 설정·검사·
  삭제·오탐 숨김·프로젝트 바꾸기는 여전히 감시 PC에서만.
- state.db는 요청마다 새 연결(mode=rw — 없으면 만들지 않음), 스키마를 만들거나 이주하지 않는다(State.attach). busy_timeout 4초.
- 권한은 forms.db meta `changes_view:<계정 id>`(스키마 그대로). 관리자는 늘 전체. 권한이 없거나 범위 밖이면 없는 주소와 같은 404.
- 이 모듈은 파일을 쓰지 않는다(test_readonly 엄격 모드). 응답은 FormsHandler._send(소켓)로만 보낸다.
"""

from __future__ import annotations

import base64
import binascii
import contextlib
import html
import json
import re
import sqlite3
from collections import Counter
from datetime import date
from pathlib import Path, PurePosixPath
from urllib.parse import quote, urlencode

from watcher.rowkey import split_row_cell
from watcher.state import ACK_EXEMPT_TEXT, KIND_LABEL, State, ack_label, clean_ack_text, lan_ack_by

E = html.escape
ACCESS_PREFIX = "changes_view:"
BUSY_MS = 4000                       # 감시 검사가 쓰기 잠금을 쥐고 있을 때 기다리는 상한
LIST_MAX = 300                       # 목록 한 번에 보이는 변경 수
COUNT_MAX = 2_000_000                # 미확인 수를 셀 때 읽는 상한 — 목록과 달리 자르지 않는다 (감시 기록 전체보다 크게)
ITEM_MAX = 400                       # 상세 근거 표 항목 상한
PHOTO_MAX = 60                       # 상세 한 장의 사진 묶음 상한
NOTE_MAX = 200                       # 확인 메모 글자 상한 (한 줄)
IMG_MAX = 24 * 1024 * 1024           # 사진 한 장 상한(바이트)
_IMG_SIG = {"image/png": b"\x89PNG\r\n\x1a\n", "image/jpeg": b"\xff\xd8\xff"}
_REQUIRED = {                        # 이 화면이 읽고 쓰는 표·칸 — 없으면(옛 판·다른 파일) '열 수 없음'
    "changes": {"id", "snapshot_id", "kind", "path", "old_sha256", "new_sha256", "detected_at", "project"},
    "acks": {"id", "change_id", "by", "note", "at"},
    "change_details": {"change_id", "items_json", "captures_json", "dismissed_json"},
    "issues": {"id", "snapshot_id", "code", "path", "project", "message", "evidence", "detected_at", "resolved_at"},
    "snapshots": {"id", "run_at"},
    "extracts": {"sha256", "doc_json"},
    "meta": {"key", "value"},
}
BUSY_TEXT = "감시 검사가 기록을 쓰는 중입니다 — 잠시 뒤 다시 해 주세요"


class WatchUnavailable(Exception):
    """감시 기록(state.db)을 열 수 없다 — 없음·손상·형식 다름. 까닭은 쉬운 말."""


class WatchBusy(Exception):
    """감시 검사가 쓰기 잠금을 쥐고 있다 — 잠시 뒤 다시."""


def _busy(e) -> bool:
    m = str(e).lower()
    return "locked" in m or "busy" in m


class WatchLog:
    """감시 기록 파일 하나 — 요청마다 짧게 열고 닫는다."""

    def __init__(self, db_path, recipients=None, config=None):
        self.path = Path(db_path)
        self._recipients = recipients
        self._config = config
        self._iss_cache = None               # 메뉴 '확인 필요 N' — (파일 표지, {프로젝트: 수})

    def config(self) -> dict | None:
        """감시 설정(config.yaml) — 문서 종류 규칙·제외 폴더를 감시 화면과 같게 (docbox.config_args). 못 읽으면 None(기본 규칙)."""
        c = self._config
        try:
            got = c() if callable(c) else c
        except (Exception, SystemExit):      # 설정 파일이 없으면 load_config가 SystemExit — 화면은 기본 규칙으로
            return None
        return got if isinstance(got, dict) else None

    def open_issue_counts(self) -> dict | None:
        """{프로젝트(없으면 '미분류'): 열린 확인 필요 수} — 왼쪽 메뉴 '확인 필요 N'용. 화면마다 부르므로 state.db 파일(·-wal)의
        크기·시각이 그대로면 지난 값을 쓰고, 검사가 쓰기 잠금을 쥐고 있으면 기다리지 않는다(0.3초). 못 읽으면 None(수 없이)."""
        p = self.path
        try:
            sig = tuple((x.stat().st_mtime_ns, x.stat().st_size) if x.exists() else None
                        for x in (p, Path(str(p) + "-wal")))
        except OSError:
            return None
        got = self._iss_cache
        if got is not None and got[0] == sig:
            return got[1]
        if sig[0] is None:
            return None
        try:
            conn = sqlite3.connect(p.resolve().as_uri() + "?mode=rw", uri=True, timeout=0.3, check_same_thread=False)
        except (sqlite3.Error, OSError, ValueError):
            return None
        try:
            conn.execute("PRAGMA busy_timeout=300")
            out = {str(k): int(n) for k, n in conn.execute(
                "SELECT IFNULL(project, '미분류'), COUNT(*) FROM issues WHERE resolved_at IS NULL GROUP BY 1")}
        except sqlite3.Error:
            return None
        finally:
            try:
                conn.close()
            except sqlite3.Error:
                pass
        self._iss_cache = (sig, out)
        return out

    def recipients(self) -> dict:
        """{'*': [메일 전체 수신자], 프로젝트: [받는 사람]} — 감시 설정에서 (기본 범위 제안용). 못 읽으면 빈 사전."""
        r = self._recipients
        try:
            got = r() if callable(r) else r
        except Exception:
            return {}
        return got if isinstance(got, dict) else {}

    @contextlib.contextmanager
    def session(self):
        p = self.path
        if not p.is_file():
            raise WatchUnavailable(f"감시 기록 파일(state.db)이 없습니다 — 감시 PC에서 검사를 한 번 돌린 뒤 다시 여세요 ({p.name})")
        try:
            conn = sqlite3.connect(p.resolve().as_uri() + "?mode=rw", uri=True, timeout=BUSY_MS / 1000,
                                   check_same_thread=False)
        except (sqlite3.Error, OSError, ValueError) as e:
            raise WatchUnavailable(f"감시 기록 파일을 열 수 없습니다 — {type(e).__name__}")
        try:
            conn.execute(f"PRAGMA busy_timeout={int(BUSY_MS)}")
            _check_schema(conn)
            yield State.attach(conn, p)
        except sqlite3.OperationalError as e:
            if _busy(e):
                raise WatchBusy(BUSY_TEXT) from e
            raise WatchUnavailable(f"감시 기록을 읽을 수 없습니다 — {e}") from e
        except sqlite3.DatabaseError as e:
            raise WatchUnavailable(f"감시 기록 파일이 손상됐거나 SQLite 파일이 아닙니다 — {e}") from e
        finally:
            try:
                conn.close()
            except sqlite3.Error:
                pass


def _check_schema(conn) -> None:
    for table, need in _REQUIRED.items():
        cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        if not cols:
            raise WatchUnavailable(f"감시 기록에 '{table}' 표가 없습니다 — 감시 기록 파일이 아니거나 아주 옛 판입니다")
        missing = need - cols
        if missing:
            raise WatchUnavailable(f"감시 기록의 형식이 이 판과 다릅니다('{table}' 표에 {', '.join(sorted(missing))} 칸이 없음) — "
                                   "감시 PC에서 Drev 화면을 한 번 열면 맞춰집니다")


# ── 권한 (forms.db meta — 스키마 그대로) ─────────────────────────────────────────

def access_of(store, user_id, role: str | None = None):
    """None = 열람 없음, 'all' = 전체, frozenset = 고른 프로젝트. 관리자는 늘 'all'. 정지 계정은 None."""
    u = store.get_user(user_id)
    if not u or u.get("disabled"):
        return None
    if u.get("role") == "admin":                 # 역할은 매번 DB에서 (세션 값이 아니라)
        return "all"
    return _parse_access(store.meta_get(f"{ACCESS_PREFIX}{int(user_id)}", ""))


def _parse_access(raw):
    """meta 값(JSON) → None·'all'·frozenset. access_of와 lan_viewer_count가 같은 규칙으로 읽는다."""
    if not raw:
        return None
    try:
        d = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(d, dict):
        return None
    if d.get("all"):
        return "all"
    ps = d.get("projects")
    if isinstance(ps, list):
        got = frozenset(str(x) for x in ps if str(x).strip())
        return got or None
    return None


def lan_viewer_count(db_path) -> int:
    """사내망에서 변경 기록을 볼 수 있는 직원 계정 수 — 관리자가 아니고 정지되지 않았고 열람 범위(전체 또는 프로젝트)가 있는 계정.
    메일 두 꼴의 판단(brief.record_link_base)이 쓴다: 이런 계정이 하나도 없으면 링크형 메일의 링크를 열 사람이 없다 (V3-4).
    forms.db는 **읽기만**(mode=ro — 없으면 만들지 않고, 이주하지 않는다). 없거나·못 읽거나·형식이 다르면 0(근거형이 안전하다)."""
    p = Path(str(db_path or ""))
    try:
        if not p.is_file():
            return 0
        # -wal이 없으면 본 파일에 다 있다 — immutable로 열어 곁 파일(-wal·-shm)도 만들지 않는다. 있으면(서버가 도는 중) 그 내용까지 읽게 ro
        wal = Path(str(p) + "-wal").exists()
        conn = sqlite3.connect(p.resolve().as_uri() + ("?mode=ro" if wal else "?mode=ro&immutable=1"), uri=True, timeout=2)
    except (OSError, ValueError, sqlite3.Error):
        return 0
    try:
        ids = {int(r[0]) for r in conn.execute(
            "SELECT id FROM users WHERE role != 'admin' AND IFNULL(disabled, 0) = 0")}
        n = 0
        for key, raw in conn.execute("SELECT key, value FROM meta WHERE key LIKE ?", (ACCESS_PREFIX + "%",)):
            try:
                uid = int(str(key)[len(ACCESS_PREFIX):])
            except ValueError:
                continue
            if uid in ids and _parse_access(raw) is not None:
                n += 1
        return n
    except sqlite3.Error:
        return 0
    finally:
        conn.close()


def set_access(store, actor_id, target_id, *, on: bool, all_: bool, projects, ip: str = "") -> str:
    """관리자가 계정 하나의 열람을 켜고 끈다 — 감사 기록 changes_access. 돌려주는 값: 한 줄 결과."""
    u = store.get_user(target_id)
    if not u:
        from watcher.forms.store import NotFound
        raise NotFound("없는 계정입니다")
    key = f"{ACCESS_PREFIX}{int(target_id)}"
    ps = sorted({str(p).strip()[:200] for p in (projects or ()) if str(p).strip()})[:500]
    if u.get("role") == "admin":
        return "관리자는 늘 모든 프로젝트의 변경을 봅니다 — 따로 정할 것이 없습니다"
    if not on or (not all_ and not ps):
        store.meta_put({key: None})
        what = "끔"
    elif all_:
        store.meta_put({key: json.dumps({"all": True}, ensure_ascii=False)})
        what = "켬 — 전체 프로젝트"
    else:
        store.meta_put({key: json.dumps({"projects": ps}, ensure_ascii=False)})
        what = f"켬 — 프로젝트 {len(ps)}개: {', '.join(ps)[:300]}"
    store.record_audit(actor_id, "changes_access", f"user:{int(target_id)}", ip=ip,
                       detail=f"{u.get('login')} 변경 브리핑 열람 {what}")
    return f"{u.get('display_name') or u.get('login')}: 변경 브리핑 열람 {what}"


def access_text(acc) -> str:
    if acc is None:
        return "끔"
    if acc == "all":
        return "전체"
    ps = sorted(acc)
    return f"{len(ps)}개 프로젝트" if len(ps) > 3 else ", ".join(ps)


def suggested(recipients: dict, email: str, projects=()) -> tuple[bool, list]:
    """계정 메일이 감시 메일 받는 사람에 있으면 (모든 통 수신 여부, 받는 프로젝트들) — 제안만(자동 부여 없음).
    recipients는 settings.watch_recipients 꼴: '*' 모든 통, '' 프로젝트별 수신자가 없는 프로젝트, 그 밖 프로젝트별(전체 수신자를 대체)."""
    em = str(email or "").strip().casefold()
    if not em:
        return False, []

    def has(lst):
        return any(str(a).strip().casefold() == em for a in (lst or ()))
    every = has(recipients.get("*"))
    own = {p for p in recipients if p not in ("*", "")}
    projs = {p for p in own if has(recipients.get(p))}
    if has(recipients.get("")):
        projs |= {p for p in projects if p not in own}
    return every, sorted(projs)


# ── 화면 공용 ─────────────────────────────────────────────────────────────────

def _S():
    from watcher.forms import server as S
    return S


def _watch(h):
    w = getattr(h.server, "watch_log", None)
    if w is None:
        raise _S().HttpError(404)
    return w


NO_SCOPE_TEXT = ("변경 열람 범위가 아직 없습니다 — 볼 프로젝트를 관리자에게 부탁하세요. "
                 "관리자는 관리 › 계정 › 변경 열람에서 정합니다.")
OUT_SCOPE_TEXT = "이 프로젝트는 열람 범위 밖입니다"


def _scope(h):
    """내 범위 — None(전체) 또는 프로젝트 모음. 열람이 없으면 404 + '변경 열람 범위가 아직 없습니다 — 관리자에게' (검토 Y3 L2).
    ~~없는 주소와 같은 404~~: 메일 꼬리말이 '사내망 계정으로 [확인함]'이라 하는데 계정이 있어도 '없는 화면입니다'뿐이라 누구에게 무엇을
    부탁할지 몰랐다. 이 말은 이 계정의 범위만 말한다 — 요청한 변경이 있는지·어느 프로젝트인지는 드러내지 않는다."""
    _watch(h)
    acc = access_of(h.server.store, h.sess.user_id, h.sess.role)
    if acc is None:
        raise _S().HttpError(404, NO_SCOPE_TEXT)
    return None if acc == "all" else acc


def _mine_text(scope) -> str:
    return "모든 프로젝트" if scope is None else ", ".join(sorted(scope))


def _note_out_of_scope(h, scope) -> bool:
    """주소의 ?p=가 열람 범위 밖이면 화면 위에 한 줄(범위 밖 상세 404와 같은 말) — 하루 묶음 메일은 받는 사람 모두에게 같은 통이라
    다른 프로젝트의 '전체 기록 ›'을 누르면 말없이 내 프로젝트 목록이 떴다 (검토 Y3 L1). 화면은 그대로(범위 밖 이름은 고르지 않은 것으로).
    p의 글자는 다시 싣지 않는다 — 이 계정의 범위만 말한다."""
    p = _S().FormsHandler._one(h._query(), "p").strip()
    if not p or _in(scope, p):
        return False
    h._flash("warn", f"{OUT_SCOPE_TEXT} — 이 계정이 변경을 볼 수 있는 프로젝트: {_mine_text(scope)}. "
                     "더 보려면 관리자에게 열람 범위를 부탁하세요.")
    return True


def _records_only(h) -> bool:
    """기록 열람만(forms.boxes: false) 서버인가 — 이때는 변경 기록이 이 서버의 첫 화면이다."""
    return not getattr(h.server, "boxes", True)


NAV_GROUP = "프로젝트 문서"           # 왼쪽 메뉴 묶음 이름 (화면 3판 큰 그림 2026-11-20 — 감시 화면과 같은 말)


def nav_items(h) -> list:
    """메뉴 줄들 [(주소, 이름, 수, 수 뜻)] — 감시 화면과 같은 말: 프로젝트 · 최근 변경 · 확인 필요 N (화면 3판 큰 그림 2026-11-20).
    열람할 수 있는 계정에게만 (그 밖에는 메뉴에도 없다). 기록 열람만이면 열람 범위가 아직 없는 직원에게도 '프로젝트' 한 줄 —
    그 화면(/changes)이 이 서버의 첫 화면이고 '관리자가 정해 주면 보입니다' 안내를 200으로 보인다 (V3-5: 메뉴가 비고 404였다).
    수는 '확인 필요'에만(내 범위의 열린 확인 필요 — /changes/issues·첫 화면과 같은 수), 프로젝트·최근 변경은 수 없이."""
    w = getattr(h.server, "watch_log", None)
    if w is None:
        return []
    try:
        acc = access_of(h.server.store, h.sess.user_id, h.sess.role)
    except Exception:
        return []
    if acc is None:
        return [("/changes", "프로젝트", 0, "")] if _records_only(h) else []
    n = 0
    try:
        counts = w.open_issue_counts() or {}
        n = sum(v for k, v in counts.items() if acc == "all" or k in acc)
    except Exception:      # noqa: BLE001 — 메뉴 수 하나 때문에 화면이 죽으면 안 된다
        n = 0
    try:                   # '내 담당 N' — 맡겨진 일이 있거나 담당을 정할 수 있는 계정에게만 (2026-11-23 사내망 협업)
        from watcher.forms.collab import mine_nav
        mine = mine_nav(h, acc)
    except Exception:      # noqa: BLE001 — 메뉴 줄 하나 때문에 화면이 죽으면 안 된다
        mine = []
    return [("/changes", "프로젝트", 0, ""), ("/changes/recent", "최근 변경", 0, ""),
            ("/changes/issues", "확인 필요", n, f"열린 확인 필요 {n}건")] + mine


def nav_item(h):
    """옛 이름 — 첫 메뉴 줄 하나(없으면 None). 새 코드는 nav_items."""
    got = nav_items(h)
    return got[0] if got else None


NO_ACCESS_TEXT = "아직 볼 수 있는 프로젝트가 없습니다."


def _no_access_page(h) -> None:
    """기록 열람만 서버의 첫 화면(/changes) — 열람 범위가 없는 직원에게 404 대신 안내(200). 링크·단추 없이 (V3-5)."""
    body = (f'<div class="rec ds-rec"><section class="ds-card"><div class="ds-empty"><b>{E(NO_ACCESS_TEXT)}</b>'
            '<div class="ds-sm">관리자가 볼 프로젝트를 정하면 여기에 보입니다. '
            '관리 › 계정 › 변경 열람에서 정합니다.</div></div></section></div>')
    h._send(200, h._shell("프로젝트", body, active="/changes"))


def _in(scope, project) -> bool:
    return scope is None or (project or "미분류") in scope


def _local(iso, fmt: str = "%Y-%m-%d %H:%M") -> str:
    from watcher.change_ledger import _local as L
    d = L(iso)
    return d.strftime(fmt) if d else ""


def _mtime(ts) -> str:
    try:
        from watcher.brief import saved_stamp
        return saved_stamp(ts)
    except (TypeError, ValueError, OSError, OverflowError):
        return ""


def _unavailable(h, why: str, status: int = 200) -> None:
    lead = "잠시 기다려 주세요" if status == 503 else "감시 기록을 열 수 없습니다"
    # 기록 열람만이면 양식함이 없다 — '양식함의 다른 화면'·[양식함으로](404)는 감춘다 (V3-10)
    rec = _records_only(h)
    body = (f'<div class="note bad" role="alert"><b>{lead}.</b> {E(why)}</div>'
            + ("" if rec and status == 503 else
               '<p class="muted">' + ("" if rec else "양식함의 다른 화면은 그대로 쓸 수 있습니다.")
               + ("" if status == 503 else (" " if not rec else "") + "감시 PC 관리자에게 알려 주세요.") + '</p>')
            + ("" if rec else '<p><a class="ds-btn" href="/forms">양식함으로</a></p>'))
    h._send(status, h._shell("변경 확인", body, active="/changes"))


def _guarded(fn):
    """감시 기록을 여는 화면 — 열 수 없으면 그 화면만 안내, 잠겨 있으면 잠시 뒤 다시(503)."""
    def run(h):
        try:
            fn(h)
        except WatchBusy as e:
            _unavailable(h, str(e), 503)
        except WatchUnavailable as e:
            _unavailable(h, str(e))
    run.__name__ = fn.__name__
    return run


def _projects(st: State, scope) -> list[str]:
    ps = [r[0] for r in st.conn.execute("SELECT DISTINCT IFNULL(project, '미분류') FROM changes ORDER BY 1")]
    return [p for p in ps if _in(scope, p)]


def _filters(h, scope) -> dict:
    S = _S()
    q = h._query()
    p = S.FormsHandler._one(q, "p").strip()
    if p and not _in(scope, p):
        p = ""                                   # 범위 밖 이름은 없는 것처럼 — 고르지 않은 것으로
    from watcher.change_ledger import parse_day
    d1 = parse_day(S.FormsHandler._one(q, "from"))
    d2 = parse_day(S.FormsHandler._one(q, "to"))
    show = S.FormsHandler._one(q, "show")
    return {"p": p, "from": d1, "to": d2, "show": "unacked" if show == "unacked" else "all"}


def _scope_set(scope, p: str):
    """조회에 쓸 프로젝트 모음 — 하나를 골랐으면 그것만, 아니면 내 범위(None = 모두)."""
    if p:
        return frozenset([p])
    return scope


def _qs(f: dict, **over) -> str:
    d = {"p": f["p"], "from": f["from"].isoformat() if f["from"] else "", "to": f["to"].isoformat() if f["to"] else "",
         "show": f["show"] if f["show"] != "all" else ""}
    d.update(over)
    d = {k: v for k, v in d.items() if v}
    return ("?" + urlencode(d)) if d else ""


# ── /changes — 최근 변경 · 프로젝트 타임라인 (2026-11-17 R3, 감시 화면 R2와 같은 꼴) ─────────────────────
# 단정한 목록 하나: 단추 없이 줄 전체가 상세 링크, 확인 필요가 위, 날짜별 묶음, 줄마다 R1 한 줄 요약(watcher.summary).
# 거르기(기간·미확인만)와 프로젝트별 표는 '변경 찾기'(?view=list — 그 밖에 show·from·to가 붙은 옛 메일 링크도)로 남긴다.

WINDOW_DAYS = 7                      # 첫 화면 — 마지막 검사 날까지 7일
DAY_ROWS = 20                        # 하루에 보이는 줄 — 넘으면 '이 날 N건 더 →'
TODO_ROWS = 5                        # 확인 필요 줄 — 넘으면 '확인 필요 전체 N건 →'
QUIET_ROWS = 50                      # 하루 '그 밖' 펼침 안의 줄 상한
ADD_FOLD = 5                         # 한 날·한 프로젝트의 새 파일이 이만큼이면 '새 파일 N개' 한 줄로 접는다 (화면 3판, 감시 화면과 같은 수)
HOME_LOAD = 5000                     # 첫 화면이 읽는 변경 상한(7일 안)
TIMELINE_LOAD = 3000                 # 타임라인이 읽는 변경 상한(최근부터) — 검색도 이 안에서
TIMELINE_ROWS = 300                  # 타임라인에 보이는 줄 상한
_WEEK = "월화수목금토일"


def _list_mode(q) -> bool:
    """옛 '변경 찾기' 표를 그릴까 — ?view=list, 또는 기간·미확인 거르기가 붙은 주소(옛 메일의 /changes?show=unacked 등)."""
    S = _S()
    return (S.FormsHandler._one(q, "view") == "list"
            or any(S.FormsHandler._one(q, k) for k in ("show", "from", "to")))


@_guarded
def get_changes(h) -> None:
    """/changes — 화면 3판 큰 그림(2026-11-20 '프로젝트별 문서 관리'): 첫 화면 = 프로젝트 목록(_projects_home).
    옛 주소는 같은 뜻 그대로 — ?p=X는 그 프로젝트의 변경 기록(메일의 'X 기록' 링크, brief.lan_project_url),
    ?view=list·show·from·to는 변경 찾기(옛 메일의 /changes?show=unacked). 날짜별 최근 변경은 /changes/recent로 옮겼다."""
    q = h._query()
    if _records_only(h):
        _watch(h)
        if access_of(h.server.store, h.sess.user_id, h.sess.role) is None:
            _no_access_page(h)                  # 첫 화면이 404면 갈 곳이 없다 (V3-5) — 상세·사진·엑셀은 그대로 404
            return
    if _list_mode(q):
        _get_changes_list(h)
        return
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    p = S.FormsHandler._one(q, "p").strip()
    if p and not _in(scope, p):
        p = ""                                   # 범위 밖 이름은 없는 것처럼 — 첫 화면 (위에 한 줄, 검토 Y3 L1)
        _note_out_of_scope(h, scope)
    if p:
        _timeline(h, w, scope, p, S.FormsHandler._one(q, "q").strip()[:100])
    else:
        _projects_home(h, w, scope)


@_guarded
def get_changes_recent(h) -> None:
    """/changes/recent — 최근 변경(날짜별, 최근 7일). 화면 3판 큰 그림 전까지의 첫 화면(/changes) 그대로."""
    scope = _scope(h)
    w = _watch(h)
    _note_out_of_scope(h, scope)                 # /changes/recent?p=범위 밖 — 위에 한 줄 (검토 Y3 L1)
    _home(h, w, scope)


def _md(d) -> str:
    return f"{d.month}월 {d.day}일"


def _week_label(window) -> str:
    """7일 창의 이름 — '최근 7일(11월 11일 ~ 17일)'. 감시 화면(_rc_week)과 같은 말 — '이번 주'·'지난 7일'이 화면마다 갈렸고
    기간이 없었다(창은 마지막 검사 날 기준이라 오늘과 다를 수 있다, 검토 W M1). 해가 다르면 연도까지."""
    start, end = window
    if start.year != end.year:
        per = f"{start.year}년 {start.month}월 {start.day}일 ~ {end.year}년 {end.month}월 {end.day}일"
    elif start.month == end.month:
        per = f"{start.month}월 {start.day}일 ~ {end.day}일"
    else:
        per = f"{start.month}월 {start.day}일 ~ {end.month}월 {end.day}일"
    return f"최근 {WINDOW_DAYS}일({per})"


def _day_title(d) -> str:
    return f"{d.month}월 {d.day}일 ({_WEEK[d.weekday()]})"


def _last_scan(st: State):
    """(마지막 검사 지역 시각 datetime | None)."""
    from watcher.change_ledger import _local as L
    try:
        row = st.conn.execute("SELECT MAX(run_at) FROM snapshots").fetchone()
    except sqlite3.OperationalError:
        return None
    return L(row[0]) if row and row[0] else None


def _scan_text(last) -> str:
    return f"마지막 검사 {_md(last)} {last:%H:%M}" if last else "아직 검사 기록이 없습니다"


# '그 밖' 접힌 줄의 말 — 감시 화면 web._RC_QUIET_PH와 같은 말('그 밖에 위치만 옮긴 파일 3개'). web을 가져오지 않으려 같은 표를 둔다
_QUIET_PH = {"이동": "위치만 옮긴 파일", "다시 저장": "다시 저장만 한 파일", "사본": "복사본", "빈 파일": "빈 파일",
             "일자만 갱신": "일자만 바뀐 파일", "표제란 틀만": "표제란 틀만 바뀐 파일", "구판 정리": "구판 정리한 파일",
             "순서만 바뀜": "순서만 바뀐 파일", "첫 등록": "첫 등록 파일"}


def _quiet_kind(note: str, moved: bool) -> str:
    """'그 밖' 줄의 갈래 한 마디 — 감시 화면 web._rc_quiet_kind와 같은 규칙(이동·사본·빈 파일·일자만 갱신·…, 나머지는 다시 저장)."""
    n = note or ""
    if moved:
        return "이동"
    for words, lab in ((("이름·위치만", "옮겨짐"), "이동"), (("복사본",), "사본"), (("빈 파일",), "빈 파일"),
                       (("일자만 갱신",), "일자만 갱신"), (("표제란 틀만",), "표제란 틀만"), (("구판 정리",), "구판 정리"),
                       (("순서만 바뀜", "배치만 바뀜"), "순서만 바뀜")):
        if any(w in n for w in words):
            return lab
    return "다시 저장"


def _gather(st: State, chs: list) -> dict:
    """변경 행 → 화면에 쓸 것: 주요/그 밖 접기(메일과 같은 규칙), 확인 기록, 확인 대상 아님, 이동 전 경로."""
    from watcher.change_ledger import acks_by_change
    ids = [c["id"] for c in chs]
    exempt, notes = st.ack_marks(ids)
    main, quiet, moved = _fold(chs, notes)
    # 목록의 '의견 N' (2026-11-23 사내망 협업) — 감시 화면 목록과 같은 수(State.comment_counts), 옛 DB면 없음
    cm = st.comment_counts("change", ids) if (ids and st.has_collab()) else {}
    return {"main": main, "quiet": quiet, "moved": moved, "notes": notes, "exempt": exempt,
            "acks": acks_by_change(st, ids), "cm": cm}


_KIND_HEAD = re.compile(r"\[([^\[\]]{1,12})\] ")


def split_kind(summary: str) -> tuple[str, str]:
    """요약 문장 머리 '[도면] …'·'[확인 필요] …'을 (종류, 나머지)로 — 화면은 종류를 줄마다 같은 자리의 작은 칩으로 그린다
    (화면 모양 v2, 2026-11-18 '행열도 잘 나눠서'). 머리가 없으면 ("", 문장). 저장된 요약 글자는 바꾸지 않는다."""
    s = str(summary or "")
    m = _KIND_HEAD.match(s)
    return (m.group(1), s[m.end():]) if m else ("", s)


def kind_chip(kind: str) -> str:
    """종류 칩 — '확인 필요'만 주황(.hot), 나머지는 회색. 빈 종류는 빈 칸(열 자리는 남는다)."""
    if not kind:
        return '<span class="rec-k"></span>'
    hot = " hot" if kind.startswith("확인 필요") else ""
    return f'<span class="rec-k"><span class="ui-kind{hot}">{E(kind)}</span></span>'


def _iss_view(code, msg, evs, path: str) -> tuple[str, list, list]:
    """확인 필요 하나 → (사실 한 줄, 화면에 남길 근거 줄들, 자세히 문장들) — 감시 화면·메일과 같은 함수
    (consistency.issue_text·issue_detail). 저장 문구·근거는 그대로 두고 보일 때만 나눈다 (화면 v2, 2026-11-19 — 사내망만
    긴 원문을 그대로 보이던 것)."""
    from watcher.consistency import issue_detail, issue_text
    fact, _d = issue_text(code, msg, path, evidence=evs if isinstance(evs, list) else [])
    shown, notes = issue_detail(code, msg, evs if isinstance(evs, list) else [], path)
    return fact, shown, notes


def _iss_more(notes) -> str:
    """접힌 '자세히' — 확인 필요의 이유·하면 되는 일. 없으면 ''."""
    notes = [n for n in (notes or []) if n]
    if not notes:
        return ""
    return ('<details class="more"><summary>자세히</summary>' + "".join(f'<p>{E(n)}</p>' for n in notes) + '</details>')


# ── 화면 3판 (2026-11-20) — 감시 화면 시안(최근 변경·확인 필요·변경 상세)과 같은 꼴 ─────────────────────────────────
# 목록은 모두 칸 이름이 있는 표(.ds-t): 바뀐 내용 = 프로젝트 · 문서 · 파일 · 바뀐 곳 · 이전 · → · 지금 · 상태 · ›,
# 확인 필요 = 문제 · 프로젝트 · 대상 · 근거 · 발견 · ›. 값은 변경 항목(change_details)의 이전/새 값 그대로(원칙 4·5) — 한 줄 요약
# (watcher.summary)과 같은 차례로 앞 세 곳만, 나머지는 '외 N건'. 확인 필요 문구는 consistency.issue_text·issue_detail 그대로 칸으로 나눈다.
# 표시는 네 가지 색 — 빨강 확인 필요 · 노랑 Rev 관련 · 초록 확인함 · 회색 종류. 이 서버는 스크립트가 없어(CSP script-src 'none')
# 줄 전체 누르기 대신 파일 이름과 줄 끝 ›가 실제 링크다.

from watcher.consistency import LABEL_TONE, SHORT_LABEL   # noqa: E402 — 짧은 이름·색 한 곳 (가벼운 모듈: 추출기 import 없음)

ISSUE_TAG = {c: (SHORT_LABEL[c], LABEL_TONE.get(c, "red")) for c in SHORT_LABEL}   # 확인 필요 표시 — 짧은 이름과 색은
# consistency 한 곳(감시 화면·메일과 같은 말, 2026-11-20). 긴 이름은 title로
_EV_TAIL = re.compile(r"\(([^()]*)\)\s*$")
_EV_ROW = re.compile(r"행\s?(\d+)|(\d+)행")


def issue_tag(code: str) -> str:
    """확인 필요 종류 표시 하나 (HTML)."""
    from watcher.consistency import CODE_LABEL
    full = CODE_LABEL.get(code, code)
    lab, col = ISSUE_TAG.get(code, (full, "red"))
    return f'<span class="ds-tg {col}" title="{E(full)}">{E(lab)}</span>'


def _cols(*names) -> str:
    """표 칸 폭 — 인라인 style을 CSP가 막으므로 col 클래스로 (DS_REC_CSS)."""
    return "<colgroup>" + "".join(f'<col class="{n}">' for n in names) + "</colgroup>"


def _triple(it: dict, has_rev: bool, full: bool = False):
    """변경 항목 하나 → (바뀐 곳, 이전, 지금) 글자. 값은 항목의 old/new 그대로(공백 접기·길이 자르기만 — summary._v).
    요약 조각(summary._part)과 같은 항목을 같은 말로. 표에 실을 것이 없는 항목은 None. full: 자르지 않는다(변경 상세)."""
    from watcher.summary import _rev_item, _v as _cut
    _v = (lambda v: " ".join(str(v or "").split())) if full else _cut
    k = str(it.get("kind") or "")
    key = " ".join(str(it.get("key") or "").split())
    o, n = it.get("old"), it.get("new")
    if _rev_item(it):
        return "Rev", ("없음" if str(o or "").strip() in ("", "-", "—") else _v(o)), _v(n)
    if k == "FIELD_CHANGED":
        from watcher.diff import field_label
        return field_label(key) or key, _v(o) or "(빈칸)", _v(n) or "(빈칸)"
    if k == "TEXT_CHANGED":
        so, sn = " ".join(str(o or "").split()), " ".join(str(n or "").split())
        if key and so.startswith(key + " ") and sn.startswith(key + " "):
            ro, rn = so[len(key):].strip(), sn[len(key):].strip()
            if ro and rn:
                return key, _v(ro), _v(rn)              # 태그 줄 'M-101 5.5kW → M-101 7.5kW' — 태그는 바뀐 곳에 한 번
        if not key or so.startswith(key) or sn.startswith(key):
            return "글자", _v(so), _v(sn)
        return key, _v(so), _v(sn)
    # 이전/지금 두 줄(2026-11-21 규칙 4): 없던 것은 [이전] 없음, 없어진 것은 [지금] 없음. 행 추가·삭제는 그 행 값을 함께
    if k == "TEXT_ADDED":
        return "글자", "없음", _v(n)
    if k == "TEXT_REMOVED":
        return "글자", _v(o), "없음"
    if k == "ROW_CHANGED":
        rk, sep, col = split_row_cell(key)
        return ((f"{rk} · {col}" if (rk and col) else f"{rk} {col}".strip()) if sep else key), _v(o) or "(빈칸)", _v(n) or "(빈칸)"
    # 행 값은 앞 5칸 + '외 N칸'(brief.row_dot = 감시 화면 web._row_join) — 40자 자르기('MOTOR 7.5kW ·…')를 다시 걸지 않는다
    if k == "ROW_ADDED":
        from watcher.brief import row_dot
        return f"{key} 행", "없음", (row_dot(n) or "추가")
    if k == "ROW_REMOVED":
        from watcher.brief import row_dot
        return f"{key} 행", (row_dot(o) or "있음"), "없음"
    # 개정표 행 — 감시 화면(web 변경 칸)과 같은 값: 추가는 [지금] 그 행 글, 삭제는 [이전] 그 행 글
    if k == "REVROW_ADDED":
        return None if has_rev else (f"개정표 {key} 행", "없음", _v(n) or "추가")
    if k == "REVROW_REMOVED":
        return f"개정표 {key} 행", _v(o) or "있음", "없음"
    if k == "REVROW_CHANGED":
        if str(o or "").strip() and str(n or "").strip():
            return f"개정표 {key} 행", _v(o), _v(n)
        return f"개정표 {key} 행", "", "변경"
    if k == "PAGE_VISUAL_CHANGED":
        return f"그림 {key}".strip(), "", "바뀜"          # 감시 화면과 같은 말('그림 1쪽')
    if k == "NEW_REVISION_OF":
        return "이전 판", _v(o), _v(n)
    if k == "CHECK_SKIPPED" and ("추출 실패" in key or (key == "내용 비교" and "수행 못 함" in str(n or ""))):
        from watcher.brief import _unread_label
        return "내용", "", f"읽지 못함 — {_unread_label(str(n or ''))}"
    if k in ("COL_RENAMED", "SHEET_RENAMED") and o and n:
        from watcher.brief import _ITEM_KIND
        return _ITEM_KIND[k][0], _v(o), _v(n)
    if k in ("EMBED_CHANGED", "PAGE_ADDED", "PAGE_REMOVED", "COL_ADDED", "COL_REMOVED", "COL_MOVED", "ROW_MOVED",
             "PAGE_MOVED", "TEXT_MOVED", "SHEET_ADDED", "SHEET_REMOVED", "COL_RENAMED", "SHEET_RENAMED"):
        from watcher.brief import _ITEM_KIND
        lab = _ITEM_KIND.get(k, (k,))[0]
        return (key, "", lab) if key and key != lab else (lab, "", "바뀜")
    return None


SHOW_PARTS = 3                       # 한 줄에 싣는 바뀐 곳 — 넘으면 앞 2곳 + '외 N곳' (감시 화면 _RC_SHOW_PARTS와 같은 수, 검토 X L2)


def _saved_day(s, tail: str = "") -> str:
    """'2026-10-08 16:01:06' → '10월 8일' + tail (감시 화면 _rc_saved와 같은 말). 꼴이 아니면 그대로."""
    m = re.match(r"\s*(\d{4})-(\d{2})-(\d{2})", str(s or ""))
    return f"{int(m.group(2))}월 {int(m.group(3))}일{tail}" if m else str(s or "")


def _move_parts(old, new) -> list:
    """이동 줄 — '위치 · 옛 폴더 / 새 폴더'(이름까지 바뀌면 '이름' 줄도), 감시 화면 _rc_move_parts와 같은 말. 대소문자만 바꾼 이름은
    '이름' 한 줄 — '위치 … 옮김'으로 보였다 (검토 X L2). 옛 경로가 열람 범위 밖이면(OUT_OF_SCOPE) 경로 없이 '다른 프로젝트 폴더'."""
    b = PurePosixPath(str(new or ""))
    if str(old or "") == OUT_OF_SCOPE:
        return [("위치", OUT_OF_SCOPE, b.parent.name or "(위 폴더)")]
    a = PurePosixPath(str(old or ""))
    pa, pb = a.parent.parts, b.parent.parts
    k = 0
    while k < len(pa) and k < len(pb) and pa[k] == pb[k]:
        k += 1
    out = []
    if pa != pb:
        out.append(("위치", "/".join(pa[k:]) or "(위 폴더)", "/".join(pb[k:]) or "(위 폴더)"))
    if a.name != b.name:
        out.append(("이름", a.name, b.name))
    return out or [("위치", "", "옮겨짐")]


def change_parts(kind: str, items, path: str, moved_from=None) -> tuple[list, int]:
    """변경 하나 → (보일 [(바뀐 곳, 이전, 지금)], 나머지 수) — 감시 화면 _rc_parts·_rc_parts_tds와 같은 말·같은 수(검토 X L2):
    값은 항목의 old/new 그대로(요약과 같은 무게 차례, 같은 줄은 한 번), 비교하지 않는 문서는 '내용 · ○월 ○일 저장본', 새 파일은
    '파일 · 없음 / 추가', 삭제는 '파일 · 있음 / 삭제됨'(+참고), 이동은 위치·이름. SHOW_PARTS곳을 넘으면 앞 2곳 + '외 N곳'."""
    from watcher.summary import _note_short, _rev_item, _weight
    items = [it for it in (items or []) if isinstance(it, dict)]
    if moved_from:
        parts = _move_parts(moved_from, path)
    else:
        has_rev = any(_rev_item(it) for it in items)
        got = []
        for it in items:
            t = _triple(it, has_rev)
            if t:
                got.append((_weight(it), t))
        got.sort(key=lambda x: x[0])
        parts, seen = [], set()
        for _w, t in got:
            if t not in seen:
                seen.add(t)
                parts.append(t)
        if parts and all(t[0] == "저장 시각" for t in parts):
            # 내용을 비교하지 않는 문서 — 바뀐 사실(저장본이 바뀜)만 (PILOT.md: 도면·BOM 외 문서는 바뀐 사실만)
            parts = [("내용", _saved_day(parts[0][1], " 저장본"), _saved_day(parts[0][2], " 저장본"))]
        else:
            parts = [(t[0], _saved_day(t[1]), _saved_day(t[2])) if t[0] == "저장 시각" else t for t in parts]
        if kind == "added" and not parts:
            from watcher.summary import restored_short
            rs = restored_short(items)          # 지웠다 같은 자리에 되살린 파일 — '새 문서'가 아니다 (Y1 P3b)
            parts = [("파일", "", rs)] if rs else [("파일", "없음", "추가")]
        elif kind == "removed":
            note = _note_short(items, path)
            parts = [("파일", "있음", "없음")] + parts + ([("참고", "", note)] if note else [])     # 규칙 4 — 없어진 것은 [지금] 없음
        elif not parts:
            note = _note_short(items, path)
            parts = [("파일", "", note)] if note else [("내용", "", "바뀜")]
    if len(parts) > SHOW_PARTS:
        return parts[:SHOW_PARTS - 1], len(parts) - (SHOW_PARTS - 1)
    return parts, 0


# ── 열람 범위 밖 경로 가리기 (검토 X L1) ────────────────────────────────────────────────────────────────────────────
# 범위 밖 프로젝트 폴더에서 옮겨 온 파일의 '참고' 글('이름·위치만 바뀜 — 이전: 설계/P26-101 컨베이어/도면/SECRET-999.dxf')이 범위 밖
# 폴더·파일 이름을 보였다. 그 경로의 가장 최근 변경 줄이 범위 밖 프로젝트(또는 기록 없음)면 경로 대신 OUT_OF_SCOPE — 상세·문서함·
# 문서 이력·변경 기록·최근 변경·변경 찾기·엑셀 모두. 저장된 글은 그대로 두고 보일 때만(읽기 전용).
OUT_OF_SCOPE = "다른 프로젝트 폴더"
_NOTE_PATHS = (
    re.compile(r"^이름·위치만 바뀜 — 이전: (.+?)(?: \((?:내용 동일|다른 이름·다른 폴더라 이동으로 묶지 않았습니다)\))?$"),
    re.compile(r"^(.+?)\(으\)로 (?:옮겨짐|옮겨지며 내용도 바뀜) — "),
    re.compile(r"^(.+?)에서 옮겨짐"),
    re.compile(r"^삭제됨 — 같은 내용의 새 파일 있음: (.+?)(?: 외 \d+곳)?(?: \(다른 이름·다른 폴더라 이동으로 묶지 않았습니다\))?$"),
)


def note_paths(note) -> list:
    """'참고' 글이 가리키는 다른 경로들 — 글 전체와, 여러 '참고'를 이은 글(_items_note)이면 줄마다도 (검토 X2 L4)."""
    raw = str(note or "")
    out = []
    for s in [raw] + (raw.split("\n") if "\n" in raw else []):
        s = " ".join(s.split())
        out += [m.group(1).strip() for rx in _NOTE_PATHS for m in [rx.match(s)] if m]
    return list(dict.fromkeys(out))


def _items_note(items) -> str:
    """'참고' 글 — 여럿이면 모두를 줄바꿈으로 이어서(범위 밖 경로 가리기가 첫 '참고'만 보면 둘째 글의 경로가 그대로 보였다:
    2026-11-21 검토 X2 L4). 이동 표지를 읽는 곳은 줄 하나만 본다(_move_prev)."""
    return "\n".join(str(it.get("new") or "") for it in items or ()
                     if isinstance(it, dict) and it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고")


def _move_prev(note: str) -> str:
    """'참고' 글의 이동 표지 뒤 옛 경로 — 표지가 든 그 줄에서만 읽는다."""
    from watcher.brief import _MOVE_MARK
    return str(note).split(_MOVE_MARK, 1)[1].split("\n", 1)[0].split(" (내용 동일")[0].strip()


class _Hider:
    """요청 하나 동안 '이 경로가 내 범위인가'를 한 번씩만 묻는다. scope가 None(전체)이면 아무것도 가리지 않는다."""

    def __init__(self, st: State, scope):
        self.st, self.scope, self._memo = st, scope, {}

    def out(self, paths) -> set:
        if self.scope is None:
            return set()
        got = set()
        for p in paths:
            if p not in self._memo:
                self._memo[p] = not _doc_in_scope(self.st, p, self.scope)
            if self._memo[p]:
                got.add(p)
        return got

    def out_of_note(self, note) -> set:
        return self.out(note_paths(note))

    def path(self, p):
        """이동 전 경로 하나 — 범위 밖이면 OUT_OF_SCOPE."""
        return OUT_OF_SCOPE if (p and self.out([p])) else p

    def items(self, items) -> list:
        """'참고' 글의 범위 밖 경로를 OUT_OF_SCOPE로 바꾼 사본(다른 항목은 그대로)."""
        items = list(items or [])
        bad = self.out_of_note(_items_note(items))
        if not bad:
            return items
        out = []
        for it in items:
            if isinstance(it, dict) and it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
                it = dict(it, new=hide_text(" ".join(str(it.get("new") or "").split()), bad))
            out.append(it)
        return out

    def text(self, s, note, ref: str = "") -> str:
        """요약 같은 글 — 그 변경의 참고 글이 가리키는 범위 밖 경로(전체·짧은 꼴)를 OUT_OF_SCOPE로."""
        bad = self.out_of_note(note)
        return hide_text(s, bad, ref) if bad else s


def hide_text(s, bad: set, ref: str = "") -> str:
    from watcher.summary import _short_path
    s = str(s or "")
    forms = set()
    for p in bad:
        forms.add(p)
        if ref:
            forms.add(_short_path(p, ref))
    for f in sorted((f for f in forms if f), key=len, reverse=True):
        s = OUT_OF_SCOPE.join(s.split(f))
    # 글자 수로 잘린 꼴(대장의 한 줄 머리 '… 이전: srv/P26-050/SECRET-999.d', 요약의 '…')도 — 앞부분만 남은 경로
    for p in bad:
        for k in range(len(p) - 1, 5, -1):
            frag = p[:k]
            if frag + "…" in s:
                s = OUT_OF_SCOPE.join(s.split(frag + "…"))
                break
            if s.endswith(frag):
                s = s[:-len(frag)] + OUT_OF_SCOPE
                break
    return s


def _pv(o, n, labels: tuple = ("이전", "지금"), side: bool = False) -> str:
    """이전/지금 두 줄 (2026-11-21 사용자 '바뀌기 전·바뀐 부분은 행을 바꿔서 — 화살표 빼고는 구분이 안 된다'). 글자는 여기서 이스케이프.
    side: 서로 다른 두 출처를 견주는 근거 — [도면] / [BOM]처럼 이름표만 다르고 둘 다 진한 글자. 화살표는 쓰지 않는다."""
    from watcher.brief import no_bidi
    lo, ln = labels
    # 감시 화면(web._pv·_pv_side)과 같은 마크업 — 출처 견주기는 ds-pv-side(줄에 o/n 없음). 'side' 한 낱말은 왼쪽 메뉴(.side)와 겹친다
    if side:
        return (f'<div class="ds-pv ds-pv-side">'
                f'<div class="ds-pv-r"><span class="ds-pv-l">{E(lo)}</span> <span class="ds-pv-v">{E(no_bidi(o))}</span></div>'
                f'<div class="ds-pv-r"><span class="ds-pv-l">{E(ln)}</span> <span class="ds-pv-v">{E(no_bidi(n))}</span></div></div>')
    return (f'<div class="ds-pv">'
            f'<div class="ds-pv-r o"><span class="ds-pv-l">{E(lo)}</span> <span class="ds-pv-v">{E(no_bidi(o) or "없음")}</span></div>'
            f'<div class="ds-pv-r n"><span class="ds-pv-l">{E(ln)}</span> <span class="ds-pv-v">{E(no_bidi(n) or "없음")}</span></div></div>')


def _pv_val(o, n, key: str = "") -> str:
    """한 곳의 값 — 이전 값이 없으면(그림 바뀜·다시 저장·첫 등록) 지금 글 한 줄, 있으면 이전/지금 두 줄.
    key는 감시 화면과 맞춘 자리(이름 바뀜도 바뀐 곳 '이름' + [이전]/[지금]). 새 문서는 [이전] 없음 / [지금] 새 문서 — 감시 화면
    _rc_pv_vals와 같은 말(데이터 칸 값 '추가'는 그대로 두고 보일 때만)."""
    from watcher.brief import no_bidi
    if not o:
        return f'<div class="ds-pv-one">{E(no_bidi(n))}</div>'
    if (key, o, n) == ("파일", "없음", "추가"):
        n = "새 문서"
    return _pv(o, n)


def unarrow(s) -> str:
    """문장 속 값 사이 화살표를 말로 (brief.unarrow — 메일과 같은 규칙, 2026-11-21)."""
    from watcher.brief import unarrow as _u
    return _u(s)


def unarrow_summary(s, items=None) -> str:
    """기록의 한 줄 요약을 보일 때만 화살표 없이 (brief.unarrow_summary — 저장 글은 그대로). items: 그 변경의 항목 — 항목에서 만든 조각과
    글자까지 같은 곳만 바꾼다(다시 쪼개 짐작하지 않는다, 검토 Y2 H1)."""
    from watcher.brief import unarrow_summary as _u
    return _u(s, items)


def no_xy(s) -> str:
    """위치 글의 좌표('…, x=330, y=21'·'좌표 (12, 34)')를 뺀다 — 표에는 좌표를 싣지 않는다(변경 상세에서만, 감시 화면과 같은 규칙).
    좌표 꼴은 메일·위치 칸과 같은 정규식(brief._XY_WORD) 하나."""
    from watcher.brief import _XY_WORD
    return _XY_WORD.sub("", str(s or ""))


def small_line(text, cls: str = "ds-sm", tag: str = "div", xy: bool = True) -> str:
    """확인 필요의 작은 근거 줄 — '바뀐 곳: 이전 → 지금 (위치)' 꼴은 바뀐 곳(굵게) · 이전/지금 두 줄 · 위치(작게)로, 나머지는 글 한 줄
    (문장 속 화살표는 말로). 2026-11-21 세부 점검표 A10 — 값 사이 화살표를 남기지 않는다."""
    from watcher.brief import ev_pair, no_bidi
    if not xy:
        text = no_xy(text)
    pr = ev_pair(text)
    if pr:
        from watcher.brief import ev_none
        return (f'<div class="ds-pb ds-pv-ev"><div class="ds-pk">{E(no_bidi(pr[0]))}</div>'
                f'{_pv(ev_none(pr[1], bool(pr[0])), ev_none(pr[2], bool(pr[0])))}'
                + (f'<div class="ds-sm ds-pv-at">{E(no_bidi(pr[3]))}</div>' if pr[3] else "") + '</div>')
    return f'<{tag} class="{cls}">{E(no_bidi(unarrow(text)))}</{tag}>'


def _last_change_html(kind: str, items, path: str, cap: int) -> str:
    """프로젝트 목록 '마지막 변경'·문서함 '최근 변경' 칸의 값 — 바뀐 곳(굵게) 한 줄 + 이전/지금 두 줄, 곳이 여럿이면 앞 cap곳 +
    '외 N곳' (2026-11-21 시안 ②). 값이 없는 변경(새 문서·삭제·다시 저장·이동)은 ''(부르는 쪽이 docbox.change_text 한 줄로)."""
    from watcher.brief import no_bidi
    its = [it for it in (items or []) if isinstance(it, dict)]
    trip, rest = change_parts(kind, its, path)
    if not any(o for _a, o, _n in trip) or (kind in ("added", "removed") and trip and trip[0][0] == "파일"):
        return ""
    shown = trip[:max(1, cap)]
    more = rest + len(trip) - len(shown)

    def _blk(a, o, n) -> str:
        # 내용을 비교하지 않는 문서 — 바뀐 곳 '저장본' + 날짜 두 줄 (감시 화면 _rc_parts_blocks와 같은 말)
        if a == "내용" and str(o).endswith(" 저장본") and str(n).endswith(" 저장본"):
            a, o, n = "저장본", str(o)[:-4], str(n)[:-4]
        return f'<div class="ds-pb"><div class="ds-pk">{E(no_bidi(a))}</div>{_pv_val(o, n, a)}</div>'
    return "".join(_blk(a, o, n) for a, o, n in shown) + (f'<div class="ds-sm">외 {more}곳</div>' if more else "")


def _items_of(st: State, cid: int) -> list:
    """변경 하나의 보이는 항목(숨긴 오탐 뺌) — 사전 목록."""
    from watcher.summary import visible_items
    d = st.change_detail(int(cid)) or {}
    return [it for it in visible_items(d.get("items") or [], d.get("dismissed") or {}) if isinstance(it, dict)]


def _opened_live(st: State, ids) -> dict:
    """변경 id → 그 변경으로 열린 확인 필요 가운데 **지금 열린** 것의 코드들 — 감시 화면 첫 화면과 같은 묶기
    (State._issues_opened_by). 읽기만. 못 읽으면 빈 사전(상태 칸이 비어 보일 뿐)."""
    ids = [int(i) for i in dict.fromkeys(ids) if i is not None]
    if not ids:
        return {}
    try:
        opened = st._issues_opened_by(st._summary_rows(ids))
        iids = sorted({d["id"] for v in opened.values() for d in v})
        live: set = set()
        for k in range(0, len(iids), 400):
            part = iids[k:k + 400]
            live |= {r[0] for r in st.conn.execute(
                f"SELECT id FROM issues WHERE resolved_at IS NULL AND id IN ({','.join('?' * len(part))})", part)}
    except Exception:            # noqa: BLE001 — 표시만 빠진다
        return {}
    out = {}
    for c, v in opened.items():
        codes = [str(d.get("code") or "") for d in v if d["id"] in live]
        if codes:
            out[int(c)] = codes
    return out


def _state_cell(cid: int, g: dict, opened: dict) -> str:
    """상태 칸 — 열린 확인 필요(빨강·노랑) 또는 확인함(초록). 아무것도 아니면 빈 칸."""
    from watcher.opinions import count_mark
    from watcher.summary import _ISSUE_ORDER
    codes = opened.get(cid) or []
    a = g["acks"].get(cid)
    cmk = count_mark((g.get("cm") or {}).get(cid))            # '의견 N' — 감시 화면 목록과 같은 수 (2026-11-23)
    cmk = f'<div class="ds-sm">{cmk}</div>' if cmk else ""
    if codes:
        codes = sorted(codes, key=lambda x: _ISSUE_ORDER.get(x, 9))
        # 확인 필요가 열려 있는 동안 확인 기록은 회색 작은 글 '확인 이름'만 — 초록 '확인함'이 같이 있으면 끝난 일처럼 읽힌다
        # (감시 화면 _status와 같은 말, V2-2)
        return (issue_tag(codes[0]) + (f' <span class="ds-m">외 {len(codes) - 1}</span>' if len(codes) > 1 else "")
                + (f'<div class="ds-sm">확인 {E(ack_label(a[-1]["by"]))}</div>' if a else "") + cmk)
    out = f'<span class="ds-tg green">확인함 · {E(ack_label(a[-1]["by"]))}</span>' if a else ""
    if str((g.get("summ") or {}).get(cid) or "").startswith("[확인 필요]"):
        out += ('<div class="ds-sm" title="이 변경으로 생긴 확인 필요는 모두 처리됐습니다">확인 필요 처리됨</div>')
    return out + cmk


def _value_cells(trip: list, rest: int) -> str:
    """바뀐 곳 · 이전 / 지금 — 두 칸(머리 '바뀐 곳'·'이전 / 지금')에 걸친 한 칸(colspan 2) 안의 격자. 곳마다 [바뀐 곳 | 두 줄],
    곳 사이 옅은 점선(2026-11-21 규칙 1·3). 격자 첫 칸 폭은 col.w-place와 맞춰(DS_REC_CSS .ds-pvg) 머리 칸 아래에 선다."""
    from watcher.brief import no_bidi
    cells = "".join(f'<div class="ds-pvk">{E(no_bidi(a))}</div><div class="ds-pvx">{_pv_val(o, n, a)}</div>' for a, o, n in trip)
    more = f'<div class="ds-pvmore">외 {rest}곳</div>' if rest else ""
    return f'<td class="c-pv" colspan="2"><div class="ds-pvg">{cells}{more}</div></td>'


def _chg_row(st: State, c: dict, g: dict, opened: dict, *, show_project: bool, moved_from=None, quiet: bool = False) -> str:
    """바뀐 내용 표의 한 줄. quiet: '그 밖' 줄 — 접기 줄을 펼쳐야 보인다(.ds-q)."""
    from watcher.brief import no_bidi
    from watcher.summary import _kind_tag
    cid = int(c["id"])
    href = f"/changes/{cid}"
    hider = g.get("hider")
    items = _items_of(st, cid)
    note = _items_note(items)
    if hider is not None:
        items, moved_from = hider.items(items), hider.path(moved_from)
    trip, rest = change_parts(c["kind"], items, c["path"], moved_from)
    pp = PurePosixPath(c["path"])
    proj = f'<td class="ds-b c-proj">{E(c["project"])}</td>' if show_project else ""
    # 한 줄 요약(R1 — State.record_summaries)은 파일 이름 링크의 title로 — 칸에는 나눠 싣고, 문장은 가리키면 보인다
    summ = (g.get("summ") or {}).get(cid) or ""
    if summ and hider is not None:
        summ = hider.text(summ, note, c["path"])
    tip = f' title="{E(no_bidi(unarrow_summary(summ, items)))}"' if summ else ""     # 항목에서 만든 조각만 바꾼다 (Y2 H1)
    return (f'<tr class="ds-row{" ds-q" if quiet else ""}" data-href="{href}">{proj}'
            f'<td class="c-doc"><span class="ds-tg gray">{E(_kind_tag(c["path"]))}</span></td>'
            f'<td class="ds-b ds-file c-file"><a href="{href}"{tip}>{E(no_bidi(pp.name))}</a></td>{_value_cells(trip, rest)}'
            f'<td class="c-state">{_state_cell(cid, g, opened)}</td>'
            f'<td class="ds-go c-go"><a href="{href}" aria-label="#{cid} 자세히">›</a></td></tr>')


def _chg_head(show_project: bool, last: str = "상태") -> str:
    # 이전/지금 두 줄(2026-11-21): '이전 | → | 지금' 세 칸 대신 '이전 / 지금' 한 칸
    cols = (("w-proj",) if show_project else ()) + ("w-doc", "w-file", "w-place", "w-val", "w-state", "w-go")
    # 칸 이름은 감시 화면 _RC_HEAD와 같은 말 — 종류 칸 '종류', 이름 칸 '문서'(문서함과 같은 말, 검토 W 고침 낮음 3)
    names = (("프로젝트",) if show_project else ()) + ("종류", "문서", "바뀐 곳", "이전 / 지금", last, "")
    return _cols(*cols) + "<thead><tr>" + "".join(f"<th>{n}</th>" for n in names) + "</tr></thead>"


def _ev_files(shown) -> str:
    """도면-BOM 불일치 근거 줄 → '도면 파일 ↔ BOM 파일 9행' (근거 줄의 위치 괄호 글자 그대로)."""
    bom = dwg = ""
    for ln in shown or ():
        s = " ".join(str(ln).split())
        m = _EV_TAIL.search(s)
        if not m:
            continue
        last = m.group(1).rsplit(", ", 1)[-1].strip()
        name = PurePosixPath("/".join(last.split(chr(92)))).name
        if "." not in name:
            continue
        if s.startswith("BOM") and not bom:
            r = _EV_ROW.search(m.group(1))
            bom = name + (f" {r.group(1) or r.group(2)}행" if r else "")
        elif not s.startswith("BOM") and not dwg:
            dwg = name
    return " ↔ ".join(x for x in (dwg, bom) if x)


_FACT_DAYS = re.compile(r" · \d+일째$")


def fresh_days(fact: str, detected_at) -> str:
    """사실 한 줄 끝의 'N일째'를 발견일부터 오늘까지로 — 변경 상세(감시 화면 web._ds_iss_line → _iss_day)와 같은 계산.
    저장 문구의 수는 발견 때 굳은 것이라 사내망 목록 '7일째'·상세 '5일째'가 갈렸다 (검토 Y3 L3). 발견 시각을 모르면 수를 뗀다."""
    m = _FACT_DAYS.search(fact or "")
    if not m:
        return fact
    from watcher.change_ledger import local_day
    d = local_day(detected_at)
    if d is None:
        return fact[:m.start()]
    n = (date.today() - d).days
    return fact[:m.start()] + (" · 오늘" if n <= 0 else f" · {n}일째")


def issue_cells(code, msg, evs, ipath: str, items=(), detected_at=None) -> tuple[str, str, list]:
    """확인 필요 하나 → (대상, 근거 첫 줄 HTML, 근거 작은 줄들 글자). 문구는 consistency.issue_text·issue_detail 그대로 —
    도면-BOM 불일치는 근거 줄의 도면 값·BOM 값(summary._mismatch_bits)을 굵게. 작은 줄 = 근거(파일·이번 변경) + 이유·하면 되는 일.
    detected_at: 그 확인 필요의 발견 시각 — 사실 한 줄의 'N일째'를 상세와 같은 계산으로 (fresh_days)."""
    from watcher.brief import human_ev, no_bidi
    from watcher.summary import _body, _mismatch_bits
    fact, shown, notes = _iss_view(code, msg, evs, ipath)
    fact = fresh_days(fact, detected_at)
    fname = PurePosixPath(ipath).name
    small: list = []
    if code == "BOM_MISMATCH":
        bits = _mismatch_bits(msg, evs if isinstance(evs, list) else [])
        if bits:
            # 이전/지금 두 줄(2026-11-21 규칙 5): 도면·BOM 다름은 [도면] 값 / [BOM] 값 두 줄, 파일·행은 아래 작은 줄
            tag, dwg, spec = bits
            files = _ev_files(shown)
            return (tag, _pv(dwg, spec, ("도면", "BOM"), side=True),
                    ([files] if files else []) + [n for n in notes if n])
    target = fname
    head, sep, _rest = fact.partition(": ")
    if sep and code in ("BOM_MISMATCH", "TAG_MISMATCH_ACROSS_DRAWINGS") and len(head) <= 30:
        target = head
    main = f"<b>{E(no_bidi(unarrow(fact)))}</b>"
    side = _side_pv(code, msg, shown)
    if side:
        main += side
    if code == "CONTENT_CHANGED_REV_SAME" and items:
        # 사실 한 줄(문장 그대로) 아래에 바뀐 값을 이전/지금 두 줄로 — 앞 한 곳 + '외 N곳' (2026-11-21 규칙 8)
        trip, rest = change_parts("modified", list(items), ipath)
        vals = [t for t in trip if t[1]]
        if vals:
            a, o, n = vals[0]
            more = rest + len(trip) - 1
            main += (f'<div class="ds-pk">{E(no_bidi(a))}</div>{_pv(o, n)}'
                     + (f'<div class="ds-sm">외 {more}곳</div>' if more else ""))
        else:
            body = _body(list(items), ipath)
            if body:
                small.append(body)
    elif shown and not notes and not side:
        small.append(human_ev(str(shown[0])))
    small = small[:1] + [n for n in notes if n]          # 근거 한 줄 + 이유·하면 되는 일(접지 않는다 — 화면 3판 '자세히' 없음)
    return target, main, small


def _side_pv(code, msg, shown) -> str:
    """서로 다른 두 출처를 견주는 확인 필요 → 같은 두 줄에 이름표만 [표제란]/[개정표]·[E-101]/[E-102] (2026-11-21 규칙 5).
    문구의 값 그대로(메일 brief._m_side_pair와 같은 읽기). 못 읽으면 ''."""
    from watcher.brief import _M_REVBLK, _M_VS
    m_ = str(msg or "")
    if code == "REV_BLOCK_MISMATCH":
        m = _M_REVBLK[0].search(m_)
        if m:
            return _pv(m.group(2), m.group(3), (m.group(1).strip(), "개정표"), side=True)
        m = _M_REVBLK[1].search(m_)
        if m:
            return _pv(m.group(3), m.group(1), (m.group(2), "개정표"), side=True)
    if code == "TAG_MISMATCH_ACROSS_DRAWINGS":
        m = _M_VS.search(m_)
        if m:
            names = []
            for ln in shown or ():
                t = _EV_TAIL.search(" ".join(str(ln).split()))
                if t:
                    nm = PurePosixPath("/".join(t.group(1).rsplit(", ", 1)[-1].split(chr(92)))).stem
                    if nm and nm not in names:
                        names.append(nm)
            labs = tuple(x[:12] for x in names[:2]) if len(names) >= 2 else ("한 도면", "다른 도면")
            return _pv(m.group(1).strip(), m.group(2).strip(), labs, side=True)
    return ""


def _issue_parts(st: State, rows: list, scope, *, h=None):
    """확인 필요 줄마다 보일 것 — rows: (id, code, path, project, message, evidence, detected_at). 표(_issue_rows)와 목록·상세(_issue_split)가
    같은 읽기를 쓴다. 전/후 보기 주소는 그 변경의 프로젝트가 이 계정 범위 안일 때만."""
    from watcher.change_ledger import local_day
    from watcher.forms import collab as _collab
    links = st.changes_for_paths([r[2] for r in rows]) if rows else {}
    cm_n, as_n = _collab.marks(st, "issue") if rows else ({}, {})      # '의견 N'·'담당 X' (2026-11-23 사내망 협업)
    collab_ok = bool(rows) and st.has_collab()
    for iid, code, ipath, proj, msg, ev, at in rows:
        try:
            evl = json.loads(ev or "[]")
        except ValueError:
            evl = []
        cid = links.get(ipath)
        href, items = "", []
        if cid is not None:
            rr = _row_of(st, int(cid))
            if rr and _in(scope, rr["project"]):
                href = f"/changes/{int(cid)}"
                if code == "CONTENT_CHANGED_REV_SAME":
                    items = _items_of(st, int(cid))
        target, main, small = issue_cells(code, msg, evl, ipath, items, detected_at=at)
        yield {"id": int(iid), "code": code, "path": ipath, "project": proj, "href": href, "target": target, "main": main, "small": small,
               "at": at, "day": local_day(at), "cm": cm_n, "as": as_n, "collab": collab_ok}


ISSUE_ROWS = 500              # 사내망 확인 필요 목록에 싣는 줄 — 넘으면 '외 N건' 한 줄


def _issue_line(d: dict) -> tuple[str, str]:
    """목록·미리보기의 (값 한 줄 HTML, 따로 남는 사실 한 줄 HTML). 바뀐 값이 두 줄 칸으로 있으면 값 한 줄 + 사실('Rev는 A 그대로'),
    표제란·개정표 다름은 사실 한 줄이 값보다 자세해('표제란 Rev B, 개정표 최신 행 A') 그것을, 그 밖은 값(없으면 사실)만."""
    from watcher import issue_view as IV
    m = re.match(r"<b>(.*?)</b>", d["main"])
    fact = m.group(1) if m else ""
    if fact and d["code"] == "REV_BLOCK_MISMATCH":
        return fact, ""
    line = IV.one_line(d["main"])
    return line, (fact if fact and '<div class="ds-pk">' in d["main"] else "")


def _issue_rows(st: State, rows: list, scope, *, show_project: bool, h=None, brief: bool = False) -> str:
    """확인 필요 표 줄들 — rows: (id, code, path, project, message, evidence, detected_at). brief: 첫 화면·최근 변경 미리보기는 값 한 줄 +
    작은 줄 하나(이유·하면 되는 일과 두 줄 값은 눌러서 — 감시 화면 첫 화면과 같은 짧은 꼴, 2026-11-24)."""
    from watcher.brief import no_bidi
    from watcher.forms import collab as _collab
    out = []
    for d in _issue_parts(st, rows, scope, h=h):
        href, proj, main = d["href"], d["project"], d["main"]
        sm = "".join(small_line(x, xy=False) for x in (d["small"][:1] if brief else d["small"]))      # 표 — 좌표 없음
        if brief:
            line, fact = _issue_line(d)
            main = f'<div class="ds-hot-v1">{line}</div>'
            sm = f'<div class="ds-sm">{fact}</div>' if fact else sm
        tgt = f'<a href="{E(href)}">{E(no_bidi(d["target"]))}</a>' if href else E(no_bidi(d["target"]))
        pj = (f'<td class="ds-b c-proj"><a class="ds-lb-plink" href="{E(_box_href(proj))}">{E(proj)}</a></td>'
              if show_project else "")             # 프로젝트 칸 → 그 문서함 (화면 3판 큰 그림)
        go = f'<a href="{E(href)}" aria-label="전/후 보기">›</a>' if href else ""
        dh = f' data-href="{E(href)}"' if href else ""
        cmk = _collab.issue_row_marks(h, d["id"], d["cm"], d["as"]) if d["collab"] else ""
        out.append(f'<tr class="ds-row"{dh}><td class="c-tag">{issue_tag(d["code"])}</td>{pj}'
                   f'<td class="ds-b ds-file c-target">{tgt}</td><td class="c-ev">{main}{sm}{cmk}</td>'
                   f'<td class="ds-m c-day">{E(_md(d["day"]) if d["day"] else "")}</td><td class="ds-go c-go">{go}</td></tr>')
    return "".join(out)


def _issue_split(st: State, rows: list, scope, *, h=None, show: int = 0) -> str:
    """확인 필요 목록·상세 — 감시 화면 /issues와 같은 모양(issue_view, 2026-11-24). 이 서버는 스크립트를 막아(CSP) 고르기는 줄 안의 라디오
    칸이 한다(주소·상태를 남기지 않는다). 상세에는 읽을 것과 길([전/후 보기]·[의견·처리 →])만 — 쓰기는 확인 필요 하나 보기(/changes/issue)
    그대로라 여기서 새로 열리는 쓰기 길은 없다. show: 처음 고를 번호(없거나 목록 밖이면 맨 위)."""
    from watcher.brief import no_bidi
    from watcher.forms import collab as _collab
    W = _W()
    ids = [int(r[0]) for r in rows]
    first = show if show in ids else (ids[0] if ids else 0)
    today = date.today()
    out = []
    for d in _issue_parts(st, rows, scope, h=h):
        iid, code, proj = d["id"], d["code"], d["project"]
        target = E(no_bidi(d["target"]))
        tone = W._iss_tone(code)
        day, age = W._iss_day(d["at"], today)
        marks = " ".join(x for x in (_collab.OP.count_mark(d["cm"].get(iid)), _collab.OP.assignee_mark(d["as"].get(iid))) if x) if d["collab"] else ""
        sel = " checked" if iid == first else ""
        loc, notes = d["small"][:1], d["small"][1:]
        acts = ((f'<a class="ds-btn sm" href="{E(d["href"])}">전/후 보기</a>' if d["href"] else "")
                + (f'<a class="ds-btn sm" href="/changes/issue?id={iid}">{E(_collab.go_label(h))}</a>' if d["collab"] else ""))
        out.append(
            f'<div class="ds-iss-r" id="iss-{iid}"><label class="ds-iss-a" for="iss-s-{iid}">'
            f'<input class="ds-iss-s" type="radio" name="iss-sel" id="iss-s-{iid}" value="{iid}" autocomplete="off" '
            f'aria-label="{target} 확인 필요 보기"{sel}>'
            f'<span class="ds-iss-t1"><span class="ds-iss-d {tone}"></span><b title="{E(no_bidi(d["path"]))}">{target}</b>'
            f'<span class="ds-iss-dt">{E(day)}</span></span>'
            f'<span class="ds-iss-t2"><span>{E(W._iss_label(code))}</span><span>{E(no_bidi(proj))}</span></span>'
            f'<span class="ds-iss-t3">{_issue_line(d)[0]}</span>'
            + (f'<span class="ds-sm ds-iss-cm">{marks}</span>' if marks else "") + '</label></div>'
            f'<div class="ds-iss-p" id="issp-{iid}" role="region" aria-label="{target} 근거">'
            f'<div class="ds-iss-ph"><h2 title="{E(no_bidi(d["path"]))}">{target}</h2>{issue_tag(code)}</div>'
            f'<div class="ds-iss-ps"><a href="{E(_box_href(proj))}">{E(no_bidi(proj))}</a>'
            + (f'<span>{E(day)} 발견</span>' if day else "") + (f'<span>{E(age)}</span>' if age else "") + '</div>'
            f'<div class="ds-iss-l1">{d["main"]}</div>'
            + "".join(small_line(x, xy=False) for x in loc + notes)
            + (f'<div class="ds-sm ds-iss-cm">{marks}</div>' if marks else "")
            + (f'<div class="ds-iss-do">{acts}</div>' if acts else "") + '</div>')
    return (f'<section class="ds-card ds-iss-card" aria-label="확인 필요 목록">'
            f'<div class="ds-iss-2" role="radiogroup" aria-label="확인 필요 고르기">{"".join(out)}</div></section>'
            if out else "")


def _issue_cards(st: State, scope, p: str = "", *, code: str = "", on: bool = False) -> str:
    """확인 필요 개수 칸 — 전체·종류마다 몇 건인지(내 범위), 누르면 확인 필요 화면의 그 종류. on: 지금 확인 필요 화면(고른 칸 표시)."""
    from watcher import issue_view as IV
    W = _W()
    rows = st.conn.execute("SELECT code, IFNULL(project, '미분류') FROM issues WHERE resolved_at IS NULL").fetchall()
    by = Counter(c for c, pj in rows if _in(scope, pj) and (not p or pj == p))
    if not by:
        return ""

    def href(c=""):
        qs = "&".join(x for x in (f"p={quote(p, safe='')}" if p else "", f"code={quote(c, safe='')}" if c else "") if x)
        return "/changes/issues" + (f"?{qs}" if qs else "")
    return IV.cards([(href(), "전체" if on else "확인 필요", sum(by.values()), "", on and not code, "")]
                    + [(href(c), W._iss_label(c), n, W._iss_tone(c), on and c == code, W.CODE_LABEL.get(c, c)) for c, n in IV.by_count(by)],
                    "종류로 거르기" if on else "확인 필요 종류별 건수")


def _issue_head(show_project: bool) -> str:
    cols = ("w-tag",) + (("w-proj",) if show_project else ()) + ("w-target", "w-ev", "w-day", "w-go")
    names = ("문제",) + (("프로젝트",) if show_project else ()) + ("대상", "근거", "발견", "")
    return _cols(*cols) + "<thead><tr>" + "".join(f"<th>{n}</th>" for n in names) + "</tr></thead>"


def _todo_block(st: State, scope, p: str, *, n_all: int, h=None) -> str:
    """'확인 필요' 카드 — 열린 검토 필요(일관성 검사) 앞 TODO_ROWS줄. 순서는 감시 화면 첫 화면('확인 필요', web._rc_hot)과 같게 —
    ~~종류순(도면-BOM 불일치 > Rev 미갱신 > …), 같은 종류는 최근 것부터 (V3-7)~~ → 최근 것부터(검사 번호·번호 큰 것 먼저) — 종류순이면
    5줄이 모두 오래된 '도면·BOM 다름'이고 오늘 생긴 것이 안 보였다 (검토 Y1 M3). 머리만 다 읽어 고르고 본문은 고른 줄만."""
    if n_all <= 0:
        return ""
    heads = st.conn.execute("SELECT id, code, IFNULL(project, '미분류'), snapshot_id FROM issues "
                            "WHERE resolved_at IS NULL").fetchall()
    heads = [r for r in heads if _in(scope, r[2]) and (not p or r[2] == p)]
    heads.sort(key=lambda r: (-int(r[3] or 0), -int(r[0])))
    pick = [int(r[0]) for r in heads[:TODO_ROWS]]
    got = {int(r[0]): r for r in st.conn.execute(
        "SELECT id, code, path, IFNULL(project, '미분류'), message, evidence, detected_at FROM issues WHERE id IN ("
        + ",".join("?" * len(pick)) + ")", pick)} if pick else {}
    rows = [got[i] for i in pick if i in got]
    show_project = not p
    more = f'/changes/issues{("?p=" + quote(p, safe="")) if p else ""}'
    return (f'<section class="ds-card ds-rec-todo" aria-labelledby="rec-todo-h"><div class="ds-card-h">'
            f'<h2 id="rec-todo-h">확인 필요</h2><span class="ds-cnt">{n_all}건</span>'
            f'<div class="ds-r"><a class="ds-more" href="{more}">{n_all}건 모두 보기 →</a></div></div>'
            f'<div class="ds-scroll"><table class="ds-t ds-rec-iss">{_issue_head(show_project)}'
            f'<tbody>{_issue_rows(st, rows, scope, show_project=show_project, h=h, brief=True)}</tbody></table></div></section>')


def _days_html(st: State, chs: list, *, day_rows: int | None, more_href, show_project: bool, search: str = "",
               max_rows: int | None = None, scope=None) -> tuple[str, int, dict]:
    """날짜별 묶음 표 본문(<tbody> 하루에 하나)·보인 주요 줄 수·프로젝트별 바뀐 파일 수. chs는 최근 것부터.
    more_href(day) → '이 날 N건 더' 주소. max_rows: 모든 날을 합친 주요 줄 상한(타임라인) — 넘으면 그 뒤 날짜는 '앞선 변경 N건'.
    '그 밖'(이동·다시 저장·복사본 — 메일과 같은 접기)은 그날 끝의 [그 밖 N건] 접기 줄 아래 — 펼쳐야 보인다(스크립트 없이 :has())."""
    from watcher.change_ledger import local_day
    g = _gather(st, chs)
    g["hider"] = _Hider(st, scope)                 # 범위 밖 옛 경로 가리기 (검토 X L1)
    by_day: dict = {}
    quiet_ids = {c["id"] for c in g["quiet"]}
    main_ids = {c["id"] for c in g["main"]}
    files_by_p: dict = {}
    for c in g["main"]:
        files_by_p.setdefault(c["project"], set()).add(c["path"])
    for c in chs:                                  # 최근 것부터 — 묶음 차례 그대로
        if c["id"] not in main_ids and c["id"] not in quiet_ids:
            continue                               # 이동 짝의 삭제 쪽(추가 쪽 한 줄로 접힘)
        d = local_day(c["detected_at"])
        slot = by_day.setdefault(d, {"main": [], "quiet": []})
        slot["main" if c["id"] in main_ids else "quiet"].append(c)
    if search:
        summ = st.record_summaries([c["id"] for c in chs])
        needle = search.casefold()
        # 요약 안의 범위 밖 옛 경로로는 찾아지지 않게(가린 글로 찾는다 — 검토 X L1)
        keep = {c["id"] for c in chs if needle in PurePosixPath(c["path"]).name.casefold()
                or needle in g["hider"].text(summ.get(c["id"]) or "", g["notes"].get(c["id"]) or "", c["path"]).casefold()}
        for slot in by_day.values():
            slot["main"] = [c for c in slot["main"] if c["id"] in keep]
            slot["quiet"] = [c for c in slot["quiet"] if c["id"] in keep]
    # 하루 안 차례 = 감시 화면 _rc_day_blocks와 같게: 새 시각(분)이 위, 같은 분 안에서는 수정·추가·삭제 순, 프로젝트·경로 순
    # (안정 정렬 두 번). 보일 줄을 고른 뒤 같은 분 안에서 확인 필요가 열린 줄을 위로(아래 opened 뒤 — 감시 화면 _hot_first와
    # 같은 차례). 같은 검사의 줄이 두 화면에서 다른 차례로 섰다
    _ord = {"modified": 0, "added": 1, "removed": 2}

    def _minute(c) -> str:
        return str(c["detected_at"] or "")[:16]
    for slot in by_day.values():
        slot["main"].sort(key=lambda c: (_ord.get(c["kind"], 3), str(c["project"] or "미분류"), c["path"]))
        slot["main"].sort(key=_minute, reverse=True)
    ncol = 7 if show_project else 6               # (프로젝트) · 문서 · 파일 · 바뀐 곳 · 이전 / 지금 · 상태 · ›
    plan, shown, left = [], 0, 0
    for d in sorted((x for x in by_day if x is not None), reverse=True) + ([None] if None in by_day else []):
        slot = by_day[d]
        if not slot["main"] and not slot["quiet"]:
            continue
        # 한 날·한 프로젝트의 새 파일이 ADD_FOLD개 이상이면 '새 파일 N개' 한 줄로 접는다(펼치면 하나씩) — 감시 화면 첫 화면과 같은 꼴
        adds: dict = {}
        for c in slot["main"]:
            if c["kind"] == "added":
                adds.setdefault(c["project"], []).append(c)
        groups = [(pj, cs) for pj, cs in adds.items() if len(cs) >= ADD_FOLD]
        grouped = {c["id"] for _pj, cs in groups for c in cs}
        singles = [c for c in slot["main"] if c["id"] not in grouped]
        if max_rows is not None and shown >= max_rows:
            left += len(slot["main"])
            continue
        rows = singles[:day_rows] if day_rows else singles
        if max_rows is not None:
            rows = rows[:max_rows - shown]
        shown += len(rows) + len(grouped)
        plan.append((d, slot, rows, singles, groups))
    opened = _opened_live(st, [c["id"] for _d, _s, rows, _sg, _g in plan for c in rows])
    for _d, _s, rows, _sg, _g in plan:                 # 같은 분 안에서는 확인 필요가 열린 줄이 위 (감시 화면 _hot_first)
        rows.sort(key=lambda c: 0 if opened.get(int(c["id"])) else 1)
        rows.sort(key=_minute, reverse=True)
    want = [c["id"] for _d, s_, rows, _sg, grps in plan
            for c in rows + [x for _p, cs in grps for x in cs[:QUIET_ROWS]] + s_["quiet"][:QUIET_ROWS]]
    g["summ"] = st.record_summaries(want) if want else {}
    parts = []
    for d, slot, rows, singles, groups in plan:
        trs = "".join(_chg_row(st, c, g, opened, show_project=show_project) for c in rows)
        extra = len(singles) - len(rows)
        if extra > 0 and d is not None:
            trs += f'<tr class="ds-fold"><td colspan="{ncol}"><a href="{E(more_href(d))}">이 날 {extra}건 더 →</a></td></tr>'
        if d is not None:
            title = f'{d.month}월 {d.day}일<span>{_WEEK[d.weekday()]}</span>'
        else:
            title = "날짜 모름"
        parts.append(f'<tbody><tr class="ds-day"><td colspan="{ncol}">{title}</td></tr>{trs}</tbody>')
        for pj, cs in groups:                       # 접은 새 파일 묶음 — 묶음마다 <tbody> 하나(펼치기가 그 묶음만 연다)
            from watcher.summary import _kind_tag
            kinds = {_kind_tag(c["path"]) for c in cs}
            kind = kinds.pop() if len(kinds) == 1 else "여러 종류"
            proj = f'<td class="ds-b c-proj">{E(pj)}</td>' if show_project else ""
            members = "".join(_chg_row(st, c, g, {}, show_project=show_project, quiet=True) for c in cs[:QUIET_ROWS])
            if len(cs) > QUIET_ROWS:
                members += f'<tr class="ds-fold ds-q"><td colspan="{ncol}">외 {len(cs) - QUIET_ROWS}건</td></tr>'
            parts.append(f'<tbody><tr class="ds-row ds-addg">{proj}<td class="c-doc"><span class="ds-tg gray">{E(kind)}</span></td>'
                         f'<td class="ds-b ds-file c-file"><details class="ds-qd"><summary>새 문서 {len(cs):,}개 <b>하나씩 보기</b>'
                         f'</summary></details></td>{_value_cells([("파일", "없음", f"{len(cs)}개 추가")], 0)}'
                         f'<td class="c-state"></td><td class="ds-go c-go"></td></tr>{members}</tbody>')
        if slot["quiet"]:
            kinds_q = Counter(_quiet_kind(g["notes"].get(c["id"], ""), c["id"] in g["moved"]) for c in slot["quiet"])
            what = ", ".join(f"{_QUIET_PH.get(k, k)} {n:,}개" for k, n in kinds_q.most_common())
            qrows = slot["quiet"][:QUIET_ROWS]
            # 감시 화면과 같은 말 — '그 밖에 위치만 옮긴 파일 3개, 다시 저장만 한 파일 1개 보기'
            qtrs = (f'<tr class="ds-fold"><td colspan="{ncol}"><details class="ds-qd"><summary>그 밖에 '
                    f'{E(what)} <b>보기</b></summary></details></td></tr>')
            qtrs += "".join(_chg_row(st, c, g, {}, show_project=show_project, moved_from=g["moved"].get(c["id"]), quiet=True)
                            for c in qrows)
            if len(slot["quiet"]) > len(qrows):
                qtrs += f'<tr class="ds-fold ds-q"><td colspan="{ncol}">외 {len(slot["quiet"]) - len(qrows)}건</td></tr>'
            parts.append(f'<tbody>{qtrs}</tbody>')
    if left:
        parts.append(f'<tbody><tr class="ds-fold"><td colspan="{ncol}">앞선 변경 {left}건은 '
                     f'<a href="/changes?view=list">변경 찾기</a>에서 기간으로 보세요.</td></tr></tbody>')
    return "".join(parts), shown, {p: len(v) for p, v in files_by_p.items()}


def _seg(projs: list, cur: str, counts: dict | None = None, base: str = "/changes", all_href: str | None = None) -> str:
    """프로젝트 걸러내기 줄(.ds-seg) — 전체 + 프로젝트. 지금 것은 .on + aria-current. all_href: '전체'가 가는 곳(기본 base)."""
    ps = sorted(projs, key=lambda x: (x == "미분류", x))
    counts = counts or {}

    def a(href, label, on, n=None):
        num = f"<b>{n}</b>" if n else ""
        cur_ = ' class="on" aria-current="page"' if on else ""
        return f'<a href="{E(href)}"{cur_}>{E(label)}{num}</a>'
    bits = [a(all_href or base, "전체", not cur, sum(counts.values()) if counts else None)]
    for pj in ps:
        bits.append(a(f"{base}?p={quote(pj, safe='')}", pj, pj == cur, counts.get(pj)))
    return f'<nav class="ds-seg" aria-label="프로젝트 거르기">{"".join(bits)}</nav>'


def _xlsx_btn(p: str = "") -> str:
    qp = f"?p={quote(p, safe='')}" if p else ""
    return f'<a class="ds-btn" href="/changes.xlsx{qp}">설계 변경 대장 (엑셀)</a>'


def _home(h, w, scope) -> None:
    """최근 변경 /changes/recent — 확인 필요 + 날짜별 바뀐 내용 (최근 7일(기간) — _week_label). 화면 3판 큰 그림(2026-11-20)에서 첫 화면 자리를
    프로젝트 목록에 넘기고, 프로젝트 칸(ds-pcards)도 그 목록으로 옮겼다 — 감시 화면 /recent와 같은 꼴."""
    from watcher.change_ledger import select_changes
    from watcher.docbox import week_window
    with w.session() as st:
        last = _last_scan(st)
        today = date.today()
        # 7일 창 = 첫 화면·문서함과 같은 규칙(docbox.week_window — 감시 화면 _rc_window와 같다)
        d1, anchor = week_window(st, today)
        n_iss = _open_issue_count(st, scope, "")
        todo = _todo_block(st, scope, "", n_all=n_iss, h=h)
        cards = _issue_cards(st, scope)
        chs = select_changes(st, projects=scope, date_from=d1, date_to=anchor, limit=HOME_LOAD + 1, newest_first=True)
        cut = len(chs) > HOME_LOAD
        chs = chs[:HOME_LOAD]

        def more(d):
            return f"/changes?view=list&from={d.isoformat()}&to={d.isoformat()}"
        days, _n, _files = _days_html(st, chs, day_rows=DAY_ROWS, more_href=more, show_project=True, scope=scope)
    late = (today - last.date()).days if last else 0
    label = _week_label((d1, anchor))
    sub = f"{E(label)} · {E(_scan_text(last))}"
    warn = ""
    if not last:
        warn = '<div class="ds-alert info" role="status">감시 PC에서 첫 검사를 마치면 여기에 바뀐 파일이 날짜별로 보입니다.</div>'
    elif late >= 2:
        warn = (f'<div class="ds-alert warn" role="status"><b>⚠ 마지막 검사가 {late}일 전입니다.</b> '
                f'감시 PC 관리자에게 알려 주세요.</div>')
    if days:
        tail = (f'<div class="ds-card-f">변경이 많아 최근 {HOME_LOAD}건만 보입니다. <a href="/changes?view=list">기간으로 찾기 →</a></div>'
                if cut else "")
        table = (f'<div class="ds-scroll"><table class="ds-t ds-rec-chg">{_chg_head(True)}{days}</table></div>{tail}')
    else:
        # 감시 화면 /recent와 같은 말 — 창 끝이 오늘이면 '최근 7일', 아니면 'M월 D일까지 7일' (기간은 머리 회색 줄에)
        table = (f'<div class="ds-empty">최근 {WINDOW_DAYS}일 동안 바뀐 파일이 없습니다</div>' if anchor == today else
                 f'<div class="ds-empty">{anchor.month}월 {anchor.day}일까지 {WINDOW_DAYS}일 동안 바뀐 파일이 없습니다</div>')
    changes_card = (f'<section class="ds-card" aria-labelledby="rec-chg-h"><div class="ds-card-h"><h2 id="rec-chg-h">바뀐 내용</h2>'
                    f'<span class="ds-s">최근 {WINDOW_DAYS}일</span><div class="ds-r"><a class="ds-more" href="/changes?view=list">'
                    f'기간·미확인으로 찾기 →</a></div></div>{table}</section>')
    body = f'<div class="rec ds-rec">{warn}{cards}{todo}{changes_card}</div>'
    h._send(200, h._shell("최근 변경", body, active="/changes/recent", actions=_xlsx_btn(), sub=sub))


def _timeline(h, w, scope, p: str, search: str) -> None:
    from watcher.change_ledger import select_changes
    with w.session() as st:
        projs = _projects(st, scope)
        n_iss = _open_issue_count(st, scope, p)
        todo = "" if search else _todo_block(st, scope, p, n_all=n_iss, h=h)     # 찾는 중에는 결과만
        chs = select_changes(st, projects=frozenset([p]), limit=TIMELINE_LOAD + 1, newest_first=True)
        cut = len(chs) > TIMELINE_LOAD
        chs = chs[:TIMELINE_LOAD]
        first = st.conn.execute("SELECT MIN(detected_at) FROM changes WHERE IFNULL(project, '미분류') = ?", (p,)).fetchone()[0]
        n_files = st.conn.execute("SELECT COUNT(DISTINCT path) FROM changes WHERE IFNULL(project, '미분류') = ?", (p,)).fetchone()[0]

        def more(d):
            return f"/changes?view=list&p={quote(p, safe='')}&from={d.isoformat()}&to={d.isoformat()}"
        days, shown, _f = _days_html(st, chs, day_rows=None, more_href=more, show_project=False, search=search,
                                     max_rows=TIMELINE_ROWS, scope=scope)
    # 경로 줄 — 프로젝트(목록) › 프로젝트(문서함) › 변경 기록 (화면 3판 큰 그림 2026-11-20, 감시 화면 /timeline?p=와 같은 말)
    crumb = (f'<div class="crumb ds-crumb"><a href="/changes">프로젝트</a><span class="ds-sep">›</span>'
             f'<a href="{E(_box_href(p))}">{E(p)}</a><span class="ds-sep">›</span>변경 기록</div>')
    sub = f"기록 시작 {E(_local(first, '%Y-%m-%d') or '—')} · 파일 {int(n_files or 0)}개"
    form = (f'<form class="ds-rec-search" method="get" action="/changes" role="search">'
            f'<input type="hidden" name="p" value="{E(p)}">'
            f'<input class="ds-inp" type="search" name="q" value="{E(search)}" maxlength="100" placeholder="파일 이름·바뀐 값 찾기" '
            f'aria-label="파일 이름·바뀐 값 찾기"><button class="ds-btn sm" type="submit">찾기</button></form>')
    tools = f'<div class="ds-tools">{_seg(projs, p, all_href="/changes/recent")}<div class="ds-r">{form}</div></div>'
    if days:
        tail = ""
        if cut:
            tail = (f'<div class="ds-card-f">최근 {TIMELINE_LOAD}건만 보입니다.' + (" 찾기도 이 안에서 합니다." if search else "")
                    + f' <a href="/changes?view=list&amp;p={quote(p, safe="")}">기간으로 찾기 →</a></div>')
        table = f'<div class="ds-scroll"><table class="ds-t ds-rec-chg ds-rec-tl">{_chg_head(False)}{days}</table></div>{tail}'
    else:
        table = (f'<div class="ds-empty">"{E(search)}"에 맞는 변경이 없습니다</div>' if search else
                 '<div class="ds-empty">이 프로젝트에 기록된 변경이 없습니다 (첫 등록만 있음)</div>')
    card = (f'<section class="ds-card" aria-labelledby="rec-tl-h"><div class="ds-card-h"><h2 id="rec-tl-h">변경 기록</h2>'
            f'<span class="ds-s">{"찾은 결과" if search else "최근 순"}</span></div>{table}</section>')
    body = f'{crumb}<div class="rec ds-rec rec-tl">{tools}{todo}{card}</div>'
    h._send(200, h._shell(f"{p} 변경 기록", body, active="/changes", actions=_xlsx_btn(p), sub=sub))


# ── 화면 3판 큰 그림 (2026-11-20, 구현자 H) — 사내망도 '프로젝트별 문서 관리' ──────────────────────────────────────────
# 사용자 결정(2026-11-20 "도면 관리 프로그램보다는 프로젝트별 문서 관리 프로그램으로, 큰 그림으로 가자"). 감시 화면(web.py
# page_home·page_docbox·page_doc)과 같은 세 화면 — 첫 화면 프로젝트 목록(/changes) · 프로젝트 문서함(/changes/project?p=) ·
# 문서 이력(/changes/doc?k=<경로 키>). 수와 목록은 watcher.docbox 하나(state.db 읽기만) — 감시 화면과 같은 수가 나온다.
#  - 문서 종류 규칙·제외 폴더: 감시 설정(config.yaml)을 forms-serve가 넘기면(WatchLog.config) docbox.config_args로 감시 화면과 같게.
#  - 프로젝트 이름: 기록(DB)의 이름 그대로 — 열람 범위(changes_view)가 그 이름으로 정해지므로, 별칭 사전으로 합쳐 보이면 범위 밖
#    이름의 기록이 범위 안 이름에 섞여 보일 수 있다. 그래서 정규 이름(canon)은 넘기지 않는다(docbox 기본 = DB 이름).
#  - 권한: 세 화면 모두 로그인 + _scope(열람 범위) — 목록은 범위 안 프로젝트만, 문서함·이력은 범위 밖·없는 것이면 _not_here(404)로
#    없는 주소와 같은 응답. 이력은 범위 밖 프로젝트로 귀속된 줄·확인 필요를 뺀다. 감시 쪽 [파일 열기]는 없다(동료 PC는 경로를 못 연다).
#  - 이 서버는 스크립트가 없다(CSP) — 줄 전체 누르기 대신 이름 칸과 줄 끝 ›가 실제 <a href>.

DB_FOLD = 10                         # 문서함 — 한 폴더에서 최근 7일 변경·확인 필요 없는 문서가 이보다 많으면 한 줄로 접는다 (감시 화면과 같은 수)
DOC_ROWS = 300                       # 문서 이력 한 화면의 줄 (감시 화면과 같은 수)


def _box_href(proj) -> str:
    """프로젝트 문서함 주소 — 경로 줄·목록의 프로젝트 칸이 가는 곳. 이름이 없으면 프로젝트 목록."""
    return f"/changes/project?p={quote(str(proj), safe='')}" if proj else "/changes"


def _doc_href(path) -> str:
    """문서 이력 주소 '/changes/doc?k=<경로 키>'."""
    return f"/changes/doc?k={quote(str(path or ''), safe='')}"


def _pname(p) -> str:
    """기록의 프로젝트 이름 → 화면 이름 — docbox 기본 정규 이름(_default_canon)과 같은 규칙(비면 '미분류')."""
    return str(p or "").strip() or "미분류"


def _doc_in_scope(st: State, path: str, scope) -> bool:
    """이 경로의 문서 이력을 이 계정이 열 수 있나 — 그 경로의 가장 최근 변경 행의 프로젝트(docbox 귀속과 같은 것)가 내 범위."""
    try:
        row = st.conn.execute("SELECT project FROM changes WHERE path = ? ORDER BY id DESC LIMIT 1", (path,)).fetchone()
    except sqlite3.Error:
        return False
    return row is not None and _in(scope, _pname(row[0]))


def _docbox_kw(w) -> dict:
    """docbox에 넘길 것 — 감시 설정에서 문서 종류 규칙·제외 폴더(감시 화면 _docbox_args와 같은 해석). 정규 이름은 넘기지 않는다."""
    from watcher import docbox
    return docbox.config_args(w.config())


def _md_day(day, today: date | None = None) -> str:
    """'YYYY-MM-DD'(지역 날짜) → '11월 17일' (올해가 아니면 연도까지). 못 읽으면 ''."""
    try:
        d = date.fromisoformat(str(day))
    except ValueError:
        return ""
    today = today or date.today()
    return (f"{d.year}년 " if d.year != today.year else "") + f"{d.month}월 {d.day}일"


def _md_iso(iso, today: date | None = None) -> str:
    """검사 시각(UTC ISO) → '11월 17일'."""
    from watcher.docbox import local_day
    return _md_day(local_day(iso), today)


def _md_ts(ts, today: date | None = None) -> str:
    """파일 저장 시각(epoch) → '11월 17일' (올해가 아니면 연도까지). 모르면 '—'."""
    from datetime import datetime
    try:
        d = datetime.fromtimestamp(float(ts))
    except (TypeError, ValueError, OSError, OverflowError):
        return "—"
    today = today or date.today()
    return (f"{d.year}년 " if d.year != today.year else "") + f"{d.month}월 {d.day}일"


def _scan_alert(last, today: date) -> str:
    """검사 상태 한 줄 — 첫 검사 전(안내)·이틀 넘게 검사 없음(경고). 최근 변경과 같은 말."""
    if not last:
        return '<div class="ds-alert info" role="status">감시 PC에서 첫 검사를 마치면 여기에 프로젝트와 문서가 보입니다.</div>'
    late = (today - last.date()).days
    if late >= 2:
        return (f'<div class="ds-alert warn" role="status"><b>⚠ 마지막 검사가 {late}일 전입니다.</b> '
                f'감시 PC 관리자에게 알려 주세요.</div>')
    return ""


def _projects_home(h, w, scope) -> None:
    """첫 화면 /changes — 프로젝트 목록 (감시 화면 page_home과 같은 꼴·같은 수). 머리(프로젝트·문서·최근 7일(기간) 바뀐 문서·마지막 검사) ·
    검사 경고 한 줄 · 프로젝트 표(문서 · 도면 · BOM·발주 · 그 밖 · 7일 변경 · 확인 필요 · 마지막 변경 · ›, 이름과 ›가 문서함 링크) ·
    확인 필요 표(앞 TODO_ROWS건, 'N건 모두 보기 →'). 내 범위의 프로젝트만 — 머리 수도 그 합."""
    from watcher import docbox
    from watcher.brief import no_bidi
    kw = _docbox_kw(w)
    today = date.today()
    with w.session() as st:
        last = _last_scan(st)
        s = docbox.summaries(st, **kw)
        n_iss = _open_issue_count(st, scope, "")
        todo = _todo_block(st, scope, "", n_all=n_iss, h=h)
        cards = _issue_cards(st, scope)
        hider = _Hider(st, scope)
        projs = [d for d in s["projects"] if _in(scope, d["project"])]
        for d in projs:                       # '마지막 변경'의 범위 밖 옛 경로 가리기 (검토 X L1)
            if d.get("last") and d["last"].get("items"):
                d["last"] = dict(d["last"], items=hider.items(d["last"]["items"]))
    n_un = s["unassigned"] if _in(scope, docbox.UNASSIGNED) else 0
    sub = " · ".join([f"프로젝트 {len(projs):,}개", f"문서 {sum(d['docs'] for d in projs):,}개",
                      f"{E(_week_label(s['window']))} 바뀐 문서 {sum(d['week'] for d in projs):,}개", E(_scan_text(last))])

    def _n(v: int, red: bool = False) -> str:
        if not v:
            return '<span class="ds-zero">0</span>'
        return f'<b class="ds-lb-red">{v:,}</b>' if red else f"{v:,}"
    trs = ""
    for d in projs:
        p = d["project"]
        href = E(_box_href(p))
        c = d["cols"]
        lr = d["last"]
        if lr:
            nm = PurePosixPath(lr["path"]).name
            body = ""
            if lr["batch"]:
                what = f"새 문서 {lr['batch']:,}개"
            elif lr["kind"] == "removed":
                what = f"{nm} 삭제"
            else:
                body = _last_change_html(lr["kind"], lr["items"], lr["path"], cap=1)
                what = f"{nm} · {docbox.change_text(lr['kind'], lr['items'], lr['path'], cap=1)}"
            if body:
                # 이전/지금 두 줄(2026-11-21 시안 ②): '11월 17일 · 파일(굵게)' / 바뀐 곳(굵게) / [이전] / [지금]
                last_c = (f'<div class="ds-lb-lh">{E(_md_day(lr["day"], today))} · <b title="{E(no_bidi(lr["path"]))}">'
                          f'{E(no_bidi(nm))}</b></div>{body}')
            else:
                last_c = (f'{E(_md_day(lr["day"], today))}<div class="ds-sm" title="{E(no_bidi(lr["path"]))}">'
                          f'{E(no_bidi(what))}</div>')
        else:
            last_c = '<span class="ds-m">바뀐 적 없음</span>'
        nums = [("문서", d["docs"], False), ("도면", c["도면"], False), ("BOM·발주", c["BOM·발주"], False),
                ("그 밖", c["그 밖"], False), ("7일 변경", d["week"], False), ("확인 필요", d["issues"], True)]

        def _kinds_of(col: str) -> tuple[str, str]:
            # 칸 수의 종류별 내역 — 두 가지 이상일 때만 (작은 회색 줄, title 글). '도면 39'가 문서함의 '배선표 30 · 도면 9'와 달라
            # 보였다 — 감시 화면 첫 화면과 같은 내역 (검토 W5, docbox col_kinds)
            ks = [(k, n_) for k, n_ in (d.get("col_kinds") or {}).get(col, []) if n_]
            if len(ks) < 2:
                return "", ""
            return ("".join(f'<div class="ds-sm ds-lb-kn">{E(k)} {n_:,}</div>' for k, n_ in ks),
                    " · ".join(f"{k} {n_:,}" for k, n_ in ks))
        tds = "".join(f'<td class="ds-num c-n{i + 1}{" ds-b ds-lb-big" if i == 0 else ""}" data-l="{lab}"'
                      + (f' title="{E(_kinds_of(lab)[1])}"' if lab in ("도면", "BOM·발주", "그 밖") and _kinds_of(lab)[1] else "")
                      + f'>{(f"{v:,}" if i == 0 else _n(v, red))}{_kinds_of(lab)[0] if lab == "도면" else ""}</td>'
                      for i, (lab, v, red) in enumerate(nums))
        trs += (f'<tr class="ds-row" data-href="{href}"><td class="c-hp"><a class="ds-lb-code" href="{href}">{E(p)}</a>'
                f'<div class="ds-sm" title="{E(no_bidi(d["folder"]))}">{E(no_bidi(d["name"])) if d["name"] else "—"}</div></td>'
                f'{tds}<td class="ds-lb-last c-ls">{last_c}</td>'
                f'<td class="ds-go c-go"><a href="{href}" aria-label="{E(p)} 문서함">›</a></td></tr>')
    if n_un:
        href = E(_box_href(docbox.UNASSIGNED))
        trs += (f'<tr class="ds-row ds-lb-un" data-href="{href}"><td class="c-hp"><a class="ds-lb-code" href="{href}">미분류</a>'
                f'<div class="ds-sm">프로젝트를 못 찾은 파일</div></td>'
                f'<td class="ds-num ds-b ds-lb-big c-n1" data-l="문서">{n_un:,}</td><td class="c-un" colspan="6"></td>'
                f'<td class="ds-go c-go"><a href="{href}" aria-label="미분류 문서">›</a></td></tr>')
    if trs:
        table = ('<div class="ds-scroll"><table class="ds-t ds-lb-home" id="lb-home">'
                 + _cols("w-hp", "w-n", "w-n", "w-n2", "w-n", "w-n3", "w-n3", "w-last", "w-go")
                 + '<thead><tr><th>프로젝트</th><th class="ds-num">문서</th><th class="ds-num">도면</th>'
                   '<th class="ds-num">BOM·발주</th><th class="ds-num">그 밖</th><th class="ds-num">7일 변경</th>'
                   '<th class="ds-num">확인 필요</th><th>마지막 변경</th><th></th></tr></thead>'
                 f'<tbody>{trs}</tbody></table></div>')
    else:
        table = '<div class="ds-empty">아직 프로젝트로 묶인 문서가 없습니다</div>'
    try:                       # '내 담당 N건 →' 한 줄 — 메뉴·내 담당 화면과 같은 수 (2026-11-23 사내망 협업)
        from watcher.forms.collab import mine_line
        mine = mine_line(h, "all" if scope is None else scope)
    except Exception:          # noqa: BLE001
        mine = ""
    body = (f'<div class="rec ds-rec ds-lb">{_scan_alert(last, today)}{mine}{cards}'
            f'<section class="ds-card" id="lb-projects" aria-label="프로젝트">{table}</section>{todo}</div>')
    h._send(200, h._shell("프로젝트", body, active="/changes", actions=_xlsx_btn(), sub=sub))


@_guarded
def get_change_project(h) -> None:
    """/changes/project?p=X — 프로젝트 문서함 (감시 화면 page_docbox와 같은 꼴·같은 수). 경로 줄(프로젝트 › X) · 머리(번호·이름,
    폴더 · 문서 수 · 최근 7일(기간) 바뀐 문서 · 마지막 변경, 오른쪽 [변경 기록][설계 변경 대장 (엑셀)]) · 종류 거르기(&k=) + 문서 이름 찾기(&q=) ·
    확인 필요 한 줄(→ /changes/issues?p=) · 문서 표(폴더 구분 줄 아래 문서 · 종류 · Rev · 마지막 저장 · 최근 변경 · 상태 · ›).
    범위 밖·없는 프로젝트는 없는 주소와 같은 404(_not_here)."""
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    q = h._query()
    one = S.FormsHandler._one
    p = one(q, "p").strip()
    kind = one(q, "k").strip()[:80]
    find = " ".join(one(q, "q").split())[:80]
    if not p or len(p) > 200 or not _in(scope, p):
        _not_here(h, scope)
        return
    from watcher import docbox
    from watcher.brief import no_bidi
    from watcher.consistency import short_label
    from watcher.doctype import doc_rank
    from watcher.summary import _note_short
    kw = _docbox_kw(w)
    today = date.today()
    with w.session() as st:
        d = docbox.project_docs(st, p, **kw)
        n_rec = st.conn.execute("SELECT COUNT(*) FROM changes WHERE IFNULL(project, '미분류') = ?", (p,)).fetchone()[0]
        hider = _Hider(st, scope)
        for x in d["docs"]:                    # '최근 변경'의 범위 밖 옛 경로 가리기 (검토 X L1)
            if x.get("last") and x["last"].get("items"):
                x["last"] = dict(x["last"], items=hider.items(x["last"]["items"]))
        # 마지막 변경에 달린 '의견 N' — 감시 화면 문서함과 같은 수 (2026-11-23 사내망 협업)
        cm_all = st.comment_counts("change") if st.has_collab() else {}
    if not d["docs"] and not d["issues"] and not n_rec:
        _not_here(h, scope)                      # 기록이 없는 이름 — 범위 밖과 같은 응답(있는지 드러내지 않는다)
        return
    docs = d["docs"]
    qp = quote(p, safe="")
    crumb = f'<div class="crumb ds-crumb"><a href="/changes">프로젝트</a><span class="ds-sep">›</span>{E(p)}</div>'
    h1 = f"{p} {d['name']}".strip()
    sub = " · ".join(x for x in (E(no_bidi(d["folder"])), f"문서 {len(docs):,}개",
                                 f"{E(_week_label(d['window']))} 바뀐 문서 {d['week']:,}개",
                                 (f"마지막 변경 {E(_md_iso(d['last'], today))}" if d["last"] else "")) if x)
    acts = (f'<a class="ds-btn" href="/changes?p={qp}" title="이 프로젝트의 변경을 날짜별로">변경 기록</a>' + _xlsx_btn(p))
    # 종류 거르기 — 많은 종류부터(같으면 돈·규격 걸린 종류 먼저). 고르면 문서 표만 거른다
    kinds = sorted(d["kinds"], key=lambda kn: (-kn[1], doc_rank(kn[0]), kn[0]))
    base = f"/changes/project?p={qp}"
    fq = f"&amp;q={quote(find, safe='')}" if find else ""
    _on = ' class="on" aria-current="true"'
    seg = (f'<a{"" if kind else _on} href="{base}{fq}">전체<b>{len(docs):,}</b></a>'
           + "".join(f'<a{_on if k_ == kind else ""} href="{base}&amp;k={quote(k_, safe="")}{fq}">{E(k_)}<b>{n_:,}</b></a>'
                     for k_, n_ in kinds))
    seg = f'<nav class="ds-seg" aria-label="문서 종류로 거르기">{seg}</nav>'
    search = (f'<form class="ds-rec-search ds-lb-find" method="get" action="/changes/project" role="search">'
              f'<input type="hidden" name="p" value="{E(p)}">'
              + (f'<input type="hidden" name="k" value="{E(kind)}">' if kind else "")
              + f'<input class="ds-inp" type="search" name="q" value="{E(find)}" maxlength="80" placeholder="문서 이름 찾기" '
              f'aria-label="문서 이름 찾기"><button class="ds-btn sm" type="submit">찾기</button>'
              + (f'<a class="ds-btn sm" href="{base}{("&amp;k=" + quote(kind, safe="")) if kind else ""}">지우기</a>' if find else "")
              + '</form>')
    tools = f'<div class="ds-tools">{seg}<div class="ds-r">{search}</div></div>' if docs else ""
    iss_line = ""
    if d["issues"]:
        cnt = Counter(short_label(i["code"]) for i in d["issues"])
        ks = " · ".join(f"{E(lab)} {n_:,}" for lab, n_ in cnt.most_common())
        iss_line = (f'<div class="ds-alert ds-lb-iss" role="status" id="lb-issues"><span><b>확인 필요 {len(d["issues"]):,}건</b>'
                    f'<span class="ds-lb-k">{ks}</span></span>'
                    f'<a class="ds-btn sm" href="/changes/issues?p={qp}">보기 →</a></div>')
    shown = [x for x in docs if (not kind or x["kind"] == kind) and (not find or find.casefold() in x["name"].casefold())]

    def _row(x, fold: bool = False) -> str:
        href = E(_doc_href(x["path"]))
        lc = x["last"]
        if lc and lc["real"]:
            # 이전/지금 두 줄(2026-11-21 시안 ②) — 값이 없는 변경(새 문서·삭제)은 한 줄 글 그대로. 앞 한 곳 + '외 N곳'
            # (감시 화면 문서함과 같은 수 — 사내망만 세 곳을 보여 줄 높이·말이 갈렸다)
            body = _last_change_html(lc["kind"], lc["items"], x["path"], cap=1)
            txt = docbox.change_text(lc["kind"], lc["items"], x["path"])
            last = ((body or f'<span class="ds-lb-w">{E(no_bidi(txt))}</span>')
                    + f'<div class="ds-sm">{E(_md_day(lc["day"], today))}</div>')
        elif lc:
            # 다시 저장·이동처럼 내용이 바뀌지 않은 변경 — 참고 문구 그대로, 회색
            txt = _note_short(lc["items"], x["path"]) or "다시 저장"
            last = f'<span class="ds-m">{E(no_bidi(txt))}</span><div class="ds-sm">{E(_md_day(lc["day"], today))}</div>'
        else:
            last = '<span class="ds-m">바뀐 적 없음</span>'
        st_ = ""
        if x["issues"]:
            st_ = f'<span class="ds-tg {x["tone"] or "red"}">확인 필요 {len(x["issues"]):,}</span>'
        elif x["issued"]:
            iv = x["issued"]          # 출도본 경로(감시 PC 쪽)는 싣지 않는다 — 표시만
            st_ = ('<span class="ds-tg green">출도본</span>' if iv["copy"] else
                   f'<span class="ds-tg green">출도 Rev {E(str(iv["rev"]))}</span>' if iv.get("rev") else
                   '<span class="ds-tg green">출도됨</span>')
        if lc and cm_all.get(lc["id"]):
            from watcher.opinions import count_mark
            st_ += f'<div class="ds-sm">{count_mark(cm_all[lc["id"]])}</div>'
        return (f'<tr class="ds-row{" ds-q" if fold else ""}" data-href="{href}">'
                f'<td class="ds-lb-name c-nm"><a href="{href}" title="{E(no_bidi(x["path"]))}">{E(no_bidi(x["name"]))}</a></td>'
                f'<td class="c-kd"><span class="ds-tg gray">{E(x["kind"])}</span></td>'
                f'<td class="ds-b c-rv" data-l="Rev">{E(x["rev"] or "—")}</td>'
                f'<td class="ds-m c-sv" data-l="저장">{E(_md_ts(x["mtime"], today))}</td>'
                f'<td class="ds-lb-last c-ls">{last}</td><td class="c-st">{st_}</td>'
                f'<td class="ds-go c-go"><a href="{href}" aria-label="{E(x["name"])} 이력">›</a></td></tr>')
    groups: dict = {}
    for x in shown:
        groups.setdefault(x["folder"], []).append(x)
    parts = []
    for folder, ds in groups.items():
        act = [x for x in ds if x["issues"] or x["week"]]
        rest = [x for x in ds if not (x["issues"] or x["week"])]
        fold = not kind and not find and len(ds) > DB_FOLD and len(rest) > DB_FOLD
        head = f'<tr class="ds-day ds-lb-fd"><td colspan="7">{E(no_bidi(folder))}<span>{len(ds):,}개</span></td></tr>'
        if not fold:
            parts.append(f'<tbody>{head}{"".join(_row(x) for x in ds)}</tbody>')
            continue
        names = [PurePosixPath(x["name"]).stem for x in rest]
        rng = names[0] if len(names) == 1 else f"{names[0]} ~ {names[-1]}"
        if act:
            parts.append(f'<tbody>{head}{"".join(_row(x) for x in act)}</tbody>')
            summ = f'최근 {WINDOW_DAYS}일 변경 없는 문서 {len(rest):,}개<span class="ds-m">{E(no_bidi(rng))}</span>'
        else:
            summ = f'{E(no_bidi(folder))}<span class="ds-m">{len(rest):,}개 · {E(no_bidi(rng))} · 최근 {WINDOW_DAYS}일 변경 없음</span>'
        # 접은 폴더 — 펼치면(스크립트 없이 :has()) 그 묶음의 줄이 보인다. :has()가 없는 브라우저는 늘 보인다(숨지 않게)
        parts.append(f'<tbody><tr class="ds-fold ds-lb-fold{"" if act else " ds-lb-whole"}"><td colspan="7"><details class="ds-qd">'
                     f'<summary>{summ}<b>펼치기</b></summary></details></td></tr>{"".join(_row(x, True) for x in rest)}</tbody>')
    what = (f"{E(kind)} · " if kind else "폴더별 · ") + f"{len(shown):,}개" + (f" · '{E(find)}'" if find else "")
    if parts:
        table = ('<div class="ds-scroll"><table class="ds-t ds-lb-docs" id="lb-docs">'
                 + _cols("w-nm", "w-kd", "w-rv", "w-sv", "w-last", "w-st", "w-go")
                 + '<thead><tr><th>문서</th><th>종류</th><th>Rev</th><th>마지막 저장</th><th>최근 변경</th><th>상태</th><th></th></tr>'
                 f'</thead>{"".join(parts)}</table></div>')
    elif docs:
        table = '<div class="ds-empty">맞는 문서가 없습니다</div>'
    else:
        table = '<div class="ds-empty">지금 이 프로젝트에 있는 문서가 없습니다</div>'
    # 문서별 '확인 필요 N'의 합이 머리 '확인 필요 N건'보다 클 때 까닭 한 줄 — 한 건(도면·BOM 다름)이 도면 줄과 BOM 줄에 모두 걸린다
    # (검토 W6·X L9, 2026-11-21 — 감시 화면과 같은 말)
    seen_n = Counter(e["issue_id"] for x in docs for e in (x["issues"] or []))
    multi = Counter(short_label(next(e["code"] for x in docs for e in x["issues"] if e["issue_id"] == iid))
                    for iid, k_ in seen_n.items() if k_ > 1)
    dup = ""
    if multi and sum(seen_n.values()) > len(d["issues"]):
        dup = '<div class="ds-card-f ds-m ds-lb-dup">' + E(" · ".join(
            f"{lab} {n_:,}건은 " + ("도면과 BOM 두 줄에 모두 나옵니다" if lab == short_label("BOM_MISMATCH") else "관련 문서 줄마다 나옵니다")
            for lab, n_ in multi.most_common())) + ".</div>"
    card = (f'<section class="ds-card" aria-labelledby="lb-docs-h"><div class="ds-card-h"><h2 id="lb-docs-h">문서</h2>'
            f'<span class="ds-s">{what}</span></div>{table}{dup}</section>')
    body = f'{crumb}<div class="rec ds-rec ds-lb">{tools}{iss_line}{card}</div>'
    h._send(200, h._shell(h1, body, active="/changes", actions=acts, sub=sub))


@_guarded
def get_change_doc(h) -> None:
    """/changes/doc?k=<경로 키> — 문서 하나의 이력 (감시 화면 page_doc과 같은 꼴, [파일 열기]는 없다). 경로 줄(프로젝트 › X › 파일) ·
    머리(파일 이름 + 종류·상태 표시, 프로젝트 · 경로 · Rev · 마지막 저장) · 이 파일의 열린 확인 필요 · 이력 표(날짜 · 바뀐 곳 · 이전 ·
    → · 지금 · 상태 · › 변경 상세), 처음 들어온 날까지. 이름·위치를 바꾼 옛 경로의 기록도 잇는다(docbox.doc_history).
    지어낸 키·감시 밖 파일·범위 밖 문서·보일 줄이 없는 문서(숨긴 기록)는 없는 주소와 같은 404(_not_here)."""
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    key = S.FormsHandler._one(h._query(), "k").strip()
    if not key or len(key) > 2000:
        _not_here(h, scope)
        return
    from watcher import docbox
    from watcher.brief import no_bidi
    from watcher.summary import _ISSUE_ORDER, _note_short
    kw = _docbox_kw(w)
    today = date.today()
    with w.session() as st:
        d = docbox.doc_history(st, key, **kw)
        rows = [r for r in (d["rows"] if d else []) if _in(scope, r["project"])]      # 범위 밖으로 귀속된 줄은 뺀다
        if d is None or not rows or not _in(scope, d["project"]):
            _not_here(h, scope)
            return
        iss = [i for i in d["issues"] if _in(scope, i.get("proj") or _pname(i.get("project")))]
        rows_h = rows[:DOC_ROWS]
        opened = _opened_live(st, [r["id"] for r in rows_h if not r["first"]])
        hider = _Hider(st, scope)
        rows_h = [dict(r, items=hider.items(r["items"] or []), note=hider.text(" ".join((r["note"] or "").split()), r["note"] or ""))
                  for r in rows_h]                       # 범위 밖 옛 경로 가리기 (검토 X L1)
    proj = d["project"]
    name = d["name"]
    crumb = (f'<div class="crumb ds-crumb"><a href="/changes">프로젝트</a><span class="ds-sep">›</span>'
             f'<a href="{E(_box_href(proj))}">{E(proj)}</a><span class="ds-sep">›</span>{E(no_bidi(name))}</div>')
    tags = f'<span class="ds-tg gray">{E(d["kind"])}</span>'
    if iss:
        tags += f' <span class="ds-tg {docbox.issue_tone(i["code"] for i in iss)}">확인 필요 {len(iss):,}</span>'
    elif not d["present"]:
        tags += ' <span class="ds-tg gray">지금 없음</span>'
    title_html = f'{E(no_bidi(name))}<span class="ds-rec-h1tags">{tags}</span>'
    sub = " · ".join(E(no_bidi(x)) for x in (proj, d["path"], (f"Rev {d['rev']}" if d["rev"] else ""),
                                             (f"마지막 저장 {_mtime(d['mtime'])}" if d["mtime"] is not None else "")) if x)
    box = ""
    if iss:
        lines = ""
        for i in iss:
            target, main, small = issue_cells(i["code"], i.get("message") or "", i.get("evidence") or [], i["path"],
                                              detected_at=i.get("detected_at"))
            href = f"/changes/issues?f={quote(str(i['path']), safe='')}"
            # 대상 · 보기 → 한 줄, 그 아래 근거(사실 한 줄·두 줄 값) — 두 줄 값은 덩이(div)라 한 줄 글 안에 넣지 않는다 (2026-11-21)
            lines += (f'<div class="ds-ln"><span class="ds-k">{issue_tag(i["code"])}</span>'
                      f'<span><span class="ds-lb-it"><b>{E(no_bidi(target))}</b> <a href="{E(href)}">보기 →</a></span>{main}'
                      + "".join(small_line(x, xy=False) for x in small[:2]) + '</span></div>')
        red = docbox.issue_tone(i["code"] for i in iss) == "red"
        box = (f'<section class="ds-issue{"" if red else " ds-lb-amber"}" id="lb-doc-issues" aria-labelledby="lb-doc-iss-h">'
               f'<h3 id="lb-doc-iss-h">확인 필요 {len(iss):,}건</h3>{lines}</section>')
    trs = ""
    for r in rows_h:
        cid = int(r["id"])
        href = f"/changes/{cid}"
        note = r["note"] or ""
        items = [it for it in (r["items"] or []) if isinstance(it, dict)]
        # 감시 화면 page_doc과 같은 말 (검토 X L2) — 첫 등록 · 이동(위치·이름 — 대소문자만 바꾼 이름은 '이름') · 다시 저장 · 값
        if r["first"]:
            trip, rest = [("파일", "", "첫 등록")], 0
        elif not r["real"]:
            if "이름·위치만 바뀜 — 이전: " in note:
                prev = note.split("이름·위치만 바뀜 — 이전: ", 1)[1].split(" (내용 동일")[0].strip()
                trip, rest = change_parts(r["kind"], items, r["path"], prev)
            else:
                trip, rest = [("파일", "", _note_short(items, r["path"]) or "다시 저장")], 0
        else:
            trip, rest = change_parts(r["kind"], items, r["path"])
        codes = sorted(opened.get(cid) or [], key=lambda x: _ISSUE_ORDER.get(x, 9))
        st_ = (issue_tag(codes[0]) + (f' <span class="ds-m">외 {len(codes) - 1}</span>' if len(codes) > 1 else "")) if codes else ""
        if r["acks"] and not r["first"]:
            who = E(ack_label(r["acks"][-1][0]))
            st_ += f'<div class="ds-sm">확인 {who}</div>' if codes else f'<span class="ds-tg green">확인함 · {who}</span>'
        when = (f'{E(_md_iso(r["at"], today))}<div class="ds-sm">{E(_local(r["at"], "%H:%M"))}</div>'
                + (f'<div class="ds-sm" title="{E(no_bidi(r["path"]))}">옛 이름 {E(no_bidi(PurePosixPath(r["path"]).name))}</div>'
                   if r["path"] != key else ""))
        trs += (f'<tr class="ds-row" data-href="{href}"><td class="c-dt">{when}</td>{_value_cells(trip, rest)}'
                f'<td class="c-state">{st_}</td>'
                f'<td class="ds-go c-go"><a href="{href}" aria-label="#{cid} 변경 상세">›</a></td></tr>')
    n = len(rows)
    first = rows[-1]["at"]
    s_bits = [f"최근 순 · {n:,}건", f"처음 {E(_md_iso(first, today))}"]
    more = (f'<div class="ds-card-f"><a href="/changes?p={quote(proj, safe="")}&amp;q={quote(name, safe="")}">'
            f'{n - DOC_ROWS:,}건 더 — 변경 기록에서 찾기 →</a></div>' if n > DOC_ROWS else "")
    table = ('<div class="ds-scroll"><table class="ds-t ds-lb-hist" id="lb-hist">'
             + _cols("w-dt", "w-place", "w-val", "w-state", "w-go")
             + '<thead><tr><th>날짜</th><th>바뀐 곳</th><th>이전 / 지금</th><th>상태</th><th></th></tr></thead>'
             f'<tbody>{trs}</tbody></table></div>')
    card = (f'<section class="ds-card" aria-labelledby="lb-hist-h"><div class="ds-card-h"><h2 id="lb-hist-h">이력</h2>'
            f'<span class="ds-s">{" · ".join(s_bits)}</span></div>{table}{more}</section>')
    body = f'{crumb}<div class="rec ds-rec ds-lb">{box}{card}</div>'
    h._send(200, h._shell(name, body, active="/changes", title_html=title_html, sub=sub))


# ── /changes?view=list — 변경 찾기 (기간·미확인만·프로젝트별 표, 2026-11-02 갈래 N의 목록 — 화면 3판에서 표 칸만 새로) ──────

def _get_changes_list(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    f = _filters(h, scope)
    _note_out_of_scope(h, scope)                 # 옛 메일의 /changes?p=범위 밖&show=… — 위에 한 줄 (검토 Y3 L1)
    from watcher.change_ledger import acks_by_change, select_changes
    with w.session() as st:
        projs = _projects(st, scope)
        # 수는 자르기 전 전체로 센다 — 최근 줄이 모두 재저장이면 그 뒤의 진짜 변경이 잘려 전체 보기 '미확인 0', 미확인만 '미확인 1'
        # 이었고, 감시 화면과도 달랐다 (ux25 F3). 판정은 미확인 행만 ack_marks 한 번 — 대시보드와 같은 것
        everything = select_changes(st, projects=_scope_set(scope, f["p"]), date_from=f["from"], date_to=f["to"],
                                    limit=COUNT_MAX, newest_first=True)
        done = {i for (i,) in st.conn.execute("SELECT DISTINCT change_id FROM acks")}
        pending = [c for c in everything if c["id"] not in done]
        exempt, side = st.ack_marks([c["id"] for c in pending])     # 기록만 남는 행 — 감시 화면·메일과 같은 판정 (ux24 AK2)
        todo = [c for c in pending if c["id"] not in exempt]
        # 짝의 삭제 쪽은 메일처럼 추가 쪽 한 줄로 접어 센다 — 추가 쪽이 이미 확인됐어도 삭제 쪽이 따로 세어지지 않게 그 행도 함께 넘긴다
        main_todo = _count_main(todo + [c for c in everything if c["kind"] == "added" and c["id"] in done], side)
        unacked_by_p = Counter(c["project"] for c in main_todo if c["id"] not in done)
        chs = todo if f["show"] == "unacked" else everything
        more = len(chs) > LIST_MAX
        chs = chs[:LIST_MAX]
        acks = acks_by_change(st, [c["id"] for c in chs])
        notes = _notes_of(st, [c["id"] for c in chs])
        n_iss = _open_issue_count(st, scope, f["p"])
        hider = _Hider(st, scope)              # 범위 밖 옛 경로 가리기 (검토 X L1)
        items_of = {c["id"]: hider.items(_items_of(st, c["id"])) for c in chs}
        for c in chs:                          # 이동 전 경로의 범위 판정은 연결이 열려 있을 때 미리 (아래 접기에서 쓴다)
            hider.out_of_note(notes.get(c["id"]) or "")
    opts = '<option value="">내 범위 전체</option>' + "".join(
        f'<option value="{E(p)}"{" selected" if p == f["p"] else ""}>{E(p)}</option>' for p in projs)
    bar = (f'<form class="ds-rec-find" method="get" action="/changes"><input type="hidden" name="view" value="list">'
           f'<div><label class="ds-lbl" for="cp">프로젝트</label><select class="ds-sel" id="cp" name="p">{opts}</select></div>'
           f'<div><label class="ds-lbl" for="cf">기간</label><span class="ds-rec-dates"><input class="ds-inp" type="date" id="cf" '
           f'name="from" value="{E(f["from"].isoformat() if f["from"] else "")}" aria-label="시작 날짜">'
           f'<span class="ds-m">~</span><input class="ds-inp" type="date" id="ct" name="to" '
           f'value="{E(f["to"].isoformat() if f["to"] else "")}" aria-label="끝 날짜"></span></div>'
           f'<label class="chk" for="cu"><input type="checkbox" id="cu" name="show" value="unacked"'
           f'{" checked" if f["show"] == "unacked" else ""}>미확인만</label>'
           f'<button class="ds-btn" type="submit">보기</button></form>')
    acts = (f'<a class="ds-btn" href="/changes/issues{_qs(f, show="", **{"from": "", "to": ""})}">확인 필요 {n_iss}건</a>'
            f'<a class="ds-btn" href="/changes.xlsx{_qs(f, show="")}" title="고른 프로젝트·기간의 변경을 엑셀 한 벌로 (사진은 화면에서)">'
            f'설계 변경 대장 (엑셀)</a>')
    sub = ("" if scope is None else f'볼 수 있는 프로젝트: <b>{E(", ".join(sorted(scope)))}</b>')
    if not chs:
        groups = '<section class="ds-card"><div class="ds-empty">조건에 맞는 변경이 없습니다</div></section>'
    else:
        from watcher.brief import no_bidi
        from watcher.summary import _kind_tag
        by_p: dict = {proj: [] for proj in unacked_by_p}      # 자른 뒤 줄이 하나도 없는 프로젝트의 미확인도 머리글에는 나온다
        for c in chs:
            by_p.setdefault(c["project"], []).append(c)
        parts = []

        def _tr(c, moved_from=None, q: bool = False) -> str:
            a = acks.get(c["id"])
            state = (f'<span class="tag approved">확인 · {E(ack_label(a[-1]["by"]))}</span>' if a else
                     f'<span class="tag off" title="{E(ACK_EXEMPT_TEXT[exempt[c["id"]]])}">기록만</span>' if c["id"] in exempt else
                     '<span class="tag pending">미확인</span>')
            pp = PurePosixPath(c["path"])
            items = items_of.get(c["id"]) or []
            trip, rest = change_parts(c["kind"], items, c["path"], moved_from)
            href = f"/changes/{int(c['id'])}"
            tr = '<tr class="ds-q">' if q else "<tr>"
            return (f'{tr}<td class="c-state">{state}</td>'
                    f'<td class="c-doc"><span class="ds-tg gray">{E(_kind_tag(c["path"]))}</span></td>'
                    f'<td class="ds-b ds-file c-file"><a href="{href}">{E(no_bidi(pp.name))}</a>'
                    f'<div class="ds-sm" title="{E(no_bidi(str(pp.parent)))}">{E(no_bidi(str(pp.parent)))}</div></td>'
                    f'{_value_cells(trip, rest)}<td class="ds-m c-when">{E(_local(c["detected_at"], "%m-%d %H:%M"))}'
                    f'<div class="ds-sm">#{int(c["id"])}</div></td>'
                    f'<td class="ds-go c-go"><a href="{href}" aria-label="#{int(c["id"])} 자세히">›</a></td></tr>')
        # 이전/지금 두 줄(2026-11-21): '이전 | → | 지금' 세 칸 대신 '이전 / 지금' 한 칸
        head = (_cols("w-state2", "w-doc", "w-file", "w-place", "w-val", "w-when", "w-go")
                + "<thead><tr><th>상태</th><th>문서</th><th>파일</th><th>바뀐 곳</th><th>이전 / 지금</th>"
                  "<th>검사</th><th></th></tr></thead>")
        for proj in sorted(by_p, key=lambda x: (x == "미분류", x)):
            # 메일과 같은 규칙으로 접는다 — 폴더 이름 변경이 '삭제 2 + 추가 2'(미확인 4)로 보였다 (ux20 mail 9)
            main_, quiet_, moved_ = _fold(by_p[proj], notes)
            moved_ = {k: hider.path(v) for k, v in moved_.items()}
            rows = sorted(main_, key=lambda c: (c["id"] in acks, -c["id"]))      # 미확인 먼저, 그 안에서 최근 것부터
            un = unacked_by_p.get(proj, 0)
            body = "".join(_tr(c) for c in rows)
            if quiet_:
                body += (f'</tbody><tbody><tr class="ds-fold"><td colspan="7"><details class="ds-qd"><summary>'
                         f'그 밖의 알림 {len(quiet_)}건: 이동·다시 저장·복사본 <b>보기</b></summary></details></td></tr>'
                         + "".join(_tr(c, moved_.get(c["id"]), q=True) for c in sorted(quiet_, key=lambda c: -c["id"])))
            cut_un = un - sum(1 for c in rows if c["id"] not in acks and c["id"] not in exempt)
            cut_line = (f'<div class="ds-card-f">미확인 {cut_un}건은 이 목록 뒤에 있습니다. <a href="/changes{_qs(f, p=proj, show="unacked")}">'
                        '미확인만 보기 →</a></div>' if cut_un > 0 else "")
            table = (f'<div class="ds-scroll"><table class="ds-t ds-rec-chg ds-rec-find-t">{head}<tbody>{body}</tbody></table></div>'
                     if body else ("" if cut_line else '<div class="ds-empty">내용이 바뀐 변경은 없습니다.</div>'))
            # 머리 = 프로젝트 + 수 표시(미확인이 있으면 빨강) — 옛 머리 글자 꼴 그대로(시험·메일 대조가 읽는다)
            parts.append(f'<section class="ds-card"><div class="ds-card-h"><h2>{E(proj)} <span class="tag{" pending" if un else ""}">미확인 {un}</span>'
                         f' <span class="tag">보이는 변경 {len(rows)}</span>'
                         + (f' <span class="tag">그 밖의 알림 {len(quiet_)}</span>' if quiet_ else "") + '</h2></div>'
                         f'{table}{cut_line}</section>')
        groups = "".join(parts)
        if more:
            groups += f'<div class="ds-alert info">최근 {LIST_MAX}건만 보입니다. 프로젝트나 기간을 좁혀 보세요.</div>'
    crumb = '<div class="crumb ds-crumb"><a href="/changes/recent">최근 변경</a><span class="ds-sep">›</span>변경 찾기</div>'
    h._send(200, h._shell("변경 찾기", f'{crumb}<section class="ds-card ds-rec-findc">{bar}</section>{groups}',
                          active="/changes/recent", actions=acts, sub=sub))


def _notes_of(st: State, ids) -> dict:
    """변경 id → '참고' 문구(이동·복사본·재저장 …) — 메일이 '그 밖의 알림'으로 접는 근거와 같은 것 (brief.note_of)."""
    out: dict = {}
    ids = [int(i) for i in ids]
    for k in range(0, len(ids), 400):
        part = ids[k:k + 400]
        for cid, js in st.conn.execute(
                f"SELECT change_id, items_json FROM change_details WHERE change_id IN ({','.join('?' * len(part))})", part):
            try:
                items = json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            for it in items if isinstance(items, list) else ():
                if isinstance(it, dict) and it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
                    out[int(cid)] = str(it.get("new") or "")
                    break
    return out


def _fold(rows: list, notes: dict) -> tuple[list, list, dict]:
    """(주요 변경, 그 밖의 알림, {추가 쪽 id: 이전 경로}) — brief.arrange_changes를 그대로 쓴다(메일과 같은 접기).
    이동 짝의 삭제 쪽은 빠지고 추가 쪽 한 줄이 '이동'으로 남는다. 내용이 바뀐 변경은 접지 않는다(원칙 5)."""
    from types import SimpleNamespace
    from watcher.brief import arrange_changes
    from watcher.diff import ChangeItem
    objs = [SimpleNamespace(id=c["id"], kind=c["kind"], path=c["path"], row=c) for c in rows]
    by_id = {o.id: ([ChangeItem("CHECK_SKIPPED", "참고", None, notes[o.id], "")] if notes.get(o.id) else []) for o in objs}
    try:
        main, quiet, moved = arrange_changes(objs, {}, by_id)
    except Exception:                       # noqa: BLE001 — 접기에 실패하면 전처럼 모두 보인다
        return list(rows), [], {}
    mv = {}
    for o in quiet:
        if id(o) in moved:
            mv[o.id] = moved[id(o)]
    return [o.row for o in main], [o.row for o in quiet], mv


def _count_main(rows: list, notes: dict) -> list:
    """_fold의 '주요 변경'과 같은 행을 정렬 없이 (brief.arrange_changes의 접기 그대로) — 수만 셀 때. 미확인 전부를 메일 순서로
    정렬하느라 /changes 한 번이 미확인 1만에 5초, 10만 건에 26초였다 (ux25 G2). 줄이 맞는지는 test_ux25_perf가 _fold와 견준다."""
    from watcher.brief import _MOVE_MARK, is_quiet
    note = {c["id"]: notes.get(c["id"]) or "" for c in rows}
    removed_by_path: dict = {}
    for c in rows:
        if c["kind"] == "removed":
            removed_by_path.setdefault(c["path"], []).append(c)
    added_paths = {c["path"] for c in rows if c["kind"] == "added"}
    hide, moved = set(), set()
    for c in rows:
        n = note[c["id"]]
        if c["kind"] == "added" and _MOVE_MARK in n:
            prev = n.split(_MOVE_MARK, 1)[1].split(" (내용 동일")[0].strip()
            x = next((x for x in removed_by_path.get(prev, ()) if x["id"] not in hide), None)
            if x is not None:
                hide.add(x["id"])
                moved.add(c["id"])
    for c in rows:
        n = note[c["id"]]
        if c["kind"] == "removed" and "옮겨지며 내용도 바뀜" in n and n.split("(으)로 옮겨지며", 1)[0].strip() in added_paths:
            hide.add(c["id"])
    return [c for c in rows if c["id"] not in hide and c["id"] not in moved and not is_quiet(note[c["id"]])]


def _open_issue_count(st: State, scope, p: str) -> int:
    rows = st.conn.execute("SELECT IFNULL(project, '미분류'), COUNT(*) FROM issues WHERE resolved_at IS NULL "
                           "GROUP BY 1").fetchall()
    return sum(n for proj, n in rows if _in(scope, proj) and (not p or proj == p))


# ── /changes/<번호> — 근거·사진·확인 ───────────────────────────────────────────

def _change_id(h) -> int:
    S = _S()
    raw = getattr(h, "path_change_id", "") or S.FormsHandler._one(h._query(), "id")
    try:
        return S.FormsHandler._int(raw)
    except S.HttpError:
        raise S.HttpError(404)


def _row_of(st: State, cid: int) -> dict | None:
    row = st.conn.execute("SELECT id, snapshot_id, kind, path, old_sha256, new_sha256, detected_at, IFNULL(project, '미분류') "
                          "FROM changes WHERE id = ?", (cid,)).fetchone()
    if row is None:
        return None
    return dict(zip(("id", "snapshot_id", "kind", "path", "old_sha256", "new_sha256", "detected_at", "project"), row))


def _cap_keys(caps) -> list[str]:
    """사진 열쇠 차례 — /changes/img?k=번호가 가리키는 자리 (전/후 사진 묶음만)."""
    if not isinstance(caps, dict):
        return []
    return sorted(k for k, v in caps.items() if isinstance(k, str) and isinstance(v, dict)
                  and (isinstance(v.get("before"), dict) or isinstance(v.get("after"), dict) or v.get("b64")))


def _cap_key_of(caps: dict, it) -> str | None:
    for k in (f"{it.kind}|{it.key}|{it.where}", f"{it.kind}|{it.key}", str(it.key)):
        v = caps.get(k)
        if isinstance(v, dict) and (isinstance(v.get("before"), dict) or isinstance(v.get("after"), dict) or v.get("b64")):
            return k
    return None


def _sides(cap: dict) -> list[tuple[str, dict]]:
    if "after" in cap or "before" in cap:
        return [(s, cap[s]) for s in ("before", "after") if isinstance(cap.get(s), dict) and cap[s].get("b64")]
    return [("after", cap)] if cap.get("b64") else []


def _item_cells(it) -> tuple[str, str, str, str]:
    """(구분, 항목, 이전, 새 값) 글자 — 메일·화면과 같은 이름 함수."""
    from watcher.brief import _flabel, _fmt_row_values, fmt_val, item_kind_label, notice_text
    kind = str(it.kind or "")
    lab = item_kind_label(it)        # 발주 후 변경 표지는 공용 '검사 한계'가 아니라 '발주 대조' (ux21 mail 1)
    if kind == "ROW_CHANGED":
        rk, _, col = split_row_cell(it.key)
        name = f"{rk or it.key} · {col}" + (f" ({it.label})" if it.label else "")
        return lab, name, fmt_val(it.old), fmt_val(it.new)
    if kind in ("ROW_ADDED", "ROW_REMOVED"):
        name = str(it.key) + (f" ({it.label})" if it.label else "")
        return lab, name, _fmt_row_values(it.old) if it.old else "—", _fmt_row_values(it.new) if it.new else "—"
    if kind == "CHECK_SKIPPED":
        return lab, str(it.key), "—", notice_text(it, full=True)
    g = not kind.startswith(("TEXT_", "FIELD_"))
    if kind in ("TEXT_ADDED", "TEXT_REMOVED"):
        # 짝 이름표('M-101: 5.5kW → 7.5kW')를 이름 칸에 통째로 실으면 화살표가 남는다 — 태그만 (메일과 같은 _m_text_cells, 2026-11-21 L)
        from watcher.brief import _m_text_cells
        return lab, _m_text_cells(it)[0], fmt_val(it.old, g), fmt_val(it.new, g)
    return lab, _flabel(it), fmt_val(it.old, g), fmt_val(it.new, g)


_HOW_FROM = ("title_block", "filename", "folder", "shared")       # '…에서'로 읽는 근거 — 나머지는 사람이 정한 것


def attribution_parts(attr, project: str) -> tuple[str, str, str]:
    """(프로젝트, 정한 근거, 처음 정한 프로젝트) — 변경 상세 머리의 이름|값 격자용 (화면 모양 v2). 옛 기록(근거 칸 없음)은 그렇다고."""
    proj = (attr or {}).get("project") or project or "미분류"
    how = (attr or {}).get("how")
    why = str((attr or {}).get("why") or "").strip()
    if not attr or not how:
        basis = "기록 없음 (옛 기록)"
    elif how == "unassigned":
        proj, basis = "미분류", "표제란·파일명·폴더에서 프로젝트를 찾지 못했습니다"
    else:
        lab = attr.get("how_label") or ""
        basis = f"{lab}{'에서' if how in _HOW_FROM else ''}" + (f" ({why})" if why and why != lab else "")
    orig = (attr or {}).get("original") or {}
    first = ""
    if orig and (orig.get("project") or "") != (attr or {}).get("project"):
        first = f"{orig.get('project') or '미분류'} ({orig.get('how_label') or '모름'})"
    return proj, basis, first


def attribution_text(attr, project: str) -> str:
    """프로젝트를 정한 근거 한 줄 — '프로젝트 P26-101 — 표제란 프로젝트 번호에서 (표제란 'P26-101')'. 옛 기록은 '정한 근거 기록 없음'.
    (화면은 attribution_parts로 이름|값 격자에 그린다. 이 한 줄 꼴은 다른 곳·시험이 쓴다.)"""
    proj, basis, first = attribution_parts(attr, project)
    if not attr or not (attr or {}).get("how"):
        out = f"프로젝트 {proj} — 정한 근거 {basis}"
    elif (attr or {}).get("how") == "unassigned":
        out = f"미분류 — {basis}"
    else:
        out = f"프로젝트 {proj} — {basis}"
    return out + (f" · 처음 정한 프로젝트: {first}" if first else "")


def _not_here(h, scope) -> None:
    """없는 변경과 범위 밖 변경은 **같은 응답** — '없는 화면입니다' + 내가 볼 수 있는 프로젝트 한 줄 (ux20 mail 결정 재검토).
    그 변경이 있는지·어느 프로젝트인지는 드러내지 않는다: 줄에 실리는 것은 이 계정의 범위뿐이고 요청한 번호와 무관하다."""
    S = _S()
    mine = _mine_text(scope)
    body = (f'<div class="note bad" role="alert">{E(S._ERROR_TEXT.get(404, "없는 화면입니다"))}</div>'
            f'<section class="ds-card"><div class="ds-card-b ds-rec-pad">'
            f'<p>이 계정이 변경을 볼 수 있는 프로젝트: <b>{E(mine)}</b></p>'
            f'<p class="ds-sm">다른 프로젝트의 변경이거나 정리된 기록입니다. 더 보려면 관리자에게 열람 범위를 부탁하세요.</p>'
            f'<p class="ds-rec-btnrow"><a class="ds-btn" href="/changes">프로젝트 목록으로</a></p></div></section>')
    h.close_connection = True
    h._send(404, h._shell(S.fail_title(404), body, active="/changes"))     # 없는 주소와 같은 제목 (갈래 L)


def _W():
    """감시 화면(web.py) — 변경 상세의 글·마크업 도우미를 같은 것으로 쓴다 (2026-11-21 구현자 M: 사내망 변경 상세를 감시 화면 변경
    상세와 같은 말·같은 꼴로). web은 forms를 함수 안에서만 가져오므로 순환이 없다. 상세를 처음 열 때 한 번만 가져온다.
    인라인 style·data: 사진·감시 PC 전용 주소를 내는 web 함수(_web_item_table·_web_row_table의 증감 배지 _delta, _ds_pic의 data: 사진,
    rc_attr_text의 /unassigned 링크)는 그대로 쓰지 않고 아래 chg_* 함수가 같은 글·같은 꼴로 그린다 — 이 서버는 CSP(style-src 'self')로
    인라인 style을 막고, 사내망은 열람·확인만 한다(CLAUDE.md 3절). 같은 글인지는 tests/test_lan_detail_parity.py가 견준다."""
    from watcher import web
    return web


def _chg_delta(old, new) -> str:
    """수량처럼 숫자면 증감 — 감시 화면 web._delta와 같은 글('+1'), 색은 클래스로(인라인 style은 CSP가 막는다)."""
    try:
        d = float(new) - float(old)      # type: ignore[arg-type]
    except (TypeError, ValueError):
        return ""
    if d == 0:
        return ""
    return f' <span class="ds-chg-delta">{"+" if d > 0 else ""}{_W()._delta_num(d)}</span>'


def chg_item_table(items) -> str:
    """'바뀐 내용' 표 — 감시 화면 web._web_item_table과 같은 칸·차례·글(바뀐 곳 | 이전 / 지금 | 위치). 갈래 표지(개정표 행 추가 등)는
    바뀐 곳 아래 작은 표지(ds-l2), 글줄 앞 태그는 이전·지금에서 떼고 title에 전체. 숨기기 단추 칸은 없다(감시 PC에서만)."""
    W = _W()
    if not items:
        return ""
    items = sorted(items, key=lambda i: 1 if (i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_")) else 0)
    trs = []
    for i in items:
        label, _cls = W._WEB_ITEM_KIND.get(i.kind, (i.kind, "na"))
        old, new, tip = i.old, i.new, ""
        k0 = str(i.key or "")
        if (i.kind == "TEXT_CHANGED" and k0 and isinstance(old, str) and isinstance(new, str)
                and old.startswith(k0 + " ") and new.startswith(k0 + " ")):
            old, new = old[len(k0) + 1:], new[len(k0) + 1:]
            tip = f' title="이전: {W._E(i.old)} / 지금: {W._E(i.new)}"'
        if i.kind in ("TEXT_CHANGED", "FIELD_CHANGED", "REVROW_CHANGED"):
            o_html, n_html = W._ds_wdiff(old, new, group=not i.kind.startswith(("TEXT_", "FIELD_")))
        else:
            _g = not i.kind.startswith(("TEXT_", "FIELD_"))
            o_html, n_html = W._E(W._fmt_val(old, _g)), W._E(W._fmt_val(new, _g))
        key_lb = W._item_key_label(i)
        tag = ("" if (i.kind in ("TEXT_CHANGED", "FIELD_CHANGED") or label == key_lb) else
               f'<div class="ds-l2"><span class="ds-tg gray">{W._E(label)}</span></div>')
        o_v = "없음" if o_html in ("", "—") else o_html
        n_v = "없음" if n_html in ("", "—") else n_html
        trs.append(f'<tr{tip}><td class="ds-b">{W._E(key_lb)}{tag}</td>'
                   f'<td class="ds-chg-pv">{W._pv(o_v, n_v + _chg_delta(i.old, i.new))}</td>'
                   f'<td class="ds-m ds-chg-at">{W._E(W._hw(i.where))}</td></tr>')
    return ('<div class="ds-scroll"><table class="ds-t ds-chg-t ds-chg-fit ds-chg-items"><thead><tr>'
            '<th class="ds-chg-wk">바뀐 곳</th><th>이전 / 지금</th><th class="ds-chg-ww">위치</th>'
            '</tr></thead><tbody>' + "".join(trs) + '</tbody></table></div>')


def chg_row_table(items) -> str:
    """표(BOM·발주서 등) 행 변경 — 감시 화면 web._web_row_table과 같은 칸·글(행 | 바뀐 칸 | 이전 / 지금 | 위치). 한 행의 여러 칸은
    행·위치 칸을 합쳐(rowspan) 칸마다 한 줄, 행 추가는 [이전] 없음 / [지금] 행 값, 삭제는 [지금] 없음, 남은 칸은 접힌 작은 표."""
    W = _W()
    trs = []
    for gid, g in W._row_groups(items):
        first = g[0]
        _lb = str(getattr(first, "label", None) or "")
        label = (f'<div class="ds-sm" title="{W._E(_lb)}">'
                 f'{W._E(_lb if len(_lb) <= 60 else _lb[:60] + "…")}</div>' if _lb else "")
        where = W._E(W._hw(first.where or ""))
        n = len(g) if first.kind == "ROW_CHANGED" else 1
        rs = f' rowspan="{n}"' if n > 1 else ""
        key = gid if first.kind == "ROW_CHANGED" else first.key
        head = (f'<td{rs} class="ds-b"><code>{W._E(key)}</code>{label}'
                + (f'<div class="ds-sm">{n}개 열</div>' if n > 1 else "") + '</td>')
        tail = f'<td{rs} class="ds-m" data-l="위치">{where}</td>'
        if first.kind == "ROW_CHANGED":
            for k, i in enumerate(g):
                o_html, n_html = W._ds_wdiff(i.old, i.new)
                o_v = "(빈칸)" if o_html in ("", "—") else o_html      # 칸의 빈 값 — 감시 화면과 같은 말 (Y2 M1)
                n_v = "(빈칸)" if n_html in ("", "—") else n_html
                trs.append(f'<tr>{head if k == 0 else ""}<td data-l="바뀐 칸"><b>{W._E(split_row_cell(i.key)[2])}</b></td>'
                           f'<td class="ds-chg-pv">{W._pv(o_v, n_v + _chg_delta(i.old, i.new))}</td>{tail if k == 0 else ""}</tr>')
            continue
        if first.kind == "ROW_ADDED":
            cell = W._pv("없음", W._E(W._row_join(first.new)) + W._row_rest_html(W._row_values(first.new)))
        elif first.kind == "ROW_REMOVED":
            cell = W._pv(W._E(W._row_join(first.old)) + W._row_rest_html(W._row_values(first.old)), "없음")
        else:
            cell = f'<span class="ds-m">{W._E(first.new or "")}</span>'
        trs.append(f'<tr>{head}<td data-l="바뀐 칸"><span class="ds-tg gray">{W._E(W._ROW_KIND_TAG.get(first.kind, first.kind))}</span></td>'
                   f'<td class="ds-chg-pv">{cell}</td>{tail}</tr>')
    if not trs:
        return ""
    return ('<div class="ds-scroll"><table class="ds-t ds-chg-t ds-chg-fit ds-chg-rows"><thead><tr>'
            '<th class="ds-chg-wr">행</th><th class="ds-chg-wc">바뀐 칸</th><th>이전 / 지금</th>'
            '<th class="ds-chg-wl">위치</th></tr></thead><tbody>' + "".join(trs) + '</tbody></table></div>')


def _chg_pic(cid: int, n: int, side: str, cap, title: str, when: str, empty: str) -> str:
    """사진 한 칸 — 감시 화면 web._ds_pic과 같은 꼴(머리 '이전'/'지금' + 저장 날짜, 사진, 없으면 같은 자리에 회색 칸). 사진은 data:가
    아니라 /changes/img(범위 확인·형식 확인을 거치는 길)로."""
    W = _W()
    head = (f'<div class="ds-cap"><span>{title}</span>'
            + (f'<span class="ds-m">{W._E(when)} 저장</span>' if when else "") + '</div>')
    if isinstance(cap, dict) and cap.get("b64"):
        where = W._hw(cap.get("caption") or "")
        return (f'<div class="ds-pic">{head}<img src="/changes/img?id={int(cid)}&amp;k={int(n)}&amp;s={side}" loading="lazy" '
                f'alt="{W._E(title)} — {W._E(where)}" title="{W._E(where)}"></div>')
    return f'<div class="ds-pic">{head}<div class="ds-chg-noimg">{empty}</div></div>'


def chg_pics_html(cid: int, pairs, when_old: str, when_new: str) -> str:
    """전/후 사진 묶음들 — 감시 화면 web._ds_pics_html과 같은 꼴: 묶음이 여럿이면 위에 바뀐 곳 + 위치 한 줄, 이전·지금 두 칸(카드 폭에
    맞게 크게), 이전 확대 사진이 없는 덮어쓴 파일은 지금 한 칸을 넓게, 넷을 넘으면 '사진 N곳 더'로 접는다.
    pairs: [(바뀐 곳 이름 HTML, 사진 묶음, /changes/img 열쇠 번호)]."""
    W = _W()
    blocks = []
    multi = len(pairs) > 1
    for name, cap, n in pairs:
        if not isinstance(cap, dict):
            continue
        after = cap.get("after") if ("after" in cap or "before" in cap) else cap
        before = cap.get("before")
        if not after and not before:
            continue
        added = "이전 판에 없음" in str((after or {}).get("caption", "") if isinstance(after, dict) else "")
        right = _chg_pic(cid, n, "after", after, "지금", when_new, "지금 판에 없는 페이지")
        if not before and not added:
            blocks.append((f'<div class="ds-chg-pt">{name}</div>' if multi else "")
                          + f'<div class="ds-pics ds-chg-one">{right}</div>')
            continue
        left = _chg_pic(cid, n, "before", before, "이전", when_old, "이전 판에 없는 페이지")
        blocks.append((f'<div class="ds-chg-pt">{name}</div>' if multi else "")
                      + f'<div class="ds-pics">{left}{right}</div>')
    if len(blocks) > W._DS_PIC_SHOW:
        rest = blocks[W._DS_PIC_SHOW:]
        return ("".join(blocks[:W._DS_PIC_SHOW])
                + f'<details class="ds-chg-fold"><summary>사진 {len(rest)}곳 더</summary>{"".join(rest)}</details>')
    return "".join(blocks)


HIST_SCAN = 200                      # 이 파일의 변경 기록 — 같은 경로의 최근 기록을 이만큼까지 읽어 접는다(보이는 줄은 web._DS_HIST_MAX)


def _moved_away(st: State, path: str, snap, note: str) -> bool:
    """삭제 줄이 이동 짝의 삭제 쪽인가 — 감시 화면 web._fold_moves와 같은 판정: 같은 검사에 '이름·위치만 바뀜 — 이전: <이 경로>' 추가가
    있거나, 참고 글이 '<새 경로>(으)로 옮겨지며 내용도 바뀜'이고 그 새 경로의 추가가 같은 검사에 있다. 감시 화면은 그 줄을 새 경로의
    '이동'·추가 한 줄로 접어 이 경로의 기록에 싣지 않는다."""
    from watcher.brief import _MOVE_MARK
    from watcher.state import _note_in
    for ln in str(note).split("\n"):              # '참고' 글이 여럿이면 줄마다 (_items_note)
        if "옮겨지며 내용도 바뀜" in ln:
            tgt = ln.split("(으)로 옮겨지며", 1)[0].strip()
            if st.conn.execute("SELECT 1 FROM changes WHERE path = ? AND kind = 'added' AND snapshot_id IS ? LIMIT 1",
                               (tgt, snap)).fetchone():
                return True
    for (js,) in st.conn.execute(
            "SELECT d.items_json FROM changes c JOIN change_details d ON d.change_id = c.id "
            "WHERE c.kind = 'added' AND c.snapshot_id IS ? AND d.items_json LIKE '%CHECK_SKIPPED%'", (snap,)):
        n = _note_in(js)
        if _MOVE_MARK in n and _move_prev(n) == path:
            return True
    return False


def _path_rows(st: State, path: str, scope, cid: int | None = None) -> list:
    """같은 경로의 기록 줄(최신순) — 감시 화면 rows()·_fold_moves를 이 경로에만: 첫 등록(baseline)·이동 짝의 추가 쪽(moved_from)을
    표시하고, 이동 짝의 삭제 쪽은 hidden(감시 화면이 접어 싣지 않는 줄). 열람 범위 밖 프로젝트로 귀속된 줄은 뺀다.
    줄마다 items(보이는 항목 — 숨긴 오탐 뺌)·note('참고' 글).
    cid: 지금 보는 기록 — 같은 경로 기록이 HIST_SCAN줄을 넘어 그 줄이 잘려 나가면 끝에 따로 붙인다(파일 정보 '발견'·'이동' 표지·
    '옮기기 전' 줄이 그 줄에서 나온다: 2026-11-21 검토 X2 L2)."""
    from watcher.brief import _MOVE_MARK
    from watcher.summary import visible_items
    cols = ("change_id", "kind", "snapshot_id", "detected_at", "project")
    rows = [dict(zip(cols, r)) for r in st.conn.execute(
        "SELECT id, kind, snapshot_id, detected_at, IFNULL(project, '미분류') FROM changes WHERE path = ? "
        "ORDER BY id DESC LIMIT ?", (path, HIST_SCAN))]
    if cid is not None and not any(int(r["change_id"]) == int(cid) for r in rows):
        rows += [dict(zip(cols, r)) for r in st.conn.execute(
            "SELECT id, kind, snapshot_id, detected_at, IFNULL(project, '미분류') FROM changes WHERE id = ? AND path = ?",
            (int(cid), path))]
    rows = [r for r in rows if _in(scope, r["project"])]
    if not rows:
        return []
    first, ext_base = st.first_snapshot_by_root(), st.ext_baseline()
    det = {int(r_["id"]): r_ for r_ in st._summary_rows([r["change_id"] for r in rows])}
    from watcher.summary import restored_adds
    rs_of = restored_adds(st, [r["change_id"] for r in rows if r["kind"] == "added"])    # 되살림 두 꼴 — 감시 화면과 같은 판단 (Z3a M1)
    for r in rows:
        d = det.get(int(r["change_id"])) or {}
        r["rs"] = rs_of.get(int(r["change_id"]))
        r["path"] = path
        r["items"] = [it for it in visible_items(d.get("items") or [], d.get("dismissed") or {}) if isinstance(it, dict)]
        r["note"] = note = _items_note(d.get("items") or [])
        r["baseline"] = State.is_first_registration(r["kind"], path, r["snapshot_id"], first, ext_base)
        r["moved_from"], r["hidden"] = None, False
        if r["kind"] == "added" and _MOVE_MARK in note:
            prev = _move_prev(note)
            if st.conn.execute("SELECT 1 FROM changes WHERE path = ? AND kind = 'removed' AND snapshot_id IS ? LIMIT 1",
                               (prev, r["snapshot_id"])).fetchone():
                r["moved_from"] = prev
        elif r["kind"] == "removed":
            r["hidden"] = _moved_away(st, path, r["snapshot_id"], note)
    return rows


def chg_hist_card(rows: list, cid: int, path: str, sums: dict) -> str:
    """오른쪽 '이 파일의 변경 기록' — 감시 화면 WebApp._chg_hist_card와 같은 말·같은 꼴: 같은 경로의 기록을 최신순으로(지금 보는 기록도
    — 굵게·링크 없이, 날짜 아래 '지금 보는 기록'), 줄마다 바뀐 곳 + [이전]/[지금] 두 줄(앞 하나, 나머지 '외 N곳'), 요약 없는 기록은
    '첫 등록'·'이동'·'새 문서'·'삭제', 그 밖은 기록 요약에서 꼬리표·주어를 뗀 값(web._ds_hist_text). 링크는 /changes/<번호>.
    rows: _path_rows(범위 밖 줄은 이미 빠짐 — 사내망 범위 규칙 그대로), sums: 변경 id → 기록 요약(범위 밖 옛 경로는 가린 것)."""
    W = _W()
    mine = [r for r in rows if not r["hidden"]][:W._DS_HIST_MAX]
    if not any(int(r["change_id"]) != int(cid) for r in mine):
        return ""
    lis = []
    for r in mine:
        rid = int(r["change_id"])
        _rs = W._row_restored(r, r.get("items") or [])      # 지웠다 되살린 파일 — 감시 화면과 같은 말 (Y1 P3b)
        txt = ("첫 등록" if r.get("baseline") else "이동" if r.get("moved_from") else "" if _rs else
               "새 문서" if r.get("kind") == "added" else "삭제" if r.get("kind") == "removed" else "")
        parts = W._rc_parts(r.get("kind") or "modified", r.get("items") or [], path, r.get("rs")) if not txt else []
        pv = W._rc_parts_blocks(parts, 1) if any(W._rc_part_is_pair(po, pn) for _w, po, pn, _l in parts[:1]) else ""
        if _rs and not pv:
            txt = "되살림"
        txt = W._ds_hist_text(sums.get(rid) or "") if (sums.get(rid) and not txt) else (txt or "내용 변경")
        day = W._E(W._ds_when_iso(r.get("detected_at"), time_too=False))
        if rid == int(cid):
            day += '<span class="ds-chg-now">지금 보는 기록</span>'
        if pv:
            inner = f'<div class="ds-chg-hv">{pv}</div>'
            lis.append(f'<li class="on"><span title="지금 보는 기록 #{rid}">{inner}</span><span class="ds-m">{day}</span></li>'
                       if rid == int(cid) else
                       f'<li><a class="ds-chg-hl" href="/changes/{rid}">{inner}</a><span class="ds-m">{day}</span></li>')
        elif rid == int(cid):
            lis.append(f'<li class="on"><span title="지금 보는 기록 #{rid}">{W._E(txt)}</span><span class="ds-m">{day}</span></li>')
        else:
            lis.append(f'<li><a href="/changes/{rid}">{W._E(txt)}</a><span class="ds-m">{day}</span></li>')
    return ('<section class="ds-side-c" id="file-hist" aria-labelledby="rec-hist-h"><h3 id="rec-hist-h">이 파일의 변경 기록</h3>'
            f'<ul class="ds-list">{"".join(lis)}</ul></section>')


def _extract_ro(st: State, sha, path):
    """추출 기록(extracts) 읽기만 — State.load_extract와 같은 고르기(확장자 묶음이 다르면 'sha:묶음' 기록)인데, 손상 행을 지우지 않는다
    (이 화면은 감시 기록에 쓰지 않는다). 못 읽으면 None."""
    from watcher.state import _TYPE_GROUP, extract_group

    def one(k):
        try:
            row = st.conn.execute("SELECT doc_json FROM extracts WHERE sha256 = ?", (k,)).fetchone()
            d = json.loads(row[0]) if row and row[0] else None
        except sqlite3.OperationalError:
            raise
        except (sqlite3.DatabaseError, ValueError, TypeError):
            return None
        return d if isinstance(d, dict) else None
    if not sha:
        return None
    d = one(sha)
    if d is None or not path:
        return d
    want = extract_group(path)
    g = d.get("ext_kind") or d.get("doc_type")
    g = _TYPE_GROUP.get(g, g) if g else None
    if not want or not g or g == want:
        return d
    return one(f"{sha}:{want}")


def _opened_by(st: State, cid: int, scope=None) -> list:
    """이 변경으로 열린 확인 필요 [(id, 지금 열림?, 코드)] — 감시 화면 WebApp._rc_opened와 같은 묶기(State._issues_opened_by). 읽기만.
    열람 범위 밖 프로젝트의 확인 필요는 세지 않는다 — 셌더니 범위 밖에서 아직 열린 것이 '모두 처리됐습니다'로 보이고 그 건수도
    드러났다(2026-11-21 검토 X2 L3)."""
    try:
        opened = st._issues_opened_by(st._summary_rows([cid]))
        v = opened.get(cid) or opened.get(int(cid)) or []
        iids = sorted({d["id"] for d in v})
        if iids and scope is not None:
            proj = dict(st.conn.execute(
                f"SELECT id, IFNULL(project, '미분류') FROM issues WHERE id IN ({','.join('?' * len(iids))})", iids).fetchall())
            v = [d for d in v if _in(scope, proj.get(d["id"], "미분류"))]
            iids = sorted({d["id"] for d in v})
        live = {r[0] for r in st.conn.execute(
            f"SELECT id FROM issues WHERE resolved_at IS NULL AND id IN ({','.join('?' * len(iids))})", iids)} if iids else set()
        return [(d["id"], d["id"] in live, d.get("code")) for d in v]
    except sqlite3.OperationalError:
        raise
    except Exception:            # noqa: BLE001 — 상자 하나 때문에 상세가 죽으면 안 된다
        return []


def _file_evidence(c: dict, facts: list, mt_new, mt_old) -> str:
    """파일 수준 근거 표 — 감시 화면 WebApp.file_evidence와 같은 칸·글(지문·경로·저장 시각·판 크기). 내용 비교가 없거나 실패한
    변경에도 이것만은 보인다(원칙 4)."""
    W = _W()
    new_sha, old_sha = c.get("new_sha256"), c.get("old_sha256")
    facts = [f for f in facts if f.get("sha256") in (new_sha, old_sha)]
    facts.sort(key=lambda f: f.get("sha256") != new_sha)

    def _size(n) -> str:
        try:
            n = int(n)
        except (TypeError, ValueError):
            return "—"
        return f"{n:,}바이트" + (f" ({n / 1048576:.1f}MB)" if n >= 1048576 else "")

    _mt = W._fe_when_ts         # 저장·검사 시각은 감시 화면과 같은 함수 — 화면 날짜 꼴(연도는 올해가 아니면), 초까지는 마우스 (Z3a M3)
    # 지문도 이전/지금 두 줄 — 감시 화면 file_evidence와 같은 꼴(값 사이 화살표 없앰, 2026-11-21)
    rows = [f'<tr><td class="ds-b">지문(SHA-256)</td><td>'
            + W._pv(f'<code>{W._E(old_sha[:16])}</code>' if old_sha else "",
                    f'<code>{W._E(new_sha[:16])}</code>' if new_sha else "") + '</td></tr>',
            f'<tr><td class="ds-b">파일 경로</td><td><code>{W._E(c["path"])}</code></td></tr>']
    if mt_new or mt_old:
        rows.append(f'<tr><td class="ds-b">저장(수정) 시각</td><td>이번 판 {_mt(mt_new) if mt_new else "—"}'
                    + (f' · 이전 판 {_mt(mt_old)}' if mt_old else "") + '</td></tr>')
    elif not facts:
        rows.append('<tr><td class="ds-b">크기·저장 시각</td><td class="ds-m">저장 시각이 기록되지 않은 변경입니다'
                    '(기록 기능이 생기기 전이거나 구판이 남긴 것) — 지문만 확정됩니다</td></tr>')
    for f in facts:
        which = "이번" if f.get("sha256") == new_sha else "이전"
        rows.append(f'<tr><td class="ds-b">{which} 판 크기</td><td>{_size(f["size"])} '
                    f'<span class="ds-m">(검사 {W._fe_when_iso(f["run_at"])}, 저장 {_mt(f["mtime"])})</span></td></tr>')
    return ('<section class="ds-card" id="file-ev"><div class="ds-card-h"><h2>파일 수준 근거</h2></div>'
            '<div class="ds-scroll"><table class="ds-t ds-chg-t ds-chg-fit"><thead><tr><th class="ds-chg-wr">근거</th><th>값</th>'
            '</tr></thead><tbody>' + "".join(rows) + '</tbody></table></div></section>')


def _attr_html(att: dict) -> str:
    """귀속 근거 한 줄 (HTML) — 감시 화면 rc_attr_text와 같은 글. 미분류의 '미분류 안내' 링크(감시 화면 /unassigned)는 사내망에 없어 뗀다."""
    s = _W().rc_attr_text(att)
    return s.partition(' · <a href="/unassigned">')[0]


def _retention_days(cfg, at) -> int:
    """보존 기간(retention_days, 기본 90일)이 지난 변경이면 그 일수, 아니면 0 — 감시 화면 _older_than_retention과 같은 판정."""
    from datetime import datetime as _dt, timedelta, timezone
    try:
        days = int((cfg or {}).get("retention_days", 90) or 0)
        if days <= 0 or not at:
            return 0
        return days if _W()._parse_utc(at) < _dt.now(timezone.utc) - timedelta(days=days) else 0
    except Exception:            # noqa: BLE001
        return 0


@_guarded
def get_change_item(h) -> None:
    """/changes/<번호> — 변경 하나의 근거·사진·확인. 감시 화면 변경 상세(web.WebApp.page_change)와 같은 말·같은 꼴 (2026-11-21 구현자 M,
    사용자 "이런 디테일들도 다 잘 살려서 수정해봐"): 경로 줄(프로젝트 › 프로젝트 › 파일) · 머리(파일 이름 + 종류·첫 등록/이동/새 파일/
    삭제·확인 필요 N건·확인함, 프로젝트 · 경로) · 발주 후 변경·출도 후 변경·참고 안내 · 두 칸 — 왼쪽 확인 필요 상자 → 검사 한계(노랑) →
    '바뀐 내용' 표(바뀐 곳 | 이전 / 지금 | 위치) → 표 행 변경 → 참고(파랑) → 전/후 도면 → 놓친 변경 기록(읽기만), 오른쪽 확인 · 파일 정보 ·
    이 파일의 변경 기록. 감시 화면 전용(파일 열기·폴더 열기·고급 도구·숨기기 단추·프로젝트 바꾸기·크게 비교)은 없다 — 사내망은
    열람·확인만(CLAUDE.md 3절). 범위 밖 기록·옛 경로는 지금처럼 빼거나 가린다(검토 X L1)."""
    scope = _scope(h)
    w = _watch(h)
    cid = _change_id(h)
    S = _S()
    W = _W()
    from watcher.brief import no_bidi, split_display_items
    from watcher.change_ledger import added_notes
    from watcher.consistency import CODE_LABEL, _RE_FIRST_EDIT
    from watcher.diff import ChangeItem
    from watcher.issued import PO_MARK_KEY
    cfg = w.config()
    with w.session() as st:
        c = _row_of(st, cid)
        if c is None or not _in(scope, c["project"]):
            _not_here(h, scope)
            return
        detail = st.change_detail(cid)
        acks = st.acks_of(cid)
        ack_why = st.ack_exempt(cid)
        mt_new, mt_old = st.change_mtimes(cid)
        newx = _extract_ro(st, c["new_sha256"], c["path"])
        add_note = added_notes(st, [c]).get(cid)      # 되살아남·출도본 기록 — 감시 화면 상세·대장과 같은 글 (rv0676 WE2·WE3)
        add_ref = None
        if add_note and add_note[1]:
            r0 = _row_of(st, int(add_note[1]))
            add_ref = int(add_note[1]) if (r0 is not None and _in(scope, r0["project"])) else None
        summ = st.record_summaries([cid]).get(cid, "")
        attr = st.attribution(cid)
        hider = _Hider(st, scope)
        doc_ok = _doc_in_scope(st, c["path"], scope)      # 경로 줄의 파일 이름 → 문서 이력 (지금 그 문서가 내 범위일 때만 링크)
        rows = _path_rows(st, c["path"], scope, cid)
        vis_ids = [int(r["change_id"]) for r in rows if not r["hidden"]][:W._DS_HIST_MAX]
        sums = st.record_summaries(vis_ids) if vis_ids else {}
        for r in rows:                                    # 범위 밖 옛 경로 가리기 (검토 X L1)
            r["items"] = hider.items(r["items"])
            if int(r["change_id"]) in sums:
                sums[int(r["change_id"])] = hider.text(sums[int(r["change_id"])], r["note"], c["path"])
            r["moved_from"] = hider.path(r["moved_from"])
        opened = _opened_by(st, cid, scope)
        all_open = st.issues()
        facts = st.file_facts(c["path"])
        if detail is not None:
            raw_items = detail.get("items") or []
            detail = dict(detail, items=hider.items(raw_items))
        # 의견·담당 (2026-11-23 사내망 협업) — 감시 화면 변경 상세와 같은 카드·같은 '담당' 칸. 옛 DB면 그 구역만 한 줄 안내
        from watcher.forms import collab as _collab
        cm_card = _collab.comment_card(h, st, "change", cid)
        asg = st.assignee_of("change", cid) if st.has_collab() else None
        side_extra = _collab.side_cards(h, st, "change", cid, c["project"])
    s_all = {iid for iid, _o, _k in opened}
    s_open = {iid for iid, o, _k in opened if o}
    this_snap = c["snapshot_id"]
    # 이 파일의 열린 것 + 이 변경으로 열린 것(도면-BOM 불일치는 BOM 쪽 경로에 걸려도 이 변경이 연 것) — 범위 밖 프로젝트의 것은 뺀다
    open_ = [i for i in all_open if (i["path"] == c["path"] or int(i["issue_id"]) in s_open)
             and _in(scope, i.get("project") or "미분류")]
    pp = PurePosixPath(c["path"])
    name = pp.name
    row = next((r for r in rows if int(r["change_id"]) == cid and not r["hidden"]), None)
    is_base = bool(row and row["baseline"]) or ack_why == "first"
    moved_from = (row or {}).get("moved_from")
    proj = c["project"]
    plabel = W._ds_proj_label(proj, c["path"])
    cat = W._cat_display(c["path"], cfg if cfg is not None else {})
    when_new = W._ds_when_ts(mt_new) if (mt_new and c["kind"] != "removed") else ""
    when_old = W._ds_when_ts(mt_old) if mt_old else ""
    flds = (newx or {}).get("fields") or {}
    flds = flds if isinstance(flds, dict) else {}         # 손상 추출 기록(fields가 목록) — 칸 하나 때문에 상세가 죽지 않게 (검토 X2 L1)
    dwg = (flds.get("DWG_NO") or {}).get("value") if isinstance(flds.get("DWG_NO"), dict) else None
    cur_rev = (flds.get("REV") or {}).get("value") if isinstance(flds.get("REV"), dict) else None
    user_notes = (detail or {}).get("user_notes") or []
    user_notes = [n for n in user_notes if isinstance(n, dict)] if isinstance(user_notes, list) else []

    # ── 왼쪽: 확인 필요 · 검사 한계 · 바뀐 내용 · 참고 · 전/후 도면 · 놓친 변경 기록 ──
    pic_pairs: list = []
    warn_notes = info_notes = cards = ""
    if detail is None:
        reason = ("첫 검사 때 등록된 파일입니다. 원본은 감시 PC나 공유 폴더에서 여세요." if is_base else
                  "삭제된 파일은 내용 비교가 없습니다. 지난 판은 변경 이력에서 이 파일 이름으로 찾습니다." if c["kind"] == "removed" else
                  "지우기 전 마지막 판과 같은 바이트로 되살아난 파일이라 바뀐 내용이 없습니다."
                  if c["kind"] == "added" and add_note and add_note[1] else
                  "이전 판이 없는 새 파일이라 비교할 대상이 없습니다. 원본은 감시 PC나 공유 폴더에서 여세요."
                  if c["kind"] == "added" else
                  ("보존 기간이 지나 정리된 기록입니다. 근거는 그날의 브리핑 원본에 남아 있습니다."
                   if _retention_days(cfg, c["detected_at"]) else "첫 등록이거나 내용을 읽지 않는 파일입니다."))
        warn_notes = f'<div class="ds-alert info" role="note"><span>이 변경에는 내용 비교 기록이 없습니다. {W._E(reason)}</span></div>'
        cards = _file_evidence(c, facts, mt_new, mt_old)
    else:
        caps = detail.get("captures") or {}
        keys = _cap_keys(caps)
        dismissed = detail.get("dismissed") or {}
        if not isinstance(dismissed, dict):              # 손상 기록(목록) — 번호만 남은 꼴로 읽는다 (검토 X2 L1)
            dismissed = {str(x): {} for x in dismissed} if isinstance(dismissed, list) else {}
        dismissed = {k: (v if isinstance(v, dict) else {}) for k, v in dismissed.items()}
        pairs_ix = []
        for ix, d in enumerate(detail.get("items") or []):
            if not isinstance(d, dict):
                continue
            try:
                # 손상·이상 꼴 항목(kind가 null·숫자 등)도 글자로 — 옛 화면처럼 열린다 (검토 X2 L1)
                pairs_ix.append((ix, ChangeItem(**{k: (str(d.get(k) or "") if k in ("kind", "key") else
                                                       None if d.get(k) is None else str(d.get(k)))
                                                   for k in ("kind", "key", "old", "new", "where", "label")})))
            except TypeError:
                continue
        items = [it for ix, it in pairs_ix if str(ix) not in dismissed]
        hidden = [(ix, it) for ix, it in pairs_ix if str(ix) in dismissed]
        if any("OCR" in str(it.where or "") for it in items):
            warn_notes += ('<div class="ds-alert info" role="note"><span><b>OCR 추정값</b> 그림에서 읽은 글자라 O/0·I/1이 틀릴 수 있습니다. '
                           + ('아래 전/후 사진으로 확인하세요.' if caps else '원본 파일로 확인하세요.') + '</span></div>')

        def cap_of(i):
            k = _cap_key_of(caps, i)
            return caps.get(k) if k is not None else None
        notice_items, regular, commons, row_items, omitted = split_display_items(items, cap_of, ITEM_MAX)
        # 이 파일에 'Rev 안 올림'이 이미 열려 있으면 첫 편집 참고 줄('7일 안에 Rev가 오르지 않으면…')은 내지 않는다 (감시 화면과 같은 판정)
        _cid_re = re.compile(rf"변경 #{cid}(?!\d)")
        rev_open = any(str(x.get("code")) == "CONTENT_CHANGED_REV_SAME"
                       and (x.get("path") == c["path"] or any(_cid_re.search(str(e)) for e in (x.get("evidence") or ())))
                       for x in all_open)
        for i in notice_items:
            if rev_open and _RE_FIRST_EDIT.match(" ".join(str(i.new or "").split())):
                continue
            txt = W._screen_words(W._plain_engine_error(i.new or ""))
            if "수행 못 함" in str(i.new or ""):
                warn_notes += W._ds_notice_html(i.key, txt, "warn")
            elif i.where == "파일 수준 감시":
                warn_notes += W._ds_notice_html(i.key, txt, "info")
            else:
                info_notes += W._ds_notice_html(i.key, txt, "info")
        file_ev = (_file_evidence(c, facts, mt_new, mt_old)
                   if any("수행 못 함" in str(i.new or "") or i.where == "파일 수준 감시" for i in notice_items) else "")
        foot = []
        if commons and (regular or row_items):
            foot.append(f'<details class="ds-chg-fold"><summary>모든 쪽 공통 변경 {len(commons)}건 '
                        f'<span class="ds-m">표제란·양식</span></summary>{chg_item_table(commons)}</details>')
        if omitted:
            foot.append(f'<span class="ds-m">외 {omitted}건은 생략했습니다. 변경이 아주 많은 문서입니다.</span>')
        if hidden:
            # 감시 PC에서 [잘못 잡힘 숨기기]로 숨긴 항목 — 기록의 일부라 접어서 보인다. 되살리기는 감시 PC에서
            his = "".join(
                f'<li><span><b>{W._E(it.key)}</b>{W._pv(W._E(it.old or "") or "없음", W._E(it.new or "") or "없음")}'
                f'<span class="ds-m">{W._E((dismissed.get(str(ix)) or {}).get("by", "-"))} 숨김, '
                f'{W._E(W._local(str((dismissed.get(str(ix)) or {}).get("at") or "")))}</span></span></li>'
                for ix, it in hidden)
            foot.append(f'<details class="ds-chg-fold" id="hidden-items"><summary>잘못 잡힘으로 숨긴 항목 {len(hidden)}건'
                        f' <span class="ds-m">되살리기는 감시 PC에서</span></summary><ul class="ds-list">{his}</ul></details>')
        foot_html = f'<div class="ds-card-f">{"".join(foot)}</div>' if foot else ""
        reg_items = regular or ([] if row_items else commons)
        regular_html = rows_html = ""
        if reg_items:
            regular_html = (f'<section class="ds-card" id="changes" aria-labelledby="rec-items-h"><div class="ds-card-h">'
                            f'<h2 id="rec-items-h">바뀐 내용</h2><span class="ds-s">{len(reg_items)}곳</span></div>'
                            f'{chg_item_table(reg_items)}' + ("" if row_items else foot_html) + '</section>')
        if row_items:
            from watcher.brief import bom_impact, impact_label, table_label
            _a, _r, _c, _d = bom_impact(row_items)
            _imp = " · ".join(x for x in ((f"신규 {_a}행" if _a else ""), (f"삭제 {_r}행" if _r else ""),
                                          (f"값 변경 {_c}건" if _c else "")) if x)
            rows_html = (f'<section class="ds-card" id="rows" aria-labelledby="rec-rows-h"><div class="ds-card-h">'
                         f'<h2 id="rec-rows-h">{"바뀐 내용" if not reg_items else W._E(table_label(c["path"])) + " 변경"}</h2>'
                         f'<span class="ds-s">{len(W._row_groups(row_items))}행</span>'
                         + (f'<span class="ds-s">{W._E(impact_label(c["path"]))} <b>{W._E(_imp)}</b></span>' if _imp else "")
                         + f'</div>{chg_row_table(row_items)}{foot_html}</section>')
        # '바뀐 내용'이 표제란 REV·개정이력 행뿐이면 표(BOM) 변경이 진짜 내용이다 — 그것을 먼저 (감시 화면과 같은 차례)
        if regular and all(i.kind == "FIELD_CHANGED" or i.kind.startswith("REVROW_") for i in regular):
            cards = rows_html + regular_html
        else:
            cards = regular_html + rows_html
        if not (reg_items or row_items) and foot_html:
            cards += f'<section class="ds-card" id="changes">{foot_html}</section>'
        cards = (cards + file_ev) if (regular or row_items) else (file_ev + cards)
        if not cards and not (warn_notes or info_notes):
            cards = '<div class="ds-card"><p class="ds-empty">기록된 상세 항목이 없습니다.</p></div>'
        for i in list(regular) + list(commons):
            k = _cap_key_of(caps, i)
            if k is not None and k in keys and len(pic_pairs) < PHOTO_MAX:
                pic_pairs.append((f'{W._E(W._item_key_label(i))}<span class="ds-m">{W._E(W._hw(i.where))}</span>',
                                  caps[k], keys.index(k)))
        _days = _retention_days(cfg, c["detected_at"])
        if not caps and _days:
            _day = W._local(c["detected_at"] or "", "%Y%m%d")
            info_notes = (f'<div class="ds-alert info" role="note"><span>'
                          f'전/후 사진은 보존 기간 {_days}일이 지나 정리됐습니다. '
                          f'그날의 브리핑 원본 <code>brief_{W._E(_day)}_….html</code>에 사진이 남아 있습니다.</span></div>'
                          + info_notes)
        # 세트 PDF의 한 쪽만 바뀌었으면 그 쪽의 도면번호 (감시 화면·메일과 같은 규칙)
        if newx and newx.get("doc_type") == "pdf":
            try:
                from watcher.consistency import set_sheet_label
                from watcher.extract.base import Document
                _pgs = {int(m.group(1)) for i in items if i.kind not in ("CHECK_SKIPPED", "NEW_REVISION_OF")
                        for m in [re.match(r"^(\d+)페이지", str(i.where or "")) or re.match(r"^(\d+)페이지", str(i.key or ""))] if m}
                _sl = set_sheet_label(Document.from_dict(newx), next(iter(_pgs))) if len(_pgs) == 1 else None
                if _sl:
                    dwg = _sl
            except Exception:          # noqa: BLE001 — 도면 번호 한 칸이 상세를 죽이지 않게
                pass

    # 확인 필요 — 이 파일에 열린 것 + 이 변경으로 열린 것. 감시 화면과 같은 제목·줄(종류 | 사실 + 두 줄 근거 + 위치)
    iss_panel = ""
    if open_:
        def _when(i):
            at = str(i.get("detected_at") or "")
            sn = i.get("snapshot_id")
            if this_snap is not None and sn is not None:
                if sn == this_snap:
                    return "이 변경에서 생김"
                if sn > this_snap:
                    return f"이 변경 뒤에 생김 ({W._rc_md_y(at)})"
                return f"{W._rc_md_y(at)}부터 열림"
            return f"{W._rc_md_y(at)} 생김" if at else ""
        mine = any(this_snap is not None and i.get("snapshot_id") == this_snap for i in open_)
        later = this_snap is not None and all((i.get("snapshot_id") or 0) > this_snap for i in open_)
        title = (f"확인 필요 {len(open_)}건" if mine else
                 f"<u>이 변경 뒤</u> 생긴 확인 필요 {len(open_)}건" if later else
                 f"<u>다른 변경</u>으로 열린 확인 필요 {len(open_)}건")
        apart = [] if mine else ["이번 변경과는 따로 생겼습니다."]
        if s_all and summ.startswith("[확인 필요]") and len(s_open) < len(s_all):
            apart.append(f"이 변경으로 생긴 확인 필요 {len(s_all)}건 중 {len(s_all) - len(s_open)}건은 처리됐습니다.")
        # 경고 표시는 글자 ⚠ — 감시 화면의 svg 아이콘은 이 서버 화면에 싣지 않는다(사내망 화면은 svg·img 태그를 쓰지 않는다: 검토 X t4)
        from watcher.docbox import issue_tone as _itone0
        _amber = _itone0(i["code"] for i in open_) == "amber"        # 감시 화면·문서 이력 상자와 같은 색 규칙 (검토 Y1 L3)
        iss_panel = (f'<div class="ds-issue{" ds-db-ok" if _amber else ""}" id="iss-open"><h3><span class="ds-chg-warn" aria-hidden="true">⚠</span><span>{title}</span>'
                     '<a href="/changes/issues">확인 필요 목록 →</a></h3>'
                     + (f'<p class="ds-chg-isub">{W._E(" ".join(apart))}</p>' if apart else "")
                     + "".join(
                         f'<div class="ds-ln"><span class="ds-k" title="{W._E(CODE_LABEL.get(i["code"], i["code"]))}">'
                         f'{W._E(W._DS_ISS_SHORT.get(i["code"]) or CODE_LABEL.get(i["code"], i["code"]))}'
                         + (f'<div class="ds-sm">{W._E(_when(i))}</div>' if _when(i) else "")
                         + f'</span><span>{W._ds_iss_line(i, c["path"])}</span></div>'
                         for i in open_[:5])
                     + (f'<div class="ds-ln"><span class="ds-k"></span><span><a href="/changes/issues">'
                        f'외 {len(open_) - 5}건 →</a></span></div>' if len(open_) > 5 else "")
                     # 사내망만의 한 줄 — 확인 필요마다 하나 보기(의견·처리·담당) 링크와 감시 PC에서만 하는 것 (2026-11-23 사내망 협업)
                     + _collab.issue_box_note(h, open_[:5]) + '</div>')
    elif s_all and summ.startswith("[확인 필요]"):
        iss_panel = (f'<div class="ds-alert ok" id="iss-open" role="note"><span>'
                     f'이 변경으로 생긴 확인 필요 {len(s_all)}건은 모두 처리됐습니다.</span></div>')
    # 발주 후 변경·출도 후 변경 — 머리 바로 아래 노란 안내 한 줄 (판정은 다시 하지 않는다: 검사가 남긴 표지·열린 확인 필요 그대로)
    al = []
    po = next((str(d.get("new") or "") for d in ((detail or {}).get("items") or [])
               if isinstance(d, dict) and d.get("kind") == "CHECK_SKIPPED" and d.get("key") == PO_MARK_KEY), None)
    if po is not None:
        al.append(f'<div class="ds-alert warn pw-al-po" role="note"><b>발주 후 변경</b>'
                  f'<span>발주서에 있는 태그·품번의 값이 발주 뒤에 바뀌었습니다. '
                  f'<span class="ds-m">{W._E(po.split(" — ", 1)[0][:80])}</span></span></div>')
    for pi in [i for i in open_ if i["code"] == "POST_ISSUE_CHANGE" and this_snap is not None
               and i.get("snapshot_id") == this_snap][:2]:
        al.append(f'<div class="ds-alert warn pw-al-post" role="note"><b>출도 후 변경</b>'
                  f'<span>{W._iss_fact_html(pi, limit=160)} <a href="#iss-open">확인 필요 ↓</a></span></div>')
    ref_box = ""
    if add_note:
        rt = W._E(add_note[0])
        if add_ref:
            rt = f'<a href="/changes/{add_ref}">#{add_ref}</a>'.join(rt.split(f'#{add_ref}', 1))
        ref_box = f'<div class="ds-alert info pw-ref" role="note"><b>참고</b><span>{rt}</span></div>'
    nls = "".join(
        f'<li><span><span class="ds-tg gray">사람 기록</span> '
        f'<b>{W._E(n.get("where") or "위치 미지정")}:</b> {W._E(n.get("text", ""))} '
        f'<span class="ds-m">{W._E(n.get("by", "-"))}, {W._E(W._ds_when_iso(n.get("at")) or W._local(str(n.get("at") or "")))}</span></span></li>'
        for n in user_notes)
    notes_sec = (f'<section class="ds-card" id="notes"><div class="ds-card-h"><h2>놓친 변경 기록</h2>'
                 f'<span class="ds-s">{len(user_notes)}건</span></div>'
                 f'<div class="ds-card-b"><ul class="ds-list">{nls}</ul></div></section>' if nls else "")
    pics_card = ""
    if pic_pairs:
        ptitle, psub = W._ds_pics_title(cat, [cp for _n, cp, _k in pic_pairs])     # 감시 화면과 같은 제목 (검토 Y1 L1)
        pics_card = (f'<section class="ds-card ds-chg-pics" id="pics" aria-labelledby="rec-pics-h"><div class="ds-card-h">'
                     f'<h2 id="rec-pics-h">{ptitle}</h2><span class="ds-s">{W._E(psub)}</span></div>'
                     + chg_pics_html(cid, pic_pairs, when_old, when_new) + '</section>')
    left = iss_panel + warn_notes + cards + info_notes + pics_card + notes_sec + cm_card

    # ── 머리 — 경로 줄(프로젝트 › 프로젝트 › 파일 이름(문서 이력)) · 파일 이름 + 표시 · 프로젝트 · 경로 ──
    fname = (f'<a href="{E(_doc_href(c["path"]))}" title="{W._E(c["path"])}">{W._E(name)}</a>' if doc_ok else W._E(name))
    crumb = (f'<div class="crumb ds-crumb"><a href="/changes">프로젝트</a><span class="ds-sep">›</span>'
             f'<a href="{E(_box_href(proj))}">{W._E(plabel)}</a><span class="ds-sep">›</span>{fname}</div>')
    tags = [f'<span class="ds-tg gray">{W._E(cat)}</span>']
    if is_base:
        tags.append('<span class="ds-tg gray">첫 등록</span>')
    elif moved_from:
        tags.append(f'<span class="ds-tg gray" title="이전: {W._E(moved_from)}">이동</span>')
    elif c["kind"] in ("added", "removed"):
        # 지웠다 같은 자리에 되살린 파일은 '되살림' — 감시 화면 머리와 같은 말 (Y1 P3b · rv0676 WE2), 저장값 '추가'는 그대로
        from watcher.summary import kind_label as _kl
        _klab = _kl(c["kind"], (detail or {}).get("items") or [])
        if c["kind"] == "added" and add_note and add_note[1]:
            _klab = "되살림"
        tags.append(f'<span class="ds-tg gray">{W._E(_klab)}</span>')
    if open_:
        from watcher.docbox import issue_tone as _itone
        tags.append(f'<span class="ds-tg {_itone(i["code"] for i in open_) or "red"}">확인 필요 {len(open_)}건</span>')
    if acks:
        tags.append('<span class="ds-tg green">확인함</span>')
    title_html = f'{W._E(name)}<span class="ds-rec-h1tags">{"".join(tags)}</span>'
    sub = (f'{W._E(plabel)} · <span title="{W._E(c["path"])}">{W._E(c["path"])}</span>'
           + (f'<span class="ds-chg-sub2">옮기기 전: {W._E(moved_from)}</span>' if moved_from else ""))

    # ── 오른쪽 — 확인 카드(사내망 계정 이름으로) · 파일 정보 · 이 파일의 변경 기록 ──
    s = h.sess
    who = lan_ack_by(s.display_name, s.login)
    if acks:
        hist = "".join(f'<li><span><span class="ds-tg green">확인</span> {E(ack_label(a["ack_by"]))}'
                       + (f' <span class="ack-note">“{E(a["ack_note"])}”</span>' if a["ack_note"] else "")
                       + f'</span><span class="ds-m">{E(W._ds_when_iso(a["ack_at"]) or _local(a["ack_at"], "%m-%d %H:%M"))}</span></li>' for a in acks)
        state = f'<ul class="ds-list ds-rec-acks">{hist}</ul>'
    elif ack_why:
        state = ""
    else:
        state = '<div class="ds-state"><span class="ds-dot off"></span>아직 아무도 확인하지 않았습니다</div>'
    if ack_why:          # 감시 화면·메일이 확인을 받지 않는 변경 — 폼을 두면 누른 뒤 거절된다 (ux24 AK2)
        ack_card = (f'<section class="ds-side-c" aria-labelledby="rec-ack-h"><h3 id="rec-ack-h">확인</h3>{state}'
                    f'<p class="ds-sm">확인 대상이 아닌 변경입니다. {E(ACK_EXEMPT_TEXT[ack_why])}.</p></section>')
    else:
        # 공용 PC — 로그아웃하지 않으면 다음 사람의 확인이 앞 사람 이름으로 남았다 (ux20 mail 6). 세션 시간은 그대로 두고 알린다
        ack_card = (f'<section class="ds-side-c" aria-labelledby="rec-ack-h"><h3 id="rec-ack-h">확인</h3>{state}'
                    f'<form method="post" action="/changes/ack">{S._hidden(h)}'
                    f'<input type="hidden" name="id" value="{cid}">'
                    f'<span class="ds-lbl">이름</span><div class="ds-rec-who">{E(who)}</div>'
                    f'<label class="ds-lbl" for="ack-note">메모 (안 써도 됨)</label>'
                    f'<input class="ds-inp memo" type="text" id="ack-note" name="note" maxlength="{NOTE_MAX}" '
                    f'placeholder="예: BOM 고치라고 전달함">'
                    f'<div class="ds-btns"><button class="ds-btn p" type="submit">{"확인 추가" if acks else "확인함"}</button></div></form>'
                    f'<p class="ds-sm">확인은 지울 수 없습니다. 잘못 눌렀으면 \'정정\' 메모로 새 확인을 남기세요.</p>'
                    f'<div class="ds-rec-shared" role="note"><b>여러 사람이 함께 쓰는 PC라면</b> 다 본 뒤 [로그아웃]을 누르세요. '
                    f'<form method="post" action="/logout">{S._hidden(h)}'
                    f'<button class="ds-btn sm" type="submit">로그아웃</button></form></div></section>')
    # 파일 정보 — 감시 화면과 같은 칸·차례: 저장 · 이전 판 · 저장한 사람(사람 이름일 때) · 도면 번호(파일 이름과 다를 때) · Rev · 발견 ·
    # 프로젝트(+ 정한 근거) · 기록 번호. 기록 요약 한 줄은 감시 화면처럼 싣지 않는다 — 같은 사실을 '바뀐 내용' 표가 말한다
    kv = []
    if when_new:
        kv.append(("저장", W._E(when_new)))
        if when_old:
            kv.append(("이전 판", W._E(when_old)))
        _who = (newx or {}).get("saved_by")
        if _who and str(_who).strip().lower() not in W._DS_PROGRAM_SAVERS:
            kv.append(("저장한 사람", f'<span title="CAD·오피스가 파일 속에 적어 둔 마지막 저장자입니다. PC 계정 이름일 수 있습니다">'
                                     f'{W._E(_who)}</span>'))
    elif when_old:
        kv.append(("이전 판", W._E(when_old)))
    if dwg and dwg != pp.stem:
        kv.append(("도면 번호", W._E(dwg)))
    if cur_rev:
        kv.append(("Rev", W._E(cur_rev)))
    if row:
        kv.append(("발견", W._E(W._ds_when_iso(c["detected_at"])) + " 검사"))
    pj = W._E(proj)
    if attr and attr.get("how"):
        pre = f"프로젝트 {W._E(str(attr.get('project') or '미분류'))}: "
        t = _attr_html(attr)
        pj = f'{W._E(proj)} <span class="ds-m">{t[len(pre):] if t.startswith(pre) else t}</span>'
    kv.append(("프로젝트", f'<span class="rc-attr">{pj}</span>'))
    if asg:
        from watcher import opinions as _OP
        kv.append(("담당", W._E(_OP.assignee_text(asg))))             # 감시 화면 파일 정보와 같은 칸·같은 글
    kv.append(("기록 번호", f"#{cid}"))
    info = ('<section class="ds-side-c" id="file-info" aria-labelledby="rec-info-h"><h3 id="rec-info-h">파일 정보</h3><dl class="ds-dl">'
            + "".join(f"<dt>{k}</dt><dd>{v}</dd>" for k, v in kv) + '</dl></section>')
    hist_c = chg_hist_card(rows, cid, c["path"], sums)
    # 확인 칸은 글 순서로 본문보다 앞 — 넓은 화면은 오른쪽 위(격자 자리), 좁은 화면(한 칸)은 머리 바로 아래 (감시 화면과 같은 틀)
    body = (f'{crumb}<div class="ds-chg">{"".join(al)}{ref_box}'
            f'<div class="ds-split ds-chg-split ds-rec-split"><section class="ds-chg-ack ds-rec-side" aria-label="확인">{ack_card}</section>'
            f'<div class="ds-chg-main ds-rec-main">{left}</div>'
            f'<aside class="ds-chg-side ds-rec-side" aria-label="파일 정보">{info}{side_extra}{hist_c}</aside></div></div>')
    h._send(200, h._shell(f"{name} — 변경 #{cid}", body, active="/changes", title_html=title_html, sub=sub))


# ── /changes/img — 전/후 사진 (state.db captures) ─────────────────────────────────

@_guarded
def get_change_img(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    q = h._query()
    try:
        cid = S.FormsHandler._int(S.FormsHandler._one(q, "id"))
        k = S.FormsHandler._int(S.FormsHandler._one(q, "k"))
    except S.HttpError:
        raise S.HttpError(404)
    side = S.FormsHandler._one(q, "s")
    if side not in ("before", "after"):
        raise S.HttpError(404)
    with w.session() as st:
        c = _row_of(st, cid)
        if c is None or not _in(scope, c["project"]):
            raise S.HttpError(404)
        detail = st.change_detail(cid) or {}
    caps = detail.get("captures") or {}
    keys = _cap_keys(caps)
    if k >= len(keys):
        raise S.HttpError(404)
    got = dict(_sides(caps[keys[k]])).get(side)
    if not got:
        raise S.HttpError(404)
    mime = str(got.get("mime") or "").lower()
    if mime not in _IMG_SIG:                      # PNG·JPEG만 — SVG·HTML 같은 것은 내지 않는다
        raise S.HttpError(404)
    b64 = str(got.get("b64") or "")
    if len(b64) > IMG_MAX * 4 // 3 + 4:
        raise S.HttpError(404)
    try:
        data = base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        raise S.HttpError(404)
    if not data.startswith(_IMG_SIG[mime]):      # 머리 글자(시그니처)가 형식과 맞을 때만
        raise S.HttpError(404)
    h._deadline(len(data))
    h._send(200, data, mime, extra=(("Content-Disposition", "inline"),))


# ── /changes/issues — 열린 검토 필요 (읽기만) ─────────────────────────────────────

@_guarded
def get_change_issues(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    q = h._query()
    p = S.FormsHandler._one(q, "p").strip()
    if p and not _in(scope, p):
        p = ""                                   # 범위 밖 이름은 없는 것처럼 (위에 한 줄, 검토 Y3 L1)
        _note_out_of_scope(h, scope)
    path = S.FormsHandler._one(q, "f").strip()
    from watcher.brief import no_bidi
    with w.session() as st:
        # 머리만 다 읽어 범위부터 거르고, 본문은 보일 줄만 — 앞 2,000건을 먼저 자르면 범위 밖 새 건이 많을 때 내 것이 통째로 빠지고
        # 개수 칸(모두 셈)과 어긋났다 (독립 검토 2026-11-24 M2)
        heads = [r for r in st.conn.execute(
            "SELECT id, code, IFNULL(project, '미분류') FROM issues WHERE resolved_at IS NULL"
            + (" AND path = ?" if path else "") + " ORDER BY id DESC", [path] if path else []).fetchall() if _in(scope, r[2])]
        counts = Counter(r[2] for r in heads)
        scoped = [r for r in heads if not p or r[2] == p]
        code = S.FormsHandler._one(q, "code").strip()
        if not any(r[1] == code for r in scoped):
            code = ""                                  # 없는 종류면 거르지 않는다(감시 화면과 같게)
        want = [int(r[0]) for r in scoped if not code or r[1] == code]
        try:
            show = int(S.FormsHandler._one(q, "show") or 0)
        except ValueError:
            show = 0
        pick = want[:ISSUE_ROWS]
        if show in want and show not in pick:
            pick = [show] + pick[:ISSUE_ROWS - 1]       # 링크가 가리킨 건이 앞 N건 밖이면 맨 앞에(감시 화면과 같게)
        n_cut = len(want) - len(pick)
        got = {int(r[0]): r for r in st.conn.execute(
            "SELECT id, code, path, IFNULL(project, '미분류'), message, evidence, detected_at FROM issues WHERE id IN ("
            + ",".join("?" * len(pick)) + ")", pick)} if pick else {}
        rows = [got[i] for i in pick if i in got]
        split = _issue_split(st, rows, scope, h=h, show=show)
        cards = "" if path else _issue_cards(st, scope, p, code=code, on=True)
    n = len(scoped)
    title_html = f'확인 필요 <span class="ds-cnt">{n}건</span>'
    from watcher.forms import collab as _collab
    sub = E(_collab.issues_sub(h))                 # 누가 무엇을 어디서 — 처리 권한에 따라 (2026-11-23 사내망 협업)
    lead = ""
    if path:
        lead = (f'<div class="ds-alert info">파일 <b>{E(no_bidi(path))}</b>의 확인 필요만 보는 중입니다.'
                f'<a class="ds-btn sm" href="/changes/issues">전체 보기</a></div>')
    tools = (f'<div class="ds-tools">{_seg(list(counts), p, dict(counts), "/changes/issues")}</div>'
             if counts and not path else "")
    table = split or '<section class="ds-card"><div class="ds-empty">열린 확인 필요가 없습니다</div></section>'
    if n_cut:                                          # 머리·개수 칸은 다 세고 목록은 앞 N건 (M1)
        table += (f'<p class="ds-sm">최신 {len(rows):,}건만 보입니다. 외 {n_cut:,}건은 싣지 않았습니다. 프로젝트·종류로 좁혀 보세요.</p>')
    # 경로 줄 — 프로젝트로 거른 확인 필요는 '프로젝트 › 그 프로젝트(문서함) › 확인 필요' (문서함의 '확인 필요 N건 보기 →'에서 온다)
    crumb = (f'<div class="crumb ds-crumb"><a href="/changes">프로젝트</a><span class="ds-sep">›</span>'
             f'<a href="{E(_box_href(p))}">{E(p)}</a><span class="ds-sep">›</span>확인 필요</div>') if p and not path else ""
    body = f'{crumb}<div class="rec ds-rec">{lead}{cards}{tools}{table}</div>'
    h._send(200, h._shell("확인 필요", body, active="/changes/issues", title_html=title_html, sub=sub))


# ── [확인함 + 메모] — state.db acks 한 줄 ─────────────────────────────────────────

def post_change_ack(h) -> None:
    S = _S()
    f = h._read_form()
    h._check_token(f)
    scope = _scope(h)
    w = _watch(h)
    try:
        cid = S.FormsHandler._int(S.FormsHandler._one(f, "id"))
    except S.HttpError:
        raise S.HttpError(404)
    note = clean_ack_text(S.FormsHandler._one(f, "note"))     # 제어 문자 지운 뒤 접기 — 감시 PC 입구와 같은 정리 (rr066 lan 1)
    if len(note) > NOTE_MAX:
        raise S.HttpError(400, f"메모는 {NOTE_MAX}자까지입니다")
    s = h.sess
    by = lan_ack_by(s.display_name, s.login)
    try:
        with w.session() as st:
            c = _row_of(st, cid)
            if c is None or not _in(scope, c["project"]):
                raise S.HttpError(404)
            why = st.ack_exempt(cid)             # 첫 등록·이동·재저장·복사본은 받지 않는다 (ux24 AK2)
            ok = not why and st.add_ack(cid, by, note)       # INSERT 한 줄 + commit — 짧은 트랜잭션
    except WatchBusy:
        h._flash("bad", BUSY_TEXT + " (확인은 아직 남지 않았습니다)")
        h._redirect(f"/changes/{cid}")
        return
    except WatchUnavailable as e:
        _unavailable(h, str(e))
        return
    if why:
        h._flash("bad", f"{ACK_EXEMPT_TEXT[why]} — 확인을 남기지 않았습니다")
        h._redirect(f"/changes/{cid}")
        return
    if not ok:
        raise S.HttpError(404)
    try:
        h.server.store.record_audit(s.user_id, "change_ack", f"change:{cid}", ip=h.ip,
                                    detail=f"{c['project']} · {PurePosixPath(c['path']).name}" + (f" — {note}" if note else ""))
    except Exception:
        pass
    # 공용 PC 로그아웃 안내는 이 화면의 '확인' 구역에 이미 있다 — 알림 줄에서는 되풀이하지 않는다 (v2 글)
    h._flash("ok", f"#{cid} 확인을 남겼습니다. 감시 PC에는 '사내망에서 확인: {s.display_name}'로 보입니다.")
    h._redirect(f"/changes/{cid}")


# ── 설계 변경 대장 엑셀 (자기 범위) ───────────────────────────────────────────────

@_guarded
def get_changes_xlsx(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    f = _filters(h, scope)
    from watcher.change_ledger import ledger_rows, ledger_xlsx, scope_text
    projs = _scope_set(scope, f["p"])
    with w.session() as st:
        rows = ledger_rows(st, projects=projs, date_from=f["from"], date_to=f["to"], photo_note="사내망 화면에서")
        # 범위 밖 옛 경로 가리기 (검토 X L1) — 그 변경의 '참고' 글이 가리키는 범위 밖 경로를 칸 글에서
        hider = _Hider(st, scope)
        ids = [r[0] for r in rows if r and isinstance(r[0], int)]
        notes = _notes_of(st, ids) if (ids and scope is not None) else {}
        for r in rows:
            if r and isinstance(r[0], int) and notes.get(r[0]):
                bad = hider.out_of_note(notes[r[0]])
                if bad:
                    rp = st.conn.execute("SELECT path FROM changes WHERE id = ?", (r[0],)).fetchone()
                    r[:] = [hide_text(x, bad, rp[0] if rp else "") if isinstance(x, str) else x for x in r]
    S = _S()
    # 범위 밖 ?p=는 내 범위 전체로 — 제목 줄에 그렇다고 (검토 Y3 L1; p의 글자는 싣지 않는다)
    asked_out = bool(S.FormsHandler._one(h._query(), "p").strip()) and not f["p"]
    data = ledger_xlsx(rows, scope_text=scope_text(projs, f["from"], f["to"])
                       + (" (요청한 프로젝트는 열람 범위 밖이라 뺐습니다)" if asked_out else ""))
    name = f"설계변경대장_{date.today():%Y%m%d}" + (f"_{f['p']}" if f["p"] else "") + ".xlsx"
    try:
        h.server.store.record_audit(h.sess.user_id, "changes_export", "changes", ip=h.ip,
                                    detail=f"{name} — 변경 {sum(1 for r in rows if isinstance(r[0], int))}건 · "
                                           f"범위 {scope_text(projs, f['from'], f['to'])}"[:500])
    except Exception:
        pass
    h._deadline(len(data))
    h._send(200, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            extra=(("Content-Disposition", S.content_disposition(name, "design-change-ledger.xlsx")),))
    h.close_connection = True


# ── 관리자: 계정의 변경 브리핑 열람 ─────────────────────────────────────────────

def access_cell(h, u: dict) -> str:
    """계정 목록의 '변경 열람' 칸."""
    if u.get("role") == "admin":
        return '<span class="muted">관리자 — 전체</span>'
    acc = access_of(h.server.store, u["id"])
    tag = (f'<span class="tag approved">{E(access_text(acc))}</span>' if acc is not None else '<span class="tag off">끔</span>')
    from watcher.forms.collab import resolve_flag
    if acc is not None and resolve_flag(h.server.store, u["id"]):        # 확인 필요 처리 (2026-11-23 사내망 협업)
        tag += ' <span class="tag approved" title="[처리함]·담당 지정">처리</span>'
    return f'{tag} <a href="/admin/users/changes?id={int(u["id"])}">바꾸기</a>'


@_guarded
def get_admin_access(h) -> None:
    S = _S()
    S._require_admin(h)
    w = _watch(h)
    uid = S.FormsHandler._int(S.FormsHandler._one(h._query(), "id"))
    store = h.server.store
    u = store.get_user(uid)
    if not u:
        raise S.HttpError(404)
    name = f'{u.get("display_name") or ""} ({u.get("login")})'
    if u.get("role") == "admin":
        body = (f'<div class="panel"><p>{E(name)}: 관리자는 늘 모든 프로젝트의 변경을 봅니다.</p>'
                f'<p><a class="btn gray" href="/admin/users">계정 목록으로</a></p></div>')
        h._send(200, h._shell("변경 브리핑 열람", body, active="/admin/users"))
        return
    acc = access_of(store, uid)
    try:
        with w.session() as st:
            projs = _projects(st, None)
        why = ""
    except (WatchUnavailable, WatchBusy) as e:
        projs, why = [], str(e)
    if isinstance(acc, frozenset):
        projs = sorted(set(projs) | set(acc))
    every, sug = suggested(w.recipients(), u.get("email") or "", projs)
    sug = [p for p in sug if p in projs] if projs else sug
    pre_all = acc == "all" or (acc is None and every)
    pre = set(acc) if isinstance(acc, frozenset) else (set(sug) if acc is None else set())
    note = ""
    if acc is None and (every or sug):
        note = ('<div class="note info">이 계정 메일(' + E(u.get("email") or "") + ')이 브리핑을 '
                + ("모든 프로젝트로" if every else f'프로젝트 {E(", ".join(sug))}로') + ' 받고 있어 그 범위를 미리 골라 두었습니다. '
                '<b>[저장]을 눌러야 적용됩니다.</b></div>')
    if why:
        note += f'<div class="note warn"><b>감시 기록을 열 수 없어 프로젝트 목록이 없습니다.</b> {E(why)}</div>'
    boxes = "".join(f'<label class="chk"><input type="checkbox" name="p" value="{E(p)}"{" checked" if p in pre else ""}>'
                    f'{E(p)}</label>' for p in projs) or '<p class="muted">아직 감시 기록에 프로젝트가 없습니다.</p>'
    # 확인 필요 처리 (2026-11-23 사내망 협업) — 열람 범위 안의 확인 필요를 [처리함]하고 변경·확인 필요에 담당을 정한다. 기본 끔
    from watcher.forms.collab import resolve_flag
    res_on = acc is not None and resolve_flag(store, uid)
    res_box = (f'<h3>확인 필요 처리</h3><label class="chk"><input type="checkbox" name="resolve" value="1"'
               f'{" checked" if res_on else ""}>[처리함]·담당 지정 허락</label>'
               '<p class="muted">켜면 열람 범위 안의 확인 필요를 사내망에서 [처리함]으로 닫습니다. '
               '감시 PC의 [처리함]과 같은 기록입니다.</p><p class="muted">변경·확인 필요에 담당도 정합니다. '
               '숨기기·설정·검사는 감시 PC에서만 합니다.</p>')
    body = (f'<div class="panel"><h2>{E(name)}</h2>{note}'
            f'<dl class="ui-kv"><div><dt>지금</dt><dd><b>{E(access_text(acc))}</b>'
            + (' · 확인 필요 처리' if res_on else "") + '</dd></div></dl>'
            f'<p class="muted">켜면 이 계정이 [프로젝트]·[최근 변경]에서 문서 이력·변경과 사진을 보고 [확인함]을 남깁니다.</p>'
            f'<form method="post" action="/admin/users/changes">{S._hidden(h)}<input type="hidden" name="id" value="{uid}">'
            f'<label class="chk"><input type="checkbox" name="on" value="1"{" checked" if (acc is not None or every or sug) else ""}>'
            f'변경 브리핑 열람 켜기</label>'
            f'<h3>범위</h3><label class="chk"><input type="radio" name="scope" value="all"{" checked" if pre_all else ""}>'
            f'모든 프로젝트</label><label class="chk"><input type="radio" name="scope" value="pick"'
            f'{"" if pre_all else " checked"}>고른 프로젝트만</label>'
            f'<div class="cols">{boxes}</div>{res_box}'
            f'<div class="form-actions"><button class="btn" type="submit">저장</button>'
            f'<a class="btn gray" href="/admin/users">계정 목록으로</a></div></form></div>')
    h._send(200, h._shell("변경 브리핑 열람", body, active="/admin/users"))


def post_admin_access(h) -> None:
    S = _S()
    S._require_admin(h)
    _watch(h)
    f = h._read_form()
    h._check_token(f)
    uid = S.FormsHandler._int(S.FormsHandler._one(f, "id"))
    on = S.FormsHandler._one(f, "on") == "1"
    all_ = S.FormsHandler._one(f, "scope") == "all"
    msg = set_access(h.server.store, h.sess.user_id, uid, on=on, all_=all_, projects=f.get("p") or [], ip=h.ip)
    # 확인 필요 처리 — 열람이 꺼지면 같이 끈다(범위 없는 처리 권한은 뜻이 없다) (2026-11-23 사내망 협업)
    from watcher.forms.collab import set_resolve
    res = set_resolve(h.server.store, h.sess.user_id, uid, ip=h.ip,
                      on=S.FormsHandler._one(f, "resolve") == "1" and access_of(h.server.store, uid) is not None)
    h._flash("ok", msg + (f" · {res}" if res else ""))
    h._redirect("/admin/users")


ROUTES_GET = {
    "/changes": get_changes, "/changes/item": get_change_item, "/changes/img": get_change_img,
    "/changes/issues": get_change_issues, "/changes.xlsx": get_changes_xlsx, "/admin/users/changes": get_admin_access,
    # 화면 3판 큰 그림 (2026-11-20): 최근 변경(옛 첫 화면) · 프로젝트 문서함 · 문서 이력. 모두 로그인 필요(server가 (fn, False)로 잇는다),
    # 기록 열람만 서버에서도 열리고(_RECORDS_OK), 로그인 뒤 돌아갈 곳(next)으로도 받는다(_safe_next — '/changes/'로 시작하는 GET 경로)
    "/changes/recent": get_changes_recent, "/changes/project": get_change_project, "/changes/doc": get_change_doc,
}
ROUTES_POST = {"/changes/ack": post_change_ack, "/admin/users/changes": post_admin_access}
CHANGE_PATH = re.compile(r"/changes/(\d{1,12})")

# 기록 화면 모양 (2026-11-17 R3) — server.CSS 끝에 붙는다. 글자색·회색·강조 하나(주황 = 확인 필요), 상자·테두리 단추·그림자 없음.
# 최대 폭 960px 가운데, 좁으면(640px 아래) 프로젝트·시각이 위 줄, 요약이 아래 줄 — 가로 넘침 없이
REC_CSS = """
.main:has(.rec)>*{max-width:960px;margin-left:auto;margin-right:auto}
.rec{line-height:1.5}
.rec-sub{color:var(--muted2);font-size:14.5px;margin:-8px 0 12px}
.rec-warn{border-left:3px solid var(--warn);padding:2px 10px;margin:0 0 14px;font-size:14.5px;color:var(--text2)}
.rec-acts{font-size:14.5px;color:var(--muted2)}
.rec-filter{font-size:14.5px;color:var(--muted2);margin:0 0 20px;line-height:1.9;overflow-wrap:anywhere}
.rec-filter a{color:var(--text3)}
.rec-filter b{color:var(--text)}
.rec-sec{margin:0 0 20px}
.rec-sec h2{font-size:17px;font-weight:700;margin:0 0 6px;color:var(--text)}
.rec-sec h2 .n{color:var(--muted2);font-weight:400;margin-left:8px;font-size:16px}
.rec-sec h2.rec-day{font-size:16px;color:var(--text2);margin:6px 0 4px}
ul.rec-list{list-style:none;padding:0;margin:0;border-top:1px solid var(--line)}
.rec-list>li{border-bottom:1px solid var(--line)}
a.rec-row{display:grid;grid-template-columns:3.4em 7.5em minmax(0,1fr) auto;gap:2px 14px;align-items:baseline;
  padding:9px 6px;color:var(--text);text-decoration:none;font-size:16px}
a.rec-row:hover{background:var(--hover);text-decoration:none}
a.rec-row:focus-visible{outline:2px solid var(--accent2);outline-offset:-2px}
.rec-t{color:var(--muted2);font-size:14.5px;font-variant-numeric:tabular-nums}
.rec-p{color:var(--text3);font-size:14.5px;overflow-wrap:anywhere;min-width:0}
.rec-s{overflow-wrap:anywhere;min-width:0}
.rec-f{color:var(--muted2);font-size:13.5px;margin-left:8px}
li.rec-f{display:block;padding:8px 6px;margin:0}
.rec-a,.rec-m{color:var(--muted2);font-size:13.5px;text-align:right;white-space:nowrap}
.rec-dot{display:inline-block;width:7px;height:7px;border-radius:50%;border:1.5px solid var(--muted2);vertical-align:middle}
.rec-dot.on{background:var(--warn);border-color:var(--warn)}
.rec .rec-todo a.rec-row{grid-template-columns:10px minmax(0,1fr) auto}
.rec-tl a.rec-row{grid-template-columns:3.4em minmax(0,1fr) auto}
.rec-more{display:block;font-size:14.5px;padding:8px 6px}
details.rec-quiet>summary{cursor:pointer;color:var(--muted2);font-size:14.5px;padding:8px 6px}
details.rec-quiet[open]>summary{color:var(--text3)}
.rec-empty{color:var(--muted2);font-size:16px;padding:18px 0}
.rec-search{display:flex;gap:8px;margin:0 0 18px;max-width:520px}
.rec-search input[type=search]{flex:1;min-width:0;width:auto}
.rec-sum{font-size:18px;font-weight:600;margin:4px 0 2px;overflow-wrap:anywhere}
.rec-why{color:var(--muted2);font-size:14.5px;margin:0 0 8px;overflow-wrap:anywhere}
.vh{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
@media (max-width:640px){
  a.rec-row{grid-template-columns:auto minmax(0,1fr) auto;grid-template-areas:"t p a" "s s s"}
  .rec-t{grid-area:t}.rec-p{grid-area:p}.rec-s{grid-area:s}.rec-a{grid-area:a}
  .rec-tl a.rec-row{grid-template-columns:auto minmax(0,1fr);grid-template-areas:"t a" "s s"}
  .rec .rec-todo a.rec-row{grid-template-columns:10px minmax(0,1fr);grid-template-areas:"d s" "d m"}
  .rec-todo .rec-dot{grid-area:d;margin-top:7px}.rec-todo .rec-s{grid-area:s}.rec-todo .rec-m{grid-area:m;text-align:left;white-space:normal}
}
""" + """
/* 화면 모양 v2 (2026-11-18) — 감시 화면 시험판과 같은 말씨: 날짜·확인 필요 구역 = 흰 카드, 수는 작은 알약, 확인 필요는 왼쪽 주황 띠,
   거르기 = 알약 줄, 종류 = 작은 칩(.ui-kind — server.CSS), 줄은 열을 맞춘다(시각 | 프로젝트 | 칩 + 요약 | 상태) */
.rec-sub{font-size:14px;margin:-8px 0 14px}
.rec-acts{font-size:14px;display:flex;flex-wrap:wrap;gap:4px 16px}
.rec-warn{font-size:14px;background:var(--panel);border-radius:0 8px 8px 0;padding:8px 12px}
.rec-filter{display:flex;flex-wrap:wrap;gap:6px;align-items:center;line-height:20px;margin:0 0 4px}
.rec-filter a,.rec-filter b{padding:3px 12px;border-radius:999px;border:1px solid var(--border);background:var(--panel);
  color:var(--text2);font-size:14px;font-weight:400;text-decoration:none}
.rec-filter a:hover{border-color:var(--border2);color:var(--text);text-decoration:none}
.rec-filter b{background:var(--text);border-color:var(--text);color:var(--panel);font-weight:700}
.rec-sec{background:var(--panel);border:1px solid var(--border);border-radius:14px;box-shadow:var(--pv-shadow);
  padding:4px 18px 8px;margin:16px 0 0}
.rec-sec h2,.rec-sec h2.rec-day{font-size:17px;font-weight:700;color:var(--text);margin:0 -18px 2px;padding:13px 18px 11px;
  border-bottom:1px solid var(--line)}
.rec-sec h2 .n{display:inline-block;font-size:14px;font-weight:600;line-height:18px;padding:0 8px;border-radius:999px;
  background:var(--panel2);border:1px solid var(--border);color:var(--text2);margin-left:8px;vertical-align:1px}
.rec-todo{border-left:4px solid var(--rc-hot)}
.rec-todo h2{color:var(--rc-hot)}
.rec-todo h2 .n{background:var(--pv-hot-bg);border-color:var(--pv-hot-bd);color:var(--rc-hot)}
ul.rec-list{border-top:none}
.rec-list>li:last-child{border-bottom:none}
a.rec-row{padding:11px 8px;border-radius:8px;grid-template-columns:3.4em 7em 6.6em minmax(0,1fr) 7em}
.rec-tl a.rec-row{grid-template-columns:3.4em 6.6em minmax(0,1fr) 7em}
.rec .rec-todo a.rec-row{grid-template-columns:6.6em minmax(0,1fr) 7em 4.6em}
.rec-k{min-width:0}
.rec-k .ui-kind{margin:0}
.rec-m{text-align:right}
.rec-p{font-weight:600;color:var(--text2);font-size:14px}
.rec-t,.rec-a,.rec-m,.rec-f{font-size:14px}
.rec-sum{font-size:17px}
.rec-why{font-size:14px}
.rec-more{font-size:14px}
details.rec-quiet>summary{font-size:14px}
.rec-empty{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px 20px;margin-top:16px}
.rec-search{margin:12px 0 0}
@media (max-width:640px){
  .rec-sec{padding:2px 12px 6px;border-radius:12px}
  .rec-sec h2,.rec-sec h2.rec-day{margin:0 -12px 2px;padding:11px 12px 9px}
  a.rec-row{grid-template-columns:auto auto minmax(0,1fr) auto;grid-template-areas:"t p k a" "s s s s";align-items:center}
  .rec-tl a.rec-row{grid-template-columns:auto minmax(0,1fr) auto;grid-template-areas:"t k a" "s s s"}
  .rec .rec-todo a.rec-row{grid-template-columns:auto minmax(0,1fr) auto;grid-template-areas:"k p m" "s s s"}
  .rec-k{grid-area:k}
  .rec-todo .rec-p{grid-area:p}.rec-todo .rec-m{grid-area:m;text-align:right}
}
"""

def _issue_view_css() -> str:
    """확인 필요 개수 칸·목록·상세 모양 — 감시 화면과 같은 것(issue_view.CSS)."""
    from watcher.issue_view import CSS as _css
    return _css


# 화면 3판 (2026-11-20) — 기록 화면 전용 (server.DS_CSS 뒤에 붙는다). 표 칸 폭은 col 클래스로(인라인 style은 CSP가 막는다),
# '그 밖' 줄은 접기 줄을 펼치면(:has) 보이고 :has()가 없는 브라우저에서는 늘 보인다(숨지 않게).
DS_REC_CSS = """
/* ── 화면 3판 — 기록 화면(최근 변경·프로젝트·확인 필요·변경 상세·변경 찾기) ── */
table.ds-t col.w-proj{width:104px} table.ds-t col.w-doc{width:96px} table.ds-t col.w-file{width:200px}
table.ds-t col.w-place{width:170px} table.ds-t col.w-state{width:170px}
table.ds-t col.w-state2{width:130px} table.ds-t col.w-when{width:104px} table.ds-t col.w-go{width:40px}
table.ds-t col.w-tag{width:170px} table.ds-t col.w-target{width:150px} table.ds-t col.w-day{width:104px}
table.ds-t col.w-kind{width:112px} table.ds-t col.w-where{width:190px}
table.ds-rec-find-t td.c-file .ds-sm{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
table.ds-rec-find-t td.c-when{white-space:nowrap}
table.ds-rec-find-t col.w-when{width:120px}
table.ds-t .ds-file a{color:var(--ds-text)}
table.ds-t .ds-file a:hover{color:var(--ds-primary-ink);text-decoration:underline}
table.ds-t td.ds-go a:hover{color:var(--ds-primary-ink);text-decoration:none}
table.ds-t td .ds-sm{overflow-wrap:anywhere}
table.ds-t tr.ds-fold a{color:var(--ds-primary-ink);font-weight:700}
.main table.ds-t>tbody>tr.ds-q{display:none}
.main table.ds-t>tbody:has(details.ds-qd[open])>tr.ds-q{display:table-row}
@supports not selector(:has(*)){.main table.ds-t>tbody>tr.ds-q{display:table-row}}
table.ds-t tr.ds-q td{background:var(--ds-surface2)}
table.ds-t tr.ds-fold details.ds-qd>summary,details.ds-qd>summary{cursor:pointer;list-style:none;color:var(--ds-muted);
  font-size:14.5px;font-weight:500}
table.ds-t tr.ds-addg details.ds-qd>summary{color:var(--ds-text);font-size:15.5px;font-weight:700}
details.ds-qd>summary::-webkit-details-marker{display:none}
details.ds-qd>summary b{color:var(--ds-primary-ink);font-weight:700;margin-left:6px}
details.ds-qd>summary b::after{content:" ▾"}
details.ds-qd[open]>summary b::after{content:" ▴"}
.ds-card-h h2 .tag{margin-left:6px;vertical-align:2px}
nav.ds-pcards{margin-bottom:24px}
.ds-rec-h1tags{display:inline-flex;flex-wrap:wrap;gap:6px;margin-left:12px;vertical-align:5px}
.ds-rec-h1tags .ds-tg{font-size:13.5px}
.ds-issue .ds-ln>span:last-child{min-width:0;overflow-wrap:anywhere}
.ds-issue .ds-rec-ev{display:block;margin-top:4px;color:var(--ds-text2)}
.ds-issue .ds-rec-note,.ds-rec-note{display:block;margin-top:4px;color:var(--ds-muted)}
.ds-issue>p.ds-rec-note{border-top:1px solid var(--ds-red-line);padding-top:8px;margin-top:4px}
.ds-rec-picwrap{padding:0 0 4px}
.ds-rec-pich{font-size:14.5px;font-weight:700;color:var(--ds-text);padding:2px 20px 8px;overflow-wrap:anywhere}
figure.ds-pic{margin:0}
.ds-pic .ds-cap .ds-m{font-weight:500;overflow-wrap:anywhere;text-align:right}
.ds-rec-side .ds-side-c>.ds-sm{margin-top:10px;line-height:1.5}
.ds-rec-who{font-size:15px;padding:9px 12px;border:1px solid var(--ds-border);border-radius:8px;background:var(--ds-surface2);
  color:var(--ds-text);margin-bottom:10px;overflow-wrap:anywhere}
.ds-rec-side input.ds-inp{width:100%}
.ds-rec-side .ds-btns .ds-btn{width:100%}
.ds-rec-shared{margin-top:12px;padding-top:12px;border-top:1px solid var(--ds-border);font-size:14px;color:var(--ds-muted);
  display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.ds-rec-shared b{color:var(--ds-text2)}
.ds-rec-shared form{display:inline}
.ds-rec-acks li>span:first-child{min-width:0;overflow-wrap:anywhere}
.ds-rec-acks .ack-note{color:var(--ds-text2)}
.ds-list a{color:var(--ds-text2);min-width:0;overflow-wrap:anywhere}
.ds-list a:hover{color:var(--ds-primary-ink)}
.ds-list .ds-m{white-space:nowrap;font-size:14px}
.ds-dl .rec-why{color:var(--ds-text);font-size:15px}
.ds-rec-sum{font-weight:500}
.ds-rec-search{display:flex;gap:8px;align-items:center;margin:0}
.ds-rec-search input.ds-inp{width:240px;margin:0}
.ds-rec-find{display:flex;flex-wrap:wrap;gap:12px 16px;align-items:flex-end;padding:16px 20px}
.ds-rec-find .ds-lbl{margin:0 0 4px}
.ds-rec-find label.chk{margin:0 0 10px}
.ds-rec-dates{display:flex;gap:8px;align-items:center}
.ds-rec-find input.ds-inp{width:auto;margin:0}
.ds-rec-pad{padding:18px 20px}
.ds-rec-pad p+p{margin-top:8px}
.ds-rec-btnrow{margin-top:14px}
.ds-empty b{display:block;color:var(--ds-text);margin-bottom:4px}
@media (max-width:900px){
  .ds-rec-search input.ds-inp{width:100%}
  .ds-rec-search{width:100%}
  .ds-tools .ds-r{margin-left:0;width:100%}
}
/* 폰(640 아래) — 기록 표는 가로로 밀지 않고 줄마다 격자로 쌓는다: 1줄 프로젝트·문서, 2줄 파일, 3줄 바뀐 곳 | 이전 → 지금, 4줄 상태.
   칸 이름 줄은 숨기지만 칸 차례·글은 그대로(이전·지금 칸은 나란히 남는다). '그 밖'·새 파일 묶음은 넓은 화면과 같이 펼쳐야 보인다 */
@media (max-width:640px){
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items){display:block;min-width:0 !important;width:100%}
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>colgroup,
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>thead{display:none}
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>tbody{display:block}
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>tbody>tr{display:block;padding:0;border:0}
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>tbody>tr>td{display:block;padding:0;border:0;white-space:normal;
    min-width:0;text-align:left}
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>tbody>tr:is(.ds-day,.ds-fold)>td{padding:9px 16px;
    border-bottom:1px solid var(--ds-border)}
  .main table.ds-t:is(.ds-rec-chg,.ds-rec-iss,.ds-rec-items)>tbody>tr:not(.ds-day,.ds-fold){display:grid;gap:4px 8px;
    padding:12px 16px;border-bottom:1px solid var(--ds-border)}
  .main table.ds-t.ds-rec-chg>tbody>tr:not(.ds-day,.ds-fold){grid-template-columns:minmax(0,1fr) minmax(0,1fr) 14px;
    grid-template-areas:"pj dc go" "fl fl go" "pv pv go" "st st go" "wh wh go"}
  .main table.ds-t.ds-rec-chg.ds-rec-tl>tbody>tr:not(.ds-day,.ds-fold){grid-template-areas:"dc dc go" "fl fl go"
    "pv pv go" "st st go" "wh wh go"}
  .main table.ds-t.ds-rec-iss>tbody>tr:not(.ds-day,.ds-fold){grid-template-columns:auto minmax(0,1fr) auto 14px;
    grid-template-areas:"tg pj dy go" "tt tt tt go" "ev ev ev go"}
  .main table.ds-t.ds-rec-items>tbody>tr{grid-template-columns:minmax(0,1fr);
    grid-template-areas:"kd" "pl" "pv" "wh"}
  .main table.ds-t.ds-rec-chg>tbody>tr.ds-q{display:none}
  .main table.ds-t.ds-rec-chg>tbody:has(details.ds-qd[open])>tr.ds-q:not(.ds-fold){display:grid}
  .main table.ds-t.ds-rec-chg>tbody:has(details.ds-qd[open])>tr.ds-fold.ds-q{display:block}
  @supports not selector(:has(*)){.main table.ds-t.ds-rec-chg>tbody>tr.ds-q:not(.ds-fold){display:grid}
    .main table.ds-t.ds-rec-chg>tbody>tr.ds-fold.ds-q{display:block}}
  table.ds-t td.c-proj{grid-area:pj} table.ds-t td.c-doc{grid-area:dc} table.ds-t td.c-file{grid-area:fl}
  table.ds-t td.c-place{grid-area:pl} table.ds-t td.c-pv{grid-area:pv}
  table.ds-t td.c-state{grid-area:st} table.ds-t td.c-when{grid-area:wh}
  table.ds-t td.c-go{grid-area:go;align-self:center} table.ds-t td.c-tag{grid-area:tg} table.ds-t td.c-target{grid-area:tt}
  table.ds-t td.c-ev{grid-area:ev} table.ds-t td.c-day{grid-area:dy;text-align:right} table.ds-t td.c-kind{grid-area:kd}
  table.ds-t td.c-where{grid-area:wh} table.ds-t td.c-note{grid-column:1/-1}
  .main table.ds-t.ds-rec-chg>tbody>tr>td.c-state:empty{display:none}
  .main table.ds-t.ds-rec-chg.ds-rec-find-t>tbody>tr:not(.ds-day,.ds-fold){grid-template-columns:auto minmax(0,1fr) auto 14px;
    grid-template-areas:"st dc wh go" "fl fl fl go" "pv pv pv go"}
  .main table.ds-t.ds-rec-chg.ds-rec-find-t>tbody>tr>td.c-when{text-align:right}
  .main table.ds-t.ds-rec-chg.ds-rec-find-t>tbody>tr>td.c-when .ds-sm{display:inline;margin-left:6px}
  nav.ds-pcards{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  .ds-pc{padding:12px 14px}
  .ds-rec-h1tags{display:flex;margin:6px 0 0}
  .ds-rec-pich{padding:2px 16px 8px}
  .ds-rec-find{padding:14px 16px}
  .ds-rec-find>div,.ds-rec-find select.ds-sel{width:100%}
  .ds-rec-dates input.ds-inp{flex:1 1 0;min-width:0}
}
"""

# 화면 3판 큰 그림 (2026-11-20, 구현자 H) — 사내망 프로젝트 목록(/changes)·문서함(/changes/project)·문서 이력(/changes/doc) 전용.
# 감시 화면 ds-hm-·ds-db- 모양(web.py)과 같은 말씨, 이름은 ds-lb-. 칸 폭은 col 클래스(인라인 style은 CSP가 막는다).
# 폰(640 아래)은 기록 표처럼 줄마다 격자로 쌓는다 — 수 칸은 칸 이름(data-l)을 위에 작게, 줄 끝 ›는 오른쪽.
DS_REC_CSS += """
/* ── 화면 3판 큰 그림 — 사내망 프로젝트 목록·문서함·문서 이력 (ds-lb-) ── */
.nav a[href="/changes/issues"] .cnt{background:var(--ds-red);color:var(--ds-surface);border-radius:999px;padding:1px 8px;
  min-width:0;font-size:13.5px;font-weight:800;line-height:18px}
table.ds-t col.w-hp{width:200px} table.ds-t col.w-n{width:76px} table.ds-t col.w-n2{width:96px} table.ds-t col.w-n3{width:104px}
table.ds-t col.w-nm{width:230px} table.ds-t col.w-kd{width:100px} table.ds-t col.w-rv{width:64px} table.ds-t col.w-sv{width:112px}
table.ds-t col.w-st{width:150px} table.ds-t col.w-dt{width:130px}
table.ds-t .ds-num{text-align:right;font-variant-numeric:tabular-nums}
table.ds-t th.ds-num{text-align:right}
table.ds-t .ds-zero{color:var(--ds-border2)}
table.ds-t .ds-lb-big{font-size:17px;color:var(--ds-text)}
table.ds-t .ds-lb-red{color:var(--ds-red);font-weight:800}
table.ds-t td .ds-lb-kn{font-size:13px;font-weight:500;color:var(--ds-muted);white-space:nowrap;margin-top:2px}
table.ds-t a.ds-lb-code{font-size:17px;font-weight:700;color:var(--ds-text)}
table.ds-t a.ds-lb-code:hover,table.ds-t td.ds-lb-name a:hover{color:var(--ds-primary-ink);text-decoration:underline}
table.ds-t td.c-hp .ds-sm,table.ds-t td.ds-lb-last .ds-sm{overflow-wrap:anywhere}
table.ds-t tr.ds-lb-un td{background:var(--ds-surface2)}
table.ds-t td.ds-lb-name a{font-weight:700;color:var(--ds-text)}
table.ds-t td.ds-lb-last .ds-sm{margin-top:2px}
table.ds-t td.ds-lb-last .ds-lb-w{color:var(--ds-text2)}
table.ds-t td.c-proj a.ds-lb-plink{color:var(--ds-text)}
table.ds-t td.c-proj a.ds-lb-plink:hover{color:var(--ds-primary-ink);text-decoration:underline}
table.ds-t tr.ds-lb-fold td{background:var(--ds-surface);padding-top:9px;padding-bottom:9px}
table.ds-t tr.ds-lb-fold.ds-lb-whole td{background:var(--ds-surface2)}
table.ds-t tr.ds-lb-fold.ds-lb-whole details.ds-qd>summary{color:var(--ds-text);font-weight:800;font-size:15px}
table.ds-t tr.ds-lb-fold details.ds-qd>summary .ds-m{font-weight:500;font-size:14px;margin-left:6px}
.ds-alert.ds-lb-iss{background:var(--ds-red-bg);border-color:var(--ds-red-line);color:var(--ds-red)}
.ds-alert.ds-lb-iss .ds-lb-k{color:var(--ds-text2);margin-left:8px}
.ds-issue.ds-lb-amber{border-color:var(--ds-amber-line);background:var(--ds-amber-bg)}
.ds-issue.ds-lb-amber h3{color:var(--ds-amber-ink)}
.ds-issue.ds-lb-amber .ds-ln{border-top-color:var(--ds-amber-line)}
.ds-issue .ds-ln a{color:var(--ds-primary-ink);font-weight:700;white-space:nowrap}
.ds-lb-find input.ds-inp{width:220px}
@media (max-width:900px){
  .main table.ds-t.ds-lb-home{min-width:980px !important}
  .main table.ds-t.ds-lb-docs{min-width:900px !important}
  .main table.ds-t.ds-lb-hist{min-width:820px !important}
  .ds-lb-find input.ds-inp{width:100%}
}
@media (max-width:640px){
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist){display:block;min-width:0 !important;width:100%}
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>colgroup,
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>thead{display:none}
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>tbody{display:block}
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>tbody>tr{display:block;padding:0;border:0}
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>tbody>tr>td{display:block;padding:0;border:0;white-space:normal;
    min-width:0;text-align:left}
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>tbody>tr:is(.ds-day,.ds-fold)>td{padding:9px 16px;
    border-bottom:1px solid var(--ds-border)}
  .main table.ds-t:is(.ds-lb-home,.ds-lb-docs,.ds-lb-hist)>tbody>tr:not(.ds-day,.ds-fold){display:grid;gap:4px 10px;
    padding:12px 16px;border-bottom:1px solid var(--ds-border)}
  .main table.ds-t.ds-lb-home>tbody>tr:not(.ds-day,.ds-fold){grid-template-columns:repeat(3,minmax(0,1fr)) 14px;
    grid-template-areas:"hp hp hp go" "n1 n2 n3 go" "n4 n5 n6 go" "ls ls ls go"}
  .main table.ds-t.ds-lb-home>tbody>tr.ds-lb-un{grid-template-areas:"hp hp hp go" "n1 n1 n1 go"}
  table.ds-lb-home td.c-hp{grid-area:hp} table.ds-lb-home td.c-ls{grid-area:ls;margin-top:4px}
  table.ds-lb-home td.c-n1{grid-area:n1} table.ds-lb-home td.c-n2{grid-area:n2} table.ds-lb-home td.c-n3{grid-area:n3}
  table.ds-lb-home td.c-n4{grid-area:n4} table.ds-lb-home td.c-n5{grid-area:n5} table.ds-lb-home td.c-n6{grid-area:n6}
  .main table.ds-t.ds-lb-home>tbody>tr>td.ds-num{font-size:16px}
  .main table.ds-t.ds-lb-home>tbody>tr>td.ds-num::before{content:attr(data-l);display:block;font-size:13px;font-weight:500;
    color:var(--ds-muted)}
  .main table.ds-t.ds-lb-home>tbody>tr>td.c-un{display:none}
  .main table.ds-t.ds-lb-docs>tbody>tr:not(.ds-day,.ds-fold){grid-template-columns:auto auto minmax(0,1fr) 14px;
    grid-template-areas:"nm nm nm go" "kd rv sv go" "ls ls ls go" "st st st go";align-items:center}
  table.ds-lb-docs td.c-nm{grid-area:nm} table.ds-lb-docs td.c-kd{grid-area:kd} table.ds-lb-docs td.c-rv{grid-area:rv}
  table.ds-lb-docs td.c-sv{grid-area:sv} table.ds-lb-docs td.c-ls{grid-area:ls} table.ds-lb-docs td.c-st{grid-area:st}
  .main table.ds-t.ds-lb-docs>tbody>tr>td:is(.c-rv,.c-sv)::before{content:attr(data-l) " ";font-weight:500;color:var(--ds-muted);
    font-size:13px}
  .main table.ds-t.ds-lb-docs>tbody>tr>td.c-st:empty{display:none}
  .main table.ds-t.ds-lb-docs>tbody>tr.ds-q{display:none}
  .main table.ds-t.ds-lb-docs>tbody:has(details.ds-qd[open])>tr.ds-q{display:grid}
  @supports not selector(:has(*)){.main table.ds-t.ds-lb-docs>tbody>tr.ds-q{display:grid}}
  .main table.ds-t.ds-lb-hist>tbody>tr:not(.ds-day,.ds-fold){grid-template-columns:minmax(0,1fr) 14px;
    grid-template-areas:"dt go" "pv go" "st go"}
  table.ds-lb-hist td.c-dt{grid-area:dt}
  table.ds-lb-hist td.c-dt .ds-sm{display:inline;margin-left:6px}
  .main table.ds-t.ds-lb-hist>tbody>tr>td.c-state:empty{display:none}
  .ds-lb-find{width:100%}
}
"""
# 이전 / 지금 두 줄 (2026-11-21 사용자 "바뀌기 전·바뀐 부분 글씨는 행을 바꿔서 — 화살표 빼고는 구분도 잘 안 되고 읽기도 어렵다").
# 감시 화면(web.py ds-pv)과 같은 마크업·같은 말 — 이름표(이전·지금 / 도면·BOM) + 값, 이전은 옅게·지금은 굵고 진하게, 화살표 없음.
# 목록 표의 '바뀐 곳 · 이전 / 지금'은 두 머리 칸에 걸친 한 칸(colspan 2) 안의 격자: 첫 칸 146px + 사이 24px = col.w-place 170px이라
# 바뀐 곳이 '바뀐 곳' 머리 아래, 두 줄이 '이전 / 지금' 머리 아래에 선다. 곳이 여럿이면 곳마다 한 덩이, 사이 옅은 점선.
# 인라인 style 없이 클래스로만(CSP). 색은 --ds-* 토큰만(밝음·어두움). 폰(640 아래)은 바뀐 곳이 두 줄 위 한 줄.
# 이전 값 색·어두운 테마 이름표 테두리는 감시 화면(web.py)과 같은 두 토큰(--ds-pv-old·--ds-pv-ring) — 이 서버의 테마 방식(OS 따라감 +
# data-theme 고정) 두 갈래 모두에 둔다
DS_REC_CSS += """
:root{--ds-pv-old:#5B6475;--ds-pv-ring:transparent}
@media (prefers-color-scheme: dark){ :root:not([data-theme=light]){--ds-pv-old:#AEB5C2;--ds-pv-ring:#3D4553} }
:root[data-theme=dark]{--ds-pv-old:#AEB5C2;--ds-pv-ring:#3D4553}
"""
DS_REC_CSS += _issue_view_css()
DS_REC_CSS += """
/* ── 이전 / 지금 두 줄 (2026-11-21) ── */
.main table.ds-t:is(.ds-rec-chg,.ds-lb-hist,.ds-rec-items,.ds-rec-iss,.ds-lb-home,.ds-lb-docs)>tbody>tr>td{vertical-align:top}
.ds-pvg{display:grid;grid-template-columns:146px minmax(0,1fr);column-gap:24px;align-items:start}
.ds-pvg>.ds-pvk{font-weight:700;color:var(--ds-text);min-width:0;overflow-wrap:anywhere;padding-top:1px}
.ds-pvg>.ds-pvx{min-width:0}
.ds-pvg>.ds-pvk:not(:first-child),.ds-pvg>.ds-pvk:not(:first-child)+.ds-pvx{margin-top:10px;padding-top:10px;
  border-top:1px dashed var(--ds-border)}
.ds-pvg>.ds-pvmore{grid-column:1/-1;margin-top:6px;font-size:14px;color:var(--ds-muted)}
.ds-pv{display:grid;grid-template-columns:max-content minmax(0,1fr);gap:4px 10px;align-items:baseline}
.ds-pv-r{display:contents}
.ds-pv-l{min-width:40px;box-sizing:border-box;text-align:center;font-size:12.5px;font-weight:800;line-height:1.5;padding:1px 7px;
  border-radius:5px;white-space:nowrap;background:var(--ds-gray-bg);color:var(--ds-muted);box-shadow:inset 0 0 0 1px var(--ds-pv-ring)}
.ds-pv-r.o .ds-pv-l{background:var(--ds-gray-bg);color:var(--ds-muted)}
.ds-pv-r.n .ds-pv-l{background:var(--ds-primary-weak);color:var(--ds-primary-ink)}
.ds-pv-v{min-width:0;line-height:22px;overflow-wrap:anywhere}
.ds-pv-r.o .ds-pv-v{color:var(--ds-pv-old);font-weight:400;font-size:15px}
.ds-pv-r.n .ds-pv-v{color:var(--ds-text);font-weight:800;font-size:15.5px}
.ds-pv.ds-pv-side .ds-pv-l{background:var(--ds-gray-bg);color:var(--ds-text2)}
.ds-pv.ds-pv-side .ds-pv-v{color:var(--ds-text);font-weight:800;font-size:15.5px}
.ds-pv-one{color:var(--ds-text2);overflow-wrap:anywhere}
.ds-pb+.ds-pb{margin-top:10px;padding-top:10px;border-top:1px dashed var(--ds-border)}
.ds-pk{font-weight:800;font-size:15px;line-height:22px;color:var(--ds-text);margin:6px 0 4px;overflow-wrap:anywhere}
.ds-pk:first-child{margin-top:0}
.ds-pv-at,.ds-sm.ds-pv-at,td.c-ev>.ds-pv+.ds-sm{font-size:13.5px;color:var(--ds-muted);margin-top:4px;overflow-wrap:anywhere}
.ds-pb.ds-pv-ev{margin-top:6px}
.ds-lb-lh{color:var(--ds-text2);margin-bottom:2px}
.ds-lb-lh b{color:var(--ds-text)}
.ds-lb-it{display:block;margin-bottom:2px}
td.c-ev>*+.ds-pv,.ds-issue .ds-pv{margin-top:6px}
td.c-ev>b+.ds-pk{margin-top:6px}
@media (max-width:640px){
  .ds-pvg{grid-template-columns:minmax(0,1fr)}
  .ds-pvg>.ds-pvk:not(:first-child)+.ds-pvx{margin-top:0;padding-top:4px;border-top:0}
  .ds-pvg>.ds-pvk+.ds-pvx{margin-top:3px}
}
"""

# 변경 상세(/changes/<번호>) — 감시 화면 변경 상세(web.py ds-chg-)와 같은 모양 (2026-11-21 구현자 M). 같은 이름·같은 값으로 옮겨 오고,
# 이 서버의 '.main table.ds-t' 좁은 폭 규칙(최소 폭 720px·폰 폭 표 그대로)보다 앞서도록 .main을 붙인 것만 다르다. 색은 --ds-* 토큰만,
# 인라인 style 없이(CSP) — 증감 배지(+1)도 클래스. 감시 PC 전용(숨기기 단추 칸·고급 도구·크게 비교)은 없다
DS_REC_CSS += """
/* ── 변경 상세 — 감시 화면과 같은 틀: 본문(왼쪽, 두 줄 걸침) | 확인(오른쪽 위) · 파일 정보·변경 기록(오른쪽 아래) ── */
.ds-chg-main,.ds-chg-side,.ds-chg-ack{min-width:0}
.ds-split.ds-chg-split{grid-template-areas:"main ack" "main side";grid-template-rows:auto 1fr;row-gap:0}
.ds-chg-split>.ds-chg-main{grid-area:main}
.ds-chg-split>.ds-chg-ack{grid-area:ack}
.ds-chg-split>.ds-chg-side{grid-area:side;align-self:start}
.ds-chg-sub2{display:block}
.ds-chg .ds-alert{align-items:baseline}
.ds-chg .ds-alert>b{flex:none}
.ds-chg .ds-alert>span{flex:1 1 0;min-width:0;overflow-wrap:break-word}
.ds-chg .ds-issue#iss-open{border-left:1px solid var(--ds-red-line);padding-left:20px}
.ds-chg .ds-alert#iss-open{border-left:1px solid var(--ds-green-line);padding-left:16px}
.ds-chg .ds-alert .ds-m{font-size:14.5px}
.ds-chg .ds-alert a{color:var(--ds-primary-ink);font-weight:700}
.ds-chg .ds-issue h3{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
.ds-chg .ds-issue h3 .ds-chg-warn{flex:none;font-size:16px;line-height:1}
.ds-chg .ds-issue h3 a{margin-left:auto;font-size:14.5px;font-weight:700;color:var(--ds-primary-ink)}
.ds-chg .ds-issue .ds-chg-isub{font-size:14.5px;color:var(--ds-muted);margin:-2px 0 6px}
.ds-chg .ds-issue .ds-chg-isub.ds-chg-ilan{margin:8px 0 0;padding-top:8px;border-top:1px solid var(--ds-red-line);font-size:14px}
.ds-chg .ds-issue .ds-ln>span{min-width:0;overflow-wrap:break-word}
.ds-chg .ds-issue .ds-ln b{color:var(--ds-text);font-weight:800}
.ds-chg .ds-issue .ds-k .ds-sm{font-weight:500}
.ds-chg .ds-issue .ds-ln .ds-sm{margin-top:3px}
.ds-chg .ds-chg-ev{display:inline-block;max-width:100%}
.ds-chg .ds-pv{margin-top:6px;min-width:0}
.ds-chg .ds-pv:first-child,.ds-chg .ds-pk+.ds-pv{margin-top:0}
.ds-chg .ds-pf{font-size:15px;color:var(--ds-text2);margin-bottom:6px}
.ds-chg .ds-pf b{color:var(--ds-text)}
.ds-chg .ds-pb{min-width:0}
.ds-chg div+.ds-pb{margin-top:6px}
.ds-chg .ds-pb+.ds-pb{margin-top:10px;padding-top:10px;border-top:1px dashed var(--ds-border)}
table.ds-chg-t td{vertical-align:top;overflow-wrap:break-word}
.main table.ds-t.ds-chg-t>tbody>tr>td{vertical-align:top}
.ds-chg-kv{display:block}
table.ds-chg-t th.ds-chg-wk{width:180px}
table.ds-chg-t th.ds-chg-ww{width:200px}
table.ds-chg-t th.ds-chg-wr{width:150px}
table.ds-chg-t th.ds-chg-wc{width:100px}
table.ds-chg-t th.ds-chg-wl{width:130px}
table.ds-chg-t code{font-family:inherit;font-size:inherit;background:none;border:0;padding:0;color:inherit}
.ds-chg .wdel{background:none;color:inherit;text-decoration:line-through;padding:0}
.ds-chg .wins{background:var(--ds-primary-weak);color:var(--ds-text);font-weight:800;border-radius:4px;padding:0 3px}
.ds-chg-delta{color:var(--ds-muted);font-weight:700;font-size:13.5px}
table.ds-chg-sub{margin-top:6px;border-collapse:collapse;font-size:14px}
table.ds-chg-sub td{padding:2px 10px 2px 0;border:0;font-size:14px}
details.ds-chg-cols>summary,details.ds-chg-fold>summary{cursor:pointer;color:var(--ds-primary-ink);font-weight:700;list-style:none}
details.ds-chg-cols>summary{font-size:14px;margin-top:4px}
details.ds-chg-fold>summary{font-size:14.5px}
details.ds-chg-cols>summary::-webkit-details-marker,details.ds-chg-fold>summary::-webkit-details-marker{display:none}
details.ds-chg-fold>summary::before{content:"\\25B8";display:inline-block;margin-right:6px;font-size:12px;transition:transform .12s}
details.ds-chg-fold[open]>summary::before{transform:rotate(90deg)}
details.ds-chg-fold>summary .ds-m{font-weight:500}
.ds-chg .ds-card-f{flex-direction:column;align-items:stretch;gap:10px}
.ds-chg .ds-card-f>details>.ds-scroll,.ds-chg .ds-card-f>details>.ds-list{margin-top:10px}
.ds-chg .ds-card-f table.ds-t th:first-child,.ds-chg .ds-card-f table.ds-t td:first-child{padding-left:12px}
.ds-chg .ds-card-h .ds-s b{color:var(--ds-text)}
.ds-chg #hidden-items .ds-list li>span{display:block;min-width:0;overflow-wrap:anywhere}
.ds-chg #hidden-items .ds-list li .ds-m{display:block;margin-top:4px;white-space:normal;text-align:left}
.ds-chg .ds-pic{display:flex;flex-direction:column}
.ds-chg .ds-pic .ds-cap .ds-m{font-weight:600}
.ds-chg-pt{font-size:14.5px;font-weight:700;color:var(--ds-text);padding:2px 20px 8px;overflow-wrap:anywhere}
.ds-chg-pt .ds-m{font-weight:500;margin-left:6px}
.ds-chg-noimg{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;min-height:150px;
  background:var(--ds-surface2);color:var(--ds-muted);font-size:14.5px;text-align:center;padding:16px}
.ds-chg-pics>details{padding:0 20px 20px}
.ds-chg-pics>details>.ds-pics{padding:12px 0 0}
.ds-chg-pics>details>.ds-chg-pt{padding:14px 0 8px}
.ds-chg .ds-pics.ds-chg-one{grid-template-columns:minmax(0,1fr)}
.ds-chg .ds-dl dd .ds-m{font-weight:500}
.ds-chg .ds-dl dd .rc-attr{font-size:14px;color:var(--muted2)}
.ds-chg .ds-list li>:first-child{min-width:0;overflow-wrap:anywhere}
.ds-chg .ds-list li a{color:var(--ds-primary-ink)}
.ds-chg .ds-list li.on>:first-child{font-weight:700;color:var(--ds-text)}
.ds-chg .ds-list li .ds-m{white-space:nowrap;flex:none;text-align:right}
.ds-chg .ds-list li .ds-chg-now{display:block;margin-top:4px;font-size:12px;font-weight:800;color:var(--ds-primary-ink)}
.ds-chg .ds-list li a.ds-chg-hl{color:inherit;text-decoration:none;display:block}
.ds-chg .ds-list li a.ds-chg-hl:hover .ds-pk{color:var(--ds-primary-ink);text-decoration:underline}
.ds-chg .ds-list li.on .ds-chg-hv .ds-pk{color:var(--ds-text)}
@media (max-width:900px){
  .ds-split.ds-chg-split{grid-template-areas:none;grid-template-rows:none}
  .ds-chg-split>.ds-chg-main,.ds-chg-split>.ds-chg-ack,.ds-chg-split>.ds-chg-side{grid-area:auto}
  /* 바뀐 내용·파일 수준 근거·행 표는 좁은 폭에서도 가로 밀기 없이 한눈에 — 칸 너비를 비율로 */
  .main table.ds-t.ds-chg-fit{min-width:0 !important}
  table.ds-chg-fit th.ds-chg-wk,table.ds-chg-fit th.ds-chg-wr{width:30%}
  table.ds-chg-fit th.ds-chg-ww{width:26%}
  .main table.ds-t.ds-chg-fit>thead>tr>th,.main table.ds-t.ds-chg-fit>tbody>tr>td{padding-left:8px;padding-right:8px}
  .main table.ds-t.ds-chg-fit>thead>tr>th:first-child,.main table.ds-t.ds-chg-fit>tbody>tr>td:first-child{padding-left:14px}
  .main table.ds-t.ds-chg-fit>thead>tr>th:last-child,.main table.ds-t.ds-chg-fit>tbody>tr>td:last-child{padding-right:14px}
  .main table.ds-t.ds-chg-fit>tbody>tr>td{font-size:15px}
  table.ds-chg-rows th.ds-chg-wr{width:22%}
  table.ds-chg-rows th.ds-chg-wc{width:15%}
  table.ds-chg-rows th.ds-chg-wl{width:17%}
  table.ds-chg-rows .ds-tg{white-space:normal}
  .ds-chg-pt{padding-left:20px}
}
@media (max-width:600px){
  /* 폰 폭: 행 표는 줄마다 한 덩어리 — '바뀐 칸·이전 / 지금·위치'를 이름표(data-l) 붙인 줄로 */
  .main table.ds-t.ds-chg-rows,.main table.ds-t.ds-chg-rows>tbody,.main table.ds-t.ds-chg-rows>tbody>tr,
  .main table.ds-t.ds-chg-rows>tbody>tr>td{display:block;width:auto}
  .main table.ds-t.ds-chg-rows>thead{display:none}
  .main table.ds-t.ds-chg-rows>tbody>tr{padding:10px 14px;border-bottom:1px solid var(--ds-border)}
  .main table.ds-t.ds-chg-rows>tbody>tr:last-child{border-bottom:0}
  .main table.ds-t.ds-chg-rows>tbody>tr>td,.main table.ds-t.ds-chg-rows>tbody>tr>td:first-child,
  .main table.ds-t.ds-chg-rows>tbody>tr>td:last-child{border:0;padding:2px 0}
  .main table.ds-t.ds-chg-rows>tbody>tr>td[data-l]{position:relative;padding-left:72px}
  .main table.ds-t.ds-chg-rows>tbody>tr>td[data-l]::before{content:attr(data-l);position:absolute;left:0;top:3px;width:64px;
    font-size:13.5px;font-weight:700;color:var(--ds-muted)}
}
@media (max-width:640px){
  /* 바뀐 내용 표도 폰 폭에서는 줄마다 한 덩이 — 바뀐 곳(굵게) / [이전]·[지금] 두 줄 / 위치(작게) */
  .main table.ds-t.ds-chg-items,.main table.ds-t.ds-chg-items>tbody,.main table.ds-t.ds-chg-items>tbody>tr,
  .main table.ds-t.ds-chg-items>tbody>tr>td{display:block;width:auto}
  .main table.ds-t.ds-chg-items>thead{display:none}
  .main table.ds-t.ds-chg-items>tbody>tr{padding:10px 14px;border-bottom:1px solid var(--ds-border)}
  .main table.ds-t.ds-chg-items>tbody>tr:last-child{border-bottom:0}
  .main table.ds-t.ds-chg-items>tbody>tr>td,.main table.ds-t.ds-chg-items>tbody>tr>td:first-child,
  .main table.ds-t.ds-chg-items>tbody>tr>td:last-child{border:0;padding:2px 0}
  .main table.ds-t.ds-chg-items>tbody>tr>td.ds-chg-at{font-size:14px}
}
"""
