# -*- coding: utf-8 -*-
"""사내망 변경 확인·열람 (기능 검토 갈래 N, 2026-11-02 — FORMS.md 11절, DECISIONS 같은 날 둘째 줄).

켜 둔 양식함 서버 안에서, 양식함 계정으로 로그인한 사람이 관리자가 허락한 범위(전체 또는 고른 프로젝트)의 감시 변경을 본다:
근거 표(이전 / 새 값 / 위치)·전/후 사진·검토 필요(읽기만)·설계 변경 대장 엑셀, 그리고 [확인함 + 한 줄 메모].

- state.db에 쓰는 것은 확인 기록(acks) 한 줄뿐 — 기존 State.add_ack. 그 밖(설정·검사·삭제·오탐 숨김·검토 필요 닫기)은 감시 PC에서만.
- state.db는 요청마다 새 연결(mode=rw — 없으면 만들지 않음), 스키마를 만들거나 이주하지 않는다(State.attach). busy_timeout 4초.
- 권한은 forms.db meta `changes_view:<계정 id>`(스키마 그대로). 관리자는 늘 전체. 권한이 없거나 범위 밖이면 없는 주소와 같은 404.
- 이 모듈은 파일을 쓰지 않는다(test_readonly 엄격 모드). 응답은 FormsHandler._send(소켓)로만 보낸다.
"""

from __future__ import annotations

import base64
import binascii
import contextlib
import html
import json
import re
import sqlite3
from datetime import date
from pathlib import Path, PurePosixPath
from urllib.parse import quote, urlencode

from watcher.state import KIND_LABEL, State, ack_label, clean_ack_text, lan_ack_by

E = html.escape
ACCESS_PREFIX = "changes_view:"
BUSY_MS = 4000                       # 감시 검사가 쓰기 잠금을 쥐고 있을 때 기다리는 상한
LIST_MAX = 300                       # 목록 한 번에 보이는 변경 수
ITEM_MAX = 400                       # 상세 근거 표 항목 상한
PHOTO_MAX = 60                       # 상세 한 장의 사진 묶음 상한
NOTE_MAX = 200                       # 확인 메모 글자 상한 (한 줄)
IMG_MAX = 24 * 1024 * 1024           # 사진 한 장 상한(바이트)
_IMG_SIG = {"image/png": b"\x89PNG\r\n\x1a\n", "image/jpeg": b"\xff\xd8\xff"}
_REQUIRED = {                        # 이 화면이 읽고 쓰는 표·칸 — 없으면(옛 판·다른 파일) '열 수 없음'
    "changes": {"id", "snapshot_id", "kind", "path", "old_sha256", "new_sha256", "detected_at", "project"},
    "acks": {"id", "change_id", "by", "note", "at"},
    "change_details": {"change_id", "items_json", "captures_json", "dismissed_json"},
    "issues": {"id", "snapshot_id", "code", "path", "project", "message", "evidence", "detected_at", "resolved_at"},
    "snapshots": {"id", "run_at"},
    "extracts": {"sha256", "doc_json"},
    "meta": {"key", "value"},
}
BUSY_TEXT = "감시 검사가 기록을 쓰는 중입니다 — 잠시 뒤 다시 해 주세요"


class WatchUnavailable(Exception):
    """감시 기록(state.db)을 열 수 없다 — 없음·손상·형식 다름. 까닭은 쉬운 말."""


class WatchBusy(Exception):
    """감시 검사가 쓰기 잠금을 쥐고 있다 — 잠시 뒤 다시."""


def _busy(e) -> bool:
    m = str(e).lower()
    return "locked" in m or "busy" in m


class WatchLog:
    """감시 기록 파일 하나 — 요청마다 짧게 열고 닫는다."""

    def __init__(self, db_path, recipients=None):
        self.path = Path(db_path)
        self._recipients = recipients

    def recipients(self) -> dict:
        """{'*': [메일 전체 수신자], 프로젝트: [받는 사람]} — 감시 설정에서 (기본 범위 제안용). 못 읽으면 빈 사전."""
        r = self._recipients
        try:
            got = r() if callable(r) else r
        except Exception:
            return {}
        return got if isinstance(got, dict) else {}

    @contextlib.contextmanager
    def session(self):
        p = self.path
        if not p.is_file():
            raise WatchUnavailable(f"감시 기록 파일(state.db)이 없습니다 — 감시 PC에서 검사를 한 번 돌린 뒤 다시 여세요 ({p.name})")
        try:
            conn = sqlite3.connect(p.resolve().as_uri() + "?mode=rw", uri=True, timeout=BUSY_MS / 1000,
                                   check_same_thread=False)
        except (sqlite3.Error, OSError, ValueError) as e:
            raise WatchUnavailable(f"감시 기록 파일을 열 수 없습니다 — {type(e).__name__}")
        try:
            conn.execute(f"PRAGMA busy_timeout={int(BUSY_MS)}")
            _check_schema(conn)
            yield State.attach(conn, p)
        except sqlite3.OperationalError as e:
            if _busy(e):
                raise WatchBusy(BUSY_TEXT) from e
            raise WatchUnavailable(f"감시 기록을 읽을 수 없습니다 — {e}") from e
        except sqlite3.DatabaseError as e:
            raise WatchUnavailable(f"감시 기록 파일이 손상됐거나 SQLite 파일이 아닙니다 — {e}") from e
        finally:
            try:
                conn.close()
            except sqlite3.Error:
                pass


def _check_schema(conn) -> None:
    for table, need in _REQUIRED.items():
        cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        if not cols:
            raise WatchUnavailable(f"감시 기록에 '{table}' 표가 없습니다 — 감시 기록 파일이 아니거나 아주 옛 판입니다")
        missing = need - cols
        if missing:
            raise WatchUnavailable(f"감시 기록의 형식이 이 판과 다릅니다('{table}' 표에 {', '.join(sorted(missing))} 칸이 없음) — "
                                   "감시 PC에서 Drev 화면을 한 번 열면 맞춰집니다")


# ── 권한 (forms.db meta — 스키마 그대로) ─────────────────────────────────────────

def access_of(store, user_id, role: str | None = None):
    """None = 열람 없음, 'all' = 전체, frozenset = 고른 프로젝트. 관리자는 늘 'all'. 정지 계정은 None."""
    u = store.get_user(user_id)
    if not u or u.get("disabled"):
        return None
    if u.get("role") == "admin":                 # 역할은 매번 DB에서 (세션 값이 아니라)
        return "all"
    raw = store.meta_get(f"{ACCESS_PREFIX}{int(user_id)}", "")
    if not raw:
        return None
    try:
        d = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(d, dict):
        return None
    if d.get("all"):
        return "all"
    ps = d.get("projects")
    if isinstance(ps, list):
        got = frozenset(str(x) for x in ps if str(x).strip())
        return got or None
    return None


def set_access(store, actor_id, target_id, *, on: bool, all_: bool, projects, ip: str = "") -> str:
    """관리자가 계정 하나의 열람을 켜고 끈다 — 감사 기록 changes_access. 돌려주는 값: 한 줄 결과."""
    u = store.get_user(target_id)
    if not u:
        from watcher.forms.store import NotFound
        raise NotFound("없는 계정입니다")
    key = f"{ACCESS_PREFIX}{int(target_id)}"
    ps = sorted({str(p).strip()[:200] for p in (projects or ()) if str(p).strip()})[:500]
    if u.get("role") == "admin":
        return "관리자는 늘 모든 프로젝트의 변경을 봅니다 — 따로 정할 것이 없습니다"
    if not on or (not all_ and not ps):
        store.meta_put({key: None})
        what = "끔"
    elif all_:
        store.meta_put({key: json.dumps({"all": True}, ensure_ascii=False)})
        what = "켬 — 전체 프로젝트"
    else:
        store.meta_put({key: json.dumps({"projects": ps}, ensure_ascii=False)})
        what = f"켬 — 프로젝트 {len(ps)}개: {', '.join(ps)[:300]}"
    store.record_audit(actor_id, "changes_access", f"user:{int(target_id)}", ip=ip,
                       detail=f"{u.get('login')} 변경 브리핑 열람 {what}")
    return f"{u.get('display_name') or u.get('login')}: 변경 브리핑 열람 {what}"


def access_text(acc) -> str:
    if acc is None:
        return "끔"
    if acc == "all":
        return "전체"
    ps = sorted(acc)
    return f"{len(ps)}개 프로젝트" if len(ps) > 3 else ", ".join(ps)


def suggested(recipients: dict, email: str, projects=()) -> tuple[bool, list]:
    """계정 메일이 감시 메일 받는 사람에 있으면 (모든 통 수신 여부, 받는 프로젝트들) — 제안만(자동 부여 없음).
    recipients는 settings.watch_recipients 꼴: '*' 모든 통, '' 프로젝트별 수신자가 없는 프로젝트, 그 밖 프로젝트별(전체 수신자를 대체)."""
    em = str(email or "").strip().casefold()
    if not em:
        return False, []

    def has(lst):
        return any(str(a).strip().casefold() == em for a in (lst or ()))
    every = has(recipients.get("*"))
    own = {p for p in recipients if p not in ("*", "")}
    projs = {p for p in own if has(recipients.get(p))}
    if has(recipients.get("")):
        projs |= {p for p in projects if p not in own}
    return every, sorted(projs)


# ── 화면 공용 ─────────────────────────────────────────────────────────────────

def _S():
    from watcher.forms import server as S
    return S


def _watch(h):
    w = getattr(h.server, "watch_log", None)
    if w is None:
        raise _S().HttpError(404)
    return w


def _scope(h):
    """내 범위 — None(전체) 또는 프로젝트 모음. 열람이 없으면 없는 주소와 같은 404."""
    _watch(h)
    acc = access_of(h.server.store, h.sess.user_id, h.sess.role)
    if acc is None:
        raise _S().HttpError(404)
    return None if acc == "all" else acc


def nav_item(h):
    """메뉴 줄 — 열람할 수 있는 계정에게만 (그 밖에는 메뉴에도 없다)."""
    if getattr(h.server, "watch_log", None) is None:
        return None
    try:
        if access_of(h.server.store, h.sess.user_id, h.sess.role) is None:
            return None
    except Exception:
        return None
    return ("/changes", "변경 확인", 0, "")


def _in(scope, project) -> bool:
    return scope is None or (project or "미분류") in scope


def _local(iso, fmt: str = "%Y-%m-%d %H:%M") -> str:
    from watcher.change_ledger import _local as L
    d = L(iso)
    return d.strftime(fmt) if d else ""


def _mtime(ts) -> str:
    try:
        from watcher.brief import saved_stamp
        return saved_stamp(ts)
    except (TypeError, ValueError, OSError, OverflowError):
        return ""


def _unavailable(h, why: str, status: int = 200) -> None:
    lead = "잠시 기다려 주세요" if status == 503 else "감시 기록을 열 수 없습니다"
    body = (f'<div class="note bad" role="alert">{lead} — {E(why)}</div>'
            f'<p class="muted">양식함의 다른 화면은 그대로 쓸 수 있습니다.'
            + ("" if status == 503 else " 감시 PC 관리자에게 알려 주세요.") + '</p>'
            f'<p><a class="btn gray" href="/forms">양식함으로</a></p>')
    h._send(status, h._shell("변경 확인", body, active="/changes"))


def _guarded(fn):
    """감시 기록을 여는 화면 — 열 수 없으면 그 화면만 안내, 잠겨 있으면 잠시 뒤 다시(503)."""
    def run(h):
        try:
            fn(h)
        except WatchBusy as e:
            _unavailable(h, str(e), 503)
        except WatchUnavailable as e:
            _unavailable(h, str(e))
    run.__name__ = fn.__name__
    return run


def _projects(st: State, scope) -> list[str]:
    ps = [r[0] for r in st.conn.execute("SELECT DISTINCT IFNULL(project, '미분류') FROM changes ORDER BY 1")]
    return [p for p in ps if _in(scope, p)]


def _filters(h, scope) -> dict:
    S = _S()
    q = h._query()
    p = S.FormsHandler._one(q, "p").strip()
    if p and not _in(scope, p):
        p = ""                                   # 범위 밖 이름은 없는 것처럼 — 고르지 않은 것으로
    from watcher.change_ledger import parse_day
    d1 = parse_day(S.FormsHandler._one(q, "from"))
    d2 = parse_day(S.FormsHandler._one(q, "to"))
    show = S.FormsHandler._one(q, "show")
    return {"p": p, "from": d1, "to": d2, "show": "unacked" if show == "unacked" else "all"}


def _scope_set(scope, p: str):
    """조회에 쓸 프로젝트 모음 — 하나를 골랐으면 그것만, 아니면 내 범위(None = 모두)."""
    if p:
        return frozenset([p])
    return scope


def _qs(f: dict, **over) -> str:
    d = {"p": f["p"], "from": f["from"].isoformat() if f["from"] else "", "to": f["to"].isoformat() if f["to"] else "",
         "show": f["show"] if f["show"] != "all" else ""}
    d.update(over)
    d = {k: v for k, v in d.items() if v}
    return ("?" + urlencode(d)) if d else ""


# ── /changes — 내 범위 프로젝트별 최근 변경 (미확인 먼저) ─────────────────────────────

@_guarded
def get_changes(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    f = _filters(h, scope)
    from watcher.change_ledger import acks_by_change, headlines, select_changes
    with w.session() as st:
        projs = _projects(st, scope)
        chs = select_changes(st, projects=_scope_set(scope, f["p"]), date_from=f["from"], date_to=f["to"],
                             limit=LIST_MAX * 4, newest_first=True)
        ids = [c["id"] for c in chs]
        acks = acks_by_change(st, ids)
        if f["show"] == "unacked":
            chs = [c for c in chs if c["id"] not in acks]
        more = len(chs) > LIST_MAX
        chs = chs[:LIST_MAX]
        heads = headlines(st, [c["id"] for c in chs])
        notes = _notes_of(st, [c["id"] for c in chs])
        n_iss = _open_issue_count(st, scope, f["p"])
    opts = '<option value="">내 범위 전체</option>' + "".join(
        f'<option value="{E(p)}"{" selected" if p == f["p"] else ""}>{E(p)}</option>' for p in projs)
    bar = (f'<form class="searchbar" method="get" action="/changes">'
           f'<label class="chk" for="cp">프로젝트</label><select id="cp" name="p">{opts}</select>'
           f'<label class="chk" for="cf">기간</label><input type="date" id="cf" name="from" '
           f'value="{E(f["from"].isoformat() if f["from"] else "")}" aria-label="시작 날짜">'
           f'<span class="muted">~</span><input type="date" id="ct" name="to" '
           f'value="{E(f["to"].isoformat() if f["to"] else "")}" aria-label="끝 날짜">'
           f'<label class="chk" for="cu"><input type="checkbox" id="cu" name="show" value="unacked"'
           f'{" checked" if f["show"] == "unacked" else ""}>미확인만</label>'
           f'<button class="btn gray sm" type="submit">보기</button></form>')
    acts = (f'<a class="btn gray" href="/changes/issues{_qs(f, show="", **{"from": "", "to": ""})}">검토 필요 {n_iss}건</a>'
            f'<a class="btn gray" href="/changes.xlsx{_qs(f, show="")}" title="고른 프로젝트·기간의 변경을 엑셀 한 벌로 (사진은 화면에서)">'
            f'설계 변경 대장 엑셀</a>')
    intro = ('<p class="muted">감시가 매일 아침 잡은 변경입니다. 줄을 눌러 근거(이전 값 / 새 값 / 위치)와 전/후 사진을 보고 '
             '[확인함]을 누르세요. 설정·검사·검토 필요 닫기는 감시 PC에서 합니다.'
             + ("" if scope is None else f' 볼 수 있는 프로젝트: {E(", ".join(sorted(scope)))}') + '</p>')
    if not chs:
        groups = '<p class="empty">조건에 맞는 변경이 없습니다</p>'
    else:
        by_p: dict = {}
        for c in chs:
            by_p.setdefault(c["project"], []).append(c)
        parts = []

        def _tr(c, moved_from=None) -> str:
            a = acks.get(c["id"])
            state = (f'<span class="tag approved">확인</span> <span class="muted">{E(ack_label(a[-1]["by"]))}</span>'
                     if a else '<span class="tag pending">미확인</span>')
            pp = PurePosixPath(c["path"])
            head = (f"이전 자리: {moved_from} — 이름·위치만 바뀜(내용 동일)" if moved_from else (heads.get(c["id"]) or ""))
            kind = "이동" if moved_from else KIND_LABEL.get(c["kind"], c["kind"])
            return (f'<tr><td class="nw">{state}</td><td class="nw">{E(kind)}</td>'
                    f'<td class="name-c"><a href="/changes/{int(c["id"])}">{E(pp.name)}</a>'
                    + (f'<div class="muted">{E(head)}</div>' if head else "")
                    + f'</td><td class="path-c muted">{E(str(pp.parent))}</td>'
                    f'<td class="nw">{E(_local(c["detected_at"]))}</td>'
                    f'<td class="nw muted">#{int(c["id"])}</td></tr>')
        _thead = ('<thead><tr><th>상태</th><th>구분</th><th>파일 · 바뀐 것</th>'
                  '<th>폴더</th><th>검사</th><th>번호</th></tr></thead>')
        for proj in sorted(by_p, key=lambda x: (x == "미분류", x)):
            # 메일과 같은 규칙으로 접는다 — 폴더 이름 변경이 '삭제 2 + 추가 2'(미확인 4)로 보였다 (ux20 mail 9)
            main_, quiet_, moved_ = _fold(by_p[proj], notes)
            rows = sorted(main_, key=lambda c: (c["id"] in acks, -c["id"]))      # 미확인 먼저, 그 안에서 최근 것부터
            un = sum(1 for c in rows if c["id"] not in acks)
            trs = [_tr(c) for c in rows]
            qhtml = ""
            if quiet_:
                qrows = "".join(_tr(c, moved_.get(c["id"])) for c in sorted(quiet_, key=lambda c: -c["id"]))
                qhtml = (f'<details class="tool"><summary>그 밖의 알림 {len(quiet_)}건 — 이동·이름 변경, 다시 저장(내용 동일), '
                         f'복사본 같은 확인할 필요 없는 변경 (눌러서 펼치기)</summary>'
                         f'<div class="tablewrap"><table class="flist">{_thead}<tbody>{qrows}</tbody></table></div></details>')
            table = (f'<div class="tablewrap"><table class="flist">{_thead}<tbody>{"".join(trs)}</tbody></table></div>'
                     if trs else '<p class="muted">내용이 바뀐 변경은 없습니다 — 아래 그 밖의 알림만 있습니다.</p>')
            parts.append(f'<div class="panel"><h2>{E(proj)} <span class="muted">미확인 {un} · 보이는 변경 {len(rows)}'
                         + (f' · 그 밖의 알림 {len(quiet_)}' if quiet_ else "") + '</span></h2>'
                         f'{table}{qhtml}</div>')
        groups = "".join(parts)
        if more:
            groups += f'<p class="muted">최근 {LIST_MAX}건만 보입니다 — 프로젝트나 기간을 좁혀 보세요.</p>'
    h._send(200, h._shell("변경 확인", f'<div class="panel">{intro}{bar}</div>{groups}', active="/changes",
                          actions=f'<div class="pick">{acts}</div>'))


def _notes_of(st: State, ids) -> dict:
    """변경 id → '참고' 문구(이동·복사본·재저장 …) — 메일이 '그 밖의 알림'으로 접는 근거와 같은 것 (brief.note_of)."""
    out: dict = {}
    ids = [int(i) for i in ids]
    for k in range(0, len(ids), 400):
        part = ids[k:k + 400]
        for cid, js in st.conn.execute(
                f"SELECT change_id, items_json FROM change_details WHERE change_id IN ({','.join('?' * len(part))})", part):
            try:
                items = json.loads(js or "[]")
            except (ValueError, TypeError):
                continue
            for it in items if isinstance(items, list) else ():
                if isinstance(it, dict) and it.get("kind") == "CHECK_SKIPPED" and it.get("key") == "참고":
                    out[int(cid)] = str(it.get("new") or "")
                    break
    return out


def _fold(rows: list, notes: dict) -> tuple[list, list, dict]:
    """(주요 변경, 그 밖의 알림, {추가 쪽 id: 이전 경로}) — brief.arrange_changes를 그대로 쓴다(메일과 같은 접기).
    이동 짝의 삭제 쪽은 빠지고 추가 쪽 한 줄이 '이동'으로 남는다. 내용이 바뀐 변경은 접지 않는다(원칙 5)."""
    from types import SimpleNamespace
    from watcher.brief import arrange_changes
    from watcher.diff import ChangeItem
    objs = [SimpleNamespace(id=c["id"], kind=c["kind"], path=c["path"], row=c) for c in rows]
    by_id = {o.id: ([ChangeItem("CHECK_SKIPPED", "참고", None, notes[o.id], "")] if notes.get(o.id) else []) for o in objs}
    try:
        main, quiet, moved = arrange_changes(objs, {}, by_id)
    except Exception:                       # noqa: BLE001 — 접기에 실패하면 전처럼 모두 보인다
        return list(rows), [], {}
    mv = {}
    for o in quiet:
        if id(o) in moved:
            mv[o.id] = moved[id(o)]
    return [o.row for o in main], [o.row for o in quiet], mv


def _open_issue_count(st: State, scope, p: str) -> int:
    rows = st.conn.execute("SELECT IFNULL(project, '미분류'), COUNT(*) FROM issues WHERE resolved_at IS NULL "
                           "GROUP BY 1").fetchall()
    return sum(n for proj, n in rows if _in(scope, proj) and (not p or proj == p))


# ── /changes/<번호> — 근거·사진·확인 ───────────────────────────────────────────

def _change_id(h) -> int:
    S = _S()
    raw = getattr(h, "path_change_id", "") or S.FormsHandler._one(h._query(), "id")
    try:
        return S.FormsHandler._int(raw)
    except S.HttpError:
        raise S.HttpError(404)


def _row_of(st: State, cid: int) -> dict | None:
    row = st.conn.execute("SELECT id, snapshot_id, kind, path, old_sha256, new_sha256, detected_at, IFNULL(project, '미분류') "
                          "FROM changes WHERE id = ?", (cid,)).fetchone()
    if row is None:
        return None
    return dict(zip(("id", "snapshot_id", "kind", "path", "old_sha256", "new_sha256", "detected_at", "project"), row))


def _cap_keys(caps) -> list[str]:
    """사진 열쇠 차례 — /changes/img?k=번호가 가리키는 자리 (전/후 사진 묶음만)."""
    if not isinstance(caps, dict):
        return []
    return sorted(k for k, v in caps.items() if isinstance(k, str) and isinstance(v, dict)
                  and (isinstance(v.get("before"), dict) or isinstance(v.get("after"), dict) or v.get("b64")))


def _cap_key_of(caps: dict, it) -> str | None:
    for k in (f"{it.kind}|{it.key}|{it.where}", f"{it.kind}|{it.key}", str(it.key)):
        v = caps.get(k)
        if isinstance(v, dict) and (isinstance(v.get("before"), dict) or isinstance(v.get("after"), dict) or v.get("b64")):
            return k
    return None


def _sides(cap: dict) -> list[tuple[str, dict]]:
    if "after" in cap or "before" in cap:
        return [(s, cap[s]) for s in ("before", "after") if isinstance(cap.get(s), dict) and cap[s].get("b64")]
    return [("after", cap)] if cap.get("b64") else []


def _item_cells(it) -> tuple[str, str, str, str]:
    """(구분, 항목, 이전, 새 값) 글자 — 메일·화면과 같은 이름 함수."""
    from watcher.brief import _flabel, _fmt_row_values, fmt_val, item_kind_label, notice_text
    kind = str(it.kind or "")
    lab = item_kind_label(it)        # 발주 후 변경 표지는 공용 '검사 한계'가 아니라 '발주 대조' (ux21 mail 1)
    if kind == "ROW_CHANGED":
        rk, _, col = str(it.key).rpartition(".")
        name = f"{rk or it.key} · {col}" + (f" ({it.label})" if it.label else "")
        return lab, name, fmt_val(it.old), fmt_val(it.new)
    if kind in ("ROW_ADDED", "ROW_REMOVED"):
        name = str(it.key) + (f" ({it.label})" if it.label else "")
        return lab, name, _fmt_row_values(it.old) if it.old else "—", _fmt_row_values(it.new) if it.new else "—"
    if kind == "CHECK_SKIPPED":
        return lab, str(it.key), "—", notice_text(it, full=True)
    g = not kind.startswith(("TEXT_", "FIELD_"))
    return lab, _flabel(it), fmt_val(it.old, g), fmt_val(it.new, g)


def _tag_class(kind: str) -> str:
    if kind.endswith(("ADDED",)):
        return "k-add"
    if kind.endswith(("REMOVED",)):
        return "k-rm"
    if kind in ("CHECK_SKIPPED", "NEW_REVISION_OF") or kind.endswith("MOVED"):
        return "k-info"
    return "k-mod"


def _not_here(h, scope) -> None:
    """없는 변경과 범위 밖 변경은 **같은 응답** — '없는 화면입니다' + 내가 볼 수 있는 프로젝트 한 줄 (ux20 mail 결정 재검토).
    그 변경이 있는지·어느 프로젝트인지는 드러내지 않는다: 줄에 실리는 것은 이 계정의 범위뿐이고 요청한 번호와 무관하다."""
    S = _S()
    mine = ("모든 프로젝트" if scope is None else ", ".join(sorted(scope)))
    body = (f'<div class="note bad" role="alert">{E(S._ERROR_TEXT.get(404, "없는 화면입니다"))}</div>'
            f'<p>이 계정이 변경을 볼 수 있는 프로젝트: <b>{E(mine)}</b></p>'
            f'<p class="muted">메일의 링크가 열리지 않으면 다른 프로젝트의 변경이거나 이미 정리된 기록일 수 있습니다 — '
            f'더 넓게 보려면 관리자에게 열람 범위를 부탁하세요.</p>'
            f'<p><a class="btn gray" href="/changes">변경 확인 목록으로</a></p>')
    h.close_connection = True
    h._send(404, h._shell("할 수 없습니다", body, active="/changes"))


@_guarded
def get_change_item(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    cid = _change_id(h)
    S = _S()
    from watcher.brief import human_ev, no_bidi, plain_where
    from watcher.change_ledger import doc_facts
    from watcher.diff import ChangeItem
    with w.session() as st:
        c = _row_of(st, cid)
        if c is None or not _in(scope, c["project"]):
            _not_here(h, scope)
            return
        detail = st.change_detail(cid)
        acks = st.acks_of(cid)
        mt_new, mt_old = st.change_mtimes(cid)
        sha = c["old_sha256"] if c["kind"] == "removed" else c["new_sha256"]
        facts = doc_facts(st, [sha]).get(sha) or {}
        iss = st.conn.execute("SELECT code, message, evidence, detected_at FROM issues WHERE path = ? AND resolved_at IS NULL "
                              "ORDER BY id DESC LIMIT 10", (c["path"],)).fetchall()
    pp = PurePosixPath(c["path"])
    meta = [f'프로젝트 <b>{E(c["project"])}</b>', f'구분 <b>{E(KIND_LABEL.get(c["kind"], c["kind"]))}</b>',
            f'검사 {E(_local(c["detected_at"]))}']
    if facts.get("dwg"):
        meta.append(f'도면/문서번호 <b>{E(facts["dwg"])}</b>')
    if facts.get("rev"):
        meta.append(f'Rev <b>{E(facts["rev"])}</b>')
    if mt_new and c["kind"] != "removed":
        meta.append(f'저장 {E(_mtime(mt_new))}' + (f' · 저장자 {E(facts["saved_by"])}' if facts.get("saved_by") else "")
                    + (f' <span class="muted">(이전 판 {E(_mtime(mt_old))})</span>' if mt_old else ""))
    head = (f'<div class="panel"><div class="crumb"><a href="/changes">변경 확인</a> › '
            f'<a href="/changes?p={quote(c["project"])}">{E(c["project"])}</a> › {E(no_bidi(str(pp.parent)))}</div>'
            f'<div class="cmp-head"><b>{E(no_bidi(pp.name))}</b><span class="muted">#{cid}</span></div>'
            f'<p class="muted">{" · ".join(meta)}</p></div>')
    # 근거 표 — 숨긴 오탐은 뺀다(감시 PC에서 숨긴 것)
    body = ""
    if detail is None:
        why = ("삭제된 파일은 내용 비교가 없습니다." if c["kind"] == "removed" else
               "이전 판이 없는 새 파일이라 비교할 대상이 없습니다." if c["kind"] == "added" else
               "이 변경에는 내용 비교 기록이 없습니다 (내용을 읽지 못하는 형식이거나 보존 기간이 지나 정리됨).")
        body += f'<div class="panel"><p class="muted">{E(why)} 원본 확인은 감시 PC나 공유 폴더에서 하세요.</p></div>'
    else:
        caps = detail.get("captures") or {}
        keys = _cap_keys(caps)
        dismissed = detail.get("dismissed") or {}
        items = []
        for ix, d in enumerate(detail.get("items") or []):
            if str(ix) in dismissed or not isinstance(d, dict):
                continue
            try:
                items.append(ChangeItem(**{k: d.get(k) for k in ("kind", "key", "old", "new", "where", "label")}))
            except TypeError:
                continue
        # 진짜 바뀐 글자·그림 먼저, 표제란 칸·개정표 행은 뒤 (화면·메일과 같은 차례)
        items.sort(key=lambda i: 1 if (i.kind == "FIELD_CHANGED" or str(i.kind).startswith("REVROW_")) else 0)
        omitted = max(0, len(items) - ITEM_MAX)
        trs, photos = [], 0
        for it in items[:ITEM_MAX]:
            lab, name, old, new = _item_cells(it)
            trs.append(f'<tr><td class="nw"><span class="tag {_tag_class(str(it.kind))}">{E(lab)}</span></td>'
                       f'<td class="name">{E(no_bidi(name))}</td><td class="val"><del class="old">{E(no_bidi(old))}</del></td>'
                       f'<td class="val"><ins class="new">{E(no_bidi(new))}</ins></td>'
                       f'<td class="muted">{E(no_bidi(plain_where(it.where or "")))}</td></tr>')
            k = _cap_key_of(caps, it)
            if k is not None and photos < PHOTO_MAX:
                photos += 1
                n = keys.index(k)
                figs = "".join(
                    f'<figure class="{side}"><figcaption>{"변경 전" if side == "before" else "변경 후"}</figcaption>'
                    f'<img src="/changes/img?id={cid}&amp;k={n}&amp;s={side}" loading="lazy" '
                    # 사진 설명은 위치 표기 — 근거 표·감시 화면·메일과 같은 말로, 저장된 caption은 그대로 (ux22 K)
                    f'alt="{"변경 전" if side == "before" else "변경 후"} — {E(no_bidi(plain_where(cap.get("caption"))))}">'
                    f'<span class="muted">{E(no_bidi(plain_where(cap.get("caption"))))}</span></figure>'
                    for side, cap in _sides(caps[k]))
                if figs:
                    trs.append(f'<tr><td colspan="5"><div class="cap">{figs}</div></td></tr>')
        if trs:
            body += (f'<div class="panel"><h2>바뀐 내용 — 근거</h2><p class="muted">이전 값 / 새 값 / 위치는 감시가 파일에서 읽은 그대로입니다. '
                     f'사진의 빨간 네모가 바뀐 자리입니다(두 장이면 왼쪽이 이전 판). 옳고 그름은 판단하지 않습니다.</p>'
                     f'<div class="tablewrap"><table class="cmp"><thead><tr><th>구분</th><th>항목</th><th>이전</th><th>새 값</th>'
                     f'<th>위치</th></tr></thead><tbody>{"".join(trs)}</tbody></table></div>'
                     + (f'<p class="muted">외 {omitted}건 생략 — 감시 PC 화면에 전부 있습니다.</p>' if omitted else "")
                     + '</div>')
        else:
            body += '<div class="panel"><p class="muted">기록된 상세 항목이 없습니다.</p></div>'
    if iss:
        from watcher.consistency import CODE_LABEL
        lis = []
        for code, msg, ev, at in iss:
            try:
                evs = json.loads(ev or "[]")
            except ValueError:
                evs = []
            lis.append(f'<li><b>{E(CODE_LABEL.get(code, code))}</b> — {E(no_bidi(msg))} <span class="muted">({E(_local(at, "%m-%d"))} 생김)</span>'
                       + ('<ul class="notes">' + "".join(f'<li>{E(no_bidi(human_ev(str(x))))}</li>' for x in evs[:4]) + '</ul>'
                          if evs else "") + '</li>')
        body += (f'<div class="panel"><h2>이 파일에 열린 검토 필요 {len(iss)}건</h2><ul class="lines">{"".join(lis)}</ul>'
                 f'<p class="muted">[처리함]·숨기기는 감시 PC 화면에서 합니다.</p></div>')
    # 확인
    s = h.sess
    who = lan_ack_by(s.display_name, s.login)
    if acks:
        hist = "".join(f'<li><span class="tag approved">확인</span> {E(ack_label(a["ack_by"]))}'
                       + (f' — {E(a["ack_note"])}' if a["ack_note"] else "")
                       + f' <span class="muted">({E(_local(a["ack_at"]))})</span></li>' for a in acks)
        ack_hist = f'<ul class="lines">{hist}</ul>'
    else:
        ack_hist = '<p class="muted">아직 아무도 확인하지 않았습니다.</p>'
    form = (f'<form method="post" action="/changes/ack" class="pick">{S._hidden(h)}'
            f'<input type="hidden" name="id" value="{cid}">'
            f'<input type="text" name="note" maxlength="{NOTE_MAX}" class="memo" placeholder="한 줄 메모 (선택)" aria-label="메모">'
            f'<button class="btn" type="submit">{"확인 추가" if acks else "확인함"}</button></form>'
            f'<p class="hint">감시 기록에 <b>{E(who)}</b>(으)로 남고, 감시 PC 화면에는 \'사내망에서 확인: {E(s.display_name)}\'로 보입니다. '
            f'확인 기록은 지워지지 않습니다 — 잘못 눌렀으면 \'정정\' 메모로 새 확인을 남기세요. 메모 {NOTE_MAX}자까지.</p>')
    # 공용 PC — 로그아웃하지 않으면 다음 사람의 확인이 앞 사람 이름으로 남았다 (ux20 mail 6). 세션 시간은 그대로 두고 알린다
    shared = (f'<div class="note warn" role="note">여러 사람이 함께 쓰는 PC라면 다 본 뒤 [로그아웃]을 누르세요 — 지금은 '
              f'<b>{E(s.display_name or s.login)}</b>(으)로 로그인되어 있어, 다른 사람이 누른 [확인함]도 이 이름으로 남습니다. '
              f'<form method="post" action="/logout" class="inline">{S._hidden(h)}'
              f'<button class="btn gray sm" type="submit">로그아웃</button></form></div>')
    body += f'<div class="panel"><h2>확인</h2>{ack_hist}{form}{shared}</div>'
    h._send(200, h._shell(f"변경 #{cid}", head + body, active="/changes"))


# ── /changes/img — 전/후 사진 (state.db captures) ─────────────────────────────────

@_guarded
def get_change_img(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    q = h._query()
    try:
        cid = S.FormsHandler._int(S.FormsHandler._one(q, "id"))
        k = S.FormsHandler._int(S.FormsHandler._one(q, "k"))
    except S.HttpError:
        raise S.HttpError(404)
    side = S.FormsHandler._one(q, "s")
    if side not in ("before", "after"):
        raise S.HttpError(404)
    with w.session() as st:
        c = _row_of(st, cid)
        if c is None or not _in(scope, c["project"]):
            raise S.HttpError(404)
        detail = st.change_detail(cid) or {}
    caps = detail.get("captures") or {}
    keys = _cap_keys(caps)
    if k >= len(keys):
        raise S.HttpError(404)
    got = dict(_sides(caps[keys[k]])).get(side)
    if not got:
        raise S.HttpError(404)
    mime = str(got.get("mime") or "").lower()
    if mime not in _IMG_SIG:                      # PNG·JPEG만 — SVG·HTML 같은 것은 내지 않는다
        raise S.HttpError(404)
    b64 = str(got.get("b64") or "")
    if len(b64) > IMG_MAX * 4 // 3 + 4:
        raise S.HttpError(404)
    try:
        data = base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        raise S.HttpError(404)
    if not data.startswith(_IMG_SIG[mime]):      # 머리 글자(시그니처)가 형식과 맞을 때만
        raise S.HttpError(404)
    h._deadline(len(data))
    h._send(200, data, mime, extra=(("Content-Disposition", "inline"),))


# ── /changes/issues — 열린 검토 필요 (읽기만) ─────────────────────────────────────

@_guarded
def get_change_issues(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    S = _S()
    q = h._query()
    p = S.FormsHandler._one(q, "p").strip()
    path = S.FormsHandler._one(q, "f").strip()
    from watcher.brief import human_ev, no_bidi
    from watcher.consistency import CODE_LABEL
    with w.session() as st:
        sql = ("SELECT id, code, path, IFNULL(project, '미분류'), message, evidence, detected_at FROM issues "
               "WHERE resolved_at IS NULL")
        args: list = []
        if path:
            sql += " AND path = ?"
            args.append(path)
        rows = [r for r in st.conn.execute(sql + " ORDER BY id DESC LIMIT 2000", args).fetchall()
                if _in(scope, r[3]) and (not p or r[3] == p)][:500]
        links = st.changes_for_paths([r[2] for r in rows]) if rows else {}
        link_proj = {}
        for cid_ in set(links.values()):
            rr = _row_of(st, int(cid_))
            if rr:
                link_proj[int(cid_)] = rr["project"]
    items = []
    for _iid, code, ipath, proj, msg, ev, at in rows:
        try:
            evs = json.loads(ev or "[]")
        except ValueError:
            evs = []
        cid = links.get(ipath)
        go = (f' <a class="btn gray sm" href="/changes/{int(cid)}">전/후 보기</a>'
              if cid is not None and _in(scope, link_proj.get(int(cid))) else "")
        items.append(f'<div class="panel"><b>{E(CODE_LABEL.get(code, code))}</b> '
                     f'<span class="tag off">{E(proj)}</span> <span class="muted">{E(no_bidi(PurePosixPath(ipath).name))} · '
                     f'{E(_local(at, "%m-%d"))} 생김</span>{go}'
                     f'<p>{E(no_bidi(msg))}</p>'
                     + ('<ul class="notes">' + "".join(f'<li>{E(no_bidi(human_ev(str(x))))}</li>' for x in evs[:8])
                        + (f'<li>외 {len(evs) - 8}줄</li>' if len(evs) > 8 else "") + '</ul>' if evs else "")
                     + '</div>')
    lead = ('<div class="note info">일관성 검사(Rev 미갱신·도면 간 불일치·도면-BOM 불일치)가 잡은 확인할 거리입니다. 옳고 그름은 판단하지 '
            '않습니다. <b>[처리함]·숨기기는 감시 PC 화면에서</b> 합니다 — 여기서는 보기만 합니다.</div>')
    if path:
        lead += f'<p class="muted">파일: {E(no_bidi(path))} — <a href="/changes/issues">전체 보기</a></p>'
    body = lead + ("".join(items) if items else '<p class="empty">열린 검토 필요가 없습니다</p>')
    h._send(200, h._shell("검토 필요 (읽기만)", body, active="/changes",
                          actions='<a class="btn gray" href="/changes">변경 확인으로</a>'))


# ── [확인함 + 메모] — state.db acks 한 줄 ─────────────────────────────────────────

def post_change_ack(h) -> None:
    S = _S()
    f = h._read_form()
    h._check_token(f)
    scope = _scope(h)
    w = _watch(h)
    try:
        cid = S.FormsHandler._int(S.FormsHandler._one(f, "id"))
    except S.HttpError:
        raise S.HttpError(404)
    note = clean_ack_text(S.FormsHandler._one(f, "note"))     # 제어 문자 지운 뒤 접기 — 감시 PC 입구와 같은 정리 (rr066 lan 1)
    if len(note) > NOTE_MAX:
        raise S.HttpError(400, f"메모는 {NOTE_MAX}자까지입니다")
    s = h.sess
    by = lan_ack_by(s.display_name, s.login)
    try:
        with w.session() as st:
            c = _row_of(st, cid)
            if c is None or not _in(scope, c["project"]):
                raise S.HttpError(404)
            ok = st.add_ack(cid, by, note)       # INSERT 한 줄 + commit — 짧은 트랜잭션
    except WatchBusy:
        h._flash("bad", BUSY_TEXT + " (확인은 아직 남지 않았습니다)")
        h._redirect(f"/changes/{cid}")
        return
    except WatchUnavailable as e:
        _unavailable(h, str(e))
        return
    if not ok:
        raise S.HttpError(404)
    try:
        h.server.store.record_audit(s.user_id, "change_ack", f"change:{cid}", ip=h.ip,
                                    detail=f"{c['project']} · {PurePosixPath(c['path']).name}" + (f" — {note}" if note else ""))
    except Exception:
        pass
    h._flash("ok", f"#{cid} 확인을 남겼습니다 — 감시 PC 화면에도 '사내망에서 확인: {s.display_name}'로 보입니다. "
                   "여러 사람이 쓰는 PC라면 다 본 뒤 [로그아웃]을 누르세요")
    h._redirect(f"/changes/{cid}")


# ── 설계 변경 대장 엑셀 (자기 범위) ───────────────────────────────────────────────

@_guarded
def get_changes_xlsx(h) -> None:
    scope = _scope(h)
    w = _watch(h)
    f = _filters(h, scope)
    from watcher.change_ledger import ledger_rows, ledger_xlsx, scope_text
    projs = _scope_set(scope, f["p"])
    with w.session() as st:
        rows = ledger_rows(st, projects=projs, date_from=f["from"], date_to=f["to"], photo_note="사내망 화면에서")
    data = ledger_xlsx(rows, scope_text=scope_text(projs, f["from"], f["to"]))
    S = _S()
    name = f"설계변경대장_{date.today():%Y%m%d}" + (f"_{f['p']}" if f["p"] else "") + ".xlsx"
    try:
        h.server.store.record_audit(h.sess.user_id, "changes_export", "changes", ip=h.ip,
                                    detail=f"{name} — 변경 {sum(1 for r in rows if isinstance(r[0], int))}건 · "
                                           f"범위 {scope_text(projs, f['from'], f['to'])}"[:500])
    except Exception:
        pass
    h._deadline(len(data))
    h._send(200, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            extra=(("Content-Disposition", S.content_disposition(name, "design-change-ledger.xlsx")),))
    h.close_connection = True


# ── 관리자: 계정의 변경 브리핑 열람 ─────────────────────────────────────────────

def access_cell(h, u: dict) -> str:
    """계정 목록의 '변경 열람' 칸."""
    if u.get("role") == "admin":
        return '<span class="muted">관리자 — 전체</span>'
    acc = access_of(h.server.store, u["id"])
    tag = (f'<span class="tag approved">{E(access_text(acc))}</span>' if acc is not None else '<span class="tag off">끔</span>')
    return f'{tag} <a href="/admin/users/changes?id={int(u["id"])}">바꾸기</a>'


@_guarded
def get_admin_access(h) -> None:
    S = _S()
    S._require_admin(h)
    w = _watch(h)
    uid = S.FormsHandler._int(S.FormsHandler._one(h._query(), "id"))
    store = h.server.store
    u = store.get_user(uid)
    if not u:
        raise S.HttpError(404)
    name = f'{u.get("display_name") or ""} ({u.get("login")})'
    if u.get("role") == "admin":
        body = (f'<div class="panel"><p>{E(name)}은(는) 관리자라 늘 모든 프로젝트의 변경을 봅니다.</p>'
                f'<p><a class="btn gray" href="/admin/users">계정 목록으로</a></p></div>')
        h._send(200, h._shell("변경 브리핑 열람", body, active="/admin/users"))
        return
    acc = access_of(store, uid)
    try:
        with w.session() as st:
            projs = _projects(st, None)
        why = ""
    except (WatchUnavailable, WatchBusy) as e:
        projs, why = [], str(e)
    if isinstance(acc, frozenset):
        projs = sorted(set(projs) | set(acc))
    every, sug = suggested(w.recipients(), u.get("email") or "", projs)
    sug = [p for p in sug if p in projs] if projs else sug
    pre_all = acc == "all" or (acc is None and every)
    pre = set(acc) if isinstance(acc, frozenset) else (set(sug) if acc is None else set())
    note = ""
    if acc is None and (every or sug):
        note = ('<div class="note info">이 계정의 메일(' + E(u.get("email") or "") + ')이 감시 브리핑 메일을 '
                + ("모든 프로젝트로" if every else f'프로젝트 {E(", ".join(sug))}로') + ' 받고 있어 그 범위를 미리 골라 두었습니다 — '
                '<b>[저장]을 눌러야 적용됩니다</b>.</div>')
    if why:
        note += f'<div class="note warn">감시 기록을 열 수 없어 프로젝트 목록을 보이지 못합니다 — {E(why)}</div>'
    boxes = "".join(f'<label class="chk"><input type="checkbox" name="p" value="{E(p)}"{" checked" if p in pre else ""}>'
                    f'{E(p)}</label>' for p in projs) or '<p class="muted">아직 감시 기록에 프로젝트가 없습니다.</p>'
    body = (f'<div class="panel"><h2>{E(name)}</h2>{note}'
            f'<p class="muted">켜면 이 계정이 양식함 메뉴의 [변경 확인]에서 고른 범위의 변경 근거·전/후 사진·검토 필요를 보고 [확인함]을 '
            f'남길 수 있습니다. 설정·검사·닫기는 감시 PC에서만 합니다. 지금: <b>{E(access_text(acc))}</b></p>'
            f'<form method="post" action="/admin/users/changes">{S._hidden(h)}<input type="hidden" name="id" value="{uid}">'
            f'<label class="chk"><input type="checkbox" name="on" value="1"{" checked" if (acc is not None or every or sug) else ""}>'
            f'변경 브리핑 열람 켜기</label>'
            f'<h3>범위</h3><label class="chk"><input type="radio" name="scope" value="all"{" checked" if pre_all else ""}>'
            f'모든 프로젝트</label><label class="chk"><input type="radio" name="scope" value="pick"'
            f'{"" if pre_all else " checked"}>고른 프로젝트만</label>'
            f'<div class="cols">{boxes}</div>'
            f'<div class="form-actions"><button class="btn" type="submit">저장</button>'
            f'<a class="btn gray" href="/admin/users">계정 목록으로</a></div></form></div>')
    h._send(200, h._shell("변경 브리핑 열람", body, active="/admin/users"))


def post_admin_access(h) -> None:
    S = _S()
    S._require_admin(h)
    _watch(h)
    f = h._read_form()
    h._check_token(f)
    uid = S.FormsHandler._int(S.FormsHandler._one(f, "id"))
    on = S.FormsHandler._one(f, "on") == "1"
    all_ = S.FormsHandler._one(f, "scope") == "all"
    msg = set_access(h.server.store, h.sess.user_id, uid, on=on, all_=all_, projects=f.get("p") or [], ip=h.ip)
    h._flash("ok", msg)
    h._redirect("/admin/users")


ROUTES_GET = {
    "/changes": get_changes, "/changes/item": get_change_item, "/changes/img": get_change_img,
    "/changes/issues": get_change_issues, "/changes.xlsx": get_changes_xlsx, "/admin/users/changes": get_admin_access,
}
ROUTES_POST = {"/changes/ack": post_change_ack, "/admin/users/changes": post_admin_access}
CHANGE_PATH = re.compile(r"/changes/(\d{1,12})")
