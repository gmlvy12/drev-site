# -*- coding: utf-8 -*-
"""양식함 기록 보존 만료 (2026-10-30 사용자 결정 ③ — FORMS.md 7-2절, DECISIONS 같은 날).

지금까지는 폐기한 양식과 지난 판을 영원히 남겼다. ISO 문서 관리처럼 '몇 년 보존한 뒤 정리'를 고를 수 있게 한다.
**기본은 영구 보존** — 설정하지 않으면 아무것도 바뀌지 않는다. **아무것도 저절로 지우지 않는다** — 관리자가 화면에서
보존 기간이 지난 판을 골라 [정리하기] → 확인(지운다는 목록 + 지문) → 실행해야 지운다.

- 정책: forms.db meta — keep_superseded_years(지난 판 보존 연수)·keep_retired_years(폐기 양식 보존 연수), 0 = 영구, 1~50.
  문서 종류마다 덮어쓰기: doc_types.keep_years(NULL = 전체 기본값, 0 = 영구) — 그 종류 양식의 두 규칙 모두에 쓴다.
- 만료일:
  · 지난 판: 그 판을 대신한 판(다음 판 번호)의 승인일 + 지난 판 보존 연수
  · 폐기된 양식의 판(현행 판 포함 모두): 폐기한 날 + 폐기 양식 보존 연수
  · 둘 다 걸리면 **먼저 오는 날** — 폐기가 보존을 늘리지는 않는다. 0(영구)인 규칙은 걸리지 않는다
  · 쓰는 중인 양식의 현행 판은 만료되지 않는다. 복원한(폐기를 푼) 양식은 폐기 규칙에서 빠진다
  · 검토 대기·반려 파일은 따로(90일 정리 — store.purge_pending) — 여기서 보지 않는다
- 정리: 판 파일을 guard로 지운다(올린 때 지문과 같을 때만 — Drev가 둔 그 파일만). 행·지문은 남기고 versions.purged_at·purged_by를 적고
  감사 기록(retention_purge) 한 줄. 파일이 이미 없으면(판 칸 폴더는 있음) 그래도 '정리됨'으로 적고 그렇게 알린다. 지문이 다르면
  지우지도 적지도 않는다. 보관소 폴더가 없으면(옮김·공유 끊김) 통째로 거부하고, 판 칸 폴더까지 없는 판은 '못 지움'으로 남긴다.
  지운 뒤 기록이 실패하면 지운 판을 로그에 남기고 화면에 '일부 파일은 이미 지워졌을 수 있습니다'라고 알린다 (2026-10-30 검토).
- 만료일의 2월 29일 + n년이 평년이면 3월 1일(적어도 n년).
- 백업 사본은 다음 백업이 지운다(backup.py), 복원은 정리된 판을 되살리지 않는다.
- 이 모듈은 파일 쓰기 API를 쓰지 않는다 — 지우기는 store.guard(guard.py)만 (tests/test_readonly.py 엄격 검사).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
from datetime import date

from watcher.forms.guard import GuardError
from watcher.forms.store import (PENDING_DIR, Conflict, FormsStore, InvalidInput, day_of, now_text)

log = logging.getLogger("drev.forms.server")

KEEP_MIN, KEEP_MAX = 0, 50                 # 0 = 영구 보존
META_SUPERSEDED = "keep_superseded_years"
META_RETIRED = "keep_retired_years"
PURGE_MAX = 500                            # 한 번에 정리할 수 있는 판 수 (한 쪽 200줄 + 여유)
HINT_YEARS = f"{KEEP_MIN}~{KEEP_MAX} (0 = 영구 보존) — 숫자만"
HINT_TYPE_YEARS = f"비우면 위 기본값을 따름 · {KEEP_MIN}~{KEEP_MAX} (0 = 영구 보존)"
WHY_LABEL = {"superseded": "지난 판", "retired": "폐기한 양식"}


def clean_years(value, what: str = "보존 연수") -> int:
    """화면·설정에서 받은 연수 → 0~50 정수. 아니면 InvalidInput(쉬운 말)."""
    s = str(value if value is not None else "").strip()
    if not s or not (s.isascii() and s.isdigit()) or len(s) > 3:
        raise InvalidInput(f"{what}은(는) {KEEP_MIN}~{KEEP_MAX} 사이 숫자로 적어 주세요 (0 = 영구 보존)")
    n = int(s)
    if not KEEP_MIN <= n <= KEEP_MAX:
        raise InvalidInput(f"{what}은(는) {KEEP_MIN}~{KEEP_MAX} 사이로 적어 주세요 (0 = 영구 보존)")
    return n


def _meta_years(raw) -> int:
    try:
        return clean_years(raw)
    except InvalidInput:
        return 0                          # 없거나 깨졌으면 영구(기본) — 잘못된 값으로 지우게 되지 않게


def policy(store: FormsStore) -> dict:
    """지금 정책 {superseded, retired, forever(둘 다 0이고 종류 덮어쓰기도 없음)}."""
    rows = {r[0]: r[1] for r in store.conn.execute(
        "SELECT key, value FROM meta WHERE key IN (?, ?)", (META_SUPERSEDED, META_RETIRED)).fetchall()}
    sup, ret = _meta_years(rows.get(META_SUPERSEDED)), _meta_years(rows.get(META_RETIRED))
    typed = store.conn.execute("SELECT COUNT(*) FROM doc_types WHERE keep_years IS NOT NULL AND keep_years > 0"
                               ).fetchone()[0]
    return {"superseded": sup, "retired": ret, "forever": not sup and not ret and not typed}


def _years_text(n) -> str:
    return "영구" if not n else f"{int(n)}년"


def _type_years_text(n) -> str:
    return "기본값 따름" if n is None else _years_text(n)


def set_policy(store: FormsStore, actor_id, superseded, retired, *, ip=None) -> dict:
    """전체 기본값 저장 — 관리자만. 감사 기록 retention_policy(이전 → 새). 돌려줌: 저장한 정책."""
    sup = clean_years(superseded, "지난 판 보존 연수")
    ret = clean_years(retired, "폐기 양식 보존 연수")
    with store.tx() as c:
        actor = store._actor(actor_id)
        store._require_admin(actor)
        old = policy(store)
        if (old["superseded"], old["retired"]) == (sup, ret):
            return old
        c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (META_SUPERSEDED, str(sup)))
        c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (META_RETIRED, str(ret)))
        store._audit(actor, "retention_policy", "retention", ip,
                     f"지난 판 {_years_text(old['superseded'])} → {_years_text(sup)}, "
                     f"폐기 양식 {_years_text(old['retired'])} → {_years_text(ret)} — 지우기는 관리자가 [정리하기]로만")
        return policy(store)


def set_type_years(store: FormsStore, actor_id, type_id, years, *, ip=None) -> bool:
    """문서 종류의 보존 연수 — 관리자만. years가 빈 글자·None이면 전체 기본값을 따른다(NULL). 바뀌었으면 True."""
    raw = "" if years is None else str(years).strip()
    n = None if raw == "" else clean_years(raw, "종류 보존 연수")
    with store.tx() as c:
        actor = store._actor(actor_id)
        store._require_admin(actor)
        t = store._doc_type(type_id)
        old = t["keep_years"]
        if old == n:
            return False
        c.execute("UPDATE doc_types SET keep_years = ? WHERE id = ?", (n, t["id"]))
        store._audit(actor, "retention_type", f"doc_type:{t['id']}", ip,
                     f"{t['code']} {t['name']}: {_type_years_text(old)} → {_type_years_text(n)}")
        return True


def add_years(d: date, n: int) -> date:
    """d + n년 — 2월 29일은 평년이면 3월 1일 (보존은 적어도 n년이어야 한다 — 2월 28일이면 하루 모자란다, 2026-10-30 검토)."""
    y = d.year + int(n)                        # date.replace는 test_readonly 이름 검사에 걸린다 — 새로 만든다
    try:
        return date(y, d.month, d.day)
    except ValueError:
        return date(y, 3, 1)


def _candidates(store: FormsStore, ids=None) -> list:
    where, args = "v.purged_at IS NULL", []
    if ids is not None:
        ids = [int(i) for i in ids]
        if not ids:
            return []
        where += f" AND v.id IN ({','.join('?' * len(ids))})"
        args = ids
    return store.conn.execute(
        "SELECT v.id, v.form_id, v.number, v.path, v.filename, v.sha256, v.size, "
        "f.name AS form_name, f.doc_no, f.retired, f.retired_at, f.current_version_id, t.keep_years, "
        "(SELECT x.approved_at FROM versions x WHERE x.form_id = v.form_id AND x.number > v.number "
        " ORDER BY x.number LIMIT 1) AS ended_at "
        "FROM versions v JOIN forms f ON f.id = v.form_id LEFT JOIN doc_types t ON t.id = f.doc_type "
        f"WHERE {where}", args).fetchall()


def expiry_of(row, pol: dict) -> tuple | None:
    """판 한 줄의 (만료일, 까닭, 끝난 날) — 만료되지 않는 판이면 None. 까닭: superseded(지난 판) / retired(폐기한 양식)."""
    tk = row["keep_years"]
    years_s = pol["superseded"] if tk is None else int(tk)
    years_r = pol["retired"] if tk is None else int(tk)
    found = []
    current = row["id"] == row["current_version_id"]
    if not current and row["ended_at"] and years_s > 0:
        ended = day_of(row["ended_at"])
        if ended is not None:
            found.append((add_years(ended, years_s), "superseded", ended))
    if row["retired"] and row["retired_at"] and years_r > 0:
        ended = day_of(row["retired_at"])
        if ended is not None:
            found.append((add_years(ended, years_r), "retired", ended))
    return min(found) if found else None


def _row_dict(r, exp: tuple) -> dict:
    expires, why, ended = exp
    return {"id": r["id"], "form_id": r["form_id"], "form_name": r["form_name"], "doc_no": r["doc_no"] or "",
            "number": r["number"], "filename": r["filename"], "size": int(r["size"] or 0), "sha256": r["sha256"],
            "path": r["path"], "why": why, "why_label": WHY_LABEL[why], "ended": ended.isoformat(),
            "expires": expires.isoformat(), "retired": bool(r["retired"])}


def _expired_py(store: FormsStore, ids=None, today: date | None = None) -> list[dict]:
    """파이썬 기준 구현 — 판마다 expiry_of로 센다. 화면·정리는 SQL(_expired)을 쓰고, 시험이 둘을 대조한다 (2026-10-31)."""
    pol = policy(store)
    day = today or store.today()
    out = []
    for r in _candidates(store, ids):
        exp = expiry_of(r, pol)
        if exp is not None and exp[0] <= day:
            out.append(_row_dict(r, exp))
    out.sort(key=lambda d: (d["expires"], d["form_name"], d["number"], d["id"]))
    return out


# 만료일을 SQL 안에서 (2026-10-31 성능 — 전에는 판 15만 개를 파이썬 사전으로 만들어 쪽마다 2.5~4초·147MB, 저장소 잠금 안에서).
# 규칙은 expiry_of와 같다: 날짜는 앞 10자가 실제 있는 날(date(x) = x — SQLite는 2월 30일을 3월 2일로 넘기므로 되돌려 대조)일 때만,
# 'N years'는 SQLite도 2월 29일 + N년이 평년이면 3월 1일(add_years와 같음), 둘 다 걸리면 먼저 오는 날(같은 날이면 폐기 —
# 파이썬 튜플 비교 'retired' < 'superseded'와 같음), 0년(영구)은 걸리지 않는다. 차례도 같다(만료일, 양식 이름, 판 번호, id).
# 끝난 날(대신한 판의 승인일): 전체 목록은 창 함수(LEAD)로 한 번에, 고른 판만 볼 때는 판마다 다음 번호 하나만 찾는다.
# 날짜 셈 (두 질의가 같이 쓴다) — ed: 대신한 판의 승인일(현행 판이면 NULL), rd: 폐기한 날(폐기 양식만), ys·yr: 연수
_EXP_S = "CASE WHEN ys > 0 AND ed >= '0001' AND date(ed) = ed THEN date(ed, '+' || ys || ' years') END"
_EXP_R = "CASE WHEN yr > 0 AND rd >= '0001' AND date(rd) = rd THEN date(rd, '+' || yr || ' years') END"
_BY_R = "(exp_r IS NOT NULL AND (exp_s IS NULL OR exp_r <= exp_s))"
_YEARS = ("COALESCE(t.keep_years, :sup) AS ys, COALESCE(t.keep_years, :ret) AS yr, "
          "CASE WHEN f.retired THEN substr(f.retired_at, 1, 10) END AS rd")


def _expiry_sql(ids: bool) -> str:
    """고른 판(ids — :ids JSON)의 모든 칸과 expires·why·ended. 끝난 날은 판마다 다음 번호 하나만 찾는다."""
    assert ids
    return (
        "WITH c AS (SELECT v.id, v.form_id, v.number, v.path, v.filename, v.sha256, v.size, f.name AS form_name, f.doc_no, "
        f" f.retired, {_YEARS}, "
        " CASE WHEN v.id IS f.current_version_id THEN NULL ELSE substr((SELECT x.approved_at FROM versions x "
        "  WHERE x.form_id = v.form_id AND x.number > v.number ORDER BY x.number LIMIT 1), 1, 10) END AS ed "
        " FROM versions v JOIN forms f ON f.id = v.form_id LEFT JOIN doc_types t ON t.id = f.doc_type "
        " WHERE v.purged_at IS NULL AND v.id IN (SELECT value FROM json_each(:ids))), "
        f"e AS (SELECT c.*, {_EXP_S} AS exp_s, {_EXP_R} AS exp_r FROM c), "
        f"y AS (SELECT e.*, CASE WHEN {_BY_R} THEN exp_r ELSE exp_s END AS expires, "
        f" CASE WHEN {_BY_R} THEN 'retired' ELSE 'superseded' END AS why, CASE WHEN {_BY_R} THEN rd ELSE ed END AS ended "
        " FROM e WHERE exp_s IS NOT NULL OR exp_r IS NOT NULL) ")


# 전체 목록 — 좁은 칸만(id·크기·차례 열쇠), 끝난 날은 창 함수(LEAD)로 한 번에. 판 정보는 쪽마다 _expiry_sql(ids)로 다시 읽는다.
_ORDER_SQL = (
    "WITH nx AS (SELECT v.id, v.form_id, v.number, v.size, v.purged_at, "
    " LEAD(v.approved_at) OVER (PARTITION BY v.form_id ORDER BY v.number) AS ended_at FROM versions v), "
    f"c AS (SELECT nx.id, nx.number, nx.size, f.name AS form_name, {_YEARS}, "
    " CASE WHEN nx.id IS f.current_version_id THEN NULL ELSE substr(nx.ended_at, 1, 10) END AS ed "
    " FROM nx JOIN forms f ON f.id = nx.form_id LEFT JOIN doc_types t ON t.id = f.doc_type WHERE nx.purged_at IS NULL), "
    f"e AS (SELECT id, number, size, form_name, {_EXP_S} AS exp_s, {_EXP_R} AS exp_r FROM c), "
    f"y AS (SELECT id, number, size, form_name, CASE WHEN {_BY_R} THEN exp_r ELSE exp_s END AS expires FROM e) "
    "SELECT id, size FROM y WHERE expires <= :today ORDER BY expires, form_name, number, id")


def _sql_row_dict(r) -> dict:
    return {"id": r["id"], "form_id": r["form_id"], "form_name": r["form_name"], "doc_no": r["doc_no"] or "",
            "number": r["number"], "filename": r["filename"], "size": int(r["size"] or 0), "sha256": r["sha256"],
            "path": r["path"], "why": r["why"], "why_label": WHY_LABEL[r["why"]], "ended": r["ended"],
            "expires": r["expires"], "retired": bool(r["retired"])}


_ORDER = " ORDER BY expires, form_name, number, id"


def _expired(store: FormsStore, ids=None, today: date | None = None) -> list[dict]:
    """보존 기간이 지났고 정리 전인 판 — ids를 주면 그 판들만(없으면 전부). 만료일 차례. SQL로 센다."""
    with store._lock:
        if ids is None:
            ids = _expired_order(store, today)[0]
        ids = sorted({int(i) for i in ids})
        if not ids:
            return []
        pol = policy(store)
        rows = store.conn.execute(_expiry_sql(True) + "SELECT * FROM y WHERE expires <= :today" + _ORDER,
                                  {"sup": pol["superseded"], "ret": pol["retired"], "ids": json.dumps(ids),
                                   "today": (today or store.today()).isoformat()}).fetchall()
    return [_sql_row_dict(r) for r in rows]


def _expired_order(store: FormsStore, today: date | None = None) -> tuple:
    """(만료 판 id들(만료일 차례), 모두 합친 크기) — 양식 세대(판·양식·종류·보존 정책 쓰기)·오늘로 캐시한다.
    목록 쪽 나누기·전체 수·주간 알림이 같이 쓴다. 판 정보는 쪽마다 그 200개만 다시 읽는다(메모리에 사전을 쌓지 않는다)."""
    day = today or store.today()
    with store._lock:
        g = store._gens()

        def make():
            pol = policy(store)
            rows = store.conn.execute(
                _ORDER_SQL,
                {"sup": pol["superseded"], "ret": pol["retired"], "today": day.isoformat()}).fetchall()
            return tuple(r[0] for r in rows), sum(int(r[1] or 0) for r in rows)
        return store._cached(("expired",), (g[2], g[3], day.isoformat()), make)


def expired_versions(store: FormsStore, actor_id, *, today: date | None = None, limit: int | None = None,
                     offset: int = 0) -> list[dict]:
    """보존 기간이 지났고 아직 정리하지 않은 판 — 관리자만, 읽기만. 만료일 차례. limit·offset: 쪽 나누기 (2026-10-31)."""
    store._require_admin(store._actor(actor_id))
    with store._lock:
        order, _size = _expired_order(store, today)
        ids = order[max(0, int(offset)):] if limit is None else order[max(0, int(offset)):max(0, int(offset)) + int(limit)]
        if not ids:
            return []
        rows = {r["id"]: r for r in _expired(store, ids, today)}
    return [rows[i] for i in ids if i in rows]


def expired_summary(store: FormsStore, *, today: date | None = None) -> tuple[int, int]:
    """(보존 기간 지난 판 수, 그 크기 합) — 목록 제목·쪽 나누기용."""
    order, size = _expired_order(store, today)
    return len(order), size


def expired_count(store: FormsStore, *, today: date | None = None) -> int:
    """주간 알림용 수 (권한 없이 — 관리자에게만 싣는다)."""
    return len(_expired_order(store, today)[0])


def _digest(pol: dict, rows: list) -> str:
    blob = json.dumps([pol["superseded"], pol["retired"],
                       [(r["id"], r["sha256"], r["path"], r["expires"]) for r in rows]], ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _clean_ids(ids) -> list[int]:
    out = sorted({int(i) for i in ids})
    if not out:
        raise InvalidInput("정리할 판을 골라 주세요")
    if len(out) > PURGE_MAX:
        raise InvalidInput(f"한 번에 {PURGE_MAX}개까지만 정리할 수 있습니다 — 나눠서 해 주세요")
    return out


def purge_plan(store: FormsStore, actor_id, ids, *, today: date | None = None) -> dict:
    """[정리하기] 확인 화면 — 관리자만, 읽기만. 고른 판이 모두 지금도 만료·정리 전이어야 한다(아니면 Conflict).
    돌려줌: {rows, total_size, digest(실행 때 같은 목록인지 대조), policy}."""
    store._require_admin(store._actor(actor_id))
    want = _clean_ids(ids)
    with store._lock:
        pol = policy(store)
        rows = _expired(store, want, today)
    got = {r["id"] for r in rows}
    if got != set(want):
        raise Conflict(f"고른 판 가운데 {len(set(want) - got)}개는 이미 정리됐거나 아직 보존 기간이 남았습니다 — "
                       f"목록을 새로 열어 다시 골라 주세요")
    return {"rows": rows, "total_size": sum(r["size"] for r in rows), "digest": _digest(pol, rows), "policy": pol}


def _drop_empty_dirs(store: FormsStore, rel: str, p) -> None:
    parts = [x for x in str(rel).split("/") if x]
    if len(parts) != 3 or parts[0] == PENDING_DIR:
        return
    try:
        if store.guard.remove_empty_dir(p.parent):            # <양식>/<판> 칸 — 비었을 때만
            store.guard.remove_empty_dir(p.parent.parent)     # <양식> — 다른 판이 남아 있으면 그대로
    except (GuardError, OSError):
        pass


class PurgePartial(Conflict):
    """파일을 지운 뒤 기록(purged_at·감사)을 적지 못했다 — 지운 목록은 로그에 남겼다 (2026-10-30 검토 3)."""


PARTIAL_HINT = ("일부 파일은 이미 지워졌을 수 있습니다 — 목록을 다시 열어 정리하세요 "
                "(다음 정리 때 '이미 없음'으로 적힙니다)")


def _store_missing_msg(store: FormsStore) -> str:
    return (f"보관소 폴더를 찾을 수 없습니다 — 아무것도 정리하지 않았습니다 ({store.store_root}). "
            f"보관소가 옮겨졌거나 디스크·공유 연결이 끊겼는지 확인한 뒤 다시 해 주세요")


def _one(store: FormsStore, r: dict):
    """판 하나 지우기 → ('purged', p) / ('missing', p) / ('failed', 까닭).
    '이미 없음'은 판 칸 폴더(<양식>/<판>)가 있고 그 안에 파일만 없을 때만 — 칸 폴더나 양식 폴더까지 없으면 보관소가 옮겨졌거나
    바깥에서 지운 것일 수 있어 정리됨으로 적지 않는다 (2026-10-30 검토 1)."""
    try:
        p = store._store_path(r["path"])
    except GuardError:
        return "failed", "보관 경로가 이상하거나 보관소에 닿지 않아 지우지 않았습니다 — 관리자 확인 필요"
    if not os.path.lexists(p):
        if not os.path.isdir(p.parent):
            slot = "/".join([x for x in str(r["path"]).split("/") if x][:-1])
            return "failed", (f"판 폴더({slot})가 없어 정리됨으로 적지 않았습니다 — 보관소가 옮겨졌거나 바깥에서 지웠을 수 있습니다. "
                              f"일부러 지운 판이면 보관소에 빈 폴더 {slot}을(를) 만든 뒤 다시 정리하면 '이미 없음'으로 적힙니다")
        return "missing", p
    try:
        removed = store.guard.remove_file(p, expected_sha256=r["sha256"])
    except GuardError:
        return "failed", "보관 파일이 올린 때와 달라(또는 파일이 아니라) 지우지 않았습니다 — 관리자 확인 필요"
    except OSError as e:
        return "failed", f"파일을 지우지 못했습니다({type(e).__name__}) — 다른 프로그램이 열고 있는지 확인하세요"
    return ("purged" if removed else "missing"), p


def purge(store: FormsStore, actor_id, ids, *, expect: str, ip=None, today: date | None = None) -> dict:
    """[정리하기] 실행 — 관리자만. expect: 확인 화면의 digest — 그사이 목록·정책이 바뀌었으면 Conflict(아무것도 지우지 않음).
    보관소 폴더(forms_store)가 없으면(옮김·공유 끊김) 통째로 거부한다(Conflict — 아무것도 적지 않음).
    판마다: guard로 파일 지우기(지문 일치일 때만) → purged_at·purged_by. 파일이 이미 없으면(판 칸 폴더는 있음) 정리됨으로 적고
    따로 알린다. 지문이 다르거나 지울 수 없거나 판 칸 폴더까지 없으면 그 판은 적지 않는다(목록에 남음).
    빈 판 칸 폴더는 기록을 적은(커밋한) 뒤에 지운다 — 기록이 실패하면 다음 정리가 '이미 없음'으로 적을 수 있게.
    파일을 지운 뒤 기록이 실패하면 지운 목록을 로그에 남기고 PurgePartial(Conflict). 돌려줌: {purged, missing, failed: [(줄, 까닭)]}.

    잠금 (2026-10-31 성능 — 전에는 쓰기 트랜잭션(저장소 잠금) 안에서 판 500개를 지워 그동안 모든 요청이 5~11초 멈췄다):
    ① 짧은 잠금: 권한·보관소·확인 지문을 보고, 지울 판을 모두 '정리 중'(store._purging)으로 표시한다 — 정리는 이 때에 일어난 것으로 친다
       (전에는 트랜잭션이 끝날 때까지 다른 쓰기가 기다렸다 — 그 순서와 같은 결과).
    ② 잠금 밖에서 guard로 지운다(판마다 지문 확인은 그대로). 그동안 다른 요청은 돈다. '정리 중'인 현행 판은 복원(set_retired)이 거부하고,
       내려받기·비교는 정리한 판처럼 답한다 — 지우는 중인 파일을 되살리거나 반쯤 읽지 않게. 정리는 한 번에 하나(store._purge_lock).
       판마다 잠금을 다시 잡지 않는다 — 무거운 읽기(찾기)가 잇달아 돌면 판마다 그만큼 기다려 정리가 몇 분으로 늘었다(합성 측정).
    ③ 짧은 트랜잭션: purged_at·purged_by + 감사 기록 한 줄(함께 남거나 함께 사라진다 — 실패하면 PurgePartial, 지운 판은 로그)."""
    want = _clean_ids(ids)
    with store._purge_lock:
        with store._lock:                                      # ① 확인 + 정리 중 표시
            actor = store._actor(actor_id)
            store._require_admin(actor)
            if not os.path.isdir(store.store_root):
                raise Conflict(_store_missing_msg(store))
            plan = purge_plan(store, actor_id, want, today=today)
            if not hmac.compare_digest(plan["digest"], str(expect or "")):
                raise Conflict("확인 화면을 연 뒤 목록이나 보존 정책이 바뀌었습니다 — 다시 [정리하기]를 눌러 확인해 주세요")
            marked = {r["id"] for r in plan["rows"]}
            store._purging.update(marked)
        purged, missing, failed = [], [], []
        removed_paths: list = []                   # 지운 파일 (기록이 실패해도 로그에 남기게)
        try:
            try:
                with store.guard.batch():                      # 뿌리 확인은 묶음마다 한 번 (guard)
                    for r in plan["rows"]:                     # ② 잠금 밖에서 지운다
                        kind, x = _one(store, r)
                        if kind == "failed":
                            failed.append((r, x))
                        elif kind == "purged":
                            purged.append(r)
                            removed_paths.append((r, x))
                        else:
                            missing.append(r)
                done = purged + missing
                if done:
                    with store.tx() as c:                      # ③ 기록
                        ts = now_text(store.clock())
                        c.executemany("UPDATE versions SET purged_at = ?, purged_by = ? WHERE id = ? AND purged_at IS NULL",
                                      [(ts, actor["id"], r["id"]) for r in done])
                        sample = ", ".join(f"{r['form_name']} v{r['number']}" for r in done[:5]) + (" …" if len(done) > 5 else "")
                        store._audit(actor, "retention_purge", "versions", ip,
                                     f"보존 기간이 지난 판 {len(done)}개 정리 (파일 지움 {len(purged)}개"
                                     + (f", 파일이 이미 없었음 {len(missing)}개" if missing else "")
                                     + (f", 못 지움 {len(failed)}개" if failed else "")
                                     + f", {sum(r['size'] for r in purged):,}바이트) — {sample}")
            finally:
                with store._lock:
                    store._purging.difference_update(marked)
        except Exception as e:
            if not removed_paths:
                raise
            log.error("보존 만료 정리: 파일 %d개를 지운 뒤 기록을 적지 못했습니다 (%s: %s) — 지운 판: %s",
                      len(removed_paths), type(e).__name__, e,
                      "; ".join(f"판 {r['id']} {r['path']}" for r, _p in removed_paths))
            raise PurgePartial(f"정리 기록을 적지 못했습니다({type(e).__name__}) — {PARTIAL_HINT}") from e
    for r, p in removed_paths:                     # 기록을 적은 뒤 빈 판 칸 폴더 (실패해도 그만)
        _drop_empty_dirs(store, r["path"], p)
    return {"purged": purged, "missing": missing, "failed": failed}
