# -*- coding: utf-8 -*-
"""양식함 주간 알림 — 검토자·관리자에게 한 주에 한 번 '할 일' 메일 (2026-10-30).

- 받는 사람: 메일 주소가 적힌 쓸 수 있는 관리자·검토자. 범위는 화면과 같다(관리자 = 전체, 검토자 = 맡은 폴더와 그 아래).
- 내용: 정기 검토 기한이 지난 양식 수, 30일 안에 기한이 오는 수, 맡은 폴더의 검토 대기 제출 수 + /register/due·/review 링크.
  셋 다 0이면 보내지 않는다. 파일·양식 내용은 싣지 않는다(원칙 1) — 숫자와 사내망 주소만.
  (2026-10-30 2단계 승인) 내가 승인할 수 있는 승인 대기 수도 싣고 할 일로 친다 — 0이면 제목·내용에 없다(지금까지와 같은 꼴).
- 보내기는 기존 메일 알림(notify.Notifier)의 줄·배경 스레드·사내 SMTP를 그대로 쓴다. 성공은 감사 기록 digest_sent,
  실패는 notify_fail.
- 설정 forms.digest_weekday(끔·월~금, 기본 월요일 — 2026-10-30 사용자 결정, 전에는 끔. 그때 [저장]해 '끔'이 적힌 설정은 끈 채로)·
  digest_hour(기본 8시). 켜도 사내 SMTP가 있을 때만 돈다.
- (2026-10-30) 관리자에게는 두 줄을 더 싣는다: 보존 기간이 지나 정리할 수 있는 판 수(/admin/retention, 0이면 없음)와
  백업 폴더가 데이터와 같은 디스크라는 경고(그 백업 폴더로는 **한 번만** — meta digest_disk_warned). 둘 다 할 일로 쳐서
  다른 수가 0이어도 관리자에게 보낸다.
  그 요일 그 시각 뒤 정리 일(1시간마다)이 보낸다 — 그날 서버가 꺼져 있었으면 그 주 금요일까지 따라잡는다.
  보낸 주(ISO 주)를 forms.db meta(digest_last_week)에 적어 서버를 다시 켜도 같은 주에 두 번 보내지 않는다.
- 이 모듈은 파일을 쓰지 않는다(forms.db meta만).
"""

from __future__ import annotations

import logging
import os
import threading
from datetime import datetime

from watcher.forms.store import FormsStore

log = logging.getLogger("drev.forms.server")

META_WEEK = "digest_last_week"
META_DISK = "digest_disk_warned"         # 같은 디스크 경고를 이미 실은 백업 폴더(접은 경로) — 한 번만
WEEKDAY_MAX = 4                         # 금요일까지만 따라잡는다


def week_key(d) -> str:
    iso = d.isocalendar()
    return f"{iso[0]}-W{iso[1]:02d}"


def digest_counts(store: FormsStore, *, retention: int = 0, disk_warn: str = "") -> list[dict]:
    """메일 주소가 있는 관리자·검토자마다 {user_id, login, name, email, role, overdue, soon, pending, retention, disk_warn}.
    retention·disk_warn은 관리자에게만 싣는다(검토자는 0·빈 글자)."""
    rows = store.conn.execute(
        "SELECT id, login, display_name, email, role FROM users WHERE disabled = 0 "
        "AND role IN ('admin', 'reviewer') AND TRIM(IFNULL(email, '')) != '' ORDER BY id").fetchall()
    out = []
    for r in rows:
        over, soon = store.due_counts(r["id"])
        pending = len(store.list_submissions(r["id"], scope="review", status="pending", limit=5000))
        approve = store.pending_approval_count(r["id"])      # 2단계 승인 — 내가 승인할 수 있는 승인 대기 (2026-10-30)
        admin = r["role"] == "admin"
        out.append({"user_id": r["id"], "login": r["login"], "name": r["display_name"], "email": r["email"].strip(),
                    "role": r["role"], "overdue": int(over), "soon": int(soon), "pending": int(pending),
                    "approve": int(approve),
                    "retention": int(retention) if admin else 0, "disk_warn": disk_warn if admin else ""})
    return out


class WeeklyDigest:
    """정리 일 스레드가 tick()을 부른다. notifier: notify.Notifier (보내기 줄)."""

    def __init__(self, store: FormsStore, notifier, *, weekday: int = 0, hour: int = 8, backup_dir=None):
        self.store = store
        self.backup_dir = str(backup_dir) if backup_dir else ""   # 같은 디스크 경고용 (백업이 꺼져 있으면 빈 글자)
        self.notifier = notifier
        self.weekday = max(0, min(int(weekday), WEEKDAY_MAX))
        self.hour = max(0, min(int(hour), 23))
        self.own_notifier = False              # 메일 알림이 꺼져 있어 이 알림만을 위해 만든 Notifier면 True(닫을 때 같이)
        self._lock = threading.Lock()

    def _now(self) -> datetime:
        return datetime.fromtimestamp(float(self.store.clock()))

    def due(self) -> bool:
        t = self._now()
        wd = t.weekday()
        if wd > WEEKDAY_MAX or wd < self.weekday or (wd == self.weekday and t.hour < self.hour):
            return False
        row = self.store.conn.execute("SELECT value FROM meta WHERE key = ?", (META_WEEK,)).fetchone()
        return (row[0] if row else "") != week_key(t.date())

    def tick(self) -> dict | None:
        if not self.due():
            return None
        return self.send()

    def send(self) -> dict:
        """이번 주 알림을 줄 세운다. 보낸 주를 먼저 적는다 — 보내는 도중 서버가 꺼져도 같은 주에 두 번 가지 않게."""
        with self._lock:
            key = week_key(self._now().date())
            with self.store.tx() as c:
                row = c.execute("SELECT value FROM meta WHERE key = ?", (META_WEEK,)).fetchone()
                if row and row[0] == key:
                    return {"week": key, "queued": 0, "skipped": 0, "already": True}
                c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (META_WEEK, key))
            retention, warn, warn_key = self._admin_extras()
            queued = skipped = 0
            warned = False
            for u in digest_counts(self.store, retention=retention, disk_warn=warn):
                if not (u["overdue"] or u["soon"] or u["pending"] or u.get("approve") or u["retention"] or u["disk_warn"]):
                    skipped += 1
                    continue
                self.notifier.digest(u)
                queued += 1
                warned = warned or bool(u["disk_warn"])
            if warned:
                with self.store.tx() as c:
                    c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (META_DISK, warn_key))
            log.info("양식함 주간 알림 %s: %d명 줄 세움, %d명은 할 일이 없어 건너뜀", key, queued, skipped)
            return {"week": key, "queued": queued, "skipped": skipped}

    def _admin_extras(self) -> tuple[int, str, str]:
        """(보존 기간 지난 판 수, 같은 디스크 경고(이미 실었으면 ''), 경고 열쇠). 실패해도 알림은 보낸다."""
        try:
            from watcher.forms.keep import expired_count
            retention = expired_count(self.store)
        except Exception:
            log.exception("양식함 주간 알림: 보존 만료 수를 세지 못함")
            retention = 0
        warn, key = "", ""
        if self.backup_dir:
            from watcher.forms.settings import same_disk_warning
            warn = same_disk_warning(self.backup_dir, self.store.data_dir)
            key = os.path.normcase(os.path.abspath(self.backup_dir))
            row = self.store.conn.execute("SELECT value FROM meta WHERE key = ?", (META_DISK,)).fetchone()
            if warn and row and row[0] == key:
                warn = ""                           # 이 백업 폴더로는 이미 한 번 알렸다
        return retention, warn, key

    def close(self, timeout: float = 5.0) -> None:
        if self.own_notifier and self.notifier is not None:
            try:
                self.notifier.close(timeout)
            except Exception:
                pass


def make_weekly(srv, fs: dict, *, mail_cfg=None, base_url: str = "", send=None) -> WeeklyDigest | None:
    """설정대로 주간 알림을 만든다 — 끔이거나 사내 SMTP가 없으면 None. 메일 알림(notify)이 켜져 있으면 그 줄을 같이 쓴다."""
    from watcher.forms.notify import Notifier, mail_ready
    from watcher.forms.settings import weekday_index
    wd = weekday_index(fs.get("digest_weekday"))          # 없으면 기본(월) — forms_settings가 이미 채운다
    if wd is None or not mail_ready(mail_cfg)[0]:
        return None
    n = getattr(srv, "notifier", None)
    own = n is None
    if own:
        n = Notifier(srv.store, dict(mail_cfg or {}), base_url=base_url, send=send)
    bk = getattr(srv, "backup", None)                    # 백업기(attach가 먼저 붙인다) — 같은 디스크 경고용
    w = WeeklyDigest(srv.store, n, weekday=wd, hour=fs.get("digest_hour", 8),
                     backup_dir=getattr(bk, "dir", None) if bk is not None else None)
    w.own_notifier = own
    return w
