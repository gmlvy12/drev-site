# -*- coding: utf-8 -*-
"""현행 미러 — 승인된 현행 판을 설정한 폴더(mirror_root) 아래 폴더 구조대로 둔다 (FORMS.md 4절 5, 2026-10-28 F4).

브라우저 없이 탐색기로 양식을 가져가는 직원용이다. `<미러 뿌리>/<폴더>/<하위 폴더>/<양식 이름>.<확장자>`.

- 쓰기·지우기는 전부 guard.Guard(뿌리 = 미러 폴더 하나)를 거친다. 이 모듈 자체는 tests/test_readonly.py 의 엄격 검사를 받는다.
- **Drev가 둔 파일만** 바꾸고 지운다 — forms.db `mirror_files`(manifest)에 적힌 지문과 같을 때만. 사람이 넣거나 고친 파일은
  건드리지 않고 건너뛴 뒤 감사 기록(mirror_skip)을 남긴다(같은 충돌은 서버가 도는 동안 한 번만 적는다).
- 폐기된 양식은 미러에서 뺀다(복원하면 다시 둔다) — DECISIONS 2026-10-28 F4.
- 미러 실패(공유 폴더가 끊김 등)는 승인을 되돌리지 않는다. 동기화는 원하는 상태(현행 판 목록)와 manifest를 견줘 맞추는
  방식이라, 서버 시작 때·뒷일이 생길 때·주기적으로(10분) 다시 돌면 저절로 따라잡는다.
- 폴더 이름을 바꾸면 옛 이름 아래 Drev 파일을 지우고 새 이름 아래 둔다. 옛 폴더는 **Drev가 만든 폴더(mirror_dirs 목록)이고
  비었을 때만** 지운다(guard.remove_empty_dir, 2026-10-28 보안 F7) — 사람이 만든 폴더·사람 파일이 든 폴더는 그대로.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
import unicodedata
from pathlib import Path

from watcher.forms.guard import Guard, GuardError, check_name, sha256_of
from watcher.forms.store import FormsError, FormsStore

log = logging.getLogger("drev.forms.server")

RESYNC_SECONDS = 600            # 아무 일이 없어도 이만큼마다 다시 맞춘다 (끊겼던 공유 폴더가 돌아온 경우)
MAX_STEM = 120
# 미러 파일 전체 경로 상한 — Excel은 전체 경로가 218자를 넘는 파일을 열지 못하고, LongPathsEnabled=0인 PC는
# 260자에서 쓰기부터 실패한다(검토20 r18-2). 넘으면 양식 이름 쪽을 줄이고 '(id)'를 붙여 구별한다.
MIRROR_PATH_MAX = 218
MIRROR_ROOT_WARN = 120          # 뿌리 경로만으로 이만큼이면 설정 화면에서 미리 경고한다
_SWAP = set('<>:"/\\|?*')
# 미러 뿌리의 안내 파일 (기능 검토 F2-12, 2026-11-02) — guard로만 쓰고, 지문을 forms.db meta에 적어 두었다가
# 사람이 고친 파일(지문이 다름)은 덮지 않는다(현행 판 파일과 같은 규칙)
README_NAME = "_읽어주세요.txt"
README_SHA_KEY = "mirror_readme_sha"


def readme_bytes(base_url: str = "") -> bytes:
    """안내 파일 내용 — 메모장이 바로 읽게 UTF-8(BOM)·CRLF."""
    where = f"양식함 주소: {base_url.rstrip('/')}/ (사내망에서만 열립니다)" if base_url else \
        "양식함 주소는 관리자에게 물어보세요 (사내망에서만 열립니다)."
    lines = ["이 폴더는 Drev 양식함이 관리하는 '현행 미러'입니다.", "",
             "- 여기 있는 파일은 승인된 현행 판입니다. 새 판이 승인되면 Drev가 덮어씁니다.",
             "- 그래서 이 폴더의 파일을 직접 고치지 마세요. 복사해서 쓰세요.",
             "- 지난 판(옛 판)을 받거나, 새 양식·고친 양식(개정안)을 올리려면 양식함에서 하세요.",
             f"- {where}", "",
             "이 안내 파일을 사람이 고치면 Drev는 다시 덮어쓰지 않습니다."]
    return ("﻿" + "\r\n".join(lines) + "\r\n").encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def mirror_filename(form_name: str, filename: str, form_id: int) -> str:
    """미러에 둘 파일 이름 = 양식 이름 + 현행 판 파일의 확장자. 파일 이름으로 못 쓰는 글자는 '_'로,
    그래도 안 되면 '양식<id>'. 탐색기에서 양식 이름으로 찾게 — 원래 파일 이름은 판마다 다를 수 있다."""
    ext = os.path.splitext(str(filename or ""))[1]
    if not ext or len(ext) > 10:
        ext = ""
    stem = "".join("_" if (ch in _SWAP or unicodedata.category(ch) in ("Cc", "Cf", "Zl", "Zp")) else ch
                   for ch in unicodedata.normalize("NFC", str(form_name or "")))
    stem = " ".join(stem.split())[:MAX_STEM].rstrip(" .")
    for cand in ((stem + ext) if stem else "", f"_{stem}{ext}" if stem else "", f"양식{int(form_id)}{ext}"):
        if not cand:
            continue
        try:
            return check_name(cand)
        except GuardError:
            continue
    return f"양식{int(form_id)}{ext}"


def _shorten_to_fit(name: str, form_id: int, room: int) -> str | None:
    """미러 파일 이름을 room 글자 안으로 — 확장자는 두고 양식 이름을 줄여 ' (id)'를 붙인다. 못 줄이면 None."""
    stem, ext = os.path.splitext(name)
    tail = f" ({int(form_id)}){ext}"
    keep = room - len(tail)
    if keep < 1:
        return None
    cut = stem[:keep].rstrip(" .")
    if not cut:
        return None
    try:
        return check_name(cut + tail)
    except GuardError:
        return None


def root_length_warning(mirror_root) -> str:
    """미러 뿌리 경로가 길면 설정 화면에 띄울 경고, 아니면 '' (검토20 r18-2)."""
    s = str(mirror_root or "").strip()
    if len(s) < MIRROR_ROOT_WARN:
        return ""
    return (f"현행 미러 폴더 경로가 깁니다({len(s)}자). 그 아래 폴더·양식 이름까지 합쳐 {MIRROR_PATH_MAX}자를 넘으면 "
            f"Excel이 파일을 열지 못하므로 Drev가 양식 이름을 줄여 둡니다 — 더 짧은 폴더(예: D:\\양식\\현행)를 권합니다")


class Mirror:
    """현행 미러 하나 — 서버가 쥐고, 뒷일이 생기면 request_sync(), 시험은 sync()를 바로 부른다.

    동기화는 한 스레드(forms-mirror)에서만 돈다(겹치지 않게)."""

    def __init__(self, store: FormsStore, mirror_root, *, interval: float = RESYNC_SECONDS, watch_roots=(),
                 base_url: str = ""):
        self.store = store
        self.root = Path(mirror_root)
        self.base_url = str(base_url or "")   # 안내 파일에 적을 양식함 주소 (F2-12)
        self.interval = float(interval)
        # 감시 폴더 목록(또는 그것을 돌려주는 함수 — config.yaml을 다시 읽는다). 미러가 그 안이면 동기화마다 거부 (검토20 r04-1)
        self.watch_roots = watch_roots
        self.disabled = ""                # 감시 폴더 안이라 꺼 둔 까닭 (관리자 화면 띠)
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._cv = threading.Condition()
        self._requested = 0               # 요청한 동기화 수 / 끝난 동기화가 따라잡은 수 (settle)
        self._done = 0
        self._noted: set = set()         # 이미 감사 기록한 충돌·실패 (서버가 도는 동안 같은 것을 다시 적지 않게)
        self.last: dict = {}              # 마지막 동기화 결과 (화면·시험용)
        self.syncs = 0

    # ── 배경 스레드 ──────────────────────────────────────────────────────

    def start(self) -> None:
        """배경 스레드를 띄우고 곧바로 한 번 전체를 맞춘다(서버 시작 때 재동기화)."""
        if self._thread is not None:
            return
        with self._cv:
            self._requested += 1
        self._wake.set()
        self._thread = threading.Thread(target=self._loop, name="forms-mirror", daemon=True)
        self._thread.start()

    def request_sync(self) -> None:
        if self._thread is None:
            self.sync()
            return
        with self._cv:
            self._requested += 1
        self._wake.set()

    def settle(self, timeout: float = 15.0) -> bool:
        """지금까지 요청한 동기화가 다 끝날 때까지 기다린다(시험·종료용). 끝났으면 True."""
        with self._cv:
            want = self._requested
            return self._cv.wait_for(lambda: self._done >= want, timeout)

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(self.interval)
            if self._stop.is_set():
                break
            self._wake.clear()
            with self._cv:
                upto = self._requested
            try:
                self.sync()
            except Exception:                         # 배경 스레드가 죽으면 다시 맞출 길이 없다
                log.exception("현행 미러 동기화 중 예상 못 한 오류")
            with self._cv:
                self._done = max(self._done, upto)
                self._cv.notify_all()

    def close(self, timeout: float = 10.0) -> None:
        self._stop.set()
        self._wake.set()
        t = self._thread
        if t is not None and t is not threading.current_thread():
            t.join(timeout)

    # ── 감사 기록 ────────────────────────────────────────────────────────

    def _note(self, action: str, target: str, detail: str) -> None:
        key = (action, target, detail)
        if key in self._noted:
            return
        self._noted.add(key)
        log.warning("현행 미러: %s %s %s", action, target, detail)
        try:
            self.store.record_audit(None, action, target, detail=detail[:500], login="(양식함)")
        except Exception:
            log.exception("현행 미러: 감사 기록을 남기지 못했습니다")

    # ── 동기화 ───────────────────────────────────────────────────────────

    def desired(self) -> dict:
        """{상대 경로: 현행 판 항목} — 폐기 안 된 양식의 현행 판. 이름이 겹치면 뒤 양식에 '(id)'를 붙인다.

        - 파일 이름이 다른 양식이 쓰는 **폴더** 경로와 같으면(`보고서.xlsx` 폴더 ↔ 양식 `보고서`) 양식 쪽에 '(id)' —
          한쪽이 영영 빠지거나 폴더를 못 만들어 매번 실패하던 것(검토20 r18-1).
        - 전체 경로가 MIRROR_PATH_MAX를 넘으면 양식 이름을 줄이고 '(id)' (검토20 r18-2)."""
        out: dict = {}
        seen: set = set()
        plan = []
        dirs: set = set()                             # 미러에 생길 폴더 경로(casefold) 전부
        for item in self.store.mirror_plan():
            try:
                parts = [check_name(n) for n in item["folder_names"]]
            except GuardError:
                continue
            plan.append((parts, item))
            for i in range(1, len(parts) + 1):
                dirs.add("/".join(parts[:i]).casefold())
        root_len = len(str(self.root))
        for parts, item in plan:
            fid = item["form_id"]
            name = mirror_filename(item["form_name"], item["filename"], fid)
            rel = "/".join(parts + [name])
            if rel.casefold() in seen or rel.casefold() in dirs:
                stem, ext = os.path.splitext(name)
                name = mirror_filename(f"{stem} ({fid})", "x" + ext, fid)   # splitext('.xlsx')는 확장자가 없다
                rel = "/".join(parts + [name])
            room = MIRROR_PATH_MAX - root_len - 1 - sum(len(x) + 1 for x in parts)
            if len(name) > room:
                short = _shorten_to_fit(name, fid, room)
                if short is not None:
                    name = short
                    rel = "/".join(parts + [name])
            if rel.casefold() in seen or rel.casefold() in dirs:
                continue
            seen.add(rel.casefold())
            out[rel] = item
        return out

    def _fix_dir_case(self, guard: Guard, want: dict) -> int:
        """폴더 이름을 대소문자만 바꾼 경우(QA → qa) Drev가 만든 미러 폴더의 표기도 바꾼다 (검토20 r18-3).
        Windows는 대소문자를 가리지 않아 같은 자리로 보고 그대로 두었다. 사람이 만든 폴더(mirror_dirs에 없음)는 건드리지 않는다.
        바꾼 폴더 수."""
        try:
            made = {r.casefold(): r for r in self.store.mirror_dirs()}
        except FormsError:
            return 0
        if not made:
            return 0
        prefixes: dict = {}
        for rel in want:
            parts = rel.split("/")[:-1]
            for i in range(1, len(parts) + 1):
                prefixes.setdefault("/".join(parts[:i]).casefold(), "/".join(parts[:i]))
        n = 0
        listed: dict = {}
        for key in sorted(prefixes, key=lambda k: k.count("/")):
            rel = prefixes[key]
            if key not in made:
                continue
            parts = rel.split("/")
            parent = self.root.joinpath(*parts[:-1])
            try:
                names = listed.get(str(parent))
                if names is None:
                    names = listed[str(parent)] = os.listdir(parent)
            except OSError:
                continue
            have = [x for x in names if x.casefold() == parts[-1].casefold()]
            if len(have) != 1 or have[0] == parts[-1]:
                continue
            try:
                guard.rename_dir_case(guard.target(self.root, *parts[:-1], have[0]), parts[-1])
            except (GuardError, OSError) as e:
                self._note("mirror_fail", f"mirror:{rel}", f"폴더 이름 표기를 바꾸지 못했습니다: {e}")
                continue
            listed.pop(str(parent), None)
            n += 1
            old_prefix = made[key]
            for rk, rv in list(made.items()):        # 이 폴더와 그 아래 기록을 새 표기로
                if rk == key or rk.startswith(key + "/"):
                    nv = rel + rv[len(old_prefix):]
                    try:
                        self.store.mirror_dir_forget(rv)
                        self.store.mirror_dir_record(nv)
                    except FormsError:
                        pass
                    made[rk] = nv
        return n

    def sync(self) -> dict:
        """미러를 원하는 상태에 맞춘다. 돌려줌 {placed, replaced, removed, kept, skipped, failed, error}."""
        with self._lock:
            res = self._sync()
            self.last = res
            self.syncs += 1
            return res

    def _remember_dirs(self, made: list) -> None:
        """방금 Drev가 만든 미러 폴더들을 목록(mirror_dirs)에 적는다 — 나중에 비면 그 폴더만 지우려고."""
        for p in made:
            try:
                rel = Path(os.path.relpath(p, self.root)).as_posix()
            except ValueError:
                continue
            if rel and rel != "." and not rel.startswith(".."):
                try:
                    self.store.mirror_dir_record(rel)
                except FormsError:
                    log.exception("현행 미러: 만든 폴더를 적지 못했습니다 (%s)", rel)

    def _drop_empty_dirs(self, guard: Guard, want: dict) -> int:
        """목록에 적힌(=Drev가 만든) 폴더 가운데, 원하는 현행 판이 하나도 들지 않고 비어 있는 것을 깊은 것부터 지운다.
        사람이 넣은 파일이 있으면 OS가 지우기를 거절하므로 그대로 남고 목록에도 남는다(다음에 다시 본다).
        사람이 미리 만들어 둔 폴더는 목록에 없으니 비어도 건드리지 않는다. 지운 폴더 수."""
        try:
            dirs = self.store.mirror_dirs()
        except FormsError:
            return 0
        needed: set = set()
        for rel in want:
            parts = rel.split("/")[:-1]
            for i in range(1, len(parts) + 1):
                needed.add("/".join(parts[:i]).casefold())
        n = 0
        for rel in sorted(dirs, key=lambda r: (-r.count("/"), r)):
            if rel.casefold() in needed:
                continue
            try:
                path = guard.target(self.root, *rel.split("/"))
                gone = guard.remove_empty_dir(path)
                if gone:
                    n += 1
                elif os.path.lexists(path):
                    continue                          # 비지 않았다 — 사람 파일이 있다. 목록에 두고 다음에 다시
            except GuardError:
                pass                                  # 이제 폴더가 아니다(파일·링크로 바뀜) — Drev 폴더가 아니니 잊는다
            except OSError as e:
                log.info("현행 미러: 빈 폴더를 지우지 못했습니다 (%s): %s", rel, e)
                continue
            try:
                self.store.mirror_dir_forget(rel)
            except FormsError:
                pass
        return n

    def _readme(self, guard: Guard, want: dict) -> str:
        """뿌리의 `_읽어주세요.txt` — 없으면 두고, Drev가 둔 그대로(meta의 지문과 같음)면 새 내용으로 바꾸고, 사람이 고쳤으면
        그대로 둔다(감사 기록 mirror_skip 한 번). 돌려줌 'placed'·'replaced'·'kept'·'skipped'·'failed'."""
        data = readme_bytes(self.base_url)
        want_sha = sha256_hex(data)
        if any(k.casefold() == README_NAME.casefold() for k in want):
            return "skipped"                          # 같은 이름의 양식 자리 — 양식이 먼저
        try:
            recorded = str(self.store.meta_get(README_SHA_KEY, "") or "")
            path = guard.target(self.root, README_NAME)
            if os.path.lexists(path):
                if not os.path.isfile(path):
                    return "skipped"
                cur = sha256_of(path)
                if cur == want_sha:
                    if recorded != want_sha:
                        self.store.meta_put({README_SHA_KEY: want_sha})
                    return "kept"
                if not recorded or cur != recorded:
                    self._note("mirror_skip", f"mirror:{README_NAME}",
                               "사람이 고친 안내 파일이라 덮어쓰지 않았습니다")
                    return "skipped"
                guard.replace_file(path, data, expected_sha256=recorded)
                self.store.meta_put({README_SHA_KEY: want_sha})
                return "replaced"
            guard.write_new(path, data)
            self.store.meta_put({README_SHA_KEY: want_sha})
            return "placed"
        except (GuardError, OSError, FormsError) as e:
            self._note("mirror_fail", f"mirror:{README_NAME}", f"안내 파일을 두지 못했습니다: {e}")
            return "failed"

    def problem(self) -> str:
        """미러 폴더가 감시 폴더와 같거나 그 안이면 까닭, 아니면 '' — 동기화마다 다시 본다 (검토20 r04-1)."""
        from watcher.forms.settings import mirror_root_problem
        roots = self.watch_roots
        if callable(roots):
            try:
                roots = roots()
            except Exception:
                log.exception("현행 미러: 감시 폴더 목록을 읽지 못했습니다")
                roots = ()
        return mirror_root_problem(str(self.root), list(roots or ()))

    def _sync(self) -> dict:
        res = {"placed": 0, "replaced": 0, "removed": 0, "kept": 0, "skipped": 0, "failed": 0, "error": "",
               "dirs_removed": 0}
        why = self.problem()
        if why:                                       # 감시 공유 안에 쓰지 않는다 — 아무것도 놓거나 지우지 않는다
            if why != self.disabled:
                log.error("현행 미러: %s", why)
            self.disabled = why
            res["error"] = why
            self._note("mirror_fail", str(self.root), why)
            return res
        self.disabled = ""
        try:
            guard = Guard([self.root])
        except GuardError as e:
            res["error"] = f"현행 미러 폴더를 쓸 수 없습니다 — {e}"
            self._note("mirror_fail", str(self.root), res["error"])
            return res
        try:
            want = self.desired()
            have = self.store.mirror_entries()
        except FormsError as e:
            res["error"] = str(e)
            return res
        want_keys = {k.casefold(): k for k in want}
        self._fix_dir_case(guard, want)

        # ① 원하는 목록에 없거나 다른 판이 된 Drev 파일을 지운다 (폐기·폴더 이름 바꾸기·개정)
        for rel, m in have.items():
            new_rel = want_keys.get(rel.casefold())
            if new_rel is not None:
                continue                              # 같은 자리 — ②에서 교체 여부를 본다
            try:
                path = guard.target(self.root, *rel.split("/"))
                if guard.remove_file(path, expected_sha256=m["sha256"]):
                    res["removed"] += 1
            except GuardError as e:
                res["skipped"] += 1
                self._note("mirror_skip", f"mirror:{rel}", f"사람이 바꾼 파일이라 지우지 않았습니다 ({e.__class__.__name__})")
            except OSError as e:
                res["failed"] += 1
                self._note("mirror_fail", f"mirror:{rel}", f"지우지 못했습니다: {e}")
                continue                              # 목록에 남겨 다음에 다시 지운다
            try:
                self.store.mirror_forget(rel)
            except FormsError:
                pass

        # ② 현행 판을 둔다 (없으면 새로, Drev가 둔 옛 판이면 교체, 사람 파일이면 건너뜀)
        have_keys = {k.casefold(): (k, v) for k, v in have.items()}
        for rel, item in want.items():
            old_rel, m = have_keys.get(rel.casefold(), (None, None))
            try:
                path = guard.target(self.root, *rel.split("/"))
                exists = os.path.lexists(path)
                if exists and m is not None and m["sha256"] == item["sha256"] and old_rel == rel:
                    try:
                        if os.path.getsize(path) == item["size"]:
                            res["kept"] += 1
                            continue
                    except OSError:
                        pass
                expected = None
                if exists:
                    if not os.path.isfile(path):
                        res["skipped"] += 1
                        self._note("mirror_skip", f"mirror:{rel}", "같은 이름의 폴더가 있어 두지 않았습니다")
                        continue
                    cur = sha256_of(path)
                    if cur == item["sha256"]:             # 이미 그 내용 — 목록만 맞춘다
                        if old_rel is not None and old_rel != rel:
                            self.store.mirror_forget(old_rel)
                        self.store.mirror_record(rel, item["form_id"], item["version_id"], item["sha256"])
                        res["kept"] += 1
                        continue
                    if m is None or cur != m["sha256"]:
                        res["skipped"] += 1
                        self._note("mirror_skip", f"mirror:{rel}",
                                   "사람이 넣거나 고친 파일이 있어 현행 판을 두지 않았습니다")
                        if m is not None:              # 이제 Drev 파일이 아니다 — 목록에서 뺀다
                            self.store.mirror_forget(old_rel)
                        continue
                    expected = m["sha256"]
                data = self.store.version_bytes(item["version_id"])
                made: list = []
                try:
                    guard.replace_file(path, data, expected_sha256=expected, created=made)
                finally:
                    self._remember_dirs(made)
                if old_rel is not None and old_rel != rel:
                    self.store.mirror_forget(old_rel)
                self.store.mirror_record(rel, item["form_id"], item["version_id"], item["sha256"])
                res["replaced" if expected else "placed"] += 1
            except (GuardError, OSError, FormsError) as e:
                res["failed"] += 1
                self._note("mirror_fail", f"mirror:{rel}", f"두지 못했습니다: {e}")
        # ③ Drev가 만든 폴더 가운데 이제 쓰지 않고 빈 것을 지운다 (폴더 이름 바꾸기·폐기 뒤 옛 빈 폴더, 보안 F7)
        res["dirs_removed"] = self._drop_empty_dirs(guard, want)
        # ④ 뿌리의 안내 파일 (F2-12)
        res["readme"] = self._readme(guard, want)
        if res["failed"] == 0:
            # 성공하면 실패 기록을 잊는다 — 다음에 또 끊기면 다시 한 번 적게
            self._noted = {k for k in self._noted if k[0] != "mirror_fail"}
        log.info("현행 미러 동기화: %s", {k: v for k, v in res.items() if v})
        return res
