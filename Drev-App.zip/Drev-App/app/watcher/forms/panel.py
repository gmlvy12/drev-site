# -*- coding: utf-8 -*-
"""감시 화면(127.0.0.1) 설정 › '양식함' 칸 (2026-10-28 F4).

- 켜기·끄기(DrevForms 상주 작업 — cli.forms_task_*), 주소·포트(사내망 주소 후보), 현행 미러 폴더, 올리기 상한,
  자동 비교 상한, 메일 알림, 첫 관리자 만들기(이 화면은 127.0.0.1에서만 열리므로 여기서 — auth.create_first_admin),
  접속 주소 안내, 사내망 전용·공유기 포트 개방 금지 경고, 방화벽 안내(포터블은 명령 한 줄만 보여 준다 — 실행하지 않는다).
- web.py는 page_settings에서 panel_html()을, POST '/formsbox/…'에서 handle_post()를 부를 뿐이다.
- 이 모듈은 파일을 쓰지 않는다 — 설정 저장은 화면 앱의 _save_key(config.yaml), 계정은 forms.db(SQLite)로만.
"""

from __future__ import annotations

import html
from pathlib import Path

from watcher.forms.settings import (DEFAULT_PORT, DIGEST_DEFAULT, DIGEST_OFF, WEEKDAYS, access_urls, check_backup_dir,
                                    check_int, check_mirror_root, check_port, firewall_command, forms_settings,
                                    lan_addresses, out_of_range, records_only, same_disk_warning, SAME_DISK_HINT)
from watcher.forms.store import DB_NAME, FormsError

E = html.escape
PREFIX = "/formsbox/"


def data_dir_of(cfg: dict) -> Path:
    """양식함 데이터 폴더 = 감시 이력(state.db)이 있는 Drev 데이터 폴더."""
    return Path(cfg["state_db"]).resolve().parent


def has_admin(cfg: dict) -> bool:
    """관리자가 있나 — forms.db가 없으면 아직 없다(열어서 새로 만들지 않는다)."""
    return admin_state(cfg)[0]


def admin_state(cfg: dict) -> tuple[bool, str]:
    """(관리자가 있나, 열 수 없는 까닭) — forms.db를 열지 못하면 (False, 까닭). 까닭을 삼키면 '더 새 판' DB나 잠긴 DB가
    '아직 관리자가 없습니다 — [첫 관리자 만들기]'로 보여 데이터가 사라진 것처럼 읽힌다 (재검토 이주 1)."""
    d = data_dir_of(cfg)
    if not (d / DB_NAME).is_file():
        return False, ""
    from watcher.forms import auth
    from watcher.forms.store import FormsStore
    try:
        with FormsStore(d) as st:
            return auth.has_admin(st), ""
    except Exception as e:
        return False, str(e) or type(e).__name__


def _program_path() -> str:
    """방화벽 규칙에 넣을 실행 파일 — 포터블·설치판의 python\\pythonw.exe (모르면 빈 글자 = 포트만)."""
    try:
        from watcher.selfupdate import install_root
        r = install_root()
        if r is not None and (r / "python" / "pythonw.exe").is_file():
            return str(r / "python" / "pythonw.exe")
    except Exception:
        pass
    return ""


def _installed() -> bool:
    """설치판(Inno Setup)인가 — 설치 폴더에 제거 프로그램이 있다."""
    try:
        from watcher.selfupdate import install_root
        r = install_root()
        return r is not None and any(r.glob("unins*.exe"))
    except Exception:
        return False


def _task_status() -> dict:
    try:
        from watcher.cli import forms_task_status
        return forms_task_status()
    except Exception:
        return {"exists": False, "running": False, "target": ""}


def backup_status(cfg: dict) -> tuple[str, bool | None]:
    """(상태 한 줄, 확인 OK 여부) — '마지막 백업 … · DB n MB · 파일 n개 · 확인 OK/실패'. forms.db가 없으면 열지 않는다."""
    d = data_dir_of(cfg)
    if not (d / DB_NAME).is_file():
        return "아직 백업한 적이 없습니다", None
    from watcher.forms import backup as FB
    from watcher.forms.store import FormsStore
    try:
        with FormsStore(d) as st:
            last = FB.last_status(st)
    except Exception as e:
        return f"백업 상태를 읽지 못했습니다 — {e}", False
    probs = int((last["summary"] or {}).get("problem_count") or 0)
    return FB.status_line(last), (None if last["ok"] is None else bool(last["ok"]) and not probs)


def restore_command(config_path, backup_dir: str) -> str:
    """복원 명령 한 줄(콘솔 python으로) — 화면은 보여 주기만 하고 실행하지 않는다 (2026-10-30)."""
    tail = f'forms-restore --from "{backup_dir}"'
    try:
        from watcher.cli import forms_task_action
        act = forms_task_action(config_path)
    except Exception:
        act = None
    if act is None:
        return f'python -m watcher.cli --config "{Path(str(config_path)).resolve()}" {tail}'
    exe, args, _ = act
    if exe.lower().endswith("pythonw.exe"):                # 창 없는 pythonw는 결과를 못 보여 준다 — 같은 폴더의 python.exe
        exe = exe[:-len("pythonw.exe")] + "python.exe"
    head = args.rpartition("forms-serve")[0]
    return f'"{exe}" {head}{tail}'


def _mirror_len_warn(root: str) -> str:
    """현행 미러 뿌리가 길면 경고 한 줄 (검토20 r18-2)."""
    from watcher.forms.publish import root_length_warning
    w = root_length_warning(root)
    return f'<p class="ui-note hot">{E(w)}</p>' if w else ""


def _hint(text: str) -> str:
    return f'<span class="ui-st">{E(text)}</span>'


def _more(inner: str, label: str = "자세히") -> str:
    """긴 설명의 나머지 — 작은 '자세히' 접기 (감시 화면 설정의 _st_more와 같은 꼴, 2026-11-18 독립 검토 R2 중간 7). 지우지 않고 접는다."""
    return (f'<details class="ui-fold st-mini"><summary>{label}</summary><div class="ui-fold-body">'
            f'<p class="ui-help">{inner}</p></div></details>')


def _field(label: str, inner: str, help_: str = "", more: str = "") -> str:
    """설정 한 줄 — 이름표 + 입력 + 회색 설명 (감시 화면 공통 꼴 .ui-field, 화면 정리 C 2026-11-18).
    more: 한 문장을 넘는 설명의 나머지 — '자세히'로 접는다 (2026-11-18 독립 검토 R2 중간 7)."""
    return (f'<div class="ui-field"><span class="ui-lab">{label}</span><div>{inner}'
            + (f'<span class="ui-help">{help_}</span>' if help_ else "")
            + (_more(more) if more else "") + '</div></div>')


def panel_html(cfg: dict, *, tok: str, lan: list | None = None, status: dict | None = None,
               config_path=None) -> str:
    """설정 화면의 '양식함' 칸 HTML. tok: 감시 화면의 CSRF hidden 필드. config_path: 복원 명령 안내용(없으면 config.yaml)."""
    fs = forms_settings(cfg)
    lan = lan_addresses() if lan is None else lan
    st = _task_status() if status is None else status
    admin, open_problem = admin_state(cfg)
    urls = access_urls(fs["host"], fs["port"], lan)
    # 화면 정리 C (2026-11-18): 색 꼬리표 대신 상태 글자 — 정상은 굵게, 손볼 것은 강조색.
    # 화면 v2 글 (2026-11-18 KW2): 상태는 굵은 글 한 줄, 할 일은 아래 회색 한 줄(줄표로 잇지 않는다). 판정·조건은 그대로
    if fs["enabled"] and st.get("running"):
        state, state_help = '<b>켜짐</b> <span class="ui-st">실행 중</span>', ''
    elif fs["enabled"] and st.get("exists"):
        state, state_help = ('<span class="ui-st hot">켜짐, 지금 멈춤</span>',
                             '[다시 시작]을 누르거나 forms.log를 확인하세요.')
    elif fs["enabled"]:
        state, state_help = ('<span class="ui-st hot">켜짐, 자동 시작 작업 없음</span>',
                             '[양식함 켜기]를 다시 누르면 Windows 작업(DrevForms)을 만듭니다.')
    else:
        state, state_help = '<b>꺼짐</b>', '꺼 두면 Drev는 감시만 합니다.'
    host_opts = "".join(f'<option value="{E(ip)}">' for ip in ["0.0.0.0"] + lan)
    who = ("".join(f'<li><code>{E(u)}</code></li>' for u in urls)
           if urls else '<li class="muted">이 PC의 사내망 주소를 찾지 못했습니다. 아래 주소 칸에 이 PC의 IP를 적어 주세요.</li>')
    local = (f'http://127.0.0.1:{fs["port"]}/' if fs["host"] in ("0.0.0.0", "127.0.0.1", "")
             else (urls[0] if urls else ""))
    mail = cfg.get("mail") or {}
    from watcher.forms.notify import mail_ready
    m_ok, m_why = mail_ready(mail)
    rec_only = records_only(fs)
    if rec_only:                                   # 기록 열람만 (2026-11-17 R3)
        state += ' <b>사내망 기록 열람만</b>'
        state_help = (state_help + ' ' if state_help else '') + '양식 올리기·승인·판 기능은 꺼져 있습니다.'
    onoff = (f'<form class="ui-inl" method="post" action="{PREFIX}off">{tok}'
             f'<button class="ui-btn2">{"사내망 서버 끄기" if rec_only else "양식함 끄기"}</button></form> '
             f'<form class="ui-inl" method="post" action="{PREFIX}restart">{tok}'
             f'<button class="ui-link">다시 시작</button></form> '
             + (f'<form class="ui-inl" method="post" action="{PREFIX}boxes_on">{tok}'
                f'<button class="ui-link">양식 기능도 켜기</button></form>' if rec_only else
                f'<form class="ui-inl" method="post" action="{PREFIX}boxes_off">{tok}'
                f'<button class="ui-link quiet">양식 기능 끄기 (기록 열람만)</button></form>')
             if fs["enabled"] else
             f'<form class="ui-inl" method="post" action="{PREFIX}on">{tok}'
             f'<button class="ui-btn2">양식함 켜기</button></form> '
             f'<form class="ui-inl" method="post" action="{PREFIX}on_records">{tok}'
             f'<button class="ui-link">사내망 기록 열람만 켜기</button></form>')
    rec_intro = ('<p class="ui-p"><b>사내망 기록 열람</b>: 동료 PC의 브라우저에서 계정으로 로그인해 변경 기록을 보고 [확인함]을 남깁니다. '
                 '프로젝트 목록·문서함·문서 이력·최근 변경·근거와 전/후 사진을 볼 수 있습니다. '
                 '양식 기능 없이 이것만 켤 수 있습니다([사내망 기록 열람만 켜기]). 볼 수 있는 프로젝트는 계정마다 관리자가 정합니다. '
                 '이 감시 화면(설정·검사)은 사내망에 열리지 않고 이 PC에서만 열립니다.</p>')
    if open_problem:
        newer = "더 새 판" in open_problem
        admin_html = ('<p class="ui-note hot"><b>양식함 데이터를 열 수 없음</b> '
                      f'<span class="ui-st">{E(open_problem)}</span> '
                      + ('Drev를 최신 판으로 업데이트하세요. 데이터는 그대로 있습니다.' if newer else
                         '데이터는 지우지 않았습니다. forms.log를 확인하고 잠시 뒤 다시 열어 보세요.')
                      + '</p>')
    elif admin:
        admin_html = _field("관리자", '<b>관리자 있음</b>',
                            '직원 계정·폴더 관리는 양식함 화면의 [계정]·[폴더 관리]에서 합니다.',
                            '검토자 지정과 기본 분류 틀도 [폴더 관리]에서 합니다.')
    else:
        admin_html = (f'<form method="post" action="{PREFIX}admin" autocomplete="off">{tok}'
                      f'<p class="ui-help">아직 관리자가 없습니다. 첫 관리자는 <b>이 PC에서만</b> 만들 수 있습니다. '
                      f'직원 계정은 이 관리자가 등록합니다.</p>'
                      + _field("관리자 아이디", '<input class="ui-in" type="text" name="login" aria-label="관리자 아이디" '
                               'style="width:12em" maxlength="32" required placeholder="예: admin">',
                               "2~32자. 글자와 숫자, 기호 . _ - 를 씁니다.",
                               "글자나 숫자가 하나는 있어야 합니다. 사내망의 다른 PC에서는 첫 관리자를 만들 수 없습니다.")
                      + _field("이름", '<input class="ui-in" type="text" name="display_name" aria-label="이름" style="width:12em" '
                               'maxlength="40" placeholder="예: 김부장">')
                      + _field("비밀번호", '<input class="ui-in" type="password" name="password" aria-label="비밀번호" '
                               'style="width:12em" maxlength="256" required autocomplete="new-password">', "8자 이상, 아이디와 다르게")
                      + _field("한 번 더", '<input class="ui-in" type="password" name="password2" aria-label="비밀번호 한 번 더" '
                               'style="width:12em" maxlength="256" required autocomplete="new-password">')
                      + '<div style="margin-top:10px"><button class="ui-btn">첫 관리자 만들기</button></div></form>')
    # 관리자가 아직 없고 꺼져 있으면 순서를 번호로 — [양식함 켜기]가 '첫 관리자' 위에 있어 헷갈리던 것 (ux20 forms 11)
    h3 = '<h3 class="st-h4">'
    if not admin and not open_problem and not fs["enabled"]:
        first_steps = (f'<p class="ui-p">처음 쓰는 순서: <b>1) 첫 관리자 만들기</b> → <b>2) 양식함 켜기</b></p>'
                       f'{h3}1) 첫 관리자 만들기</h3>{admin_html}')
        onoff_head = f'{h3}2) 양식함 켜기</h3>'
        admin_later = ""
    else:
        first_steps, onoff_head = "", ""
        admin_later = f'{h3}첫 관리자</h3>{admin_html}'
    # 백업·주간 알림 (2026-10-30)
    from watcher.forms.backup import backup_dir_of
    b_line, b_ok = backup_status(cfg)
    b_tag = ('' if b_ok is None else ' <span class="ui-st ok">확인 OK</span>' if b_ok
             else ' <span class="ui-st hot">확인 실패</span>')
    # 화면 v2 (2026-11-18 KW2): '마지막 백업 … · DB … · 파일 … · 확인 …'을 한 줄에 잇지 않고 위아래로
    b_rows = "<br>".join(E(x) for x in b_line.split(" · "))
    b_default = backup_dir_of(data_dir_of(cfg), "")
    # 백업이 데이터와 같은 디스크면 경고 (2026-10-30) — 기본 위치는 그대로, 백업도 막지 않는다
    disk_warn = same_disk_warning(backup_dir_of(data_dir_of(cfg), fs["backup_dir"]), data_dir_of(cfg)) \
        if fs["backup_enabled"] else ""
    disk_html = (f'<p class="ui-note hot"><b>{E(disk_warn)}</b></p>') if disk_warn else ""
    r_cmd = restore_command(config_path or "config.yaml", str(backup_dir_of(data_dir_of(cfg), fs["backup_dir"])))
    wd_opts = "".join(f'<option value="{E(w)}"{" selected" if w == fs["digest_weekday"] else ""}>'
                      f'{E(w + "요일" if w != DIGEST_OFF else "끔")}</option>' for w in (DIGEST_OFF,) + WEEKDAYS)
    bad_vals = out_of_range(cfg)
    bad_html = ('<div class="ui-note hot"><b>config.yaml의 양식함 값 가운데 쓸 수 없는 것이 있어 기본값으로 쓰고 있습니다.</b>'
                '<ul style="margin:4px 0 0 18px">' + "".join(f"<li>{E(x)}</li>" for x in bad_vals)
                + '</ul>아래 칸에 범위 안의 값을 적고 [저장]하세요.</div>') if bad_vals else ""
    fw_cmd = firewall_command(fs["port"], _program_path())
    fw = (_field("방화벽", f'<pre class="st-cmd"><code>{E(fw_cmd)}</code></pre>',
                 "다른 PC에서 접속되지 않으면 관리자 권한 명령 프롬프트에서 위 한 줄을 한 번 실행하세요.",
                 "Windows 방화벽이 막고 있는 것입니다. 전산 담당이나 이 PC 관리자가 실행하면 됩니다. "
                 "사내망(개인·도메인 네트워크)에서만 엽니다. Drev는 이 명령을 스스로 실행하지 않습니다."
                 + (f"<br>설치판은 설치할 때 고른 경우 <b>{DEFAULT_PORT} 포트</b> 규칙(개인·도메인 네트워크만)을 더해 둡니다. "
                    "포트를 바꿨거나 설치 때 고르지 않았다면 위 명령을 쓰세요." if _installed() else "")))
    m_warn = '' if m_ok else '<span class="ui-st hot">지금은 보낼 수 없습니다.</span> <span class="ui-st">' + E(m_why) + '</span>'
    rm_v = '' if fs['review_months_default'] is None else fs['review_months_default']
    # 머리 두 문단(기록 열람·양식함)이 펼쳐져 있었다 — 한 문장 + '자세히' (2026-11-18 독립 검토 R2 중간 7).
    # 칸 설명(현행 미러·메일 알림·정기 검토 주기·백업 폴더·주간 알림)도 첫 문장과 경고만 밖에, 나머지는 _field(more=)로 접는다.
    # 메일 알림이 가리키던 '[메일 — SMTP 자동 발송]'은 없는 접기 이름이었다 — 설정 위쪽 '메일' 묶음 안의 'SMTP 자동 발송'
    boxes_intro = ('<p class="ui-p"><b>양식함</b>: 회사 양식(잔업집계표·신청서·BOM 양식 등)을 폴더로 나눠 올립니다. '
                   '검토자가 승인하면 판(v1, v2…)으로 관리하고, 직원들이 사내망의 다른 PC 브라우저로 내려받습니다. '
                   '감시와 따로 도는 별도 서버라, 꺼 두면 Drev는 지금과 같습니다.</p>')
    return f"""<div class="ui-sub-sec" id="forms"><h3>사내망 서버</h3>
<p class="ui-p">동료 PC 브라우저에서 변경 기록을 보고, 회사 양식을 주고받는 별도 서버입니다.</p>
<details class="ui-fold st-mini"><summary>자세히</summary><div class="ui-fold-body">{rec_intro}{boxes_intro}</div></details>
{_field("지금 상태", state, state_help)}
{first_steps}<div class="ui-inline" style="margin:8px 0 4px">{onoff_head}{onoff}</div>
<p class="ui-note hot" role="note"><b>사내망 전용입니다.</b> 이 포트를 인터넷으로 열지 마세요(포트 포워딩 금지).
암호화(HTTPS)가 없습니다. 인터넷(공인) 주소에서 온 접속은 거절합니다.</p>
{_field("직원 접속 주소", f'<ul class="ui-p" style="margin:0 0 0 18px">{who}</ul>',
        ('켠 뒤에 열립니다. ' if not fs['enabled'] else '')
        + (f'이 PC에서는 <a href="{E(local)}" target="_blank" class="ui-link">{E(local)}</a>' if local else ''))}
{admin_later}
<h3 class="st-h4">설정</h3>
{bad_html}
<form method="post" action="{PREFIX}save">{tok}
{_field("주소", f'<input class="ui-in" type="text" name="host" style="width:12em" list="forms-hosts" value="{E(fs['host'])}" aria-label="양식함 주소"><datalist id="forms-hosts">{host_opts}</datalist>',
        f"0.0.0.0 = 이 PC의 모든 사내망 주소. 후보: {E(', '.join(lan) or '찾지 못함')}")}
{_field("포트", f'<input class="ui-in" type="text" name="port" style="width:6em" value="{fs['port']}" aria-label="양식함 포트">',
        f"기본 {DEFAULT_PORT} (감시 화면 8765와 다르게)")}
{_field("현행 미러 폴더", f'<input class="ui-in st-wide" type="text" name="mirror_root" value="{E(fs['mirror_root'])}" placeholder="(선택) 예: \\\\서버\\공용\\양식\\현행" aria-label="현행 미러 폴더">',
        "승인된 현행 판을 폴더 구조대로 여기에 둡니다. "
        "<b>먼저 폴더를 만들어 두세요. 없으면 저장되지 않습니다. 감시 폴더 안은 피하세요.</b>" + _mirror_len_warn(fs['mirror_root']),
        "브라우저 없이 탐색기로 가져가는 직원용입니다. "
        "Drev가 둔 파일만 바꾸고 지우며, 사람이 넣은 파일은 건드리지 않습니다. 폐기한 양식은 여기서 빠집니다.")}
{_field("올리기 상한", f'<input class="ui-in" type="text" name="max_upload_mb" style="width:5em" value="{fs['max_upload_mb']}" aria-label="올리기 상한(MB)"> MB {_hint("1~2048")}')}
{_field("자동 비교 상한", f'<input class="ui-in" type="text" name="compare_timeout" style="width:5em" value="{fs['compare_timeout']}" aria-label="자동 비교 상한(초)"> 초 {_hint("5~3600")}')}
{_field("메일 알림", f'<label class="st-check"><input type="checkbox" name="notify" value="1"{' checked' if fs['notify'] else ''}> 승인·반려와 새 현행 판을 메일로 알림</label>',
        "설정 위쪽 메일 › 'SMTP 자동 발송'의 서버와 보내는 주소를 씁니다. " + m_warn,
        "승인·반려는 올린 사람에게, 새 현행 판은 폴더 구독자에게 갑니다. 받는 주소는 양식함 계정마다 관리자가 적습니다. "
        "하루 한 번 묶어 보내기와 새 현행 판을 모든 계정에게 보내기는 양식함 화면의 [관리 › 고급]에서 고릅니다(둘 다 기본 끔).")}
{_field("정기 검토 주기", f'<input class="ui-in" type="text" name="review_months_default" style="width:4em" value="{rm_v}" placeholder="끔" aria-label="정기 검토 기본 주기(개월)"> 개월',
        "0~120 (0 = 끔, 기본 끔). 양식을 정기적으로 다시 볼 때만 적으세요.",
        "ISO 문서 관리처럼 정기 검토를 하는 곳에 맞습니다. "
        "문서 관리 대장의 다음 검토 기한 = 최근 검토일·현행 판 승인일 중 늦은 날 + 이 주기. 양식마다 따로 정할 수 있습니다. "
        "비워 두면 새 설치는 끔이고, 이 기능이 바뀌기 전부터 양식을 쓰던 설치는 12개월 그대로입니다")}
<h3 class="st-h4" id="forms-backup">백업</h3>
{_field("마지막 백업", f'{b_rows}{b_tag}')}
{_field("자동 백업", f'<input type="hidden" name="backup_form" value="1"><label class="st-check"><input type="checkbox" name="backup_enabled" value="1"{' checked' if fs['backup_enabled'] else ''}> 매일 양식함 데이터와 판 파일을 백업 폴더에 둠</label>',
        "감시의 주간 백업에는 양식함이 들어가지 않습니다. 이 백업을 켜 두세요.",
        "forms.db(계정·폴더·판·승인·감사 기록)와 판 파일을 둡니다. 기본 켜짐입니다. 감시의 주간 백업은 state.db만 담습니다.")}
{_field("백업 폴더", f'<input class="ui-in st-wide" type="text" name="backup_dir" value="{E(fs['backup_dir'])}" placeholder="(비우면) {E(str(b_default))}" aria-label="양식함 백업 폴더">',
        "다른 디스크나 <code>\\\\서버\\백업</code> 같은 공유 폴더를 권합니다. 이 PC 디스크가 고장 나도 남습니다."
        + disk_html,
        "Drev 폴더 밖이면 먼저 폴더를 만들어 두세요. 계정 비밀번호 해시가 들어 있으니 관리자만 여는 곳에 두고, 현행 미러·감시 폴더 안은 피하세요."
        + f"<br>백업 위치 참고: {E(SAME_DISK_HINT)}")}
{_field("DB 사본 수", f'<input class="ui-in" type="text" name="backup_keep" style="width:4em" value="{fs['backup_keep']}" aria-label="DB 사본 수"> 개 {_hint("1~30")}',
        "가장 오래된 사본부터 덮어 씁니다. 판 파일 사본은 지우지 않고 쌓입니다.")}
{_field("백업 시각", f'<input class="ui-in" type="text" name="backup_hour" style="width:4em" value="{fs['backup_hour']}" aria-label="백업 시각(시)"> 시 {_hint("0~23")}',
        "이 시각 뒤 그날 처음 한 번 백업합니다.")}
{_field("복원", f'<pre class="st-cmd"><code>{E(r_cmd)} --dry-run\n{E(r_cmd)}</code></pre>',
        "복원은 명령으로만 합니다. [양식함 끄기] 뒤 먼저 미리보기(--dry-run)를 돌리세요.",
        "명령 프롬프트에서 실행합니다. 서버를 끈 같은 Windows 계정에서 실행하세요. 미리보기가 괜찮으면 두 번째 줄을 그대로 실행합니다.")}
<h3 class="st-h4">주간 알림</h3>
{_field("요일·시각", f'<div class="ui-inline"><select class="ui-in" name="digest_weekday" aria-label="주간 알림 요일">{wd_opts}</select>'
        f'<input class="ui-in" type="text" name="digest_hour" style="width:4em" value="{fs['digest_hour']}" aria-label="주간 알림 시각(시)"> 시 {_hint("0~23")}</div>',
        "한 주에 한 번 관리자·검토자에게 검토 기한과 대기 수를 메일로 보냅니다."
        + ('' if m_ok else '<br><span class="ui-st hot">사내 SMTP가 설정돼 있지 않아 지금은 보내지 않습니다</span>'),
        "기한 지남·30일 안·검토 대기 수를 보냅니다. 0건이면 보내지 않습니다(사내 메일 설정 필요). 받는 주소는 양식함 계정의 메일 주소입니다. "
        "기본은 월요일 8시이고, 받지 않으려면 '끔'을 고르고 [저장]하세요. 관리자에게는 보존 기간이 지난 판 수와(있을 때) 백업 디스크 경고(한 번)도 함께 갑니다.")}
<div class="ui-inline" style="margin-top:12px"><button class="ui-btn2">저장</button>
<span class="ui-st">{'저장하면 양식함 서버를 다시 시작해 바로 적용합니다' if fs['enabled'] else '켤 때 적용됩니다'}</span></div>
</form>
<h3 class="st-h4">방화벽</h3>
{fw}
<details class="ui-fold st-mini"><summary>자세히</summary><div class="ui-fold-body"><p class="ui-help">켜면 Windows 작업 스케줄러에
<code>DrevForms</code> 작업이 생깁니다. Windows에 로그인할 때 양식함 서버가 저절로 시작되고, 멈추면 1분 뒤 다시 시작합니다(매일 검사 작업
ProjectWatcher와는 별개). 데이터는 이 Drev 폴더의 <code>forms.db</code>·<code>forms_store</code>에, 기록은 <code>forms.log</code>에 남습니다.
끄면 서버와 자동 시작만 멈추고 양식·계정·이력은 그대로 둡니다. Drev 업데이트 때는 교체하는 동안 잠시 멈췄다가 다시 시작합니다.</p></div></details>
</div>"""


def _restart_if_on(cfg: dict) -> str:
    fs = forms_settings(cfg)
    if not fs["enabled"]:
        return ""
    from watcher.cli import forms_task_start, forms_task_stop
    forms_task_stop()
    return " 양식함 서버를 다시 시작했습니다." if forms_task_start() else " (서버를 다시 시작하지 못했습니다 — [다시 시작])"


def handle_post(app, path: str, q: dict) -> str:
    """POST /formsbox/<동작> 처리 → 화면에 보일 한 줄. app: 감시 화면 앱(WebApp — cfg(), _save_key(), config_path)."""
    action = path[len(PREFIX):] if path.startswith(PREFIX) else ""
    cfg = app.cfg()
    cur = dict(cfg.get("forms") or {}) if isinstance(cfg.get("forms"), dict) else {}

    def one(k: str) -> str:
        return str((q.get(k) or [""])[0] or "")

    if action == "save":
        from watcher.forms.settings import check_host
        try:
            host = check_host(one("host").strip() or "0.0.0.0")
            port = check_port(one("port") or DEFAULT_PORT)
            mirror = check_mirror_root(one("mirror_root"))
            up = int(one("max_upload_mb").strip() or 50)
            ct = int(one("compare_timeout").strip() or 60)
            rm_raw = one("review_months_default").strip()
            rm = int(rm_raw) if rm_raw else None          # 비우면(옛 화면) 저장값을 건드리지 않는다
        except ValueError:
            return "올리기 상한·자동 비교 상한·정기 검토 주기는 숫자로 적어 주세요 — 저장하지 않았습니다."
        except FormsError as e:
            return f"{e} — 저장하지 않았습니다."
        if not 1 <= up <= 2048:
            return "올리기 상한은 1~2048 MB로 적어 주세요 — 저장하지 않았습니다."
        if not 5 <= ct <= 3600:
            return "자동 비교 상한은 5~3600초로 적어 주세요 — 저장하지 않았습니다."
        if rm is not None and not 0 <= rm <= 120:
            return "정기 검토 주기는 0~120개월로 적어 주세요(0 = 끔) — 저장하지 않았습니다."
        if mirror and _inside_watch(cfg, mirror):
            return "현행 미러 폴더가 감시 폴더 안에 있습니다 — 감시 밖의 폴더를 골라 주세요(저장하지 않았습니다)."
        extra = {}
        if one("backup_form") == "1":                     # 백업·주간 알림 칸 (2026-10-30) — 옛 화면이 보낸 저장에는 없다
            try:
                extra = _backup_fields(cfg, one, mirror)
            except FormsError as e:
                return f"{e} — 저장하지 않았습니다."
        cur.update(host=host, port=port, mirror_root=mirror, max_upload_mb=up, compare_timeout=ct,
                   notify=one("notify") == "1")
        cur.update(extra)
        if rm is not None:
            cur["review_months_default"] = rm
        cur.setdefault("enabled", False)
        app._save_key("forms", cur)
        return "양식함 설정을 저장했습니다." + _restart_if_on(app.cfg())
    if action in ("on", "on_records"):
        # on_records = 사내망 기록 열람만 (2026-11-17 R3) — 같은 켜기 흐름(DrevForms 작업)에 양식 기능만 끈다.
        # [양식함 켜기]는 전에 기록 열람만으로 켰던 설정이어도 양식 기능을 켠다(그 단추를 누른 뜻대로)
        from watcher.cli import forms_task_register
        cur.setdefault("host", "0.0.0.0")
        cur.setdefault("port", DEFAULT_PORT)
        cur["enabled"] = True
        if action == "on_records":
            cur["boxes"] = False
        elif "boxes" in cur:
            cur["boxes"] = True
        app._save_key("forms", cur)
        ok, msg = forms_task_register(app.config_path)
        if not ok:
            cur["enabled"] = False
            app._save_key("forms", cur)
        elif action == "on_records":
            msg = (f"{msg} — 사내망 기록 열람만 켰습니다(양식 기능 없음). 직원 계정을 등록하고 [계정]에서 볼 수 있는 프로젝트를 "
                   "정해 주세요.") if msg else "사내망 기록 열람만 켰습니다."
        return msg
    if action in ("boxes_on", "boxes_off"):
        if not forms_settings(cfg)["enabled"]:
            return "사내망 서버가 꺼져 있습니다 — 먼저 켜 주세요."
        cur["boxes"] = action == "boxes_on"
        app._save_key("forms", cur)
        what = "양식 기능을 켰습니다." if cur["boxes"] else "양식 기능을 껐습니다 — 사내망 기록 열람만 남습니다(양식·판 데이터는 그대로)."
        return what + _restart_if_on(app.cfg())
    if action == "off":
        from watcher.cli import forms_task_unregister
        cur["enabled"] = False
        app._save_key("forms", cur)
        ok, msg = forms_task_unregister()
        if not ok and not _task_status().get("exists"):
            return "양식함을 껐습니다 — 자동 시작 작업은 이미 없었습니다. 양식·계정·이력은 그대로 남습니다."
        return msg
    if action == "restart":
        msg = _restart_if_on(cfg)
        return msg.strip() or "양식함이 꺼져 있습니다 — 먼저 [양식함 켜기]를 누르세요."
    if action == "admin":
        return _first_admin(cfg, one("login").strip(), one("display_name").strip(), one("password"), one("password2"))
    return "알 수 없는 요청입니다."


def _overlap(a: str, b: str) -> bool:
    """두 폴더가 같거나 한쪽이 다른 쪽 안인가."""
    import os
    try:
        x = os.path.normcase(os.path.realpath(a)).rstrip("\\/")
        y = os.path.normcase(os.path.realpath(b)).rstrip("\\/")
    except (OSError, ValueError):
        return False
    return x == y or x.startswith(y + os.sep) or y.startswith(x + os.sep)


def _backup_fields(cfg: dict, one, mirror: str) -> dict:
    """백업·주간 알림 칸 검사 → 저장할 값. 범위 밖·없는 폴더면 FormsError (기본값으로 바꿔 저장하지 않는다)."""
    bdir = check_backup_dir(one("backup_dir"), data_dir_of(cfg))
    if bdir:
        if mirror and _overlap(bdir, mirror):
            raise FormsError("백업 폴더와 현행 미러 폴더가 겹칩니다 — 미러는 직원들이 여는 곳이라 백업(계정 정보 포함)을 두면 안 됩니다")
        if _inside_watch(cfg, bdir):
            raise FormsError("백업 폴더가 감시 폴더 안에 있습니다 — 감시 밖의 폴더를 골라 주세요")
    wd = one("digest_weekday").strip() or DIGEST_DEFAULT
    if wd not in WEEKDAYS and wd != DIGEST_OFF:
        raise FormsError("주간 알림 요일은 끔 또는 월~금 가운데 하나입니다")
    return {"backup_enabled": one("backup_enabled") == "1", "backup_dir": bdir,
            "backup_keep": check_int(one("backup_keep") or 4, "backup_keep"),
            "backup_hour": check_int(one("backup_hour") or 3, "backup_hour"),
            "digest_weekday": wd, "digest_hour": check_int(one("digest_hour") or 8, "digest_hour")}


def _inside_watch(cfg: dict, folder: str) -> bool:
    """미러 폴더가 감시 폴더 안(또는 같음)인가 — 미러에 둔 판이 감시의 '추가·변경'으로 잡히지 않게."""
    from watcher.forms.settings import inside_watch_root
    return bool(inside_watch_root(folder, cfg.get("roots") or []))


def _first_admin(cfg: dict, login: str, name: str, pw: str, pw2: str) -> str:
    """첫 관리자 — 이 화면(감시 화면)은 127.0.0.1에만 열리므로 is_local=True."""
    if pw != pw2:
        return "비밀번호 두 칸이 서로 다릅니다 — 관리자를 만들지 않았습니다."
    from watcher.forms import auth
    from watcher.forms.store import FormsStore
    try:
        with FormsStore(data_dir_of(cfg)) as st:
            auth.create_first_admin(st, login, name or login, pw, is_local=True, ip="127.0.0.1")
    except FormsError as e:
        return f"관리자를 만들지 못했습니다 — {e}"
    return (f"양식함 첫 관리자 '{login}'를 만들었습니다 — 양식함 화면에서 이 아이디로 로그인해 폴더를 만들고 "
            f"[계정]에서 직원을 등록하세요.")
