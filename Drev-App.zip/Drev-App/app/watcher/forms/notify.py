# -*- coding: utf-8 -*-
"""양식함 메일 알림 (FORMS.md 4절 6, 2026-10-28 F4).

- 승인·반려 → 올린 사람에게, 새 현행 판 → 그 폴더(또는 위 폴더) 구독자에게.
  검토 완료(2단계 승인, 2026-10-30) → 그 폴더를 볼 수 있는 승인권자에게 '승인 요청'(없으면 관리자, 올린 사람·검토한 사람 빼고).
- 감시 브리핑과 같은 사내 SMTP 설정(config.yaml `mail:` — 서버·포트·보안 방식·보내는 주소·로그인)을 다시 쓴다.
  보내는 함수는 watcher.mail.send_brief 하나다. 받는 사람은 계정에 적힌 메일 주소(관리자가 등록 화면에서 선택 입력).
- 보내기는 배경 스레드 하나(forms-mail)가 줄 세워 한다 — 메일 서버가 느리거나 죽어도 화면 동작(승인·반려)을 막지 않는다.
  실패는 감사 기록(notify_fail)과 로그에만 남고 아무것도 되돌리지 않는다.
- 메일 본문에는 양식 이름·판·사유·메모와 양식함 주소만 싣는다. 파일 자체는 붙이지 않는다(원칙 1).
"""

from __future__ import annotations

import html
import logging
import queue
import threading

from watcher.forms.store import FormsStore

log = logging.getLogger("drev.forms.server")

SUBJECT_PREFIX = "[Drev 양식함] "
QUEUE_MAX = 500
BATCH_KEY = "notify_batch_queue"        # 묶어 보낼 알림 (forms.db meta, JSON 목록 — F2-14)
BATCH_SENT_KEY = "notify_batch_sent"    # 묶음을 마지막으로 보낸 날 (YYYY-MM-DD)
BATCH_MAX = 2000
E = html.escape


def _default_send(mail_cfg: dict, subject: str, html_body: str) -> bool:
    from watcher.mail import send_brief
    return send_brief(mail_cfg, subject, html_body)


def mail_ready(mail_cfg: dict | None) -> tuple[bool, str]:
    """사내 SMTP 설정으로 보낼 수 있나 — (가능, 안 되는 까닭)."""
    m = mail_cfg or {}
    if not str(m.get("smtp_host") or "").strip():
        return False, "메일 서버(SMTP)가 설정돼 있지 않습니다 — 감시 화면 설정 › 메일에서 서버·보내는 주소를 채우세요"
    if not str(m.get("sender") or "").strip():
        return False, "보내는 주소가 없습니다 — 감시 화면 설정 › 메일에서 채우세요"
    return True, ""


def _cell(v) -> str:
    """표 칸 — 글자, 또는 (글자, 링크 글자, 주소): 주소가 있으면 링크 글자를 링크로 (2026-10-31 주간 알림 '정리할 판')."""
    if isinstance(v, tuple):
        text, label, url = v
        return E(text) + (f' <a href="{E(url)}">{E(label)}</a>' if url else "")
    return E(v)


def _page(title: str, rows: list[tuple[str, str]], link: str, *, links: tuple = ()) -> str:
    """알림 메일 본문. links: (글자, 주소) 여러 개 — 주간 알림의 '검토 기한 목록'·'검토 대기' (2026-10-30)."""
    trs = "".join(f'<tr><td style="color:#57606a;padding:3px 12px 3px 0;white-space:nowrap">{E(k)}</td>'
                  f'<td style="padding:3px 0">{_cell(v)}</td></tr>' for k, v in rows if v)
    go = (f'<p style="margin-top:14px"><a href="{E(link)}">양식함에서 열기</a> '
          f'<span style="color:#57606a">(사내망에서만 열립니다)</span></p>') if link else ""
    many = [(t, u) for t, u in links if u]
    if many:
        go += ('<p style="margin-top:14px">' + " · ".join(f'<a href="{E(u)}">{E(t)}</a>' for t, u in many)
               + ' <span style="color:#57606a">(사내망에서만 열립니다)</span></p>')
    return (f'<div style="font-family:\'Malgun Gothic\',sans-serif;font-size:14px;color:#1f2328">'
            f'<h2 style="font-size:17px;margin:0 0 10px">{E(title)}</h2>'
            f'<table style="border-collapse:collapse">{trs}</table>{go}'
            f'<p style="color:#57606a;font-size:12px;margin-top:16px">Drev 양식함이 보낸 알림입니다. '
            f'이 메일에 답장해도 양식함에는 남지 않습니다.</p></div>')


class Notifier:
    """메일 알림 — 서버가 하나 쥔다. send(mail_cfg, subject, html)는 시험에서 바꿔 끼운다."""

    def __init__(self, store: FormsStore, mail_cfg: dict, *, base_url: str = "", send=None):
        self.store = store
        self.mail_cfg = dict(mail_cfg or {})
        self.base_url = str(base_url or "").rstrip("/")
        self._send = send or _default_send
        self._q: queue.Queue = queue.Queue(maxsize=QUEUE_MAX)
        self._thread: threading.Thread | None = None
        self._start_lock = threading.Lock()
        self.sent = 0
        self.failed = 0
        self._batch_lock = threading.Lock()   # 묶음 대기열(meta)을 쌓기·비우기가 겹치지 않게 (F2-14)
        self._closed = False              # close()가 남은 메일을 비운 뒤 — 저장소가 닫히므로 감사 기록 대신 로그만

    # ── 알림 만들기 (요청 스레드에서 — 가볍다) ──────────────────────────────

    def _link(self, path: str) -> str:
        return f"{self.base_url}{path}" if self.base_url else ""

    def approved(self, submission_id) -> None:
        d = self.store.submission_notice(submission_id)
        if not d or not d["submitter_email"]:
            return
        if d.get("decided_by") is not None and d.get("decided_by") == d.get("submitted_by"):
            return                              # 자기가 올린 것을 자기가 승인 — 자기에게 메일을 보내지 않는다 (2026-10-30)
        ver = f"v{d['number']}" if d.get("number") else ""
        title = f"승인됨: {d['form_name']} {ver}".strip()
        sees = d.get("submitter_sees", True)        # 기밀 폴더를 볼 수 없게 된 사람에게는 폴더 경로·양식 링크를 싣지 않는다 (2026-10-30)
        rows = [("양식", d["form_name"]), ("폴더", " / ".join(d["folder_names"]) if sees else ""), ("현행 판", ver),
                ("파일", d["filename"]), ("승인한 사람", d["decided_by_name"]), ("승인 메모", d["decision_note"])]
        self._enqueue([d["submitter_email"]], title,
                      _page(title, rows, self._link(f"/form?id={d['form_id']}" if d.get("form_id") and sees
                                                    else "/mine")),
                      f"submission:{submission_id}", batchable=True)

    def rejected(self, submission_id) -> None:
        d = self.store.submission_notice(submission_id)
        if not d or not d["submitter_email"]:
            return
        title = f"반려됨: {d['form_name']}"
        sees = d.get("submitter_sees", True)
        rows = [("양식", d["form_name"]), ("폴더", " / ".join(d["folder_names"]) if sees else ""), ("파일", d["filename"]),
                ("반려한 사람", d["decided_by_name"]), ("반려 사유", d["reason"])]
        self._enqueue([d["submitter_email"]], title, _page(title, rows, self._link("/mine")),
                      f"submission:{submission_id}", batchable=True)

    def checked(self, submission_id) -> None:
        """검토 완료(2단계 승인의 1단계) → 그 폴더 승인권자에게 '승인 요청' (2026-10-30). 받는 사람은 store.approval_recipients —
        그 폴더를 볼 수 있는 승인권자(없으면 관리자), 올린 사람·검토한 사람 자신은 뺀다. 메일 주소가 있는 사람만."""
        d = self.store.submission_notice(submission_id)
        if not d or d.get("status") != "pending" or not d.get("checked_at"):
            return
        to = []
        for u in self.store.approval_recipients(submission_id):
            em = (u.get("email") or "").strip()
            if em and em.lower() not in {t.lower() for t in to}:
                to.append(em)
        if not to:
            return
        title = f"승인 요청: {d['form_name']}"
        rows = [("양식", d["form_name"]), ("폴더", " / ".join(d["folder_names"])), ("파일", d["filename"]),
                ("올린 사람", d["submitted_by_name"]), ("바꾼 내용·설명", d["note"]),
                ("검토한 사람", d["checked_by_name"]), ("검토 메모", d["check_memo"])]
        self._enqueue(to, title, _page(title, rows, self._link(f"/review/item?id={submission_id}")),
                      f"submission:{submission_id}")

    def new_current(self, version_id, *, skip: tuple = ()) -> None:
        """새 현행 판 — 폴더 구독자에게. skip: 이미 승인 메일을 받는 주소(올린 사람).
        기밀 폴더면 그 폴더를 볼 수 있는 구독자에게만 간다(store.subscribers가 거른다, 2026-10-30)."""
        v = self.store.version_notice(version_id)
        if not v:
            return
        skip_l = {str(s).lower() for s in skip if s}
        to = []
        people = list(self.store.subscribers(v["folder_id"]))
        if self.store.option("notify_all_current") == "1":
            # 관리 › 고급 '새 현행 판은 메일 주소가 있는 모든 계정에게' (기능 검토 F2-4) — 기밀 폴더는 볼 수 있는 사람만
            people += self.store.all_mail_recipients(v["folder_id"])
        for u in people:
            em = (u.get("email") or "").strip()
            if em and em.lower() not in skip_l and em.lower() not in {t.lower() for t in to}:
                to.append(em)
        if not to:
            return
        title = f"새 현행 판: {v['form_name']} v{v['number']}"
        rows = [("양식", v["form_name"]), ("폴더", " / ".join(v["folder_names"])), ("현행 판", f"v{v['number']}"),
                ("파일", v["filename"]), ("승인한 사람", v["approved_by_name"]), ("설명", v["note"])]
        self._enqueue(to, title, _page(title, rows, self._link(f"/form?id={v['form_id']}")),
                      f"version:{version_id}", batchable=True)

    def digest(self, u: dict) -> None:
        """주간 알림 한 통 (2026-10-30, weekly.py) — u: {user_id, name, email, role, overdue, soon, pending}."""
        if not u.get("email"):
            return
        keep = int(u.get("retention") or 0)
        appr = int(u.get("approve") or 0)            # 2단계 승인 — 내가 승인할 수 있는 승인 대기 (2026-10-30)
        title = (f"이번 주 할 일: 검토 기한 지남 {u['overdue']} · 곧 {u['soon']} · 검토 대기 {u['pending']}"
                 + (f" · 승인 대기 {appr}" if appr else "")
                 + (f" · 보존 기간 지난 판 {keep}" if keep else ""))
        rows = [("받는 사람", u.get("name") or u.get("login") or ""),
                ("범위", "전체 폴더(관리자)" if u.get("role") == "admin" else "맡은 폴더와 그 아래"),
                ("정기 검토 기한 지남", f"{u['overdue']}개"), ("30일 안에 기한", f"{u['soon']}개"),
                ("검토 대기 제출", f"{u['pending']}건")]
        if appr:
            rows.append(("승인 대기 (2단계 승인)", f"{appr}건 — 검토자가 검토 완료한 것, 내가 승인할 수 있는 것"))
        if keep:                                     # 관리자만 (2026-10-30 기록 보존 만료)
            url = self._link("/admin/retention")     # 주소 글자 대신 링크 — 다른 링크와 같게 (2026-10-31 실사용 검토)
            rows.append(("정리할 판", (f"보존 기간이 지난 판 {keep}개 —", "보존 만료 화면에서 정리", url) if url
                                     else f"보존 기간이 지난 판 {keep}개 — 양식함의 [보존 만료] 화면에서 정리하세요"))
        if u.get("disk_warn"):                       # 관리자에게 한 번 (2026-10-30 같은 디스크 백업)
            rows.append(("백업 경고", str(u["disk_warn"])))
        links = (("검토 기한 목록", self._link("/register/due")), ("검토 대기", self._link("/review")))
        if appr:
            links += (("승인 대기", self._link("/review?stage=approve")),)
        if keep:
            links += (("보존 만료 정리", self._link("/admin/retention")),)
        self._enqueue([u["email"]], title, _page(title, rows, "", links=links), f"user:{u['user_id']}",
                      ok_action="digest_sent")

    def login_spray(self, login: str, ips: int, fails: int) -> None:
        """한 아이디에 여러 주소에서 로그인 실패가 몰림 → 메일 주소가 있는 관리자에게 (검토20 r09-1).
        본문에는 아이디·횟수·주소 수만 — 주소 자체는 감사 기록에서 본다."""
        to = []
        for (em,) in self.store.conn.execute(
                "SELECT email FROM users WHERE role = 'admin' AND disabled = 0 AND IFNULL(email, '') != '' "
                "ORDER BY login_key").fetchall():
            em = str(em).strip()
            if em and em.lower() not in {t.lower() for t in to}:
                to.append(em)
        if not to:
            return
        title = f"로그인 실패가 몰림: 아이디 {login}"
        rows = [("아이디", login), ("실패", f"최근 10분에 {fails}번 — 서로 다른 접속 주소 {ips}곳에서"),
                ("조치", "이 아이디는 당분간 1분에 한 번만 로그인을 받습니다(잠그지는 않음). 본인이 아니면 비밀번호를 "
                         "초기화하고, 감사 기록(login_spray·login_fail)에서 접속 주소를 확인하세요")]
        self._enqueue(to, title, _page(title, rows, self._link("/admin/audit")), f"login:{login}",
                      ok_action="notify")

    def temp_password(self, email: str, login: str, name: str, temp: str) -> None:
        """일괄 등록에서 관리자가 고른 경우에만 — 임시 비밀번호를 그 사람 메일로 (기능 검토 F2-2, 사내 SMTP, 기본 끔).
        묶지 않는다(바로 보낸다). 감사 기록에는 비밀번호를 적지 않는다."""
        if not email:
            return
        title = f"양식함 계정이 만들어졌습니다: {login}"
        rows = [("이름", name), ("아이디", login), ("임시 비밀번호", temp),
                ("안내", "처음 로그인하면 새 비밀번호로 바꿔야 합니다. 이 메일은 바꾼 뒤 지워 주세요.")]
        self._enqueue([email], title, _page(title, rows, self._link("/login")), f"user:{login}")

    # ── 하루 한 번 묶어 보내기 (기능 검토 F2-14) ──────────────────────────────
    # 켜면 승인·반려·새 현행 판 메일을 바로 보내지 않고 forms.db meta(BATCH_KEY)에 쌓았다가, 정한 시각(기본 17시)이 지난 뒤
    # 첫 요청이나 정리 타이머 때 받는 사람마다 한 통으로 보낸다. 서버를 껐다 켜면 쌓인 것을 시작할 때 보낸다.

    def batching(self) -> bool:
        try:
            return self.store.option("notify_batch") == "1"
        except Exception:
            return False

    def _stash(self, recipients: list, title: str, body: str, target: str) -> None:
        import json
        with self._batch_lock:
            try:
                with self.store.tx():
                    raw = self.store.meta_get(BATCH_KEY, "[]")
                    try:
                        items = json.loads(raw) if raw else []
                    except ValueError:
                        items = []
                    if len(items) >= BATCH_MAX:
                        raise OverflowError
                    items.append({"to": list(recipients), "title": title, "body": body, "target": target,
                                  "at": self.store.clock()})
                    self.store.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                                            (BATCH_KEY, json.dumps(items, ensure_ascii=False)))
            except OverflowError:
                self._fail(target, len(recipients), "묶음 알림이 너무 많이 쌓여 이 알림은 버렸습니다")

    def batch_pending(self) -> int:
        import json
        try:
            return len(json.loads(self.store.meta_get(BATCH_KEY, "[]") or "[]"))
        except (ValueError, Exception):
            return 0

    def batch_due(self, now: float | None = None) -> bool:
        """지금 묶음을 보낼 때인가 — 묶기가 꺼졌거나(남은 것을 바로), 정한 시각이 지났고 오늘 아직 안 보냈을 때."""
        import time as _t
        if not self.batch_pending():
            return False
        if not self.batching():
            return True
        t = _t.localtime(self.store.clock() if now is None else now)
        try:
            hour = int(self.store.option("notify_batch_hour"))
        except ValueError:
            hour = 17
        today = _t.strftime("%Y-%m-%d", t)
        return t.tm_hour >= hour and self.store.meta_get(BATCH_SENT_KEY, "") != today

    def flush_batch(self, *, force: bool = False) -> int:
        """쌓인 묶음을 받는 사람마다 한 통으로 줄 세운다. 보낸(줄 세운) 통 수. force: 시각과 상관없이(서버 시작 때)."""
        import json
        import time as _t
        with self._batch_lock:
            if not force and not self.batch_due():
                return 0
            with self.store.tx():
                raw = self.store.meta_get(BATCH_KEY, "[]")
                self.store.conn.execute("DELETE FROM meta WHERE key = ?", (BATCH_KEY,))
                if self.batching():
                    self.store.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                                            (BATCH_SENT_KEY, _t.strftime("%Y-%m-%d", _t.localtime(self.store.clock()))))
            try:
                items = json.loads(raw) if raw else []
            except ValueError:
                items = []
        per: dict = {}
        for it in items:
            for addr in it.get("to") or []:
                per.setdefault(str(addr).lower(), (str(addr), []))[1].append(it)
        n = 0
        for _k, (addr, its) in per.items():
            title = f"오늘의 양식함 알림 {len(its)}건"
            parts = "".join(f'<div style="border-top:1px solid #d0d7de;padding-top:10px;margin-top:10px">{x["body"]}</div>'
                            for x in its)
            body = (f'<div style="font-family:\'Malgun Gothic\',sans-serif;font-size:14px;color:#1f2328">'
                    f'<h2 style="font-size:17px;margin:0 0 6px">{E(title)}</h2>'
                    f'<p style="color:#57606a;margin:0">관리자가 알림을 하루 한 번 묶어 보내도록 정했습니다 — '
                    + E(", ".join(x["title"] for x in its))[:600] + f'</p>{parts}</div>')
            self._enqueue([addr], title, body, f"batch:{len(its)}")
            n += 1
        return n

    # ── 보내기 (배경 스레드) ───────────────────────────────────────────────

    def _enqueue(self, recipients: list, title: str, body: str, target: str, *, ok_action: str = "notify",
                 batchable: bool = False) -> None:
        if batchable and self.batching():
            self._stash(recipients, title, body, target)
            return
        self._ensure_thread()
        try:
            self._q.put_nowait((list(recipients), SUBJECT_PREFIX + title, body, target, ok_action))
        except queue.Full:
            self._fail(target, len(recipients), "보낼 메일이 너무 많이 밀려 이 알림은 버렸습니다")

    def _ensure_thread(self) -> None:
        with self._start_lock:
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._loop, name="forms-mail", daemon=True)
                self._thread.start()

    def _loop(self) -> None:
        while True:
            job = self._q.get()
            try:
                if job is None or self._closed:
                    return
                self._deliver(*job)
            except Exception:
                log.exception("양식함 메일 알림: 예상 못 한 오류")
            finally:
                self._q.task_done()

    def _deliver(self, recipients: list, subject: str, body: str, target: str, ok_action: str = "notify") -> None:
        ok, why = mail_ready(self.mail_cfg)
        if not ok:
            self._fail(target, len(recipients), why)
            return
        good = 0
        for addr in recipients:              # 한 사람씩 — 받는 사람끼리 주소가 보이지 않게, 한 주소 거부가 나머지를 막지 않게
            cfg = {**self.mail_cfg, "enabled": True, "recipients": [addr]}
            try:
                if self._send(cfg, subject, body):
                    good += 1
                else:
                    self._fail(target, 1, "보내지 못했습니다(받는 사람 없음)")
            except Exception as e:                   # 메일 실패는 아무것도 되돌리지 않는다
                self._fail(target, 1, f"{type(e).__name__}: {e}")
        if good:
            self.sent += good
            log.info("양식함 메일 알림 %d통: %s", good, subject)
            if self._closed:
                return
            try:
                self.store.record_audit(None, ok_action, target, detail=f"{subject} → {good}명", login="(양식함)")
            except Exception:
                log.exception("양식함 메일 알림: 감사 기록 실패")

    def _fail(self, target: str, n: int, why: str) -> None:
        self.failed += n
        log.warning("양식함 메일 알림 실패(%s): %s", target, why)
        if self._closed:
            return
        try:
            self.store.record_audit(None, "notify_fail", target, detail=str(why)[:500], login="(양식함)")
        except Exception:
            log.exception("양식함 메일 알림: 감사 기록 실패")

    def drain(self, timeout: float = 10.0) -> bool:
        """줄 선 메일을 다 보낼 때까지 기다린다(시험·종료용). 다 보냈으면 True."""
        done = threading.Event()

        def _wait():
            self._q.join()
            done.set()
        threading.Thread(target=_wait, daemon=True).start()
        return done.wait(timeout)

    def close(self, timeout: float = 5.0) -> None:
        """서버를 끌 때 — 줄 선 메일을 timeout까지 보내 보고, 그래도 남은 것은 버리되 통마다 notify_fail
        '서버 종료로 보내지 못함'을 감사 기록에 남긴다(저장소를 닫기 전에). 소리 없이 사라지던 것 (검토20 r10-4).
        시한이 지나도 보내는 중인 한 통은 끝까지 가지만 그 결과는 로그에만 남긴다(저장소가 닫히므로)."""
        t = self._thread
        if t is not None and t.is_alive():
            try:
                self._q.put_nowait(None)
            except queue.Full:
                pass                              # 끝 표식을 못 넣어도 아래에서 남은 것을 비우고 _closed로 멈춘다
            t.join(timeout)
        self._drop_rest()

    def _drop_rest(self) -> None:
        """줄에 남은 메일을 꺼내 버리고 기록한다 — 그 뒤 배경 스레드는 새 일을 받지 않는다."""
        dropped = []
        while True:
            try:
                job = self._q.get_nowait()
            except queue.Empty:
                break
            try:
                if job is not None:
                    dropped.append(job)
            finally:
                self._q.task_done()
        for recipients, subject, _body, target, _ok in dropped:
            self._fail(target, len(recipients), f"서버 종료로 보내지 못함 — {subject}")
        self._closed = True
