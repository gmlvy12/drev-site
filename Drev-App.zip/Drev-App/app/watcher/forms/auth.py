# -*- coding: utf-8 -*-
"""양식함 계정·로그인 (FORMS.md 3·6절, 2026-10-28 F1).

- 비밀번호: pbkdf2_hmac(sha256, 60만 회, 솔트 16B), 비교는 상수 시간(hmac.compare_digest).
- 세션: 32B 난수 토큰(원문은 저장하지 않고 sha256만), 유휴 8시간·절대 7일 만료, 세션별 CSRF 토큰.
- 로그인 실패 잠금: 같은 아이디+IP로 5번 틀리면 5분. 주소(IP) 단위로도 아이디 상관없이 10분에 20번이면 15분,
  10번을 넘으면 점증 지연(2026-10-28 보안 F2). 오래된 실패 행은 지운다(cleanup_failures, 보안 F1).
- 정지된 계정은 맞는 비밀번호여도 일반 실패와 같은 응답(보안 F5).
- 비밀번호 정책: 8자 이상, 아이디와 같으면 안 됨. 초기화된 비밀번호는 첫 로그인 때 바꿔야 한다(must_change).
- 계정은 관리자가 등록한다(스스로 가입 없음). 첫 관리자는 Drev PC(127.0.0.1)에서만, 관리자가 하나도 없을 때만.
- 마지막 관리자는 정지·강등할 수 없다.

이 모듈은 파일을 쓰지 않는다 — forms.db만 store.FormsStore 트랜잭션으로 바꾼다.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
import unicodedata
from dataclasses import dataclass

from watcher.forms.store import (ROLES, Conflict, FormsError, FormsStore, InvalidInput, NotFound,
                                 PermissionDenied, _plain_text, _user_dict, name_key, now_text)

ITERATIONS = 600_000
SALT_BYTES = 16
TOKEN_BYTES = 32
IDLE_SECONDS = 8 * 3600
ABSOLUTE_SECONDS = 7 * 24 * 3600
LOCK_THRESHOLD = 5
LOCK_SECONDS = 5 * 60
FAIL_WINDOW = 15 * 60          # 계정+IP 실패 횟수는 이만큼 실패가 없으면 0부터 (행도 지운다 — 보안 F1 TTL)
# 주소(IP) 단위 — 계정을 돌려 가며 대입하는 것을 막는다 (2026-10-28 보안 F2)
IP_WINDOW = 10 * 60            # 이 창(초) 안의 실패를 아이디 상관없이 센다
IP_THRESHOLD = 20              # 창 안에서 이만큼 실패하면 그 주소를 잠근다
IP_LOCK_SECONDS = 15 * 60
IP_DELAY_AFTER = 10            # 창 안 실패가 이만큼을 넘으면 다음 시도까지 기다리게 한다(점증 지연)
IP_DELAY_MAX = 30              # 점증 지연 상한(초) — 2, 4, 8, 16, 30, 30…
MAX_SESSIONS = 10              # 계정마다 남기는 세션 수(가장 최근 것부터) — 2026-10-30 L2
MIN_PASSWORD = 8
MAX_PASSWORD = 256
_LOGIN_RE = re.compile(r"^[\w.\-]{2,32}$")
# 임시 비밀번호 글자 — 헷갈리는 0/O·1/l/I 를 뺐다
_TEMP_ALPHABET = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"


class LoginFailed(FormsError):
    """아이디·비밀번호가 틀렸거나 쓸 수 없는 계정."""


class LoginLocked(FormsError):
    """실패가 겹쳐 잠시 잠김. seconds = 남은 초.
    kind: 'account'(아이디+주소 잠금) · 'ip'(주소 전체 잠금, 보안 F2) · 'delay'(점증 지연 — 잠깐 기다리기)."""

    def __init__(self, seconds: int, kind: str = "account"):
        self.seconds = int(seconds)
        self.kind = kind
        super().__init__(locked_text(self.seconds, kind))


def _left_text(seconds: int) -> str:
    mins, secs = divmod(max(1, int(seconds)), 60)
    return f"{mins}분 {secs}초" if mins and secs else (f"{mins}분" if mins else f"{secs}초")


def locked_text(seconds: int, kind: str = "account") -> str:
    """잠김 안내 (쉬운 말). 주소 잠금은 같은 공유기를 쓰는 PC가 함께 막힌다는 것까지 알린다."""
    left = _left_text(seconds)
    if kind == "ip":
        return (f"이 접속 주소에서 로그인 실패가 너무 많아 잠시 막았습니다 — {left} 뒤에 다시 해 주세요. "
                f"같은 공유기(사내망 주소)를 쓰는 다른 PC도 함께 막힙니다. 급하면 관리자에게 풀어 달라고 하세요")
    if kind == "delay":
        return f"로그인 실패가 잦아 잠깐 기다려야 합니다 — {left} 뒤에 다시 해 주세요"
    return f"로그인 실패가 많아 잠겼습니다 — {left} 뒤에 다시 해 주세요"


class LastAdmin(Conflict):
    """마지막 관리자를 정지·강등하려 했다."""


@dataclass
class Session:
    token: str               # 쿠키에 넣을 원문 (로그인 때만 채워진다 — 조회 때는 넘겨받은 값)
    csrf: str
    user_id: int
    login: str
    display_name: str
    role: str
    must_change: bool
    created_at: float
    last_seen: float


# ── 비밀번호 ─────────────────────────────────────────────────────────────

def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def hash_password(password: str, *, iterations: int | None = None) -> str:
    """'pbkdf2_sha256$<회수>$<솔트 b64>$<해시 b64>'."""
    n = int(iterations or ITERATIONS)
    salt = secrets.token_bytes(SALT_BYTES)
    dk = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, n)
    return f"pbkdf2_sha256${n}${_b64(salt)}${_b64(dk)}"


def verify_password(password: str, stored: str) -> bool:
    """저장된 해시와 상수 시간으로 비교한다. 형식이 깨졌으면 False."""
    try:
        algo, n, salt_b64, dk_b64 = str(stored).split("$")
        if algo != "pbkdf2_sha256":
            return False
        salt, want = base64.b64decode(salt_b64), base64.b64decode(dk_b64)
        n = int(n)
        if not (1 <= n <= 10_000_000):
            return False
    except (ValueError, TypeError):
        return False
    got = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, n)
    return hmac.compare_digest(got, want)


_DUMMY_HASH: dict = {}


def _dummy_hash() -> str:
    """없는 아이디에도 같은 시간만큼 계산하게 — 응답 시간으로 아이디 유무를 알 수 없게."""
    key = int(ITERATIONS)
    if key not in _DUMMY_HASH:
        _DUMMY_HASH[key] = hash_password(secrets.token_hex(8))
    return _DUMMY_HASH[key]


def check_password_policy(password, login: str = "") -> None:
    """8자 이상, 아이디와 같으면 안 됨. 어기면 InvalidInput(쉬운 말)."""
    if not isinstance(password, str) or len(password) < MIN_PASSWORD:
        raise InvalidInput(f"비밀번호는 {MIN_PASSWORD}자 이상이어야 합니다")
    if len(password) > MAX_PASSWORD:
        raise InvalidInput("비밀번호가 너무 깁니다")
    if not password.strip():
        raise InvalidInput("비밀번호를 공백만으로 만들 수 없습니다")
    if login and name_key(password) == name_key(login):
        raise InvalidInput("비밀번호를 아이디와 같게 할 수 없습니다")


def make_temp_password(login: str = "") -> str:
    while True:
        pw = "".join(secrets.choice(_TEMP_ALPHABET) for _ in range(12))
        try:
            check_password_policy(pw, login)
            return pw
        except InvalidInput:     # 아이디와 같을 확률은 사실상 0이지만 규칙은 지킨다
            continue


# 한글 낱자·채움 글자 — 아이디의 '글자'로 치지 않는다 (2026-10-30): 첫가끝 자모(U+1100~11FF·A960~A97F·D7B0~D7FF, 채움
# U+115F·U+1160 포함), 호환 자모(U+3130~318F, 채움 U+3164 포함), 반각 자모(U+FFA0~FFDF, 채움 U+FFA0 포함)
_JAMO_RANGES = (("\u1100", "\u11ff"), ("\ua960", "\ua97f"), ("\ud7b0", "\ud7ff"), ("\u3130", "\u318f"),
                ("\uffa0", "\uffdf"))
LOGIN_RULE = "아이디는 2~32자 — 글자·숫자와 점(.)·밑줄(_)·붙임표(-)만, 글자나 숫자가 하나 이상 (ㄱ·ㅏ 같은 낱자만은 불가)"


def _is_compat_jamo(ch: str) -> bool:
    """한글 낱자(자모)·채움 글자인가 — 글자·숫자 하나 이상 규칙에서 글자로 치지 않는다."""
    return any(a <= ch <= b for a, b in _JAMO_RANGES)


def _check_login(login) -> str:
    v = unicodedata.normalize("NFC", str(login or "")).strip()
    if not _LOGIN_RE.match(v):
        raise InvalidInput(LOGIN_RULE)
    if not any(ch.isalnum() and not _is_compat_jamo(ch) for ch in v):
        # '__'·'.-'·'ㄱㄴ'처럼 글자·숫자가 없는 아이디는 화면·감사 기록에서 누구인지 알 수 없다 (2026-10-30 L6)
        raise InvalidInput(LOGIN_RULE)
    return v


def _check_role(role) -> str:
    if role not in ROLES:
        raise InvalidInput("역할은 관리자·검토자·직원 가운데 하나입니다")
    return role


# ── 계정 ────────────────────────────────────────────────────────────────

def _active_admins(store: FormsStore) -> int:
    return store.conn.execute(
        "SELECT COUNT(*) FROM users WHERE role = 'admin' AND disabled = 0").fetchone()[0]


def _target(store: FormsStore, user_id):
    row = store.conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise NotFound("없는 계정입니다")
    return row


def _revoke(store: FormsStore, user_id, except_token: str | None = None) -> None:
    if except_token:
        store.conn.execute("DELETE FROM sessions WHERE user_id = ? AND token_hash != ?",
                           (user_id, _token_hash(except_token)))
    else:
        store.conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))


def has_admin(store: FormsStore) -> bool:
    return store.conn.execute("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1").fetchone() is not None


def create_first_admin(store: FormsStore, login, display_name, password, *, is_local: bool,
                       ip=None) -> int:
    """첫 관리자 만들기 — 관리자가 하나도 없을 때만, Drev PC(127.0.0.1)에서 온 요청일 때만.

    is_local: 부르는 쪽이 요청 주소가 127.0.0.1·::1 인지 확인해 넘긴다. 아니면 거부."""
    if is_local is not True:
        raise PermissionDenied("첫 관리자는 Drev가 설치된 PC에서만 만들 수 있습니다")
    lg = _check_login(login)
    dn = _plain_text(display_name or lg, "이름", 40, required=True)
    check_password_policy(password, lg)
    h = hash_password(password)
    with store.tx():
        if has_admin(store):
            raise Conflict("관리자가 이미 있습니다 — 관리자 화면에서 계정을 등록해 주세요")
        if store.conn.execute("SELECT 1 FROM users WHERE login_key = ?", (name_key(lg),)).fetchone():
            raise Conflict("이미 있는 아이디입니다")
        cur = store.conn.execute(
            "INSERT INTO users (login, login_key, display_name, role, pw_hash, must_change, created_at) "
            "VALUES (?, ?, ?, 'admin', ?, 0, ?)", (lg, name_key(lg), dn, h, now_text(store.clock())))
        uid = cur.lastrowid
        store._audit(_target(store, uid), "admin_bootstrap", f"user:{uid}", ip, lg)
        return uid


_EMAIL_RE = re.compile(r"^[^@\s<>,;:\"'()\[\]\\]{1,64}@[^@\s<>,;:\"'()\[\]\\]{1,190}\.[^@\s<>,;:\"'()\[\]\\.]{2,63}$")


def check_email(email) -> str:
    """알림 메일 주소 — 비워도 된다(알림을 안 받음). 꼴이 이상하면 InvalidInput. 머리글 끼워 넣기(줄바꿈·쉼표)는 거부."""
    v = unicodedata.normalize("NFC", str(email or "")).strip()
    if not v:
        return ""
    if len(v) > 254 or not _EMAIL_RE.match(v):
        raise InvalidInput("메일 주소 꼴이 아닙니다 (예: kim@회사.co.kr)")
    return v


def register_user(store: FormsStore, actor_id, login, display_name, role: str = "member", *,
                  ip=None, email: str = "") -> tuple[int, str]:
    """관리자가 직원 계정을 등록한다. 돌려줌: (계정 id, 임시 비밀번호) — 첫 로그인 때 바꿔야 한다.
    email: (선택, F4) 승인·반려·새 현행 판 알림을 받을 주소."""
    lg = _check_login(login)
    dn = _plain_text(display_name or lg, "이름", 40, required=True)
    _check_role(role)
    em = check_email(email)
    temp = make_temp_password(lg)
    h = hash_password(temp)
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        if store.conn.execute("SELECT 1 FROM users WHERE login_key = ?", (name_key(lg),)).fetchone():
            raise Conflict("이미 있는 아이디입니다")
        cur = store.conn.execute(
            "INSERT INTO users (login, login_key, display_name, role, pw_hash, must_change, created_at, "
            "created_by, email) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)",
            (lg, name_key(lg), dn, role, h, now_text(store.clock()), actor["id"], em))
        uid = cur.lastrowid
        store._audit(actor, "user_create", f"user:{uid}", ip, f"{lg} ({role})" + (f" {em}" if em else ""))
        return uid, temp


def set_email(store: FormsStore, actor_id, user_id, email, *, ip=None) -> None:
    """알림 메일 주소 바꾸기 — 관리자만 (F4). 비우면 알림을 받지 않는다."""
    em = check_email(email)
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        t = _target(store, user_id)
        store.conn.execute("UPDATE users SET email = ? WHERE id = ?", (em, user_id))
        store._audit(actor, "user_email", f"user:{user_id}", ip, f"{t['login']}: {em or '(없음)'}")


def set_disabled(store: FormsStore, actor_id, user_id, disabled: bool, *, ip=None) -> None:
    """정지(True)·복구(False) — 관리자만. 마지막 관리자는 정지할 수 없다. 정지하면 세션을 끊는다."""
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        t = _target(store, user_id)
        if disabled and t["role"] == "admin" and not t["disabled"] and _active_admins(store) <= 1:
            raise LastAdmin("마지막 관리자는 정지할 수 없습니다 — 다른 관리자를 먼저 만들어 주세요")
        store.conn.execute("UPDATE users SET disabled = ? WHERE id = ?", (1 if disabled else 0, user_id))
        if disabled:
            _revoke(store, user_id)
        store._audit(actor, "user_disable" if disabled else "user_enable", f"user:{user_id}", ip, t["login"])


def set_role(store: FormsStore, actor_id, user_id, role: str, *, ip=None, detail: bool = False):
    """역할 바꾸기 — 관리자만. 마지막 관리자는 강등할 수 없다. 검토자가 아니게 되면 폴더 검토 지정도 뺀다.
    직원이 되면 승인권자 지정(2단계 승인, 이주 11)도 뺀다 — 승인권자는 검토자·관리자 역할만.
    돌려줌: 풀린 폴더 검토 지정 수 (2026-10-30 — 화면이 '맡은 폴더 N개 지정이 풀렸습니다'로 알린다).
    detail=True면 {reviewers: 풀린 검토 지정 수, approvers: 풀린 승인권자 지정 수}."""
    _check_role(role)
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        t = _target(store, user_id)
        if t["role"] == "admin" and role != "admin" and not t["disabled"] and _active_admins(store) <= 1:
            raise LastAdmin("마지막 관리자는 강등할 수 없습니다 — 다른 관리자를 먼저 만들어 주세요")
        store.conn.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
        dropped = approvers = 0
        if role == "member":
            dropped = int(store.conn.execute("DELETE FROM folder_reviewers WHERE user_id = ?",
                                             (user_id,)).rowcount or 0)
            if getattr(store, "_v11", True):
                approvers = int(store.conn.execute("DELETE FROM folder_approvers WHERE user_id = ?",
                                                   (user_id,)).rowcount or 0)
        store._audit(actor, "user_role", f"user:{user_id}", ip, f"{t['login']}: {t['role']} → {role}"
                     + (f" (맡은 폴더 {dropped}개 지정 풀림)" if dropped else "")
                     + (f" (승인권자 지정 {approvers}개 풀림)" if approvers else ""))
        return {"reviewers": dropped, "approvers": approvers, "from": t["role"]} if detail else dropped


def reset_password(store: FormsStore, actor_id, user_id, *, ip=None) -> str:
    """비밀번호 초기화 — 관리자만. 임시 비밀번호를 돌려주고, 다음 로그인 때 바꾸게 하며, 세션·잠금을 푼다."""
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        t = _target(store, user_id)
    temp = make_temp_password(t["login"])
    h = hash_password(temp)
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        t = _target(store, user_id)
        store.conn.execute("UPDATE users SET pw_hash = ?, must_change = 1 WHERE id = ?", (h, user_id))
        _revoke(store, user_id)
        store.conn.execute("DELETE FROM login_failures WHERE login_key = ?", (t["login_key"],))
        store._audit(actor, "password_reset", f"user:{user_id}", ip, t["login"])
    return temp


def change_password(store: FormsStore, user_id, old_password, new_password, *, keep_token=None,
                    ip=None) -> None:
    """자기 비밀번호 바꾸기 — 지금 비밀번호 확인 후. 다른 세션은 끊고 keep_token(지금 세션)만 남긴다.
    지금 비밀번호를 틀리면 로그인 실패와 같은 잠금(계정+주소 5번 → 5분, 주소 단위)에 세고 감사 기록(묶음)을 남긴다 —
    로그인된 화면에 앉아 비밀번호를 대입해 보지 못하게 (2026-10-30 L3). 잠긴 동안은 LoginLocked."""
    t = store.get_user(user_id)
    if t is None or t["disabled"]:
        raise PermissionDenied("로그인한 계정을 쓸 수 없습니다")
    row = _target(store, user_id)
    ip_s, key = str(ip or ""), _fail_key(row["login_key"])
    wait, kind = ip_wait(store, ip_s)
    if wait <= 0:
        wait, kind = lock_remaining(store, row["login"], ip_s), "account"
    if wait > 0:
        store.audit_grouped("password_locked", ip=ip_s, user_id=row["id"], login=row["login"],
                            target=f"user:{row['id']}", what="시도 — 잠긴 동안 비밀번호 바꾸기")
        raise LoginLocked(wait, kind)
    if not verify_password(old_password, row["pw_hash"]):
        now = store.clock()
        with store.tx():
            _note_failure(store, key, ip_s, now)
            newly = _note_ip_failure(store, ip_s, now)
            store.audit_grouped("password_fail", ip=ip_s, user_id=row["id"], login=row["login"],
                                target=f"user:{row['id']}", what="실패 — 비밀번호 바꾸기의 지금 비밀번호 틀림")
            if newly:
                store.record_audit(None, "ip_locked", f"ip:{ip_s}", ip=ip_s, login=row["login"],
                                   detail=f"{IP_WINDOW // 60}분 안에 아이디 상관없이 {IP_THRESHOLD}번 실패 — "
                                          f"{IP_LOCK_SECONDS // 60}분 동안 이 주소의 로그인을 막음")
        left, kind = wait_seconds(store, row["login"], ip_s)
        raise LoginFailed("지금 비밀번호가 맞지 않습니다" + (f" — {locked_text(left, kind)}" if left > 0 else ""))
    check_password_policy(new_password, row["login"])
    if verify_password(new_password, row["pw_hash"]):
        raise InvalidInput("지금과 다른 비밀번호로 바꿔 주세요")
    h = hash_password(new_password)
    with store.tx():
        row2 = _target(store, user_id)
        if row2["pw_hash"] != row["pw_hash"]:
            raise Conflict("그사이 비밀번호가 바뀌었습니다 — 다시 로그인해 주세요")
        store.conn.execute("UPDATE users SET pw_hash = ?, must_change = 0 WHERE id = ?", (h, user_id))
        _revoke(store, user_id, except_token=keep_token)
        store._audit(row2, "password_change", f"user:{user_id}", ip, "")


def list_users(store: FormsStore, actor_id) -> list[dict]:
    """계정 목록 — 관리자만."""
    actor = store._actor(actor_id)
    store._require_admin(actor)
    rows = store.conn.execute("SELECT * FROM users ORDER BY login_key").fetchall()
    return [_user_dict(r) for r in rows]


# ── 로그인·세션 ─────────────────────────────────────────────────────────

def _token_hash(token: str) -> str:
    return hashlib.sha256(str(token).encode("utf-8")).hexdigest()


def _fail_key(key: str) -> str:
    """실패 표에 적는 아이디 열쇠 — 64자를 넘으면 지문으로 줄인다(긴 아이디를 보내 표를 키우지 못하게, 2026-10-30 L1).
    실제 계정 아이디는 32자 이하라 그대로다."""
    k = str(key or "")
    return k if len(k) <= 64 else "#" + hashlib.sha256(k.encode("utf-8")).hexdigest()[:40]


def lock_remaining(store: FormsStore, login, ip) -> int:
    """그 아이디+IP 잠금의 남은 초 (잠기지 않았으면 0)."""
    row = store.conn.execute("SELECT locked_until FROM login_failures WHERE login_key = ? AND ip = ?",
                             (_fail_key(name_key(login)), str(ip or ""))).fetchone()
    if row is None or row[0] is None:
        return 0
    return max(0, int(row[0] - store.clock() + 0.999))


def _note_failure(store: FormsStore, key: str, ip: str, now: float) -> None:
    """계정+IP 실패 하나 — 잠금이 풀렸거나 FAIL_WINDOW 동안 실패가 없었으면 0부터 센다."""
    row = store.conn.execute("SELECT count, locked_until, last_at FROM login_failures WHERE login_key = ? AND ip = ?",
                             (key, ip)).fetchone()
    stale = row is None or (row["locked_until"] is not None and row["locked_until"] <= now) \
        or (row["locked_until"] is None and now - float(row["last_at"]) > FAIL_WINDOW)
    count = 0 if stale else row["count"]
    count += 1
    locked = now + LOCK_SECONDS if count >= LOCK_THRESHOLD else None
    store.conn.execute(
        "INSERT OR REPLACE INTO login_failures (login_key, ip, count, locked_until, last_at) VALUES (?, ?, ?, ?, ?)",
        (key, ip, count, locked, now))


def _note_ip_failure(store: FormsStore, ip: str, now: float) -> bool:
    """주소(IP) 실패 하나 — 아이디 상관없이 IP_WINDOW 창 안에서 센다. 이번에 잠갔으면 True (보안 F2)."""
    row = store.conn.execute("SELECT * FROM ip_failures WHERE ip = ?", (ip,)).fetchone()
    # 창은 **마지막 실패**부터 잰다(계정 잠금과 같은 미끄럼 창, 2026-10-30 M1) — 창 끝마다 한 번씩 몰아 쳐 잠금을 피하지 못하게
    if row is None or (row["locked_until"] is not None and row["locked_until"] <= now) \
            or (row["locked_until"] is None and now - float(row["last_at"]) >= IP_WINDOW):
        count, start = 0, now
    else:
        count, start = int(row["count"]), float(row["window_start"])
    count += 1
    locked = now + IP_LOCK_SECONDS if count >= IP_THRESHOLD else None
    store.conn.execute(
        "INSERT OR REPLACE INTO ip_failures (ip, count, window_start, locked_until, last_at) VALUES (?, ?, ?, ?, ?)",
        (ip, count, start, locked, now))
    return locked is not None and (row is None or row["locked_until"] is None or row["locked_until"] <= now)


def ip_wait(store: FormsStore, ip, now: float | None = None) -> tuple[int, str]:
    """그 주소가 지금 로그인을 시도할 수 있나 — (남은 초, 'ip'|'delay'), 시도해도 되면 (0, '').

    'ip': 창 안 실패가 IP_THRESHOLD를 넘어 잠김. 'delay': 실패가 IP_DELAY_AFTER를 넘어 다음 시도까지 2·4·8…초(상한 30초)."""
    now = store.clock() if now is None else now
    row = store.conn.execute("SELECT * FROM ip_failures WHERE ip = ?", (str(ip or ""),)).fetchone()
    if row is None:
        return 0, ""
    if row["locked_until"] is not None:
        if row["locked_until"] > now:
            return max(1, int(row["locked_until"] - now + 0.999)), "ip"
        return 0, ""
    if now - float(row["last_at"]) >= IP_WINDOW or int(row["count"]) <= IP_DELAY_AFTER:
        return 0, ""
    delay = min(IP_DELAY_MAX, 2 ** (int(row["count"]) - IP_DELAY_AFTER))
    left = float(row["last_at"]) + delay - now
    return (max(1, int(left + 0.999)), "delay") if left > 0 else (0, "")


def wait_seconds(store: FormsStore, login_name, ip) -> tuple[int, str]:
    """로그인 화면 안내용 — 계정+IP 잠금과 주소 잠금 가운데 긴 것 (남은 초, 종류). 없으면 (0, '')."""
    a = lock_remaining(store, login_name, ip)
    b, kind = ip_wait(store, ip)
    if kind == "ip" and b >= a:
        return b, "ip"
    if a > 0:
        return a, "account"
    return (b, kind) if b > 0 else (0, "")


def cleanup_failures(store: FormsStore, now: float | None = None) -> int:
    """잠금이 지났거나 오래 조용한 실패 행을 지운다 (보안 F1 TTL — 아이디를 바꿔 가며 표를 키워도 남지 않게). 지운 행 수."""
    now = store.clock() if now is None else now
    with store.tx():
        a = store.conn.execute(
            "DELETE FROM login_failures WHERE (locked_until IS NOT NULL AND locked_until <= ?) "
            "OR (locked_until IS NULL AND last_at < ?)", (now, now - FAIL_WINDOW)).rowcount
        b = store.conn.execute(
            "DELETE FROM ip_failures WHERE (locked_until IS NOT NULL AND locked_until <= ?) "
            "OR (locked_until IS NULL AND last_at < ?)", (now, now - IP_WINDOW)).rowcount
    return int(a or 0) + int(b or 0)


def locked_ips(store: FormsStore, actor_id) -> list[dict]:
    """관리자 화면 '잠긴 접속 주소' — 관리자만. 주소 잠금과, 그 주소의 계정+IP 잠금(아이디 수)을 함께.
    돌려줌: [{ip, kind('ip'|'account'), seconds, count, accounts}] (남은 시간이 긴 것부터)."""
    actor = store._actor(actor_id)
    store._require_admin(actor)
    now = store.clock()
    out: dict = {}
    for r in store.conn.execute("SELECT * FROM ip_failures WHERE locked_until IS NOT NULL AND locked_until > ?",
                                (now,)).fetchall():
        out[r["ip"]] = {"ip": r["ip"], "kind": "ip", "seconds": int(r["locked_until"] - now + 0.999),
                        "count": int(r["count"]), "accounts": 0}
    for r in store.conn.execute(
            "SELECT ip, COUNT(*) AS n, MAX(locked_until) AS until FROM login_failures "
            "WHERE locked_until IS NOT NULL AND locked_until > ? GROUP BY ip", (now,)).fetchall():
        d = out.setdefault(r["ip"], {"ip": r["ip"], "kind": "account", "seconds": int(r["until"] - now + 0.999),
                                     "count": 0, "accounts": 0})
        d["accounts"] = int(r["n"])
    return sorted(out.values(), key=lambda d: (-d["seconds"], d["ip"]))


def unlock_ip(store: FormsStore, actor_id, target_ip, *, ip=None) -> bool:
    """그 주소의 잠금(주소 잠금 + 그 주소의 계정+IP 잠금)을 푼다 — 관리자만. 풀 것이 있었으면 True."""
    t = str(target_ip or "").strip()
    if not t or len(t) > 64:
        raise InvalidInput("접속 주소가 없습니다")
    with store.tx():
        actor = store._actor(actor_id)
        store._require_admin(actor)
        a = store.conn.execute("DELETE FROM ip_failures WHERE ip = ?", (t,)).rowcount
        b = store.conn.execute("DELETE FROM login_failures WHERE ip = ?", (t,)).rowcount
        if a or b:
            store._audit(actor, "ip_unlock", f"ip:{t}", ip, f"{t} 잠금 풀기 (계정 잠금 {int(b or 0)}개 포함)")
    return bool(a or b)


def login(store: FormsStore, login_name, password, *, ip) -> Session:
    """로그인 — 성공하면 새 세션(토큰·CSRF). 틀리면 LoginFailed, 잠겼으면 LoginLocked. 감사 기록을 남긴다.

    ip: 요청한 주소(잠금 열쇠의 반쪽). 잠긴 동안에는 맞는 비밀번호도 받지 않는다.
    - 주소 잠금(보안 F2): 아이디 상관없이 한 주소가 10분에 20번 틀리면 15분, 10번을 넘으면 다음 시도까지 점증 지연.
    - 정지된 계정은 맞는 비밀번호여도 틀린 것과 같은 응답(보안 F5) — 정지 사실은 감사 기록(login_disabled)에만.
    - 실패·잠긴 동안의 시도는 같은 주소·같은 계정끼리 1분 창으로 묶어 한 줄에 적는다(보안 F1)."""
    key, ip_s = name_key(login_name), str(ip or "")
    shown = str(login_name or "")[:64]
    wait, kind = ip_wait(store, ip_s)
    if wait > 0:
        store.audit_grouped("login_locked", ip=ip_s, login=shown,
                            what="시도 — 주소가 잠긴 동안" if kind == "ip" else "시도 — 기다려야 할 때")
        raise LoginLocked(wait, kind)
    left = lock_remaining(store, login_name, ip_s)
    if left > 0:
        store.audit_grouped("login_locked", ip=ip_s, login=shown, what="시도 — 계정이 잠긴 동안")
        raise LoginLocked(left)
    row = store.conn.execute("SELECT * FROM users WHERE login_key = ?", (key,)).fetchone() if key else None
    ok = verify_password(str(password or ""), row["pw_hash"] if row is not None else _dummy_hash())
    ok = ok and row is not None
    now = store.clock()
    if not ok or row["disabled"]:
        with store.tx():
            cleanup_failures(store, now)            # 지난 행부터 치운다 — 실패 표가 아이디 수만큼 쌓이지 않게
            # 잠금 판정은 쓰기 잠금 안에서 다시 — 두 요청이 겹쳐도 횟수가 새지 않게
            _note_failure(store, _fail_key(key), ip_s, now)
            newly = _note_ip_failure(store, ip_s, now)
            if ok:      # 정지 계정 + 맞는 비밀번호 — 화면에는 일반 실패와 같게, 기록에만 정지 사실
                store.audit_grouped("login_disabled", ip=ip_s, user_id=row["id"], login=shown,
                                    target=f"user:{row['id']}", what="시도 — 정지된 계정(비밀번호는 맞음)")
            else:
                store.audit_grouped("login_fail", ip=ip_s, user_id=row["id"] if row is not None else None,
                                    login=shown, what="실패")
            if newly:
                store.record_audit(None, "ip_locked", f"ip:{ip_s}", ip=ip_s, login=shown,
                                   detail=f"{IP_WINDOW // 60}분 안에 아이디 상관없이 {IP_THRESHOLD}번 실패 — "
                                          f"{IP_LOCK_SECONDS // 60}분 동안 이 주소의 로그인을 막음")
        raise LoginFailed("아이디 또는 비밀번호가 맞지 않습니다")
    token, csrf = secrets.token_urlsafe(TOKEN_BYTES), secrets.token_urlsafe(TOKEN_BYTES)
    with store.tx():
        store.conn.execute("DELETE FROM login_failures WHERE login_key = ? AND ip = ?", (_fail_key(key), ip_s))
        # 오래된 세션 정리 (유휴·절대 만료 지난 것)
        store.conn.execute("DELETE FROM sessions WHERE last_seen < ? OR created_at < ?",
                           (now - IDLE_SECONDS, now - ABSOLUTE_SECONDS))
        store.conn.execute(
            "INSERT INTO sessions (token_hash, user_id, csrf, created_at, last_seen, ip) VALUES (?, ?, ?, ?, ?, ?)",
            (_token_hash(token), row["id"], csrf, now, now, ip_s))
        # 계정마다 세션은 최근 MAX_SESSIONS개만 — 로그인을 되풀이해 세션 표를 키우지 못하게 (2026-10-30 L2)
        store.conn.execute(
            "DELETE FROM sessions WHERE user_id = ? AND token_hash NOT IN (SELECT token_hash FROM sessions "
            "WHERE user_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?)", (row["id"], row["id"], MAX_SESSIONS))
        store._audit(row, "login", f"user:{row['id']}", ip_s, "")
    return Session(token=token, csrf=csrf, user_id=row["id"], login=row["login"],
                   display_name=row["display_name"], role=row["role"], must_change=bool(row["must_change"]),
                   created_at=now, last_seen=now)


def get_session(store: FormsStore, token) -> Session | None:
    """쿠키 토큰 → 세션. 없거나·유휴 8시간·절대 7일이 지났거나·계정이 정지됐으면 None (지운다). 마지막 사용 시각을 갱신한다."""
    if not token or not isinstance(token, str) or len(token) > 256:
        return None
    th = _token_hash(token)
    now = store.clock()
    with store.tx():
        row = store.conn.execute(
            "SELECT s.*, u.login, u.display_name, u.role, u.disabled, u.must_change FROM sessions s "
            "JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?", (th,)).fetchone()
        if row is None:
            return None
        if (row["disabled"] or now - row["last_seen"] > IDLE_SECONDS
                or now - row["created_at"] > ABSOLUTE_SECONDS):
            store.conn.execute("DELETE FROM sessions WHERE token_hash = ?", (th,))
            return None
        store.conn.execute("UPDATE sessions SET last_seen = ? WHERE token_hash = ?", (now, th))
    return Session(token=token, csrf=row["csrf"], user_id=row["user_id"], login=row["login"],
                   display_name=row["display_name"], role=row["role"], must_change=bool(row["must_change"]),
                   created_at=row["created_at"], last_seen=now)


def logout(store: FormsStore, token, *, ip=None) -> None:
    if not token or not isinstance(token, str):
        return
    with store.tx():
        row = store.conn.execute("SELECT user_id FROM sessions WHERE token_hash = ?",
                                 (_token_hash(token),)).fetchone()
        store.conn.execute("DELETE FROM sessions WHERE token_hash = ?", (_token_hash(token),))
        if row is not None:
            u = store.conn.execute("SELECT * FROM users WHERE id = ?", (row[0],)).fetchone()
            if u is not None:
                store._audit(u, "logout", f"user:{u['id']}", ip, "")


def check_csrf(session: Session | None, supplied) -> bool:
    """세션별 CSRF 토큰 확인 (상수 시간). 세션이 없거나 값이 비면 False."""
    if session is None or not supplied or not isinstance(supplied, str):
        return False
    return hmac.compare_digest(session.csrf.encode("utf-8"), supplied.encode("utf-8"))
