# -*- coding: utf-8 -*-
"""양식함 백업·복원 (2026-10-30, DECISIONS 같은 날).

forms.db(계정·폴더·판·승인·감사 기록)와 forms_store(판 파일)는 감시의 주간 백업(state.db만)에 들어가지 않았다 —
디스크 하나가 죽으면 회사 양식의 판 이력과 승인 기록이 함께 사라진다. 이 모듈이 매일 한 번 백업 폴더에 둔다.

백업 폴더(설정 forms.backup_dir, 기본 <데이터 폴더>\\forms_backup — 다른 디스크·\\\\서버\\공유 권장):
  forms_backup_<n>.db     forms.db 사본 슬롯(1~keep). 가장 오래된 슬롯부터 덮어 돌려 쓴다.
  backup_slots.json       슬롯마다 {at, sha256, size} — 어느 슬롯이 가장 오래됐는지(시험 시계와도 맞게)
  store/<양식>/<판>/<파일>  판 파일 사본 — 판 파일은 한 번 쓰면 바뀌지 않으므로 없는 것만 더한다. 지우는 것은 하나뿐:
                          관리자가 보존 기간이 지나 정리한 판(versions.purged_at, keep.py)의 사본 — 다음 백업이 guard로 지운다
                          (지문이 같을 때만). 남겨 두면 보존 만료 정책이 백업에서 무너진다 (2026-10-30)

- DB 사본: SQLite 온라인 백업 API로 메모리에 떠서 PRAGMA integrity_check를 통과한 것만, 같은 폴더 임시 파일 → os.replace
  (guard.write_atomic)로 슬롯에 둔다. 사본 안 meta에 backup_taken_at을 적어 두어 복원이 슬롯 순서를 사본만 보고 안다.
- 판 파일 사본: 원본을 읽어 versions.sha256과 대조한 뒤 쓰고, 쓴 것을 다시 읽어 대조한다. 검토 대기(_pending)는 뺀다.
- 쓰기는 전부 guard.Guard(뿌리 = 백업 폴더 하나, 복원 때는 데이터 폴더)를 거친다. 이 모듈은 tests/test_readonly.py의
  엄격 검사를 받는다(파일 쓰기 API 없음, open은 'rb'만).
- 결과는 forms.db meta(backup_last_*)와 감사 기록(backup / backup_fail)에 남는다. 백업 폴더가 없거나 공유가 끊기면
  실패를 한 번 적고(같은 실패는 서버가 도는 동안 다시 적지 않는다) 서버는 그대로 돈다. 백업은 동시에 둘이 돌지 않는다.
- 복원(forms-restore)은 Drev PC의 명령으로만 한다 — 양식함 서버가 돌고 있으면 거부한다(단일 실행 뮤텍스).
  지금 forms.db는 지우지 않고 forms.db.before-restore-<때>로 비켜 둔다. 판 파일은 없는 것만 되살린다.
  정리한 판(purged_at)은 되살리지 않고 '정리됨'으로 센다 — 없는 파일(문제)로 치지 않는다 (2026-10-30).
  정리 전에 뜬 사본으로 복원하면, 지금 forms.db(비켜 둘 것)나 더 새 사본에 정리 기록이 있는 판(판 id + 지문이 같음)을
  '보존 만료로 정리한 판 — 되살리지 않음'으로 따로 세고, 복원한 DB에 purged_at·purged_by를 옮겨 적는다 (2026-10-30 검토 2).
- 정리한 판의 백업 사본은 정리 기록이 있고 **보관소 폴더가 지금 있고** 원본이 보관소에 없을 때만 지운다 (검토 1).
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path

from watcher.forms.guard import Guard, GuardError, GuardExists, GuardNoSpace, check_name, free_bytes, sha256_of
from watcher.forms.store import DB_NAME, PENDING_DIR, SCHEMA_VERSION, STORE_DIR, FormsError, FormsStore, now_text

log = logging.getLogger("drev.forms.server")

BACKUP_DIR_NAME = "forms_backup"
STORE_COPY = "store"
SLOT_FMT = "forms_backup_{}.db"
SLOT_RE = re.compile(r"forms_backup_(\d{1,2})\.db", re.IGNORECASE)
MANIFEST = "backup_slots.json"
KEEP_DEFAULT, KEEP_MIN, KEEP_MAX = 4, 1, 30
HOUR_DEFAULT = 3
TAKEN_KEY = "backup_taken_at"
META_AT = "backup_last_at"             # 마지막 시도 때
META_OK = "backup_last_ok"             # '1' 확인 OK / '0' 실패
META_DONE_AT = "backup_last_done_at"   # DB 사본을 마지막으로 둔 때 (하루 한 번 판정)
META_SUMMARY = "backup_last_summary"   # JSON
MAX_PROBLEMS = 20
ASIDE_TAG = ".before-restore-"


class BackupError(FormsError):
    """백업·복원을 할 수 없다 — 폴더가 없음·검사 실패·쓰기 실패."""


class BackupBusy(BackupError):
    """이미 백업이 돌고 있다."""


# ── 작은 도구 ───────────────────────────────────────────────────────────────

def default_dir(data_dir) -> Path:
    return Path(data_dir) / BACKUP_DIR_NAME


def backup_dir_of(data_dir, configured="") -> Path:
    """설정값(비면 기본) → 백업 폴더 절대 경로."""
    s = str(configured or "").strip().strip('"')
    return Path(os.path.abspath(s)) if s else Path(os.path.abspath(default_dir(data_dir)))


def _norm(p) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(str(p))))


def _within(child, parent) -> bool:
    try:
        return os.path.commonpath([_norm(child), _norm(parent)]) == _norm(parent)
    except ValueError:
        return False


def _mb(n) -> str:
    n = int(n or 0)
    if n >= 1024 * 1024 * 1024:
        return f"{n / (1024 ** 3):.1f} GB"
    if n >= 1024 * 1024:
        return f"{n / (1024 * 1024):.1f} MB"
    return f"{max(1, (n + 1023) // 1024) if n else 0} KB"


def _rel_parts(rel) -> list[str] | None:
    """versions.path(보관소 기준 상대 경로) → 이름 성분. 대기 파일·이상한 경로는 None.
    성분마다 guard.check_name — 'C:'(드라이브 상대)·예약 이름 등이 섞이면 보관소 밖을 읽게 되므로 None (2026-10-30 검토)."""
    parts = [p for p in re.split(r"[\\/]+", str(rel or "")) if p]
    if not parts or parts[0] == PENDING_DIR:
        return None
    try:
        for p in parts:
            check_name(p)
    except GuardError:
        return None
    return parts


def _integrity(conn) -> str:
    """PRAGMA integrity_check — 'ok' 또는 첫 몇 줄. (시험이 바꿔 끼워 검사 실패를 흉내 낸다.)"""
    rows = conn.execute("PRAGMA integrity_check").fetchall()
    msg = "; ".join(str(r[0]) for r in rows[:5])
    return "ok" if msg == "ok" else (msg or "알 수 없는 오류")


def _rollback_header(data: bytes) -> bytes:
    """사본은 롤백 저널 형식으로 둔다(파일 머리 18·19번째 바이트 2 = WAL) — 백업 폴더에 -wal·-shm이 생기지 않게."""
    if len(data) >= 100 and data[18:20] == b"\x02\x02":
        return data[:18] + b"\x01\x01" + data[20:]
    return data


def _meta(store: FormsStore, keys) -> dict:
    marks = ",".join("?" * len(keys))
    return {r[0]: r[1] for r in store.conn.execute(f"SELECT key, value FROM meta WHERE key IN ({marks})",
                                                    tuple(keys)).fetchall()}


def _meta_set(store: FormsStore, pairs: dict) -> None:
    with store.tx() as c:
        for k, v in pairs.items():
            c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (str(k), str(v)))


def last_status(store: FormsStore) -> dict:
    """마지막 백업 결과 — {at, ok(True/False/None), done_at, summary(사전)}."""
    m = _meta(store, (META_AT, META_OK, META_DONE_AT, META_SUMMARY))
    try:
        summary = json.loads(m.get(META_SUMMARY) or "{}")
    except ValueError:
        summary = {}
    ok = m.get(META_OK)
    return {"at": m.get(META_AT, ""), "ok": None if ok is None else ok == "1", "done_at": m.get(META_DONE_AT, ""),
            "summary": summary if isinstance(summary, dict) else {}}


def status_line(st: dict) -> str:
    """'마지막 백업 2026-10-30 03:00 · DB 3.1 MB · 파일 120개 · 확인 OK' — 설정 화면·양식함 백업 화면이 같이 쓴다."""
    if not st.get("at"):
        return "아직 백업한 적이 없습니다"
    s = st.get("summary") or {}
    when = " ".join(str(st["at"]).split("T", 1))[:16]
    if s.get("error"):
        return f"마지막 백업 {when} · 실패 — {s['error']}"
    probs = int(s.get("problem_count") or 0)
    check = "확인 OK" if st.get("ok") and not probs else f"확인 실패 {probs}건"
    return (f"마지막 백업 {when} · DB {_mb(s.get('db_bytes'))} · 파일 {int(s.get('files_total') or 0)}개 · {check}")


# ── DB 사본 ─────────────────────────────────────────────────────────────────

def _snapshot(store: FormsStore, taken_at: str) -> bytes:
    """forms.db → 메모리 사본(온라인 백업 API) → integrity_check → meta에 찍은 때 → 바이트."""
    mem = sqlite3.connect(":memory:")
    try:
        with store._lock:                        # 다른 스레드의 트랜잭션 도중을 뜨지 않게 (저장소 잠금)
            store.conn.raw.backup(mem)
        res = _integrity(mem)
        if res != "ok":
            raise BackupError(f"forms.db 검사(integrity_check) 실패 — 사본을 두지 않았습니다: {res}")
        mem.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (TAKEN_KEY, taken_at))
        mem.commit()
        data = bytes(mem.serialize())
    finally:
        mem.close()
    return _rollback_header(data)


def inspect_db(data: bytes) -> dict:
    """사본 바이트 → {ok, error, taken_at, schema, versions}. 파일을 열지 않고 메모리에서만 본다."""
    out = {"ok": False, "error": "", "taken_at": "", "schema": 0, "versions": 0}
    mem = sqlite3.connect(":memory:")
    try:
        mem.deserialize(_rollback_header(bytes(data)))     # 손으로 복사한 forms.db는 WAL 머리 (재검토 이주 3)
        res = _integrity(mem)
        if res != "ok":
            out["error"] = f"검사 실패: {res}"
            return out
        meta = dict(mem.execute("SELECT key, value FROM meta").fetchall())
        out["taken_at"] = str(meta.get(TAKEN_KEY) or "")
        out["schema"] = int(meta.get("schema_version") or 0)
        out["versions"] = int(mem.execute("SELECT COUNT(*) FROM versions").fetchone()[0])
        out["ok"] = True
    except (sqlite3.Error, ValueError, TypeError) as e:
        out["error"] = f"읽을 수 없음: {type(e).__name__}: {e}"
        if bytes(data[18:20]) == b"\x02\x02":       # WAL 머리 = 손으로 복사한 forms.db (재검토 이주 3)
            out["error"] += (" — Drev 백업이 만든 사본이 아닙니다(실행 중에 forms.db만 복사하면 최근 내용이 -wal 파일에 남아 "
                             "빠집니다. 양식함 서버를 멈춘 뒤 복사하거나 [지금 백업]을 쓰세요)")
    finally:
        mem.close()
    return out


def _read_manifest(bdir: Path) -> dict:
    p = bdir / MANIFEST
    try:
        with open(p, "rb") as f:
            m = json.loads(f.read().decode("utf-8"))
    except (OSError, ValueError):
        m = {}
    if not isinstance(m, dict) or not isinstance(m.get("slots"), dict):
        m = {"slots": {}}
    return m


def slot_taken_at(path) -> str:
    """슬롯 파일 자체가 말하는 찍은 때 — 사본 안 meta의 backup_taken_at(정본). 읽히지만 그 값이 없으면 파일 수정 시각,
    읽을 수 없는(깨진) 사본은 ''(가장 오래된 것으로 — 먼저 덮어 쓴다). backup_slots.json은 보지 않는다:
    그 파일이 깨지거나 슬롯을 쓴 뒤 목록 쓰기가 실패하면 가장 새 사본을 덮어 쓰게 된다 (2026-10-30 검토)."""
    p = Path(path)
    blob = _read(p)
    if blob is None:
        return ""
    mem = sqlite3.connect(":memory:")
    try:
        mem.deserialize(_rollback_header(bytes(blob)))
        row = mem.execute("SELECT value FROM meta WHERE key = ?", (TAKEN_KEY,)).fetchone()
    except (sqlite3.Error, ValueError, TypeError):
        return ""
    finally:
        mem.close()
    if row and row[0]:
        return str(row[0])
    try:
        return now_text(p.stat().st_mtime)
    except OSError:
        return ""


def _pick_slot(bdir: Path, keep: int) -> int:
    """빈 슬롯이 있으면 가장 작은 번호, 다 찼으면 가장 오래된(슬롯 파일 안의 찍은 때 기준, 깨진 것 먼저) 슬롯."""
    for n in range(1, keep + 1):
        if not (bdir / SLOT_FMT.format(n)).exists():
            return n
    ats = {n: slot_taken_at(bdir / SLOT_FMT.format(n)) for n in range(1, keep + 1)}
    return min(range(1, keep + 1), key=lambda n: (ats[n], n))


def slots(bdir) -> list[dict]:
    """백업 폴더의 DB 슬롯 목록(번호 순) — {n, path, size, at}. 화면용(내용은 열지 않는다)."""
    bdir = Path(bdir)
    m = _read_manifest(bdir)
    out = []
    try:
        names = sorted(os.listdir(bdir))
    except OSError:
        return []
    for name in names:
        mt = SLOT_RE.fullmatch(name)
        if not mt:
            continue
        p = bdir / name
        try:
            size = p.stat().st_size
        except OSError:
            continue
        n = int(mt.group(1))
        out.append({"n": n, "path": p, "size": size, "at": str((m["slots"].get(str(n)) or {}).get("at") or "")})
    out.sort(key=lambda d: d["n"])
    return out


# ── 판 파일 사본 ─────────────────────────────────────────────────────────────

def _has_purged(conn) -> bool:
    """versions에 purged_at 칸이 있나 — 이주 10 전 사본(복원할 옛 백업)에는 없다."""
    return any(r[1] == "purged_at" for r in conn.execute("PRAGMA table_info(versions)").fetchall())


def _drop_purged_copy(store: FormsStore, guard: Guard, bdir: Path, parts: list, sha: str, res: dict) -> None:
    """정리한 판의 백업 사본을 지운다(지문이 같을 때만) — 그 빈 칸 폴더도. 없으면 할 일 없음.
    원본이 없다는 것을 정리 기록(purged_at — 부르는 쪽이 본다)과 **지금 있는 보관소 폴더**로 함께 확인할 때만 지운다:
    보관소가 없으면(옮김·공유 끊김) 부르는 쪽이 아예 부르지 않고, 원본 파일이 아직 보관소에 있으면 지우지 않는다 (2026-10-30 검토 1)."""
    try:
        if os.path.lexists(store.store_root.joinpath(*parts)):
            res["problems"].append(f"정리한 판인데 보관소에 파일이 남아 있어 백업 사본을 지우지 않았습니다: {'/'.join(parts)}")
            return
    except OSError:
        return
    try:
        dst = guard.target(bdir, STORE_COPY, *parts)
        if not guard.remove_file(dst, expected_sha256=sha):
            return
    except GuardError:
        res["problems"].append(f"정리한 판의 백업 사본이 기록과 달라 지우지 않았습니다: {'/'.join(parts)}")
        return
    except OSError as e:
        res["problems"].append(f"정리한 판의 백업 사본을 지우지 못했습니다: {'/'.join(parts)} ({type(e).__name__})")
        return
    res["files_purged"] += 1
    if len(parts) == 3:
        try:
            if guard.remove_empty_dir(dst.parent):
                guard.remove_empty_dir(dst.parent.parent)
        except (GuardError, OSError):
            pass


def _copy_store(store: FormsStore, guard: Guard, bdir: Path, deep: bool) -> dict:
    with store._lock:                            # 목록만 잠금 안에서 한 번에 뜬다 — 파일 읽기·쓰기는 잠금 밖 (2026-10-30 검토 4)
        purged_col = ", purged_at" if _has_purged(store.conn) else ", NULL AS purged_at"
        rows = list(store.conn.execute(f"SELECT id, path, sha256, size{purged_col} FROM versions ORDER BY id"
                                       ).fetchall())
    res = {"files_total": 0, "files_bytes": 0, "files_copied": 0, "files_repaired": 0, "files_kept": 0,
           "files_purged": 0, "problems": []}
    probs = res["problems"]
    store_ok = store.store_root.is_dir()         # 보관소가 없으면 정리한 판의 사본도 지우지 않는다 (2026-10-30 검토 1)
    if not store_ok and any(r["purged_at"] for r in rows):
        probs.append(f"보관소 폴더를 찾을 수 없어 정리한 판의 백업 사본을 지우지 않았습니다: {store.store_root}")
    for r in rows:
        parts = _rel_parts(r["path"])
        if parts is None:
            if not r["purged_at"]:
                probs.append(f"판 {r['id']}: 보관 경로가 이상합니다 ({r['path']})")
            continue
        if r["purged_at"]:                       # 보존 기간이 지나 정리한 판 — 사본도 지운다 (2026-10-30)
            if store_ok:
                _drop_purged_copy(store, guard, bdir, parts, str(r["sha256"] or "").lower(), res)
            continue
        res["files_total"] += 1
        res["files_bytes"] += int(r["size"] or 0)
        want = str(r["sha256"] or "").lower()
        try:
            dst = guard.target(bdir, STORE_COPY, *parts)
        except GuardError as e:
            probs.append(f"{r['path']}: {e}")
            continue
        damaged = False
        if os.path.isfile(dst):
            try:
                same = os.path.getsize(dst) == int(r["size"] or 0) and (not deep or sha256_of(dst) == want)
            except OSError:
                same = False
            if same:
                res["files_kept"] += 1
                continue
            damaged = True                       # 사본이 깨졌다 — 맞는 내용으로 다시 둔다(판 파일은 바뀌지 않으므로 이력 손실 아님)
        src = store.store_root.joinpath(*parts)
        try:
            with open(src, "rb") as f:
                blob = f.read()
        except OSError as e:
            probs.append(f"원본 판 파일을 읽을 수 없습니다: {r['path']} ({type(e).__name__})")
            continue
        if hashlib.sha256(blob).hexdigest() != want:
            probs.append(f"원본 판 파일의 지문이 기록과 다릅니다(손상?): {r['path']}")
            continue
        try:
            guard.write_atomic(dst, blob, overwrite=damaged)
        except GuardExists:
            res["files_kept"] += 1
            continue
        except GuardNoSpace as e:
            probs.append(f"백업 폴더 디스크 여유가 모자라 판 파일 사본을 멈췄습니다 — {e}")
            break
        except (GuardError, OSError) as e:
            probs.append(f"{r['path']}: 사본을 두지 못했습니다 ({type(e).__name__}: {e})")
            continue
        if sha256_of(dst) != want:
            probs.append(f"{r['path']}: 사본을 다시 읽어 보니 지문이 다릅니다")
            continue
        res["files_repaired" if damaged else "files_copied"] += 1
    return res


# ── 백업 한 번 ──────────────────────────────────────────────────────────────

_LOCKS: dict = {}
_LOCKS_GUARD = threading.Lock()


def _lock_for(data_dir) -> threading.Lock:
    """데이터 폴더 하나에 백업 하나 — 정리 일 스레드와 [지금 백업]이 겹치지 않게."""
    with _LOCKS_GUARD:
        return _LOCKS.setdefault(_norm(data_dir), threading.Lock())


def run_backup(store: FormsStore, backup_dir, *, keep: int = KEEP_DEFAULT, deep: bool = False,
               create: bool = False) -> dict:
    """백업 한 번 — 요약 사전. 이미 돌고 있으면 BackupBusy, DB 사본을 못 두면 BackupError.
    create: 백업 폴더가 없으면 만든다(데이터 폴더 아래 기본 폴더일 때만). deep: 있는 판 파일 사본도 지문까지 다시 본다."""
    lock = _lock_for(store.data_dir)
    if not lock.acquire(blocking=False):
        raise BackupBusy("이미 백업 중입니다")
    try:
        return _run(store, Path(os.path.abspath(str(backup_dir))), keep, deep, create)
    finally:
        lock.release()


def _run(store: FormsStore, bdir: Path, keep: int, deep: bool, create: bool) -> dict:
    t0 = time.monotonic()
    at = now_text(float(store.clock()))
    keep = max(KEEP_MIN, min(int(keep), KEEP_MAX))
    if _within(store.data_dir, bdir) or _within(bdir, store.store_root):
        raise BackupError(f"이 폴더는 백업 폴더로 쓸 수 없습니다(데이터 폴더 자체·그 위 폴더·보관소 안): {bdir}")
    if not create and not bdir.is_dir():                # 데이터 폴더 밖은 만들지 않는다 — Guard 속말 대신 할 일을 말한다 (2026-10-31)
        from watcher.forms.settings import missing_backup_dir_message
        raise BackupError(missing_backup_dir_message(bdir))
    try:
        guard = Guard([bdir], create=[bdir] if create else ())
    except (GuardError, OSError) as e:
        if not bdir.is_dir():
            from watcher.forms.settings import missing_backup_dir_message
            raise BackupError(missing_backup_dir_message(bdir))
        raise BackupError(f"백업 폴더를 쓸 수 없습니다: {bdir} — {e}")
    data = _snapshot(store, at)
    manifest = _read_manifest(bdir)
    slot = _pick_slot(bdir, keep)
    target = guard.target(bdir, SLOT_FMT.format(slot))
    sha = hashlib.sha256(data).hexdigest()
    try:
        guard.write_atomic(target, data, overwrite=True, make_parents=False)
        if sha256_of(target) != sha:
            raise BackupError(f"DB 사본을 다시 읽어 보니 내용이 다릅니다: {target}")
        manifest["slots"][str(slot)] = {"at": at, "sha256": sha, "size": len(data)}
        guard.write_atomic(guard.target(bdir, MANIFEST),
                           json.dumps(manifest, ensure_ascii=False, indent=1).encode("utf-8"),
                           overwrite=True, make_parents=False)
    except (GuardError, OSError) as e:
        raise BackupError(f"DB 사본을 두지 못했습니다: {type(e).__name__}: {e}")
    files = _copy_store(store, guard, bdir, deep)
    probs = files.pop("problems")
    return {"at": at, "slot": slot, "keep": keep, "db_bytes": len(data), "db_sha256": sha, "deep": bool(deep),
            **files, "problem_count": len(probs), "problems": probs[:MAX_PROBLEMS], "ok": not probs,
            "dir": str(bdir), "seconds": round(time.monotonic() - t0, 2)}


def describe(summary: dict) -> str:
    """감사 기록 한 줄."""
    s = summary
    new = s.get("files_copied", 0) + s.get("files_repaired", 0)
    check = "확인 OK" if s.get("ok") else f"확인 실패 {s.get('problem_count', 0)}건"
    first = f" — {s['problems'][0]}" if s.get("problems") else ""
    gone = int(s.get("files_purged") or 0)
    return (f"DB 슬롯 {s.get('slot')} ({_mb(s.get('db_bytes'))}) · 판 파일 {s.get('files_total', 0)}개"
            f"(새로 {new}개{', 지문까지 다시 봄' if s.get('deep') else ''}"
            f"{f', 정리한 판 사본 {gone}개 지움' if gone else ''}) · {check}{first}")


class FormsBackup:
    """서버가 쥐는 백업기 — 정리 일 스레드가 tick(), 관리자 [지금 백업]이 run_async()."""

    def __init__(self, store: FormsStore, backup_dir, *, keep: int = KEEP_DEFAULT, hour: int = HOUR_DEFAULT,
                 create: bool | None = None, mirror_root="", watch_roots=()):
        self.store = store
        self.dir = Path(os.path.abspath(str(backup_dir)))
        self.mirror_root = str(mirror_root or "")
        self.watch_roots = [str(r) for r in (watch_roots or ()) if r]
        self.keep = max(KEEP_MIN, min(int(keep), KEEP_MAX))
        self.hour = max(0, min(int(hour), 23))
        self.create = _within(self.dir, store.data_dir) if create is None else bool(create)
        self._noted = ""                      # 서버가 도는 동안 이미 감사 기록한 실패 (같은 실패를 매시간 적지 않게)
        self._thread: threading.Thread | None = None
        self.last: dict = {}

    def running(self) -> bool:
        return _lock_for(self.store.data_dir).locked()

    def due(self) -> bool:
        """백업 시각(hour)이 지났고 오늘 DB 사본을 아직 두지 않았으면 True."""
        t = datetime.fromtimestamp(float(self.store.clock()))
        if t.hour < self.hour:
            return False
        done = _meta(self.store, (META_DONE_AT,)).get(META_DONE_AT, "")
        return str(done)[:10] != t.date().isoformat()

    def tick(self) -> dict | None:
        """정리 일 스레드에서 — 때가 됐을 때만 돈다. 일요일에는 있는 사본도 지문까지 다시 본다."""
        if not self.due():
            return None
        deep = datetime.fromtimestamp(float(self.store.clock())).weekday() == 6
        return self.run(deep=deep)

    def problem(self) -> str:
        """백업 폴더 전체 검사(설정 화면과 같은 규칙 + 현행 미러·감시 폴더와 겹침) — 문제가 있으면 까닭, 없으면 ''.
        config.yaml은 손으로 고칠 수 있으므로 백업할 때마다 다시 본다 (2026-10-30 검토)."""
        from watcher.forms.settings import backup_dir_problem
        return backup_dir_problem(self.dir, self.store.data_dir, mirror_root=self.mirror_root,
                                  watch_roots=self.watch_roots)

    def run(self, *, deep: bool = False, actor_id=None) -> dict:
        why = self.problem()
        if why:
            msg = f"백업 폴더 설정이 맞지 않아 백업하지 않았습니다: {self.dir} — {why}"
            self._fail(msg, actor_id)
            self.last = {"ok": False, "error": msg}
            return self.last
        try:
            s = run_backup(self.store, self.dir, keep=self.keep, deep=deep, create=self.create)
        except BackupBusy:
            return {"busy": True}
        except (BackupError, GuardError, OSError, sqlite3.Error) as e:
            msg = str(e) if isinstance(e, FormsError) else f"{type(e).__name__}: {e}"
            self._fail(msg, actor_id)
            self.last = {"ok": False, "error": msg}
            return self.last
        self._done(s, actor_id)
        self.last = s
        return s

    def _done(self, s: dict, actor_id) -> None:
        self._noted = ""
        try:
            _meta_set(self.store, {META_AT: s["at"], META_OK: "1" if s["ok"] else "0", META_DONE_AT: s["at"],
                                   META_SUMMARY: json.dumps(s, ensure_ascii=False)})
            self.store.record_audit(actor_id, "backup" if s["ok"] else "backup_fail", f"슬롯 {s['slot']}",
                                    detail=describe(s), login="(양식함)")
        except Exception:
            log.exception("양식함 백업: 결과 기록 실패")
        log.info("양식함 백업: %s", describe(s))

    def _fail(self, msg: str, actor_id) -> None:
        log.warning("양식함 백업 실패: %s", msg)
        at = now_text(float(self.store.clock()))
        try:
            _meta_set(self.store, {META_AT: at, META_OK: "0",
                                   META_SUMMARY: json.dumps({"at": at, "error": msg, "dir": str(self.dir)},
                                                            ensure_ascii=False)})
            if msg != self._noted or actor_id is not None:
                self.store.record_audit(actor_id, "backup_fail", str(self.dir), detail=msg[:500], login="(양식함)")
                self._noted = msg
        except Exception:
            log.exception("양식함 백업: 실패 기록 실패")

    def run_async(self, *, deep: bool = True, actor_id=None) -> bool:
        """배경 스레드로 한 번 — 이미 돌고 있으면 False."""
        if self.running() or (self._thread is not None and self._thread.is_alive()):
            return False

        def go():
            try:
                self.run(deep=deep, actor_id=actor_id)
            except Exception:
                log.exception("양식함 백업: 예상 못 한 오류")
        self._thread = threading.Thread(target=go, name="forms-backup", daemon=True)
        self._thread.start()
        return True

    def wait(self, timeout: float = 30.0) -> bool:
        t = self._thread
        if t is not None:
            t.join(timeout)
            return not t.is_alive()
        return True

    def close(self, timeout: float = 60.0) -> None:
        """[지금 백업] 스레드가 결과를 적을 때까지 기다린다(저장소를 닫기 전, 길어도 timeout초)."""
        t = self._thread
        if t is not None and t is not threading.current_thread():
            t.join(timeout)

    def overview(self) -> dict:
        """화면용 — {dir, dir_ok, free, slots, last}."""
        try:
            free = free_bytes(self.dir) if self.dir.is_dir() else None
        except (GuardError, OSError):
            free = None
        return {"dir": str(self.dir), "dir_ok": self.dir.is_dir(), "free": free, "slots": slots(self.dir),
                "last": last_status(self.store), "keep": self.keep, "hour": self.hour, "running": self.running()}


# ── 서버에 붙이기 (cli forms-serve가 부른다) ──────────────────────────────────

def attach(srv, fs: dict, *, data_dir, mail_cfg=None, base_url: str = "", send=None, kick: bool = True,
           watch_roots=()) -> None:
    """설정(forms_settings)대로 백업기·주간 알림을 서버에 붙인다. 정리 일 스레드(1시간마다)가 tick()을 부른다.
    kick: 붙인 뒤 곧바로 한 번 확인(서버를 03시 뒤에 켠 날도 그날 백업을 하게).
    watch_roots: 감시 폴더들 — 백업 폴더가 그 안이면 백업하지 않고 실패를 적는다(백업기가 매번 다시 본다)."""
    store = getattr(srv, "store", None)
    if store is None:                                  # 시험의 가짜 서버 등 — 붙일 것이 없다
        return
    if fs.get("backup_enabled", True):
        bdir = backup_dir_of(data_dir, fs.get("backup_dir"))
        srv.backup = FormsBackup(store, bdir, keep=fs.get("backup_keep", KEEP_DEFAULT),
                                 hour=fs.get("backup_hour", HOUR_DEFAULT), mirror_root=fs.get("mirror_root") or "",
                                 watch_roots=watch_roots)
    from watcher.forms.weekly import make_weekly
    srv.weekly = make_weekly(srv, fs, mail_cfg=mail_cfg, base_url=base_url, send=send)
    if kick:
        def go():
            for part in (getattr(srv, "backup", None), getattr(srv, "weekly", None)):
                if part is None:
                    continue
                try:
                    part.tick()
                except Exception:
                    log.exception("양식함: 시작 때 백업·주간 알림 확인 실패")
        threading.Thread(target=go, name="forms-backup-kick", daemon=True).start()


# ── 복원 (forms-restore) ────────────────────────────────────────────────────

def _say(out, text: str = "") -> None:
    out(text)


def restore(data_dir, backup_dir, *, slot: int | None = None, dry_run: bool = False, out=print,
            clock=time.time) -> int:
    """백업 폴더에서 forms.db·판 파일을 되살린다. 돌려주는 값: 0 성공(미리보기 포함), 1 실패·확인 문제, 2 서버 실행 중."""
    data = Path(os.path.abspath(str(data_dir)))
    bdir = Path(os.path.abspath(str(backup_dir)))
    if not data.is_dir():
        _say(out, f"오류: Drev 데이터 폴더가 없습니다: {data}")
        return 1
    if not bdir.is_dir():
        _say(out, f"오류: 백업 폴더가 없습니다: {bdir}")
        return 1
    from watcher.forms.server import InstanceLock          # 서버와 같은 단일 실행 뮤텍스
    lock = InstanceLock(data)
    if not lock.acquire():
        _say(out, "양식함 서버가 실행 중이라 복원하지 않습니다 — Drev 화면 설정 › 양식함에서 [양식함 끄기]를 누른 뒤 "
                  "다시 실행하세요. 복원이 끝나면 [양식함 켜기]로 다시 켭니다. "
                  "(서버를 끈 같은 Windows 계정에서 실행하세요 — 다른 계정의 서버는 여기서 알아보지 못합니다)")
        return 2
    try:
        if _lock_for(data).locked():
            _say(out, "이 PC에서 양식함 백업이 돌고 있습니다 — 끝난 뒤 다시 실행하세요.")
            return 2
        return _restore(data, bdir, slot, dry_run, out, clock)
    finally:
        lock.release()


def _candidates(bdir: Path, slot: int | None) -> list[Path]:
    if slot is not None:
        return [bdir / SLOT_FMT.format(int(slot))]
    try:
        names = os.listdir(bdir)
    except OSError:
        return []
    return [bdir / n for n in sorted(names) if SLOT_RE.fullmatch(n)]


def _read(p: Path) -> bytes | None:
    try:
        with open(p, "rb") as f:
            return f.read()
    except OSError:
        return None


def _file_sha(p: Path) -> str | None:
    try:
        return sha256_of(p) if p.is_file() else None
    except OSError:
        return None


def _purge_records(blob: bytes | None) -> dict:
    """DB 바이트 → {판 id: (sha256, purged_at, purged_by)} — 정리한 판만. 검사 실패·옛 스키마(칸 없음)·읽기 실패면 {}.
    파일을 열지 않고 메모리에서만 본다."""
    if not blob:
        return {}
    mem = sqlite3.connect(":memory:")
    try:
        mem.deserialize(_rollback_header(bytes(blob)))     # 지금 forms.db는 WAL 머리 — 메모리에서는 롤백 머리로 읽는다
        if _integrity(mem) != "ok" or not _has_purged(mem):
            return {}
        has_by = any(r[1] == "purged_by" for r in mem.execute("PRAGMA table_info(versions)").fetchall())
        by = "purged_by" if has_by else "NULL"
        return {int(vid): (str(sha or "").lower(), str(at), who) for vid, sha, at, who in mem.execute(
            f"SELECT id, sha256, purged_at, {by} FROM versions WHERE purged_at IS NOT NULL").fetchall()}
    except (sqlite3.Error, ValueError, TypeError):
        return {}
    finally:
        mem.close()


def _ids(blob: bytes | None) -> tuple[set, set] | None:
    """DB 바이트 → (판 id 모음, 제출 id 모음). 검사 실패·읽기 실패면 None. 파일을 열지 않고 메모리에서만 본다."""
    if not blob:
        return None
    mem = sqlite3.connect(":memory:")
    try:
        mem.deserialize(_rollback_header(bytes(blob)))
        if _integrity(mem) != "ok":
            return None
        vers = {int(r[0]) for r in mem.execute("SELECT id FROM versions").fetchall()}
        subs = {int(r[0]) for r in mem.execute("SELECT id FROM submissions").fetchall()}
        return vers, subs
    except (sqlite3.Error, ValueError, TypeError):
        return None
    finally:
        mem.close()


def _live_extra(data: Path, chosen_blob: bytes) -> tuple[int, int]:
    """지금 forms.db에만 있고 고른 사본에는 없는 (판 수, 제출 수) — 복원하면 보이지 않게 될 것 (2026-10-31 실사용 검토).
    지금 DB를 읽기 전용으로 메모리에서만 본다. 읽지 못하면 (0, 0)."""
    live = data / DB_NAME
    if not live.is_file():
        return 0, 0
    now, old = _ids(_read(live)), _ids(chosen_blob)
    if now is None or old is None:
        return 0, 0
    return len(now[0] - old[0]), len(now[1] - old[1])


def _later_purges(data: Path, bdir: Path, chosen: Path, chosen_at: str) -> tuple[dict, list[str]]:
    """고른 사본을 뜬 뒤 보존 만료로 정리한 판의 기록 — 지금 forms.db(비켜 둘 것)와 고른 것보다 새 사본 가운데 가장 새 것에서.
    돌려줌: ({판 id: (sha256, purged_at, purged_by, 출처)}, 알림 줄). 앞의 출처가 먼저 (지금 forms.db → 가장 새 사본).
    정리는 되돌릴 수 없으므로(파일이 지워졌다) 어느 쪽에든 기록이 있으면 되살리지 않는다 (2026-10-30 검토 2)."""
    found: dict = {}
    notes: list[str] = []
    live = data / DB_NAME
    if live.is_file():
        recs = _purge_records(_read(live))
        for vid, rec in recs.items():
            found.setdefault(vid, (*rec, f"지금 {DB_NAME}"))
        wal = data / (DB_NAME + "-wal")
        try:
            if wal.is_file() and wal.stat().st_size > 0:
                notes.append(f"지금 {DB_NAME}-wal에 아직 합쳐지지 않은 기록이 있어 최근 정리 기록 일부를 못 봤을 수 있습니다")
        except OSError:
            pass
    newer = []
    for p in _candidates(bdir, None):
        if _norm(p) == _norm(chosen) or not p.is_file():
            continue
        blob = _read(p)
        info = inspect_db(blob) if blob is not None else {"ok": False}
        if info.get("ok") and info.get("schema", 0) <= SCHEMA_VERSION and str(info.get("taken_at") or "") > str(chosen_at or ""):
            newer.append((str(info["taken_at"]), p, blob))
    if newer:
        newer.sort(key=lambda x: x[0], reverse=True)
        _at, p, blob = newer[0]
        for vid, rec in _purge_records(blob).items():
            found.setdefault(vid, (*rec, p.name))
    return found, notes


def _restore(data: Path, bdir: Path, slot: int | None, dry_run: bool, out, clock) -> int:
    _say(out, f"백업 폴더: {bdir}")
    _say(out, f"데이터 폴더: {data}")
    found = []
    for p in _candidates(bdir, slot):
        if not p.is_file():
            _say(out, f"  {p.name}: 없음")
            continue
        blob = _read(p)
        info = inspect_db(blob) if blob is not None else {"ok": False, "error": "읽을 수 없음"}
        if info["ok"] and info["schema"] > SCHEMA_VERSION:
            info = {**info, "ok": False, "error": f"더 새 판 Drev가 만든 사본입니다(스키마 {info['schema']})"}
        found.append((p, blob, info))
        mark = (f"찍은 때 {info['taken_at'] or '모름'} · 판 {info['versions']}개 · 검사 OK" if info["ok"]
                else f"쓸 수 없음 — {info['error']}")
        _say(out, f"  {p.name}: {mark}")
    good = [x for x in found if x[2]["ok"]]
    if not good:
        _say(out, "오류: 검사를 통과한 DB 사본이 없습니다 — 아무것도 바꾸지 않았습니다.")
        return 1
    good.sort(key=lambda x: x[2]["taken_at"], reverse=True)
    path, blob, info = good[0]
    _say(out, f"고른 사본: {path.name} (찍은 때 {info['taken_at'] or '모름'})")
    if 0 < info["schema"] < SCHEMA_VERSION:     # 재검토 이주 5
        _say(out, f"  주의: 옛 판(스키마 {info['schema']}) 사본입니다 — 복원하면 이 판(스키마 {SCHEMA_VERSION})으로 이주합니다. "
                  "그 사본을 뜬 뒤 정한 기밀 폴더·승인 단계·승인권자·보존 기간은 되살아나지 않으니 복원 뒤 다시 확인하세요.")

    # 판 파일 계획 — 사본 DB의 versions 기준
    mem = sqlite3.connect(":memory:")
    try:
        mem.deserialize(_rollback_header(bytes(blob)))
        purged_col = ", purged_at" if _has_purged(mem) else ", NULL"
        rows = mem.execute(f"SELECT id, path, sha256, size{purged_col} FROM versions ORDER BY id").fetchall()
    finally:
        mem.close()
    later, later_notes = _later_purges(data, bdir, path, info["taken_at"])
    plan = {"ok": [], "restore": [], "damaged": [], "lost": [], "purged": [], "purged_later": []}
    for vid, rel, sha, size, purged_at in rows:
        if purged_at:                                  # 보존 기간이 지나 정리한 판 — 되살리지 않는다 (2026-10-30)
            plan["purged"].append((vid, rel, "정리됨"))
            continue
        rec = later.get(int(vid))
        if rec is not None and rec[0] == str(sha or "").lower():
            # 이 사본을 뜬 뒤 보존 만료로 정리한 판 — 되살리지 않고, 복원한 DB에 정리 기록을 옮겨 적는다 (2026-10-30 검토 2)
            plan["purged_later"].append((vid, rel, rec))
            continue
        parts = _rel_parts(rel)
        if parts is None:
            plan["lost"].append((vid, rel, "보관 경로가 이상합니다"))
            continue
        live = data.joinpath(STORE_DIR, *parts)
        want = str(sha or "").lower()
        got = _file_sha(live)
        if got == want:
            plan["ok"].append((vid, rel, parts))
        elif got is not None:
            plan["damaged"].append((vid, rel, "지금 보관소 파일의 지문이 기록과 다릅니다"))
        else:
            copy = bdir.joinpath(STORE_COPY, *parts)
            if _file_sha(copy) == want:
                plan["restore"].append((vid, rel, parts))
            else:
                plan["lost"].append((vid, rel, "백업 사본도 없거나 지문이 다릅니다"))
    ts = datetime.fromtimestamp(float(clock())).strftime("%Y%m%d-%H%M%S")
    aside = [n for n in (DB_NAME + "-wal", DB_NAME + "-shm", DB_NAME) if os.path.lexists(data / n)]
    _say(out, "")
    for n in aside:
        _say(out, f"지금 {n} → {n}{ASIDE_TAG}{ts} 로 비켜 둠 (지우지 않음)")
    extra_v, extra_s = _live_extra(data, blob)
    if extra_v or extra_s:
        _say(out, f"주의: 지금 {DB_NAME}에는 이 사본에 없는 판 {extra_v}개·제출 {extra_s}건이 있습니다 — "
                  f"복원하면 보이지 않게 됩니다(지금 DB는 {DB_NAME}{ASIDE_TAG}{ts}로 비켜 둡니다)")
    _say(out, f"{path.name} → {DB_NAME}")
    _say(out, f"판 파일: 이미 있음 {len(plan['ok'])}개 · 되살림 {len(plan['restore'])}개 · "
              f"손상 {len(plan['damaged'])}개 · 되살릴 수 없음 {len(plan['lost'])}개"
              + (f" · 정리됨 {len(plan['purged'])}개(보존 기간이 지나 지운 판 — 되살리지 않음)" if plan["purged"] else ""))
    if plan["purged_later"]:
        srcs = sorted({rec[3] for _v, _r, rec in plan["purged_later"]})
        _say(out, f"보존 만료로 정리한 판 — 되살리지 않음: {len(plan['purged_later'])}개 (이 사본을 뜬 뒤 정리됨 — "
                  f"{', '.join(srcs)}의 기록. 복원한 forms.db에 정리한 때·사람을 옮겨 적습니다)")
        for vid, rel, rec in plan["purged_later"][:20]:
            _say(out, f"  판 {vid} {rel}: {rec[1]} 정리")
    for note in later_notes:
        _say(out, f"주의: {note}")
    for vid, rel, why in (plan["damaged"] + plan["lost"])[:20]:
        _say(out, f"  판 {vid} {rel}: {why}")
    if dry_run:
        _say(out, "")
        _say(out, "(미리보기 — 아무것도 바꾸지 않았습니다. 실제로 하려면 --dry-run 없이 다시 실행하세요.)")
        return 0

    guard = Guard([data])
    moved: list[tuple[Path, str]] = []
    try:
        for n in aside:
            moved.append((guard.rename_aside(data / n, f"{n}{ASIDE_TAG}{ts}"), n))
        guard.write_new(guard.target(data, DB_NAME), blob)
    except (GuardError, OSError) as e:
        for dst, orig in reversed(moved):              # 되돌린다 — 반쯤 바뀐 채로 두지 않게
            try:
                guard.rename_aside(dst, orig)
            except (GuardError, OSError):
                _say(out, f"  되돌리지 못함: {dst} → {orig} (손으로 이름을 되돌리세요)")
        _say(out, f"오류: forms.db를 바꾸지 못했습니다 — {type(e).__name__}: {e}")
        return 1
    restored, failed = 0, []
    want_sha = {r[0]: str(r[2] or "").lower() for r in rows}
    for vid, rel, parts in plan["restore"]:
        blob_f = _read(bdir.joinpath(STORE_COPY, *parts))
        if blob_f is None or hashlib.sha256(blob_f).hexdigest() != want_sha[vid]:
            failed.append((vid, rel, "백업 사본을 다시 읽지 못했습니다"))
            continue
        try:
            guard.write_new(guard.target(data, STORE_DIR, *parts), blob_f)
            restored += 1
        except (GuardError, OSError) as e:
            failed.append((vid, rel, f"{type(e).__name__}: {e}"))

    # 확인 — 되살린 DB를 정식으로 열어(필요하면 이주) 모든 판 파일의 존재·지문을 본다
    problems, pending_missing, pending_total, purged_n, carried = [], 0, 0, 0, 0
    try:
        with FormsStore(data) as st:
            if plan["purged_later"]:                   # 사본을 뜬 뒤의 정리 기록을 옮겨 적는다 — 판 id + 지문이 같은 행만
                with st.tx() as c:
                    for vid, _rel, rec in plan["purged_later"]:
                        carried += c.execute(
                            "UPDATE versions SET purged_at = ?, purged_by = ? "
                            "WHERE id = ? AND LOWER(sha256) = ? AND purged_at IS NULL",
                            (rec[1], rec[2], int(vid), rec[0])).rowcount
            for vid, rel, sha, purged_at in st.conn.execute(
                    "SELECT id, path, sha256, purged_at FROM versions ORDER BY id").fetchall():
                if purged_at:                          # 정리한 판 — 파일이 없어야 맞다
                    purged_n += 1
                    continue
                parts = _rel_parts(rel)
                got = _file_sha(data.joinpath(STORE_DIR, *parts)) if parts else None
                if got != str(sha or "").lower():
                    problems.append((vid, rel, "파일 없음" if got is None else "지문 다름"))
            for (staged,) in st.conn.execute(
                    "SELECT staged_path FROM submissions WHERE status = 'pending'").fetchall():
                pending_total += 1
                parts = [p for p in re.split(r"[\\/]+", str(staged or "")) if p]
                try:
                    for p in parts:
                        check_name(p)
                except GuardError:
                    parts = []
                if not parts or not data.joinpath(STORE_DIR, *parts).is_file():
                    pending_missing += 1
            st.record_audit(None, "restore", path.name,
                            detail=(f"{path.name}(찍은 때 {info['taken_at']})로 복원 · 판 파일 되살림 {restored}개 · "
                                    f"확인 문제 {len(problems)}건"
                                    + (f" · 정리됨 {purged_n}개" if purged_n else "")
                                    + (f"(사본을 뜬 뒤 정리한 판 {carried}개의 정리 기록을 옮겨 적음)" if carried else "")
                                    + f" · 이전 forms.db는 {DB_NAME}{ASIDE_TAG}{ts}"),
                            login="(복원)")
    except (FormsError, sqlite3.Error, OSError) as e:
        _say(out, f"오류: 되살린 forms.db를 열지 못했습니다 — {type(e).__name__}: {e}")
        return 1
    _say(out, "")
    _say(out, f"복원했습니다: {path.name} → {DB_NAME} · 판 파일 {restored}개 되살림")
    if carried:
        _say(out, f"보존 만료로 정리한 판 {carried}개 — 되살리지 않고 정리한 때·사람을 복원한 {DB_NAME}에 옮겨 적었습니다")
    total = len(rows) - purged_n
    gone = f" (정리됨 {purged_n}개는 보존 기간이 지나 지운 판이라 파일이 없는 것이 맞습니다)" if purged_n else ""
    if problems or failed:
        _say(out, f"확인: 판 {total}개 중 {total - len(problems)}개 정상, 문제 {len(problems)}개{gone}")
        for vid, rel, why in (failed + problems)[:30]:
            _say(out, f"  판 {vid} {rel}: {why}")
    else:
        _say(out, f"확인: 판 {total}개 모두 파일이 있고 지문이 맞습니다{gone}")
    if pending_total:
        _say(out, f"검토 대기 {pending_total}건 중 파일이 없는 {pending_missing}건은 다시 올려야 합니다"
                  f"(검토 대기 파일은 백업하지 않습니다)")
    if aside:
        _say(out, f"이전 파일은 {data}에 '{ASIDE_TAG}{ts}'를 붙여 남겨 두었습니다 — 확인이 끝나면 손으로 정리하세요.")
    _say(out, "양식함을 다시 켜세요: Drev 화면 설정 › 양식함 › [양식함 켜기]")
    return 1 if (problems or failed) else 0
