# -*- coding: utf-8 -*-
"""양식함 저장소 — forms.db(SQLite, state.db와 분리) + forms_store/ 보관 파일 (FORMS.md 5절, 2026-10-28 F1).

- 데이터 폴더(state.db가 있는 Drev 데이터 폴더)를 인자로 받는다. 전역 경로를 모른다.
- 판 파일: forms_store/<양식 id>/<판 번호>/<원래 파일명> — 한 번 쓰면 바꾸지 않고 sha256을 적는다.
  검토 대기 파일: forms_store/_pending/<제출 id>-<난수>/<원래 파일명> — 승인되면 판 파일로 옮겨 적고 지운다.
- 파일 쓰기·지우기는 전부 guard.Guard 를 거친다. 이 모듈 자체는 tests/test_readonly.py 의 엄격 검사를 받는다.
- 권한은 여기서 다시 확인한다 — 다음 단계 서버가 실수해도 직원이 승인·폴더 만들기를 못 하게.
- 감시(state.db)와 잠금·DB를 공유하지 않는다.
"""

from __future__ import annotations

import contextlib
import hashlib
import hmac
import io
import json
import calendar
import os
import re
import sqlite3
import threading
import time
import unicodedata
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

from watcher.forms.guard import (Guard, GuardError, GuardExists, GuardNoSpace, check_name, clean_filename,
                                 sha256_of)

SCHEMA_VERSION = 8                 # 2: 비교 캐시·승인 메모·폐기 사유 (F3), 3: 메일 주소·미러 목록 (F4)
                                   # 4: 감사 기록 묶음 칸·IP 실패 표·미러 폴더 목록 (2026-10-28 보안 고침)
                                   # 5: 폴더 순서 칸(sort) — 기본 분류 틀의 차례 (f6, 2026-10-29)
                                   # 6: 문서번호·폴더 번호 머리·정기 검토 (F7 ISO 문서 관리 대장, 2026-10-29)
                                   # 7: 번호가 손 번호인지(doc_no_manual)·이전 번호(doc_no_history) (F7 번호 규칙, 2026-10-29)
                                   # 8: 문서 종류(doc_types)·forms.doc_type·submissions.doc_type (F7 문서 종류, 2026-10-29)
DB_NAME = "forms.db"
STORE_DIR = "forms_store"
PENDING_DIR = "_pending"
ROLES = ("admin", "reviewer", "member")
ALLOWED_EXTS = {".xlsx", ".xlsm", ".xls", ".docx", ".doc", ".hwpx", ".hwp", ".pdf", ".dxf",
                ".dwg", ".pptx", ".txt", ".csv",
                # 서식 파일(양식 그 자체)·옛 파워포인트 (f6, 2026-10-29)
                ".xltx", ".xltm", ".dotx", ".dotm", ".potx", ".hwt", ".ppt"}
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
MAX_FORM_NAME = 100
MAX_NOTE = 500
MAX_CATEGORY = 50
AUDIT_MAX_ROWS = 200_000           # 감사 기록 보존 상한(행) — 넘으면 오래된 것부터 지운다 (보안 F1, 설정 audit_max_rows)
PENDING_KEEP_DAYS = 90             # 반려·취소된 제출의 대기 파일 보존 기간(일) — 지나면 지운다 (보안 F7)
GROUP_SECONDS = 60                 # 같은 주소의 연달은 로그인 실패를 한 줄로 묶는 창(초) (보안 F1)
GROUP_MAX_LOGINS = 30              # 묶은 줄에 적어 두는 '시도한 아이디' 수 — 넘는 것은 개수만
REVIEW_MONTHS_DEFAULT = 12         # 정기 검토 주기 기본값(개월) — 설정 review_months_default, 0 = 끔 (F7)
REVIEW_MONTHS_MAX = 120
REVIEW_SOON_DAYS = 30              # 기한이 이 날수 안에 오면 '곧' (F7)
MAX_STORE_PATH = 250               # 보관 경로(대기·판 파일) 길이 상한 — LongPathsEnabled 없는 PC의 260자 한도 아래로 (2026-10-30)
SEARCH_MAX = 200                   # 찾기 결과 상한 — 넘으면 '더 좁혀 주세요' (2026-10-30)
ORPHAN_GRACE_SECONDS = 300         # 처리된 지 이만큼 지난 제출의 남은 대기 파일만 정리 (승인 자신의 지우기와 겹치지 않게)
ORPHAN_STALE_SECONDS = 86400       # 기록 없는 대기 칸(되돌려진 올리기)은 이만큼 오래된 것만 정리
MAX_DOC_NO = 40
# 번호 머리·종류 기호 — 영문 대문자·숫자·한글 음절(가-힣, 자모 낱자는 아님) 1~8자, 가운데에 '.'(ISO 조항 7.5·8.5.1 —
# 처음·끝 아님, '..' 아님) (F7 문서 종류, 2026-10-29). 문서번호도 한글 음절을 받는다 — 처음과 끝은 영문·숫자·한글
FOLDER_CODE_RE = re.compile(r"(?!.*\.\.)[A-Z0-9가-힣](?:[A-Z0-9가-힣.]{0,6}[A-Z0-9가-힣])?")
DOC_NO_RE = re.compile(r"[A-Z0-9가-힣](?:[A-Z0-9가-힣._-]{0,38}[A-Z0-9가-힣])?")
GLOBAL_PREFIX = "F"                # 조상 폴더에 번호 머리가 하나도 없을 때 — F-0001 (F7)
GLOBAL_HEAD = GLOBAL_PREFIX + "-"  # 전역 번호의 머리(일련번호 앞 글자 전부)
GLOBAL_DIGITS = 4
# 문서번호 규칙 (F7 번호 규칙, 2026-10-29) — forms.db meta에 둔다(양식함 서버 설정 관례). 앞으로 매기는 번호에만 적용
DOCNO_DEFAULT_PATTERN = "{분류}-{번호}"     # 지금까지의 꼴: 조상 폴더 머리를 '-'로 잇고 + 세 자리 (QA-01-01-001)
DOCNO_DEFAULT_DIGITS = 3
DOCNO_DIGITS_MIN, DOCNO_DIGITS_MAX = 2, 6
MAX_DOCNO_PATTERN = 60
DOCNO_TOKENS = ("분류", "대", "중", "소", "종류", "YYYY", "YY", "번호")
DOCNO_SEPS = "-_."
DOCNO_FOLDER_TOKENS = ("분류", "대", "중", "소")
DOCNO_IDENT_TOKENS = DOCNO_FOLDER_TOKENS + ("종류",)   # 머리가 문서를 가리키게 하는 칸 — 폴더 머리 칸과 {종류}
# 문서 종류 (F7 문서 종류, 2026-10-29) — 같은 부서 폴더 안에서도 종류마다 따로 세는 ISO 회사용({종류}-{대}-{번호} → QP-QA-001·
# QF-QA-001). 새 DB와 이주한 DB 모두에 ISO 기본 다섯 가지를 넣는다. 양식에는 종류 id를 둔다(기호를 바꿔도 양식은 그대로)
DOC_TYPE_DEFAULTS = (("QM", "품질매뉴얼"), ("QP", "절차서"), ("QI", "지침서"), ("QF", "양식"), ("QR", "기록"))
MAX_DOC_TYPE_NAME = 40
# 화면의 보기 단추 (규칙, 설명) — ?preset=번호 로 칸만 채운다(저장은 [저장])
DOCNO_PRESETS = (                 # (규칙, 자릿수, 설명) — 첫 줄이 기본 규칙(되돌리기)
    (DOCNO_DEFAULT_PATTERN, DOCNO_DEFAULT_DIGITS, "기본 — 위 폴더 머리를 모두 잇기 (QA-01-01-001)"),
    ("{대}-{YYYY}-{번호}", 3, "대분류 머리 + 해 (QA-2026-001)"),
    ("QF-{대}-{중}-{번호}", 3, "회사 글자 + 대·중분류 (QF-QA-01-001)"),
    ("{대}_{중}_{번호}", 3, "밑줄로 잇기 (HR_01_001)"),
    ("{종류}-{대}-{번호}", 3, "문서 종류 + 대분류 (QP-QA-001)"),
)


class FormsError(Exception):
    """양식함 오류의 뿌리. 메시지는 화면에 그대로 보여도 되는 쉬운 한국어."""


class PermissionDenied(FormsError):
    """그 역할·폴더에서 할 수 없는 일."""


class NotFound(FormsError):
    """없는 대상."""


class Conflict(FormsError):
    """이름 중복·이미 처리됨·같은 파일 재제출 등 지금 상태와 맞지 않는 요청."""


class InvalidInput(FormsError, ValueError):
    """입력값이 규칙에 맞지 않는다."""


class MemoRequired(InvalidInput):
    """바꾼 내용이 빈 옛 개정안을 승인 메모 없이 승인하려 했다 (2026-10-30) — 화면은 검토 화면으로 돌려보낸다."""


class NoSpace(FormsError):
    """보관소 디스크 여유가 모자라 저장하지 못했다 (2026-10-30 — 화면은 500 대신 쉬운 말)."""


def name_key(s: str) -> str:
    """이름 비교 열쇠 — 전각·반각, 대소문자, 앞뒤·겹친 공백을 접는다 ('잔업 집계표' = '잔업  집계표')."""
    return " ".join(unicodedata.normalize("NFKC", str(s or "")).casefold().split())


FIELD_SEP = "\x1f"                   # 찾기 칸 사이 구분 글자 — 칸끼리 이어 붙어 잘못 맞지 않게 ('성적서'+'품질' ≠ '성적서품질')


def search_key(s) -> str:
    """찾기 열쇠 — name_key에서 빈칸까지 모두 뺀다 ('수입 검사' = '수입검사', 2026-10-30)."""
    return "".join(unicodedata.normalize("NFKC", str(s or "")).casefold().split())


def search_fields_key(s) -> str:
    """여러 칸을 FIELD_SEP로 이은 글자 → 칸마다 search_key 후 다시 FIELD_SEP로 (SQL 함수 drev_fold). 구분 글자는 빈칸으로 접히지 않는다."""
    return FIELD_SEP.join(search_key(x) for x in str(s or "").split(FIELD_SEP))


def now_text(ts: float | None = None) -> str:
    return datetime.fromtimestamp(time.time() if ts is None else ts).isoformat(timespec="seconds")


# ── 올린 파일 내용 최소 검증 (2026-10-28 보안 F4) ─────────────────────────────────
# 확장자만 믿지 않는다 — 실행 파일을 '.xlsx' 이름으로 올려 승인·배포되는 것을 막는 정도의 머리(시그니처) 확인.
# 내용이 맞는 양식인지(셀·글자)는 보지 않는다(원칙 6). 압축을 풀지 않고 ZIP 목차만 읽는다.
_ZIP_MAGIC = b"PK\x03\x04"
_OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
_OOXML_EXTS = {".xlsx", ".xlsm", ".docx", ".pptx", ".xltx", ".xltm", ".dotx", ".dotm", ".potx"}
_OLE_EXTS = {".xls", ".doc", ".hwp", ".hwt", ".ppt"}     # hwt(한글 서식)도 OLE만 — 옛 HWP 3.0 꼴은 받지 않는다 (f6)
_DXF_BINARY = b"AutoCAD Binary DXF\r\n\x1a\x00"
_KIND_NAME = {".xlsx": "엑셀", ".xlsm": "엑셀", ".xls": "엑셀(옛 형식)", ".docx": "워드", ".doc": "워드(옛 형식)",
              ".pptx": "파워포인트", ".hwpx": "한글", ".hwp": "한글(옛 형식)", ".pdf": "PDF", ".dxf": "DXF 도면",
              ".dwg": "DWG 도면", ".txt": "글자", ".csv": "CSV",
              ".xltx": "엑셀 서식", ".xltm": "엑셀 서식", ".dotx": "워드 서식", ".dotm": "워드 서식",
              ".potx": "파워포인트 서식", ".hwt": "한글 서식", ".ppt": "파워포인트(옛 형식)"}


def check_content(data: bytes, ext: str) -> None:
    """확장자별 머리 확인. 맞지 않으면 InvalidInput(쉬운 말).

    - 실행 파일(MZ로 시작)은 어떤 확장자로 와도 거부.
    - xlsx·xlsm·docx·pptx·xltx·xltm·dotx·dotm·potx: ZIP(PK\\x03\\x04)이고 목차에 [Content_Types].xml. hwpx: ZIP이고 목차에 mimetype.
    - xls·doc·hwp·hwt·ppt: OLE 복합 문서(D0 CF 11 E0 A1 B1 1A E1). pdf: 앞 1KB 안에 %PDF-. dwg: 'AC10'으로 시작.
    - dxf: 글자 DXF(앞 4KB에 NUL 없고 첫 줄이 그룹 코드 숫자) 또는 이진 DXF 머리.
    - txt·csv: NUL 없음 (UTF-16 BOM으로 시작하면 UTF-16으로 풀리는지만 본다 — 메모장 '유니코드' 저장)."""
    b = bytes(data[:8])
    kind = _KIND_NAME.get(ext, ext.lstrip("."))
    if b[:2] == b"MZ":
        raise InvalidInput("실행 파일(프로그램)은 올릴 수 없습니다 — 양식 파일을 올려 주세요")
    bad = InvalidInput(f"파일 내용이 {kind} 파일이 아닙니다 — 확장자만 바꾼 파일은 올릴 수 없습니다. "
                       f"원래 프로그램에서 '{ext.lstrip('.')}' 형식으로 저장해 올려 주세요")
    if ext in _OOXML_EXTS or ext == ".hwpx":
        if not data.startswith(_ZIP_MAGIC):
            raise bad
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                names = set(z.namelist())
        except Exception:                      # 깨진 ZIP — BadZipFile·LargeZipFile·ValueError 등
            raise bad
        need = "mimetype" if ext == ".hwpx" else "[Content_Types].xml"
        if need not in names:
            raise bad
        return
    if ext in _OLE_EXTS:
        if not data.startswith(_OLE_MAGIC):
            raise bad
        return
    if ext == ".pdf":
        if b"%PDF-" not in data[:1024]:
            raise bad
        return
    if ext == ".dwg":
        if not data.startswith(b"AC10"):
            raise bad
        return
    if ext == ".dxf":
        if data.startswith(_DXF_BINARY):
            return
        head = data[:4096]
        if b"\x00" in head:
            raise bad
        text = head.decode("latin-1").lstrip("﻿\xef\xbb\xbf")
        first = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
        if not (first.lstrip("-").isdigit() and len(first) <= 6):
            raise bad
        return
    if ext in (".txt", ".csv"):
        if data.startswith((b"\xff\xfe", b"\xfe\xff")):
            try:
                data.decode("utf-16")
            except UnicodeDecodeError:
                raise bad
            return
        if b"\x00" in data:
            raise bad
        return


def _plain_text(value, what: str, max_len: int, *, required: bool, multiline: bool = False) -> str:
    """한 줄 글자 칸 검사. multiline: 여러 줄 칸(승인 메모·반려 사유·폐기·복원 사유 — 화면의 textarea, 2026-10-30) —
    줄바꿈(\\r\\n·\\r → \\n)만 더 받는다. 그 밖의 제어·서식 글자는 여전히 거부."""
    v = unicodedata.normalize("NFC", str(value or ""))
    if multiline:
        v = re.sub(r"\r\n?", "\n", v)
    v = v.strip()
    if required and not v:
        raise InvalidInput(f"{what}을(를) 적어 주세요")
    if len(v) > max_len:
        raise InvalidInput(f"{what}이(가) 너무 깁니다 (최대 {max_len}자)")
    for ch in v:
        if unicodedata.category(ch) in ("Cc", "Cf", "Zl", "Zp") and ch != "\t" and not (multiline and ch == "\n"):
            raise InvalidInput(f"{what}에 쓸 수 없는 글자가 있습니다")
    return v


class _Result:
    """잠금 안에서 다 읽어 둔 결과 — 다른 스레드의 트랜잭션 도중 같은 연결의 커서를 넘기지 않으려고."""

    def __init__(self, rows: list, lastrowid, rowcount):
        self._rows, self.lastrowid, self.rowcount = rows, lastrowid, rowcount

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def fetchall(self) -> list:
        return list(self._rows)

    def __iter__(self):
        return iter(self._rows)


class _LockedConn:
    """연결 하나를 여러 스레드(다음 단계 서버)가 같이 써도 되게 — 모든 실행을 저장소 잠금 안에서 한다.
    트랜잭션(tx)은 같은 잠금을 끝까지 쥐므로, 다른 스레드가 쓰는 도중의 값을 읽지 않는다."""

    def __init__(self, raw: sqlite3.Connection, lock):
        self.raw, self._lock = raw, lock

    def execute(self, sql: str, args=()) -> _Result:
        with self._lock:
            cur = self.raw.execute(sql, args)
            return _Result(cur.fetchall(), cur.lastrowid, cur.rowcount)

    def executemany(self, sql: str, seq) -> _Result:
        with self._lock:
            cur = self.raw.executemany(sql, seq)
            return _Result([], cur.lastrowid, cur.rowcount)

    @property
    def in_transaction(self) -> bool:
        return self.raw.in_transaction

    def close(self) -> None:
        with self._lock:
            self.raw.close()


# 이주 1: 첫 스키마. 문장은 모두 IF NOT EXISTS — 도중에 멈춘 이주를 다시 돌려도 안전하다.
_MIGRATION_1 = [
    """CREATE TABLE IF NOT EXISTS users (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        login        TEXT NOT NULL,                -- 적은 그대로의 아이디
        login_key    TEXT NOT NULL UNIQUE,         -- 접은 아이디 (중복 검사)
        display_name TEXT NOT NULL,
        role         TEXT NOT NULL CHECK (role IN ('admin', 'reviewer', 'member')),
        pw_hash      TEXT NOT NULL,
        disabled     INTEGER NOT NULL DEFAULT 0,
        must_change  INTEGER NOT NULL DEFAULT 0,   -- 초기화된 비밀번호 → 첫 로그인 때 바꿔야 함
        created_at   TEXT NOT NULL,
        created_by   INTEGER
    )""",
    """CREATE TABLE IF NOT EXISTS sessions (
        token_hash TEXT PRIMARY KEY,               -- 토큰 원문은 저장하지 않는다 (sha256)
        user_id    INTEGER NOT NULL REFERENCES users(id),
        csrf       TEXT NOT NULL,
        created_at REAL NOT NULL,
        last_seen  REAL NOT NULL,
        ip         TEXT
    )""",
    "CREATE INDEX IF NOT EXISTS ix_sessions_user ON sessions(user_id)",
    """CREATE TABLE IF NOT EXISTS login_failures (
        login_key    TEXT NOT NULL,
        ip           TEXT NOT NULL,
        count        INTEGER NOT NULL,
        locked_until REAL,
        last_at      REAL NOT NULL,
        PRIMARY KEY (login_key, ip)
    )""",
    """CREATE TABLE IF NOT EXISTS folders (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        parent_id  INTEGER REFERENCES folders(id),
        name       TEXT NOT NULL,
        name_key   TEXT NOT NULL,
        created_by INTEGER REFERENCES users(id),
        created_at TEXT NOT NULL
    )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS ux_folders_name ON folders(IFNULL(parent_id, 0), name_key)",
    """CREATE TABLE IF NOT EXISTS folder_reviewers (
        folder_id INTEGER NOT NULL REFERENCES folders(id),
        user_id   INTEGER NOT NULL REFERENCES users(id),
        PRIMARY KEY (folder_id, user_id)
    )""",
    """CREATE TABLE IF NOT EXISTS forms (
        id                 INTEGER PRIMARY KEY AUTOINCREMENT,
        folder_id          INTEGER NOT NULL REFERENCES folders(id),
        name               TEXT NOT NULL,
        name_key           TEXT NOT NULL,
        category           TEXT NOT NULL DEFAULT '',
        current_version_id INTEGER,
        retired            INTEGER NOT NULL DEFAULT 0,
        created_by         INTEGER REFERENCES users(id),
        created_at         TEXT NOT NULL,
        UNIQUE (folder_id, name_key)
    )""",
    """CREATE TABLE IF NOT EXISTS versions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        form_id     INTEGER NOT NULL REFERENCES forms(id),
        number      INTEGER NOT NULL,
        path        TEXT NOT NULL,                 -- forms_store 기준 상대 경로
        filename    TEXT NOT NULL,
        sha256      TEXT NOT NULL,
        size        INTEGER NOT NULL,
        uploaded_by INTEGER REFERENCES users(id),
        uploaded_at TEXT NOT NULL,
        approved_by INTEGER REFERENCES users(id),
        approved_at TEXT NOT NULL,
        note        TEXT NOT NULL DEFAULT '',
        submission_id INTEGER,
        UNIQUE (form_id, number)
    )""",
    """CREATE TABLE IF NOT EXISTS submissions (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        kind         TEXT NOT NULL CHECK (kind IN ('new', 'revision')),
        folder_id    INTEGER NOT NULL REFERENCES folders(id),
        form_id      INTEGER REFERENCES forms(id),
        form_name    TEXT NOT NULL,
        form_key     TEXT NOT NULL,
        category     TEXT NOT NULL DEFAULT '',
        filename     TEXT NOT NULL,
        sha256       TEXT NOT NULL,
        size         INTEGER NOT NULL,
        staged_path  TEXT NOT NULL DEFAULT '',     -- forms_store 기준 상대 경로 (승인 뒤 비움)
        note         TEXT NOT NULL DEFAULT '',
        status       TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
        reason       TEXT NOT NULL DEFAULT '',
        submitted_by INTEGER NOT NULL REFERENCES users(id),
        submitted_at TEXT NOT NULL,
        decided_by   INTEGER REFERENCES users(id),
        decided_at   TEXT,
        version_id   INTEGER REFERENCES versions(id)
    )""",
    "CREATE INDEX IF NOT EXISTS ix_submissions_status ON submissions(status, folder_id)",
    """CREATE TABLE IF NOT EXISTS subscriptions (
        user_id   INTEGER NOT NULL REFERENCES users(id),
        folder_id INTEGER NOT NULL REFERENCES folders(id),
        PRIMARY KEY (user_id, folder_id)
    )""",
    """CREATE TABLE IF NOT EXISTS audit (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        at      TEXT NOT NULL,
        user_id INTEGER,
        login   TEXT NOT NULL DEFAULT '',          -- 그때의 아이디 (계정이 바뀌어도 남게)
        action  TEXT NOT NULL,
        target  TEXT NOT NULL DEFAULT '',
        ip      TEXT NOT NULL DEFAULT '',
        detail  TEXT NOT NULL DEFAULT ''
    )""",
    "CREATE INDEX IF NOT EXISTS ix_audit_at ON audit(at)",
]

def _add_column(conn, table: str, column: str, decl: str) -> None:
    """칸이 없을 때만 더한다 — ALTER TABLE ADD COLUMN에는 IF NOT EXISTS가 없다 (도중에 멈춘 이주를 다시 돌려도 안전하게)."""
    have = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in have:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")


def _migration_2(conn) -> None:
    """이주 2 (F3): 자동 비교 결과 캐시, 승인 메모, 폐기 사유·누가·언제."""
    conn.execute("""CREATE TABLE IF NOT EXISTS compare_cache (
        cache_key  TEXT PRIMARY KEY,               -- 엔진 판 | 이전 지문+확장자 | 새 지문+확장자
        status     TEXT NOT NULL,                  -- ok / failed (지원 안 하는 형식은 저장하지 않는다)
        result     TEXT NOT NULL,                  -- JSON (근거 표)
        created_at REAL NOT NULL
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_compare_cache_at ON compare_cache(created_at)")
    _add_column(conn, "submissions", "decision_note", "TEXT NOT NULL DEFAULT ''")   # 승인 메모
    _add_column(conn, "forms", "retired_reason", "TEXT NOT NULL DEFAULT ''")
    _add_column(conn, "forms", "retired_by", "INTEGER")
    _add_column(conn, "forms", "retired_at", "TEXT")


def _migration_3(conn) -> None:
    """이주 3 (F4): 계정 메일 주소(알림용, 선택), 현행 미러 목록(manifest — Drev가 미러에 둔 파일만)."""
    _add_column(conn, "users", "email", "TEXT NOT NULL DEFAULT ''")
    conn.execute("""CREATE TABLE IF NOT EXISTS mirror_files (
        rel_path   TEXT PRIMARY KEY,               -- 미러 뿌리 기준 상대 경로 (/ 구분)
        form_id    INTEGER NOT NULL,
        version_id INTEGER NOT NULL,
        sha256     TEXT NOT NULL,                  -- 둔 파일의 지문 — 이것과 같을 때만 바꾸거나 지운다
        placed_at  TEXT NOT NULL
    )""")


def _migration_4(conn) -> None:
    """이주 4 (2026-10-28 보안 고침): 감사 기록 묶음 칸(횟수·마지막 때·시도한 아이디), 묶음 찾기 색인,
    IP 단위 로그인 실패 표(계정 상관없이), 로그인 실패 정리용 색인, 현행 미러에 Drev가 만든 폴더 목록."""
    _add_column(conn, "audit", "cnt", "INTEGER NOT NULL DEFAULT 1")       # 묶은 줄의 횟수 (보통 1)
    _add_column(conn, "audit", "last_at", "TEXT")                         # 묶은 줄의 마지막 때
    _add_column(conn, "audit", "extra", "TEXT NOT NULL DEFAULT ''")      # 묶은 줄의 시도한 아이디 (JSON)
    conn.execute("CREATE INDEX IF NOT EXISTS ix_audit_group ON audit(action, ip)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_login_failures_at ON login_failures(last_at)")
    conn.execute("""CREATE TABLE IF NOT EXISTS ip_failures (
        ip           TEXT PRIMARY KEY,
        count        INTEGER NOT NULL,             -- 창 안의 실패 수 (아이디 상관없이)
        window_start REAL NOT NULL,                -- 창이 시작된 때
        locked_until REAL,                         -- 주소 잠금이 풀리는 때 (없으면 안 잠김)
        last_at      REAL NOT NULL                 -- 마지막 실패 때 (점증 지연의 기준)
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS mirror_dirs (
        rel_path   TEXT PRIMARY KEY,               -- 미러 뿌리 기준 상대 경로 (/ 구분) — Drev가 만든 폴더만
        created_at TEXT NOT NULL
    )""")


def _migration_5(conn) -> None:
    """이주 5 (f6, 2026-10-29): 폴더 순서 칸. 0 = 이름순(사람이 만든 폴더), 1 이상 = 그 차례(기본 분류 틀·[위로]/[아래로]).
    같은 부모 아래에서 차례 있는 폴더가 먼저(작은 수부터), 그 뒤에 0인 폴더가 이름순."""
    _add_column(conn, "folders", "sort", "INTEGER NOT NULL DEFAULT 0")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_folders_parent ON folders(parent_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_forms_folder ON forms(folder_id)")


DOC_NO_INDEX = ("CREATE UNIQUE INDEX IF NOT EXISTS ux_forms_doc_no ON forms(doc_no) "
                "WHERE doc_no IS NOT NULL AND doc_no != ''")


def _ensure_doc_no_index(conn) -> None:
    """문서번호 부분 유일 색인 — 빈 글자도 '번호 없음'으로 빼는 꼴. 처음 꼴(빈 글자 조건 없음)로 이미 만들어졌으면
    지우고 다시 만든다(F7 검토 7, 스키마 6 안에서 — 여러 번 돌려도 안전)."""
    row = conn.execute("SELECT sql FROM sqlite_master WHERE type = 'index' AND name = 'ux_forms_doc_no'").fetchone()
    if row is not None and "!= ''" not in str(row[0] or ""):
        conn.execute("DROP INDEX ux_forms_doc_no")
    conn.execute(DOC_NO_INDEX)


def _migration_6(conn) -> None:
    """이주 6 (F7, 2026-10-29): ISO 문서 관리 대장.
    folders.code — 문서번호 머리(영문 대문자·숫자 1~8자, 빈 값 = 없음).
    forms.doc_no — 문서번호(NULL = 아직 없음, 값이 있으면 유일 — 부분 유일 색인). 한 번 정하면 폴더를 옮겨도 그대로.
    forms.review_months — 정기 검토 주기(개월): NULL = 전체 기본값, 0 = 안 함. forms.last_reviewed_at — 최근 검토 때.
    doc_counters — 번호 머리마다 지금까지 쓴 가장 큰 일련번호(손으로 고쳐 비운 번호도 다시 매기지 않게)."""
    _add_column(conn, "folders", "code", "TEXT NOT NULL DEFAULT ''")
    _add_column(conn, "forms", "doc_no", "TEXT")
    _add_column(conn, "forms", "review_months", "INTEGER")
    _add_column(conn, "forms", "last_reviewed_at", "TEXT")
    _ensure_doc_no_index(conn)
    conn.execute("""CREATE TABLE IF NOT EXISTS doc_counters (
        prefix TEXT PRIMARY KEY,                   -- 번호 머리 ('QA-01-01', 머리가 없으면 'F')
        last   INTEGER NOT NULL                    -- 그 머리로 매긴 가장 큰 일련번호
    )""")


def _migration_7(conn) -> None:
    """이주 7 (F7 번호 규칙, 2026-10-29): 관리자가 정하는 문서번호 규칙과 [다시 매기기].
    forms.doc_no_manual — 1 = 관리자가 손으로 적은 번호(다시 매기기에서 기본으로 뺀다), 0 = 자동. 이주된 번호는 자동으로 본다.
    doc_no_history — 다시 매기기로 바뀐 번호의 이전 값(양식 상세·대장·엑셀에 '이전 번호'). 규칙 자체는 meta 표(키 docno_*)."""
    _add_column(conn, "forms", "doc_no_manual", "INTEGER NOT NULL DEFAULT 0")
    conn.execute("""CREATE TABLE IF NOT EXISTS doc_no_history (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        form_id INTEGER NOT NULL REFERENCES forms(id),
        old_no  TEXT NOT NULL,                     -- 바뀌기 전 번호
        new_no  TEXT NOT NULL,                     -- 바뀐 번호
        at      TEXT NOT NULL,
        user_id INTEGER                            -- 다시 매긴 사람
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_doc_no_history_form ON doc_no_history(form_id)")
    _restore_manual_flags(conn)


# 스키마 6(규칙 없던 판)이 자동으로 매긴 번호의 꼴 — 폴더 머리(영문·숫자 1~8자)를 '-'로 잇고 '-' + 세 자리 이상,
# 또는 머리가 없을 때 F-네 자리 이상. 이 꼴이 아닌 번호는 사람이 적은 것이다.
_V6_AUTO_RE = re.compile(r"(?:F-[0-9]{4,}|(?!F-)[A-Z0-9]{1,8}(?:-[A-Z0-9]{1,8})*-[0-9]{3,})")


def _restore_manual_flags(conn) -> None:
    """이주 7 안에서(최선 노력) 스키마 6 때 관리자가 손으로 고친 번호를 손 번호(doc_no_manual = 1)로 되살린다.
    ① 감사 기록 'doc_no'(대상 form:ID, 내용 '이름: 이전 → 새')의 마지막 새 번호가 지금 번호와 같으면 손 번호
    ② 스키마 6 자동 꼴(_V6_AUTO_RE)에 맞지 않는 번호도 손 번호. 1로 올리기만 하므로 여러 번 돌려도 같다 (검토 2)."""
    last: dict = {}
    for target, detail in conn.execute(
            "SELECT target, detail FROM audit WHERE action = 'doc_no' AND target LIKE 'form:%' ORDER BY id").fetchall():
        fid = str(target)[5:]
        if fid.isascii() and fid.isdigit() and " → " in str(detail or ""):
            last[int(fid)] = str(detail).rsplit(" → ", 1)[1].strip()
    marks = []
    for fid, no in conn.execute("SELECT id, doc_no FROM forms WHERE doc_no IS NOT NULL AND doc_no != ''").fetchall():
        if last.get(fid) == no or not _V6_AUTO_RE.fullmatch(str(no)):
            marks.append((fid,))
    if marks:
        conn.executemany("UPDATE forms SET doc_no_manual = 1 WHERE id = ?", marks)


def _migration_8(conn) -> None:
    """이주 8 (F7 문서 종류, 2026-10-29): 문서 종류 표 doc_types(기호 유일·이름·차례·사용 중 여부)와
    forms.doc_type(종류 id, NULL = 종류 없음 — 이주된 양식은 모두 NULL), submissions.doc_type(올릴 때 고른 종류).
    종류 표가 비어 있을 때만 ISO 기본 다섯 가지(QM·QP·QI·QF·QR)를 넣는다 — 도중에 멈춘 이주를 다시 돌려도 두 번 넣지 않는다."""
    conn.execute("""CREATE TABLE IF NOT EXISTS doc_types (
        id     INTEGER PRIMARY KEY AUTOINCREMENT,     -- 지운 종류의 id는 다시 쓰지 않는다
        code   TEXT NOT NULL UNIQUE,                  -- 기호 (QP) — 규칙의 {종류} 칸에 들어간다
        name   TEXT NOT NULL,                         -- 이름 (절차서)
        sort   INTEGER NOT NULL DEFAULT 0,            -- 고르기 목록 차례 (작은 수부터)
        active INTEGER NOT NULL DEFAULT 1             -- 0 = 사용 중지(고르기에서 숨김, 이미 쓴 양식은 그대로)
    )""")
    _add_column(conn, "forms", "doc_type", "INTEGER REFERENCES doc_types(id)")
    _add_column(conn, "submissions", "doc_type", "INTEGER")       # 개정안의 NULL = 그 양식의 지금 종류 그대로
    conn.execute("CREATE INDEX IF NOT EXISTS ix_forms_doc_type ON forms(doc_type)")
    if conn.execute("SELECT COUNT(*) FROM doc_types").fetchone()[0] == 0:
        conn.executemany("INSERT INTO doc_types (code, name, sort, active) VALUES (?, ?, ?, 1)",
                         [(c, n, k) for k, (c, n) in enumerate(DOC_TYPE_DEFAULTS, start=1)])


_MIGRATIONS = {1: _MIGRATION_1, 2: _migration_2, 3: _migration_3, 4: _migration_4, 5: _migration_5,
               6: _migration_6, 7: _migration_7, 8: _migration_8}
# 같은 부모 아래 폴더 차례 — 차례(sort) 있는 것 먼저, 그 뒤 이름순 (이주 5)
FOLDER_ORDER = "(CASE WHEN sort > 0 THEN 0 ELSE 1 END), sort, name_key, id"
LEVEL_NAMES = ("대분류", "중분류", "소분류")      # 깊이 1·2·3의 이름, 그 아래는 '하위 폴더' (f6)


def level_name(depth: int) -> str:
    """폴더 깊이(맨 위 = 1) → 층 이름."""
    return LEVEL_NAMES[depth - 1] if 1 <= depth <= len(LEVEL_NAMES) else "하위 폴더"


COMPARE_CACHE_MAX = 2000           # 캐시 행 상한 — 넘으면 오래된 것부터 버린다


# ── 정기 검토 기한 (F7) ────────────────────────────────────────────────────

def add_months(d: date, months: int) -> date:
    """날짜 + N개월. 그 달에 같은 날이 없으면 그 달 마지막 날 — 1/31 + 1개월 = 2/28(윤년 2/29), 3/31 + 1개월 = 4/30."""
    y, m = divmod(d.month - 1 + int(months), 12)
    year, month = d.year + y, m + 1
    return date(year, month, min(d.day, calendar.monthrange(year, month)[1]))


def day_of(text) -> date | None:
    """'2026-10-29T14:03:22' → date. 비었거나 깨졌으면 None."""
    s = str(text or "")[:10]
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def is_hangul(ch: str) -> bool:
    """한글 음절(가-힣)인가 — 자모 낱자(ㄱ·ㅏ)는 아니다 (F7 문서 종류, 2026-10-29)."""
    return "가" <= ch <= "힣"


def _code_text(code) -> str:
    """번호 머리·종류 기호 고르기 — 전각 접기(NFKC) + 대문자. 한글 음절은 대문자로 바꿔도 그대로다."""
    return unicodedata.normalize("NFKC", str(code or "")).strip().upper()


def _check_code(v: str, what: str, example: str) -> str:
    if not FOLDER_CODE_RE.fullmatch(v):
        raise InvalidInput(f"{what}는 영문·숫자·한글 1~8자로 적어 주세요 — 가운데에 '.'를 넣을 수 있습니다 (예: {example})")
    if v == GLOBAL_PREFIX:
        raise InvalidInput(f"'{GLOBAL_PREFIX}'는 머리 없는 양식의 번호(F-0001…)에 쓰는 글자라 {what}로 쓸 수 없습니다 "
                           f"— 다른 글자(예: FM, FO)를 적어 주세요")
    return v


def clean_folder_code(code) -> str:
    """폴더 번호 머리 — 영문 대문자·숫자·한글 1~8자(가운데 '.' 가능 — 7.5). 소문자는 대문자로(전각도 접는다), 빈 값 = 없음."""
    v = _code_text(code)
    return _check_code(v, "번호 머리", "QA, HR, 01, 7.5, 품질") if v else v


def clean_type_code(code) -> str:
    """문서 종류 기호 — 번호 머리와 같은 규칙(영문·숫자·한글 1~8자, 가운데 '.', 'F' 아님). 빈 값은 받지 않는다."""
    v = _code_text(code)
    if not v:
        raise InvalidInput("종류 기호를 적어 주세요 (예: QP)")
    return _check_code(v, "종류 기호", "QP, QF, 절차")


def clean_type_name(name) -> str:
    """문서 종류 이름 — 1~40자, 제어 글자 없음."""
    return _plain_text(name, "종류 이름", MAX_DOC_TYPE_NAME, required=True)


def _natural(s: str) -> tuple:
    """글자 자연 정렬 — 숫자 덩어리는 수로 ('7.5' < '7.10'). 짝수 자리는 글자, 홀수 자리는 수라 서로 비교된다."""
    parts = re.split(r"([0-9]+)", s)
    return tuple(int(p) if k % 2 else p for k, p in enumerate(parts))


def doc_no_key(no) -> tuple:
    """문서번호 자연 정렬 열쇠 (머리, 숫자 꼬리) — QA-999 다음에 QA-1000 (글자 정렬이면 QA-1000이 앞에 온다).
    머리도 숫자 덩어리를 수로 본다(QP-7.5-001 < QP-7.10-001), 꼬리는 마지막 구분자(- _ .) 뒤 숫자."""
    s = str(no or "")
    m = re.fullmatch(r"(.*[-_.])([0-9]+)", s)
    return (_natural(m.group(1)), int(m.group(2)), s) if m else (_natural(s), -1, s)


def clean_doc_no(value) -> str:
    """문서번호 — 영문 대문자·숫자·한글과 '-'·'.'·'_' (처음과 끝은 영문·숫자·한글), 40자까지. 소문자는 대문자로."""
    v = unicodedata.normalize("NFKC", str(value or "")).strip().upper()
    if not v:
        raise InvalidInput("문서번호를 적어 주세요")
    if len(v) > MAX_DOC_NO or not DOC_NO_RE.fullmatch(v):
        raise InvalidInput(f"문서번호는 영문·숫자·한글과 '-'·'.'·'_'로 {MAX_DOC_NO}자까지 적어 주세요 (예: QA-01-01-001)")
    return v


# ── 문서번호 규칙 (F7 번호 규칙, 2026-10-29) ──────────────────────────────────
# 규칙 = 패턴 글자 한 줄 + 일련 자릿수. 칸: {분류}(조상 폴더 머리 전부를 구분자로 이음) {대}{중}{소}(1·2·3단 폴더 머리)
# {YYYY}{YY}(그 양식이 처음 승인된 해 — 새로 매길 때는 오늘) {번호}(일련, 맨 끝에 정확히 한 번). 그 밖의 글자는 영문 대문자·
# 숫자·한글 음절·'-'·'_'·'.'만. 빈 칸(그 단계 폴더가 없거나 머리가 빔)은 지우고 이웃 구분자가 겹치거나 앞에 남으면 접는다.
# {종류}(양식의 문서 종류 기호, F7 문서 종류 2026-10-29) — 종류가 없는 양식은 빈 폴더 칸처럼 빠진다. 접기는 규칙 글자의
# 구분자끼리만 한다 — 칸 값 안의 '.'(머리 7.5)는 건드리지 않는다.

def parse_docno_pattern(value) -> tuple[str, list]:
    """번호 규칙 글자 → (고른 꼴 글자, [(종류 'lit'|'tok', 값)…]). 소문자는 대문자로(전각도 접는다). 틀리면 InvalidInput."""
    raw = str(value or "")
    v = unicodedata.normalize("NFKC", raw).strip().upper()
    if not v:
        raise InvalidInput("번호 규칙을 적어 주세요 (예: {분류}-{번호})")
    if len(v) > MAX_DOCNO_PATTERN:
        raise InvalidInput(f"번호 규칙이 너무 깁니다 (최대 {MAX_DOCNO_PATTERN}자)")
    parts, pos = [], 0
    for m in re.finditer(r"\{([^{}]*)\}", v):
        if m.start() > pos:
            parts.append(("lit", v[pos:m.start()]))
        name = m.group(1).strip()
        if name not in DOCNO_TOKENS:
            raise InvalidInput(f"모르는 칸 {{{m.group(1)}}} — 쓸 수 있는 칸: "
                               + " ".join("{" + t + "}" for t in DOCNO_TOKENS))
        parts.append(("tok", name))
        pos = m.end()
    if pos < len(v):
        parts.append(("lit", v[pos:]))
    for kind, val in parts:
        if kind != "lit":
            continue
        if "{" in val or "}" in val:
            raise InvalidInput("중괄호 { }는 칸 이름을 감쌀 때만 씁니다 (예: {대})")
        bad = []
        for ch in val:
            if not (ch in DOCNO_SEPS or (ch.isascii() and ch.isalnum()) or is_hangul(ch)) and ch not in bad:
                bad.append(ch)
        if bad:
            raise InvalidInput(f"번호 규칙에 쓸 수 없는 글자가 있습니다: {' '.join(_shown_char(_as_typed(ch, raw)) for ch in bad)} "
                               f"— 칸 밖의 글자는 영문·숫자·한글과 - _ . 만 씁니다")
        if re.search(r"[-_.]{2}", val):
            raise InvalidInput("구분자(- _ .)를 두 개 잇따라 쓸 수 없습니다 (예: QF--{번호} → QF-{번호})")
    seen_tok: list = []
    for kind, val in parts:
        if kind == "tok" and val != "번호":
            if val in seen_tok:
                raise InvalidInput(f"칸 {{{val}}}를 두 번 넣을 수 없습니다 (예: {{{val}}}-{{번호}})")
            seen_tok.append(val)
    nums = sum(1 for kind, val in parts if kind == "tok" and val == "번호")
    if nums == 0:
        raise InvalidInput("일련번호 칸 {번호}가 없습니다 — 맨 끝에 {번호}를 넣어 주세요")
    if nums > 1:
        raise InvalidInput("{번호}는 한 번만 넣을 수 있습니다")
    if parts[-1] != ("tok", "번호"):
        raise InvalidInput("{번호}는 맨 끝에 있어야 합니다 (예: {대}-{YYYY}-{번호})")
    if len(parts) == 1:
        raise InvalidInput("{번호} 앞에 머리(폴더 머리 칸이나 글자)가 있어야 합니다 (예: {분류}-{번호})")
    before = parts[-2]
    if before[0] != "lit" or before[1][-1] not in DOCNO_SEPS:
        raise InvalidInput("{번호} 바로 앞에는 구분자(- _ .)를 넣어 주세요 (예: {대}-{번호}) — 머리와 일련번호가 붙으면 "
                           "다른 머리의 번호와 헷갈립니다")
    for (k1, v1), (k2, v2) in zip(parts, parts[1:]):
        if k1 == "tok" and k2 == "tok":
            raise InvalidInput(f"칸 {{{v1}}}와 {{{v2}}} 사이에 구분자(- _ .)를 넣어 주세요 — 붙이면 다른 머리와 헷갈립니다")
    if not any((k == "tok" and val in DOCNO_IDENT_TOKENS) or (k == "lit" and any(ch.isalnum() for ch in val))
               for k, val in parts[:-1]):
        raise InvalidInput("{번호} 앞에 폴더 머리 칸({분류}·{대}·{중}·{소})이나 {종류}, 영문·숫자·한글 글자가 하나는 있어야 "
                           "합니다 (해·구분자만으로는 어느 문서인지 알 수 없습니다)")
    text = "".join(val if kind == "lit" else "{" + val + "}" for kind, val in parts)
    return text, parts


def _as_typed(ch: str, raw: str) -> str:
    """고른(NFKC·대문자) 글자 → 사람이 적은 글자 — 호환 자모 'ㄱ'이 첫소리 자모(U+1100)로 바뀌어 안내에 낯설게 보이지 않게."""
    for r in raw:
        if r == ch or unicodedata.normalize("NFKC", r).upper() == ch:
            return r
    return ch


def _shown_char(ch: str) -> str:
    """안내에 보일 글자 — 빈칸은 '빈칸', 인쇄되지 않는 글자(폭 없는 빈칸 등)는 U+200B 꼴."""
    if ch == " ":
        return "빈칸"
    if not ch.isprintable() or unicodedata.category(ch) in ("Cf", "Zs", "Zl", "Zp", "Mn", "Me"):
        return f"U+{ord(ch):04X}"
    return ch


def clean_docno_digits(value) -> int:
    """일련번호 자릿수 — 2~6 (넘치면 자릿수가 늘어난다: 999 다음 1000)."""
    try:
        n = int(str(value).strip()) if isinstance(value, str) else int(value)
    except (TypeError, ValueError):
        raise InvalidInput(f"일련번호 자릿수는 {DOCNO_DIGITS_MIN}~{DOCNO_DIGITS_MAX} 숫자로 적어 주세요")
    if not DOCNO_DIGITS_MIN <= n <= DOCNO_DIGITS_MAX:
        raise InvalidInput(f"일련번호 자릿수는 {DOCNO_DIGITS_MIN}~{DOCNO_DIGITS_MAX}로 적어 주세요")
    return n


def _join_sep(parts: list, i: int) -> str:
    """{분류}가 폴더 머리를 이을 구분자 — 규칙에서 그 칸 바로 뒤(없으면 바로 앞) 구분자, 둘 다 없으면 '-'."""
    for j in (i + 1, i - 1):
        if 0 <= j < len(parts) and parts[j][0] == "lit":
            ch = parts[j][1][0] if j == i + 1 else parts[j][1][-1]
            if ch in DOCNO_SEPS:
                return ch
    return "-"


def render_docno_head(parts: list, codes: list, year: int, dtype: str = "") -> str:
    """규칙의 {번호} 앞부분(머리)을 그린다. codes: 맨 위부터 그 폴더까지의 번호 머리(빈 글자 = 없음). dtype: 문서 종류 기호.
    빈 칸은 지우고, 규칙 글자의 구분자가 둘 이상 잇따르면 앞 것 하나로, 맨 앞에 남은 구분자는 뺀다.
    접기는 **규칙 글자(lit) 사이에서만** — 칸 값(머리 7.5, {분류}가 이은 QA.7.5)은 구분자로 시작·끝나지 않고 '..'도 없어
    그대로 둔다 (F7 문서 종류, 2026-10-29)."""
    pieces: list = []                                   # (글자, 규칙 글자인가)
    for i, (kind, val) in enumerate(parts):
        if kind == "tok" and val == "번호":
            break
        if kind == "lit":
            pieces.append((val, True))
        elif val == "분류":
            pieces.append((_join_sep(parts, i).join(c for c in codes if c), False))
        elif val in ("대", "중", "소"):
            k = ("대", "중", "소").index(val)
            pieces.append((codes[k] if k < len(codes) else "", False))
        elif val == "종류":
            pieces.append((str(dtype or ""), False))
        elif val == "YYYY":
            pieces.append((f"{int(year):04d}", False))
        elif val == "YY":
            pieces.append((f"{int(year) % 100:02d}", False))
    out, sep_end = "", False                            # sep_end: 지금 끝이 규칙 글자의 구분자인가
    for text, lit in pieces:
        if not text:
            continue
        if lit and (not out or sep_end):                # 맨 앞, 또는 바로 앞이 규칙 구분자 → 이 글자 앞 구분자를 접는다
            text = text.lstrip(DOCNO_SEPS)
            if not text:
                continue
        out += text
        sep_end = lit and text[-1] in DOCNO_SEPS
    return out


def head_has_identity(parts: list, codes: list, dtype: str = "") -> bool:
    """그린 머리가 문서를 가리키나 — 채워진 폴더 머리 칸·{종류}가 하나라도 있거나 영문·숫자·한글 글자가 있으면 참.
    해·구분자만 남으면(`{대}-{YY}-{번호}`에서 폴더 머리 없음 → '27-') 거짓 → 전역 F-0001 꼴로 (F7 번호 규칙 검토 1)."""
    for kind, val in parts:
        if kind == "tok" and val == "번호":
            break
        if kind == "lit" and any(ch.isalnum() for ch in val):
            return True
        if kind == "tok" and val == "종류" and dtype:
            return True
        if kind == "tok" and val == "분류" and any(codes):
            return True
        if kind == "tok" and val in ("대", "중", "소"):
            k = ("대", "중", "소").index(val)
            if k < len(codes) and codes[k]:
                return True
    return False


def split_doc_no(no: str) -> tuple[str, str]:
    """번호 → (머리, 일련 글자) — 마지막 구분자에서 자른다('QA-01-007' → ('QA-01-', '007')). 구분자가 없으면 ('', 번호)."""
    s = str(no or "")
    i = max(s.rfind(c) for c in DOCNO_SEPS)
    return (s[:i + 1], s[i + 1:]) if i >= 0 else ("", s)


def rule_uses_type(parts: list) -> bool:
    """규칙에 {종류} 칸이 있나."""
    return ("tok", "종류") in parts


def counter_key(head: str) -> str:
    """doc_counters 열쇠 — 머리 끝 구분자를 뗀 것('QA-01-01-' → 'QA-01-01', 'F-' → 'F'). 지금까지의 열쇠와 같다."""
    return head.rstrip(DOCNO_SEPS) or head


class FormsStore:
    """forms.db 연결 하나 + 보관소 쓰기 문(Guard). 여러 스레드가 같이 써도 되게 내부 잠금을 쥔다.

    data_dir: Drev 데이터 폴더(있어야 한다). mirror_root: (선택) 현행 미러 뿌리 — Guard의 두 번째 허용 뿌리.
    clock: 세션·잠금 시각 함수(시험에서 바꿔 끼운다)."""

    def __init__(self, data_dir, *, mirror_root=None, clock=time.time):
        self.data_dir = Path(data_dir)
        if not self.data_dir.is_dir():
            raise FormsError(f"Drev 데이터 폴더가 없습니다: {self.data_dir}")
        self.db_path = self.data_dir / DB_NAME
        self.store_root = self.data_dir / STORE_DIR
        self.mirror_root = Path(mirror_root) if mirror_root else None
        roots = [self.store_root] + ([self.mirror_root] if self.mirror_root else [])
        self.guard = Guard(roots, create=[self.store_root])
        self.clock = clock
        self.max_upload_bytes = MAX_UPLOAD_BYTES
        self.audit_max_rows = AUDIT_MAX_ROWS            # 감사 기록 보존 상한 (서버가 설정값으로 바꾼다)
        self.review_months_default = REVIEW_MONTHS_DEFAULT   # 정기 검토 기본 주기(개월, 0 = 끔) — 서버가 설정값으로 (F7)
        self._lock = threading.RLock()
        self._depth = 0
        raw = sqlite3.connect(self.db_path, timeout=15, isolation_level=None, check_same_thread=False)
        raw.row_factory = sqlite3.Row
        raw.create_function("drev_fold", 1, search_fields_key, deterministic=True)   # 찾기 — 접은 글자로 SQL 안에서 (2026-10-30)
        self.conn = _LockedConn(raw, self._lock)
        try:
            self.conn.execute("PRAGMA busy_timeout=15000")
            self._set_wal()
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
            self._migrate()
        except BaseException:
            try:
                self.conn.close()
            except Exception:
                pass
            raise

    # ── 연결·트랜잭션·이주 ───────────────────────────────────────────────

    def _set_wal(self) -> None:
        """WAL 전환 — 새 DB를 여러 연결이 동시에 열면 전환이 바쁨 처리기 없이 'locked'로 바로 실패한다
        (시험 실측: 6개 동시 열기 중 5개). 잠깐씩 기다리며 다시 해 본다."""
        deadline = time.monotonic() + 15
        while True:
            try:
                self.conn.execute("PRAGMA journal_mode=WAL")
                return
            except sqlite3.OperationalError as e:
                if "locked" not in str(e).lower() and "busy" not in str(e).lower():
                    raise
                if time.monotonic() > deadline:
                    raise
                time.sleep(0.05)

    def close(self) -> None:
        with self._lock:
            self.conn.close()

    def __enter__(self) -> "FormsStore":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    @contextlib.contextmanager
    def tx(self):
        """쓰기 트랜잭션 — 쓰기 잠금을 먼저 잡고(BEGIN IMMEDIATE) 읽는다. 다른 연결과 겹치지 않는다.
        같은 스레드에서 겹쳐 부르면 바깥 트랜잭션에 합쳐진다."""
        with self._lock:
            if self._depth:
                self._depth += 1
                try:
                    yield self.conn
                finally:
                    self._depth -= 1
                return
            self.conn.execute("BEGIN IMMEDIATE")
            self._depth = 1
            try:
                yield self.conn
            except BaseException:
                self._depth = 0
                if self.conn.in_transaction:
                    self.conn.execute("ROLLBACK")
                raise
            else:
                self._depth = 0
                self.conn.execute("COMMIT")

    def schema_version(self) -> int:
        try:
            row = self.conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        except sqlite3.OperationalError:
            return 0
        return int(row[0]) if row else 0

    def _migrate(self) -> None:
        """스키마 버전을 meta에 적고 모자란 이주만 차례로 돌린다. 여러 번·동시에 돌려도 안전하다."""
        with self.tx() as c:
            c.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            v = self.schema_version()
            if v > SCHEMA_VERSION:
                raise FormsError(f"더 새 판 Drev가 만든 forms.db입니다 (스키마 {v}, 이 판은 {SCHEMA_VERSION})")
            for target in range(v + 1, SCHEMA_VERSION + 1):
                step = _MIGRATIONS[target]
                if callable(step):
                    step(c)
                else:
                    for stmt in step:
                        c.execute(stmt)
                c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('schema_version', ?)",
                          (str(target),))
            if SCHEMA_VERSION >= 6:
                _ensure_doc_no_index(c)          # 첫 F7 꼴 색인으로 이미 6이 된 DB도 고친다 (값싼 확인 한 번)

    # ── 사람·권한 ─────────────────────────────────────────────────────────

    def get_user(self, user_id) -> dict | None:
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return _user_dict(row) if row else None

    def _actor(self, actor_id) -> sqlite3.Row:
        """요청한 사람 — 없거나 정지됐으면 거부. 역할은 매번 DB에서 새로 읽는다."""
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (actor_id,)).fetchone()
        if row is None or row["disabled"]:
            raise PermissionDenied("로그인한 계정을 쓸 수 없습니다")
        return row

    def _require_admin(self, actor: sqlite3.Row) -> None:
        if actor["role"] != "admin":
            raise PermissionDenied("관리자만 할 수 있습니다")

    def _ancestors(self, folder_id) -> list[int]:
        """폴더 자신부터 맨 위까지의 id 목록."""
        rows = self.conn.execute(
            "WITH RECURSIVE up(id, parent_id, depth) AS ("
            " SELECT id, parent_id, 0 FROM folders WHERE id = ?"
            " UNION ALL SELECT f.id, f.parent_id, up.depth + 1 FROM folders f JOIN up ON f.id = up.parent_id"
            " WHERE up.depth < 64) SELECT id FROM up ORDER BY depth", (folder_id,)).fetchall()
        return [r[0] for r in rows]

    def is_reviewer_of(self, actor_id, folder_id) -> bool:
        """그 폴더를 검토할 수 있나 — 관리자, 또는 그 폴더나 위 폴더에 지정된 검토자."""
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (actor_id,)).fetchone()
        return bool(row) and not row["disabled"] and self._can_review(row, folder_id)

    def _can_review(self, actor: sqlite3.Row, folder_id) -> bool:
        if actor["role"] == "admin":
            return True
        if actor["role"] != "reviewer" or folder_id is None:
            return False
        ids = self._ancestors(folder_id)
        if not ids:
            return False
        marks = ",".join("?" * len(ids))
        return self.conn.execute(
            f"SELECT 1 FROM folder_reviewers WHERE user_id = ? AND folder_id IN ({marks}) LIMIT 1",
            (actor["id"], *ids)).fetchone() is not None

    def _require_reviewer(self, actor: sqlite3.Row, folder_id) -> None:
        if not self._can_review(actor, folder_id):
            raise PermissionDenied("이 폴더의 검토자만 할 수 있습니다")

    # ── 감사 기록 ─────────────────────────────────────────────────────────

    def _audit(self, actor, action: str, target="", ip=None, detail="") -> None:
        """트랜잭션 안에서 부른다 — 바뀐 일과 기록이 함께 남거나 함께 사라진다."""
        uid = actor["id"] if actor is not None else None
        login = actor["login"] if actor is not None else ""
        cur = self.conn.execute(
            "INSERT INTO audit (at, user_id, login, action, target, ip, detail) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (now_text(self.clock()), uid, login, str(action), str(target or ""), str(ip or ""),
             str(detail or "")[:2000]))
        self._audit_trim(cur.lastrowid)

    def _audit_trim(self, last_id) -> None:
        """보존 상한(audit_max_rows)을 넘은 오래된 기록을 지운다 (보안 F1 — 비인증 요청이 감사 표를 끝없이 키우지 못하게).
        id는 늘기만 하므로 '마지막 id - 상한' 이하를 지우면 된다(색인 범위 지우기, 매번 싸다)."""
        cap = max(100, int(self.audit_max_rows or AUDIT_MAX_ROWS))
        if last_id is not None and int(last_id) > cap:
            self.conn.execute("DELETE FROM audit WHERE id <= ?", (int(last_id) - cap,))

    def audit_grouped(self, action: str, *, ip, user_id=None, login: str = "", target: str = "",
                      what: str = "실패", window: float = GROUP_SECONDS, item: str | None = None,
                      item_label: str = "시도한 아이디") -> None:
        """같은 주소·같은 일·같은 계정(없는 아이디는 '없음' 하나로)의 연달은 기록을 한 줄로 묶는다 (보안 F1).

        묶은 줄: 첫 때(at)·마지막 때(last_at)·횟수(cnt)·시도한 아이디(extra, 앞의 GROUP_MAX_LOGINS개 + 나머지 개수).
        창(window초)은 그 줄의 **첫 때**부터 잰다 — 한 줄이 1분 넘게 늘어나지 않아 시간 증거가 흐려지지 않는다.
        트랜잭션 안·밖 어디서 불러도 된다. item·item_label: 모아 적을 것과 그 이름(기본은 시도한 아이디 — 거부된 요청은
        '거부된 주소'로 경로를 모은다, 2026-10-30 L4)."""
        now = float(self.clock())
        ip_s, shown = str(ip or ""), str(login or "")[:64]
        piece = shown if item is None else str(item)[:120]
        with self.tx():
            if user_id is not None:
                row = self.conn.execute(
                    "SELECT id, at, cnt, extra FROM audit WHERE action = ? AND ip = ? AND user_id = ? "
                    "ORDER BY id DESC LIMIT 1", (str(action), ip_s, user_id)).fetchone()
            else:
                row = self.conn.execute(
                    "SELECT id, at, cnt, extra FROM audit WHERE action = ? AND ip = ? AND user_id IS NULL "
                    "ORDER BY id DESC LIMIT 1", (str(action), ip_s)).fetchone()
            first = None
            if row is not None:
                try:
                    first = datetime.fromisoformat(row["at"]).timestamp()
                except (TypeError, ValueError):
                    first = None
            tried: dict = {}
            if row is not None:
                try:
                    tried = json.loads(row["extra"] or "{}")
                except ValueError:
                    tried = {}
                if not isinstance(tried, dict):
                    tried = {}
            # 까닭(what)이 다른 기록은 묶지 않는다 — 'CSRF 틀림'과 '권한 없음'이 한 줄이 되지 않게 (2026-10-30 검토)
            same_what = str(tried.get("what", what)) == str(what)
            if row is not None and first is not None and 0 <= now - first < float(window) and same_what:
                names, more = [str(x) for x in (tried.get("logins") or [])], int(tried.get("more") or 0)
                if piece not in names:
                    if len(names) < GROUP_MAX_LOGINS:
                        names.append(piece)
                    else:
                        more += 1
                n = int(row["cnt"] or 1) + 1
                self.conn.execute(
                    "UPDATE audit SET cnt = ?, last_at = ?, extra = ?, detail = ? WHERE id = ?",
                    (n, now_text(now), json.dumps({"logins": names, "more": more, "what": what}, ensure_ascii=False),
                     _group_detail(what, n, row["at"], now_text(now), names, more, item_label), row["id"]))
                return
            names = [piece]
            cur = self.conn.execute(
                "INSERT INTO audit (at, user_id, login, action, target, ip, detail, cnt, last_at, extra) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)",
                (now_text(now), user_id, shown, str(action), str(target or ""), ip_s,
                 _group_detail(what, 1, now_text(now), now_text(now), names, 0, item_label), now_text(now),
                 json.dumps({"logins": names, "more": 0, "what": what}, ensure_ascii=False)))
            self._audit_trim(cur.lastrowid)

    def audit_info(self, actor_id) -> dict:
        """감사 기록 보존 안내 — 관리자만. {count, oldest_at, max_rows}."""
        actor = self._actor(actor_id)
        self._require_admin(actor)
        row = self.conn.execute("SELECT COUNT(*), MIN(at) FROM audit").fetchone()
        return {"count": int(row[0] or 0), "oldest_at": row[1], "max_rows": int(self.audit_max_rows)}

    def record_audit(self, actor_id, action: str, target="", *, ip=None, detail="", login="") -> None:
        """서버가 남기는 기록(로그인 실패 등). actor_id가 없으면 login 글자만 남긴다."""
        with self.tx():
            actor = self.conn.execute("SELECT * FROM users WHERE id = ?", (actor_id,)).fetchone() \
                if actor_id is not None else None
            if actor is None:
                cur = self.conn.execute(
                    "INSERT INTO audit (at, user_id, login, action, target, ip, detail) VALUES (?, NULL, ?, ?, ?, ?, ?)",
                    (now_text(self.clock()), str(login or ""), str(action), str(target or ""),
                     str(ip or ""), str(detail or "")[:2000]))
                self._audit_trim(cur.lastrowid)
            else:
                self._audit(actor, action, target, ip, detail)

    def audit_log(self, actor_id, *, limit: int = 200, offset: int = 0, action=None,
                  user_id=None) -> list[dict]:
        """감사 기록 조회 — 관리자만. 최근 것부터."""
        actor = self._actor(actor_id)
        self._require_admin(actor)
        sql, args = "SELECT * FROM audit WHERE 1 = 1", []
        if action:
            sql += " AND action = ?"
            args.append(action)
        if user_id is not None:
            sql += " AND user_id = ?"
            args.append(user_id)
        sql += " ORDER BY id DESC LIMIT ? OFFSET ?"
        args += [max(1, min(int(limit), 5000)), max(0, int(offset))]
        return [dict(r) for r in self.conn.execute(sql, args)]

    # ── 폴더 ─────────────────────────────────────────────────────────────

    def _folder(self, folder_id) -> sqlite3.Row:
        row = self.conn.execute("SELECT * FROM folders WHERE id = ?", (folder_id,)).fetchone()
        if row is None:
            raise NotFound("없는 폴더입니다")
        return row

    @staticmethod
    def _folder_name(name) -> str:
        v = _plain_text(name, "폴더 이름", 80, required=True)
        try:
            check_name(v)          # 현행 미러에 그대로 폴더로 만들어지므로 파일 이름 규칙을 따른다
        except GuardError as e:
            raise InvalidInput(f"폴더 이름으로 쓸 수 없습니다 — {e}")
        return v

    def create_folder(self, actor_id, parent_id, name, *, ip=None) -> int:
        """폴더 만들기. 맨 위는 관리자만, 하위는 관리자나 그 폴더 검토자. 같은 부모 아래 이름(접어 비교) 중복 금지."""
        v = self._folder_name(name)
        with self.tx():
            actor = self._actor(actor_id)
            if parent_id is None:
                self._require_admin(actor)
            else:
                self._folder(parent_id)
                self._require_reviewer(actor, parent_id)
            self._folder_name_free(parent_id, v)
            cur = self.conn.execute(
                "INSERT INTO folders (parent_id, name, name_key, created_by, created_at) VALUES (?, ?, ?, ?, ?)",
                (parent_id, v, name_key(v), actor["id"], now_text(self.clock())))
            fid = cur.lastrowid
            self._audit(actor, "folder_create", f"folder:{fid}", ip, v)
            return fid

    def _folder_name_free(self, parent_id, name, except_id=None) -> None:
        row = self.conn.execute(
            "SELECT id FROM folders WHERE IFNULL(parent_id, 0) = IFNULL(?, 0) AND name_key = ?",
            (parent_id, name_key(name))).fetchone()
        if row is not None and row[0] != except_id:
            raise Conflict("같은 이름의 폴더가 이미 있습니다")

    def rename_folder(self, actor_id, folder_id, new_name, *, ip=None) -> None:
        v = self._folder_name(new_name)
        with self.tx():
            actor = self._actor(actor_id)
            f = self._folder(folder_id)
            self._require_reviewer(actor, folder_id)
            self._folder_name_free(f["parent_id"], v, except_id=folder_id)
            self.conn.execute("UPDATE folders SET name = ?, name_key = ? WHERE id = ?",
                              (v, name_key(v), folder_id))
            self._audit(actor, "folder_rename", f"folder:{folder_id}", ip, f"{f['name']} → {v}")

    def _sibling_with_code(self, parent_id, code: str, except_id=None) -> str | None:
        """같은 부모 아래에서 그 머리를 이미 쓰는 다른 폴더의 이름 — 없거나 머리가 비면 None (F7 검토 4)."""
        if not code:
            return None
        row = self.conn.execute(
            "SELECT name FROM folders WHERE IFNULL(parent_id, 0) = IFNULL(?, 0) AND code = ? AND id != IFNULL(?, -1) "
            "LIMIT 1", (parent_id, code, except_id)).fetchone()
        return row[0] if row else None

    def set_folder_code(self, actor_id, folder_id, code, *, ip=None) -> str:
        """폴더 번호 머리(문서번호 앞부분) 정하기·고치기·지우기(빈 값) — 권한은 이름 바꾸기와 같다(관리자나 그 폴더 검토자).
        이미 매긴 문서번호는 바뀌지 않는다 — 다음에 처음 승인되는 양식부터 새 머리를 쓴다 (F7). 돌려줌: 정한 머리."""
        v = clean_folder_code(code)
        with self.tx():
            actor = self._actor(actor_id)
            f = self._folder(folder_id)
            self._require_reviewer(actor, folder_id)
            old = f["code"] or ""
            if old == v:
                return v
            twin = self._sibling_with_code(f["parent_id"], v, folder_id)
            if twin is not None:
                raise Conflict(f"같은 위 폴더 아래 '{twin}' 폴더가 이미 번호 머리 {v}을(를) 씁니다 — 다른 머리를 적어 주세요")
            self.conn.execute("UPDATE folders SET code = ? WHERE id = ?", (v, folder_id))
            self._audit(actor, "folder_code", f"folder:{folder_id}", ip,
                        f"{f['name']}: {old or '(없음)'} → {v or '(없음)'}")
            return v

    def list_folders(self, actor_id, parent_id=None) -> list[dict]:
        """한 단계 아래 폴더들 (차례 있는 것 먼저, 그 뒤 이름순 — 이주 5)."""
        self._actor(actor_id)
        rows = self.conn.execute(
            f"SELECT * FROM folders WHERE IFNULL(parent_id, 0) = IFNULL(?, 0) ORDER BY {FOLDER_ORDER}",
            (parent_id,)).fetchall()
        return [_folder_dict(r) for r in rows]

    def folder_tree(self, actor_id) -> list[dict]:
        """폴더 전체를 중첩 목록으로: [{id, name, parent_id, children: [...]}, ...]."""
        self._actor(actor_id)
        rows = self.conn.execute(f"SELECT * FROM folders ORDER BY {FOLDER_ORDER}").fetchall()
        nodes = {r["id"]: dict(_folder_dict(r), children=[]) for r in rows}
        top = []
        for r in rows:
            node = nodes[r["id"]]
            parent = nodes.get(r["parent_id"]) if r["parent_id"] is not None else None
            (parent["children"] if parent is not None else top).append(node)
        return top

    def folder_path(self, actor_id, folder_id) -> list[dict]:
        """맨 위부터 그 폴더까지 [{id, name}, ...] — 화면의 경로 표시용."""
        self._actor(actor_id)
        self._folder(folder_id)
        ids = list(reversed(self._ancestors(folder_id)))
        out = []
        for i in ids:
            r = self._folder(i)
            out.append({"id": r["id"], "name": r["name"]})
        return out

    # ── 폴더 관리: 깊이·옮기기·지우기·차례·기본 분류 틀 (f6, 2026-10-29) ──────────────

    def folder_depth(self, folder_id) -> int:
        """맨 위 폴더 = 1."""
        return len(self._ancestors(folder_id))

    def _descendants(self, folder_id) -> list[int]:
        """폴더 자신과 그 아래 모든 폴더의 id."""
        rows = self.conn.execute(
            "WITH RECURSIVE down(id, depth) AS (SELECT id, 0 FROM folders WHERE id = ?"
            " UNION ALL SELECT f.id, down.depth + 1 FROM folders f JOIN down ON f.parent_id = down.id"
            " WHERE down.depth < 64) SELECT id FROM down", (folder_id,)).fetchall()
        return [r[0] for r in rows]

    def _path_text(self, folder_id) -> str:
        return " / ".join(self._path_names(self._folder_names(), folder_id)) if folder_id is not None else "(맨 위)"

    def can_manage_child_of(self, actor_id, parent_id) -> bool:
        """그 부모 아래 폴더를 다룰 수 있나(만들기·지우기·차례) — 맨 위(None)는 관리자만, 하위는 관리자나 부모 검토자."""
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (actor_id,)).fetchone()
        if row is None or row["disabled"]:
            return False
        if parent_id is None:
            return row["role"] == "admin"
        return self._can_review(row, parent_id)

    def reviewable_folders(self, actor_id) -> set | None:
        """검토할 수 있는 폴더 id 모음 — 관리자는 None(전부). 지정된 폴더와 그 아래 전부. 질의 둘(폴더마다 묻지 않는다)."""
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (actor_id,)).fetchone()
        if row is None or row["disabled"]:
            return set()
        if row["role"] == "admin":
            return None
        if row["role"] != "reviewer":
            return set()
        roots = {r[0] for r in self.conn.execute("SELECT folder_id FROM folder_reviewers WHERE user_id = ?",
                                                 (actor_id,))}
        kids: dict = {}
        for fid, parent in self.conn.execute("SELECT id, parent_id FROM folders"):
            kids.setdefault(parent, []).append(fid)
        out, todo = set(), list(roots)
        while todo:
            x = todo.pop()
            if x in out:
                continue
            out.add(x)
            todo.extend(kids.get(x, []))
        return out

    def _require_manage_child(self, actor: sqlite3.Row, parent_id) -> None:
        if parent_id is None:
            self._require_admin(actor)
        else:
            self._require_reviewer(actor, parent_id)

    def move_folder(self, actor_id, folder_id, new_parent_id, *, ip=None) -> None:
        """폴더를 다른 부모(None = 맨 위) 아래로. 권한: 관리자, 또는 원래 부모와 새 부모 둘 다의 검토자
        (맨 위로·맨 위에서는 관리자만). 자기 자신·자기 하위로는 못 옮기고, 같은 이름이 있으면 거부.
        옮긴 폴더는 새 부모 아래에서 이름순(차례 0). 검토자 지정·구독은 폴더에 붙어 있어 그대로 따라간다."""
        with self.tx():
            actor = self._actor(actor_id)
            f = self._folder(folder_id)
            old_parent = f["parent_id"]
            if new_parent_id is not None:
                self._folder(new_parent_id)
            if (old_parent or 0) == (new_parent_id or 0):
                raise Conflict("이미 그 폴더 아래에 있습니다")
            self._require_manage_child(actor, old_parent)
            self._require_manage_child(actor, new_parent_id)
            if new_parent_id is not None and int(new_parent_id) in self._descendants(folder_id):
                raise InvalidInput("폴더를 자기 자신이나 자기 하위 폴더 안으로 옮길 수 없습니다")
            self._folder_name_free(new_parent_id, f["name"], except_id=folder_id)
            before = self._path_text(folder_id)
            self.conn.execute("UPDATE folders SET parent_id = ?, sort = 0 WHERE id = ?", (new_parent_id, folder_id))
            self._audit(actor, "folder_move", f"folder:{folder_id}", ip, f"{before} → {self._path_text(folder_id)}")

    def folder_contents(self, folder_id) -> dict:
        """지우기 전에 남은 것 세기 — {children, forms, retired, pending}."""
        one = lambda sql: int(self.conn.execute(sql, (folder_id,)).fetchone()[0] or 0)   # noqa: E731
        return {"children": one("SELECT COUNT(*) FROM folders WHERE parent_id = ?"),
                "forms": one("SELECT COUNT(*) FROM forms WHERE folder_id = ? AND retired = 0"),
                "retired": one("SELECT COUNT(*) FROM forms WHERE folder_id = ? AND retired = 1"),
                "pending": one("SELECT COUNT(*) FROM submissions WHERE folder_id = ? AND status = 'pending'")}

    @staticmethod
    def not_empty_text(c: dict) -> str:
        """비어 있지 않은 폴더 — 무엇이 남았는지 쉬운 말로."""
        bits = []
        if c["forms"]:
            bits.append(f"양식 {c['forms']}개")
        if c["retired"]:
            bits.append(f"폐기된 양식 {c['retired']}개")
        if c["pending"]:
            bits.append(f"검토 대기 {c['pending']}건")
        if c["children"]:
            bits.append(f"하위 폴더 {c['children']}개")
        def josa(word: str, pair: tuple) -> str:          # '개'는 받침 없음, '건'은 받침 있음
            return pair[1] if word.endswith("건") else pair[0]
        if len(bits) > 1:
            head = ", ".join(bits[:-1])
            what = f"{head}{josa(head, ('와', '과'))} {bits[-1]}"
        else:
            what = bits[0] if bits else "남은 것"
        what += josa(what, ("가", "이"))
        hint = "먼저 옮기거나 폐기하세요"
        if c["retired"] and not (c["forms"] or c["pending"] or c["children"]):
            hint = "폐기된 양식은 기록으로 남아 지우지 않습니다 — 이 폴더를 다른 폴더 아래로 옮겨 두세요"
        elif c["pending"]:
            hint = "검토 대기를 먼저 승인·반려하고, 양식·하위 폴더는 옮기거나 폐기하세요"
        return f"{what} 있어 지울 수 없습니다 — {hint}"

    def delete_folder(self, actor_id, folder_id, *, ip=None) -> str:
        """빈 폴더 지우기 — 하위 폴더·양식(폐기 포함)·검토 대기 제출이 하나도 없을 때만. 권한: 관리자, 또는 부모 폴더 검토자
        (맨 위 폴더는 관리자만). 그 폴더의 검토자 지정·구독 행도 지운다. 끝난(반려·취소) 제출 기록이 이 폴더를 가리키면
        위 폴더로 옮겨 적는다(기록은 남긴다) — 맨 위 폴더면 지우지 않는다. 돌려줌: 지운 폴더의 경로 글."""
        with self.tx():
            actor = self._actor(actor_id)
            f = self._folder(folder_id)
            self._require_manage_child(actor, f["parent_id"])
            c = self.folder_contents(folder_id)
            if any(c.values()):
                raise Conflict(self.not_empty_text(c))
            closed = int(self.conn.execute("SELECT COUNT(*) FROM submissions WHERE folder_id = ?",
                                           (folder_id,)).fetchone()[0] or 0)
            if closed and f["parent_id"] is None:
                raise Conflict(f"이 폴더에 반려·취소된 제출 기록 {closed}건이 남아 있어 맨 위 폴더는 지울 수 없습니다 "
                               f"— 다른 폴더 아래로 옮긴 뒤 지우세요")
            path = self._path_text(folder_id)
            if closed:
                self.conn.execute("UPDATE submissions SET folder_id = ? WHERE folder_id = ?", (f["parent_id"], folder_id))
            self.conn.execute("DELETE FROM folder_reviewers WHERE folder_id = ?", (folder_id,))
            self.conn.execute("DELETE FROM subscriptions WHERE folder_id = ?", (folder_id,))
            self.conn.execute("DELETE FROM folders WHERE id = ?", (folder_id,))
            self._audit(actor, "folder_delete", f"folder:{folder_id}", ip,
                        path + (f" (끝난 제출 기록 {closed}건은 위 폴더로)" if closed else ""))
            return path

    def move_folder_order(self, actor_id, folder_id, step: int, *, ip=None) -> bool:
        """같은 부모 아래 차례에서 한 칸 위(-1)·아래(+1)로. 권한은 만들기와 같다(맨 위는 관리자, 하위는 부모 검토자).
        형제 모두에게 지금 보이는 차례대로 1, 2, 3…을 다시 매긴 뒤 둘을 바꾼다. 끝에 있어 못 움직이면 False."""
        step = -1 if int(step) < 0 else 1
        with self.tx():
            actor = self._actor(actor_id)
            f = self._folder(folder_id)
            self._require_manage_child(actor, f["parent_id"])
            ids = [r[0] for r in self.conn.execute(
                f"SELECT id FROM folders WHERE IFNULL(parent_id, 0) = IFNULL(?, 0) ORDER BY {FOLDER_ORDER}",
                (f["parent_id"],)).fetchall()]
            i = ids.index(folder_id)
            j = i + step
            if not 0 <= j < len(ids):
                return False
            ids[i], ids[j] = ids[j], ids[i]
            self.conn.executemany("UPDATE folders SET sort = ? WHERE id = ?", [(k + 1, x) for k, x in enumerate(ids)])
            self._audit(actor, "folder_order", f"folder:{folder_id}", ip,
                        f"{f['name']} {'위로' if step < 0 else '아래로'}")
            return True

    def apply_template(self, actor_id, tree, *, ip=None, codes=None) -> dict:
        """기본 분류 틀 만들기 — 관리자만, 한 트랜잭션. tree: [(이름, [하위 tree…]), …] (watcher/forms/catalog.py 꼴).
        **없는 폴더만** 만든다: 같은 부모 아래 같은 이름(접어 비교)이 있으면 그대로 두고 그 아래로 이어 간다 — 몇 번 눌러도
        같은 결과. 새로 만든 폴더에는 틀의 차례(형제 안 1, 2, 3…)를 넣는다. 돌려줌 {created, skipped}.
        codes: (F7) {대분류 이름: 번호 머리} — 주면 대분류는 그 머리, 중분류·소분류 아래는 틀 안 차례 두 자리(01, 02…)를
        번호 머리(code)로 넣는다. 이미 있던 폴더는 머리가 비어 있을 때만 채운다(사람이 정한 머리는 그대로)."""
        top_codes = dict(codes or {})
        by_code: list = []          # 이름은 달라도 번호 머리로 찾아 이어 간 폴더 (이름을 바꾼 대분류 — 2026-10-30)
        code_taken: list = []       # 머리가 다른 형제에게 이미 있어 비워 둔 폴더
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            made, kept = 0, 0
            when = now_text(self.clock())

            def walk(parent_id, nodes, depth):
                nonlocal made, kept
                for k, (name, kids) in enumerate(nodes, start=1):
                    v = self._folder_name(name)
                    code = ""
                    if codes is not None:
                        code = clean_folder_code(top_codes.get(name, "") if depth == 0 else f"{k:02d}")
                    row = self.conn.execute(
                        "SELECT id FROM folders WHERE IFNULL(parent_id, 0) = IFNULL(?, 0) AND name_key = ?",
                        (parent_id, name_key(v))).fetchone()
                    if row is None and code and depth == 0:
                        # 같은 이름이 없으면 같은 머리의 대분류를 찾는다 — 대분류 이름을 바꾼 뒤 다시 눌러도 겹쳐 만들지 않게.
                        # 중분류 아래 머리(01·02…)는 사람이 만든 다른 폴더와 겹치기 쉬워 이름으로만 찾는다
                        twin = self.conn.execute(
                            "SELECT id, name FROM folders WHERE IFNULL(parent_id, 0) = IFNULL(?, 0) AND code = ? LIMIT 1",
                            (parent_id, code)).fetchone()
                        if twin is not None:
                            row = twin
                            by_code.append(f"{twin['name']}({code}) ← 틀 이름 {v}")
                    # 같은 부모 아래 다른 폴더가 이미 그 머리를 쓰면 비워 둔다 (형제 머리 겹침 금지, F7 검토 4)
                    if code and self._sibling_with_code(parent_id, code, row[0] if row is not None else None):
                        code_taken.append(f"{v}({code})")
                        code = ""
                    if row is not None:
                        fid = row[0]
                        kept += 1
                        # 이름순(차례 0)이던 같은 이름 폴더는 틀의 차례를 받는다 — 이름·내용은 그대로, 보이는 차례만
                        self.conn.execute("UPDATE folders SET sort = ? WHERE id = ? AND sort = 0", (k, fid))
                        if code:
                            self.conn.execute("UPDATE folders SET code = ? WHERE id = ? AND code = ''", (code, fid))
                    else:
                        fid = self.conn.execute(
                            "INSERT INTO folders (parent_id, name, name_key, created_by, created_at, sort, code) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (parent_id, v, name_key(v), actor["id"], when, k, code)).lastrowid
                        made += 1
                    walk(fid, kids or [], depth + 1)
            walk(None, list(tree or []), 0)
            self._audit(actor, "folder_template", "folders", ip, f"만든 폴더 {made}개 · 이미 있어 그대로 {kept}개"
                        + (f" · 번호 머리로 찾음 {len(by_code)}개" if by_code else "")
                        + (f" · 머리가 겹쳐 비워 둠 {len(code_taken)}개" if code_taken else ""))
            return {"created": made, "skipped": kept, "by_code": by_code, "code_taken": code_taken}

    def folder_overview(self, actor_id) -> dict:
        """관리 화면 한 번에 — {forms: {폴더: (현행, 폐기)}, pending: {폴더: 수}, reviewers: {폴더: [사용자…]}}.
        폴더 수백 개여도 질의 셋 (폴더마다 묻지 않는다)."""
        self._actor(actor_id)
        forms: dict = {}
        for fid, retired, n in self.conn.execute(
                "SELECT folder_id, retired, COUNT(*) FROM forms GROUP BY folder_id, retired"):
            cur = forms.setdefault(fid, [0, 0])
            cur[1 if retired else 0] = int(n)
        pending = {r[0]: int(r[1]) for r in self.conn.execute(
            "SELECT folder_id, COUNT(*) FROM submissions WHERE status = 'pending' GROUP BY folder_id")}
        reviewers: dict = {}
        for r in self.conn.execute(
                "SELECT r.folder_id AS fid, u.* FROM folder_reviewers r JOIN users u ON u.id = r.user_id "
                "ORDER BY u.login_key"):
            reviewers.setdefault(r["fid"], []).append(_user_dict(r))
        return {"forms": {k: tuple(v) for k, v in forms.items()}, "pending": pending, "reviewers": reviewers}

    def set_folder_reviewers(self, actor_id, folder_id, user_ids, *, ip=None) -> None:
        """폴더 검토자 지정(전부 바꿔 끼움) — 관리자만. 검토자·관리자 역할 계정만 지정할 수 있다."""
        ids = sorted({int(u) for u in user_ids})
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            self._folder(folder_id)
            for uid in ids:
                u = self.conn.execute("SELECT role FROM users WHERE id = ?", (uid,)).fetchone()
                if u is None:
                    raise NotFound("없는 계정입니다")
                if u["role"] not in ("reviewer", "admin"):
                    raise InvalidInput("검토자 역할인 계정만 검토자로 지정할 수 있습니다")
            self.conn.execute("DELETE FROM folder_reviewers WHERE folder_id = ?", (folder_id,))
            self.conn.executemany("INSERT INTO folder_reviewers (folder_id, user_id) VALUES (?, ?)",
                                  [(folder_id, uid) for uid in ids])
            self._audit(actor, "folder_reviewers", f"folder:{folder_id}", ip,
                        ",".join(str(i) for i in ids))

    def folder_reviewers(self, actor_id, folder_id) -> list[dict]:
        self._actor(actor_id)
        rows = self.conn.execute(
            "SELECT u.* FROM folder_reviewers r JOIN users u ON u.id = r.user_id WHERE r.folder_id = ? "
            "ORDER BY u.login_key", (folder_id,)).fetchall()
        return [_user_dict(r) for r in rows]

    def set_subscription(self, actor_id, folder_id, on: bool = True) -> None:
        """폴더 구독(새 현행 판 메일) 켜기·끄기 — 자기 것만."""
        with self.tx():
            actor = self._actor(actor_id)
            self._folder(folder_id)
            if on:
                self.conn.execute("INSERT OR IGNORE INTO subscriptions (user_id, folder_id) VALUES (?, ?)",
                                  (actor["id"], folder_id))
            else:
                self.conn.execute("DELETE FROM subscriptions WHERE user_id = ? AND folder_id = ?",
                                  (actor["id"], folder_id))

    def subscribers(self, folder_id) -> list[dict]:
        """폴더나 위 폴더를 구독한 정지되지 않은 계정들 (메일 보내는 쪽이 쓴다)."""
        ids = self._ancestors(folder_id)
        if not ids:
            return []
        marks = ",".join("?" * len(ids))
        rows = self.conn.execute(
            f"SELECT DISTINCT u.* FROM subscriptions s JOIN users u ON u.id = s.user_id "
            f"WHERE s.folder_id IN ({marks}) AND u.disabled = 0 ORDER BY u.login_key", ids).fetchall()
        return [_user_dict(r) for r in rows]

    # ── 제출(올리기) ───────────────────────────────────────────────────────

    def _form(self, form_id) -> sqlite3.Row:
        row = self.conn.execute("SELECT * FROM forms WHERE id = ?", (form_id,)).fetchone()
        if row is None:
            raise NotFound("없는 양식입니다")
        return row

    def _current_sha(self, form: sqlite3.Row) -> str | None:
        if form["current_version_id"] is None:
            return None
        row = self.conn.execute("SELECT sha256 FROM versions WHERE id = ?",
                                (form["current_version_id"],)).fetchone()
        return row[0] if row else None

    def _check_upload(self, data, filename) -> tuple[bytes, str]:
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise InvalidInput("올릴 파일 내용이 없습니다")
        data = bytes(data)
        if not data:
            raise InvalidInput("빈 파일은 올릴 수 없습니다")
        if len(data) > self.max_upload_bytes:
            raise InvalidInput(f"파일이 너무 큽니다 (최대 {self.max_upload_bytes // (1024 * 1024)}MB)")
        try:
            fname = clean_filename(filename)
        except GuardError as e:
            raise InvalidInput(f"파일 이름으로 쓸 수 없습니다 — {e}")
        ext = os.path.splitext(fname)[1].lower()
        if ext not in ALLOWED_EXTS:
            raise InvalidInput("올릴 수 없는 파일 종류입니다 ("
                               + "·".join(sorted(e.lstrip(".") for e in ALLOWED_EXTS)) + "만)")
        check_content(data, ext)
        return data, fname

    def submit(self, actor_id, *, data, filename, folder_id=None, form_name=None, category="",
               form_id=None, note="", ip=None, doc_type=None) -> dict:
        """양식 올리기 → 검토 대기. form_id가 있으면 그 양식의 개정안, 없으면 folder_id 아래 새 양식(form_name).
        doc_type: (선택) 문서 종류 id — 새 양식은 승인 때 그 종류로, 개정안은 지금 종류와 다를 때만 승인 때 바꾼다
        (None·지금 종류와 같음 = 그대로). 사용 중지된 종류는 고를 수 없다(개정안의 지금 종류는 받는다).

        같은 파일 처리: 현행 판과 같은 내용이면 거부, 같은 대상에 같은 내용이 이미 검토 대기면 거부.
        지난 판과 같은 내용(되돌리기)은 받는다 — 승인되면 새 판 번호가 붙는다."""
        data, fname = self._check_upload(data, filename)
        note = _plain_text(note, "바꾼 내용" if form_id is not None else "설명", MAX_NOTE, required=False)
        if form_id is not None and not note:
            # 개정안은 바꾼 내용 필수 — 대장의 '개정 사유'로 남는다 (2026-10-30, 새 양식은 그대로 선택)
            raise InvalidInput("바꾼 내용을 적어 주세요 — 개정안의 '바꾼 내용'은 문서 관리 대장의 개정 사유로 남습니다")
        self._check_path_length(fname, form_id)
        sha = hashlib.sha256(data).hexdigest()
        with self.tx():
            actor = self._actor(actor_id)
            if form_id is not None:
                form = self._form(form_id)
                if form["retired"]:
                    raise Conflict("폐기된 양식에는 개정안을 올릴 수 없습니다 — 먼저 복원해 주세요")
                if self._current_sha(form) == sha:
                    raise Conflict("현행 판과 같은 파일입니다")
                kind, fid, fname_v, cat = "revision", form["folder_id"], form["name"], form["category"]
                tid = self._usable_type(doc_type, keep=form["doc_type"])
                if tid == form["doc_type"]:
                    tid = None                       # 지금 종류 그대로 — 그사이 상세에서 바꾼 종류를 되돌리지 않게
                dup = self.conn.execute(
                    "SELECT id FROM submissions WHERE status = 'pending' AND form_id = ? AND sha256 = ?",
                    (form_id, sha)).fetchone()
            else:
                if folder_id is None:
                    raise InvalidInput("폴더를 골라 주세요")
                self._folder(folder_id)
                fname_v = _plain_text(form_name, "양식 이름", MAX_FORM_NAME, required=True)
                cat = _plain_text(category, "분류", MAX_CATEGORY, required=False)
                if self.conn.execute("SELECT 1 FROM forms WHERE folder_id = ? AND name_key = ?",
                                     (folder_id, name_key(fname_v))).fetchone():
                    raise Conflict("같은 이름의 양식이 이 폴더에 이미 있습니다 — 그 양식의 개정안으로 올려 주세요")
                kind, fid = "new", folder_id
                tid = self._usable_type(doc_type)
                dup = self.conn.execute(
                    "SELECT id FROM submissions WHERE status = 'pending' AND form_id IS NULL "
                    "AND folder_id = ? AND form_key = ? AND sha256 = ?",
                    (folder_id, name_key(fname_v), sha)).fetchone()
            if dup is not None:
                raise Conflict(f"같은 파일이 이미 검토 대기 중입니다 (제출 {dup[0]}번)")
            cur = self.conn.execute(
                "INSERT INTO submissions (kind, folder_id, form_id, form_name, form_key, category, filename, "
                "sha256, size, note, submitted_by, submitted_at, doc_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (kind, fid, form_id, fname_v, name_key(fname_v), cat, fname, sha, len(data), note,
                 actor["id"], now_text(self.clock()), tid))
            sid = cur.lastrowid
            # 되돌린(ROLLBACK) 제출 번호가 다시 쓰일 수 있어 폴더 이름에 난수를 붙인다
            slot = f"{sid}-{os.urandom(4).hex()}"
            target = self.guard.target(self.store_root, PENDING_DIR, slot, fname)
            self._guarded_write(target, data)
            rel = f"{PENDING_DIR}/{slot}/{fname}"
            self.conn.execute("UPDATE submissions SET staged_path = ? WHERE id = ?", (rel, sid))
            self._audit(actor, "submit", f"submission:{sid}", ip,
                        f"{kind} {fname_v} ({fname}, {len(data)}B)"
                        + (f" — 문서 종류 {self._type_label(tid)}" if tid is not None else ""))
        return self.submission(actor_id, sid)

    def _guarded_write(self, target, data) -> None:
        """새 파일 쓰기(guard) — 디스크 여유 부족은 NoSpace(쉬운 말)로 (2026-10-30, 화면 500 대신)."""
        try:
            self.guard.write_new(target, data)
        except GuardNoSpace:
            raise NoSpace("저장 공간이 부족합니다 — 관리자에게 알려 주세요")

    def _check_path_length(self, fname: str, form_id=None) -> None:
        """보관 경로가 MAX_STORE_PATH(250자)를 넘을 파일 이름이면 올리기 전에 거부 — LongPathsEnabled가 꺼진 PC의 260자 한도
        (2026-10-30). 대기 칸(_pending/<제출 번호>-<난수 8>)과 판 자리(<양식 id>/<판>-<난수 6>) 가운데 긴 쪽으로 넉넉히 센다."""
        root = len(os.path.abspath(str(self.store_root)))
        nxt = int(self.conn.execute("SELECT IFNULL(MAX(id), 0) + 1000 FROM submissions").fetchone()[0])
        pending = len(PENDING_DIR) + 1 + len(str(nxt)) + 9
        fid = form_id if form_id is not None else int(
            self.conn.execute("SELECT IFNULL(MAX(id), 0) + 1000 FROM forms").fetchone()[0])
        version = len(str(fid)) + 1 + 4 + 7                     # '<id>\<판 4자리>-<난수 6>'
        need = root + 1 + max(pending, version) + 1 + len(fname)
        if need > MAX_STORE_PATH:
            keep = max(1, len(fname) - (need - MAX_STORE_PATH))
            raise InvalidInput(f"파일 이름이 너무 깁니다 — 보관 경로가 Windows 경로 길이 한도를 넘습니다. "
                               f"파일 이름을 {keep}자 이하로 줄여 다시 올려 주세요 (지금 {len(fname)}자)")

    def _store_path(self, rel: str) -> Path:
        """forms_store 기준 상대 경로 → Guard가 검사한 절대 경로."""
        parts = [p for p in str(rel).split("/") if p]
        return self.guard.target(self.store_root, *parts)

    def _read_checked(self, rel: str, sha: str, size: int, *, want_data: bool = True) -> bytes:
        """보관 파일을 읽어 크기·지문을 확인한다. 다르면 Conflict (보관소가 바깥에서 바뀐 것)."""
        p = self._store_path(rel)
        h, parts, total = hashlib.sha256(), [], 0
        try:
            with open(p, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    total += len(chunk)
                    if total > size:
                        break
                    h.update(chunk)
                    if want_data:
                        parts.append(chunk)
        except OSError as e:
            raise Conflict(f"보관 파일을 읽을 수 없습니다 ({e.__class__.__name__})")
        if total != size or h.hexdigest() != sha:
            raise Conflict("보관 파일이 올린 때와 다릅니다 — 관리자에게 알려 주세요")
        return b"".join(parts)

    def approve(self, actor_id, submission_id, *, ip=None, memo="") -> dict:
        """승인 — 판 번호를 매기고(1, 2, …) 판 파일을 쓰고 현행 판으로 올린다. 한 트랜잭션.
        memo: (선택) 검토자의 승인 메모 — 올린 사람이 '내 제출'에서 보고 감사 기록에도 남는다 (F3).

        두 사람이 동시에 승인해도 판 번호는 이어지고 같은 제출이 두 번 승인되지 않는다(BEGIN IMMEDIATE)."""
        memo = _plain_text(memo, "승인 메모", MAX_NOTE, required=False, multiline=True)
        track = {"written": None, "sha": None, "memo": memo}
        try:
            res, staged = self._approve_tx(actor_id, submission_id, ip, track)
        except BaseException:
            self._approve_failed(track["written"], track["sha"])
            raise
        # 판 파일이 기록까지 끝난 뒤에만 대기 파일을 치운다 (실패해도 승인은 그대로)
        self._drop_staged(staged[0], staged[1])
        return res

    def _drop_staged(self, rel: str, sha: str) -> bool:
        """대기 파일 하나와 그 빈 칸 폴더(_pending/<칸>)를 guard로 지운다. 파일이 없거나 지웠으면 True,
        Drev가 둔 내용이 아니거나(지문이 다름) 지울 수 없으면 False — 그대로 둔다."""
        try:
            p = self._store_path(rel)
            self.guard.remove_file(p, expected_sha256=sha)
        except (GuardError, OSError):
            return False
        parts = [x for x in str(rel).split("/") if x]
        if len(parts) == 3 and parts[0] == PENDING_DIR:          # _pending/<칸>/<파일> — 칸 폴더만, 위로 더 가지 않는다
            try:
                self.guard.remove_empty_dir(p.parent)
            except (GuardError, OSError):
                pass
        return True

    def purge_pending(self, *, days: float = PENDING_KEEP_DAYS) -> list[int]:
        """보존 기간(days)이 지난 반려·취소 제출의 대기 파일을 지운다 (2026-10-28 보안 F7). 지운 제출 id 목록.

        - 결정된 때(decided_at)가 days일보다 오래된 것만. 검토 대기·승인된 것은 건드리지 않는다.
        - 지우기는 guard 경유 — 올린 때의 지문과 같은 파일만, 그 빈 칸 폴더까지. 지문이 다르면(바깥에서 바뀜) 그대로 둔다.
        - 지운 제출은 대기 파일 칸(staged_path)을 비우고 감사 기록(pending_purge)을 남긴다. 제출 기록 자체는 남는다."""
        cutoff = now_text(float(self.clock()) - float(days) * 86400)
        rows = self.conn.execute(
            "SELECT id, staged_path, sha256, filename, status, decided_at FROM submissions "
            "WHERE status IN ('rejected', 'cancelled') AND staged_path != '' AND decided_at IS NOT NULL "
            "AND decided_at < ? ORDER BY id", (cutoff,)).fetchall()
        done: list[int] = []
        for r in rows:
            if not self._drop_staged(r["staged_path"], r["sha256"]):
                continue
            with self.tx():
                cur = self.conn.execute(
                    "UPDATE submissions SET staged_path = '' WHERE id = ? AND staged_path = ?",
                    (r["id"], r["staged_path"]))
                if cur.rowcount:
                    label = "반려" if r["status"] == "rejected" else "취소"
                    self.record_audit(None, "pending_purge", f"submission:{r['id']}", login="(양식함)",
                                      detail=f"{label}된 제출의 대기 파일 정리 ({r['filename']}, "
                                             f"{label} {str(r['decided_at'])[:10]}, 보존 {int(days)}일 지남)")
            done.append(r["id"])
        return done

    def sweep_pending_orphans(self) -> list[int]:
        """남은 대기 파일 정리 (2026-10-30) — 정리 일이 돌 때마다 _pending/<칸>을 훑는다. 검토 대기 제출이 가리키는 칸은 절대 건드리지 않는다.

        ① 처리된 제출의 남은 파일: 승인은 staged_path를 비운 뒤 대기 파일을 지우는데, 그때 파일이 잠겨 있으면(백신·미리보기)
           영영 남았다. 그 칸의 제출이 검토 대기가 아니고, 결정된 지 ORPHAN_GRACE초가 지났고(승인 자신의 지우기와 겹치지 않게),
           기록이 그 칸을 더는 가리키지 않으면 그 제출의 지문과 같은 파일만 guard로 지운다.
        ② 기록 없는 칸: 되돌려진 올리기(쓰기 뒤 트랜잭션 실패)가 남긴 칸 — 제출 번호가 다시 쓰여 기록이 다른 파일을 가리킬 수도
           있다. 어떤 제출도 그 칸을 가리키지 않고 ORPHAN_STALE_SECONDS(하루)보다 오래된 칸만, 파일마다 그 파일 자신의 지문으로 지운다.
        반려·취소 보존 중인 칸(기록이 가리킴)은 purge_pending 몫. 돌려줌: 정리한 칸의 제출 번호."""
        base = self.store_root / PENDING_DIR
        try:
            slots = [e.name for e in os.scandir(base) if e.is_dir(follow_symlinks=False)]
        except OSError:
            return []
        referenced = {str(r[0]).split("/")[1] for r in self.conn.execute(
            "SELECT staged_path FROM submissions WHERE staged_path LIKE ?", (PENDING_DIR + "/%/%",)).fetchall()
            if len(str(r[0]).split("/")) == 3}
        grace = now_text(float(self.clock()) - ORPHAN_GRACE_SECONDS)
        done: list[int] = []
        for slot in sorted(slots):
            m = re.fullmatch(r"([0-9]{1,12})-[0-9a-f]{8}", slot)
            if not m or slot in referenced:                 # 기록이 가리키는 칸(검토 대기·보존 중) — 손대지 않는다
                continue
            sid = int(m.group(1))
            prefix = f"{PENDING_DIR}/{slot}/"
            try:
                entries = [(e.name, e.stat(follow_symlinks=False).st_mtime) for e in os.scandir(base / slot)
                           if e.is_file(follow_symlinks=False)]
                slot_mtime = os.stat(base / slot, follow_symlinks=False).st_mtime
            except OSError:
                continue
            sub = self.conn.execute("SELECT id, status, sha256, filename, decided_at FROM submissions WHERE id = ?",
                                    (sid,)).fetchone()
            if sub is not None and sub["status"] == "pending" and not entries:
                continue
            # ① 처리된 제출의 남은 파일 (그 제출의 지문과 같을 때만)
            if sub is not None and sub["status"] != "pending" and str(sub["decided_at"] or "") < grace \
                    and any(n == sub["filename"] for n, _t in entries):
                if self._drop_staged(prefix + sub["filename"], sub["sha256"]):
                    self.record_audit(None, "pending_purge", f"submission:{sid}", login="(양식함)",
                                      detail=f"남은 대기 파일 정리 ({sub['filename']} — 처리된 제출인데 대기 칸에 남아 있었음)")
                    done.append(sid)
                    continue
            if sub is not None and sub["status"] != "pending" and str(sub["decided_at"] or "") >= grace:
                continue                                    # 막 처리된 제출 — 승인 자신의 지우기와 겹치지 않게 다음 차례에
            # ② 기록 없는 칸 — 하루 넘게 아무도 가리키지 않은 칸만, 파일마다 자기 지문으로
            newest = max([slot_mtime] + [t for _n, t in entries])
            if time.time() - newest < ORPHAN_STALE_SECONDS:
                continue
            removed = 0
            for name, _t in entries:
                try:
                    p = self._store_path(prefix + name)
                    if self.guard.remove_file(p, expected_sha256=sha256_of(p)):
                        removed += 1
                except (GuardError, OSError):
                    pass
            try:
                self.guard.remove_empty_dir(base / slot)
            except (GuardError, OSError):
                pass
            if removed:
                self.record_audit(None, "pending_purge", f"pending:{slot}", login="(양식함)",
                                  detail=f"기록 없는 대기 칸 정리 (되돌려진 올리기로 보임, 파일 {removed}개)")
                done.append(sid)
        return done

    def _approve_tx(self, actor_id, submission_id, ip, track: dict):
        with self.tx():
            actor = self._actor(actor_id)
            sub = self._submission(submission_id)
            if sub["status"] != "pending":
                raise Conflict("이미 처리된 제출입니다")
            folder_id = sub["folder_id"]
            if sub["form_id"] is not None:
                folder_id = self._form(sub["form_id"])["folder_id"]
            self._require_reviewer(actor, folder_id)
            if sub["kind"] == "revision" and not str(sub["note"] or "").strip() and not track.get("memo"):
                # 바꾼 내용 필수(2026-10-30) 전에 올라온 개정안 — 승인 메모가 대장의 개정 사유가 된다
                raise MemoRequired("이 개정안은 '바꾼 내용'이 비어 있습니다 — 승인 메모에 바꾼 내용을 적어 주세요 "
                                   "(문서 관리 대장의 개정 사유로 남습니다)")
            data = self._read_checked(sub["staged_path"], sub["sha256"], sub["size"])
            ts = now_text(self.clock())
            if sub["kind"] == "new":
                if self.conn.execute("SELECT 1 FROM forms WHERE folder_id = ? AND name_key = ?",
                                     (folder_id, sub["form_key"])).fetchone():
                    raise Conflict("그사이 같은 이름의 양식이 생겼습니다 — 반려하고 개정안으로 다시 올려 주세요")
                tid, skipped = self._approvable_type(sub["doc_type"])
                cur = self.conn.execute(
                    "INSERT INTO forms (folder_id, name, name_key, category, created_by, created_at, doc_type) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (folder_id, sub["form_name"], sub["form_key"], sub["category"], sub["submitted_by"], ts, tid))
                form_id = cur.lastrowid
                type_note = (f" — 문서 종류 {self._type_label(tid)}" if tid is not None else "") + skipped
            else:
                form = self._form(sub["form_id"])
                if form["retired"]:
                    raise Conflict("폐기된 양식입니다 — 먼저 복원해 주세요")
                if self._current_sha(form) == sub["sha256"]:
                    raise Conflict("그사이 같은 파일이 현행 판이 됐습니다 — 반려해 주세요")
                form_id = form["id"]
                tid, type_note = self._approvable_type(sub["doc_type"])
                if tid is not None and tid != form["doc_type"]:
                    # 개정안에서 고른 종류 — 번호는 그대로(이미 매긴 번호는 종류를 바꿔도 바뀌지 않는다)
                    self.conn.execute("UPDATE forms SET doc_type = ? WHERE id = ?", (tid, form_id))
                    type_note = f" — 문서 종류 {self._type_label(form['doc_type'])} → {self._type_label(tid)}"
            number = self.conn.execute("SELECT IFNULL(MAX(number), 0) + 1 FROM versions WHERE form_id = ?",
                                       (form_id,)).fetchone()[0]
            rel = self._place_version(form_id, number, sub["filename"], data, sub["sha256"], sub["size"])
            track["written"], track["sha"] = rel, sub["sha256"]
            cur = self.conn.execute(
                "INSERT INTO versions (form_id, number, path, filename, sha256, size, uploaded_by, uploaded_at, "
                "approved_by, approved_at, note, submission_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (form_id, number, rel, sub["filename"], sub["sha256"], sub["size"], sub["submitted_by"],
                 sub["submitted_at"], actor["id"], ts, sub["note"], sub["id"]))
            vid = cur.lastrowid
            self.conn.execute("UPDATE forms SET current_version_id = ? WHERE id = ?", (vid, form_id))
            # 문서번호 — 처음 현행 판이 될 때(번호가 아직 없을 때) 매긴다. 이미 있으면 그대로 (F7)
            doc_no, new_no = self._form(form_id)["doc_no"], ""
            if not doc_no:
                doc_no = new_no = self._assign_doc_no(form_id, actor, ip)
            memo = track.get("memo", "")
            self.conn.execute(
                "UPDATE submissions SET status = 'approved', decided_by = ?, decided_at = ?, version_id = ?, "
                "form_id = ?, staged_path = '', decision_note = ? WHERE id = ?",
                (actor["id"], ts, vid, form_id, memo, sub["id"]))
            self._audit(actor, "approve", f"submission:{sub['id']}", ip,
                        f"form:{form_id} v{number} ({sub['filename']})" + (f" — 메모: {memo}" if memo else "")
                        + (f" — 문서번호 {new_no} 매김" if new_no else "") + type_note)
        return ({"form_id": form_id, "version_id": vid, "number": number, "doc_no": doc_no},
                (sub["staged_path"], sub["sha256"]))

    def _approve_failed(self, written, sha) -> None:
        """기록이 되돌려졌으면 방금 쓴 판 파일도 치운다 — 남으면 다음 승인의 같은 번호 자리를 막는다."""
        if written:
            try:
                self.guard.remove_file(self._store_path(written), expected_sha256=sha)
            except (GuardError, OSError):
                pass

    def _place_version(self, form_id, number, filename, data, sha, size) -> str:
        """판 파일을 <양식 id>/<판>/<파일명> 에 새로 쓴다. 자리에 같은 내용이 이미 있으면(지난 승인이 파일만 쓰고
        멈춤) 그대로 쓰고, 다른 내용이 있으면 <판>-<난수> 자리에 쓴다 — 판 파일은 덮어쓰지 않는다."""
        slot = str(number)
        for _ in range(4):
            target = self.guard.target(self.store_root, str(form_id), slot, filename)
            rel = f"{form_id}/{slot}/{filename}"
            try:
                self._guarded_write(target, data)
                return rel
            except GuardExists:
                try:
                    self._read_checked(rel, sha, size, want_data=False)
                    return rel
                except Conflict:
                    slot = f"{number}-{os.urandom(3).hex()}"
        raise Conflict("판 파일 자리를 찾지 못했습니다 — 관리자에게 알려 주세요")

    def reject(self, actor_id, submission_id, reason, *, ip=None) -> None:
        """반려 — 사유 필수. 올린 사람이 상태에서 사유를 본다. 대기 파일은 기록으로 남긴다."""
        why = _plain_text(reason, "반려 사유", MAX_NOTE, required=True, multiline=True)
        with self.tx():
            actor = self._actor(actor_id)
            sub = self._submission(submission_id)
            if sub["status"] != "pending":
                raise Conflict("이미 처리된 제출입니다")
            folder_id = self._form(sub["form_id"])["folder_id"] if sub["form_id"] is not None \
                else sub["folder_id"]
            self._require_reviewer(actor, folder_id)
            self.conn.execute(
                "UPDATE submissions SET status = 'rejected', reason = ?, decided_by = ?, decided_at = ? "
                "WHERE id = ?", (why, actor["id"], now_text(self.clock()), sub["id"]))
            self._audit(actor, "reject", f"submission:{sub['id']}", ip, why)

    def cancel(self, actor_id, submission_id, *, ip=None) -> None:
        """취소 — 올린 사람 자신(또는 관리자)이 검토 대기 중일 때만."""
        with self.tx():
            actor = self._actor(actor_id)
            sub = self._submission(submission_id)
            if sub["submitted_by"] != actor["id"] and actor["role"] != "admin":
                raise PermissionDenied("자기가 올린 것만 취소할 수 있습니다")
            if sub["status"] != "pending":
                raise Conflict("이미 처리된 제출입니다")
            self.conn.execute(
                "UPDATE submissions SET status = 'cancelled', decided_by = ?, decided_at = ? WHERE id = ?",
                (actor["id"], now_text(self.clock()), sub["id"]))
            self._audit(actor, "cancel", f"submission:{sub['id']}", ip, "")

    def _submission(self, submission_id) -> sqlite3.Row:
        row = self.conn.execute("SELECT * FROM submissions WHERE id = ?", (submission_id,)).fetchone()
        if row is None:
            raise NotFound("없는 제출입니다")
        return row

    def _may_see_submission(self, actor: sqlite3.Row, sub: sqlite3.Row) -> bool:
        if actor["role"] == "admin" or sub["submitted_by"] == actor["id"]:
            return True
        return self._can_review(actor, sub["folder_id"])

    def submission(self, actor_id, submission_id) -> dict:
        """제출 하나 — 올린 사람·그 폴더 검토자·관리자만 본다."""
        actor = self._actor(actor_id)
        sub = self._submission(submission_id)
        if not self._may_see_submission(actor, sub):
            raise PermissionDenied("볼 수 없는 제출입니다")
        return _submission_dict(sub, self._names())

    def list_submissions(self, actor_id, *, scope: str = "mine", status=None, limit: int = 500) -> list[dict]:
        """제출 목록. scope: 'mine'(내가 올린 것) / 'review'(내가 검토할 수 있는 폴더) / 'all'(관리자)."""
        actor = self._actor(actor_id)
        sql, args = "SELECT * FROM submissions WHERE 1 = 1", []
        if status:
            sql += " AND status = ?"
            args.append(status)
        if scope == "mine":
            sql += " AND submitted_by = ?"
            args.append(actor["id"])
        elif scope == "all":
            self._require_admin(actor)
        elif scope != "review":
            raise InvalidInput("알 수 없는 범위입니다")
        cap = max(1, min(int(limit), 5000))
        if scope != "review":            # 검토 범위는 폴더 권한으로 거른 뒤에 자른다
            sql += f" ORDER BY id DESC LIMIT {cap}"
        else:
            sql += " ORDER BY id DESC"
        rows = self.conn.execute(sql, args).fetchall()
        if scope == "review":
            rows = [r for r in rows if self._can_review(actor, r["folder_id"])][:cap]
        names = self._names()
        return [_submission_dict(r, names) for r in rows]

    def submission_file(self, actor_id, submission_id, *, ip=None) -> dict:
        """검토 대기 파일(검토자가 열어 보기·자동 비교용) — 볼 수 있는 사람만. {path, filename, sha256, size}."""
        actor = self._actor(actor_id)
        sub = self._submission(submission_id)
        if not self._may_see_submission(actor, sub):
            raise PermissionDenied("볼 수 없는 제출입니다")
        if not sub["staged_path"]:
            raise NotFound("대기 파일이 없습니다 (승인되어 판 파일로 옮겨졌거나, 보존 기간이 지나 정리됐습니다)")
        self._read_checked(sub["staged_path"], sub["sha256"], sub["size"], want_data=False)
        with self.tx():
            self._audit(actor, "download_submission", f"submission:{sub['id']}", ip, sub["filename"])
        return {"path": self._store_path(sub["staged_path"]), "filename": sub["filename"],
                "sha256": sub["sha256"], "size": sub["size"]}

    # ── 자동 비교용 읽기 (F3) — 권한은 확인하되 '내려받음' 감사 기록은 남기지 않는다 ─────────────

    def submission_source(self, actor_id, submission_id, *, verify: bool = True) -> dict:
        """비교용 검토 대기 파일 — 볼 수 있는 사람(올린 사람·그 폴더 검토자·관리자)만.
        verify면 지문을 확인한다(보관소가 바깥에서 바뀌었으면 Conflict). 감사 기록은 남기지 않는다.
        돌려줌: {path, filename, sha256, size}."""
        actor = self._actor(actor_id)
        sub = self._submission(submission_id)
        if not self._may_see_submission(actor, sub):
            raise PermissionDenied("볼 수 없는 제출입니다")
        if not sub["staged_path"]:
            raise NotFound("대기 파일이 없습니다 (이미 처리된 제출입니다)")
        if verify:
            self._read_checked(sub["staged_path"], sub["sha256"], sub["size"], want_data=False)
        return {"path": self._store_path(sub["staged_path"]), "filename": sub["filename"],
                "sha256": sub["sha256"], "size": sub["size"]}

    def version_source(self, actor_id, version_id, *, verify: bool = True) -> dict:
        """비교용 판 파일 — 로그인한 누구나(판은 모두가 볼 수 있다). id로만 찾는다. 감사 기록은 남기지 않는다.
        돌려줌: {id, path, filename, sha256, size, form_id, number}."""
        self._actor(actor_id)
        v = self.conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
        if v is None:
            raise NotFound("없는 판입니다")
        if verify:
            self._read_checked(v["path"], v["sha256"], v["size"], want_data=False)
        return {"id": v["id"], "path": self._store_path(v["path"]), "filename": v["filename"],
                "sha256": v["sha256"], "size": v["size"], "form_id": v["form_id"], "number": v["number"]}

    def compare_cache_get(self, key: str) -> dict | None:
        """비교 결과 캐시 한 줄 {status, result(JSON 글자), created_at} 또는 None."""
        row = self.conn.execute("SELECT status, result, created_at FROM compare_cache WHERE cache_key = ?",
                                (str(key),)).fetchone()
        return {"status": row[0], "result": row[1], "created_at": row[2]} if row else None

    def compare_cache_put(self, key: str, status: str, result: str) -> None:
        """비교 결과를 캐시에 둔다(같은 열쇠면 바꿔 끼움). 상한을 넘으면 오래된 것부터 버린다."""
        with self.tx():
            self.conn.execute(
                "INSERT OR REPLACE INTO compare_cache (cache_key, status, result, created_at) VALUES (?, ?, ?, ?)",
                (str(key), str(status), str(result), float(self.clock())))
            n = self.conn.execute("SELECT COUNT(*) FROM compare_cache").fetchone()[0]
            if n > COMPARE_CACHE_MAX:
                self.conn.execute(
                    "DELETE FROM compare_cache WHERE cache_key IN (SELECT cache_key FROM compare_cache "
                    "ORDER BY created_at LIMIT ?)", (n - COMPARE_CACHE_MAX,))

    # ── 메일 알림·현행 미러용 읽기 (F4) — 서버 안쪽(시스템)이 쓴다. 화면 권한과 무관, 감사 기록 없음 ─────────

    def user_email(self, user_id) -> str:
        """알림 받을 주소 — 없거나 정지된 계정이면 빈 글자."""
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if row is None or row["disabled"]:
            return ""
        return (row["email"] or "").strip()

    def is_subscribed(self, actor_id, folder_id) -> bool:
        """그 폴더(자체)를 구독 중인가 — 화면의 [메일 받기] 단추용."""
        self._actor(actor_id)
        return self.conn.execute("SELECT 1 FROM subscriptions WHERE user_id = ? AND folder_id = ?",
                                 (actor_id, folder_id)).fetchone() is not None

    def _folder_names(self) -> dict:
        """{폴더 id: (부모 id, 이름)} — 경로를 한 번에 만들려고."""
        return {r[0]: (r[1], r[2]) for r in self.conn.execute("SELECT id, parent_id, name FROM folders")}

    @staticmethod
    def _path_names(folders: dict, folder_id) -> list[str]:
        out, cur, n = [], folder_id, 0
        while cur is not None and cur in folders and n < 64:
            parent, name = folders[cur]
            out.append(name)
            cur, n = parent, n + 1
        return list(reversed(out))

    def submission_notice(self, submission_id) -> dict | None:
        """알림 메일용 제출 정보 — 양식 이름·상태·사유·메모·판 번호·올린 사람 이름과 주소·폴더 경로."""
        sub = self.conn.execute("SELECT * FROM submissions WHERE id = ?", (submission_id,)).fetchone()
        if sub is None:
            return None
        d = _submission_dict(sub, self._names())
        d["submitter_email"] = self.user_email(sub["submitted_by"])
        folder_id = sub["folder_id"]
        if sub["form_id"] is not None:
            f = self.conn.execute("SELECT folder_id FROM forms WHERE id = ?", (sub["form_id"],)).fetchone()
            folder_id = f[0] if f else folder_id
        d["folder_names"] = self._path_names(self._folder_names(), folder_id)
        d["number"] = None
        if sub["version_id"] is not None:
            v = self.conn.execute("SELECT number FROM versions WHERE id = ?", (sub["version_id"],)).fetchone()
            d["number"] = v[0] if v else None
        return d

    def version_notice(self, version_id) -> dict | None:
        """새 현행 판 알림용 — 양식 이름·판 번호·파일 이름·승인자·설명·폴더 id·경로."""
        v = self.conn.execute(
            "SELECT v.*, f.name AS form_name, f.folder_id AS folder_id FROM versions v "
            "JOIN forms f ON f.id = v.form_id WHERE v.id = ?", (version_id,)).fetchone()
        if v is None:
            return None
        names = self._names()
        return {"version_id": v["id"], "form_id": v["form_id"], "form_name": v["form_name"],
                "number": v["number"], "filename": v["filename"], "note": v["note"],
                "approved_by_name": names.get(v["approved_by"], ""), "folder_id": v["folder_id"],
                "folder_names": self._path_names(self._folder_names(), v["folder_id"])}

    def mirror_plan(self) -> list[dict]:
        """현행 미러에 둘 것 — 폐기되지 않은 양식의 현행 판마다
        {form_id, version_id, form_name, folder_names, filename, sha256, size}. 폐기 양식은 빠진다 (DECISIONS F4)."""
        folders = self._folder_names()
        rows = self.conn.execute(
            "SELECT f.id AS form_id, f.name AS form_name, f.folder_id, v.id AS version_id, v.filename, "
            "v.sha256, v.size FROM forms f JOIN versions v ON v.id = f.current_version_id "
            "WHERE f.retired = 0 ORDER BY f.id").fetchall()
        return [{"form_id": r["form_id"], "version_id": r["version_id"], "form_name": r["form_name"],
                 "folder_names": self._path_names(folders, r["folder_id"]), "filename": r["filename"],
                 "sha256": r["sha256"], "size": r["size"]} for r in rows]

    def version_bytes(self, version_id) -> bytes:
        """판 파일 내용 — 지문·크기를 확인하고 읽는다(미러에 옮겨 둘 때). 다르면 Conflict."""
        v = self.conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
        if v is None:
            raise NotFound("없는 판입니다")
        return self._read_checked(v["path"], v["sha256"], v["size"])

    def mirror_entries(self) -> dict:
        """미러 목록(manifest) {상대 경로: {form_id, version_id, sha256}} — Drev가 미러에 둔 파일들."""
        return {r["rel_path"]: {"form_id": r["form_id"], "version_id": r["version_id"], "sha256": r["sha256"]}
                for r in self.conn.execute("SELECT * FROM mirror_files")}

    def mirror_record(self, rel_path: str, form_id, version_id, sha256: str) -> None:
        with self.tx():
            self.conn.execute(
                "INSERT OR REPLACE INTO mirror_files (rel_path, form_id, version_id, sha256, placed_at) "
                "VALUES (?, ?, ?, ?, ?)", (str(rel_path), form_id, version_id, str(sha256), now_text(self.clock())))

    def mirror_forget(self, rel_path: str) -> None:
        with self.tx():
            self.conn.execute("DELETE FROM mirror_files WHERE rel_path = ?", (str(rel_path),))

    # 현행 미러에 Drev가 만든 폴더 목록 (보안 F7 — 빈 옛 폴더는 Drev가 만든 것만 지운다)
    def mirror_dirs(self) -> list[str]:
        return [r[0] for r in self.conn.execute("SELECT rel_path FROM mirror_dirs ORDER BY rel_path")]

    def mirror_dir_record(self, rel_path: str) -> None:
        with self.tx():
            self.conn.execute("INSERT OR IGNORE INTO mirror_dirs (rel_path, created_at) VALUES (?, ?)",
                              (str(rel_path), now_text(self.clock())))

    def mirror_dir_forget(self, rel_path: str) -> None:
        with self.tx():
            self.conn.execute("DELETE FROM mirror_dirs WHERE rel_path = ?", (str(rel_path),))

    # ── 양식·판 ─────────────────────────────────────────────────────────

    def _names(self) -> dict:
        return {r[0]: r[1] for r in self.conn.execute("SELECT id, display_name FROM users")}

    def _form_rows(self, where: str, args, *, limit: int | None = None, offset: int = 0) -> list[dict]:
        page = f" LIMIT {max(1, int(limit))} OFFSET {max(0, int(offset))}" if limit is not None else ""
        rows = self.conn.execute(
            "SELECT f.*, v.number AS cur_number, v.filename AS cur_filename, v.sha256 AS cur_sha256, "
            "v.size AS cur_size, v.approved_at AS cur_approved_at, u.display_name AS cur_uploaded_by_name, "
            "r.display_name AS retired_by_name, t.code AS dt_code, t.name AS dt_name, t.active AS dt_active "
            "FROM forms f LEFT JOIN versions v ON v.id = f.current_version_id "
            "LEFT JOIN users u ON u.id = v.uploaded_by LEFT JOIN doc_types t ON t.id = f.doc_type "
            f"LEFT JOIN users r ON r.id = f.retired_by WHERE {where} ORDER BY f.name_key, f.id{page}",
            args).fetchall()
        return [_form_dict(r) for r in rows]

    @staticmethod
    def _list_where(folder_id, include_retired: bool) -> tuple[str, list]:
        where, args = "1 = 1", []
        if folder_id is not None:
            where += " AND f.folder_id = ?"
            args.append(folder_id)
        if not include_retired:
            where += " AND f.retired = 0"
        return where, args

    def list_forms(self, actor_id, folder_id=None, *, include_retired: bool = False, limit: int | None = None,
                   offset: int = 0) -> list[dict]:
        """폴더 안 양식들 (folder_id 없으면 전체). limit·offset: 쪽 나누기 (2026-10-30 — 전체 목록 200줄씩)."""
        self._actor(actor_id)
        where, args = self._list_where(folder_id, include_retired)
        return self._form_rows(where, args, limit=limit, offset=offset)

    def count_forms(self, actor_id, folder_id=None, *, include_retired: bool = False) -> int:
        """list_forms와 같은 범위의 양식 수 (쪽 나누기용)."""
        self._actor(actor_id)
        where, args = self._list_where(folder_id, include_retired)
        return int(self.conn.execute(f"SELECT COUNT(*) FROM forms f WHERE {where}", args).fetchone()[0] or 0)

    def form_doc_types(self, actor_id, form_ids) -> dict:
        """{양식 id: 문서 종류 id} — 필요한 양식만 묻는다(내 제출·검토 대기 목록이 양식 전체를 읽지 않게, 2026-10-30)."""
        self._actor(actor_id)
        ids = sorted({int(i) for i in form_ids if i is not None})
        out: dict = {}
        for k in range(0, len(ids), 500):
            chunk = ids[k:k + 500]
            for fid, dt in self.conn.execute(
                    f"SELECT id, doc_type FROM forms WHERE id IN ({','.join('?' * len(chunk))})", chunk).fetchall():
                out[fid] = dt
        return out

    def retired_form_ids(self, actor_id, form_ids) -> set:
        """그 가운데 폐기된 양식 id — 검토 목록의 '폐기된 양식 — 복원해야 승인' 안내용 (2026-10-30)."""
        self._actor(actor_id)
        ids = sorted({int(i) for i in form_ids if i is not None})
        out: set = set()
        for k in range(0, len(ids), 500):
            chunk = ids[k:k + 500]
            out |= {r[0] for r in self.conn.execute(
                f"SELECT id FROM forms WHERE retired = 1 AND id IN ({','.join('?' * len(chunk))})", chunk).fetchall()}
        return out

    def search_forms(self, actor_id, text, *, include_retired: bool = False, limit: int = SEARCH_MAX,
                     folder_id=None) -> list[dict]:
        """양식 찾기 (2026-10-30 넓힘) — 이름·분류·현행 파일 이름·문서번호(지금·이전)·문서 종류 기호·폴더 경로 이름에서.
        접어 비교(전각·대소문자)하고 빈칸은 무시한다('수입 검사' → '수입검사성적서'). 낱말 여럿이면 붙여 쓴 꼴이나 낱말마다
        모두 든 것. folder_id: 그 폴더와 하위 폴더 안에서만 — 범위를 SQL에서 먼저 거른 뒤 limit으로 자른다(폴더를 고른 찾기가
        전체 200개에서 잘려 비던 것). 일치도 SQL 안에서(drev_fold) — 양식을 파이썬으로 다 읽지 않는다.
        돌려줌: 이름순 최대 limit개 — 부르는 쪽이 limit + 1로 물어 잘렸는지 안다."""
        self._actor(actor_id)
        terms = [search_key(t) for t in str(text or "").split()]
        terms = [t for t in terms if t]
        if not terms:
            if folder_id is None:
                return self.list_forms(actor_id, include_retired=include_retired, limit=limit)
            terms = []
        whole = "".join(terms)
        cond = "1 = 1"
        args: list = []
        if terms:
            cond = "(instr(m.h, ?) > 0" + ("" if len(terms) == 1 else
                                            " OR (" + " AND ".join("instr(m.h, ?) > 0" for _ in terms) + ")") + ")"
            args = [whole] + (terms if len(terms) > 1 else [])
        scope_cte, scope_where, scope_args = "", "", []
        if folder_id is not None:
            scope_cte = (", scope(id, d) AS (SELECT ?, 0 UNION ALL SELECT x.id, scope.d + 1 FROM folders x "
                         "JOIN scope ON x.parent_id = scope.id WHERE scope.d < 64)")
            scope_where = " AND f.folder_id IN (SELECT id FROM scope)"
            scope_args = [int(folder_id)]
        retired = "" if include_retired else " AND f.retired = 0"
        sql = ("WITH RECURSIVE fp(id, path, d) AS (SELECT id, name, 0 FROM folders WHERE parent_id IS NULL "
               "UNION ALL SELECT x.id, fp.path || char(31) || x.name, fp.d + 1 FROM folders x JOIN fp ON x.parent_id = fp.id "
               f"WHERE fp.d < 64){scope_cte}, "
               "m AS (SELECT f.id, f.name_key, drev_fold(f.name || char(31) || f.category || char(31) "
               "|| IFNULL(v.filename, '') || char(31) || IFNULL(f.doc_no, '') || char(31) || IFNULL(t.code, '') "
               "|| char(31) || IFNULL(fp.path, '') || char(31) "
               "|| IFNULL((SELECT group_concat(h.old_no, char(31)) FROM doc_no_history h WHERE h.form_id = f.id), '')) AS h "
               "FROM forms f LEFT JOIN versions v ON v.id = f.current_version_id LEFT JOIN doc_types t ON t.id = f.doc_type "
               f"LEFT JOIN fp ON fp.id = f.folder_id WHERE 1 = 1{retired}{scope_where}) "
               f"SELECT m.id FROM m WHERE {cond} ORDER BY m.name_key, m.id LIMIT ?")
        ids = [r[0] for r in self.conn.execute(sql, scope_args + args + [max(1, int(limit))]).fetchall()]
        if not ids:
            return []
        rows = {f["id"]: f for f in self._form_rows(f"f.id IN ({','.join('?' * len(ids))})", ids)}
        return [rows[i] for i in ids if i in rows]

    def form_detail(self, actor_id, form_id) -> dict:
        """양식 하나 + 폴더 경로 + 판 이력(최신부터) + 검토 대기 수."""
        self._actor(actor_id)
        self._form(form_id)
        f = self._form_rows("f.id = ?", (form_id,))[0]
        f["folder_path"] = self.folder_path(actor_id, f["folder_id"])
        f["versions"] = self.list_versions(actor_id, form_id)
        f["pending"] = self.conn.execute(
            "SELECT COUNT(*) FROM submissions WHERE form_id = ? AND status = 'pending'", (form_id,)).fetchone()[0]
        f["prev_doc_nos"] = self.prev_doc_nos([form_id]).get(form_id, [])       # 다시 매기기 전 번호 (F7 번호 규칙)
        f["type_mismatch"] = form_id in self.type_mismatch_ids([form_id])     # 번호의 종류와 다름 (F7 문서 종류 검토 7)
        return f

    def list_versions(self, actor_id, form_id) -> list[dict]:
        self._actor(actor_id)
        names = self._names()
        rows = self.conn.execute("SELECT * FROM versions WHERE form_id = ? ORDER BY number DESC",
                                 (form_id,)).fetchall()
        return [_version_dict(r, names) for r in rows]

    def version_file(self, actor_id, version_id, *, ip=None) -> dict:
        """내려받기용 판 파일 — id로만 찾는다(경로 입력 없음). 지문을 확인하고 감사 기록을 남긴다.

        돌려줌: {path, filename, sha256, size, form_id, number}."""
        actor = self._actor(actor_id)
        v = self.conn.execute("SELECT * FROM versions WHERE id = ?", (version_id,)).fetchone()
        if v is None:
            raise NotFound("없는 판입니다")
        self._read_checked(v["path"], v["sha256"], v["size"], want_data=False)
        form = self._form(v["form_id"])
        retired = bool(form["retired"])
        current = form["current_version_id"] == v["id"]          # 지난 판을 받으면 이름·감사 기록에 표시 (2026-10-30)
        cur_no = None
        if not current and form["current_version_id"] is not None:
            row = self.conn.execute("SELECT number FROM versions WHERE id = ?", (form["current_version_id"],)).fetchone()
            cur_no = row[0] if row else None
        with self.tx():
            self._audit(actor, "download", f"version:{v['id']}", ip,
                        f"form:{v['form_id']} v{v['number']} ({v['filename']})" + (" [폐기된 양식]" if retired else "")
                        + ("" if current else f" [지난 판 — 현행 v{cur_no}]" if cur_no else " [지난 판]"))
        return {"path": self._store_path(v["path"]), "filename": v["filename"], "sha256": v["sha256"],
                "size": v["size"], "form_id": v["form_id"], "number": v["number"], "retired": retired,
                "current": current}

    def set_retired(self, actor_id, form_id, retired: bool, *, ip=None, reason="") -> None:
        """폐기(True)·복원(False) — 관리자나 그 폴더 검토자. 판 파일은 그대로 남는다.
        reason: 사유(화면은 필수로 받는다, F3). 폐기 사유·누가·언제를 양식에 적고, 복원하면 지운다.
        이미 그 상태면 Conflict (두 사람이 같이 눌러도 기록이 겹치지 않게)."""
        why = _plain_text(reason, "사유", MAX_NOTE, required=False, multiline=True)
        with self.tx():
            actor = self._actor(actor_id)
            form = self._form(form_id)
            self._require_reviewer(actor, form["folder_id"])
            if bool(form["retired"]) == bool(retired):
                raise Conflict("이미 폐기된 양식입니다" if retired else "폐기된 양식이 아닙니다")
            if retired:
                self.conn.execute(
                    "UPDATE forms SET retired = 1, retired_reason = ?, retired_by = ?, retired_at = ? WHERE id = ?",
                    (why, actor["id"], now_text(self.clock()), form_id))
            else:
                self.conn.execute(
                    "UPDATE forms SET retired = 0, retired_reason = '', retired_by = NULL, retired_at = NULL "
                    "WHERE id = ?", (form_id,))
            self._audit(actor, "retire" if retired else "restore", f"form:{form_id}", ip,
                        form["name"] + (f" — 사유: {why}" if why else ""))

    def retire_form(self, actor_id, form_id, *, ip=None, reason="") -> None:
        self.set_retired(actor_id, form_id, True, ip=ip, reason=reason)

    def restore_form(self, actor_id, form_id, *, ip=None, reason="") -> None:
        self.set_retired(actor_id, form_id, False, ip=ip, reason=reason)

    # ── 문서번호 (F7 ISO 문서 관리 대장, 2026-10-29) ─────────────────────────────
    # 규칙: 처음 현행 판이 될 때 번호가 없으면 매긴다. 조상 폴더들의 번호 머리(code)를 위에서부터 '-'로 잇고
    # '-' + 그 머리 안 세 자리 일련번호(QA-01-01-001). 머리가 하나도 없으면 전역 F-0001. 번호는 한 번 정하면
    # 폴더를 옮기거나 머리를 바꿔도 그대로다(ISO 관례 — DECISIONS 2026-10-29).
    # 다음 일련번호 = max(그 머리로 지금 실제 쓰이는 번호(폐기 양식 포함 — 행이 남는다), 그 머리로 **자동** 발급한
    # 가장 큰 번호(doc_counters)) + 1. 손으로 적은 번호는 카운터에 올리지 않는다 — 오타(QA-500)를 고쳐도(QA-005)
    # 다음 자동 번호가 501로 뛰지 않게(F7 검토 2). 손으로 적은 번호가 남아 있으면 실제 스캔이 겹침을 막는다.
    # 자동 번호가 MAX_DOC_NO(40자)를 넘으면(깊은 폴더·긴 머리) 전역 꼴(F-0001)로 대신 매기고 감사 기록에 남긴다.

    # (F7 번호 규칙, 2026-10-29) 머리는 관리자가 정한 규칙(docno_rule)으로 그린다 — 기본 {분류}-{번호}·세 자리는 위와 같은 꼴.
    # 머리(규칙의 {번호} 앞부분)에 채워진 폴더 머리 칸도 영문·숫자 글자도 없으면(해만 남음 등) 전역 F-0001. 카운터 열쇠는 머리 끝 구분자를 뗀 것(counter_key).
    # 연도 칸은 그 양식이 처음 승인된 해 — 처음 승인 때 매기므로 곧 오늘이고, [다시 매기기]에서도 같은 해가 나온다.

    def docno_rule(self) -> dict:
        """지금 번호 규칙 {pattern, digits, default} — meta에 없거나 깨졌으면 기본값({분류}-{번호}, 세 자리)."""
        rows = {r[0]: r[1] for r in self.conn.execute(
            "SELECT key, value FROM meta WHERE key IN ('docno_pattern', 'docno_digits')").fetchall()}
        try:                                          # 패턴·자릿수는 따로 되돌린다 — 한쪽이 깨져도 다른 쪽은 그대로
            pattern, _parts = parse_docno_pattern(rows.get("docno_pattern") or DOCNO_DEFAULT_PATTERN)
        except InvalidInput:
            pattern = DOCNO_DEFAULT_PATTERN
        try:
            digits = clean_docno_digits(rows.get("docno_digits") or DOCNO_DEFAULT_DIGITS)
        except InvalidInput:
            digits = DOCNO_DEFAULT_DIGITS
        return {"pattern": pattern, "digits": digits,
                "default": pattern == DOCNO_DEFAULT_PATTERN and digits == DOCNO_DEFAULT_DIGITS}

    def set_docno_rule(self, actor_id, pattern, digits, *, ip=None) -> dict:
        """번호 규칙 저장 — 관리자만. **앞으로 매기는 번호에만** 적용하고 이미 매긴 번호는 그대로(바꾸려면 [다시 매기기]).
        감사 기록(docno_rule)에 이전 → 새 규칙. 돌려줌: 저장한 규칙."""
        text, _parts = parse_docno_pattern(pattern)
        n = clean_docno_digits(digits)
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            old = self.docno_rule()
            if (old["pattern"], old["digits"]) == (text, n):
                return self.docno_rule()
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('docno_pattern', ?)", (text,))
            self.conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('docno_digits', ?)", (str(n),))
            self._audit(actor, "docno_rule", "docno", ip,
                        f"{old['pattern']} (일련 {old['digits']}자리) → {text} (일련 {n}자리) — 앞으로 매기는 번호에만")
            return self.docno_rule()

    def _rule_parts(self) -> tuple[list, int]:
        rule = self.docno_rule()
        return parse_docno_pattern(rule["pattern"])[1], rule["digits"]

    def _folder_table(self) -> dict:
        """{폴더 id: (부모 id, 이름, 번호 머리)} — 여러 양식의 머리를 한 번에 그리려고(폴더마다 묻지 않는다)."""
        return {r[0]: (r[1], r[2], r[3] or "") for r in self.conn.execute("SELECT id, parent_id, name, code FROM folders")}

    @staticmethod
    def _codes_from(table: dict, folder_id) -> list[str]:
        """맨 위부터 그 폴더까지의 번호 머리 (빈 글자 = 머리 없음)."""
        out, cur, n = [], folder_id, 0
        while cur is not None and cur in table and n < 64:
            parent, _name, code = table[cur]
            out.append(code)
            cur, n = parent, n + 1
        return list(reversed(out))

    @staticmethod
    def _head_for(codes: list, parts: list, digits: int, year: int, dtype: str = "") -> tuple[str, int, str]:
        """(머리, 자릿수, 전역으로 바꾼 까닭) — 채워진 폴더 머리 칸·종류도 영문·숫자·한글 글자도 없으면 전역(F-, 네 자리)."""
        head = render_docno_head(parts, codes, year, dtype)
        if not head or not head_has_identity(parts, codes, dtype):
            return GLOBAL_HEAD, GLOBAL_DIGITS, "empty"
        return head, digits, ""

    def _type_codes(self) -> dict:
        """{종류 id: 기호} — 사용 중지된 종류도 (이미 쓴 양식은 그 종류로 센다)."""
        return {r[0]: r[1] for r in self.conn.execute("SELECT id, code FROM doc_types")}

    def _first_year(self, form_id) -> int:
        """그 양식이 처음 승인된 해 — 판이 없거나 날짜가 깨졌으면 오늘의 해."""
        row = self.conn.execute("SELECT MIN(approved_at) FROM versions WHERE form_id = ?", (form_id,)).fetchone()
        d = day_of(row[0] if row else None)
        return d.year if d else self.today().year

    def docno_examples(self, actor_id, pattern=None, digits=None, *, limit: int = 6) -> list[dict]:
        """규칙 미리보기 — 실제 폴더 몇 개(머리 있는 1·2·3단, 머리 없는 것)에 규칙을 적용한 다음 번호. 관리자만, 읽기만.
        pattern·digits를 주면 그 규칙으로(저장 전 미리보기), 안 주면 지금 규칙. 틀린 규칙은 InvalidInput.
        돌려줌: [{path, codes, type, next, kind}…] — kind: 'folder'(실제 폴더) / 'sample'(가상 예시).
        규칙에 {종류}가 있으면 가상 예시를 쓰는 종류 앞 두 가지와 '종류 없음'으로 한 줄씩, 실제 폴더는 첫 종류로 (type = 기호)."""
        actor = self._actor(actor_id)
        self._require_admin(actor)
        if pattern is None:
            parts, dg = self._rule_parts()
        else:
            parts = parse_docno_pattern(pattern)[1]
            dg = clean_docno_digits(DOCNO_DEFAULT_DIGITS if digits is None else digits)
        year = self.today().year
        table = self._folder_table()
        picks: list = []
        by_depth: dict = {}
        no_code = None
        for fid in sorted(table, key=lambda i: (len(self._codes_from(table, i)), i)):
            codes = self._codes_from(table, fid)
            if any(codes):
                if codes[-1] and len(codes) not in by_depth:
                    by_depth[len(codes)] = fid
            elif no_code is None:
                no_code = fid
        picks = [by_depth[k] for k in sorted(by_depth)][:max(1, limit - 1)]
        if no_code is not None:
            picks.append(no_code)
        sample = ["QA", "01", "02"]
        types = [""]
        if rule_uses_type(parts):
            active = [t["code"] for t in self._doc_type_rows() if t["active"]]
            types = active[:2] + [""]                   # 사용 중인 종류가 없으면 '종류 없음' 예시만 (화면이 안내)
        out = [{"path": "(예시) 품질 QA / 검사 01 / 수입검사 02", "codes": sample, "kind": "sample", "type": t,
                "next": self._preview_no(sample, parts, dg, year, scan=False, dtype=t)} for t in types]
        for fid in picks:
            codes = self._codes_from(table, fid)
            names = self._path_names({k: (v[0], v[1]) for k, v in table.items()}, fid)
            out.append({"path": " / ".join(names), "codes": codes, "kind": "folder", "type": types[0],
                        "next": self._preview_no(codes, parts, dg, year, scan=True, dtype=types[0])})
        return out

    def _preview_no(self, codes, parts, digits, year, *, scan: bool, dtype: str = "") -> str:
        head, dg, _why = self._head_for(codes, parts, digits, year, dtype)
        cand = self._next_doc_no(head, dg)[0] if scan else f"{head}{1:0{dg}d}"
        if len(cand) > MAX_DOC_NO:
            return (self._next_doc_no(GLOBAL_HEAD, GLOBAL_DIGITS)[0] if scan else f"{GLOBAL_HEAD}{1:0{GLOBAL_DIGITS}d}") \
                + f" (규칙대로면 {cand} — {MAX_DOC_NO}자를 넘어 전역 꼴)"
        return cand

    def _bump_counter(self, prefix: str, n: int) -> None:
        row = self.conn.execute("SELECT last FROM doc_counters WHERE prefix = ?", (prefix,)).fetchone()
        if row is None or int(row[0]) < int(n):
            self.conn.execute("INSERT OR REPLACE INTO doc_counters (prefix, last) VALUES (?, ?)", (prefix, int(n)))

    def _counter_last(self, head: str) -> int:
        row = self.conn.execute("SELECT last FROM doc_counters WHERE prefix = ?", (counter_key(head),)).fetchone()
        return int(row[0]) if row else 0

    def _seen_max(self, head: str) -> int:
        """그 머리로 지금 실제 쓰이는 번호(폐기 양식 포함)의 가장 큰 일련번호."""
        seen = 0
        for (no,) in self.conn.execute("SELECT doc_no FROM forms WHERE substr(doc_no, 1, ?) = ?",
                                       (len(head), head)).fetchall():
            tail = str(no)[len(head):]
            if str(no).startswith(head) and tail.isascii() and tail.isdigit():
                seen = max(seen, int(tail))
        return seen

    def _next_doc_no(self, head: str, digits: int) -> tuple[str, int]:
        """그 머리의 다음 자동 번호 (번호, 일련) — 아직 적지 않는다. head는 일련번호 앞 글자 전부('QA-01-01-')."""
        n = max(self._seen_max(head), self._counter_last(head)) + 1
        while True:
            cand = f"{head}{n:0{digits}d}"
            if self.conn.execute("SELECT 1 FROM forms WHERE doc_no = ?", (cand,)).fetchone() is None:
                return cand, n
            n += 1

    def _assign_doc_no(self, form_id, actor=None, ip=None) -> str:
        """양식 하나에 다음 번호를 매긴다 — 트랜잭션 안에서 부른다. 돌려줌: 매긴 번호."""
        form = self._form(form_id)
        parts, digits = self._rule_parts()
        codes = self._codes_from(self._folder_table(), form["folder_id"])
        dtype = self._type_codes().get(form["doc_type"], "") if form["doc_type"] is not None else ""
        head, dg, _why = self._head_for(codes, parts, digits, self._first_year(form_id), dtype)
        cand, n = self._next_doc_no(head, dg)
        if len(cand) > MAX_DOC_NO:
            long_ = cand
            head, dg = GLOBAL_HEAD, GLOBAL_DIGITS
            cand, n = self._next_doc_no(head, dg)
            if actor is not None:
                self._audit(actor, "doc_no_fallback", f"form:{form_id}", ip,
                            f"{form['name']}: 번호 규칙과 폴더 머리로 만든 번호 {long_}이(가) {MAX_DOC_NO}자를 넘어 "
                            f"{cand}(으)로 매김 — 폴더 번호 머리나 규칙을 줄이면 다음 양식부터 규칙 꼴로 매깁니다")
        self._bump_counter(counter_key(head), n)
        self.conn.execute("UPDATE forms SET doc_no = ?, doc_no_manual = 0 WHERE id = ?", (cand, form_id))
        return cand

    def assign_missing_doc_numbers(self, actor_id, *, ip=None) -> list[tuple[int, str]]:
        """[번호 없는 양식에 번호 매기기] — 관리자만. 현행 판이 있는데 번호가 없는 양식(이주 전 양식 등, 폐기 포함)에
        만든 차례(id)대로 매긴다. 한 트랜잭션. 돌려줌: [(양식 id, 번호)…]."""
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            ids = [r[0] for r in self.conn.execute(
                "SELECT id FROM forms WHERE doc_no IS NULL AND current_version_id IS NOT NULL ORDER BY id").fetchall()]
            done = [(fid, self._assign_doc_no(fid, actor, ip)) for fid in ids]
            if done:
                self._audit(actor, "doc_no_assign", "forms", ip,
                            f"번호 없는 양식 {len(done)}개에 문서번호를 매김 ({done[0][1]} … {done[-1][1]})")
            return done

    def missing_doc_no_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) FROM forms WHERE doc_no IS NULL AND current_version_id IS NOT NULL")
                   .fetchone()[0] or 0)

    def set_doc_no(self, actor_id, form_id, value, *, ip=None) -> str:
        """문서번호 손으로 고치기 — 관리자만. 다른 양식이 쓰는 번호면 Conflict(그 양식 이름을 알린다). 돌려줌: 정한 번호.
        손 번호로 표시해 둔다(doc_no_manual = 1) — [다시 매기기]는 기본으로 손 번호를 건드리지 않는다."""
        v = clean_doc_no(value)
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            form = self._form(form_id)
            old = form["doc_no"] or ""
            if old == v:
                return v
            other = self.conn.execute("SELECT id, name FROM forms WHERE doc_no = ? AND id != ?", (v, form_id)).fetchone()
            if other is not None:
                raise Conflict(f"문서번호 {v}은(는) 이미 다른 양식({other['name']})이 쓰고 있습니다 — 다른 번호를 적어 주세요")
            self.conn.execute("UPDATE forms SET doc_no = ?, doc_no_manual = 1 WHERE id = ?", (v, form_id))
            self._audit(actor, "doc_no", f"form:{form_id}", ip, f"{form['name']}: {old or '(없음)'} → {v}")
            return v

    # ── 문서 종류 (F7 문서 종류, 2026-10-29) ──────────────────────────────────────
    # 관리는 관리자만(목록·더하기·이름·기호·사용 중지/다시 사용·지우기(안 쓰는 것만)·종류 없는 양식 한꺼번에 지정), 고르기
    # 목록은 누구나 본다. 양식의 종류 바꾸기는 관리자나 그 폴더 검토자(검토 주기와 같은 권한). 종류·기호를 바꿔도 이미 매긴
    # 문서번호는 그대로 — 앞으로 매기는 번호에만(번호 규칙과 같은 원칙). [다시 매기기]는 종류도 '규칙 꼴'의 일부로 본다.

    def _doc_type_rows(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT t.id, t.code, t.name, t.sort, t.active, "
            "(SELECT COUNT(*) FROM forms f WHERE f.doc_type = t.id) AS used, "
            "(SELECT COUNT(*) FROM submissions s WHERE s.doc_type = t.id AND s.status = 'pending') AS pending "
            "FROM doc_types t ORDER BY t.sort, t.id").fetchall()
        return [{"id": r["id"], "code": r["code"], "name": r["name"], "sort": int(r["sort"] or 0),
                 "active": bool(r["active"]), "used": int(r["used"] or 0), "pending": int(r["pending"] or 0)}
                for r in rows]

    def list_doc_types(self, actor_id, *, active_only: bool = False) -> list[dict]:
        """문서 종류 목록(차례대로) — [{id, code, name, sort, active, used(쓰는 양식 수), pending(검토 대기에서 고른 수)}…].
        로그인한 누구나(올리기 화면의 고르기). active_only면 사용 중지된 것을 뺀다."""
        self._actor(actor_id)
        rows = self._doc_type_rows()
        return [t for t in rows if t["active"]] if active_only else rows

    def _doc_type(self, type_id) -> sqlite3.Row:
        row = self.conn.execute("SELECT * FROM doc_types WHERE id = ?", (type_id,)).fetchone()
        if row is None:
            raise NotFound("없는 문서 종류입니다")
        return row

    def _type_code_free(self, code: str, except_id=None) -> None:
        row = self.conn.execute("SELECT name FROM doc_types WHERE code = ? AND id != IFNULL(?, -1)",
                                (code, except_id)).fetchone()
        if row is not None:
            raise Conflict(f"종류 기호 {code}은(는) 이미 '{row['name']}'이(가) 쓰고 있습니다 — 다른 기호를 적어 주세요")

    def create_doc_type(self, actor_id, code, name, *, ip=None) -> int:
        """문서 종류 더하기 — 관리자만. 기호는 유일, 목록 맨 뒤에 붙는다. 돌려줌: 새 종류 id."""
        c, n = clean_type_code(code), clean_type_name(name)
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            self._type_code_free(c)
            sort = int(self.conn.execute("SELECT IFNULL(MAX(sort), 0) + 1 FROM doc_types").fetchone()[0])
            tid = self.conn.execute("INSERT INTO doc_types (code, name, sort, active) VALUES (?, ?, ?, 1)",
                                    (c, n, sort)).lastrowid
            self._audit(actor, "doc_type_create", f"doc_type:{tid}", ip, f"{c} {n}")
            return tid

    def update_doc_type(self, actor_id, type_id, *, code=None, name=None, ip=None) -> dict:
        """문서 종류 기호·이름 바꾸기 — 관리자만. 바뀐 칸마다 감사 기록. 기호를 바꿔도 이미 매긴 번호는 그대로.
        돌려줌: {'code': (이전, 새)|None, 'name': (이전, 새)|None}."""
        c = clean_type_code(code) if code is not None else None
        n = clean_type_name(name) if name is not None else None
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            t = self._doc_type(type_id)
            done: dict = {"code": None, "name": None}
            if c is not None and c != t["code"]:
                self._type_code_free(c, type_id)
                self.conn.execute("UPDATE doc_types SET code = ? WHERE id = ?", (c, type_id))
                self._audit(actor, "doc_type_code", f"doc_type:{type_id}", ip,
                            f"{t['name']}: {t['code']} → {c} — 이미 매긴 문서번호는 그대로")
                done["code"] = (t["code"], c)
            if n is not None and n != t["name"]:
                self.conn.execute("UPDATE doc_types SET name = ? WHERE id = ?", (n, type_id))
                self._audit(actor, "doc_type_name", f"doc_type:{type_id}", ip, f"{c or t['code']}: {t['name']} → {n}")
                done["name"] = (t["name"], n)
            return done

    def set_doc_type_active(self, actor_id, type_id, active: bool, *, ip=None) -> bool:
        """사용 중지(고르기에서 숨김 — 이미 그 종류인 양식은 그대로)·다시 사용 — 관리자만. 돌려줌: 바뀌었나."""
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            t = self._doc_type(type_id)
            if bool(t["active"]) == bool(active):
                return False
            self.conn.execute("UPDATE doc_types SET active = ? WHERE id = ?", (1 if active else 0, type_id))
            self._audit(actor, "doc_type_active" if active else "doc_type_inactive", f"doc_type:{type_id}", ip,
                        f"{t['code']} {t['name']}")
            return True

    def delete_doc_type(self, actor_id, type_id, *, ip=None) -> str:
        """문서 종류 지우기 — 관리자만, 쓰는 양식도 검토 대기 제출도 없을 때만(있으면 사용 중지를 안내). 돌려줌: 지운 기호."""
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            t = self._doc_type(type_id)
            used = int(self.conn.execute("SELECT COUNT(*) FROM forms WHERE doc_type = ?", (type_id,)).fetchone()[0])
            pend = int(self.conn.execute("SELECT COUNT(*) FROM submissions WHERE doc_type = ? AND status = 'pending'",
                                         (type_id,)).fetchone()[0])
            if used or pend:
                what = " · ".join(x for x in (f"양식 {used}개" if used else "", f"검토 대기 {pend}건" if pend else "") if x)
                raise Conflict(f"문서 종류 {t['code']}({t['name']})는 {what}에 쓰여 지울 수 없습니다 "
                               f"— 고르기에서 숨기려면 [사용 중지]를 누르세요")
            self.conn.execute("UPDATE submissions SET doc_type = NULL WHERE doc_type = ?", (type_id,))   # 처리 끝난 제출의 흔적
            self.conn.execute("DELETE FROM doc_types WHERE id = ?", (type_id,))
            self._audit(actor, "doc_type_delete", f"doc_type:{type_id}", ip, f"{t['code']} {t['name']}")
            return t["code"]

    def _usable_type(self, type_id, *, keep=None):
        """고를 수 있는 종류 id — 없으면 NotFound 대신 InvalidInput(화면 입력), 사용 중지면 거부(지금 종류 keep이면 받는다)."""
        if type_id is None:
            return None
        row = self.conn.execute("SELECT id, code, active FROM doc_types WHERE id = ?", (type_id,)).fetchone()
        if row is None:
            raise InvalidInput("없는 문서 종류입니다 — 다시 골라 주세요")
        if not row["active"] and row["id"] != keep:
            raise InvalidInput(f"사용 중지된 문서 종류({row['code']})는 고를 수 없습니다")
        return row["id"]

    def _approvable_type(self, type_id) -> tuple:
        """승인 때 적용할 종류 (id|None, 감사 덧말) — 지운 종류는 조용히 빼고, 올린 뒤 사용 중지된 종류는 적용하지 않고
        감사 기록에 남긴다(승인은 그대로 된다 — 검토 3)."""
        if type_id is None:
            return None, ""
        row = self.conn.execute("SELECT id, code, active FROM doc_types WHERE id = ?", (type_id,)).fetchone()
        if row is None:
            return None, ""
        if not row["active"]:
            return None, f" — 고른 종류 {row['code']}는 사용 중지되어 적용 안 함"
        return row["id"], ""

    def _type_label(self, type_id) -> str:
        if type_id is None:
            return "(없음)"
        row = self.conn.execute("SELECT code, name FROM doc_types WHERE id = ?", (type_id,)).fetchone()
        return f"{row['code']} {row['name']}" if row else "(지운 종류)"

    def set_form_doc_type(self, actor_id, form_id, type_id, *, ip=None) -> bool:
        """양식의 문서 종류 바꾸기 — 관리자나 그 폴더 검토자. None = 종류 없음. **이미 매긴 문서번호는 그대로**
        (번호 규칙과 같은 원칙 — 번호까지 바꾸려면 관리자의 [다시 매기기]). 돌려줌: 바뀌었나."""
        with self.tx():
            actor = self._actor(actor_id)
            form = self._form(form_id)
            self._require_reviewer(actor, form["folder_id"])
            tid = self._usable_type(type_id, keep=form["doc_type"])
            if form["doc_type"] == tid:
                return False
            self.conn.execute("UPDATE forms SET doc_type = ? WHERE id = ?", (tid, form_id))
            self._audit(actor, "form_doc_type", f"form:{form_id}", ip,
                        f"{form['name']}: {self._type_label(form['doc_type'])} → {self._type_label(tid)}"
                        + (f" — 문서번호 {form['doc_no']}은(는) 그대로" if form["doc_no"] else ""))
            return True

    def set_submission_doc_type(self, actor_id, submission_id, type_id, *, ip=None) -> bool:
        """검토 대기 제출의 문서 종류를 승인 전에 고친다 — 관리자나 그 폴더 검토자, 검토 대기일 때만. 뜻은 올리기와 같다:
        새 양식은 None = 종류 없음, 개정안은 None·지금 종류와 같음 = 그대로(NULL). 돌려줌: 바뀌었나 (검토 2)."""
        with self.tx():
            actor = self._actor(actor_id)
            sub = self._submission(submission_id)
            if sub["status"] != "pending":
                raise Conflict("이미 처리된 제출입니다")
            folder_id, keep = sub["folder_id"], None
            if sub["form_id"] is not None:
                form = self._form(sub["form_id"])
                folder_id, keep = form["folder_id"], form["doc_type"]
            self._require_reviewer(actor, folder_id)
            tid = self._usable_type(type_id, keep=keep)
            if sub["form_id"] is not None and tid == keep:
                tid = None
            if sub["doc_type"] == tid:
                return False
            self.conn.execute("UPDATE submissions SET doc_type = ? WHERE id = ?", (tid, submission_id))
            said = (lambda i: "(그대로)" if i is None else self._type_label(i)) if sub["form_id"] is not None \
                else self._type_label
            self._audit(actor, "submission_doc_type", f"submission:{submission_id}", ip,
                        f"{sub['form_name']}: {said(sub['doc_type'])} → {said(tid)} (승인 전)")
            return True

    def preview_doc_no(self, folder_id, type_id=None) -> str:
        """그 폴더·종류로 지금 처음 승인되면 매길 번호(아직 적지 않는다) — 검토 화면의 '종류 없이 매겨짐' 안내용. 읽기만."""
        parts, digits = self._rule_parts()
        codes = self._codes_from(self._folder_table(), folder_id)
        dtype = self._type_codes().get(type_id, "") if type_id is not None else ""
        return self._preview_no(codes, parts, digits, self.today().year, scan=True, dtype=dtype)

    def type_mismatch_ids(self, form_ids=None) -> set:
        """규칙에 {종류}가 있을 때, 번호의 머리가 **다른 종류(또는 종류 없음)**로 그린 머리와 같고 지금 종류로 그린 머리와는
        다른 양식 id들 — '번호의 종류와 다름 — 다시 매기기 필요' 표시용(검토 7). 지금 폴더 기준이라 옮긴 양식·손 번호처럼
        어느 종류 머리와도 맞지 않는 번호는 표시하지 않는다(종류 탓이 아님). 규칙에 {종류}가 없으면 빈 모음."""
        parts, digits = self._rule_parts()
        if not rule_uses_type(parts):
            return set()
        table = self._folder_table()
        codes_of: dict = {}
        type_codes = self._type_codes()
        cands = [""] + sorted(set(type_codes.values()))
        first = {r[0]: r[1] for r in self.conn.execute(
            "SELECT form_id, MIN(approved_at) FROM versions GROUP BY form_id").fetchall()}
        rows = self.conn.execute("SELECT id, folder_id, doc_no, doc_type FROM forms "
                                 "WHERE doc_no IS NOT NULL AND doc_no != ''").fetchall()
        want = None if form_ids is None else {int(i) for i in form_ids}
        year_now = self.today().year
        out = set()
        for r in rows:
            if want is not None and r["id"] not in want:
                continue
            if r["folder_id"] not in codes_of:
                codes_of[r["folder_id"]] = self._codes_from(table, r["folder_id"])
            d = day_of(first.get(r["id"]))
            year = d.year if d else year_now
            own = type_codes.get(r["doc_type"], "") if r["doc_type"] is not None else ""
            heads = {t: self._head_for(codes_of[r["folder_id"]], parts, digits, year, t)[0] for t in cands}
            h = split_doc_no(r["doc_no"])[0]
            if h != heads.get(own) and any(h == hd for t, hd in heads.items() if t != own):
                out.add(r["id"])
        return out

    def untyped_form_count(self) -> int:
        """종류가 없는 양식 수(현행 판이 있는 것, 폐기 포함 — [다시 매기기] 대상과 같은 범위)."""
        return int(self.conn.execute("SELECT COUNT(*) FROM forms WHERE doc_type IS NULL AND current_version_id IS NOT NULL")
                   .fetchone()[0] or 0)

    def assign_type_to_untyped(self, actor_id, type_id, *, ip=None) -> int:
        """[종류가 없는 양식 N개를 (고른 종류)로 지정] — 관리자만, 한 트랜잭션. 현행 판이 있는 종류 없는 양식 전부(폐기 포함).
        번호는 바꾸지 않는다({종류} 규칙으로 바꾸려면 그다음 [다시 매기기]). 돌려줌: 지정한 양식 수."""
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            if type_id is None:
                raise InvalidInput("지정할 문서 종류를 골라 주세요")
            self._doc_type(type_id)
            tid = self._usable_type(type_id)
            ids = [r[0] for r in self.conn.execute(
                "SELECT id FROM forms WHERE doc_type IS NULL AND current_version_id IS NOT NULL ORDER BY id").fetchall()]
            if not ids:
                return 0
            self.conn.executemany("UPDATE forms SET doc_type = ? WHERE id = ?", [(tid, i) for i in ids])
            self._audit(actor, "doc_type_assign", "forms", ip,
                        f"종류가 없는 양식 {len(ids)}개를 {self._type_label(tid)}(으)로 지정 — 문서번호는 그대로")
            return len(ids)

    # ── 다시 매기기 (F7 번호 규칙) — 처음 규칙을 도입하는 회사용. 관리자가 미리보기를 보고 확인해야 실행 ──────────
    # 대상: 현행 판이 있는 양식 전부(폐기 포함). 손 번호는 고른 때만. 이미 지금 규칙 꼴인 번호는 그대로 — 같은 규칙으로
    # 다시 눌러도 바뀌는 것이 없다. '규칙 꼴'은 기본으로 **어느 폴더의 머리로든**(폴더를 옮겨도 번호는 그대로라는 F7 원칙),
    # relocate(옮긴 양식도 새 위치 머리로)를 고르면 그 양식이 지금 있는 폴더의 머리로만 본다. 머리는 맞는데 자릿수만
    # 다르면 일련을 지킨 채 0 채움만 바꾼다(QA-001 → QA-0001, 표기 변경 — 이전 번호로 남김). 나머지는 옛 번호 차례
    # (번호 없는 것은 뒤, 만든 차례)대로 머리마다 max(그 머리로 쓰이는 번호·이전 번호·카운터) 다음부터.

    def prev_doc_nos(self, form_ids=None) -> dict:
        """{양식 id: [이전 번호…]} (오래된 것부터) — 다시 매기기로 바뀐 번호. 지금 번호와 같은 값은 뺀다."""
        sql = ("SELECT h.form_id, h.old_no, f.doc_no FROM doc_no_history h JOIN forms f ON f.id = h.form_id")
        if form_ids is None:
            rows = self.conn.execute(sql + " ORDER BY h.id").fetchall()
        else:
            ids = [int(i) for i in form_ids]
            if not ids:
                return {}
            rows = []
            for k in range(0, len(ids), 500):
                chunk = ids[k:k + 500]
                rows += self.conn.execute(
                    sql + f" WHERE h.form_id IN ({','.join('?' * len(chunk))}) ORDER BY h.id", chunk).fetchall()
        out: dict = {}
        for fid, old, cur in rows:
            if old and old != (cur or "") and old not in out.setdefault(fid, []):
                out[fid].append(old)
        return {k: v for k, v in out.items() if v}

    def _renumber_rows(self, include_manual: bool, relocate: bool = False) -> list[dict]:
        parts, digits = self._rule_parts()
        table = self._folder_table()
        names = {k: (v[0], v[1]) for k, v in table.items()}
        first = {r[0]: r[1] for r in self.conn.execute(
            "SELECT form_id, MIN(approved_at) FROM versions GROUP BY form_id").fetchall()}
        forms = self.conn.execute(
            "SELECT id, folder_id, name, doc_no, doc_no_manual, retired, doc_type FROM forms "
            "WHERE current_version_id IS NOT NULL").fetchall()
        type_codes = self._type_codes()
        targets, used = [], set()
        for f in forms:
            if include_manual or not f["doc_no_manual"] or not f["doc_no"]:
                targets.append(f)
            elif f["doc_no"]:
                used.add(f["doc_no"])                       # 건드리지 않는 손 번호 — 새 번호가 피해 간다
        history: dict = {}                                  # 이전 번호 → 그 번호를 썼던 양식들
        for fid, old in self.conn.execute("SELECT form_id, old_no FROM doc_no_history").fetchall():
            history.setdefault(old, set()).add(fid)
        today_year = self.today().year
        codes_of = {fid: self._codes_from(table, fid) for fid in table}
        any_heads: dict = {}                                # (해, 종류) → {머리: 자릿수} (모든 폴더, 전역 꼴 빼고)
        use_type = rule_uses_type(parts)

        def heads_of_year(year: int, dtype: str) -> dict:
            # 폴더는 어느 것이든(옮긴 양식의 번호를 지킨다) 받아 주지만 종류는 그 양식의 지금 종류만 — 종류도 '규칙 꼴'의 일부
            if (year, dtype) not in any_heads:
                got = {}
                for codes in codes_of.values():
                    h, dg, why = self._head_for(codes, parts, digits, year, dtype)
                    if not why and len(h) + dg <= MAX_DOC_NO:
                        got[h] = dg
                any_heads[(year, dtype)] = got
            return any_heads[(year, dtype)]
        rows = []
        for f in targets:
            d = day_of(first.get(f["id"]))
            year = d.year if d else today_year
            dtype = type_codes.get(f["doc_type"], "") if (use_type and f["doc_type"] is not None) else ""
            head, dg, why = self._head_for(codes_of.get(f["folder_id"], []), parts, digits, year, dtype)
            fallback = ""
            if len(head) + dg > MAX_DOC_NO:
                fallback = f"{head}{1:0{dg}d}"
                head, dg = GLOBAL_HEAD, GLOBAL_DIGITS
            ok_heads = {head: dg} if relocate else dict(heads_of_year(year, dtype), **{head: dg})
            rows.append({"id": f["id"], "name": f["name"], "folder_id": f["folder_id"],
                         "path": " / ".join(self._path_names(names, f["folder_id"])),
                         "old": f["doc_no"] or "", "new": "", "head": head, "digits": dg, "n": 0, "_ok": ok_heads,
                         "manual": bool(f["doc_no_manual"]) and bool(f["doc_no"]), "retired": bool(f["retired"]),
                         "global": why == "empty" or bool(fallback), "fallback": fallback, "reformat": False,
                         "type": type_codes.get(f["doc_type"], "") if f["doc_type"] is not None else ""})
        olds = {r["old"]: r["id"] for r in rows if r["old"]}

        def serial(r) -> tuple[str, int, int]:
            """(옛 번호 머리, 일련, 그 머리의 자릿수) — 받아 줄 머리가 아니거나 일련이 숫자가 아니면 ('', 0, 0)."""
            h, t = split_doc_no(r["old"])
            if h in r["_ok"] and t.isascii() and t.isdigit() and int(t) > 0:
                return h, int(t), r["_ok"][h]
            return "", 0, 0
        for r in rows:                                       # 1) 이미 규칙 꼴인 번호는 그대로
            h, n, dg = serial(r) if r["old"] else ("", 0, 0)
            if n and f"{n:0{dg}d}" == split_doc_no(r["old"])[1] and r["old"] not in used:
                r.update(new=r["old"], n=n, head=h, digits=dg, **{"global": h == GLOBAL_HEAD})
                used.add(r["old"])
        for r in rows:                                       # 2) 머리는 맞고 자릿수만 다름 — 일련을 지켜 0 채움만
            if r["new"] or not r["old"]:
                continue
            h, n, dg = serial(r)
            cand = f"{h}{n:0{dg}d}" if n else ""
            if (cand and len(cand) <= MAX_DOC_NO and cand not in used and olds.get(cand, r["id"]) == r["id"]
                    and not (history.get(cand, set()) - {r["id"]})):
                r.update(new=cand, n=n, head=h, digits=dg, reformat=True, **{"global": h == GLOBAL_HEAD})
                used.add(cand)
        last: dict = {}
        hist = list(history)
        heads = {r["head"] for r in rows if not r["new"]}
        for head in heads:                                   # 3) 머리마다 지난 번호 다음부터
            tails = [x[len(head):] for x in list(used) + hist + list(olds) if x.startswith(head)]
            seen = max([int(t) for t in tails if t.isascii() and t.isdigit()] + [0])
            last[head] = max(seen, self._counter_last(head), self._seen_max(head))
        rows.sort(key=lambda r: (0 if r["old"] else 1, doc_no_key(r["old"]), r["id"]))
        for r in rows:
            if r["new"]:
                continue
            head, dg = r["head"], r["digits"]
            n = last[head] + 1
            while f"{head}{n:0{dg}d}" in used:
                n += 1
            cand = f"{head}{n:0{dg}d}"
            if len(cand) > MAX_DOC_NO:                       # 일련이 자라 40자를 넘음 — 전역 꼴로
                r["fallback"] = cand
                head, dg = GLOBAL_HEAD, GLOBAL_DIGITS
                if head not in last:
                    tails = [x[len(head):] for x in list(used) + hist + list(olds) if x.startswith(head)]
                    last[head] = max([int(t) for t in tails if t.isascii() and t.isdigit()]
                                     + [self._counter_last(head), self._seen_max(head)])
                n = last[head] + 1
                while f"{head}{n:0{dg}d}" in used:
                    n += 1
                cand = f"{head}{n:0{dg}d}"
                r["head"], r["digits"], r["global"] = head, dg, True
            last[head] = n
            r["new"], r["n"] = cand, n
            used.add(cand)
        for r in rows:
            del r["_ok"]
        return rows

    @staticmethod
    def _plan_digest(rule: dict, include_manual: bool, relocate: bool, changed: list) -> str:
        blob = json.dumps([rule["pattern"], rule["digits"], bool(include_manual), bool(relocate),
                           [(r["id"], r["old"], r["new"]) for r in changed]], ensure_ascii=False)
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()

    def renumber_plan(self, actor_id, *, include_manual: bool = False, relocate: bool = False) -> dict:
        """[다시 매기기] 미리보기 — 관리자만, 읽기만. 실행(renumber)과 같은 계산.
        relocate: 옮긴 양식도 지금 폴더의 머리로 다시 매김(기본 끔 — 어느 폴더 머리로든 규칙 꼴이면 그대로).
        돌려줌: {rule, changed: [{id, name, path, old, new, manual, retired, global, fallback, reformat}…], same(그대로인 수),
        manual_kept(손 번호라 뺀 수), total, digest(실행 때 같은 목록인지 대조)}."""
        actor = self._actor(actor_id)
        self._require_admin(actor)
        with self._lock:
            rule = self.docno_rule()
            rows = self._renumber_rows(include_manual, relocate)
            manual_kept = 0 if include_manual else int(self.conn.execute(
                "SELECT COUNT(*) FROM forms WHERE current_version_id IS NOT NULL AND doc_no_manual = 1 "
                "AND doc_no IS NOT NULL AND doc_no != ''").fetchone()[0] or 0)
        changed = [r for r in rows if r["new"] != r["old"]]
        changed.sort(key=lambda r: (doc_no_key(r["new"]), r["id"]))
        return {"rule": rule, "include_manual": bool(include_manual), "relocate": bool(relocate), "changed": changed,
                "same": len(rows) - len(changed), "manual_kept": manual_kept, "total": len(rows),
                "digest": self._plan_digest(rule, include_manual, relocate, changed)}

    def renumber(self, actor_id, *, include_manual: bool = False, relocate: bool = False, expect: str | None = None,
                 ip=None) -> list[dict]:
        """[다시 매기기] 실행 — 관리자만, 한 트랜잭션. expect(미리보기의 digest)를 주면 그사이 목록이 바뀌었을 때 Conflict.
        바뀌는 양식은 먼저 번호를 비운 뒤(NULL — 유일 색인이 겹침을 보지 않게) 새 번호를 적는다. 옛 번호는
        doc_no_history(이전 번호)에 남고 감사 기록(docno_renumber) 한 줄. 돌려줌: 바뀐 줄들(미리보기와 같은 꼴)."""
        with self.tx():
            actor = self._actor(actor_id)
            self._require_admin(actor)
            plan = self.renumber_plan(actor_id, include_manual=include_manual, relocate=relocate)
            if expect is not None and not hmac.compare_digest(plan["digest"], str(expect)):
                raise Conflict("미리보기 뒤에 양식이나 번호가 바뀌었습니다 — 다시 미리보기를 보고 실행해 주세요")
            changed = plan["changed"]
            if not changed:
                return []
            ts = now_text(self.clock())
            self.conn.executemany("UPDATE forms SET doc_no = NULL WHERE id = ?", [(r["id"],) for r in changed])
            self.conn.executemany("UPDATE forms SET doc_no = ?, doc_no_manual = 0 WHERE id = ?",
                                  [(r["new"], r["id"]) for r in changed])
            self.conn.executemany(
                "INSERT INTO doc_no_history (form_id, old_no, new_no, at, user_id) VALUES (?, ?, ?, ?, ?)",
                [(r["id"], r["old"], r["new"], ts, actor["id"]) for r in changed if r["old"]])
            top: dict = {}
            for r in changed:
                key = counter_key(r["head"])
                top[key] = max(top.get(key, 0), int(r["n"]))
            for key, n in top.items():
                self._bump_counter(key, n)
            rule = plan["rule"]
            fb = sum(1 for r in changed if r["global"])
            sample = ", ".join(f"{r['old'] or '(없음)'} → {r['new']}" for r in changed[:3])
            self._audit(actor, "docno_renumber", "forms", ip,
                        f"문서번호 다시 매김 {len(changed)}개 (규칙 {rule['pattern']}, 일련 {rule['digits']}자리"
                        + (", 손 번호 포함" if include_manual else "") + (", 옮긴 양식은 새 위치 머리로" if relocate else "")
                        + f"; 그대로 {plan['same']}개"
                        + (f"; 전역 꼴 {fb}개" if fb else "") + f") — {sample}" + (" …" if len(changed) > 3 else ""))
            return changed

    # ── 정기 검토 (F7) ─────────────────────────────────────────────────────
    # 다음 기한 = max(최근 검토일, 현행 판 승인일) + 주기(개월, 월말은 그 달 마지막 날). 새 판 승인은 검토로 친다.
    # 주기: 양식별(review_months) — NULL = 전체 기본값(설정 review_months_default, 기본 12), 0 = 안 함.

    def today(self) -> date:
        return datetime.fromtimestamp(float(self.clock())).date()

    def default_review_months(self) -> int:
        try:
            n = int(self.review_months_default)
        except (TypeError, ValueError):
            n = REVIEW_MONTHS_DEFAULT
        return max(0, min(n, REVIEW_MONTHS_MAX))

    def review_state(self, review_months, last_reviewed_at, approved_at, *, retired=False, today=None) -> dict:
        """검토 기한 계산 — {months, inherit, base, due, state}. state: ok / soon(30일 안) / overdue(지남) /
        off(주기 0·판 없음) / retired(폐기 — 검토하지 않는다). base·due는 date 또는 None."""
        inherit = review_months is None
        months = self.default_review_months() if inherit else max(0, int(review_months))
        base = max([d for d in (day_of(last_reviewed_at), day_of(approved_at)) if d is not None], default=None)
        out = {"months": months, "inherit": inherit, "base": base, "due": None, "state": "off"}
        if retired:
            out["state"] = "retired"
            return out
        if months <= 0 or base is None:
            return out
        due = add_months(base, months)
        t = today or self.today()
        out["due"] = due
        out["state"] = "overdue" if due < t else ("soon" if due <= t + timedelta(days=REVIEW_SOON_DAYS) else "ok")
        return out

    def set_review_months(self, actor_id, form_id, months, *, ip=None) -> None:
        """양식별 검토 주기 — None = 전체 기본값 따름, 0 = 안 함, 1~120개월. 관리자나 그 폴더 검토자."""
        if months is not None:
            try:
                months = int(months)
            except (TypeError, ValueError):
                raise InvalidInput("검토 주기는 개월 수(숫자)로 적어 주세요")
            if not 0 <= months <= REVIEW_MONTHS_MAX:
                raise InvalidInput(f"검토 주기는 0~{REVIEW_MONTHS_MAX}개월로 적어 주세요 (0 = 안 함)")
        with self.tx():
            actor = self._actor(actor_id)
            form = self._form(form_id)
            self._require_reviewer(actor, form["folder_id"])
            if form["retired"]:
                raise Conflict("폐기된 양식은 정기 검토하지 않습니다 — 주기를 바꾸려면 먼저 복원해 주세요")
            if form["review_months"] == months:
                return
            self.conn.execute("UPDATE forms SET review_months = ? WHERE id = ?", (months, form_id))

            def said(m):
                return "전체 기본값" if m is None else ("안 함" if m == 0 else f"{m}개월")
            self._audit(actor, "review_months", f"form:{form_id}", ip,
                        f"{form['name']}: {said(form['review_months'])} → {said(months)}")

    def mark_reviewed(self, actor_id, form_id, memo="", *, ip=None) -> str:
        """[검토함 — 바꿀 것 없음] — 최근 검토 때를 지금으로 적고 감사 기록(form_review)을 남긴다. 관리자나 그 폴더 검토자.
        폐기 양식·현행 판 없는 양식은 거부. 고칠 것이 있으면 개정안을 올린다(승인이 곧 검토). 돌려줌: 적은 때."""
        note = _plain_text(memo, "검토 메모", MAX_NOTE, required=False)
        with self.tx():
            actor = self._actor(actor_id)
            form = self._form(form_id)
            self._require_reviewer(actor, form["folder_id"])
            if form["retired"]:
                raise Conflict("폐기된 양식은 정기 검토하지 않습니다")
            if form["current_version_id"] is None:
                raise Conflict("현행 판이 없는 양식입니다")
            ts = now_text(self.clock())
            self.conn.execute("UPDATE forms SET last_reviewed_at = ? WHERE id = ?", (ts, form_id))
            self._audit(actor, "form_review", f"form:{form_id}", ip,
                        f"{form['doc_no'] or ''} {form['name']} — 바꿀 것 없음".strip()
                        + (f" — 메모: {note}" if note else ""))
            return ts

    def mark_reviewed_many(self, actor_id, form_ids, memo="", *, ip=None) -> list[int]:
        """[선택한 양식 검토함] (2026-10-30, 기한 목록 일괄) — 한 트랜잭션, 메모 하나. 양식마다 권한(관리자나 그 폴더 검토자)·
        폐기·현행 판을 mark_reviewed와 똑같이 본다 — 하나라도 안 되면 아무것도 적지 않는다. 감사 기록은 양식마다 한 줄(일괄 표시).
        돌려줌: 적은 양식 id."""
        note = _plain_text(memo, "검토 메모", MAX_NOTE, required=False)
        ids = list(dict.fromkeys(int(i) for i in form_ids))
        if not ids:
            raise InvalidInput("검토함으로 적을 양식을 골라 주세요")
        if len(ids) > 500:
            raise InvalidInput("한 번에 500개까지 고를 수 있습니다")
        with self.tx():
            actor = self._actor(actor_id)
            ts = now_text(self.clock())
            for fid in ids:
                form = self._form(fid)
                if not self._can_review(actor, form["folder_id"]):
                    raise PermissionDenied(f"맡은 폴더 밖의 양식이 있어 아무것도 적지 않았습니다 — '{form['name']}'"
                                           f"(은)는 이 폴더의 검토자만 할 수 있습니다")
                if form["retired"]:
                    raise Conflict(f"폐기된 양식은 정기 검토하지 않습니다 ({form['name']})")
                if form["current_version_id"] is None:
                    raise Conflict(f"현행 판이 없는 양식입니다 ({form['name']})")
                self.conn.execute("UPDATE forms SET last_reviewed_at = ? WHERE id = ?", (ts, fid))
                self._audit(actor, "form_review", f"form:{fid}", ip,
                            f"{form['doc_no'] or ''} {form['name']} — 바꿀 것 없음 (일괄 {len(ids)}개)".strip()
                            + (f" — 메모: {note}" if note else ""))
            return ids

    # ── 문서 관리 대장 (F7) — 관리자는 전체, 검토자는 맡은 폴더(상속 포함), 직원은 거부 ─────────────

    def _register_scope(self, actor_id):
        """(요청한 사람, 볼 수 있는 폴더 모음 — 관리자는 None=전부). 직원은 PermissionDenied."""
        actor = self._actor(actor_id)
        if actor["role"] not in ("admin", "reviewer"):
            raise PermissionDenied("문서 관리 대장은 관리자와 검토자만 볼 수 있습니다")
        return actor, self.reviewable_folders(actor_id)

    def _register_rows(self, scope, *, include_retired: bool, today=None) -> list[dict]:
        folders = self._folder_names()
        names = self._names()
        rows = self.conn.execute(
            "SELECT f.id, f.folder_id, f.name, f.name_key, f.doc_no, f.retired, f.review_months, f.last_reviewed_at, "
            "t.code AS dt_code, t.name AS dt_name, "
            "v.number AS cur_number, v.approved_at AS cur_approved_at, v.note AS cur_note, "
            "v.approved_by AS cur_approved_by, IFNULL(s.decision_note, '') AS cur_memo, "
            "(SELECT COUNT(*) FROM versions x WHERE x.form_id = f.id) AS n_versions "
            "FROM forms f JOIN versions v ON v.id = f.current_version_id "
            "LEFT JOIN submissions s ON s.id = v.submission_id LEFT JOIN doc_types t ON t.id = f.doc_type "
            "WHERE (? = 1 OR f.retired = 0)", (1 if include_retired else 0,)).fetchall()
        t = today or self.today()
        prev = self.prev_doc_nos()
        mism = self.type_mismatch_ids()                  # 번호의 종류와 다름 (규칙에 {종류}가 있을 때만, 화면용 — 엑셀엔 없음)
        out = []
        for r in rows:
            if scope is not None and r["folder_id"] not in scope:
                continue
            path = self._path_names(folders, r["folder_id"])
            rv = self.review_state(r["review_months"], r["last_reviewed_at"], r["cur_approved_at"],
                                   retired=bool(r["retired"]), today=t)
            reason = r["cur_note"] or ""
            if not reason and r["cur_memo"]:
                reason = f"(승인 메모) {r['cur_memo']}"
            out.append({
                "id": r["id"], "folder_id": r["folder_id"], "doc_no": r["doc_no"] or "", "name": r["name"],
                "top": path[0] if path else "", "mid": path[1] if len(path) > 1 else "",
                "rest": " / ".join(path[2:]), "path": " / ".join(path),
                "number": r["cur_number"], "effective": str(r["cur_approved_at"] or "")[:10],
                "approver": names.get(r["cur_approved_by"], ""), "reason": reason,
                "versions": int(r["n_versions"] or 0), "revisions": max(0, int(r["n_versions"] or 0) - 1),
                "last_reviewed": str(r["last_reviewed_at"] or "")[:10], "review_months": r["review_months"],
                "months": rv["months"], "inherit": rv["inherit"],
                "due": rv["due"].isoformat() if rv["due"] else "", "state": rv["state"],
                "prev_doc_nos": prev.get(r["id"], []),
                "doc_type": r["dt_code"] or "", "doc_type_name": r["dt_name"] or "",          # 문서 종류 (이주 8)
                "type_mismatch": r["id"] in mism,
                "retired": bool(r["retired"]), "_key": (0 if r["doc_no"] else 1, doc_no_key(r["doc_no"]),
                                                       " / ".join(path), r["name_key"], r["id"])})
        out.sort(key=lambda x: x["_key"])
        for x in out:
            del x["_key"]
        return out

    def register(self, actor_id, *, include_retired: bool = False, history: bool = False) -> dict:
        """문서 관리 대장 — {rows: [양식 한 줄…], history: [승인된 판 한 줄…](history=True일 때), scope_all}.
        읽기만 한다(감사 기록은 서버가 내려받기 때만 남긴다)."""
        actor, scope = self._register_scope(actor_id)
        rows = self._register_rows(scope, include_retired=include_retired)
        out = {"rows": rows, "history": [], "scope_all": scope is None}
        if history:
            names = self._names()
            order = {r["id"]: k for k, r in enumerate(rows)}
            hist = self.conn.execute(
                "SELECT v.form_id, v.number, v.approved_at, v.approved_by, v.uploaded_by, v.note, "
                "IFNULL(s.decision_note, '') AS memo FROM versions v "
                "LEFT JOIN submissions s ON s.id = v.submission_id ORDER BY v.form_id, v.number").fetchall()
            by_id = {r["id"]: r for r in rows}
            for h in hist:
                f = by_id.get(h["form_id"])
                if f is None:
                    continue
                out["history"].append({
                    "form_id": f["id"], "doc_no": f["doc_no"], "name": f["name"], "number": h["number"],
                    "approved_at": str(h["approved_at"] or ""), "approver": names.get(h["approved_by"], ""),
                    "uploader": names.get(h["uploaded_by"], ""),
                    "reason": h["note"] or (f"(승인 메모) {h['memo']}" if h["memo"] else "")})
            out["history"].sort(key=lambda h: (order[h["form_id"]], h["number"]))
        return out

    def due_forms(self, actor_id) -> list[dict]:
        """정기 검토 기한이 지났거나(overdue) 30일 안에 오는(soon) 양식 — 관리자는 전체, 검토자는 맡은 폴더,
        직원은 빈 목록. 지난 것 먼저, 기한 이른 것부터."""
        actor = self._actor(actor_id)
        if actor["role"] not in ("admin", "reviewer"):
            return []
        rows = self._register_rows(self.reviewable_folders(actor_id), include_retired=False)
        due = [r for r in rows if r["state"] in ("overdue", "soon")]
        due.sort(key=lambda r: (0 if r["state"] == "overdue" else 1, r["due"], r["doc_no"], r["name"]))
        return due

    @staticmethod
    def _last_base(months: int, limit: date, *, strict: bool) -> date:
        """add_months(b, months) < limit(strict) 또는 <= limit 인 가장 늦은 기준일 b. add_months는 b에 대해 줄지 않으므로
        (월말 접기로 같아질 뿐) 넉넉한 위(한 달 전 + 7일)에서 하루씩 내려온다 — 많아야 열흘 안팎."""
        b = add_months(limit, -months) + timedelta(days=7)
        while not (add_months(b, months) < limit if strict else add_months(b, months) <= limit):
            b -= timedelta(days=1)
        return b

    def due_counts(self, actor_id) -> tuple[int, int]:
        """(기한 지난 수, 30일 안에 오는 수) — 메뉴 숫자·첫 화면 띠용. 직원은 (0, 0).
        양식마다 파이썬으로 날짜를 셈하지 않고 SQL 한 번: 주기(개월) 값마다 '이 날 이하면 지남/곧'인 기준일을 미리 구해
        (review_state와 같은 규칙 — 시험이 대조) 글자 날짜끼리 비교한다. 폴더별로 세어 받아 범위만 파이썬에서 거른다
        (F7 검토 10 — 양식 3000개에서 매 화면 12ms → 아래 보고)."""
        actor = self._actor(actor_id)
        if actor["role"] not in ("admin", "reviewer"):
            return 0, 0
        scope = self.reviewable_folders(actor_id)
        dflt = self.default_review_months()
        t = self.today()
        soon_limit = t + timedelta(days=REVIEW_SOON_DAYS)
        months = {int(r[0]) for r in self.conn.execute(
            "SELECT DISTINCT review_months FROM forms WHERE review_months IS NOT NULL").fetchall()}
        months.add(dflt)
        th = [(m, self._last_base(m, t, strict=True).isoformat(), self._last_base(m, soon_limit, strict=False).isoformat())
              for m in sorted(months) if m > 0]
        if not th:
            return 0, 0
        values = ", ".join("(?, ?, ?)" for _ in th)
        args = [x for row in th for x in row] + [dflt]
        rows = self.conn.execute(
            f"WITH th(m, o, s) AS (VALUES {values}), "
            "b AS (SELECT f.folder_id AS fo, IFNULL(f.review_months, ?) AS m, "
            "MAX(IFNULL(substr(f.last_reviewed_at, 1, 10), ''), IFNULL(substr(v.approved_at, 1, 10), '')) AS base "
            "FROM forms f JOIN versions v ON v.id = f.current_version_id WHERE f.retired = 0) "
            "SELECT b.fo, SUM(b.base <= th.o), SUM(b.base > th.o AND b.base <= th.s) "
            "FROM b JOIN th ON th.m = b.m WHERE b.base != '' GROUP BY b.fo", args).fetchall()
        over = soon = 0
        for fo, o, s in rows:
            if scope is None or fo in scope:
                over += int(o or 0)
                soon += int(s or 0)
        return over, soon

    def overdue_count(self, actor_id) -> int:
        """기한 지난 양식 수 — 메뉴 숫자용. 직원은 0."""
        return self.due_counts(actor_id)[0]


def _group_detail(what: str, n: int, first: str, last: str, names: list, more: int,
                  label: str = "시도한 아이디") -> str:
    """묶은 감사 기록 한 줄의 내용 — 'N회 실패 (첫 때~마지막 때) · 시도한 아이디: …'."""
    span = first[11:19] if n == 1 else f"{first[11:19]}~{last[11:19]}"
    shown = ", ".join(x if x else "(빈칸)" for x in names)
    if more:
        shown += f" 외 {more}개"
    return f"{n}회 {what} ({span}) · {label}: {shown}"[:2000]


# ── 행 → 사전 ─────────────────────────────────────────────────────────────

def _user_dict(r) -> dict:
    return {"id": r["id"], "login": r["login"], "display_name": r["display_name"], "role": r["role"],
            "disabled": bool(r["disabled"]), "must_change": bool(r["must_change"]),
            "created_at": r["created_at"],
            "email": (r["email"] if "email" in r.keys() else "") or ""}            # 알림 메일 주소 (F4)


def _folder_dict(r) -> dict:
    return {"id": r["id"], "parent_id": r["parent_id"], "name": r["name"], "created_at": r["created_at"],
            "sort": int(r["sort"] or 0) if "sort" in r.keys() else 0,                # 폴더 차례 (f6)
            "code": (r["code"] if "code" in r.keys() else "") or ""}                 # 번호 머리 (F7)


def _form_dict(r) -> dict:
    return {"id": r["id"], "folder_id": r["folder_id"], "name": r["name"], "category": r["category"],
            "retired": bool(r["retired"]), "current_version_id": r["current_version_id"],
            "current_number": r["cur_number"], "current_filename": r["cur_filename"],
            "current_sha256": r["cur_sha256"], "current_size": r["cur_size"],
            "current_approved_at": r["cur_approved_at"],
            "current_uploaded_by_name": r["cur_uploaded_by_name"] or "",   # 목록의 '올린 사람' (F2)
            "retired_reason": r["retired_reason"] or "", "retired_by_name": r["retired_by_name"] or "",
            "retired_at": r["retired_at"],                                   # 폐기 사유·누가·언제 (F3)
            "created_at": r["created_at"],
            # 문서번호·검토 주기·최근 검토 (F7) — 이주 6 전 행이면 빈 값
            "doc_no": (r["doc_no"] if "doc_no" in r.keys() else "") or "",
            "doc_no_manual": bool(r["doc_no_manual"]) if "doc_no_manual" in r.keys() else False,   # 손 번호 (이주 7)
            "review_months": r["review_months"] if "review_months" in r.keys() else None,
            "last_reviewed_at": r["last_reviewed_at"] if "last_reviewed_at" in r.keys() else None,
            # 문서 종류 (이주 8) — id·기호·이름·사용 중인가. 종류가 없으면 None·빈 글자
            "doc_type_id": r["doc_type"] if "doc_type" in r.keys() else None,
            "doc_type": (r["dt_code"] if "dt_code" in r.keys() else "") or "",
            "doc_type_name": (r["dt_name"] if "dt_name" in r.keys() else "") or "",
            "doc_type_active": bool(r["dt_active"]) if "dt_active" in r.keys() and r["dt_active"] is not None else True}


def _version_dict(r, names: dict) -> dict:
    return {"id": r["id"], "form_id": r["form_id"], "number": r["number"], "filename": r["filename"],
            "sha256": r["sha256"], "size": r["size"], "note": r["note"],
            "uploaded_by": r["uploaded_by"], "uploaded_by_name": names.get(r["uploaded_by"], ""),
            "uploaded_at": r["uploaded_at"],
            "approved_by": r["approved_by"], "approved_by_name": names.get(r["approved_by"], ""),
            "approved_at": r["approved_at"]}


def _submission_dict(r, names: dict) -> dict:
    return {"id": r["id"], "kind": r["kind"], "folder_id": r["folder_id"], "form_id": r["form_id"],
            "form_name": r["form_name"], "category": r["category"], "filename": r["filename"],
            "sha256": r["sha256"], "size": r["size"], "note": r["note"], "status": r["status"],
            "reason": r["reason"], "submitted_by": r["submitted_by"],
            "submitted_by_name": names.get(r["submitted_by"], ""), "submitted_at": r["submitted_at"],
            "decided_by": r["decided_by"], "decided_by_name": names.get(r["decided_by"], ""),
            "decided_at": r["decided_at"], "version_id": r["version_id"],
            "decision_note": r["decision_note"] or "",                     # 승인 메모 (F3)
            "doc_type_id": r["doc_type"] if "doc_type" in r.keys() else None}   # 고른 문서 종류 (이주 8)
