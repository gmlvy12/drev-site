# -*- coding: utf-8 -*-
"""양식함 사내망 화면 서버 (FORMS.md 3·4·6절, 2026-10-28 F2).

- 표준 라이브러리 http.server(ThreadingHTTPServer)만 쓴다. 저장·권한은 store.FormsStore, 계정은 auth.
  이 모듈은 파일을 쓰지 않는다 — 소켓으로 응답을 보낼 뿐(self.wfile.write 한 곳, tests/test_readonly.py).
- 화면: 로그인·로그아웃·비밀번호 바꾸기, 첫 관리자 만들기(Drev PC에서만), 양식함(폴더 트리·목록·검색),
  폴더 만들기·이름 바꾸기, 양식 올리기(검토 대기)·내 제출, 양식 상세·판 이력·내려받기,
  관리자(계정·폴더 관리(f6: 기본 분류 틀·옮기기·지우기·차례)·감사 기록), 검토(F3: 현행 판과 자동 비교·새 양식 요약·승인 메모·반려 사유),
  판끼리 비교(F3), 폐기·복원(F3, 사유 필수), 문서 관리 대장·문서번호·정기 검토(F7 — 대장 화면·엑셀·기한 목록·검토함),
  문서번호 규칙·다시 매기기(F7 번호 규칙 — 관리자 /admin/docno).
- 보안(6절): 상태를 바꾸는 요청은 전부 POST + 세션 + CSRF(로그인 전 화면은 이중 제출 쿠키). GET은 바꾸지 않는다.
  보안 헤더(CSP에 스크립트 없음·인라인 스타일 없음), HttpOnly·SameSite=Strict 쿠키, 모든 출력 html.escape,
  요청 줄·헤더 크기 상한, 느린 요청 끊기(감시 스레드), 동시 연결 상한, 본문을 읽기 전에 Content-Length로 413.
  오류는 화면에 Traceback을 보이지 않고 로그에만 남긴다. 인터넷 주소(공인 IP)에서 온 요청은 받지 않는다.
- 보안 검토 고침(2026-10-28): 비인증 POST 주소별 토큰 버킷(429), 주소 잠금·잠긴 주소 풀기 화면, GET /compare는 캐시만
  (계산은 POST [비교하기]), 검토 화면 자동 비교는 대기 1건당 1회, 정리 일 스레드(대기 파일 보존 기간·실패 행).
- 손으로 띄우기: python -m watcher.forms.server --data <데이터 폴더> --host <사내망 IP> --port 8766
  (forms-serve 명령·DrevForms 예약 작업·방화벽은 F4.)
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import html
import ipaddress
import logging
import os
import re
import secrets
import socket
import sys
import threading
import time
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

from watcher.forms import auth
from watcher.forms.compare import COMPARE_TIMEOUT, Comparer
from watcher.forms.notify import Notifier
from watcher.forms.publish import Mirror
from watcher.forms import catalog, ledger
from watcher.forms.store import (ALLOWED_EXTS, AUDIT_MAX_ROWS, DOCNO_DIGITS_MAX, DOCNO_DIGITS_MIN, DOCNO_PRESETS,
                                 MAX_DOC_NO, MAX_DOCNO_PATTERN, MAX_UPLOAD_BYTES, PENDING_KEEP_DAYS, REVIEW_MONTHS_MAX,
                                 REVIEW_SOON_DAYS, Conflict, FormsError, FormsStore, InvalidInput, NotFound,
                                 PermissionDenied, level_name, now_text, parse_docno_pattern, rule_uses_type,
                                 MAX_DOC_TYPE_NAME)

log = logging.getLogger("drev.forms.server")

DEFAULT_PORT = 8766
SESSION_COOKIE = "drev_forms"
PRE_COOKIE = "drev_forms_pre"         # 로그인 전 화면(로그인·첫 관리자)의 CSRF 이중 제출 쿠키
THEME_COOKIE = "drev_forms_theme"
RETIRED_PREFIX = "[폐기] "               # 폐기된 양식을 내려받을 때 파일 이름 앞에 (F3)
MAX_REQUEST_LINE = 8 * 1024
MAX_HEADER_BYTES = 32 * 1024
MAX_HEADERS = 60
MAX_FORM_BODY = 64 * 1024              # 올리기가 아닌 POST(글자 칸만)
DISCARD_BODY_MAX = 64 * 1024           # 읽지 않고 답할 때 그래도 읽어 버리는 본문 상한 (Windows RST 방지)
MULTIPART_SLACK = 1024 * 1024          # 올리기 본문 = 파일 상한 + 이만큼(경계·다른 칸)
MAX_CONNECTIONS = 64
HEADER_SECONDS = 20.0                  # 요청 줄·헤더를 이 안에 다 보내야 한다
BODY_MIN_RATE = 128 * 1024             # 본문·응답은 최소 이 속도(바이트/초) + 30초 여유
SOCKET_TIMEOUT = 20                    # 한 번 읽기·쓰기가 이만큼 멈추면 끊는다

ROLE_LABEL = {"admin": "관리자", "reviewer": "검토자", "member": "직원"}
STATUS_LABEL = {"pending": "검토 대기", "approved": "승인됨", "rejected": "반려됨", "cancelled": "취소함"}
KIND_LABEL = {"new": "새 양식", "revision": "개정안"}
ACTION_LABEL = {
    "admin_bootstrap": "첫 관리자 만듦", "user_create": "계정 등록", "user_disable": "계정 정지",
    "user_enable": "계정 복구", "user_role": "역할 바꿈", "password_reset": "비밀번호 초기화",
    "password_change": "비밀번호 바꿈", "login": "로그인", "login_fail": "로그인 실패",
    "login_locked": "잠긴 동안 로그인 시도", "login_disabled": "정지 계정 로그인 시도", "logout": "로그아웃",
    "folder_create": "폴더 만듦", "folder_rename": "폴더 이름 바꿈", "folder_reviewers": "검토자 지정",
    "folder_move": "폴더 옮김", "folder_delete": "폴더 지움", "folder_order": "폴더 차례 바꿈",
    "folder_template": "기본 분류 틀 만듦",
    "submit": "올림", "approve": "승인", "reject": "반려", "cancel": "제출 취소",
    "download": "내려받음", "download_submission": "대기 파일 열어 봄", "retire": "폐기", "restore": "복원",
    "compare_fail": "자동 비교 실패",
    "user_email": "메일 주소 바꿈", "notify": "메일 알림 보냄", "notify_fail": "메일 알림 실패",
    "mirror_fail": "현행 미러 실패", "mirror_skip": "현행 미러 건너뜀",
    "ip_locked": "접속 주소 잠김", "ip_unlock": "접속 주소 잠금 풀기", "pending_purge": "대기 파일 정리",
    # 문서 관리 대장 (F7)
    "doc_no": "문서번호 고침", "doc_no_assign": "문서번호 일괄 매김", "folder_code": "폴더 번호 머리 바꿈",
    "review_months": "검토 주기 바꿈", "form_review": "정기 검토함", "register_export": "문서 관리 대장 내려받음",
    "doc_no_fallback": "문서번호 전역 꼴로 매김",
    "docno_rule": "문서번호 규칙 바꿈", "docno_renumber": "문서번호 다시 매김",          # F7 번호 규칙
    # 문서 종류 (F7 문서 종류)
    "doc_type_create": "문서 종류 더함", "doc_type_code": "문서 종류 기호 바꿈", "doc_type_name": "문서 종류 이름 바꿈",
    "doc_type_inactive": "문서 종류 사용 중지", "doc_type_active": "문서 종류 다시 사용", "doc_type_delete": "문서 종류 지움",
    "doc_type_assign": "문서 종류 일괄 지정", "form_doc_type": "양식 문서 종류 바꿈",
    "submission_doc_type": "검토 대기 문서 종류 바꿈",
}
REVIEW_STATE = {"overdue": ("기한 지남", "overdue"), "soon": ("곧", "soon"), "ok": ("", ""),
                "off": ("검토 안 함", "off"), "retired": ("", "")}
# 비인증 화면(로그인·첫 관리자) POST의 주소(IP)별 토큰 버킷 — 순간 30번, 그 뒤 초당 1번 (2026-10-28 보안 F1)
RATE_CAPACITY = 30
RATE_PER_SECOND = 1.0
MAINT_SECONDS = 3600                   # 정리 일(대기 파일·실패 행)을 도는 간격(초) — 서버 시작 때 한 번 + 이만큼마다
_ERROR_TEXT = {
    400: "요청을 이해하지 못했습니다", 401: "로그인이 필요합니다", 403: "할 수 없는 일입니다",
    404: "없는 화면입니다", 405: "이 방법으로는 열 수 없는 주소입니다", 408: "요청이 너무 느려 끊었습니다",
    409: "지금 상태와 맞지 않습니다", 411: "본문 길이(Content-Length)가 필요합니다",
    413: "보낸 내용이 너무 큽니다", 414: "주소가 너무 깁니다", 415: "지원하지 않는 형식입니다",
    429: "잠시 뒤에 다시 해 주세요", 431: "요청 머리글이 너무 큽니다", 500: "문제가 생겼습니다",
    501: "지원하지 않는 요청입니다", 503: "접속이 많습니다 — 잠시 뒤에 다시 해 주세요",
}
_BUSY = ("HTTP/1.0 503 Service Unavailable\r\nContent-Type: text/plain; charset=utf-8\r\n"
         "Connection: close\r\nRetry-After: 5\r\nX-Content-Type-Options: nosniff\r\n\r\n"
         "busy\r\n").encode("ascii")

# 스크립트 없음, 인라인 스타일 없음 — 스타일은 /forms.css 하나 (FORMS.md 6절 CSP default-src 'self')
CSP = ("default-src 'self'; script-src 'none'; style-src 'self'; img-src 'self' data:; "
       "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")
SECURITY_HEADERS = (
    ("X-Frame-Options", "DENY"),
    ("Content-Security-Policy", CSP),
    ("X-Content-Type-Options", "nosniff"),
    ("Referrer-Policy", "same-origin"),
    ("Cache-Control", "no-store"),
    ("Cross-Origin-Opener-Policy", "same-origin"),
)

E = html.escape


class AlreadyRunning(FormsError):
    """같은 데이터 폴더로 양식함 서버가 이미 돌고 있다."""


class HttpError(Exception):
    """화면에 보일 HTTP 오류 (status, 쉬운 말)."""

    def __init__(self, status: int, message: str = ""):
        super().__init__(message)
        self.status = int(status)
        self.message = message or _ERROR_TEXT.get(self.status, "요청을 처리할 수 없습니다")


class MultipartError(ValueError):
    """올리기 본문(multipart/form-data)이 깨졌다 → 400."""


# ── 화면 모양 (Drev 감시 화면과 같은 토큰, 어두운·밝은 테마) ────────────────────────

_DARK_TOKENS = """
  --bg:#0C0E12; --panel:#14171D; --panel2:#1A1E26; --hover:#212634;
  --border:#232833; --border2:#333B4A; --line:#1E242F;
  --text:#E6E9EF; --text2:#CBD1DC; --text3:#ADB5C4; --muted:#AAB2C1; --muted2:#8E97A8;
  --link:#93A0FA; --accent:#4C5DE6; --accent2:#7C8CF8; --on-accent:#FFFFFF;
  --ok:#3FB950; --ok-strong:#4ADE80; --warn:#E3B341; --warn3:#EAB94E; --bad:#F47067; --bad-btn:#C62F2F;
  --tag-add:rgba(63,185,80,.14); --tag-mod:rgba(227,179,65,.14); --tag-rm:rgba(244,112,103,.15);
  --tag-done:rgba(124,140,248,.16); --note-warn:#2E2612; --note-info:#1B2140;
  --shadow:0 1px 3px rgba(0,0,0,.45); color-scheme:dark;"""

CSS = """/* Drev 양식함 — 감시 화면(web.py)과 같은 디자인 토큰. 기본은 OS 설정을 따르고 [테마] 단추로 고정 */
:root{
  --bg:#F2F4F8; --panel:#FFFFFF; --panel2:#F7F8FB; --hover:#EEF0F6;
  --border:#E3E6EE; --border2:#C9CEDB; --line:#EEF0F5;
  --text:#171C26; --text2:#2A303C; --text3:#454D5E; --muted:#596273; --muted2:#5F6B82;
  --link:#4353E8; --accent:#4353E8; --accent2:#5B6CF5; --on-accent:#FFFFFF;
  --ok:#0F8A3D; --ok-strong:#0F7A37; --warn:#B97800; --warn3:#8A5A05; --bad:#C62F2F; --bad-btn:#C62F2F;
  --tag-add:#E2F5E9; --tag-mod:#FBF0D9; --tag-rm:#FBE7E7; --tag-done:#E5E9FD;
  --note-warn:#FFF8E5; --note-info:#E8ECFE;
  --shadow:0 1px 3px rgba(23,28,38,.06), 0 1px 2px rgba(23,28,38,.04); color-scheme:light;
  --fs-s:13px; --fs-m:15px; --fs-l:17px;
}
@media (prefers-color-scheme: dark){ :root:not([data-theme=light]){""" + _DARK_TOKENS + """} }
:root[data-theme=dark]{""" + _DARK_TOKENS + """}
*{margin:0;box-sizing:border-box;font-family:'Pretendard','Malgun Gothic','Segoe UI Variable','Segoe UI',sans-serif}
body{background:var(--bg);color:var(--text);display:flex;min-height:100vh;-webkit-font-smoothing:antialiased}
a{color:var(--link);text-decoration:none} a:hover{text-decoration:underline}
.skip{position:absolute;left:-9999px;top:0;z-index:200;background:var(--accent);color:#fff;padding:8px 14px}
.skip:focus{left:0}
.side{width:216px;background:var(--panel);border-right:1px solid var(--border);padding:18px 12px;
  position:fixed;top:0;bottom:0;display:flex;flex-direction:column;overflow-y:auto}
.logo{font-weight:800;font-size:17px;color:var(--link);padding:6px 10px 16px}
.logo small{display:block;color:var(--muted);font-weight:400;font-size:12px;margin-top:3px}
.nav{flex:1}
.nav .grp{font-size:11px;color:var(--muted);letter-spacing:.6px;padding:12px 12px 4px}
.nav a{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;border-radius:9px;
  min-height:36px;color:var(--text3);font-size:14px;margin-bottom:2px}
.nav a:hover{background:var(--hover);color:var(--text);text-decoration:none}
.nav a.on{background:var(--accent);color:var(--on-accent);font-weight:700}
.cnt{display:inline-block;min-width:22px;padding:1px 7px;border-radius:999px;background:var(--tag-mod);
  color:var(--warn3);font-size:12px;font-weight:700;text-align:center}
.nav a.on .cnt{background:rgba(255,255,255,.25);color:#fff}
.me{border-top:1px solid var(--line);padding:12px 8px 4px;font-size:13px;color:var(--muted)}
.me b{display:block;color:var(--text);font-size:14px;margin-bottom:2px}
.me a{display:block;margin:8px 0 4px}
.me form{margin-top:6px}
.side .btn{width:100%}
.main{margin-left:216px;flex:1;min-width:0;padding:22px 30px;max-width:1500px}
.topbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:16px}
.topbar h1{font-size:20px;font-weight:800;letter-spacing:-.3px}
.crumb{font-size:var(--fs-s);color:var(--muted2);margin-bottom:6px}
.panel{background:var(--panel);border-radius:12px;padding:14px 18px;margin-bottom:12px;
  border:1px solid var(--border);box-shadow:var(--shadow);overflow-x:auto}
.panel h2{font-size:var(--fs-l);margin:0 0 10px;font-weight:700}
.panel h3{font-size:var(--fs-m);margin:14px 0 8px;font-weight:700}
.split{display:grid;grid-template-columns:250px minmax(0,1fr);gap:12px;align-items:start}
.tree ul{list-style:none;padding-left:14px;margin:2px 0}
.tree>ul{padding-left:0}
.tree li{margin:1px 0}
.tree a{display:block;padding:5px 8px;border-radius:8px;color:var(--text2);font-size:14px;word-break:break-all}
.tree a:hover{background:var(--hover);text-decoration:none}
.tree a.on{background:var(--tag-done);color:var(--link);font-weight:700}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.chips a{border:1px solid var(--border);border-radius:999px;padding:4px 12px;font-size:13px;color:var(--text2);
  background:var(--panel2)}
table{width:100%;border-collapse:collapse;font-size:14px}
th{color:var(--muted);font-weight:600;text-align:left;padding:7px 10px;border-bottom:1px solid var(--border);
  font-size:12px;background:var(--panel2);white-space:nowrap}
td{padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top;font-variant-numeric:tabular-nums}
tr:hover td{background:var(--panel2)}
td.nw{white-space:nowrap}
.muted{color:var(--muted2);font-size:13px}
.panel>p.muted{margin-bottom:10px}
.empty{color:var(--muted);padding:18px 4px;text-align:center}
.tag{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;white-space:nowrap}
.tag.pending{background:var(--tag-mod);color:var(--warn3)}
.tag.approved{background:var(--tag-add);color:var(--ok-strong)}
.tag.rejected{background:var(--tag-rm);color:var(--bad)}
.tag.cancelled,.tag.retired,.tag.off{background:var(--hover);color:var(--muted)}
.tag.role{background:var(--tag-done);color:var(--link)}
.btn{display:inline-block;background:var(--accent);color:var(--on-accent);border:none;border-radius:9px;
  padding:6px 14px;min-height:32px;font-size:14px;cursor:pointer;font-weight:700;white-space:nowrap;line-height:20px}
.btn:hover{filter:brightness(1.08);text-decoration:none}
.btn.gray{background:var(--panel2);color:var(--text2);border:1px solid var(--border)}
.btn.red{background:var(--bad-btn);color:#fff}
.btn.sm{min-height:28px;padding:4px 10px;font-size:13px}
form.inline{display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap;margin:2px 0}
label{display:block;margin:10px 0 4px;font-size:13px;color:var(--muted)}
label.chk{display:inline-flex;align-items:center;gap:6px;margin:4px 12px 4px 0;color:var(--text2);font-size:14px}
input[type=text],input[type=password],input[type=search],input[type=file],input[type=email],select,textarea{
  border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:14px;
  background:var(--panel);color:var(--text);max-width:100%}
input[type=text],input[type=password],select.wide,textarea{width:420px}
input:focus,select:focus,textarea:focus{outline:2px solid var(--accent2);border-color:var(--accent)}
.form-actions{margin-top:14px;display:flex;gap:8px;flex-wrap:wrap}
.searchbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
.searchbar input[type=search]{width:280px}
.note{border-radius:10px;padding:10px 14px;margin-bottom:12px;border:1px solid var(--border);font-size:14px}
.note.ok{background:var(--tag-add);color:var(--text)}
.note.bad{background:var(--tag-rm);color:var(--text);border-left:4px solid var(--bad)}
.note.info{background:var(--note-info);color:var(--text)}
.note.warn{background:var(--note-warn);color:var(--text)}
.secret{font-family:Consolas,'Courier New',monospace;font-size:22px;font-weight:700;letter-spacing:1px;
  padding:10px 14px;border:1px dashed var(--border2);border-radius:10px;display:inline-block;margin:8px 0;
  background:var(--panel2);user-select:all}
details.tool{margin:6px 0}
details.tool>summary{cursor:pointer;color:var(--link);font-size:14px;display:inline-block}
details.tool[open]{background:var(--panel2);border-radius:10px;padding:8px 12px}
.later{color:var(--muted);font-size:13px;border:1px dashed var(--border2);border-radius:10px;padding:8px 12px;margin-top:10px}
.authwrap{margin:8vh auto;max-width:440px;width:100%;padding:0 16px}
.authwrap .logo{text-align:center;padding-bottom:18px}
.authwrap .panel{padding:22px 24px}
.authwrap input[type=text],.authwrap input[type=password]{width:100%}
.pager{display:flex;gap:8px;margin-top:10px}
/* 자동 비교 근거 표 (F3) — 이전 값은 취소선, 새 값은 강조, 바뀐 낱말은 색 */
.tag.k-add{background:var(--tag-add);color:var(--ok-strong)}
.tag.k-mod{background:var(--tag-mod);color:var(--warn3)}
.tag.k-rm{background:var(--tag-rm);color:var(--bad)}
.tag.k-info{background:var(--hover);color:var(--muted)}
.cmp-head{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:baseline;margin:0 0 10px;font-size:14px}
.cmp-head b{font-size:16px}
table.cmp td{font-size:14px;word-break:break-word}
table.cmp td.name{min-width:110px}
table.cmp td.val{min-width:140px;max-width:420px}
del.old{text-decoration:line-through;color:var(--muted)}
del.old .hl{background:var(--tag-rm);color:var(--bad);border-radius:3px}
ins.new{text-decoration:none;font-weight:700;color:var(--text)}
ins.new mark{background:var(--tag-add);color:var(--ok-strong);border-radius:3px;padding:0 1px}
.none{color:var(--muted2)}
ul.notes{margin:8px 0 0 18px;color:var(--muted2);font-size:13px}
ul.lines{margin:4px 0 0 18px;font-size:14px}
.kv{display:grid;grid-template-columns:120px minmax(0,1fr);gap:6px 12px;font-size:14px;margin-bottom:6px}
.kv dt{color:var(--muted)} .kv dd{margin:0;word-break:break-word}
.cols{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 8px}
.cols span{border:1px solid var(--border);border-radius:6px;padding:2px 8px;font-size:13px;background:var(--panel2)}
.decide{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}
.decide textarea{width:100%;min-height:64px}
.pick{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
/* 메일 알림·구독 (F4) */
input[type=email]{width:240px}
.sub{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0 10px;font-size:13px;color:var(--muted)}
/* 판 이력 표 (f6) — 판·날짜·이름은 줄바꿈 없이, 설명·파일 칸이 줄어든다. 좁으면 표만 가로로 밀린다 */
.tablewrap{overflow-x:auto;max-width:100%}
table.hist td.note-c{min-width:9em;word-break:keep-all;overflow-wrap:anywhere}
table.hist td.file-c{min-width:7em;overflow-wrap:anywhere;word-break:break-all}
table.hist td.acts{min-width:8.5em}
table.hist .dt{word-break:keep-all;min-width:6em}          /* 날짜와 시각 사이에서만 줄을 바꾼다 */
span.nw{white-space:nowrap}
/* 양식 목록 표 — 이름·폴더가 한두 글자씩 꺾이지 않게 최소 폭, 낱말 단위로만 줄바꿈 */
table.flist td.name-c{min-width:6em;word-break:keep-all}
table.flist td.path-c{min-width:6.5em;word-break:keep-all}
table.hist td.acts .btn{margin:2px 0}
/* 폴더 층·관리 (f6) */
.tag.lvl{background:var(--hover);color:var(--muted);font-weight:600;margin-left:4px;vertical-align:1px}
table.ftree td{vertical-align:top}
table.ftree td.fname{min-width:10em;word-break:keep-all}
.tree p a{display:inline;padding:0}
table.ftree td.lv1{padding-left:28px} table.ftree td.lv2{padding-left:46px} table.ftree td.lv3{padding-left:64px}
table.ftree td.lv4{padding-left:82px} table.ftree td.lv5{padding-left:100px} table.ftree td.lv6{padding-left:118px}
table.ftree details.tool[open]{min-width:280px}
table.ftree form{margin:4px 0}
table.ftree input[type=text]{width:200px}
.order{display:inline-flex;gap:6px;flex-wrap:wrap;margin:4px 0}
.tplgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:8px 16px;margin:8px 0}
.tpl{border:1px solid var(--border);border-radius:10px;padding:8px 12px;background:var(--panel2)}
.tpl .muted{display:block}
/* 문서 관리 대장·문서번호·정기 검토 (F7) — 넓은 표는 .tablewrap 안에서만 가로로 밀린다 */
.docno{font-family:Consolas,'Courier New',monospace;font-size:12px;color:var(--muted2);letter-spacing:.2px}
td .docno{display:block}
.tag.code{background:var(--tag-done);color:var(--link);font-family:Consolas,'Courier New',monospace;margin-left:4px;
  vertical-align:1px}
.tag.overdue{background:var(--tag-rm);color:var(--bad)}
.tag.soon{background:var(--tag-mod);color:var(--warn3)}
table.reg td{font-size:13px}
table.reg td.reason{min-width:12em;overflow-wrap:anywhere}
table.reg td.name-c{min-width:8em;word-break:keep-all}
table.reg td.path-c{min-width:5em;word-break:keep-all}
table.due td.act{min-width:17em}
input[type=text].code,input[type=text].docno-in{width:12em}
/* 문서번호 규칙·다시 매기기 (F7 번호 규칙) */
input[type=text].pattern{width:24em;font-family:Consolas,'Courier New',monospace}
.docno.big{font-size:14px;color:var(--text)}
.prevno{display:block;font-size:11px;color:var(--muted)}
.presets{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:10px 0 4px}
.presets .btn{font-family:Consolas,'Courier New',monospace}
ul.tokens code{font-family:Consolas,'Courier New',monospace;font-weight:700}
table.docex td.path-c,table.renum td.path-c{min-width:8em;word-break:keep-all}
table.renum td.name-c{min-width:8em;word-break:keep-all}
input[type=text].memo{width:15em}
input[type=text].months{width:5em}
/* 문서 종류 (F7 문서 종류) */
.tag.dtype{background:var(--tag-done);color:var(--text);font-family:Consolas,'Courier New',monospace;margin-right:4px;
  vertical-align:1px}
table.dtypes td.name-c{min-width:8em;word-break:keep-all}
table.dtypes form{margin:2px 0}
input[type=text].tname{width:12em}
.typewarn{color:var(--warn3);font-size:12px}
.reviewinfo{display:flex;flex-wrap:wrap;gap:4px 18px;margin:0 0 8px;font-size:14px}
@media (max-width:860px){
  body{display:block}
  .side{position:static;width:auto;border-right:none;border-bottom:1px solid var(--border)}
  .main{margin-left:0;padding:16px}
  .split{grid-template-columns:minmax(0,1fr)}
  input[type=text],input[type=password],select.wide,textarea{width:100%}
  table.ftree input[type=text]{width:100%}
  .searchbar input[type=search]{width:100%}
}
"""


def _fmt_time(value) -> str:
    """'2026-10-28T14:03:22' → '2026-10-28 14:03'."""
    s = str(value or "")
    return " ".join(s.split("T", 1))[:16] if s else ""     # str.replace는 test_readonly 이름 검사에 걸린다


def _fmt_size(n) -> str:
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f}KB"
    return f"{n / (1024 * 1024):.1f}MB"


def _flatten(tree, depth: int = 0, prefix: tuple = ()):
    """폴더 트리 → (폴더, 깊이, '맨위 / 하위' 경로) 차례."""
    for node in tree:
        path = prefix + (node["name"],)
        yield node, depth, " / ".join(path)
        yield from _flatten(node["children"], depth + 1, path)


def content_disposition(filename: str) -> str:
    """내려받기 이름 — 한글은 filename*=UTF-8''…, 옛 브라우저용 ASCII 대체 이름도 함께."""
    fallback = "".join(c if 32 <= ord(c) < 127 and c not in '"\\;%' else "_" for c in filename) or "download"
    return f"attachment; filename=\"{fallback}\"; filename*=UTF-8''{quote(filename, safe='')}"


def _safe_back(to: str) -> str:
    """돌아갈 곳은 이 서버 안의 경로만 — 다른 사이트로 보내지 않는다 (web._safe_back 과 같은 규칙)."""
    to = "".join(ch for ch in (to or "") if ch >= " " and ch != "\x7f").strip()
    if not to.startswith("/") or to.startswith("//") or to.startswith("/\\"):
        return "/forms"
    return to


def _is_loopback(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(str(ip).split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped is not None:
        a = a.ipv4_mapped
    return a.is_loopback


def _is_internet(ip: str) -> bool:
    """공인(인터넷) 주소인가 — 사내망 전용 서버라 그런 곳에서 온 요청은 받지 않는다 (원칙 1)."""
    try:
        a = ipaddress.ip_address(str(ip).split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped is not None:
        a = a.ipv4_mapped
    return a.is_global


def check_bind_host(host: str) -> str:
    """바인드 주소 검사 — IP 글자(또는 localhost)만, 공인 주소는 거부한다 (사내망 전용, 공유기 포트 개방 금지)."""
    h = str(host or "").strip()
    if h.lower() == "localhost":
        return "127.0.0.1"
    try:
        a = ipaddress.ip_address(h)
    except ValueError:
        raise FormsError("양식함 주소는 사내망 IP로 적어 주세요 (예: 192.168.0.10, 모두: 0.0.0.0)")
    if a.is_global:
        raise FormsError("인터넷(공인) 주소에는 양식함을 열 수 없습니다 — 사내망 주소를 적어 주세요")
    return h


# ── 올리기 본문(multipart/form-data) — cgi 모듈 없이 직접 읽는다 ───────────────────────

_BOUNDARY_RE = re.compile(r"^[0-9A-Za-z'()+_,\-./:=? ]{1,70}$")


def _header_params(value: str) -> tuple[str, dict]:
    """'form-data; name="a"; filename="b.xlsx"' → ('form-data', {'name': 'a', 'filename': 'b.xlsx'}).

    브라우저(HTML 표준)는 따옴표 안의 '"'·줄바꿈을 %22·%0A로 바꿔 보내고 역슬래시는 그대로 둔다 —
    그래서 따옴표 안은 다음 따옴표까지 글자 그대로 읽는다(옛 IE의 'C:\\a\\b.xlsx'도 그대로)."""
    s, i, n = value, 0, len(value)
    j = s.find(";")
    main = (s if j < 0 else s[:j]).strip().lower()
    i = n if j < 0 else j + 1
    params: dict = {}
    while i < n:
        while i < n and s[i] in " \t;":
            i += 1
        if i >= n:
            break
        eq = s.find("=", i)
        if eq < 0:
            raise MultipartError("머리글 값이 깨졌습니다")
        key = s[i:eq].strip().lower()
        i = eq + 1
        while i < n and s[i] in " \t":
            i += 1
        if i < n and s[i] == '"':
            end = s.find('"', i + 1)
            if end < 0:
                raise MultipartError("따옴표가 닫히지 않았습니다")
            val, i = s[i + 1:end], end + 1
        else:
            end = s.find(";", i)
            end = n if end < 0 else end
            val, i = s[i:end].strip(), end
        if not key or key in params:
            raise MultipartError("머리글 값이 겹치거나 비었습니다")
        params[key] = val
    return main, params


def _rfc5987(value: str) -> str:
    """filename*=UTF-8''%EC%9E%94… 풀기."""
    from urllib.parse import unquote
    charset, _, rest = value.partition("'")
    _lang, _, enc = rest.partition("'")
    if charset.strip().lower() not in ("utf-8", "utf8") or not _:
        raise MultipartError("파일 이름 인코딩을 모릅니다")
    return unquote(enc, encoding="utf-8", errors="strict")


def boundary_of(content_type: str) -> bytes:
    main, params = _header_params(str(content_type or ""))
    if main != "multipart/form-data":
        raise MultipartError("올리기 형식(multipart/form-data)이 아닙니다")
    b = params.get("boundary", "")
    if not _BOUNDARY_RE.match(b) or b.endswith(" "):
        raise MultipartError("경계 표시(boundary)가 잘못됐습니다")
    return b.encode("ascii")


def parse_multipart(body: bytes, boundary: bytes, *, max_parts: int = 20,
                    max_field: int = MAX_FORM_BODY) -> tuple[dict, dict]:
    """multipart/form-data 본문 → (글자 칸 {이름: [값…]}, 파일 칸 {이름: (파일 이름, 바이트)}).

    깨진 본문은 MultipartError(→ 400). 끝 표시(--경계--)가 없으면 덜 온 것으로 본다."""
    delim = b"--" + boundary
    data = b"\r\n" + bytes(body)
    sep = b"\r\n" + delim
    pieces = data.split(sep)
    if len(pieces) < 2:
        raise MultipartError("경계 표시가 본문에 없습니다")
    fields: dict = {}
    files: dict = {}
    closed = False
    for count, piece in enumerate(pieces[1:], start=1):
        if piece.startswith(b"--"):
            closed = True
            break
        if count > max_parts:
            raise MultipartError("칸이 너무 많습니다")
        piece = piece.lstrip(b" \t")
        if not piece.startswith(b"\r\n"):
            raise MultipartError("경계 뒤 줄바꿈이 없습니다")
        head, mark, content = piece[2:].partition(b"\r\n\r\n")
        if not mark:
            raise MultipartError("칸 머리글이 끝나지 않았습니다")
        if len(head) > 8192:
            raise MultipartError("칸 머리글이 너무 깁니다")
        try:
            head_text = head.decode("utf-8")
        except UnicodeDecodeError:
            raise MultipartError("칸 머리글 글자가 깨졌습니다")
        disp = None
        for line in head_text.split("\r\n"):
            name, colon, value = line.partition(":")
            if not colon:
                raise MultipartError("칸 머리글 줄이 깨졌습니다")
            if name.strip().lower() == "content-disposition":
                if disp is not None:
                    raise MultipartError("칸 머리글이 겹칩니다")
                disp = value.strip()
        if disp is None:
            raise MultipartError("칸 이름(Content-Disposition)이 없습니다")
        kind, params = _header_params(disp)
        if kind != "form-data" or not params.get("name"):
            raise MultipartError("칸 이름이 없습니다")
        fname = params["name"]
        if "filename*" in params:
            filename = _rfc5987(params["filename*"])
        else:
            filename = params.get("filename")
        if filename is not None:
            if fname in files:
                raise MultipartError("파일 칸이 겹칩니다")
            files[fname] = (filename, content)
        else:
            if len(content) > max_field:
                raise MultipartError("글자 칸이 너무 깁니다")
            try:
                fields.setdefault(fname, []).append(content.decode("utf-8"))
            except UnicodeDecodeError:
                raise MultipartError("글자 칸이 깨졌습니다")
    if not closed:
        raise MultipartError("본문 끝 표시가 없습니다 — 덜 왔거나 깨졌습니다")
    return fields, files


# ── 단일 실행 잠금 (파일을 쓰지 않는 Windows 이름 있는 뮤텍스) ─────────────────────────

class InstanceLock:
    """같은 데이터 폴더로 서버가 두 번 뜨지 않게 — 커널 뮤텍스라 프로세스가 죽으면 저절로 풀린다."""

    def __init__(self, data_dir):
        key = os.path.normcase(os.path.abspath(str(data_dir)))
        self.name = "Local\\DrevForms-" + hashlib.sha256(key.encode("utf-8")).hexdigest()[:24]
        self._handle = None

    def acquire(self) -> bool:
        if os.name != "nt":           # Drev는 Windows 전용 — 다른 곳에서는 포트 독점에 맡긴다
            return True
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
        k32.CreateMutexW.restype = wintypes.HANDLE
        k32.CloseHandle.argtypes = (wintypes.HANDLE,)
        h = k32.CreateMutexW(None, False, self.name)
        err = ctypes.get_last_error()
        if not h:
            raise OSError(err, "단일 실행 잠금을 만들 수 없습니다")
        if err == 183:                # ERROR_ALREADY_EXISTS
            k32.CloseHandle(h)
            return False
        self._handle = h
        return True

    def release(self) -> None:
        if self._handle:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.CloseHandle.argtypes = (wintypes.HANDLE,)
            k32.CloseHandle(self._handle)
            self._handle = None


# ── 서버 ────────────────────────────────────────────────────────────────────

class RateLimiter:
    """주소(IP)별 토큰 버킷 — 메모리만 쓴다(DB에 아무것도 적지 않는다). 2026-10-28 보안 F1.

    capacity번까지는 한꺼번에 받고, 그 뒤로는 초당 per_second번씩 다시 채워진다. 열쇠(주소)가 너무 많으면
    가득 찬(=한동안 조용한) 것부터 버려 메모리도 끝없이 늘지 않는다. clock: 시험에서 바꿔 끼운다."""

    def __init__(self, capacity: int = RATE_CAPACITY, per_second: float = RATE_PER_SECOND, *, clock=time.monotonic,
                 max_keys: int = 10000):
        self.capacity = float(max(1, int(capacity)))
        self.per_second = max(0.001, float(per_second))
        self.clock = clock
        self.max_keys = int(max_keys)
        self._b: dict = {}
        self._lock = threading.Lock()

    def take(self, key: str) -> float:
        """한 번 쓰기. 받으면 0, 넘쳤으면 다음 한 번까지 기다릴 초."""
        now = float(self.clock())
        with self._lock:
            tokens, at = self._b.get(key, (self.capacity, now))
            tokens = min(self.capacity, tokens + max(0.0, now - at) * self.per_second)
            if tokens >= 1.0:
                self._b[key] = (tokens - 1.0, now)
                if len(self._b) > self.max_keys:
                    self._prune(now)
                return 0.0
            self._b[key] = (tokens, now)
            return (1.0 - tokens) / self.per_second

    def _prune(self, now: float) -> None:
        full = [k for k, (t, at) in self._b.items()
                if t + max(0.0, now - at) * self.per_second >= self.capacity]
        for k in full:
            self._b.pop(k, None)
        if len(self._b) > self.max_keys:                 # 그래도 많으면 가장 오래 조용한 것부터
            for k, _ in sorted(self._b.items(), key=lambda kv: kv[1][1])[:len(self._b) - self.max_keys]:
                self._b.pop(k, None)

    def prune(self) -> None:
        with self._lock:
            self._prune(float(self.clock()))


class FormsHTTPServer(ThreadingHTTPServer):
    """요청마다 스레드. 저장소(FormsStore) 하나를 스레드끼리 같이 쓴다(F1이 잠금으로 보장).

    - 포트 독점(SO_EXCLUSIVEADDRUSE): 윈도우는 SO_REUSEADDR이면 두 프로세스가 같은 포트를 나눠 잡는다(web.py 2026-08-31).
    - 동시 연결 상한: 넘치면 바로 503으로 끊는다.
    - 느린 요청 끊기: 감시 스레드가 마감이 지난 연결을 shutdown 한다(헤더를 한 글자씩 보내며 버티기 방지)."""

    daemon_threads = True
    block_on_close = False
    allow_reuse_address = False
    request_queue_size = 32

    def __init__(self, address, handler, store: FormsStore, *, max_connections: int = MAX_CONNECTIONS):
        self.store = store
        self.comparer: Comparer | None = None        # 자동 비교기 (F3) — make_server가 붙인다
        self.mirror: Mirror | None = None            # 현행 미러 (F4, 설정했을 때만)
        self.notifier: Notifier | None = None        # 메일 알림 (F4, 켰을 때만)
        self.header_seconds = HEADER_SECONDS
        self.body_min_rate = BODY_MIN_RATE
        self._slots = threading.BoundedSemaphore(max_connections)
        self._conns: dict = {}
        self._conns_lock = threading.Lock()
        self._flash: dict = {}
        self._flash_lock = threading.Lock()
        self._stop = threading.Event()
        self.limiter = RateLimiter(clock=store.clock)     # 비인증 POST(로그인·첫 관리자) 주소별 상한 (보안 F1)
        self.pending_keep_days = float(PENDING_KEEP_DAYS)  # 반려·취소 대기 파일 보존 기간 (보안 F7)
        self._maint: threading.Thread | None = None
        super().__init__(address, handler)
        self._reaper = threading.Thread(target=self._reap, name="forms-reaper", daemon=True)
        self._reaper.start()

    # 정리 일 (2026-10-28 보안 F1·F7) — 대기 파일 보존 기간 지난 것, 지난 로그인 실패 행, 버킷 메모리
    def maintain(self) -> dict:
        out = {"purged": [], "failures": 0}
        try:
            out["purged"] = self.store.purge_pending(days=self.pending_keep_days)
        except Exception:
            log.exception("양식함: 대기 파일 정리 실패")
        try:
            out["failures"] = auth.cleanup_failures(self.store)
        except Exception:
            log.exception("양식함: 로그인 실패 기록 정리 실패")
        self.limiter.prune()
        return out

    def start_maintenance(self, interval: float = MAINT_SECONDS) -> None:
        if self._maint is not None:
            return

        def loop():
            while True:
                self.maintain()
                if self._stop.wait(float(interval)):
                    return
        self._maint = threading.Thread(target=loop, name="forms-maint", daemon=True)
        self._maint.start()

    def server_bind(self) -> None:
        if os.name == "nt":
            try:
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            except (OSError, AttributeError):
                pass
        super().server_bind()

    # 연결 상한
    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            try:
                request.sendall(_BUSY)
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    # 느린 요청 끊기
    def watch(self, key, sock, seconds: float) -> None:
        with self._conns_lock:
            self._conns[key] = (sock, time.monotonic() + seconds)

    def unwatch(self, key) -> None:
        with self._conns_lock:
            self._conns.pop(key, None)

    def _reap(self) -> None:
        while not self._stop.wait(0.25):
            now = time.monotonic()
            with self._conns_lock:
                late = [(k, s) for k, (s, dl) in self._conns.items() if dl < now]
                for k, _ in late:
                    self._conns.pop(k, None)
            for _, s in late:
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

    # 한 번 보이는 알림 (로그인 세션별)
    def flash_set(self, token: str, kind: str, msg: str) -> None:
        with self._flash_lock:
            if len(self._flash) > 2000:
                self._flash.clear()
            self._flash[hashlib.sha256(token.encode()).hexdigest()] = (kind, msg)

    def flash_pop(self, token: str):
        with self._flash_lock:
            return self._flash.pop(hashlib.sha256(token.encode()).hexdigest(), None)

    def handle_error(self, request, client_address) -> None:
        exc = sys.exception()
        if isinstance(exc, (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        log.exception("양식함 서버: 요청 처리 중 오류 (%s)", client_address[0] if client_address else "")

    def on_event(self, kind: str, **kw) -> None:
        """승인·반려·폐기·복원·폴더 이름 바꾸기 뒤의 뒷일 — 현행 미러 다시 맞추기, 메일 알림 (F4).
        여기서 무엇이 실패해도 화면 동작(이미 끝난 승인 등)은 그대로다. 실제 쓰기·보내기는 배경 스레드가 한다."""
        try:
            if self.mirror is not None and kind in ("approved", "retired", "restored", "folder_renamed",
                                                     "folder_moved", "folder_deleted"):
                self.mirror.request_sync()
        except Exception:
            log.exception("양식함: 현행 미러 요청 실패 (%s)", kind)
        n = self.notifier
        if n is None:
            return
        try:
            if kind == "approved":
                sid = kw["submission_id"]
                n.approved(sid)
                d = self.store.submission_notice(sid) or {}
                n.new_current(kw["result"]["version_id"], skip=(d.get("submitter_email"),))
            elif kind == "rejected":
                n.rejected(kw["submission_id"])
        except Exception:
            log.exception("양식함: 메일 알림 준비 실패 (%s)", kind)

    def server_close(self) -> None:
        self._stop.set()
        super().server_close()
        if self._maint is not None and self._maint is not threading.current_thread():
            self._maint.join(10)                       # 정리 일이 저장소를 쓰는 도중에 닫지 않게
        for part in (self.mirror, self.notifier):        # 배경 스레드(미러·메일)를 저장소보다 먼저 멈춘다
            if part is not None:
                try:
                    part.close()
                except Exception:
                    pass
        if self.comparer is not None:
            try:
                self.comparer.close()                # 비교 자식 프로세스를 끝낸다
            except Exception:
                pass
        try:
            self.store.close()
        except Exception:
            pass


def make_server(data_dir, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, mirror_root=None,
                max_upload_bytes: int | None = None, clock=None,
                max_connections: int = MAX_CONNECTIONS, compare_timeout: float = COMPARE_TIMEOUT,
                compare_command: list | None = None, notify_mail: dict | None = None,
                base_url: str = "", notify_send=None, audit_max_rows: int | None = None,
                pending_keep_days: float | None = None, rate_capacity: int = RATE_CAPACITY,
                rate_per_second: float = RATE_PER_SECOND, maintenance: bool = True,
                review_months_default: int | None = None) -> FormsHTTPServer:
    """양식함 서버를 만든다(아직 돌리지 않음). serve_forever()로 돌린다.

    host: 사내망 주소(공인 주소는 거부). 시험은 127.0.0.1 포트 0.
    max_upload_bytes: 올리기 상한(기본 50MB). clock: 시험용 시계(세션·잠금).
    compare_timeout: 자동 비교 한 번의 상한(초, 기본 60). compare_command: 비교 자식 명령(시험용).
    mirror_root: (F4) 현행 미러 폴더 — 주면 배경 스레드가 곧바로 전체를 맞춘다. 폴더가 지금 없어도(공유가 끊김)
      서버는 뜨고, 미러만 실패를 감사 기록에 남긴 뒤 나중에 다시 맞춘다.
    notify_mail: (F4) 메일 알림을 켤 때 감시의 `mail:` 설정(사내 SMTP). base_url: 메일의 '양식함에서 열기' 주소.
    notify_send: 시험용 보내기 함수.
    audit_max_rows: 감사 기록 보존 상한(행, 기본 20만). pending_keep_days: 반려·취소 대기 파일 보존(일, 기본 90).
    rate_capacity·rate_per_second: 비인증 POST(로그인·첫 관리자) 주소별 토큰 버킷. maintenance: 정리 일 스레드(기본 켬).
    review_months_default: (F7) 정기 검토 기본 주기(개월, 기본 12, 0 = 끔)."""
    h = check_bind_host(host)
    kw = {}
    if clock is not None:
        kw["clock"] = clock
    store = FormsStore(data_dir, **kw)
    if max_upload_bytes:
        store.max_upload_bytes = int(max_upload_bytes)
    if audit_max_rows:
        store.audit_max_rows = int(audit_max_rows)
    if review_months_default is not None:
        store.review_months_default = max(0, min(int(review_months_default), REVIEW_MONTHS_MAX))
    try:
        srv = FormsHTTPServer((h, int(port)), FormsHandler, store, max_connections=max_connections)
    except BaseException:
        store.close()
        raise
    srv.limiter = RateLimiter(rate_capacity, rate_per_second, clock=store.clock)
    if pending_keep_days is not None:
        srv.pending_keep_days = float(pending_keep_days)
    if maintenance:
        srv.start_maintenance()
    srv.comparer = Comparer(store, timeout=compare_timeout, command=compare_command)
    if notify_mail is not None:
        srv.notifier = Notifier(store, notify_mail, base_url=base_url, send=notify_send)
    if mirror_root:
        srv.mirror = Mirror(store, mirror_root)
        srv.mirror.start()                       # 서버 시작 때 전체 재동기화 (지난 실패를 따라잡는다)
    return srv


def serve(data_dir, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, mirror_root=None,
          max_upload_bytes: int | None = None, on_ready=None, compare_timeout: float = COMPARE_TIMEOUT,
          notify_mail: dict | None = None, base_url: str = "", audit_max_rows: int | None = None,
          pending_keep_days: float | None = None, review_months_default: int | None = None) -> None:
    """단일 실행 잠금을 잡고 서버를 돌린다(멈출 때까지). 이미 돌고 있으면 AlreadyRunning.

    on_ready(server): 바인드 직후 한 번 부른다(주소 알림·시험에서 멈추기용)."""
    lock = InstanceLock(data_dir)
    if not lock.acquire():
        raise AlreadyRunning("양식함이 이미 실행 중입니다")
    try:
        srv = make_server(data_dir, host, port, mirror_root=mirror_root, max_upload_bytes=max_upload_bytes,
                          compare_timeout=compare_timeout, notify_mail=notify_mail, base_url=base_url,
                          audit_max_rows=audit_max_rows, pending_keep_days=pending_keep_days,
                          review_months_default=review_months_default)
        try:
            if on_ready is not None:
                on_ready(srv)
            srv.serve_forever(poll_interval=0.5)
        finally:
            srv.server_close()
    finally:
        lock.release()


# ── 요청 처리 ────────────────────────────────────────────────────────────────

class FormsHandler(BaseHTTPRequestHandler):
    server: FormsHTTPServer
    server_version = "Drev-Forms"
    sys_version = ""
    protocol_version = "HTTP/1.0"     # 요청 하나에 연결 하나 — 마감·상한 관리가 단순하다
    timeout = SOCKET_TIMEOUT

    # ── 연결 수명 ───────────────────────────────────────────────────────
    def setup(self) -> None:
        super().setup()
        self._cookies_out: list = []
        self.sess = None
        self._pre = None
        self.server.watch(id(self), self.connection, self.server.header_seconds)

    def finish(self) -> None:
        self.server.unwatch(id(self))
        try:
            super().finish()
        except OSError:
            pass

    def _deadline(self, nbytes: int = 0) -> None:
        """본문 읽기·응답 보내기 마감 — 30초 + 최소 속도로 나눈 시간."""
        self.server.watch(id(self), self.connection, 30.0 + nbytes / max(1, self.server.body_min_rate))

    def _allow_compare(self) -> None:
        """자동 비교를 기다리는 동안 느린 요청 끊기에 걸리지 않게 마감을 늘린다 — 자리 기다림 + 비교 상한 + 여유 30초."""
        c = self.server.comparer
        t = c.timeout if c is not None else COMPARE_TIMEOUT
        self.server.watch(id(self), self.connection, 2 * t + 30.0)

    def handle_one_request(self) -> None:
        """표준 처리와 같되 요청 줄·헤더 크기 상한을 좁혔다 (8KB·32KB·60개)."""
        try:
            self.raw_requestline = self.rfile.readline(MAX_REQUEST_LINE + 1)
            if len(self.raw_requestline) > MAX_REQUEST_LINE:
                self.requestline, self.request_version, self.command = "", "", ""
                self.send_error(HTTPStatus.REQUEST_URI_TOO_LONG)
                return
            if not self.raw_requestline:
                self.close_connection = True
                return
            if not self.parse_request():
                return
            if len(self.headers) > MAX_HEADERS or \
                    sum(len(k) + len(v) + 4 for k, v in self.headers.items()) > MAX_HEADER_BYTES:
                self.send_error(HTTPStatus.REQUEST_HEADER_FIELDS_TOO_LARGE)
                return
            self._deadline()
            mname = "do_" + self.command
            if not hasattr(self, mname):
                self.send_error(HTTPStatus.NOT_IMPLEMENTED)
                return
            getattr(self, mname)()
            self.wfile.flush()
        except TimeoutError:
            self.close_connection = True
        except (ConnectionError, OSError) as e:      # 감시 스레드가 끊었거나 상대가 나갔다
            log.debug("연결 끊김: %s", e)
            self.close_connection = True

    def log_message(self, fmt, *args) -> None:       # 콘솔 소음 대신 로그(디버그)로
        log.debug("%s %s", self.client_address[0] if self.client_address else "-", fmt % args)

    # ── 응답 ────────────────────────────────────────────────────────────
    def _out(self, data: bytes) -> None:
        """소켓으로 보내기 — 이 모듈에서 write를 부르는 유일한 곳 (파일 쓰기 아님, test_readonly)."""
        self.wfile.write(data)

    def end_headers(self) -> None:
        for k, v in SECURITY_HEADERS:
            self.send_header(k, v)
        for c in self._cookies_out:
            self.send_header("Set-Cookie", c)
        self._cookies_out = []
        super().end_headers()

    def _cookie(self, name: str, value: str, *, max_age: int | None = None) -> None:
        c = f"{name}={value}; Path=/; HttpOnly; SameSite=Strict"
        if max_age is not None:
            c += f"; Max-Age={int(max_age)}"
        self._cookies_out.append(c)

    def _send(self, status: int, body, ctype: str = "text/html; charset=utf-8", extra=()) -> None:
        data = body.encode("utf-8") if isinstance(body, str) else bytes(body)
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self._out(data)

    def _redirect(self, location: str, status: int = 303) -> None:
        self.send_response(status)
        self.send_header("Location", _safe_back(location))
        self.send_header("Content-Length", "0")
        self.end_headers()

    def send_error(self, code, message=None, explain=None) -> None:
        """표준 오류 화면 대신 한국어 쉬운 말 — 내부 설명(explain)은 화면에 내지 않는다."""
        code = int(code)
        self.close_connection = True
        if not hasattr(self, "_cookies_out"):
            self._cookies_out = []
        try:
            phrase = HTTPStatus(code).phrase
        except ValueError:
            phrase = "Error"
        body = _auth_page("오류", f'<div class="note bad">{E(_ERROR_TEXT.get(code, "요청을 처리할 수 없습니다"))}'
                                  f' ({code})</div><p><a href="/forms">양식함으로 가기</a></p>',
                          self._theme_attr_safe()).encode("utf-8")
        self.send_response(code, phrase)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD" and code >= 200 and code not in (204, 304):
            self._out(body)

    # ── 요청 정보 ───────────────────────────────────────────────────────
    def _client_ip(self) -> str:
        ip = str(self.client_address[0]) if self.client_address else ""
        if ip.lower().startswith("::ffff:"):
            ip = ip[7:]
        return ip

    def _cookies_in(self) -> dict:
        try:
            c = SimpleCookie(self.headers.get("Cookie", ""))
        except CookieError:
            return {}
        return {k: m.value for k, m in c.items()}

    def _theme(self) -> str:
        t = self._cookies_in().get(THEME_COOKIE, "") if hasattr(self, "headers") and self.headers else ""
        return t if t in ("light", "dark") else ""

    def _theme_attr_safe(self) -> str:
        try:
            t = self._theme()
        except Exception:
            t = ""
        return f' data-theme="{t}"' if t else ""

    def _query(self) -> dict:
        try:
            return parse_qs(urlsplit(self.path).query, keep_blank_values=True, max_num_fields=40,
                            strict_parsing=False)
        except ValueError:
            raise HttpError(400)

    @staticmethod
    def _one(d: dict, key: str, default: str = "") -> str:
        v = d.get(key)
        return v[0] if v else default

    @staticmethod
    def _int(value, *, required: bool = True):
        s = str(value or "").strip()
        if not s:
            if required:
                raise HttpError(400, "번호가 빠졌습니다")
            return None
        if not (s.isascii() and s.isdigit()) or len(s) > 12:     # '²'·'①'은 isdigit()이 참이라 int()가 깨진다
            raise HttpError(400, "잘못된 번호입니다")
        return int(s)

    def _pre_token(self) -> str:
        """로그인 전 화면의 CSRF 값 — 쿠키와 양식에 같은 값을 둔다(이중 제출). SameSite=Strict라 다른 사이트는 못 보낸다."""
        if self._pre:
            return self._pre
        cur = self._cookies_in().get(PRE_COOKIE, "")
        if re.fullmatch(r"[A-Za-z0-9_\-]{40,64}", cur or ""):
            self._pre = cur
        else:
            self._pre = secrets.token_urlsafe(32)
            self._cookie(PRE_COOKIE, self._pre)
        return self._pre

    def _csrf_value(self) -> str:
        return self.sess.csrf if self.sess is not None else self._pre_token()

    def _check_origin(self) -> None:
        """Origin 머리글이 있으면 같은 주소여야 한다 (SameSite 쿠키에 더한 두 번째 문)."""
        origin = self.headers.get("Origin")
        if origin is None:
            return
        host = self.headers.get("Host", "")
        if origin == "null" or urlsplit(origin).netloc.lower() != host.lower():
            raise HttpError(403, "다른 곳에서 보낸 요청은 받지 않습니다")

    def _check_token(self, fields: dict) -> None:
        supplied = self._one(fields, "csrf")
        if self.sess is not None:
            ok = auth.check_csrf(self.sess, supplied)
        else:
            pre = self._cookies_in().get(PRE_COOKIE, "")
            ok = bool(pre) and bool(supplied) and hmac.compare_digest(pre.encode(), supplied.encode())
        if not ok:
            raise HttpError(403, "확인 값(CSRF)이 맞지 않습니다 — 화면을 새로 열고 다시 해 주세요")

    def _length(self, limit: int) -> int:
        if self.headers.get("Transfer-Encoding"):
            raise HttpError(411)
        raw = self.headers.get("Content-Length")
        if raw is None:
            raise HttpError(411)
        raw = raw.strip()
        if not raw.isdigit() or len(raw) > 15:
            raise HttpError(400, "본문 길이가 잘못됐습니다")
        n = int(raw)
        if n > limit:
            raise HttpError(413, f"보낸 내용이 너무 큽니다 (최대 {limit // (1024 * 1024) or 1}MB)"
                            if limit >= 1024 * 1024 else "보낸 내용이 너무 큽니다")
        return n

    def _discard_small_body(self) -> None:
        """본문을 읽지 않고 답할 때(로그인 안 됨·속도 제한·오류) 작은 본문은 읽어 버린다 — Windows는 안 읽은
        데이터가 남은 소켓을 닫으면 RST를 보내 상대가 답을 받기 전에 끊긴다 (2026-10-29 시험 간헐 실패).
        큰 본문은 여전히 읽지 않고 끊는다(비인증 상대에게 대역을 내주지 않는다)."""
        if self.command != "POST" or getattr(self, "_body_done", True):
            return
        self._body_done = True
        raw = (self.headers.get("Content-Length") or "").strip()
        if not raw.isascii() or not raw.isdigit() or len(raw) > 15 or int(raw) > DISCARD_BODY_MAX:
            return
        try:
            self._read_body(int(raw))
        except (HttpError, ConnectionError, TimeoutError, OSError):
            pass

    def _read_body(self, n: int) -> bytes:
        self._body_done = True
        self._deadline(n)
        parts, left = [], n
        while left > 0:
            chunk = self.rfile.read(min(left, 256 * 1024))
            if not chunk:
                raise HttpError(400, "본문이 덜 왔습니다")
            parts.append(chunk)
            left -= len(chunk)
        self._deadline()
        return b"".join(parts)

    def _read_form(self) -> dict:
        ctype = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        n = self._length(MAX_FORM_BODY)
        if ctype != "application/x-www-form-urlencoded":
            raise HttpError(415)
        body = self._read_body(n)
        try:
            text = body.decode("utf-8")
            return parse_qs(text, keep_blank_values=True, max_num_fields=500)
        except (UnicodeDecodeError, ValueError):
            raise HttpError(400)

    # ── 진입 ────────────────────────────────────────────────────────────
    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def _dispatch(self, method: str) -> None:
        self._body_done = False
        try:
            self.ip = self._client_ip()
            if _is_internet(self.ip):
                raise HttpError(403, "양식함은 사내망에서만 열립니다")
            path = urlsplit(self.path).path or "/"
            if path == "/forms.css" and method == "GET":
                self._send(200, CSS, "text/css; charset=utf-8")
                return
            routes = _GET if method == "GET" else _POST
            entry = routes.get(path)
            if entry is None:
                other = _POST if method == "GET" else _GET
                raise HttpError(405 if path in other else 404)
            fn, public = entry
            store = self.server.store
            token = self._cookies_in().get(SESSION_COOKIE, "")
            self.sess = auth.get_session(store, token) if token else None
            if not public:
                if self.sess is None:
                    self.close_connection = True       # 큰 본문은 읽지 않고 끊는다
                    self._discard_small_body()
                    self._redirect("/login")
                    return
                if self.sess.must_change and path not in _MUST_CHANGE_OK:
                    if method == "POST":
                        raise HttpError(403, "먼저 비밀번호를 바꿔 주세요")
                    self._redirect("/password")
                    return
            if method == "POST":
                self._check_origin()
            fn(self)
        except HttpError as e:
            self._fail(e.status, e.message)
        except auth.LoginLocked as e:
            self._fail(429, auth.locked_text(e.seconds, e.kind))
        except (PermissionDenied,) as e:
            self._fail(403, str(e))
        except NotFound as e:
            self._fail(404, str(e))
        except Conflict as e:
            self._fail(409, str(e))
        except (InvalidInput, auth.LoginFailed, FormsError) as e:
            self._fail(400, str(e))
        except (ConnectionError, TimeoutError):
            self.close_connection = True
        except Exception:
            log.exception("양식함 화면 오류: %s %s", method, urlsplit(self.path).path)
            self._fail(500, "문제가 생겼습니다 — 잠시 뒤 다시 해 보고, 계속되면 관리자에게 알려 주세요")

    def _fail(self, status: int, message: str) -> None:
        self.close_connection = True
        if status not in (411, 413):                   # 길이 없음·너무 큼은 읽지 않는다
            self._discard_small_body()
        body = f'<div class="note bad" role="alert">{E(message)}</div>' \
               f'<p><a class="btn gray" href="/forms">양식함으로</a></p>'
        try:
            if self.sess is not None and not self.sess.must_change:
                page = self._shell("할 수 없습니다", body, active="")
            else:
                page = _auth_page("할 수 없습니다", body, self._theme_attr_safe())
        except Exception:
            log.exception("오류 화면을 그리다 또 오류")
            page = _auth_page("오류", f'<div class="note bad">{E(message)}</div>', "")
        try:
            self._send(status, page)
        except OSError:
            pass

    # ── 화면 틀 ─────────────────────────────────────────────────────────
    def _shell(self, title: str, body: str, *, active: str, actions: str = "") -> str:
        s = self.sess
        store = self.server.store
        flash = self.server.flash_pop(s.token) if s else None
        note = ""
        if flash:
            kind, msg = flash
            note = f'<div class="note {E(kind)}" role="status">{E(msg)}</div>'
        mine = sum(1 for x in store.list_submissions(s.user_id, scope="mine", status="pending"))
        items = [("/forms", "양식함", 0), ("/upload", "양식 올리기", 0), ("/mine", "내 제출", mine)]
        if s.role in ("reviewer", "admin"):
            review = len(store.list_submissions(s.user_id, scope="review", status="pending"))
            items.append(("/review", "검토 대기", review))
            # 문서 관리 대장 (F7) — 숫자는 정기 검토 기한이 지난 양식 수
            items.append(("/register", "문서 관리 대장", _due_counts(self)[0]))

        def link(href, label, cnt):
            on = ' class="on" aria-current="page"' if href == active else ""
            badge = f'<span class="cnt">{cnt}</span>' if cnt else ""
            return f'<a href="{href}"{on}><span>{E(label)}</span>{badge}</a>'

        nav = '<div class="grp">양식</div>' + "".join(link(*i) for i in items)
        if s.role == "admin":
            nav += '<div class="grp">관리</div>' + "".join(link(*i) for i in (
                ("/admin/users", "계정", 0), ("/admin/folders", "폴더 관리", 0), ("/admin/docno", "문서번호 규칙", 0),
                ("/admin/doctypes", "문서 종류", 0), ("/admin/audit", "감사 기록", 0)))
        csrf = E(s.csrf)
        theme = self._theme()
        nxt = {"": "dark", "dark": "light", "light": ""}[theme]
        theme_label = {"": "OS 따라감", "dark": "어둡게", "light": "밝게"}[theme]
        nxt_label = {"": "OS 따라감", "dark": "어둡게", "light": "밝게"}[nxt]
        back = E(_safe_back(self.path))
        me = (f'<div class="me"><b>{E(s.display_name)}</b>{E(s.login)} · {E(ROLE_LABEL.get(s.role, s.role))}'
              f'<a href="/password">비밀번호 바꾸기</a>'
              f'<form method="post" action="/theme"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="theme" value="{nxt}"><input type="hidden" name="back" value="{back}">'
              f'<button class="btn gray sm" type="submit" title="누르면 {nxt_label}(으)로 바꿉니다">테마: {theme_label}'
              f'</button></form>'
              f'<form method="post" action="/logout"><input type="hidden" name="csrf" value="{csrf}">'
              f'<button class="btn gray sm" type="submit">로그아웃</button></form></div>')
        return (f'<!DOCTYPE html><html lang="ko"{self._theme_attr_safe()}><head><meta charset="utf-8">'
                f'<meta name="viewport" content="width=device-width, initial-scale=1">'
                f'<title>{E(title)} — Drev 양식함</title><link rel="stylesheet" href="/forms.css"></head><body>'
                f'<a class="skip" href="#main">본문으로 건너뛰기</a>'
                f'<nav class="side" aria-label="메뉴"><div class="logo">Drev 양식함<small>사내망 전용</small></div>'
                f'<div class="nav">{nav}</div>{me}</nav>'
                f'<main class="main" id="main"><div class="topbar"><h1>{E(title)}</h1>{actions}</div>'
                f'{note}{body}</main></body></html>')

    def _flash(self, kind: str, msg: str) -> None:
        if self.sess is not None:
            self.server.flash_set(self.sess.token, kind, msg)

    def _folders(self):
        return list(_flatten(self.server.store.folder_tree(self.sess.user_id)))


def _auth_page(title: str, body: str, theme_attr: str = "") -> str:
    """로그인 전 화면 틀 (메뉴 없음)."""
    return (f'<!DOCTYPE html><html lang="ko"{theme_attr}><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{E(title)} — Drev 양식함</title><link rel="stylesheet" href="/forms.css"></head><body>'
            f'<main class="authwrap" id="main"><div class="logo">Drev 양식함<small>사내망 전용 · 회사 양식 보관</small></div>'
            f'<div class="panel"><h2>{E(title)}</h2>{body}</div></main></body></html>')


# ── 화면별 처리 ─────────────────────────────────────────────────────────────

def _hidden(h: FormsHandler) -> str:
    return f'<input type="hidden" name="csrf" value="{E(h._csrf_value())}">'


def _password_rules() -> str:
    return f'<p class="muted">비밀번호는 {auth.MIN_PASSWORD}자 이상, 아이디와 달라야 합니다.</p>'


def get_root(h: FormsHandler) -> None:
    store = h.server.store
    if not auth.has_admin(store):
        h._redirect("/setup")
    elif h.sess is None:
        h._redirect("/login")
    else:
        h._redirect("/forms")


def _login_form(h: FormsHandler, msg: str = "", login: str = "") -> str:
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'{note}<form method="post" action="/login">{_hidden(h)}'
            f'<label for="lg">아이디</label><input type="text" id="lg" name="login" value="{E(login)}" '
            f'autocomplete="username" required maxlength="64" autofocus>'
            f'<label for="pw">비밀번호</label><input type="password" id="pw" name="password" '
            f'autocomplete="current-password" required maxlength="256">'
            f'<div class="form-actions"><button class="btn" type="submit">로그인</button></div></form>'
            f'<p class="muted">계정은 관리자가 등록해 줍니다. 비밀번호를 잊었으면 관리자에게 초기화를 부탁하세요.</p>')


def get_login(h: FormsHandler) -> None:
    store = h.server.store
    if not auth.has_admin(store):
        h._redirect("/setup")
        return
    if h.sess is not None:
        h._redirect("/password" if h.sess.must_change else "/forms")
        return
    h._send(200, _auth_page("로그인", _login_form(h), h._theme_attr_safe()))


def _rate_limited(h: FormsHandler, back: str) -> bool:
    """비인증 POST(로그인·첫 관리자)의 주소별 상한 (2026-10-28 보안 F1). 넘쳤으면 429 쉬운 말 화면을 내고 True.
    본문을 읽기 전에, DB에 아무것도 적기 전에 본다 — 넘친 요청은 감사 기록도 남기지 않는다(메모리만)."""
    wait = h.server.limiter.take(h.ip)
    if wait <= 0:
        return False
    secs = max(1, int(wait + 0.999))
    h.close_connection = True
    h._discard_small_body()                      # 안 읽고 닫으면 Windows RST로 429를 못 받는다 (작은 본문만)
    body = (f'<div class="note bad" role="alert">요청이 너무 잦습니다 — {secs}초 뒤에 다시 해 주세요.</div>'
            f'<p class="muted">같은 공유기(사내망 주소)를 쓰는 여러 PC가 한꺼번에 로그인하면 잠깐 이렇게 될 수 있습니다.</p>'
            f'<p><a class="btn gray" href="{E(back)}">돌아가기</a></p>')
    h._send(429, _auth_page("잠시 뒤에 다시", body, h._theme_attr_safe()), extra=(("Retry-After", str(secs)),))
    return True


def post_login(h: FormsHandler) -> None:
    store = h.server.store
    if _rate_limited(h, "/login"):
        return
    f = h._read_form()
    h._check_token(f)
    name, pw = h._one(f, "login").strip(), h._one(f, "password")
    try:
        sess = auth.login(store, name, pw, ip=h.ip)
    except auth.LoginLocked as e:
        h._send(429, _auth_page("로그인", _login_form(h, auth.locked_text(e.seconds, e.kind), name),
                                h._theme_attr_safe()), extra=(("Retry-After", str(max(1, e.seconds))),))
        return
    except auth.LoginFailed as e:
        msg = str(e)
        left, kind = auth.wait_seconds(store, name, h.ip)
        if left > 0:
            msg += " — " + auth.locked_text(left, kind)
        h._send(401, _auth_page("로그인", _login_form(h, msg, name), h._theme_attr_safe()))
        return
    h._cookie(SESSION_COOKIE, sess.token)
    h._redirect("/password" if sess.must_change else "/forms")


def post_logout(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    auth.logout(h.server.store, h.sess.token, ip=h.ip)
    h._cookie(SESSION_COOKIE, "", max_age=0)
    h._redirect("/login")


def _password_form(h: FormsHandler, msg: str = "") -> str:
    s = h.sess
    lead = ('<div class="note warn">관리자가 정해 준 임시 비밀번호입니다 — 새 비밀번호로 바꿔야 계속할 수 있습니다.</div>'
            if s.must_change else "")
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'{lead}{note}<form method="post" action="/password">{_hidden(h)}'
            f'<input type="text" name="username" value="{E(s.login)}" autocomplete="username" hidden>'
            f'<label for="old">지금 비밀번호</label><input type="password" id="old" name="old" '
            f'autocomplete="current-password" required maxlength="256">'
            f'<label for="new">새 비밀번호</label><input type="password" id="new" name="new" '
            f'autocomplete="new-password" required maxlength="256">'
            f'<label for="new2">새 비밀번호 한 번 더</label><input type="password" id="new2" name="new2" '
            f'autocomplete="new-password" required maxlength="256">{_password_rules()}'
            f'<div class="form-actions"><button class="btn" type="submit">바꾸기</button></div></form>')


def _password_page(h: FormsHandler, status: int = 200, msg: str = "") -> None:
    if h.sess.must_change:
        csrf = E(h.sess.csrf)
        body = _password_form(h, msg) + (
            f'<form method="post" action="/logout" class="inline">'
            f'<input type="hidden" name="csrf" value="{csrf}"><button class="btn gray sm" type="submit">로그아웃</button></form>')
        h._send(status, _auth_page("비밀번호 바꾸기", body, h._theme_attr_safe()))
    else:
        h._send(status, h._shell("비밀번호 바꾸기", f'<div class="panel">{_password_form(h, msg)}</div>',
                                 active=""))


def get_password(h: FormsHandler) -> None:
    _password_page(h)


def post_password(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    old, new, new2 = h._one(f, "old"), h._one(f, "new"), h._one(f, "new2")
    if new != new2:
        _password_page(h, 400, "새 비밀번호 두 칸이 서로 다릅니다")
        return
    try:
        auth.change_password(h.server.store, h.sess.user_id, old, new, keep_token=h.sess.token, ip=h.ip)
    except (auth.LoginFailed, InvalidInput, Conflict) as e:
        _password_page(h, 400, str(e))
        return
    h._flash("ok", "비밀번호를 바꿨습니다")
    h._redirect("/forms")


def get_setup(h: FormsHandler) -> None:
    store = h.server.store
    if auth.has_admin(store):
        h._redirect("/login")
        return
    if not _is_loopback(h.ip):
        h._send(200, _auth_page("첫 관리자 만들기", (
            '<div class="note warn">아직 관리자가 없습니다. 첫 관리자는 <b>Drev가 설치된 PC</b>에서만 만들 수 있습니다.</div>'
            '<p>Drev PC에서 이 화면을 열어(주소의 IP 자리에 127.0.0.1) 관리자를 만든 뒤, '
            '관리자가 직원 계정을 등록해 주면 이 PC에서도 로그인할 수 있습니다.</p>'), h._theme_attr_safe()))
        return
    h._send(200, _auth_page("첫 관리자 만들기", _setup_form(h), h._theme_attr_safe()))


def _setup_form(h: FormsHandler, msg: str = "", login: str = "", name: str = "") -> str:
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'<p class="muted">양식함을 처음 쓰는 중입니다. 관리자 계정을 하나 만드세요. 직원 계정은 관리자가 등록합니다.</p>'
            f'{note}<form method="post" action="/setup">{_hidden(h)}'
            f'<label for="lg">관리자 아이디</label><input type="text" id="lg" name="login" value="{E(login)}" '
            f'required maxlength="32" autocomplete="username">'
            f'<label for="dn">이름 (화면에 보이는 이름)</label><input type="text" id="dn" name="display_name" '
            f'value="{E(name)}" maxlength="40">'
            f'<label for="pw">비밀번호</label><input type="password" id="pw" name="password" required '
            f'maxlength="256" autocomplete="new-password">'
            f'<label for="pw2">비밀번호 한 번 더</label><input type="password" id="pw2" name="password2" required '
            f'maxlength="256" autocomplete="new-password">{_password_rules()}'
            f'<div class="form-actions"><button class="btn" type="submit">관리자 만들기</button></div></form>')


def post_setup(h: FormsHandler) -> None:
    store = h.server.store
    if _rate_limited(h, "/setup"):
        return
    if not _is_loopback(h.ip):
        raise HttpError(403, "첫 관리자는 Drev가 설치된 PC에서만 만들 수 있습니다")
    f = h._read_form()
    h._check_token(f)
    login, name = h._one(f, "login").strip(), h._one(f, "display_name").strip()
    pw, pw2 = h._one(f, "password"), h._one(f, "password2")
    if pw != pw2:
        h._send(400, _auth_page("첫 관리자 만들기", _setup_form(h, "비밀번호 두 칸이 서로 다릅니다", login, name),
                                h._theme_attr_safe()))
        return
    try:
        auth.create_first_admin(store, login, name or login, pw, is_local=True, ip=h.ip)
    except (InvalidInput, Conflict) as e:
        status = 409 if isinstance(e, Conflict) else 400
        h._send(status, _auth_page("첫 관리자 만들기", _setup_form(h, str(e), login, name), h._theme_attr_safe()))
        return
    sess = auth.login(store, login, pw, ip=h.ip)
    h._cookie(SESSION_COOKIE, sess.token)
    h.server.flash_set(sess.token, "ok", "관리자를 만들었습니다 — 먼저 폴더를 만들고, [계정]에서 직원을 등록하세요")
    h._redirect("/forms")


def post_theme(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    t = h._one(f, "theme")
    if t in ("light", "dark"):
        h._cookie(THEME_COOKIE, t, max_age=365 * 24 * 3600)
    else:
        h._cookie(THEME_COOKIE, "", max_age=0)
    h._redirect(_safe_back(h._one(f, "back", "/forms")))


# ── 양식함 본 화면 ───────────────────────────────────────────────────────────

def _tree_html(nodes, current, path_ids, q: str) -> str:
    """폴더 트리 — 맨 위 폴더는 늘 보이고, 지금 폴더까지의 길(path_ids)만 펼친다 (f6: 기본 분류 틀이면 폴더가 170개 넘어
    전부 펼치면 목록이 화면 몇 장이 된다). 하위가 있는데 접힌 폴더는 이름 뒤에 '…'."""
    if not nodes:
        return ""
    out = ["<ul>"]
    for n in nodes:
        on = ' class="on" aria-current="page"' if n["id"] == current else ""
        kids = n["children"]
        open_ = n["id"] in path_ids
        more = ' <span class="muted" aria-label="하위 폴더 있음">…</span>' if kids and not open_ else ""
        out.append(f'<li><a href="/forms?folder={n["id"]}"{on}>{E(n["name"])}{more}</a>'
                   f'{_tree_html(kids, current, path_ids, q) if open_ else ""}</li>')
    out.append("</ul>")
    return "".join(out)


def get_forms(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    qd = h._query()
    folder_id = h._int(h._one(qd, "folder"), required=False)
    text = h._one(qd, "q").strip()[:100]
    retired = h._one(qd, "retired") == "1"
    tree = store.folder_tree(s.user_id)
    flat = list(_flatten(tree))
    paths = {n["id"]: p for n, _, p in flat}
    crumbs = store.folder_path(s.user_id, folder_id) if folder_id is not None else []
    if text:
        forms = store.search_forms(s.user_id, text, include_retired=retired)
        if folder_id is not None:          # 폴더를 고른 채 찾으면 그 폴더와 하위 폴더 안에서만
            inside = {n["id"] for n, _, p in flat if p == paths[folder_id] or p.startswith(paths[folder_id] + " / ")}
            forms = [x for x in forms if x["folder_id"] in inside]
    else:
        forms = store.list_forms(s.user_id, folder_id, include_retired=retired)
    can_top = s.role == "admin"
    can_here = folder_id is not None and store.is_reviewer_of(s.user_id, folder_id)
    csrf = E(s.csrf)

    side = (f'<div class="panel tree"><h2>폴더</h2>'
            f'<a href="/forms"{" class=\"on\"" if folder_id is None else ""}>전체 양식</a>'
            f'{_tree_html(tree, folder_id, {c["id"] for c in crumbs}, text) or "<p class=\"muted\">아직 폴더가 없습니다</p>"}')
    if can_top:
        side += (f'<details class="tool"><summary>+ 대분류(맨 위 폴더) 만들기</summary>'
                 f'<form method="post" action="/folders/new"><input type="hidden" name="csrf" value="{csrf}">'
                 f'<label for="nf-top">폴더 이름</label><input type="text" id="nf-top" name="name" required maxlength="80">'
                 f'<div class="form-actions"><button class="btn sm" type="submit">폴더 만들기</button></div></form></details>'
                 f'<p class="muted"><a href="/admin/folders">폴더 관리</a>에서 기본 분류 틀(대분류·중분류·소분류)을 한 번에 '
                 f'만들 수 있습니다.</p>')
    side += "</div>"

    # 가운데: 경로·도구·검색·목록
    head = ""
    depth = len(crumbs)
    codes = {n["id"]: n.get("code", "") for n, _, _ in flat}
    if crumbs:
        trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in crumbs)
        here_code = codes.get(folder_id, "")
        head += (f'<div class="crumb"><a href="/forms">전체</a> / {trail} '
                 f'<span class="tag lvl">{E(level_name(depth))}</span>'
                 + (f'<span class="tag code" title="문서번호 머리">{E(here_code)}</span>' if here_code else "")
                 + '</div>')
    banner = ""
    if folder_id is None and not text and s.role in ("reviewer", "admin"):
        banner = _due_banner(h)
    tools = ""
    if can_here:
        cur_name = crumbs[-1]["name"] if crumbs else ""
        child = level_name(depth + 1)
        tools += _folder_code_tool(h, folder_id, codes.get(folder_id, ""))
        tools += (f'<details class="tool"><summary>+ {E(child)} 만들기</summary>'
                  f'<form method="post" action="/folders/new"><input type="hidden" name="csrf" value="{csrf}">'
                  f'<input type="hidden" name="parent" value="{folder_id}">'
                  f'<label for="nf-sub">{E(child)} 이름</label><input type="text" id="nf-sub" name="name" required '
                  f'maxlength="80">'
                  f'<div class="form-actions"><button class="btn sm" type="submit">폴더 만들기</button></div></form></details>'
                  f'<details class="tool"><summary>폴더 이름 바꾸기</summary>'
                  f'<form method="post" action="/folders/rename"><input type="hidden" name="csrf" value="{csrf}">'
                  f'<input type="hidden" name="folder" value="{folder_id}">'
                  f'<label for="rn">새 이름</label><input type="text" id="rn" name="name" value="{E(cur_name)}" '
                  f'required maxlength="80"><div class="form-actions"><button class="btn sm" type="submit">이름 바꾸기'
                  f'</button></div></form></details>')
    if folder_id is not None:
        tools += _folder_manage_tools(h, folder_id, crumbs)
    if folder_id is not None and h.server.notifier is not None:
        on = store.is_subscribed(s.user_id, folder_id)
        tools += (f'<form class="sub" method="post" action="/folders/subscribe">'
                  f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="folder" value="{folder_id}">'
                  f'<input type="hidden" name="on" value="{"0" if on else "1"}">'
                  f'<button class="btn gray sm" type="submit">{"메일 알림 끄기" if on else "새 현행 판 메일 받기"}</button>'
                  f'<span>{"이 폴더(하위 포함)에 새 현행 판이 생기면 메일로 알립니다" if on else "이 폴더(하위 포함)에 새 판이 승인되면 메일로 알려 줍니다"}'
                  f'{"" if store.user_email(s.user_id) else " — 내 계정에 메일 주소가 없습니다(관리자가 등록)"}</span></form>')
    subs = []
    if folder_id is not None:
        subs = store.list_folders(s.user_id, folder_id)
    chips = ("<div class=\"chips\">" + "".join(
        f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in subs) + "</div>") if subs else ""
    hidden_folder = f'<input type="hidden" name="folder" value="{folder_id}">' if folder_id is not None else ""
    search = (f'<form class="searchbar" method="get" action="/forms" role="search">{hidden_folder}'
              f'<input type="search" name="q" value="{E(text)}" placeholder="양식 이름·분류·파일 이름" '
              f'aria-label="양식 찾기" maxlength="100">'
              + (f'<input type="hidden" name="retired" value="1">' if retired else "")
              + f'<button class="btn sm" type="submit">찾기</button>'
              + (f'<a class="btn gray sm" href="/forms{"?folder=" + str(folder_id) if folder_id is not None else ""}">'
                 f'지우기</a>' if text else "")
              + "</form>")
    base = "/forms?" + "&".join(x for x in (
        f"folder={folder_id}" if folder_id is not None else "", f"q={quote(text)}" if text else "") if x)
    toggle = (f'<a class="btn gray sm" href="{E(base.rstrip("?&"))}">폐기 양식 숨기기</a>' if retired else
              f'<a class="btn gray sm" href="{E(base + ("&" if base[-1] != "?" else "") + "retired=1")}">'
              f'폐기 양식도 보기</a>')
    show_folder = folder_id is None or bool(text)
    rows = []
    for f in forms:
        tag = ' <span class="tag retired">폐기</span>' if f["retired"] else ""
        cat = f'<div class="muted">{E(f["category"])}</div>' if f["category"] else ""
        no = f'<span class="docno">{E(f["doc_no"])}</span>' if f.get("doc_no") else ""      # 문서번호 (F7)
        ver = f'v{f["current_number"]}' if f["current_number"] else "—"
        rows.append(
            f'<tr><td class="name-c">{no}<a href="/form?id={f["id"]}">{E(f["name"])}</a>{tag}{cat}</td>'
            + (f'<td class="path-c">{E(paths.get(f["folder_id"], ""))}</td>' if show_folder else "")
            + f'<td class="nw">{ver}</td><td class="nw">{E(_fmt_time(f["current_approved_at"]))}</td>'
            f'<td class="nw">{E(f["current_uploaded_by_name"])}</td></tr>')
    table = ('<div class="tablewrap"><table class="flist"><thead><tr><th>양식</th>'
             + ("<th>폴더</th>" if show_folder else "")
             + "<th>현행 판</th><th>마지막 개정</th><th>올린 사람</th></tr></thead><tbody>"
             + "".join(rows) + "</tbody></table></div>") if rows else \
        f'<p class="empty">{"찾는 양식이 없습니다" if text else "이 폴더에는 아직 양식이 없습니다"}</p>'
    up = f'/upload?folder={folder_id}' if folder_id is not None else "/upload"
    title = crumbs[-1]["name"] if crumbs else ("찾기 결과" if text else "양식함")
    main = (f'<div class="panel">{head}{tools}{chips}{search}'
            f'<div class="searchbar">{toggle}<span class="muted">{len(forms)}개</span></div>{table}</div>')
    body = f'{banner}<div class="split">{side}<div>{main}</div></div>'
    h._send(200, h._shell(title, body, active="/forms",
                          actions=f'<a class="btn" href="{E(up)}">양식 올리기</a>'))


def post_folder_new(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    parent = h._int(h._one(f, "parent"), required=False)
    fid = h.server.store.create_folder(h.sess.user_id, parent, h._one(f, "name"), ip=h.ip)
    h._flash("ok", "폴더를 만들었습니다")
    h._redirect(f"/forms?folder={fid}")


def post_folder_rename(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    h.server.store.rename_folder(h.sess.user_id, fid, h._one(f, "name"), ip=h.ip)
    h.server.on_event("folder_renamed", folder_id=fid)
    h._flash("ok", "폴더 이름을 바꿨습니다")
    h._redirect(f"/forms?folder={fid}")


# ── 폴더 관리: 옮기기·지우기·차례 (f6, 2026-10-29) ─────────────────────────────

def _move_targets(h: FormsHandler, folder_id: int) -> list:
    """옮겨 갈 수 있는 부모 후보 [(id|None, 경로 글)] — 자기 자신·자기 하위·지금 부모는 빼고, 검토자는 맡은 폴더만."""
    store, s = h.server.store, h.sess
    flat = h._folders()
    kids: dict = {}
    for n, _d, _p in flat:
        kids.setdefault(n["parent_id"], []).append(n["id"])
    banned, todo = set(), [folder_id]
    while todo:
        x = todo.pop()
        if x not in banned:
            banned.add(x)
            todo.extend(kids.get(x, []))
    parent = next((n["parent_id"] for n, _d, _p in flat if n["id"] == folder_id), None)
    mine = store.reviewable_folders(s.user_id)
    out = []
    if mine is None and parent is not None:
        out.append((None, "(맨 위 — 대분류로)"))
    for n, _d, p in flat:
        if n["id"] in banned or n["id"] == parent:
            continue
        if mine is not None and n["id"] not in mine:
            continue
        out.append((n["id"], p))
    return out


def _move_form(h: FormsHandler, folder_id: int, idp: str = "mv") -> str:
    """[옮기기] 양식 — 스크립트 없는 POST(/folders/move, CSRF). 옮길 곳이 없으면 안내만."""
    opts = _move_targets(h, folder_id)
    note = ('<p class="muted">옮기면 그 안의 하위 폴더·양식이 함께 갑니다. 검토자 지정은 폴더에 붙어 있어 <b>새 위 폴더의 검토자도 '
            '이 폴더를 검토할 수 있게</b> 되고, 옛 위 폴더의 검토자는 (따로 지정되지 않았다면) 더 이상 검토하지 못합니다.</p>')
    if not opts:
        return note + '<p class="muted">옮겨 갈 수 있는 폴더가 없습니다.</p>'
    o = "".join(f'<option value="{"" if fid is None else fid}">{E(p)}</option>' for fid, p in opts)
    return (note + f'<form method="post" action="/folders/move">{_hidden(h)}'
            f'<input type="hidden" name="folder" value="{folder_id}">'
            f'<label for="{idp}-to">어느 폴더 아래로 옮길까요</label><select class="wide" id="{idp}-to" name="to">{o}</select>'
            f'<div class="form-actions"><button class="btn sm" type="submit">옮기기</button></div></form>')


def _folder_manage_tools(h: FormsHandler, folder_id: int, crumbs: list) -> str:
    """폴더 화면의 옮기기·지우기·차례 — 권한이 맞을 때만 보인다 (관리자, 또는 위 폴더의 검토자)."""
    store, s = h.server.store, h.sess
    parent = crumbs[-2]["id"] if len(crumbs) >= 2 else None
    if not store.can_manage_child_of(s.user_id, parent):
        return ""
    out = (f'<details class="tool"><summary>폴더 옮기기</summary>{_move_form(h, folder_id)}</details>'
           f'<details class="tool"><summary>폴더 지우기</summary>'
           f'<p class="muted">빈 폴더만 지울 수 있습니다 — 하위 폴더·양식(폐기 포함)·검토 대기가 없어야 합니다.</p>'
           f'<form method="post" action="/folders/delete">{_hidden(h)}<input type="hidden" name="folder" '
           f'value="{folder_id}"><div class="form-actions"><button class="btn red sm" type="submit">이 폴더 지우기</button>'
           f'</div></form></details>')
    return out + _order_buttons(h, folder_id, back=f"/forms?folder={folder_id}")


def _folder_code_tool(h: FormsHandler, folder_id: int, code: str, back: str = "") -> str:
    """번호 머리(문서번호 앞부분) 정하기 — 이름 바꾸기와 같은 권한(관리자나 그 폴더 검토자). POST /folders/code (F7)."""
    return (f'<details class="tool"><summary>번호 머리(문서번호) {E(code) if code else "정하기"}</summary>'
            f'<p class="muted">이 폴더에서 처음 승인되는 양식의 문서번호 앞부분입니다. 관리자가 정한 문서번호 규칙대로 '
            f'잇습니다(기본: 위 폴더들의 머리를 위에서부터 빼기(-)로 잇고 일련번호 세 자리, 예: QA-01-01-001). 머리가 하나도 없으면 F-0001처럼 매깁니다. '
            f'<b>이미 매긴 번호는 바뀌지 않습니다.</b> 영문·숫자·한글 1~8자(가운데 점(.) 가능 — ISO 조항 7.5), 비우면 머리 없음.</p>'
            f'<form class="inline" method="post" action="/folders/code">{_hidden(h)}'
            f'<input type="hidden" name="folder" value="{folder_id}">'
            + (f'<input type="hidden" name="back" value="{E(back)}">' if back else "")
            + f'<input type="text" class="code" name="code" value="{E(code)}" maxlength="8" '
              f'aria-label="번호 머리" placeholder="예: QA">'
              f'<button class="btn gray sm" type="submit">머리 저장</button></form></details>')


def _due_counts(h: "FormsHandler") -> tuple[int, int]:
    """(기한 지난 수, 곧 오는 수) — 요청 하나에 한 번만 센다(메뉴 숫자와 첫 화면 띠가 같이 쓴다, SQL 한 번 — F7 검토 10)."""
    got = getattr(h, "_due_memo", None)
    if got is None:
        got = h._due_memo = h.server.store.due_counts(h.sess.user_id)
    return got


def _due_banner(h: FormsHandler) -> str:
    """양식함 첫 화면 위 띠 — 정기 검토 기한이 지난 양식(관리자는 전체, 검토자는 맡은 폴더) (F7)."""
    over, soon = _due_counts(h)
    if over:
        more = f" · {REVIEW_SOON_DAYS}일 안에 기한이 오는 양식 {soon}개" if soon else ""
        return (f'<div class="note warn" role="status"><b>검토 기한 지난 양식 {over}개</b>{more} — '
                f'바꿀 것이 없으면 [검토함]을, 고칠 것이 있으면 개정안을 올리세요. '
                f'<a href="/register/due">검토할 양식 보기</a></div>')
    if soon:
        return (f'<div class="note info" role="status">{REVIEW_SOON_DAYS}일 안에 정기 검토 기한이 오는 양식 {soon}개 — '
                f'<a href="/register/due">보기</a></div>')
    return ""


def _order_buttons(h: FormsHandler, folder_id: int, back: str) -> str:
    def one(step, label):
        return (f'<form class="inline" method="post" action="/folders/order">{_hidden(h)}'
                f'<input type="hidden" name="folder" value="{folder_id}"><input type="hidden" name="step" value="{step}">'
                f'<input type="hidden" name="back" value="{E(back)}">'
                f'<button class="btn gray sm" type="submit" title="같은 위 폴더 안에서 차례를 바꿉니다">{label}</button></form>')
    return f'<div class="order">{one(-1, "위로")}{one(1, "아래로")}</div>'


def get_folder_move(h: FormsHandler) -> None:
    """옮기기 화면(관리 표에서 연다) — 읽기만 한다. 실제 옮기기는 POST /folders/move."""
    store, s = h.server.store, h.sess
    fid = h._int(h._one(h._query(), "folder"))
    crumbs = store.folder_path(s.user_id, fid)
    parent = crumbs[-2]["id"] if len(crumbs) >= 2 else None
    if not store.can_manage_child_of(s.user_id, parent):
        raise PermissionDenied("이 폴더를 옮길 수 있는 사람은 관리자나 위 폴더의 검토자입니다")
    trail = " / ".join(E(c["name"]) for c in crumbs)
    body = (f'<div class="crumb"><a href="/forms?folder={fid}">{trail}</a> '
            f'<span class="tag lvl">{E(level_name(len(crumbs)))}</span></div>'
            f'<div class="panel">{_move_form(h, fid)}</div>')
    h._send(200, h._shell("폴더 옮기기", body, active="/admin/folders" if s.role == "admin" else "/forms"))


def post_folder_move(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    to = h._int(h._one(f, "to"), required=False)
    h.server.store.move_folder(h.sess.user_id, fid, to, ip=h.ip)
    h.server.on_event("folder_moved", folder_id=fid)
    h._flash("ok", "폴더를 옮겼습니다 — 검토자 지정은 새 위치 기준으로 이어집니다")
    h._redirect(f"/forms?folder={fid}")


def post_folder_delete(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    store = h.server.store
    path = store.folder_path(h.sess.user_id, fid)
    parent = path[-2]["id"] if len(path) >= 2 else None
    back = _safe_back(h._one(f, "back")) if h._one(f, "back") else ""
    try:
        gone = store.delete_folder(h.sess.user_id, fid, ip=h.ip)
    except Conflict as e:                       # 비어 있지 않음 — 무엇이 남았는지 알리고 그 폴더로 돌아간다
        h._flash("bad", str(e))
        h._redirect(back or f"/forms?folder={fid}")
        return
    h.server.on_event("folder_deleted", folder_id=fid)
    h._flash("ok", f"폴더를 지웠습니다 ({gone})")
    h._redirect(back or (f"/forms?folder={parent}" if parent is not None else "/forms"))


def post_folder_order(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    step = -1 if h._one(f, "step") == "-1" else 1
    moved = h.server.store.move_folder_order(h.sess.user_id, fid, step, ip=h.ip)
    if not moved:
        h._flash("info", "이미 맨 " + ("앞" if step < 0 else "뒤") + "입니다")
    back = _safe_back(h._one(f, "back") or f"/forms?folder={fid}")
    h._redirect(back)


# ── 올리기·내 제출 ───────────────────────────────────────────────────────────

def _type_label(code: str, name: str) -> str:
    return f"{code} — {name}" if code else ""


def _type_options(types: list, selected, empty_label: str, *, keep=None) -> str:
    """문서 종류 고르기 칸 — 빈 값(empty_label) + 사용 중인 종류. keep(그 양식의 지금 종류)은 사용 중지여도 보인다."""
    out = [f'<option value=""{" selected" if selected is None else ""}>{E(empty_label)}</option>']
    for t in types:
        if not t["active"] and t["id"] != keep:
            continue
        mark = " (사용 중지)" if not t["active"] else ""
        out.append(f'<option value="{t["id"]}"{" selected" if t["id"] == selected else ""}>'
                   f'{E(_type_label(t["code"], t["name"]))}{mark}</option>')
    return "".join(out)


def get_upload(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    qd = h._query()
    pick_folder = h._int(h._one(qd, "folder"), required=False)
    pick_form = h._int(h._one(qd, "form"), required=False)
    flat = h._folders()
    paths = {n["id"]: p for n, _, p in flat}
    forms = [f for f in store.list_forms(s.user_id) if not f["retired"]]
    exts = "·".join(sorted(e.lstrip(".") for e in ALLOWED_EXTS))
    mb = store.max_upload_bytes // (1024 * 1024)
    csrf = E(s.csrf)
    intro = (f'<p class="muted">올린 파일은 바로 쓰이지 않고 <b>검토 대기</b>가 됩니다. 검토자가 승인하면 판 번호(v1, v2…)가 붙어 '
             f'현행 판이 됩니다. 올릴 수 있는 파일: {E(exts)} · 최대 {mb}MB</p>')
    if not flat:
        body = intro + '<div class="note warn">아직 폴더가 없습니다 — 관리자가 먼저 폴더를 만들어야 올릴 수 있습니다.</div>'
        h._send(200, h._shell("양식 올리기", f'<div class="panel">{body}</div>', active="/upload"))
        return
    fopts = "".join(f'<option value="{n["id"]}"{" selected" if n["id"] == pick_folder else ""}>'
                    f'{E(p)}</option>' for n, _, p in flat)
    types = store.list_doc_types(s.user_id)                  # 문서 종류 (F7 문서 종류) — 고르기는 사용 중인 것만
    new_type = ""
    if any(t["active"] for t in types):
        new_type = (f'<label for="nt">문서 종류 (선택)</label><select id="nt" name="doc_type">'
                    f'{_type_options(types, None, "(없음)")}</select>')
    new_form = (f'<div class="panel"><h2>새 양식 올리기</h2>'
                f'<form method="post" action="/upload" enctype="multipart/form-data">'
                f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="kind" value="new">'
                f'<label for="nf">폴더</label><select class="wide" id="nf" name="folder_id" required>{fopts}</select>'
                f'<label for="nn">양식 이름</label><input type="text" id="nn" name="form_name" required maxlength="100" '
                f'placeholder="예: 잔업집계표">'
                f'<label for="nc">분류 (선택)</label><input type="text" id="nc" name="category" maxlength="50" '
                f'placeholder="예: 인사·근태">{new_type}'
                f'<label for="nfile">파일</label><input type="file" id="nfile" name="file" required>'
                f'<label for="nnote">한 줄 설명</label><input type="text" id="nnote" name="note" maxlength="500" '
                f'placeholder="예: 2026년 잔업 집계 양식 처음 올림">'
                f'<div class="form-actions"><button class="btn" type="submit">올리기 (검토 대기)</button></div></form></div>')
    if forms:
        # 개정안의 종류 — ?form=로 고른 양식이면 그 양식의 종류를 미리 고른다. 빈 값 = 지금 종류 그대로.
        # type_form: 미리 고른 양식 — 양식 칸을 바꿨는데 종류를 손대지 않았으면 서버가 '그대로'로 본다(스크립트 없음)
        picked = next((f for f in forms if f["id"] == pick_form), None)
        rev_type = ""
        if any(t["active"] for t in types) or (picked and picked["doc_type_id"] is not None):
            keep = picked["doc_type_id"] if picked else None
            rev_type = (f'<label for="rt">문서 종류 (선택)</label><select id="rt" name="doc_type">'
                        f'{_type_options(types, keep, "(지금 종류 그대로)", keep=keep)}</select>'
                        + (f'<input type="hidden" name="type_form" value="{picked["id"]}">' if picked else ""))
        ropts = "".join(f'<option value="{f["id"]}"{" selected" if f["id"] == pick_form else ""}>'
                        f'{E(paths.get(f["folder_id"], ""))} / {E(f["name"])}'
                        f'{" (v" + str(f["current_number"]) + ")" if f["current_number"] else ""}</option>'
                        for f in forms)
        rev_form = (f'<div class="panel"><h2>기존 양식의 개정안 올리기</h2>'
                    f'<form method="post" action="/upload" enctype="multipart/form-data">'
                    f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="kind" value="revision">'
                    f'<label for="rf">어느 양식의 개정안인가요</label><select class="wide" id="rf" name="form_id" required>'
                    f'{ropts}</select>{rev_type}'
                    f'<label for="rfile">파일</label><input type="file" id="rfile" name="file" required>'
                    f'<label for="rnote">한 줄 설명 (무엇을 바꿨나요)</label><input type="text" id="rnote" name="note" '
                    f'maxlength="500" placeholder="예: 서명란 추가, 합계 칸 수식 고침">'
                    f'<div class="form-actions"><button class="btn" type="submit">개정안 올리기 (검토 대기)</button></div>'
                    f'</form></div>')
    else:
        rev_form = '<div class="panel"><h2>기존 양식의 개정안 올리기</h2><p class="muted">아직 승인된 양식이 없습니다.</p></div>'
    first = rev_form + new_form if pick_form is not None else new_form + rev_form
    h._send(200, h._shell("양식 올리기", f'<div class="panel">{intro}</div>{first}', active="/upload"))


def post_upload(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    n = h._length(store.max_upload_bytes + MULTIPART_SLACK)     # 본문을 읽기 전에 자른다
    try:
        bnd = boundary_of(h.headers.get("Content-Type", ""))
    except MultipartError as e:
        raise HttpError(400, str(e))
    body = h._read_body(n)
    try:
        fields, files = parse_multipart(body, bnd)
    except MultipartError as e:
        raise HttpError(400, f"올린 내용을 읽지 못했습니다 — {e}")
    del body
    h._check_token(fields)
    if "file" not in files:
        raise HttpError(400, "파일을 골라 주세요")
    filename, data = files["file"]
    if not filename:
        raise HttpError(400, "파일을 골라 주세요")
    kind = h._one(fields, "kind")
    note = h._one(fields, "note")
    dtype = h._int(h._one(fields, "doc_type"), required=False)          # 문서 종류 (선택, F7 문서 종류)
    if kind == "revision":
        form_id = h._int(h._one(fields, "form_id"))
        tf = h._int(h._one(fields, "type_form"), required=False)
        if dtype is not None and tf is not None and tf != form_id:
            # 미리 고른 양식과 다른 양식을 골랐는데 종류는 미리 채운 그대로 → 그 종류를 옮겨 붙이지 않는다
            try:
                prev = store.form_detail(s.user_id, tf)
            except NotFound:
                prev = None
            if prev is not None and prev["doc_type_id"] == dtype:
                dtype = None
        res = store.submit(s.user_id, data=data, filename=filename, form_id=form_id,
                           note=note, ip=h.ip, doc_type=dtype)
    elif kind == "new":
        res = store.submit(s.user_id, data=data, filename=filename,
                           folder_id=h._int(h._one(fields, "folder_id")),
                           form_name=h._one(fields, "form_name"), category=h._one(fields, "category"),
                           note=note, ip=h.ip, doc_type=dtype)
    else:
        raise HttpError(400, "새 양식인지 개정안인지 골라 주세요")
    h._flash("ok", f"올렸습니다 — 검토 대기 (제출 {res['id']}번). 검토자가 승인하면 현행 판이 됩니다")
    h._redirect("/mine")


def _status_tag(st: str) -> str:
    return f'<span class="tag {E(st)}">{E(STATUS_LABEL.get(st, st))}</span>'


def get_mine(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    subs = store.list_submissions(s.user_id, scope="mine", limit=300)
    csrf = E(s.csrf)
    codes = {t["id"]: t["code"] for t in store.list_doc_types(s.user_id)}          # 고른 문서 종류 (F7 문서 종류 검토 4)
    form_types = {f["id"]: f["doc_type_id"] for f in store.list_forms(s.user_id, include_retired=True)}
    rows = []
    for x in subs:
        act = ""
        if x["status"] == "pending":
            act = (f'<form class="inline" method="post" action="/submissions/cancel">'
                   f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="id" value="{x["id"]}">'
                   f'<button class="btn gray sm" type="submit">취소</button></form>')
        elif x["status"] == "approved" and x["form_id"]:
            act = f'<a href="/form?id={x["form_id"]}">양식 보기</a>'
        why = f'<div class="muted">반려 사유: {E(x["reason"])}</div>' if x["reason"] else ""
        if x.get("decision_note"):
            why += f'<div class="muted">승인 메모: {E(x["decision_note"])}</div>'
        who = f'<div class="muted">{E(x["decided_by_name"])} · {E(_fmt_time(x["decided_at"]))}</div>' \
            if x["decided_at"] else ""
        rows.append(f'<tr><td class="nw">{x["id"]}</td><td>{E(x["form_name"])}<div class="muted">'
                    f'{E(KIND_LABEL.get(x["kind"], x["kind"]))}</div>'
                    f'{_sub_type_short(x, codes, form_types, warn_empty=False)}</td>'
                    f'<td>{E(x["filename"])}<div class="muted">{_fmt_size(x["size"])}</div></td>'
                    f'<td>{E(x["note"])}</td><td class="nw">{E(_fmt_time(x["submitted_at"]))}</td>'
                    f'<td>{_status_tag(x["status"])}{who}{why}</td><td class="nw">{act}</td></tr>')
    table = ("<table><thead><tr><th>번호</th><th>양식</th><th>파일</th><th>설명</th><th>올린 때</th>"
             "<th>상태</th><th></th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>") if rows else \
        '<p class="empty">아직 올린 것이 없습니다</p>'
    h._send(200, h._shell("내 제출", f'<div class="panel">{table}</div>', active="/mine",
                          actions='<a class="btn" href="/upload">양식 올리기</a>'))


def post_cancel(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    h.server.store.cancel(h.sess.user_id, sid, ip=h.ip)
    h._flash("ok", f"제출 {sid}번을 취소했습니다")
    h._redirect("/mine")


# ── 양식 상세·내려받기 ──────────────────────────────────────────────────────

def get_form(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    fid = h._int(h._one(h._query(), "id"))
    d = store.form_detail(s.user_id, fid)
    trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in d["folder_path"])
    meta = []
    if d.get("doc_no"):
        meta.append(f'문서번호 <b class="docno">{E(d["doc_no"])}</b>')
    if d.get("type_mismatch") and s.role in ("admin", "reviewer"):      # 번호의 종류와 다름 (F7 문서 종류 검토 7)
        meta.append(f'<span class="muted">{MISMATCH_TEXT}</span>')
    if d.get("prev_doc_nos"):                                 # 다시 매기기 전 번호 (F7 번호 규칙)
        meta.append(f'이전 번호 <span class="docno">{E(", ".join(d["prev_doc_nos"]))}</span>')
    if d.get("doc_type"):                                     # 문서 종류 (F7 문서 종류)
        meta.append(f'문서 종류 <span class="tag dtype">{E(d["doc_type"])}</span>{E(d["doc_type_name"])}'
                    + ("" if d.get("doc_type_active", True) else " (사용 중지된 종류)"))
    if d["category"]:
        meta.append(f'분류 {E(d["category"])}')
    meta.append(f'현행 v{d["current_number"]}' if d["current_number"] else "현행 판 없음")
    if d["pending"]:
        meta.append(f'검토 대기 {d["pending"]}건')
    retired = ""
    if d["retired"]:
        who = " · ".join(x for x in (d.get("retired_by_name") or "", _fmt_time(d.get("retired_at"))) if x)
        retired = (f'<div class="note warn" role="status"><b>폐기된 양식입니다</b> — 목록에서는 숨겨지고 기록으로 남습니다. '
                   f'내려받을 수는 있지만 새로 쓰지 마세요.'
                   + (f'<div>폐기 사유: {E(d["retired_reason"])}</div>' if d.get("retired_reason") else "")
                   + (f'<div class="muted">{E(who)}</div>' if who else "") + '</div>')
    versions = d["versions"]                                  # 최신 판부터
    dl_mark = ' <span class="tag retired">폐기된 양식</span>' if d["retired"] else ""
    rows = []
    for k, v in enumerate(versions):
        cur = ' <span class="tag approved">현행</span>' if v["id"] == d["current_version_id"] else ""
        prev = versions[k + 1] if k + 1 < len(versions) else None
        cmp_link = (f'<a class="btn gray sm" href="/compare?form={fid}&amp;a={prev["id"]}&amp;b={v["id"]}" '
                    f'title="전 판(v{prev["number"]})과 비교">v{prev["number"]}과 비교</a>') if prev else ""
        # 판·날짜·사람 이름 칸은 줄바꿈하지 않고(nw), 설명·파일 칸이 줄어든다 — 1024px에서 '이검토'가 한 글자씩 꺾이던 것 (f6)
        rows.append(f'<tr><td class="nw"><b>v{v["number"]}</b>{cur}</td>'
                    f'<td class="dt">{E(_fmt_time(v["approved_at"]))}</td>'
                    f'<td><span class="nw">{E(v["uploaded_by_name"])}</span>'
                    f'<div class="muted dt">{E(_fmt_time(v["uploaded_at"]))}</div></td>'
                    f'<td class="nw">{E(v["approved_by_name"])}</td><td class="note-c">{E(v["note"])}</td>'
                    f'<td class="file-c">{E(v["filename"])}<div class="muted">{_fmt_size(v["size"])}</div></td>'
                    f'<td class="acts"><a class="btn sm" href="/download?v={v["id"]}">내려받기</a>{dl_mark} {cmp_link}</td></tr>')
    table = ('<div class="tablewrap"><table class="hist"><thead><tr><th>판</th><th>승인한 날</th><th>올린 사람</th>'
             '<th>승인자</th><th>설명</th><th>파일</th><th></th></tr></thead><tbody>' + "".join(rows)
             + "</tbody></table></div>") if rows else '<p class="empty">아직 승인된 판이 없습니다</p>'
    pick = ""
    if len(versions) >= 2:
        pick = (f'<h3>판끼리 비교</h3><p class="muted">두 판을 골라 무엇이 바뀌었는지 근거 표(이전 값 / 새 값 / 위치)로 봅니다.</p>'
                + _version_picker(fid, versions, versions[1]["id"], versions[0]["id"], s.csrf))
    tools = ""
    if store.is_reviewer_of(s.user_id, d["folder_id"]):
        csrf = E(s.csrf)
        if d["retired"]:
            tools = (f'<details class="tool"><summary>양식 복원</summary>'
                     f'<form method="post" action="/form/restore"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{fid}"><label for="rs">복원 사유 (필수)</label>'
                     f'<input type="text" id="rs" name="reason" required maxlength="500" placeholder="예: 새 양식 적용을 미룸">'
                     f'<div class="form-actions"><button class="btn sm" type="submit">복원하기</button></div></form></details>')
        else:
            tools = (f'<details class="tool"><summary>양식 폐기</summary>'
                     f'<p class="muted">폐기하면 목록에서 숨겨지고 개정안을 받지 않습니다. 판 파일은 그대로 남고 언제든 복원할 수 있습니다.</p>'
                     f'<form method="post" action="/form/retire"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{fid}"><label for="rt">폐기 사유 (필수)</label>'
                     f'<input type="text" id="rt" name="reason" required maxlength="500" placeholder="예: 2027년 양식으로 바뀜">'
                     f'<div class="form-actions"><button class="btn red sm" type="submit">폐기하기</button></div></form></details>')
        tools = (f'<div class="panel"><h2>검토자 도구</h2>{_review_panel(h, d)}{_doctype_tool(h, d)}{tools}'
                 f'{_docno_tool(h, d)}</div>')
    actions = "" if d["retired"] else f'<a class="btn" href="/upload?form={fid}">개정안 올리기</a>'
    body = (f'<div class="crumb"><a href="/forms">전체</a> / {trail}</div>{retired}'
            f'<div class="panel"><p class="muted">{" · ".join(meta)}</p><h3>판 이력</h3>{table}{pick}</div>{tools}')
    h._send(200, h._shell(d["name"], body, active="/forms", actions=actions))


def _compare_button(action: str, csrf: str, fields, label: str = "비교하기") -> str:
    """비교 계산 단추 — POST + CSRF (2026-10-28 보안 F3: 화면을 여는 GET은 계산하지 않는다)."""
    hid = "".join(f'<input type="hidden" name="{E(k)}" value="{E(str(v))}">' for k, v in fields)
    return (f'<form class="inline" method="post" action="{E(action)}"><input type="hidden" name="csrf" '
            f'value="{E(csrf)}">{hid}<button class="btn sm" type="submit">{E(label)}</button></form>')


def _version_picker(fid: int, versions: list, a_id, b_id, csrf: str) -> str:
    """판 두 개 고르기 — 스크립트 없는 POST 양식 (/compare, CSRF). 고르고 누르면 비교해 보기 화면으로 간다 (보안 F3)."""
    def opts(sel):
        return "".join(f'<option value="{v["id"]}"{" selected" if v["id"] == sel else ""}>v{v["number"]} · '
                       f'{E(_fmt_time(v["approved_at"]))}</option>' for v in versions)
    return (f'<form class="pick" method="post" action="/compare"><input type="hidden" name="csrf" value="{E(csrf)}">'
            f'<input type="hidden" name="form" value="{fid}">'
            f'<label class="chk" for="pa">이전</label><select id="pa" name="a">{opts(a_id)}</select>'
            f'<span aria-hidden="true">→</span>'
            f'<label class="chk" for="pb">새</label><select id="pb" name="b">{opts(b_id)}</select>'
            f'<button class="btn sm" type="submit">비교하기</button></form>')


# ── 자동 비교 표 (F3) ───────────────────────────────────────────────────────

def _parts_html(parts: list, mark_tag: str, mark_cls: str = "") -> str:
    """[[조각, 바뀜?]…] → HTML. 바뀐 조각만 강조. 값은 전부 이스케이프."""
    out = []
    for text, changed in parts or []:
        t = E(str(text))
        if changed:
            cls = f' class="{mark_cls}"' if mark_cls else ""
            out.append(f"<{mark_tag}{cls}>{t}</{mark_tag}>")
        else:
            out.append(t)
    return "".join(out)


def _compare_table(rows: list) -> str:
    trs = []
    for r in rows:
        old = (f'<del class="old">{_parts_html(r.get("old_parts"), "span", "hl")}</del>'
               if r.get("old") else '<span class="none">—</span>')
        new = (f'<ins class="new">{_parts_html(r.get("new_parts"), "mark")}</ins>'
               if r.get("new") else '<span class="none">—</span>')
        sub = f'<div class="muted">{E(r["label"])}</div>' if r.get("label") else ""
        trs.append(f'<tr><td class="nw"><span class="tag k-{E(r.get("tone", "info"))}">{E(r.get("kind_label", ""))}</span>'
                   f'</td><td class="name">{E(r.get("name", ""))}{sub}</td><td class="val">{old}</td>'
                   f'<td class="val">{new}</td><td class="muted">{E(r.get("where", ""))}</td></tr>')
    return ('<table class="cmp"><thead><tr><th>구분</th><th>항목</th><th>이전 값</th><th>새 값</th><th>위치</th></tr>'
            '</thead><tbody>' + "".join(trs) + "</tbody></table>")


def _notes_html(notes) -> str:
    notes = [n for n in (notes or []) if str(n).strip()]
    return ('<ul class="notes">' + "".join(f"<li>{E(str(n))}</li>" for n in notes) + "</ul>") if notes else ""


def _compare_html(res: dict, old_label: str, new_label: str, downloads: str = "", retry: str = "") -> str:
    """비교 결과 → 화면 조각. status: ok / unsupported / failed. retry: 실패 때 보일 [다시 비교하기](POST) 단추."""
    st = res.get("status")
    head = (f'<div class="cmp-head"><span>이전: {E(old_label)}</span><span aria-hidden="true">→</span>'
            f'<span>새: {E(new_label)}</span></div>')
    if st == "unsupported":
        return head + f'<div class="note info" role="status">{E(res.get("reason", ""))}</div>{downloads}'
    if st != "ok":
        again = ("잠시 뒤 [다시 비교하기]를 누르면 다시 해 봅니다." if retry else "")
        return (head + f'<div class="note bad" role="alert"><b>비교할 수 없음</b> — {E(res.get("reason", ""))}</div>'
                f'<p class="muted">파일을 내려받아 직접 열어 확인해 주세요. {again}</p>'
                f'{retry}{downloads}')
    rows = res.get("rows") or []
    if not rows:
        return (head + '<div class="note ok" role="status">글자·표로는 바뀐 것이 없습니다 — 서식·그림만 바뀌었을 수 있으니 '
                       '파일을 열어 확인하세요.</div>' + _notes_html(res.get("notes")) + downloads)
    adds = sum(1 for r in rows if r.get("tone") == "add")
    rms = sum(1 for r in rows if r.get("tone") == "rm")
    mods = sum(1 for r in rows if r.get("tone") == "mod")
    tally = " · ".join(x for x in (f"추가 {adds}" if adds else "", f"삭제 {rms}" if rms else "",
                                   f"변경 {mods}" if mods else "") if x)
    count = (f'<div class="cmp-head"><b>변경 {len(rows)}건</b>'
             + (f'<span class="muted">{E(tally)}</span>' if tally else "")
             + '<span class="muted">이전 값은 취소선, 새 값은 굵게 — 바뀐 낱말은 색으로 표시</span></div>')
    return head + count + _compare_table(rows) + _notes_html(res.get("notes")) + downloads


def _summary_html(res: dict, downloads: str = "", retry: str = "") -> str:
    """새 양식 — 비교할 이전 판이 없을 때의 글자 요약. retry: 실패 때 보일 [다시 읽기](POST) 단추."""
    lead = '<div class="note info" role="status"><b>새 양식 — 비교할 이전 판 없음</b>. 아래는 파일에서 읽은 글자 요약입니다.</div>'
    st = res.get("status")
    if st == "unsupported":
        return lead + f'<div class="note info">{E(res.get("reason", ""))}</div>{downloads}'
    if st != "new":
        return lead + (f'<div class="note bad" role="alert"><b>비교할 수 없음</b> — {E(res.get("reason", ""))}</div>'
                       f'{retry}{downloads}')
    s = res.get("summary") or {}
    parts = []
    if s.get("sheets"):
        parts.append(f'<dt>시트</dt><dd>{E(" · ".join(s["sheets"]))}</dd>')
    for k, v in s.get("fields") or []:
        parts.append(f'<dt>{E(k)}</dt><dd>{E(v)}</dd>')
    if s.get("row_count"):
        parts.append(f'<dt>표 행 수</dt><dd>{int(s["row_count"])}행</dd>')
    out = lead + (f'<dl class="kv">{"".join(parts)}</dl>' if parts else "")
    for sheet, cols in s.get("headers") or []:
        out += (f'<h3>칸 이름 — {E(sheet)}</h3><div class="cols">'
                + "".join(f"<span>{E(c)}</span>" for c in cols) + "</div>")
    if not s.get("headers"):                        # 빈 양식(값 행 없음) — 칸에 적힌 글자를 그대로 (f6)
        for unit, texts in s.get("cells") or []:
            out += (f'<h3>칸 글자 — {E(unit)}</h3><div class="cols">'
                    + "".join(f"<span>{E(c)}</span>" for c in texts) + "</div>")
    if s.get("lines"):
        out += '<h3>머리 글줄</h3><ul class="lines">' + "".join(f"<li>{E(x)}</li>" for x in s["lines"]) + "</ul>"
    if not parts and not s.get("headers") and not s.get("lines") and not s.get("cells"):
        out += '<p class="muted">읽을 수 있는 글자가 없습니다.</p>'
    return out + _notes_html(s.get("notes")) + downloads


def _compare_pick(h: FormsHandler, fid: int, a, b):
    """판끼리 비교의 두 판 정하기 — (양식 상세, 이전 판, 새 판) 또는 판이 하나뿐이면 (상세, None, None)."""
    d = h.server.store.form_detail(h.sess.user_id, fid)
    versions = d["versions"]
    by_id = {v["id"]: v for v in versions}
    for x in (a, b):
        if x is not None and x not in by_id:
            raise HttpError(404, "이 양식의 판이 아닙니다")
    if len(versions) < 2:
        return d, None, None
    if b is None:
        b = d["current_version_id"] if d["current_version_id"] in by_id else versions[0]["id"]
    if a is None:
        older = [v for v in versions if v["number"] < by_id[b]["number"]]
        a = older[0]["id"] if older else next(v["id"] for v in versions if v["id"] != b)
    va, vb = by_id[a], by_id[b]
    if va["number"] > vb["number"]:                 # 이전 → 새 순서로 (취소선이 옛 값에 가게)
        va, vb = vb, va
    return d, va, vb


def post_compare(h: FormsHandler) -> None:
    """[비교하기] — 판끼리 비교를 계산해 캐시에 둔 뒤 보기 화면(GET)으로 (2026-10-28 보안 F3: GET은 계산하지 않는다)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "form"))
    d, va, vb = _compare_pick(h, fid, h._int(h._one(f, "a"), required=False), h._int(h._one(f, "b"), required=False))
    if va is not None and va["id"] != vb["id"]:
        h._allow_compare()
        out = h.server.comparer.compare_versions(h.sess.user_id, va["id"], vb["id"], ip=h.ip)
        if out["result"].get("status") == "failed" and "밀려" in str(out["result"].get("reason", "")):
            h._flash("bad", "비교가 밀려 있습니다 — 잠시 뒤 [비교하기]를 다시 눌러 주세요")
        h._redirect(f"/compare?form={fid}&a={va['id']}&b={vb['id']}")
        return
    h._redirect(f"/compare?form={fid}")


def get_compare(h: FormsHandler) -> None:
    """판끼리 비교 — 기본은 현행과 바로 전 판. 누구나(판은 모두가 볼 수 있다). 내려받기 감사 기록은 남기지 않는다.
    이 화면(GET)은 **캐시만 본다** — 아직 비교하지 않은 두 판이면 [비교하기](POST+CSRF) 단추를 보인다 (보안 F3)."""
    store, s = h.server.store, h.sess
    qd = h._query()
    fid = h._int(h._one(qd, "form"))
    a = h._int(h._one(qd, "a"), required=False)
    b = h._int(h._one(qd, "b"), required=False)
    d, va0, vb0 = _compare_pick(h, fid, a, b)
    versions = d["versions"]
    trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in d["folder_path"])
    crumb = (f'<div class="crumb"><a href="/forms">전체</a> / {trail} / '
             f'<a href="/form?id={fid}">{E(d["name"])}</a></div>')
    if va0 is None:
        body = crumb + '<div class="panel"><p class="empty">판이 둘 이상 있어야 비교할 수 있습니다.</p></div>'
        h._send(200, h._shell(f"{d['name']} — 판끼리 비교", body, active="/forms"))
        return
    va, vb = va0, vb0
    picker = _version_picker(fid, versions, va["id"], vb["id"], s.csrf)
    retired = '<div class="note warn">폐기된 양식입니다.</div>' if d["retired"] else ""
    dl = (f'<p class="form-actions"><a class="btn gray sm" href="/download?v={va["id"]}">v{va["number"]} 내려받기</a>'
          f'<a class="btn gray sm" href="/download?v={vb["id"]}">v{vb["number"]} 내려받기</a></p>')
    if va["id"] == vb["id"]:
        inner = '<div class="note info">같은 판을 골랐습니다 — 다른 두 판을 골라 주세요.</div>'
    else:
        out = h.server.comparer.compare_versions(s.user_id, va["id"], vb["id"], ip=h.ip, compute=False)
        old_l, new_l = f"v{va['number']} ({va['filename']})", f"v{vb['number']} ({vb['filename']})"
        run_btn = _compare_button("/compare", s.csrf, (("form", fid), ("a", va["id"]), ("b", vb["id"])))
        if out["result"] is None:
            inner = (f'<div class="cmp-head"><span>이전: {E(old_l)}</span><span aria-hidden="true">→</span>'
                     f'<span>새: {E(new_l)}</span></div>'
                     f'<div class="note info" role="status">아직 비교하지 않은 두 판입니다 — [비교하기]를 누르면 '
                     f'근거 표(이전 값 / 새 값 / 위치)를 만듭니다. 한 번 비교한 결과는 저장돼 다음부터 바로 보입니다.</div>'
                     f'{run_btn}{dl}')
        else:
            again = _compare_button("/compare", s.csrf, (("form", fid), ("a", va["id"]), ("b", vb["id"])),
                                    "다시 비교하기")
            inner = _compare_html(out["result"], old_l, new_l, dl, retry=again)
    body = crumb + retired + f'<div class="panel">{picker}{inner}</div>'
    h._send(200, h._shell(f"{d['name']} — 판끼리 비교", body, active="/forms"))


def post_retire(h: FormsHandler) -> None:
    _set_retired(h, True)


def post_restore(h: FormsHandler) -> None:
    _set_retired(h, False)


def _set_retired(h: FormsHandler, retired: bool) -> None:
    """폐기·복원 — 사유 필수. 역할은 여기서, 맡은 폴더인지는 store가 다시 본다."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    reason = h._one(f, "reason").strip()
    if not reason:
        raise HttpError(400, f"{'폐기' if retired else '복원'} 사유를 적어 주세요")
    h.server.store.set_retired(h.sess.user_id, fid, retired, ip=h.ip, reason=reason)
    h.server.on_event("retired" if retired else "restored", form_id=fid)
    h._flash("ok", "양식을 폐기했습니다 — 목록에서 숨겨지고 '폐기 양식도 보기'에서만 보입니다" if retired
             else "양식을 복원했습니다 — 다시 목록에 보입니다")
    h._redirect(f"/form?id={fid}")


def _stream_file(h: FormsHandler, path, filename: str, size: int) -> None:
    h._deadline(int(size))
    h.send_response(200)
    h.send_header("Content-Type", "application/octet-stream")
    h.send_header("Content-Length", str(int(size)))
    h.send_header("Content-Disposition", content_disposition(filename))
    h.end_headers()
    sent = 0
    with open(path, "rb") as f:
        while sent < size:
            chunk = f.read(min(256 * 1024, size - sent))
            if not chunk:
                break
            h._out(chunk)
            sent += len(chunk)
    h.close_connection = True


def get_download(h: FormsHandler) -> None:
    vid = h._int(h._one(h._query(), "v"))
    info = h.server.store.version_file(h.sess.user_id, vid, ip=h.ip)
    # 폐기된 양식은 받은 파일 이름에도 표시를 붙인다 — 내려받은 뒤 탐색기에서도 옛 양식인 줄 알게 (F3)
    name = RETIRED_PREFIX + info["filename"] if info.get("retired") else info["filename"]
    _stream_file(h, info["path"], name, info["size"])


def get_review_file(h: FormsHandler) -> None:
    sid = h._int(h._one(h._query(), "s"))
    info = h.server.store.submission_file(h.sess.user_id, sid, ip=h.ip)
    _stream_file(h, info["path"], info["filename"], info["size"])


# ── 검토 대기 (최소판 — 자동 비교·판끼리 비교·폐기 화면은 F3) ───────────────────────

def _require_reviewer_role(h: FormsHandler) -> None:
    if h.sess.role not in ("reviewer", "admin"):
        raise HttpError(403, "검토자와 관리자만 볼 수 있습니다")


def get_review(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    subs = store.list_submissions(s.user_id, scope="review", status="pending")
    paths = {n["id"]: p for n, _, p in h._folders()}
    csrf = E(s.csrf)
    comparer = h.server.comparer
    codes = {t["id"]: t["code"] for t in store.list_doc_types(s.user_id)}          # 문서 종류 (F7 문서 종류 검토 1)
    form_types = {f["id"]: f["doc_type_id"] for f in store.list_forms(s.user_id, include_retired=True)}
    warn_empty = rule_uses_type(parse_docno_pattern(store.docno_rule()["pattern"])[1])
    rows = []
    for x in subs:
        target = (f'<a href="/form?id={x["form_id"]}">{E(x["form_name"])}</a>' if x["form_id"]
                  else E(x["form_name"]))
        target += _sub_type_short(x, codes, form_types, warn_empty=warn_empty)
        # 변경 건수는 이미 비교해 둔 것만 보인다 — 목록을 그리려고 비교를 돌리지 않는다
        n = comparer.cached_count(s.user_id, x["id"]) if (comparer is not None and x["form_id"]) else None
        badge = (f'<div class="muted">현행 판과 비교: 변경 {n}건</div>' if n is not None
                 else ('<div class="muted">열면 현행 판과 자동 비교</div>' if x["form_id"] else
                       '<div class="muted">새 양식 — 열면 글자 요약</div>'))
        rows.append(
            f'<tr><td class="nw">{x["id"]}</td><td>{target}<div class="muted">{E(KIND_LABEL.get(x["kind"], ""))} · '
            f'{E(paths.get(x["folder_id"], ""))}</div></td>'
            f'<td><a href="/review/file?s={x["id"]}">{E(x["filename"])}</a><div class="muted">{_fmt_size(x["size"])}'
            f'</div></td><td>{E(x["submitted_by_name"])}<div class="muted">{E(_fmt_time(x["submitted_at"]))}</div></td>'
            f'<td>{E(x["note"])}</td><td><a class="btn sm" href="/review/item?id={x["id"]}">비교 보며 검토</a>{badge}'
            f'<details class="tool"><summary>바로 처리</summary>'
            f'<form class="inline" method="post" action="/review/approve"><input type="hidden" name="csrf" value="{csrf}">'
            f'<input type="hidden" name="id" value="{x["id"]}"><button class="btn sm" type="submit">승인</button></form>'
            f'<form class="inline" method="post" action="/review/reject"><input type="hidden" name="csrf" value="{csrf}">'
            f'<input type="hidden" name="id" value="{x["id"]}">'
            f'<input type="text" name="reason" required maxlength="500" placeholder="반려 사유 (필수)" aria-label="반려 사유">'
            f'<button class="btn red sm" type="submit">반려</button></form></details></td></tr>')
    table = ("<table><thead><tr><th>번호</th><th>양식</th><th>파일</th><th>올린 사람</th><th>설명</th><th>처리</th>"
             "</tr></thead><tbody>" + "".join(rows) + "</tbody></table>") if rows else \
        '<p class="empty">검토할 것이 없습니다</p>'
    hint = ('<p class="muted">[비교 보며 검토]를 누르면 개정안은 현행 판과의 자동 비교 표(이전 값 / 새 값 / 위치)가, '
            '새 양식은 파일에서 읽은 글자 요약이 보입니다. 승인할 때 메모를, 반려할 때 사유(필수)를 남깁니다.</p>')
    h._send(200, h._shell("검토 대기", f'<div class="panel">{hint}{table}</div>', active="/review"))


def get_review_item(h: FormsHandler) -> None:
    """검토 화면 하나 — 개정안은 현행 판과 자동 비교, 새 양식은 글자 요약. 승인(메모)·반려(사유 필수)."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    sid = h._int(h._one(h._query(), "id"))
    sub = store.submission(s.user_id, sid)
    if not store.is_reviewer_of(s.user_id, sub["folder_id"]):
        raise HttpError(403, "이 폴더의 검토자만 볼 수 있습니다")
    paths = {n["id"]: p for n, _, p in h._folders()}
    target = (f'<a href="/form?id={sub["form_id"]}">{E(sub["form_name"])}</a>' if sub["form_id"]
              else E(sub["form_name"]))
    info = (f'<dl class="kv"><dt>양식</dt><dd>{target}</dd>'
            f'<dt>구분</dt><dd>{E(KIND_LABEL.get(sub["kind"], sub["kind"]))}</dd>'
            f'<dt>폴더</dt><dd>{E(paths.get(sub["folder_id"], ""))}</dd>'
            f'{_sub_type_row(h, sub)}'
            f'<dt>올린 사람</dt><dd>{E(sub["submitted_by_name"])} · {E(_fmt_time(sub["submitted_at"]))}</dd>'
            f'<dt>설명</dt><dd>{E(sub["note"]) or "<span class=none>—</span>"}</dd>'
            f'<dt>파일</dt><dd>{E(sub["filename"])} <span class="muted">{_fmt_size(sub["size"])}</span></dd>'
            f'<dt>상태</dt><dd>{_status_tag(sub["status"])}</dd></dl>')
    if sub["status"] != "pending":
        extra = ""
        if sub["reason"]:
            extra += f'<p>반려 사유: {E(sub["reason"])}</p>'
        if sub.get("decision_note"):
            extra += f'<p>승인 메모: {E(sub["decision_note"])}</p>'
        body = (f'<div class="crumb"><a href="/review">검토 대기</a> / 제출 {sid}번</div>'
                f'<div class="panel">{info}<div class="note info">이미 처리된 제출입니다 '
                f'({E(sub["decided_by_name"])} · {E(_fmt_time(sub["decided_at"]))})</div>{extra}</div>')
        h._send(200, h._shell(f"제출 {sid}번", body, active="/review"))
        return
    # 자동 비교는 '맡은 폴더의 검토자가, 검토 대기 1건당 한 번'만 이 화면(GET)에서 계산한다 — 그 뒤로는 캐시만 보고,
    # 다시 계산은 [다시 비교하기](POST+CSRF). 직원은 이 화면에 들어오지 못한다(위 403). (2026-10-28 보안 F3)
    comparer = h.server.comparer
    rv = comparer.review_submission(s.user_id, sid, ip=h.ip, compute=False)
    if rv["result"] is None and comparer.claim_auto(sid):
        h._allow_compare()
        rv = comparer.review_submission(s.user_id, sid, ip=h.ip)
    run_btn = _compare_button("/review/compare", s.csrf, (("id", sid),))
    again_btn = _compare_button("/review/compare", s.csrf, (("id", sid),), "다시 비교하기")
    not_yet = ('<div class="note info" role="status">아직 비교하지 않았습니다 — [비교하기]를 누르면 '
               '{what}을(를) 만듭니다.</div>')
    open_new = f'<a class="btn gray sm" href="/review/file?s={sid}">올린 파일 열어 보기</a>'
    if rv["mode"] == "revision":
        old = rv["old"]
        dl = (f'<p class="form-actions">{open_new}'
              f'<a class="btn gray sm" href="/download?v={int(old["id"])}">'
              f'현행 v{old["number"]} 내려받기</a></p>')
        if rv["result"] is None:
            cmp_html = ('<h2>현행 판과 자동 비교</h2>' + not_yet.format(what="현행 판과의 근거 표") + run_btn + dl)
        else:
            cmp_html = ('<h2>현행 판과 자동 비교</h2>'
                        + _compare_html(rv["result"], f"현행 v{old['number']} ({old['filename']})",
                                        f"올린 파일 ({sub['filename']})", dl, retry=again_btn))
    else:
        if rv["result"] is None:
            cmp_html = ('<h2>올린 양식</h2>' + not_yet.format(what="글자 요약") + run_btn
                        + f'<p class="form-actions">{open_new}</p>')
        else:
            cmp_html = '<h2>올린 양식</h2>' + _summary_html(rv["result"], f'<p class="form-actions">{open_new}</p>',
                                                         retry=again_btn)
    csrf = E(s.csrf)
    decide = (f'<div class="panel"><h2>처리</h2><div class="decide">'
              f'<form method="post" action="/review/approve"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="id" value="{sid}"><label for="memo">승인 메모 (선택 — 올린 사람이 봅니다)</label>'
              f'<textarea id="memo" name="memo" maxlength="500" placeholder="예: 야간수당 열 확인함"></textarea>'
              f'<div class="form-actions"><button class="btn" type="submit">승인 — 새 현행 판으로</button></div></form>'
              f'<form method="post" action="/review/reject"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="id" value="{sid}"><label for="why">반려 사유 (필수 — 올린 사람이 봅니다)</label>'
              f'<textarea id="why" name="reason" required maxlength="500" placeholder="예: 결재란 칸 수가 규정과 다릅니다">'
              f'</textarea><div class="form-actions"><button class="btn red" type="submit">반려</button></div></form>'
              f'</div></div>')
    body = (f'<div class="crumb"><a href="/review">검토 대기</a> / 제출 {sid}번</div>'
            f'<div class="panel">{info}{_sub_type_warning(h, sub)}</div><div class="panel">{cmp_html}</div>{decide}')
    h._send(200, h._shell(f"검토 — {sub['form_name']}", body, active="/review"))


def post_review_compare(h: FormsHandler) -> None:
    """[비교하기]·[다시 비교하기] — 검토 화면의 자동 비교를 (다시) 계산한다. 맡은 폴더의 검토자만, 검토 대기일 때만 (보안 F3)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    sid = h._int(h._one(f, "id"))
    sub = store.submission(s.user_id, sid)
    if not store.is_reviewer_of(s.user_id, sub["folder_id"]):
        raise HttpError(403, "이 폴더의 검토자만 할 수 있습니다")
    if sub["status"] != "pending":
        raise Conflict("이미 처리된 제출입니다")
    h._allow_compare()
    rv = h.server.comparer.review_submission(s.user_id, sid, ip=h.ip)
    res = rv.get("result") or {}
    if res.get("status") == "failed" and "밀려" in str(res.get("reason", "")):
        h._flash("bad", "비교가 밀려 있습니다 — 잠시 뒤 [비교하기]를 다시 눌러 주세요")
    h._redirect(f"/review/item?id={sid}")


def post_approve(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    res = h.server.store.approve(h.sess.user_id, sid, ip=h.ip, memo=h._one(f, "memo"))
    h.server.on_event("approved", submission_id=sid, result=res)
    h._flash("ok", f"승인했습니다 — 제출 {sid}번이 v{res['number']}(현행 판)이 됐습니다")
    h._redirect("/review")


def post_reject(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    h.server.store.reject(h.sess.user_id, sid, h._one(f, "reason"), ip=h.ip)
    h.server.on_event("rejected", submission_id=sid)
    h._flash("ok", f"반려했습니다 — 제출 {sid}번 (올린 사람이 사유를 봅니다)")
    h._redirect("/review")


# ── 문서 관리 대장·문서번호·정기 검토 (F7 ISO, 2026-10-29) ────────────────────────
# 권한은 store가 다시 본다(숨긴 단추에 기대지 않는다): 대장·기한 목록·검토함·주기는 관리자와 그 폴더 검토자,
# 문서번호 고치기·일괄 매기기는 관리자, 번호 머리는 폴더 이름 바꾸기와 같은 권한. 모든 POST는 CSRF, GET은 읽기만
# (엑셀 내려받기는 감사 기록 한 줄만 남긴다 — 판 내려받기와 같다).

def _state_tag(state: str) -> str:
    label, cls = REVIEW_STATE.get(state, ("", ""))
    if not label:
        return ""
    if cls == "off":
        return f' <span class="muted">{E(label)}</span>'
    return f' <span class="tag {cls}">{E(label)}</span>'


def _review_panel(h: FormsHandler, d: dict) -> str:
    """양식 상세의 정기 검토 칸 — 주기·최근 검토·다음 기한, [검토함 — 바꿀 것 없음], 주기 바꾸기 (검토자 도구 안)."""
    store = h.server.store
    rv = store.review_state(d.get("review_months"), d.get("last_reviewed_at"), d.get("current_approved_at"),
                            retired=d["retired"])
    every = "안 함" if rv["months"] == 0 else f"{rv['months']}개월마다"
    src = "전체 기본값 따름" if rv["inherit"] else "이 양식만 따로"
    due = rv["due"].isoformat() if rv["due"] else "—"
    info = (f'<div class="reviewinfo"><span>검토 주기: <b>{E(every)}</b> <span class="muted">({src})</span></span>'
            f'<span>시행일: {E(str(d.get("current_approved_at") or "")[:10] or "—")}</span>'
            f'<span>최근 검토: {E(str(d.get("last_reviewed_at") or "")[:10] or "—")}</span>'
            f'<span>다음 기한: <b>{E(due)}</b>{_state_tag(rv["state"])}</span></div>')
    out = '<h3>정기 검토</h3>' + info
    fid = d["id"]
    if d["retired"]:
        return out + '<p class="muted">폐기된 양식은 정기 검토하지 않습니다.</p>'
    out += (f'<form class="inline" method="post" action="/register/reviewed">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{fid}"><input type="hidden" name="back" value="/form?id={fid}">'
            f'<input type="text" class="memo" name="memo" maxlength="500" placeholder="메모 (선택)" aria-label="검토 메모">'
            f'<button class="btn sm" type="submit">검토함 — 바꿀 것 없음</button></form>'
            f'<p class="muted">고칠 것이 있으면 [개정안 올리기]로 올리세요 — 새 판이 승인되면 그날부터 다시 셉니다.</p>')
    cur = d.get("review_months")
    sel = "inherit" if cur is None else ("off" if cur == 0 else "months")

    def opt(v, label):
        return f'<option value="{v}"{" selected" if v == sel else ""}>{E(label)}</option>'
    dflt = store.default_review_months()
    out += (f'<details class="tool"><summary>검토 주기 바꾸기</summary>'
            f'<form class="inline" method="post" action="/form/review-months">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{fid}">'
            f'<select name="mode" aria-label="검토 주기">'
            f'{opt("inherit", f"전체 기본값 ({dflt}개월)" if dflt else "전체 기본값 (지금 꺼짐)")}'
            f'{opt("months", "따로 정함")}{opt("off", "검토 안 함")}</select>'
            f'<input type="text" class="months" name="months" inputmode="numeric" maxlength="3" '
            f'value="{cur if cur else ""}" aria-label="개월 수" placeholder="개월"> 개월 '
            f'<button class="btn gray sm" type="submit">저장</button></form></details>')
    return out


def _sub_types(sub: dict, form_types: dict) -> tuple:
    """제출의 (지금 종류 id, 고른 종류 id, 승인 뒤 종류 id) — 개정안의 고른 값 None = 그 양식의 지금 종류 그대로."""
    chosen = sub.get("doc_type_id")
    if sub.get("kind") == "revision" and sub.get("form_id"):     # 승인된 새 양식도 form_id가 생기므로 구분(kind)으로 본다
        cur = form_types.get(sub["form_id"])
        return cur, chosen, (chosen if chosen is not None else cur)
    return None, chosen, chosen


def _sub_type_short(sub: dict, codes: dict, form_types: dict, *, warn_empty: bool) -> str:
    """목록(검토 대기·내 제출)의 한 줄 — 새 양식 '문서 종류 QI', 바꾸는 개정안 'QF → QP', 결과가 종류 없음이면
    warn_empty(규칙에 {종류}가 있을 때)일 때만 '문서 종류 없음'."""
    cur, chosen, result = _sub_types(sub, form_types)
    if sub.get("status") != "pending":                           # 처리된 것은 고른 종류만 (지금 종류는 그 뒤에 바뀌었을 수 있다)
        return f'<div class="muted">문서 종류 {E(codes.get(chosen, "?"))}</div>' if chosen is not None else ""
    if sub.get("kind") == "revision" and chosen is not None and chosen != cur:
        return (f'<div class="muted">문서 종류 {E(codes.get(cur, "없음") if cur is not None else "없음")} → '
                f'{E(codes.get(chosen, "?"))}</div>')
    if sub.get("kind") != "revision" and chosen is not None:
        return f'<div class="muted">문서 종류 {E(codes.get(chosen, "?"))}</div>'
    if result is None and warn_empty:
        return '<div class="typewarn">문서 종류 없음</div>'
    return ""


def _sub_type_row(h: FormsHandler, sub: dict) -> str:
    """검토 화면의 '문서 종류' 줄 — 늘 보인다(없음 포함). 새 양식은 고른 종류, 개정안은 지금 종류(그대로) 또는 지금 → 새 종류.
    검토 대기면 승인 전에 고치는 칸(POST /review/doctype)을 함께 둔다."""
    store = h.server.store
    types = store.list_doc_types(h.sess.user_id)
    by_id = {t["id"]: t for t in types}

    def label(i):
        t = by_id.get(i)
        return (_type_label(t["code"], t["name"]) + ("" if t["active"] else " (사용 중지 — 승인해도 적용 안 됨)")) \
            if t else "없음"
    rev = sub.get("kind") == "revision" and bool(sub.get("form_id"))     # 승인된 새 양식도 form_id가 생긴다
    cur = store.form_detail(h.sess.user_id, sub["form_id"])["doc_type_id"] if rev else None
    tid = sub.get("doc_type_id")
    if sub.get("status") != "pending":                         # 처리된 제출 — 그때 고른 종류만
        shown = E(label(tid)) if tid is not None else ('<span class="muted">(그대로)</span>' if rev else "없음")
    elif rev:
        if tid is None or tid == cur:
            shown = f'{E(label(cur))} <span class="muted">(그대로)</span>'
        else:
            shown = (f'{E(label(cur))} → <b>{E(label(tid))}</b> '
                     f'<span class="muted">(승인하면 바뀝니다 — 문서번호는 그대로)</span>')
    else:
        shown = E(label(tid))
    edit = ""
    if sub.get("status") == "pending" and (types or tid is not None):
        sel = tid if tid is not None else (cur if rev else None)
        empty = "(지금 종류 그대로)" if rev else "(없음)"
        edit = (f'<details class="tool"><summary>승인 전에 문서 종류 고치기</summary>'
                f'<form class="inline" method="post" action="/review/doctype">{_hidden(h)}'
                f'<input type="hidden" name="id" value="{sub["id"]}">'
                f'<select name="doc_type" aria-label="문서 종류">'
                f'{_type_options(types, sel, empty, keep=cur if cur is not None else tid)}</select>'
                f'<button class="btn gray sm" type="submit">종류 저장</button></form></details>')
    return f'<dt>문서 종류</dt><dd>{shown}{edit}</dd>'


def _sub_type_warning(h: FormsHandler, sub: dict) -> str:
    """규칙에 {종류}가 있는데 이대로 승인하면 종류 없이 **새 번호**가 매겨질 때의 경고 (검토 2)."""
    store = h.server.store
    if sub.get("status") != "pending" or not rule_uses_type(parse_docno_pattern(store.docno_rule()["pattern"])[1]):
        return ""
    folder_id, form = sub["folder_id"], None
    if sub.get("form_id"):
        form = store.form_detail(h.sess.user_id, sub["form_id"])
        folder_id = form["folder_id"]
        if form.get("doc_no"):
            return ""                                # 이미 번호가 있는 양식 — 승인해도 번호는 그대로
    form_types = {sub["form_id"]: form["doc_type_id"]} if form else {}
    result = _sub_types(sub, form_types)[2]
    active = {t["id"] for t in store.list_doc_types(h.sess.user_id, active_only=True)}
    if result is not None and (result in active or (form and result == form["doc_type_id"])):
        return ""
    example = store.preview_doc_no(folder_id, None)
    return (f'<div class="note warn" role="status">문서 종류가 없습니다 — 이대로 승인하면 {E(example)}처럼 종류 없이 번호가 '
            f'매겨지고, 나중에 종류를 바꿔도 번호는 그대로입니다.</div>')


def post_review_doctype(h: FormsHandler) -> None:
    """승인 전에 검토 대기 제출의 문서 종류 고치기 — 관리자나 그 폴더 검토자, 검토 대기만(store가 다시 확인). 감사 기록."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    tid = h._int(h._one(f, "doc_type"), required=False)
    store = h.server.store
    try:
        changed = store.set_submission_doc_type(h.sess.user_id, sid, tid, ip=h.ip)
    except InvalidInput as e:
        store.submission(h.sess.user_id, sid)                  # 없는 제출이면 404
        h._flash("bad", f"문서 종류를 바꾸지 않았습니다 — {e}")
        h._redirect(f"/review/item?id={sid}")
        return
    h._flash("ok", "승인 전 문서 종류를 고쳤습니다" if changed else "바뀐 것이 없습니다")
    h._redirect(f"/review/item?id={sid}")


def _doctype_tool(h: FormsHandler, d: dict) -> str:
    """양식의 문서 종류 바꾸기 — 관리자나 그 폴더 검토자(검토 주기와 같은 권한). 번호는 그대로."""
    types = h.server.store.list_doc_types(h.sess.user_id)
    if not types and d.get("doc_type_id") is None:
        return ""
    return (f'<details class="tool"><summary>문서 종류 바꾸기</summary>'
            f'<p class="muted">종류를 바꿔도 이미 매긴 문서번호는 그대로입니다 — 번호 규칙에 {{종류}}가 있고 번호까지 맞추려면 '
            f'관리자가 [문서번호 규칙 › 다시 매기기]를 씁니다.</p>'
            f'<form class="inline" method="post" action="/form/doctype">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{d["id"]}">'
            f'<select name="doc_type" aria-label="문서 종류">'
            f'{_type_options(types, d.get("doc_type_id"), "(없음)", keep=d.get("doc_type_id"))}</select>'
            f'<button class="btn gray sm" type="submit">종류 저장</button></form></details>')


def post_form_doctype(h: FormsHandler) -> None:
    """양식의 문서 종류 바꾸기 — 관리자나 그 폴더 검토자(store가 다시 확인). 빈 값 = 종류 없음."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    tid = h._int(h._one(f, "doc_type"), required=False)
    store = h.server.store
    try:
        changed = store.set_form_doc_type(h.sess.user_id, fid, tid, ip=h.ip)
    except InvalidInput as e:
        store.form_detail(h.sess.user_id, fid)                  # 없는 양식이면 404
        h._flash("bad", f"문서 종류를 바꾸지 않았습니다 — {e}")
        h._redirect(f"/form?id={fid}")
        return
    h._flash("ok", ("문서 종류를 바꿨습니다 — 이미 매긴 문서번호는 그대로입니다" if changed else "바뀐 것이 없습니다"))
    h._redirect(f"/form?id={fid}")


def _docno_tool(h: FormsHandler, d: dict) -> str:
    """문서번호 고치기 — 관리자만 보인다(서버도 관리자만 받는다)."""
    if h.sess.role != "admin":
        return ""
    return (f'<details class="tool"><summary>문서번호 고치기</summary>'
            f'<p class="muted">번호는 처음 승인 때 저절로 매겨지고 폴더를 옮겨도 그대로입니다. 회사 규칙에 맞춰 바꿀 때만 고치세요 '
            f'— 다른 양식이 쓰는 번호는 받지 않습니다.</p>'
            f'<form class="inline" method="post" action="/form/docno">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{d["id"]}">'
            f'<input type="text" class="docno-in" name="doc_no" value="{E(d.get("doc_no") or "")}" maxlength="40" '
            f'aria-label="문서번호" placeholder="예: QA-01-01-001">'
            f'<button class="btn gray sm" type="submit">번호 저장</button></form></details>')


def _register_query(h: FormsHandler) -> bool:
    return h._one(h._query(), "retired") == "1"


def get_register(h: FormsHandler) -> None:
    """문서 관리 대장 화면 — 관리자는 전체, 검토자는 맡은 폴더(상속 포함). 직원은 403. 읽기만."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    retired = _register_query(h)
    reg = store.register(s.user_id, include_retired=retired)
    rows = []
    for r in reg["rows"]:
        no = f'<span class="docno">{E(r["doc_no"])}</span>' if r["doc_no"] else '<span class="none">—</span>'
        if r.get("prev_doc_nos"):
            no += f'<span class="prevno">이전 {E(", ".join(r["prev_doc_nos"]))}</span>'
        if r.get("type_mismatch"):
            no += f'<span class="prevno">{MISMATCH_TEXT}</span>'
        state = '<span class="tag retired">폐기</span>' if r["retired"] else '<span class="tag approved">현행</span>'
        due = (E(r["due"]) + _state_tag(r["state"])) if r["due"] else (
            '<span class="muted">검토 안 함</span>' if r["state"] == "off" else "")
        dt = (f'<span class="tag dtype" title="{E(r["doc_type_name"])}">{E(r["doc_type"])}</span>' if r.get("doc_type")
              else '<span class="none">—</span>')
        rows.append(
            f'<tr><td class="nw">{no}</td><td class="nw">{dt}</td><td class="nw">{E(r["top"])}</td>'
            f'<td class="path-c">{E(r["mid"])}</td>'
            f'<td class="path-c">{E(r["rest"])}</td>'
            f'<td class="name-c"><a href="/form?id={r["id"]}">{E(r["name"])}</a></td>'
            f'<td class="nw">{"v" + str(r["number"]) if r["number"] else ""}</td><td class="nw">{E(r["effective"])}</td>'
            f'<td class="nw">{E(r["approver"])}</td><td class="reason">{E(r["reason"])}</td>'
            f'<td class="nw">{r["revisions"]}</td><td class="nw">{E(r["last_reviewed"]) or "—"}</td>'
            f'<td class="nw">{due}</td><td class="nw">{state}</td></tr>')
    table = ('<div class="tablewrap"><table class="reg"><thead><tr><th>문서번호</th><th>문서 종류</th><th>대분류</th>'
             '<th>중분류</th>'
             '<th>그 아래</th><th>양식명</th><th>현행 판</th><th>시행일</th><th>승인자</th><th>개정 사유</th>'
             '<th>개정 횟수</th><th>최근 검토일</th><th>다음 검토 기한</th><th>상태</th></tr></thead><tbody>'
             + "".join(rows) + "</tbody></table></div>") if rows else \
        '<p class="empty">아직 승인된 양식이 없습니다</p>'
    q = "?retired=1" if retired else ""
    toggle = (f'<a class="btn gray sm" href="/register">폐기 양식 빼기</a>' if retired else
              f'<a class="btn gray sm" href="/register?retired=1">폐기 양식도 보기</a>')
    scope = "모든 폴더" if reg["scope_all"] else "내가 검토하는 폴더(하위 포함)"
    dflt = store.default_review_months()
    intro = (f'<p class="muted">ISO 9001 문서 관리용 목록 — 양식마다 문서번호·현행 판·시행일(현행 판 승인일)·승인자·개정 사유·'
             f'개정 횟수(v1 = 제정, 그 뒤 승인마다 1)·정기 검토 기한을 양식함의 승인 기록에서 그대로 만듭니다. 범위: {E(scope)}. '
             f'정기 검토 기본 주기: {f"{dflt}개월" if dflt else "꺼짐"} (다음 기한 = 최근 검토일과 현행 판 승인일 중 늦은 날 + 주기).</p>')
    bar = (f'<div class="searchbar"><a class="btn sm" href="/register.xlsx{q}">엑셀로 내려받기</a>{toggle}'
           f'<a class="btn gray sm" href="/register/due">검토 기한 목록</a>'
           + (f'<a class="btn gray sm" href="/admin/docno">문서번호 규칙</a>' if s.role == "admin" else "")
           + f'<span class="muted">{len(reg["rows"])}개</span></div>')
    extra = ""
    if s.role == "admin":
        missing = store.missing_doc_no_count()
        if missing:
            extra = (f'<div class="panel"><h2>번호 없는 양식 {missing}개</h2>'
                     f'<p class="muted">문서번호가 생기기 전에 승인된 양식입니다. 누르면 지금 폴더의 번호 머리로 만든 차례대로 '
                     f'번호를 매깁니다(폐기 양식 포함). 한 번 매긴 번호는 바뀌지 않습니다.</p>'
                     f'<form method="post" action="/admin/docno/assign">{_hidden(h)}'
                     f'<button class="btn" type="submit">번호 없는 양식에 번호 매기기</button></form></div>')
    body = f'{_due_banner(h)}<div class="panel">{intro}{bar}{table}</div>{extra}'
    h._send(200, h._shell("문서 관리 대장", body, active="/register"))


def get_register_xlsx(h: FormsHandler) -> None:
    """[엑셀로 내려받기] — 메모리에서 만든 xlsx(디스크 쓰기 없음). 감사 기록(register_export)을 남긴다."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    retired = _register_query(h)
    reg = store.register(s.user_id, include_retired=retired, history=True)
    gen = _fmt_time(now_text(store.clock()))
    scope = "전체" if reg["scope_all"] else "검토하는 폴더"
    data = ledger.register_xlsx(reg, generated_at=gen, scope_text=scope, include_retired=retired)
    name = f"문서관리대장_{store.today():%Y%m%d}.xlsx"
    store.record_audit(s.user_id, "register_export", "register", ip=h.ip,
                       detail=f"{name} — 양식 {len(reg['rows'])}개 · 판 {len(reg['history'])}개 · "
                              f"{'폐기 포함' if retired else '현행만'} · 범위 {scope}")
    h._deadline(len(data))
    h._send(200, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            extra=(("Content-Disposition", content_disposition(name)),))
    h.close_connection = True


def get_register_due(h: FormsHandler) -> None:
    """정기 검토 기한 목록 — 지난 것과 30일 안에 오는 것. 줄마다 [검토함 — 바꿀 것 없음](POST)과 개정안 올리기 안내."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    due = store.due_forms(s.user_id)
    rows = []
    for r in due:
        no = f'<span class="docno">{E(r["doc_no"])}</span>' if r["doc_no"] else ""
        act = (f'<form class="inline" method="post" action="/register/reviewed">{_hidden(h)}'
               f'<input type="hidden" name="id" value="{r["id"]}"><input type="hidden" name="back" value="/register/due">'
               f'<input type="text" class="memo" name="memo" maxlength="500" placeholder="메모 (선택)" '
               f'aria-label="{E(r["name"])} 검토 메모"><button class="btn sm" type="submit">검토함 — 바꿀 것 없음</button>'
               f'</form><div class="muted">고칠 것이 있으면 <a href="/upload?form={r["id"]}">개정안 올리기</a></div>')
        rows.append(f'<tr><td class="name-c">{no}<a href="/form?id={r["id"]}">{E(r["name"])}</a>'
                    f'<div class="muted">{E(r["path"])}</div></td>'
                    f'<td class="nw">{E(r["due"])}{_state_tag(r["state"])}</td>'
                    f'<td class="nw">{E(r["last_reviewed"]) or "—"}<div class="muted">시행 {E(r["effective"])}</div></td>'
                    f'<td class="act">{act}</td></tr>')
    table = ('<div class="tablewrap"><table class="due"><thead><tr><th>양식</th><th>다음 검토 기한</th>'
             '<th>최근 검토</th><th>처리</th></tr></thead><tbody>' + "".join(rows) + "</tbody></table></div>") if rows \
        else '<p class="empty">기한이 지났거나 곧 오는 양식이 없습니다</p>'
    over = sum(1 for r in due if r["state"] == "overdue")
    intro = (f'<p class="muted">정기 검토 기한이 지난 양식 <b>{over}개</b>와 {REVIEW_SOON_DAYS}일 안에 오는 양식 '
             f'{len(due) - over}개. 내용을 확인해 바꿀 것이 없으면 [검토함]을 누르세요 — 오늘 날짜로 적히고 다음 기한이 다시 '
             f'셉니다(감사 기록에 남음). 고칠 것이 있으면 개정안을 올리세요 — 새 판이 승인되면 그것이 검토입니다.</p>')
    body = (f'<div class="crumb"><a href="/register">문서 관리 대장</a> / 검토 기한</div>'
            f'<div class="panel">{intro}{table}</div>')
    h._send(200, h._shell("정기 검토 기한", body, active="/register"))


def post_register_reviewed(h: FormsHandler) -> None:
    """[검토함 — 바꿀 것 없음] — 관리자나 그 폴더 검토자 (store가 다시 확인)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    h.server.store.mark_reviewed(h.sess.user_id, fid, h._one(f, "memo"), ip=h.ip)
    h._flash("ok", "정기 검토를 적었습니다 — 오늘부터 다음 기한을 다시 셉니다")
    h._redirect(_safe_back(h._one(f, "back") or "/register/due"))


def post_form_review_months(h: FormsHandler) -> None:
    """양식별 검토 주기 — mode: inherit(전체 기본값) / off(안 함) / months(따로, 1~120개월)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    mode = h._one(f, "mode")
    if mode == "inherit":
        months = None
    elif mode == "off":
        months = 0
    elif mode == "months":
        months = h._int(h._one(f, "months"), required=False)
        if not months:
            raise HttpError(400, f"개월 수를 1~{REVIEW_MONTHS_MAX}로 적어 주세요 (검토하지 않으려면 '검토 안 함')")
    else:
        raise HttpError(400, "검토 주기를 골라 주세요")
    h.server.store.set_review_months(h.sess.user_id, fid, months, ip=h.ip)
    h._flash("ok", "검토 주기를 저장했습니다")
    h._redirect(f"/form?id={fid}")


def post_form_docno(h: FormsHandler) -> None:
    """문서번호 고치기 — 관리자만. 다른 양식이 쓰는 번호·형식이 틀린 번호는 받지 않고 화면에 알린다."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    try:
        v = h.server.store.set_doc_no(h.sess.user_id, fid, h._one(f, "doc_no"), ip=h.ip)
    except (Conflict, InvalidInput) as e:
        h.server.store.form_detail(h.sess.user_id, fid)          # 없는 양식이면 404
        h._flash("bad", f"문서번호를 바꾸지 않았습니다 — {e}")
        h._redirect(f"/form?id={fid}")
        return
    h._flash("ok", f"문서번호를 {v}(으)로 정했습니다")
    h._redirect(f"/form?id={fid}")


def post_docno_assign(h: FormsHandler) -> None:
    """[번호 없는 양식에 번호 매기기] — 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    done = h.server.store.assign_missing_doc_numbers(h.sess.user_id, ip=h.ip)
    h._flash("ok", f"양식 {len(done)}개에 문서번호를 매겼습니다" if done else "번호 없는 양식이 없습니다")
    h._redirect("/register")


def post_folder_code(h: FormsHandler) -> None:
    """폴더 번호 머리 — 관리자나 그 폴더 검토자 (이름 바꾸기와 같은 권한, store가 확인)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    back = _safe_back(h._one(f, "back") or f"/forms?folder={fid}")
    if not h.server.store.is_reviewer_of(h.sess.user_id, fid):
        raise PermissionDenied("이 폴더의 검토자만 번호 머리를 바꿀 수 있습니다")
    try:
        v = h.server.store.set_folder_code(h.sess.user_id, fid, h._one(f, "code"), ip=h.ip)
    except InvalidInput as e:
        h._flash("bad", str(e))
        h._redirect(back)
        return
    h._flash("ok", f"번호 머리를 {v}(으)로 정했습니다 — 이미 매긴 문서번호는 그대로입니다" if v
             else "번호 머리를 지웠습니다 — 이미 매긴 문서번호는 그대로입니다")
    h._redirect(back)


# ── 문서번호 규칙·다시 매기기 (F7 번호 규칙, 2026-10-29) ────────────────────────────────
# 관리자만(store도 다시 본다). GET은 읽기만 — ?preset=은 규칙 칸만 채우고 저장하지 않는다. 미리보기는 상태를 바꾸지 않는
# POST(스크립트 없이 서버가 계산), [저장]·[다시 매기기 실행]은 POST + CSRF. 다시 매기기는 미리보기 목록의 지문(digest)과
# 확인 칸이 있어야 돈다 — 그사이 목록이 바뀌면 거부하고 다시 미리보기를 보게 한다.

# 종류 도입 안내 (F7 문서 종류 검토 6) — 일괄 지정은 한 종류만 되므로 다른 종류는 하나씩 고친 뒤 다시 매기기는 한 번만
MISMATCH_TEXT = "(번호의 종류와 다름 — 다시 매기기 필요)"
_ADOPT_GUIDE = ('가장 많은 종류로 한꺼번에 지정하고, 다른 종류인 양식은 <a href="/register">문서 관리 대장</a>에서 찾아 '
                '양식 상세에서 하나씩 고친 뒤 <a href="/admin/docno#renumber">[다시 매기기]</a>를 한 번만 쓰세요 — 다시 매긴 뒤 '
                '종류를 바꾸면 번호는 그대로라 또 매겨야 합니다.')
RENUMBER_SHOW = 500                    # 다시 매기기 미리보기 표에 보이는 줄 상한 (넘으면 '외 N개' — 실행은 전부)
DOCNO_TOKEN_HELP = (
    ("{분류}", "위 폴더들의 번호 머리를 위에서부터 모두 이음 (QA-01-01) — 지금까지의 꼴"),
    ("{대}", "대분류(맨 위 폴더) 머리"), ("{중}", "중분류(2단) 머리"), ("{소}", "소분류(3단) 머리"),
    ("{종류}", "양식의 문서 종류 기호 (QP 절차서·QF 양식…) — 같은 폴더 안에서도 종류마다 따로 셈. 종류가 없으면 빈 칸처럼 빠짐"),
    ("{YYYY}", "그 양식이 처음 승인된 해 네 자리 (2026)"), ("{YY}", "같은 해 두 자리 (26)"),
    ("{번호}", "일련번호 — 맨 끝에 한 번. 머리마다 따로 세고, 해가 들어가면 해마다 001부터"),
)


def _docno_examples_table(rows: list, *, with_type: bool = False) -> str:
    """미리보기 표 — 규칙에 {종류}가 있으면 '문서 종류' 칸을 더한다(없으면 v0.61.0과 같은 표)."""
    def type_cell(r):
        if not with_type:
            return ""
        t = r.get("type") or ""
        return (f'<td class="nw"><span class="tag dtype">{E(t)}</span></td>' if t
                else '<td class="nw"><span class="muted">종류 없음</span></td>')
    trs = "".join(
        f'<tr><td class="path-c">{E(r["path"])}' + (' <span class="muted">(가상)</span>' if r["kind"] == "sample" else "")
        + f'</td><td class="nw">{E(" · ".join(c or "—" for c in r["codes"]) or "—")}</td>{type_cell(r)}'
          f'<td><span class="docno big">{E(r["next"])}</span></td></tr>' for r in rows)
    return ('<div class="tablewrap"><table class="docex"><thead><tr><th>폴더</th><th>폴더 번호 머리 (위부터)</th>'
            + ('<th>문서 종류</th>' if with_type else '')
            + '<th>다음에 매길 번호</th></tr></thead><tbody>' + trs + '</tbody></table></div>')


def _untyped_warning(h: FormsHandler, parts: list, digits: int) -> str:
    """규칙에 {종류}가 있는데 종류가 없는 양식이 있으면 알린다 — 그 양식은 종류 칸 없이 매겨진다 (F7 문서 종류)."""
    if not rule_uses_type(parts):
        return ""
    store = h.server.store
    n = store.untyped_form_count()
    if not n:
        return ""
    sample = store._preview_no(["QA", "01", "02"], parts, digits, store.today().year, scan=False, dtype="")
    return (f'<div class="note warn" role="status">종류가 없는 양식 <b>{n}개</b>는 {{종류}} 칸 없이 매겨집니다 '
            f'(예: 품질 QA / 검사 01 / 수입검사 02 폴더라면 <span class="docno">{E(sample)}</span>, 폴더 머리도 없으면 '
            f'<span class="docno">F-0001</span>) — '
            f'<a href="/admin/doctypes#assign">문서 종류</a>에서 {_ADOPT_GUIDE}</div>')


def _docno_page(h: FormsHandler, *, pattern: str, digits: str, previewing: bool = False, error: str = "",
                plan: dict | None = None, include_manual: bool = False, relocate: bool = False,
                status: int = 200) -> None:
    store, s = h.server.store, h.sess
    rule = store.docno_rule()
    hid = _hidden(h)
    cur = (f'<p>지금 규칙: <b class="docno big">{E(rule["pattern"])}</b> · 일련번호 {rule["digits"]}자리'
           + (' <span class="tag off">기본값</span>' if rule["default"] else "") + '</p>')
    tokens = "".join(f'<li><code>{E(t)}</code> — {E(d)}</li>' for t, d in DOCNO_TOKEN_HELP)
    presets = "".join(f'<a class="btn gray sm" href="/admin/docno?preset={i}" title="{E(d)} · 일련번호 {dg}자리">'
                      f'{E(p)}{" (기본)" if i == 0 else ""}</a>' for i, (p, dg, d) in enumerate(DOCNO_PRESETS))
    p0, d0 = DOCNO_PRESETS[0][0], DOCNO_PRESETS[0][1]
    dflt = "" if rule["default"] else (
        f'<div class="note info" role="status">기본 규칙: <b class="docno big">{E(p0)}</b> · {d0}자리 — '
        f'<a href="/admin/docno?preset=0#rule">기본 규칙으로 되돌리기</a> (칸을 채운 뒤 [저장])</div>')
    note = f'<div class="note bad" role="alert">{E(error)}</div>' if error else ""
    if previewing and not error:
        ex_title = f'<h3>미리보기 — {E(pattern)} · 일련번호 {E(digits)}자리 (아직 저장 안 됨)</h3>'
        examples = store.docno_examples(s.user_id, pattern, digits)
        ex_parts, ex_digits = parse_docno_pattern(pattern)[1], int(digits)
    else:
        ex_title = '<h3>지금 규칙으로 다음에 매길 번호</h3>'
        examples = store.docno_examples(s.user_id)
        ex_parts, ex_digits = parse_docno_pattern(rule["pattern"])[1], rule["digits"]
    with_type = rule_uses_type(ex_parts)
    no_active = ""
    if with_type and not store.list_doc_types(s.user_id, active_only=True):
        no_active = ('<div class="note warn" role="status">사용 중인 문서 종류가 없습니다 — 모든 양식이 종류 없이 매겨집니다. '
                     '<a href="/admin/doctypes">문서 종류</a>에서 더하거나 [다시 사용]으로 돌려 주세요.</div>')
    rule_panel = (
        f'<div class="panel" id="rule"><h2>문서번호 규칙</h2>{dflt}{cur}'
        f'<p class="muted">처음에는 기본 규칙이 적용돼 있고, 회사 체계에 맞게 고칠 수 있습니다. 양식이 <b>처음 승인될 때</b> 이 '
        f'규칙으로 번호를 매깁니다. 규칙을 바꾸면 <b>앞으로 매기는 번호에만</b> '
        f'적용되고 이미 매긴 번호는 그대로입니다(바꾸려면 아래 [다시 매기기]). 칸 밖의 글자는 영문 대문자·숫자·한글과 '
        f'<code>-</code> <code>_</code> <code>.</code>만 쓰고, {{번호}} 바로 앞과 칸과 칸 사이에는 구분자를 하나 넣습니다. '
        f'빈 칸(그 단계 폴더가 없거나 머리가 빔)은 빠지고 이웃 구분자는 하나로 접힙니다. 채워진 폴더 머리·문서 종류도 회사 글자도 없으면'
        f'(해만 남음) <code>F-0001</code>처럼, 번호가 {MAX_DOC_NO}자를 넘으면 전역 꼴로 매깁니다.</p>'
        f'<ul class="lines tokens">{tokens}</ul>'
        f'<p class="muted">{{종류}}에 들어갈 기호는 <a href="/admin/doctypes">문서 종류</a>에서 관리합니다.</p>{note}'
        f'<form method="post" action="/admin/docno">{hid}'
        f'<label for="dp">번호 규칙</label>'
        f'<input type="text" class="pattern" id="dp" name="pattern" value="{E(pattern)}" maxlength="{MAX_DOCNO_PATTERN}" '
        f'required placeholder="예: {{대}}-{{YYYY}}-{{번호}}" spellcheck="false" autocomplete="off">'
        f'<label for="dd">일련번호 자릿수 ({DOCNO_DIGITS_MIN}~{DOCNO_DIGITS_MAX})</label>'
        f'<input type="text" class="months" id="dd" name="digits" value="{E(digits)}" inputmode="numeric" maxlength="1" required>'
        f'<div class="form-actions"><button class="btn gray" type="submit" name="do" value="preview">미리보기</button>'
        f'<button class="btn" type="submit" name="do" value="save">저장</button></div></form>'
        f'<div class="presets"><span class="muted">보기 (누르면 규칙·자릿수 칸만 채웁니다):</span>{presets}</div>'
        f'{ex_title}{_untyped_warning(h, ex_parts, ex_digits)}{no_active}'
        f'{_docno_examples_table(examples, with_type=with_type)}</div>')
    # 폴더 번호 머리 한눈에 — 고치기는 폴더 관리와 같은 POST /folders/code (같은 권한·같은 store 함수)
    flat = h._folders()
    empty = sum(1 for n, _d, _p in flat if not n.get("code"))
    rows = []
    for n, depth, path in flat:
        fid = n["id"]
        rows.append(f'<tr><td class="fname lv{min(depth, 6)}">{E(n["name"])}</td>'
                    f'<td class="nw"><span class="tag lvl">{E(level_name(depth + 1))}</span></td>'
                    f'<td><form class="inline" method="post" action="/folders/code">{hid}'
                    f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="/admin/docno#codes">'
                    f'<input type="text" class="code" name="code" value="{E(n.get("code", ""))}" maxlength="8" '
                    f'aria-label="{E(path)} 번호 머리" placeholder="머리 없음">'
                    f'<button class="btn gray sm" type="submit">머리 저장</button></form></td></tr>')
    codes_table = ('<details class="tool"><summary>폴더 번호 머리 보기·고치기</summary>'
                   '<div class="tablewrap"><table class="ftree"><thead><tr><th>폴더</th><th>층</th><th>번호 머리</th></tr>'
                   '</thead><tbody>' + "".join(rows) + '</tbody></table></div></details>') if rows else \
        '<p class="empty">아직 폴더가 없습니다</p>'
    codes_panel = (f'<div class="panel" id="codes"><h2>폴더 번호 머리</h2>'
                   f'<p class="muted">폴더 {len(flat)}개 중 <b>머리가 빈 폴더 {empty}개</b>. 규칙의 {{분류}}·{{대}}·{{중}}·{{소}} 칸은 '
                   f'이 머리로 채워집니다(영문·숫자·한글 1~8자, 가운데 \'.\' 가능 — 7.5, 같은 위 폴더 아래 형제끼리는 겹칠 수 없음). '
                   f'<a href="/admin/folders">폴더 관리</a>에서도 고칠 수 있습니다.</p>{codes_table}</div>')
    # 다시 매기기
    chk = " checked" if include_manual else ""
    chk2 = " checked" if relocate else ""
    ren = (f'<div class="panel" id="renumber"><h2>기존 번호를 지금 규칙으로 다시 매기기</h2>'
           f'<p class="muted">처음 규칙을 정한 회사용입니다. 현행 판이 있는 양식(폐기 포함)의 번호를 <b>저장된 지금 규칙</b>으로 '
           f'다시 매깁니다. 이미 규칙 꼴인 번호는(폴더를 옮긴 양식이라도 어느 폴더 머리로든 맞으면) 그대로 두고, 머리는 맞는데 '
           f'자릿수만 다르면 일련을 지켜 0 채움만 바꿉니다(QA-001 → QA-0001). 나머지는 옛 번호 차례대로 머리마다 지난 번호 '
           f'다음부터 매깁니다(지난 번호·이전 번호는 다시 쓰지 않음). 바뀐 양식의 <b>이전 번호</b>는 양식 상세·문서 관리 대장·엑셀에 남습니다. '
           f'먼저 [미리보기]로 목록을 보고, 확인 칸에 체크해야 실행됩니다.</p>'
           f'<form method="post" action="/admin/docno/renumber">{hid}'
           f'<label class="chk" for="rm"><input type="checkbox" id="rm" name="manual" value="1"{chk}>'
           f'손으로 고친 번호도 다시 매기기 (기본: 손 번호는 그대로)</label>'
           f'<label class="chk" for="rl"><input type="checkbox" id="rl" name="moved" value="1"{chk2}>'
           f'옮긴 양식도 지금 있는 폴더의 머리로 다시 매기기 (기본: 번호는 폴더를 옮겨도 그대로)</label>'
           f'<div class="form-actions"><button class="btn gray" type="submit" name="do" value="preview">다시 매기기 미리보기'
           f'</button></div></form>')
    if plan is not None:
        changed = plan["changed"]
        ren_type = rule_uses_type(parse_docno_pattern(plan["rule"]["pattern"])[1])
        summary = (f'<p>바뀌는 양식 <b>{len(changed)}개</b> · 그대로 {plan["same"]}개'
                   + (f' · 손 번호라 뺀 양식 {plan["manual_kept"]}개' if plan["manual_kept"] else "")
                   + f' — 규칙 <span class="docno">{E(plan["rule"]["pattern"])}</span>, 일련번호 {plan["rule"]["digits"]}자리</p>')
        if changed:
            trs = []
            for r in changed[:RENUMBER_SHOW]:
                marks = "".join(x for x in (
                    ' <span class="tag pending">손 번호</span>' if r["manual"] else "",
                    ' <span class="tag off">자릿수만</span>' if r.get("reformat") else "",
                    ' <span class="tag retired">폐기</span>' if r["retired"] else "",
                    f' <span class="tag off" title="규칙대로면 {E(r["fallback"])}">전역 꼴</span>' if r["global"] else ""))
                tcell = ""
                if ren_type:
                    tcell = (f'<td class="nw"><span class="tag dtype">{E(r["type"])}</span></td>' if r.get("type")
                             else '<td class="nw"><span class="muted">없음</span></td>')
                trs.append(f'<tr><td class="nw"><span class="docno">{E(r["old"]) or "(없음)"}</span></td>'
                           f'<td class="nw"><b class="docno">{E(r["new"])}</b></td>'
                           f'<td class="name-c"><a href="/form?id={r["id"]}">{E(r["name"])}</a>{marks}</td>{tcell}'
                           f'<td class="path-c">{E(r["path"])}</td></tr>')
            more = (f'<p class="muted">외 {len(changed) - RENUMBER_SHOW}개는 줄였습니다 — 실행하면 모두 바뀝니다.</p>'
                    if len(changed) > RENUMBER_SHOW else "")
            table = ('<div class="tablewrap"><table class="renum"><thead><tr><th>지금 번호</th><th>새 번호</th><th>양식</th>'
                     + ('<th>문서 종류</th>' if ren_type else '')
                     + '<th>폴더</th></tr></thead><tbody>' + "".join(trs) + '</tbody></table></div>' + more)
            run = (f'<form method="post" action="/admin/docno/renumber">{hid}'
                   f'<input type="hidden" name="do" value="run"><input type="hidden" name="digest" value="{E(plan["digest"])}">'
                   + ('<input type="hidden" name="manual" value="1">' if plan["include_manual"] else "")
                   + ('<input type="hidden" name="moved" value="1">' if plan.get("relocate") else "")
                   + f'<label class="chk" for="rc"><input type="checkbox" id="rc" name="confirm" value="1" required>'
                     f'위 목록대로 양식 {len(changed)}개의 문서번호를 바꾸는 것을 확인합니다</label>'
                     f'<div class="form-actions"><button class="btn red" type="submit">다시 매기기 실행</button></div></form>')
        else:
            table, run = '<p class="empty">바꿀 번호가 없습니다 — 모두 지금 규칙 꼴입니다</p>', ""
        ren += f'<h3>미리보기</h3>{summary}{table}{run}'
    ren += '</div>'
    body = rule_panel + codes_panel + ren
    h._send(status, h._shell("문서번호 규칙", body, active="/admin/docno"))


def get_admin_docno(h: FormsHandler) -> None:
    """문서번호 규칙 화면 — 관리자만. 읽기만: ?preset=N 은 규칙 칸만 채운다(저장은 [저장] POST)."""
    _require_admin(h)
    rule = h.server.store.docno_rule()
    pattern, digits = rule["pattern"], str(rule["digits"])
    k = h._int(h._one(h._query(), "preset"), required=False)
    if k is not None:
        if not 0 <= k < len(DOCNO_PRESETS):
            raise HttpError(400, "없는 보기입니다")
        pattern, digits = DOCNO_PRESETS[k][0], str(DOCNO_PRESETS[k][1])      # 규칙과 자릿수를 함께 채운다
    _docno_page(h, pattern=pattern, digits=digits)


def post_admin_docno(h: FormsHandler) -> None:
    """[미리보기](상태 안 바꿈) / [저장](규칙 저장 — 앞으로 매기는 번호에만) — 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    pattern, digits_s = h._one(f, "pattern")[:200], h._one(f, "digits")[:12]
    do = h._one(f, "do")
    if do not in ("preview", "save"):
        raise HttpError(400, "할 일을 골라 주세요")
    store = h.server.store
    try:
        digits = h._int(digits_s, required=False)
        if digits is None:
            raise InvalidInput(f"일련번호 자릿수를 {DOCNO_DIGITS_MIN}~{DOCNO_DIGITS_MAX}로 적어 주세요")
        if do == "preview":
            store.docno_examples(h.sess.user_id, pattern, digits)          # 틀린 규칙이면 여기서 InvalidInput
            shown = parse_docno_pattern(pattern)[0]                 # 고른 꼴(대문자·전각 접기)을 칸에 돌려준다
            _docno_page(h, pattern=shown, digits=str(digits), previewing=True)
            return
        old = store.docno_rule()
        rule = store.set_docno_rule(h.sess.user_id, pattern, digits, ip=h.ip)
    except (InvalidInput, HttpError) as e:
        msg = e.message if isinstance(e, HttpError) else str(e)
        _docno_page(h, pattern=pattern, digits=digits_s, error=f"{'저장하지 않았습니다' if do == 'save' else '미리보기를 못 했습니다'} — {msg}",
                    status=400 if do == "save" else 200)
        return
    same = (old["pattern"], old["digits"]) == (rule["pattern"], rule["digits"])
    h._flash("ok", "바뀐 것이 없습니다" if same else
             f"번호 규칙을 {rule['pattern']}(일련번호 {rule['digits']}자리)로 저장했습니다 — 앞으로 처음 승인되는 양식부터 "
             f"적용되고 이미 매긴 번호는 그대로입니다")
    h._redirect("/admin/docno")


def post_admin_docno_renumber(h: FormsHandler) -> None:
    """[다시 매기기 미리보기](상태 안 바꿈) / 실행(확인 칸 + 미리보기 지문) — 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    manual = h._one(f, "manual") == "1"
    moved = h._one(f, "moved") == "1"
    do = h._one(f, "do")
    rule = store.docno_rule()
    here = dict(pattern=rule["pattern"], digits=str(rule["digits"]), include_manual=manual, relocate=moved)
    if do == "preview":
        _docno_page(h, plan=store.renumber_plan(s.user_id, include_manual=manual, relocate=moved), **here)
        return
    if do != "run":
        raise HttpError(400, "할 일을 골라 주세요")
    digest = h._one(f, "digest")
    if not re.fullmatch(r"[0-9a-f]{64}", digest or ""):
        raise HttpError(400, "미리보기를 먼저 보고 실행해 주세요")
    if h._one(f, "confirm") != "1":
        raise HttpError(400, "확인 칸에 체크해야 다시 매깁니다")
    try:
        done = store.renumber(s.user_id, include_manual=manual, relocate=moved, expect=digest, ip=h.ip)
    except Conflict as e:
        h._flash("bad", str(e))
        h._redirect("/admin/docno#renumber")
        return
    h._flash("ok", f"양식 {len(done)}개의 문서번호를 다시 매겼습니다 — 이전 번호는 양식 상세·문서 관리 대장에 남습니다"
             if done else "바꿀 번호가 없었습니다")
    h._redirect("/admin/docno")


# ── 문서 종류 (F7 문서 종류, 2026-10-29) ──────────────────────────────────────────────
# 관리자만(store도 다시 본다). GET은 읽기만, 바꾸기는 모두 POST + CSRF, 바뀔 때마다 감사 기록. 종류·기호를 바꿔도 이미 매긴
# 문서번호는 그대로 — 규칙에 {종류}를 넣고 번호까지 맞추려면 [문서번호 규칙 › 다시 매기기].

def get_admin_doctypes(h: FormsHandler) -> None:
    """문서 종류 화면 — 목록(기호·이름 고치기, 사용 중지·다시 사용, 안 쓰는 것 지우기), 더하기, 종류 없는 양식 한꺼번에 지정."""
    _require_admin(h)
    store, s = h.server.store, h.sess
    types = store.list_doc_types(s.user_id)
    hid = _hidden(h)
    rule = store.docno_rule()
    uses = rule_uses_type(parse_docno_pattern(rule["pattern"])[1])
    rows = []
    for t in types:
        tid = t["id"]
        state = ('<span class="tag approved">사용 중</span>' if t["active"] else '<span class="tag off">사용 중지</span>')
        use = f'양식 {t["used"]}개' + (f' · 검토 대기 {t["pending"]}건' if t["pending"] else "")
        edit = (f'<form class="inline" method="post" action="/admin/doctypes/edit">{hid}'
                f'<input type="hidden" name="id" value="{tid}">'
                f'<input type="text" class="code" name="code" value="{E(t["code"])}" maxlength="8" required '
                f'aria-label="{E(t["name"])} 기호">'
                f'<input type="text" class="tname" name="name" value="{E(t["name"])}" maxlength="{MAX_DOC_TYPE_NAME}" '
                f'required aria-label="{E(t["code"])} 이름">'
                f'<button class="btn gray sm" type="submit">저장</button></form>')
        toggle = (f'<form class="inline" method="post" action="/admin/doctypes/active">{hid}'
                  f'<input type="hidden" name="id" value="{tid}"><input type="hidden" name="on" value="{0 if t["active"] else 1}">'
                  f'<button class="btn gray sm" type="submit">{"사용 중지" if t["active"] else "다시 사용"}</button></form>')
        delete = ""
        if not t["used"] and not t["pending"]:
            delete = (f'<form class="inline" method="post" action="/admin/doctypes/delete">{hid}'
                      f'<input type="hidden" name="id" value="{tid}">'
                      f'<button class="btn red sm" type="submit">지우기</button></form>')
        rows.append(f'<tr><td class="nw"><span class="tag dtype">{E(t["code"])}</span></td>'
                    f'<td class="name-c">{E(t["name"])}</td><td class="nw">{state}</td><td class="nw">{E(use)}</td>'
                    f'<td>{edit}</td><td class="nw">{toggle}{delete}</td></tr>')
    table = ('<div class="tablewrap"><table class="dtypes"><thead><tr><th>기호</th><th>이름</th><th>상태</th><th>쓰는 양식</th>'
             '<th>기호·이름 고치기</th><th>상태 바꾸기</th></tr></thead><tbody>' + "".join(rows) + '</tbody></table></div>') if rows \
        else '<p class="empty">문서 종류가 없습니다 — 아래에서 더해 주세요</p>'
    intro = (f'<p class="muted">ISO 문서 체계처럼 같은 부서 폴더 안에서도 <b>문서 종류마다 번호를 따로</b> 셀 때 씁니다 — 번호 규칙에 '
             f'<code>{{종류}}</code>를 넣으면(예: <code>{{종류}}-{{대}}-{{번호}}</code>) 절차서는 <span class="docno">QP-QA-001</span>, '
             f'양식은 <span class="docno">QF-QA-001</span>처럼 종류마다 001부터 매깁니다. 직원은 양식을 올릴 때 종류를 고르고(선택), '
             f'검토자는 양식 상세에서 바꿀 수 있습니다. 종류나 기호를 바꿔도 <b>이미 매긴 번호는 그대로</b>입니다(번호까지 바꾸려면 '
             f'<a href="/admin/docno#renumber">다시 매기기</a>). [사용 중지]한 종류는 고르기에서 숨고 이미 그 종류인 양식은 그대로이며, '
             f'쓰는 양식이 없는 종류만 지울 수 있습니다. 기호는 영문·숫자·한글 1~8자(가운데 \'.\' 가능, \'F\'는 안 됨).</p>'
             + ('' if uses else f'<div class="note info" role="status">지금 번호 규칙(<span class="docno">{E(rule["pattern"])}</span>)에는 '
                f'{{종류}}가 없어 종류가 번호에 들어가지 않습니다 — 번호에 넣으려면 '
                f'<a href="/admin/docno?preset={_iso_preset()}#rule">문서번호 규칙</a>에서 정하세요.</div>'))
    add = (f'<h3>종류 더하기</h3><form method="post" action="/admin/doctypes/new">{hid}'
           f'<label for="tc">기호</label><input type="text" class="code" id="tc" name="code" maxlength="8" required '
           f'placeholder="예: QS" spellcheck="false" autocomplete="off">'
           f'<label for="tn">이름</label><input type="text" class="tname" id="tn" name="name" maxlength="{MAX_DOC_TYPE_NAME}" '
           f'required placeholder="예: 규격서">'
           f'<div class="form-actions"><button class="btn" type="submit">더하기</button></div></form>')
    untyped = store.untyped_form_count()
    active = [t for t in types if t["active"]]
    if untyped and active:
        assign = (f'<div class="panel" id="assign"><h2>종류가 없는 양식 {untyped}개</h2>'
                  f'<p class="muted">이주 전에 올라왔거나 종류를 고르지 않은 양식입니다(폐기 포함). [지정]은 한 종류로만 '
                  f'한꺼번에 정하고 문서번호는 바꾸지 않습니다. {_ADOPT_GUIDE}</p>'
                  f'<form class="inline" method="post" action="/admin/doctypes/assign">{hid}'
                  f'<select name="doc_type" aria-label="지정할 문서 종류" required>'
                  + "".join(f'<option value="{t["id"]}">{E(_type_label(t["code"], t["name"]))}</option>' for t in active)
                  + f'</select><button class="btn sm" type="submit">종류가 없는 양식 {untyped}개를 이 종류로 지정</button>'
                    f'</form></div>')
    elif untyped:
        assign = (f'<div class="panel" id="assign"><h2>종류가 없는 양식 {untyped}개</h2>'
                  f'<p class="muted">사용 중인 종류가 없어 지정할 수 없습니다 — 먼저 종류를 더하거나 [다시 사용]으로 돌려 주세요.</p></div>')
    else:
        assign = ('<div class="panel" id="assign"><h2>종류가 없는 양식</h2>'
                  '<p class="muted">없습니다 — 모든 양식에 종류가 있습니다. 번호 규칙에 {종류}가 있고 번호를 종류에 맞추려면 '
                  '<a href="/admin/docno#renumber">문서번호 규칙 › 다시 매기기</a>.</p></div>')
    body = f'<div class="panel">{intro}{table}{add}</div>{assign}'
    h._send(200, h._shell("문서 종류", body, active="/admin/doctypes",
                          actions='<a class="btn gray" href="/admin/docno">문서번호 규칙</a>'))


def _iso_preset() -> int:
    """{종류}가 든 첫 보기 번호 (문서번호 규칙 화면의 ?preset=)."""
    return next((i for i, (p, _d, _t) in enumerate(DOCNO_PRESETS) if "{종류}" in p), 0)


def _doctype_back(h: FormsHandler, kind: str, msg: str) -> None:
    h._flash(kind, msg)
    h._redirect("/admin/doctypes")


def post_doctype_new(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    try:
        tid = h.server.store.create_doc_type(h.sess.user_id, h._one(f, "code"), h._one(f, "name"), ip=h.ip)
    except (InvalidInput, Conflict) as e:
        _doctype_back(h, "bad", f"종류를 더하지 않았습니다 — {e}")
        return
    t = next(x for x in h.server.store.list_doc_types(h.sess.user_id) if x["id"] == tid)
    _doctype_back(h, "ok", f"문서 종류를 더했습니다 — {t['code']} {t['name']}")


def post_doctype_edit(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "id"))
    try:
        done = h.server.store.update_doc_type(h.sess.user_id, tid, code=h._one(f, "code"), name=h._one(f, "name"),
                                              ip=h.ip)
    except (InvalidInput, Conflict) as e:
        _doctype_back(h, "bad", f"바꾸지 않았습니다 — {e}")
        return
    if not (done["code"] or done["name"]):
        _doctype_back(h, "ok", "바뀐 것이 없습니다")
        return
    said = []
    if done["code"]:
        said.append(f"기호: {done['code'][0]} → {done['code'][1]} (이미 매긴 문서번호는 그대로)")
    if done["name"]:
        said.append(f"이름: {done['name'][0]} → {done['name'][1]}")
    _doctype_back(h, "ok", "문서 종류를 바꿨습니다 — " + ", ".join(said))


def post_doctype_active(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "id"))
    on = h._one(f, "on")
    if on not in ("0", "1"):
        raise HttpError(400, "사용 중지인지 다시 사용인지 골라 주세요")
    changed = h.server.store.set_doc_type_active(h.sess.user_id, tid, on == "1", ip=h.ip)
    _doctype_back(h, "ok", ("다시 사용합니다 — 올리기 화면에서 고를 수 있습니다" if on == "1" else
                            "사용 중지했습니다 — 고르기에서 숨고, 이미 그 종류인 양식은 그대로입니다") if changed
                  else "바뀐 것이 없습니다")


def post_doctype_delete(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "id"))
    try:
        code = h.server.store.delete_doc_type(h.sess.user_id, tid, ip=h.ip)
    except Conflict as e:
        _doctype_back(h, "bad", str(e))
        return
    _doctype_back(h, "ok", f"문서 종류를 지웠습니다 — {code}")


def post_doctype_assign(h: FormsHandler) -> None:
    """[종류가 없는 양식 N개를 이 종류로 지정] — 관리자만. 번호는 그대로."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "doc_type"))
    try:
        n = h.server.store.assign_type_to_untyped(h.sess.user_id, tid, ip=h.ip)
    except InvalidInput as e:
        _doctype_back(h, "bad", f"지정하지 않았습니다 — {e}")
        return
    _doctype_back(h, "ok", f"종류가 없는 양식 {n}개에 종류를 지정했습니다 — 문서번호는 그대로입니다. 다른 종류인 양식을 "
                           f"양식 상세에서 고친 뒤 [문서번호 규칙 › 다시 매기기]를 한 번 쓰세요(아래 안내)" if n
                  else "종류가 없는 양식이 없습니다")


# ── 관리자 ─────────────────────────────────────────────────────────────────

def _require_admin(h: FormsHandler) -> None:
    if h.sess.role != "admin":
        raise HttpError(403, "관리자만 볼 수 있습니다")


def _role_options(cur: str) -> str:
    return "".join(f'<option value="{r}"{" selected" if r == cur else ""}>{ROLE_LABEL[r]}</option>'
                   for r in ("member", "reviewer", "admin"))


def get_admin_users(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    users = auth.list_users(store, s.user_id)
    csrf = E(s.csrf)
    hid = f'<input type="hidden" name="csrf" value="{csrf}">'
    rows = []
    for u in users:
        uid = u["id"]
        state = '<span class="tag off">정지</span>' if u["disabled"] else '<span class="tag approved">사용 중</span>'
        if u["must_change"]:
            state += ' <span class="tag pending">임시 비밀번호</span>'
        toggle = (f'<form class="inline" method="post" action="/admin/users/disable">{hid}'
                  f'<input type="hidden" name="id" value="{uid}"><input type="hidden" name="disabled" '
                  f'value="{0 if u["disabled"] else 1}"><button class="btn gray sm" type="submit">'
                  f'{"복구" if u["disabled"] else "정지"}</button></form>')
        reset = (f'<form class="inline" method="post" action="/admin/users/reset">{hid}'
                 f'<input type="hidden" name="id" value="{uid}"><button class="btn gray sm" type="submit">'
                 f'비밀번호 초기화</button></form>')
        role = (f'<form class="inline" method="post" action="/admin/users/role">{hid}'
                f'<input type="hidden" name="id" value="{uid}"><select name="role" aria-label="역할">'
                f'{_role_options(u["role"])}</select><button class="btn gray sm" type="submit">역할 바꾸기</button></form>')
        mail = (f'<form class="inline" method="post" action="/admin/users/email">{hid}'
                f'<input type="hidden" name="id" value="{uid}"><input type="email" name="email" '
                f'value="{E(u.get("email") or "")}" maxlength="254" placeholder="알림 메일(선택)" aria-label="메일 주소">'
                f'<button class="btn gray sm" type="submit">저장</button></form>')
        rows.append(f'<tr><td>{E(u["login"])}</td><td>{E(u["display_name"])}</td>'
                    f'<td><span class="tag role">{E(ROLE_LABEL.get(u["role"], u["role"]))}</span></td>'
                    f'<td>{state}</td><td class="nw">{E(_fmt_time(u["created_at"]))}</td>'
                    f'<td>{mail}</td><td>{role}{toggle}{reset}</td></tr>')
    table = ("<table><thead><tr><th>아이디</th><th>이름</th><th>역할</th><th>상태</th><th>만든 날</th><th>메일</th>"
             "<th>관리</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>")
    reg = (f'<div class="panel"><h2>직원 등록</h2>'
           f'<p class="muted">등록하면 임시 비밀번호가 <b>한 번만</b> 보입니다. 직원은 첫 로그인 때 비밀번호를 바꿉니다. '
           f'검토자는 [폴더 관리]에서 맡을 폴더를 정해 주세요.</p>'
           f'<form method="post" action="/admin/users/new">{hid}'
           f'<label for="ul">아이디</label><input type="text" id="ul" name="login" required maxlength="32" '
           f'placeholder="예: kim.cs (글자·숫자·점·밑줄·빼기)">'
           f'<label for="un">이름</label><input type="text" id="un" name="display_name" required maxlength="40" '
           f'placeholder="예: 김철수 (생산팀)">'
           f'<label for="ur">역할</label><select id="ur" name="role">{_role_options("member")}</select>'
           f'<label for="ue">메일 주소 (선택 — 승인·반려·새 판 알림을 받을 주소)</label>'
           f'<input type="email" id="ue" name="email" maxlength="254" placeholder="예: kim@회사.co.kr">'
           f'<div class="form-actions"><button class="btn" type="submit">등록</button></div></form></div>')
    roles = ('<p class="muted">관리자: 전부 + 계정·검토자 지정·감사 기록 · 검토자: 맡은 폴더에서 폴더 만들기·승인·반려 · '
             '직원: 보기·내려받기·올리기(검토 대기). 마지막 관리자는 정지·강등할 수 없습니다.</p>')
    h._send(200, h._shell("계정", f'{reg}<div class="panel"><h2>계정 목록</h2>{roles}{table}</div>'
                                  f'{_locked_ips_panel(h, hid)}', active="/admin/users"))


def _locked_ips_panel(h: FormsHandler, hid: str) -> str:
    """잠긴 접속 주소 — 주소 잠금(아이디 상관없이 실패가 많음)과 계정+주소 잠금. 관리자가 풀 수 있다 (보안 F2)."""
    rows = auth.locked_ips(h.server.store, h.sess.user_id)
    intro = (f'<p class="muted">한 접속 주소에서 아이디 상관없이 {auth.IP_WINDOW // 60}분 안에 {auth.IP_THRESHOLD}번 틀리면 '
             f'그 주소의 로그인을 {auth.IP_LOCK_SECONDS // 60}분 막습니다(비밀번호 대입 막기). 회사 공유기를 같이 쓰는 PC들은 '
             f'바깥에서 보기에 같은 주소라 <b>함께 막힐 수 있습니다</b> — 직원이 몰라서 틀린 것이 확실하면 여기서 풀어 주세요.</p>')
    if not rows:
        return f'<div class="panel" id="locked"><h2>잠긴 접속 주소</h2>{intro}<p class="empty">지금 잠긴 주소가 없습니다</p></div>'
    trs = []
    for r in rows:
        what = (f'주소 잠금 — {r["count"]}번 실패' if r["kind"] == "ip" else "") + \
               (f'{" · " if r["kind"] == "ip" else ""}계정 잠금 {r["accounts"]}개' if r["accounts"] else "")
        trs.append(f'<tr><td class="nw">{E(r["ip"])}</td><td>{E(what)}</td>'
                   f'<td class="nw">{E(auth._left_text(r["seconds"]))} 남음</td>'
                   f'<td><form class="inline" method="post" action="/admin/unlock-ip">{hid}'
                   f'<input type="hidden" name="ip" value="{E(r["ip"])}">'
                   f'<button class="btn gray sm" type="submit">잠금 풀기</button></form></td></tr>')
    table = ("<table><thead><tr><th>접속 주소</th><th>까닭</th><th>남은 시간</th><th></th></tr></thead><tbody>"
             + "".join(trs) + "</tbody></table>")
    return f'<div class="panel" id="locked"><h2>잠긴 접속 주소</h2>{intro}{table}</div>'


def post_unlock_ip(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    target = h._one(f, "ip").strip()
    done = auth.unlock_ip(h.server.store, h.sess.user_id, target, ip=h.ip)
    h._flash("ok", f"{target} 주소의 잠금을 풀었습니다" if done else f"{target} 주소는 잠겨 있지 않습니다")
    h._redirect("/admin/users#locked")


def _secret_page(h: FormsHandler, title: str, who: str, temp: str, lead: str) -> None:
    body = (f'<div class="panel"><div class="note ok">{E(lead)}</div>'
            f'<p><b>{E(who)}</b>의 임시 비밀번호:</p><div class="secret">{E(temp)}</div>'
            f'<p class="muted">이 화면을 벗어나면 다시 볼 수 없습니다 — 지금 직원에게 직접 전해 주세요. '
            f'첫 로그인 때 새 비밀번호로 바꾸게 됩니다.</p>'
            f'<div class="form-actions"><a class="btn" href="/admin/users">계정 목록으로</a></div></div>')
    h._send(200, h._shell(title, body, active="/admin/users"))


def post_user_new(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    login = h._one(f, "login").strip()
    uid, temp = auth.register_user(h.server.store, h.sess.user_id, login, h._one(f, "display_name"),
                                   h._one(f, "role", "member"), ip=h.ip, email=h._one(f, "email"))
    _secret_page(h, "직원 등록", login, temp, "계정을 등록했습니다")


def post_user_email(h: FormsHandler) -> None:
    """알림 메일 주소 바꾸기 (F4) — 관리자만. 비우면 알림을 받지 않는다."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    em = h._one(f, "email").strip()
    auth.set_email(h.server.store, h.sess.user_id, uid, em, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정의 메일 주소를 {'저장' if em else '지웠'}했습니다")
    h._redirect("/admin/users")


def post_folder_subscribe(h: FormsHandler) -> None:
    """폴더 구독(새 현행 판 메일) 켜기·끄기 — 자기 것만 (F4)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    on = h._one(f, "on") == "1"
    h.server.store.set_subscription(h.sess.user_id, fid, on)
    if on and not h.server.store.user_email(h.sess.user_id):
        h._flash("ok", "구독했습니다 — 다만 내 계정에 메일 주소가 없어 알림이 가지 않습니다. 관리자에게 주소 등록을 부탁하세요")
    else:
        h._flash("ok", "이 폴더에 새 현행 판이 생기면 메일로 알립니다" if on else "이 폴더 메일 알림을 껐습니다")
    h._redirect(f"/forms?folder={fid}")


def _user_login(h: FormsHandler, uid: int) -> str:
    u = h.server.store.get_user(uid)
    if u is None:
        raise HttpError(404, "없는 계정입니다")
    return u["login"]


def post_user_disable(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    off = h._one(f, "disabled") == "1"
    auth.set_disabled(h.server.store, h.sess.user_id, uid, off, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정을 {'정지' if off else '복구'}했습니다")
    h._redirect("/admin/users")


def post_user_reset(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    temp = auth.reset_password(h.server.store, h.sess.user_id, uid, ip=h.ip)
    _secret_page(h, "비밀번호 초기화", _user_login(h, uid), temp, "비밀번호를 초기화했습니다 — 그 계정의 접속은 모두 끊겼습니다")


def post_user_role(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    role = h._one(f, "role")
    auth.set_role(h.server.store, h.sess.user_id, uid, role, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정의 역할을 {ROLE_LABEL.get(role, role)}(으)로 바꿨습니다")
    h._redirect("/admin/users")


def _template_panel(h: FormsHandler) -> str:
    """기본 분류 틀 만들기 — 대분류별 체크(기본 전부 켜짐)와 미리보기(트리). POST + CSRF, 없는 폴더만 만든다."""
    n = catalog.counts()
    boxes = []
    for i, (top, mids) in enumerate(catalog.CATALOG):
        leaves = sum(len(lv) for _m, lv in mids)
        tree_ = "".join(f'<li><b>{E(m)}</b> — {E(" · ".join(lv))}</li>' for m, lv in mids)
        boxes.append(f'<div class="tpl"><label class="chk" for="tpl{i}"><input type="checkbox" id="tpl{i}" name="top" '
                     f'value="{E(top)}" checked>{E(top)}</label><span class="muted">중분류 {len(mids)} · 소분류 {leaves}</span>'
                     f'<details class="tool"><summary>미리보기</summary><ul class="lines">{tree_}</ul></details></div>')
    return (f'<div class="panel"><h2>기본 분류 틀 만들기</h2>'
            f'<p class="muted">중소 제조기업에서 흔한 양식을 <b>대분류 {n["tops"]} / 중분류 {n["mids"]} / 소분류(양식 종류) '
            f'{n["leaves"]}</b>로 나눈 폴더를 만듭니다. 소분류 폴더에 그 양식을 올리면 됩니다. <b>없는 폴더만</b> 만들고, 같은 '
            f'이름이 이미 있으면 그대로 두고 그 아래로 이어 갑니다 — 여러 번 눌러도 같은 결과입니다. 필요 없는 폴더는 나중에 '
            f'지우면 됩니다(빈 폴더만).</p>'
            f'<form method="post" action="/admin/folders/template">{_hidden(h)}<div class="tplgrid">{"".join(boxes)}</div>'
            f'<div class="form-actions"><button class="btn" type="submit">고른 분류 만들기</button></div></form></div>')


def get_admin_folders(h: FormsHandler) -> None:
    """폴더 관리 — 전체 트리를 한 표로: 층·양식 수(현행/폐기)·대기·검토자, 행마다 이름 바꾸기·옮기기·지우기·차례·검토자 지정.
    질의는 폴더 수와 상관없이 몇 개뿐(트리 1·집계 3·계정 1) — 폴더마다 묻지 않는다. 스크립트 없이 접기 칸(details)."""
    _require_admin(h)
    store, s = h.server.store, h.sess
    flat = h._folders()
    ov = store.folder_overview(s.user_id)
    users = [u for u in auth.list_users(store, s.user_id) if u["role"] in ("reviewer", "admin") and not u["disabled"]]
    hid = _hidden(h)
    rows = []
    for n, depth, path in flat:
        fid = n["id"]
        cur_f, ret_f = ov["forms"].get(fid, (0, 0))
        pend = ov["pending"].get(fid, 0)
        revs = ov["reviewers"].get(fid, [])
        cur = {u["id"] for u in revs}
        boxes = "".join(
            f'<label class="chk"><input type="checkbox" name="user" value="{u["id"]}"'
            f'{" checked" if u["id"] in cur else ""}>{E(u["display_name"])} ({E(u["login"])})</label>' for u in users)
        lvl = level_name(depth + 1)
        manage = (f'<details class="tool"><summary>관리</summary>'
                  f'<form class="inline" method="post" action="/folders/rename">{hid}'
                  f'<input type="hidden" name="folder" value="{fid}">'
                  f'<input type="text" name="name" value="{E(n["name"])}" required maxlength="80" '
                  f'aria-label="{E(path)} 새 이름"><button class="btn gray sm" type="submit">이름 바꾸기</button></form>'
                  f'<form method="post" action="/admin/reviewers">{hid}<input type="hidden" name="folder" value="{fid}">'
                  f'<div class="muted">검토자</div>{boxes or "<span class=muted>검토자 역할 계정이 없습니다</span>"} '
                  f'<button class="btn gray sm" type="submit">검토자 저장</button></form>'
                  f'<form class="inline" method="post" action="/folders/code">{hid}'
                  f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="/admin/folders">'
                  f'<input type="text" class="code" name="code" value="{E(n.get("code", ""))}" maxlength="8" '
                  f'aria-label="{E(path)} 번호 머리" placeholder="번호 머리 (예: QA)">'
                  f'<button class="btn gray sm" type="submit">머리 저장</button></form>'
                  f'<div class="form-actions"><a class="btn gray sm" href="/folders/move?folder={fid}">옮기기…</a>'
                  f'{_order_buttons(h, fid, back="/admin/folders")}'
                  f'<form class="inline" method="post" action="/folders/delete">{hid}'
                  f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="/admin/folders">'
                  f'<button class="btn red sm" type="submit">지우기</button></form></div></details>')
        names = ", ".join(u["display_name"] for u in revs)
        code_tag = f'<span class="tag code" title="문서번호 머리">{E(n["code"])}</span>' if n.get("code") else ""
        rows.append(f'<tr><td class="fname lv{min(depth, 6)}"><a href="/forms?folder={fid}">{E(n["name"])}</a>{code_tag}</td>'
                    f'<td class="nw"><span class="tag lvl">{E(lvl)}</span></td>'
                    f'<td class="nw">{cur_f}' + (f' <span class="muted">/ 폐기 {ret_f}</span>' if ret_f else "")
                    + f'</td><td class="nw">{pend or ""}</td><td>{E(names)}</td><td>{manage}</td></tr>')
    table = ('<div class="tablewrap"><table class="ftree"><thead><tr><th>폴더</th><th>층</th><th>양식</th><th>대기</th>'
             '<th>검토자</th><th></th></tr></thead><tbody>' + "".join(rows) + "</tbody></table></div>") if rows else \
        '<p class="empty">아직 폴더가 없습니다 — 아래 [기본 분류 틀 만들기]로 시작하거나 양식함에서 대분류를 만드세요</p>'
    intro = ('<p class="muted">층: 맨 위 = 대분류, 그 아래 = 중분류, 그 아래 = 소분류(양식 종류), 더 아래는 하위 폴더. '
             '검토자는 지정된 폴더와 그 <b>하위 폴더</b>에서 승인·반려·폴더 만들기를 할 수 있습니다. '
             '관리자는 지정하지 않아도 모든 폴더를 검토할 수 있습니다. 폴더를 옮기면 검토자 범위도 새 위치를 따릅니다.</p>'
             '<p class="muted">번호 머리(파란 글자): 처음 승인되는 양식의 문서번호 앞부분 — <a href="/admin/docno">문서번호 규칙</a>'
             '대로 잇습니다(기본: 위 폴더 머리를 위에서부터 잇고 일련번호, 예: QA-01-01-001). 기본 분류 틀은 머리를 함께 넣습니다. 이미 매긴 번호는 폴더를 옮기거나 '
             '머리를 바꿔도 그대로입니다. 번호 없는 옛 양식은 <a href="/register">문서 관리 대장</a>에서 한 번에 매깁니다.</p>')
    body = (f'<div class="panel"><h2>폴더 {len(flat)}개</h2>{intro}{table}</div>' + _template_panel(h))
    h._send(200, h._shell("폴더 관리", body, active="/admin/folders"))


def post_folder_template(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    picked = [t for t in f.get("top", []) if t in set(catalog.tops())]
    if not picked:
        h._flash("bad", "만들 대분류를 하나 이상 골라 주세요")
        h._redirect("/admin/folders")
        return
    res = h.server.store.apply_template(h.sess.user_id, catalog.tree(picked), ip=h.ip, codes=catalog.TOP_CODES)
    h._flash("ok", f"기본 분류 틀: 폴더 {res['created']}개를 만들었습니다"
             + (f" · 이미 있던 {res['skipped']}개는 그대로 두었습니다" if res["skipped"] else ""))
    h._redirect("/admin/folders")


def post_reviewers(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    ids = [h._int(v) for v in f.get("user", [])]
    h.server.store.set_folder_reviewers(h.sess.user_id, fid, ids, ip=h.ip)
    h._flash("ok", "검토자를 저장했습니다")
    h._redirect("/admin/folders")


AUDIT_PAGE = 100


def get_admin_audit(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    qd = h._query()
    action = h._one(qd, "action")
    if action and action not in ACTION_LABEL:
        action = ""
    uid = h._int(h._one(qd, "user"), required=False)
    page = h._int(h._one(qd, "page"), required=False) or 0
    page = min(page, 10000)
    rows_ = store.audit_log(s.user_id, limit=AUDIT_PAGE + 1, offset=page * AUDIT_PAGE, action=action or None,
                            user_id=uid)
    more = len(rows_) > AUDIT_PAGE
    rows_ = rows_[:AUDIT_PAGE]
    users = auth.list_users(store, s.user_id)
    aopts = '<option value="">모든 일</option>' + "".join(
        f'<option value="{k}"{" selected" if k == action else ""}>{E(v)}</option>' for k, v in ACTION_LABEL.items())
    uopts = '<option value="">모든 사람</option>' + "".join(
        f'<option value="{u["id"]}"{" selected" if u["id"] == uid else ""}>{E(u["login"])}</option>' for u in users)
    filt = (f'<form class="searchbar" method="get" action="/admin/audit">'
            f'<select name="action" aria-label="일 종류">{aopts}</select>'
            f'<select name="user" aria-label="사람">{uopts}</select>'
            f'<button class="btn sm" type="submit">걸러 보기</button>'
            f'<a class="btn gray sm" href="/admin/audit">지우기</a></form>')
    trs = "".join(
        f'<tr><td class="nw">{E(_fmt_time(r["at"]))}</td><td>{E(r["login"])}</td>'
        f'<td>{E(ACTION_LABEL.get(r["action"], r["action"]))}</td><td>{E(r["target"])}</td>'
        f'<td class="nw">{E(r["ip"])}</td><td>{E(r["detail"])}</td></tr>' for r in rows_)
    table = ("<table><thead><tr><th>때</th><th>아이디</th><th>일</th><th>대상</th><th>접속 주소</th><th>내용</th>"
             "</tr></thead><tbody>" + trs + "</tbody></table>") if trs else '<p class="empty">기록이 없습니다</p>'
    q = "&".join(x for x in (f"action={quote(action)}" if action else "", f"user={uid}" if uid is not None else "") if x)
    pager = '<div class="pager">'
    if page > 0:
        pager += f'<a class="btn gray sm" href="/admin/audit?{E(q + "&" if q else "")}page={page - 1}">← 최근 쪽</a>'
    if more:
        pager += f'<a class="btn gray sm" href="/admin/audit?{E(q + "&" if q else "")}page={page + 1}">이전 기록 →</a>'
    pager += "</div>"
    info = store.audit_info(s.user_id)
    keep = (f'<p class="muted" id="keep">감사 기록은 최근 <b>{info["max_rows"]:,}건</b>까지 보관하고, 넘으면 가장 오래된 것부터 '
            f'지웁니다. 지금 {info["count"]:,}건 · <b>가장 오래된 기록: {E(_fmt_time(info["oldest_at"]) or "없음")}</b>. '
            f'같은 주소에서 연달아 틀린 로그인은 1분씩 묶어 한 줄(횟수·시각·시도한 아이디)로 적습니다.</p>')
    h._send(200, h._shell("감사 기록", f'<div class="panel">{keep}{filt}{table}{pager}</div>', active="/admin/audit"))


# 경로 → (처리 함수, 로그인 없이 열리나)
_GET = {
    "/": (get_root, True), "/login": (get_login, True), "/setup": (get_setup, True),
    "/password": (get_password, False), "/forms": (get_forms, False), "/upload": (get_upload, False),
    "/mine": (get_mine, False), "/form": (get_form, False), "/download": (get_download, False),
    "/review": (get_review, False), "/review/file": (get_review_file, False),
    "/review/item": (get_review_item, False), "/compare": (get_compare, False),
    "/admin/users": (get_admin_users, False), "/admin/folders": (get_admin_folders, False),
    "/admin/audit": (get_admin_audit, False), "/folders/move": (get_folder_move, False),       # f6
    "/register": (get_register, False), "/register.xlsx": (get_register_xlsx, False),           # F7 문서 관리 대장
    "/register/due": (get_register_due, False),
    "/admin/docno": (get_admin_docno, False),                                                   # F7 번호 규칙
    "/admin/doctypes": (get_admin_doctypes, False),                                             # F7 문서 종류
}
_POST = {
    "/login": (post_login, True), "/setup": (post_setup, True), "/theme": (post_theme, True),
    "/logout": (post_logout, False), "/password": (post_password, False),
    "/folders/new": (post_folder_new, False), "/folders/rename": (post_folder_rename, False),
    "/folders/subscribe": (post_folder_subscribe, False), "/admin/users/email": (post_user_email, False),
    "/upload": (post_upload, False), "/submissions/cancel": (post_cancel, False),
    "/review/approve": (post_approve, False), "/review/reject": (post_reject, False),
    "/form/retire": (post_retire, False), "/form/restore": (post_restore, False),
    "/admin/users/new": (post_user_new, False), "/admin/users/disable": (post_user_disable, False),
    "/admin/users/reset": (post_user_reset, False), "/admin/users/role": (post_user_role, False),
    "/admin/reviewers": (post_reviewers, False),
    "/compare": (post_compare, False), "/review/compare": (post_review_compare, False),     # 보안 F3
    "/admin/unlock-ip": (post_unlock_ip, False),                                              # 보안 F2
    "/folders/move": (post_folder_move, False), "/folders/delete": (post_folder_delete, False),   # f6 폴더 관리
    "/folders/order": (post_folder_order, False), "/admin/folders/template": (post_folder_template, False),
    "/register/reviewed": (post_register_reviewed, False), "/form/review-months": (post_form_review_months, False),
    "/form/docno": (post_form_docno, False), "/admin/docno/assign": (post_docno_assign, False),     # F7
    "/folders/code": (post_folder_code, False),
    "/admin/docno": (post_admin_docno, False), "/admin/docno/renumber": (post_admin_docno_renumber, False),
    "/form/doctype": (post_form_doctype, False), "/review/doctype": (post_review_doctype, False),   # F7 문서 종류
    "/admin/doctypes/new": (post_doctype_new, False), "/admin/doctypes/edit": (post_doctype_edit, False),
    "/admin/doctypes/active": (post_doctype_active, False), "/admin/doctypes/delete": (post_doctype_delete, False),
    "/admin/doctypes/assign": (post_doctype_assign, False),
}
# 비밀번호를 바꿔야 하는 계정이 쓸 수 있는 주소
_MUST_CHANGE_OK = {"/password", "/logout", "/theme", "/login", "/setup", "/"}


# ── 손으로 띄우기 ────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):      # 한국어 Windows 콘솔(cp949)에서 글자 하나로 죽지 않게
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    p = argparse.ArgumentParser(prog="python -m watcher.forms.server",
                                description="Drev 양식함 사내망 화면 서버 (손으로 띄우기, 상시 실행은 F4의 forms-serve)")
    p.add_argument("--data", required=True, help="Drev 데이터 폴더 (forms.db·forms_store가 생기는 곳)")
    p.add_argument("--host", default="127.0.0.1", help="사내망 주소 (기본 127.0.0.1, 모든 주소: 0.0.0.0)")
    p.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"포트 (기본 {DEFAULT_PORT})")
    p.add_argument("--mirror", default=None, help="(선택) 현행 미러 폴더")
    p.add_argument("--max-upload-mb", type=int, default=MAX_UPLOAD_BYTES // (1024 * 1024),
                   help="올리기 상한 MB (기본 50)")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    def ready(srv):
        host, port = srv.server_address[:2]
        print(f"양식함이 열렸습니다: http://{host}:{port}/  (멈추려면 Ctrl+C)", flush=True)
        if host in ("0.0.0.0", "::"):
            print("사내망 전용입니다 — 공유기에서 이 포트를 인터넷으로 열지 마세요.", flush=True)

    try:
        serve(a.data, a.host, a.port, mirror_root=a.mirror,
              max_upload_bytes=max(1, a.max_upload_mb) * 1024 * 1024, on_ready=ready)
    except AlreadyRunning as e:
        print(str(e), file=sys.stderr)
        return 2
    except (FormsError, OSError) as e:
        print(f"양식함을 열 수 없습니다: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
