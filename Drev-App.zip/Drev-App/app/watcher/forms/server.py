# -*- coding: utf-8 -*-
"""양식함 사내망 화면 서버 (FORMS.md 3·4·6절, 2026-10-28 F2).

- 표준 라이브러리 http.server(ThreadingHTTPServer)만 쓴다. 저장·권한은 store.FormsStore, 계정은 auth.
  이 모듈은 파일을 쓰지 않는다 — 소켓으로 응답을 보낼 뿐(self.wfile.write 한 곳, tests/test_readonly.py).
- 화면: 로그인·로그아웃·비밀번호 바꾸기, 첫 관리자 만들기(Drev PC에서만), 양식함(폴더 트리·목록·검색),
  폴더 만들기·이름 바꾸기, 양식 올리기(검토 대기)·내 제출, 양식 상세·판 이력·내려받기,
  관리자(계정·폴더 관리(f6: 기본 분류 틀·옮기기·지우기·차례)·감사 기록), 검토(F3: 현행 판과 자동 비교·새 양식 요약·승인 메모·반려 사유),
  판끼리 비교(F3), 폐기·복원(F3, 사유 필수), 문서 관리 대장·문서번호·정기 검토(F7 — 대장 화면·엑셀·기한 목록·검토함),
  문서번호 규칙·다시 매기기(F7 번호 규칙 — 관리자 /admin/docno).
- 보안(6절): 상태를 바꾸는 요청은 전부 POST + 세션 + CSRF(로그인 전 화면은 이중 제출 쿠키). GET은 바꾸지 않는다.
  보안 헤더(CSP에 스크립트 없음·인라인 스타일 없음), HttpOnly·SameSite=Strict 쿠키, 모든 출력 html.escape,
  요청 줄·헤더 크기 상한, 느린 요청 끊기(감시 스레드), 동시 연결 상한, 본문을 읽기 전에 Content-Length로 413.
  오류는 화면에 Traceback을 보이지 않고 로그에만 남긴다. 인터넷 주소(공인 IP)에서 온 요청은 받지 않는다.
- 보안 검토 고침(2026-10-28): 비인증 POST 주소별 토큰 버킷(429), 주소 잠금·잠긴 주소 풀기 화면, GET /compare는 캐시만
  (계산은 POST [비교하기]), 검토 화면 자동 비교는 대기 1건당 1회, 정리 일 스레드(대기 파일 보존 기간·실패 행).
- 손으로 띄우기: python -m watcher.forms.server --data <데이터 폴더> --host <사내망 IP> --port 8766
  (forms-serve 명령·DrevForms 예약 작업·방화벽은 F4.)
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import html
import ipaddress
import logging
import os
import re
import secrets
import socket
import sys
import threading
import time
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

from watcher.forms import auth
from watcher.forms.compare import COMPARE_TIMEOUT, Comparer
from watcher.forms.notify import Notifier
from watcher.forms.publish import Mirror
from watcher.forms import catalog, keep, ledger
from watcher.forms.store import (ALLOWED_EXTS, AUDIT_MAX_ROWS, DOCNO_DIGITS_MAX, DOCNO_DIGITS_MIN, DOCNO_PRESETS,
                                 MAX_DOC_NO, MAX_DOCNO_PATTERN, MAX_UPLOAD_BYTES, PENDING_KEEP_DAYS, REVIEW_MONTHS_MAX,
                                 REVIEW_SOON_DAYS, SEARCH_MAX, Conflict, FormsError, FormsStore, GuardError,
                                 InvalidInput, MemoRequired, NoSpace, NotFound, PermissionDenied, Purged, level_name,
                                 now_text, parse_docno_pattern, rule_uses_type, MAX_DOC_TYPE_NAME, StageError,
                                 StepRefused)

log = logging.getLogger("drev.forms.server")

DEFAULT_PORT = 8766
SESSION_COOKIE = "drev_forms"
PRE_COOKIE = "drev_forms_pre"         # 로그인 전 화면(로그인·첫 관리자)의 CSRF 이중 제출 쿠키
THEME_COOKIE = "drev_forms_theme"
RETIRED_PREFIX = "[폐기] "               # 폐기된 양식을 내려받을 때 파일 이름 앞에 (F3)
MAX_REQUEST_LINE = 8 * 1024
MAX_HEADER_BYTES = 32 * 1024
MAX_HEADERS = 60
MAX_FORM_BODY = 64 * 1024              # 올리기가 아닌 POST(글자 칸만)
DISCARD_BODY_MAX = 64 * 1024           # 읽지 않고 답할 때 그래도 읽어 버리는 본문 상한 (Windows RST 방지)
MULTIPART_SLACK = 1024 * 1024          # 올리기 본문 = 파일 상한 + 이만큼(경계·다른 칸)
MAX_CONNECTIONS = 64
HEADER_SECONDS = 20.0                  # 요청 줄·헤더를 이 안에 다 보내야 한다
BODY_MIN_RATE = 128 * 1024             # 본문·응답은 최소 이 속도(바이트/초) + 30초 여유
SOCKET_TIMEOUT = 20                    # 한 번 읽기·쓰기가 이만큼 멈추면 끊는다

ROLE_LABEL = {"admin": "관리자", "reviewer": "검토자", "member": "직원"}
STATUS_LABEL = {"pending": "검토 대기", "approved": "승인됨", "rejected": "반려됨", "cancelled": "취소함"}
DECIDED_LABEL = {"approved": "승인", "rejected": "반려", "cancelled": "취소"}     # 내 제출의 처리 줄 머리 (2026-10-31)
KIND_LABEL = {"new": "새 양식", "revision": "개정안"}
ACTION_LABEL = {
    "admin_bootstrap": "첫 관리자 만듦", "user_create": "계정 등록", "user_disable": "계정 정지",
    "user_enable": "계정 복구", "user_role": "역할 바꿈", "password_reset": "비밀번호 초기화",
    "password_change": "비밀번호 바꿈", "login": "로그인", "login_fail": "로그인 실패",
    "login_locked": "잠긴 동안 로그인 시도", "login_disabled": "정지 계정 로그인 시도", "logout": "로그아웃",
    "folder_create": "폴더 만듦", "folder_rename": "폴더 이름 바꿈", "folder_reviewers": "검토자 지정",
    "folder_move": "폴더 옮김", "folder_delete": "폴더 지움", "folder_order": "폴더 차례 바꿈",
    "folder_template": "기본 분류 틀 만듦",
    "submit": "올림", "approve": "승인", "reject": "반려", "cancel": "제출 취소",
    "download": "내려받음", "download_submission": "대기 파일 열어 봄", "retire": "폐기", "restore": "복원",
    "compare_fail": "자동 비교 실패",
    "user_email": "메일 주소 바꿈", "notify": "메일 알림 보냄", "notify_fail": "메일 알림 실패",
    "mirror_fail": "현행 미러 실패", "mirror_skip": "현행 미러 건너뜀",
    "ip_locked": "접속 주소 잠김", "ip_unlock": "접속 주소 잠금 풀기", "pending_purge": "대기 파일 정리",
    "login_spray": "여러 주소에서 로그인 실패 몰림",                                        # 검토20 r09-1
    # 문서 관리 대장 (F7)
    "doc_no": "문서번호 고침", "doc_no_assign": "문서번호 일괄 매김", "folder_code": "폴더 번호 머리 바꿈",
    "review_months": "검토 주기 바꿈", "form_review": "정기 검토함", "register_export": "문서 관리 대장 내려받음",
    "doc_no_fallback": "문서번호 전역 꼴로 매김",
    "docno_rule": "문서번호 규칙 바꿈", "docno_renumber": "문서번호 다시 매김",          # F7 번호 규칙
    # 문서 종류 (F7 문서 종류)
    "doc_type_create": "문서 종류 더함", "doc_type_code": "문서 종류 기호 바꿈", "doc_type_name": "문서 종류 이름 바꿈",
    "doc_type_inactive": "문서 종류 사용 중지", "doc_type_active": "문서 종류 다시 사용", "doc_type_delete": "문서 종류 지움",
    "doc_type_assign": "문서 종류 일괄 지정", "form_doc_type": "양식 문서 종류 바꿈",
    "submission_doc_type": "검토 대기 문서 종류 바꿈",
    # 백업·복원·주간 알림 (2026-10-30, backup.py·weekly.py)
    "backup": "백업", "backup_fail": "백업 실패", "restore": "복원", "digest_sent": "주간 알림 보냄",
    "password_fail": "비밀번호 바꾸기 실패", "password_locked": "잠긴 동안 비밀번호 바꾸기 시도",   # 2026-10-30 L3
    "forbidden": "거부된 요청(권한)", "forbidden_csrf": "거부된 요청(확인 값)",                   # 2026-10-30 L4
    "forbidden_origin": "거부된 요청(다른 곳)",
    "folder_restricted": "기밀 폴더 켬·끔", "folder_members": "기밀 폴더 볼 사람 지정",     # 기밀 폴더 (2026-10-30)
    # 기록 보존 만료 (2026-10-30, keep.py)
    "retention_policy": "보존 기간 바꿈", "retention_type": "문서 종류 보존 기간 바꿈",
    "retention_purge": "보존 기간 지난 판 정리",
    # 2단계 승인 (2026-10-30 사용자 결정 ②)
    "folder_approval_steps": "승인 단계 바꿈", "folder_approvers": "승인권자 지정",
    "submission_checked": "검토 완료(승인 요청)",
    # 기능 검토 F2 (2026-11-02)
    "forms_settings": "양식함 설정 바꿈", "form_move": "양식 옮김",
    # 사내망 변경 확인 (기능 검토 갈래 N, 2026-11-02 — FORMS.md 11절)
    "change_ack": "변경 확인함(사내망)", "changes_access": "변경 브리핑 열람 권한 바꿈", "changes_export": "설계 변경 대장 내려받음",
}
STAGE_LABEL = {"check": "검토 대기", "approve": "승인 대기"}       # 2단계 승인 — 검토 대기 제출의 단계 (상태 칸은 그대로 pending)
REVIEW_STATE = {"overdue": ("기한 지남", "overdue"), "soon": ("곧", "soon"), "ok": ("", ""),
                "off": ("검토 안 함", "off"), "retired": ("", "")}
# 비인증 화면(로그인·첫 관리자) POST의 주소(IP)별 토큰 버킷 — 순간 30번, 그 뒤 초당 1번 (2026-10-28 보안 F1)
RATE_CAPACITY = 30
RATE_PER_SECOND = 1.0
MAINT_SECONDS = 3600                   # 정리 일(대기 파일·실패 행)을 도는 간격(초) — 서버 시작 때 한 번 + 이만큼마다
UPLOAD_PARALLEL = 4                    # 본문을 읽고 푸는 올리기 동시 상한 — 넘으면 503 (메모리 50MB×몇 배가 겹치지 않게, 2026-10-30)
STASH_MAX = 4                          # (옛 이름 — 이제 쓰지 않는다. 보관은 사용자마다 하나 + STASH_BYTES, 재검토 rr066 lan 3)
STASH_BYTES = 64 * 1024 * 1024         # [그래도 올리기]를 기다리는 올린 파일 전체 바이트 상한 (메모리) — 넘으면 보관하지 않고 안내
STASH_SECONDS = 900
BULK_MAX = 300                         # 계정 일괄 등록 한 번에 받는 줄 수 (F2-2)
PAGE_ROWS = 200                        # 긴 목록(전체 양식·대장·기한 목록·폴더 관리) 한 쪽 줄 수 (2026-10-30)
REVISION_PICK_MAX = 300                # 개정안 양식 고르기 칸에 한 번에 넣는 양식 수 — 넘으면 폴더부터 고른다 (2026-10-30)
OLD_PREFIX = "지난 판 v{n}"              # 현행이 아닌 판을 받을 때 파일 이름 앞 '[지난 판 v2] ' (2026-10-30)
# 입력 칸 아래 주의 문구 (2026-10-30 사용자 요청 '무슨 기호 쓰면 안되는게 있으면 주의 문구') — 검사 함수(store·guard·auth)와 같은 규칙
HINT_FOLDER_NAME = ('쓸 수 없는 기호: \\ / : * ? " < > | · 끝에 점·공백 불가 · CON·NUL 같은 Windows 예약 이름 불가 (80자까지) '
                    '— 탐색기 폴더 이름으로도 쓰입니다')
HINT_FOLDER_CODE = ("영문·숫자·한글 1~8자, 가운데 점만 가능 (예: QA, 7.5, 품질) — 공백·붙임표(-)·괄호 불가, 'F' 한 글자 불가, "
                    "소문자는 대문자로 저장")
HINT_TYPE_CODE = ("영문·숫자·한글 1~8자, 가운데 점만 가능 (예: QP, 절차) — 공백·붙임표(-)·괄호 불가, 'F' 한 글자 불가 · 번호에 그대로 "
                  "들어갑니다")
HINT_TYPE_NAME = f"{MAX_DOC_TYPE_NAME}자까지 — 화면·대장에만 보이고 번호에는 안 들어갑니다"
HINT_DOCNO_RULE = "쓸 수 있는 글자: 영문·숫자·한글과 - _ . 그리고 칸 {…} — 공백·괄호·/ 불가, {번호}는 맨 끝에 한 번"
HINT_DOC_NO = (f"영문·숫자·한글과 - . _ 만, {MAX_DOC_NO}자까지 (예: QA-01-001) — 공백·괄호·/ 불가, 처음과 끝은 글자·숫자, "
               f"소문자는 대문자로, 다른 양식 번호와 겹치면 안 됨")
HINT_FORM_NAME = "100자까지"
HINT_FORM_NAME_MIRROR = ('100자까지 — 승인되면 공유 폴더(현행 미러)에 이 이름의 파일로도 놓이므로 \\ / : * ? " < > | 는 '
                         '\'_\'로 바뀌고 끝의 점·공백은 빠집니다')
HINT_FILE = "파일 이름 200자까지 · CON·NUL 같은 Windows 예약 이름 불가 · 올릴 수 있는 종류·크기는 위 안내대로"


def hint_file(n: int) -> str:
    """올리기 화면의 파일 안내 — 실제 한도(이름 상한 200자와 이 서버 보관 폴더 경로로 남는 글자 가운데 작은 쪽)를 싣는다
    (검토20 r05-3 — 데이터 폴더가 길면 '200자까지'인데 181자에서 거부됐다). 200자면 HINT_FILE 그대로."""
    if n >= 200:
        return HINT_FILE
    return (f"파일 이름 {n}자까지 (이 서버의 보관 폴더 경로 때문에 200자보다 짧습니다) · CON·NUL 같은 Windows 예약 이름 불가 · "
            "올릴 수 있는 종류·크기는 위 안내대로")
HINT_LOGIN = "2~32자 — 글자·숫자와 점(.)·밑줄(_)·붙임표(-)만, 글자나 숫자가 하나 이상 (ㄱ·ㅏ 같은 낱자만은 불가)"
HINT_DISPLAY_NAME = "40자까지"
HINT_EMAIL = "한 사람 한 주소 (쉼표로 여럿 불가) — 비우면 알림을 받지 않습니다"
HINT_MONTHS = f"1~{REVIEW_MONTHS_MAX}개월 (검토하지 않으려면 '검토 안 함'을 고르세요)"
UPLOAD_WAIT_SECONDS = 10.0             # 올리기 자리가 빌 때까지 기다리는 상한 — 넘으면 503 (2026-10-30 검토)
UPLOAD_MIN_RATE = 1024 * 1024          # 올리기 본문 최소 속도(바이트/초) — 느린 상대가 자리를 오래 쥐지 못하게
UPLOAD_FLOOR_SECONDS = 60.0            # 올리기 본문 마감 = 이만큼 + 크기/최소 속도 (50MB ≈ 110초)
HINT_MEMO = "500자까지"
HINT_CONFIDENTIAL = ("켜면 이 폴더와 하위 폴더는 관리자·이 폴더 검토자·승인권자·아래에서 고른 직원만 봅니다. "
                     "공유 폴더(현행 미러)에도 놓지 않습니다.")
HINT_CONF_CODE = ("기밀 폴더에는 따로 번호 머리를 주세요 — 위 폴더와 머리를 같이 쓰면 문서번호 일련이 이어져, "
                  "번호 간격으로 기밀 양식 수를 짐작할 수 있습니다.")          # 기밀 폴더 검토 3 (2026-10-30)
TWO_STEP_NOTE = "이 폴더는 2단계 승인입니다 — 검토자가 검토한 뒤 승인권자가 승인해야 현행 판이 됩니다"   # 모두에게 (2026-10-31)
HINT_TWO_STEP = ("2단계면 검토자가 [검토 완료]한 뒤 승인권자가 [승인]해야 현행 판이 됩니다. "
                 "올린 사람·검토한 사람·승인한 사람은 서로 달라야 합니다.")
HINT_APPROVERS = ("검토자 역할 계정만 고릅니다 — 관리자는 고르지 않아도 늘 승인권자입니다. 직원은 안 됩니다. "
                  "대표처럼 승인만 하는 사람은 [계정]에서 검토자 역할로 등록하세요. 이 폴더와 하위 폴더에 적용됩니다.")
HINT_KEEP_YEARS = keep.HINT_YEARS                  # 보존 연수 (2026-10-30) — keep.clean_years와 같은 규칙
HINT_TYPE_KEEP_YEARS = keep.HINT_TYPE_YEARS
_ERROR_TEXT = {
    400: "요청을 이해하지 못했습니다", 401: "로그인이 필요합니다", 403: "할 수 없는 일입니다",
    404: "없는 화면입니다", 405: "이 방법으로는 열 수 없는 주소입니다", 408: "요청이 너무 느려 끊었습니다",
    409: "지금 상태와 맞지 않습니다", 410: "보존 기간이 지나 정리한 판입니다", 411: "본문 길이(Content-Length)가 필요합니다",
    413: "보낸 내용이 너무 큽니다", 414: "주소가 너무 깁니다", 415: "지원하지 않는 형식입니다",
    429: "잠시 뒤에 다시 해 주세요", 431: "요청 머리글이 너무 큽니다", 500: "문제가 생겼습니다",
    501: "지원하지 않는 요청입니다", 503: "접속이 많습니다 — 잠시 뒤에 다시 해 주세요",
    507: "저장 공간이 부족합니다 — 관리자에게 알려 주세요",
}
_BUSY = ("HTTP/1.0 503 Service Unavailable\r\nContent-Type: text/plain; charset=utf-8\r\n"
         "Connection: close\r\nRetry-After: 5\r\nX-Content-Type-Options: nosniff\r\n\r\n"
         "busy\r\n").encode("ascii")

# 스크립트 없음, 인라인 스타일 없음 — 스타일은 /forms.css 하나 (FORMS.md 6절 CSP default-src 'self')
CSP = ("default-src 'self'; script-src 'none'; style-src 'self'; img-src 'self' data:; "
       "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")
SECURITY_HEADERS = (
    ("X-Frame-Options", "DENY"),
    ("Content-Security-Policy", CSP),
    ("X-Content-Type-Options", "nosniff"),
    ("Referrer-Policy", "same-origin"),
    ("Cache-Control", "no-store"),
    ("Cross-Origin-Opener-Policy", "same-origin"),
)

E = html.escape


class AlreadyRunning(FormsError):
    """같은 데이터 폴더로 양식함 서버가 이미 돌고 있다."""


class HttpError(Exception):
    """화면에 보일 HTTP 오류 (status, 쉬운 말)."""

    def __init__(self, status: int, message: str = ""):
        super().__init__(message)
        self.status = int(status)
        self.message = message or _ERROR_TEXT.get(self.status, "요청을 처리할 수 없습니다")


class MultipartError(ValueError):
    """올리기 본문(multipart/form-data)이 깨졌다 → 400."""


# ── 화면 모양 (Drev 감시 화면과 같은 토큰, 어두운·밝은 테마) ────────────────────────

_DARK_TOKENS = """
  --bg:#0C0E12; --panel:#14171D; --panel2:#1A1E26; --hover:#212634;
  --border:#232833; --border2:#333B4A; --line:#1E242F;
  --text:#E6E9EF; --text2:#CBD1DC; --text3:#ADB5C4; --muted:#AAB2C1; --muted2:#8E97A8;
  --link:#93A0FA; --accent:#4C5DE6; --accent2:#7C8CF8; --on-accent:#FFFFFF;
  --ok:#3FB950; --ok-strong:#4ADE80; --warn:#E3B341; --warn3:#EAB94E; --bad:#F47067; --bad-btn:#C62F2F;
  --tag-add:rgba(63,185,80,.14); --tag-mod:rgba(227,179,65,.14); --tag-rm:rgba(244,112,103,.15);
  --tag-done:rgba(124,140,248,.16); --note-warn:#2E2612; --note-info:#1B2140;
  --shadow:0 1px 3px rgba(0,0,0,.45); color-scheme:dark;"""

CSS = """/* Drev 양식함 — 감시 화면(web.py)과 같은 디자인 토큰. 기본은 OS 설정을 따르고 [테마] 단추로 고정 */
:root{
  --bg:#F2F4F8; --panel:#FFFFFF; --panel2:#F7F8FB; --hover:#EEF0F6;
  --border:#E3E6EE; --border2:#C9CEDB; --line:#EEF0F5;
  --text:#171C26; --text2:#2A303C; --text3:#454D5E; --muted:#596273; --muted2:#5F6B82;
  --link:#4353E8; --accent:#4353E8; --accent2:#5B6CF5; --on-accent:#FFFFFF;
  --ok:#0F8A3D; --ok-strong:#0F7A37; --warn:#B97800; --warn3:#8A5A05; --bad:#C62F2F; --bad-btn:#C62F2F;
  --tag-add:#E2F5E9; --tag-mod:#FBF0D9; --tag-rm:#FBE7E7; --tag-done:#E5E9FD;
  --note-warn:#FFF8E5; --note-info:#E8ECFE;
  --shadow:0 1px 3px rgba(23,28,38,.06), 0 1px 2px rgba(23,28,38,.04); color-scheme:light;
  --fs-s:13px; --fs-m:15px; --fs-l:17px;
}
@media (prefers-color-scheme: dark){ :root:not([data-theme=light]){""" + _DARK_TOKENS + """} }
:root[data-theme=dark]{""" + _DARK_TOKENS + """}
*{margin:0;box-sizing:border-box;font-family:'Pretendard','Malgun Gothic','Segoe UI Variable','Segoe UI',sans-serif}
body{background:var(--bg);color:var(--text);display:flex;min-height:100vh;-webkit-font-smoothing:antialiased}
a{color:var(--link);text-decoration:none} a:hover{text-decoration:underline}
.skip{position:absolute;left:-9999px;top:0;z-index:200;background:var(--accent);color:#fff;padding:8px 14px}
.skip:focus{left:0}
.side{width:216px;background:var(--panel);border-right:1px solid var(--border);padding:18px 12px;
  position:fixed;top:0;bottom:0;display:flex;flex-direction:column;overflow-y:auto}
.logo{font-weight:800;font-size:17px;color:var(--link);padding:6px 10px 16px}
.logo small{display:block;color:var(--muted);font-weight:400;font-size:12px;margin-top:3px}
.nav{flex:1}
.nav .grp{font-size:11px;color:var(--muted);letter-spacing:.6px;padding:12px 12px 4px}
.nav a{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;border-radius:9px;
  min-height:36px;color:var(--text3);font-size:14px;margin-bottom:2px}
.nav a:hover{background:var(--hover);color:var(--text);text-decoration:none}
.nav a[data-ic]{justify-content:flex-start;gap:8px}
.nav a[data-ic]::before{content:attr(data-ic);width:1.3em;text-align:center;flex:none}
.nav a .cnt{margin-left:auto}
.nav a.on{background:var(--accent);color:var(--on-accent);font-weight:700}
.cnt{display:inline-block;min-width:22px;padding:1px 7px;border-radius:999px;background:var(--tag-mod);
  color:var(--warn3);font-size:12px;font-weight:700;text-align:center}
.nav a.on .cnt{background:rgba(255,255,255,.25);color:#fff}
.me{border-top:1px solid var(--line);padding:12px 8px 4px;font-size:13px;color:var(--muted)}
.me b{display:block;color:var(--text);font-size:14px;margin-bottom:2px}
.me a{display:block;margin:8px 0 4px}
.me form{margin-top:6px}
.side .btn{width:100%}
.main{margin-left:216px;flex:1;min-width:0;padding:22px 30px;max-width:1500px}
.topbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:16px}
.topbar h1{font-size:20px;font-weight:800;letter-spacing:-.3px}
.crumb{font-size:var(--fs-s);color:var(--muted2);margin-bottom:6px}
.panel{background:var(--panel);border-radius:12px;padding:14px 18px;margin-bottom:12px;
  border:1px solid var(--border);box-shadow:var(--shadow);overflow-x:auto}
.panel h2{font-size:var(--fs-l);margin:0 0 10px;font-weight:700}
.panel h3{font-size:var(--fs-m);margin:14px 0 8px;font-weight:700}
.split{display:grid;grid-template-columns:250px minmax(0,1fr);gap:12px;align-items:start}
.tree ul{list-style:none;padding-left:14px;margin:2px 0}
.tree>ul{padding-left:0}
.tree li{margin:1px 0}
.tree a{display:block;padding:5px 8px;border-radius:8px;color:var(--text2);font-size:14px;word-break:break-all}
.tree a:hover{background:var(--hover);text-decoration:none}
.tree a.on{background:var(--tag-done);color:var(--link);font-weight:700}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.chips a{border:1px solid var(--border);border-radius:999px;padding:4px 12px;font-size:13px;color:var(--text2);
  background:var(--panel2)}
table{width:100%;border-collapse:collapse;font-size:14px}
th{color:var(--muted);font-weight:600;text-align:left;padding:7px 10px;border-bottom:1px solid var(--border);
  font-size:12px;background:var(--panel2);white-space:nowrap}
td{padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top;font-variant-numeric:tabular-nums}
tr:hover td{background:var(--panel2)}
td.nw{white-space:nowrap}
.muted{color:var(--muted2);font-size:13px}
.panel>p.muted{margin-bottom:10px}
.empty{color:var(--muted);padding:18px 4px;text-align:center}
.tag{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;white-space:nowrap}
.tag.pending{background:var(--tag-mod);color:var(--warn3)}
.tag.approved{background:var(--tag-add);color:var(--ok-strong)}
.tag.rejected{background:var(--tag-rm);color:var(--bad)}
.tag.cancelled,.tag.retired,.tag.off{background:var(--hover);color:var(--muted)}
.tag.role{background:var(--tag-done);color:var(--link)}
.btn{display:inline-block;background:var(--accent);color:var(--on-accent);border:none;border-radius:9px;
  padding:6px 14px;min-height:32px;font-size:14px;cursor:pointer;font-weight:700;white-space:nowrap;line-height:20px}
.btn:hover{filter:brightness(1.08);text-decoration:none}
.btn.gray{background:var(--panel2);color:var(--text2);border:1px solid var(--border)}
.btn.red{background:var(--bad-btn);color:#fff}
.btn.sm{min-height:28px;padding:4px 10px;font-size:13px}
form.inline{display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap;margin:2px 0}
label{display:block;margin:10px 0 4px;font-size:13px;color:var(--muted)}
label.chk{display:inline-flex;align-items:center;gap:6px;margin:4px 12px 4px 0;color:var(--text2);font-size:14px}
input[type=text],input[type=password],input[type=search],input[type=file],input[type=email],select,textarea{
  border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:14px;
  background:var(--panel);color:var(--text);max-width:100%}
input[type=text],input[type=password],select.wide,textarea{width:420px}
input:focus,select:focus,textarea:focus{outline:2px solid var(--accent2);border-color:var(--accent)}
.form-actions{margin-top:14px;display:flex;gap:8px;flex-wrap:wrap}
.searchbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
.searchbar input[type=search]{width:280px}
.note{border-radius:10px;padding:10px 14px;margin-bottom:12px;border:1px solid var(--border);font-size:14px}
.note.ok{background:var(--tag-add);color:var(--text)}
.note.bad{background:var(--tag-rm);color:var(--text);border-left:4px solid var(--bad)}
.note.info{background:var(--note-info);color:var(--text)}
.note.warn{background:var(--note-warn);color:var(--text)}
.secret{font-family:Consolas,'Courier New',monospace;font-size:22px;font-weight:700;letter-spacing:1px;
  padding:10px 14px;border:1px dashed var(--border2);border-radius:10px;display:inline-block;margin:8px 0;
  background:var(--panel2);user-select:all}
details.tool{margin:6px 0}
details.tool>summary{cursor:pointer;color:var(--link);font-size:14px;display:inline-block}
details.tool[open]{background:var(--panel2);border-radius:10px;padding:8px 12px}
details.tool.fold>summary{font-weight:600}
details.tool.fold[open]{background:var(--panel);border:1px solid var(--border)}
.later{color:var(--muted);font-size:13px;border:1px dashed var(--border2);border-radius:10px;padding:8px 12px;margin-top:10px}
.authwrap{margin:8vh auto;max-width:440px;width:100%;padding:0 16px}
.authwrap .logo{text-align:center;padding-bottom:18px}
.authwrap .panel{padding:22px 24px}
.authwrap input[type=text],.authwrap input[type=password]{width:100%}
.pager{display:flex;gap:8px;margin-top:10px}
/* 자동 비교 근거 표 (F3) — 이전 값은 취소선, 새 값은 강조, 바뀐 낱말은 색 */
.tag.k-add{background:var(--tag-add);color:var(--ok-strong)}
.tag.k-mod{background:var(--tag-mod);color:var(--warn3)}
.tag.k-rm{background:var(--tag-rm);color:var(--bad)}
.tag.k-info{background:var(--hover);color:var(--muted)}
.cmp-head{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:baseline;margin:0 0 10px;font-size:14px}
.cmp-head b{font-size:16px}
table.cmp td{font-size:14px;word-break:break-word}
table.cmp td.name{min-width:110px}
table.cmp td.val{min-width:140px;max-width:420px}
del.old{text-decoration:line-through;color:var(--muted)}
del.old .hl{background:var(--tag-rm);color:var(--bad);border-radius:3px}
ins.new{text-decoration:none;font-weight:700;color:var(--text)}
ins.new mark{background:var(--tag-add);color:var(--ok-strong);border-radius:3px;padding:0 1px}
.none{color:var(--muted2)}
ul.notes{margin:8px 0 0 18px;color:var(--muted2);font-size:13px}
ul.lines{margin:4px 0 0 18px;font-size:14px}
.kv{display:grid;grid-template-columns:120px minmax(0,1fr);gap:6px 12px;font-size:14px;margin-bottom:6px}
.kv dt{color:var(--muted)} .kv dd{margin:0;word-break:break-word}
.cols{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 8px}
.cols span{border:1px solid var(--border);border-radius:6px;padding:2px 8px;font-size:13px;background:var(--panel2)}
.decide{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}
.decide textarea{width:100%;min-height:64px}
.pick{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
/* 메일 알림·구독 (F4) */
input[type=email]{width:240px}
.sub{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0 10px;font-size:13px;color:var(--muted)}
/* 판 이력 표 (f6) — 판·날짜·이름은 줄바꿈 없이, 설명·파일 칸이 줄어든다. 좁으면 표만 가로로 밀린다 */
.tablewrap{overflow-x:auto;max-width:100%}
table.hist td.note-c{min-width:9em;word-break:keep-all;overflow-wrap:anywhere}
table.hist td.file-c{min-width:7em;overflow-wrap:anywhere;word-break:break-all}
table.hist td.acts{min-width:8.5em}
table.hist .dt{word-break:keep-all;min-width:6em}          /* 날짜와 시각 사이에서만 줄을 바꾼다 */
span.nw{white-space:nowrap}
/* 양식 목록 표 — 이름·폴더가 한두 글자씩 꺾이지 않게 최소 폭, 낱말 단위로만 줄바꿈 */
table.flist td.name-c{min-width:6em;word-break:keep-all}
table.flist td.path-c{min-width:6.5em;word-break:keep-all}
.exts{overflow-wrap:anywhere}             /* 올릴 수 있는 확장자 줄 — 폰에서 줄을 바꾼다 (ux21 forms 11) */
table.flist .nshow{display:none}            /* 좁은 화면에서만 — 숨긴 폴더 열 대신 이름 아래 (ux21 forms 2) */
table.mine td.name-c{min-width:7em;word-break:keep-all}     /* 내 제출 양식명이 한 글자씩 꺾이지 않게 (ux21 forms 1) */
.cands .gap,.note .gap{margin-left:10px}                   /* [현행 판 받기] 옆 '판 이력'을 띄운다 (ux21 forms 7) */
table.hist td.acts .btn{margin:2px 0}
/* 폴더 층·관리 (f6) */
.tag.lvl{background:var(--hover);color:var(--muted);font-weight:600;margin-left:4px;vertical-align:1px}
.tag.conf{background:var(--tag-rm);color:var(--bad);font-weight:600;margin-left:4px;vertical-align:1px}
.tag.two{background:var(--tag-done);color:var(--link);font-weight:600;margin-left:4px;vertical-align:1px}
.tag.awaiting{background:var(--tag-done);color:var(--link)}
.conf-who{margin:6px 0}
table.ftree td{vertical-align:top}
table.ftree td.fname{min-width:10em;word-break:keep-all}
.tree p a{display:inline;padding:0}
table.ftree td.lv1{padding-left:28px} table.ftree td.lv2{padding-left:46px} table.ftree td.lv3{padding-left:64px}
table.ftree td.lv4{padding-left:82px} table.ftree td.lv5{padding-left:100px} table.ftree td.lv6{padding-left:118px}
table.ftree details.tool[open]{min-width:280px}
table.ftree form{margin:4px 0}
table.ftree input[type=text]{width:200px}
.order{display:inline-flex;gap:6px;flex-wrap:wrap;margin:4px 0;align-items:center}
.tplgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:8px 16px;margin:8px 0}
.tpl{border:1px solid var(--border);border-radius:10px;padding:8px 12px;background:var(--panel2)}
.tpl .muted{display:block}
/* 문서 관리 대장·문서번호·정기 검토 (F7) — 넓은 표는 .tablewrap 안에서만 가로로 밀린다 */
.docno{font-family:Consolas,'Courier New',monospace;font-size:12px;color:var(--muted2);letter-spacing:.2px}
td .docno{display:block}
.tag.code{background:var(--tag-done);color:var(--link);font-family:Consolas,'Courier New',monospace;margin-left:4px;
  vertical-align:1px}
.tag.overdue{background:var(--tag-rm);color:var(--bad)}
.tag.soon{background:var(--tag-mod);color:var(--warn3)}
table.reg td{font-size:13px}
table.reg td.reason{min-width:12em;overflow-wrap:anywhere}
table.reg td.name-c{min-width:8em;word-break:keep-all}
table.reg td.path-c{min-width:5em;word-break:keep-all}
table.due td.act{min-width:17em}
input[type=text].code,input[type=text].docno-in{width:12em}
/* 문서번호 규칙·다시 매기기 (F7 번호 규칙) */
input[type=text].pattern{width:24em;font-family:Consolas,'Courier New',monospace}
.docno.big{font-size:14px;color:var(--text)}
.prevno{display:block;font-size:11px;color:var(--muted)}
.presets{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:10px 0 4px}
.presets .btn{font-family:Consolas,'Courier New',monospace}
ul.tokens code{font-family:Consolas,'Courier New',monospace;font-weight:700}
table.docex td.path-c,table.renum td.path-c{min-width:8em;word-break:keep-all}
table.renum td.name-c{min-width:8em;word-break:keep-all}
input[type=text].memo{width:15em}
input[type=text].months{width:5em}
/* 문서 종류 (F7 문서 종류) */
.tag.dtype{background:var(--tag-done);color:var(--text);font-family:Consolas,'Courier New',monospace;margin-right:4px;
  vertical-align:1px}
table.dtypes td.name-c{min-width:8em;word-break:keep-all}
table.dtypes form{margin:2px 0}
table.keep td.name-c{min-width:8em;word-break:keep-all}
table.keep td.file-c{min-width:7em;overflow-wrap:anywhere;word-break:break-all}
input[type=text].tname{width:12em}
.typewarn{color:var(--warn3);font-size:12px}
.reviewinfo{display:flex;flex-wrap:wrap;gap:4px 18px;margin:0 0 8px;font-size:14px}
/* 입력 칸 주의 문구·여러 줄 사유 (2026-10-30) */
.hint{color:var(--muted2);font-size:12px;margin:3px 0 0;line-height:1.45}
.pre{white-space:pre-line;overflow-wrap:anywhere}
td.chk{width:28px}
/* 기능 검토 F2 (2026-11-02) — 계정 일괄 등록 결과는 인쇄해 나눠 준다 */
.secret.sm{font-size:15px;margin:0;padding:2px 8px}
/* 사내망 변경 확인 (갈래 N, 2026-11-02) — 전/후 사진 */
.cap{display:flex;flex-wrap:wrap;gap:10px;margin:2px 0 6px}
.cap figure{margin:0;flex:1 1 300px;max-width:640px}
.cap figcaption{font-size:12px;font-weight:700;color:var(--muted);margin-bottom:3px}
.cap figure.after figcaption{color:var(--bad)}
.cap img{display:block;max-width:100%;height:auto;border:1px solid var(--border2);border-radius:6px;background:#fff}
.cap figure.after img{border-color:var(--bad)}
.curdl{display:none}                        /* 좁은 화면에서만 — 현행 판 큰 [내려받기] (ux20 forms 1) */
@media print{.side,.skip,.topbar .btn,.noprint{display:none}.main{margin-left:0;padding:0}
  .panel{box-shadow:none;border:none}body{background:#fff;color:#000}}
@media (max-width:860px){
  body{display:block}
  .side{position:static;width:auto;border-right:none;border-bottom:1px solid var(--border);padding:10px 12px}
  .nav{display:flex;flex-wrap:wrap;gap:4px}
  .nav .grp{width:100%;padding:6px 4px 0}
  .nav a{min-height:32px;padding:6px 10px;margin:0}
  .logo{padding:2px 4px 8px}
  .me{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center;padding:8px 4px 2px}
  .me b{display:inline;margin:0}
  .me a,.me form{margin:0}
  .side .btn{width:auto}
  .main{margin-left:0;padding:16px}
  .split{grid-template-columns:minmax(0,1fr)}
  input[type=text],input[type=password],select.wide,textarea{width:100%}
  table.ftree input[type=text]{width:100%}
  .searchbar input[type=search]{width:100%}
  /* 표 → 줄 단위 카드 (ux20 forms 1) — 핵심 단추가 가로 스크롤 밖으로 숨지 않게. 칸 이름은 칸 차례로 붙인다 */
  table:is(.hist,.due),table:is(.hist,.due) tbody,table:is(.hist,.due) tr,table:is(.hist,.due) td{display:block;width:auto;min-width:0}
  table:is(.hist,.due) thead{display:none}
  table:is(.hist,.due) tr{border:1px solid var(--border);border-radius:10px;padding:8px 12px;margin:0 0 8px;background:var(--panel)}
  table:is(.hist,.due) td{border:0;padding:3px 0;min-width:0 !important;white-space:normal}
  table:is(.hist,.due) td::before{color:var(--muted);font-size:12px}
  table.hist td:nth-child(2)::before{content:"승인한 날 · "}
  table.hist td:nth-child(3)::before{content:"올린 사람 · "}
  table.hist td:nth-child(4)::before{content:"승인자 · "}
  table.hist td:nth-child(5)::before{content:"설명 · "}
  table.hist td:nth-child(6)::before{content:"파일 · "}
  table.due td:nth-child(3)::before{content:"다음 검토 기한 · "}
  table.due td:nth-child(4)::before{content:"최근 검토 · "}
  table:is(.hist,.due) td:empty{display:none}
  table:is(.hist,.due) td.acts .btn,table:is(.hist,.due) td.act .btn{min-height:36px}
  /* 내 제출·근거 표도 줄 단위 카드 (ux21 forms 1·mail 5) — [고쳐서 다시 올리기]·[취소]·새 값·위치가 화면 밖으로 밀리지 않게 */
  table:is(.mine,.cmp),table:is(.mine,.cmp) tbody,table:is(.mine,.cmp) tr,table:is(.mine,.cmp) td{display:block;width:auto;min-width:0}
  table:is(.mine,.cmp) thead{display:none}
  table:is(.mine,.cmp) tr{border:1px solid var(--border);border-radius:10px;padding:8px 12px;margin:0 0 8px;background:var(--panel)}
  table:is(.mine,.cmp) td{border:0;padding:3px 0;min-width:0 !important;max-width:none !important;white-space:normal;
    overflow-wrap:anywhere}
  table:is(.mine,.cmp) td::before{color:var(--muted);font-size:12px}
  table.mine td:nth-child(1)::before{content:"번호 · "}
  table.mine td:nth-child(3)::before{content:"파일 · "}
  table.mine td:nth-child(4)::before{content:"설명 · "}
  table.mine td:nth-child(5)::before{content:"올린 때 · "}
  table.cmp td:nth-child(3)::before{content:"이전 · "}
  table.cmp td:nth-child(4)::before{content:"새 값 · "}
  table.cmp td:nth-child(5)::before{content:"위치 · "}
  table:is(.mine,.cmp) td:empty{display:none}
  table.mine td.acts .btn{min-height:40px;padding:9px 14px}
  .cap figure{flex:1 1 100%;min-width:0;max-width:100%}
  .cap img{max-width:100%}
  /* 양식 목록 — 폴더·올린 사람 열은 숨기고 폴더는 이름 아래 작은 글로 (ux21 forms 2) */
  table.flist .nh{display:none}
  table.flist .nshow{display:block}
  /* 손가락 표적 (ux21 forms 7) — 폴더 나무·작은 단추·메뉴를 40px 안팎으로, 붙은 링크 사이를 띄운다 */
  .tree a{min-height:40px;padding:10px 8px}
  .btn.sm{min-height:40px;padding:9px 12px}
  .nav a{min-height:40px}
  .chips a{padding:9px 14px}
  .cands li,.note .gap{line-height:1.6}
  .cands li{margin:8px 0}
  .gap{display:inline-block;margin:6px 0 6px 10px;padding:6px 2px}
  .curdl.narrow{display:flex;flex-direction:column;gap:4px;margin:4px 0 14px}
  .curdl .btn.big{display:block;text-align:center;padding:12px 14px;font-size:16px}
}
"""


# 메뉴 아이콘 한 글자 + 영문 이름 (ux21 forms 6) — 주소 → (아이콘, 영문)
NAV_HINTS = {
    "/forms": ("📁", "Forms"), "/upload": ("⬆", "Upload"), "/mine": ("📝", "My uploads"),
    "/check": ("✔", "Check version"), "/review": ("👀", "Review"), "/register": ("📋", "Register"),
    "/changes": ("🔔", "Changes"), "/admin/users": ("👤", "Accounts"), "/admin/folders": ("🗂", "Folders"),
    "/admin/docno": ("№", "Doc numbers"), "/admin/audit": ("🕘", "Audit log"), "/admin/advanced": ("⚙", "Advanced"),
}


def _fmt_time(value) -> str:
    """'2026-10-28T14:03:22' → '2026-10-28 14:03'."""
    s = str(value or "")
    return " ".join(s.split("T", 1))[:16] if s else ""     # str.replace는 test_readonly 이름 검사에 걸린다


def _fmt_size(n) -> str:
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f}KB"
    if n < 1024 ** 3:
        return f"{n / (1024 * 1024):.1f}MB"
    if n < 1024 ** 4:                                  # 남은 공간 등 — '1112196.3MB'로 그리던 것 (2026-10-31 실사용 검토)
        return f"{n / 1024 ** 3:.1f}GB"
    return f"{n / 1024 ** 4:.1f}TB"


def _flatten(tree, depth: int = 0, prefix: tuple = ()):
    """폴더 트리 → (폴더, 깊이, '맨위 / 하위' 경로) 차례."""
    for node in tree:
        path = prefix + (node["name"] + (" [기밀]" if node.get("restricted") else ""),)   # 같은 이름 두 줄 구분 (재검토 4)
        yield node, depth, " / ".join(path)
        yield from _flatten(node["children"], depth + 1, path)


def content_disposition(filename: str, fallback_name: str | None = None) -> str:
    """내려받기 이름 — 한글은 filename*=UTF-8''…, 옛 브라우저용 ASCII 대체 이름도 함께.
    fallback_name: ASCII 대체 이름을 따로 줄 때(지난 판·폐기 표시를 '[old-v1] '처럼 — 한글 표시가 '_'로 뭉개지지 않게)."""
    src = filename if fallback_name is None else fallback_name
    fallback = "".join(c if 32 <= ord(c) < 127 and c not in '"\\;%' else "_" for c in src) or "download"
    return f"attachment; filename=\"{fallback}\"; filename*=UTF-8''{quote(filename, safe='')}"


def _safe_back(to: str) -> str:
    """돌아갈 곳은 이 서버 안의 경로만 — 다른 사이트로 보내지 않는다 (web._safe_back 과 같은 규칙)."""
    to = "".join(ch for ch in (to or "") if ch >= " " and ch != "\x7f").strip()
    if not to.startswith("/") or to.startswith("//") or to.startswith("/\\"):
        return "/forms"
    return to


_NEXT_SKIP = frozenset({"/login", "/logout", "/setup", "/", "/forms"})


def _safe_next(to) -> str:
    """로그인 뒤 돌아갈 곳(?next=) — 이 서버의 GET 화면 경로만, 아니면 '' (ux20 mail 1). 열린 리다이렉트를 막으려고
    _safe_back보다 좁다: 제어 문자·공백·백슬래시가 하나라도 있으면(브라우저가 '/\\t/x'를 '//x'로 읽는다) 고치지 않고 버린다.
    '/'로 시작하고 '//'로 시작하지 않으며, 스킴·호스트가 없고, 경로가 알려진 화면(/changes/<번호> 포함)이어야 한다."""
    s = str(to or "")
    if not s or len(s) > 600 or not s.startswith("/") or s.startswith("//"):
        return ""
    if any(ch <= " " or ch == "\x7f" or ch == "\\" for ch in s):
        return ""
    try:
        sp = urlsplit(s)
    except ValueError:
        return ""
    if sp.scheme or sp.netloc or sp.fragment:
        return ""
    path = sp.path
    if path in _NEXT_SKIP:
        return ""
    # 메일이 가리키는 사내망 변경 화면만(/changes·/changes/<번호>·/changes/issues) — 양식함 화면은 지금처럼 /forms로 간다
    from watcher.forms import changes as _chg
    if not (_chg.CHANGE_PATH.fullmatch(path) or (path in _GET and (path == "/changes" or path.startswith("/changes/")))):
        return ""
    return s


def _location(to: str) -> str:
    """Location 머리글 값 — _safe_back을 거친 뒤 ASCII 밖 글자(한글 등)·공백·따옴표를 퍼센트 인코딩한다.
    http.server는 머리글을 latin-1로 쓰므로 `back=/forms?q=한글`이 UnicodeEncodeError로 응답을 깨뜨리던 것 (검토20 r05-2).
    이미 있는 %xx는 그대로 둔다."""
    return quote(_safe_back(to), safe="/?&=%#:+,;@!$'()*[]~-._")


def _is_loopback(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(str(ip).split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped is not None:
        a = a.ipv4_mapped
    return a.is_loopback


def _is_internet(ip: str) -> bool:
    """공인(인터넷) 주소인가 — 사내망 전용 서버라 그런 곳에서 온 요청은 받지 않는다 (원칙 1)."""
    try:
        a = ipaddress.ip_address(str(ip).split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped is not None:
        a = a.ipv4_mapped
    return a.is_global


def check_bind_host(host: str) -> str:
    """바인드 주소 검사 — IP 글자(또는 localhost)만, 공인 주소는 거부한다 (사내망 전용, 공유기 포트 개방 금지)."""
    h = str(host or "").strip()
    if h.lower() == "localhost":
        return "127.0.0.1"
    try:
        a = ipaddress.ip_address(h)
    except ValueError:
        raise FormsError("양식함 주소는 사내망 IP로 적어 주세요 (예: 192.168.0.10, 모두: 0.0.0.0)")
    if a.is_global:
        raise FormsError("인터넷(공인) 주소에는 양식함을 열 수 없습니다 — 사내망 주소를 적어 주세요")
    return h


# ── 올리기 본문(multipart/form-data) — cgi 모듈 없이 직접 읽는다 ───────────────────────

_BOUNDARY_RE = re.compile(r"^[0-9A-Za-z'()+_,\-./:=? ]{1,70}$")


def _header_params(value: str) -> tuple[str, dict]:
    """'form-data; name="a"; filename="b.xlsx"' → ('form-data', {'name': 'a', 'filename': 'b.xlsx'}).

    브라우저(HTML 표준)는 따옴표 안의 '"'·줄바꿈을 %22·%0A로 바꿔 보내고 역슬래시는 그대로 둔다 —
    그래서 따옴표 안은 다음 따옴표까지 글자 그대로 읽는다(옛 IE의 'C:\\a\\b.xlsx'도 그대로)."""
    s, i, n = value, 0, len(value)
    j = s.find(";")
    main = (s if j < 0 else s[:j]).strip().lower()
    i = n if j < 0 else j + 1
    params: dict = {}
    while i < n:
        while i < n and s[i] in " \t;":
            i += 1
        if i >= n:
            break
        eq = s.find("=", i)
        if eq < 0:
            raise MultipartError("머리글 값이 깨졌습니다")
        key = s[i:eq].strip().lower()
        i = eq + 1
        while i < n and s[i] in " \t":
            i += 1
        if i < n and s[i] == '"':
            end = s.find('"', i + 1)
            if end < 0:
                raise MultipartError("따옴표가 닫히지 않았습니다")
            val, i = s[i + 1:end], end + 1
        else:
            end = s.find(";", i)
            end = n if end < 0 else end
            val, i = s[i:end].strip(), end
        if not key or key in params:
            raise MultipartError("머리글 값이 겹치거나 비었습니다")
        params[key] = val
    return main, params


def _rfc5987(value: str) -> str:
    """filename*=UTF-8''%EC%9E%94… 풀기. UTF-8이 아닌 바이트(%FF·%ED%A0%80)는 MultipartError(→ 400) — 500이던 것 (검토20 r05-1)."""
    from urllib.parse import unquote
    charset, _, rest = value.partition("'")
    _lang, _, enc = rest.partition("'")
    if charset.strip().lower() not in ("utf-8", "utf8") or not _:
        raise MultipartError("파일 이름 인코딩을 모릅니다")
    try:
        return unquote(enc, encoding="utf-8", errors="strict")
    except UnicodeDecodeError:
        raise MultipartError("파일 이름 글자가 깨졌습니다")


def boundary_of(content_type: str) -> bytes:
    main, params = _header_params(str(content_type or ""))
    if main != "multipart/form-data":
        raise MultipartError("올리기 형식(multipart/form-data)이 아닙니다")
    b = params.get("boundary", "")
    if not _BOUNDARY_RE.match(b) or b.endswith(" "):
        raise MultipartError("경계 표시(boundary)가 잘못됐습니다")
    return b.encode("ascii")


def _multipart_pieces(body, delim: bytes, limit: int | None = None):
    """본문에서 경계로 나뉜 조각의 (시작, 끝) 위치 — 본문 앞에 줄바꿈을 붙여 복사하거나 split으로 통째 나누지 않고
    위치만 찾는다(50MB 올리기가 메모리에 두세 벌 겹치던 것, 2026-10-30). 첫 조각(경계 앞 머리말)은 뺀다.
    limit: 조각을 이만큼 찾으면 멈춘다(마지막 조각은 다음 경계 앞까지) — 짧은 경계로 가득 찬 본문이 조각 목록을 수백만 개
    만들어 메모리를 1.5GB 쓰던 것 (검토20 r06-1). 부르는 쪽이 칸 수 상한 + 1을 준다."""
    sep = b"\r\n" + delim
    if bytes(body[:len(delim)]) == delim:
        pos = len(delim)
    else:
        i = body.find(sep)
        if i < 0:
            return None
        pos = i + len(sep)
    out = []
    while True:
        j = body.find(sep, pos)
        out.append((pos, len(body) if j < 0 else j))
        if j < 0 or (limit is not None and len(out) >= limit):
            return out
        pos = j + len(sep)


def parse_multipart(body, boundary: bytes, *, max_parts: int = 20,
                    max_field: int = MAX_FORM_BODY) -> tuple[dict, dict]:
    """multipart/form-data 본문 → (글자 칸 {이름: [값…]}, 파일 칸 {이름: (파일 이름, 바이트)}).

    깨진 본문은 MultipartError(→ 400). 끝 표시(--경계--)가 없으면 덜 온 것으로 본다.
    body: bytes·bytearray — 조각은 위치로 찾고 파일 내용만 한 번 bytes로 떼어 낸다."""
    delim = b"--" + boundary
    spans = _multipart_pieces(body, delim, limit=max_parts + 1)     # 상한 + 1(끝 표시)까지만 찾는다 (검토20 r06-1)
    if spans is None:
        raise MultipartError("경계 표시가 본문에 없습니다")
    fields: dict = {}
    files: dict = {}
    closed = False
    for count, (start, end) in enumerate(spans, start=1):
        if bytes(body[start:start + 2]) == b"--":
            closed = True
            break
        if count > max_parts:
            raise MultipartError("칸이 너무 많습니다")
        while start < end and body[start] in (0x20, 0x09):
            start += 1
        if bytes(body[start:start + 2]) != b"\r\n":
            raise MultipartError("경계 뒤 줄바꿈이 없습니다")
        start += 2
        hend = body.find(b"\r\n\r\n", start, end)
        if hend < 0:
            raise MultipartError("칸 머리글이 끝나지 않았습니다")
        head = bytes(body[start:hend])
        with memoryview(body) as mv:                    # 파일 내용은 한 번만 복사 (bytearray 조각 + bytes 두 벌이 아니게)
            content = bytes(mv[hend + 4:end])
        if len(head) > 8192:
            raise MultipartError("칸 머리글이 너무 깁니다")
        try:
            head_text = head.decode("utf-8")
        except UnicodeDecodeError:
            raise MultipartError("칸 머리글 글자가 깨졌습니다")
        disp = None
        for line in head_text.split("\r\n"):
            name, colon, value = line.partition(":")
            if not colon:
                raise MultipartError("칸 머리글 줄이 깨졌습니다")
            if name.strip().lower() == "content-disposition":
                if disp is not None:
                    raise MultipartError("칸 머리글이 겹칩니다")
                disp = value.strip()
        if disp is None:
            raise MultipartError("칸 이름(Content-Disposition)이 없습니다")
        kind, params = _header_params(disp)
        if kind != "form-data" or not params.get("name"):
            raise MultipartError("칸 이름이 없습니다")
        fname = params["name"]
        if "filename*" in params:
            filename = _rfc5987(params["filename*"])
        else:
            filename = params.get("filename")
        if filename is not None:
            if fname in files:
                raise MultipartError("파일 칸이 겹칩니다")
            files[fname] = (filename, content)
        else:
            if len(content) > max_field:
                raise MultipartError("글자 칸이 너무 깁니다")
            try:
                fields.setdefault(fname, []).append(content.decode("utf-8"))
            except UnicodeDecodeError:
                raise MultipartError("글자 칸이 깨졌습니다")
    if not closed:
        raise MultipartError("본문 끝 표시가 없습니다 — 덜 왔거나 깨졌습니다")
    return fields, files


# ── 단일 실행 잠금 (파일을 쓰지 않는 Windows 이름 있는 뮤텍스) ─────────────────────────

class InstanceLock:
    """같은 데이터 폴더로 서버가 두 번 뜨지 않게 — 커널 뮤텍스라 프로세스가 죽으면 저절로 풀린다."""

    def __init__(self, data_dir):
        key = os.path.normcase(os.path.abspath(str(data_dir)))
        self.name = "Local\\DrevForms-" + hashlib.sha256(key.encode("utf-8")).hexdigest()[:24]
        self._handle = None

    def acquire(self) -> bool:
        if os.name != "nt":           # Drev는 Windows 전용 — 다른 곳에서는 포트 독점에 맡긴다
            return True
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
        k32.CreateMutexW.restype = wintypes.HANDLE
        k32.CloseHandle.argtypes = (wintypes.HANDLE,)
        h = k32.CreateMutexW(None, False, self.name)
        err = ctypes.get_last_error()
        if not h:
            raise OSError(err, "단일 실행 잠금을 만들 수 없습니다")
        if err == 183:                # ERROR_ALREADY_EXISTS
            k32.CloseHandle(h)
            return False
        self._handle = h
        return True

    def release(self) -> None:
        if self._handle:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.CloseHandle.argtypes = (wintypes.HANDLE,)
            k32.CloseHandle(self._handle)
            self._handle = None


# ── 서버 ────────────────────────────────────────────────────────────────────

class RateLimiter:
    """주소(IP)별 토큰 버킷 — 메모리만 쓴다(DB에 아무것도 적지 않는다). 2026-10-28 보안 F1.

    capacity번까지는 한꺼번에 받고, 그 뒤로는 초당 per_second번씩 다시 채워진다. 열쇠(주소)가 너무 많으면
    가득 찬(=한동안 조용한) 것부터 버려 메모리도 끝없이 늘지 않는다. clock: 시험에서 바꿔 끼운다."""

    def __init__(self, capacity: int = RATE_CAPACITY, per_second: float = RATE_PER_SECOND, *, clock=time.monotonic,
                 max_keys: int = 10000):
        self.capacity = float(max(1, int(capacity)))
        self.per_second = max(0.001, float(per_second))
        self.clock = clock
        self.max_keys = int(max_keys)
        self._b: dict = {}
        self._lock = threading.Lock()

    def take(self, key: str) -> float:
        """한 번 쓰기. 받으면 0, 넘쳤으면 다음 한 번까지 기다릴 초."""
        now = float(self.clock())
        with self._lock:
            tokens, at = self._b.get(key, (self.capacity, now))
            tokens = min(self.capacity, tokens + max(0.0, now - at) * self.per_second)
            if tokens >= 1.0:
                self._b[key] = (tokens - 1.0, now)
                if len(self._b) > self.max_keys:
                    self._prune(now)
                return 0.0
            self._b[key] = (tokens, now)
            return (1.0 - tokens) / self.per_second

    def _prune(self, now: float) -> None:
        full = [k for k, (t, at) in self._b.items()
                if t + max(0.0, now - at) * self.per_second >= self.capacity]
        for k in full:
            self._b.pop(k, None)
        if len(self._b) > self.max_keys:                 # 그래도 많으면 가장 오래 조용한 것부터
            for k, _ in sorted(self._b.items(), key=lambda kv: kv[1][1])[:len(self._b) - self.max_keys]:
                self._b.pop(k, None)

    def prune(self) -> None:
        with self._lock:
            self._prune(float(self.clock()))


class FormsHTTPServer(ThreadingHTTPServer):
    """요청마다 스레드. 저장소(FormsStore) 하나를 스레드끼리 같이 쓴다(F1이 잠금으로 보장).

    - 포트 독점(SO_EXCLUSIVEADDRUSE): 윈도우는 SO_REUSEADDR이면 두 프로세스가 같은 포트를 나눠 잡는다(web.py 2026-08-31).
    - 동시 연결 상한: 넘치면 바로 503으로 끊는다.
    - 느린 요청 끊기: 감시 스레드가 마감이 지난 연결을 shutdown 한다(헤더를 한 글자씩 보내며 버티기 방지)."""

    daemon_threads = True
    block_on_close = False
    allow_reuse_address = False
    request_queue_size = 32

    def __init__(self, address, handler, store: FormsStore, *, max_connections: int = MAX_CONNECTIONS):
        self.store = store
        self.comparer: Comparer | None = None        # 자동 비교기 (F3) — make_server가 붙인다
        self.mirror: Mirror | None = None            # 현행 미러 (F4, 설정했을 때만)
        self.mirror_problem = ""                     # 미러를 켜지 않은 까닭 — 감시 폴더 안 (검토20 r04-1, 관리자 띠)
        self.notifier: Notifier | None = None        # 메일 알림 (F4, 켰을 때만)
        self.backup = None                           # 백업기 (2026-10-30, backup.attach — 켰을 때만)
        self.weekly = None                           # 주간 알림 (2026-10-30, weekly — 요일·SMTP가 있을 때만)
        self.watch_log = None                           # 감시 기록(state.db) — 사내망 변경 확인 (갈래 N, 경로를 줬을 때만)
        self.header_seconds = HEADER_SECONDS
        self.body_min_rate = BODY_MIN_RATE
        self._slots = threading.BoundedSemaphore(max_connections)
        self._conns: dict = {}
        self._conns_lock = threading.Lock()
        self._flash: dict = {}
        self._flash_lock = threading.Lock()
        self._stop = threading.Event()
        self.limiter = RateLimiter(clock=store.clock)     # 비인증 POST(로그인·첫 관리자) 주소별 상한 (보안 F1)
        self.pending_keep_days = float(PENDING_KEEP_DAYS)  # 반려·취소 대기 파일 보존 기간 (보안 F7)
        self.upload_slots = threading.BoundedSemaphore(UPLOAD_PARALLEL)   # 올리기 본문 동시 상한 (2026-10-30)
        self.upload_wait = UPLOAD_WAIT_SECONDS                              # 자리 기다림 상한(초)
        self.upload_min_rate = UPLOAD_MIN_RATE                              # 올리기 본문 최소 속도
        self.upload_floor = UPLOAD_FLOOR_SECONDS
        self._uploading: set = set()                                        # 지금 올리는 중인 계정 — 계정마다 한 번에 하나
        self._uploading_cond = threading.Condition()
        self._drafts: dict = {}                                             # 실패한 입력 되살리기 (세션별, 한 번)
        self._drafts_lock = threading.Lock()
        self._maint: threading.Thread | None = None
        self._stash: dict = {}                                              # 올리기 확인 대기 — [그래도 올리기] (F2-1)
        self._stash_lock = threading.Lock()
        self._notify_tick_at = 0.0                                          # 묶음 알림 확인 (F2-14) — 요청마다 아니라 1분에 한 번
        super().__init__(address, handler)
        self._reaper = threading.Thread(target=self._reap, name="forms-reaper", daemon=True)
        self._reaper.start()

    # 정리 일 (2026-10-28 보안 F1·F7) — 대기 파일 보존 기간 지난 것, 지난 로그인 실패 행, 버킷 메모리
    def maintain(self) -> dict:
        out = {"purged": [], "failures": 0, "orphans": []}
        try:
            out["purged"] = self.store.purge_pending(days=self.pending_keep_days)
        except Exception:
            log.exception("양식함: 대기 파일 정리 실패")
        try:                                            # 승인 때 잠겨 못 지운 대기 파일 (2026-10-30)
            out["orphans"] = self.store.sweep_pending_orphans()
        except Exception:
            log.exception("양식함: 남은 대기 파일 정리 실패")
        try:
            out["failures"] = auth.cleanup_failures(self.store)
        except Exception:
            log.exception("양식함: 로그인 실패 기록 정리 실패")
        self.limiter.prune()
        out["batch"] = self.notify_tick()                 # 하루 한 번 묶어 보내는 알림 (F2-14)
        for key, part in (("backup", self.backup), ("weekly", self.weekly)):     # 하루 한 번 백업·주 한 번 알림 (2026-10-30)
            if part is not None:
                try:
                    out[key] = part.tick()
                except Exception:
                    log.exception("양식함: %s 실패", "백업" if key == "backup" else "주간 알림")
        return out

    def start_maintenance(self, interval: float = MAINT_SECONDS) -> None:
        if self._maint is not None:
            return

        def loop():
            while True:
                self.maintain()
                if self._stop.wait(float(interval)):
                    return
        self._maint = threading.Thread(target=loop, name="forms-maint", daemon=True)
        self._maint.start()

    def server_bind(self) -> None:
        if os.name == "nt":
            try:
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            except (OSError, AttributeError):
                pass
        super().server_bind()

    # 연결 상한
    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            try:
                request.sendall(_BUSY)
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    # 느린 요청 끊기
    def watch(self, key, sock, seconds: float) -> None:
        with self._conns_lock:
            self._conns[key] = (sock, time.monotonic() + seconds)

    def unwatch(self, key) -> None:
        with self._conns_lock:
            self._conns.pop(key, None)

    def _reap(self) -> None:
        while not self._stop.wait(0.25):
            now = time.monotonic()
            with self._conns_lock:
                late = [(k, s) for k, (s, dl) in self._conns.items() if dl < now]
                for k, _ in late:
                    self._conns.pop(k, None)
            for _, s in late:
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

    # 한 번 보이는 알림 (로그인 세션별)
    def flash_set(self, token: str, kind: str, msg: str) -> None:
        with self._flash_lock:
            if len(self._flash) > 2000:
                self._flash.clear()
            self._flash[hashlib.sha256(token.encode()).hexdigest()] = (kind, msg)

    def flash_pop(self, token: str):
        with self._flash_lock:
            return self._flash.pop(hashlib.sha256(token.encode()).hexdigest(), None)

    # 실패한 입력 되살리기 (2026-10-30 검토) — 올리기·계정 등록이 막히면 적은 글자를 메모리에 두었다가 다음 화면 한 번에 채운다
    def draft_set(self, token: str, key: str, values: dict) -> None:
        with self._drafts_lock:
            if len(self._drafts) > 2000:
                self._drafts.clear()
            self._drafts[(hashlib.sha256(token.encode()).hexdigest(), key)] = {
                str(k): str(v)[:1000] for k, v in values.items() if v is not None}

    def draft_pop(self, token: str, key: str) -> dict:
        with self._drafts_lock:
            return self._drafts.pop((hashlib.sha256(token.encode()).hexdigest(), key), None) or {}

    def upload_begin(self, user_id) -> str:
        """올리기 자리 잡기 — ''(잡음) 또는 거절 까닭. 계정마다 한 번에 하나(느린 본문 몇 개로 모두의 자리를 쥐지 못하게 — 같은 계정의
        두 번째는 앞 것이 끝나기를 upload_wait초까지 기다림), 그다음 전체 자리도 upload_wait초까지 기다린다. 잡았으면 반드시 upload_end."""
        wait = max(0.0, float(self.upload_wait))
        deadline = time.monotonic() + wait
        with self._uploading_cond:
            while user_id in self._uploading:
                left = deadline - time.monotonic()
                if left <= 0:
                    return "이 계정으로 올리는 중인 파일이 있습니다 — 그 올리기가 끝난 뒤 다시 해 주세요"
                self._uploading_cond.wait(left)
            self._uploading.add(user_id)
        if not self.upload_slots.acquire(timeout=wait):
            with self._uploading_cond:
                self._uploading.discard(user_id)
                self._uploading_cond.notify_all()
            return "올리기가 몰려 있습니다 — 잠시 뒤 다시 해 주세요"
        return ""

    # [그래도 올리기] 대기 (F2-1) — 같은 폴더에 같은 이름·내용의 내 검토 대기가 있으면 파일을 메모리에 잠깐 두고 묻는다.
    # 사용자마다 하나(새로 두면 그 사용자의 앞 것을 바꾼다), 전체 STASH_BYTES·STASH_SECONDS초까지(디스크에 쓰지 않는다).
    # 남의 보관을 밀어내지 않는다 — 전에는 전체 4개를 먼저 둔 순서로 밀어내 한 직원이 세션 여럿으로 남의 보관을 지웠다 (재검토 rr066 lan 3).
    # 열쇠는 둔 세션(토큰)에 묶인다 — 같은 사람 다른 세션도 못 쓴다.
    def upload_stash_put(self, user_id, token: str, payload: dict) -> str:
        """보관하고 열쇠를 돌려준다. 전체 상한을 넘으면 보관하지 않고 ''."""
        key = secrets.token_urlsafe(12)
        now = time.monotonic()
        size = len(payload.get("data") or b"")
        with self._stash_lock:
            for k in [k for k, v in self._stash.items() if now - v[0] > STASH_SECONDS]:
                self._stash.pop(k, None)
            self._stash.pop(user_id, None)                          # 내 앞 보관은 바꾼다
            if sum(v[4] for v in self._stash.values()) + size > STASH_BYTES:
                return ""
            self._stash[user_id] = (now, key, hashlib.sha256(token.encode()).hexdigest(), payload, size)
        return key

    def upload_stash_pop(self, user_id, token: str, key: str):
        with self._stash_lock:
            got = self._stash.get(user_id)
            if got is None or not hmac.compare_digest(str(got[1]), str(key or ""))                     or not hmac.compare_digest(got[2], hashlib.sha256(token.encode()).hexdigest())                     or time.monotonic() - got[0] > STASH_SECONDS:
                return None
            self._stash.pop(user_id, None)
            return got[3]

    def notify_tick(self, *, force: bool = False) -> int:
        """묶음 알림을 보낼 때가 됐으면 보낸다 (F2-14). 실패해도 화면·정리 일은 그대로."""
        n = self.notifier
        if n is None:
            return 0
        try:
            return n.flush_batch(force=force)
        except Exception:
            log.exception("양식함: 묶음 알림 보내기 실패")
            return 0

    def upload_end(self, user_id) -> None:
        self.upload_slots.release()
        with self._uploading_cond:
            self._uploading.discard(user_id)
            self._uploading_cond.notify_all()

    def handle_error(self, request, client_address) -> None:
        exc = sys.exception()
        if isinstance(exc, (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        log.exception("양식함 서버: 요청 처리 중 오류 (%s)", client_address[0] if client_address else "")

    def on_event(self, kind: str, **kw) -> None:
        """승인·반려·폐기·복원·폴더 이름 바꾸기 뒤의 뒷일 — 현행 미러 다시 맞추기, 메일 알림 (F4).
        여기서 무엇이 실패해도 화면 동작(이미 끝난 승인 등)은 그대로다. 실제 쓰기·보내기는 배경 스레드가 한다."""
        try:
            if self.mirror is not None and kind in ("approved", "retired", "restored", "folder_renamed",
                                                     "folder_moved", "folder_deleted", "folder_restricted"):
                self.mirror.request_sync()
        except Exception:
            log.exception("양식함: 현행 미러 요청 실패 (%s)", kind)
        n = self.notifier
        if n is None:
            return
        try:
            if kind == "approved":
                sid = kw["submission_id"]
                n.approved(sid)
                d = self.store.submission_notice(sid) or {}
                # 올린 사람(승인 메일을 따로 받음)과 승인한 검토자 자신(방금 자기가 한 일)에게는 새 현행 판 메일을 보내지 않는다
                approver = self.store.user_email(d["decided_by"]) if d.get("decided_by") is not None else ""
                n.new_current(kw["result"]["version_id"], skip=(d.get("submitter_email"), approver))
            elif kind == "rejected":
                n.rejected(kw["submission_id"])
            elif kind == "checked":                  # 2단계 승인 — 검토 완료 → 승인권자에게 승인 요청
                n.checked(kw["submission_id"])
        except Exception:
            log.exception("양식함: 메일 알림 준비 실패 (%s)", kind)

    def server_close(self) -> None:
        self._stop.set()
        super().server_close()
        if self._maint is not None and self._maint is not threading.current_thread():
            busy = self.backup is not None and self.backup.running()
            self._maint.join(60 if busy else 10)       # 정리 일이 저장소를 쓰는 도중에 닫지 않게 (백업 중이면 60초까지)
        for part in (self.backup, self.weekly, self.mirror, self.notifier):   # 배경 스레드(백업·미러·메일)를 저장소보다 먼저 멈춘다
            if part is not None:
                try:
                    part.close()
                except Exception:
                    pass
        if self.comparer is not None:
            try:
                self.comparer.close()                # 비교 자식 프로세스를 끝낸다
            except Exception:
                pass
        try:
            self.store.close()
        except Exception:
            pass


def make_server(data_dir, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, mirror_root=None,
                max_upload_bytes: int | None = None, clock=None,
                max_connections: int = MAX_CONNECTIONS, compare_timeout: float = COMPARE_TIMEOUT,
                compare_command: list | None = None, notify_mail: dict | None = None,
                base_url: str = "", notify_send=None, audit_max_rows: int | None = None,
                pending_keep_days: float | None = None, rate_capacity: int = RATE_CAPACITY,
                rate_per_second: float = RATE_PER_SECOND, maintenance: bool = True,
                review_months_default: int | None = None, watch_roots=(), watch_db=None,
                watch_recipients=None) -> FormsHTTPServer:
    """양식함 서버를 만든다(아직 돌리지 않음). serve_forever()로 돌린다.

    host: 사내망 주소(공인 주소는 거부). 시험은 127.0.0.1 포트 0.
    max_upload_bytes: 올리기 상한(기본 50MB). clock: 시험용 시계(세션·잠금).
    compare_timeout: 자동 비교 한 번의 상한(초, 기본 60). compare_command: 비교 자식 명령(시험용).
    mirror_root: (F4) 현행 미러 폴더 — 주면 배경 스레드가 곧바로 전체를 맞춘다. 폴더가 지금 없어도(공유가 끊김)
      서버는 뜨고, 미러만 실패를 감사 기록에 남긴 뒤 나중에 다시 맞춘다.
    notify_mail: (F4) 메일 알림을 켤 때 감시의 `mail:` 설정(사내 SMTP). base_url: 메일의 '양식함에서 열기' 주소.
    notify_send: 시험용 보내기 함수.
    audit_max_rows: 감사 기록 보존 상한(행, 기본 20만). pending_keep_days: 반려·취소 대기 파일 보존(일, 기본 90).
    rate_capacity·rate_per_second: 비인증 POST(로그인·첫 관리자) 주소별 토큰 버킷. maintenance: 정리 일 스레드(기본 켬).
    review_months_default: (F7) 정기 검토 기본 주기(개월, 기본 12, 0 = 끔).
    watch_roots: 감시 폴더 목록(또는 그것을 돌려주는 함수) — 미러 폴더가 그 안이면 미러를 끄고 관리자 화면에 알린다
      (서버 시작 때와 동기화마다, 검토20 r04-1).
    watch_db: (갈래 N, 2026-11-02) 감시 기록 state.db 경로 — 주면 사내망 '변경 확인' 화면이 생긴다(FORMS.md 11절). 파일이 지금 없어도
      서버는 뜨고 그 화면만 '열 수 없음'. watch_recipients: {'*': [...], 프로젝트: [...]}(또는 그것을 돌려주는 함수) — 기본 범위 제안용."""
    h = check_bind_host(host)
    kw = {}
    if clock is not None:
        kw["clock"] = clock
    store = FormsStore(data_dir, **kw)
    if max_upload_bytes:
        store.max_upload_bytes = int(max_upload_bytes)
    if audit_max_rows:
        store.audit_max_rows = int(audit_max_rows)
    if review_months_default is not None:
        store.review_months_default = max(0, min(int(review_months_default), REVIEW_MONTHS_MAX))
    try:
        srv = FormsHTTPServer((h, int(port)), FormsHandler, store, max_connections=max_connections)
    except BaseException:
        store.close()
        raise
    srv.limiter = RateLimiter(rate_capacity, rate_per_second, clock=store.clock)
    if pending_keep_days is not None:
        srv.pending_keep_days = float(pending_keep_days)
    if maintenance:
        srv.start_maintenance()
    srv.comparer = Comparer(store, timeout=compare_timeout, command=compare_command)
    if watch_db:
        from watcher.forms.changes import WatchLog
        srv.watch_log = WatchLog(watch_db, watch_recipients)
    if notify_mail is not None:
        srv.notifier = Notifier(store, notify_mail, base_url=base_url, send=notify_send)
        store.on_login_spray = srv.notifier.login_spray          # 여러 주소 로그인 실패 몰림 → 관리자 메일 (검토20 r09-1)
        if srv.notifier.batch_pending():                          # 지난번 서버 종료 때 쌓여 있던 묶음 알림 — 시작할 때 보낸다 (F2-14)
            srv.notify_tick(force=True)
    if mirror_root:
        from watcher.forms.settings import mirror_root_problem
        roots = watch_roots() if callable(watch_roots) else watch_roots
        why = mirror_root_problem(mirror_root, list(roots or ()))
        if why:                                  # 감시 폴더 안 — 미러를 켜지 않는다 (검토20 r04-1)
            log.error("현행 미러: %s", why)
            srv.mirror_problem = why
            try:
                store.record_audit(None, "mirror_fail", str(mirror_root), detail=why[:500], login="(양식함)")
            except Exception:
                log.exception("현행 미러: 감사 기록을 남기지 못했습니다")
        else:
            srv.mirror = Mirror(store, mirror_root, watch_roots=watch_roots, base_url=base_url)
            srv.mirror.start()                   # 서버 시작 때 전체 재동기화 (지난 실패를 따라잡는다)
    return srv


def serve(data_dir, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, mirror_root=None,
          max_upload_bytes: int | None = None, on_ready=None, compare_timeout: float = COMPARE_TIMEOUT,
          notify_mail: dict | None = None, base_url: str = "", audit_max_rows: int | None = None,
          pending_keep_days: float | None = None, review_months_default: int | None = None,
          watch_roots=(), watch_db=None, watch_recipients=None) -> None:
    """단일 실행 잠금을 잡고 서버를 돌린다(멈출 때까지). 이미 돌고 있으면 AlreadyRunning.

    on_ready(server): 바인드 직후 한 번 부른다(주소 알림·시험에서 멈추기용)."""
    lock = InstanceLock(data_dir)
    if not lock.acquire():
        raise AlreadyRunning("양식함이 이미 실행 중입니다")
    try:
        srv = make_server(data_dir, host, port, mirror_root=mirror_root, max_upload_bytes=max_upload_bytes,
                          compare_timeout=compare_timeout, notify_mail=notify_mail, base_url=base_url,
                          audit_max_rows=audit_max_rows, pending_keep_days=pending_keep_days,
                          review_months_default=review_months_default, watch_roots=watch_roots,
                          watch_db=watch_db, watch_recipients=watch_recipients)
        try:
            if on_ready is not None:
                on_ready(srv)
            srv.serve_forever(poll_interval=0.5)
        finally:
            srv.server_close()
    finally:
        lock.release()


# ── 요청 처리 ────────────────────────────────────────────────────────────────

class FormsHandler(BaseHTTPRequestHandler):
    server: FormsHTTPServer
    server_version = "Drev-Forms"
    sys_version = ""
    protocol_version = "HTTP/1.0"     # 요청 하나에 연결 하나 — 마감·상한 관리가 단순하다
    timeout = SOCKET_TIMEOUT

    # ── 연결 수명 ───────────────────────────────────────────────────────
    def setup(self) -> None:
        super().setup()
        self._cookies_out: list = []
        self.sess = None
        self._pre = None
        self.server.watch(id(self), self.connection, self.server.header_seconds)

    def finish(self) -> None:
        self.server.unwatch(id(self))
        try:
            super().finish()
        except OSError:
            pass

    def _deadline(self, nbytes: int = 0) -> None:
        """본문 읽기·응답 보내기 마감 — 30초 + 최소 속도로 나눈 시간."""
        self.server.watch(id(self), self.connection, 30.0 + nbytes / max(1, self.server.body_min_rate))

    def _allow_compare(self) -> None:
        """자동 비교를 기다리는 동안 느린 요청 끊기에 걸리지 않게 마감을 늘린다 — 자리 기다림 + 비교 상한 + 여유 30초."""
        c = self.server.comparer
        t = c.timeout if c is not None else COMPARE_TIMEOUT
        self.server.watch(id(self), self.connection, 2 * t + 30.0)

    def handle_one_request(self) -> None:
        """표준 처리와 같되 요청 줄·헤더 크기 상한을 좁혔다 (8KB·32KB·60개)."""
        try:
            self.raw_requestline = self.rfile.readline(MAX_REQUEST_LINE + 1)
            if len(self.raw_requestline) > MAX_REQUEST_LINE:
                self.requestline, self.request_version, self.command = "", "", ""
                self.send_error(HTTPStatus.REQUEST_URI_TOO_LONG)
                return
            if not self.raw_requestline:
                self.close_connection = True
                return
            if not self.parse_request():
                return
            if len(self.headers) > MAX_HEADERS or \
                    sum(len(k) + len(v) + 4 for k, v in self.headers.items()) > MAX_HEADER_BYTES:
                self.send_error(HTTPStatus.REQUEST_HEADER_FIELDS_TOO_LARGE)
                return
            self._deadline()
            mname = "do_" + self.command
            if not hasattr(self, mname):
                self.send_error(HTTPStatus.NOT_IMPLEMENTED)
                return
            getattr(self, mname)()
            self.wfile.flush()
        except TimeoutError:
            self.close_connection = True
        except (ConnectionError, OSError) as e:      # 감시 스레드가 끊었거나 상대가 나갔다
            log.debug("연결 끊김: %s", e)
            self.close_connection = True

    def log_message(self, fmt, *args) -> None:       # 콘솔 소음 대신 로그(디버그)로
        log.debug("%s %s", self.client_address[0] if self.client_address else "-", fmt % args)

    # ── 응답 ────────────────────────────────────────────────────────────
    def _out(self, data: bytes) -> None:
        """소켓으로 보내기 — 이 모듈에서 write를 부르는 유일한 곳 (파일 쓰기 아님, test_readonly)."""
        self.wfile.write(data)

    def end_headers(self) -> None:
        for k, v in SECURITY_HEADERS:
            self.send_header(k, v)
        for c in self._cookies_out:
            self.send_header("Set-Cookie", c)
        self._cookies_out = []
        super().end_headers()

    def _cookie(self, name: str, value: str, *, max_age: int | None = None) -> None:
        c = f"{name}={value}; Path=/; HttpOnly; SameSite=Strict"
        if max_age is not None:
            c += f"; Max-Age={int(max_age)}"
        self._cookies_out.append(c)

    def _send(self, status: int, body, ctype: str = "text/html; charset=utf-8", extra=()) -> None:
        data = body.encode("utf-8") if isinstance(body, str) else bytes(body)
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self._out(data)

    def _redirect(self, location: str, status: int = 303) -> None:
        self.send_response(status)
        self.send_header("Location", _location(location))
        self.send_header("Content-Length", "0")
        self.end_headers()

    def send_error(self, code, message=None, explain=None) -> None:
        """표준 오류 화면 대신 한국어 쉬운 말 — 내부 설명(explain)은 화면에 내지 않는다."""
        code = int(code)
        self.close_connection = True
        if not hasattr(self, "_cookies_out"):
            self._cookies_out = []
        try:
            phrase = HTTPStatus(code).phrase
        except ValueError:
            phrase = "Error"
        body = _auth_page("오류", f'<div class="note bad">{E(_ERROR_TEXT.get(code, "요청을 처리할 수 없습니다"))}'
                                  f' ({code})</div><p><a href="/forms">양식함으로 가기</a></p>',
                          self._theme_attr_safe()).encode("utf-8")
        self.send_response(code, phrase)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD" and code >= 200 and code not in (204, 304):
            self._out(body)

    # ── 요청 정보 ───────────────────────────────────────────────────────
    def _client_ip(self) -> str:
        ip = str(self.client_address[0]) if self.client_address else ""
        if ip.lower().startswith("::ffff:"):
            ip = ip[7:]
        return ip

    def _cookies_in(self) -> dict:
        try:
            c = SimpleCookie(self.headers.get("Cookie", ""))
        except CookieError:
            return {}
        return {k: m.value for k, m in c.items()}

    def _theme(self) -> str:
        t = self._cookies_in().get(THEME_COOKIE, "") if hasattr(self, "headers") and self.headers else ""
        return t if t in ("light", "dark") else ""

    def _theme_attr_safe(self) -> str:
        try:
            t = self._theme()
        except Exception:
            t = ""
        return f' data-theme="{t}"' if t else ""

    def _query(self) -> dict:
        try:
            return parse_qs(urlsplit(self.path).query, keep_blank_values=True, max_num_fields=40,
                            strict_parsing=False)
        except ValueError:
            raise HttpError(400)

    @staticmethod
    def _one(d: dict, key: str, default: str = "") -> str:
        v = d.get(key)
        return v[0] if v else default

    @staticmethod
    def _int(value, *, required: bool = True):
        s = str(value or "").strip()
        if not s:
            if required:
                raise HttpError(400, "번호가 빠졌습니다")
            return None
        if not (s.isascii() and s.isdigit()) or len(s) > 12:     # '²'·'①'은 isdigit()이 참이라 int()가 깨진다
            raise HttpError(400, "잘못된 번호입니다")
        return int(s)

    def _pre_token(self) -> str:
        """로그인 전 화면의 CSRF 값 — 쿠키와 양식에 같은 값을 둔다(이중 제출). SameSite=Strict라 다른 사이트는 못 보낸다."""
        if self._pre:
            return self._pre
        cur = self._cookies_in().get(PRE_COOKIE, "")
        if re.fullmatch(r"[A-Za-z0-9_\-]{40,64}", cur or ""):
            self._pre = cur
        else:
            self._pre = secrets.token_urlsafe(32)
            self._cookie(PRE_COOKIE, self._pre)
        return self._pre

    def _csrf_value(self) -> str:
        return self.sess.csrf if self.sess is not None else self._pre_token()

    def _check_origin(self) -> None:
        """Origin 머리글이 있으면 같은 주소여야 한다 (SameSite 쿠키에 더한 두 번째 문)."""
        origin = self.headers.get("Origin")
        if origin is None:
            return
        host = self.headers.get("Host", "")
        if origin == "null" or urlsplit(origin).netloc.lower() != host.lower():
            raise HttpError(403, "다른 곳에서 보낸 요청은 받지 않습니다")

    def _check_token(self, fields: dict) -> None:
        supplied = self._one(fields, "csrf")
        if self.sess is not None:
            ok = auth.check_csrf(self.sess, supplied)
        else:
            pre = self._cookies_in().get(PRE_COOKIE, "")
            ok = bool(pre) and bool(supplied) and hmac.compare_digest(pre.encode(), supplied.encode())
        if not ok:
            raise HttpError(403, "확인 값(CSRF)이 맞지 않습니다 — 화면을 새로 열고 다시 해 주세요")

    def _length(self, limit: int) -> int:
        if self.headers.get("Transfer-Encoding"):
            raise HttpError(411)
        raw = self.headers.get("Content-Length")
        if raw is None:
            raise HttpError(411)
        raw = raw.strip()
        if not raw.isdigit() or len(raw) > 15:
            raise HttpError(400, "본문 길이가 잘못됐습니다")
        n = int(raw)
        if n > limit:
            raise HttpError(413, f"보낸 내용이 너무 큽니다 (최대 {limit // (1024 * 1024) or 1}MB)"
                            if limit >= 1024 * 1024 else "보낸 내용이 너무 큽니다")
        return n

    def _discard_small_body(self) -> None:
        """본문을 읽지 않고 답할 때(로그인 안 됨·속도 제한·오류) 작은 본문은 읽어 버린다 — Windows는 안 읽은
        데이터가 남은 소켓을 닫으면 RST를 보내 상대가 답을 받기 전에 끊긴다 (2026-10-29 시험 간헐 실패).
        큰 본문은 여전히 읽지 않고 끊는다(비인증 상대에게 대역을 내주지 않는다)."""
        if self.command != "POST" or getattr(self, "_body_done", True):
            return
        self._body_done = True
        raw = (self.headers.get("Content-Length") or "").strip()
        if not raw.isascii() or not raw.isdigit() or len(raw) > 15 or int(raw) > DISCARD_BODY_MAX:
            return
        try:
            self._read_body(int(raw))
        except (HttpError, ConnectionError, TimeoutError, OSError):
            pass

    def _read_body(self, n: int, *, seconds: float | None = None) -> bytearray:
        """본문 n바이트를 미리 잡은 버퍼 하나에 바로 읽는다 — 조각 목록 + join으로 두 벌 들던 것을 한 벌로 (2026-10-30).
        seconds: 본문 마감(초)을 따로 줄 때 — 올리기는 더 빠듯하게(느린 상대가 올리기 자리를 오래 쥐지 못하게)."""
        self._body_done = True
        end = None
        if seconds is None:
            self._deadline(n)
        else:
            self.server.watch(id(self), self.connection, float(seconds))
            end = time.monotonic() + float(seconds)
        buf = bytearray(n)
        view, got = memoryview(buf), 0
        try:
            while got < n:
                if end is not None:
                    # 마감을 이 스레드가 직접 지킨다 — Windows는 감시 스레드의 shutdown이 막혀 있는 recv를 깨우지 않아
                    # 멈춘 상대가 자리를 소켓 시간 상한(20초)만큼 더 쥐었다 (2026-10-30 검토)
                    left = end - time.monotonic()
                    if left <= 0:
                        raise HttpError(408, "올리는 속도가 너무 느려 끊었습니다 — 네트워크를 확인하고 다시 해 주세요")
                    self.connection.settimeout(min(float(SOCKET_TIMEOUT), left))
                k = self.rfile.readinto(view[got:min(n, got + 256 * 1024)])
                if not k:
                    raise HttpError(400, "본문이 덜 왔습니다")
                got += k
        finally:
            view.release()
            if end is not None:
                try:
                    self.connection.settimeout(SOCKET_TIMEOUT)
                except OSError:
                    pass
        self._deadline()
        return buf

    def _read_form(self) -> dict:
        ctype = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        n = self._length(MAX_FORM_BODY)
        if ctype != "application/x-www-form-urlencoded":
            raise HttpError(415)
        body = self._read_body(n)
        try:
            text = body.decode("utf-8")
            return parse_qs(text, keep_blank_values=True, max_num_fields=500)
        except (UnicodeDecodeError, ValueError):
            raise HttpError(400)

    # ── 진입 ────────────────────────────────────────────────────────────
    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def _dispatch(self, method: str) -> None:
        self._body_done = False
        try:
            self.ip = self._client_ip()
            if _is_internet(self.ip):
                raise HttpError(403, "양식함은 사내망에서만 열립니다")
            path = urlsplit(self.path).path or "/"
            if path == "/forms.css" and method == "GET":
                self._send(200, CSS, "text/css; charset=utf-8")
                return
            m_chg = _changes.CHANGE_PATH.fullmatch(path)      # /changes/<번호> — 사내망 변경 상세 (갈래 N)
            if m_chg:
                path, self.path_change_id = "/changes/item", m_chg.group(1)
            routes = _GET if method == "GET" else _POST
            entry = routes.get(path)
            if entry is None:
                other = _POST if method == "GET" else _GET
                raise HttpError(405 if path in other else 404)
            fn, public = entry
            store = self.server.store
            token = self._cookies_in().get(SESSION_COOKIE, "")
            self.sess = auth.get_session(store, token) if token else None
            if not public:
                if self.sess is None:
                    self.close_connection = True       # 큰 본문은 읽지 않고 끊는다
                    self._discard_small_body()
                    # 메일 링크(/changes/146)로 왔으면 로그인 뒤 그 화면으로 — 늘 /forms로 떨어졌다 (ux20 mail 1). GET만
                    _nx = _safe_next(self.path) if method == "GET" else ""
                    self._redirect("/login" + (f"?next={quote(_nx, safe='')}" if _nx else ""))
                    return
                if self.sess.must_change and path not in _MUST_CHANGE_OK:
                    if method == "POST":
                        raise HttpError(403, "먼저 비밀번호를 바꿔 주세요")
                    self._redirect("/password")
                    return
            if method == "POST":
                self._check_origin()
            srv = self.server
            if srv.notifier is not None and time.monotonic() - srv._notify_tick_at > 60:   # 묶음 알림 (F2-14) — 그 시각 뒤 첫 요청
                srv._notify_tick_at = time.monotonic()
                srv.notify_tick()
            fn(self)
        except HttpError as e:
            if e.status == 403:
                self._audit_forbidden(method, e.message)
            self._fail(e.status, e.message)
        except auth.LoginLocked as e:
            self._fail(429, auth.locked_text(e.seconds, e.kind))
        except (PermissionDenied,) as e:
            self._audit_forbidden(method, str(e))
            self._fail(403, str(e))
        except Purged as e:                              # 보존 기간이 지나 정리한 판 (2026-10-30)
            self._fail(410, str(e))
        except NotFound as e:
            self._fail(404, str(e))
        except Conflict as e:
            self._fail(409, str(e))
        except NoSpace as e:                             # 디스크 여유 부족 — 500 대신 쉬운 말 (2026-10-30)
            log.warning("양식함: 저장 공간 부족 — %s %s", method, urlsplit(self.path).path)
            self._fail(507, str(e))
        except (InvalidInput, auth.LoginFailed, FormsError) as e:
            self._fail(400, str(e))
        except GuardError:                              # 보관소 쓰기 문이 거부 — 경로·이름 문제 (2026-10-30)
            log.warning("양식함: 보관소 쓰기 거부 — %s %s", method, urlsplit(self.path).path, exc_info=True)
            self._fail(400, "파일을 저장하지 못했습니다 — 파일 이름을 짧고 평범하게 바꿔 다시 해 보고, 계속되면 관리자에게 알려 주세요")
        except (ConnectionError, TimeoutError):
            self.close_connection = True
        except Exception:
            log.exception("양식함 화면 오류: %s %s", method, urlsplit(self.path).path)
            self._fail(500, "문제가 생겼습니다 — 잠시 뒤 다시 해 보고, 계속되면 관리자에게 알려 주세요")

    def _audit_forbidden(self, method: str, why: str) -> None:
        """거부(403 — 권한·CSRF·Origin) 기록 — 같은 주소·같은 사람은 1분씩 한 줄로 묶고 거부된 주소(경로)를 모은다 (2026-10-30 L4).
        기록이 실패해도 화면은 그대로 거부를 보인다."""
        try:
            path = urlsplit(self.path).path[:120]
            s = self.sess
            # 까닭마다 따로 묶는다 — 확인 값(CSRF)·다른 곳에서 온 요청(Origin)·권한 없음이 한 줄이 되지 않게 (2026-10-30 검토)
            if "CSRF" in why:
                action, what = "forbidden_csrf", "거부 — 확인 값(CSRF) 틀림"
            elif "다른 곳에서" in why:
                action, what = "forbidden_origin", "거부 — 다른 곳에서 보낸 요청(Origin)"
            else:
                action, what = "forbidden", "거부 — 권한 없음"
            self.server.store.audit_grouped(
                action, ip=getattr(self, "ip", ""), user_id=s.user_id if s is not None else None,
                login=s.login if s is not None else "", target=f"{method} {path}", what=what,
                item=f"{method} {path}", item_label="거부된 주소")
        except Exception:
            log.exception("양식함: 거부 기록 실패")

    def _fail(self, status: int, message: str) -> None:
        self.close_connection = True
        if status not in (411, 413):                   # 길이 없음·너무 큼은 읽지 않는다
            self._discard_small_body()
        body = f'<div class="note bad" role="alert">{E(message)}</div>' \
               f'<p><a class="btn gray" href="/forms">양식함으로</a></p>'
        try:
            if self.sess is not None and not self.sess.must_change:
                page = self._shell("할 수 없습니다", body, active="")
            else:
                page = _auth_page("할 수 없습니다", body, self._theme_attr_safe())
        except Exception:
            log.exception("오류 화면을 그리다 또 오류")
            page = _auth_page("오류", f'<div class="note bad">{E(message)}</div>', "")
        try:
            self._send(status, page)
        except OSError:
            pass

    # ── 화면 틀 ─────────────────────────────────────────────────────────
    def _shell(self, title: str, body: str, *, active: str, actions: str = "") -> str:
        s = self.sess
        store = self.server.store
        flash = self.server.flash_pop(s.token) if s else None
        note = ""
        if flash:
            kind, msg = flash
            note = f'<div class="note {E(kind)}" role="status">{E(msg)}</div>'
        # 메뉴 숫자는 캐시한 대기 목록 + 권한 모음으로 센다 — 화면마다 제출 목록을 두 번 읽지 않는다 (2026-10-31 성능).
        # 숫자는 참 개수(전에는 500에서 잘림), '검토 대기'는 승인 대기 단계를 빼고 센다 — 주간 알림과 같게, 한 건을 두 번 세지 않게
        counts = store.pending_counts(s.user_id)
        mine = counts["mine"]
        # (주소, 이름, 숫자, 숫자 뜻) — 숫자 뜻은 title로 (2026-10-30: 배지 숫자만으로는 무엇인지 몰랐다)
        items = [("/forms", "양식함", 0, ""), ("/upload", "양식 올리기", 0, ""),
                 ("/mine", "내 제출", mine, f"검토를 기다리는 내 제출 {mine}건"),
                 ("/check", "현행 판 확인", 0, "")]                  # 이 파일이 현행 판인가 (F2-11)
        if s.role in ("reviewer", "admin"):
            review = counts["review"]
            appr = _approval_count(self)                # 2단계 승인 — 내가 승인할 수 있는 승인 대기 (같은 캐시)
            items.append(("/review", "검토 대기", review + appr, f"검토 대기 {review}건"
                          + (f" · 승인 대기 {appr}건" if appr else "")))
            # 문서 관리 대장 (F7) — 숫자는 정기 검토 기한이 지난 양식 수
            over = _due_counts(self)[0]
            items.append(("/register", "문서 관리 대장", over, f"정기 검토 기한 지난 양식 {over}개"))
        chg = _changes.nav_item(self)                   # 사내망 변경 확인 — 열람할 수 있는 계정에게만 (갈래 N)
        if chg:
            items.append(chg)

        def link(href, label, cnt, what=""):
            on = ' class="on" aria-current="page"' if href == active else ""
            badge = f'<span class="cnt" title="{E(what)}">{cnt}</span>' if cnt else ""
            # 아이콘 한 글자 + 영문 이름은 마우스 설명(title)만 (ux21 forms 6) — 메뉴 칸에 영문을 넣으면 216px 사이드바에서 한국어가 글자 중간에서
            # 꺾였다('내 제/출', ux22 forms 3)
            ic, en = NAV_HINTS.get(href, ("", ""))
            tip = " · ".join(x for x in (en, what if cnt else "") if x)
            tip = f' title="{E(tip)}"' if tip else ""
            ic = f' data-ic="{E(ic)}"' if ic else ""            # 아이콘은 CSS ::before — 글자 칸 차례는 그대로
            return f'<a href="{href}"{on}{tip}{ic}><span>{E(label)}</span>{badge}</a>'

        nav = '<div class="grp">양식</div>' + "".join(link(*i) for i in items)
        if s.role == "admin":
            # 문서 종류는 문서번호 규칙 화면 안으로, 백업·보존 만료는 '고급' 한 곳으로 (기능 검토 F2-5, 2026-11-02)
            nav += '<div class="grp">관리</div>' + "".join(link(*i) for i in (
                ("/admin/users", "계정", 0), ("/admin/folders", "폴더 관리", 0), ("/admin/docno", "문서번호 규칙", 0),
                ("/admin/audit", "감사 기록", 0), ("/admin/advanced", "고급", 0)))
        csrf = E(s.csrf)
        theme = self._theme()
        nxt = {"": "dark", "dark": "light", "light": ""}[theme]
        theme_label = {"": "OS 따라감", "dark": "어둡게", "light": "밝게"}[theme]
        nxt_label = {"": "OS 따라감", "dark": "어둡게", "light": "밝게"}[nxt]
        back = E(_safe_back(self.path))
        me = (f'<div class="me"><b>{E(s.display_name)}</b>{E(s.login)} · {E(ROLE_LABEL.get(s.role, s.role))}'
              f'<a href="/password">비밀번호 바꾸기</a>'
              f'<form method="post" action="/theme"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="theme" value="{nxt}"><input type="hidden" name="back" value="{back}">'
              f'<button class="btn gray sm" type="submit" title="누르면 {nxt_label}(으)로 바꿉니다">테마: {theme_label}'
              f'</button></form>'
              f'<form method="post" action="/logout"><input type="hidden" name="csrf" value="{csrf}">'
              f'<button class="btn gray sm" type="submit">로그아웃</button></form></div>')
        return (f'<!DOCTYPE html><html lang="ko"{self._theme_attr_safe()}><head><meta charset="utf-8">'
                f'<meta name="viewport" content="width=device-width, initial-scale=1">'
                f'<title>{E(title)} — Drev 양식함</title><link rel="stylesheet" href="/forms.css"></head><body>'
                f'<a class="skip" href="#main">본문으로 건너뛰기</a>'
                f'<nav class="side" aria-label="메뉴"><div class="logo">Drev 양식함<small>사내망 전용</small></div>'
                f'<div class="nav">{nav}</div>{me}</nav>'
                f'<main class="main" id="main"><div class="topbar"><h1>{E(title)}</h1>{actions}</div>'
                f'{note}{body}</main></body></html>')

    def _flash(self, kind: str, msg: str) -> None:
        if self.sess is not None:
            self.server.flash_set(self.sess.token, kind, msg)

    def _folders(self):
        return list(_flatten(self.server.store.folder_tree(self.sess.user_id)))


def _auth_page(title: str, body: str, theme_attr: str = "", sub: str = "") -> str:
    """로그인 전 화면 틀 (메뉴 없음). sub: 머리 작은 글을 바꿀 때 (메일 링크로 온 변경 확인 등, ux21 mail 7)."""
    return (f'<!DOCTYPE html><html lang="ko"{theme_attr}><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{E(title)} — Drev 양식함</title><link rel="stylesheet" href="/forms.css"></head><body>'
            f'<main class="authwrap" id="main"><div class="logo">Drev 양식함<small>{E(sub or "사내망 전용 · 회사 양식 보관")}'
            f'</small></div>'
            f'<div class="panel"><h2>{E(title)}</h2>{body}</div></main></body></html>')


# ── 화면별 처리 ─────────────────────────────────────────────────────────────

def _hidden(h: FormsHandler) -> str:
    return f'<input type="hidden" name="csrf" value="{E(h._csrf_value())}">'


def _password_rules() -> str:
    return f'<p class="muted">비밀번호는 {auth.MIN_PASSWORD}자 이상, 아이디와 달라야 합니다.</p>'


def get_root(h: FormsHandler) -> None:
    store = h.server.store
    if not auth.has_admin(store):
        h._redirect("/setup")
    elif h.sess is None:
        h._redirect("/login")
    else:
        h._redirect("/forms")


def _login_form(h: FormsHandler, msg: str = "", login: str = "", nxt: str = "") -> str:
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    nxt = _safe_next(nxt)
    lead = ('<p class="muted">로그인하면 요청한 화면(메일의 링크)으로 바로 갑니다.</p>' if nxt else "")
    return (f'{note}{lead}<form method="post" action="/login">{_hidden(h)}'
            + (f'<input type="hidden" name="next" value="{E(nxt)}">' if nxt else "") +
            f'<label for="lg">아이디</label><input type="text" id="lg" name="login" value="{E(login)}" '
            f'autocomplete="username" required maxlength="32" autofocus>'
            f'<label for="pw">비밀번호</label><input type="password" id="pw" name="password" '
            f'autocomplete="current-password" required maxlength="256">'
            f'<div class="form-actions"><button class="btn" type="submit">로그인</button></div></form>'
            f'<p class="muted">계정은 관리자가 등록해 줍니다. 비밀번호를 잊었으면 관리자에게 초기화를 부탁하세요.</p>'
            # 공용 PC — 로그인은 브라우저를 닫거나 8시간 쓰지 않아야 풀린다. 다음 사람 확인이 앞 사람 이름으로 남았다 (ux20 mail 6)
            f'<p class="muted">여러 사람이 함께 쓰는 PC라면 다 본 뒤 꼭 <b>[로그아웃]</b>을 누르세요 — 그대로 두면 다음 사람의 '
            f'[확인함]도 내 이름으로 남습니다.</p>')


def get_login(h: FormsHandler) -> None:
    store = h.server.store
    if not auth.has_admin(store):
        h._redirect("/setup")
        return
    qd = h._query()
    nxt = _safe_next(h._one(qd, "next"))
    if h.sess is not None:
        h._redirect("/password" if h.sess.must_change else (nxt or "/forms"))
        return
    out = ('<div class="note ok" role="status">로그아웃했습니다 — 다음 사람은 자기 계정으로 로그인하세요.</div>'
           if h._one(qd, "out") == "1" else "")
    h._send(200, _auth_page("로그인", out + _login_form(h, nxt=nxt), h._theme_attr_safe(), sub=_login_sub(nxt)))


def _login_sub(nxt: str) -> str:
    """로그인 화면 머리 작은 글 — 메일의 변경 확인 링크로 왔으면 그렇게 (ux21 mail 7)."""
    return "변경 확인 — 메일 링크로 오셨습니다" if str(nxt or "").startswith("/changes") else ""


def _rate_limited(h: FormsHandler, back: str) -> bool:
    """비인증 POST(로그인·첫 관리자)의 주소별 상한 (2026-10-28 보안 F1). 넘쳤으면 429 쉬운 말 화면을 내고 True.
    본문을 읽기 전에, DB에 아무것도 적기 전에 본다 — 넘친 요청은 감사 기록도 남기지 않는다(메모리만)."""
    wait = h.server.limiter.take(h.ip)
    if wait <= 0:
        return False
    secs = max(1, int(wait + 0.999))
    h.close_connection = True
    h._discard_small_body()                      # 안 읽고 닫으면 Windows RST로 429를 못 받는다 (작은 본문만)
    body = (f'<div class="note bad" role="alert">요청이 너무 잦습니다 — {secs}초 뒤에 다시 해 주세요.</div>'
            f'<p class="muted">같은 공유기(사내망 주소)를 쓰는 여러 PC가 한꺼번에 로그인하면 잠깐 이렇게 될 수 있습니다.</p>'
            f'<p><a class="btn gray" href="{E(back)}">돌아가기</a></p>')
    h._send(429, _auth_page("잠시 뒤에 다시", body, h._theme_attr_safe()), extra=(("Retry-After", str(secs)),))
    return True


def post_login(h: FormsHandler) -> None:
    store = h.server.store
    if h.sess is not None:
        # 이미 로그인한 브라우저(다른 탭의 옛 로그인 화면) — 확인 값이 맞지 않아 403을 보이던 것을 그냥 양식함으로 (2026-10-30 L2)
        h._discard_small_body()
        h.close_connection = True
        h._redirect("/password" if h.sess.must_change else "/forms")
        return
    if _rate_limited(h, "/login"):
        return
    f = h._read_form()
    h._check_token(f)
    name, pw = h._one(f, "login").strip(), h._one(f, "password")
    nxt = _safe_next(h._one(f, "next"))          # 로그인 뒤 돌아갈 화면 (ux20 mail 1) — 같은 서버의 화면 경로만
    try:
        sess = auth.login(store, name, pw, ip=h.ip)
    except auth.LoginLocked as e:
        h._send(429, _auth_page("로그인", _login_form(h, auth.locked_text(e.seconds, e.kind), name, nxt),
                                h._theme_attr_safe(), sub=_login_sub(nxt)),
                extra=(("Retry-After", str(max(1, e.seconds))),))
        return
    except auth.LoginFailed as e:
        msg = str(e)
        left, kind = auth.wait_seconds(store, name, h.ip)
        if left > 0:
            msg += " — " + auth.locked_text(left, kind)
        h._send(401, _auth_page("로그인", _login_form(h, msg, name, nxt), h._theme_attr_safe(), sub=_login_sub(nxt)))
        return
    h._cookie(SESSION_COOKIE, sess.token)
    h._redirect("/password" if sess.must_change else (nxt or "/forms"))


def post_logout(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    auth.logout(h.server.store, h.sess.token, ip=h.ip)
    h._cookie(SESSION_COOKIE, "", max_age=0)
    h._redirect("/login?out=1")              # 로그아웃한 것이 보이게 (ux21 mail 6)


def _password_form(h: FormsHandler, msg: str = "") -> str:
    s = h.sess
    lead = ('<div class="note warn">관리자가 정해 준 임시 비밀번호입니다 — 새 비밀번호로 바꿔야 계속할 수 있습니다.</div>'
            if s.must_change else "")
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'{lead}{note}<form method="post" action="/password">{_hidden(h)}'
            f'<input type="text" name="username" value="{E(s.login)}" autocomplete="username" hidden>'
            f'<label for="old">지금 비밀번호</label><input type="password" id="old" name="old" '
            f'autocomplete="current-password" required maxlength="256">'
            f'<label for="new">새 비밀번호</label><input type="password" id="new" name="new" '
            f'autocomplete="new-password" required maxlength="256">'
            f'<label for="new2">새 비밀번호 한 번 더</label><input type="password" id="new2" name="new2" '
            f'autocomplete="new-password" required maxlength="256">{_password_rules()}'
            f'<div class="form-actions"><button class="btn" type="submit">바꾸기</button></div></form>')


def _password_page(h: FormsHandler, status: int = 200, msg: str = "") -> None:
    if h.sess.must_change:
        csrf = E(h.sess.csrf)
        body = _password_form(h, msg) + (
            f'<form method="post" action="/logout" class="inline">'
            f'<input type="hidden" name="csrf" value="{csrf}"><button class="btn gray sm" type="submit">로그아웃</button></form>')
        h._send(status, _auth_page("비밀번호 바꾸기", body, h._theme_attr_safe()))
    else:
        h._send(status, h._shell("비밀번호 바꾸기", f'<div class="panel">{_password_form(h, msg)}</div>',
                                 active=""))


def get_password(h: FormsHandler) -> None:
    _password_page(h)


def post_password(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    old, new, new2 = h._one(f, "old"), h._one(f, "new"), h._one(f, "new2")
    if new != new2:
        _password_page(h, 400, "새 비밀번호 두 칸이 서로 다릅니다")
        return
    try:
        auth.change_password(h.server.store, h.sess.user_id, old, new, keep_token=h.sess.token, ip=h.ip)
    except auth.LoginLocked as e:                   # 지금 비밀번호를 거듭 틀림 — 로그인과 같은 잠금 (2026-10-30 L3)
        _password_page(h, 429, auth.locked_text(e.seconds, e.kind))
        return
    except (auth.LoginFailed, InvalidInput, Conflict) as e:
        _password_page(h, 400, str(e))
        return
    h._flash("ok", "비밀번호를 바꿨습니다")
    h._redirect("/forms")


def get_setup(h: FormsHandler) -> None:
    store = h.server.store
    if auth.has_admin(store):
        h._redirect("/login")
        return
    if not _is_loopback(h.ip):
        h._send(200, _auth_page("첫 관리자 만들기", (
            '<div class="note warn">아직 관리자가 없습니다. 첫 관리자는 <b>Drev가 설치된 PC</b>에서만 만들 수 있습니다.</div>'
            '<p>Drev PC에서 이 화면을 열어(주소의 IP 자리에 127.0.0.1) 관리자를 만든 뒤, '
            '관리자가 직원 계정을 등록해 주면 이 PC에서도 로그인할 수 있습니다.</p>'), h._theme_attr_safe()))
        return
    h._send(200, _auth_page("첫 관리자 만들기", _setup_form(h), h._theme_attr_safe()))


def _setup_form(h: FormsHandler, msg: str = "", login: str = "", name: str = "") -> str:
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'<p class="muted">양식함을 처음 쓰는 중입니다. 관리자 계정을 하나 만드세요. 직원 계정은 관리자가 등록합니다.</p>'
            f'{note}<form method="post" action="/setup">{_hidden(h)}'
            f'<label for="lg">관리자 아이디</label><input type="text" id="lg" name="login" value="{E(login)}" '
            f'required maxlength="32" autocomplete="username">'
            f'<label for="dn">이름 (화면에 보이는 이름)</label><input type="text" id="dn" name="display_name" '
            f'value="{E(name)}" maxlength="40">'
            f'<label for="pw">비밀번호</label><input type="password" id="pw" name="password" required '
            f'maxlength="256" autocomplete="new-password">'
            f'<label for="pw2">비밀번호 한 번 더</label><input type="password" id="pw2" name="password2" required '
            f'maxlength="256" autocomplete="new-password">{_password_rules()}'
            f'<div class="form-actions"><button class="btn" type="submit">관리자 만들기</button></div></form>')


def post_setup(h: FormsHandler) -> None:
    store = h.server.store
    if _rate_limited(h, "/setup"):
        return
    if not _is_loopback(h.ip):
        raise HttpError(403, "첫 관리자는 Drev가 설치된 PC에서만 만들 수 있습니다")
    f = h._read_form()
    h._check_token(f)
    login, name = h._one(f, "login").strip(), h._one(f, "display_name").strip()
    pw, pw2 = h._one(f, "password"), h._one(f, "password2")
    if pw != pw2:
        h._send(400, _auth_page("첫 관리자 만들기", _setup_form(h, "비밀번호 두 칸이 서로 다릅니다", login, name),
                                h._theme_attr_safe()))
        return
    try:
        auth.create_first_admin(store, login, name or login, pw, is_local=True, ip=h.ip)
    except (InvalidInput, Conflict) as e:
        status = 409 if isinstance(e, Conflict) else 400
        h._send(status, _auth_page("첫 관리자 만들기", _setup_form(h, str(e), login, name), h._theme_attr_safe()))
        return
    sess = auth.login(store, login, pw, ip=h.ip)
    h._cookie(SESSION_COOKIE, sess.token)
    h.server.flash_set(sess.token, "ok", "관리자를 만들었습니다 — 먼저 폴더를 만들고, [계정]에서 직원을 등록하세요")
    h._redirect("/forms")


def post_theme(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    t = h._one(f, "theme")
    if t in ("light", "dark"):
        h._cookie(THEME_COOKIE, t, max_age=365 * 24 * 3600)
    else:
        h._cookie(THEME_COOKIE, "", max_age=0)
    h._redirect(_safe_back(h._one(f, "back", "/forms")))


# ── 양식함 본 화면 ───────────────────────────────────────────────────────────

def _tree_html(nodes, current, path_ids, q: str) -> str:
    """폴더 트리 — 맨 위 폴더는 늘 보이고, 지금 폴더까지의 길(path_ids)만 펼친다 (f6: 기본 분류 틀이면 폴더가 170개 넘어
    전부 펼치면 목록이 화면 몇 장이 된다). 하위가 있는데 접힌 폴더는 이름 뒤에 '…'."""
    if not nodes:
        return ""
    out = ["<ul>"]
    for n in nodes:
        on = ' class="on" aria-current="page"' if n["id"] == current else ""
        kids = n["children"]
        open_ = n["id"] in path_ids
        more = ' <span class="muted" aria-label="하위 폴더 있음">…</span>' if kids and not open_ else ""
        conf = ' <span class="tag conf" title="기밀 폴더">기밀</span>' if n.get("restricted") else ""
        out.append(f'<li><a href="/forms?folder={n["id"]}"{on}>{E(n["name"])}{conf}{more}</a>'
                   f'{_tree_html(kids, current, path_ids, q) if open_ else ""}</li>')
    out.append("</ul>")
    return "".join(out)


def _hint(text: str) -> str:
    """입력 칸 바로 아래 주의 문구 한 줄 (2026-10-30) — 규칙을 쓰기 **전에** 보이게."""
    return f'<p class="hint">{E(text)}</p>'


def _page_of(h: FormsHandler, total: int | None = None) -> int:
    """?page= (0부터) — 숫자가 아니면 400. total을 주면 마지막 쪽을 넘지 않게 맞춘다(없는 쪽에 '양식이 없습니다'가 뜨지 않게)."""
    page = min(h._int(h._one(h._query(), "page"), required=False) or 0, 100000)
    if total is not None:
        page = min(page, max(0, (int(total) - 1) // PAGE_ROWS))
    return page


def _pager(path: str, params: dict, page: int, more: bool, total: int | None = None, per: int = PAGE_ROWS) -> str:
    """← 앞 쪽 / 다음 쪽 → 링크 (스크립트 없음, 걸러 보기 값은 그대로) — 한 쪽뿐이면 빈 글자."""
    if page <= 0 and not more:
        return ""
    keep = "&".join(f"{k}={quote(str(v))}" for k, v in params.items() if v not in (None, ""))

    def href(n):
        return E(f"{path}?{keep + '&' if keep else ''}page={n}")
    out = '<div class="pager">'
    if page > 0:
        out += f'<a class="btn gray sm" href="{href(page - 1)}">← 앞 쪽</a>'
    shown = f"{page * per + 1}~{page * per + per if more else (total if total is not None else '')}"
    out += f'<span class="muted">{E(shown)}' + (f' / 모두 {total}' if total is not None else '') + '</span>'
    if more:
        out += f'<a class="btn gray sm" href="{href(page + 1)}">다음 쪽 →</a>'
    return out + '</div>'


def _no_assigned_note(h: FormsHandler, *, approvals: bool = False, register: bool = False) -> str:
    """검토자인데 맡은 폴더가 하나도 없을 때의 빈 화면 안내 (2026-10-30 M5) — 관리자·직원·맡은 폴더 있는 검토자는 빈 글자.
    register: 문서 관리 대장·검토 기한 화면 — 승인권자로만 지정된 계정에는 그 까닭을 따로 말한다 (2026-10-31)."""
    if h.sess.role != "reviewer":
        return ""
    store = h.server.store
    if store.reviewable_folders(h.sess.user_id):
        return ""
    if approvals and store.steps_map() and store.approver_folder_count(h.sess.user_id):   # 2단계 승인의 승인권자만 맡은 계정
        return ('<div class="note info" role="status">승인할 것이 없습니다 — 승인권자로 지정된 폴더에서 검토자가 '
                '[검토 완료]하면 여기에 승인 대기로 보입니다.</div>')
    if register and store.steps_map() and store.approver_folder_count(h.sess.user_id):   # 2단계 폴더가 있을 때만
        return ('<div class="note info" role="status">승인권자로만 지정된 계정입니다 — 문서 관리 대장은 검토자로 지정된 '
                '폴더만 보여 줍니다. 승인할 것은 [검토 대기]의 승인 대기에서 봅니다.</div>')
    return ('<div class="note info" role="status">검토하도록 지정된 폴더가 없습니다 — 관리자가 [폴더 관리]에서 검토자로 '
            '지정하면 여기에 보입니다.</div>')


def get_forms(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    qd = h._query()
    folder_id = h._int(h._one(qd, "folder"), required=False)
    text = h._one(qd, "q").strip()[:100]
    retired = h._one(qd, "retired") == "1"
    page = _page_of(h)
    tree = store.folder_tree(s.user_id)
    flat = list(_flatten(tree))
    paths = {n["id"]: p for n, _, p in flat}
    crumbs = store.folder_path(s.user_id, folder_id) if folder_id is not None else []
    truncated, more, total = False, False, None
    if text:
        # 폴더를 고른 채 찾으면 그 폴더와 하위 폴더 안에서만 — 범위는 store가 SQL에서 먼저 거르고 그다음 자른다 (2026-10-30)
        forms = store.search_forms(s.user_id, text, include_retired=retired, folder_id=folder_id, limit=SEARCH_MAX + 1)
        truncated = len(forms) > SEARCH_MAX
        forms = forms[:SEARCH_MAX]
    else:
        # 전체 양식·폴더 안 양식 — 한 쪽에 PAGE_ROWS줄씩, 없는 쪽은 마지막 쪽으로 (2026-10-30 M3)
        total = store.count_forms(s.user_id, folder_id, include_retired=retired)
        page = _page_of(h, total)
        forms = store.list_forms(s.user_id, folder_id, include_retired=retired, limit=PAGE_ROWS + 1,
                                 offset=page * PAGE_ROWS)
        more = len(forms) > PAGE_ROWS
        forms = forms[:PAGE_ROWS]
    can_top = s.role == "admin"
    can_here = folder_id is not None and store.is_reviewer_of(s.user_id, folder_id)
    csrf = E(s.csrf)

    side = (f'<div class="panel tree"><h2>폴더</h2>'
            f'<a href="/forms"{" class=\"on\"" if folder_id is None else ""}>전체 양식</a>'
            f'{_tree_html(tree, folder_id, {c["id"] for c in crumbs}, text) or "<p class=\"muted\">아직 폴더가 없습니다</p>"}')
    if can_top:
        side += (f'<details class="tool"><summary>+ 대분류(맨 위 폴더) 만들기</summary>'
                 f'<form method="post" action="/folders/new"><input type="hidden" name="csrf" value="{csrf}">'
                 f'<label for="nf-top">폴더 이름</label><input type="text" id="nf-top" name="name" required maxlength="80">'
                 f'{_hint(HINT_FOLDER_NAME)}'
                 f'<div class="form-actions"><button class="btn sm" type="submit">폴더 만들기</button></div></form></details>'
                 f'<p class="muted"><a href="/admin/folders">폴더 관리</a>에서 기본 분류 틀(대분류·중분류·소분류)을 한 번에 '
                 f'만들 수 있습니다.</p>')
    side += "</div>"

    # 가운데: 경로·도구·검색·목록
    head = ""
    depth = len(crumbs)
    codes = {n["id"]: n.get("code", "") for n, _, _ in flat}
    if crumbs:
        trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in crumbs)
        here_code = codes.get(folder_id, "")
        secret = store.restricted_path(folder_id)                 # 기밀 폴더 (2026-10-30) — 볼 수 있는 사람에게만 이 화면이 열린다
        two = store.approval_steps(folder_id) == 2      # 2단계 승인 — 올리기 전에 알게 모두에게 (2026-10-31 실사용 검토)
        head += (f'<div class="crumb"><a href="/forms">전체</a> / {trail} '
                 f'<span class="tag lvl">{E(level_name(depth))}</span>'
                 + (f'<span class="tag code" title="문서번호 머리">{E(here_code)}</span>' if here_code else "")
                 + ('<span class="tag conf" title="관리자·검토자·고른 직원만 보는 폴더">[기밀]</span>' if secret else "")
                 + (f'<span class="tag two" title="{E(HINT_TWO_STEP)}">2단계 승인</span>' if two else "")
                 + '</div>')
        if two:
            # 관리자·그 폴더 검토자·승인권자에게는 승인권자 이름까지, 다른 사람(직원 등)에게는 짧은 안내 한 줄
            head += _two_step_note(h, folder_id) or f'<p class="muted">{E(TWO_STEP_NOTE)}</p>'
    banner = ""
    if folder_id is None and not text and s.role in ("reviewer", "admin"):
        banner = _approval_banner(h) + _due_banner(h)
    if folder_id is None and not text and s.role == "admin":
        banner = _mirror_banner(h) + banner
    tools = ""
    manage = ""             # 자주 쓰지 않는 관리 도구는 '폴더 관리' 하나로 접는다 (ux20 forms 8 — 세로 링크 11개)
    if can_here:
        cur_name = crumbs[-1]["name"] if crumbs else ""
        child = level_name(depth + 1)
        manage += _folder_code_tool(h, folder_id, codes.get(folder_id, ""))
        tools += (f'<details class="tool"><summary>+ {E(child)} 만들기</summary>'
                  f'<form method="post" action="/folders/new"><input type="hidden" name="csrf" value="{csrf}">'
                  f'<input type="hidden" name="parent" value="{folder_id}">'
                  f'<label for="nf-sub">{E(child)} 이름</label><input type="text" id="nf-sub" name="name" required '
                  f'maxlength="80">{_hint(HINT_FOLDER_NAME)}'
                  f'<div class="form-actions"><button class="btn sm" type="submit">폴더 만들기</button></div></form></details>')
        manage += (f'<details class="tool"><summary>폴더 이름 바꾸기</summary>'
                   f'<form method="post" action="/folders/rename"><input type="hidden" name="csrf" value="{csrf}">'
                   f'<input type="hidden" name="folder" value="{folder_id}">'
                   f'<label for="rn">새 이름</label><input type="text" id="rn" name="name" value="{E(cur_name)}" '
                   f'required maxlength="80">{_hint(HINT_FOLDER_NAME)}'
                   f'<div class="form-actions"><button class="btn sm" type="submit">이름 바꾸기'
                   f'</button></div></form></details>')
    if folder_id is not None:
        manage += _folder_manage_tools(h, folder_id, crumbs)
        manage += _confidential_tool(h, folder_id, can_here)
        if can_here and store.list_folders(s.user_id, folder_id):        # 빈 하위 폴더 한꺼번에 (F2-6)
            manage += (f'<p class="form-actions"><a class="btn gray sm" href="/folders/prune?folder={folder_id}">'
                       f'이 아래 빈 폴더 모두 지우기…</a></p>')
        mine_wait = store.my_pending(s.user_id, folder_id)          # 올린 직후 '어디 갔지?' (F2-1) — 자기 것만
        if mine_wait:
            head += (f'<div class="note info" role="status">검토를 기다리는 내 제출 {len(mine_wait)}건 — '
                     + ", ".join(E(x["form_name"]) for x in mine_wait[:3]) + (" …" if len(mine_wait) > 3 else "")
                     + ' · 승인되면 이 폴더 목록에 보입니다. <a href="/mine">내 제출</a></div>')
    if manage:
        tools += f'<details class="tool fold"><summary>폴더 관리 ▸</summary>{manage}</details>'
    # 메일 주소가 없는 계정에는 알림 단추 대신 안내 한 줄 — 눌러도 메일이 가지 않는다 (ux20 forms 9). 이미 켠 것은 끌 수 있게 둔다
    has_mail = bool(store.user_email(s.user_id)) if h.server.notifier is not None else False
    no_mail = ('<p class="sub">새 판 메일 알림을 받으려면 내 계정에 메일 주소가 있어야 합니다 — '
               + ('<a href="/admin/users">[계정]에서 내 메일 주소를 적으세요</a>' if s.role == "admin"
                  else '관리자에게 메일 주소 등록을 부탁하세요') + '</p>')
    if folder_id is None and not text and h.server.notifier is not None and not has_mail \
            and not store.is_subscribed_all(s.user_id):
        tools += no_mail
    elif folder_id is None and not text and h.server.notifier is not None:
        on_all = store.is_subscribed_all(s.user_id)                  # 모든 폴더 새 판 알림 (F2-4, 맨 위 구독)
        tools += (f'<form class="sub" method="post" action="/folders/subscribe-all">'
                  f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="on" value="{"0" if on_all else "1"}">'
                  f'<button class="btn gray sm" type="submit">{"모든 폴더 새 판 알림 끄기" if on_all else "모든 폴더 새 판 알림 받기"}'
                  f'</button><span>{"볼 수 있는 모든 폴더에 새 현행 판이 생기면 메일로 알립니다" if on_all else "어느 폴더든 새 판이 승인되면 메일로 알려 줍니다"}'
                  f'{"" if store.user_email(s.user_id) else " — 내 계정에 메일 주소가 없습니다(관리자가 등록)"}</span></form>')
    if folder_id is not None and h.server.notifier is not None and not has_mail \
            and not store.is_subscribed(s.user_id, folder_id):
        tools += no_mail
    elif folder_id is not None and h.server.notifier is not None:
        on = store.is_subscribed(s.user_id, folder_id)
        tools += (f'<form class="sub" method="post" action="/folders/subscribe">'
                  f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="folder" value="{folder_id}">'
                  f'<input type="hidden" name="on" value="{"0" if on else "1"}">'
                  f'<button class="btn gray sm" type="submit">{"메일 알림 끄기" if on else "새 현행 판 메일 받기"}</button>'
                  f'<span>{"이 폴더(하위 포함)에 새 현행 판이 생기면 메일로 알립니다" if on else "이 폴더(하위 포함)에 새 판이 승인되면 메일로 알려 줍니다"}'
                  f'{"" if store.user_email(s.user_id) else " — 내 계정에 메일 주소가 없습니다(관리자가 등록)"}</span></form>')
    subs = []
    if folder_id is not None:
        subs = store.list_folders(s.user_id, folder_id)
    chips = ("<div class=\"chips\">" + "".join(
        f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in subs) + "</div>") if subs else ""
    hidden_folder = f'<input type="hidden" name="folder" value="{folder_id}">' if folder_id is not None else ""
    search = (f'<form class="searchbar" method="get" action="/forms" role="search">{hidden_folder}'
              f'<input type="search" name="q" value="{E(text)}" placeholder="양식 이름·문서번호·폴더·파일 이름" '
              f'aria-label="양식 찾기" maxlength="100">'
              + (f'<input type="hidden" name="retired" value="1">' if retired else "")
              + f'<button class="btn sm" type="submit">찾기</button>'
              + (f'<a class="btn gray sm" href="/forms{"?folder=" + str(folder_id) if folder_id is not None else ""}">'
                 f'지우기</a>' if text else "")
              + "</form>")
    base = "/forms?" + "&".join(x for x in (
        f"folder={folder_id}" if folder_id is not None else "", f"q={quote(text)}" if text else "") if x)
    toggle = (f'<a class="btn gray sm" href="{E(base.rstrip("?&"))}">폐기 양식 숨기기</a>' if retired else
              f'<a class="btn gray sm" href="{E(base + ("&" if base[-1] != "?" else "") + "retired=1")}">'
              f'폐기 양식도 보기</a>')
    show_folder = folder_id is None or bool(text)
    rows = []
    for f in forms:
        tag = ' <span class="tag retired">폐기</span>' if f["retired"] else ""
        cat = f'<div class="muted">{E(f["category"])}</div>' if f["category"] else ""
        no = f'<span class="docno">{E(f["doc_no"])}</span>' if f.get("doc_no") else ""      # 문서번호 (F7)
        ver = f'v{f["current_number"]}' if f["current_number"] else "—"
        # 좁은 화면(폰)에서는 폴더·올린 사람 열(nh)을 숨기고 폴더는 이름 아래 작은 글(nshow)로 (ux21 forms 2)
        fpath = E(paths.get(f["folder_id"], ""))
        rows.append(
            f'<tr><td class="name-c">{no}<a href="/form?id={f["id"]}">{E(f["name"])}</a>{tag}{cat}'
            + (f'<div class="muted nshow">{fpath}</div>' if show_folder and fpath else "") + '</td>'
            + (f'<td class="path-c nh">{fpath}</td>' if show_folder else "")
            + f'<td class="nw">{ver}</td><td class="nw">{E(_fmt_time(f["current_approved_at"]))}</td>'
            f'<td class="nw nh">{E(f["current_uploaded_by_name"])}</td></tr>')
    empty_more = ""
    if text:
        empty = "찾는 양식이 없습니다" + ("" if retired else " — 폐기된 양식은 [폐기 양식도 보기]를 켜면 찾습니다")
        if not rows:
            empty_more = _search_help(h, text, retired, folder_id)
    elif folder_id is None:
        empty = "아직 올라온 양식이 없습니다"
    else:
        empty = "이 폴더에는 아직 양식이 없습니다"
    table = ('<div class="tablewrap"><table class="flist"><thead><tr><th>양식</th>'
             + ('<th class="nh">폴더</th>' if show_folder else "")
             + '<th>현행 판</th><th>마지막 개정</th><th class="nh">올린 사람</th></tr></thead><tbody>'
             + "".join(rows) + "</tbody></table></div>") if rows else f'<p class="empty">{empty}</p>{empty_more}'
    if truncated:
        table = (f'<div class="note warn" role="status">{SEARCH_MAX}개 넘음 — 낱말을 더 적어 좁혀 주세요 '
                 f'(이름순 앞 {SEARCH_MAX}개만 보입니다)</div>' + table)
    pager = ""
    if not text:
        pager = _pager("/forms", {"folder": folder_id, "retired": "1" if retired else ""}, page, more, total)
    count = f"{len(forms)}개" + (" 넘음" if truncated else "") if total is None else f"모두 {total}개"
    up = f'/upload?folder={folder_id}' if folder_id is not None else "/upload"
    title = crumbs[-1]["name"] if crumbs else ("찾기 결과" if text else "양식함")
    main = (f'<div class="panel">{head}{tools}{chips}{search}'
            f'<div class="searchbar">{toggle}<span class="muted">{count}</span></div>{table}{pager}</div>')
    body = f'{banner}<div class="split">{side}<div>{main}</div></div>'
    h._send(200, h._shell(title, body, active="/forms",
                          actions=f'<a class="btn" href="{E(up)}">양식 올리기</a>'))


RECENT_ON_EMPTY = 5          # 찾기 0건일 때 보일 최근 양식 수 (ux20 forms 6)
# 찾기 0건일 때만 쓰는 영문 → 우리말 (ux21 forms 6, 외국인 직원). 작은 표 — 실제 양식 이름 찾기를 가리지 않는다(0건일 때만)
SEARCH_ALIASES = {
    "vacation": "휴가", "leave": "휴가", "holiday": "휴가", "dayoff": "휴가",
    "overtime": "잔업", "quote": "견적", "quotation": "견적", "estimate": "견적",
    "order": "발주", "purchase": "발주", "drawing": "도면", "inspection": "검사", "report": "보고서",
    "expense": "경비", "application": "신청서", "request": "신청서", "contract": "계약서", "spec": "사양서",
    "specification": "사양서",
}


def _search_help(h: FormsHandler, text: str, retired: bool, folder_id) -> str:
    """찾기 0건 안내 (ux20 forms 6) — '두세 글자만' 예시 + 끝 글자를 한두 자 줄여 찾은 것(오타 '휴가신청소' → '휴가신청') +
    최근 승인된 양식. 모두 같은 store 찾기·목록이라 볼 수 없는 기밀 폴더의 양식은 나오지 않는다."""
    from watcher.forms.store import search_key
    store, uid = h.server.store, h.sess.user_id
    words = text.split()

    def find(q, n=RECENT_ON_EMPTY):
        return store.search_forms(uid, q, include_retired=retired, folder_id=folder_id, limit=n)
    tip = ('<p class="muted">두세 글자만 쳐 보세요 — 예: <a href="/forms?q=' + quote("휴가") + '">휴가</a>, '
           '<a href="/forms?q=' + quote("잔업") + '">잔업</a>. 띄어쓰기는 상관없습니다.</p>')
    if re.search(r"[A-Za-z]{3,}", text):            # 영문으로 찾은 사람에게 — 양식 이름은 대부분 한국어
        tip += ('<p class="muted" lang="en">Form names are in Korean. Try: '
                + ", ".join(f'<a href="/forms?q={quote(ko)}">{E(en)} = {E(ko)}</a>'
                            for en, ko in (("vacation", "휴가"), ("overtime", "잔업"), ("quote", "견적"))) + '</p>')

    def lst(forms):
        return '<ul class="lines">' + "".join(
            f'<li><a href="/form?id={f["id"]}">{E(f["name"])}</a>'
            + (f' <span class="muted">현행 v{f["current_number"]}</span>' if f["current_number"] else "") + '</li>'
            for f in forms) + '</ul>'
    # ① 영문 낱말 → 우리말 (ux21 forms 6). 찾기가 0건일 때만 오므로 실제 양식 이름 찾기를 가리지 않는다
    mapped = [(w, SEARCH_ALIASES[search_key(w)]) for w in words if search_key(w) in SEARCH_ALIASES]
    if mapped:
        q = " ".join(dict.fromkeys(ko for _, ko in mapped))
        got = find(q) or (find(mapped[0][1]) if len(mapped) > 1 else [])
        if got:
            pairs = ", ".join(f"'{E(w)}' → '{E(ko)}'" for w, ko in mapped)
            return tip + f'<h3>혹시 이것인가요? — {pairs}(으)로 찾은 양식</h3>' + lst(got)
    # ② 낱말 여럿 — 하나라도 맞는 양식을 모아 많이 맞는 순으로 (ux21 forms 9: '견적서 최신'이 0건이던 것)
    if len(words) >= 2:
        score: dict = {}
        seen: dict = {}
        hit = []
        for w in dict.fromkeys(words):
            got = find(w, SEARCH_MAX)
            if got:
                hit.append(w)
            for f in got:
                score[f["id"]] = score.get(f["id"], 0) + 1
                seen[f["id"]] = f
        if score:
            best = sorted(seen.values(), key=lambda f: (-score[f["id"]], search_key(f["name"]), f["id"]))
            return (tip + '<h3>혹시 이것인가요? — 낱말 하나라도 맞는 양식 ('
                    + ", ".join(f"'{E(w)}'" for w in hit) + ' 맞음)</h3>' + lst(best[:RECENT_ON_EMPTY]))
    near, used = [], ""
    if len(words) == 1 and len(words[0]) >= 3:              # 낱말 하나 — 끝을 1~2자 줄여 본다(단순·안전)
        for cut in (1, 2):
            q = words[0][:-cut]
            if len(q) < 2:
                break
            near = find(q)
            if near:
                used = q
                break
    if near:
        return (tip + f'<h3>혹시 이것인가요? — \'{E(used)}\'(으)로 찾은 양식</h3>' + lst(near))
    # ③ 가운데 한 글자 오타 ('견작서' → '견적서') — 세 글자 넘는 낱말 하나, 폴더를 고르지 않은 찾기에서만. 양식 이름 안에서
    # 같은 길이 토막 가운데 한 글자만 다른 것. 볼 수 있는 양식만(list_forms가 기밀 폴더를 거른다)
    if len(words) == 1 and folder_id is None and len(search_key(words[0])) >= 3:
        w = search_key(words[0])
        typo = []
        for f in store.list_forms(uid, include_retired=retired, limit=2000):
            k = search_key(f["name"])
            if any(sum(a != b for a, b in zip(w, k[i:i + len(w)])) == 1 for i in range(len(k) - len(w) + 1)):
                typo.append(f)
            if len(typo) >= RECENT_ON_EMPTY:
                break
        if typo:
            return tip + f'<h3>혹시 이것인가요? — \'{E(words[0])}\'와 한 글자 다른 양식</h3>' + lst(typo)
    recent = [f for f in store.list_forms(uid, limit=2000) if f["current_approved_at"]]
    recent.sort(key=lambda f: str(f["current_approved_at"]), reverse=True)
    if not recent:
        return tip
    return tip + '<h3>최근 바뀐 양식</h3>' + lst(recent[:RECENT_ON_EMPTY])


def _two_step_note(h: FormsHandler, folder_id: int) -> str:
    """2단계 승인 폴더 안내 한 줄 — 그 폴더의 검토자·승인권자·관리자에게 승인권자 이름까지 (다른 검토자에게는 표시만)."""
    store = h.server.store
    try:
        a = store.folder_approval(h.sess.user_id, folder_id)
    except (PermissionDenied, NotFound):
        return ""
    who = ", ".join(f'{E(u["display_name"])}({E(u["login"])})' for u in a["approvers"]) or "지정 없음"
    src = f" (위 폴더 '{E(a['source'])}'의 설정)" if a["own"] is None and a["source"] else ""
    return (f'<p class="muted">2단계 승인{src} — 검토자가 [검토 완료]한 뒤 승인권자가 [승인]합니다. '
            f'승인권자: {who} · 관리자 {a["admins"]}명(늘 승인할 수 있음). 올린 사람·검토한 사람·승인한 사람은 서로 달라야 합니다.</p>')


def _confidential_tool(h: FormsHandler, folder_id: int, can_here: bool) -> str:
    """기밀 폴더 칸 (2026-10-30) — 관리자는 늘(켜기·끄기 + 볼 사람), 그 폴더 검토자는 경로에 기밀 폴더가 있을 때 볼 사람만.
    직원에게는 아무것도 보이지 않는다. 켜기·끄기는 POST /folders/restricted(관리자), 볼 사람은 POST /folders/members."""
    store, s = h.server.store, h.sess
    is_admin = s.role == "admin"
    if not (is_admin or can_here):
        return ""
    acc = store.folder_access(s.user_id, folder_id)
    secret = acc["restricted"]
    if not is_admin and not secret:
        return ""
    own = bool(secret) and secret[-1]["id"] == folder_id
    if own:
        state = ("이 폴더는 <b>기밀 폴더</b>입니다 — 이 폴더와 하위 폴더는 관리자·이 폴더(또는 위 폴더) 검토자·승인권자·"
                 "고른 직원만 봅니다.")
    elif secret:
        names = ", ".join(f"'{E(x['name'])}'" for x in secret)
        state = f"위 폴더 {names}이(가) 기밀이라 이 폴더도 기밀입니다 — 거기에 들어갈 수 있는 사람만 봅니다."
    else:
        state = "기밀 폴더가 아닙니다 — 로그인한 모든 사람이 봅니다."
    out = f'<p class="muted">{state}</p>'
    if secret:
        who = ", ".join(f'{E(u["display_name"])}({E(u["login"])})' for u in acc["people"]) or "없음"
        out += (f'<p class="conf-who">볼 수 있는 사람: 관리자 {acc["admins"]}명 · 그 밖에 {len(acc["people"])}명 — '
                f'{who}</p>')
    if is_admin:
        out += (f'<form method="post" action="/folders/restricted">{_hidden(h)}'
                f'<input type="hidden" name="folder" value="{folder_id}">'
                f'<label class="chk" for="conf-on"><input type="checkbox" id="conf-on" name="on" value="1"'
                f'{" checked" if own else ""}>기밀 폴더</label>{_hint(HINT_CONFIDENTIAL)}{_hint(HINT_CONF_CODE)}'
                f'<div class="form-actions"><button class="btn sm" type="submit">기밀 설정 저장</button></div></form>')
    if not secret:
        # 기밀이 꺼져 있으면 '볼 사람' 계정 목록을 그리지 않는다 — 켠 뒤에 고른다 (기능 검토 F2-5)
        label = "기밀 폴더"
        return f'<details class="tool"><summary>{label}</summary>{out}</details>'
    users = [u for u in auth.list_users(store, s.user_id) if not u["disabled"] and u["role"] != "admin"] \
        if is_admin else [u for u in store.active_people(s.user_id) if u["role"] != "admin"]
    mine = {u["id"] for u in acc["members"]}
    boxes = "".join(
        f'<label class="chk"><input type="checkbox" name="user" value="{u["id"]}"{" checked" if u["id"] in mine else ""}>'
        f'{E(u["display_name"])} ({E(u["login"])}) <span class="muted">{E(ROLE_LABEL.get(u["role"], u["role"]))}</span>'
        f'</label>' for u in users)
    see = {u["id"] for u in acc["people"]}
    blocked = [u for u in acc["members"] if secret and u["id"] not in see and not u["disabled"]]
    warn = ""
    if blocked:
        warn = (f'<p class="hint">고른 사람 가운데 위 기밀 폴더에 들어갈 수 없어 아직 못 보는 사람: '
                + ", ".join(E(u["display_name"]) for u in blocked) + ' — 위 기밀 폴더에서도 골라 주세요.</p>')
    out += (f'<form method="post" action="/folders/members">{_hidden(h)}'
            f'<input type="hidden" name="folder" value="{folder_id}">'
            f'<div class="muted">이 폴더를 볼 수 있게 고른 사람 — 이 폴더와 그 아래 기밀 폴더를 봅니다(관리자는 늘 봄)</div>'
            f'{boxes or "<span class=muted>고를 계정이 없습니다</span>"}{warn}'
            f'<div class="form-actions"><button class="btn gray sm" type="submit">볼 사람 저장</button></div></form>')
    label = "기밀 폴더" + (" — 켜짐" if own else (" — 위 폴더가 기밀" if secret else ""))
    return f'<details class="tool"><summary>{label}</summary>{out}</details>'


def _confirm_page(h: FormsHandler, title: str, action: str, fields: dict, lead: str, items: list, button: str,
                  back: str, active: str) -> None:
    """되돌리기 어려운 동작 전 한 단계 확인 (기능 검토 F2-8) — 바꾸지 않는다. 같은 칸 + confirm=1로 다시 보낸다."""
    hid = "".join(f'<input type="hidden" name="{E(k)}" value="{E(str(v))}">' for k, v in fields.items())
    lis = "".join(f"<li>{x}</li>" for x in items)
    body = (f'<div class="panel"><div class="note warn" role="status">{lead}</div>'
            + (f'<ul class="lines">{lis}</ul>' if lis else "")
            + f'<form method="post" action="{E(action)}">{_hidden(h)}{hid}<input type="hidden" name="confirm" value="1">'
              f'<div class="form-actions"><button class="btn red" type="submit">{E(button)}</button>'
              f'<a class="btn gray" href="{E(back)}">그만두기</a></div></form></div>')
    h._send(200, h._shell(title, body, active=active))


def post_folder_restricted(h: FormsHandler) -> None:
    """기밀 폴더 켜기·끄기 — 관리자만(store도 다시 본다). 켜면 현행 미러에서 그 아래 Drev 파일을 다음 맞추기 때 뺀다.
    켜기는 영향(공유 폴더에서 빠질 파일 수·볼 수 없게 될 계정 수)을 보이는 확인 화면을 한 번 거친다 (F2-8)."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    on = h._one(f, "on") == "1"
    store = h.server.store
    if on and h._one(f, "confirm") != "1" and not store._folder(fid)["restricted"]:
        imp = store.restrict_impact(h.sess.user_id, fid)
        path = " / ".join(c["name"] for c in store.folder_path(h.sess.user_id, fid))
        who = ", ".join(f'{E(u["display_name"])}({E(u["login"])})' for u in imp["losing"][:20]) \
            + (" …" if len(imp["losing"]) > 20 else "")
        items = [f'볼 수 없게 될 계정 <b>{len(imp["losing"])}명</b>' + (f' — {who}' if who else ""),
                 f'공유 폴더(현행 미러)에서 빠질 파일 <b>{imp["mirrored"]}개</b>'
                 + (" (사람이 고친 파일은 지우지 않고 남깁니다)" if imp["mirrored"] else "")]
        if imp["members"]:
            items.append("이미 고른 볼 사람(이 폴더나 위 폴더) — 계속 봅니다: " + E(", ".join(imp["members"][:20])))
        _confirm_page(h, "기밀 폴더 켜기 — 확인", "/folders/restricted", {"folder": fid, "on": "1"},
                      f"'{E(path)}' 폴더를 기밀로 바꾸면 이 폴더와 하위 폴더는 관리자·검토자·승인권자·고른 사람만 봅니다.",
                      items, "기밀 폴더로 바꾸기", f"/forms?folder={fid}", "/forms")
        return
    try:
        res = h.server.store.set_folder_restricted(h.sess.user_id, fid, on, ip=h.ip)
    except Conflict as e:                       # 기밀을 풀 때 보이는 형제와 이름이 같음 (이주 12)
        h._flash("bad", str(e))
        h._redirect(f"/forms?folder={fid}")
        return
    if res["changed"]:
        h.server.on_event("folder_restricted", folder_id=fid)
    if not res["changed"]:
        h._flash("info", "바뀐 것이 없습니다")
    elif on:
        msg = "기밀 폴더로 정했습니다 — 이 폴더와 하위 폴더는 관리자·검토자·고른 직원만 봅니다"
        if res.get("members"):                  # 위 폴더에 예전에 고른 사람도 본다 — 누가 보게 되는지 알린다 (검토20 r01-1)
            from watcher.forms.store import members_text
            msg += f" · {members_text(res['members'])} (이 폴더나 위 폴더에서 고른 사람 — 빼려면 [볼 사람]에서 고치세요)"
        if res["mirrored"]:
            msg += (f" · 공유 폴더(현행 미러)에 놓였던 파일 {res['mirrored']}개를 뺍니다"
                    " (공유 폴더에서 사람이 고친 파일은 지우지 않고 남깁니다 — 감사 기록의 '현행 미러 건너뜀'을 보고 직접 지우세요)")
        h._flash("ok", msg)
    else:
        h._flash("ok", "기밀 폴더를 풀었습니다 — 이제 로그인한 모든 사람이 봅니다"
                 + (" (현행 미러에도 다시 놓습니다)" if h.server.mirror is not None else ""))
    h._redirect(f"/forms?folder={fid}")


def post_folder_members(h: FormsHandler) -> None:
    """기밀 폴더를 볼 사람 지정 — 관리자나 그 폴더 검토자(store가 확인). 볼 수 없는 폴더는 없는 폴더처럼."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    ids = [h._int(v) for v in f.get("user", [])]
    try:
        res = h.server.store.set_folder_members(h.sess.user_id, fid, ids, ip=h.ip)
    except InvalidInput as e:
        h._flash("bad", f"볼 사람을 저장하지 않았습니다 — {e}")
        h._redirect(f"/forms?folder={fid}")
        return
    bits = [x for x in (f"더함 {len(res['added'])}명" if res["added"] else "",
                        f"뺌 {len(res['removed'])}명" if res["removed"] else "") if x]
    h._flash("ok", ("볼 사람을 저장했습니다 — " + " · ".join(bits)) if bits else "바뀐 것이 없습니다")
    h._redirect(f"/forms?folder={fid}")


def _folder_back(h: FormsHandler, f: dict, fid) -> str:
    """폴더 POST가 실패했을 때 돌아갈 곳 — 양식의 back(이 서버 안), 없으면 그 폴더 화면."""
    b = h._one(f, "back")
    return _safe_back(b) if b else (f"/forms?folder={fid}" if fid is not None else "/forms")


def post_folder_new(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    parent = h._int(h._one(f, "parent"), required=False)
    try:
        fid = h.server.store.create_folder(h.sess.user_id, parent, h._one(f, "name"), ip=h.ip)
    except (Conflict, InvalidInput) as e:            # 이름 겹침·쓸 수 없는 이름 — 막다른 오류 화면 대신 알림 + 그 폴더로 (2026-10-30)
        same = None
        if isinstance(e, Conflict):                  # 같은 이름이 이미 있으면 그 폴더로 — 위 폴더로 돌아가 거기 올리던 것 (ux20 forms 7)
            from watcher.forms.store import name_key
            key = name_key(h._one(f, "name"))
            try:                                     # 볼 수 있는 폴더 가운데서만(기밀 폴더는 list_folders가 거른다)
                same = next((x for x in h.server.store.list_folders(h.sess.user_id, parent)
                             if name_key(x["name"]) == key), None)
            except (PermissionDenied, NotFound):
                same = None
        if same is not None:
            h._flash("info", f"'{same['name']}' 폴더가 이미 있어 새로 만들지 않고 그 폴더를 열었습니다 — 여기에 올리면 됩니다")
            h._redirect(f"/forms?folder={same['id']}")
            return
        h._flash("bad", f"폴더를 만들지 않았습니다 — {e}")
        h._redirect(_folder_back(h, f, parent))
        return
    h._flash("ok", "폴더를 만들었습니다")
    h._redirect(f"/forms?folder={fid}")


def post_folder_rename(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    try:
        h.server.store.rename_folder(h.sess.user_id, fid, h._one(f, "name"), ip=h.ip)
    except (Conflict, InvalidInput) as e:
        h._flash("bad", f"이름을 바꾸지 않았습니다 — {e}")
        h._redirect(_folder_back(h, f, fid))
        return
    h.server.on_event("folder_renamed", folder_id=fid)
    h._flash("ok", "폴더 이름을 바꿨습니다")
    h._redirect(_safe_back(h._one(f, "back")) if h._one(f, "back") else f"/forms?folder={fid}")


# ── 폴더 관리: 옮기기·지우기·차례 (f6, 2026-10-29) ─────────────────────────────

def _move_targets(h: FormsHandler, folder_id: int) -> list:
    """옮겨 갈 수 있는 부모 후보 [(id|None, 경로 글)] — 자기 자신·자기 하위·지금 부모는 빼고, 검토자는 맡은 폴더만."""
    store, s = h.server.store, h.sess
    flat = h._folders()
    kids: dict = {}
    for n, _d, _p in flat:
        kids.setdefault(n["parent_id"], []).append(n["id"])
    banned, todo = set(), [folder_id]
    while todo:
        x = todo.pop()
        if x not in banned:
            banned.add(x)
            todo.extend(kids.get(x, []))
    parent = next((n["parent_id"] for n, _d, _p in flat if n["id"] == folder_id), None)
    mine = store.reviewable_folders(s.user_id)
    out = []
    if mine is None and parent is not None:
        out.append((None, "(맨 위 — 대분류로)"))
    for n, _d, p in flat:
        if n["id"] in banned or n["id"] == parent:
            continue
        if mine is not None and n["id"] not in mine:
            continue
        out.append((n["id"], p))
    return out


def _move_form(h: FormsHandler, folder_id: int, idp: str = "mv") -> str:
    """[옮기기] 양식 — 스크립트 없는 POST(/folders/move, CSRF). 옮길 곳이 없으면 안내만."""
    opts = _move_targets(h, folder_id)
    note = ('<p class="muted">옮기면 그 안의 하위 폴더·양식이 함께 갑니다. 검토자 지정은 폴더에 붙어 있어 <b>새 위 폴더의 검토자도 '
            '이 폴더를 검토할 수 있게</b> 되고, 옛 위 폴더의 검토자는 (따로 지정되지 않았다면) 더 이상 검토하지 못합니다.</p>')
    if not opts:
        return note + '<p class="muted">옮겨 갈 수 있는 폴더가 없습니다.</p>'
    o = "".join(f'<option value="{"" if fid is None else fid}">{E(p)}</option>' for fid, p in opts)
    return (note + f'<form method="post" action="/folders/move">{_hidden(h)}'
            f'<input type="hidden" name="folder" value="{folder_id}">'
            f'<label for="{idp}-to">어느 폴더 아래로 옮길까요</label><select class="wide" id="{idp}-to" name="to">{o}</select>'
            f'<div class="form-actions"><button class="btn sm" type="submit">옮기기</button></div></form>')


def _folder_manage_tools(h: FormsHandler, folder_id: int, crumbs: list) -> str:
    """폴더 화면의 옮기기·지우기·차례 — 권한이 맞을 때만 보인다 (관리자, 또는 위 폴더의 검토자)."""
    store, s = h.server.store, h.sess
    parent = crumbs[-2]["id"] if len(crumbs) >= 2 else None
    if not store.can_manage_child_of(s.user_id, parent):
        return ""
    out = (f'<details class="tool"><summary>폴더 옮기기</summary>{_move_form(h, folder_id)}</details>'
           f'<details class="tool"><summary>폴더 지우기</summary>'
           f'<p class="muted">빈 폴더만 지울 수 있습니다 — 하위 폴더·양식(폐기 포함)·검토 대기가 없어야 합니다.</p>'
           f'<form method="post" action="/folders/delete">{_hidden(h)}<input type="hidden" name="folder" '
           f'value="{folder_id}"><div class="form-actions"><button class="btn red sm" type="submit">이 폴더 지우기</button>'
           f'</div></form></details>')
    return out + _order_buttons(h, folder_id, back=f"/forms?folder={folder_id}")


def _folder_code_tool(h: FormsHandler, folder_id: int, code: str, back: str = "") -> str:
    """번호 머리(문서번호 앞부분) 정하기 — 이름 바꾸기와 같은 권한(관리자나 그 폴더 검토자). POST /folders/code (F7)."""
    return (f'<details class="tool"><summary>번호 머리(문서번호) {E(code) if code else "정하기"}</summary>'
            f'<p class="muted">이 폴더에서 처음 승인되는 양식의 문서번호 앞부분입니다. 관리자가 정한 문서번호 규칙대로 '
            f'잇습니다(기본: 위 폴더들의 머리를 위에서부터 붙임표(-)로 잇고 일련번호 세 자리, 예: QA-01-01-001). 머리가 하나도 없으면 F-0001처럼 매깁니다. '
            f'<b>이미 매긴 번호는 바뀌지 않습니다.</b> 비우면 머리 없음.</p>'
            f'<form class="inline" method="post" action="/folders/code">{_hidden(h)}'
            f'<input type="hidden" name="folder" value="{folder_id}">'
            + (f'<input type="hidden" name="back" value="{E(back)}">' if back else "")
            + f'<input type="text" class="code" name="code" value="{E(code)}" maxlength="8" '
              f'aria-label="번호 머리" placeholder="예: QA">'
              f'<button class="btn gray sm" type="submit">머리 저장</button></form>{_hint(HINT_FOLDER_CODE)}</details>')


def _due_counts(h: "FormsHandler") -> tuple[int, int]:
    """(기한 지난 수, 곧 오는 수) — 요청 하나에 한 번만 센다(메뉴 숫자와 첫 화면 띠가 같이 쓴다, SQL 한 번 — F7 검토 10)."""
    got = getattr(h, "_due_memo", None)
    if got is None:
        got = h._due_memo = h.server.store.due_counts(h.sess.user_id)
    return got


def _approval_count(h: "FormsHandler") -> int:
    """내가 지금 [승인]할 수 있는 승인 대기 수 (2단계 승인) — 요청 하나에 한 번만 센다(메뉴 숫자와 첫 화면 띠)."""
    got = getattr(h, "_appr_memo", None)
    if got is None:
        got = h._appr_memo = h.server.store.pending_approval_count(h.sess.user_id)
    return got


def _mirror_banner(h: FormsHandler) -> str:
    """관리자 첫 화면 위 띠 — 현행 미러 폴더가 감시 폴더 안이라 꺼 둠 (검토20 r04-1, 백업 폴더 검사와 같은 태도)."""
    srv = h.server
    why = srv.mirror_problem or (getattr(srv.mirror, "disabled", "") if srv.mirror is not None else "")
    if not why:
        return ""
    return f'<div class="note bad" role="alert"><b>현행 미러 꺼짐</b> — {E(why)}</div>'


def _approval_banner(h: FormsHandler) -> str:
    """양식함 첫 화면 위 띠 — 승인 대기(검토자가 검토 완료한 2단계 승인 제출)가 있으면 승인권자에게 (2026-10-30)."""
    n = _approval_count(h)
    if not n:
        return ""
    return (f'<div class="note info" role="status"><b>승인 대기 {n}건</b> — 검토자가 [검토 완료]한 제출이 승인을 '
            f'기다립니다. <a href="/review?stage=approve">승인 대기 보기</a></div>')


def _due_banner(h: FormsHandler) -> str:
    """양식함 첫 화면 위 띠 — 정기 검토 기한이 지난 양식(관리자는 전체, 검토자는 맡은 폴더) (F7)."""
    over, soon = _due_counts(h)
    if over:
        more = f" · {REVIEW_SOON_DAYS}일 안에 기한이 오는 양식 {soon}개" if soon else ""
        return (f'<div class="note warn" role="status"><b>검토 기한 지난 양식 {over}개</b>{more} — '
                f'바꿀 것이 없으면 [검토함]을, 고칠 것이 있으면 개정안을 올리세요. '
                f'<a href="/register/due">검토할 양식 보기</a></div>')
    if soon:
        return (f'<div class="note info" role="status">{REVIEW_SOON_DAYS}일 안에 정기 검토 기한이 오는 양식 {soon}개 — '
                f'<a href="/register/due">보기</a></div>')
    return ""


def _order_buttons(h: FormsHandler, folder_id: int, back: str) -> str:
    def one(step, label):
        return (f'<form class="inline" method="post" action="/folders/order">{_hidden(h)}'
                f'<input type="hidden" name="folder" value="{folder_id}"><input type="hidden" name="step" value="{step}">'
                f'<input type="hidden" name="back" value="{E(back)}">'
                f'<button class="btn gray sm" type="submit" title="같은 위 폴더 안에서 차례를 바꿉니다">{label}</button></form>')
    # '위로/아래로가 뭐지?' (ux20 forms 8) — 무엇의 차례인지 라벨을 붙인다
    return (f'<div class="order"><span class="muted">차례(같은 층 안에서):</span>'
            f'{one(-1, "위로")}{one(1, "아래로")}</div>')


def get_folder_move(h: FormsHandler) -> None:
    """옮기기 화면(관리 표에서 연다) — 읽기만 한다. 실제 옮기기는 POST /folders/move."""
    store, s = h.server.store, h.sess
    fid = h._int(h._one(h._query(), "folder"))
    crumbs = store.folder_path(s.user_id, fid)
    parent = crumbs[-2]["id"] if len(crumbs) >= 2 else None
    if not store.can_manage_child_of(s.user_id, parent):
        raise PermissionDenied("이 폴더를 옮길 수 있는 사람은 관리자나 위 폴더의 검토자입니다")
    trail = " / ".join(E(c["name"]) for c in crumbs)
    body = (f'<div class="crumb"><a href="/forms?folder={fid}">{trail}</a> '
            f'<span class="tag lvl">{E(level_name(len(crumbs)))}</span></div>'
            f'<div class="panel">{_move_form(h, fid)}</div>')
    h._send(200, h._shell("폴더 옮기기", body, active="/admin/folders" if s.role == "admin" else "/forms"))


def post_folder_move(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    to = h._int(h._one(f, "to"), required=False)
    try:
        h.server.store.move_folder(h.sess.user_id, fid, to, ip=h.ip)
    except (Conflict, InvalidInput) as e:            # 같은 이름이 있음·자기 하위로 — 알림 + 그 폴더로 (2026-10-30)
        h._flash("bad", f"폴더를 옮기지 않았습니다 — {e}")
        h._redirect(_folder_back(h, f, fid))
        return
    h.server.on_event("folder_moved", folder_id=fid)
    h._flash("ok", "폴더를 옮겼습니다 — 검토자 지정은 새 위치 기준으로 이어집니다")
    h._redirect(f"/forms?folder={fid}")


def post_folder_delete(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    store = h.server.store
    path = store.folder_path(h.sess.user_id, fid)
    parent = path[-2]["id"] if len(path) >= 2 else None
    back = _safe_back(h._one(f, "back")) if h._one(f, "back") else ""
    try:
        gone = store.delete_folder(h.sess.user_id, fid, ip=h.ip)
    except Conflict as e:                       # 비어 있지 않음 — 무엇이 남았는지 알리고 그 폴더로 돌아간다
        h._flash("bad", str(e))
        h._redirect(back or f"/forms?folder={fid}")
        return
    h.server.on_event("folder_deleted", folder_id=fid)
    h._flash("ok", f"폴더를 지웠습니다 ({gone})")
    h._redirect(back or (f"/forms?folder={parent}" if parent is not None else "/forms"))


def post_folder_order(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    step = -1 if h._one(f, "step") == "-1" else 1
    moved = h.server.store.move_folder_order(h.sess.user_id, fid, step, ip=h.ip)
    if not moved:
        h._flash("info", "이미 맨 " + ("앞" if step < 0 else "뒤") + "입니다")
    back = _safe_back(h._one(f, "back") or f"/forms?folder={fid}")
    h._redirect(back)


def get_folder_prune(h: FormsHandler) -> None:
    """[이 아래 빈 폴더 모두 지우기] 확인 화면 (F2-6) — 읽기만. 지울 폴더 목록·수, 양식·제출·기밀 지정이 있는 폴더는 남긴다."""
    store, s = h.server.store, h.sess
    fid = h._int(h._one(h._query(), "folder"))
    crumbs = store.folder_path(s.user_id, fid)
    rows = store.empty_subfolders(s.user_id, fid)
    trail = " / ".join(E(c["name"]) for c in crumbs)
    head = f'<div class="crumb"><a href="/forms?folder={fid}">{trail}</a></div>'
    if not rows:
        body = (head + '<div class="panel"><p class="empty">지울 빈 폴더가 없습니다 — 이 아래 폴더마다 양식·제출 기록·기밀 '
                f'지정 가운데 하나가 있습니다.</p><p><a class="btn gray" href="/forms?folder={fid}">폴더로 돌아가기</a></p></div>')
        h._send(200, h._shell("빈 폴더 지우기", body, active="/forms"))
        return
    lis = "".join(f'<li>{E(r["path"])}</li>' for r in rows[:500])
    more = f'<p class="muted">외 {len(rows) - 500}개</p>' if len(rows) > 500 else ""
    body = (head + f'<div class="panel"><div class="note warn" role="status">이 폴더 아래 빈 폴더 <b>{len(rows)}개</b>를 지웁니다. '
            f'양식(폐기 포함)·제출 기록·기밀 지정이 있는 폴더와 그 위 폴더는 남깁니다. 이 폴더 자체는 지우지 않습니다.</div>'
            f'<ul class="lines">{lis}</ul>{more}'
            f'<form method="post" action="/folders/prune">{_hidden(h)}<input type="hidden" name="folder" value="{fid}">'
            f'<input type="hidden" name="digest" value="{E(store.prune_digest(rows))}">'
            f'<label class="chk" for="pc"><input type="checkbox" id="pc" name="confirm" value="1" required>'
            f'위 빈 폴더 {len(rows)}개를 지우는 것을 확인합니다</label>'
            f'<div class="form-actions"><button class="btn red" type="submit">빈 폴더 {len(rows)}개 지우기</button>'
            f'<a class="btn gray" href="/forms?folder={fid}">그만두기</a></div></form></div>')
    h._send(200, h._shell("빈 폴더 지우기", body, active="/forms"))


def post_folder_prune(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    if h._one(f, "confirm") != "1":
        h._flash("bad", "확인 칸에 체크해야 지웁니다")
        h._redirect(f"/folders/prune?folder={fid}")
        return
    try:
        gone = h.server.store.delete_empty_subfolders(h.sess.user_id, fid, expect=h._one(f, "digest"), ip=h.ip)
    except Conflict as e:
        h._flash("bad", str(e))
        h._redirect(f"/folders/prune?folder={fid}")
        return
    if gone:
        h.server.on_event("folder_deleted", folder_id=fid)
    h._flash("ok", f"빈 폴더 {len(gone)}개를 지웠습니다" if gone else "지울 빈 폴더가 없었습니다")
    h._redirect(f"/forms?folder={fid}")


def post_folder_subscribe_all(h: FormsHandler) -> None:
    """모든 폴더 새 판 알림 켜기·끄기 — 자기 것만 (F2-4). 기밀 폴더는 볼 수 있을 때만 받는다."""
    f = h._read_form()
    h._check_token(f)
    on = h._one(f, "on") == "1"
    store = h.server.store
    store.set_subscription_all(h.sess.user_id, on)
    if on and not store.user_email(h.sess.user_id):
        h._flash("ok", "켰습니다 — 다만 내 계정에 메일 주소가 없어 알림이 가지 않습니다. 관리자에게 주소 등록을 부탁하세요")
    else:
        h._flash("ok", "볼 수 있는 모든 폴더에 새 현행 판이 생기면 메일로 알립니다" if on else "모든 폴더 새 판 알림을 껐습니다")
    h._redirect("/forms")


# ── 올리기·내 제출 ───────────────────────────────────────────────────────────

def _type_label(code: str, name: str) -> str:
    return f"{code} — {name}" if code else ""


def _type_options(types: list, selected, empty_label: str, *, keep=None) -> str:
    """문서 종류 고르기 칸 — 빈 값(empty_label) + 사용 중인 종류. keep(그 양식의 지금 종류)은 사용 중지여도 보인다."""
    out = [f'<option value=""{" selected" if selected is None else ""}>{E(empty_label)}</option>']
    for t in types:
        if not t["active"] and t["id"] != keep:
            continue
        mark = " (사용 중지)" if not t["active"] else ""
        out.append(f'<option value="{t["id"]}"{" selected" if t["id"] == selected else ""}>'
                   f'{E(_type_label(t["code"], t["name"]))}{mark}</option>')
    return "".join(out)


def _types_in_use(store: FormsStore) -> bool:
    """문서 종류 칸을 보일까 (기능 검토 F2-5) — 규칙에 {종류}가 있거나 종류가 정해진 양식·검토 대기가 있을 때만."""
    return store.doc_types_in_use()


def _accept_attr() -> str:
    """파일 고르기 칸의 accept — 실제 허용 확장자(store.ALLOWED_EXTS)에서 만든다 (2026-10-30)."""
    return ",".join(sorted(ALLOWED_EXTS))


def get_upload(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    qd = h._query()
    pick_folder = h._int(h._one(qd, "folder"), required=False)
    pick_form = h._int(h._one(qd, "form"), required=False)
    draft = h.server.draft_pop(s.token, "upload")             # 막혔던 올리기의 적은 글자 (2026-10-30 검토 — 다시 적지 않게)
    dkind = draft.get("kind", "")
    file_hint = hint_file(store.max_filename_length())       # 실제 파일 이름 한도 (검토20 r05-3)

    if not dkind and (h._one(qd, "name") or h._one(qd, "cat")):
        # 반려된 새 양식 [고쳐서 다시 올리기] — 폴더·이름·분류를 미리 채운다 (기능 검토 F2-3)
        draft, dkind = {"kind": "new", "form_name": h._one(qd, "name")[:100], "category": h._one(qd, "cat")[:50]}, "new"

    def dval(kind: str, key: str) -> str:
        return E(draft.get(key, "")) if dkind == kind else ""

    def dtype_pick(kind: str):
        v = draft.get("doc_type", "") if dkind == kind else ""
        return int(v) if v.isascii() and v.isdigit() else None
    flat = h._folders()
    paths = {n["id"]: p for n, _, p in flat}
    exts = " · ".join(sorted(e.lstrip(".") for e in ALLOWED_EXTS))   # 빈칸 — 폰에서 한 낱말로 넘치지 않게 (ux21 forms 11)
    mb = store.max_upload_bytes // (1024 * 1024)
    csrf = E(s.csrf)
    accept = E(_accept_attr())
    wait_word = "검토 대기" if store.steps_map() else "검토 중"      # 2단계 폴더가 없으면 직원 용어는 '검토 중' 하나 (F2-5)
    intro = (f'<p class="muted">올린 파일은 바로 쓰이지 않고 <b>{wait_word}</b>{"가" if wait_word.endswith("기") else "이"} 됩니다. 검토자가 승인하면 판 번호(v1, v2…)가 붙어 '
             f'현행 판이 됩니다. 올릴 수 있는 파일: <span class="exts">{E(exts)}</span> · 최대 {mb}MB</p>')
    if not flat:
        body = intro + '<div class="note warn">아직 폴더가 없습니다 — 관리자가 먼저 폴더를 만들어야 올릴 수 있습니다.</div>'
        h._send(200, h._shell("양식 올리기", f'<div class="panel">{body}</div>', active="/upload"))
        return
    two_map = store.steps_map()                              # 2단계 승인 폴더 — 올리기 전에 알게 (2026-10-31 실사용 검토)
    fopts = "".join(f'<option value="{n["id"]}"{" selected" if n["id"] == pick_folder else ""}>'
                    f'{E(p)}{" — 2단계 승인" if two_map.get(n["id"]) == 2 else ""}</option>' for n, _, p in flat)
    types = store.list_doc_types(s.user_id)                  # 문서 종류 (F7 문서 종류) — 고르기는 사용 중인 것만
    types_on = _types_in_use(store)                          # 문서 종류를 쓰지 않으면 칸을 숨긴다 (F2-5)
    new_type = ""
    if types_on and any(t["active"] for t in types):
        new_type = (f'<label for="nt">문서 종류 (선택)</label><select id="nt" name="doc_type">'
                    f'{_type_options(types, dtype_pick("new"), "(없음)")}</select>')
    name_hint = HINT_FORM_NAME_MIRROR if h.server.mirror is not None else HINT_FORM_NAME
    new_form = (f'<div class="panel"><h2>새 양식 올리기</h2>'
                f'<form method="post" action="/upload" enctype="multipart/form-data">'
                f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="kind" value="new">'
                f'<label for="nf">폴더</label><select class="wide" id="nf" name="folder_id" required>{fopts}</select>'
                f'<label for="nn">양식 이름</label><input type="text" id="nn" name="form_name" required maxlength="100" '
                f'value="{dval("new", "form_name")}" placeholder="예: 잔업집계표">{_hint(name_hint)}'
                f'<label for="nc">분류 (선택)</label><input type="text" id="nc" name="category" maxlength="50" '
                f'value="{dval("new", "category")}" placeholder="예: 인사·근태">{new_type}'
                f'<label for="nfile">파일</label><input type="file" id="nfile" name="file" required accept="{accept}">'
                f'{_hint(file_hint)}'
                f'<label for="nnote">한 줄 설명 (선택)</label><input type="text" id="nnote" name="note" maxlength="500" '
                f'value="{dval("new", "note")}" placeholder="예: 2026년 잔업 집계 양식 처음 올림">'
                f'<div class="form-actions"><button class="btn" type="submit">올리기 ({wait_word})</button></div></form></div>')
    # 개정안 고르기 — 양식이 많으면(REVISION_PICK_MAX 넘음) 폴더부터 고른다(두 단계, 스크립트 없음) (2026-10-30 M3)
    total = store.count_forms(s.user_id)
    scoped = None
    if total > REVISION_PICK_MAX:
        if pick_folder is not None:
            scoped = store.search_forms(s.user_id, "", folder_id=pick_folder, limit=REVISION_PICK_MAX + 1)
        else:
            scoped = []
        cut = len(scoped) > REVISION_PICK_MAX
        forms = [f for f in scoped if not f["retired"]][:REVISION_PICK_MAX]
        if pick_form is not None and all(f["id"] != pick_form for f in forms):
            try:
                d = store.form_detail(s.user_id, pick_form)
                if not d["retired"]:
                    forms.insert(0, d)
            except NotFound:
                pass
    else:
        forms = [f for f in store.list_forms(s.user_id) if not f["retired"]]
    folder_pick = ""
    if total > REVISION_PICK_MAX:
        fopts2 = "".join(f'<option value="{n["id"]}"{" selected" if n["id"] == pick_folder else ""}>{E(p)}</option>'
                         for n, _, p in flat)
        folder_pick = (f'<form class="pick" method="get" action="/upload">'
                       f'<label class="chk" for="rpf">먼저 폴더 고르기</label>'
                       f'<select class="wide" id="rpf" name="folder">{fopts2}</select>'
                       f'<button class="btn gray sm" type="submit">이 폴더의 양식 보기</button></form>'
                       f'<p class="muted">양식이 {total}개라 폴더(하위 포함)를 먼저 고릅니다. 양식 화면의 [개정안 올리기]를 쓰면 '
                       f'그 양식이 바로 골라져 있습니다.</p>')
        if cut:
            folder_pick += (f'<div class="note warn" role="status">이 폴더에 양식이 {REVISION_PICK_MAX}개를 넘어 이름순 앞 '
                            f'{REVISION_PICK_MAX}개만 보입니다 — 하위 폴더를 고르거나, 양식함에서 그 양식을 찾아 [개정안 올리기]를 '
                            f'누르세요.</div>')
    if forms:
        # 개정안의 종류 — ?form=로 고른 양식이면 그 양식의 종류를 미리 고른다. 빈 값 = 지금 종류 그대로.
        # type_form: 미리 고른 양식 — 양식 칸을 바꿨는데 종류를 손대지 않았으면 서버가 '그대로'로 본다(스크립트 없음)
        picked = next((f for f in forms if f["id"] == pick_form), None)
        rev_type = ""
        if types_on and (any(t["active"] for t in types) or (picked and picked["doc_type_id"] is not None)):
            keep = picked["doc_type_id"] if picked else None
            sel = dtype_pick("revision") if dkind == "revision" and draft.get("doc_type") else keep
            rev_type = (f'<label for="rt">문서 종류 (선택)</label><select id="rt" name="doc_type">'
                        f'{_type_options(types, sel, "(지금 종류 그대로)", keep=keep)}</select>'
                        + (f'<input type="hidden" name="type_form" value="{picked["id"]}">' if picked else ""))
        ropts = "".join(f'<option value="{f["id"]}"{" selected" if f["id"] == pick_form else ""}>'
                        f'{E(paths.get(f["folder_id"], ""))} / {E(f["name"])}'
                        f'{" (v" + str(f["current_number"]) + ")" if f["current_number"] else ""}</option>'
                        for f in forms)
        rev_form = (f'<div class="panel"><h2>기존 양식의 개정안 올리기</h2>{folder_pick}'
                    f'<form method="post" action="/upload" enctype="multipart/form-data">'
                    f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="kind" value="revision">'
                    f'<label for="rf">어느 양식의 개정안인가요</label><select class="wide" id="rf" name="form_id" required>'
                    f'{ropts}</select>{rev_type}'
                    f'<label for="rfile">파일</label><input type="file" id="rfile" name="file" required accept="{accept}">'
                    f'{_hint(file_hint)}'
                    f'<label for="rnote">바꾼 내용 (필수 — 대장의 \'개정 사유\'로 남습니다)</label>'
                    f'<input type="text" id="rnote" name="note" required maxlength="500" value="{dval("revision", "note")}" '
                    f'placeholder="예: 서명란 추가, 합계 칸 수식 고침">{_hint(HINT_MEMO)}'
                    f'<div class="form-actions"><button class="btn" type="submit">개정안 올리기 ({wait_word})</button></div>'
                    f'</form></div>')
    elif folder_pick:
        msg = ("이 폴더(하위 포함)에는 개정할 양식이 없습니다 — 다른 폴더를 골라 주세요." if pick_folder is not None
               else "위에서 폴더를 고르면 그 폴더의 양식이 고르기 칸에 나옵니다.")
        rev_form = f'<div class="panel"><h2>기존 양식의 개정안 올리기</h2>{folder_pick}<p class="muted">{msg}</p></div>'
    else:
        rev_form = '<div class="panel"><h2>기존 양식의 개정안 올리기</h2><p class="muted">아직 승인된 양식이 없습니다.</p></div>'
    first = rev_form + new_form if pick_form is not None else new_form + rev_form
    target = pick_folder
    if pick_form is not None:
        target = next((f["folder_id"] for f in forms if f["id"] == pick_form), target)
    if target is not None and two_map.get(target) == 2:
        intro += f'<div class="note info" role="status">{E(TWO_STEP_NOTE)}</div>'
    elif two_map:
        intro += '<p class="muted">폴더 이름 뒤에 ‘2단계 승인’이 붙은 폴더는 검토자가 검토한 뒤 승인권자가 승인해야 현행 판이 됩니다.</p>'
    h._send(200, h._shell("양식 올리기", f'<div class="panel">{intro}</div>{first}', active="/upload"))


def post_upload(h: FormsHandler) -> None:
    store = h.server.store
    n = h._length(store.max_upload_bytes + MULTIPART_SLACK)     # 본문을 읽기 전에 자른다
    try:
        bnd = boundary_of(h.headers.get("Content-Type", ""))
    except MultipartError as e:
        raise HttpError(400, str(e))
    # 본문을 읽고 푸는 올리기는 계정마다 하나·전체 UPLOAD_PARALLEL개까지 — 넘치면 읽기 전에 503 (2026-10-30, 메모리 겹침·자리 독점 막기)
    srv, uid = h.server, h.sess.user_id
    why = srv.upload_begin(uid)
    if why:
        raise HttpError(503, why)
    try:
        # 올리기 본문은 최소 1MB/초 + 60초 안에 — 느리게 보내며 자리를 쥐면 끊고 자리를 돌려준다
        body = h._read_body(n, seconds=srv.upload_floor + n / max(1, srv.upload_min_rate))
        try:
            fields, files = parse_multipart(body, bnd)
        except MultipartError as e:
            raise HttpError(400, f"올린 내용을 읽지 못했습니다 — {e}")
        del body
        _upload_parsed(h, fields, files)                # 저장까지 자리 안에서 — 파일 내용이 메모리에 겹치는 수를 묶는다
    finally:
        srv.upload_end(uid)


def _upload_parsed(h: FormsHandler, fields: dict, files: dict) -> None:
    store, s = h.server.store, h.sess
    h._check_token(fields)
    kind = h._one(fields, "kind")
    if kind not in ("new", "revision"):
        raise HttpError(400, "새 양식인지 개정안인지 골라 주세요")
    try:
        _upload_submit(h, fields, files, kind)
    except (InvalidInput, Conflict, _UploadMissing) as e:
        # 막다른 400 화면 대신 올리기 화면으로 — 적은 글자(양식 이름·분류·설명·종류)는 되살리고 파일만 다시 고른다 (2026-10-30 검토)
        h.server.draft_set(s.token, "upload", {k: h._one(fields, k) for k in
                                                ("kind", "form_name", "category", "note", "doc_type")})
        h._flash("bad", f"올리지 않았습니다 — {e} · 적은 글자는 그대로 두었습니다. 파일을 다시 골라 주세요")
        if kind == "revision" and h._one(fields, "form_id").isascii() and h._one(fields, "form_id").isdigit():
            h._redirect(f"/upload?form={int(h._one(fields, 'form_id'))}")
        elif kind == "new" and h._one(fields, "folder_id").isascii() and h._one(fields, "folder_id").isdigit():
            h._redirect(f"/upload?folder={int(h._one(fields, 'folder_id'))}")
        else:
            h._redirect("/upload")


class _UploadMissing(Exception):
    """올리기에 파일이 빠졌다 — 올리기 화면으로 돌려보낸다."""


UPLOAD_FIELDS = ("kind", "form_name", "category", "note", "doc_type", "form_id", "folder_id", "type_form")


def _upload_submit(h: FormsHandler, fields: dict, files: dict, kind: str, *, force: bool = False) -> None:
    store, s = h.server.store, h.sess
    filename, data = files.get("file", ("", b""))
    if not filename:
        raise _UploadMissing("파일을 골라 주세요")
    if not force:
        # 같은 폴더에 같은 파일 이름(또는 같은 내용)으로 검토를 기다리는 내 제출이 있으면 먼저 묻는다 (기능 검토 F2-1)
        target_form = h._int(h._one(fields, "form_id"), required=False) if kind == "revision" else None
        target_folder = h._int(h._one(fields, "folder_id"), required=False) if kind == "new" else None
        same = store.my_similar_pending(s.user_id, filename=filename, data=data, folder_id=target_folder,
                                        form_id=target_form)
        # 같은 대상·같은 내용이면 store가 '같은 파일이 이미 검토 대기 중'으로 거절한다 — 그것은 묻지 않고 그대로 거절
        from watcher.forms.store import name_key
        sha = hashlib.sha256(bytes(data)).hexdigest()
        want_key = name_key(h._one(fields, "form_name").strip()) if kind == "new" else None
        same = [x for x in same if not (x["sha256"] == sha and (
            (kind == "revision" and x["form_id"] == target_form)
            or (kind == "new" and x["form_id"] is None and x["kind"] == "new" and name_key(x["form_name"]) == want_key)))]
        if same:
            key = h.server.upload_stash_put(s.user_id, s.token,
                                            {"fields": {k: list(fields.get(k, [])) for k in UPLOAD_FIELDS},
                                             "filename": filename, "data": bytes(data), "kind": kind})
            if not key:                     # 보관 자리(전체 바이트 상한)가 찼다 — 들고 있지 않고 안내만 (rr066 lan 3)
                h.server.draft_set(s.token, "upload", {k: h._one(fields, k) for k in
                                                        ("kind", "form_name", "category", "note", "doc_type")})
            _upload_dup_page(h, same, key)
            return
    note = h._one(fields, "note")
    dtype = h._int(h._one(fields, "doc_type"), required=False)          # 문서 종류 (선택, F7 문서 종류)
    if kind == "revision":
        form_id = h._int(h._one(fields, "form_id"))
        tf = h._int(h._one(fields, "type_form"), required=False)
        if dtype is not None and tf is not None and tf != form_id:
            # 미리 고른 양식과 다른 양식을 골랐는데 종류는 미리 채운 그대로 → 그 종류를 옮겨 붙이지 않는다
            try:
                prev = store.form_detail(s.user_id, tf)
            except NotFound:
                prev = None
            if prev is not None and prev["doc_type_id"] == dtype:
                dtype = None
        res = store.submit(s.user_id, data=data, filename=filename, form_id=form_id,
                           note=note, ip=h.ip, doc_type=dtype)
    else:
        res = store.submit(s.user_id, data=data, filename=filename,
                           folder_id=h._int(h._one(fields, "folder_id")),
                           form_name=h._one(fields, "form_name"), category=h._one(fields, "category"),
                           note=note, ip=h.ip, doc_type=dtype)
    h._flash("ok", f"올렸습니다 — {'검토 대기' if store.steps_map() else '검토 중'} (제출 {res['id']}번). "
                   f"검토자가 승인하면 현행 판이 됩니다")
    h._redirect("/mine")


def _upload_dup_page(h: FormsHandler, same: list, key: str) -> None:
    """같은 폴더에 같은 이름·내용의 내 검토 대기가 있을 때 — 경고 + [그래도 올리기] (F2-1). 아직 아무것도 저장하지 않았다."""
    lis = "".join(f'<li>제출 {x["id"]}번 — {E(x["form_name"])} · {E(x["filename"])} · {E(_fmt_time(x["submitted_at"]))}</li>'
                  for x in same[:10])
    body = (f'<div class="panel"><div class="note warn" role="status"><b>이미 검토를 기다리는 내 제출이 있습니다</b> — 같은 폴더에 '
            f'같은 파일 이름이나 같은 내용으로 올린 것입니다. 올린 양식은 승인되기 전까지 폴더 목록에 보이지 않습니다 '
            f'(<a href="/mine">내 제출</a>에서 볼 수 있습니다).</div><ul class="lines">{lis}</ul>'
            f'<p class="muted">고친 파일을 다시 올리려는 것이면 앞의 제출을 [취소]하고 올리면 검토자가 헷갈리지 않습니다.</p>'
            + (f'<form method="post" action="/upload/confirm">{_hidden(h)}<input type="hidden" name="key" value="{E(key)}">'
               f'<div class="form-actions"><button class="btn" type="submit">그래도 올리기</button>'
               f'<a class="btn gray" href="/mine">내 제출 보기 (올리지 않음)</a></div></form></div>' if key else
               # 보관 자리가 찼을 때 — 파일을 들고 있지 않으므로 [그래도 올리기]가 없다 (재검토 rr066 lan 3)
               f'<div class="note info" role="status">지금은 이 파일을 잠깐 들고 있을 자리가 없어 올리지 않았습니다 — '
               f'<b>앞 제출을 취소하고 다시 올리세요</b>. 같이 올리려면 잠시 뒤 다시 올려 주세요.</div>'
               f'<div class="form-actions"><a class="btn" href="/mine">내 제출 보기 (취소하러)</a>'
               f'<a class="btn gray" href="/upload">다시 올리기</a></div></div>'))
    h._send(200, h._shell("이미 검토를 기다리는 제출이 있습니다", body, active="/upload"))


def post_upload_confirm(h: FormsHandler) -> None:
    """[그래도 올리기] — 메모리에 잠깐 둔 파일로 올리기를 마친다. 시간이 지났거나 다른 세션이면 다시 올리게 한다."""
    f = h._read_form()
    h._check_token(f)
    # 올리기와 같은 동시 상한 안에서 저장한다 — 자리를 못 잡으면 보관은 그대로 두고 503 (재검토 rr066 lan 4)
    srv, s = h.server, h.sess
    why = srv.upload_begin(s.user_id)
    if why:
        raise HttpError(503, why)
    try:
        got = srv.upload_stash_pop(s.user_id, s.token, h._one(f, "key"))
        if got is None:
            h._flash("bad", "올리려던 파일을 더 들고 있지 않습니다(15분이 지났거나 다른 올리기를 했음) — 파일을 다시 골라 주세요")
            h._redirect("/upload")
            return
        files = {"file": (got["filename"], got["data"])}
        try:
            _upload_submit(h, got["fields"], files, got["kind"], force=True)
        except (InvalidInput, Conflict, _UploadMissing) as e:
            h._flash("bad", f"올리지 않았습니다 — {e}")
            h._redirect("/upload")
    finally:
        srv.upload_end(s.user_id)


# ── 현행 판 확인 (기능 검토 F2-11, 2026-11-02) — 누구나(로그인): '이 파일이 현행 판인가?' ─────────────────────
# 파일을 올리면 저장하지 않고 sha256만 판 지문과 견준다. 볼 수 없는 폴더의 양식은 '양식함에 없는 파일'과 같은 답.

def _check_form_html(h: FormsHandler) -> str:
    mb = h.server.store.max_upload_bytes // (1024 * 1024)
    return (f'<form method="post" action="/check" enctype="multipart/form-data">{_hidden(h)}'
            f'<label for="cf">확인할 파일</label><input type="file" id="cf" name="file" required>'
            f'{_hint(f"최대 {mb}MB · 파일은 저장하지 않고 지문(sha256)만 견줍니다")}'
            f'<div class="form-actions"><button class="btn" type="submit">현행 판인지 확인</button></div></form>')


CHECK_CANDIDATES = 3          # '양식함에 없는 파일'일 때 이름이 비슷한 양식을 몇 개까지 (ux20 forms 3)


def _name_bits(filename: str) -> tuple[str, list]:
    """파일 이름 → (접은 전체, 낱말들). 확장자·'[지난 판 v1]' 머리·숫자만인 낱말·날짜 꼬리('11월')는 뺀다."""
    from watcher.forms.store import search_key
    stem = Path(str(filename or "")).stem
    stem = re.sub(r"^\s*\[[^\]]*\]\s*", "", stem)                 # '[지난 판 v1] 잔업집계표' → '잔업집계표'
    words = []
    for w in re.split(r"[\s_\-.,()\[\]{}+~·]+", stem):
        w = re.sub(r"\d+(월|일|년|차|부|번|호|판)?$", "", w)          # '11월'·'2026'·'v2' 꼬리
        w = re.sub(r"(?i)v$|rev$", "", w)
        k = search_key(w)
        if len(k) >= 2 and not k.isdigit():
            words.append(k)
    return search_key(stem), words


TITLE_READ_MAX = 256 * 1024       # 첫 시트 제목 읽기 — 압축을 푼 글자에서 앞 이만큼만 훑는다
TITLE_PART_MAX = 8 * 1024 * 1024  # 시트·공유 문자열 한 조각의 풀린 크기 상한 — 넘으면 제목 없이 (압축 폭탄·큰 파일)
TITLE_CELLS = 3                   # 첫 시트 앞쪽 글자 칸 몇 개를 제목으로 보나
TITLE_SCAN_ITEMS = 50000          # 훑는 칸·문단 수 상한 — 테두리만 친 빈칸이 수만 개인 양식
TITLE_SCAN_SECS = 0.5             # 훑는 시간 상한 — 올리기 자리를 쥔 채 도는 일이라 넘으면 찾은 데까지만


def _xml_items(xml: str, tag: str):
    """'<tag …>내용</tag>'을 앞에서부터 (속성, 내용)으로 — 정규식 대신 find로 한 번만 지나간다. 자기닫힘 '<c r="A1" s="1"/>'은 건너뛴다:
    여는 태그로 보아 다음 칸의 글자를 삼켰고(A1 테두리 빈칸·B1 제목 → 제목 없음), 닫는 태그까지 되풀이해 훑어 44KB 양식에 25초가 걸렸다
    (ux22 forms 2). 닫는 태그가 없으면 거기서 끝 — 뒤에도 없으므로 다시 훑지 않는다."""
    op, cl = f"<{tag}", f"</{tag}>"
    pos = 0
    for _n in range(TITLE_SCAN_ITEMS):
        a = xml.find(op, pos)
        if a < 0:
            return
        after = a + len(op)
        if xml[after:after + 1] not in (" ", "\t", "\r", "\n", "/", ">"):      # <cols>·<w:pPr> — 다른 태그
            pos = after
            continue
        e = xml.find(">", after)
        if e < 0:
            return
        if xml[e - 1] == "/":
            pos = e + 1
            continue
        end = xml.find(cl, e)
        if end < 0:
            return
        yield xml[after:e], xml[e + 1:end]
        pos = end + len(cl)


def _strip_tags(s: str) -> str:
    return re.sub(r"<[^<>]*>", "", s)          # [^<>] — '<'만 잔뜩 든 칸에서 되풀이해 훑지 않게


def first_sheet_title(filename: str, data) -> str:
    """(ux21 forms 8) 엑셀 첫 시트·워드 첫 문단의 앞쪽 글자 몇 칸 — 파일 이름에 양식 이름이 없을 때 후보를 한 번 더 찾으려고.
    메모리에서 zip 목차만 열고 정해진 만큼만 풀어 읽는다(디스크 쓰기 없음). 못 읽으면 빈 글자 — 결과 화면을 막지 않는다."""
    import io
    import zipfile
    ext = Path(str(filename or "")).suffix.lower()
    try:
        z = zipfile.ZipFile(io.BytesIO(bytes(data)))
        names = set(z.namelist())

        def part(name: str) -> str:
            # 밝힌 크기가 상한을 넘으면 읽지 않는다. 밝힌 크기는 믿지 못한다 — 실제로도 앞 TITLE_READ_MAX만 푼다(z.read는 전부 풀고 잘라,
            # 298KB zip이 메모리 600MB를 썼다, ux22 forms 1). zipfile.Path도 쓰지 않는다 — 처음 열 때 모든 항목의 상위 폴더 문자열을 만들어
            # 이름이 긴 빈 항목 둘 든 250KB zip이 2GB를 썼다 (ux22 vx-check 1). 읽는 양이 묶이는 것은 DEFLATE·저장뿐이다 — bz2·LZMA는 읽은 압축
            # 조각을 다 푼 뒤 잘라 1KB zip이 1GB를 썼다 (ux22 vy-check 1). 진짜 xlsx·docx는 이 두 방식만 쓴다
            if name not in names:
                return ""
            info = z.getinfo(name)
            if info.file_size > TITLE_PART_MAX or info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                return ""
            with z.open(name) as fp:
                return fp.read(TITLE_READ_MAX).decode("utf-8", "ignore")
        if ext in (".xlsx", ".xlsm", ".xltx", ".xltm"):
            sheet = part("xl/worksheets/sheet1.xml")
            shared = None
            out = []
            until = time.monotonic() + TITLE_SCAN_SECS
            for attrs, body in _xml_items(sheet, "c"):
                if time.monotonic() > until:
                    break
                if 't="s"' in attrs:
                    v = re.search(r"<v>(\d+)</v>", body)
                    if v is None:
                        continue
                    if shared is None:
                        shared = [_strip_tags(x) for _a, x in _xml_items(part("xl/sharedStrings.xml"), "si")]
                    i = int(v.group(1))
                    txt = shared[i] if i < len(shared) else ""
                elif 't="inlineStr"' in attrs or 't="str"' in attrs:
                    txt = _strip_tags(body)
                else:
                    continue
                txt = html.unescape(txt).strip()
                if len(search_key_of(txt)) >= 2 and not search_key_of(txt).isdigit():
                    out.append(txt)
                if len(out) >= TITLE_CELLS:
                    break
            return " ".join(out)[:200]
        if ext in (".docx", ".dotx", ".dotm"):
            doc = part("word/document.xml")
            out = []
            for _a, p in _xml_items(doc, "w:p"):
                txt = html.unescape("".join(re.findall(r"<w:t(?:\s[^<>]*)?>([^<]*)</w:t>", p))).strip()
                if len(search_key_of(txt)) >= 2:
                    out.append(txt)
                if len(out) >= 1:
                    break
            return " ".join(out)[:200]
    except Exception:                    # 깨진 파일·zip 아님 — 제목 없이 넘어간다
        return ""
    return ""


def search_key_of(s) -> str:
    from watcher.forms.store import search_key
    return search_key(s)


def _check_candidates(h: FormsHandler, filename: str, title: str = "") -> str:
    """'양식함에 없는 파일'일 때 파일 이름으로 비슷한 양식 후보 — 그 사람이 볼 수 있는 양식만(list_forms가 기밀 폴더를 거른다).
    양식 이름이 파일 이름 안에 들었거나, 파일 이름 낱말이 양식 이름 안에 들었으면 후보. 파일 이름으로 하나도 없으면
    첫 시트 제목 글자(title, ux21 forms 8)로 한 번 더. 그래도 없으면 [양식함에서 찾기] 단추."""
    whole, words = _name_bits(filename)
    found = _cand_items(h, whole, words) if (whole or words) else []
    how = "파일 이름이 비슷한 양식"
    if not found and title:
        tw = [search_key_of(w) for w in re.split(r"[\s_\-.,()\[\]{}+~·:/]+", title)]
        found = _cand_items(h, search_key_of(title), [w for w in tw if len(w) >= 2 and not w.isdigit()])
        how = f"첫 시트 제목('{E(title[:40])}')이 비슷한 양식"
    if not found:
        q = (title.split() or [""])[0] if title else ""
        if not q:
            q = next((w for w in re.split(r"[\s_\-.,()\[\]{}+~·]+", Path(str(filename or "")).stem)
                      if len(w) >= 2 and not w.isdigit()), "")
        href = "/forms" + (f"?q={quote(q[:30])}" if q else "")
        return ('<div class="cands"><p class="muted">파일 이름' + (" · 첫 시트 제목" if title else "")
                + '으로는 비슷한 양식을 찾지 못했습니다. 양식함에서 양식 이름으로 찾아 현행 판을 받아 쓰세요.</p>'
                f'<p class="form-actions"><a class="btn" href="{E(href)}">양식함에서 찾기</a></p></div>')
    return (f'<div class="cands"><h3>이 양식인가요? — {how}</h3>'
            '<p class="muted">값을 채운 파일은 원본과 내용이 달라 몇 판인지 알 수 없습니다. 아래가 맞는 양식이고 내 파일이 '
            '현행 판보다 오래됐을 수 있으면, 현행 판을 받아 다시 작성하세요.</p>'
            f'<ul class="lines">{"".join(found)}</ul></div>')


def _cand_items(h: FormsHandler, whole: str, words: list) -> list:
    from watcher.forms.store import search_key
    scored = []
    for f in h.server.store.list_forms(h.sess.user_id, limit=5000):
        if not f["current_version_id"]:
            continue
        k = search_key(f["name"])
        if len(k) < 2:
            continue
        if k in whole:
            score = 100 + len(k)                                        # 양식 이름이 통째로 든 것이 먼저
        else:
            hit = [w for w in words if w in k]
            if not hit:
                continue
            score = sum(len(w) for w in hit) * 100 // max(len(k), 1)   # 양식 이름을 얼마나 덮나
            if score < 40:
                continue
        scored.append((-score, k, f))
    scored.sort(key=lambda x: (x[0], x[1]))
    items = []
    for _s, _k, f in scored[:CHECK_CANDIDATES]:
        no = f'<span class="docno">{E(f["doc_no"])}</span> ' if f.get("doc_no") else ""
        items.append(f'<li>{no}<b>{E(f["name"])}</b> — 현행 v{f["current_number"]} '
                     f'({E(str(f["current_approved_at"] or "")[:10])} 승인) '
                     f'<a class="btn sm" href="/download?v={f["current_version_id"]}">현행 판 받기</a> '
                     f'<a class="gap" href="/form?id={f["id"]}">판 이력</a></li>')
    return items


def get_check(h: FormsHandler) -> None:
    body = (f'<div class="panel"><p class="muted">PC에 있는 양식 파일이 지금 쓰는 판(현행 판)인지 확인합니다. 메일로 받았거나 '
            f'예전에 내려받아 둔 파일을 올려 보세요. 내용이 한 글자라도 다르면 \'양식함에 없는 파일\'로 나옵니다.</p>'
            f'{_check_form_html(h)}</div>')
    h._send(200, h._shell("현행 판 확인", body, active="/check"))


def post_check_file(h: FormsHandler) -> None:
    store = h.server.store
    n = h._length(store.max_upload_bytes + MULTIPART_SLACK)
    try:
        bnd = boundary_of(h.headers.get("Content-Type", ""))
    except MultipartError as e:
        raise HttpError(400, str(e))
    srv, uid = h.server, h.sess.user_id
    why = srv.upload_begin(uid)                     # 올리기와 같은 자리 상한 (메모리)
    if why:
        raise HttpError(503, why)
    try:
        body = h._read_body(n, seconds=srv.upload_floor + n / max(1, srv.upload_min_rate))
        try:
            fields, files = parse_multipart(body, bnd)
        except MultipartError as e:
            raise HttpError(400, f"올린 내용을 읽지 못했습니다 — {e}")
        del body
        h._check_token(fields)
        name, data = files.get("file", ("", b""))
        if not name or not data:
            h._flash("bad", "확인할 파일을 골라 주세요")
            h._redirect("/check")
            return
        if len(data) > store.max_upload_bytes:          # 올리기와 같은 상한 — multipart 여유(1MB)만큼 더 받던 것 (rr066 lan 5)
            raise HttpError(413, f"파일이 너무 큽니다 (최대 {store.max_upload_bytes // (1024 * 1024)}MB)")
        sha = hashlib.sha256(bytes(data)).hexdigest()
        hits = store.find_by_sha(uid, sha)
        # 없는 파일이면 첫 시트 제목 글자를 메모리에서만 읽어 둔다 — 파일 이름에 양식 이름이 없을 때 후보용 (ux21 forms 8)
        title = first_sheet_title(name, data) if not hits else ""
        del data, files
    finally:
        srv.upload_end(uid)
    if not hits:
        res = (f'<div class="note warn" role="status"><b>양식함에 없는 파일입니다</b> — {E(name)}. 승인된 어느 판과도 내용이 '
               f'같지 않습니다(값을 채웠거나 고친 파일, 다른 곳에서 받은 파일). 양식함에서 찾아 현행 판을 받아 쓰세요.</div>'
               + _check_candidates(h, name, title))
    else:
        out = []
        for x in hits:
            label = (f'<span class="docno">{E(x["doc_no"])}</span> ' if x["doc_no"] else "") + \
                f'<b>{E(x["form_name"])} v{x["number"]}</b>'
            when = E(str(x["current_approved_at"])[:10])
            get = (f' <a class="btn sm" href="/download?v={x["current_version_id"]}">현행 판 받기</a>'
                   if x["current_version_id"] else "")
            if x["retired"]:
                out.append(f'<div class="note warn">{label} — <b>폐기된 양식</b>입니다. 새로 쓰지 마세요. '
                           f'<a href="/form?id={x["form_id"]}">양식 보기</a></div>')
            elif x["current"]:
                out.append(f'<div class="note ok">{label} — <b>현행 판</b>입니다 ({when} 승인). 그대로 쓰면 됩니다. '
                           f'<a href="/form?id={x["form_id"]}">양식 보기</a></div>')
            else:
                out.append(f'<div class="note warn">{label} — <b>지난 판</b>입니다. 현행은 v{x["current_number"]}'
                           f' ({when} 승인).{get} <a class="gap" href="/form?id={x["form_id"]}">판 이력</a></div>')
        res = "".join(out)
    body = (f'<div class="panel"><h2>결과 — {E(name)}</h2>{res}</div>'
            f'<div class="panel"><h2>다른 파일 확인</h2>{_check_form_html(h)}</div>')
    h._send(200, h._shell("현행 판 확인", body, active="/check"))


def _status_tag(st: str) -> str:
    return f'<span class="tag {E(st)}">{E(STATUS_LABEL.get(st, st))}</span>'


def get_mine(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    subs = store.list_submissions(s.user_id, scope="mine", limit=300)
    csrf = E(s.csrf)
    codes = {t["id"]: t["code"] for t in store.list_doc_types(s.user_id)}          # 고른 문서 종류 (F7 문서 종류 검토 4)
    form_types = store.form_doc_types(s.user_id, (x["form_id"] for x in subs))      # 필요한 양식만 (2026-10-30)
    two_any = bool(store.steps_map())
    show_types = _types_in_use(store)
    rows = []
    for x in subs:
        act = ""
        if x["status"] == "pending":
            act = (f'<form class="inline" method="post" action="/submissions/cancel">'
                   f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="id" value="{x["id"]}">'
                   f'<button class="btn gray sm" type="submit">취소</button></form>')
        elif x["status"] == "approved" and x["form_id"] and x["form_id"] in form_types:   # 볼 수 없는 기밀 폴더면 링크 없음
            act = f'<a href="/form?id={x["form_id"]}">양식 보기</a>'
        elif x["status"] == "rejected":                # 반려 뒤 다시 올리기 (기능 검토 F2-3) — 새 양식은 폴더·이름을 미리 채운다
            if x["kind"] == "revision" and x["form_id"]:
                again = f'/upload?form={x["form_id"]}'
            else:
                again = (f'/upload?folder={x["folder_id"]}&name={quote(x["form_name"] or "")}'
                         + (f'&cat={quote(x["category"])}' if x.get("category") else ""))
            act = f'<a class="btn gray sm" href="{E(again)}">고쳐서 다시 올리기</a>'
        # 줄마다 누가 무엇을 했는지 머리를 붙인다 — '검토: 이름 · 때', '반려: 이름 · 때 — 사유' (2026-10-31 실사용 검토)
        why, who = "", ""
        if x.get("decision_note"):
            why += f'<div class="muted pre">승인 메모: {E(x["decision_note"])}</div>'
        if x["decided_at"]:
            stamp = f'{E(x["decided_by_name"])} · {E(_fmt_time(x["decided_at"]))}'
            label = DECIDED_LABEL.get(x["status"], "처리")
            if x["status"] == "rejected":
                who = (f'<div class="muted pre">{label}: {stamp}'
                       + (f' — {E(x["reason"])}' if x["reason"] else "") + '</div>')
            else:
                who = f'<div class="muted">{label}: {stamp}</div>'
        elif x["reason"]:
            why = f'<div class="muted pre">반려 사유: {E(x["reason"])}</div>' + why
        status = _status_tag(x["status"])
        if x["status"] == "pending" and not two_any:   # 2단계 폴더가 없으면 직원 화면 용어는 '검토 중' 하나 (F2-5)
            status = '<span class="tag pending">검토 중</span>'
        if x.get("checked_at"):                    # 2단계 승인 — 검토 완료(승인 대기)·검토한 사람
            if x.get("stage") == "approve":
                status = '<span class="tag awaiting">승인 대기</span>'
            who = (f'<div class="muted">검토: {E(x["checked_by_name"])} · {E(_fmt_time(x["checked_at"]))}</div>'
                   + (f'<div class="muted pre">검토 메모: {E(x["check_memo"])}</div>' if x.get("check_memo") else "")
                   + who)
        elif x.get("stage") == "check":
            who = '<div class="muted">2단계 승인 — 검토 뒤 승인권자가 승인합니다</div>' + who
        rows.append(f'<tr><td class="nw">{x["id"]}</td><td class="name-c">{E(x["form_name"])}<div class="muted">'
                    f'{E(KIND_LABEL.get(x["kind"], x["kind"]))}</div>'
                    f'{_sub_type_short(x, codes, form_types, warn_empty=False) if show_types else ""}</td>'
                    f'<td>{E(x["filename"])}<div class="muted">{_fmt_size(x["size"])}</div></td>'
                    f'<td>{E(x["note"])}</td><td class="nw">{E(_fmt_time(x["submitted_at"]))}</td>'
                    f'<td>{status}{who}{why}</td><td class="nw acts">{act}</td></tr>')
    table = ("<div class=\"tablewrap\"><table class=\"mine\"><thead><tr><th>번호</th><th>양식</th><th>파일</th><th>설명</th><th>올린 때</th>"
             "<th>상태</th><th></th></tr></thead><tbody>" + "".join(rows) + "</tbody></table></div>") if rows else \
        '<p class="empty">아직 올린 것이 없습니다</p>'
    h._send(200, h._shell("내 제출", f'<div class="panel">{table}</div>', active="/mine",
                          actions='<a class="btn" href="/upload">양식 올리기</a>'))


def post_cancel(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    h.server.store.cancel(h.sess.user_id, sid, ip=h.ip)
    h._flash("ok", f"제출 {sid}번을 취소했습니다")
    h._redirect("/mine")


# ── 양식 상세·내려받기 ──────────────────────────────────────────────────────

def get_form(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    fid = h._int(h._one(h._query(), "id"))
    d = store.form_detail(s.user_id, fid)
    trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in d["folder_path"])
    meta = []
    if d.get("doc_no"):
        meta.append(f'문서번호 <b class="docno">{E(d["doc_no"])}</b>')
    if d.get("type_mismatch") and s.role in ("admin", "reviewer"):      # 번호의 종류와 다름 (F7 문서 종류 검토 7)
        meta.append(f'<span class="muted">{MISMATCH_TEXT}</span>')
    if d.get("prev_doc_nos"):                                 # 다시 매기기 전 번호 (F7 번호 규칙)
        meta.append(f'이전 번호 <span class="docno">{E(", ".join(d["prev_doc_nos"]))}</span>')
    if d.get("doc_type"):                                     # 문서 종류 (F7 문서 종류) — 종류가 있으면 쓰는 중이라 보인다
        meta.append(f'문서 종류 <span class="tag dtype">{E(d["doc_type"])}</span>{E(d["doc_type_name"])}'
                    + ("" if d.get("doc_type_active", True) else " (사용 중지된 종류)"))
    if d["category"]:
        meta.append(f'분류 {E(d["category"])}')
    meta.append(f'현행 v{d["current_number"]}' if d["current_number"] else "현행 판 없음")
    if d["pending"]:
        meta.append(f'검토 대기 {d["pending"]}건')
    retired = ""
    if d["retired"]:
        who = " · ".join(x for x in (d.get("retired_by_name") or "", _fmt_time(d.get("retired_at"))) if x)
        retired = (f'<div class="note warn" role="status"><b>폐기된 양식입니다</b> — 목록에서는 숨겨지고 기록으로 남습니다. '
                   f'내려받을 수는 있지만 새로 쓰지 마세요.'
                   + (f'<div class="pre">폐기 사유: {E(d["retired_reason"])}</div>' if d.get("retired_reason") else "")
                   + (f'<div class="muted">{E(who)}</div>' if who else "") + '</div>')
    versions = d["versions"]                                  # 최신 판부터
    dl_mark = ' <span class="tag retired">폐기된 양식</span>' if d["retired"] else ""
    rows = []
    for k, v in enumerate(versions):
        cur = (' <span class="tag approved">현행</span>' if v["id"] == d["current_version_id"] else
               ' <span class="tag off" title="내려받으면 파일 이름 앞에 [지난 판]이 붙습니다">현행 아님</span>')
        prev = versions[k + 1] if k + 1 < len(versions) else None
        cmp_link = (f'<a class="btn gray sm" href="/compare?form={fid}&amp;a={prev["id"]}&amp;b={v["id"]}" '
                    f'title="전 판(v{prev["number"]})과 비교">v{prev["number"]}과 비교</a>') \
            if prev and not prev.get("purged_at") and not v.get("purged_at") else ""
        if v.get("purged_at"):                    # 보존 기간이 지나 정리한 판 — 파일 없음, 기록만 (2026-10-30)
            who = " · ".join(x for x in (_fmt_time(v["purged_at"]), v.get("purged_by_name") or "") if x)
            dl_cell = (f'<span class="tag off" title="보존 기간이 지나 파일을 지웠습니다 — 판 기록만 남음">정리됨</span>'
                       f'<div class="muted">{E(who)}</div>')
        else:
            dl_cell = f'<a class="btn sm" href="/download?v={v["id"]}">내려받기</a>{dl_mark} {cmp_link}'
        # 판·날짜·사람 이름 칸은 줄바꿈하지 않고(nw), 설명·파일 칸이 줄어든다 — 1024px에서 '이검토'가 한 글자씩 꺾이던 것 (f6)
        # 현행 기간 (ux21 forms 5) — 이 판이 승인된 때부터 다음 판이 승인될 때까지. 현행이면 '지금'(폐기된 양식이면 폐기일)
        newer = versions[k - 1] if k > 0 else None
        if v["id"] == d["current_version_id"]:
            end = f'폐기 {_fmt_time(d.get("retired_at"))[:10]}' if d["retired"] and d.get("retired_at") else (
                "폐기" if d["retired"] else "지금")
        else:
            end = _fmt_time(newer["approved_at"]) if newer is not None else ""
        period = (f'<div class="muted period">현행 기간: {E(_fmt_time(v["approved_at"]))} ~ {E(end)}</div>'
                  if end else "")
        rows.append(f'<tr><td class="nw"><b>v{v["number"]}</b>{cur}</td>'
                    f'<td class="dt">{E(_fmt_time(v["approved_at"]))}{period}</td>'
                    f'<td><span class="nw">{E(v["uploaded_by_name"])}</span>'
                    f'<div class="muted dt">{E(_fmt_time(v["uploaded_at"]))}</div></td>'
                    f'<td class="nw">{E(v["approved_by_name"])}'
                    + (' <span class="muted" title="올린 사람이 직접 승인했습니다">(본인 승인)</span>'
                       if v.get("uploaded_by") is not None and v.get("uploaded_by") == v.get("approved_by") else "")   # F2-9
                    + (f'<div class="muted">1단계 검토: {E(v["checked_by_name"])}</div>' if v.get("checked_by") else "")
                    + f'</td><td class="note-c">{E(v["note"])}</td>'
                    f'<td class="file-c">{E(v["filename"])}<div class="muted">{_fmt_size(v["size"])}</div></td>'
                    f'<td class="acts">{dl_cell}</td></tr>')
    table = ('<div class="tablewrap"><table class="hist"><thead><tr><th>판</th><th>승인한 날</th><th>올린 사람</th>'
             '<th>승인자</th><th>설명</th><th>파일</th><th></th></tr></thead><tbody>' + "".join(rows)
             + "</tbody></table></div>") if rows else '<p class="empty">아직 승인된 판이 없습니다</p>'
    # 휴대폰 폭에서는 현행 판 [내려받기]를 표 위 큰 단추로 따로 (ux20 forms 1 — 표 가로 스크롤 밖에 숨던 것)
    cur_v = next((v for v in versions if v["id"] == d["current_version_id"] and not v.get("purged_at")), None)
    if cur_v is not None:
        table = (f'<div class="curdl narrow"><a class="btn big" href="/download?v={cur_v["id"]}">현행 판 v{cur_v["number"]} '
                 f'내려받기</a><span class="muted">{E(cur_v["filename"])} · {_fmt_size(cur_v["size"])}'
                 + (' · 폐기된 양식' if d["retired"] else "") + '</span></div>' + table)
    pick = ""
    if len(versions) >= 2:
        pick = (f'<h3>판끼리 비교</h3><p class="muted">두 판을 골라 무엇이 바뀌었는지 근거 표(이전 값 / 새 값 / 위치)로 봅니다.</p>'
                + _version_picker(fid, versions, versions[1]["id"], versions[0]["id"], s.csrf))
    tools = ""
    if store.is_reviewer_of(s.user_id, d["folder_id"]):
        csrf = E(s.csrf)
        if d["retired"]:
            tools = (f'<details class="tool"><summary>양식 복원</summary>'
                     f'<form method="post" action="/form/restore"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{fid}"><label for="rs">복원 사유 (필수)</label>'
                     f'<textarea id="rs" name="reason" required maxlength="500" placeholder="예: 새 양식 적용을 미룸">'
                     f'</textarea>{_hint(HINT_MEMO + " · 여러 줄 가능")}'
                     f'<div class="form-actions"><button class="btn sm" type="submit">복원하기</button></div></form></details>')
        else:
            tools = (f'<details class="tool"><summary>양식 폐기</summary>'
                     f'<p class="muted">폐기하면 목록에서 숨겨지고 개정안을 받지 않습니다. 판 파일은 그대로 남고 언제든 복원할 수 있습니다.</p>'
                     f'<form method="post" action="/form/retire"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{fid}"><label for="rt">폐기 사유 (필수)</label>'
                     f'<textarea id="rt" name="reason" required maxlength="500" placeholder="예: 2027년 양식으로 바뀜">'
                     f'</textarea>{_hint(HINT_MEMO + " · 여러 줄 가능")}'
                     f'<div class="form-actions"><button class="btn red sm" type="submit">폐기하기</button></div></form></details>')
        types_tool = _doctype_tool(h, d) if _types_in_use(store) else ""     # 문서 종류를 안 쓰면 숨김 (F2-5)
        tools = (f'<div class="panel"><h2>검토자 도구</h2>{_review_panel(h, d)}{types_tool}{tools}'
                 f'{_move_form_tool(h, d)}{_docno_tool(h, d)}</div>')
    actions = "" if d["retired"] else f'<a class="btn" href="/upload?form={fid}">개정안 올리기</a>'
    body = (f'<div class="crumb"><a href="/forms">전체</a> / {trail}</div>{retired}'
            f'<div class="panel"><p class="muted">{" · ".join(meta)}</p><h3>판 이력</h3>{table}{pick}</div>{tools}')
    h._send(200, h._shell(d["name"], body, active="/forms", actions=actions))


def _move_form_tool(h: FormsHandler, d: dict) -> str:
    """[다른 폴더로 옮기기] (기능 검토 F2-7) — 관리자, 또는 원래 폴더와 새 폴더 둘 다의 검토자. 폐기한 양식도 옮길 수 있다
    (빈 폴더를 지우려면 폐기한 양식도 옮겨야 한다). 판·제출 기록·문서번호는 그대로 따라간다."""
    store, s = h.server.store, h.sess
    mine = store.reviewable_folders(s.user_id)
    opts = [(n["id"], p) for n, _d, p in h._folders()
            if n["id"] != d["folder_id"] and (mine is None or n["id"] in mine)]
    if not opts:
        return ""
    o = "".join(f'<option value="{fid}">{E(p)}</option>' for fid, p in opts)
    return (f'<details class="tool"><summary>다른 폴더로 옮기기</summary>'
            f'<p class="muted">판 이력·제출 기록·문서번호는 그대로 따라갑니다. 옮길 폴더에 같은 이름의 양식이 있으면 옮기지 않습니다.</p>'
            f'<form class="inline" method="post" action="/form/move">{_hidden(h)}<input type="hidden" name="id" value="{d["id"]}">'
            f'<select class="wide" name="folder" aria-label="옮길 폴더">{o}</select>'
            f'<button class="btn gray sm" type="submit">옮기기</button></form></details>')


def post_form_move(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    to = h._int(h._one(f, "folder"))
    store = h.server.store
    try:
        store.move_form(h.sess.user_id, fid, to, ip=h.ip)
    except (Conflict, InvalidInput) as e:
        store.form_detail(h.sess.user_id, fid)                  # 없는 양식이면 404
        h._flash("bad", f"옮기지 않았습니다 — {e}")
        h._redirect(f"/form?id={fid}")
        return
    h.server.on_event("folder_moved", folder_id=to)            # 현행 미러 다시 맞추기
    h._flash("ok", "양식을 옮겼습니다 — 판 이력·문서번호는 그대로입니다")
    h._redirect(f"/form?id={fid}")


def _compare_button(action: str, csrf: str, fields, label: str = "비교하기") -> str:
    """비교 계산 단추 — POST + CSRF (2026-10-28 보안 F3: 화면을 여는 GET은 계산하지 않는다)."""
    hid = "".join(f'<input type="hidden" name="{E(k)}" value="{E(str(v))}">' for k, v in fields)
    return (f'<form class="inline" method="post" action="{E(action)}"><input type="hidden" name="csrf" '
            f'value="{E(csrf)}">{hid}<button class="btn sm" type="submit">{E(label)}</button></form>')


def _version_picker(fid: int, versions: list, a_id, b_id, csrf: str) -> str:
    """판 두 개 고르기 — 스크립트 없는 POST 양식 (/compare, CSRF). 고르고 누르면 비교해 보기 화면으로 간다 (보안 F3)."""
    def opts(sel):
        return "".join(f'<option value="{v["id"]}"{" selected" if v["id"] == sel else ""}>v{v["number"]} · '
                       f'{E(_fmt_time(v["approved_at"]))}</option>' for v in versions)
    return (f'<form class="pick" method="post" action="/compare"><input type="hidden" name="csrf" value="{E(csrf)}">'
            f'<input type="hidden" name="form" value="{fid}">'
            f'<label class="chk" for="pa">이전</label><select id="pa" name="a">{opts(a_id)}</select>'
            f'<span aria-hidden="true">→</span>'
            f'<label class="chk" for="pb">새</label><select id="pb" name="b">{opts(b_id)}</select>'
            f'<button class="btn sm" type="submit">비교하기</button></form>')


# ── 자동 비교 표 (F3) ───────────────────────────────────────────────────────

def _parts_html(parts: list, mark_tag: str, mark_cls: str = "") -> str:
    """[[조각, 바뀜?]…] → HTML. 바뀐 조각만 강조. 값은 전부 이스케이프."""
    out = []
    for text, changed in parts or []:
        t = E(str(text))
        if changed:
            cls = f' class="{mark_cls}"' if mark_cls else ""
            out.append(f"<{mark_tag}{cls}>{t}</{mark_tag}>")
        else:
            out.append(t)
    return "".join(out)


def _compare_table(rows: list) -> str:
    trs = []
    for r in rows:
        old = (f'<del class="old">{_parts_html(r.get("old_parts"), "span", "hl")}</del>'
               if r.get("old") else '<span class="none">—</span>')
        new = (f'<ins class="new">{_parts_html(r.get("new_parts"), "mark")}</ins>'
               if r.get("new") else '<span class="none">—</span>')
        sub = f'<div class="muted">{E(r["label"])}</div>' if r.get("label") else ""
        trs.append(f'<tr><td class="nw"><span class="tag k-{E(r.get("tone", "info"))}">{E(r.get("kind_label", ""))}</span>'
                   f'</td><td class="name">{E(r.get("name", ""))}{sub}</td><td class="val">{old}</td>'
                   f'<td class="val">{new}</td><td class="muted">{E(r.get("where", ""))}</td></tr>')
    return ('<table class="cmp"><thead><tr><th>구분</th><th>항목</th><th>이전 값</th><th>새 값</th><th>위치</th></tr>'
            '</thead><tbody>' + "".join(trs) + "</tbody></table>")


def _notes_html(notes) -> str:
    notes = [n for n in (notes or []) if str(n).strip()]
    return ('<ul class="notes">' + "".join(f"<li>{E(str(n))}</li>" for n in notes) + "</ul>") if notes else ""


def _compare_html(res: dict, old_label: str, new_label: str, downloads: str = "", retry: str = "") -> str:
    """비교 결과 → 화면 조각. status: ok / unsupported / failed. retry: 실패 때 보일 [다시 비교하기](POST) 단추."""
    st = res.get("status")
    head = (f'<div class="cmp-head"><span>이전: {E(old_label)}</span><span aria-hidden="true">→</span>'
            f'<span>새: {E(new_label)}</span></div>')
    if st == "unsupported":
        return head + f'<div class="note info" role="status">{E(res.get("reason", ""))}</div>{downloads}'
    if st != "ok":
        again = ("잠시 뒤 [다시 비교하기]를 누르면 다시 해 봅니다." if retry else "")
        return (head + f'<div class="note bad" role="alert"><b>비교할 수 없음</b> — {E(res.get("reason", ""))}</div>'
                f'<p class="muted">파일을 내려받아 직접 열어 확인해 주세요. {again}</p>'
                f'{retry}{downloads}')
    rows = res.get("rows") or []
    if not rows:
        return (head + '<div class="note ok" role="status">글자·표로는 바뀐 것이 없습니다 — 서식·그림만 바뀌었을 수 있으니 '
                       '파일을 열어 확인하세요.</div>' + _notes_html(res.get("notes")) + downloads)
    adds = sum(1 for r in rows if r.get("tone") == "add")
    rms = sum(1 for r in rows if r.get("tone") == "rm")
    mods = sum(1 for r in rows if r.get("tone") == "mod")
    tally = " · ".join(x for x in (f"추가 {adds}" if adds else "", f"삭제 {rms}" if rms else "",
                                   f"변경 {mods}" if mods else "") if x)
    count = (f'<div class="cmp-head"><b>변경 {len(rows)}건</b>'
             + (f'<span class="muted">{E(tally)}</span>' if tally else "")
             + '<span class="muted">이전 값은 취소선, 새 값은 굵게 — 바뀐 낱말은 색으로 표시</span></div>')
    return head + count + _compare_table(rows) + _notes_html(res.get("notes")) + downloads


def _summary_html(res: dict, downloads: str = "", retry: str = "") -> str:
    """새 양식 — 비교할 이전 판이 없을 때의 글자 요약. retry: 실패 때 보일 [다시 읽기](POST) 단추."""
    lead = '<div class="note info" role="status"><b>새 양식 — 비교할 이전 판 없음</b>. 아래는 파일에서 읽은 글자 요약입니다.</div>'
    st = res.get("status")
    if st == "unsupported":
        return lead + f'<div class="note info">{E(res.get("reason", ""))}</div>{downloads}'
    if st != "new":
        return lead + (f'<div class="note bad" role="alert"><b>비교할 수 없음</b> — {E(res.get("reason", ""))}</div>'
                       f'{retry}{downloads}')
    s = res.get("summary") or {}
    parts = []
    if s.get("sheets"):
        parts.append(f'<dt>시트</dt><dd>{E(" · ".join(s["sheets"]))}</dd>')
    for k, v in s.get("fields") or []:
        parts.append(f'<dt>{E(k)}</dt><dd>{E(v)}</dd>')
    if s.get("row_count"):
        parts.append(f'<dt>표 행 수</dt><dd>{int(s["row_count"])}행</dd>')
    out = lead + (f'<dl class="kv">{"".join(parts)}</dl>' if parts else "")
    for sheet, cols in s.get("headers") or []:
        out += (f'<h3>칸 이름 — {E(sheet)}</h3><div class="cols">'
                + "".join(f"<span>{E(c)}</span>" for c in cols) + "</div>")
    if not s.get("headers"):                        # 빈 양식(값 행 없음) — 칸에 적힌 글자를 그대로 (f6)
        for unit, texts in s.get("cells") or []:
            out += (f'<h3>칸 글자 — {E(unit)}</h3><div class="cols">'
                    + "".join(f"<span>{E(c)}</span>" for c in texts) + "</div>")
    if s.get("lines"):
        out += '<h3>머리 글줄</h3><ul class="lines">' + "".join(f"<li>{E(x)}</li>" for x in s["lines"]) + "</ul>"
    if not parts and not s.get("headers") and not s.get("lines") and not s.get("cells"):
        out += '<p class="muted">읽을 수 있는 글자가 없습니다.</p>'
    return out + _notes_html(s.get("notes")) + downloads


def _compare_pick(h: FormsHandler, fid: int, a, b):
    """판끼리 비교의 두 판 정하기 — (양식 상세, 이전 판, 새 판) 또는 판이 하나뿐이면 (상세, None, None)."""
    d = h.server.store.form_detail(h.sess.user_id, fid)
    versions = d["versions"]
    by_id = {v["id"]: v for v in versions}
    for x in (a, b):
        if x is not None and x not in by_id:
            raise HttpError(404, "이 양식의 판이 아닙니다")
    if len(versions) < 2:
        return d, None, None
    if b is None:
        b = d["current_version_id"] if d["current_version_id"] in by_id else versions[0]["id"]
    if a is None:
        older = [v for v in versions if v["number"] < by_id[b]["number"]]
        a = older[0]["id"] if older else next(v["id"] for v in versions if v["id"] != b)
    va, vb = by_id[a], by_id[b]
    if va["number"] > vb["number"]:                 # 이전 → 새 순서로 (취소선이 옛 값에 가게)
        va, vb = vb, va
    return d, va, vb


def post_compare(h: FormsHandler) -> None:
    """[비교하기] — 판끼리 비교를 계산해 캐시에 둔 뒤 보기 화면(GET)으로 (2026-10-28 보안 F3: GET은 계산하지 않는다)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "form"))
    d, va, vb = _compare_pick(h, fid, h._int(h._one(f, "a"), required=False), h._int(h._one(f, "b"), required=False))
    if va is not None and (va.get("purged_at") or vb.get("purged_at")):     # 정리한 판 — 보기 화면이 설명한다
        h._redirect(f"/compare?form={fid}&a={va['id']}&b={vb['id']}")
        return
    if va is not None and va["id"] != vb["id"]:
        h._allow_compare()
        out = h.server.comparer.compare_versions(h.sess.user_id, va["id"], vb["id"], ip=h.ip)
        if out["result"].get("status") == "failed" and "밀려" in str(out["result"].get("reason", "")):
            h._flash("bad", "비교가 밀려 있습니다 — 잠시 뒤 [비교하기]를 다시 눌러 주세요")
        h._redirect(f"/compare?form={fid}&a={va['id']}&b={vb['id']}")
        return
    h._redirect(f"/compare?form={fid}")


def get_compare(h: FormsHandler) -> None:
    """판끼리 비교 — 기본은 현행과 바로 전 판. 누구나(판은 모두가 볼 수 있다). 내려받기 감사 기록은 남기지 않는다.
    이 화면(GET)은 **캐시만 본다** — 아직 비교하지 않은 두 판이면 [비교하기](POST+CSRF) 단추를 보인다 (보안 F3)."""
    store, s = h.server.store, h.sess
    qd = h._query()
    fid = h._int(h._one(qd, "form"))
    a = h._int(h._one(qd, "a"), required=False)
    b = h._int(h._one(qd, "b"), required=False)
    d, va0, vb0 = _compare_pick(h, fid, a, b)
    versions = d["versions"]
    trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in d["folder_path"])
    crumb = (f'<div class="crumb"><a href="/forms">전체</a> / {trail} / '
             f'<a href="/form?id={fid}">{E(d["name"])}</a></div>')
    if va0 is None:
        body = crumb + '<div class="panel"><p class="empty">판이 둘 이상 있어야 비교할 수 있습니다.</p></div>'
        h._send(200, h._shell(f"{d['name']} — 판끼리 비교", body, active="/forms"))
        return
    va, vb = va0, vb0
    picker = _version_picker(fid, versions, va["id"], vb["id"], s.csrf)
    retired = '<div class="note warn">폐기된 양식입니다.</div>' if d["retired"] else ""
    dl = (f'<p class="form-actions"><a class="btn gray sm" href="/download?v={va["id"]}">v{va["number"]} 내려받기</a>'
          f'<a class="btn gray sm" href="/download?v={vb["id"]}">v{vb["number"]} 내려받기</a></p>')
    gone = [v for v in (va, vb) if v.get("purged_at")]
    if va["id"] == vb["id"]:
        inner = '<div class="note info">같은 판을 골랐습니다 — 다른 두 판을 골라 주세요.</div>'
    elif gone:                                   # 보존 기간이 지나 정리한 판 — 파일이 없어 비교하지 않는다 (2026-10-30)
        said = "; ".join(f'v{v["number"]} (정리한 날 {_fmt_time(v["purged_at"])}'
                         + (f' · 정리한 사람 {v["purged_by_name"]}' if v.get("purged_by_name") else "") + ")" for v in gone)
        inner = (f'<div class="note warn" role="status">보존 기간이 지나 정리한 판은 파일이 없어 비교할 수 없습니다 — {E(said)}. '
                 f'판 기록(번호·지문·승인)은 양식 상세에 남아 있습니다. 다른 두 판을 골라 주세요.</div>')
    else:
        out = h.server.comparer.compare_versions(s.user_id, va["id"], vb["id"], ip=h.ip, compute=False)
        old_l, new_l = f"v{va['number']} ({va['filename']})", f"v{vb['number']} ({vb['filename']})"
        run_btn = _compare_button("/compare", s.csrf, (("form", fid), ("a", va["id"]), ("b", vb["id"])))
        if out["result"] is None:
            inner = (f'<div class="cmp-head"><span>이전: {E(old_l)}</span><span aria-hidden="true">→</span>'
                     f'<span>새: {E(new_l)}</span></div>'
                     f'<div class="note info" role="status">아직 비교하지 않은 두 판입니다 — [비교하기]를 누르면 '
                     f'근거 표(이전 값 / 새 값 / 위치)를 만듭니다. 한 번 비교한 결과는 저장돼 다음부터 바로 보입니다.</div>'
                     f'{run_btn}{dl}')
        else:
            again = _compare_button("/compare", s.csrf, (("form", fid), ("a", va["id"]), ("b", vb["id"])),
                                    "다시 비교하기")
            inner = _compare_html(out["result"], old_l, new_l, dl, retry=again)
    body = crumb + retired + f'<div class="panel">{picker}{inner}</div>'
    h._send(200, h._shell(f"{d['name']} — 판끼리 비교", body, active="/forms"))


def post_retire(h: FormsHandler) -> None:
    _set_retired(h, True)


def post_restore(h: FormsHandler) -> None:
    _set_retired(h, False)


def _set_retired(h: FormsHandler, retired: bool) -> None:
    """폐기·복원 — 사유 필수. 역할은 여기서, 맡은 폴더인지는 store가 다시 본다."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    reason = h._one(f, "reason").strip()
    if not reason:
        raise HttpError(400, f"{'폐기' if retired else '복원'} 사유를 적어 주세요")
    h.server.store.set_retired(h.sess.user_id, fid, retired, ip=h.ip, reason=reason)
    h.server.on_event("retired" if retired else "restored", form_id=fid)
    h._flash("ok", "양식을 폐기했습니다 — 목록에서 숨겨지고 '폐기 양식도 보기'에서만 보입니다" if retired
             else "양식을 복원했습니다 — 다시 목록에 보입니다")
    h._redirect(f"/form?id={fid}")


def _stream_file(h: FormsHandler, path, filename: str, size: int, fallback_name: str | None = None) -> None:
    h._deadline(int(size))
    h.send_response(200)
    h.send_header("Content-Type", "application/octet-stream")
    h.send_header("Content-Length", str(int(size)))
    h.send_header("Content-Disposition", content_disposition(filename, fallback_name))
    h.end_headers()
    sent = 0
    with open(path, "rb") as f:
        while sent < size:
            chunk = f.read(min(256 * 1024, size - sent))
            if not chunk:
                break
            h._out(chunk)
            sent += len(chunk)
    h.close_connection = True


def get_download(h: FormsHandler) -> None:
    vid = h._int(h._one(h._query(), "v"))
    info = h.server.store.version_file(h.sess.user_id, vid, ip=h.ip)
    _stream_file(h, info["path"], download_name(info), info["size"], download_name(info, ascii_marks=True))


def download_name(info: dict, *, ascii_marks: bool = False) -> str:
    """내려받는 파일 이름 — 내려받은 뒤 탐색기에서도 옛 양식·지난 판인 줄 알게 표시를 붙인다.
    폐기된 양식의 현행 판 '[폐기] 이름'(F3), 지난 판 '[지난 판 v2] 이름'(2026-10-30), 폐기된 양식의 지난 판 '[폐기·지난 판 v2] 이름'.
    ascii_marks: 옛 브라우저용 ASCII 대체 이름의 표시('[retired] '·'[old-v2] '·'[retired-old-v2] ')."""
    marks = []
    if info.get("retired"):
        marks.append("retired" if ascii_marks else "폐기")
    if info.get("current") is False:
        marks.append(f"old-v{info.get('number')}" if ascii_marks else OLD_PREFIX.format(n=info.get("number")))
    if ascii_marks:
        return (f"[{'-'.join(marks)}] " if marks else "") + info["filename"]
    if marks == ["폐기"]:
        return RETIRED_PREFIX + info["filename"]
    return (f"[{'·'.join(marks)}] " if marks else "") + info["filename"]


def get_review_file(h: FormsHandler) -> None:
    sid = h._int(h._one(h._query(), "s"))
    info = h.server.store.submission_file(h.sess.user_id, sid, ip=h.ip)
    _stream_file(h, info["path"], info["filename"], info["size"])


# ── 검토 대기 (최소판 — 자동 비교·판끼리 비교·폐기 화면은 F3) ───────────────────────

def _require_reviewer_role(h: FormsHandler) -> None:
    if h.sess.role not in ("reviewer", "admin"):
        # 보기(GET)와 하기(POST)를 나눠 말한다 (2026-10-30 — POST에 '볼 수 있습니다'가 어색했다)
        raise HttpError(403, "검토자와 관리자만 " + ("할" if h.command == "POST" else "볼") + " 수 있습니다")


def _review_flags(store: FormsStore, user_id, subs: list) -> dict:
    """{제출 id: (폐기된 양식인가, 바꾼 내용 없는 옛 개정안인가)} — 검토 목록·화면의 안내용 (2026-10-30). 필요한 양식만 묻는다."""
    retired = store.retired_form_ids(user_id, (x["form_id"] for x in subs
                                               if x.get("kind") == "revision" and x.get("form_id")))
    return {x["id"]: (x.get("form_id") in retired and x.get("kind") == "revision",
                      x.get("kind") == "revision" and not str(x.get("note") or "").strip()) for x in subs}


RETIRED_PENDING = "폐기된 양식 — 복원해야 승인할 수 있습니다"
NO_NOTE_PENDING = "바꾼 내용이 비어 있는 개정안 — [비교 보며 검토]를 열어 승인 메모에 바꾼 내용을 적고 승인하세요"


def _stage_line(x: dict) -> str:
    """검토 목록·화면의 2단계 승인 한 줄 — 1단계 검토 대기는 빈 글자(지금까지와 같은 화면)."""
    if x.get("stage") == "check":
        return ('<div class="muted"><span class="tag pending">검토 대기</span> 2단계 승인 — 검토자가 [검토 완료]하면 '
                '승인권자가 승인합니다</div>')
    if x.get("stage") == "approve":
        return (f'<div class="muted"><span class="tag awaiting">승인 대기</span> 검토: {E(x["checked_by_name"])} · '
                f'{E(_fmt_time(x["checked_at"]))}</div>'
                + (f'<div class="muted pre">검토 메모: {E(x["check_memo"])}</div>' if x.get("check_memo") else ""))
    return ""


def get_review(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    only = h._one(h._query(), "stage")              # 2단계 승인 — ?stage=approve 면 승인 대기만 (읽기만)
    only = only if only == "approve" else ""
    oldest = h._one(h._query(), "order") == "old"   # 오래된 것부터 (2026-10-31)
    # 200줄씩 쪽 나누기 (2026-10-31 — 전에는 최근 500건에서 말없이 잘려 가장 오래 기다린 제출이 보이지 않았다)
    pg = store.review_page(s.user_id, stage=only or None, page=_page_of(h), per=PAGE_ROWS, oldest=oldest)
    subs, page = pg["rows"], pg["page"]
    staged = [x for x in subs if x.get("stage") in ("check", "approve")]
    acts = store.review_actions(s.user_id, staged) if staged else {}
    n_appr = pg["n_approve"]
    filters = ""
    keep_q = {"stage": only, "order": "old" if oldest else ""}
    order_link = ""
    if pg["n_all"] > PAGE_ROWS or oldest:
        flip = {"stage": only, "order": "" if oldest else "old"}
        q = "&".join(f"{k}={v}" for k, v in flip.items() if v)
        order_link = (f'<a class="btn gray sm" href="/review{"?" + q if q else ""}">'
                      f'{"최근 것부터 보기" if oldest else "오래 기다린 것부터 보기"}</a>')
    if store.steps_map():                           # 2단계 폴더가 하나도 없으면 '승인 대기' 거르기를 그리지 않는다 (F2-5)
        filters = (f'<div class="searchbar"><a class="btn {"gray " if only else ""}sm" href="/review">전체 {pg["n_all"]}</a>'
                   f'<a class="btn {"" if only else "gray "}sm" href="/review?stage=approve">승인 대기 {n_appr}</a>'
                   f'{order_link}'
                   f'<span class="muted">승인 대기 = 검토자가 [검토 완료]해 승인권자의 [승인]을 기다리는 것</span></div>')
    elif order_link:
        filters = f'<div class="searchbar">{order_link}<span class="muted">모두 {pg["n_all"]}건</span></div>'
    paths = {n["id"]: p for n, _, p in h._folders()}
    csrf = E(s.csrf)
    comparer = h.server.comparer
    codes = {t["id"]: t["code"] for t in store.list_doc_types(s.user_id)}          # 문서 종류 (F7 문서 종류 검토 1)
    form_types = store.form_doc_types(s.user_id, (x["form_id"] for x in subs))      # 필요한 양식만 (2026-10-30)
    warn_empty = rule_uses_type(parse_docno_pattern(store.docno_rule()["pattern"])[1])
    show_types = _types_in_use(store)                                                # F2-5
    flags = _review_flags(store, s.user_id, subs)
    # 변경 건수 배지 — 한 쪽을 한 번에 (줄마다 제출·양식·판을 다시 읽지 않는다, 2026-10-31)
    badges = comparer.cached_counts(s.user_id, subs) if comparer is not None else {}
    rows = []
    for x in subs:
        target = (f'<a href="/form?id={x["form_id"]}">{E(x["form_name"])}</a>' if x["form_id"]
                  else E(x["form_name"]))
        if show_types:
            target += _sub_type_short(x, codes, form_types, warn_empty=warn_empty)
        retired_form, no_note = flags.get(x["id"], (False, False))
        if retired_form:
            target += f'<div class="typewarn">{RETIRED_PENDING}</div>'
        elif no_note:
            target += f'<div class="typewarn">{NO_NOTE_PENDING}</div>'
        # 변경 건수는 이미 비교해 둔 것만 보인다 — 목록을 그리려고 비교를 돌리지 않는다
        n = badges.get(x["id"]) if x["form_id"] else None
        badge = (f'<div class="muted">현행 판과 비교: 변경 {n}건</div>' if n is not None
                 else ('<div class="muted">열면 현행 판과 자동 비교</div>' if x["form_id"] else
                       '<div class="muted">새 양식 — 열면 글자 요약</div>'))
        # 바로 승인은 메모 칸이 없다 — 폐기된 양식·바꾼 내용 없는 옛 개정안은 검토 화면에서만 (2026-10-30)
        quick_ok = "" if (retired_form or no_note) else (
            f'<form class="inline" method="post" action="/review/approve"><input type="hidden" name="csrf" value="{csrf}">'
            f'<input type="hidden" name="id" value="{x["id"]}"><button class="btn sm" type="submit">승인</button></form>')
        a = acts.get(x["id"])
        if a is not None:                           # 2단계 승인 — 단계마다 단추가 다르다 (store가 누를 때 다시 본다)
            target += _stage_line(x)
            if a["stage"] == "check":
                quick_ok = "" if (retired_form or not a["can_check"]) else (
                    f'<form class="inline" method="post" action="/review/check"><input type="hidden" name="csrf" '
                    f'value="{csrf}"><input type="hidden" name="id" value="{x["id"]}">'
                    f'<button class="btn sm" type="submit">검토 완료 — 승인 요청</button></form>')
            elif not a["can_approve"]:
                quick_ok = ""
            if a["why"]:
                target += f'<div class="muted">{E(a["why"])}</div>'
        rows.append(
            f'<tr><td class="nw">{x["id"]}</td><td>{target}<div class="muted">{E(KIND_LABEL.get(x["kind"], ""))} · '
            f'{E(paths.get(x["folder_id"], ""))}</div></td>'
            f'<td><a href="/review/file?s={x["id"]}">{E(x["filename"])}</a><div class="muted">{_fmt_size(x["size"])}'
            f'</div></td><td>{E(x["submitted_by_name"])}<div class="muted">{E(_fmt_time(x["submitted_at"]))}</div></td>'
            f'<td class="pre">{E(x["note"])}</td><td><a class="btn sm" href="/review/item?id={x["id"]}">비교 보며 검토</a>{badge}'
            f'<details class="tool"><summary>바로 처리</summary>{quick_ok}'
            f'<form class="inline" method="post" action="/review/reject"><input type="hidden" name="csrf" value="{csrf}">'
            f'<input type="hidden" name="id" value="{x["id"]}">'
            f'<input type="text" name="reason" required maxlength="500" placeholder="반려 사유 (필수, 500자까지)" '
            f'aria-label="반려 사유">'
            f'<button class="btn red sm" type="submit">반려</button></form></details></td></tr>')
    table = ("<table><thead><tr><th>번호</th><th>양식</th><th>파일</th><th>올린 사람</th><th>설명</th><th>처리</th>"
             "</tr></thead><tbody>" + "".join(rows) + "</tbody></table>"
             + _pager("/review", keep_q, page, pg["more"], pg["total"])) if rows else \
        ('<p class="empty">승인 대기가 없습니다</p>' if only else
         (_no_assigned_note(h, approvals=True) or '<p class="empty">검토할 것이 없습니다</p>'))
    hint = ('<p class="muted">[비교 보며 검토]를 누르면 개정안은 현행 판과의 자동 비교 표(이전 값 / 새 값 / 위치)가, '
            '새 양식은 파일에서 읽은 글자 요약이 보입니다. 승인할 때 메모를, 반려할 때 사유(필수)를 남깁니다.</p>')
    h._send(200, h._shell("검토 대기", f'<div class="panel">{hint}{filters}{table}</div>', active="/review"))


def get_review_item(h: FormsHandler) -> None:
    """검토 화면 하나 — 개정안은 현행 판과 자동 비교, 새 양식은 글자 요약. 승인(메모)·반려(사유 필수)."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    sid = h._int(h._one(h._query(), "id"))
    sub = store.submission(s.user_id, sid)
    if not store.can_handle_submission(s.user_id, sid):          # 검토자, 또는 2단계 승인의 승인권자
        raise HttpError(403, "이 폴더의 검토자만 볼 수 있습니다")
    paths = {n["id"]: p for n, _, p in h._folders()}
    target = (f'<a href="/form?id={sub["form_id"]}">{E(sub["form_name"])}</a>' if sub["form_id"]
              else E(sub["form_name"]))
    info = (f'<dl class="kv"><dt>양식</dt><dd>{target}</dd>'
            f'<dt>구분</dt><dd>{E(KIND_LABEL.get(sub["kind"], sub["kind"]))}</dd>'
            f'<dt>폴더</dt><dd>{E(paths.get(sub["folder_id"], ""))}</dd>'
            f'{_sub_type_row(h, sub) if _types_in_use(store) else ""}'
            f'<dt>올린 사람</dt><dd>{E(sub["submitted_by_name"])} · {E(_fmt_time(sub["submitted_at"]))}</dd>'
            f'<dt>{"바꾼 내용" if sub["kind"] == "revision" else "설명"}</dt>'
            f'<dd class="pre">{E(sub["note"]) or "<span class=none>—</span>"}</dd>'
            f'<dt>파일</dt><dd>{E(sub["filename"])} <span class="muted">{_fmt_size(sub["size"])}</span></dd>'
            f'<dt>상태</dt><dd>'
            + ('<span class="tag awaiting">승인 대기</span>' if sub.get("stage") == "approve" else _status_tag(sub["status"]))
            + ('<span class="tag two">2단계 승인</span>' if sub.get("steps") == 2 and sub["status"] == "pending" else "")
            + '</dd>'
            + (f'<dt>1단계 검토</dt><dd>{E(sub["checked_by_name"])} · {E(_fmt_time(sub["checked_at"]))}'
               + (f'<div class="pre">검토 메모: {E(sub["check_memo"])}</div>' if sub.get("check_memo") else "")
               + '</dd>' if sub.get("checked_at") else "")
            + '</dl>')
    if sub["status"] != "pending":
        extra = ""
        if sub["reason"]:
            extra += f'<p class="pre">반려 사유: {E(sub["reason"])}</p>'
        if sub.get("decision_note"):
            extra += f'<p class="pre">승인 메모: {E(sub["decision_note"])}</p>'
        body = (f'<div class="crumb"><a href="/review">검토 대기</a> / 제출 {sid}번</div>'
                f'<div class="panel">{info}<div class="note info">이미 처리된 제출입니다 '
                f'({E(sub["decided_by_name"])} · {E(_fmt_time(sub["decided_at"]))})</div>{extra}</div>')
        h._send(200, h._shell(f"제출 {sid}번", body, active="/review"))
        return
    # 자동 비교는 '맡은 폴더의 검토자가, 검토 대기 1건당 한 번'만 이 화면(GET)에서 계산한다 — 그 뒤로는 캐시만 보고,
    # 다시 계산은 [다시 비교하기](POST+CSRF). 직원은 이 화면에 들어오지 못한다(위 403). (2026-10-28 보안 F3)
    comparer = h.server.comparer
    rv = comparer.review_submission(s.user_id, sid, ip=h.ip, compute=False)
    if rv["result"] is None and comparer.claim_auto(sid):
        h._allow_compare()
        rv = comparer.review_submission(s.user_id, sid, ip=h.ip)
    run_btn = _compare_button("/review/compare", s.csrf, (("id", sid),))
    again_btn = _compare_button("/review/compare", s.csrf, (("id", sid),), "다시 비교하기")
    not_yet = ('<div class="note info" role="status">아직 비교하지 않았습니다 — [비교하기]를 누르면 '
               '{what}을(를) 만듭니다.</div>')
    open_new = f'<a class="btn gray sm" href="/review/file?s={sid}">올린 파일 열어 보기</a>'
    if rv["mode"] == "revision":
        old = rv["old"]
        dl = (f'<p class="form-actions">{open_new}'
              f'<a class="btn gray sm" href="/download?v={int(old["id"])}">'
              f'현행 v{old["number"]} 내려받기</a></p>')
        if rv["result"] is None:
            cmp_html = ('<h2>현행 판과 자동 비교</h2>' + not_yet.format(what="현행 판과의 근거 표") + run_btn + dl)
        else:
            cmp_html = ('<h2>현행 판과 자동 비교</h2>'
                        + _compare_html(rv["result"], f"현행 v{old['number']} ({old['filename']})",
                                        f"올린 파일 ({sub['filename']})", dl, retry=again_btn))
    else:
        if rv["result"] is None:
            cmp_html = ('<h2>올린 양식</h2>' + not_yet.format(what="글자 요약") + run_btn
                        + f'<p class="form-actions">{open_new}</p>')
        else:
            cmp_html = '<h2>올린 양식</h2>' + _summary_html(rv["result"], f'<p class="form-actions">{open_new}</p>',
                                                         retry=again_btn)
    csrf = E(s.csrf)
    retired_form, no_note = _review_flags(store, s.user_id, [sub]).get(sid, (False, False))
    warn = ""
    if retired_form:
        warn += (f'<div class="note warn" role="status"><b>{RETIRED_PENDING}</b> — 양식 상세의 [양식 복원] 뒤에 승인하거나, '
                 f'이대로 반려하세요.</div>')
    if no_note:
        warn += (f'<div class="note warn" role="status"><b>바꾼 내용이 비어 있는 개정안입니다</b> (바꾼 내용이 필수가 되기 전에 '
                 f'올라옴) — 승인하려면 아래 승인 메모에 바꾼 내용을 적어 주세요. 문서 관리 대장의 개정 사유로 남습니다.</div>')
    memo_label = ("승인 메모 (필수 — 바꾼 내용을 적어 주세요. 대장의 개정 사유로 남습니다)" if no_note
                  else "승인 메모 (선택 — 올린 사람이 봅니다)")
    approve_form = (f'<form method="post" action="/review/approve"><input type="hidden" name="csrf" value="{csrf}">'
                    f'<input type="hidden" name="id" value="{sid}"><label for="memo">{E(memo_label)}</label>'
                    f'<textarea id="memo" name="memo" maxlength="500"{" required" if no_note else ""} '
                    f'placeholder="예: 야간수당 열 확인함"></textarea>{_hint(HINT_MEMO + " · 여러 줄 가능")}'
                    f'<div class="form-actions"><button class="btn" type="submit">승인 — 새 현행 판으로</button></div>'
                    f'</form>')
    reject_form = (f'<form method="post" action="/review/reject"><input type="hidden" name="csrf" value="{csrf}">'
                   f'<input type="hidden" name="id" value="{sid}"><label for="why">반려 사유 (필수 — 올린 사람이 봅니다)</label>'
                   f'<textarea id="why" name="reason" required maxlength="500" placeholder="예: 결재란 칸 수가 규정과 다릅니다">'
                   f'</textarea>{_hint(HINT_MEMO + " · 여러 줄 가능")}'
                   f'<div class="form-actions"><button class="btn red" type="submit">반려</button></div></form>')
    first = approve_form
    if sub.get("stage") in ("check", "approve"):    # 2단계 승인 — 단계마다 왼쪽 칸이 다르다 (store가 누를 때 다시 본다)
        a = store.review_actions(s.user_id, [sub]).get(sid, {})
        blocker = store.stage_blocker(s.user_id, sid)
        why = a.get("why", "")
        if blocker:
            warn += f'<div class="note warn" role="status"><b>다음 단계로 넘길 사람이 없습니다</b> — {E(blocker)}</div>'
        if a.get("stage") == "check":
            first = (f'<form method="post" action="/review/check"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{sid}">'
                     f'<label for="cmemo">검토 메모 (선택 — 승인권자와 올린 사람이 봅니다)</label>'
                     f'<textarea id="cmemo" name="memo" maxlength="500" placeholder="예: 결재란·서식 확인함"></textarea>'
                     f'{_hint(HINT_MEMO + " · 여러 줄 가능")}{_hint(HINT_TWO_STEP)}'
                     f'<div class="form-actions"><button class="btn" type="submit">검토 완료 — 승인 요청</button></div>'
                     f'</form>') if a.get("can_check") else \
                f'<div><h3>검토 완료</h3><p class="muted">{E(why or HINT_TWO_STEP)}</p></div>'
        elif not a.get("can_approve"):
            first = f'<div><h3>승인</h3><p class="muted">{E(why or "이 폴더의 승인권자만 승인합니다")}</p></div>'
    decide = f'<div class="panel"><h2>처리</h2><div class="decide">{first}{reject_form}</div></div>'
    body = (f'<div class="crumb"><a href="/review">검토 대기</a> / 제출 {sid}번</div>{warn}'
            f'<div class="panel">{info}{_sub_type_warning(h, sub)}</div><div class="panel">{cmp_html}</div>{decide}')
    h._send(200, h._shell(f"검토 — {sub['form_name']}", body, active="/review"))


def post_review_compare(h: FormsHandler) -> None:
    """[비교하기]·[다시 비교하기] — 검토 화면의 자동 비교를 (다시) 계산한다. 맡은 폴더의 검토자만, 검토 대기일 때만 (보안 F3)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    sid = h._int(h._one(f, "id"))
    sub = store.submission(s.user_id, sid)
    if not store.can_handle_submission(s.user_id, sid):          # 검토자, 또는 2단계 승인의 승인권자
        raise HttpError(403, "이 폴더의 검토자만 할 수 있습니다")
    if sub["status"] != "pending":
        raise Conflict("이미 처리된 제출입니다")
    h._allow_compare()
    rv = h.server.comparer.review_submission(s.user_id, sid, ip=h.ip)
    res = rv.get("result") or {}
    if res.get("status") == "failed" and "밀려" in str(res.get("reason", "")):
        h._flash("bad", "비교가 밀려 있습니다 — 잠시 뒤 [비교하기]를 다시 눌러 주세요")
    h._redirect(f"/review/item?id={sid}")


def post_approve(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    try:
        res = h.server.store.approve(h.sess.user_id, sid, ip=h.ip, memo=h._one(f, "memo"))
    except (StageError, StepRefused, Conflict, InvalidInput) as e:   # 바꾼 내용 없는 옛 개정안(MemoRequired)·2단계 승인 거부·
        # 폐기된 양식·이미 처리됨·메모 길이 — 맨 오류 화면 대신 검토 화면으로 돌아가 알린다 (2단계 승인 검토 4)
        h.server.store.submission(h.sess.user_id, sid)          # 없는 제출·볼 수 없는 제출이면 404·403
        h._flash("bad", f"승인하지 않았습니다 — {e}")
        h._redirect(f"/review/item?id={sid}")
        return
    h.server.on_event("approved", submission_id=sid, result=res)
    h._flash("ok", f"승인했습니다 — 제출 {sid}번이 v{res['number']}(현행 판)이 됐습니다")
    h._redirect("/review")


def post_check(h: FormsHandler) -> None:
    """[검토 완료 — 승인 요청] (2단계 승인) — 그 폴더 검토자가. 권한·단계·올린 사람 거르기는 store가 한 트랜잭션에서 본다."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    try:
        h.server.store.check(h.sess.user_id, sid, memo=h._one(f, "memo"), ip=h.ip)
    except (StageError, StepRefused, Conflict, InvalidInput) as e:   # 폐기된 양식·메모 길이도 (2단계 승인 검토 4)
        h.server.store.submission(h.sess.user_id, sid)          # 없는 제출·볼 수 없는 제출이면 404·403
        h._flash("bad", f"검토 완료하지 않았습니다 — {e}")
        h._redirect(f"/review/item?id={sid}")
        return
    h.server.on_event("checked", submission_id=sid)
    h._flash("ok", f"검토 완료했습니다 — 제출 {sid}번이 승인 대기가 됐습니다 (승인권자가 승인하면 현행 판이 됩니다)")
    h._redirect("/review")


def post_reject(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    h.server.store.reject(h.sess.user_id, sid, h._one(f, "reason"), ip=h.ip)
    h.server.on_event("rejected", submission_id=sid)
    h._flash("ok", f"반려했습니다 — 제출 {sid}번 (올린 사람이 사유를 봅니다)")
    h._redirect("/review")


# ── 문서 관리 대장·문서번호·정기 검토 (F7 ISO, 2026-10-29) ────────────────────────
# 권한은 store가 다시 본다(숨긴 단추에 기대지 않는다): 대장·기한 목록·검토함·주기는 관리자와 그 폴더 검토자,
# 문서번호 고치기·일괄 매기기는 관리자, 번호 머리는 폴더 이름 바꾸기와 같은 권한. 모든 POST는 CSRF, GET은 읽기만
# (엑셀 내려받기는 감사 기록 한 줄만 남긴다 — 판 내려받기와 같다).

def _state_tag(state: str) -> str:
    label, cls = REVIEW_STATE.get(state, ("", ""))
    if not label:
        return ""
    if cls == "off":
        return f' <span class="muted">{E(label)}</span>'
    return f' <span class="tag {cls}">{E(label)}</span>'


def _review_panel(h: FormsHandler, d: dict) -> str:
    """양식 상세의 정기 검토 칸 — 주기·최근 검토·다음 기한, [검토함 — 바꿀 것 없음], 주기 바꾸기 (검토자 도구 안)."""
    store = h.server.store
    rv = store.review_state(d.get("review_months"), d.get("last_reviewed_at"), d.get("current_approved_at"),
                            retired=d["retired"])
    every = "안 함" if rv["months"] == 0 else f"{rv['months']}개월마다"
    src = "전체 기본값 따름" if rv["inherit"] else "이 양식만 따로"
    due = rv["due"].isoformat() if rv["due"] else "—"
    info = (f'<div class="reviewinfo"><span>검토 주기: <b>{E(every)}</b> <span class="muted">({src})</span></span>'
            f'<span>시행일: {E(str(d.get("current_approved_at") or "")[:10] or "—")}</span>'
            f'<span>최근 검토: {E(str(d.get("last_reviewed_at") or "")[:10] or "—")}</span>'
            f'<span>다음 기한: <b>{E(due)}</b>{_state_tag(rv["state"])}</span></div>')
    out = '<h3>정기 검토</h3>' + info
    fid = d["id"]
    if d["retired"]:
        return out + '<p class="muted">폐기된 양식은 정기 검토하지 않습니다.</p>'
    off = rv["months"] == 0
    if off:                  # 정기 검토를 안 쓰면 뜻 모를 [검토함 — 바꿀 것 없음]·기한 칸 대신 한 줄 (ux20 forms 5)
        out = ('<h3>정기 검토</h3><p class="muted">이 양식은 정기 검토를 하지 않습니다'
               + (' (전체 기본값이 꺼져 있음)' if rv["inherit"] else '') + '. 몇 개월마다 다시 볼지 정하려면 아래 '
               '[검토 주기 정하기]를 여세요.</p>')
    else:
        out += (f'<form class="inline" method="post" action="/register/reviewed">{_hidden(h)}'
                f'<input type="hidden" name="id" value="{fid}"><input type="hidden" name="back" value="/form?id={fid}">'
                f'<input type="text" class="memo" name="memo" maxlength="500" placeholder="메모 (선택, 500자까지)" '
                f'aria-label="검토 메모">'
                f'<button class="btn sm" type="submit">검토함 — 바꿀 것 없음</button></form>'
                f'<p class="muted">고칠 것이 있으면 [개정안 올리기]로 올리세요 — 새 판이 승인되면 그날부터 다시 셉니다.</p>')
    cur = d.get("review_months")
    sel = "inherit" if cur is None else ("off" if cur == 0 else "months")

    def opt(v, label):
        return f'<option value="{v}"{" selected" if v == sel else ""}>{E(label)}</option>'
    dflt = store.default_review_months()
    out += (f'<details class="tool"><summary>{"검토 주기 정하기" if off else "검토 주기 바꾸기"}</summary>'
            f'<form class="inline" method="post" action="/form/review-months">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{fid}">'
            f'<select name="mode" aria-label="검토 주기">'
            f'{opt("inherit", f"전체 기본값 ({dflt}개월)" if dflt else "전체 기본값 (지금 꺼짐)")}'
            f'{opt("months", "따로 정함")}{opt("off", "검토 안 함")}</select>'
            f'<input type="text" class="months" name="months" inputmode="numeric" maxlength="3" '
            f'value="{cur if cur else ""}" aria-label="개월 수" placeholder="개월"> 개월 '
            f'<button class="btn gray sm" type="submit">저장</button></form>{_hint(HINT_MONTHS)}</details>')
    return out


def _sub_types(sub: dict, form_types: dict) -> tuple:
    """제출의 (지금 종류 id, 고른 종류 id, 승인 뒤 종류 id) — 개정안의 고른 값 None = 그 양식의 지금 종류 그대로."""
    chosen = sub.get("doc_type_id")
    if sub.get("kind") == "revision" and sub.get("form_id"):     # 승인된 새 양식도 form_id가 생기므로 구분(kind)으로 본다
        cur = form_types.get(sub["form_id"])
        return cur, chosen, (chosen if chosen is not None else cur)
    return None, chosen, chosen


def _sub_type_short(sub: dict, codes: dict, form_types: dict, *, warn_empty: bool) -> str:
    """목록(검토 대기·내 제출)의 한 줄 — 새 양식 '문서 종류 QI', 바꾸는 개정안 'QF → QP', 결과가 종류 없음이면
    warn_empty(규칙에 {종류}가 있을 때)일 때만 '문서 종류 없음'."""
    cur, chosen, result = _sub_types(sub, form_types)
    if sub.get("status") != "pending":                           # 처리된 것은 고른 종류만 (지금 종류는 그 뒤에 바뀌었을 수 있다)
        return f'<div class="muted">문서 종류 {E(codes.get(chosen, "?"))}</div>' if chosen is not None else ""
    if sub.get("kind") == "revision" and chosen is not None and chosen != cur:
        return (f'<div class="muted">문서 종류 {E(codes.get(cur, "없음") if cur is not None else "없음")} → '
                f'{E(codes.get(chosen, "?"))}</div>')
    if sub.get("kind") != "revision" and chosen is not None:
        return f'<div class="muted">문서 종류 {E(codes.get(chosen, "?"))}</div>'
    if result is None and warn_empty:
        return '<div class="typewarn">문서 종류 없음</div>'
    return ""


def _sub_type_row(h: FormsHandler, sub: dict) -> str:
    """검토 화면의 '문서 종류' 줄 — 늘 보인다(없음 포함). 새 양식은 고른 종류, 개정안은 지금 종류(그대로) 또는 지금 → 새 종류.
    검토 대기면 승인 전에 고치는 칸(POST /review/doctype)을 함께 둔다."""
    store = h.server.store
    types = store.list_doc_types(h.sess.user_id)
    by_id = {t["id"]: t for t in types}

    def label(i):
        t = by_id.get(i)
        return (_type_label(t["code"], t["name"]) + ("" if t["active"] else " (사용 중지 — 승인해도 적용 안 됨)")) \
            if t else "없음"
    rev = sub.get("kind") == "revision" and bool(sub.get("form_id"))     # 승인된 새 양식도 form_id가 생긴다
    cur = store.form_detail(h.sess.user_id, sub["form_id"])["doc_type_id"] if rev else None
    tid = sub.get("doc_type_id")
    if sub.get("status") != "pending":                         # 처리된 제출 — 그때 고른 종류만
        shown = E(label(tid)) if tid is not None else ('<span class="muted">지금 종류 그대로</span>' if rev else "없음")
    elif rev:
        if tid is None or tid == cur:
            shown = f'{E(label(cur))} <span class="muted">(그대로)</span>'
        else:
            shown = (f'{E(label(cur))} → <b>{E(label(tid))}</b> '
                     f'<span class="muted">(승인하면 바뀝니다 — 문서번호는 그대로)</span>')
    else:
        shown = E(label(tid))
    edit = ""
    if sub.get("status") == "pending" and (types or tid is not None):
        sel = tid if tid is not None else (cur if rev else None)
        empty = "(지금 종류 그대로)" if rev else "(없음)"
        edit = (f'<details class="tool"><summary>승인 전에 문서 종류 고치기</summary>'
                f'<form class="inline" method="post" action="/review/doctype">{_hidden(h)}'
                f'<input type="hidden" name="id" value="{sub["id"]}">'
                f'<select name="doc_type" aria-label="문서 종류">'
                f'{_type_options(types, sel, empty, keep=cur if cur is not None else tid)}</select>'
                f'<button class="btn gray sm" type="submit">종류 저장</button></form></details>')
    return f'<dt>문서 종류</dt><dd>{shown}{edit}</dd>'


def _sub_type_warning(h: FormsHandler, sub: dict) -> str:
    """규칙에 {종류}가 있는데 이대로 승인하면 종류 없이 **새 번호**가 매겨질 때의 경고 (검토 2)."""
    store = h.server.store
    if sub.get("status") != "pending" or not rule_uses_type(parse_docno_pattern(store.docno_rule()["pattern"])[1]):
        return ""
    folder_id, form = sub["folder_id"], None
    if sub.get("form_id"):
        form = store.form_detail(h.sess.user_id, sub["form_id"])
        folder_id = form["folder_id"]
        if form.get("doc_no"):
            return ""                                # 이미 번호가 있는 양식 — 승인해도 번호는 그대로
    form_types = {sub["form_id"]: form["doc_type_id"]} if form else {}
    result = _sub_types(sub, form_types)[2]
    active = {t["id"] for t in store.list_doc_types(h.sess.user_id, active_only=True)}
    if result is not None and (result in active or (form and result == form["doc_type_id"])):
        return ""
    example = store.preview_doc_no(folder_id, None)
    return (f'<div class="note warn" role="status">문서 종류가 없습니다 — 이대로 승인하면 {E(example)}처럼 종류 없이 번호가 '
            f'매겨지고, 나중에 종류를 바꿔도 번호는 그대로입니다.</div>')


def post_review_doctype(h: FormsHandler) -> None:
    """승인 전에 검토 대기 제출의 문서 종류 고치기 — 관리자나 그 폴더 검토자, 검토 대기만(store가 다시 확인). 감사 기록."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    tid = h._int(h._one(f, "doc_type"), required=False)
    store = h.server.store
    try:
        changed = store.set_submission_doc_type(h.sess.user_id, sid, tid, ip=h.ip)
    except InvalidInput as e:
        store.submission(h.sess.user_id, sid)                  # 없는 제출이면 404
        h._flash("bad", f"문서 종류를 바꾸지 않았습니다 — {e}")
        h._redirect(f"/review/item?id={sid}")
        return
    h._flash("ok", "승인 전 문서 종류를 고쳤습니다" if changed else "바뀐 것이 없습니다")
    h._redirect(f"/review/item?id={sid}")


def _doctype_tool(h: FormsHandler, d: dict) -> str:
    """양식의 문서 종류 바꾸기 — 관리자나 그 폴더 검토자(검토 주기와 같은 권한). 번호는 그대로."""
    types = h.server.store.list_doc_types(h.sess.user_id)
    if not types and d.get("doc_type_id") is None:
        return ""
    return (f'<details class="tool"><summary>문서 종류 바꾸기</summary>'
            f'<p class="muted">종류를 바꿔도 이미 매긴 문서번호는 그대로입니다 — 번호 규칙에 {{종류}}가 있고 번호까지 맞추려면 '
            f'관리자가 [문서번호 규칙 › 다시 매기기]를 씁니다.</p>'
            f'<form class="inline" method="post" action="/form/doctype">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{d["id"]}">'
            f'<select name="doc_type" aria-label="문서 종류">'
            f'{_type_options(types, d.get("doc_type_id"), "(없음)", keep=d.get("doc_type_id"))}</select>'
            f'<button class="btn gray sm" type="submit">종류 저장</button></form></details>')


def post_form_doctype(h: FormsHandler) -> None:
    """양식의 문서 종류 바꾸기 — 관리자나 그 폴더 검토자(store가 다시 확인). 빈 값 = 종류 없음."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    tid = h._int(h._one(f, "doc_type"), required=False)
    store = h.server.store
    try:
        changed = store.set_form_doc_type(h.sess.user_id, fid, tid, ip=h.ip)
    except InvalidInput as e:
        store.form_detail(h.sess.user_id, fid)                  # 없는 양식이면 404
        h._flash("bad", f"문서 종류를 바꾸지 않았습니다 — {e}")
        h._redirect(f"/form?id={fid}")
        return
    h._flash("ok", ("문서 종류를 바꿨습니다 — 이미 매긴 문서번호는 그대로입니다" if changed else "바뀐 것이 없습니다"))
    h._redirect(f"/form?id={fid}")


def _docno_tool(h: FormsHandler, d: dict) -> str:
    """문서번호 고치기 — 관리자만 보인다(서버도 관리자만 받는다)."""
    if h.sess.role != "admin":
        return ""
    return (f'<details class="tool"><summary>문서번호 고치기</summary>'
            f'<p class="muted">번호는 처음 승인 때 저절로 매겨지고 폴더를 옮겨도 그대로입니다. 회사 규칙에 맞춰 바꿀 때만 고치세요 '
            f'— 다른 양식이 쓰는 번호는 받지 않습니다.</p>'
            f'<form class="inline" method="post" action="/form/docno">{_hidden(h)}'
            f'<input type="hidden" name="id" value="{d["id"]}">'
            f'<input type="text" class="docno-in" name="doc_no" value="{E(d.get("doc_no") or "")}" maxlength="40" '
            f'aria-label="문서번호" placeholder="예: QA-01-01-001">'
            f'<button class="btn gray sm" type="submit">번호 저장</button></form>{_hint(HINT_DOC_NO)}</details>')


def _register_query(h: FormsHandler) -> bool:
    return h._one(h._query(), "retired") == "1"


def get_register(h: FormsHandler) -> None:
    """문서 관리 대장 화면 — 관리자는 전체, 검토자는 맡은 폴더(상속 포함). 직원은 403. 읽기만."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    retired = _register_query(h)
    reg = store.register(s.user_id, include_retired=retired)
    all_rows = reg["rows"]
    page = _page_of(h, len(all_rows))
    shown = all_rows[page * PAGE_ROWS:(page + 1) * PAGE_ROWS]          # 한 쪽 PAGE_ROWS줄 (2026-10-30 M3, 엑셀은 전부)
    rows = []
    for r in shown:
        no = f'<span class="docno">{E(r["doc_no"])}</span>' if r["doc_no"] else '<span class="none">—</span>'
        if r.get("prev_doc_nos"):
            no += f'<span class="prevno">이전 {E(", ".join(r["prev_doc_nos"]))}</span>'
        if r.get("type_mismatch"):
            no += f'<span class="prevno">{MISMATCH_TEXT}</span>'
        state = '<span class="tag retired">폐기</span>' if r["retired"] else '<span class="tag approved">현행</span>'
        due = (E(r["due"]) + _state_tag(r["state"])) if r["due"] else (
            '<span class="muted">검토 안 함</span>' if r["state"] == "off" else "")
        dt = (f'<span class="tag dtype" title="{E(r["doc_type_name"])}">{E(r["doc_type"])}</span>' if r.get("doc_type")
              else '<span class="none">—</span>')
        rows.append(
            f'<tr><td class="nw">{no}</td><td class="nw">{dt}</td><td class="nw">{E(r["top"])}</td>'
            f'<td class="path-c">{E(r["mid"])}</td>'
            f'<td class="path-c">{E(r["rest"])}</td>'
            f'<td class="name-c"><a href="/form?id={r["id"]}">{E(r["name"])}</a></td>'
            f'<td class="nw">{"v" + str(r["number"]) if r["number"] else ""}</td><td class="nw">{E(r["effective"])}</td>'
            f'<td class="nw">{E(r["approver"])}'
            + (' <span class="muted" title="올린 사람이 직접 승인했습니다">(본인 승인)</span>' if r.get("self_approved") else "")
            + (f'<div class="muted">1단계 검토: {E(r["checker"])}</div>' if r.get("checker") else "")
            + f'</td><td class="reason pre">{E(r["reason"])}</td>'
            f'<td class="nw">{r["revisions"]}</td><td class="nw">{E(r["last_reviewed"]) or "—"}</td>'
            f'<td class="nw">{due}</td><td class="nw">{state}</td></tr>')
    table = ('<div class="tablewrap"><table class="reg"><thead><tr><th>문서번호</th><th>문서 종류</th><th>대분류</th>'
             '<th>중분류</th>'
             '<th>소분류 이하 경로</th><th>양식명</th><th>현행 판</th><th>시행일</th><th>승인자</th><th>개정 사유</th>'
             '<th>개정 횟수</th><th>최근 검토일</th><th>다음 검토 기한</th><th>상태</th></tr></thead><tbody>'
             + "".join(rows) + "</tbody></table></div>") if rows else \
        (_no_assigned_note(h, register=True) or '<p class="empty">아직 승인된 양식이 없습니다</p>')
    table += _pager("/register", {"retired": "1" if retired else ""}, page,
                    len(all_rows) > (page + 1) * PAGE_ROWS, len(all_rows))
    q = "?retired=1" if retired else ""
    toggle = (f'<a class="btn gray sm" href="/register">폐기 양식 빼기</a>' if retired else
              f'<a class="btn gray sm" href="/register?retired=1">폐기 양식도 보기</a>')
    scope = "모든 폴더" if reg["scope_all"] else "내가 검토하는 폴더(하위 포함)"
    dflt = store.default_review_months()
    intro = (f'<p class="muted">ISO 9001 문서 관리용 목록 — 양식마다 문서번호·현행 판·시행일(현행 판 승인일)·승인자·개정 사유·'
             f'개정 횟수(v1 = 제정, 그 뒤 승인마다 1)·정기 검토 기한을 양식함의 승인 기록에서 그대로 만듭니다. 범위: {E(scope)}. '
             f'정기 검토 기본 주기: {f"{dflt}개월" if dflt else "꺼짐"} (다음 기한 = 최근 검토일과 현행 판 승인일 중 늦은 날 + 주기).</p>')
    bar = (f'<div class="searchbar"><a class="btn sm" href="/register.xlsx{q}">엑셀로 내려받기</a>{toggle}'
           f'<a class="btn gray sm" href="/register/due">검토 기한 목록</a>'
           + (f'<a class="btn gray sm" href="/admin/docno">문서번호 규칙</a>' if s.role == "admin" else "")
           + f'<span class="muted">{len(all_rows)}개</span></div>')
    extra = ""
    if s.role == "admin":
        missing = store.missing_doc_no_count()
        if missing:
            extra = (f'<div class="panel"><h2>번호 없는 양식 {missing}개</h2>'
                     f'<p class="muted">문서번호가 생기기 전에 승인된 양식입니다. 누르면 지금 폴더의 번호 머리로 만든 차례대로 '
                     f'번호를 매깁니다(폐기 양식 포함). 한 번 매긴 번호는 바뀌지 않습니다.</p>'
                     f'<form method="post" action="/admin/docno/assign">{_hidden(h)}'
                     f'<button class="btn" type="submit">번호 없는 양식에 번호 매기기</button></form></div>')
    body = f'{_due_banner(h)}<div class="panel">{intro}{bar}{table}</div>{extra}'
    h._send(200, h._shell("문서 관리 대장", body, active="/register"))


def get_register_xlsx(h: FormsHandler) -> None:
    """[엑셀로 내려받기] — 메모리에서 만든 xlsx(디스크 쓰기 없음). 감사 기록(register_export)을 남긴다."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    retired = _register_query(h)
    reg = store.register(s.user_id, include_retired=retired, history=True, retired_list=not retired)
    gen = _fmt_time(now_text(store.clock()))
    scope = "전체" if reg["scope_all"] else "검토하는 폴더"
    downloads = store.download_log(s.user_id, include_retired=retired)       # '내려받은 기록' 시트 (F2-13)
    data = ledger.register_xlsx(reg, generated_at=gen, scope_text=scope, include_retired=retired, downloads=downloads)
    name = f"문서관리대장_{store.today():%Y%m%d}.xlsx"
    store.record_audit(s.user_id, "register_export", "register", ip=h.ip,
                       detail=f"{name} — 양식 {len(reg['rows'])}개 · 판 {len(reg['history'])}개 · "
                              f"내려받은 기록 {len(downloads)}건 · "
                              f"{'폐기 포함' if retired else '현행만'} · 범위 {scope}")
    h._deadline(len(data))
    h._send(200, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            extra=(("Content-Disposition", content_disposition(name)),))
    h.close_connection = True


def get_register_due(h: FormsHandler) -> None:
    """정기 검토 기한 목록 — 지난 것과 30일 안에 오는 것. 줄마다 [검토함 — 바꿀 것 없음](POST)과 개정안 올리기 안내."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    due = store.due_forms(s.user_id)
    page = _page_of(h, len(due))
    shown = due[page * PAGE_ROWS:(page + 1) * PAGE_ROWS]                # 한 쪽 PAGE_ROWS줄 (2026-10-30 M3)
    rows = []
    for r in shown:
        no = f'<span class="docno">{E(r["doc_no"])}</span>' if r["doc_no"] else ""
        act = (f'<form class="inline" method="post" action="/register/reviewed">{_hidden(h)}'
               f'<input type="hidden" name="id" value="{r["id"]}"><input type="hidden" name="back" value="/register/due">'
               f'<input type="text" class="memo" name="memo" maxlength="500" placeholder="메모 (선택)" '
               f'aria-label="{E(r["name"])} 검토 메모"><button class="btn sm" type="submit">검토함 — 바꿀 것 없음</button>'
               f'</form><div class="muted">고칠 것이 있으면 <a href="/upload?form={r["id"]}">개정안 올리기</a></div>')
        # 일괄 [검토함] 고르기 칸 — 표 밖의 양식(id="bulk")에 form 속성으로 붙는다(스크립트 없이, 줄마다의 양식과 겹치지 않게)
        pick = (f'<td class="chk"><input type="checkbox" name="id" value="{r["id"]}" form="bulk" '
                f'aria-label="{E(r["name"])} 고르기"></td>')
        rows.append(f'<tr>{pick}<td class="name-c">{no}<a href="/form?id={r["id"]}">{E(r["name"])}</a>'
                    f'<div class="muted">{E(r["path"])}</div></td>'
                    f'<td class="nw">{E(r["due"])}{_state_tag(r["state"])}</td>'
                    f'<td class="nw">{E(r["last_reviewed"]) or "—"}<div class="muted">시행 {E(r["effective"])}</div></td>'
                    f'<td class="act">{act}</td></tr>')
    table = ('<div class="tablewrap"><table class="due"><thead><tr><th><span class="muted">고르기</span></th><th>양식</th>'
             '<th>다음 검토 기한</th><th>최근 검토</th><th>처리</th></tr></thead><tbody>' + "".join(rows)
             + "</tbody></table></div>") if rows \
        else (_no_assigned_note(h, register=True) or '<p class="empty">기한이 지났거나 곧 오는 양식이 없습니다</p>')
    if rows:
        table += (f'<form id="bulk" class="inline" method="post" action="/register/reviewed-bulk">{_hidden(h)}'
                  f'<input type="text" class="memo" name="memo" maxlength="500" placeholder="메모 하나 (선택, 500자까지)" '
                  f'aria-label="고른 양식 검토 메모">'
                  f'<button class="btn sm" type="submit">고른 양식 검토함 — 바꿀 것 없음 (메모 하나)</button></form>'
                  f'<p class="hint">왼쪽 칸에 체크한 양식을 한꺼번에 오늘 날짜로 검토함으로 적습니다(양식마다 감사 기록). '
                  f'하나라도 권한이 없거나 폐기된 양식이면 아무것도 적지 않습니다.</p>')
        table += _pager("/register/due", {}, page, len(due) > (page + 1) * PAGE_ROWS, len(due))
    over = sum(1 for r in due if r["state"] == "overdue")
    intro = (f'<p class="muted">정기 검토 기한이 지난 양식 <b>{over}개</b>와 {REVIEW_SOON_DAYS}일 안에 오는 양식 '
             f'{len(due) - over}개. 내용을 확인해 바꿀 것이 없으면 [검토함]을 누르세요 — 오늘 날짜로 적히고 다음 기한이 다시 '
             f'셉니다(감사 기록에 남음). 고칠 것이 있으면 개정안을 올리세요 — 새 판이 승인되면 그것이 검토입니다.</p>')
    body = (f'<div class="crumb"><a href="/register">문서 관리 대장</a> / 검토 기한</div>'
            f'<div class="panel">{intro}{table}</div>')
    h._send(200, h._shell("정기 검토 기한", body, active="/register"))


def post_register_reviewed(h: FormsHandler) -> None:
    """[검토함 — 바꿀 것 없음] — 관리자나 그 폴더 검토자 (store가 다시 확인)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    h.server.store.mark_reviewed(h.sess.user_id, fid, h._one(f, "memo"), ip=h.ip)
    h._flash("ok", "정기 검토를 적었습니다 — 오늘부터 다음 기한을 다시 셉니다")
    h._redirect(_safe_back(h._one(f, "back") or "/register/due"))


def post_register_reviewed_bulk(h: FormsHandler) -> None:
    """[고른 양식 검토함] (2026-10-30 M4) — 기한 목록에서 체크한 양식을 메모 하나로 한꺼번에. 양식마다 권한은 store가 본다
    (관리자나 그 폴더 검토자) — 하나라도 안 되면 아무것도 적지 않는다. 감사 기록은 양식마다 한 줄."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    ids = [h._int(v) for v in f.get("id", [])]
    if not ids:
        h._flash("bad", "검토함으로 적을 양식을 왼쪽 칸에서 골라 주세요")
        h._redirect("/register/due")
        return
    try:
        done = h.server.store.mark_reviewed_many(h.sess.user_id, ids, h._one(f, "memo"), ip=h.ip)
    except (Conflict, InvalidInput) as e:
        h._flash("bad", f"검토함으로 적지 않았습니다 — {e}")
        h._redirect("/register/due")
        return
    h._flash("ok", f"양식 {len(done)}개를 검토함으로 적었습니다 — 오늘부터 다음 기한을 다시 셉니다")
    h._redirect("/register/due")


def post_form_review_months(h: FormsHandler) -> None:
    """양식별 검토 주기 — mode: inherit(전체 기본값) / off(안 함) / months(따로, 1~120개월)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    mode = h._one(f, "mode")
    bad = f"검토 주기를 저장하지 않았습니다 — 개월 수는 {HINT_MONTHS}"
    if mode == "inherit":
        months = None
    elif mode == "off":
        months = 0
    elif mode == "months":
        raw = h._one(f, "months").strip()
        # '-1'·'abc'·'0'·'121'은 모두 같은 범위 안내로 (2026-10-30 검토 — 예전엔 '잘못된 번호'·400)
        if not (raw.isascii() and raw.isdigit() and len(raw) <= 4 and 1 <= int(raw) <= REVIEW_MONTHS_MAX):
            store_fd = h.server.store.form_detail(h.sess.user_id, fid)       # 없는 양식이면 404
            h._flash("bad", bad)
            h._redirect(f"/form?id={store_fd['id']}")
            return
        months = int(raw)
    else:
        raise HttpError(400, "검토 주기를 골라 주세요")
    try:
        h.server.store.set_review_months(h.sess.user_id, fid, months, ip=h.ip)
    except (InvalidInput, Conflict) as e:
        h._flash("bad", f"검토 주기를 저장하지 않았습니다 — {e}")
        h._redirect(f"/form?id={fid}")
        return
    h._flash("ok", "검토 주기를 저장했습니다")
    h._redirect(f"/form?id={fid}")


def post_form_docno(h: FormsHandler) -> None:
    """문서번호 고치기 — 관리자만. 다른 양식이 쓰는 번호·형식이 틀린 번호는 받지 않고 화면에 알린다."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    try:
        v = h.server.store.set_doc_no(h.sess.user_id, fid, h._one(f, "doc_no"), ip=h.ip)
    except (Conflict, InvalidInput) as e:
        h.server.store.form_detail(h.sess.user_id, fid)          # 없는 양식이면 404
        h._flash("bad", f"문서번호를 바꾸지 않았습니다 — {e}")
        h._redirect(f"/form?id={fid}")
        return
    h._flash("ok", f"문서번호를 {v}(으)로 정했습니다")
    h._redirect(f"/form?id={fid}")


def post_docno_assign(h: FormsHandler) -> None:
    """[번호 없는 양식에 번호 매기기] — 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    done = h.server.store.assign_missing_doc_numbers(h.sess.user_id, ip=h.ip)
    h._flash("ok", f"양식 {len(done)}개에 문서번호를 매겼습니다" if done else "번호 없는 양식이 없습니다")
    h._redirect("/register")


def post_folder_code(h: FormsHandler) -> None:
    """폴더 번호 머리 — 관리자나 그 폴더 검토자 (이름 바꾸기와 같은 권한, store가 확인)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    back = _safe_back(h._one(f, "back") or f"/forms?folder={fid}")
    if not h.server.store.is_reviewer_of(h.sess.user_id, fid):
        raise PermissionDenied("이 폴더의 검토자만 번호 머리를 바꿀 수 있습니다")
    try:
        v = h.server.store.set_folder_code(h.sess.user_id, fid, h._one(f, "code"), ip=h.ip)
    except (InvalidInput, Conflict) as e:           # 형제와 머리 겹침도 막다른 409 대신 알림 (2026-10-30)
        h._flash("bad", str(e))
        h._redirect(back)
        return
    h._flash("ok", f"번호 머리를 {v}(으)로 정했습니다 — 이미 매긴 문서번호는 그대로입니다" if v
             else "번호 머리를 지웠습니다 — 이미 매긴 문서번호는 그대로입니다")
    h._redirect(back)


# ── 문서번호 규칙·다시 매기기 (F7 번호 규칙, 2026-10-29) ────────────────────────────────
# 관리자만(store도 다시 본다). GET은 읽기만 — ?preset=은 규칙 칸만 채우고 저장하지 않는다. 미리보기는 상태를 바꾸지 않는
# POST(스크립트 없이 서버가 계산), [저장]·[다시 매기기 실행]은 POST + CSRF. 다시 매기기는 미리보기 목록의 지문(digest)과
# 확인 칸이 있어야 돈다 — 그사이 목록이 바뀌면 거부하고 다시 미리보기를 보게 한다.

# 종류 도입 안내 (F7 문서 종류 검토 6) — 일괄 지정은 한 종류만 되므로 다른 종류는 하나씩 고친 뒤 다시 매기기는 한 번만
MISMATCH_TEXT = "(번호의 종류와 다름 — 다시 매기기 필요)"
_ADOPT_GUIDE = ('가장 많은 종류로 한꺼번에 지정하고, 다른 종류인 양식은 <a href="/register">문서 관리 대장</a>에서 찾아 '
                '양식 상세에서 하나씩 고친 뒤 <a href="/admin/docno#renumber">[다시 매기기]</a>를 한 번만 쓰세요 — 다시 매긴 뒤 '
                '종류를 바꾸면 번호는 그대로라 또 매겨야 합니다.')
RENUMBER_SHOW = 500                    # 다시 매기기 미리보기 표에 보이는 줄 상한 (넘으면 '외 N개' — 실행은 전부)
DOCNO_TOKEN_HELP = (
    ("{분류}", "위 폴더들의 번호 머리를 위에서부터 모두 이음 (QA-01-01) — 지금까지의 꼴"),
    ("{대}", "대분류(맨 위 폴더) 머리"), ("{중}", "중분류(2단) 머리"), ("{소}", "소분류(3단) 머리"),
    ("{종류}", "양식의 문서 종류 기호 (QP 절차서·QF 양식…) — 같은 폴더 안에서도 종류마다 따로 셈. 종류가 없으면 빈 칸처럼 빠짐"),
    ("{YYYY}", "그 양식이 처음 승인된 해 네 자리 (2026)"), ("{YY}", "같은 해 두 자리 (26)"),
    ("{번호}", "일련번호 — 맨 끝에 한 번. 머리마다 따로 세고, 해가 들어가면 해마다 001부터"),
)


def _docno_examples_table(rows: list, *, with_type: bool = False) -> str:
    """미리보기 표 — 규칙에 {종류}가 있으면 '문서 종류' 칸을 더한다(없으면 v0.61.0과 같은 표)."""
    def type_cell(r):
        if not with_type:
            return ""
        t = r.get("type") or ""
        return (f'<td class="nw"><span class="tag dtype">{E(t)}</span></td>' if t
                else '<td class="nw"><span class="muted">종류 없음</span></td>')
    trs = "".join(
        f'<tr><td class="path-c">{E(r["path"])}' + (' <span class="muted">(가상)</span>' if r["kind"] == "sample" else "")
        + f'</td><td class="nw">{E(" · ".join(c or "—" for c in r["codes"]) or "—")}</td>{type_cell(r)}'
          f'<td><span class="docno big">{E(r["next"])}</span></td></tr>' for r in rows)
    return ('<div class="tablewrap"><table class="docex"><thead><tr><th>폴더</th><th>폴더 번호 머리 (위부터)</th>'
            + ('<th>문서 종류</th>' if with_type else '')
            + '<th>다음에 매길 번호</th></tr></thead><tbody>' + trs + '</tbody></table></div>')


def _untyped_warning(h: FormsHandler, parts: list, digits: int) -> str:
    """규칙에 {종류}가 있는데 종류가 없는 양식이 있으면 알린다 — 그 양식은 종류 칸 없이 매겨진다 (F7 문서 종류)."""
    if not rule_uses_type(parts):
        return ""
    store = h.server.store
    n = store.untyped_form_count()
    if not n:
        return ""
    sample = store._preview_no(["QA", "01", "02"], parts, digits, store.today().year, scan=False, dtype="")
    return (f'<div class="note warn" role="status">종류가 없는 양식 <b>{n}개</b>는 {{종류}} 칸 없이 매겨집니다 '
            f'(예: 품질 QA / 검사 01 / 수입검사 02 폴더라면 <span class="docno">{E(sample)}</span>, 폴더 머리도 없으면 '
            f'<span class="docno">F-0001</span>) — '
            f'<a href="/admin/doctypes#assign">문서 종류</a>에서 {_ADOPT_GUIDE}</div>')


def _docno_page(h: FormsHandler, *, pattern: str, digits: str, previewing: bool = False, error: str = "",
                plan: dict | None = None, include_manual: bool = False, relocate: bool = False,
                status: int = 200) -> None:
    store, s = h.server.store, h.sess
    rule = store.docno_rule()
    hid = _hidden(h)
    cur = (f'<p>지금 규칙: <b class="docno big">{E(rule["pattern"])}</b> · 일련번호 {rule["digits"]}자리'
           + (' <span class="tag off">기본값</span>' if rule["default"] else "") + '</p>')
    tokens = "".join(f'<li><code>{E(t)}</code> — {E(d)}</li>' for t, d in DOCNO_TOKEN_HELP)
    presets = "".join(f'<a class="btn gray sm" href="/admin/docno?preset={i}" title="{E(d)} · 일련번호 {dg}자리">'
                      f'{E(p)}{" (기본)" if i == 0 else ""}</a>' for i, (p, dg, d) in enumerate(DOCNO_PRESETS))
    p0, d0 = DOCNO_PRESETS[0][0], DOCNO_PRESETS[0][1]
    dflt = "" if rule["default"] else (
        f'<div class="note info" role="status">기본 규칙: <b class="docno big">{E(p0)}</b> · {d0}자리 — '
        f'<a href="/admin/docno?preset=0#rule">기본 규칙으로 되돌리기</a> (칸을 채운 뒤 [저장])</div>')
    note = f'<div class="note bad" role="alert">{E(error)}</div>' if error else ""
    if previewing and not error:
        ex_title = f'<h3>미리보기 — {E(pattern)} · 일련번호 {E(digits)}자리 (아직 저장 안 됨)</h3>'
        examples = store.docno_examples(s.user_id, pattern, digits)
        ex_parts, ex_digits = parse_docno_pattern(pattern)[1], int(digits)
    else:
        ex_title = '<h3>지금 규칙으로 다음에 매길 번호</h3>'
        examples = store.docno_examples(s.user_id)
        ex_parts, ex_digits = parse_docno_pattern(rule["pattern"])[1], rule["digits"]
    with_type = rule_uses_type(ex_parts)
    no_active = ""
    if with_type and not store.list_doc_types(s.user_id, active_only=True):
        no_active = ('<div class="note warn" role="status">사용 중인 문서 종류가 없습니다 — 모든 양식이 종류 없이 매겨집니다. '
                     '<a href="/admin/doctypes">문서 종류</a>에서 더하거나 [다시 사용]으로 돌려 주세요.</div>')
    rule_panel = (
        f'<div class="panel" id="rule"><h2>문서번호 규칙</h2>{dflt}{cur}'
        f'<p class="muted">처음에는 기본 규칙이 적용돼 있고, 회사 체계에 맞게 고칠 수 있습니다. 양식이 <b>처음 승인될 때</b> 이 '
        f'규칙으로 번호를 매깁니다. 규칙을 바꾸면 <b>앞으로 매기는 번호에만</b> '
        f'적용되고 이미 매긴 번호는 그대로입니다(바꾸려면 아래 [다시 매기기]). 칸 밖의 글자는 영문 대문자·숫자·한글과 '
        f'<code>-</code> <code>_</code> <code>.</code>만 쓰고, {{번호}} 바로 앞과 칸과 칸 사이에는 구분자를 하나 넣습니다. '
        f'빈 칸(그 단계 폴더가 없거나 머리가 빔)은 빠지고 이웃 구분자는 하나로 접힙니다. 폴더 머리·문서 종류·고정 글자가 모두 비어 '
        f'해만 남으면 <code>F-0001</code>처럼, 번호가 {MAX_DOC_NO}자를 넘으면 전역 꼴로 매깁니다.</p>'
        f'<ul class="lines tokens">{tokens}</ul>'
        f'<p class="muted">{{종류}}에 들어갈 기호는 <a href="/admin/doctypes">문서 종류</a>에서 관리합니다.</p>{note}'
        f'<form method="post" action="/admin/docno">{hid}'
        f'<label for="dp">번호 규칙</label>{_hint(HINT_DOCNO_RULE)}'
        f'<input type="text" class="pattern" id="dp" name="pattern" value="{E(pattern)}" maxlength="{MAX_DOCNO_PATTERN}" '
        f'required placeholder="예: {{대}}-{{YYYY}}-{{번호}}" spellcheck="false" autocomplete="off">'
        f'<label for="dd">일련번호 자릿수 ({DOCNO_DIGITS_MIN}~{DOCNO_DIGITS_MAX})</label>'
        f'<input type="text" class="months" id="dd" name="digits" value="{E(digits)}" inputmode="numeric" maxlength="1" required>'
        f'<div class="form-actions"><button class="btn gray" type="submit" name="do" value="preview">미리보기</button>'
        f'<button class="btn" type="submit" name="do" value="save">저장</button></div></form>'
        f'<div class="presets"><span class="muted">보기 (누르면 규칙·자릿수 칸만 채웁니다):</span>{presets}</div>'
        f'{ex_title}{_untyped_warning(h, ex_parts, ex_digits)}{no_active}'
        f'{_docno_examples_table(examples, with_type=with_type)}</div>')
    # 폴더 번호 머리 한눈에 — 고치기는 폴더 관리와 같은 POST /folders/code (같은 권한·같은 store 함수)
    flat = h._folders()
    empty = sum(1 for n, _d, _p in flat if not n.get("code"))
    rows = []
    for n, depth, path in flat:
        fid = n["id"]
        rows.append(f'<tr><td class="fname lv{min(depth, 6)}">{E(n["name"])}</td>'
                    f'<td class="nw"><span class="tag lvl">{E(level_name(depth + 1))}</span></td>'
                    f'<td><form class="inline" method="post" action="/folders/code">{hid}'
                    f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="/admin/docno#codes">'
                    f'<input type="text" class="code" name="code" value="{E(n.get("code", ""))}" maxlength="8" '
                    f'aria-label="{E(path)} 번호 머리" placeholder="머리 없음">'
                    f'<button class="btn gray sm" type="submit">머리 저장</button></form></td></tr>')
    codes_table = ('<details class="tool"><summary>폴더 번호 머리 보기·고치기</summary>'
                   '<div class="tablewrap"><table class="ftree"><thead><tr><th>폴더</th><th>층</th><th>번호 머리</th></tr>'
                   '</thead><tbody>' + "".join(rows) + '</tbody></table></div></details>') if rows else \
        '<p class="empty">아직 폴더가 없습니다</p>'
    codes_panel = (f'<div class="panel" id="codes"><h2>폴더 번호 머리</h2>'
                   f'<p class="muted">폴더 {len(flat)}개 중 <b>머리가 빈 폴더 {empty}개</b>. 규칙의 {{분류}}·{{대}}·{{중}}·{{소}} 칸은 '
                   f'이 머리로 채워집니다(영문·숫자·한글 1~8자, 가운데 \'.\' 가능 — 7.5, 같은 위 폴더 아래 형제끼리는 겹칠 수 없음). '
                   f'<a href="/admin/folders">폴더 관리</a>에서도 고칠 수 있습니다.</p>{_hint(HINT_FOLDER_CODE)}'
                   f'{codes_table}</div>')
    # 다시 매기기
    chk = " checked" if include_manual else ""
    chk2 = " checked" if relocate else ""
    ren = (f'<div class="panel" id="renumber"><h2>기존 번호를 지금 규칙으로 다시 매기기</h2>'
           f'<p class="muted">처음 규칙을 정한 회사용입니다. 현행 판이 있는 양식(폐기 포함)의 번호를 <b>저장된 지금 규칙</b>으로 '
           f'다시 매깁니다. 이미 규칙 꼴인 번호는(폴더를 옮긴 양식이라도 어느 폴더 머리로든 맞으면) 그대로 두고, 머리는 맞는데 '
           f'자릿수만 다르면 일련을 지켜 0 채움만 바꿉니다(QA-001 → QA-0001). 나머지는 옛 번호 차례대로 머리마다 지난 번호 '
           f'다음부터 매깁니다(지난 번호·이전 번호는 다시 쓰지 않음). 바뀐 양식의 <b>이전 번호</b>는 양식 상세·문서 관리 대장·엑셀에 남습니다. '
           f'먼저 [미리보기]로 목록을 보고, 확인 칸에 체크해야 실행됩니다.</p>'
           f'<form method="post" action="/admin/docno/renumber">{hid}'
           f'<label class="chk" for="rm"><input type="checkbox" id="rm" name="manual" value="1"{chk}>'
           f'손으로 고친 번호도 다시 매기기 (기본: 손 번호는 그대로)</label>'
           f'<label class="chk" for="rl"><input type="checkbox" id="rl" name="moved" value="1"{chk2}>'
           f'옮긴 양식도 지금 있는 폴더의 머리로 다시 매기기 (기본: 번호는 폴더를 옮겨도 그대로)</label>'
           f'<div class="form-actions"><button class="btn gray" type="submit" name="do" value="preview">다시 매기기 미리보기'
           f'</button></div></form>')
    if plan is not None:
        changed = plan["changed"]
        ren_type = rule_uses_type(parse_docno_pattern(plan["rule"]["pattern"])[1])
        summary = (f'<p>바뀌는 양식 <b>{len(changed)}개</b> · 그대로 {plan["same"]}개'
                   + (f' · 손 번호라 뺀 양식 {plan["manual_kept"]}개' if plan["manual_kept"] else "")
                   + f' — 규칙 <span class="docno">{E(plan["rule"]["pattern"])}</span>, 일련번호 {plan["rule"]["digits"]}자리</p>')
        if changed:
            trs = []
            for r in changed[:RENUMBER_SHOW]:
                marks = "".join(x for x in (
                    ' <span class="tag pending">손 번호</span>' if r["manual"] else "",
                    ' <span class="tag off">자릿수만</span>' if r.get("reformat") else "",
                    ' <span class="tag retired">폐기</span>' if r["retired"] else "",
                    f' <span class="tag off" title="규칙대로면 {E(r["fallback"])}">전역 꼴</span>' if r["global"] else ""))
                tcell = ""
                if ren_type:
                    tcell = (f'<td class="nw"><span class="tag dtype">{E(r["type"])}</span></td>' if r.get("type")
                             else '<td class="nw"><span class="muted">없음</span></td>')
                trs.append(f'<tr><td class="nw"><span class="docno">{E(r["old"]) or "(없음)"}</span></td>'
                           f'<td class="nw"><b class="docno">{E(r["new"])}</b></td>'
                           f'<td class="name-c"><a href="/form?id={r["id"]}">{E(r["name"])}</a>{marks}</td>{tcell}'
                           f'<td class="path-c">{E(r["path"])}</td></tr>')
            more = (f'<p class="muted">외 {len(changed) - RENUMBER_SHOW}개는 줄였습니다 — 실행하면 모두 바뀝니다.</p>'
                    if len(changed) > RENUMBER_SHOW else "")
            table = ('<div class="tablewrap"><table class="renum"><thead><tr><th>지금 번호</th><th>새 번호</th><th>양식</th>'
                     + ('<th>문서 종류</th>' if ren_type else '')
                     + '<th>폴더</th></tr></thead><tbody>' + "".join(trs) + '</tbody></table></div>' + more)
            run = (f'<form method="post" action="/admin/docno/renumber">{hid}'
                   f'<input type="hidden" name="do" value="run"><input type="hidden" name="digest" value="{E(plan["digest"])}">'
                   + ('<input type="hidden" name="manual" value="1">' if plan["include_manual"] else "")
                   + ('<input type="hidden" name="moved" value="1">' if plan.get("relocate") else "")
                   + f'<label class="chk" for="rc"><input type="checkbox" id="rc" name="confirm" value="1" required>'
                     f'위 목록대로 양식 {len(changed)}개의 문서번호를 바꾸는 것을 확인합니다</label>'
                     f'<div class="form-actions"><button class="btn red" type="submit">다시 매기기 실행</button></div></form>')
        else:
            table, run = '<p class="empty">바꿀 번호가 없습니다 — 모두 지금 규칙 꼴입니다</p>', ""
        ren += f'<h3>미리보기</h3>{summary}{table}{run}'
    ren += '</div>'
    # 기능 검토 F2-5 (2026-11-02): 위에 '지금 규칙·예시·[바꾸기]' 한 덩이, 규칙 고치기·폴더 머리 표·다시 매기기는 접어 둔다.
    # 바꾸는 중(미리보기·오류·보기 단추)이거나 다시 매기기 미리보기를 보는 중이면 그 칸을 펼친다.
    now_ex = store.docno_examples(s.user_id)[:1]
    ex_line = (f'<p>예: <span class="docno big">{E(now_ex[0]["next"])}</span> '
               f'<span class="muted">({E(now_ex[0]["path"])} 폴더에서 다음에 매길 번호)</span></p>') if now_ex else ""
    if h.command == "POST":
        editing = plan is None                      # 규칙 [미리보기]·[저장] 오류 뒤에는 펼친 채, 다시 매기기 미리보기는 그 칸만
    else:
        editing = previewing or bool(error) or h._one(h._query(), "preset") != ""
    summary_panel = (f'<div class="panel"><h2>지금 규칙</h2>{cur}{ex_line}'
                     f'<p class="muted">처음 승인되는 양식에 이 규칙으로 번호를 매깁니다. 이미 매긴 번호는 규칙을 바꿔도 그대로입니다. '
                     f'<a href="/admin/doctypes">문서 종류</a>(규칙의 {{종류}} 칸)도 여기서 관리합니다.</p></div>')
    fold = lambda inner, sid, label, opened: (           # noqa: E731
        f'<details class="tool" id="{sid}"{" open" if opened else ""}><summary>{label}</summary>{inner}</details>')
    body = (summary_panel
            + fold(rule_panel, "rule-box", "바꾸기 — 번호 규칙 고치기·보기", editing)
            + fold(codes_panel, "codes-box", f"폴더 번호 머리 ({len(flat)}개 중 빈 머리 {empty}개)", False)
            + fold(ren, "renumber-box", "기존 번호를 지금 규칙으로 다시 매기기", plan is not None))
    h._send(status, h._shell("문서번호 규칙", body, active="/admin/docno"))


def get_admin_docno(h: FormsHandler) -> None:
    """문서번호 규칙 화면 — 관리자만. 읽기만: ?preset=N 은 규칙 칸만 채운다(저장은 [저장] POST)."""
    _require_admin(h)
    rule = h.server.store.docno_rule()
    pattern, digits = rule["pattern"], str(rule["digits"])
    k = h._int(h._one(h._query(), "preset"), required=False)
    if k is not None:
        if not 0 <= k < len(DOCNO_PRESETS):
            raise HttpError(400, "없는 보기입니다")
        pattern, digits = DOCNO_PRESETS[k][0], str(DOCNO_PRESETS[k][1])      # 규칙과 자릿수를 함께 채운다
    _docno_page(h, pattern=pattern, digits=digits)


def post_admin_docno(h: FormsHandler) -> None:
    """[미리보기](상태 안 바꿈) / [저장](규칙 저장 — 앞으로 매기는 번호에만) — 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    pattern, digits_s = h._one(f, "pattern")[:200], h._one(f, "digits")[:12]
    do = h._one(f, "do")
    if do not in ("preview", "save"):
        raise HttpError(400, "할 일을 골라 주세요")
    store = h.server.store
    try:
        digits = h._int(digits_s, required=False)
        if digits is None:
            raise InvalidInput(f"일련번호 자릿수를 {DOCNO_DIGITS_MIN}~{DOCNO_DIGITS_MAX}로 적어 주세요")
        if do == "preview":
            store.docno_examples(h.sess.user_id, pattern, digits)          # 틀린 규칙이면 여기서 InvalidInput
            shown = parse_docno_pattern(pattern)[0]                 # 고른 꼴(대문자·전각 접기)을 칸에 돌려준다
            _docno_page(h, pattern=shown, digits=str(digits), previewing=True)
            return
        old = store.docno_rule()
        rule = store.set_docno_rule(h.sess.user_id, pattern, digits, ip=h.ip)
    except (InvalidInput, HttpError) as e:
        msg = e.message if isinstance(e, HttpError) else str(e)
        _docno_page(h, pattern=pattern, digits=digits_s, error=f"{'저장하지 않았습니다' if do == 'save' else '미리보기를 못 했습니다'} — {msg}",
                    status=400 if do == "save" else 200)
        return
    same = (old["pattern"], old["digits"]) == (rule["pattern"], rule["digits"])
    h._flash("ok", "바뀐 것이 없습니다" if same else
             f"번호 규칙을 {rule['pattern']}(일련번호 {rule['digits']}자리)로 저장했습니다 — 앞으로 처음 승인되는 양식부터 "
             f"적용되고 이미 매긴 번호는 그대로입니다")
    h._redirect("/admin/docno")


def post_admin_docno_renumber(h: FormsHandler) -> None:
    """[다시 매기기 미리보기](상태 안 바꿈) / 실행(확인 칸 + 미리보기 지문) — 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    manual = h._one(f, "manual") == "1"
    moved = h._one(f, "moved") == "1"
    do = h._one(f, "do")
    rule = store.docno_rule()
    here = dict(pattern=rule["pattern"], digits=str(rule["digits"]), include_manual=manual, relocate=moved)
    if do == "preview":
        _docno_page(h, plan=store.renumber_plan(s.user_id, include_manual=manual, relocate=moved), **here)
        return
    if do != "run":
        raise HttpError(400, "할 일을 골라 주세요")
    digest = h._one(f, "digest")
    if not re.fullmatch(r"[0-9a-f]{64}", digest or ""):
        raise HttpError(400, "미리보기를 먼저 보고 실행해 주세요")
    if h._one(f, "confirm") != "1":
        raise HttpError(400, "확인 칸에 체크해야 다시 매깁니다")
    try:
        done = store.renumber(s.user_id, include_manual=manual, relocate=moved, expect=digest, ip=h.ip)
    except Conflict as e:
        h._flash("bad", str(e))
        h._redirect("/admin/docno#renumber")
        return
    h._flash("ok", f"양식 {len(done)}개의 문서번호를 다시 매겼습니다 — 이전 번호는 양식 상세·문서 관리 대장에 남습니다"
             if done else "바꿀 번호가 없었습니다")
    h._redirect("/admin/docno")


# ── 문서 종류 (F7 문서 종류, 2026-10-29) ──────────────────────────────────────────────
# 관리자만(store도 다시 본다). GET은 읽기만, 바꾸기는 모두 POST + CSRF, 바뀔 때마다 감사 기록. 종류·기호를 바꿔도 이미 매긴
# 문서번호는 그대로 — 규칙에 {종류}를 넣고 번호까지 맞추려면 [문서번호 규칙 › 다시 매기기].

def get_admin_doctypes(h: FormsHandler) -> None:
    """문서 종류 화면 — 목록(기호·이름 고치기, 사용 중지·다시 사용, 안 쓰는 것 지우기), 더하기, 종류 없는 양식 한꺼번에 지정."""
    _require_admin(h)
    store, s = h.server.store, h.sess
    types = store.list_doc_types(s.user_id)
    hid = _hidden(h)
    rule = store.docno_rule()
    uses = rule_uses_type(parse_docno_pattern(rule["pattern"])[1])
    rows = []
    for t in types:
        tid = t["id"]
        state = ('<span class="tag approved">사용 중</span>' if t["active"] else '<span class="tag off">사용 중지</span>')
        use = f'양식 {t["used"]}개' + (f' · 검토 대기 {t["pending"]}건' if t["pending"] else "")
        edit = (f'<form class="inline" method="post" action="/admin/doctypes/edit">{hid}'
                f'<input type="hidden" name="id" value="{tid}">'
                f'<input type="text" class="code" name="code" value="{E(t["code"])}" maxlength="8" required '
                f'aria-label="{E(t["name"])} 기호">'
                f'<input type="text" class="tname" name="name" value="{E(t["name"])}" maxlength="{MAX_DOC_TYPE_NAME}" '
                f'required aria-label="{E(t["code"])} 이름">'
                f'<button class="btn gray sm" type="submit">저장</button></form>')
        toggle = (f'<form class="inline" method="post" action="/admin/doctypes/active">{hid}'
                  f'<input type="hidden" name="id" value="{tid}"><input type="hidden" name="on" value="{0 if t["active"] else 1}">'
                  f'<button class="btn gray sm" type="submit">{"사용 중지" if t["active"] else "다시 사용"}</button></form>')
        delete = ""
        if not t["used"] and not t["pending"]:
            delete = (f'<form class="inline" method="post" action="/admin/doctypes/delete">{hid}'
                      f'<input type="hidden" name="id" value="{tid}">'
                      f'<button class="btn red sm" type="submit">지우기</button></form>')
        rows.append(f'<tr><td class="nw"><span class="tag dtype">{E(t["code"])}</span></td>'
                    f'<td class="name-c">{E(t["name"])}</td><td class="nw">{state}</td><td class="nw">{E(use)}</td>'
                    f'<td>{edit}</td><td class="nw">{toggle}{delete}</td></tr>')
    table = (_hint("기호: " + HINT_TYPE_CODE) + _hint("이름: " + HINT_TYPE_NAME)
             + '<div class="tablewrap"><table class="dtypes"><thead><tr><th>기호</th><th>이름</th><th>상태</th><th>쓰는 양식</th>'
             '<th>기호·이름 고치기</th><th>상태 바꾸기</th></tr></thead><tbody>' + "".join(rows) + '</tbody></table></div>') if rows \
        else '<p class="empty">문서 종류가 없습니다 — 아래에서 더해 주세요</p>'
    intro = (f'<p class="muted">ISO 문서 체계처럼 같은 부서 폴더 안에서도 <b>문서 종류마다 번호를 따로</b> 셀 때 씁니다 — 번호 규칙에 '
             f'<code>{{종류}}</code>를 넣으면(예: <code>{{종류}}-{{대}}-{{번호}}</code>) 절차서는 <span class="docno">QP-QA-001</span>, '
             f'양식은 <span class="docno">QF-QA-001</span>처럼 종류마다 001부터 매깁니다. 직원은 양식을 올릴 때 종류를 고르고(선택), '
             f'검토자는 양식 상세에서 바꿀 수 있습니다. 종류나 기호를 바꿔도 <b>이미 매긴 번호는 그대로</b>입니다(번호까지 바꾸려면 '
             f'<a href="/admin/docno#renumber">다시 매기기</a>). [사용 중지]한 종류는 고르기에서 숨고 이미 그 종류인 양식은 그대로이며, '
             f'쓰는 양식이 없는 종류만 지울 수 있습니다. 기호는 영문·숫자·한글 1~8자(가운데 \'.\' 가능, \'F\'는 안 됨).</p>'
             + ('' if uses else f'<div class="note info" role="status">지금 번호 규칙(<span class="docno">{E(rule["pattern"])}</span>)에는 '
                f'{{종류}}가 없어 종류가 번호에 들어가지 않습니다 — 번호에 넣으려면 '
                f'<a href="/admin/docno?preset={_iso_preset()}#rule">문서번호 규칙</a>에서 정하세요.</div>'))
    add = (f'<h3>종류 더하기</h3><form method="post" action="/admin/doctypes/new">{hid}'
           f'<label for="tc">기호</label><input type="text" class="code" id="tc" name="code" maxlength="8" required '
           f'placeholder="예: QS" spellcheck="false" autocomplete="off">{_hint(HINT_TYPE_CODE)}'
           f'<label for="tn">이름</label><input type="text" class="tname" id="tn" name="name" maxlength="{MAX_DOC_TYPE_NAME}" '
           f'required placeholder="예: 규격서">{_hint(HINT_TYPE_NAME)}'
           f'<div class="form-actions"><button class="btn" type="submit">더하기</button></div></form>')
    untyped = store.untyped_form_count()
    active = [t for t in types if t["active"]]
    if untyped and active:
        assign = (f'<div class="panel" id="assign"><h2>종류가 없는 양식 {untyped}개</h2>'
                  f'<p class="muted">이주 전에 올라왔거나 종류를 고르지 않은 양식입니다(폐기 포함). [지정]은 한 종류로만 '
                  f'한꺼번에 정하고 문서번호는 바꾸지 않습니다. {_ADOPT_GUIDE}</p>'
                  f'<form class="inline" method="post" action="/admin/doctypes/assign">{hid}'
                  f'<select name="doc_type" aria-label="지정할 문서 종류" required>'
                  + "".join(f'<option value="{t["id"]}">{E(_type_label(t["code"], t["name"]))}</option>' for t in active)
                  + f'</select><button class="btn sm" type="submit">종류가 없는 양식 {untyped}개를 이 종류로 지정</button>'
                    f'</form></div>')
    elif untyped:
        assign = (f'<div class="panel" id="assign"><h2>종류가 없는 양식 {untyped}개</h2>'
                  f'<p class="muted">사용 중인 종류가 없어 지정할 수 없습니다 — 먼저 종류를 더하거나 [다시 사용]으로 돌려 주세요.</p></div>')
    else:
        assign = ('<div class="panel" id="assign"><h2>종류가 없는 양식</h2>'
                  '<p class="muted">없습니다 — 모든 양식에 종류가 있습니다. 번호 규칙에 {종류}가 있고 번호를 종류에 맞추려면 '
                  '<a href="/admin/docno#renumber">문서번호 규칙 › 다시 매기기</a>.</p></div>')
    body = f'<div class="panel">{intro}{table}{add}</div>{assign}'
    h._send(200, h._shell("문서 종류", body, active="/admin/docno",
                          actions='<a class="btn gray" href="/admin/docno">문서번호 규칙</a>'))


def _iso_preset() -> int:
    """{종류}가 든 첫 보기 번호 (문서번호 규칙 화면의 ?preset=)."""
    return next((i for i, (p, _d, _t) in enumerate(DOCNO_PRESETS) if "{종류}" in p), 0)


def _doctype_back(h: FormsHandler, kind: str, msg: str) -> None:
    h._flash(kind, msg)
    h._redirect("/admin/doctypes")


def post_doctype_new(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    try:
        tid = h.server.store.create_doc_type(h.sess.user_id, h._one(f, "code"), h._one(f, "name"), ip=h.ip)
    except (InvalidInput, Conflict) as e:
        _doctype_back(h, "bad", f"종류를 더하지 않았습니다 — {e}")
        return
    t = next(x for x in h.server.store.list_doc_types(h.sess.user_id) if x["id"] == tid)
    _doctype_back(h, "ok", f"문서 종류를 더했습니다 — {t['code']} {t['name']}")


def post_doctype_edit(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "id"))
    try:
        done = h.server.store.update_doc_type(h.sess.user_id, tid, code=h._one(f, "code"), name=h._one(f, "name"),
                                              ip=h.ip)
    except (InvalidInput, Conflict) as e:
        _doctype_back(h, "bad", f"바꾸지 않았습니다 — {e}")
        return
    if not (done["code"] or done["name"]):
        _doctype_back(h, "ok", "바뀐 것이 없습니다")
        return
    said = []
    if done["code"]:
        said.append(f"기호: {done['code'][0]} → {done['code'][1]} (이미 매긴 문서번호는 그대로)")
    if done["name"]:
        said.append(f"이름: {done['name'][0]} → {done['name'][1]}")
    _doctype_back(h, "ok", "문서 종류를 바꿨습니다 — " + ", ".join(said))


def post_doctype_active(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "id"))
    on = h._one(f, "on")
    if on not in ("0", "1"):
        raise HttpError(400, "사용 중지인지 다시 사용인지 골라 주세요")
    changed = h.server.store.set_doc_type_active(h.sess.user_id, tid, on == "1", ip=h.ip)
    _doctype_back(h, "ok", ("다시 사용합니다 — 올리기 화면에서 고를 수 있습니다" if on == "1" else
                            "사용 중지했습니다 — 고르기에서 숨고, 이미 그 종류인 양식은 그대로입니다") if changed
                  else "바뀐 것이 없습니다")


def post_doctype_delete(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "id"))
    try:
        code = h.server.store.delete_doc_type(h.sess.user_id, tid, ip=h.ip)
    except Conflict as e:
        _doctype_back(h, "bad", str(e))
        return
    _doctype_back(h, "ok", f"문서 종류를 지웠습니다 — {code}")


def post_doctype_assign(h: FormsHandler) -> None:
    """[종류가 없는 양식 N개를 이 종류로 지정] — 관리자만. 번호는 그대로."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "doc_type"))
    try:
        n = h.server.store.assign_type_to_untyped(h.sess.user_id, tid, ip=h.ip)
    except InvalidInput as e:
        _doctype_back(h, "bad", f"지정하지 않았습니다 — {e}")
        return
    _doctype_back(h, "ok", f"종류가 없는 양식 {n}개에 종류를 지정했습니다 — 문서번호는 그대로입니다. 다른 종류인 양식을 "
                           f"양식 상세에서 고친 뒤 [문서번호 규칙 › 다시 매기기]를 한 번 쓰세요(아래 안내)" if n
                  else "종류가 없는 양식이 없습니다")


# ── 관리자 ─────────────────────────────────────────────────────────────────

def _require_admin(h: FormsHandler) -> None:
    if h.sess.role != "admin":
        raise HttpError(403, "관리자만 " + ("할" if h.command == "POST" else "볼") + " 수 있습니다")


def _role_options(cur: str) -> str:
    return "".join(f'<option value="{r}"{" selected" if r == cur else ""}>{ROLE_LABEL[r]}</option>'
                   for r in ("member", "reviewer", "admin"))


def get_admin_users(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    users = auth.list_users(store, s.user_id)
    csrf = E(s.csrf)
    hid = f'<input type="hidden" name="csrf" value="{csrf}">'
    dr = h.server.draft_pop(s.token, "user")                    # 막혔던 등록의 적은 글자 (2026-10-30 검토)
    last = store.last_logins()                                  # 마지막 로그인 (ux21 forms 4) — 감사 기록·세션에서
    rows = []
    for u in users:
        uid = u["id"]
        state = '<span class="tag off">정지</span>' if u["disabled"] else '<span class="tag approved">사용 중</span>'
        if u["must_change"]:
            state += ' <span class="tag pending">임시 비밀번호</span>'
        toggle = (f'<form class="inline" method="post" action="/admin/users/disable">{hid}'
                  f'<input type="hidden" name="id" value="{uid}"><input type="hidden" name="disabled" '
                  f'value="{0 if u["disabled"] else 1}"><button class="btn gray sm" type="submit">'
                  f'{"복구" if u["disabled"] else "정지"}</button></form>')
        reset = (f'<form class="inline" method="post" action="/admin/users/reset">{hid}'
                 f'<input type="hidden" name="id" value="{uid}"><button class="btn gray sm" type="submit">'
                 f'비밀번호 초기화</button></form>')
        role = (f'<form class="inline" method="post" action="/admin/users/role">{hid}'
                f'<input type="hidden" name="id" value="{uid}"><select name="role" aria-label="역할">'
                f'{_role_options(u["role"])}</select><button class="btn gray sm" type="submit">역할 바꾸기</button></form>')
        mail = (f'<form class="inline" method="post" action="/admin/users/email">{hid}'
                f'<input type="hidden" name="id" value="{uid}"><input type="email" name="email" '
                f'value="{E(u.get("email") or "")}" maxlength="254" placeholder="알림 메일(선택)" aria-label="메일 주소">'
                f'<button class="btn gray sm" type="submit">저장</button></form>')
        chg = f'<td class="nw">{_changes.access_cell(h, u)}</td>' if h.server.watch_log is not None else ""   # 변경 브리핑 열람 (갈래 N)
        last_txt = E(_fmt_time(last.get(uid))) or '<span class="muted">없음</span>'
        rows.append(f'<tr><td>{E(u["login"])}</td><td class="nw">{E(u["display_name"])}</td>'
                    f'<td><span class="tag role">{E(ROLE_LABEL.get(u["role"], u["role"]))}</span></td>'
                    f'<td>{state}</td><td class="nw">{E(_fmt_time(u["created_at"]))}</td>'
                    f'<td class="nw lastlogin">{last_txt}</td>'
                    f'<td>{mail}</td>{chg}<td>{role}{toggle}{reset}</td></tr>')
    table = (_hint("메일: " + HINT_EMAIL)
             + "<table><thead><tr><th>아이디</th><th>이름</th><th>역할</th><th>상태</th><th>만든 날</th>"
               '<th title="감사 기록(보존 상한 안)과 지금 열린 접속에서 찾은 마지막 로그인">마지막 로그인</th><th>메일</th>'
             + ('<th title="양식함 메뉴 [변경 확인]에서 감시 변경을 보고 확인할 수 있는 범위 — 기본 끔">변경 열람</th>'
                if h.server.watch_log is not None else "")
             + "<th>관리</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>")
    # 계정 목록이 먼저, 한 명 등록은 접어 둔다 (ux21 forms 10) — 막혔던 등록(적은 글자 있음)이면 펼친 채로
    reg = (f'<div class="panel" id="new"><details class="tool fold"{" open" if dr else ""}>'
           f'<summary>+ 직원 한 명 등록</summary>'
           + (f'<div class="note bad" role="status">{E(dr["err"])}</div>' if dr.get("err") else "") +
           f'<p class="muted">등록하면 임시 비밀번호가 <b>한 번만</b> 보입니다. 직원은 첫 로그인 때 비밀번호를 바꿉니다. '
           f'검토자는 [폴더 관리]에서 맡을 폴더를 정해 주세요.</p>'
           f'<form method="post" action="/admin/users/new">{hid}'
           f'<label for="ul">아이디</label><input type="text" id="ul" name="login" required maxlength="32" '
           f'value="{E(dr.get("login", ""))}" placeholder="예: kim.cs">{_hint(HINT_LOGIN)}'
           f'<label for="un">이름</label><input type="text" id="un" name="display_name" required maxlength="40" '
           f'value="{E(dr.get("display_name", ""))}" placeholder="예: 김철수 (생산팀)">{_hint(HINT_DISPLAY_NAME)}'
           f'<label for="ur">역할</label><select id="ur" name="role">'
           f'{_role_options(dr.get("role") if dr.get("role") in ROLE_LABEL else "member")}</select>'
           f'<label for="ue">메일 주소 (선택 — 승인·반려·새 판 알림을 받을 주소)</label>'
           f'<input type="email" id="ue" name="email" maxlength="254" value="{E(dr.get("email", ""))}" '
           f'placeholder="예: kim@company.co.kr">{_hint(HINT_EMAIL)}'
           f'<div class="form-actions"><button class="btn" type="submit">등록</button></div></form></details></div>')
    roles = ('<p class="muted">관리자: 전부 + 계정·검토자 지정·감사 기록 · 검토자: 맡은 폴더에서 폴더 만들기·승인·반려 · '
             '직원: 보기·내려받기·올리기(검토 대기) — 기밀 폴더는 고른 사람만 봅니다. 마지막 관리자는 정지·강등할 수 없습니다.</p>')
    # 여러 명 한꺼번에 (기능 검토 F2-2) — 미리보기 → 등록 → 결과 표(임시 비밀번호 한 번에, 인쇄용)
    bulk = (f'<div class="panel" id="bulk"><h2>여러 명 한꺼번에 등록</h2>'
            f'<p class="muted">한 줄에 한 사람씩 <code>아이디 이름 [메일] [역할]</code> — 엑셀에서 열을 그대로 붙여 넣어도 됩니다(탭·쉼표·빈칸으로 '
            f'나눔). 맨 위 머리글 줄(아이디·이름·메일…)째 붙여 넣으면 칸 이름대로 읽고, 부서처럼 쓰지 않는 칸은 빼 둡니다. '
            f'역할은 직원·검토자·관리자(비우면 직원). 먼저 미리보기로 확인하고, 틀린 줄은 건너뜁니다.</p>'
            f'<form method="post" action="/admin/users/bulk">{hid}<input type="hidden" name="do" value="preview">'
            f'<label for="bl">등록할 사람들</label><textarea id="bl" name="lines" rows="6" maxlength="60000" '
            f'placeholder="kim.cs 김철수 kim@company.co.kr&#10;lee.yh 이영희 검토자&#10;park 박민수"></textarea>'
            f'{_hint(f"{BULK_MAX}줄까지 · 아이디: " + HINT_LOGIN)}'
            + ('<label class="chk" for="bm0"><input type="checkbox" id="bm0" name="mail" value="1">메일 주소가 있는 사람에게 '
               '임시 비밀번호를 메일로 보내기 (사내 메일 서버 — 기본 끔)</label>' if h.server.notifier is not None else "")
            + '<div class="form-actions"><button class="btn gray" type="submit">미리보기</button></div></form></div>')
    h._send(200, h._shell("계정", f'<div class="panel"><h2>계정 목록</h2>{roles}<div class="tablewrap">{table}</div></div>'
                                  f'{reg}{bulk}{_locked_ips_panel(h, hid)}', active="/admin/users"))


def _locked_ips_panel(h: FormsHandler, hid: str) -> str:
    """잠긴 접속 주소 — 주소 잠금(아이디 상관없이 실패가 많음)과 계정+주소 잠금. 관리자가 풀 수 있다 (보안 F2)."""
    rows = auth.locked_ips(h.server.store, h.sess.user_id)
    intro = (f'<p class="muted">한 접속 주소에서 아이디 상관없이 {auth.IP_WINDOW // 60}분 안에 {auth.IP_THRESHOLD}번 틀리면 '
             f'그 주소의 로그인을 {auth.IP_LOCK_SECONDS // 60}분 막습니다(비밀번호 대입 막기). 회사 공유기를 같이 쓰는 PC들은 '
             f'바깥에서 보기에 같은 주소라 <b>함께 막힐 수 있습니다</b> — 직원이 몰라서 틀린 것이 확실하면 여기서 풀어 주세요.</p>')
    if not rows:
        return f'<div class="panel" id="locked"><h2>잠긴 접속 주소</h2>{intro}<p class="empty">지금 잠긴 주소가 없습니다</p></div>'
    trs = []
    for r in rows:
        what = (f'주소 잠금 — {r["count"]}번 실패' if r["kind"] == "ip" else "") + \
               (f'{" · " if r["kind"] == "ip" else ""}계정 잠금 {r["accounts"]}개' if r["accounts"] else "")
        trs.append(f'<tr><td class="nw">{E(r["ip"])}</td><td>{E(what)}</td>'
                   f'<td class="nw">{E(auth._left_text(r["seconds"]))} 남음</td>'
                   f'<td><form class="inline" method="post" action="/admin/unlock-ip">{hid}'
                   f'<input type="hidden" name="ip" value="{E(r["ip"])}">'
                   f'<button class="btn gray sm" type="submit">잠금 풀기</button></form></td></tr>')
    table = ("<table><thead><tr><th>접속 주소</th><th>까닭</th><th>남은 시간</th><th></th></tr></thead><tbody>"
             + "".join(trs) + "</tbody></table>")
    return f'<div class="panel" id="locked"><h2>잠긴 접속 주소</h2>{intro}{table}</div>'


def post_unlock_ip(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    target = h._one(f, "ip").strip()
    done = auth.unlock_ip(h.server.store, h.sess.user_id, target, ip=h.ip)
    h._flash("ok", f"{target} 주소의 잠금을 풀었습니다" if done else f"{target} 주소는 잠겨 있지 않습니다")
    h._redirect("/admin/users#locked")


def _secret_page(h: FormsHandler, title: str, who: str, temp: str, lead: str, *, reviewer: bool = False,
                 disabled: bool = False) -> None:
    # 검토자를 등록했으면 다음 할 일(맡을 폴더 정하기)로 바로 (기능 검토 F2-9)
    nxt = ('<a class="btn" href="/admin/folders">맡을 폴더 정하기</a>'
           '<a class="btn gray" href="/admin/users">계정 목록으로</a>') if reviewer else \
        '<a class="btn" href="/admin/users">계정 목록으로</a>'
    # 정지된 계정이면 새 비밀번호로도 로그인할 수 없다 — 먼저 알린다 (ux21 forms 12)
    stop = ('<div class="note warn" role="status"><b>정지 중인 계정입니다</b> — 계정 목록에서 [복구]해야 이 비밀번호로 '
            '로그인할 수 있습니다.</div>') if disabled else ""
    body = (f'<div class="panel"><div class="note ok">{E(lead)}</div>{stop}'
            f'<p><b>{E(who)}</b>의 임시 비밀번호:</p><div class="secret">{E(temp)}</div>'
            f'<p class="muted">이 화면을 벗어나면 다시 볼 수 없습니다 — 지금 직원에게 직접 전해 주세요. '
            f'첫 로그인 때 새 비밀번호로 바꾸게 됩니다.</p>'
            + ('<p class="muted">검토자는 맡은 폴더가 있어야 검토할 수 있습니다 — [폴더 관리]에서 폴더마다 검토자로 지정하세요.</p>'
               if reviewer else "")
            + f'<div class="form-actions">{nxt}</div></div>')
    h._send(200, h._shell(title, body, active="/admin/users"))


# ── 계정 일괄 등록 (기능 검토 F2-2, 2026-11-02) ────────────────────────────────────
# 줄마다 '아이디 이름 [메일] [역할]' — 탭(엑셀에서 붙여 넣기)·쉼표·빈칸으로 나눈다. 미리보기 → [등록] → 결과 표(임시 비밀번호 한 번에).
# ux20 forms 2 (2026-11-03): 엑셀 머리글 줄('아이디 이름 메일 부서')은 계정이 아니라 머리글로 보고 건너뛰며, 칸 이름대로 읽는다.
# '@'가 든 칸은 어디 있든 메일, 역할 낱말은 어디 있든 역할. 쓰지 않는 칸(부서 등)은 이름에 붙이지 않고 '쓰지 않은 칸'으로 보인다.
# 탭·쉼표로 나눈 줄은 칸 단위(빈 칸도 자리 유지) — 이름 칸 하나만 이름. 빈칸으로 나눈 줄은 이름에 빈칸이 있어도 되지만
# (맨 앞 = 아이디, 다음부터 메일·역할 낱말 앞까지 = 이름), 메일·역할 뒤에 남은 낱말은 쓰지 않은 칸.

ROLE_WORDS = {"직원": "member", "member": "member", "검토자": "reviewer", "reviewer": "reviewer",
              "관리자": "admin", "admin": "admin"}
# 머리글 칸 이름 (접어 비교 — 대소문자·빈칸 무시)
BULK_HEADERS = {
    "login": ("아이디", "id", "로그인", "로그인아이디", "login", "userid", "username", "계정", "계정아이디", "사용자아이디"),
    "name": ("이름", "성명", "name", "표시이름", "직원명", "사원명", "displayname"),
    "email": ("메일", "이메일", "email", "e-mail", "mail", "메일주소", "이메일주소", "전자우편", "전자메일"),
    "role": ("역할", "권한", "role"),
}
_HEAD_KEY = {"".join(w.casefold().split()): f for f, ws in BULK_HEADERS.items() for w in ws}


def _head_field(cell: str) -> str:
    return _HEAD_KEY.get("".join(str(cell or "").casefold().split()), "")


def _bulk_cells(raw: str) -> tuple[str, list]:
    """(나눈 방식, 칸들). 탭·쉼표는 빈 칸도 자리를 지킨다(엑셀의 빈 메일 칸 때문에 부서가 이름으로 밀려 오던 것)."""
    line = raw.strip()
    if "\t" in line:
        cells = [c.strip() for c in raw.rstrip("\r\n").split("\t")]
        mode = "tab"
    elif "," in line:
        cells = [c.strip() for c in line.split(",")]
        mode = "comma"
    else:
        return "space", line.split()
    while cells and not cells[-1]:
        cells.pop()
    return mode, cells


def parse_bulk_lines(text: str) -> list[dict]:
    """붙여 넣은 글 → [{line, text, login, name, email, role, ignored, header, error}] (빈 줄·# 줄은 뺀다).
    header=True 줄은 머리글(계정 아님 — 부르는 쪽이 건너뜀 안내만). ignored: 쓰지 않은 칸 ['부서: 생산1팀', …].
    검사는 등록과 같은 규칙(auth)."""
    out: list = []
    seen: set = set()
    cols: dict | None = None             # 머리글이 정한 칸 자리 {칸 번호: 'login'|'name'|'email'|'role'|''} + 이름
    col_names: list = []
    cols_mode = ""
    count = 0
    for no, raw in enumerate(str(text or "").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        mode, cells = _bulk_cells(raw)
        fields = [_head_field(c) for c in cells]
        # 머리글 줄: 칸 이름이 둘 이상이고 메일 주소가 없다 ('아이디 이름 메일 부서')
        if sum(1 for f in fields if f) >= 2 and not any("@" in c for c in cells):
            hdr = {"line": no, "text": line[:200], "header": True, "login": "", "name": "", "email": "",
                   "role": "member", "ignored": [], "error": ""}
            if mode != "space" and "login" in fields and "name" in fields:
                cols = {}
                for i, f in enumerate(fields):
                    cols[i] = f if f and f not in cols.values() else ""
                col_names, cols_mode = list(cells), mode
                hdr["ignored"] = [c for i, c in enumerate(cells) if c and not cols.get(i)]
            out.append(hdr)
            continue
        row = {"line": no, "text": line[:200], "header": False, "login": "", "name": "", "email": "",
               "role": "member", "ignored": [], "error": ""}
        role_word = ""
        if cols is not None and mode == cols_mode:          # 머리글대로 (머리글과 같은 방식으로 나눈 줄만)
            for i, c in enumerate(cells):
                if not c:
                    continue
                f = cols.get(i, "")
                if f == "role":
                    role_word = c
                elif f in ("login", "name", "email") and not row[f]:
                    row[f] = c
                elif "@" in c and not row["email"] and f not in ("login", "name"):
                    row["email"] = c                       # '@'가 든 칸은 어디 있든 메일
                else:
                    label = col_names[i] if i < len(col_names) and col_names[i] else f"{i + 1}번째 칸"
                    row["ignored"].append(f"{label}: {c}")
        elif mode != "space":                              # 칸 단위 — 첫 칸 아이디, '@' 칸 메일, 역할 낱말, 남은 첫 칸 이름
            rest = [(i, c) for i, c in enumerate(cells) if c]
            if rest:
                row["login"] = rest.pop(0)[1]
            for i, c in rest:
                if "@" in c and not row["email"]:
                    row["email"] = c
                elif c.lower() in ROLE_WORDS and not role_word:
                    role_word = c
                elif not row["name"]:
                    row["name"] = c
                else:
                    row["ignored"].append(f"{i + 1}번째 칸: {c}")
        else:                                              # 빈칸 — 이름에 빈칸이 있어도 된다(메일·역할 낱말 앞까지)
            toks = list(cells)
            row["login"] = toks.pop(0) if toks else ""
            name, after = [], False
            for t in toks:
                if "@" in t and not row["email"]:
                    row["email"], after = t, True
                elif t.lower() in ROLE_WORDS and not role_word:
                    role_word, after = t, True
                elif not after:
                    name.append(t)
                elif not name:
                    name.append(t)
                else:
                    row["ignored"].append(t)
            row["name"] = " ".join(name)
        if role_word:
            row["role"] = ROLE_WORDS.get(role_word.lower(), "")
            if not row["role"]:
                row["role"] = "member"
                row["error"] = f"역할 '{role_word[:20]}'을 알 수 없습니다 — 직원·검토자·관리자 가운데 하나로 적어 주세요"
        try:
            if row["error"]:
                raise InvalidInput(row["error"])
            row["login"] = auth._check_login(row["login"])
            if not row["name"]:
                raise InvalidInput("이름이 빠졌습니다 — '아이디 이름 [메일] [역할]' 꼴로 적어 주세요")
            if len(row["name"]) > 40:
                raise InvalidInput("이름은 40자까지입니다")
            row["email"] = auth.check_email(row["email"])
            key = row["login"].casefold()
            if key in seen:
                raise InvalidInput("위 줄과 아이디가 같습니다")
            seen.add(key)
        except InvalidInput as e:
            row["error"] = str(e)
        out.append(row)
        count += 1
        if count >= BULK_MAX:
            break
    return out


def post_users_bulk(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    text = h._one(f, "lines")[:60000]
    do = h._one(f, "do")
    mail_ok = h.server.notifier is not None
    send_mail = mail_ok and h._one(f, "mail") == "1"
    rows = parse_bulk_lines(text)
    taken = {r[0] for r in store.conn.execute("SELECT login_key FROM users").fetchall()}
    from watcher.forms.store import name_key
    for r in rows:
        if not r["error"] and name_key(r["login"]) in taken:
            r["error"] = "이미 있는 아이디입니다"
    heads = [r for r in rows if r.get("header")]          # 머리글 줄 — 계정이 아니다 (ux20 forms 2)
    rows = [r for r in rows if not r.get("header")]
    good = [r for r in rows if not r["error"]]
    bad = [r for r in rows if r["error"]]
    hid = _hidden(h)
    head_note = "".join(
        f'<div class="note info" role="status">{r["line"]}번째 줄 <b>{E(r["text"])}</b>은 머리글(칸 이름)로 보고 '
        f'건너뜁니다 — 계정으로 만들지 않습니다.'
        + (f' 쓰지 않는 칸: {E(", ".join(r["ignored"]))}' if r["ignored"] else "") + '</div>' for r in heads)
    err_table = ("<h3>건너뛸 줄</h3><table><thead><tr><th>줄</th><th>적은 것</th><th>까닭</th></tr></thead><tbody>"
                 + "".join(f'<tr><td class="nw">{r["line"]}</td><td>{E(r["text"])}</td><td>{E(r["error"])}</td></tr>'
                           for r in bad) + "</tbody></table>") if bad else ""
    if do != "run":
        if not rows and not heads:
            h._flash("bad", "등록할 줄이 없습니다 — 줄마다 '아이디 이름 [메일] [역할]'을 적어 주세요")
            h._redirect("/admin/users#bulk")
            return
        extra = any(r["ignored"] for r in good)          # 쓰지 않은 칸(부서 등)이 있으면 열 하나 더 — 이름에 붙지 않았음을 보인다
        trs = "".join(f'<tr><td class="nw">{r["line"]}</td><td>{E(r["login"])}</td><td>{E(r["name"])}</td>'
                      f'<td>{E(r["email"]) or "—"}</td><td>{E(ROLE_LABEL[r["role"]])}</td>'
                      + (f'<td class="muted">{E(", ".join(r["ignored"])) or "—"}</td>' if extra else "")
                      + '</tr>' for r in good)
        table = ("<table><thead><tr><th>줄</th><th>아이디</th><th>이름</th><th>메일</th><th>역할</th>"
                 + ("<th>쓰지 않은 칸</th>" if extra else "") + "</tr></thead><tbody>"
                 + trs + "</tbody></table>") if good else '<p class="empty">등록할 수 있는 줄이 없습니다</p>'
        mail_box = (f'<label class="chk" for="bm"><input type="checkbox" id="bm" name="mail" value="1"'
                    f'{" checked" if send_mail else ""}>메일 주소가 있는 사람에게 임시 비밀번호를 메일로 보내기 (사내 메일 서버)</label>'
                    if mail_ok and any(r["email"] for r in good) else "")
        run = (f'<form method="post" action="/admin/users/bulk">{hid}<input type="hidden" name="do" value="run">'
               f'<textarea name="lines" hidden>{E(text)}</textarea>{mail_box}'
               f'<div class="form-actions"><button class="btn" type="submit">{len(good)}명 등록</button>'
               f'<a class="btn gray" href="/admin/users#bulk">고치기</a></div></form>') if good else \
            '<p><a class="btn gray" href="/admin/users#bulk">돌아가기</a></p>'
        body = (f'<div class="panel"><h2>미리보기 — 등록 {len(good)}명 · 건너뜀 {len(bad)}줄</h2>'
                f'<p class="muted">아직 등록하지 않았습니다. 이름·메일 칸이 맞는지 확인한 뒤 [등록]을 누르세요.</p>'
                f'{head_note}{table}{err_table}{run}</div>')
        h._send(200, h._shell("계정 일괄 등록 — 미리보기", body, active="/admin/users"))
        return
    made, failed = [], list(bad)
    h.server.watch(id(h), h.connection, 30.0 + 2.0 * len(good))      # 계정마다 비밀번호 해시(약 0.4초) — 느린 요청 끊기를 늦춘다
    for r in good:
        try:
            uid, temp = auth.register_user(store, s.user_id, r["login"], r["name"], r["role"], ip=h.ip, email=r["email"])
        except (InvalidInput, Conflict) as e:
            r["error"] = str(e)
            failed.append(r)
            continue
        mailed = False
        if send_mail and r["email"]:
            h.server.notifier.temp_password(r["email"], r["login"], r["name"], temp)
            mailed = True
        made.append(dict(r, temp=temp, mailed=mailed, uid=uid))
    trs = "".join(f'<tr><td>{E(r["login"])}</td><td>{E(r["name"])}</td><td>{E(ROLE_LABEL[r["role"]])}</td>'
                  f'<td><span class="secret sm">{E(r["temp"])}</span></td>'
                  f'<td>{E(r["email"]) or "—"}{" · 메일 보내는 중" if r["mailed"] else ""}</td></tr>' for r in made)
    # '메일 보냄'은 큐에 넣은 때였다 — 실제로 나갔는지는 감사 기록에서 (ux20 forms 4)
    mail_note = ('<p class="muted noprint">임시 비밀번호 메일은 이 화면 뒤에서 차례로 나갑니다. 실제로 나갔는지는 '
                 '<a href="/admin/audit?action=notify">감사 기록 › 메일 알림 보냄</a>·'
                 '<a href="/admin/audit?action=notify_fail">메일 알림 실패</a>에서 확인하세요 — 실패한 사람에게는 '
                 '이 표의 임시 비밀번호를 직접 전해 주세요.</p>') if any(r["mailed"] for r in made) else ""
    err_table = ("<h3 class=\"noprint\">등록하지 못한 줄</h3><table class=\"noprint\"><thead><tr><th>줄</th><th>적은 것</th>"
                 "<th>까닭</th></tr></thead><tbody>"
                 + "".join(f'<tr><td class="nw">{r["line"]}</td><td>{E(r["text"])}</td><td>{E(r["error"])}</td></tr>'
                           for r in failed) + "</tbody></table>") if failed else ""
    reviewers = any(r["role"] == "reviewer" for r in made)
    body = (f'<div class="panel"><div class="note ok noprint">{len(made)}명을 등록했습니다'
            + (f' · 등록하지 못한 줄 {len(failed)}개' if failed else "") + '</div>'
            f'<p class="muted noprint">임시 비밀번호는 <b>이 화면에서 한 번만</b> 보입니다 — 인쇄(Ctrl+P)해 나눠 주거나 지금 전해 주세요. '
            f'첫 로그인 때 새 비밀번호로 바꿉니다.</p>'
            + ("<table><thead><tr><th>아이디</th><th>이름</th><th>역할</th><th>임시 비밀번호</th><th>메일</th></tr></thead><tbody>"
               + trs + "</tbody></table>" if made else '<p class="empty">등록한 계정이 없습니다</p>')
            + mail_note + err_table
            + '<div class="form-actions noprint">'
            + ('<a class="btn" href="/admin/folders">검토자가 맡을 폴더 정하기</a>' if reviewers else "")
            + '<a class="btn gray" href="/admin/users">계정 목록으로</a></div></div>')
    h._send(200, h._shell("계정 일괄 등록 — 결과", body, active="/admin/users"))


def post_user_new(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    login = h._one(f, "login").strip()
    try:
        uid, temp = auth.register_user(h.server.store, h.sess.user_id, login, h._one(f, "display_name"),
                                       h._one(f, "role", "member"), ip=h.ip, email=h._one(f, "email"))
    except (InvalidInput, Conflict) as e:           # 막다른 400 대신 알림 + 적은 글자 되살리기 (2026-10-30 검토)
        # 폼으로 곧장 돌아간다 — 폼이 목록 아래라 위쪽 알림만 보고 폼을 찾아 내려가야 했다 (ux22 forms 4). 알림도 폼 안에 (위 알림은 화면 밖이다)
        h.server.draft_set(h.sess.token, "user", {**{k: h._one(f, k) for k in ("login", "display_name", "role", "email")},
                                                  "err": f"등록하지 않았습니다 — {e}"})
        h._redirect("/admin/users#new")
        return
    _secret_page(h, "직원 등록", login, temp, "계정을 등록했습니다", reviewer=h._one(f, "role") == "reviewer")


def post_user_email(h: FormsHandler) -> None:
    """알림 메일 주소 바꾸기 (F4) — 관리자만. 비우면 알림을 받지 않는다."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    em = h._one(f, "email").strip()
    auth.set_email(h.server.store, h.sess.user_id, uid, em, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정의 메일 주소를 {'저장' if em else '지웠'}했습니다")
    h._redirect("/admin/users")


def post_folder_subscribe(h: FormsHandler) -> None:
    """폴더 구독(새 현행 판 메일) 켜기·끄기 — 자기 것만 (F4)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    on = h._one(f, "on") == "1"
    h.server.store.set_subscription(h.sess.user_id, fid, on)
    if on and not h.server.store.user_email(h.sess.user_id):
        h._flash("ok", "구독했습니다 — 다만 내 계정에 메일 주소가 없어 알림이 가지 않습니다. 관리자에게 주소 등록을 부탁하세요")
    else:
        h._flash("ok", "이 폴더에 새 현행 판이 생기면 메일로 알립니다" if on else "이 폴더 메일 알림을 껐습니다")
    h._redirect(f"/forms?folder={fid}")


def _user_login(h: FormsHandler, uid: int) -> str:
    u = h.server.store.get_user(uid)
    if u is None:
        raise HttpError(404, "없는 계정입니다")
    return u["login"]


def post_user_disable(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    off = h._one(f, "disabled") == "1"
    store = h.server.store
    u = store.get_user(uid)
    if u is None:
        raise HttpError(404, "없는 계정입니다")
    last_admin = u["role"] == "admin" and auth._active_admins(store) <= 1   # 막힐 일이면 확인 없이 바로 까닭을 보인다
    if off and not u["disabled"] and not last_admin and h._one(f, "confirm") != "1":   # 정지 전 영향 수 확인 (F2-8)
        imp = store.user_impact(uid)
        items = [x for x in (
            "로그인 중인 접속은 바로 끊깁니다" + (f" ({imp['sessions']}곳)" if imp["sessions"] else ""),
            f"맡은 폴더 {imp['reviewer']}개 — 정지된 동안 이 사람은 검토하지 못합니다" if imp["reviewer"] else "",
            f"승인권자 지정 {imp['approver']}개 — 정지된 동안 승인하지 못합니다" if imp["approver"] else "",
            f"이 사람이 올린 검토 대기 {imp['pending']}건 — 그대로 남습니다(검토자가 처리)" if imp["pending"] else "",
            f"기밀 폴더 볼 사람 지정 {imp['member']}개" if imp["member"] else "") if x]
        _confirm_page(h, "계정 정지 — 확인", "/admin/users/disable", {"id": uid, "disabled": "1"},
                      f"<b>{E(u['display_name'])}({E(u['login'])})</b> 계정을 정지합니다. 지정·기록은 지우지 않고, [복구]하면 "
                      f"그대로 돌아옵니다.", items, "정지하기", "/admin/users", "/admin/users")
        return
    auth.set_disabled(store, h.sess.user_id, uid, off, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정을 {'정지' if off else '복구'}했습니다")
    h._redirect("/admin/users")


def post_user_reset(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    temp = auth.reset_password(h.server.store, h.sess.user_id, uid, ip=h.ip)
    u = h.server.store.get_user(uid) or {}
    _secret_page(h, "비밀번호 초기화", _user_login(h, uid), temp, "비밀번호를 초기화했습니다 — 그 계정의 접속은 모두 끊겼습니다",
                 disabled=bool(u.get("disabled")))


def post_user_role(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    role = h._one(f, "role")
    store = h.server.store
    u = store.get_user(uid)
    if u is None:
        raise HttpError(404, "없는 계정입니다")
    last_admin = u["role"] == "admin" and not u["disabled"] and auth._active_admins(store) <= 1
    if role == "member" and u["role"] != "member" and not last_admin and h._one(f, "confirm") != "1":   # 지정이 풀린다 (F2-8)
        imp = store.user_impact(uid)
        if imp["reviewer"] or imp["approver"]:
            items = [x for x in (f"맡은 폴더(검토자 지정) {imp['reviewer']}개가 풀립니다" if imp["reviewer"] else "",
                                 f"승인권자 지정 {imp['approver']}개가 풀립니다" if imp["approver"] else "") if x]
            _confirm_page(h, "직원으로 바꾸기 — 확인", "/admin/users/role", {"id": uid, "role": "member"},
                          f"<b>{E(u['display_name'])}({E(u['login'])})</b> 계정을 직원으로 바꿉니다. 풀린 지정은 다시 검토자로 "
                          f"올려도 <b>돌아오지 않습니다</b> — [폴더 관리]에서 다시 지정해야 합니다.", items,
                          "직원으로 바꾸기", "/admin/users", "/admin/users")
            return
    res = auth.set_role(store, h.sess.user_id, uid, role, ip=h.ip, detail=True)
    dropped, appr = res["reviewers"], res["approvers"]
    h._flash("ok", f"{_user_login(h, uid)} 계정의 역할을 {ROLE_LABEL.get(role, role)}(으)로 바꿨습니다"
             + (f" — 맡은 폴더 {dropped}개 지정이 풀렸습니다" if dropped else "")
             + (f" — 승인권자 지정 {appr}개가 풀렸습니다" if appr else "")
             # 직원 → 검토자로 되돌려도 직원이 될 때 풀린 지정은 돌아오지 않는다 (2026-10-31 실사용 검토)
             + (" — 직원이 될 때 풀린 맡은 폴더·승인권자 지정은 되살아나지 않습니다 — [폴더 관리]에서 다시 지정하세요"
                if res.get("from") == "member" and role == "reviewer" else ""))
    h._redirect("/admin/users")


def _template_panel(h: FormsHandler) -> str:
    """기본 분류 틀 만들기 — 대분류별 체크(기본 전부 켜짐)와 미리보기(트리). POST + CSRF, 없는 폴더만 만든다."""
    n = catalog.counts()
    boxes = []
    for i, (top, mids) in enumerate(catalog.CATALOG):
        leaves = sum(len(lv) for _m, lv in mids)
        tree_ = "".join(f'<li><b>{E(m)}</b> — {E(" · ".join(lv))}</li>' for m, lv in mids)
        # 기본은 모두 꺼짐 — 필요한 대분류만 골라 만든다 (기능 검토 F2-6: 전부 켜져 있어 폴더 170여 개가 한 번에 생겼다)
        boxes.append(f'<div class="tpl"><label class="chk" for="tpl{i}"><input type="checkbox" id="tpl{i}" name="top" '
                     f'value="{E(top)}">{E(top)}</label><span class="muted">중분류 {len(mids)} · 소분류 {leaves}</span>'
                     f'<details class="tool"><summary>미리보기</summary><ul class="lines">{tree_}</ul></details></div>')
    return (f'<div class="panel"><h2>기본 분류 틀 만들기</h2>'
            f'<p class="muted">중소 제조기업에서 흔한 양식을 <b>대분류 {n["tops"]} / 중분류 {n["mids"]} / 소분류(양식 종류) '
            f'{n["leaves"]}</b>로 나눈 폴더를 만듭니다. 소분류 폴더에 그 양식을 올리면 됩니다. <b>없는 폴더만</b> 만들고, 같은 '
            f'이름이 이미 있으면 그대로 두고 그 아래로 이어 갑니다 — 여러 번 눌러도 같은 결과입니다. 필요 없는 폴더는 나중에 '
            f'지우면 됩니다(빈 폴더만).</p>'
            f'<form method="post" action="/admin/folders/template">{_hidden(h)}'
            f'<div class="sub"><span>얼마나 깊게:</span>'
            f'<label class="chk" for="tdt"><input type="radio" id="tdt" name="depth" value="top" checked>대분류만</label>'
            f'<label class="chk" for="tdl"><input type="radio" id="tdl" name="depth" value="leaf">소분류까지 (중분류·소분류 폴더도)'
            f'</label></div><div class="tplgrid">{"".join(boxes)}</div>'
            f'<div class="form-actions"><button class="btn" type="submit">고른 분류 만들기</button></div></form></div>')


def get_admin_folders(h: FormsHandler) -> None:
    """폴더 관리 — 전체 트리를 한 표로: 층·양식 수(현행/폐기)·대기·검토자, 행마다 이름 바꾸기·옮기기·지우기·차례·검토자 지정.
    질의는 폴더 수와 상관없이 몇 개뿐(트리 1·집계 3·계정 1) — 폴더마다 묻지 않는다. 스크립트 없이 접기 칸(details)."""
    _require_admin(h)
    store, s = h.server.store, h.sess
    flat = h._folders()
    page = _page_of(h, len(flat))
    shown = flat[page * PAGE_ROWS:(page + 1) * PAGE_ROWS]       # 한 쪽 PAGE_ROWS줄 — 행마다 도구가 무거워서 (2026-10-30 M3)
    ov = store.folder_overview(s.user_id)
    users = [u for u in auth.list_users(store, s.user_id) if u["role"] in ("reviewer", "admin") and not u["disabled"]]
    hid = _hidden(h)
    back = f"/admin/folders?page={page}" if page else "/admin/folders"
    rows = []
    for n, depth, path in shown:
        fid = n["id"]
        cur_f, ret_f = ov["forms"].get(fid, (0, 0))
        pend = ov["pending"].get(fid, 0)
        revs = ov["reviewers"].get(fid, [])
        cur = {u["id"] for u in revs}
        boxes = "".join(
            f'<label class="chk"><input type="checkbox" name="user" value="{u["id"]}"'
            f'{" checked" if u["id"] in cur else ""}>{E(u["display_name"])} ({E(u["login"])})</label>' for u in users)
        lvl = level_name(depth + 1)
        approval = _approval_form(h, n, ov, users, back)
        manage = (f'<details class="tool"><summary>관리</summary>'
                  f'<form class="inline" method="post" action="/folders/rename">{hid}'
                  f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="{E(back)}">'
                  f'<input type="text" name="name" value="{E(n["name"])}" required maxlength="80" '
                  f'aria-label="{E(path)} 새 이름"><button class="btn gray sm" type="submit">이름 바꾸기</button></form>'
                  f'<form method="post" action="/admin/reviewers">{hid}<input type="hidden" name="folder" value="{fid}">'
                  f'<div class="muted">검토자</div>{boxes or "<span class=muted>검토자 역할 계정이 없습니다</span>"} '
                  f'<button class="btn gray sm" type="submit">검토자 저장</button></form>{approval}'
                  f'<form class="inline" method="post" action="/folders/code">{hid}'
                  f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="{E(back)}">'
                  f'<input type="text" class="code" name="code" value="{E(n.get("code", ""))}" maxlength="8" '
                  f'aria-label="{E(path)} 번호 머리" placeholder="번호 머리 (예: QA)">'
                  f'<button class="btn gray sm" type="submit">머리 저장</button></form>'
                  f'<div class="form-actions"><a class="btn gray sm" href="/folders/move?folder={fid}">옮기기…</a>'
                  f'{_order_buttons(h, fid, back=back)}'
                  f'<form class="inline" method="post" action="/folders/delete">{hid}'
                  f'<input type="hidden" name="folder" value="{fid}"><input type="hidden" name="back" value="{E(back)}">'
                  f'<button class="btn red sm" type="submit">지우기</button></form></div></details>')
        names = ", ".join(u["display_name"] for u in revs)
        code_tag = f'<span class="tag code" title="문서번호 머리">{E(n["code"])}</span>' if n.get("code") else ""
        if n.get("restricted"):                         # 기밀 폴더 (2026-10-30) — 켜기·끄기와 볼 사람은 폴더 화면에서
            code_tag += '<span class="tag conf" title="기밀 폴더 — 폴더 화면의 [기밀 폴더]에서 바꿉니다">기밀</span>'
        if ov["steps"].get(fid) == 2:                   # 2단계 승인 (2026-10-30) — 자기 값이면 '2단계 승인', 위 폴더를 따르면 '(위)'
            code_tag += (f'<span class="tag two" title="{E(HINT_TWO_STEP)}">2단계 승인'
                         + ("" if n.get("approval_steps") == 2 else "(위 폴더)") + '</span>')
        rows.append(f'<tr><td class="fname lv{min(depth, 6)}"><a href="/forms?folder={fid}">{E(n["name"])}</a>{code_tag}</td>'
                    f'<td class="nw"><span class="tag lvl">{E(lvl)}</span></td>'
                    f'<td class="nw">{cur_f}' + (f' <span class="muted">/ 폐기 {ret_f}</span>' if ret_f else "")
                    + f'</td><td class="nw">{pend or ""}</td><td>{E(names)}</td><td>{manage}</td></tr>')
    table = ('<div class="tablewrap"><table class="ftree"><thead><tr><th>폴더</th><th>층</th><th>양식</th><th>대기</th>'
             '<th>검토자</th><th></th></tr></thead><tbody>' + "".join(rows) + "</tbody></table></div>") if rows else \
        '<p class="empty">아직 폴더가 없습니다 — 아래 [기본 분류 틀 만들기]로 시작하거나 양식함에서 대분류를 만드세요</p>'
    # 규칙 문단 세 개는 접어 둔다 — 읽지 않고 건너뛰던 것 (ux20 forms 12). 한 줄 요약만 펼쳐 둔다
    intro = ('<p class="muted">층: 대분류 › 중분류 › 소분류(양식 종류). 폴더마다 오른쪽 [관리]에서 이름·검토자·번호 머리·차례를 '
             '바꿉니다.</p><details class="tool"><summary>규칙 자세히 — 검토자가 할 수 있는 일·기밀·번호 머리</summary>'
             '<p class="muted">층: 맨 위 = 대분류, 그 아래 = 중분류, 그 아래 = 소분류(양식 종류), 더 아래는 하위 폴더. '
             '검토자는 지정된 폴더와 그 <b>하위 폴더</b>에서 폴더 만들기·이름 바꾸기·번호 머리·옮기기·지우기(빈 폴더)·차례, '
             '올라온 양식 승인·반려, 양식 폐기·복원, 문서 관리 대장 보기·내려받기, 정기 검토(검토함·주기), 양식의 문서 종류 바꾸기를 '
             '할 수 있습니다. '
             '관리자는 지정하지 않아도 모든 폴더를 검토할 수 있습니다. 폴더를 옮기면 검토자 범위도 새 위치를 따릅니다. '
             '<b>기밀</b>(빨간 표시) 폴더와 그 하위 폴더는 관리자·그 폴더(또는 위 폴더) 검토자·고른 직원만 봅니다 — 켜기·끄기와 볼 사람은 '
             '폴더 화면의 [기밀 폴더]에서 바꿉니다. '
             # 2단계 폴더가 없으면 두 문장을 그리지 않는다 — [관리] › 승인 단계에서 켜면 그때 보인다 (F2-5)
             + ('<b>2단계 승인</b>(파란 표시)은 [관리] › 승인 단계에서 폴더마다 고릅니다 — 하위 폴더는 따로 정하지 않으면 위 폴더를 '
                '따르고, 바꾸면 이미 올라온 제출에도 바로 적용됩니다. 승인권자도 그 폴더와 하위 폴더(기밀 폴더 포함)를 봅니다.'
                if ov["steps"] else "") + '</p>'
             f'{_hint("폴더 이름: " + HINT_FOLDER_NAME)}{_hint("번호 머리: " + HINT_FOLDER_CODE)}'
             '<p class="muted">번호 머리(파란 글자): 처음 승인되는 양식의 문서번호 앞부분 — <a href="/admin/docno">문서번호 규칙</a>'
             '대로 잇습니다(기본: 위 폴더 머리를 위에서부터 잇고 일련번호, 예: QA-01-01-001). 기본 분류 틀은 머리를 함께 넣습니다. 이미 매긴 번호는 폴더를 옮기거나 '
             '머리를 바꿔도 그대로입니다. 번호 없는 옛 양식은 <a href="/register">문서 관리 대장</a>에서 한 번에 매깁니다.</p>'
             '</details>')
    table += _pager("/admin/folders", {}, page, len(flat) > (page + 1) * PAGE_ROWS, len(flat))
    body = (f'<div class="panel"><h2>폴더 {len(flat)}개</h2>{intro}{table}</div>' + _template_panel(h))
    h._send(200, h._shell("폴더 관리", body, active="/admin/folders"))


def post_folder_template(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    picked = [t for t in f.get("top", []) if t in set(catalog.tops())]
    if not picked:
        h._flash("bad", "만들 대분류를 하나 이상 골라 주세요")
        h._redirect("/admin/folders")
        return
    tree = catalog.tree(picked)
    if h._one(f, "depth", "leaf") == "top":            # 대분류만 (F2-6) — 옛 화면(깊이 칸 없음)은 지금까지처럼 소분류까지
        tree = [(name, []) for name, _kids in tree]
    res = h.server.store.apply_template(h.sess.user_id, tree, ip=h.ip, codes=catalog.TOP_CODES)
    msg = (f"기본 분류 틀: 폴더 {res['created']}개를 만들었습니다"
           + (f" · 이미 있던 {res['skipped']}개는 그대로 두었습니다" if res["skipped"] else ""))
    if res.get("by_code"):                          # 이름을 바꾼 폴더는 번호 머리로 찾아 이어 갔다 (2026-10-30 M6)
        msg += (f" · 이름이 바뀐 폴더 {len(res['by_code'])}개는 번호 머리로 찾아 그 아래로 이어 갔습니다 ("
                + ", ".join(res["by_code"][:3]) + (" …" if len(res["by_code"]) > 3 else "") + ")")
    if res.get("code_taken"):
        msg += (f" · 번호 머리가 이미 다른 형제 폴더에 쓰여 머리를 비워 둔 폴더 {len(res['code_taken'])}개 ("
                + ", ".join(res["code_taken"][:3]) + (" …" if len(res["code_taken"]) > 3 else "")
                + ") — [폴더 관리]에서 머리를 정해 주세요")
    h._flash("info" if res.get("code_taken") else "ok", msg)
    h._redirect("/admin/folders")


def _approval_form(h: FormsHandler, n: dict, ov: dict, users: list, back: str) -> str:
    """폴더 관리 줄의 '승인 단계' 칸 (2단계 승인, 2026-10-30) — 1단계 / 2단계 / 위 폴더 따름 + 승인권자(검토자·관리자 역할만).
    POST /admin/approval + CSRF, 관리자만(store가 다시 본다)."""
    fid = n["id"]
    own = n.get("approval_steps")
    parent = n.get("parent_id")
    up = ov["steps"].get(parent, 1) if parent is not None else 1
    inherit = f"위 폴더 따름 (지금 {up}단계)" if parent is not None else "위 폴더 따름 (맨 위 — 기본 1단계)"
    sel = "" if own is None else str(own)

    def opt(v, label):
        return f'<option value="{v}"{" selected" if v == sel else ""}>{E(label)}</option>'
    own_list = ov["approvers"].get(fid, [])
    mine = {u["id"] for u in own_list}
    # 관리자는 늘 승인권자라 고르기에 넣지 않는다 (2026-10-31 실사용 검토) — 예전에 지정해 둔 관리자 줄은 숨은 칸으로
    # 그대로 보내 저장해도 빠지지 않게(감사 기록에 '뺌'이 생기지 않게) 둔다. 남아 있어도 해가 없다.
    keep_admins = "".join(f'<input type="hidden" name="user" value="{u["id"]}">'
                          for u in own_list if u["role"] == "admin" and not u.get("disabled"))
    boxes = "".join(
        f'<label class="chk"><input type="checkbox" name="user" value="{u["id"]}"'
        f'{" checked" if u["id"] in mine else ""}>{E(u["display_name"])} ({E(u["login"])})</label>'
        for u in users if u["role"] != "admin")
    return (f'<form method="post" action="/admin/approval">{_hidden(h)}<input type="hidden" name="folder" value="{fid}">'
            f'<input type="hidden" name="back" value="{E(back)}">'
            f'<label for="steps{fid}">승인 단계</label><select id="steps{fid}" name="steps">'
            f'{opt("", inherit)}{opt("1", "1단계 — 검토자가 바로 승인")}{opt("2", "2단계 — 검토 완료 뒤 승인권자가 승인")}'
            f'</select>{_hint(HINT_TWO_STEP)}'
            f'<div class="muted">승인권자 (2단계일 때 마지막 [승인]을 하는 사람)</div>'
            f'{keep_admins}{boxes or "<span class=muted>검토자 역할 계정이 없습니다</span>"}{_hint(HINT_APPROVERS)}'
            f'<button class="btn gray sm" type="submit">승인 단계 저장</button></form>')


def post_admin_approval(h: FormsHandler) -> None:
    """폴더 승인 단계·승인권자 저장 — 관리자만, CSRF. 바뀐 것만 감사 기록(folder_approval_steps·folder_approvers)."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    raw = h._one(f, "steps")
    steps = None if raw in ("", "inherit") else h._int(raw)
    ids = [h._int(v) for v in f.get("user", [])]
    back = _safe_back(h._one(f, "back")) if h._one(f, "back") else "/admin/folders"
    store = h.server.store
    try:
        with store.tx():                            # 둘 다 바뀌거나 둘 다 그대로 (한 트랜잭션)
            before = set(store.steps_map())
            changed = store.set_folder_approval_steps(h.sess.user_id, fid, steps, ip=h.ip)
            res = store.set_folder_approvers(h.sess.user_id, fid, ids, ip=h.ip)
            after = set(store.steps_map())
    except InvalidInput as e:
        h._flash("bad", f"승인 단계를 저장하지 않았습니다 — {e}")
        h._redirect(back)
        return
    step_note = ""
    if changed:                                     # 이미 올라온 제출에 바로 적용된다 — 몇 건이 어떻게 되는지 (2026-10-31)
        _u1, now_one = store.pending_stage_counts(before - after)      # 2단계 → 1단계가 된 폴더의 승인 대기
        now_two, _c2 = store.pending_stage_counts(after - before)      # 1단계 → 2단계가 된 폴더의 검토 대기
        if before - after:
            step_note = (f" — 승인 대기 {now_one}건은 이제 검토자가 바로 승인할 수 있습니다" if now_one
                         else " — 이 폴더(하위 포함)의 승인 대기는 없습니다")
        if after - before:
            step_note += (f" — 검토 대기 {now_two}건은 먼저 [검토 완료]가 필요합니다 (검토자가 검토한 뒤 승인권자가 승인)"
                          if now_two else " — 이 폴더(하위 포함)의 검토 대기는 없습니다")
    bits = [x for x in ("승인 단계를 바꿨습니다" + step_note if changed else "",
                        f"승인권자 더함 {len(res['added'])}명" if res["added"] else "",
                        f"승인권자 뺌 {len(res['removed'])}명" if res["removed"] else "") if x]
    h._flash("ok", " · ".join(bits) if bits else "바뀐 것이 없습니다")
    h._redirect(back)


def post_reviewers(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    ids = [h._int(v) for v in f.get("user", [])]
    h.server.store.set_folder_reviewers(h.sess.user_id, fid, ids, ip=h.ip)
    h._flash("ok", "검토자를 저장했습니다")
    h._redirect("/admin/folders")


AUDIT_PAGE = 100


def get_admin_audit(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    qd = h._query()
    action = h._one(qd, "action")
    if action and action not in ACTION_LABEL:
        action = ""
    uid = h._int(h._one(qd, "user"), required=False)
    page = h._int(h._one(qd, "page"), required=False) or 0
    page = min(page, 10000)
    rows_ = store.audit_log(s.user_id, limit=AUDIT_PAGE + 1, offset=page * AUDIT_PAGE, action=action or None,
                            user_id=uid)
    more = len(rows_) > AUDIT_PAGE
    rows_ = rows_[:AUDIT_PAGE]
    users = auth.list_users(store, s.user_id)
    aopts = '<option value="">모든 일</option>' + "".join(
        f'<option value="{k}"{" selected" if k == action else ""}>{E(v)}</option>' for k, v in ACTION_LABEL.items())
    uopts = '<option value="">모든 사람</option>' + "".join(
        f'<option value="{u["id"]}"{" selected" if u["id"] == uid else ""}>{E(u["login"])}</option>' for u in users)
    filt = (f'<form class="searchbar" method="get" action="/admin/audit">'
            f'<select name="action" aria-label="일 종류">{aopts}</select>'
            f'<select name="user" aria-label="사람">{uopts}</select>'
            f'<button class="btn sm" type="submit">걸러 보기</button>'
            f'<a class="btn gray sm" href="/admin/audit">지우기</a>'
            f'<span class="muted">사람을 고르면 그 사람이 한 일과 그 사람에게 한 일(비밀번호 초기화·정지·역할 바꿈)을 함께 봅니다</span>'
            f'</form>')
    # 대상 번호 옆에 지금 이름(폴더 경로·아이디·양식명 vN) — 지워진 대상은 번호 그대로 (ux21 forms 3)
    names = store.audit_target_names(s.user_id, (r["target"] for r in rows_))
    old_ids = {int(i) for r in rows_ if r["action"] == "folder_reviewers"
               for i in re.findall(r"\d+", r["detail"] or "") if re.fullmatch(r"[\d,\s]*", r["detail"] or "")}
    logins = store.logins_of(old_ids)

    def target_cell(t: str) -> str:
        nm = names.get(t)
        return f'{E(nm)} <span class="muted">{E(t)}</span>' if nm else E(t)

    def detail_text(r) -> str:
        d = r["detail"] or ""
        if r["action"] == "folder_reviewers" and re.fullmatch(r"[\d,\s]*", d):   # 옛 기록 — 계정 번호 '4,7'
            ids = [int(i) for i in re.findall(r"\d+", d)]
            return "검토자: " + (", ".join(logins.get(i, f"#{i}") for i in ids) or "없음")
        return d
    trs = "".join(
        f'<tr><td class="nw">{E(_fmt_time(r["at"]))}</td><td>{E(r["login"])}</td>'
        f'<td>{E(ACTION_LABEL.get(r["action"], r["action"]))}</td><td>{target_cell(r["target"])}</td>'
        f'<td class="nw">{E(r["ip"])}</td><td class="pre">{E(detail_text(r))}</td></tr>' for r in rows_)
    table = ("<table><thead><tr><th>때</th><th>아이디</th><th>일</th><th>대상</th><th>접속 주소</th><th>내용</th>"
             "</tr></thead><tbody>" + trs + "</tbody></table>") if trs else '<p class="empty">기록이 없습니다</p>'
    q = "&".join(x for x in (f"action={quote(action)}" if action else "", f"user={uid}" if uid is not None else "") if x)
    pager = '<div class="pager">'
    if page > 0:
        pager += f'<a class="btn gray sm" href="/admin/audit?{E(q + "&" if q else "")}page={page - 1}">← 최근 쪽</a>'
    if more:
        pager += f'<a class="btn gray sm" href="/admin/audit?{E(q + "&" if q else "")}page={page + 1}">이전 기록 →</a>'
    pager += "</div>"
    info = store.audit_info(s.user_id)
    keep = (f'<p class="muted" id="keep">감사 기록은 최근 <b>{info["max_rows"]:,}건</b>까지 보관하고, 넘으면 가장 오래된 것부터 '
            f'지웁니다. 지금 {info["count"]:,}건 · <b>가장 오래된 기록: {E(_fmt_time(info["oldest_at"]) or "없음")}</b>. '
            f'같은 주소에서 연달아 틀린 로그인은 1분씩 묶어 한 줄(횟수·시각·시도한 아이디)로 적습니다.</p>')
    h._send(200, h._shell("감사 기록", f'{_backup_line(h)}<div class="panel">{keep}{filt}{table}{pager}</div>',
                          active="/admin/audit"))


def _backup_line(h: FormsHandler) -> str:
    """'마지막 백업: 때 · 결과 · [지금 백업]' 한 줄 (기능 검토 F2-5 — 백업 화면을 메뉴에서 빼고 감사 기록·고급 위에)."""
    from watcher.forms import backup as FB
    last = FB.last_status(h.server.store)
    ok = last["ok"]
    tag = ('<span class="tag approved">확인 OK</span>' if ok else '<span class="tag rejected">실패</span>' if ok is False
           else '<span class="tag off">아직 없음</span>')
    run = (f'<form class="inline" method="post" action="/admin/backup/run">{_hidden(h)}'
           f'<button class="btn gray sm" type="submit">지금 백업</button></form>') if h.server.backup is not None else \
        '<span class="muted">자동 백업 꺼짐</span>'
    return (f'<div class="note info searchbar" role="status"><span>마지막 백업: <b>{E(_fmt_time(last["at"])) or "—"}</b></span>'
            f'{tag}<span class="muted">{E(FB.status_line(last))}</span>{run}'
            f'<a href="/admin/backup">백업 자세히</a></div>')


# ── 관리 › 고급 (기능 검토 F2-4·5·14, 2026-11-02) — 메일 알림 설정 + 백업·보존 만료로 가는 곳 ───────────────

def get_admin_advanced(h: FormsHandler) -> None:
    _require_admin(h)
    store = h.server.store
    o = store.options()
    n = h.server.notifier
    off = ('<div class="note warn" role="status">메일 알림이 꺼져 있습니다 — Drev PC의 감시 화면 설정 › 양식함 › 메일 알림을 켜야 '
           '아래 설정이 쓰입니다(골라 둘 수는 있습니다).</div>') if n is None else ""
    waiting = n.batch_pending() if n is not None else 0
    chk = lambda k: " checked" if o[k] == "1" else ""   # noqa: E731
    mail = (f'<div class="panel" id="mail"><h2>메일 알림</h2>{off}'
            f'<form method="post" action="/admin/advanced">{_hidden(h)}'
            f'<label class="chk" for="oa"><input type="checkbox" id="oa" name="notify_all_current" value="1"'
            f'{chk("notify_all_current")}>새 현행 판은 메일 주소가 있는 모든 계정에게 보내기</label>'
            f'{_hint("끄면(기본) 그 폴더나 모든 폴더 알림을 받기로 한 사람에게만 갑니다. 기밀 폴더의 새 판은 그 폴더를 볼 수 있는 사람에게만 갑니다.")}'
            f'<label class="chk" for="ob"><input type="checkbox" id="ob" name="notify_batch" value="1"'
            f'{chk("notify_batch")}>승인·반려·새 판 메일을 하루 한 번 묶어 보내기</label>'
            f'<label for="oh">묶어 보내는 시각 (0~23시)</label><input type="text" class="months" id="oh" name="notify_batch_hour" '
            f'value="{E(o["notify_batch_hour"])}" inputmode="numeric" maxlength="2">'
            f'{_hint("그 시각이 지난 뒤 첫 접속이나 정리 때 받는 사람마다 한 통으로 보냅니다. 서버가 꺼져 있던 동안 쌓인 것은 다음에 켤 때 보냅니다. 승인 요청(2단계)·주간 알림은 묶지 않습니다.")}'
            + (f'<p class="muted">지금 묶여 기다리는 알림 {waiting}건</p>' if waiting else "")
            + '<div class="form-actions"><button class="btn" type="submit">저장</button></div></form></div>')
    from watcher.forms import keep as K
    pol = K.policy(store)
    links = (f'<div class="panel"><h2>백업</h2>{_backup_line(h)}<p class="muted">백업 폴더·사본·복원 명령은 '
             f'<a href="/admin/backup">백업 화면</a>에서 봅니다.</p></div>'
             f'<div class="panel"><h2>기록 보존 만료</h2><p class="muted">지난 판 보존: {E(_years_label(pol.get("superseded")))} · '
             f'폐기 양식 보존: {E(_years_label(pol.get("retired")))} — 정하지 않으면 영구 보존이고 저절로 지우지 않습니다. '
             f'<a href="/admin/retention">보존 만료 화면</a></p></div>')
    h._send(200, h._shell("고급", mail + links, active="/admin/advanced"))


def post_admin_advanced(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    vals = {"notify_all_current": "1" if h._one(f, "notify_all_current") == "1" else "0",
            "notify_batch": "1" if h._one(f, "notify_batch") == "1" else "0",
            "notify_batch_hour": h._one(f, "notify_batch_hour").strip() or "17"}
    try:
        changed = h.server.store.set_options(h.sess.user_id, vals, ip=h.ip)
    except InvalidInput as e:
        h._flash("bad", f"저장하지 않았습니다 — {e}")
        h._redirect("/admin/advanced")
        return
    if "notify_batch" in changed and vals["notify_batch"] == "0":
        h.server.notify_tick(force=True)               # 묶기를 껐다 — 쌓여 있던 것을 바로 보낸다
    h._flash("ok", "설정을 저장했습니다" if changed else "바뀐 것이 없습니다")
    h._redirect("/admin/advanced")


# ── 백업 (2026-10-30, backup.py) — 상태 보기(GET)·지금 백업(POST, 배경 스레드). 복원은 Drev PC의 명령으로만 ──────────

def get_admin_backup(h: FormsHandler) -> None:
    _require_admin(h)
    from watcher.forms import backup as FB
    store, s, bk = h.server.store, h.sess, h.server.backup
    last = FB.last_status(store)
    ok = last["ok"]
    tag = ('<span class="tag approved">확인 OK</span>' if ok else '<span class="tag rejected">실패</span>' if ok is False
           else '<span class="tag off">아직 없음</span>')
    if bk is None:
        head = ('<div class="note warn" role="status">자동 백업이 꺼져 있습니다 — Drev PC의 감시 화면 설정 › 양식함 › 백업에서 '
                '켜세요(기본 켜짐). 아래는 마지막으로 남은 기록입니다.</div>')
        ov = None
    else:
        ov = bk.overview()
        head = ""
        if ov["running"]:
            head = '<div class="note info" role="status">지금 백업 중입니다 — 잠시 뒤 이 화면을 새로 고치세요.</div>'
        elif not ov["dir_ok"] and not bk.create:
            head = (f'<div class="note bad" role="alert">백업 폴더가 없거나 열리지 않습니다: <code>{E(ov["dir"])}</code> — '
                    f'공유 폴더가 끊겼는지 확인하세요. 양식함은 그대로 돌고, 폴더가 돌아오면 다음 정리 때 다시 백업합니다.</div>')
    if bk is not None:                           # 백업이 데이터와 같은 디스크 (2026-10-30) — 막지 않고 알리기만
        from watcher.forms.settings import same_disk_warning
        warn = same_disk_warning(bk.dir, store.data_dir)
        if warn:
            head += f'<div class="note warn" role="status">{E(warn)}</div>'
    summ = last["summary"] or {}
    probs = "".join(f"<li>{E(p)}</li>" for p in (summ.get("problems") or [])[:10])
    rows = [("마지막 백업", E(_fmt_time(last["at"])) or "—"), ("결과", f'{tag} {E(FB.status_line(last))}')]
    if ov is not None:
        rows += [("백업 폴더", f'<code>{E(ov["dir"])}</code>'),
                 ("남은 공간", E(_fmt_size(ov["free"])) if ov["free"] is not None else "알 수 없음"),
                 ("자동 백업", f'매일 {ov["hour"]}시 뒤 그날 첫 정리 때 (DB 사본 {ov["keep"]}개를 돌려 씀, 판 파일 사본은 쌓음)')]
    if summ.get("files_total") is not None:
        rows.append(("판 파일 사본", f'{int(summ.get("files_total") or 0)}개 · {E(_fmt_size(summ.get("files_bytes") or 0))}'))
    info = '<dl class="kv">' + "".join(f"<dt>{k}</dt><dd>{v}</dd>" for k, v in rows) + "</dl>"
    if bk is not None:                           # 볼륨 단위 판정이 못 잡는 경우 (2026-10-30 검토 7)
        from watcher.forms.settings import SAME_DISK_HINT
        info += f'<p class="muted">백업 위치 참고: {E(SAME_DISK_HINT)}</p>'
    if probs:
        info += f'<div class="note warn">확인에서 걸린 것 (앞의 10개)<ul>{probs}</ul></div>'
    slot_rows = "".join(f'<tr><td class="nw">{d["n"]}</td><td class="nw">{E(_fmt_time(d["at"])) or "—"}</td>'
                        f'<td class="nw">{E(_fmt_size(d["size"]))}</td></tr>' for d in (ov["slots"] if ov else []))
    slots_html = (('<h2>DB 사본</h2><div class="tablewrap"><table><thead><tr><th>슬롯</th><th>찍은 때</th><th>크기</th>'
                   '</tr></thead><tbody>' + slot_rows + '</tbody></table></div>') if slot_rows else "")
    run = ""
    if bk is not None and not ov["running"]:
        run = (f'<form method="post" action="/admin/backup/run">{_hidden(h)}'
               f'<button class="btn" type="submit">지금 백업</button> <span class="muted">판 파일 사본도 지문까지 다시 '
               f'확인합니다. 배경에서 돌고 끝나면 여기와 감사 기록에 남습니다.</span></form>')
    hist = store.audit_log(s.user_id, limit=10, action="backup") + store.audit_log(s.user_id, limit=10,
                                                                                   action="backup_fail")
    hist.sort(key=lambda r: (str(r.get("at") or ""), int(r.get("id") or 0)), reverse=True)
    trs = "".join(f'<tr><td class="nw">{E(_fmt_time(r["at"]))}</td><td>{E(r["login"])}</td>'
                  f'<td>{E(ACTION_LABEL.get(r["action"], r["action"]))}</td><td>{E(r["detail"])}</td></tr>'
                  for r in hist[:10])
    hist_html = ('<h2>최근 결과</h2><div class="tablewrap"><table><thead><tr><th>때</th><th>누가</th><th>일</th>'
                 '<th>내용</th></tr></thead><tbody>' + trs + '</tbody></table></div>') if trs \
        else '<h2>최근 결과</h2><p class="empty">기록이 없습니다</p>'
    bdir = ov["dir"] if ov else "<백업 폴더>"
    restore = (f'<h2>복원</h2><p class="muted">복원은 이 화면에서 하지 않습니다 — Drev PC에서 양식함을 끈 뒤 명령으로 합니다. '
               f'지금 forms.db는 지우지 않고 <code>forms.db.before-restore-…</code>로 남기고, 검사를 통과한 가장 새 사본을 쓰며, '
               f'판 파일은 없는 것만 되살린 뒤 모든 판의 지문을 확인합니다. 먼저 <code>--dry-run</code>으로 무엇이 바뀌는지 보세요. '
               f'붙여 넣을 전체 명령은 감시 화면 설정 › 양식함 › 백업 칸에 있습니다.</p>'
               f'<p><code>forms-restore --from "{E(bdir)}" --dry-run</code></p>')
    body = (f'{head}<div class="panel">{info}{run}</div><div class="panel">{slots_html}{hist_html}</div>'
            f'<div class="panel">{restore}</div>')
    h._send(200, h._shell("백업", body, active="/admin/advanced"))


def post_admin_backup_run(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    bk = h.server.backup
    if bk is None:
        h._flash("bad", "자동 백업이 꺼져 있어 백업하지 않았습니다 — Drev PC의 설정 › 양식함 › 백업에서 켜세요")
    elif bk.run_async(deep=True, actor_id=h.sess.user_id):
        h._flash("ok", "백업을 시작했습니다 — 잠시 뒤 이 화면을 새로 고치면 결과가 보입니다")
    else:
        h._flash("info", "이미 백업 중입니다 — 잠시 뒤 이 화면을 새로 고치세요")
    h._redirect("/admin/backup")


# ── 기록 보존 만료 (2026-10-30 사용자 결정 ③, keep.py) — 관리자만. 기본 영구 보존, 저절로 지우지 않는다 ──────────
# 목록(GET, 읽기만) → 고르기 → [정리하기](POST do=preview, 바꾸지 않음 — 지울 목록과 지문) → 확인 칸 + 지문으로 실행(POST do=run)

def _years_label(n) -> str:
    return "영구 보존" if not n else f"{int(n)}년"


def _retention_ids(h: FormsHandler, f: dict) -> list[int]:
    """고른 판 id — 줄마다 칸(id)과 [이 쪽 모두 고르기](all + pids '1,2,3'). 확인 화면은 ids '1,2,3'."""
    ids = [h._int(v) for v in f.get("id", [])]
    for key in ("pids", "ids"):
        if key == "pids" and h._one(f, "all") != "1":
            continue
        raw = h._one(f, key)
        if len(raw) > 8000:
            raise HttpError(400, "고른 판이 너무 많습니다")
        ids += [h._int(x) for x in raw.split(",") if x.strip()]
    return sorted(set(ids))


def get_admin_retention(h: FormsHandler) -> None:
    """보존 만료 화면 — 정책(전체 기본값·문서 종류별)과 보존 기간이 지난 판 목록(200줄씩, 고르기). 읽기만."""
    _require_admin(h)
    store, s = h.server.store, h.sess
    hid = _hidden(h)
    pol = keep.policy(store)
    intro = (f'<p>지금: 지난 판 <b>{_years_label(pol["superseded"])}</b> · 폐기한 양식 <b>{_years_label(pol["retired"])}</b>'
             + (' <span class="tag off">기본값 — 아무것도 지우지 않음</span>' if pol["forever"] else "") + '</p>'
             '<p class="muted">ISO 문서 관리처럼 지난 판과 폐기한 양식의 파일을 몇 년 보존한 뒤 정리할 수 있습니다. '
             '<b>기본은 영구 보존</b>이고, 기간을 정해도 Drev가 저절로 지우지 않습니다 — 아래 목록에서 관리자가 골라 '
             '[정리하기]를 누르고 확인해야 지웁니다. 지우는 것은 판 <b>파일</b>뿐이고 판 기록(번호·지문·승인·감사 기록)은 남습니다.</p>'
             '<ul class="lines"><li>지난 판: 그 판을 대신한 새 판이 승인된 날 + 지난 판 보존 연수</li>'
             '<li>폐기한 양식: 폐기한 날 + 폐기 양식 보존 연수 (현행 판 포함 그 양식의 모든 판)</li>'
             '<li>목록의 <b>보존 시작일</b>은 그 판이 새 판으로 대체된 날(새 판 승인일)이나 양식을 폐기한 날입니다 — '
             '여기에 보존 연수를 더한 날이 <b>보존 만료일</b>입니다</li>'
             '<li>둘 다 걸리면 먼저 오는 날. 쓰는 중인 양식의 현행 판은 만료되지 않고, 복원한 양식은 폐기 규칙에서 빠집니다</li>'
             '<li>검토 대기·반려 파일은 따로(90일 뒤 자동 정리) — 여기서 다루지 않습니다</li>'
             '<li>정리한 판의 백업 사본은 다음 백업이 지우고, 복원(forms-restore)은 정리한 판을 되살리지 않습니다</li></ul>')
    form = (f'<form method="post" action="/admin/retention">{hid}'
            f'<label for="ks">지난 판 보존 연수</label>'
            f'<input type="text" class="months" id="ks" name="superseded" value="{pol["superseded"]}" inputmode="numeric" '
            f'maxlength="2" required>{_hint(HINT_KEEP_YEARS)}'
            f'<label for="kr">폐기 양식 보존 연수</label>'
            f'<input type="text" class="months" id="kr" name="retired" value="{pol["retired"]}" inputmode="numeric" '
            f'maxlength="2" required>{_hint(HINT_KEEP_YEARS)}'
            f'<div class="form-actions"><button class="btn" type="submit">저장</button></div></form>')
    policy_panel = f'<div class="panel" id="policy"><h2>보존 기간</h2>{intro}{form}</div>'
    types = store.list_doc_types(s.user_id)
    trs = []
    for t in types:
        val = "" if t["keep_years"] is None else str(t["keep_years"])
        now = "기본값 따름" if t["keep_years"] is None else _years_label(t["keep_years"])
        trs.append(f'<tr><td class="nw"><span class="tag dtype">{E(t["code"])}</span></td><td>{E(t["name"])}'
                   + ('' if t["active"] else ' <span class="muted">(사용 중지)</span>') + f'</td>'
                   f'<td class="nw">{E(now)}</td><td><form class="inline" method="post" action="/admin/retention/type">{hid}'
                   f'<input type="hidden" name="type" value="{t["id"]}">'
                   f'<input type="text" class="months" name="years" value="{E(val)}" inputmode="numeric" maxlength="2" '
                   f'aria-label="{E(t["code"])} 보존 연수" placeholder="기본">'
                   f'<button class="btn gray sm" type="submit">저장</button></form></td></tr>')
    type_panel = (f'<div class="panel" id="types"><h2>문서 종류별 보존 연수</h2>'
                  f'<p class="muted">종류마다 다르게 둘 때만 적습니다 — 적으면 그 종류 양식의 지난 판과 폐기 규칙 모두에 이 연수를 씁니다. '
                  f'종류가 없는 양식은 위 기본값을 따릅니다.</p>{_hint(HINT_TYPE_KEEP_YEARS)}'
                  + ('<div class="tablewrap"><table><thead><tr><th>기호</th><th>이름</th><th>지금</th><th>보존 연수</th></tr>'
                     '</thead><tbody>' + "".join(trs) + '</tbody></table></div>' if trs
                     else '<p class="empty">문서 종류가 없습니다</p>') + '</div>')
    # 수·크기는 SQL로 센 것(캐시), 줄은 이 쪽 200개만 읽는다 (2026-10-31 성능 — 전에는 만료 판 전부를 쪽마다 사전으로)
    n_rows, total = keep.expired_summary(store)
    page = _page_of(h, n_rows)
    shown = keep.expired_versions(store, s.user_id, limit=PAGE_ROWS, offset=page * PAGE_ROWS)
    if shown:
        trs = []
        for r in shown:
            no = f'<span class="docno">{E(r["doc_no"])}</span> ' if r["doc_no"] else ""
            trs.append(f'<tr><td class="chk"><input type="checkbox" name="id" value="{r["id"]}" form="purge" '
                       f'aria-label="{E(r["form_name"])} v{r["number"]} 고르기"></td>'
                       f'<td class="name-c">{no}<a href="/form?id={r["form_id"]}">{E(r["form_name"])}</a>'
                       + (' <span class="tag retired">폐기</span>' if r["retired"] else "") + '</td>'
                       f'<td class="nw">v{r["number"]}</td><td class="nw">{E(r["why_label"])}</td>'
                       f'<td class="nw">{E(r["ended"])}</td><td class="nw">{E(r["expires"])}</td>'
                       f'<td class="nw">{E(_fmt_size(r["size"]))}</td></tr>')
        pids = ",".join(str(r["id"]) for r in shown)
        table = ('<div class="tablewrap"><table class="keep"><thead><tr><th><span class="muted">고르기</span></th><th>양식</th>'
                 '<th>판</th><th>까닭</th><th>보존 시작일(대체·폐기된 날)</th><th>보존 만료일</th><th>크기</th></tr></thead><tbody>'
                 + "".join(trs) + '</tbody></table></div>'
                 f'<form id="purge" method="post" action="/admin/retention/purge">{hid}'
                 f'<input type="hidden" name="do" value="preview"><input type="hidden" name="pids" value="{E(pids)}">'
                 f'<label class="chk" for="kall"><input type="checkbox" id="kall" name="all" value="1">'
                 f'이 쪽의 {len(shown)}개 모두 고르기</label>'
                 f'<div class="form-actions"><button class="btn red" type="submit">정리하기</button></div></form>'
                 f'<p class="hint">[정리하기]는 아직 지우지 않습니다 — 지울 목록과 지문을 보여 주는 확인 화면으로 갑니다.</p>'
                 + _pager("/admin/retention", {}, page, n_rows > (page + 1) * PAGE_ROWS, n_rows))
    elif pol["forever"]:
        table = '<p class="empty">영구 보존이라 정리할 판이 없습니다 — 위에서 보존 연수를 정하면 기간이 지난 판이 여기에 보입니다</p>'
    else:
        table = '<p class="empty">보존 기간이 지난 판이 없습니다</p>'
    list_panel = (f'<div class="panel" id="expired"><h2>보존 기간이 지난 판 {n_rows}개'
                  + (f' · {E(_fmt_size(total))}' if n_rows else "") + f'</h2>{table}</div>')
    h._send(200, h._shell("보존 만료", policy_panel + type_panel + list_panel, active="/admin/advanced"))


def post_admin_retention(h: FormsHandler) -> None:
    """전체 보존 연수 저장 — 관리자만 (store도 다시 본다)."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    try:
        old = keep.policy(h.server.store)
        pol = keep.set_policy(h.server.store, h.sess.user_id, h._one(f, "superseded")[:12], h._one(f, "retired")[:12],
                              ip=h.ip)
    except InvalidInput as e:
        h._flash("bad", f"저장하지 않았습니다 — {e}")
        h._redirect("/admin/retention")
        return
    same = (old["superseded"], old["retired"]) == (pol["superseded"], pol["retired"])
    h._flash("ok", "바뀐 것이 없습니다" if same else
             f"보존 기간을 저장했습니다 — 지난 판 {_years_label(pol['superseded'])}, 폐기한 양식 {_years_label(pol['retired'])}. "
             f"저절로 지우지 않습니다 — 기간이 지난 판은 아래 목록에서 골라 정리하세요")
    h._redirect("/admin/retention")


def post_admin_retention_type(h: FormsHandler) -> None:
    """문서 종류별 보존 연수 — 비우면 기본값을 따른다. 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    tid = h._int(h._one(f, "type"))
    try:
        changed = keep.set_type_years(h.server.store, h.sess.user_id, tid, h._one(f, "years")[:12], ip=h.ip)
    except InvalidInput as e:
        h._flash("bad", f"저장하지 않았습니다 — {e}")
        h._redirect("/admin/retention#types")
        return
    h._flash("ok", "문서 종류의 보존 연수를 저장했습니다" if changed else "바뀐 것이 없습니다")
    h._redirect("/admin/retention#types")


def post_admin_retention_purge(h: FormsHandler) -> None:
    """[정리하기](do=preview — 확인 화면, 바꾸지 않음) / 실행(do=run — 확인 칸 + 확인 화면의 지문). 관리자만."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    do = h._one(f, "do")
    if do not in ("preview", "run"):
        raise HttpError(400, "할 일을 골라 주세요")
    ids = _retention_ids(h, f)
    if not ids:
        h._flash("bad", "정리할 판을 왼쪽 칸에서 골라 주세요 (또는 '이 쪽 모두 고르기')")
        h._redirect("/admin/retention#expired")
        return
    if do == "preview":
        _purge_preview(h, ids)
        return
    digest = h._one(f, "digest")
    if not re.fullmatch(r"[0-9a-f]{64}", digest or ""):
        # 막다른 400 화면 대신 목록으로 — 다른 정리 실패와 같게 (2026-10-31 실사용 검토)
        h._flash("bad", "정리하지 않았습니다 — 확인 화면을 먼저 보고 실행해 주세요. 판을 다시 골라 [정리하기]를 누르세요")
        h._redirect("/admin/retention#expired")
        return
    if h._one(f, "confirm") != "1":
        # 확인 칸을 빠뜨렸으면 같은 확인 화면을 다시 — 읽기만 한다, 아무것도 지우지 않는다
        _purge_preview(h, ids, note="정리하지 않았습니다 — 아래 확인 칸에 체크한 뒤 [정리 실행]을 누르세요")
        return
    try:
        res = keep.purge(store, s.user_id, ids, expect=digest, ip=h.ip)
    except (Conflict, InvalidInput) as e:
        h._flash("bad", str(e))
        h._redirect("/admin/retention#expired")
        return
    done = len(res["purged"]) + len(res["missing"])
    msg = f"보존 기간이 지난 판 {done}개를 정리했습니다 (파일 지움 {len(res['purged'])}개"
    if res["missing"]:
        msg += f", 파일이 이미 없어 정리됨으로만 적음 {len(res['missing'])}개"
    msg += ")"
    if res["failed"]:
        r0, why = res["failed"][0]
        msg += f" — 못 지운 판 {len(res['failed'])}개는 목록에 남았습니다: {r0['form_name']} v{r0['number']} — {why}"
    h._flash("bad" if res["failed"] and not done else "ok", msg)
    h._redirect("/admin/retention")


def _purge_preview(h: FormsHandler, ids: list[int], *, note: str = "") -> None:
    """정리 확인 화면 — 바꾸지 않는다. note: 확인 칸을 빠뜨리고 실행했을 때 위에 띄우는 한 줄."""
    store, s = h.server.store, h.sess
    try:
        plan = keep.purge_plan(store, s.user_id, ids)
    except (Conflict, InvalidInput) as e:
        h._flash("bad", str(e))
        h._redirect("/admin/retention#expired")
        return
    trs = "".join(
        f'<tr><td class="name-c">' + (f'<span class="docno">{E(r["doc_no"])}</span> ' if r["doc_no"] else "")
        + f'{E(r["form_name"])}</td><td class="nw">v{r["number"]}</td><td class="file-c">{E(r["filename"])}</td>'
        f'<td class="nw">{E(r["why_label"])}</td><td class="nw">{E(r["expires"])}</td>'
        f'<td class="nw">{E(_fmt_size(r["size"]))}</td></tr>' for r in plan["rows"])
    n = len(plan["rows"])
    body = (f'<div class="crumb"><a href="/admin/retention">보존 만료</a> / 정리 확인</div>'
            f'<div class="panel"><div class="note warn" role="status">아래 판 <b>{n}개</b>의 파일 '
            f'({E(_fmt_size(plan["total_size"]))})을 지웁니다. <b>되돌릴 수 없습니다.</b> 판 기록(번호·지문·승인·감사 기록)은 '
            f'남고, 양식 상세에는 [정리됨]으로 보이며 내려받을 수 없게 됩니다. 백업 폴더의 사본도 다음 백업 때 지웁니다.</div>'
            f'<div class="tablewrap"><table class="keep"><thead><tr><th>양식</th><th>판</th><th>파일</th><th>까닭</th>'
            f'<th>보존 만료일</th><th>크기</th></tr></thead><tbody>{trs}</tbody></table></div>'
            f'<p class="muted">확인 지문 <code>{E(plan["digest"][:16])}</code> — 이 화면을 연 뒤 목록이나 보존 기간이 바뀌면 '
            f'실행하지 않고 다시 확인하게 합니다.</p>'
            f'<form method="post" action="/admin/retention/purge">{_hidden(h)}'
            f'<input type="hidden" name="do" value="run"><input type="hidden" name="digest" value="{E(plan["digest"])}">'
            f'<input type="hidden" name="ids" value="{E(",".join(str(r["id"]) for r in plan["rows"]))}">'
            f'<label class="chk" for="kc"><input type="checkbox" id="kc" name="confirm" value="1" required>'
            f'위 판 {n}개의 파일을 지우는 것을 확인합니다</label>'
            f'<div class="form-actions"><button class="btn red" type="submit">정리 실행</button>'
            f'<a class="btn gray" href="/admin/retention#expired">그만두기</a></div></form></div>')
    if note:
        h._flash("bad", note)
    h._send(200, h._shell("보존 만료 — 정리 확인", body, active="/admin/advanced"))


# 경로 → (처리 함수, 로그인 없이 열리나)
_GET = {
    "/": (get_root, True), "/login": (get_login, True), "/setup": (get_setup, True),
    "/password": (get_password, False), "/forms": (get_forms, False), "/upload": (get_upload, False),
    "/mine": (get_mine, False), "/form": (get_form, False), "/download": (get_download, False),
    "/review": (get_review, False), "/review/file": (get_review_file, False),
    "/review/item": (get_review_item, False), "/compare": (get_compare, False),
    "/admin/users": (get_admin_users, False), "/admin/folders": (get_admin_folders, False),
    "/admin/audit": (get_admin_audit, False), "/folders/move": (get_folder_move, False),       # f6
    "/register": (get_register, False), "/register.xlsx": (get_register_xlsx, False),           # F7 문서 관리 대장
    "/register/due": (get_register_due, False),
    "/admin/docno": (get_admin_docno, False),                                                   # F7 번호 규칙
    "/admin/doctypes": (get_admin_doctypes, False),                                             # F7 문서 종류
    "/admin/backup": (get_admin_backup, False),                                                 # 백업 (2026-10-30)
    "/admin/retention": (get_admin_retention, False),                                           # 보존 만료 (2026-10-30)
    # 기능 검토 F2 (2026-11-02)
    "/check": (get_check, False), "/folders/prune": (get_folder_prune, False),
    "/admin/advanced": (get_admin_advanced, False),
}
_POST = {
    "/login": (post_login, True), "/setup": (post_setup, True), "/theme": (post_theme, True),
    "/logout": (post_logout, False), "/password": (post_password, False),
    "/folders/new": (post_folder_new, False), "/folders/rename": (post_folder_rename, False),
    "/folders/subscribe": (post_folder_subscribe, False), "/admin/users/email": (post_user_email, False),
    "/upload": (post_upload, False), "/submissions/cancel": (post_cancel, False),
    "/review/approve": (post_approve, False), "/review/reject": (post_reject, False),
    "/review/check": (post_check, False), "/admin/approval": (post_admin_approval, False),     # 2단계 승인 (2026-10-30)
    "/form/retire": (post_retire, False), "/form/restore": (post_restore, False),
    "/admin/users/new": (post_user_new, False), "/admin/users/disable": (post_user_disable, False),
    "/admin/users/reset": (post_user_reset, False), "/admin/users/role": (post_user_role, False),
    "/admin/reviewers": (post_reviewers, False),
    "/compare": (post_compare, False), "/review/compare": (post_review_compare, False),     # 보안 F3
    "/admin/unlock-ip": (post_unlock_ip, False),                                              # 보안 F2
    "/folders/move": (post_folder_move, False), "/folders/delete": (post_folder_delete, False),   # f6 폴더 관리
    "/folders/order": (post_folder_order, False), "/admin/folders/template": (post_folder_template, False),
    "/register/reviewed": (post_register_reviewed, False), "/form/review-months": (post_form_review_months, False),
    "/register/reviewed-bulk": (post_register_reviewed_bulk, False),                           # 2026-10-30 M4
    "/form/docno": (post_form_docno, False), "/admin/docno/assign": (post_docno_assign, False),     # F7
    "/folders/code": (post_folder_code, False),
    "/admin/docno": (post_admin_docno, False), "/admin/docno/renumber": (post_admin_docno_renumber, False),
    "/form/doctype": (post_form_doctype, False), "/review/doctype": (post_review_doctype, False),   # F7 문서 종류
    "/admin/doctypes/new": (post_doctype_new, False), "/admin/doctypes/edit": (post_doctype_edit, False),
    "/admin/doctypes/active": (post_doctype_active, False), "/admin/doctypes/delete": (post_doctype_delete, False),
    "/admin/doctypes/assign": (post_doctype_assign, False),
    "/admin/backup/run": (post_admin_backup_run, False),                                        # 백업 (2026-10-30)
    "/folders/restricted": (post_folder_restricted, False), "/folders/members": (post_folder_members, False),  # 기밀 폴더
    "/admin/retention": (post_admin_retention, False), "/admin/retention/type": (post_admin_retention_type, False),
    "/admin/retention/purge": (post_admin_retention_purge, False),                              # 보존 만료 (2026-10-30)
    # 기능 검토 F2 (2026-11-02)
    "/upload/confirm": (post_upload_confirm, False), "/admin/users/bulk": (post_users_bulk, False),
    "/check": (post_check_file, False), "/folders/prune": (post_folder_prune, False),
    "/folders/subscribe-all": (post_folder_subscribe_all, False), "/form/move": (post_form_move, False),
    "/admin/advanced": (post_admin_advanced, False),
}
# 사내망 변경 확인·열람 (기능 검토 갈래 N, 2026-11-02 — FORMS.md 11절). 화면 처리는 changes.py에 — 이 파일은 경로만 잇는다
from watcher.forms import changes as _changes  # noqa: E402 — 위 정의(HttpError·_hidden 등)를 changes가 부를 때 쓴다

_GET.update({k: (fn, False) for k, fn in _changes.ROUTES_GET.items()})
_POST.update({k: (fn, False) for k, fn in _changes.ROUTES_POST.items()})
# 비밀번호를 바꿔야 하는 계정이 쓸 수 있는 주소
_MUST_CHANGE_OK = {"/password", "/logout", "/theme", "/login", "/setup", "/"}


# ── 손으로 띄우기 ────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):      # 한국어 Windows 콘솔(cp949)에서 글자 하나로 죽지 않게
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    p = argparse.ArgumentParser(prog="python -m watcher.forms.server",
                                description="Drev 양식함 사내망 화면 서버 (손으로 띄우기, 상시 실행은 F4의 forms-serve)")
    p.add_argument("--data", required=True, help="Drev 데이터 폴더 (forms.db·forms_store가 생기는 곳)")
    p.add_argument("--host", default="127.0.0.1", help="사내망 주소 (기본 127.0.0.1, 모든 주소: 0.0.0.0)")
    p.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"포트 (기본 {DEFAULT_PORT})")
    p.add_argument("--mirror", default=None, help="(선택) 현행 미러 폴더")
    p.add_argument("--max-upload-mb", type=int, default=MAX_UPLOAD_BYTES // (1024 * 1024),
                   help="올리기 상한 MB (기본 50)")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    def ready(srv):
        host, port = srv.server_address[:2]
        print(f"양식함이 열렸습니다: http://{host}:{port}/  (멈추려면 Ctrl+C)", flush=True)
        if host in ("0.0.0.0", "::"):
            print("사내망 전용입니다 — 공유기에서 이 포트를 인터넷으로 열지 마세요.", flush=True)

    try:
        serve(a.data, a.host, a.port, mirror_root=a.mirror,
              max_upload_bytes=max(1, a.max_upload_mb) * 1024 * 1024, on_ready=ready)
    except AlreadyRunning as e:
        print(str(e), file=sys.stderr)
        return 2
    except (FormsError, OSError) as e:
        print(f"양식함을 열 수 없습니다: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
