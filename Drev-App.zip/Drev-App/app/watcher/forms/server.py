# -*- coding: utf-8 -*-
"""양식함 사내망 화면 서버 (FORMS.md 3·4·6절, 2026-10-28 F2).

- 표준 라이브러리 http.server(ThreadingHTTPServer)만 쓴다. 저장·권한은 store.FormsStore, 계정은 auth.
  이 모듈은 파일을 쓰지 않는다 — 소켓으로 응답을 보낼 뿐(self.wfile.write 한 곳, tests/test_readonly.py).
- 화면: 로그인·로그아웃·비밀번호 바꾸기, 첫 관리자 만들기(Drev PC에서만), 양식함(폴더 트리·목록·검색),
  폴더 만들기·이름 바꾸기, 양식 올리기(검토 대기)·내 제출, 양식 상세·판 이력·내려받기,
  관리자(계정·폴더 검토자·감사 기록), 검토(F3: 현행 판과 자동 비교·새 양식 요약·승인 메모·반려 사유),
  판끼리 비교(F3), 폐기·복원(F3, 사유 필수).
- 보안(6절): 상태를 바꾸는 요청은 전부 POST + 세션 + CSRF(로그인 전 화면은 이중 제출 쿠키). GET은 바꾸지 않는다.
  보안 헤더(CSP에 스크립트 없음·인라인 스타일 없음), HttpOnly·SameSite=Strict 쿠키, 모든 출력 html.escape,
  요청 줄·헤더 크기 상한, 느린 요청 끊기(감시 스레드), 동시 연결 상한, 본문을 읽기 전에 Content-Length로 413.
  오류는 화면에 Traceback을 보이지 않고 로그에만 남긴다. 인터넷 주소(공인 IP)에서 온 요청은 받지 않는다.
- 보안 검토 고침(2026-10-28): 비인증 POST 주소별 토큰 버킷(429), 주소 잠금·잠긴 주소 풀기 화면, GET /compare는 캐시만
  (계산은 POST [비교하기]), 검토 화면 자동 비교는 대기 1건당 1회, 정리 일 스레드(대기 파일 보존 기간·실패 행).
- 손으로 띄우기: python -m watcher.forms.server --data <데이터 폴더> --host <사내망 IP> --port 8766
  (forms-serve 명령·DrevForms 예약 작업·방화벽은 F4.)
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import html
import ipaddress
import logging
import os
import re
import secrets
import socket
import sys
import threading
import time
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

from watcher.forms import auth
from watcher.forms.compare import COMPARE_TIMEOUT, Comparer
from watcher.forms.notify import Notifier
from watcher.forms.publish import Mirror
from watcher.forms.store import (ALLOWED_EXTS, AUDIT_MAX_ROWS, MAX_UPLOAD_BYTES, PENDING_KEEP_DAYS, Conflict,
                                 FormsError, FormsStore, InvalidInput, NotFound, PermissionDenied)

log = logging.getLogger("drev.forms.server")

DEFAULT_PORT = 8766
SESSION_COOKIE = "drev_forms"
PRE_COOKIE = "drev_forms_pre"         # 로그인 전 화면(로그인·첫 관리자)의 CSRF 이중 제출 쿠키
THEME_COOKIE = "drev_forms_theme"
RETIRED_PREFIX = "[폐기] "               # 폐기된 양식을 내려받을 때 파일 이름 앞에 (F3)
MAX_REQUEST_LINE = 8 * 1024
MAX_HEADER_BYTES = 32 * 1024
MAX_HEADERS = 60
MAX_FORM_BODY = 64 * 1024              # 올리기가 아닌 POST(글자 칸만)
MULTIPART_SLACK = 1024 * 1024          # 올리기 본문 = 파일 상한 + 이만큼(경계·다른 칸)
MAX_CONNECTIONS = 64
HEADER_SECONDS = 20.0                  # 요청 줄·헤더를 이 안에 다 보내야 한다
BODY_MIN_RATE = 128 * 1024             # 본문·응답은 최소 이 속도(바이트/초) + 30초 여유
SOCKET_TIMEOUT = 20                    # 한 번 읽기·쓰기가 이만큼 멈추면 끊는다

ROLE_LABEL = {"admin": "관리자", "reviewer": "검토자", "member": "직원"}
STATUS_LABEL = {"pending": "검토 대기", "approved": "승인됨", "rejected": "반려됨", "cancelled": "취소함"}
KIND_LABEL = {"new": "새 양식", "revision": "개정안"}
ACTION_LABEL = {
    "admin_bootstrap": "첫 관리자 만듦", "user_create": "계정 등록", "user_disable": "계정 정지",
    "user_enable": "계정 복구", "user_role": "역할 바꿈", "password_reset": "비밀번호 초기화",
    "password_change": "비밀번호 바꿈", "login": "로그인", "login_fail": "로그인 실패",
    "login_locked": "잠긴 동안 로그인 시도", "login_disabled": "정지 계정 로그인 시도", "logout": "로그아웃",
    "folder_create": "폴더 만듦", "folder_rename": "폴더 이름 바꿈", "folder_reviewers": "검토자 지정",
    "submit": "올림", "approve": "승인", "reject": "반려", "cancel": "제출 취소",
    "download": "내려받음", "download_submission": "대기 파일 열어 봄", "retire": "폐기", "restore": "복원",
    "compare_fail": "자동 비교 실패",
    "user_email": "메일 주소 바꿈", "notify": "메일 알림 보냄", "notify_fail": "메일 알림 실패",
    "mirror_fail": "현행 미러 실패", "mirror_skip": "현행 미러 건너뜀",
    "ip_locked": "접속 주소 잠김", "ip_unlock": "접속 주소 잠금 풀기", "pending_purge": "대기 파일 정리",
}
# 비인증 화면(로그인·첫 관리자) POST의 주소(IP)별 토큰 버킷 — 순간 30번, 그 뒤 초당 1번 (2026-10-28 보안 F1)
RATE_CAPACITY = 30
RATE_PER_SECOND = 1.0
MAINT_SECONDS = 3600                   # 정리 일(대기 파일·실패 행)을 도는 간격(초) — 서버 시작 때 한 번 + 이만큼마다
_ERROR_TEXT = {
    400: "요청을 이해하지 못했습니다", 401: "로그인이 필요합니다", 403: "할 수 없는 일입니다",
    404: "없는 화면입니다", 405: "이 방법으로는 열 수 없는 주소입니다", 408: "요청이 너무 느려 끊었습니다",
    409: "지금 상태와 맞지 않습니다", 411: "본문 길이(Content-Length)가 필요합니다",
    413: "보낸 내용이 너무 큽니다", 414: "주소가 너무 깁니다", 415: "지원하지 않는 형식입니다",
    429: "잠시 뒤에 다시 해 주세요", 431: "요청 머리글이 너무 큽니다", 500: "문제가 생겼습니다",
    501: "지원하지 않는 요청입니다", 503: "접속이 많습니다 — 잠시 뒤에 다시 해 주세요",
}
_BUSY = ("HTTP/1.0 503 Service Unavailable\r\nContent-Type: text/plain; charset=utf-8\r\n"
         "Connection: close\r\nRetry-After: 5\r\nX-Content-Type-Options: nosniff\r\n\r\n"
         "busy\r\n").encode("ascii")

# 스크립트 없음, 인라인 스타일 없음 — 스타일은 /forms.css 하나 (FORMS.md 6절 CSP default-src 'self')
CSP = ("default-src 'self'; script-src 'none'; style-src 'self'; img-src 'self' data:; "
       "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")
SECURITY_HEADERS = (
    ("X-Frame-Options", "DENY"),
    ("Content-Security-Policy", CSP),
    ("X-Content-Type-Options", "nosniff"),
    ("Referrer-Policy", "same-origin"),
    ("Cache-Control", "no-store"),
    ("Cross-Origin-Opener-Policy", "same-origin"),
)

E = html.escape


class AlreadyRunning(FormsError):
    """같은 데이터 폴더로 양식함 서버가 이미 돌고 있다."""


class HttpError(Exception):
    """화면에 보일 HTTP 오류 (status, 쉬운 말)."""

    def __init__(self, status: int, message: str = ""):
        super().__init__(message)
        self.status = int(status)
        self.message = message or _ERROR_TEXT.get(self.status, "요청을 처리할 수 없습니다")


class MultipartError(ValueError):
    """올리기 본문(multipart/form-data)이 깨졌다 → 400."""


# ── 화면 모양 (Drev 감시 화면과 같은 토큰, 어두운·밝은 테마) ────────────────────────

_DARK_TOKENS = """
  --bg:#0C0E12; --panel:#14171D; --panel2:#1A1E26; --hover:#212634;
  --border:#232833; --border2:#333B4A; --line:#1E242F;
  --text:#E6E9EF; --text2:#CBD1DC; --text3:#ADB5C4; --muted:#AAB2C1; --muted2:#8E97A8;
  --link:#93A0FA; --accent:#4C5DE6; --accent2:#7C8CF8; --on-accent:#FFFFFF;
  --ok:#3FB950; --ok-strong:#4ADE80; --warn:#E3B341; --warn3:#EAB94E; --bad:#F47067; --bad-btn:#C62F2F;
  --tag-add:rgba(63,185,80,.14); --tag-mod:rgba(227,179,65,.14); --tag-rm:rgba(244,112,103,.15);
  --tag-done:rgba(124,140,248,.16); --note-warn:#2E2612; --note-info:#1B2140;
  --shadow:0 1px 3px rgba(0,0,0,.45); color-scheme:dark;"""

CSS = """/* Drev 양식함 — 감시 화면(web.py)과 같은 디자인 토큰. 기본은 OS 설정을 따르고 [테마] 단추로 고정 */
:root{
  --bg:#F2F4F8; --panel:#FFFFFF; --panel2:#F7F8FB; --hover:#EEF0F6;
  --border:#E3E6EE; --border2:#C9CEDB; --line:#EEF0F5;
  --text:#171C26; --text2:#2A303C; --text3:#454D5E; --muted:#596273; --muted2:#5F6B82;
  --link:#4353E8; --accent:#4353E8; --accent2:#5B6CF5; --on-accent:#FFFFFF;
  --ok:#0F8A3D; --ok-strong:#0F7A37; --warn:#B97800; --warn3:#8A5A05; --bad:#C62F2F; --bad-btn:#C62F2F;
  --tag-add:#E2F5E9; --tag-mod:#FBF0D9; --tag-rm:#FBE7E7; --tag-done:#E5E9FD;
  --note-warn:#FFF8E5; --note-info:#E8ECFE;
  --shadow:0 1px 3px rgba(23,28,38,.06), 0 1px 2px rgba(23,28,38,.04); color-scheme:light;
  --fs-s:13px; --fs-m:15px; --fs-l:17px;
}
@media (prefers-color-scheme: dark){ :root:not([data-theme=light]){""" + _DARK_TOKENS + """} }
:root[data-theme=dark]{""" + _DARK_TOKENS + """}
*{margin:0;box-sizing:border-box;font-family:'Pretendard','Malgun Gothic','Segoe UI Variable','Segoe UI',sans-serif}
body{background:var(--bg);color:var(--text);display:flex;min-height:100vh;-webkit-font-smoothing:antialiased}
a{color:var(--link);text-decoration:none} a:hover{text-decoration:underline}
.skip{position:absolute;left:-9999px;top:0;z-index:200;background:var(--accent);color:#fff;padding:8px 14px}
.skip:focus{left:0}
.side{width:216px;background:var(--panel);border-right:1px solid var(--border);padding:18px 12px;
  position:fixed;top:0;bottom:0;display:flex;flex-direction:column;overflow-y:auto}
.logo{font-weight:800;font-size:17px;color:var(--link);padding:6px 10px 16px}
.logo small{display:block;color:var(--muted);font-weight:400;font-size:12px;margin-top:3px}
.nav{flex:1}
.nav .grp{font-size:11px;color:var(--muted);letter-spacing:.6px;padding:12px 12px 4px}
.nav a{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;border-radius:9px;
  min-height:36px;color:var(--text3);font-size:14px;margin-bottom:2px}
.nav a:hover{background:var(--hover);color:var(--text);text-decoration:none}
.nav a.on{background:var(--accent);color:var(--on-accent);font-weight:700}
.cnt{display:inline-block;min-width:22px;padding:1px 7px;border-radius:999px;background:var(--tag-mod);
  color:var(--warn3);font-size:12px;font-weight:700;text-align:center}
.nav a.on .cnt{background:rgba(255,255,255,.25);color:#fff}
.me{border-top:1px solid var(--line);padding:12px 8px 4px;font-size:13px;color:var(--muted)}
.me b{display:block;color:var(--text);font-size:14px;margin-bottom:2px}
.me a{display:block;margin:8px 0 4px}
.me form{margin-top:6px}
.side .btn{width:100%}
.main{margin-left:216px;flex:1;min-width:0;padding:22px 30px;max-width:1500px}
.topbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:16px}
.topbar h1{font-size:20px;font-weight:800;letter-spacing:-.3px}
.crumb{font-size:var(--fs-s);color:var(--muted2);margin-bottom:6px}
.panel{background:var(--panel);border-radius:12px;padding:14px 18px;margin-bottom:12px;
  border:1px solid var(--border);box-shadow:var(--shadow);overflow-x:auto}
.panel h2{font-size:var(--fs-l);margin:0 0 10px;font-weight:700}
.panel h3{font-size:var(--fs-m);margin:14px 0 8px;font-weight:700}
.split{display:grid;grid-template-columns:250px minmax(0,1fr);gap:12px;align-items:start}
.tree ul{list-style:none;padding-left:14px;margin:2px 0}
.tree>ul{padding-left:0}
.tree li{margin:1px 0}
.tree a{display:block;padding:5px 8px;border-radius:8px;color:var(--text2);font-size:14px;word-break:break-all}
.tree a:hover{background:var(--hover);text-decoration:none}
.tree a.on{background:var(--tag-done);color:var(--link);font-weight:700}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.chips a{border:1px solid var(--border);border-radius:999px;padding:4px 12px;font-size:13px;color:var(--text2);
  background:var(--panel2)}
table{width:100%;border-collapse:collapse;font-size:14px}
th{color:var(--muted);font-weight:600;text-align:left;padding:7px 10px;border-bottom:1px solid var(--border);
  font-size:12px;background:var(--panel2);white-space:nowrap}
td{padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top;font-variant-numeric:tabular-nums}
tr:hover td{background:var(--panel2)}
td.nw{white-space:nowrap}
.muted{color:var(--muted2);font-size:13px}
.panel>p.muted{margin-bottom:10px}
.empty{color:var(--muted);padding:18px 4px;text-align:center}
.tag{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;white-space:nowrap}
.tag.pending{background:var(--tag-mod);color:var(--warn3)}
.tag.approved{background:var(--tag-add);color:var(--ok-strong)}
.tag.rejected{background:var(--tag-rm);color:var(--bad)}
.tag.cancelled,.tag.retired,.tag.off{background:var(--hover);color:var(--muted)}
.tag.role{background:var(--tag-done);color:var(--link)}
.btn{display:inline-block;background:var(--accent);color:var(--on-accent);border:none;border-radius:9px;
  padding:6px 14px;min-height:32px;font-size:14px;cursor:pointer;font-weight:700;white-space:nowrap;line-height:20px}
.btn:hover{filter:brightness(1.08);text-decoration:none}
.btn.gray{background:var(--panel2);color:var(--text2);border:1px solid var(--border)}
.btn.red{background:var(--bad-btn);color:#fff}
.btn.sm{min-height:28px;padding:4px 10px;font-size:13px}
form.inline{display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap;margin:2px 0}
label{display:block;margin:10px 0 4px;font-size:13px;color:var(--muted)}
label.chk{display:inline-flex;align-items:center;gap:6px;margin:4px 12px 4px 0;color:var(--text2);font-size:14px}
input[type=text],input[type=password],input[type=search],input[type=file],input[type=email],select,textarea{
  border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:14px;
  background:var(--panel);color:var(--text);max-width:100%}
input[type=text],input[type=password],select.wide,textarea{width:420px}
input:focus,select:focus,textarea:focus{outline:2px solid var(--accent2);border-color:var(--accent)}
.form-actions{margin-top:14px;display:flex;gap:8px;flex-wrap:wrap}
.searchbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
.searchbar input[type=search]{width:280px}
.note{border-radius:10px;padding:10px 14px;margin-bottom:12px;border:1px solid var(--border);font-size:14px}
.note.ok{background:var(--tag-add);color:var(--text)}
.note.bad{background:var(--tag-rm);color:var(--text);border-left:4px solid var(--bad)}
.note.info{background:var(--note-info);color:var(--text)}
.note.warn{background:var(--note-warn);color:var(--text)}
.secret{font-family:Consolas,'Courier New',monospace;font-size:22px;font-weight:700;letter-spacing:1px;
  padding:10px 14px;border:1px dashed var(--border2);border-radius:10px;display:inline-block;margin:8px 0;
  background:var(--panel2);user-select:all}
details.tool{margin:6px 0}
details.tool>summary{cursor:pointer;color:var(--link);font-size:14px;display:inline-block}
details.tool[open]{background:var(--panel2);border-radius:10px;padding:8px 12px}
.later{color:var(--muted);font-size:13px;border:1px dashed var(--border2);border-radius:10px;padding:8px 12px;margin-top:10px}
.authwrap{margin:8vh auto;max-width:440px;width:100%;padding:0 16px}
.authwrap .logo{text-align:center;padding-bottom:18px}
.authwrap .panel{padding:22px 24px}
.authwrap input[type=text],.authwrap input[type=password]{width:100%}
.pager{display:flex;gap:8px;margin-top:10px}
/* 자동 비교 근거 표 (F3) — 이전 값은 취소선, 새 값은 강조, 바뀐 낱말은 색 */
.tag.k-add{background:var(--tag-add);color:var(--ok-strong)}
.tag.k-mod{background:var(--tag-mod);color:var(--warn3)}
.tag.k-rm{background:var(--tag-rm);color:var(--bad)}
.tag.k-info{background:var(--hover);color:var(--muted)}
.cmp-head{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:baseline;margin:0 0 10px;font-size:14px}
.cmp-head b{font-size:16px}
table.cmp td{font-size:14px;word-break:break-word}
table.cmp td.name{min-width:110px}
table.cmp td.val{min-width:140px;max-width:420px}
del.old{text-decoration:line-through;color:var(--muted)}
del.old .hl{background:var(--tag-rm);color:var(--bad);border-radius:3px}
ins.new{text-decoration:none;font-weight:700;color:var(--text)}
ins.new mark{background:var(--tag-add);color:var(--ok-strong);border-radius:3px;padding:0 1px}
.none{color:var(--muted2)}
ul.notes{margin:8px 0 0 18px;color:var(--muted2);font-size:13px}
ul.lines{margin:4px 0 0 18px;font-size:14px}
.kv{display:grid;grid-template-columns:120px minmax(0,1fr);gap:6px 12px;font-size:14px;margin-bottom:6px}
.kv dt{color:var(--muted)} .kv dd{margin:0;word-break:break-word}
.cols{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 8px}
.cols span{border:1px solid var(--border);border-radius:6px;padding:2px 8px;font-size:13px;background:var(--panel2)}
.decide{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}
.decide textarea{width:100%;min-height:64px}
.pick{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
/* 메일 알림·구독 (F4) */
input[type=email]{width:240px}
.sub{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0 10px;font-size:13px;color:var(--muted)}
@media (max-width:860px){
  body{display:block}
  .side{position:static;width:auto;border-right:none;border-bottom:1px solid var(--border)}
  .main{margin-left:0;padding:16px}
  .split{grid-template-columns:minmax(0,1fr)}
  input[type=text],input[type=password],select.wide,textarea{width:100%}
}
"""


def _fmt_time(value) -> str:
    """'2026-10-28T14:03:22' → '2026-10-28 14:03'."""
    s = str(value or "")
    return " ".join(s.split("T", 1))[:16] if s else ""     # str.replace는 test_readonly 이름 검사에 걸린다


def _fmt_size(n) -> str:
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f}KB"
    return f"{n / (1024 * 1024):.1f}MB"


def _flatten(tree, depth: int = 0, prefix: tuple = ()):
    """폴더 트리 → (폴더, 깊이, '맨위 / 하위' 경로) 차례."""
    for node in tree:
        path = prefix + (node["name"],)
        yield node, depth, " / ".join(path)
        yield from _flatten(node["children"], depth + 1, path)


def content_disposition(filename: str) -> str:
    """내려받기 이름 — 한글은 filename*=UTF-8''…, 옛 브라우저용 ASCII 대체 이름도 함께."""
    fallback = "".join(c if 32 <= ord(c) < 127 and c not in '"\\;%' else "_" for c in filename) or "download"
    return f"attachment; filename=\"{fallback}\"; filename*=UTF-8''{quote(filename, safe='')}"


def _safe_back(to: str) -> str:
    """돌아갈 곳은 이 서버 안의 경로만 — 다른 사이트로 보내지 않는다 (web._safe_back 과 같은 규칙)."""
    to = "".join(ch for ch in (to or "") if ch >= " " and ch != "\x7f").strip()
    if not to.startswith("/") or to.startswith("//") or to.startswith("/\\"):
        return "/forms"
    return to


def _is_loopback(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(str(ip).split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped is not None:
        a = a.ipv4_mapped
    return a.is_loopback


def _is_internet(ip: str) -> bool:
    """공인(인터넷) 주소인가 — 사내망 전용 서버라 그런 곳에서 온 요청은 받지 않는다 (원칙 1)."""
    try:
        a = ipaddress.ip_address(str(ip).split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped is not None:
        a = a.ipv4_mapped
    return a.is_global


def check_bind_host(host: str) -> str:
    """바인드 주소 검사 — IP 글자(또는 localhost)만, 공인 주소는 거부한다 (사내망 전용, 공유기 포트 개방 금지)."""
    h = str(host or "").strip()
    if h.lower() == "localhost":
        return "127.0.0.1"
    try:
        a = ipaddress.ip_address(h)
    except ValueError:
        raise FormsError("양식함 주소는 사내망 IP로 적어 주세요 (예: 192.168.0.10, 모두: 0.0.0.0)")
    if a.is_global:
        raise FormsError("인터넷(공인) 주소에는 양식함을 열 수 없습니다 — 사내망 주소를 적어 주세요")
    return h


# ── 올리기 본문(multipart/form-data) — cgi 모듈 없이 직접 읽는다 ───────────────────────

_BOUNDARY_RE = re.compile(r"^[0-9A-Za-z'()+_,\-./:=? ]{1,70}$")


def _header_params(value: str) -> tuple[str, dict]:
    """'form-data; name="a"; filename="b.xlsx"' → ('form-data', {'name': 'a', 'filename': 'b.xlsx'}).

    브라우저(HTML 표준)는 따옴표 안의 '"'·줄바꿈을 %22·%0A로 바꿔 보내고 역슬래시는 그대로 둔다 —
    그래서 따옴표 안은 다음 따옴표까지 글자 그대로 읽는다(옛 IE의 'C:\\a\\b.xlsx'도 그대로)."""
    s, i, n = value, 0, len(value)
    j = s.find(";")
    main = (s if j < 0 else s[:j]).strip().lower()
    i = n if j < 0 else j + 1
    params: dict = {}
    while i < n:
        while i < n and s[i] in " \t;":
            i += 1
        if i >= n:
            break
        eq = s.find("=", i)
        if eq < 0:
            raise MultipartError("머리글 값이 깨졌습니다")
        key = s[i:eq].strip().lower()
        i = eq + 1
        while i < n and s[i] in " \t":
            i += 1
        if i < n and s[i] == '"':
            end = s.find('"', i + 1)
            if end < 0:
                raise MultipartError("따옴표가 닫히지 않았습니다")
            val, i = s[i + 1:end], end + 1
        else:
            end = s.find(";", i)
            end = n if end < 0 else end
            val, i = s[i:end].strip(), end
        if not key or key in params:
            raise MultipartError("머리글 값이 겹치거나 비었습니다")
        params[key] = val
    return main, params


def _rfc5987(value: str) -> str:
    """filename*=UTF-8''%EC%9E%94… 풀기."""
    from urllib.parse import unquote
    charset, _, rest = value.partition("'")
    _lang, _, enc = rest.partition("'")
    if charset.strip().lower() not in ("utf-8", "utf8") or not _:
        raise MultipartError("파일 이름 인코딩을 모릅니다")
    return unquote(enc, encoding="utf-8", errors="strict")


def boundary_of(content_type: str) -> bytes:
    main, params = _header_params(str(content_type or ""))
    if main != "multipart/form-data":
        raise MultipartError("올리기 형식(multipart/form-data)이 아닙니다")
    b = params.get("boundary", "")
    if not _BOUNDARY_RE.match(b) or b.endswith(" "):
        raise MultipartError("경계 표시(boundary)가 잘못됐습니다")
    return b.encode("ascii")


def parse_multipart(body: bytes, boundary: bytes, *, max_parts: int = 20,
                    max_field: int = MAX_FORM_BODY) -> tuple[dict, dict]:
    """multipart/form-data 본문 → (글자 칸 {이름: [값…]}, 파일 칸 {이름: (파일 이름, 바이트)}).

    깨진 본문은 MultipartError(→ 400). 끝 표시(--경계--)가 없으면 덜 온 것으로 본다."""
    delim = b"--" + boundary
    data = b"\r\n" + bytes(body)
    sep = b"\r\n" + delim
    pieces = data.split(sep)
    if len(pieces) < 2:
        raise MultipartError("경계 표시가 본문에 없습니다")
    fields: dict = {}
    files: dict = {}
    closed = False
    for count, piece in enumerate(pieces[1:], start=1):
        if piece.startswith(b"--"):
            closed = True
            break
        if count > max_parts:
            raise MultipartError("칸이 너무 많습니다")
        piece = piece.lstrip(b" \t")
        if not piece.startswith(b"\r\n"):
            raise MultipartError("경계 뒤 줄바꿈이 없습니다")
        head, mark, content = piece[2:].partition(b"\r\n\r\n")
        if not mark:
            raise MultipartError("칸 머리글이 끝나지 않았습니다")
        if len(head) > 8192:
            raise MultipartError("칸 머리글이 너무 깁니다")
        try:
            head_text = head.decode("utf-8")
        except UnicodeDecodeError:
            raise MultipartError("칸 머리글 글자가 깨졌습니다")
        disp = None
        for line in head_text.split("\r\n"):
            name, colon, value = line.partition(":")
            if not colon:
                raise MultipartError("칸 머리글 줄이 깨졌습니다")
            if name.strip().lower() == "content-disposition":
                if disp is not None:
                    raise MultipartError("칸 머리글이 겹칩니다")
                disp = value.strip()
        if disp is None:
            raise MultipartError("칸 이름(Content-Disposition)이 없습니다")
        kind, params = _header_params(disp)
        if kind != "form-data" or not params.get("name"):
            raise MultipartError("칸 이름이 없습니다")
        fname = params["name"]
        if "filename*" in params:
            filename = _rfc5987(params["filename*"])
        else:
            filename = params.get("filename")
        if filename is not None:
            if fname in files:
                raise MultipartError("파일 칸이 겹칩니다")
            files[fname] = (filename, content)
        else:
            if len(content) > max_field:
                raise MultipartError("글자 칸이 너무 깁니다")
            try:
                fields.setdefault(fname, []).append(content.decode("utf-8"))
            except UnicodeDecodeError:
                raise MultipartError("글자 칸이 깨졌습니다")
    if not closed:
        raise MultipartError("본문 끝 표시가 없습니다 — 덜 왔거나 깨졌습니다")
    return fields, files


# ── 단일 실행 잠금 (파일을 쓰지 않는 Windows 이름 있는 뮤텍스) ─────────────────────────

class InstanceLock:
    """같은 데이터 폴더로 서버가 두 번 뜨지 않게 — 커널 뮤텍스라 프로세스가 죽으면 저절로 풀린다."""

    def __init__(self, data_dir):
        key = os.path.normcase(os.path.abspath(str(data_dir)))
        self.name = "Local\\DrevForms-" + hashlib.sha256(key.encode("utf-8")).hexdigest()[:24]
        self._handle = None

    def acquire(self) -> bool:
        if os.name != "nt":           # Drev는 Windows 전용 — 다른 곳에서는 포트 독점에 맡긴다
            return True
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
        k32.CreateMutexW.restype = wintypes.HANDLE
        k32.CloseHandle.argtypes = (wintypes.HANDLE,)
        h = k32.CreateMutexW(None, False, self.name)
        err = ctypes.get_last_error()
        if not h:
            raise OSError(err, "단일 실행 잠금을 만들 수 없습니다")
        if err == 183:                # ERROR_ALREADY_EXISTS
            k32.CloseHandle(h)
            return False
        self._handle = h
        return True

    def release(self) -> None:
        if self._handle:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.CloseHandle.argtypes = (wintypes.HANDLE,)
            k32.CloseHandle(self._handle)
            self._handle = None


# ── 서버 ────────────────────────────────────────────────────────────────────

class RateLimiter:
    """주소(IP)별 토큰 버킷 — 메모리만 쓴다(DB에 아무것도 적지 않는다). 2026-10-28 보안 F1.

    capacity번까지는 한꺼번에 받고, 그 뒤로는 초당 per_second번씩 다시 채워진다. 열쇠(주소)가 너무 많으면
    가득 찬(=한동안 조용한) 것부터 버려 메모리도 끝없이 늘지 않는다. clock: 시험에서 바꿔 끼운다."""

    def __init__(self, capacity: int = RATE_CAPACITY, per_second: float = RATE_PER_SECOND, *, clock=time.monotonic,
                 max_keys: int = 10000):
        self.capacity = float(max(1, int(capacity)))
        self.per_second = max(0.001, float(per_second))
        self.clock = clock
        self.max_keys = int(max_keys)
        self._b: dict = {}
        self._lock = threading.Lock()

    def take(self, key: str) -> float:
        """한 번 쓰기. 받으면 0, 넘쳤으면 다음 한 번까지 기다릴 초."""
        now = float(self.clock())
        with self._lock:
            tokens, at = self._b.get(key, (self.capacity, now))
            tokens = min(self.capacity, tokens + max(0.0, now - at) * self.per_second)
            if tokens >= 1.0:
                self._b[key] = (tokens - 1.0, now)
                if len(self._b) > self.max_keys:
                    self._prune(now)
                return 0.0
            self._b[key] = (tokens, now)
            return (1.0 - tokens) / self.per_second

    def _prune(self, now: float) -> None:
        full = [k for k, (t, at) in self._b.items()
                if t + max(0.0, now - at) * self.per_second >= self.capacity]
        for k in full:
            self._b.pop(k, None)
        if len(self._b) > self.max_keys:                 # 그래도 많으면 가장 오래 조용한 것부터
            for k, _ in sorted(self._b.items(), key=lambda kv: kv[1][1])[:len(self._b) - self.max_keys]:
                self._b.pop(k, None)

    def prune(self) -> None:
        with self._lock:
            self._prune(float(self.clock()))


class FormsHTTPServer(ThreadingHTTPServer):
    """요청마다 스레드. 저장소(FormsStore) 하나를 스레드끼리 같이 쓴다(F1이 잠금으로 보장).

    - 포트 독점(SO_EXCLUSIVEADDRUSE): 윈도우는 SO_REUSEADDR이면 두 프로세스가 같은 포트를 나눠 잡는다(web.py 2026-08-31).
    - 동시 연결 상한: 넘치면 바로 503으로 끊는다.
    - 느린 요청 끊기: 감시 스레드가 마감이 지난 연결을 shutdown 한다(헤더를 한 글자씩 보내며 버티기 방지)."""

    daemon_threads = True
    block_on_close = False
    allow_reuse_address = False
    request_queue_size = 32

    def __init__(self, address, handler, store: FormsStore, *, max_connections: int = MAX_CONNECTIONS):
        self.store = store
        self.comparer: Comparer | None = None        # 자동 비교기 (F3) — make_server가 붙인다
        self.mirror: Mirror | None = None            # 현행 미러 (F4, 설정했을 때만)
        self.notifier: Notifier | None = None        # 메일 알림 (F4, 켰을 때만)
        self.header_seconds = HEADER_SECONDS
        self.body_min_rate = BODY_MIN_RATE
        self._slots = threading.BoundedSemaphore(max_connections)
        self._conns: dict = {}
        self._conns_lock = threading.Lock()
        self._flash: dict = {}
        self._flash_lock = threading.Lock()
        self._stop = threading.Event()
        self.limiter = RateLimiter(clock=store.clock)     # 비인증 POST(로그인·첫 관리자) 주소별 상한 (보안 F1)
        self.pending_keep_days = float(PENDING_KEEP_DAYS)  # 반려·취소 대기 파일 보존 기간 (보안 F7)
        self._maint: threading.Thread | None = None
        super().__init__(address, handler)
        self._reaper = threading.Thread(target=self._reap, name="forms-reaper", daemon=True)
        self._reaper.start()

    # 정리 일 (2026-10-28 보안 F1·F7) — 대기 파일 보존 기간 지난 것, 지난 로그인 실패 행, 버킷 메모리
    def maintain(self) -> dict:
        out = {"purged": [], "failures": 0}
        try:
            out["purged"] = self.store.purge_pending(days=self.pending_keep_days)
        except Exception:
            log.exception("양식함: 대기 파일 정리 실패")
        try:
            out["failures"] = auth.cleanup_failures(self.store)
        except Exception:
            log.exception("양식함: 로그인 실패 기록 정리 실패")
        self.limiter.prune()
        return out

    def start_maintenance(self, interval: float = MAINT_SECONDS) -> None:
        if self._maint is not None:
            return

        def loop():
            while True:
                self.maintain()
                if self._stop.wait(float(interval)):
                    return
        self._maint = threading.Thread(target=loop, name="forms-maint", daemon=True)
        self._maint.start()

    def server_bind(self) -> None:
        if os.name == "nt":
            try:
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            except (OSError, AttributeError):
                pass
        super().server_bind()

    # 연결 상한
    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            try:
                request.sendall(_BUSY)
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    # 느린 요청 끊기
    def watch(self, key, sock, seconds: float) -> None:
        with self._conns_lock:
            self._conns[key] = (sock, time.monotonic() + seconds)

    def unwatch(self, key) -> None:
        with self._conns_lock:
            self._conns.pop(key, None)

    def _reap(self) -> None:
        while not self._stop.wait(0.25):
            now = time.monotonic()
            with self._conns_lock:
                late = [(k, s) for k, (s, dl) in self._conns.items() if dl < now]
                for k, _ in late:
                    self._conns.pop(k, None)
            for _, s in late:
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

    # 한 번 보이는 알림 (로그인 세션별)
    def flash_set(self, token: str, kind: str, msg: str) -> None:
        with self._flash_lock:
            if len(self._flash) > 2000:
                self._flash.clear()
            self._flash[hashlib.sha256(token.encode()).hexdigest()] = (kind, msg)

    def flash_pop(self, token: str):
        with self._flash_lock:
            return self._flash.pop(hashlib.sha256(token.encode()).hexdigest(), None)

    def handle_error(self, request, client_address) -> None:
        exc = sys.exception()
        if isinstance(exc, (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        log.exception("양식함 서버: 요청 처리 중 오류 (%s)", client_address[0] if client_address else "")

    def on_event(self, kind: str, **kw) -> None:
        """승인·반려·폐기·복원·폴더 이름 바꾸기 뒤의 뒷일 — 현행 미러 다시 맞추기, 메일 알림 (F4).
        여기서 무엇이 실패해도 화면 동작(이미 끝난 승인 등)은 그대로다. 실제 쓰기·보내기는 배경 스레드가 한다."""
        try:
            if self.mirror is not None and kind in ("approved", "retired", "restored", "folder_renamed"):
                self.mirror.request_sync()
        except Exception:
            log.exception("양식함: 현행 미러 요청 실패 (%s)", kind)
        n = self.notifier
        if n is None:
            return
        try:
            if kind == "approved":
                sid = kw["submission_id"]
                n.approved(sid)
                d = self.store.submission_notice(sid) or {}
                n.new_current(kw["result"]["version_id"], skip=(d.get("submitter_email"),))
            elif kind == "rejected":
                n.rejected(kw["submission_id"])
        except Exception:
            log.exception("양식함: 메일 알림 준비 실패 (%s)", kind)

    def server_close(self) -> None:
        self._stop.set()
        super().server_close()
        if self._maint is not None and self._maint is not threading.current_thread():
            self._maint.join(10)                       # 정리 일이 저장소를 쓰는 도중에 닫지 않게
        for part in (self.mirror, self.notifier):        # 배경 스레드(미러·메일)를 저장소보다 먼저 멈춘다
            if part is not None:
                try:
                    part.close()
                except Exception:
                    pass
        if self.comparer is not None:
            try:
                self.comparer.close()                # 비교 자식 프로세스를 끝낸다
            except Exception:
                pass
        try:
            self.store.close()
        except Exception:
            pass


def make_server(data_dir, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, mirror_root=None,
                max_upload_bytes: int | None = None, clock=None,
                max_connections: int = MAX_CONNECTIONS, compare_timeout: float = COMPARE_TIMEOUT,
                compare_command: list | None = None, notify_mail: dict | None = None,
                base_url: str = "", notify_send=None, audit_max_rows: int | None = None,
                pending_keep_days: float | None = None, rate_capacity: int = RATE_CAPACITY,
                rate_per_second: float = RATE_PER_SECOND, maintenance: bool = True) -> FormsHTTPServer:
    """양식함 서버를 만든다(아직 돌리지 않음). serve_forever()로 돌린다.

    host: 사내망 주소(공인 주소는 거부). 시험은 127.0.0.1 포트 0.
    max_upload_bytes: 올리기 상한(기본 50MB). clock: 시험용 시계(세션·잠금).
    compare_timeout: 자동 비교 한 번의 상한(초, 기본 60). compare_command: 비교 자식 명령(시험용).
    mirror_root: (F4) 현행 미러 폴더 — 주면 배경 스레드가 곧바로 전체를 맞춘다. 폴더가 지금 없어도(공유가 끊김)
      서버는 뜨고, 미러만 실패를 감사 기록에 남긴 뒤 나중에 다시 맞춘다.
    notify_mail: (F4) 메일 알림을 켤 때 감시의 `mail:` 설정(사내 SMTP). base_url: 메일의 '양식함에서 열기' 주소.
    notify_send: 시험용 보내기 함수.
    audit_max_rows: 감사 기록 보존 상한(행, 기본 20만). pending_keep_days: 반려·취소 대기 파일 보존(일, 기본 90).
    rate_capacity·rate_per_second: 비인증 POST(로그인·첫 관리자) 주소별 토큰 버킷. maintenance: 정리 일 스레드(기본 켬)."""
    h = check_bind_host(host)
    kw = {}
    if clock is not None:
        kw["clock"] = clock
    store = FormsStore(data_dir, **kw)
    if max_upload_bytes:
        store.max_upload_bytes = int(max_upload_bytes)
    if audit_max_rows:
        store.audit_max_rows = int(audit_max_rows)
    try:
        srv = FormsHTTPServer((h, int(port)), FormsHandler, store, max_connections=max_connections)
    except BaseException:
        store.close()
        raise
    srv.limiter = RateLimiter(rate_capacity, rate_per_second, clock=store.clock)
    if pending_keep_days is not None:
        srv.pending_keep_days = float(pending_keep_days)
    if maintenance:
        srv.start_maintenance()
    srv.comparer = Comparer(store, timeout=compare_timeout, command=compare_command)
    if notify_mail is not None:
        srv.notifier = Notifier(store, notify_mail, base_url=base_url, send=notify_send)
    if mirror_root:
        srv.mirror = Mirror(store, mirror_root)
        srv.mirror.start()                       # 서버 시작 때 전체 재동기화 (지난 실패를 따라잡는다)
    return srv


def serve(data_dir, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, mirror_root=None,
          max_upload_bytes: int | None = None, on_ready=None, compare_timeout: float = COMPARE_TIMEOUT,
          notify_mail: dict | None = None, base_url: str = "", audit_max_rows: int | None = None,
          pending_keep_days: float | None = None) -> None:
    """단일 실행 잠금을 잡고 서버를 돌린다(멈출 때까지). 이미 돌고 있으면 AlreadyRunning.

    on_ready(server): 바인드 직후 한 번 부른다(주소 알림·시험에서 멈추기용)."""
    lock = InstanceLock(data_dir)
    if not lock.acquire():
        raise AlreadyRunning("양식함이 이미 실행 중입니다")
    try:
        srv = make_server(data_dir, host, port, mirror_root=mirror_root, max_upload_bytes=max_upload_bytes,
                          compare_timeout=compare_timeout, notify_mail=notify_mail, base_url=base_url,
                          audit_max_rows=audit_max_rows, pending_keep_days=pending_keep_days)
        try:
            if on_ready is not None:
                on_ready(srv)
            srv.serve_forever(poll_interval=0.5)
        finally:
            srv.server_close()
    finally:
        lock.release()


# ── 요청 처리 ────────────────────────────────────────────────────────────────

class FormsHandler(BaseHTTPRequestHandler):
    server: FormsHTTPServer
    server_version = "Drev-Forms"
    sys_version = ""
    protocol_version = "HTTP/1.0"     # 요청 하나에 연결 하나 — 마감·상한 관리가 단순하다
    timeout = SOCKET_TIMEOUT

    # ── 연결 수명 ───────────────────────────────────────────────────────
    def setup(self) -> None:
        super().setup()
        self._cookies_out: list = []
        self.sess = None
        self._pre = None
        self.server.watch(id(self), self.connection, self.server.header_seconds)

    def finish(self) -> None:
        self.server.unwatch(id(self))
        try:
            super().finish()
        except OSError:
            pass

    def _deadline(self, nbytes: int = 0) -> None:
        """본문 읽기·응답 보내기 마감 — 30초 + 최소 속도로 나눈 시간."""
        self.server.watch(id(self), self.connection, 30.0 + nbytes / max(1, self.server.body_min_rate))

    def _allow_compare(self) -> None:
        """자동 비교를 기다리는 동안 느린 요청 끊기에 걸리지 않게 마감을 늘린다 — 자리 기다림 + 비교 상한 + 여유 30초."""
        c = self.server.comparer
        t = c.timeout if c is not None else COMPARE_TIMEOUT
        self.server.watch(id(self), self.connection, 2 * t + 30.0)

    def handle_one_request(self) -> None:
        """표준 처리와 같되 요청 줄·헤더 크기 상한을 좁혔다 (8KB·32KB·60개)."""
        try:
            self.raw_requestline = self.rfile.readline(MAX_REQUEST_LINE + 1)
            if len(self.raw_requestline) > MAX_REQUEST_LINE:
                self.requestline, self.request_version, self.command = "", "", ""
                self.send_error(HTTPStatus.REQUEST_URI_TOO_LONG)
                return
            if not self.raw_requestline:
                self.close_connection = True
                return
            if not self.parse_request():
                return
            if len(self.headers) > MAX_HEADERS or \
                    sum(len(k) + len(v) + 4 for k, v in self.headers.items()) > MAX_HEADER_BYTES:
                self.send_error(HTTPStatus.REQUEST_HEADER_FIELDS_TOO_LARGE)
                return
            self._deadline()
            mname = "do_" + self.command
            if not hasattr(self, mname):
                self.send_error(HTTPStatus.NOT_IMPLEMENTED)
                return
            getattr(self, mname)()
            self.wfile.flush()
        except TimeoutError:
            self.close_connection = True
        except (ConnectionError, OSError) as e:      # 감시 스레드가 끊었거나 상대가 나갔다
            log.debug("연결 끊김: %s", e)
            self.close_connection = True

    def log_message(self, fmt, *args) -> None:       # 콘솔 소음 대신 로그(디버그)로
        log.debug("%s %s", self.client_address[0] if self.client_address else "-", fmt % args)

    # ── 응답 ────────────────────────────────────────────────────────────
    def _out(self, data: bytes) -> None:
        """소켓으로 보내기 — 이 모듈에서 write를 부르는 유일한 곳 (파일 쓰기 아님, test_readonly)."""
        self.wfile.write(data)

    def end_headers(self) -> None:
        for k, v in SECURITY_HEADERS:
            self.send_header(k, v)
        for c in self._cookies_out:
            self.send_header("Set-Cookie", c)
        self._cookies_out = []
        super().end_headers()

    def _cookie(self, name: str, value: str, *, max_age: int | None = None) -> None:
        c = f"{name}={value}; Path=/; HttpOnly; SameSite=Strict"
        if max_age is not None:
            c += f"; Max-Age={int(max_age)}"
        self._cookies_out.append(c)

    def _send(self, status: int, body, ctype: str = "text/html; charset=utf-8", extra=()) -> None:
        data = body.encode("utf-8") if isinstance(body, str) else bytes(body)
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self._out(data)

    def _redirect(self, location: str, status: int = 303) -> None:
        self.send_response(status)
        self.send_header("Location", _safe_back(location))
        self.send_header("Content-Length", "0")
        self.end_headers()

    def send_error(self, code, message=None, explain=None) -> None:
        """표준 오류 화면 대신 한국어 쉬운 말 — 내부 설명(explain)은 화면에 내지 않는다."""
        code = int(code)
        self.close_connection = True
        if not hasattr(self, "_cookies_out"):
            self._cookies_out = []
        try:
            phrase = HTTPStatus(code).phrase
        except ValueError:
            phrase = "Error"
        body = _auth_page("오류", f'<div class="note bad">{E(_ERROR_TEXT.get(code, "요청을 처리할 수 없습니다"))}'
                                  f' ({code})</div><p><a href="/forms">양식함으로 가기</a></p>',
                          self._theme_attr_safe()).encode("utf-8")
        self.send_response(code, phrase)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD" and code >= 200 and code not in (204, 304):
            self._out(body)

    # ── 요청 정보 ───────────────────────────────────────────────────────
    def _client_ip(self) -> str:
        ip = str(self.client_address[0]) if self.client_address else ""
        if ip.lower().startswith("::ffff:"):
            ip = ip[7:]
        return ip

    def _cookies_in(self) -> dict:
        try:
            c = SimpleCookie(self.headers.get("Cookie", ""))
        except CookieError:
            return {}
        return {k: m.value for k, m in c.items()}

    def _theme(self) -> str:
        t = self._cookies_in().get(THEME_COOKIE, "") if hasattr(self, "headers") and self.headers else ""
        return t if t in ("light", "dark") else ""

    def _theme_attr_safe(self) -> str:
        try:
            t = self._theme()
        except Exception:
            t = ""
        return f' data-theme="{t}"' if t else ""

    def _query(self) -> dict:
        try:
            return parse_qs(urlsplit(self.path).query, keep_blank_values=True, max_num_fields=40,
                            strict_parsing=False)
        except ValueError:
            raise HttpError(400)

    @staticmethod
    def _one(d: dict, key: str, default: str = "") -> str:
        v = d.get(key)
        return v[0] if v else default

    @staticmethod
    def _int(value, *, required: bool = True):
        s = str(value or "").strip()
        if not s:
            if required:
                raise HttpError(400, "번호가 빠졌습니다")
            return None
        if not s.isdigit() or len(s) > 12:
            raise HttpError(400, "잘못된 번호입니다")
        return int(s)

    def _pre_token(self) -> str:
        """로그인 전 화면의 CSRF 값 — 쿠키와 양식에 같은 값을 둔다(이중 제출). SameSite=Strict라 다른 사이트는 못 보낸다."""
        if self._pre:
            return self._pre
        cur = self._cookies_in().get(PRE_COOKIE, "")
        if re.fullmatch(r"[A-Za-z0-9_\-]{40,64}", cur or ""):
            self._pre = cur
        else:
            self._pre = secrets.token_urlsafe(32)
            self._cookie(PRE_COOKIE, self._pre)
        return self._pre

    def _csrf_value(self) -> str:
        return self.sess.csrf if self.sess is not None else self._pre_token()

    def _check_origin(self) -> None:
        """Origin 머리글이 있으면 같은 주소여야 한다 (SameSite 쿠키에 더한 두 번째 문)."""
        origin = self.headers.get("Origin")
        if origin is None:
            return
        host = self.headers.get("Host", "")
        if origin == "null" or urlsplit(origin).netloc.lower() != host.lower():
            raise HttpError(403, "다른 곳에서 보낸 요청은 받지 않습니다")

    def _check_token(self, fields: dict) -> None:
        supplied = self._one(fields, "csrf")
        if self.sess is not None:
            ok = auth.check_csrf(self.sess, supplied)
        else:
            pre = self._cookies_in().get(PRE_COOKIE, "")
            ok = bool(pre) and bool(supplied) and hmac.compare_digest(pre.encode(), supplied.encode())
        if not ok:
            raise HttpError(403, "확인 값(CSRF)이 맞지 않습니다 — 화면을 새로 열고 다시 해 주세요")

    def _length(self, limit: int) -> int:
        if self.headers.get("Transfer-Encoding"):
            raise HttpError(411)
        raw = self.headers.get("Content-Length")
        if raw is None:
            raise HttpError(411)
        raw = raw.strip()
        if not raw.isdigit() or len(raw) > 15:
            raise HttpError(400, "본문 길이가 잘못됐습니다")
        n = int(raw)
        if n > limit:
            raise HttpError(413, f"보낸 내용이 너무 큽니다 (최대 {limit // (1024 * 1024) or 1}MB)"
                            if limit >= 1024 * 1024 else "보낸 내용이 너무 큽니다")
        return n

    def _read_body(self, n: int) -> bytes:
        self._deadline(n)
        parts, left = [], n
        while left > 0:
            chunk = self.rfile.read(min(left, 256 * 1024))
            if not chunk:
                raise HttpError(400, "본문이 덜 왔습니다")
            parts.append(chunk)
            left -= len(chunk)
        self._deadline()
        return b"".join(parts)

    def _read_form(self) -> dict:
        ctype = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        n = self._length(MAX_FORM_BODY)
        if ctype != "application/x-www-form-urlencoded":
            raise HttpError(415)
        body = self._read_body(n)
        try:
            text = body.decode("utf-8")
            return parse_qs(text, keep_blank_values=True, max_num_fields=500)
        except (UnicodeDecodeError, ValueError):
            raise HttpError(400)

    # ── 진입 ────────────────────────────────────────────────────────────
    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def _dispatch(self, method: str) -> None:
        try:
            self.ip = self._client_ip()
            if _is_internet(self.ip):
                raise HttpError(403, "양식함은 사내망에서만 열립니다")
            path = urlsplit(self.path).path or "/"
            if path == "/forms.css" and method == "GET":
                self._send(200, CSS, "text/css; charset=utf-8")
                return
            routes = _GET if method == "GET" else _POST
            entry = routes.get(path)
            if entry is None:
                other = _POST if method == "GET" else _GET
                raise HttpError(405 if path in other else 404)
            fn, public = entry
            store = self.server.store
            token = self._cookies_in().get(SESSION_COOKIE, "")
            self.sess = auth.get_session(store, token) if token else None
            if not public:
                if self.sess is None:
                    self.close_connection = True       # 본문을 읽지 않고 끊는다
                    self._redirect("/login")
                    return
                if self.sess.must_change and path not in _MUST_CHANGE_OK:
                    if method == "POST":
                        raise HttpError(403, "먼저 비밀번호를 바꿔 주세요")
                    self._redirect("/password")
                    return
            if method == "POST":
                self._check_origin()
            fn(self)
        except HttpError as e:
            self._fail(e.status, e.message)
        except auth.LoginLocked as e:
            self._fail(429, auth.locked_text(e.seconds, e.kind))
        except (PermissionDenied,) as e:
            self._fail(403, str(e))
        except NotFound as e:
            self._fail(404, str(e))
        except Conflict as e:
            self._fail(409, str(e))
        except (InvalidInput, auth.LoginFailed, FormsError) as e:
            self._fail(400, str(e))
        except (ConnectionError, TimeoutError):
            self.close_connection = True
        except Exception:
            log.exception("양식함 화면 오류: %s %s", method, urlsplit(self.path).path)
            self._fail(500, "문제가 생겼습니다 — 잠시 뒤 다시 해 보고, 계속되면 관리자에게 알려 주세요")

    def _fail(self, status: int, message: str) -> None:
        self.close_connection = True
        body = f'<div class="note bad" role="alert">{E(message)}</div>' \
               f'<p><a class="btn gray" href="/forms">양식함으로</a></p>'
        try:
            if self.sess is not None and not self.sess.must_change:
                page = self._shell("할 수 없습니다", body, active="")
            else:
                page = _auth_page("할 수 없습니다", body, self._theme_attr_safe())
        except Exception:
            log.exception("오류 화면을 그리다 또 오류")
            page = _auth_page("오류", f'<div class="note bad">{E(message)}</div>', "")
        try:
            self._send(status, page)
        except OSError:
            pass

    # ── 화면 틀 ─────────────────────────────────────────────────────────
    def _shell(self, title: str, body: str, *, active: str, actions: str = "") -> str:
        s = self.sess
        store = self.server.store
        flash = self.server.flash_pop(s.token) if s else None
        note = ""
        if flash:
            kind, msg = flash
            note = f'<div class="note {E(kind)}" role="status">{E(msg)}</div>'
        mine = sum(1 for x in store.list_submissions(s.user_id, scope="mine", status="pending"))
        items = [("/forms", "양식함", 0), ("/upload", "양식 올리기", 0), ("/mine", "내 제출", mine)]
        if s.role in ("reviewer", "admin"):
            review = len(store.list_submissions(s.user_id, scope="review", status="pending"))
            items.append(("/review", "검토 대기", review))

        def link(href, label, cnt):
            on = ' class="on" aria-current="page"' if href == active else ""
            badge = f'<span class="cnt">{cnt}</span>' if cnt else ""
            return f'<a href="{href}"{on}><span>{E(label)}</span>{badge}</a>'

        nav = '<div class="grp">양식</div>' + "".join(link(*i) for i in items)
        if s.role == "admin":
            nav += '<div class="grp">관리</div>' + "".join(link(*i) for i in (
                ("/admin/users", "계정", 0), ("/admin/folders", "폴더 검토자", 0), ("/admin/audit", "감사 기록", 0)))
        csrf = E(s.csrf)
        theme = self._theme()
        nxt = {"": "dark", "dark": "light", "light": ""}[theme]
        theme_label = {"": "OS 따라감", "dark": "어둡게", "light": "밝게"}[theme]
        nxt_label = {"": "OS 따라감", "dark": "어둡게", "light": "밝게"}[nxt]
        back = E(_safe_back(self.path))
        me = (f'<div class="me"><b>{E(s.display_name)}</b>{E(s.login)} · {E(ROLE_LABEL.get(s.role, s.role))}'
              f'<a href="/password">비밀번호 바꾸기</a>'
              f'<form method="post" action="/theme"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="theme" value="{nxt}"><input type="hidden" name="back" value="{back}">'
              f'<button class="btn gray sm" type="submit" title="누르면 {nxt_label}(으)로 바꿉니다">테마: {theme_label}'
              f'</button></form>'
              f'<form method="post" action="/logout"><input type="hidden" name="csrf" value="{csrf}">'
              f'<button class="btn gray sm" type="submit">로그아웃</button></form></div>')
        return (f'<!DOCTYPE html><html lang="ko"{self._theme_attr_safe()}><head><meta charset="utf-8">'
                f'<meta name="viewport" content="width=device-width, initial-scale=1">'
                f'<title>{E(title)} — Drev 양식함</title><link rel="stylesheet" href="/forms.css"></head><body>'
                f'<a class="skip" href="#main">본문으로 건너뛰기</a>'
                f'<nav class="side" aria-label="메뉴"><div class="logo">Drev 양식함<small>사내망 전용</small></div>'
                f'<div class="nav">{nav}</div>{me}</nav>'
                f'<main class="main" id="main"><div class="topbar"><h1>{E(title)}</h1>{actions}</div>'
                f'{note}{body}</main></body></html>')

    def _flash(self, kind: str, msg: str) -> None:
        if self.sess is not None:
            self.server.flash_set(self.sess.token, kind, msg)

    def _folders(self):
        return list(_flatten(self.server.store.folder_tree(self.sess.user_id)))


def _auth_page(title: str, body: str, theme_attr: str = "") -> str:
    """로그인 전 화면 틀 (메뉴 없음)."""
    return (f'<!DOCTYPE html><html lang="ko"{theme_attr}><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{E(title)} — Drev 양식함</title><link rel="stylesheet" href="/forms.css"></head><body>'
            f'<main class="authwrap" id="main"><div class="logo">Drev 양식함<small>사내망 전용 · 회사 양식 보관</small></div>'
            f'<div class="panel"><h2>{E(title)}</h2>{body}</div></main></body></html>')


# ── 화면별 처리 ─────────────────────────────────────────────────────────────

def _hidden(h: FormsHandler) -> str:
    return f'<input type="hidden" name="csrf" value="{E(h._csrf_value())}">'


def _password_rules() -> str:
    return f'<p class="muted">비밀번호는 {auth.MIN_PASSWORD}자 이상, 아이디와 달라야 합니다.</p>'


def get_root(h: FormsHandler) -> None:
    store = h.server.store
    if not auth.has_admin(store):
        h._redirect("/setup")
    elif h.sess is None:
        h._redirect("/login")
    else:
        h._redirect("/forms")


def _login_form(h: FormsHandler, msg: str = "", login: str = "") -> str:
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'{note}<form method="post" action="/login">{_hidden(h)}'
            f'<label for="lg">아이디</label><input type="text" id="lg" name="login" value="{E(login)}" '
            f'autocomplete="username" required maxlength="64" autofocus>'
            f'<label for="pw">비밀번호</label><input type="password" id="pw" name="password" '
            f'autocomplete="current-password" required maxlength="256">'
            f'<div class="form-actions"><button class="btn" type="submit">로그인</button></div></form>'
            f'<p class="muted">계정은 관리자가 등록해 줍니다. 비밀번호를 잊었으면 관리자에게 초기화를 부탁하세요.</p>')


def get_login(h: FormsHandler) -> None:
    store = h.server.store
    if not auth.has_admin(store):
        h._redirect("/setup")
        return
    if h.sess is not None:
        h._redirect("/password" if h.sess.must_change else "/forms")
        return
    h._send(200, _auth_page("로그인", _login_form(h), h._theme_attr_safe()))


def _rate_limited(h: FormsHandler, back: str) -> bool:
    """비인증 POST(로그인·첫 관리자)의 주소별 상한 (2026-10-28 보안 F1). 넘쳤으면 429 쉬운 말 화면을 내고 True.
    본문을 읽기 전에, DB에 아무것도 적기 전에 본다 — 넘친 요청은 감사 기록도 남기지 않는다(메모리만)."""
    wait = h.server.limiter.take(h.ip)
    if wait <= 0:
        return False
    secs = max(1, int(wait + 0.999))
    h.close_connection = True
    body = (f'<div class="note bad" role="alert">요청이 너무 잦습니다 — {secs}초 뒤에 다시 해 주세요.</div>'
            f'<p class="muted">같은 공유기(사내망 주소)를 쓰는 여러 PC가 한꺼번에 로그인하면 잠깐 이렇게 될 수 있습니다.</p>'
            f'<p><a class="btn gray" href="{E(back)}">돌아가기</a></p>')
    h._send(429, _auth_page("잠시 뒤에 다시", body, h._theme_attr_safe()), extra=(("Retry-After", str(secs)),))
    return True


def post_login(h: FormsHandler) -> None:
    store = h.server.store
    if _rate_limited(h, "/login"):
        return
    f = h._read_form()
    h._check_token(f)
    name, pw = h._one(f, "login").strip(), h._one(f, "password")
    try:
        sess = auth.login(store, name, pw, ip=h.ip)
    except auth.LoginLocked as e:
        h._send(429, _auth_page("로그인", _login_form(h, auth.locked_text(e.seconds, e.kind), name),
                                h._theme_attr_safe()), extra=(("Retry-After", str(max(1, e.seconds))),))
        return
    except auth.LoginFailed as e:
        msg = str(e)
        left, kind = auth.wait_seconds(store, name, h.ip)
        if left > 0:
            msg += " — " + auth.locked_text(left, kind)
        h._send(401, _auth_page("로그인", _login_form(h, msg, name), h._theme_attr_safe()))
        return
    h._cookie(SESSION_COOKIE, sess.token)
    h._redirect("/password" if sess.must_change else "/forms")


def post_logout(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    auth.logout(h.server.store, h.sess.token, ip=h.ip)
    h._cookie(SESSION_COOKIE, "", max_age=0)
    h._redirect("/login")


def _password_form(h: FormsHandler, msg: str = "") -> str:
    s = h.sess
    lead = ('<div class="note warn">관리자가 정해 준 임시 비밀번호입니다 — 새 비밀번호로 바꿔야 계속할 수 있습니다.</div>'
            if s.must_change else "")
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'{lead}{note}<form method="post" action="/password">{_hidden(h)}'
            f'<input type="text" name="username" value="{E(s.login)}" autocomplete="username" hidden>'
            f'<label for="old">지금 비밀번호</label><input type="password" id="old" name="old" '
            f'autocomplete="current-password" required maxlength="256">'
            f'<label for="new">새 비밀번호</label><input type="password" id="new" name="new" '
            f'autocomplete="new-password" required maxlength="256">'
            f'<label for="new2">새 비밀번호 한 번 더</label><input type="password" id="new2" name="new2" '
            f'autocomplete="new-password" required maxlength="256">{_password_rules()}'
            f'<div class="form-actions"><button class="btn" type="submit">바꾸기</button></div></form>')


def _password_page(h: FormsHandler, status: int = 200, msg: str = "") -> None:
    if h.sess.must_change:
        csrf = E(h.sess.csrf)
        body = _password_form(h, msg) + (
            f'<form method="post" action="/logout" class="inline">'
            f'<input type="hidden" name="csrf" value="{csrf}"><button class="btn gray sm" type="submit">로그아웃</button></form>')
        h._send(status, _auth_page("비밀번호 바꾸기", body, h._theme_attr_safe()))
    else:
        h._send(status, h._shell("비밀번호 바꾸기", f'<div class="panel">{_password_form(h, msg)}</div>',
                                 active=""))


def get_password(h: FormsHandler) -> None:
    _password_page(h)


def post_password(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    old, new, new2 = h._one(f, "old"), h._one(f, "new"), h._one(f, "new2")
    if new != new2:
        _password_page(h, 400, "새 비밀번호 두 칸이 서로 다릅니다")
        return
    try:
        auth.change_password(h.server.store, h.sess.user_id, old, new, keep_token=h.sess.token, ip=h.ip)
    except (auth.LoginFailed, InvalidInput, Conflict) as e:
        _password_page(h, 400, str(e))
        return
    h._flash("ok", "비밀번호를 바꿨습니다")
    h._redirect("/forms")


def get_setup(h: FormsHandler) -> None:
    store = h.server.store
    if auth.has_admin(store):
        h._redirect("/login")
        return
    if not _is_loopback(h.ip):
        h._send(200, _auth_page("첫 관리자 만들기", (
            '<div class="note warn">아직 관리자가 없습니다. 첫 관리자는 <b>Drev가 설치된 PC</b>에서만 만들 수 있습니다.</div>'
            '<p>Drev PC에서 이 화면을 열어(주소의 IP 자리에 127.0.0.1) 관리자를 만든 뒤, '
            '관리자가 직원 계정을 등록해 주면 이 PC에서도 로그인할 수 있습니다.</p>'), h._theme_attr_safe()))
        return
    h._send(200, _auth_page("첫 관리자 만들기", _setup_form(h), h._theme_attr_safe()))


def _setup_form(h: FormsHandler, msg: str = "", login: str = "", name: str = "") -> str:
    note = f'<div class="note bad" role="alert">{E(msg)}</div>' if msg else ""
    return (f'<p class="muted">양식함을 처음 쓰는 중입니다. 관리자 계정을 하나 만드세요. 직원 계정은 관리자가 등록합니다.</p>'
            f'{note}<form method="post" action="/setup">{_hidden(h)}'
            f'<label for="lg">관리자 아이디</label><input type="text" id="lg" name="login" value="{E(login)}" '
            f'required maxlength="32" autocomplete="username">'
            f'<label for="dn">이름 (화면에 보이는 이름)</label><input type="text" id="dn" name="display_name" '
            f'value="{E(name)}" maxlength="40">'
            f'<label for="pw">비밀번호</label><input type="password" id="pw" name="password" required '
            f'maxlength="256" autocomplete="new-password">'
            f'<label for="pw2">비밀번호 한 번 더</label><input type="password" id="pw2" name="password2" required '
            f'maxlength="256" autocomplete="new-password">{_password_rules()}'
            f'<div class="form-actions"><button class="btn" type="submit">관리자 만들기</button></div></form>')


def post_setup(h: FormsHandler) -> None:
    store = h.server.store
    if _rate_limited(h, "/setup"):
        return
    if not _is_loopback(h.ip):
        raise HttpError(403, "첫 관리자는 Drev가 설치된 PC에서만 만들 수 있습니다")
    f = h._read_form()
    h._check_token(f)
    login, name = h._one(f, "login").strip(), h._one(f, "display_name").strip()
    pw, pw2 = h._one(f, "password"), h._one(f, "password2")
    if pw != pw2:
        h._send(400, _auth_page("첫 관리자 만들기", _setup_form(h, "비밀번호 두 칸이 서로 다릅니다", login, name),
                                h._theme_attr_safe()))
        return
    try:
        auth.create_first_admin(store, login, name or login, pw, is_local=True, ip=h.ip)
    except (InvalidInput, Conflict) as e:
        status = 409 if isinstance(e, Conflict) else 400
        h._send(status, _auth_page("첫 관리자 만들기", _setup_form(h, str(e), login, name), h._theme_attr_safe()))
        return
    sess = auth.login(store, login, pw, ip=h.ip)
    h._cookie(SESSION_COOKIE, sess.token)
    h.server.flash_set(sess.token, "ok", "관리자를 만들었습니다 — 먼저 폴더를 만들고, [계정]에서 직원을 등록하세요")
    h._redirect("/forms")


def post_theme(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    t = h._one(f, "theme")
    if t in ("light", "dark"):
        h._cookie(THEME_COOKIE, t, max_age=365 * 24 * 3600)
    else:
        h._cookie(THEME_COOKIE, "", max_age=0)
    h._redirect(_safe_back(h._one(f, "back", "/forms")))


# ── 양식함 본 화면 ───────────────────────────────────────────────────────────

def _tree_html(nodes, current, path_ids, q: str) -> str:
    if not nodes:
        return ""
    out = ["<ul>"]
    for n in nodes:
        on = ' class="on" aria-current="page"' if n["id"] == current else ""
        out.append(f'<li><a href="/forms?folder={n["id"]}"{on}>{E(n["name"])}</a>'
                   f'{_tree_html(n["children"], current, path_ids, q)}</li>')
    out.append("</ul>")
    return "".join(out)


def get_forms(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    qd = h._query()
    folder_id = h._int(h._one(qd, "folder"), required=False)
    text = h._one(qd, "q").strip()[:100]
    retired = h._one(qd, "retired") == "1"
    tree = store.folder_tree(s.user_id)
    flat = list(_flatten(tree))
    paths = {n["id"]: p for n, _, p in flat}
    crumbs = store.folder_path(s.user_id, folder_id) if folder_id is not None else []
    if text:
        forms = store.search_forms(s.user_id, text, include_retired=retired)
        if folder_id is not None:          # 폴더를 고른 채 찾으면 그 폴더와 하위 폴더 안에서만
            inside = {n["id"] for n, _, p in flat if p == paths[folder_id] or p.startswith(paths[folder_id] + " / ")}
            forms = [x for x in forms if x["folder_id"] in inside]
    else:
        forms = store.list_forms(s.user_id, folder_id, include_retired=retired)
    can_top = s.role == "admin"
    can_here = folder_id is not None and store.is_reviewer_of(s.user_id, folder_id)
    csrf = E(s.csrf)

    side = (f'<div class="panel tree"><h2>폴더</h2>'
            f'<a href="/forms"{" class=\"on\"" if folder_id is None else ""}>전체 양식</a>'
            f'{_tree_html(tree, folder_id, set(), text) or "<p class=\"muted\">아직 폴더가 없습니다</p>"}')
    if can_top:
        side += (f'<details class="tool"><summary>+ 맨 위 폴더 만들기</summary>'
                 f'<form method="post" action="/folders/new"><input type="hidden" name="csrf" value="{csrf}">'
                 f'<label for="nf-top">폴더 이름</label><input type="text" id="nf-top" name="name" required maxlength="80">'
                 f'<div class="form-actions"><button class="btn sm" type="submit">폴더 만들기</button></div></form></details>')
    side += "</div>"

    # 가운데: 경로·도구·검색·목록
    head = ""
    if crumbs:
        trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in crumbs)
        head += f'<div class="crumb"><a href="/forms">전체</a> / {trail}</div>'
    tools = ""
    if can_here:
        cur_name = crumbs[-1]["name"] if crumbs else ""
        tools += (f'<details class="tool"><summary>+ 하위 폴더 만들기</summary>'
                  f'<form method="post" action="/folders/new"><input type="hidden" name="csrf" value="{csrf}">'
                  f'<input type="hidden" name="parent" value="{folder_id}">'
                  f'<label for="nf-sub">폴더 이름</label><input type="text" id="nf-sub" name="name" required maxlength="80">'
                  f'<div class="form-actions"><button class="btn sm" type="submit">폴더 만들기</button></div></form></details>'
                  f'<details class="tool"><summary>폴더 이름 바꾸기</summary>'
                  f'<form method="post" action="/folders/rename"><input type="hidden" name="csrf" value="{csrf}">'
                  f'<input type="hidden" name="folder" value="{folder_id}">'
                  f'<label for="rn">새 이름</label><input type="text" id="rn" name="name" value="{E(cur_name)}" '
                  f'required maxlength="80"><div class="form-actions"><button class="btn sm" type="submit">이름 바꾸기'
                  f'</button></div></form></details>')
    if folder_id is not None and h.server.notifier is not None:
        on = store.is_subscribed(s.user_id, folder_id)
        tools += (f'<form class="sub" method="post" action="/folders/subscribe">'
                  f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="folder" value="{folder_id}">'
                  f'<input type="hidden" name="on" value="{"0" if on else "1"}">'
                  f'<button class="btn gray sm" type="submit">{"메일 알림 끄기" if on else "새 현행 판 메일 받기"}</button>'
                  f'<span>{"이 폴더(하위 포함)에 새 현행 판이 생기면 메일로 알립니다" if on else "이 폴더(하위 포함)에 새 판이 승인되면 메일로 알려 줍니다"}'
                  f'{"" if store.user_email(s.user_id) else " — 내 계정에 메일 주소가 없습니다(관리자가 등록)"}</span></form>')
    subs = []
    if folder_id is not None:
        subs = store.list_folders(s.user_id, folder_id)
    chips = ("<div class=\"chips\">" + "".join(
        f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in subs) + "</div>") if subs else ""
    hidden_folder = f'<input type="hidden" name="folder" value="{folder_id}">' if folder_id is not None else ""
    search = (f'<form class="searchbar" method="get" action="/forms" role="search">{hidden_folder}'
              f'<input type="search" name="q" value="{E(text)}" placeholder="양식 이름·분류·파일 이름" '
              f'aria-label="양식 찾기" maxlength="100">'
              + (f'<input type="hidden" name="retired" value="1">' if retired else "")
              + f'<button class="btn sm" type="submit">찾기</button>'
              + (f'<a class="btn gray sm" href="/forms{"?folder=" + str(folder_id) if folder_id is not None else ""}">'
                 f'지우기</a>' if text else "")
              + "</form>")
    base = "/forms?" + "&".join(x for x in (
        f"folder={folder_id}" if folder_id is not None else "", f"q={quote(text)}" if text else "") if x)
    toggle = (f'<a class="btn gray sm" href="{E(base.rstrip("?&"))}">폐기 양식 숨기기</a>' if retired else
              f'<a class="btn gray sm" href="{E(base + ("&" if base[-1] != "?" else "") + "retired=1")}">'
              f'폐기 양식도 보기</a>')
    show_folder = folder_id is None or bool(text)
    rows = []
    for f in forms:
        tag = ' <span class="tag retired">폐기</span>' if f["retired"] else ""
        cat = f'<div class="muted">{E(f["category"])}</div>' if f["category"] else ""
        ver = f'v{f["current_number"]}' if f["current_number"] else "—"
        rows.append(
            f'<tr><td><a href="/form?id={f["id"]}">{E(f["name"])}</a>{tag}{cat}</td>'
            + (f'<td>{E(paths.get(f["folder_id"], ""))}</td>' if show_folder else "")
            + f'<td class="nw">{ver}</td><td class="nw">{E(_fmt_time(f["current_approved_at"]))}</td>'
            f'<td>{E(f["current_uploaded_by_name"])}</td></tr>')
    table = ("<table><thead><tr><th>양식</th>" + ("<th>폴더</th>" if show_folder else "")
             + "<th>현행 판</th><th>마지막 개정</th><th>올린 사람</th></tr></thead><tbody>"
             + "".join(rows) + "</tbody></table>") if rows else \
        f'<p class="empty">{"찾는 양식이 없습니다" if text else "이 폴더에는 아직 양식이 없습니다"}</p>'
    up = f'/upload?folder={folder_id}' if folder_id is not None else "/upload"
    title = crumbs[-1]["name"] if crumbs else ("찾기 결과" if text else "양식함")
    main = (f'<div class="panel">{head}{tools}{chips}{search}'
            f'<div class="searchbar">{toggle}<span class="muted">{len(forms)}개</span></div>{table}</div>')
    body = f'<div class="split">{side}<div>{main}</div></div>'
    h._send(200, h._shell(title, body, active="/forms",
                          actions=f'<a class="btn" href="{E(up)}">양식 올리기</a>'))


def post_folder_new(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    parent = h._int(h._one(f, "parent"), required=False)
    fid = h.server.store.create_folder(h.sess.user_id, parent, h._one(f, "name"), ip=h.ip)
    h._flash("ok", "폴더를 만들었습니다")
    h._redirect(f"/forms?folder={fid}")


def post_folder_rename(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    h.server.store.rename_folder(h.sess.user_id, fid, h._one(f, "name"), ip=h.ip)
    h.server.on_event("folder_renamed", folder_id=fid)
    h._flash("ok", "폴더 이름을 바꿨습니다")
    h._redirect(f"/forms?folder={fid}")


# ── 올리기·내 제출 ───────────────────────────────────────────────────────────

def get_upload(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    qd = h._query()
    pick_folder = h._int(h._one(qd, "folder"), required=False)
    pick_form = h._int(h._one(qd, "form"), required=False)
    flat = h._folders()
    paths = {n["id"]: p for n, _, p in flat}
    forms = [f for f in store.list_forms(s.user_id) if not f["retired"]]
    exts = "·".join(sorted(e.lstrip(".") for e in ALLOWED_EXTS))
    mb = store.max_upload_bytes // (1024 * 1024)
    csrf = E(s.csrf)
    intro = (f'<p class="muted">올린 파일은 바로 쓰이지 않고 <b>검토 대기</b>가 됩니다. 검토자가 승인하면 판 번호(v1, v2…)가 붙어 '
             f'현행 판이 됩니다. 올릴 수 있는 파일: {E(exts)} · 최대 {mb}MB</p>')
    if not flat:
        body = intro + '<div class="note warn">아직 폴더가 없습니다 — 관리자가 먼저 폴더를 만들어야 올릴 수 있습니다.</div>'
        h._send(200, h._shell("양식 올리기", f'<div class="panel">{body}</div>', active="/upload"))
        return
    fopts = "".join(f'<option value="{n["id"]}"{" selected" if n["id"] == pick_folder else ""}>'
                    f'{E(p)}</option>' for n, _, p in flat)
    new_form = (f'<div class="panel"><h2>새 양식 올리기</h2>'
                f'<form method="post" action="/upload" enctype="multipart/form-data">'
                f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="kind" value="new">'
                f'<label for="nf">폴더</label><select class="wide" id="nf" name="folder_id" required>{fopts}</select>'
                f'<label for="nn">양식 이름</label><input type="text" id="nn" name="form_name" required maxlength="100" '
                f'placeholder="예: 잔업집계표">'
                f'<label for="nc">분류 (선택)</label><input type="text" id="nc" name="category" maxlength="50" '
                f'placeholder="예: 인사·근태">'
                f'<label for="nfile">파일</label><input type="file" id="nfile" name="file" required>'
                f'<label for="nnote">한 줄 설명</label><input type="text" id="nnote" name="note" maxlength="500" '
                f'placeholder="예: 2026년 잔업 집계 양식 처음 올림">'
                f'<div class="form-actions"><button class="btn" type="submit">올리기 (검토 대기)</button></div></form></div>')
    if forms:
        ropts = "".join(f'<option value="{f["id"]}"{" selected" if f["id"] == pick_form else ""}>'
                        f'{E(paths.get(f["folder_id"], ""))} / {E(f["name"])}'
                        f'{" (v" + str(f["current_number"]) + ")" if f["current_number"] else ""}</option>'
                        for f in forms)
        rev_form = (f'<div class="panel"><h2>기존 양식의 개정안 올리기</h2>'
                    f'<form method="post" action="/upload" enctype="multipart/form-data">'
                    f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="kind" value="revision">'
                    f'<label for="rf">어느 양식의 개정안인가요</label><select class="wide" id="rf" name="form_id" required>'
                    f'{ropts}</select>'
                    f'<label for="rfile">파일</label><input type="file" id="rfile" name="file" required>'
                    f'<label for="rnote">한 줄 설명 (무엇을 바꿨나요)</label><input type="text" id="rnote" name="note" '
                    f'maxlength="500" placeholder="예: 서명란 추가, 합계 칸 수식 고침">'
                    f'<div class="form-actions"><button class="btn" type="submit">개정안 올리기 (검토 대기)</button></div>'
                    f'</form></div>')
    else:
        rev_form = '<div class="panel"><h2>기존 양식의 개정안 올리기</h2><p class="muted">아직 승인된 양식이 없습니다.</p></div>'
    first = rev_form + new_form if pick_form is not None else new_form + rev_form
    h._send(200, h._shell("양식 올리기", f'<div class="panel">{intro}</div>{first}', active="/upload"))


def post_upload(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    n = h._length(store.max_upload_bytes + MULTIPART_SLACK)     # 본문을 읽기 전에 자른다
    try:
        bnd = boundary_of(h.headers.get("Content-Type", ""))
    except MultipartError as e:
        raise HttpError(400, str(e))
    body = h._read_body(n)
    try:
        fields, files = parse_multipart(body, bnd)
    except MultipartError as e:
        raise HttpError(400, f"올린 내용을 읽지 못했습니다 — {e}")
    del body
    h._check_token(fields)
    if "file" not in files:
        raise HttpError(400, "파일을 골라 주세요")
    filename, data = files["file"]
    if not filename:
        raise HttpError(400, "파일을 골라 주세요")
    kind = h._one(fields, "kind")
    note = h._one(fields, "note")
    if kind == "revision":
        res = store.submit(s.user_id, data=data, filename=filename, form_id=h._int(h._one(fields, "form_id")),
                           note=note, ip=h.ip)
    elif kind == "new":
        res = store.submit(s.user_id, data=data, filename=filename,
                           folder_id=h._int(h._one(fields, "folder_id")),
                           form_name=h._one(fields, "form_name"), category=h._one(fields, "category"),
                           note=note, ip=h.ip)
    else:
        raise HttpError(400, "새 양식인지 개정안인지 골라 주세요")
    h._flash("ok", f"올렸습니다 — 검토 대기 (제출 {res['id']}번). 검토자가 승인하면 현행 판이 됩니다")
    h._redirect("/mine")


def _status_tag(st: str) -> str:
    return f'<span class="tag {E(st)}">{E(STATUS_LABEL.get(st, st))}</span>'


def get_mine(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    subs = store.list_submissions(s.user_id, scope="mine", limit=300)
    csrf = E(s.csrf)
    rows = []
    for x in subs:
        act = ""
        if x["status"] == "pending":
            act = (f'<form class="inline" method="post" action="/submissions/cancel">'
                   f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="id" value="{x["id"]}">'
                   f'<button class="btn gray sm" type="submit">취소</button></form>')
        elif x["status"] == "approved" and x["form_id"]:
            act = f'<a href="/form?id={x["form_id"]}">양식 보기</a>'
        why = f'<div class="muted">반려 사유: {E(x["reason"])}</div>' if x["reason"] else ""
        if x.get("decision_note"):
            why += f'<div class="muted">승인 메모: {E(x["decision_note"])}</div>'
        who = f'<div class="muted">{E(x["decided_by_name"])} · {E(_fmt_time(x["decided_at"]))}</div>' \
            if x["decided_at"] else ""
        rows.append(f'<tr><td class="nw">{x["id"]}</td><td>{E(x["form_name"])}<div class="muted">'
                    f'{E(KIND_LABEL.get(x["kind"], x["kind"]))}</div></td>'
                    f'<td>{E(x["filename"])}<div class="muted">{_fmt_size(x["size"])}</div></td>'
                    f'<td>{E(x["note"])}</td><td class="nw">{E(_fmt_time(x["submitted_at"]))}</td>'
                    f'<td>{_status_tag(x["status"])}{who}{why}</td><td class="nw">{act}</td></tr>')
    table = ("<table><thead><tr><th>번호</th><th>양식</th><th>파일</th><th>설명</th><th>올린 때</th>"
             "<th>상태</th><th></th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>") if rows else \
        '<p class="empty">아직 올린 것이 없습니다</p>'
    h._send(200, h._shell("내 제출", f'<div class="panel">{table}</div>', active="/mine",
                          actions='<a class="btn" href="/upload">양식 올리기</a>'))


def post_cancel(h: FormsHandler) -> None:
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    h.server.store.cancel(h.sess.user_id, sid, ip=h.ip)
    h._flash("ok", f"제출 {sid}번을 취소했습니다")
    h._redirect("/mine")


# ── 양식 상세·내려받기 ──────────────────────────────────────────────────────

def get_form(h: FormsHandler) -> None:
    store, s = h.server.store, h.sess
    fid = h._int(h._one(h._query(), "id"))
    d = store.form_detail(s.user_id, fid)
    trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in d["folder_path"])
    meta = []
    if d["category"]:
        meta.append(f'분류 {E(d["category"])}')
    meta.append(f'현행 v{d["current_number"]}' if d["current_number"] else "현행 판 없음")
    if d["pending"]:
        meta.append(f'검토 대기 {d["pending"]}건')
    retired = ""
    if d["retired"]:
        who = " · ".join(x for x in (d.get("retired_by_name") or "", _fmt_time(d.get("retired_at"))) if x)
        retired = (f'<div class="note warn" role="status"><b>폐기된 양식입니다</b> — 목록에서는 숨겨지고 기록으로 남습니다. '
                   f'내려받을 수는 있지만 새로 쓰지 마세요.'
                   + (f'<div>폐기 사유: {E(d["retired_reason"])}</div>' if d.get("retired_reason") else "")
                   + (f'<div class="muted">{E(who)}</div>' if who else "") + '</div>')
    versions = d["versions"]                                  # 최신 판부터
    dl_mark = ' <span class="tag retired">폐기된 양식</span>' if d["retired"] else ""
    rows = []
    for k, v in enumerate(versions):
        cur = ' <span class="tag approved">현행</span>' if v["id"] == d["current_version_id"] else ""
        prev = versions[k + 1] if k + 1 < len(versions) else None
        cmp_link = (f'<a class="btn gray sm" href="/compare?form={fid}&amp;a={prev["id"]}&amp;b={v["id"]}">'
                    f'전 판(v{prev["number"]})과 비교</a>') if prev else ""
        rows.append(f'<tr><td class="nw"><b>v{v["number"]}</b>{cur}</td>'
                    f'<td class="nw">{E(_fmt_time(v["approved_at"]))}</td>'
                    f'<td>{E(v["uploaded_by_name"])}<div class="muted">{E(_fmt_time(v["uploaded_at"]))}</div></td>'
                    f'<td>{E(v["approved_by_name"])}</td><td>{E(v["note"])}</td>'
                    f'<td>{E(v["filename"])}<div class="muted">{_fmt_size(v["size"])}</div></td>'
                    f'<td class="nw"><a class="btn sm" href="/download?v={v["id"]}">내려받기</a>{dl_mark} {cmp_link}</td></tr>')
    table = ("<table><thead><tr><th>판</th><th>승인한 날</th><th>올린 사람</th><th>승인자</th><th>설명</th>"
             "<th>파일</th><th></th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>") if rows else \
        '<p class="empty">아직 승인된 판이 없습니다</p>'
    pick = ""
    if len(versions) >= 2:
        pick = (f'<h3>판끼리 비교</h3><p class="muted">두 판을 골라 무엇이 바뀌었는지 근거 표(이전 값 / 새 값 / 위치)로 봅니다.</p>'
                + _version_picker(fid, versions, versions[1]["id"], versions[0]["id"], s.csrf))
    tools = ""
    if store.is_reviewer_of(s.user_id, d["folder_id"]):
        csrf = E(s.csrf)
        if d["retired"]:
            tools = (f'<details class="tool"><summary>양식 복원</summary>'
                     f'<form method="post" action="/form/restore"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{fid}"><label for="rs">복원 사유 (필수)</label>'
                     f'<input type="text" id="rs" name="reason" required maxlength="500" placeholder="예: 새 양식 적용을 미룸">'
                     f'<div class="form-actions"><button class="btn sm" type="submit">복원하기</button></div></form></details>')
        else:
            tools = (f'<details class="tool"><summary>양식 폐기</summary>'
                     f'<p class="muted">폐기하면 목록에서 숨겨지고 개정안을 받지 않습니다. 판 파일은 그대로 남고 언제든 복원할 수 있습니다.</p>'
                     f'<form method="post" action="/form/retire"><input type="hidden" name="csrf" value="{csrf}">'
                     f'<input type="hidden" name="id" value="{fid}"><label for="rt">폐기 사유 (필수)</label>'
                     f'<input type="text" id="rt" name="reason" required maxlength="500" placeholder="예: 2027년 양식으로 바뀜">'
                     f'<div class="form-actions"><button class="btn red sm" type="submit">폐기하기</button></div></form></details>')
        tools = f'<div class="panel"><h2>검토자 도구</h2>{tools}</div>'
    actions = "" if d["retired"] else f'<a class="btn" href="/upload?form={fid}">개정안 올리기</a>'
    body = (f'<div class="crumb"><a href="/forms">전체</a> / {trail}</div>{retired}'
            f'<div class="panel"><p class="muted">{" · ".join(meta)}</p><h3>판 이력</h3>{table}{pick}</div>{tools}')
    h._send(200, h._shell(d["name"], body, active="/forms", actions=actions))


def _compare_button(action: str, csrf: str, fields, label: str = "비교하기") -> str:
    """비교 계산 단추 — POST + CSRF (2026-10-28 보안 F3: 화면을 여는 GET은 계산하지 않는다)."""
    hid = "".join(f'<input type="hidden" name="{E(k)}" value="{E(str(v))}">' for k, v in fields)
    return (f'<form class="inline" method="post" action="{E(action)}"><input type="hidden" name="csrf" '
            f'value="{E(csrf)}">{hid}<button class="btn sm" type="submit">{E(label)}</button></form>')


def _version_picker(fid: int, versions: list, a_id, b_id, csrf: str) -> str:
    """판 두 개 고르기 — 스크립트 없는 POST 양식 (/compare, CSRF). 고르고 누르면 비교해 보기 화면으로 간다 (보안 F3)."""
    def opts(sel):
        return "".join(f'<option value="{v["id"]}"{" selected" if v["id"] == sel else ""}>v{v["number"]} · '
                       f'{E(_fmt_time(v["approved_at"]))}</option>' for v in versions)
    return (f'<form class="pick" method="post" action="/compare"><input type="hidden" name="csrf" value="{E(csrf)}">'
            f'<input type="hidden" name="form" value="{fid}">'
            f'<label class="chk" for="pa">이전</label><select id="pa" name="a">{opts(a_id)}</select>'
            f'<span aria-hidden="true">→</span>'
            f'<label class="chk" for="pb">새</label><select id="pb" name="b">{opts(b_id)}</select>'
            f'<button class="btn sm" type="submit">비교하기</button></form>')


# ── 자동 비교 표 (F3) ───────────────────────────────────────────────────────

def _parts_html(parts: list, mark_tag: str, mark_cls: str = "") -> str:
    """[[조각, 바뀜?]…] → HTML. 바뀐 조각만 강조. 값은 전부 이스케이프."""
    out = []
    for text, changed in parts or []:
        t = E(str(text))
        if changed:
            cls = f' class="{mark_cls}"' if mark_cls else ""
            out.append(f"<{mark_tag}{cls}>{t}</{mark_tag}>")
        else:
            out.append(t)
    return "".join(out)


def _compare_table(rows: list) -> str:
    trs = []
    for r in rows:
        old = (f'<del class="old">{_parts_html(r.get("old_parts"), "span", "hl")}</del>'
               if r.get("old") else '<span class="none">—</span>')
        new = (f'<ins class="new">{_parts_html(r.get("new_parts"), "mark")}</ins>'
               if r.get("new") else '<span class="none">—</span>')
        sub = f'<div class="muted">{E(r["label"])}</div>' if r.get("label") else ""
        trs.append(f'<tr><td class="nw"><span class="tag k-{E(r.get("tone", "info"))}">{E(r.get("kind_label", ""))}</span>'
                   f'</td><td class="name">{E(r.get("name", ""))}{sub}</td><td class="val">{old}</td>'
                   f'<td class="val">{new}</td><td class="muted">{E(r.get("where", ""))}</td></tr>')
    return ('<table class="cmp"><thead><tr><th>구분</th><th>항목</th><th>이전 값</th><th>새 값</th><th>위치</th></tr>'
            '</thead><tbody>' + "".join(trs) + "</tbody></table>")


def _notes_html(notes) -> str:
    notes = [n for n in (notes or []) if str(n).strip()]
    return ('<ul class="notes">' + "".join(f"<li>{E(str(n))}</li>" for n in notes) + "</ul>") if notes else ""


def _compare_html(res: dict, old_label: str, new_label: str, downloads: str = "", retry: str = "") -> str:
    """비교 결과 → 화면 조각. status: ok / unsupported / failed. retry: 실패 때 보일 [다시 비교하기](POST) 단추."""
    st = res.get("status")
    head = (f'<div class="cmp-head"><span>이전: {E(old_label)}</span><span aria-hidden="true">→</span>'
            f'<span>새: {E(new_label)}</span></div>')
    if st == "unsupported":
        return head + f'<div class="note info" role="status">{E(res.get("reason", ""))}</div>{downloads}'
    if st != "ok":
        again = ("잠시 뒤 [다시 비교하기]를 누르면 다시 해 봅니다." if retry else "")
        return (head + f'<div class="note bad" role="alert"><b>비교할 수 없음</b> — {E(res.get("reason", ""))}</div>'
                f'<p class="muted">파일을 내려받아 직접 열어 확인해 주세요. {again}</p>'
                f'{retry}{downloads}')
    rows = res.get("rows") or []
    if not rows:
        return (head + '<div class="note ok" role="status">글자·표로는 바뀐 것이 없습니다 — 서식·그림만 바뀌었을 수 있으니 '
                       '파일을 열어 확인하세요.</div>' + _notes_html(res.get("notes")) + downloads)
    adds = sum(1 for r in rows if r.get("tone") == "add")
    rms = sum(1 for r in rows if r.get("tone") == "rm")
    mods = sum(1 for r in rows if r.get("tone") == "mod")
    tally = " · ".join(x for x in (f"추가 {adds}" if adds else "", f"삭제 {rms}" if rms else "",
                                   f"변경 {mods}" if mods else "") if x)
    count = (f'<div class="cmp-head"><b>변경 {len(rows)}건</b>'
             + (f'<span class="muted">{E(tally)}</span>' if tally else "")
             + '<span class="muted">이전 값은 취소선, 새 값은 굵게 — 바뀐 낱말은 색으로 표시</span></div>')
    return head + count + _compare_table(rows) + _notes_html(res.get("notes")) + downloads


def _summary_html(res: dict, downloads: str = "", retry: str = "") -> str:
    """새 양식 — 비교할 이전 판이 없을 때의 글자 요약. retry: 실패 때 보일 [다시 읽기](POST) 단추."""
    lead = '<div class="note info" role="status"><b>새 양식 — 비교할 이전 판 없음</b>. 아래는 파일에서 읽은 글자 요약입니다.</div>'
    st = res.get("status")
    if st == "unsupported":
        return lead + f'<div class="note info">{E(res.get("reason", ""))}</div>{downloads}'
    if st != "new":
        return lead + (f'<div class="note bad" role="alert"><b>비교할 수 없음</b> — {E(res.get("reason", ""))}</div>'
                       f'{retry}{downloads}')
    s = res.get("summary") or {}
    parts = []
    if s.get("sheets"):
        parts.append(f'<dt>시트</dt><dd>{E(" · ".join(s["sheets"]))}</dd>')
    for k, v in s.get("fields") or []:
        parts.append(f'<dt>{E(k)}</dt><dd>{E(v)}</dd>')
    if s.get("row_count"):
        parts.append(f'<dt>표 행 수</dt><dd>{int(s["row_count"])}행</dd>')
    out = lead + (f'<dl class="kv">{"".join(parts)}</dl>' if parts else "")
    for sheet, cols in s.get("headers") or []:
        out += (f'<h3>칸 이름 — {E(sheet)}</h3><div class="cols">'
                + "".join(f"<span>{E(c)}</span>" for c in cols) + "</div>")
    if s.get("lines"):
        out += '<h3>머리 글줄</h3><ul class="lines">' + "".join(f"<li>{E(x)}</li>" for x in s["lines"]) + "</ul>"
    if not parts and not s.get("headers") and not s.get("lines"):
        out += '<p class="muted">읽을 수 있는 글자가 없습니다.</p>'
    return out + _notes_html(s.get("notes")) + downloads


def _compare_pick(h: FormsHandler, fid: int, a, b):
    """판끼리 비교의 두 판 정하기 — (양식 상세, 이전 판, 새 판) 또는 판이 하나뿐이면 (상세, None, None)."""
    d = h.server.store.form_detail(h.sess.user_id, fid)
    versions = d["versions"]
    by_id = {v["id"]: v for v in versions}
    for x in (a, b):
        if x is not None and x not in by_id:
            raise HttpError(404, "이 양식의 판이 아닙니다")
    if len(versions) < 2:
        return d, None, None
    if b is None:
        b = d["current_version_id"] if d["current_version_id"] in by_id else versions[0]["id"]
    if a is None:
        older = [v for v in versions if v["number"] < by_id[b]["number"]]
        a = older[0]["id"] if older else next(v["id"] for v in versions if v["id"] != b)
    va, vb = by_id[a], by_id[b]
    if va["number"] > vb["number"]:                 # 이전 → 새 순서로 (취소선이 옛 값에 가게)
        va, vb = vb, va
    return d, va, vb


def post_compare(h: FormsHandler) -> None:
    """[비교하기] — 판끼리 비교를 계산해 캐시에 둔 뒤 보기 화면(GET)으로 (2026-10-28 보안 F3: GET은 계산하지 않는다)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "form"))
    d, va, vb = _compare_pick(h, fid, h._int(h._one(f, "a"), required=False), h._int(h._one(f, "b"), required=False))
    if va is not None and va["id"] != vb["id"]:
        h._allow_compare()
        out = h.server.comparer.compare_versions(h.sess.user_id, va["id"], vb["id"], ip=h.ip)
        if out["result"].get("status") == "failed" and "밀려" in str(out["result"].get("reason", "")):
            h._flash("bad", "비교가 밀려 있습니다 — 잠시 뒤 [비교하기]를 다시 눌러 주세요")
        h._redirect(f"/compare?form={fid}&a={va['id']}&b={vb['id']}")
        return
    h._redirect(f"/compare?form={fid}")


def get_compare(h: FormsHandler) -> None:
    """판끼리 비교 — 기본은 현행과 바로 전 판. 누구나(판은 모두가 볼 수 있다). 내려받기 감사 기록은 남기지 않는다.
    이 화면(GET)은 **캐시만 본다** — 아직 비교하지 않은 두 판이면 [비교하기](POST+CSRF) 단추를 보인다 (보안 F3)."""
    store, s = h.server.store, h.sess
    qd = h._query()
    fid = h._int(h._one(qd, "form"))
    a = h._int(h._one(qd, "a"), required=False)
    b = h._int(h._one(qd, "b"), required=False)
    d, va0, vb0 = _compare_pick(h, fid, a, b)
    versions = d["versions"]
    trail = " / ".join(f'<a href="/forms?folder={c["id"]}">{E(c["name"])}</a>' for c in d["folder_path"])
    crumb = (f'<div class="crumb"><a href="/forms">전체</a> / {trail} / '
             f'<a href="/form?id={fid}">{E(d["name"])}</a></div>')
    if va0 is None:
        body = crumb + '<div class="panel"><p class="empty">판이 둘 이상 있어야 비교할 수 있습니다.</p></div>'
        h._send(200, h._shell(f"{d['name']} — 판끼리 비교", body, active="/forms"))
        return
    va, vb = va0, vb0
    picker = _version_picker(fid, versions, va["id"], vb["id"], s.csrf)
    retired = '<div class="note warn">폐기된 양식입니다.</div>' if d["retired"] else ""
    dl = (f'<p class="form-actions"><a class="btn gray sm" href="/download?v={va["id"]}">v{va["number"]} 내려받기</a>'
          f'<a class="btn gray sm" href="/download?v={vb["id"]}">v{vb["number"]} 내려받기</a></p>')
    if va["id"] == vb["id"]:
        inner = '<div class="note info">같은 판을 골랐습니다 — 다른 두 판을 골라 주세요.</div>'
    else:
        out = h.server.comparer.compare_versions(s.user_id, va["id"], vb["id"], ip=h.ip, compute=False)
        old_l, new_l = f"v{va['number']} ({va['filename']})", f"v{vb['number']} ({vb['filename']})"
        run_btn = _compare_button("/compare", s.csrf, (("form", fid), ("a", va["id"]), ("b", vb["id"])))
        if out["result"] is None:
            inner = (f'<div class="cmp-head"><span>이전: {E(old_l)}</span><span aria-hidden="true">→</span>'
                     f'<span>새: {E(new_l)}</span></div>'
                     f'<div class="note info" role="status">아직 비교하지 않은 두 판입니다 — [비교하기]를 누르면 '
                     f'근거 표(이전 값 / 새 값 / 위치)를 만듭니다. 한 번 비교한 결과는 저장돼 다음부터 바로 보입니다.</div>'
                     f'{run_btn}{dl}')
        else:
            again = _compare_button("/compare", s.csrf, (("form", fid), ("a", va["id"]), ("b", vb["id"])),
                                    "다시 비교하기")
            inner = _compare_html(out["result"], old_l, new_l, dl, retry=again)
    body = crumb + retired + f'<div class="panel">{picker}{inner}</div>'
    h._send(200, h._shell(f"{d['name']} — 판끼리 비교", body, active="/forms"))


def post_retire(h: FormsHandler) -> None:
    _set_retired(h, True)


def post_restore(h: FormsHandler) -> None:
    _set_retired(h, False)


def _set_retired(h: FormsHandler, retired: bool) -> None:
    """폐기·복원 — 사유 필수. 역할은 여기서, 맡은 폴더인지는 store가 다시 본다."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "id"))
    reason = h._one(f, "reason").strip()
    if not reason:
        raise HttpError(400, f"{'폐기' if retired else '복원'} 사유를 적어 주세요")
    h.server.store.set_retired(h.sess.user_id, fid, retired, ip=h.ip, reason=reason)
    h.server.on_event("retired" if retired else "restored", form_id=fid)
    h._flash("ok", "양식을 폐기했습니다 — 목록에서 숨겨지고 '폐기 양식도 보기'에서만 보입니다" if retired
             else "양식을 복원했습니다 — 다시 목록에 보입니다")
    h._redirect(f"/form?id={fid}")


def _stream_file(h: FormsHandler, path, filename: str, size: int) -> None:
    h._deadline(int(size))
    h.send_response(200)
    h.send_header("Content-Type", "application/octet-stream")
    h.send_header("Content-Length", str(int(size)))
    h.send_header("Content-Disposition", content_disposition(filename))
    h.end_headers()
    sent = 0
    with open(path, "rb") as f:
        while sent < size:
            chunk = f.read(min(256 * 1024, size - sent))
            if not chunk:
                break
            h._out(chunk)
            sent += len(chunk)
    h.close_connection = True


def get_download(h: FormsHandler) -> None:
    vid = h._int(h._one(h._query(), "v"))
    info = h.server.store.version_file(h.sess.user_id, vid, ip=h.ip)
    # 폐기된 양식은 받은 파일 이름에도 표시를 붙인다 — 내려받은 뒤 탐색기에서도 옛 양식인 줄 알게 (F3)
    name = RETIRED_PREFIX + info["filename"] if info.get("retired") else info["filename"]
    _stream_file(h, info["path"], name, info["size"])


def get_review_file(h: FormsHandler) -> None:
    sid = h._int(h._one(h._query(), "s"))
    info = h.server.store.submission_file(h.sess.user_id, sid, ip=h.ip)
    _stream_file(h, info["path"], info["filename"], info["size"])


# ── 검토 대기 (최소판 — 자동 비교·판끼리 비교·폐기 화면은 F3) ───────────────────────

def _require_reviewer_role(h: FormsHandler) -> None:
    if h.sess.role not in ("reviewer", "admin"):
        raise HttpError(403, "검토자와 관리자만 볼 수 있습니다")


def get_review(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    subs = store.list_submissions(s.user_id, scope="review", status="pending")
    paths = {n["id"]: p for n, _, p in h._folders()}
    csrf = E(s.csrf)
    comparer = h.server.comparer
    rows = []
    for x in subs:
        target = (f'<a href="/form?id={x["form_id"]}">{E(x["form_name"])}</a>' if x["form_id"]
                  else E(x["form_name"]))
        # 변경 건수는 이미 비교해 둔 것만 보인다 — 목록을 그리려고 비교를 돌리지 않는다
        n = comparer.cached_count(s.user_id, x["id"]) if (comparer is not None and x["form_id"]) else None
        badge = (f'<div class="muted">현행 판과 비교: 변경 {n}건</div>' if n is not None
                 else ('<div class="muted">열면 현행 판과 자동 비교</div>' if x["form_id"] else
                       '<div class="muted">새 양식 — 열면 글자 요약</div>'))
        rows.append(
            f'<tr><td class="nw">{x["id"]}</td><td>{target}<div class="muted">{E(KIND_LABEL.get(x["kind"], ""))} · '
            f'{E(paths.get(x["folder_id"], ""))}</div></td>'
            f'<td><a href="/review/file?s={x["id"]}">{E(x["filename"])}</a><div class="muted">{_fmt_size(x["size"])}'
            f'</div></td><td>{E(x["submitted_by_name"])}<div class="muted">{E(_fmt_time(x["submitted_at"]))}</div></td>'
            f'<td>{E(x["note"])}</td><td><a class="btn sm" href="/review/item?id={x["id"]}">비교 보며 검토</a>{badge}'
            f'<details class="tool"><summary>바로 처리</summary>'
            f'<form class="inline" method="post" action="/review/approve"><input type="hidden" name="csrf" value="{csrf}">'
            f'<input type="hidden" name="id" value="{x["id"]}"><button class="btn sm" type="submit">승인</button></form>'
            f'<form class="inline" method="post" action="/review/reject"><input type="hidden" name="csrf" value="{csrf}">'
            f'<input type="hidden" name="id" value="{x["id"]}">'
            f'<input type="text" name="reason" required maxlength="500" placeholder="반려 사유 (필수)" aria-label="반려 사유">'
            f'<button class="btn red sm" type="submit">반려</button></form></details></td></tr>')
    table = ("<table><thead><tr><th>번호</th><th>양식</th><th>파일</th><th>올린 사람</th><th>설명</th><th>처리</th>"
             "</tr></thead><tbody>" + "".join(rows) + "</tbody></table>") if rows else \
        '<p class="empty">검토할 것이 없습니다</p>'
    hint = ('<p class="muted">[비교 보며 검토]를 누르면 개정안은 현행 판과의 자동 비교 표(이전 값 / 새 값 / 위치)가, '
            '새 양식은 파일에서 읽은 글자 요약이 보입니다. 승인할 때 메모를, 반려할 때 사유(필수)를 남깁니다.</p>')
    h._send(200, h._shell("검토 대기", f'<div class="panel">{hint}{table}</div>', active="/review"))


def get_review_item(h: FormsHandler) -> None:
    """검토 화면 하나 — 개정안은 현행 판과 자동 비교, 새 양식은 글자 요약. 승인(메모)·반려(사유 필수)."""
    _require_reviewer_role(h)
    store, s = h.server.store, h.sess
    sid = h._int(h._one(h._query(), "id"))
    sub = store.submission(s.user_id, sid)
    if not store.is_reviewer_of(s.user_id, sub["folder_id"]):
        raise HttpError(403, "이 폴더의 검토자만 볼 수 있습니다")
    paths = {n["id"]: p for n, _, p in h._folders()}
    target = (f'<a href="/form?id={sub["form_id"]}">{E(sub["form_name"])}</a>' if sub["form_id"]
              else E(sub["form_name"]))
    info = (f'<dl class="kv"><dt>양식</dt><dd>{target}</dd>'
            f'<dt>종류</dt><dd>{E(KIND_LABEL.get(sub["kind"], sub["kind"]))}</dd>'
            f'<dt>폴더</dt><dd>{E(paths.get(sub["folder_id"], ""))}</dd>'
            f'<dt>올린 사람</dt><dd>{E(sub["submitted_by_name"])} · {E(_fmt_time(sub["submitted_at"]))}</dd>'
            f'<dt>설명</dt><dd>{E(sub["note"]) or "<span class=none>—</span>"}</dd>'
            f'<dt>파일</dt><dd>{E(sub["filename"])} <span class="muted">{_fmt_size(sub["size"])}</span></dd>'
            f'<dt>상태</dt><dd>{_status_tag(sub["status"])}</dd></dl>')
    if sub["status"] != "pending":
        extra = ""
        if sub["reason"]:
            extra += f'<p>반려 사유: {E(sub["reason"])}</p>'
        if sub.get("decision_note"):
            extra += f'<p>승인 메모: {E(sub["decision_note"])}</p>'
        body = (f'<div class="crumb"><a href="/review">검토 대기</a> / 제출 {sid}번</div>'
                f'<div class="panel">{info}<div class="note info">이미 처리된 제출입니다 '
                f'({E(sub["decided_by_name"])} · {E(_fmt_time(sub["decided_at"]))})</div>{extra}</div>')
        h._send(200, h._shell(f"제출 {sid}번", body, active="/review"))
        return
    # 자동 비교는 '맡은 폴더의 검토자가, 검토 대기 1건당 한 번'만 이 화면(GET)에서 계산한다 — 그 뒤로는 캐시만 보고,
    # 다시 계산은 [다시 비교하기](POST+CSRF). 직원은 이 화면에 들어오지 못한다(위 403). (2026-10-28 보안 F3)
    comparer = h.server.comparer
    rv = comparer.review_submission(s.user_id, sid, ip=h.ip, compute=False)
    if rv["result"] is None and comparer.claim_auto(sid):
        h._allow_compare()
        rv = comparer.review_submission(s.user_id, sid, ip=h.ip)
    run_btn = _compare_button("/review/compare", s.csrf, (("id", sid),))
    again_btn = _compare_button("/review/compare", s.csrf, (("id", sid),), "다시 비교하기")
    not_yet = ('<div class="note info" role="status">아직 비교하지 않았습니다 — [비교하기]를 누르면 '
               '{what}을(를) 만듭니다.</div>')
    open_new = f'<a class="btn gray sm" href="/review/file?s={sid}">올린 파일 열어 보기</a>'
    if rv["mode"] == "revision":
        old = rv["old"]
        dl = (f'<p class="form-actions">{open_new}'
              f'<a class="btn gray sm" href="/download?v={int(old["id"])}">'
              f'현행 v{old["number"]} 내려받기</a></p>')
        if rv["result"] is None:
            cmp_html = ('<h2>현행 판과 자동 비교</h2>' + not_yet.format(what="현행 판과의 근거 표") + run_btn + dl)
        else:
            cmp_html = ('<h2>현행 판과 자동 비교</h2>'
                        + _compare_html(rv["result"], f"현행 v{old['number']} ({old['filename']})",
                                        f"올린 파일 ({sub['filename']})", dl, retry=again_btn))
    else:
        if rv["result"] is None:
            cmp_html = ('<h2>올린 양식</h2>' + not_yet.format(what="글자 요약") + run_btn
                        + f'<p class="form-actions">{open_new}</p>')
        else:
            cmp_html = '<h2>올린 양식</h2>' + _summary_html(rv["result"], f'<p class="form-actions">{open_new}</p>',
                                                         retry=again_btn)
    csrf = E(s.csrf)
    decide = (f'<div class="panel"><h2>처리</h2><div class="decide">'
              f'<form method="post" action="/review/approve"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="id" value="{sid}"><label for="memo">승인 메모 (선택 — 올린 사람이 봅니다)</label>'
              f'<textarea id="memo" name="memo" maxlength="500" placeholder="예: 야간수당 열 확인함"></textarea>'
              f'<div class="form-actions"><button class="btn" type="submit">승인 — 새 현행 판으로</button></div></form>'
              f'<form method="post" action="/review/reject"><input type="hidden" name="csrf" value="{csrf}">'
              f'<input type="hidden" name="id" value="{sid}"><label for="why">반려 사유 (필수 — 올린 사람이 봅니다)</label>'
              f'<textarea id="why" name="reason" required maxlength="500" placeholder="예: 결재란 칸 수가 규정과 다릅니다">'
              f'</textarea><div class="form-actions"><button class="btn red" type="submit">반려</button></div></form>'
              f'</div></div>')
    body = (f'<div class="crumb"><a href="/review">검토 대기</a> / 제출 {sid}번</div>'
            f'<div class="panel">{info}</div><div class="panel">{cmp_html}</div>{decide}')
    h._send(200, h._shell(f"검토 — {sub['form_name']}", body, active="/review"))


def post_review_compare(h: FormsHandler) -> None:
    """[비교하기]·[다시 비교하기] — 검토 화면의 자동 비교를 (다시) 계산한다. 맡은 폴더의 검토자만, 검토 대기일 때만 (보안 F3)."""
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    store, s = h.server.store, h.sess
    sid = h._int(h._one(f, "id"))
    sub = store.submission(s.user_id, sid)
    if not store.is_reviewer_of(s.user_id, sub["folder_id"]):
        raise HttpError(403, "이 폴더의 검토자만 할 수 있습니다")
    if sub["status"] != "pending":
        raise Conflict("이미 처리된 제출입니다")
    h._allow_compare()
    rv = h.server.comparer.review_submission(s.user_id, sid, ip=h.ip)
    res = rv.get("result") or {}
    if res.get("status") == "failed" and "밀려" in str(res.get("reason", "")):
        h._flash("bad", "비교가 밀려 있습니다 — 잠시 뒤 [비교하기]를 다시 눌러 주세요")
    h._redirect(f"/review/item?id={sid}")


def post_approve(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    res = h.server.store.approve(h.sess.user_id, sid, ip=h.ip, memo=h._one(f, "memo"))
    h.server.on_event("approved", submission_id=sid, result=res)
    h._flash("ok", f"승인했습니다 — 제출 {sid}번이 v{res['number']}(현행 판)이 됐습니다")
    h._redirect("/review")


def post_reject(h: FormsHandler) -> None:
    _require_reviewer_role(h)
    f = h._read_form()
    h._check_token(f)
    sid = h._int(h._one(f, "id"))
    h.server.store.reject(h.sess.user_id, sid, h._one(f, "reason"), ip=h.ip)
    h.server.on_event("rejected", submission_id=sid)
    h._flash("ok", f"반려했습니다 — 제출 {sid}번 (올린 사람이 사유를 봅니다)")
    h._redirect("/review")


# ── 관리자 ─────────────────────────────────────────────────────────────────

def _require_admin(h: FormsHandler) -> None:
    if h.sess.role != "admin":
        raise HttpError(403, "관리자만 볼 수 있습니다")


def _role_options(cur: str) -> str:
    return "".join(f'<option value="{r}"{" selected" if r == cur else ""}>{ROLE_LABEL[r]}</option>'
                   for r in ("member", "reviewer", "admin"))


def get_admin_users(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    users = auth.list_users(store, s.user_id)
    csrf = E(s.csrf)
    hid = f'<input type="hidden" name="csrf" value="{csrf}">'
    rows = []
    for u in users:
        uid = u["id"]
        state = '<span class="tag off">정지</span>' if u["disabled"] else '<span class="tag approved">사용 중</span>'
        if u["must_change"]:
            state += ' <span class="tag pending">임시 비밀번호</span>'
        toggle = (f'<form class="inline" method="post" action="/admin/users/disable">{hid}'
                  f'<input type="hidden" name="id" value="{uid}"><input type="hidden" name="disabled" '
                  f'value="{0 if u["disabled"] else 1}"><button class="btn gray sm" type="submit">'
                  f'{"복구" if u["disabled"] else "정지"}</button></form>')
        reset = (f'<form class="inline" method="post" action="/admin/users/reset">{hid}'
                 f'<input type="hidden" name="id" value="{uid}"><button class="btn gray sm" type="submit">'
                 f'비밀번호 초기화</button></form>')
        role = (f'<form class="inline" method="post" action="/admin/users/role">{hid}'
                f'<input type="hidden" name="id" value="{uid}"><select name="role" aria-label="역할">'
                f'{_role_options(u["role"])}</select><button class="btn gray sm" type="submit">역할 바꾸기</button></form>')
        mail = (f'<form class="inline" method="post" action="/admin/users/email">{hid}'
                f'<input type="hidden" name="id" value="{uid}"><input type="email" name="email" '
                f'value="{E(u.get("email") or "")}" maxlength="254" placeholder="알림 메일(선택)" aria-label="메일 주소">'
                f'<button class="btn gray sm" type="submit">저장</button></form>')
        rows.append(f'<tr><td>{E(u["login"])}</td><td>{E(u["display_name"])}</td>'
                    f'<td><span class="tag role">{E(ROLE_LABEL.get(u["role"], u["role"]))}</span></td>'
                    f'<td>{state}</td><td class="nw">{E(_fmt_time(u["created_at"]))}</td>'
                    f'<td>{mail}</td><td>{role}{toggle}{reset}</td></tr>')
    table = ("<table><thead><tr><th>아이디</th><th>이름</th><th>역할</th><th>상태</th><th>만든 날</th><th>메일</th>"
             "<th>관리</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>")
    reg = (f'<div class="panel"><h2>직원 등록</h2>'
           f'<p class="muted">등록하면 임시 비밀번호가 <b>한 번만</b> 보입니다. 직원은 첫 로그인 때 비밀번호를 바꿉니다. '
           f'검토자는 [폴더 검토자]에서 맡을 폴더를 정해 주세요.</p>'
           f'<form method="post" action="/admin/users/new">{hid}'
           f'<label for="ul">아이디</label><input type="text" id="ul" name="login" required maxlength="32" '
           f'placeholder="예: kim.cs (글자·숫자·점·밑줄·빼기)">'
           f'<label for="un">이름</label><input type="text" id="un" name="display_name" required maxlength="40" '
           f'placeholder="예: 김철수 (생산팀)">'
           f'<label for="ur">역할</label><select id="ur" name="role">{_role_options("member")}</select>'
           f'<label for="ue">메일 주소 (선택 — 승인·반려·새 판 알림을 받을 주소)</label>'
           f'<input type="email" id="ue" name="email" maxlength="254" placeholder="예: kim@회사.co.kr">'
           f'<div class="form-actions"><button class="btn" type="submit">등록</button></div></form></div>')
    roles = ('<p class="muted">관리자: 전부 + 계정·검토자 지정·감사 기록 · 검토자: 맡은 폴더에서 폴더 만들기·승인·반려 · '
             '직원: 보기·내려받기·올리기(검토 대기). 마지막 관리자는 정지·강등할 수 없습니다.</p>')
    h._send(200, h._shell("계정", f'{reg}<div class="panel"><h2>계정 목록</h2>{roles}{table}</div>'
                                  f'{_locked_ips_panel(h, hid)}', active="/admin/users"))


def _locked_ips_panel(h: FormsHandler, hid: str) -> str:
    """잠긴 접속 주소 — 주소 잠금(아이디 상관없이 실패가 많음)과 계정+주소 잠금. 관리자가 풀 수 있다 (보안 F2)."""
    rows = auth.locked_ips(h.server.store, h.sess.user_id)
    intro = (f'<p class="muted">한 접속 주소에서 아이디 상관없이 {auth.IP_WINDOW // 60}분 안에 {auth.IP_THRESHOLD}번 틀리면 '
             f'그 주소의 로그인을 {auth.IP_LOCK_SECONDS // 60}분 막습니다(비밀번호 대입 막기). 회사 공유기를 같이 쓰는 PC들은 '
             f'바깥에서 보기에 같은 주소라 <b>함께 막힐 수 있습니다</b> — 직원이 몰라서 틀린 것이 확실하면 여기서 풀어 주세요.</p>')
    if not rows:
        return f'<div class="panel" id="locked"><h2>잠긴 접속 주소</h2>{intro}<p class="empty">지금 잠긴 주소가 없습니다</p></div>'
    trs = []
    for r in rows:
        what = (f'주소 잠금 — {r["count"]}번 실패' if r["kind"] == "ip" else "") + \
               (f'{" · " if r["kind"] == "ip" else ""}계정 잠금 {r["accounts"]}개' if r["accounts"] else "")
        trs.append(f'<tr><td class="nw">{E(r["ip"])}</td><td>{E(what)}</td>'
                   f'<td class="nw">{E(auth._left_text(r["seconds"]))} 남음</td>'
                   f'<td><form class="inline" method="post" action="/admin/unlock-ip">{hid}'
                   f'<input type="hidden" name="ip" value="{E(r["ip"])}">'
                   f'<button class="btn gray sm" type="submit">잠금 풀기</button></form></td></tr>')
    table = ("<table><thead><tr><th>접속 주소</th><th>까닭</th><th>남은 시간</th><th></th></tr></thead><tbody>"
             + "".join(trs) + "</tbody></table>")
    return f'<div class="panel" id="locked"><h2>잠긴 접속 주소</h2>{intro}{table}</div>'


def post_unlock_ip(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    target = h._one(f, "ip").strip()
    done = auth.unlock_ip(h.server.store, h.sess.user_id, target, ip=h.ip)
    h._flash("ok", f"{target} 주소의 잠금을 풀었습니다" if done else f"{target} 주소는 잠겨 있지 않습니다")
    h._redirect("/admin/users#locked")


def _secret_page(h: FormsHandler, title: str, who: str, temp: str, lead: str) -> None:
    body = (f'<div class="panel"><div class="note ok">{E(lead)}</div>'
            f'<p><b>{E(who)}</b>의 임시 비밀번호:</p><div class="secret">{E(temp)}</div>'
            f'<p class="muted">이 화면을 벗어나면 다시 볼 수 없습니다 — 지금 직원에게 직접 전해 주세요. '
            f'첫 로그인 때 새 비밀번호로 바꾸게 됩니다.</p>'
            f'<div class="form-actions"><a class="btn" href="/admin/users">계정 목록으로</a></div></div>')
    h._send(200, h._shell(title, body, active="/admin/users"))


def post_user_new(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    login = h._one(f, "login").strip()
    uid, temp = auth.register_user(h.server.store, h.sess.user_id, login, h._one(f, "display_name"),
                                   h._one(f, "role", "member"), ip=h.ip, email=h._one(f, "email"))
    _secret_page(h, "직원 등록", login, temp, "계정을 등록했습니다")


def post_user_email(h: FormsHandler) -> None:
    """알림 메일 주소 바꾸기 (F4) — 관리자만. 비우면 알림을 받지 않는다."""
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    em = h._one(f, "email").strip()
    auth.set_email(h.server.store, h.sess.user_id, uid, em, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정의 메일 주소를 {'저장' if em else '지웠'}했습니다")
    h._redirect("/admin/users")


def post_folder_subscribe(h: FormsHandler) -> None:
    """폴더 구독(새 현행 판 메일) 켜기·끄기 — 자기 것만 (F4)."""
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    on = h._one(f, "on") == "1"
    h.server.store.set_subscription(h.sess.user_id, fid, on)
    if on and not h.server.store.user_email(h.sess.user_id):
        h._flash("ok", "구독했습니다 — 다만 내 계정에 메일 주소가 없어 알림이 가지 않습니다. 관리자에게 주소 등록을 부탁하세요")
    else:
        h._flash("ok", "이 폴더에 새 현행 판이 생기면 메일로 알립니다" if on else "이 폴더 메일 알림을 껐습니다")
    h._redirect(f"/forms?folder={fid}")


def _user_login(h: FormsHandler, uid: int) -> str:
    u = h.server.store.get_user(uid)
    if u is None:
        raise HttpError(404, "없는 계정입니다")
    return u["login"]


def post_user_disable(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    off = h._one(f, "disabled") == "1"
    auth.set_disabled(h.server.store, h.sess.user_id, uid, off, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정을 {'정지' if off else '복구'}했습니다")
    h._redirect("/admin/users")


def post_user_reset(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    temp = auth.reset_password(h.server.store, h.sess.user_id, uid, ip=h.ip)
    _secret_page(h, "비밀번호 초기화", _user_login(h, uid), temp, "비밀번호를 초기화했습니다 — 그 계정의 접속은 모두 끊겼습니다")


def post_user_role(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    uid = h._int(h._one(f, "id"))
    role = h._one(f, "role")
    auth.set_role(h.server.store, h.sess.user_id, uid, role, ip=h.ip)
    h._flash("ok", f"{_user_login(h, uid)} 계정의 역할을 {ROLE_LABEL.get(role, role)}(으)로 바꿨습니다")
    h._redirect("/admin/users")


def get_admin_folders(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    flat = h._folders()
    users = [u for u in auth.list_users(store, s.user_id) if u["role"] in ("reviewer", "admin") and not u["disabled"]]
    csrf = E(s.csrf)
    blocks = []
    for n, depth, path in flat:
        cur = {u["id"] for u in store.folder_reviewers(s.user_id, n["id"])}
        boxes = "".join(
            f'<label class="chk"><input type="checkbox" name="user" value="{u["id"]}"'
            f'{" checked" if u["id"] in cur else ""}>{E(u["display_name"])} ({E(u["login"])})</label>' for u in users)
        blocks.append(f'<tr><td>{E(path)}</td><td><form method="post" action="/admin/reviewers">'
                      f'<input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="folder" '
                      f'value="{n["id"]}">{boxes or "<span class=muted>검토자 역할 계정이 없습니다</span>"} '
                      f'<button class="btn gray sm" type="submit">저장</button></form></td></tr>')
    table = ("<table><thead><tr><th>폴더</th><th>검토자</th></tr></thead><tbody>" + "".join(blocks)
             + "</tbody></table>") if blocks else '<p class="empty">아직 폴더가 없습니다</p>'
    intro = ('<p class="muted">검토자는 지정된 폴더와 그 <b>하위 폴더</b>에서 승인·반려·폴더 만들기를 할 수 있습니다. '
             '관리자는 지정하지 않아도 모든 폴더를 검토할 수 있습니다.</p>')
    h._send(200, h._shell("폴더 검토자", f'<div class="panel">{intro}{table}</div>', active="/admin/folders"))


def post_reviewers(h: FormsHandler) -> None:
    _require_admin(h)
    f = h._read_form()
    h._check_token(f)
    fid = h._int(h._one(f, "folder"))
    ids = [h._int(v) for v in f.get("user", [])]
    h.server.store.set_folder_reviewers(h.sess.user_id, fid, ids, ip=h.ip)
    h._flash("ok", "검토자를 저장했습니다")
    h._redirect("/admin/folders")


AUDIT_PAGE = 100


def get_admin_audit(h: FormsHandler) -> None:
    _require_admin(h)
    store, s = h.server.store, h.sess
    qd = h._query()
    action = h._one(qd, "action")
    if action and action not in ACTION_LABEL:
        action = ""
    uid = h._int(h._one(qd, "user"), required=False)
    page = h._int(h._one(qd, "page"), required=False) or 0
    page = min(page, 10000)
    rows_ = store.audit_log(s.user_id, limit=AUDIT_PAGE + 1, offset=page * AUDIT_PAGE, action=action or None,
                            user_id=uid)
    more = len(rows_) > AUDIT_PAGE
    rows_ = rows_[:AUDIT_PAGE]
    users = auth.list_users(store, s.user_id)
    aopts = '<option value="">모든 일</option>' + "".join(
        f'<option value="{k}"{" selected" if k == action else ""}>{E(v)}</option>' for k, v in ACTION_LABEL.items())
    uopts = '<option value="">모든 사람</option>' + "".join(
        f'<option value="{u["id"]}"{" selected" if u["id"] == uid else ""}>{E(u["login"])}</option>' for u in users)
    filt = (f'<form class="searchbar" method="get" action="/admin/audit">'
            f'<select name="action" aria-label="일 종류">{aopts}</select>'
            f'<select name="user" aria-label="사람">{uopts}</select>'
            f'<button class="btn sm" type="submit">걸러 보기</button>'
            f'<a class="btn gray sm" href="/admin/audit">지우기</a></form>')
    trs = "".join(
        f'<tr><td class="nw">{E(_fmt_time(r["at"]))}</td><td>{E(r["login"])}</td>'
        f'<td>{E(ACTION_LABEL.get(r["action"], r["action"]))}</td><td>{E(r["target"])}</td>'
        f'<td class="nw">{E(r["ip"])}</td><td>{E(r["detail"])}</td></tr>' for r in rows_)
    table = ("<table><thead><tr><th>때</th><th>아이디</th><th>일</th><th>대상</th><th>접속 주소</th><th>내용</th>"
             "</tr></thead><tbody>" + trs + "</tbody></table>") if trs else '<p class="empty">기록이 없습니다</p>'
    q = "&".join(x for x in (f"action={quote(action)}" if action else "", f"user={uid}" if uid is not None else "") if x)
    pager = '<div class="pager">'
    if page > 0:
        pager += f'<a class="btn gray sm" href="/admin/audit?{E(q + "&" if q else "")}page={page - 1}">← 최근 쪽</a>'
    if more:
        pager += f'<a class="btn gray sm" href="/admin/audit?{E(q + "&" if q else "")}page={page + 1}">이전 기록 →</a>'
    pager += "</div>"
    info = store.audit_info(s.user_id)
    keep = (f'<p class="muted" id="keep">감사 기록은 최근 <b>{info["max_rows"]:,}건</b>까지 보관하고, 넘으면 가장 오래된 것부터 '
            f'지웁니다. 지금 {info["count"]:,}건 · <b>가장 오래된 기록: {E(_fmt_time(info["oldest_at"]) or "없음")}</b>. '
            f'같은 주소에서 연달아 틀린 로그인은 1분씩 묶어 한 줄(횟수·시각·시도한 아이디)로 적습니다.</p>')
    h._send(200, h._shell("감사 기록", f'<div class="panel">{keep}{filt}{table}{pager}</div>', active="/admin/audit"))


# 경로 → (처리 함수, 로그인 없이 열리나)
_GET = {
    "/": (get_root, True), "/login": (get_login, True), "/setup": (get_setup, True),
    "/password": (get_password, False), "/forms": (get_forms, False), "/upload": (get_upload, False),
    "/mine": (get_mine, False), "/form": (get_form, False), "/download": (get_download, False),
    "/review": (get_review, False), "/review/file": (get_review_file, False),
    "/review/item": (get_review_item, False), "/compare": (get_compare, False),
    "/admin/users": (get_admin_users, False), "/admin/folders": (get_admin_folders, False),
    "/admin/audit": (get_admin_audit, False),
}
_POST = {
    "/login": (post_login, True), "/setup": (post_setup, True), "/theme": (post_theme, True),
    "/logout": (post_logout, False), "/password": (post_password, False),
    "/folders/new": (post_folder_new, False), "/folders/rename": (post_folder_rename, False),
    "/folders/subscribe": (post_folder_subscribe, False), "/admin/users/email": (post_user_email, False),
    "/upload": (post_upload, False), "/submissions/cancel": (post_cancel, False),
    "/review/approve": (post_approve, False), "/review/reject": (post_reject, False),
    "/form/retire": (post_retire, False), "/form/restore": (post_restore, False),
    "/admin/users/new": (post_user_new, False), "/admin/users/disable": (post_user_disable, False),
    "/admin/users/reset": (post_user_reset, False), "/admin/users/role": (post_user_role, False),
    "/admin/reviewers": (post_reviewers, False),
    "/compare": (post_compare, False), "/review/compare": (post_review_compare, False),     # 보안 F3
    "/admin/unlock-ip": (post_unlock_ip, False),                                              # 보안 F2
}
# 비밀번호를 바꿔야 하는 계정이 쓸 수 있는 주소
_MUST_CHANGE_OK = {"/password", "/logout", "/theme", "/login", "/setup", "/"}


# ── 손으로 띄우기 ────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):      # 한국어 Windows 콘솔(cp949)에서 글자 하나로 죽지 않게
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    p = argparse.ArgumentParser(prog="python -m watcher.forms.server",
                                description="Drev 양식함 사내망 화면 서버 (손으로 띄우기, 상시 실행은 F4의 forms-serve)")
    p.add_argument("--data", required=True, help="Drev 데이터 폴더 (forms.db·forms_store가 생기는 곳)")
    p.add_argument("--host", default="127.0.0.1", help="사내망 주소 (기본 127.0.0.1, 모든 주소: 0.0.0.0)")
    p.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"포트 (기본 {DEFAULT_PORT})")
    p.add_argument("--mirror", default=None, help="(선택) 현행 미러 폴더")
    p.add_argument("--max-upload-mb", type=int, default=MAX_UPLOAD_BYTES // (1024 * 1024),
                   help="올리기 상한 MB (기본 50)")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    def ready(srv):
        host, port = srv.server_address[:2]
        print(f"양식함이 열렸습니다: http://{host}:{port}/  (멈추려면 Ctrl+C)", flush=True)
        if host in ("0.0.0.0", "::"):
            print("사내망 전용입니다 — 공유기에서 이 포트를 인터넷으로 열지 마세요.", flush=True)

    try:
        serve(a.data, a.host, a.port, mirror_root=a.mirror,
              max_upload_bytes=max(1, a.max_upload_mb) * 1024 * 1024, on_ready=ready)
    except AlreadyRunning as e:
        print(str(e), file=sys.stderr)
        return 2
    except (FormsError, OSError) as e:
        print(f"양식함을 열 수 없습니다: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
