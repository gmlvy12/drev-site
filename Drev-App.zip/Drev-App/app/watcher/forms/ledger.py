# -*- coding: utf-8 -*-
"""문서 관리 대장 엑셀(xlsx) 만들기 (F7 ISO 문서 관리 대장, 2026-10-29).

- **메모리에서만** 만든다(zipfile + BytesIO) — 디스크에 아무것도 쓰지 않는다. openpyxl의 저장(save)은 시트마다
  %TEMP%에 임시 파일(openpyxl.*.xml)을 썼다 지우므로(3.1.5 worksheet/_writer.create_temporary_file) 쓰지 않고,
  엑셀이 읽는 최소 SpreadsheetML(통합 문서·시트·스타일)을 직접 적는다. 읽어 확인하는 쪽(시험)은 openpyxl.
- **수식 주입 막기**: 모든 글자 칸은 인라인 문자열(t="inlineStr")로 적어 수식(<f>)이 될 길이 없고,
  = + - @ 탭 CR로 시작하는 글자는 '작은따옴표 앞붙임'(quotePrefix) 스타일까지 준다 — 엑셀에서 칸을 고쳐도 글자로 남는다.
  (openpyxl에 '=…' 글자를 그냥 넣으면 수식으로 저장된다 — tests/test_forms_f7.py가 보인다.)
- 저장소(store)·쓰기 문(guard)을 import 하지 않는다 — 받은 사전만 바이트로 바꾼다.
"""

from __future__ import annotations

import io
import re
import zipfile
from datetime import date, datetime
from xml.sax.saxutils import escape

FORMULA_LEAD = ("=", "+", "-", "@", "\t", "\r")
_BAD_XML = re.compile("[\\x00-\\x08\\x0b\\x0c\\x0e-\\x1f\\ud800-\\udfff\\ufffe\\uffff]")   # 짝 없는 서로게이트는 UTF-8로 못 적는다
_MAX_CELL = 32767                         # 엑셀 한 칸 글자 상한

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_SHEET = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"

# 스타일 번호 (styles.xml의 cellXfs 차례)
S_PLAIN, S_HEAD, S_QUOTED, S_TITLE, S_DATE, S_STAMP = 0, 1, 2, 3, 4, 5
# 보고용 시트(설계 변경 대장 — 검토 Y3 M1)의 값 칸: 위 맞춤, 긴 글 칸은 줄바꿈까지. 앞 여섯 번호는 그대로(문서 관리 대장은 옛 꼴)
S_TOP, S_WRAP, S_QUOTED_TOP, S_QUOTED_WRAP, S_DATE_TOP, S_STAMP_TOP = 6, 7, 8, 9, 10, 11
_EPOCH = datetime(1899, 12, 30)              # 엑셀 날짜 일련값 0 (1900-03-01 뒤 날짜는 이 기준이 맞다)

STATE_TEXT = {"overdue": "검토 기한 지남", "soon": "검토 기한 곧"}

REGISTER_COLUMNS = (            # (머리, 너비(글자))
    ("문서번호", 16), ("대분류", 12), ("중분류", 14), ("소분류 이하 경로", 18), ("양식명", 24), ("현행 판", 8),
    ("시행일", 11), ("승인자", 10), ("개정 사유", 36), ("개정 횟수", 9), ("최근 검토일", 11),
    ("다음 검토 기한", 13), ("상태", 18),
    ("이전 번호", 22),              # 14열 고정 — [다시 매기기] 전 번호(없으면 빈 칸). 매크로·VLOOKUP 열 참조가 안 깨지게
    ("문서 종류", 16),              # 15열 (F7 문서 종류) — 기호 + 이름(QP 절차서), 없으면 빈 칸. 앞 14열의 자리는 그대로
    ("1단계 검토자", 12),           # 16열 (2단계 승인, 2026-10-30) — 현행 판을 [검토 완료]한 사람, 1단계로 승인된 판은 빈 칸. 끝에만 더함
    ("폐기일", 11), ("폐기자", 10), ("폐기 사유", 30))   # 17~19열 (ux21 forms 5) — 폐기한 양식만, 아니면 빈 칸. 끝에만 더함
HISTORY_COLUMNS = (("문서번호", 16), ("양식명", 24), ("판", 6), ("승인일", 17), ("승인자", 10),
                   ("올린 사람", 10), ("사유", 44),
                   ("1단계 검토자", 10),            # 8열 (2단계 승인, 2026-10-30) — 앞 7열의 자리는 그대로
                   ("정리(보존 만료)", 20),         # 9열 (2026-10-31) — 파일을 정리한 날 + 사람, 아니면 빈 칸. 끝에만 더함
                   ("현행 끝", 17))                 # 10열 (ux21 forms 5) — 다음 판 승인일(그때까지 현행). 지금 현행이면 '현행'
RETIRED_COLUMNS = (("문서번호", 16), ("대분류", 12), ("중분류", 14), ("소분류 이하 경로", 18), ("양식명", 24),
                   ("마지막 판", 8), ("마지막 판 시행일", 13), ("폐기일", 11), ("폐기자", 10), ("폐기 사유", 36))


def looks_like_formula(value) -> bool:
    """엑셀이 수식으로 받을 수 있는 글자인가 — = + - @ 탭 CR로 시작."""
    return isinstance(value, str) and value.startswith(FORMULA_LEAD)


def _clean(text: str) -> str:
    text = _BAD_XML.sub("", text)
    if len(text) > _MAX_CELL // 2:            # 엑셀 상한은 UTF-16 단위 — 이모지 같은 글자는 둘로 센다
        text = text.encode("utf-16-le")[:_MAX_CELL * 2].decode("utf-16-le", "ignore")   # 잘린 반쪽은 버린다
    return text


def quoteattr_body(text: str) -> str:
    """속성 값 안에 넣을 글자 (따옴표까지 이스케이프)."""
    return escape(_clean(str(text)), {'"': "&quot;"})


def col_name(i: int) -> str:
    """0 → A, 25 → Z, 26 → AA."""
    out, n = "", i + 1
    while n:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


def _cell(ref: str, value, style: int, top: bool = False, wrap: bool = False) -> str:
    """칸 하나. top: 위 맞춤(보고용 시트의 값 줄 — 한 줄이 여러 줄로 꺾여도 칸들이 같은 높이에서 시작), wrap: 긴 글 칸 줄바꿈."""
    if value is None or value == "":
        return ""
    if isinstance(value, datetime):          # 진짜 날짜 칸 — 일련값 + 날짜 서식 (F7 검토 9)
        serial = (value - _EPOCH).total_seconds() / 86400
        return f'<c r="{ref}" s="{S_STAMP_TOP if top else S_STAMP}"><v>{serial!r}</v></c>'
    if isinstance(value, date):
        return f'<c r="{ref}" s="{S_DATE_TOP if top else S_DATE}"><v>{(value - _EPOCH.date()).days}</v></c>'
    if isinstance(value, bool):
        value = "예" if value else "아니오"
    if isinstance(value, (int, float)):
        return f'<c r="{ref}" s="{S_TOP if top else style}"><v>{value}</v></c>'
    text = _clean(str(value))
    if looks_like_formula(text):
        style = S_QUOTED_WRAP if wrap else S_QUOTED_TOP if top else S_QUOTED
    elif wrap:
        style = S_WRAP
    elif top:
        style = S_TOP
    body = escape(text, {"\r": "&#13;"})               # CR이 XML 줄바꿈 정리에 먹히지 않게
    return f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{body}</t></is></c>'


def _hf_text(s) -> str:
    """머리글·바닥글 글 — 엑셀 머리글 코드(&P·&N·&A)의 '&'와 겹치지 않게 글 속 '&'는 '&&'로."""
    return "&&".join(_clean(str(s or "")).split("&"))


def _sheet_xml(title, headers, widths, rows, *, selected: bool, opts: dict | None = None) -> str:
    """시트 하나. opts(보고용 시트 — 설계 변경 대장, 검토 Y3 M1): wrap(줄바꿈할 칸 번호 모음, 0부터) — 값 줄은 모두 위 맞춤,
    filter(자동 필터), print(A4 가로·폭 1쪽 맞춤·쪽 번호 — 머리줄 반복은 통합 문서의 이름 정의), header_right(머리글 오른쪽 글).
    행 높이는 적지 않는다 — 엑셀이 줄바꿈된 글에 맞춰 높이를 정한다."""
    opts = opts or {}
    head_row = 2 if title else 1
    tab = ' tabSelected="1"' if selected else ""
    wrap_cols = frozenset(opts.get("wrap") or ())
    top = bool(opts)
    xml = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           f'<worksheet xmlns="{NS_MAIN}" xmlns:r="{NS_REL}">'
           + ('<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>' if opts.get("print") else "")
           + '<sheetViews>'
           f'<sheetView workbookViewId="0"{tab}>'
           f'<pane ySplit="{head_row}" topLeftCell="A{head_row + 1}" activePane="bottomLeft" state="frozen"/>'
           f'<selection pane="bottomLeft" activeCell="A{head_row + 1}" sqref="A{head_row + 1}"/>'
           f'</sheetView></sheetViews><sheetFormatPr defaultRowHeight="16.5"/><cols>']
    for i, w in enumerate(widths, start=1):
        xml.append(f'<col min="{i}" max="{i}" width="{float(w):.1f}" customWidth="1"/>')
    xml.append("</cols><sheetData>")
    r = 1
    if title:
        xml.append(f'<row r="1" ht="22" customHeight="1">{_cell("A1", title, S_TITLE)}</row>')
        r = 2
    xml.append(f'<row r="{r}">' + "".join(_cell(f"{col_name(i)}{r}", h, S_HEAD) for i, h in enumerate(headers))
               + "</row>")
    for vals in rows:
        r += 1
        xml.append(f'<row r="{r}">' + "".join(_cell(f"{col_name(i)}{r}", v, S_PLAIN, top, i in wrap_cols)
                                             for i, v in enumerate(vals)) + "</row>")
    xml.append("</sheetData>")
    if opts.get("filter") and headers:
        # 머리줄부터 마지막 값 줄까지 — 프로젝트·구분·확인자로 거른다
        xml.append(f'<autoFilter ref="A{head_row}:{col_name(len(headers) - 1)}{max(r, head_row)}"/>')
    if opts.get("print"):
        # A4(9) 가로·폭 1쪽(높이는 쪽수 제한 없음)·인쇄 격자선 — 보고용으로 받은 사람이 손으로 맞추지 않게.
        # 머리글: 시트 이름(&A) · 생성 시각, 바닥글: 쪽 번호(&P / &N)
        xml.append('<printOptions gridLines="1"/>'
                   '<pageMargins left="0.4" right="0.4" top="0.6" bottom="0.6" header="0.25" footer="0.25"/>'
                   '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>'
                   '<headerFooter><oddHeader>' + escape("&L&A"
                                                        + (f"&R{_hf_text(opts['header_right'])}" if opts.get("header_right")
                                                           else ""))
                   + '</oddHeader><oddFooter>' + escape("&C&P / &N") + '</oddFooter></headerFooter>')
    xml.append("</worksheet>")
    return "".join(xml)


_STYLES = (
    f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="{NS_MAIN}">'
    '<numFmts count="2"><numFmt numFmtId="164" formatCode="yyyy-mm-dd"/>'
    '<numFmt numFmtId="165" formatCode="yyyy-mm-dd hh:mm"/></numFmts>'
    '<fonts count="3"><font><sz val="11"/><name val="맑은 고딕"/><family val="2"/></font>'
    '<font><b/><sz val="11"/><name val="맑은 고딕"/><family val="2"/></font>'
    '<font><b/><sz val="14"/><name val="맑은 고딕"/><family val="2"/></font></fonts>'
    '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
    '<fill><patternFill patternType="solid"><fgColor rgb="FFE8ECF4"/><bgColor indexed="64"/></patternFill></fill></fills>'
    '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
    '<border><left/><right/><top/><bottom style="thin"><color rgb="FF8E97A8"/></bottom><diagonal/></border></borders>'
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    '<cellXfs count="12"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
    '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>'
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" quotePrefix="1"/>'
    '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
    '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'      # 4 날짜
    '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'      # 5 날짜·시각
    # 6~11 보고용 시트 값 칸 (검토 Y3 M1) — 위 맞춤 · 줄바꿈 + 위 맞춤 · 수식 앞붙임 둘 · 날짜 둘
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top"/></xf>'
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1">'
    '<alignment vertical="top" wrapText="1"/></xf>'
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" quotePrefix="1" applyAlignment="1">'
    '<alignment vertical="top"/></xf>'
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" quotePrefix="1" applyAlignment="1">'
    '<alignment vertical="top" wrapText="1"/></xf>'
    '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1">'
    '<alignment vertical="top"/></xf>'
    '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1">'
    '<alignment vertical="top"/></xf></cellXfs>'
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')


def build_xlsx(sheets) -> bytes:
    """sheets: [(시트 이름, 제목 줄|None, [(머리, 너비)…], [[값…]…][, 꾸밈]), …] → xlsx 바이트 (메모리에서만).
    제목 줄이 있으면 1행 제목(굵게), 2행 머리(굵게·고정), 3행부터 값. 없으면 1행 머리.
    꾸밈(다섯째, 있으면 — 보고용 시트): {"wrap": 칸 번호들, "filter": True, "print": True, "header_right": 글} (_sheet_xml).
    print면 머리줄을 쪽마다 반복한다(통합 문서의 _xlnm.Print_Titles)."""
    sheets = [tuple(s) + ((None,) if len(s) < 5 else ()) for s in sheets]
    names = [str(s[0])[:31] for s in sheets]
    q = "'"

    def _ref(n: str) -> str:                  # 시트 이름 참조 — 'A''s 시트' (작은따옴표는 둘로)
        return q + (q + q).join(n.split(q)) + q
    titles = "".join(
        f'<definedName name="_xlnm.Print_Titles" localSheetId="{i}">'
        f'{escape(_clean(_ref(n)))}!${2 if s[1] else 1}:${2 if s[1] else 1}</definedName>'
        for i, (n, s) in enumerate(zip(names, sheets)) if (s[4] or {}).get("print"))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        overrides = "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="{CT_SHEET}"/>'
                            for i in range(1, len(sheets) + 1))
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   f'{overrides}</Types>')
        z.writestr("_rels/.rels",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{NS_PKG}">'
                   f'<Relationship Id="rId1" Type="{NS_REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="{NS_MAIN}" '
                   f'xmlns:r="{NS_REL}"><bookViews><workbookView/></bookViews><sheets>'
                   + "".join(f'<sheet name="{quoteattr_body(n)}" sheetId="{i}" r:id="rId{i}"/>'
                             for i, n in enumerate(names, start=1))
                   + "</sheets>" + (f"<definedNames>{titles}</definedNames>" if titles else "") + "</workbook>")
        rels = "".join(f'<Relationship Id="rId{i}" Type="{NS_REL}/worksheet" Target="worksheets/sheet{i}.xml"/>'
                       for i in range(1, len(sheets) + 1))
        z.writestr("xl/_rels/workbook.xml.rels",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{NS_PKG}">{rels}'
                   f'<Relationship Id="rId{len(sheets) + 1}" Type="{NS_REL}/styles" Target="styles.xml"/>'
                   f'</Relationships>')
        z.writestr("xl/styles.xml", _STYLES)
        for i, (_name, title, cols, rows, opts) in enumerate(sheets, start=1):
            z.writestr(f"xl/worksheets/sheet{i}.xml",
                       _sheet_xml(title, [c[0] for c in cols], [c[1] for c in cols], rows, selected=(i == 1), opts=opts))
    return buf.getvalue()


def as_date(text) -> date | None:
    """'2026-10-29…' → date (진짜 날짜 칸). 비었거나 깨졌으면 None(빈 칸)."""
    try:
        return date.fromisoformat(str(text or "")[:10])
    except ValueError:
        return None


def as_stamp(text) -> datetime | None:
    """'2026-10-29T14:03:22' → datetime(분까지). 비었거나 깨졌으면 None(빈 칸)."""
    try:
        return datetime.fromisoformat(str(text or "")[:16])
    except ValueError:
        return None


def purge_mark(h: dict) -> str | None:
    """개정 이력 9열 — '2029-03-12 정리 · 관리자' (정리하지 않은 판은 None = 빈 칸)."""
    at = str(h.get("purged_at") or "")
    if not at:
        return None
    who = str(h.get("purged_by") or "")
    return f"{at[:10]} 정리" + (f" · {who}" if who else "")


DOWNLOAD_COLUMNS = (("문서번호", 16), ("양식명", 24), ("판", 6), ("내려받은 사람", 18), ("때", 17))   # F2-13


def register_xlsx(reg: dict, *, generated_at: str, scope_text: str, include_retired: bool,
                  downloads: list | None = None) -> bytes:
    """store.register(history=True) 결과 → '문서 관리 대장' + '개정 이력' 두 시트.
    downloads: (기능 검토 F2-13) store.download_log 결과 — 주면 셋째 시트 '내려받은 기록'(양식·판·사람·때, 최근 것부터)."""
    rows = reg.get("rows") or []
    hist = reg.get("history") or []
    which = "폐기 포함" if include_retired else "현행만"
    main = []
    for r in rows:
        state = "폐기" if r["retired"] else "현행"
        if not r["retired"] and r["state"] in STATE_TEXT:
            state += f" ({STATE_TEXT[r['state']]})"
        main.append([r["doc_no"], r["top"], r["mid"], r["rest"], r["name"],
                     f"v{r['number']}" if r.get("number") else "", as_date(r["effective"]), r["approver"], r["reason"],
                     int(r["revisions"]), as_date(r["last_reviewed"]), None if r["retired"] else as_date(r["due"]),
                     state, ", ".join(r.get("prev_doc_nos") or []) or None,
                     " ".join(x for x in (r.get("doc_type") or "", r.get("doc_type_name") or "") if x) or None,
                     r.get("checker") or None,
                     as_date(r.get("retired_at")) if r["retired"] else None,
                     (r.get("retired_by") or None) if r["retired"] else None,
                     (r.get("retired_reason") or None) if r["retired"] else None])
    # 현행 끝 (ux21 forms 5) — 같은 양식의 다음 판 승인일. 판은 승인될 때마다 현행이 되므로 다음 판이 곧 끝이다
    cur_no = {r.get("id"): r.get("number") for r in rows if r.get("id") is not None}
    gone = {r.get("id"): str(r.get("retired_at") or "")[:10] for r in rows if r.get("retired") and r.get("id") is not None}
    nxt: dict = {}
    for h in hist:
        nxt[(h.get("form_id"), int(h["number"]) - 1)] = h["approved_at"]
    history = []
    for h in hist:
        end = nxt.get((h.get("form_id"), int(h["number"])))
        if end:
            end_v = as_stamp(end)
        elif h.get("form_id") in cur_no and cur_no[h.get("form_id")] == h["number"]:
            fid = h.get("form_id")
            end_v = (f"폐기 {gone[fid]}".strip() if fid in gone else "현행")
        else:
            end_v = None
        history.append([h["doc_no"], h["name"], f"v{int(h['number'])}", as_stamp(h["approved_at"]),
                        h["approver"], h["uploader"], h["reason"], h.get("checker") or None, purge_mark(h), end_v])
    sheets = [
        ("문서 관리 대장", f"문서 관리 대장 — 생성 {generated_at} · 양식 {len(rows)}개 ({which}) · 범위: {scope_text}",
         REGISTER_COLUMNS, main),
        ("개정 이력", f"개정 이력 — 생성 {generated_at} · 승인된 판 {len(hist)}개 ({which}) · 범위: {scope_text}",
         HISTORY_COLUMNS, history),
    ]
    if downloads is not None:
        dl = [[d["doc_no"], d["name"], f"v{int(d['number'])}", d["who"], as_stamp(d["at"])] for d in downloads]
        sheets.append(("내려받은 기록", f"내려받은 기록 — 생성 {generated_at} · {len(dl)}건 (감사 기록에 남은 것, 최근 것부터) "
                                    f"· 범위: {scope_text}", DOWNLOAD_COLUMNS, dl))
    retired = reg.get("retired")
    if retired and not include_retired:
        # 폐기한 양식 (ux21 forms 5) — '현행만' 대장에도 폐기 양식·폐기일·폐기자를 맨 끝 시트로 따로 남긴다.
        # '폐기 포함'이면 첫 시트에 이미 있다(17~19열). 앞 시트들의 차례는 그대로
        ret = [[r["doc_no"], r["top"], r["mid"], r["rest"], r["name"],
                f"v{r['number']}" if r.get("number") else "", as_date(r["effective"]), as_date(r.get("retired_at")),
                r.get("retired_by") or None, r.get("retired_reason") or None] for r in retired]
        sheets.append(("폐기한 양식", f"폐기한 양식 — 생성 {generated_at} · {len(ret)}개 · 범위: {scope_text}",
                       RETIRED_COLUMNS, ret))
    return build_xlsx(sheets)
