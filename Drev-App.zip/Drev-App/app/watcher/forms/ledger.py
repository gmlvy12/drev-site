# -*- coding: utf-8 -*-
"""문서 관리 대장 엑셀(xlsx) 만들기 (F7 ISO 문서 관리 대장, 2026-10-29).

- **메모리에서만** 만든다(zipfile + BytesIO) — 디스크에 아무것도 쓰지 않는다. openpyxl의 저장(save)은 시트마다
  %TEMP%에 임시 파일(openpyxl.*.xml)을 썼다 지우므로(3.1.5 worksheet/_writer.create_temporary_file) 쓰지 않고,
  엑셀이 읽는 최소 SpreadsheetML(통합 문서·시트·스타일)을 직접 적는다. 읽어 확인하는 쪽(시험)은 openpyxl.
- **수식 주입 막기**: 모든 글자 칸은 인라인 문자열(t="inlineStr")로 적어 수식(<f>)이 될 길이 없고,
  = + - @ 탭 CR로 시작하는 글자는 '작은따옴표 앞붙임'(quotePrefix) 스타일까지 준다 — 엑셀에서 칸을 고쳐도 글자로 남는다.
  (openpyxl에 '=…' 글자를 그냥 넣으면 수식으로 저장된다 — tests/test_forms_f7.py가 보인다.)
- 저장소(store)·쓰기 문(guard)을 import 하지 않는다 — 받은 사전만 바이트로 바꾼다.
"""

from __future__ import annotations

import io
import re
import zipfile
from datetime import date, datetime
from xml.sax.saxutils import escape

FORMULA_LEAD = ("=", "+", "-", "@", "\t", "\r")
_BAD_XML = re.compile("[\\x00-\\x08\\x0b\\x0c\\x0e-\\x1f\\ud800-\\udfff\\ufffe\\uffff]")   # 짝 없는 서로게이트는 UTF-8로 못 적는다
_MAX_CELL = 32767                         # 엑셀 한 칸 글자 상한

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_SHEET = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"

# 스타일 번호 (styles.xml의 cellXfs 차례)
S_PLAIN, S_HEAD, S_QUOTED, S_TITLE, S_DATE, S_STAMP = 0, 1, 2, 3, 4, 5
_EPOCH = datetime(1899, 12, 30)              # 엑셀 날짜 일련값 0 (1900-03-01 뒤 날짜는 이 기준이 맞다)

STATE_TEXT = {"overdue": "검토 기한 지남", "soon": "검토 기한 곧"}

REGISTER_COLUMNS = (            # (머리, 너비(글자))
    ("문서번호", 16), ("대분류", 12), ("중분류", 14), ("소분류 이하 경로", 18), ("양식명", 24), ("현행 판", 8),
    ("시행일", 11), ("승인자", 10), ("개정 사유", 36), ("개정 횟수", 9), ("최근 검토일", 11),
    ("다음 검토 기한", 13), ("상태", 18),
    ("이전 번호", 22),              # 14열 고정 — [다시 매기기] 전 번호(없으면 빈 칸). 매크로·VLOOKUP 열 참조가 안 깨지게
    ("문서 종류", 16),              # 15열 (F7 문서 종류) — 기호 + 이름(QP 절차서), 없으면 빈 칸. 앞 14열의 자리는 그대로
    ("1단계 검토자", 12))           # 16열 (2단계 승인, 2026-10-30) — 현행 판을 [검토 완료]한 사람, 1단계로 승인된 판은 빈 칸. 끝에만 더함
HISTORY_COLUMNS = (("문서번호", 16), ("양식명", 24), ("판", 6), ("승인일", 17), ("승인자", 10),
                   ("올린 사람", 10), ("사유", 44),
                   ("1단계 검토자", 10),            # 8열 (2단계 승인, 2026-10-30) — 앞 7열의 자리는 그대로
                   ("정리(보존 만료)", 20))         # 9열 (2026-10-31) — 파일을 정리한 날 + 사람, 아니면 빈 칸. 끝에만 더함


def looks_like_formula(value) -> bool:
    """엑셀이 수식으로 받을 수 있는 글자인가 — = + - @ 탭 CR로 시작."""
    return isinstance(value, str) and value.startswith(FORMULA_LEAD)


def _clean(text: str) -> str:
    text = _BAD_XML.sub("", text)
    if len(text) > _MAX_CELL // 2:            # 엑셀 상한은 UTF-16 단위 — 이모지 같은 글자는 둘로 센다
        text = text.encode("utf-16-le")[:_MAX_CELL * 2].decode("utf-16-le", "ignore")   # 잘린 반쪽은 버린다
    return text


def quoteattr_body(text: str) -> str:
    """속성 값 안에 넣을 글자 (따옴표까지 이스케이프)."""
    return escape(_clean(str(text)), {'"': "&quot;"})


def col_name(i: int) -> str:
    """0 → A, 25 → Z, 26 → AA."""
    out, n = "", i + 1
    while n:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


def _cell(ref: str, value, style: int) -> str:
    if value is None or value == "":
        return ""
    if isinstance(value, datetime):          # 진짜 날짜 칸 — 일련값 + 날짜 서식 (F7 검토 9)
        serial = (value - _EPOCH).total_seconds() / 86400
        return f'<c r="{ref}" s="{S_STAMP}"><v>{serial!r}</v></c>'
    if isinstance(value, date):
        return f'<c r="{ref}" s="{S_DATE}"><v>{(value - _EPOCH.date()).days}</v></c>'
    if isinstance(value, bool):
        value = "예" if value else "아니오"
    if isinstance(value, (int, float)):
        return f'<c r="{ref}" s="{style}"><v>{value}</v></c>'
    text = _clean(str(value))
    if looks_like_formula(text):
        style = S_QUOTED
    body = escape(text, {"\r": "&#13;"})               # CR이 XML 줄바꿈 정리에 먹히지 않게
    return f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{body}</t></is></c>'


def _sheet_xml(title, headers, widths, rows, *, selected: bool) -> str:
    head_row = 2 if title else 1
    tab = ' tabSelected="1"' if selected else ""
    xml = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           f'<worksheet xmlns="{NS_MAIN}" xmlns:r="{NS_REL}"><sheetViews>'
           f'<sheetView workbookViewId="0"{tab}>'
           f'<pane ySplit="{head_row}" topLeftCell="A{head_row + 1}" activePane="bottomLeft" state="frozen"/>'
           f'<selection pane="bottomLeft" activeCell="A{head_row + 1}" sqref="A{head_row + 1}"/>'
           f'</sheetView></sheetViews><sheetFormatPr defaultRowHeight="16.5"/><cols>']
    for i, w in enumerate(widths, start=1):
        xml.append(f'<col min="{i}" max="{i}" width="{float(w):.1f}" customWidth="1"/>')
    xml.append("</cols><sheetData>")
    r = 1
    if title:
        xml.append(f'<row r="1" ht="22" customHeight="1">{_cell("A1", title, S_TITLE)}</row>')
        r = 2
    xml.append(f'<row r="{r}">' + "".join(_cell(f"{col_name(i)}{r}", h, S_HEAD) for i, h in enumerate(headers))
               + "</row>")
    for vals in rows:
        r += 1
        xml.append(f'<row r="{r}">' + "".join(_cell(f"{col_name(i)}{r}", v, S_PLAIN) for i, v in enumerate(vals))
                   + "</row>")
    xml.append("</sheetData></worksheet>")
    return "".join(xml)


_STYLES = (
    f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="{NS_MAIN}">'
    '<numFmts count="2"><numFmt numFmtId="164" formatCode="yyyy-mm-dd"/>'
    '<numFmt numFmtId="165" formatCode="yyyy-mm-dd hh:mm"/></numFmts>'
    '<fonts count="3"><font><sz val="11"/><name val="맑은 고딕"/><family val="2"/></font>'
    '<font><b/><sz val="11"/><name val="맑은 고딕"/><family val="2"/></font>'
    '<font><b/><sz val="14"/><name val="맑은 고딕"/><family val="2"/></font></fonts>'
    '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
    '<fill><patternFill patternType="solid"><fgColor rgb="FFE8ECF4"/><bgColor indexed="64"/></patternFill></fill></fills>'
    '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
    '<border><left/><right/><top/><bottom style="thin"><color rgb="FF8E97A8"/></bottom><diagonal/></border></borders>'
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    '<cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
    '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>'
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" quotePrefix="1"/>'
    '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
    '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'      # 4 날짜
    '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs>'  # 5 날짜·시각
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')


def build_xlsx(sheets) -> bytes:
    """sheets: [(시트 이름, 제목 줄|None, [(머리, 너비)…], [[값…]…]), …] → xlsx 바이트 (메모리에서만).
    제목 줄이 있으면 1행 제목(굵게), 2행 머리(굵게·고정), 3행부터 값. 없으면 1행 머리."""
    sheets = list(sheets)
    names = [str(s[0])[:31] for s in sheets]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        overrides = "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="{CT_SHEET}"/>'
                            for i in range(1, len(sheets) + 1))
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   f'{overrides}</Types>')
        z.writestr("_rels/.rels",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{NS_PKG}">'
                   f'<Relationship Id="rId1" Type="{NS_REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="{NS_MAIN}" '
                   f'xmlns:r="{NS_REL}"><bookViews><workbookView/></bookViews><sheets>'
                   + "".join(f'<sheet name="{quoteattr_body(n)}" sheetId="{i}" r:id="rId{i}"/>'
                             for i, n in enumerate(names, start=1))
                   + "</sheets></workbook>")
        rels = "".join(f'<Relationship Id="rId{i}" Type="{NS_REL}/worksheet" Target="worksheets/sheet{i}.xml"/>'
                       for i in range(1, len(sheets) + 1))
        z.writestr("xl/_rels/workbook.xml.rels",
                   f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{NS_PKG}">{rels}'
                   f'<Relationship Id="rId{len(sheets) + 1}" Type="{NS_REL}/styles" Target="styles.xml"/>'
                   f'</Relationships>')
        z.writestr("xl/styles.xml", _STYLES)
        for i, (_name, title, cols, rows) in enumerate(sheets, start=1):
            z.writestr(f"xl/worksheets/sheet{i}.xml",
                       _sheet_xml(title, [c[0] for c in cols], [c[1] for c in cols], rows, selected=(i == 1)))
    return buf.getvalue()


def as_date(text) -> date | None:
    """'2026-10-29…' → date (진짜 날짜 칸). 비었거나 깨졌으면 None(빈 칸)."""
    try:
        return date.fromisoformat(str(text or "")[:10])
    except ValueError:
        return None


def as_stamp(text) -> datetime | None:
    """'2026-10-29T14:03:22' → datetime(분까지). 비었거나 깨졌으면 None(빈 칸)."""
    try:
        return datetime.fromisoformat(str(text or "")[:16])
    except ValueError:
        return None


def purge_mark(h: dict) -> str | None:
    """개정 이력 9열 — '2029-03-12 정리 · 관리자' (정리하지 않은 판은 None = 빈 칸)."""
    at = str(h.get("purged_at") or "")
    if not at:
        return None
    who = str(h.get("purged_by") or "")
    return f"{at[:10]} 정리" + (f" · {who}" if who else "")


def register_xlsx(reg: dict, *, generated_at: str, scope_text: str, include_retired: bool) -> bytes:
    """store.register(history=True) 결과 → '문서 관리 대장' + '개정 이력' 두 시트."""
    rows = reg.get("rows") or []
    hist = reg.get("history") or []
    which = "폐기 포함" if include_retired else "현행만"
    main = []
    for r in rows:
        state = "폐기" if r["retired"] else "현행"
        if not r["retired"] and r["state"] in STATE_TEXT:
            state += f" ({STATE_TEXT[r['state']]})"
        main.append([r["doc_no"], r["top"], r["mid"], r["rest"], r["name"],
                     f"v{r['number']}" if r.get("number") else "", as_date(r["effective"]), r["approver"], r["reason"],
                     int(r["revisions"]), as_date(r["last_reviewed"]), None if r["retired"] else as_date(r["due"]),
                     state, ", ".join(r.get("prev_doc_nos") or []) or None,
                     " ".join(x for x in (r.get("doc_type") or "", r.get("doc_type_name") or "") if x) or None,
                     r.get("checker") or None])
    history = [[h["doc_no"], h["name"], f"v{int(h['number'])}", as_stamp(h["approved_at"]),
                h["approver"], h["uploader"], h["reason"], h.get("checker") or None, purge_mark(h)] for h in hist]
    return build_xlsx([
        ("문서 관리 대장", f"문서 관리 대장 — 생성 {generated_at} · 양식 {len(rows)}개 ({which}) · 범위: {scope_text}",
         REGISTER_COLUMNS, main),
        ("개정 이력", f"개정 이력 — 생성 {generated_at} · 승인된 판 {len(hist)}개 ({which}) · 범위: {scope_text}",
         HISTORY_COLUMNS, history),
    ])
