# -*- coding: utf-8 -*-
"""양식함 '칸 글자 층' — 빈 양식(칸 이름·라벨만 있는 틀)의 차이를 칸 단위로 잡는다 (f6, 2026-10-29).

왜: 감시 엔진(extract → diff_documents)은 **값 행**을 비교한다. 값 행이 없는 머리글만 있는 시트·빈 칸 표는 행이 0개라
'사유' 칸을 더한 개정안도 "바뀐 것 없음"이 됐다(실사용 시험 f6). 양식은 대부분 비어 있는 틀이라 양식함에서는 치명적이다.
감시 엔진의 동작은 바꾸지 않는다 — 이 모듈은 양식함 비교 자식(watcher/worker.py의 form_compare·form_summary)에서만 쓴다.

- 엑셀(xlsx·xlsm·xltx·xltm): openpyxl read_only로 시트별 비어 있지 않은 칸(시트!주소 → 글자, 수식이면 수식 글자).
- 워드·한글(docx·dotx·dotm·hwpx): 감시 추출기와 **같은 표 읽기**(watcher.extract.docx의 _docx_parts·_hwpx_parts)로
  표 칸 글자. 표 번호가 엔진과 같아야 '엔진이 다룬 표'를 가릴 수 있다. 문단은 엔진이 이미 비교한다.
- 줄 맞춤: 줄(행)을 글자 차례로 맞춘 뒤(difflib) 짝지은 줄 안에서 칸을 글자 차례로 맞춘다 — 한 줄·한 칸을 끼워 넣어도
  아래가 전부 '바뀜'이 되지 않게.
- 합치기 규칙(DECISIONS 2026-10-29): 엔진 결과가 우선. 칸 층 줄은 **엔진 줄이 하나도 없는 시트·표**의 것만 보이고,
  그래도 엔진 줄과 이전 값·새 값이 똑같은 줄은 뺀다.
- 줄마다 이전 값 / 새 값 / 위치(시트!A1, 표1 행2 칸3)를 꼭 갖는다(원칙 4). 줄 수 상한 MAX_LINES(넘으면 '외 N곳').
- 파일은 읽기만 한다(openpyxl·zipfile이 읽기로 연다). 저장소·쓰기 문(guard)을 import 하지 않는다.
"""

from __future__ import annotations

import re
import zipfile
from datetime import date, datetime, time as dtime
from difflib import SequenceMatcher
from pathlib import Path

from watcher.forms.digest import KIND_TEXT, MAX_ROWS, MAX_VALUE

MAX_LINES = MAX_ROWS             # 근거 표 전체 줄 상한 (엔진 줄 + 칸 줄)
MAX_CELLS = 200_000              # 한 파일에서 읽는 칸 수 상한 — 넘으면 앞부분만 비교하고 참고 글을 남긴다
MAX_ALIGN = 3000                 # 줄 맞춤(difflib)을 하는 줄 수 상한 — 넘으면 줄 번호끼리 맞춘다
MAX_TEXT = 200                   # 줄 추가·삭제 줄에 늘어놓는 글자 상한
SIM_MIN = 0.34                   # 두 줄을 '같은 줄이 고쳐진 것'으로 볼 글자 닮음 하한

# 서식 파일 → 같은 길로 읽는 형식 (엔진 추출기는 확장자로 갈래를 고른다 — 서식은 내용 구조가 같다)
ALIAS = {".xltx": ".xlsx", ".xltm": ".xlsm", ".dotx": ".docx", ".dotm": ".docx"}
BOOK_EXTS = (".xlsx", ".xlsm", ".xltx", ".xltm")
DOC_EXTS = (".docx", ".dotx", ".dotm", ".hwpx")

# 칸 층 줄 종류 — digest.KIND_TEXT에 더해 쓴다 (화면 이름, 색 갈래)
LAYER_KINDS = {
    "CELL_CHANGED": ("칸 변경", "mod"),
    "CELL_ADDED": ("칸 추가", "add"),
    "CELL_REMOVED": ("칸 삭제", "rm"),
    "LINE_ADDED": ("줄 추가", "add"),
    "LINE_REMOVED": ("줄 삭제", "rm"),
    "LINE_MOVED": ("줄 이동", "info"),
    "TABLE_ADDED": ("표 추가", "add"),
    "TABLE_REMOVED": ("표 삭제", "rm"),
    "SHEET_ADDED": KIND_TEXT["SHEET_ADDED"],
    "SHEET_REMOVED": KIND_TEXT["SHEET_REMOVED"],
    "SHEET_RENAMED": KIND_TEXT["SHEET_RENAMED"],
}


def ext_of(path) -> str:
    return Path(str(path)).suffix.lower()


# ── 엔진 읽기 (서식 파일도) ──────────────────────────────────────────────────

def read_doc(path):
    """감시 엔진 추출 — 서식 파일(xltx·xltm·dotx·dotm)은 같은 구조의 추출기로 직접 읽는다. 읽지 못하는 형식은 None."""
    from watcher import extract as X
    p = Path(path)
    e = ext_of(p)
    if e not in ALIAS:
        return X.extract(p)
    X._check_zip_size(p)
    if ALIAS[e] in (".xlsx", ".xlsm"):
        from watcher.extract import xlsx
        doc = xlsx.extract(p)
    else:
        from watcher.extract import docx
        doc = docx.extract(p)
    if doc is None:
        return None
    doc.parts = X.embedded_parts(p)
    return doc.sanitized()


# ── 칸 글자 ─────────────────────────────────────────────────────────────

def cell_text(v) -> str:
    """칸 값 → 비교 글자. 빈칸은 ''. 수식은 수식 글자('=SUM(A1:A3)'), 정수꼴 실수는 정수로, 날짜는 ISO."""
    if v is None:
        return ""
    t = getattr(v, "text", None)               # 배열 수식 등 (openpyxl ArrayFormula)
    if t is not None and not isinstance(v, str):
        v = t
    if isinstance(v, bool):
        s = "TRUE" if v else "FALSE"
    elif isinstance(v, float):
        s = str(int(v)) if v.is_integer() and abs(v) < 1e15 else repr(v)
    elif isinstance(v, datetime):
        s = v.isoformat(sep=" ")
        if s.endswith(" 00:00:00"):
            s = s[:-9]
    elif isinstance(v, (date, dtime)):
        s = v.isoformat()
    else:
        s = str(v)
    s = " ".join(s.split())
    return s if len(s) <= MAX_VALUE else s[:MAX_VALUE] + "…"


def col_letter(n: int) -> str:
    out = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


class _Budget:
    def __init__(self, cap: int = MAX_CELLS):
        self.left = int(cap)
        self.cut = False

    def take(self) -> bool:
        if self.left <= 0:
            self.cut = True
            return False
        self.left -= 1
        return True


def book_grids(path, budget: _Budget | None = None) -> list:
    """엑셀 → [(시트 이름, [(행 번호, [(열 번호, 글자), …]), …]), …] — 비어 있지 않은 칸만, 시트 차례대로."""
    import openpyxl
    budget = budget or _Budget()
    wb = openpyxl.load_workbook(Path(path), read_only=True, data_only=False)
    try:
        out = []
        for ws in wb.worksheets:
            try:
                ws.reset_dimensions()                  # 머리의 dimension이 낡았어도 실제 칸을 다 읽게
            except AttributeError:
                pass
            rows = []
            for row in ws.iter_rows():
                cells = []
                for c in row:
                    t = cell_text(getattr(c, "value", None))
                    if t and getattr(c, "column", None) and budget.take():
                        cells.append((int(c.column), t))
                if cells:
                    rows.append((_row_no(row), cells))
                if budget.cut:
                    break
            out.append((str(ws.title), rows))
            if budget.cut:
                break
        return out
    finally:
        wb.close()


def _row_no(row) -> int:
    for c in row:
        r = getattr(c, "row", None)
        if r:
            return int(r)
    return 0


def doc_grids(path, budget: _Budget | None = None, offsets: dict | None = None) -> list:
    """워드·한글 → [('표1', [(행 번호, [(칸 번호, 글자), …]), …]), …] — 감시 추출기와 같은 표 읽기·같은 번호.
    offsets: 주면 {표: 엔진 행 번호에 더할 수} — 엔진은 표 위 병합 제목 행을 떼고 행을 센다(_title_row)."""
    from watcher.extract.docx import _docx_parts, _hwpx_parts, _title_row
    budget = budget or _Budget()
    with zipfile.ZipFile(Path(path)) as z:                  # 읽기 전용 열기
        if ext_of(path) == ".hwpx":
            _paras, tables = _hwpx_parts(z)
        else:
            _paras, tables = _docx_parts(z, {}, {})
    out = []
    for ti, tbl in enumerate(tables, start=1):
        if offsets is not None:
            try:
                offsets[f"표{ti}"] = 1 if tbl and _title_row(tbl) else 0
            except Exception:
                offsets[f"표{ti}"] = 0
        rows = []
        for ri, r in enumerate(tbl or [], start=1):
            cells = []
            for ci, v in enumerate(r or [], start=1):
                t = cell_text(v)
                if t and budget.take():
                    cells.append((ci, t))
            if cells:
                rows.append((ri, cells))
        out.append((f"표{ti}", rows))
        if budget.cut:
            break
    return out


# ── 줄 맞춤 ─────────────────────────────────────────────────────────────

def _sig(row) -> tuple:
    return tuple(t for _c, t in row[1])


def _ratio(a: tuple, b: tuple) -> float:
    if not a and not b:
        return 1.0
    return SequenceMatcher(None, a, b, autojunk=False).ratio()


def _pair_block(olds: list, news: list) -> tuple[list, list, list]:
    """바뀐 덩어리 안에서 짝짓기 — 차례를 지키며 글자가 닮은 줄끼리, 남은 것 가운데 줄 번호가 같은 것끼리.
    돌려줌 (짝들, 짝 없는 옛 줄들, 짝 없는 새 줄들)."""
    pairs, used_old = [], set()
    j = 0
    for n in news:
        best, best_k = 0.0, None
        for k in range(j, len(olds)):
            r = _ratio(_sig(olds[k]), _sig(n))
            if r > best:
                best, best_k = r, k
        if best_k is not None and best >= SIM_MIN:
            pairs.append((olds[best_k], n))
            used_old.add(best_k)
            j = best_k + 1
    paired_new = {id(n) for _o, n in pairs}
    rest_old = [o for k, o in enumerate(olds) if k not in used_old]
    rest_new = [n for n in news if id(n) not in paired_new]
    by_no = {o[0]: o for o in rest_old}
    for n in list(rest_new):
        o = by_no.pop(n[0], None)
        if o is not None:                                  # 같은 자리 줄을 고쳐 쓴 것 ('결재' → '승인')
            pairs.append((o, n))
            rest_old = [x for x in rest_old if x is not o]
            rest_new = [x for x in rest_new if x is not n]
    pairs.sort(key=lambda p: p[1][0])
    return pairs, rest_old, rest_new


def align_rows(old: list, new: list) -> tuple[list, list, list]:
    """두 줄 목록 → (짝지은 줄들, 사라진 줄들, 새로 생긴 줄들). 글자가 똑같은 줄은 빼고 돌려준다."""
    if len(old) > MAX_ALIGN or len(new) > MAX_ALIGN:
        o_by, n_by = {r[0]: r for r in old}, {r[0]: r for r in new}
        pairs = [(o_by[k], n_by[k]) for k in sorted(set(o_by) & set(n_by)) if _sig(o_by[k]) != _sig(n_by[k])]
        return pairs, [o_by[k] for k in sorted(set(o_by) - set(n_by))], [n_by[k] for k in sorted(set(n_by) - set(o_by))]
    sm = SequenceMatcher(None, [_sig(r) for r in old], [_sig(r) for r in new], autojunk=False)
    pairs, gone, added = [], [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        p, ro, rn = _pair_block(old[i1:i2], new[j1:j2])
        pairs += p
        gone += ro
        added += rn
    return pairs, gone, added


def _cell_ops(o_cells: list, n_cells: list) -> list:
    """한 줄 안의 칸 맞춤 → [(종류, 옛 (열, 글자)|None, 새 (열, 글자)|None)] — 글자가 같은 칸은 빼고."""
    ot, nt = [t for _c, t in o_cells], [t for _c, t in n_cells]
    out = []
    for tag, i1, i2, j1, j2 in SequenceMatcher(None, ot, nt, autojunk=False).get_opcodes():
        if tag == "equal":
            continue
        a, b = o_cells[i1:i2], n_cells[j1:j2]
        k = min(len(a), len(b)) if tag == "replace" else 0
        for x, y in zip(a[:k], b[:k]):
            out.append(("CELL_CHANGED", x, y))
        for x in a[k:]:
            out.append(("CELL_REMOVED", x, None))
        for y in b[k:]:
            out.append(("CELL_ADDED", None, y))
    return out


# ── 근거 줄 만들기 ───────────────────────────────────────────────────────

def _line(kind: str, name: str, old: str, new: str, where: str, unit: str, *, texts=None, at=None) -> dict:
    """근거 줄 하나 — digest.describe의 줄과 같은 꼴(+ layer·unit). 겹침 판정용(합칠 때 뗌): texts = 줄 줄의 칸 글자들,
    at = ((옛 시트, 옛 행)|None, (새 시트, 새 행)|None)."""
    from watcher.forms.digest import word_segments
    label, tone = LAYER_KINDS.get(kind, (kind, "info"))
    if kind == "CELL_CHANGED" and old and new:
        op, np_ = word_segments(old, new)
    else:
        op, np_ = ([[old, False]] if old else []), ([[new, False]] if new else [])
    out = {"kind": kind, "kind_label": label, "tone": tone, "name": name, "label": "", "old": old, "new": new,
           "where": where, "old_parts": op, "new_parts": np_, "layer": "cell", "unit": unit}
    if texts:
        out["texts"] = [str(t) for t in texts][:200]
    if at:
        out["at"] = at
    return out


def _joined(cells: list, addr) -> str:
    s = " · ".join(f"{addr(c)} {t}" for c, t in cells)
    return s if len(s) <= MAX_TEXT else s[:MAX_TEXT] + "…"


def _book_place(sheet: str):
    def cell(r: int, c: int) -> tuple[str, str]:
        a = f"{col_letter(c)}{r}"
        return a, f"{sheet}!{a}"

    def line(r: int, cells: list) -> tuple[str, str]:
        first, last = col_letter(cells[0][0]), col_letter(cells[-1][0])
        return f"{r}행", f"{sheet}!{first}{r}" + (f":{last}{r}" if last != first else "")
    return cell, line, (lambda c: col_letter(c))


def _doc_place(table: str):
    def cell(r: int, c: int) -> tuple[str, str]:
        return f"행{r} 칸{c}", f"{table} 행{r} 칸{c}"

    def line(r: int, cells: list) -> tuple[str, str]:
        return f"행{r}", f"{table} 행{r}"
    return cell, line, (lambda c: f"칸{c}")


def grid_lines(old_rows: list, new_rows: list, place, unit: str, old_unit: str | None = None) -> list:
    """한 시트(표)의 두 칸 목록 → 근거 줄들. place = (칸 자리, 줄 자리, 칸 이름) 함수 셋. old_unit: 이름이 바뀐 시트의 옛 이름."""
    cell_at, line_at, short = place
    ou = old_unit or unit
    pairs, gone, added = align_rows(old_rows, new_rows)
    out = []
    for o, n in pairs:
        for kind, x, y in _cell_ops(o[1], n[1]):
            if y is not None:
                name, where = cell_at(n[0], y[0])
                if x is not None:
                    oname, _w = cell_at(o[0], x[0])
                    if oname != name:
                        where += f" (이전 {oname})"
            else:
                name, where = cell_at(o[0], x[0])
            out.append(_line(kind, name, x[1] if x else "", y[1] if y else "", where, unit,
                             at=((ou, o[0]), (unit, n[0]))))
    # 글자가 똑같은 줄이 사라지고 다른 자리에 생겼으면 '줄 이동' 한 줄로
    moved = []
    for r in list(added):
        o = next((g for g in gone if _sig(g) == _sig(r)), None)
        if o is not None:
            gone = [g for g in gone if g is not o]
            added = [a for a in added if a is not r]
            moved.append((o, r))
    for o, r in moved:
        name, where = line_at(r[0], r[1])
        oname, _w = line_at(o[0], o[1])
        t = _joined(r[1], short)
        out.append(_line("LINE_MOVED", name, t, t, f"{where} (이전 {oname})", unit, texts=_sig(r),
                         at=((ou, o[0]), (unit, r[0]))))
    for r in gone:
        name, where = line_at(r[0], r[1])
        out.append(_line("LINE_REMOVED", name, _joined(r[1], short), "", where, unit, texts=_sig(r),
                         at=((ou, r[0]), None)))
    for r in added:
        name, where = line_at(r[0], r[1])
        out.append(_line("LINE_ADDED", name, "", _joined(r[1], short), where, unit, texts=_sig(r),
                         at=(None, (unit, r[0]))))
    return out


def _first_texts(rows: list, n: int = 6) -> str:
    ts = [t for _r, cells in rows for _c, t in cells][:n]
    s = " · ".join(ts)
    return s if len(s) <= MAX_TEXT else s[:MAX_TEXT] + "…"


def book_layer(old_path, new_path) -> dict:
    """엑셀 두 파일 → {units: [{unit, lines}], notes} — 시트 이름으로 맞추고, 사라진·생긴 시트가 같은 자리면 이름 바꿈."""
    budget = _Budget()
    og, ng = book_grids(old_path, budget), book_grids(new_path, budget)
    o_by, n_by = dict(og), dict(ng)
    o_names, n_names = [s for s, _ in og], [s for s, _ in ng]
    gone = [s for s in o_names if s not in n_by]
    added = [s for s in n_names if s not in o_by]
    renamed = {}
    for s in gone:
        i = o_names.index(s)
        if i < len(n_names) and n_names[i] in added and n_names[i] not in renamed.values():
            renamed[s] = n_names[i]
    units = []
    for i, s in enumerate(n_names):
        lines = []
        src = next((o for o, nn in renamed.items() if nn == s), None)
        if src is not None:
            lines.append(_line("SHEET_RENAMED", s, src, s, f"시트 탭 {i + 1}번째", s))
            lines += grid_lines(o_by[src], n_by[s], _book_place(s), s, old_unit=src)
        elif s in o_by:
            lines += grid_lines(o_by[s], n_by[s], _book_place(s), s)
        else:
            lines.append(_line("SHEET_ADDED", s, "", f"{s} — {_first_texts(n_by[s]) or '빈 시트'}",
                               f"시트 탭 {i + 1}번째", s))
        if lines:
            units.append({"unit": s, "lines": lines})
    for s in gone:
        if s in renamed:
            continue
        units.append({"unit": s, "lines": [_line("SHEET_REMOVED", s, f"{s} — {_first_texts(o_by[s]) or '빈 시트'}", "",
                                                 f"시트 탭 {o_names.index(s) + 1}번째(이전)", s)]})
    notes = [f"칸이 아주 많아 앞의 {MAX_CELLS:,}칸까지만 칸 단위로 비교했습니다"] if budget.cut else []
    return {"units": units, "notes": notes, "grids": (o_by, n_by)}


def doc_layer(old_path, new_path, offsets: tuple | None = None) -> dict:
    """워드·한글 두 파일 → 표마다 칸 줄. 표는 차례(번호)로 맞춘다 — 엔진과 같은 번호.
    offsets: (옛 {표: 더할 수}, 새 {…}) 를 채운다 — 엔진 행 번호를 이 층의 행 번호로 옮기려고."""
    budget = _Budget()
    oo, no = offsets if offsets else ({}, {})
    og, ng = doc_grids(old_path, budget, oo), doc_grids(new_path, budget, no)
    units = []
    for k in range(max(len(og), len(ng))):
        if k < len(og) and k < len(ng):
            t = ng[k][0]
            lines = grid_lines(og[k][1], ng[k][1], _doc_place(t), t)
        elif k < len(ng):
            t = ng[k][0]
            lines = [_line("TABLE_ADDED", t, "", _first_texts(ng[k][1]) or "빈 표", t, t)]
        else:
            t = og[k][0]
            lines = [_line("TABLE_REMOVED", t, _first_texts(og[k][1]) or "빈 표", "", f"{t}(이전)", t)]
        if lines:
            units.append({"unit": t, "lines": lines})
    notes = [f"칸이 아주 많아 앞의 {MAX_CELLS:,}칸까지만 칸 단위로 비교했습니다"] if budget.cut else []
    return {"units": units, "notes": notes, "grids": (dict(og), dict(ng))}


_BOOK_ROW = re.compile(r"^(.*)!행(\d+)")
_DOC_ROW = re.compile(r"^(표\d+)[ !]행(\d+)")


HEAD_SHARE = 0.6                 # 줄 글자의 이만큼 이상이 엔진 열 이름이면 엔진의 머리글 줄로 본다


def _key(s) -> str:
    return " ".join(str(s or "").split()).upper()


def engine_rows(doc, *, book: bool, offsets: dict | None = None, grids: dict | None = None) -> dict:
    """엔진이 읽은 표 자리 {시트(표): {행 번호…}} — 이 행들의 비교는 엔진 몫이다(칸 층이 겹쳐 말하지 않게).
    값 행: 엑셀은 'BOM!행3'의 3이 시트 행 번호 그대로, 문서는 '표1 행2'에 제목 행 몫(offsets)을 더한다.
    머리글 줄: 값 행이 있는 시트(표)에서, 칸 글자의 HEAD_SHARE 이상이 엔진 열 이름(값 행의 칸 이름)인 줄 — 엔진이 열 추가·
    이름 바꿈·이동(COL_*)으로 본다. 값 행이 없는 머리글만의 빈 양식은 엔진이 열을 비교하지 않으므로 여기 들지 않는다."""
    out: dict = {}
    heads: dict = {}
    for r in getattr(doc, "rows", None) or []:
        w = str(getattr(r, "where", "") or "")
        m = (_BOOK_ROW if book else _DOC_ROW).match(w)
        if not m:
            continue
        unit, n = m.group(1), int(m.group(2))
        if not book:
            n += int((offsets or {}).get(unit, 0))
        out.setdefault(unit, set()).add(n)
        heads.setdefault(unit, set()).update(_key(k) for k in (getattr(r, "values", None) or {}))
    for unit, rows in (grids or {}).items():
        names = heads.get(unit)
        if not names:
            continue
        for rno, cells_ in rows:
            ts = [_key(t) for _c, t in cells_]
            if ts and sum(1 for t in ts if t in names) >= HEAD_SHARE * len(ts):
                out[unit].add(rno)
    return out


def layer_for(old_path, new_path, old_doc=None, new_doc=None) -> dict | None:
    """두 파일의 칸 층 — 엑셀끼리·문서끼리만. 다른 형식(pdf·dxf)은 None (엔진이 글줄로 이미 읽는다).
    old_doc·new_doc(엔진 추출 결과)을 주면 엔진이 읽은 표 자리를 layer['engine']에 적는다(merge가 쓴다)."""
    oe, ne = ext_of(old_path), ext_of(new_path)
    if oe in BOOK_EXTS and ne in BOOK_EXTS:
        out = book_layer(old_path, new_path)
        go, gn = out.pop("grids")
        out["engine"] = (engine_rows(old_doc, book=True, grids=go), engine_rows(new_doc, book=True, grids=gn))
        return out
    if oe in DOC_EXTS and ne in DOC_EXTS:
        offs = ({}, {})
        out = doc_layer(old_path, new_path, offs)
        go, gn = out.pop("grids")
        out["engine"] = (engine_rows(old_doc, book=False, offsets=offs[0], grids=go),
                         engine_rows(new_doc, book=False, offsets=offs[1], grids=gn))
        return out
    return None


# ── 엔진 결과와 합치기 ───────────────────────────────────────────────────

_TABLE_WHERE = re.compile(r"^(표\d+)(?=[ !(]|$)")


def unit_of(where: str) -> str:
    """엔진 근거 줄의 위치 → 시트(표) 이름. '잔업집계!제목' → '잔업집계', '표1 행2' → '표1', '잔업집계' → '잔업집계'."""
    w = str(where or "").strip()
    m = _TABLE_WHERE.match(w)
    if m:
        return m.group(1)
    return w.split("!", 1)[0] if "!" in w else w


def _norm(s) -> str:
    return " ".join(str(s or "").split())


_SPLIT = re.compile(r"[\s·:,|—]+")


def _tokens(rows: list) -> set:
    """엔진 근거 줄에 나온 글자 조각 — 항목 이름·이전 값·새 값·부제를 통째로, 그리고 낱말(공백·'·'·':'·','로 나눔)로."""
    out: set = set()
    for r in rows:
        for k in ("name", "old", "new", "label"):
            s = _norm(r.get(k))
            if s:
                out.add(s)
                out.update(t for t in _SPLIT.split(s) if t)
    return out


def _line_texts(ln: dict) -> list:
    """칸 층 줄이 말하는 칸 글자들 — 칸 줄은 그 값, 줄 줄은 줄 안의 칸 글자(주소 머리를 떼고)."""
    if ln["kind"] == "CELL_ADDED":
        return [ln["new"]]
    if ln["kind"] == "CELL_REMOVED":
        return [ln["old"]]
    if ln["kind"] == "CELL_CHANGED":
        return [ln["new"]]
    texts = ln.get("texts")
    return list(texts) if texts else [ln["new"] or ln["old"]]


def merge(engine_rows: list, layer: dict | None) -> tuple[list, list]:
    """엔진 줄 + 칸 층 → (근거 줄들, 참고 글들). 규칙(DECISIONS 2026-10-29 f6):
    ⓪ 엔진이 값 행으로 읽은 행(layer["engine"])의 칸 줄은 뺀다 — 그 행의 비교는 엔진 몫이다(엔진이 일부러 접은 숫자 표기·
       순번 다시 매김도 다시 꺼내지 않는다). 칸 층은 머리글·제목·라벨·결재란처럼 엔진이 값 행으로 읽지 않은 칸을 맡는다.
    ① 엔진 줄은 그대로 앞에.
    ② 칸 층 줄은 엔진이 이미 말한 것을 빼고 더한다 — (이전 값, 새 값) 짝이 엔진 줄과 같거나, 그 칸 글자(줄이면 모든 칸 글자)가
       엔진 줄 글자(항목 이름·이전 값·새 값, 통째 또는 낱말)에 이미 나오면 겹친 근거로 보고 뺀다.
       칸을 고친 줄(CELL_CHANGED)은 새 값이 엔진 글자에 있고 이전 값도 엔진 글자에 있을 때만 뺀다.
    ③ 줄 이동(LINE_MOVED)은 그 시트·표에 엔진 줄이 하나라도 있으면 뺀다(엔진이 행 순서를 따로 본다).
    ④ 합쳐 MAX_LINES줄 — 넘으면 '외 N곳'."""
    rows = list(engine_rows or [])
    if not layer:
        return rows, []
    covered = {unit_of(r.get("where", "")) for r in rows}
    pairs = {(_norm(r.get("old")), _norm(r.get("new"))) for r in rows}
    toks = _tokens(rows)

    def seen(t) -> bool:
        return _norm(t) in toks

    e_old, e_new = layer.get("engine") or ({}, {})

    def engine_row(ln) -> bool:
        """그 줄이 엔진이 비교한 행인가 — 짝지은 줄은 옛 행·새 행 **둘 다** 엔진 행일 때만(한쪽만이면 엔진이 그 행을
        서로 다르게 읽은 것이라 칸 층이 말한다), 생긴 줄은 새 행, 사라진 줄은 옛 행."""
        o, n = ln.get("at") or (None, None)
        in_o = bool(o) and o[1] in e_old.get(o[0], ())
        in_n = bool(n) and n[1] in e_new.get(n[0], ())
        if o and n:
            return in_o and in_n
        return in_o or in_n

    extra = []
    for u in layer.get("units") or []:
        for ln in u["lines"]:
            if engine_row(ln):
                continue                             # ⓪ 엔진이 값 행으로 읽은 줄 — 엔진 몫 (바뀐 것 없음이라 해도)
            if rows and (_norm(ln["old"]), _norm(ln["new"])) in pairs:
                continue
            if ln["kind"] == "LINE_MOVED" and u["unit"] in covered:
                continue
            if rows and ln["kind"] == "CELL_CHANGED":
                if seen(ln["new"]) and seen(ln["old"]):
                    continue
            elif rows and ln["kind"].startswith("SHEET_"):
                if any(r.get("kind") == ln["kind"] and _norm(r.get("name")) == _norm(ln["name"]) for r in rows):
                    continue
            elif rows and all(seen(t) for t in _line_texts(ln)):
                continue
            ln = dict(ln)
            ln.pop("texts", None)                    # 겹침 판정용 — 캐시·화면에는 싣지 않는다
            ln.pop("at", None)
            extra.append(ln)
    notes = list(layer.get("notes") or [])
    room = max(0, MAX_LINES - len(rows))
    if len(extra) > room:
        notes.append(f"칸 변경이 많아 앞의 {room}곳만 보입니다 (외 {len(extra) - room}곳) — 파일을 내려받아 확인하세요")
        extra = extra[:room]
    return rows + extra, notes


# ── 새 양식 요약에 칸 글자 ─────────────────────────────────────────────────

def summary_cells(path, *, units: int = 6, per_unit: int = 24, width: int = 40) -> list:
    """새 양식 요약용 [[시트(표), [칸 글자…]], …] — 빈 양식에서도 칸 이름이 보이게. 같은 글자는 한 번, 긴 글은 자른다."""
    e = ext_of(path)
    budget = _Budget(20_000)
    if e in BOOK_EXTS:
        grids = book_grids(path, budget)
    elif e in DOC_EXTS:
        grids = doc_grids(path, budget)
    else:
        return []
    out = []
    for unit, rows in grids:
        seen, ts = set(), []
        for _r, cells in rows:
            for _c, t in cells:
                s = t if len(t) <= width else t[:width] + "…"
                if s not in seen:
                    seen.add(s)
                    ts.append(s)
                if len(ts) >= per_unit:
                    break
            if len(ts) >= per_unit:
                break
        if ts:
            out.append([unit, ts])
        if len(out) >= units:
            break
    return out
