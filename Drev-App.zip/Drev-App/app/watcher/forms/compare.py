# -*- coding: utf-8 -*-
"""양식함 자동 비교 — 두 판(또는 검토 대기 파일)을 감시 엔진으로 비교해 '근거 표'를 만든다 (FORMS.md 4절 2, F3 2026-10-28).

- 엔진은 감시와 같다: extract → diff_documents. 감시 엔진 동작은 바꾸지 않는다.
- 추출·비교는 **자식 프로세스**(watcher/worker.py의 ExtractWorker, form_compare 요청)에서 시간 상한(기본 60초)을 두고 돈다.
  멈추거나 깨진 파일은 "비교할 수 없음(이유)"으로 돌려줄 뿐 화면 서버는 멈추거나 죽지 않는다.
- 파일은 보관소에서 **읽기만** 한다(자식의 추출기가 'rb'로 연다). 이 모듈은 파일을 쓰지 않는다 — 결과 캐시는 store가 forms.db에.
- 같은 (이전 지문, 새 지문) 쌍의 결과는 forms.db에 캐시한다. 실패는 잠깐(FAIL_TTL)만 기억한다 — 바쁜 때의 시간 초과가 굳지 않게.
- 비교용 파일 경로는 store.version_source / submission_source로 얻는다 — 권한은 확인하고 '내려받음' 감사 기록은 남기지 않는다.
- 비교 실패는 감사 기록('compare_fail')에 남긴다.
"""

from __future__ import annotations

import json
import logging
import os
import threading

from watcher.forms.store import FormsStore, NotFound

log = logging.getLogger("drev.forms.compare")

COMPARE_TIMEOUT = 60.0         # 초 — 비교 한 번(두 파일 추출 + 비교)의 상한
MAX_WORKERS = 2                # 동시에 도는 비교 자식 수 — 넘치면 앞 비교가 끝나기를 기다린다
ENGINE = "f6.1"                # 근거 표 꼴이 바뀌면 올린다 — 캐시 열쇠에 들어가 옛 결과를 쓰지 않게
                               # f6.1(2026-10-29): 칸 글자 층 — 옛 '빈 양식은 바뀐 것 없음' 결과가 다시 쓰이지 않게
FAIL_TTL = 600.0               # 실패 결과를 기억하는 시간(초)

# 글자 비교를 하는 형식 (감시 엔진이 내용을 읽는 형식 — watcher.extract.READABLE_EXTS와 같게, 시험이 대조)
READABLE = (".dxf", ".pdf", ".xlsx", ".xlsm", ".docx", ".hwpx")
# 서식 파일(양식 그 자체, f6) — 같은 구조라 같은 추출기로 읽는다 (watcher/forms/cells.py ALIAS)
TEMPLATES = (".xltx", ".xltm", ".dotx", ".dotm")
# 서로 비교해도 되는 형식 묶음 — 묶음이 다르면(엑셀 → 워드) 글자 비교를 하지 않는다
_FAMILY = {".xlsx": "표", ".xlsm": "표", ".xltx": "표", ".xltm": "표", ".docx": "문서", ".dotx": "문서",
           ".dotm": "문서", ".hwpx": "문서", ".pdf": "pdf", ".dxf": "dxf"}

UNSUPPORTED_TEXT = "글자 비교를 지원하지 않는 형식 — 파일을 내려받아 확인하세요"


def _ext(filename) -> str:
    return os.path.splitext(str(filename or ""))[1].lower()


def _readable(e: str) -> bool:
    return e in READABLE or e in TEMPLATES


def supported(filename) -> bool:
    return _readable(_ext(filename))


def _reason(exc: BaseException, timeout: float) -> str:
    """자식에서 난 일 → 화면에 보일 쉬운 이유. 보관소 경로·내부 글은 내지 않는다."""
    from watcher.worker import ExtractTimeout, RemoteError
    if isinstance(exc, ExtractTimeout):
        return f"{int(timeout)}초 안에 끝나지 않아 멈췄습니다 — 파일이 너무 크거나 복잡합니다"
    if isinstance(exc, RemoteError):
        t = exc.error_type
        if t == "TooLargeToRead":
            return str(exc)[:300]
        if t in ("WorkerDied", "BrokenPipe", "BadResponse", "ConfigLost"):
            return "비교 프로그램이 도중에 끝났습니다 (메모리 부족일 수 있습니다)"
        if exc.transient:
            return "파일을 읽는 중 일시적인 문제가 생겼습니다 — 잠시 뒤 다시 열어 보세요"
        return f"파일을 읽지 못했습니다 — 깨졌거나 암호가 걸린 파일일 수 있습니다 ({t or '알 수 없음'})"
    return "비교 프로그램을 실행하지 못했습니다"


class _Busy(Exception):
    """비교 자리가 모두 차 기다리다 시간이 다 됐다."""


class Comparer:
    """화면 서버가 하나 쥐는 비교기. 자식 프로세스를 몇 개(max_workers) 돌려 쓰고 결과를 캐시한다.

    timeout: 비교 한 번 상한(초). command: 자식 명령(시험에서 멈춘 자식 흉내) — 없으면 감시와 같은 worker_command()."""

    def __init__(self, store: FormsStore, *, timeout: float = COMPARE_TIMEOUT, max_workers: int = MAX_WORKERS,
                 command: list | None = None):
        self.store = store
        self.timeout = float(timeout)
        self.command = command
        self._slots = threading.BoundedSemaphore(max(1, int(max_workers)))
        self._idle: list = []
        self._lock = threading.Lock()
        self._closed = False
        self._auto: set = set()   # 검토 화면이 자동으로 비교해 본 제출 id (대기 1건당 1회, 보안 F3)
        self.computed = 0          # 실제로 자식에게 맡긴 횟수 (시험·진단용)
        self.hits = 0              # 캐시 적중 횟수

    # ── 자식 다루기 ─────────────────────────────────────────────────────
    def _request(self, req: dict) -> dict:
        from watcher.worker import ExtractWorker
        if not self._slots.acquire(timeout=self.timeout):
            raise _Busy()
        w = None
        try:
            with self._lock:
                w = self._idle.pop() if self._idle else None
            if w is None:
                w = ExtractWorker(timeout=self.timeout, command=list(self.command) if self.command else None)
            self.computed += 1
            return w.request(req, timeout=self.timeout)
        finally:
            if w is not None:
                with self._lock:
                    keep = not self._closed and w.alive() and len(self._idle) < 4
                    if keep:
                        self._idle.append(w)
                if not keep:
                    w.close()
            self._slots.release()

    def drop_idle(self) -> None:
        """쉬고 있는 자식을 모두 끝낸다 — 다음 비교는 새 자식으로 (명령·설정을 바꾼 뒤)."""
        with self._lock:
            idle, self._idle = self._idle, []
        for w in idle:
            try:
                w.close()
            except Exception:
                pass

    def close(self) -> None:
        with self._lock:
            self._closed = True
        self.drop_idle()

    # ── 캐시 ─────────────────────────────────────────────────────────────
    def _cache_get(self, key: str):
        row = self.store.compare_cache_get(key)
        if row is None:
            return None
        if row["status"] != "ok" and self.store.clock() - float(row["created_at"]) > FAIL_TTL:
            return None
        try:
            res = json.loads(row["result"])
        except ValueError:
            return None
        res["cached"] = True
        self.hits += 1
        return res

    def _cache_put(self, key: str, res: dict) -> None:
        try:
            self.store.compare_cache_put(key, "ok" if res["status"] in ("ok", "new") else "failed",
                                         json.dumps(res, ensure_ascii=False))
        except Exception:                       # 캐시는 덤 — 못 적어도 화면은 보인다
            log.exception("비교 캐시를 적지 못함")

    # ── 비교 ─────────────────────────────────────────────────────────────
    def compare_paths(self, old: dict, new: dict, *, actor_id=None, target: str = "", ip=None,
                      compute: bool = True) -> dict | None:
        """두 파일(store의 *_source 결과: path·filename·sha256)을 비교한다. 캐시를 먼저 본다.

        돌려줌: {status: ok|unsupported|failed, reason, rows, notes, cached}. 예외를 내지 않는다(권한 오류 제외).
        compute=False면 계산하지 않는다 — 캐시에 없으면 None (GET 화면은 조회만, 2026-10-28 보안 F3)."""
        oe, ne = _ext(old["filename"]), _ext(new["filename"])
        if not _readable(oe) or not _readable(ne):
            return {"status": "unsupported", "reason": UNSUPPORTED_TEXT, "rows": [], "notes": [], "cached": False}
        if _FAMILY.get(oe) != _FAMILY.get(ne):
            return {"status": "unsupported", "rows": [], "notes": [], "cached": False,
                    "reason": f"두 파일의 형식이 달라({oe.lstrip('.')} → {ne.lstrip('.')}) 글자 비교를 하지 않습니다 "
                              f"— 파일을 내려받아 확인하세요"}
        if old["sha256"] == new["sha256"]:
            return {"status": "ok", "reason": "", "rows": [], "notes": ["두 파일의 내용이 똑같습니다"], "cached": False}
        key = f"{ENGINE}|{old['sha256']}{oe}|{new['sha256']}{ne}"
        hit = self._cache_get(key)
        if hit is not None:
            return hit
        if not compute:
            return None
        res = self._run({"op": "form_compare", "old": str(old["path"]), "new": str(new["path"])},
                        actor_id=actor_id, target=target, ip=ip)
        if res is None:
            return {"status": "failed", "reason": "비교가 밀려 있습니다 — 잠시 뒤 다시 열어 보세요", "rows": [], "notes": []}
        if res.get("unsupported"):
            out = {"status": "unsupported", "reason": UNSUPPORTED_TEXT, "rows": [], "notes": []}
        elif res.get("failed"):
            out = {"status": "failed", "reason": res["reason"], "rows": [], "notes": []}
        else:
            out = {"status": "ok", "reason": "", "rows": res.get("rows") or [], "notes": res.get("notes") or []}
        if out["status"] != "unsupported":
            self._cache_put(key, out)
        out["cached"] = False
        return out

    def summary_path(self, src: dict, *, actor_id=None, target: str = "", ip=None,
                     compute: bool = True) -> dict | None:
        """새 양식 요약(머리글·칸 이름) — {status: new|unsupported|failed, reason, summary}.
        compute=False면 캐시에 없을 때 None."""
        e = _ext(src["filename"])
        if not _readable(e):
            return {"status": "unsupported", "reason": UNSUPPORTED_TEXT, "summary": None}
        key = f"{ENGINE}|summary|{src['sha256']}{e}"
        hit = self._cache_get(key)
        if hit is not None:
            return hit
        if not compute:
            return None
        res = self._run({"op": "form_summary", "path": str(src["path"])}, actor_id=actor_id, target=target, ip=ip)
        if res is None:
            return {"status": "failed", "reason": "비교가 밀려 있습니다 — 잠시 뒤 다시 열어 보세요", "summary": None}
        if res.get("failed"):
            out = {"status": "failed", "reason": res["reason"], "summary": None}
        elif res.get("summary") is None:
            out = {"status": "unsupported", "reason": UNSUPPORTED_TEXT, "summary": None}
        else:
            out = {"status": "new", "reason": "", "summary": res["summary"]}
        if out["status"] != "unsupported":
            self._cache_put(key, out)
        out["cached"] = False
        return out

    def _run(self, req: dict, *, actor_id, target: str, ip):
        """자식에게 맡긴다. 바빠서 못 하면 None, 실패면 {failed, reason} — 실패는 감사 기록에 남긴다."""
        try:
            return self._request(req)
        except _Busy:
            return None
        except Exception as e:      # 시간 초과·깨진 파일·자식이 죽음 — 서버는 계속 돈다
            reason = _reason(e, self.timeout)
            log.info("양식 비교 실패 (%s): %s %s", target, type(e).__name__, e)
            if actor_id is not None:
                try:
                    self.store.record_audit(actor_id, "compare_fail", target, ip=ip, detail=reason)
                except Exception:
                    log.exception("비교 실패 감사 기록을 남기지 못함")
            return {"failed": True, "reason": reason}

    # ── 화면이 부르는 것 ─────────────────────────────────────────────────
    def compare_versions(self, actor_id, old_version_id, new_version_id, *, ip=None, compute: bool = True) -> dict:
        """두 판 비교 — 판끼리 비교 화면. {old, new(판 정보), result}.
        compute=False(GET 화면): 캐시·형식만 보고 계산하지 않는다 — 아직 없으면 result가 None."""
        st = self.store
        old = st.version_source(actor_id, old_version_id, verify=False)
        new = st.version_source(actor_id, new_version_id, verify=False)
        if old["form_id"] != new["form_id"]:
            raise NotFound("같은 양식의 판끼리만 비교할 수 있습니다")
        result = self._compare_checked(actor_id, old, new, ip=ip, compute=compute,
                                       target=f"form:{old['form_id']} v{old['number']}→v{new['number']}",
                                       reload=lambda: (st.version_source(actor_id, old_version_id),
                                                       st.version_source(actor_id, new_version_id)))
        return {"old": old, "new": new, "result": result}

    def _compare_checked(self, actor_id, old, new, *, ip, target, reload, compute: bool = True):
        """캐시에 없으면 지문을 확인한 뒤(보관소가 바깥에서 바뀌었으면 비교하지 않음) 비교한다."""
        oe, ne = _ext(old["filename"]), _ext(new["filename"])
        key = f"{ENGINE}|{old['sha256']}{oe}|{new['sha256']}{ne}"
        if compute and _readable(oe) and _readable(ne) and old["sha256"] != new["sha256"] \
                and self.store.compare_cache_get(key) is None:
            reload()                                  # 지문 확인 (Conflict는 그대로 위로 — 관리자에게 알릴 일)
        return self.compare_paths(old, new, actor_id=actor_id, target=target, ip=ip, compute=compute)

    def review_submission(self, actor_id, submission_id, *, ip=None, compute: bool = True) -> dict:
        """검토 화면 — 개정안이면 현행 판과 비교, 새 양식이면 요약.

        돌려줌: {mode: revision|new, sub, old(현행 판 정보|None), result}. compute=False면 캐시에 없을 때 result가 None."""
        st = self.store
        sub = st.submission(actor_id, submission_id)
        src = st.submission_source(actor_id, submission_id, verify=False)
        target = f"submission:{submission_id}"
        cur, cur_id = None, None
        if sub["form_id"] is not None:
            form = st.form_detail(actor_id, sub["form_id"])
            cur_id = form["current_version_id"]
            if cur_id is not None:
                cur = st.version_source(actor_id, cur_id, verify=False)
        if cur is None:
            e = _ext(src["filename"])
            if compute and _readable(e) \
                    and self.store.compare_cache_get(f"{ENGINE}|summary|{src['sha256']}{e}") is None:
                st.submission_source(actor_id, submission_id)          # 지문 확인
            return {"mode": "new", "sub": sub, "old": None,
                    "result": self.summary_path(src, actor_id=actor_id, target=target, ip=ip, compute=compute)}
        result = self._compare_checked(actor_id, cur, src, ip=ip, target=target, compute=compute,
                                       reload=lambda: (st.version_source(actor_id, cur_id),
                                                       st.submission_source(actor_id, submission_id)))
        return {"mode": "revision", "sub": sub, "old": cur, "result": result}

    def claim_auto(self, submission_id) -> bool:
        """검토 화면을 열 때의 자동 비교 자격 — 검토 대기 1건당 (서버가 도는 동안) 한 번만 True (보안 F3).
        그 뒤로 화면을 열면 캐시만 본다. 다시 계산은 검토자가 [다시 비교하기](POST+CSRF)로 한다."""
        with self._lock:
            key = int(submission_id)
            if key in self._auto:
                return False
            if len(self._auto) >= 5000:
                self._auto.clear()
            self._auto.add(key)
            return True

    def cached_count(self, actor_id, submission_id):
        """검토 대기 목록의 '변경 N건' 배지 — 캐시에 있을 때만(목록을 그리려고 비교를 돌리지 않는다). 없으면 None."""
        st = self.store
        try:
            sub = st.submission(actor_id, submission_id)
            if sub["form_id"] is None or sub["status"] != "pending":
                return None
            form = st.form_detail(actor_id, sub["form_id"])
            if form["current_version_id"] is None:
                return None
            cur = st.version_source(actor_id, form["current_version_id"], verify=False)
        except Exception:
            return None
        key = f"{ENGINE}|{cur['sha256']}{_ext(cur['filename'])}|{sub['sha256']}{_ext(sub['filename'])}"
        row = st.compare_cache_get(key)
        if row is None or row["status"] != "ok":
            return None
        try:
            return len(json.loads(row["result"]).get("rows") or [])
        except ValueError:
            return None
