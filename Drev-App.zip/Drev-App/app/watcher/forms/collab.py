# -*- coding: utf-8 -*-
"""사내망 협업 다듬기 (2026-11-23 사용자 "부서원 전체가 같이 프로젝트 변경점 공유하고 같이 관리" — DECISIONS 같은 날,
ROADMAP '사내망 협업 다듬기', FORMS.md 11-1절).

켜 둔 양식함 서버 안의 사내망 변경 열람(changes.py) 위에:
- **의견**: 변경·확인 필요 하나에 여러 줄 글(덧붙임만). 열람 범위 안이면 누구나. 확인([확인함])과는 다른 동작.
- **확인 필요 하나 보기** `/changes/issue?id=` — 사실·근거·의견, (권한이 있으면) [처리함 + 메모]·담당 지정.

state.db 쓰기는 확인(changes.py)·의견·담당·처리함 네 가지뿐이고, 쓰기마다 대상의 프로젝트가 이 계정 범위 안인지 서버가 다시 본다
(범위 밖·없는 번호는 같은 404). 스키마는 만들지 않는다 — 의견·담당 표가 없는 옛 DB면 그 구역만 숨기고 한 줄 안내(OLD_DB_TEXT).
감시 검사가 쓰기 잠금을 쥐면 확인과 같은 꼴로 '잠시 뒤 다시'(아무것도 남기지 않음). 이 모듈은 파일을 쓰지 않는다(test_readonly).
"""

from __future__ import annotations

import html
from pathlib import PurePosixPath
from urllib.parse import quote

from watcher import opinions as OP
from watcher.state import COMMENT_MAX, State, clean_comment_text, done_label, lan_ack_by

E = html.escape
CSS = OP.CSS
OLD_DB_TEXT = "감시 기록이 옛 판 형식이라 의견·담당이 아직 없습니다. 감시 PC에서 검사를 한 번 돌리면 열립니다."
KINDS = ("change", "issue")
RESOLVE_PREFIX = "changes_resolve:"      # forms.db meta — '확인 필요 처리' 권한(값 "1"). changes_view:와 같은 꼴, 스키마 그대로
NO_RESOLVE_TEXT = "확인 필요를 처리할 권한이 없습니다 — 관리자에게 '확인 필요 처리'를 부탁하세요"


def _C():
    from watcher.forms import changes as C
    return C


def _S():
    from watcher.forms import server as S
    return S


def _W():
    return _C()._W()


# ── 권한: 확인 필요 처리 ([처리함]·담당 지정) — 관리자가 계정마다 켠다, 관리자는 늘 ─────────────────

def resolve_flag(store, user_id) -> bool:
    """meta에 켜 둔 값만 (관리자 여부는 보지 않는다 — 계정 화면 표시용)."""
    try:
        return store.meta_get(f"{RESOLVE_PREFIX}{int(user_id)}", "") == "1"
    except (TypeError, ValueError):
        return False


def can_resolve(store, user_id) -> bool:
    """[처리함]·담당 지정을 할 수 있나 — 관리자는 늘, 정지 계정은 아니다, 그 밖에는 관리자가 켠 계정만(기본 끔).
    역할·정지는 매번 DB에서 (세션 값이 아니라). 열람 범위는 따로 본다(범위 밖은 404)."""
    u = store.get_user(user_id) if user_id is not None else None
    if not u or u.get("disabled"):
        return False
    if u.get("role") == "admin":
        return True
    return resolve_flag(store, user_id)


def set_resolve(store, actor_id, target_id, *, on: bool, ip: str = "") -> str:
    """관리자가 계정 하나의 '확인 필요 처리'를 켜고 끈다 — 바뀔 때만 감사 기록 changes_resolve. 돌려주는 값: 한 줄 결과(안 바뀌면 '')."""
    u = store.get_user(target_id)
    if not u or u.get("role") == "admin":
        return ""
    if resolve_flag(store, target_id) == bool(on):
        return ""
    store.meta_put({f"{RESOLVE_PREFIX}{int(target_id)}": "1" if on else None})
    what = "켬" if on else "끔"
    store.record_audit(actor_id, "changes_resolve", f"user:{int(target_id)}", ip=ip,
                       detail=f"{u.get('login')} 확인 필요 처리(처리함·담당 지정) {what}")
    return f"확인 필요 처리 {what}"


# ── 대상(변경·확인 필요) ─────────────────────────────────────────────────────────

def target_info(st: State, kind: str, tid: int) -> dict | None:
    """{kind, id, project, path, name, href} — 없으면 None. 프로젝트 없음은 '미분류'(열람 범위 판정과 같은 이름)."""
    if kind == "change":
        r = _C()._row_of(st, tid)
        if r is None:
            return None
        return {"kind": kind, "id": tid, "project": r["project"], "path": r["path"],
                "name": PurePosixPath(r["path"]).name, "href": f"/changes/{tid}"}
    if kind == "issue":
        i = st.issue_by_id(tid)
        if i is None:
            return None
        return {"kind": kind, "id": tid, "project": i.get("project") or "미분류", "path": i["path"],
                "name": PurePosixPath(i["path"]).name, "href": f"/changes/issue?id={tid}", "issue": i}
    return None


def _form_target(h, f) -> tuple[str, int]:
    S = _S()
    kind = S.FormsHandler._one(f, "kind") or "change"
    if kind not in KINDS:
        raise S.HttpError(404)
    try:
        return kind, S.FormsHandler._int(S.FormsHandler._one(f, "id"))
    except S.HttpError:
        raise S.HttpError(404)


# ── 의견 카드 (사내망 변경 상세·확인 필요 하나 보기) ─────────────────────────────────

def comment_card(h, st: State, kind: str, tid: int) -> str:
    """'의견' 카드 — 감시 화면과 같은 꼴(opinions.card), 쓰는 칸은 계정 이름으로. 옛 DB면 카드 대신 한 줄 안내."""
    if not st.has_collab():
        return f'<p class="ds-sm ds-cm-old" id="cm">{E(OLD_DB_TEXT)}</p>'
    s = h.sess
    who = lan_ack_by(s.display_name, s.login)
    form = (f'<form method="post" action="/changes/comment" class="ds-cm-form">{_S()._hidden(h)}'
            f'<input type="hidden" name="kind" value="{kind}"><input type="hidden" name="id" value="{int(tid)}">'
            f'<span class="ds-lbl">이름</span><div class="ds-rec-who">{E(OP.person_label(who))}</div>'
            + OP.textarea() + '<div class="ds-btns"><button class="ds-btn" type="submit">의견 남기기</button></div></form>')
    return OP.card(st.comments_of(kind, tid), form)


def post_comment(h) -> None:
    """[의견 남기기] — state.db comments 한 줄. 범위 밖·없는 대상은 같은 404, 검사가 잠금을 쥐면 '잠시 뒤 다시'."""
    C, S = _C(), _S()
    f = h._read_form()
    h._check_token(f)
    scope = C._scope(h)
    w = C._watch(h)
    kind, tid = _form_target(h, f)
    body = clean_comment_text(S.FormsHandler._one(f, "body"))
    if len(body) > COMMENT_MAX:
        raise S.HttpError(400, f"의견은 {COMMENT_MAX:,}자까지입니다")
    s = h.sess
    by = lan_ack_by(s.display_name, s.login)
    back = f"/changes/{tid}" if kind == "change" else f"/changes/issue?id={tid}"
    try:
        with w.session() as st:
            t = target_info(st, kind, tid)
            if t is None or not C._in(scope, t["project"]):
                raise S.HttpError(404)
            if not st.has_collab():
                h._flash("bad", OLD_DB_TEXT)
                h._redirect(back)
                return
            if not body:
                h._flash("bad", "의견을 적어 주세요. 아무것도 남기지 않았습니다.")
                h._redirect(back + "#cm")
                return
            got = st.add_comment(kind, tid, by, body)
    except C.WatchBusy:
        h._flash("bad", C.BUSY_TEXT + " (의견은 아직 남지 않았습니다)")
        h._redirect(back)
        return
    except C.WatchUnavailable as e:
        C._unavailable(h, str(e))
        return
    if not got:
        raise S.HttpError(404)
    try:
        h.server.store.record_audit(s.user_id, "change_comment", f"{kind}:{tid}", ip=h.ip,
                                    detail=f"{t['project']} · {t['name']} — {' '.join(body.split())[:300]}")
    except Exception:          # noqa: BLE001 — 감사 한 줄 때문에 의견이 실패로 보이면 안 된다(이미 남았다)
        pass
    h._flash("ok", "의견을 남겼습니다. [확인함]과는 따로입니다. 감시 PC 화면에도 보입니다.")
    h._redirect(back + "#cm")


# ── /changes/issue?id= — 확인 필요 하나 보기 ───────────────────────────────────────

def _issue_id(h) -> int:
    S = _S()
    try:
        return S.FormsHandler._int(S.FormsHandler._one(h._query(), "id"))
    except S.HttpError:
        raise S.HttpError(404)


def process_card(h, st: State, i: dict) -> str:
    """'처리' 카드 — 열림/처리됨 상태 + (권한이 있으면) [처리함]. 처리 권한이 없으면 누가 하는지 한 줄."""
    W = _W()
    if i.get("resolved_at"):
        # 한 줄에 가운뎃점은 하나까지(화면 글 규칙) — 처리한 때는 아래 작은 줄
        state = (f'<div class="ds-state"><span class="ds-dot"></span><span>처리됨 · {E(done_label(i.get("resolved_by")) or "—")}'
                 f'</span></div><p class="ds-sm">{E(W._ds_when_iso(i["resolved_at"]))}에 처리했습니다.</p>'
                 '<p class="ds-sm">잘못 처리했으면 감시 PC에서 [다시 열기]를 누릅니다.</p>')
        return f'<section class="ds-side-c" id="proc" aria-labelledby="proc-h"><h3 id="proc-h">처리</h3>{state}</section>'
    day = W._rc_md_y(i.get("detected_at"))
    state = (f'<div class="ds-state"><span class="ds-dot bad"></span><span>열림' + (f' · {E(day)} 발견' if day else "")
             + '</span></div>')
    if not can_resolve(h.server.store, h.sess.user_id):
        how = ('<p class="ds-sm">[처리함]은 처리 권한이 있는 계정·감시 PC에서 합니다. '
               '숨기기는 감시 PC에서 합니다.</p>')
        return f'<section class="ds-side-c" id="proc" aria-labelledby="proc-h"><h3 id="proc-h">처리</h3>{state}{how}</section>'
    s = h.sess
    who = lan_ack_by(s.display_name, s.login)
    # 처리 메모는 의견 표에 남는다 — 옛 판 DB(표 없음)면 칸을 두지 않는다. 두면 적은 메모가 조용히 버려졌다 (조율자 탐침 2026-11-23)
    memo = (f'<label class="ds-lbl" for="res-note">처리 메모 (안 써도 됨)</label>'
            f'<input class="ds-inp memo" type="text" id="res-note" name="note" maxlength="{_C().NOTE_MAX}" '
            f'placeholder="예: BOM 7.5kW로 고친 것 확인">') if st.has_collab() else ""
    form = (f'<form method="post" action="/changes/issue/close">{_S()._hidden(h)}'
            f'<input type="hidden" name="id" value="{int(i["issue_id"])}">'
            f'<span class="ds-lbl">처리자</span><div class="ds-rec-who">{E(OP.person_label(who))}</div>'
            + memo +
            f'<div class="ds-btns"><button class="ds-btn p" type="submit">처리함</button></div></form>'
            '<p class="ds-sm">처리하면 확인 필요 목록에서 빠집니다. 감시 PC의 [처리함]과 같은 기록입니다. '
            '같은 내용이 다시 나오면 새로 올라옵니다. 숨기기는 감시 PC에서 합니다.</p>')
    return f'<section class="ds-side-c" id="proc" aria-labelledby="proc-h"><h3 id="proc-h">처리</h3>{state}{form}</section>'


def post_issue_close(h) -> None:
    """사내망 [처리함] — 감시 PC [처리함]과 같은 State.resolve_issue·같은 기록(처리자 = '이름 (사내망·아이디)'). 메모는 의견 표에
    '처리 메모'로 한 줄. 권한 없음 403, 범위 밖·없는 번호는 같은 404. 한 건씩만(사내망 일괄 처리는 없다)."""
    C, S = _C(), _S()
    f = h._read_form()
    h._check_token(f)
    scope = C._scope(h)
    w = C._watch(h)
    s = h.sess
    if not can_resolve(h.server.store, s.user_id):
        raise S.HttpError(403, NO_RESOLVE_TEXT)
    try:
        iid = S.FormsHandler._int(S.FormsHandler._one(f, "id"))
    except S.HttpError:
        raise S.HttpError(404)
    note = C.clean_ack_text(S.FormsHandler._one(f, "note"))
    if len(note) > C.NOTE_MAX:
        raise S.HttpError(400, f"처리 메모는 {C.NOTE_MAX}자까지입니다")
    by = lan_ack_by(s.display_name, s.login)
    back = f"/changes/issue?id={iid}"
    try:
        with w.session() as st:
            t = target_info(st, "issue", iid)
            if t is None or not C._in(scope, t["project"]):
                raise S.HttpError(404)
            if t["issue"].get("resolved_at"):
                h._flash("info", f"이미 처리된 확인 필요입니다 — {done_label(t['issue'].get('resolved_by')) or '처리됨'}")
                h._redirect(back)
                return
            done = st.resolve_issue(iid, by)              # 감시 PC [처리함]과 같은 함수·같은 칸
            memo_lost = bool(done and note and not st.has_collab())     # 옛 판 DB — 메모는 감사 기록에만
            if done and note and not memo_lost:
                st.add_comment("issue", iid, by, note, kind="resolve")
    except C.WatchBusy:
        h._flash("bad", C.BUSY_TEXT + " (처리는 아직 남지 않았습니다)")
        h._redirect(back)
        return
    except C.WatchUnavailable as e:
        C._unavailable(h, str(e))
        return
    if not done:
        h._flash("info", "이미 처리된 확인 필요입니다")
        h._redirect(back)
        return
    try:
        from watcher.consistency import short_label
        h.server.store.record_audit(s.user_id, "issue_resolve", f"issue:{iid}", ip=h.ip,
                                    detail=f"{t['project']} · {t['name']} · {short_label(t['issue']['code'])}"
                                           + (f" — {note}" if note else ""))
    except Exception:          # noqa: BLE001 — 감사 한 줄 때문에 처리가 실패로 보이면 안 된다(이미 남았다)
        pass
    h._flash("ok", f"처리함으로 표시했습니다. 감시 PC에는 '사내망에서 처리: {s.display_name}'로 보입니다. "
                   "잘못 눌렀으면 감시 PC에서 [다시 열기]를 누릅니다."
                   + (" 처리 메모는 감시 기록이 옛 판 형식이라 감사 기록에만 남았습니다." if memo_lost else ""))
    h._redirect(back)


def get_issue(h) -> None:
    """확인 필요 하나 — 사실 한 줄·근거(감시 화면 변경 상세 상자와 같은 줄: web._ds_iss_line)·관련 변경 링크·의견, 처리 상태.
    범위 밖·없는 번호는 변경 상세와 같은 404(_not_here). 감시 기록을 못 열면 그 화면만 안내(changes._guarded와 같은 꼴)."""
    C = _C()
    try:
        _get_issue(h)
    except C.WatchBusy as e:
        C._unavailable(h, str(e), 503)
    except C.WatchUnavailable as e:
        C._unavailable(h, str(e))


def _get_issue(h) -> None:
    C, W = _C(), _W()
    scope = C._scope(h)
    w = C._watch(h)
    iid = _issue_id(h)
    from watcher.consistency import CODE_LABEL
    with w.session() as st:
        i = st.issue_by_id(iid)
        if i is None or not C._in(scope, i.get("project") or "미분류"):
            C._not_here(h, scope)
            return
        proj = i.get("project") or "미분류"
        cid = st.changes_for_paths([i["path"]]).get(i["path"])
        if cid is not None:
            r0 = C._row_of(st, int(cid))
            cid = int(cid) if (r0 is not None and C._in(scope, r0["project"])) else None
        line = W._ds_iss_line(i, i["path"])
        cm = comment_card(h, st, "issue", iid)
        proc = process_card(h, st, i)
        side_extra = side_cards(h, st, "issue", iid, proj)
        asg = st.assignee_of("issue", iid) if st.has_collab() else None
    name = PurePosixPath(i["path"]).name
    code = i["code"]
    day = W._rc_md_y(i.get("detected_at"))
    lab = W._DS_ISS_SHORT.get(code) or CODE_LABEL.get(code, code)
    from watcher.docbox import issue_tone
    amber = issue_tone([code]) == "amber"             # 변경 상세 상자와 같은 색 규칙 (Rev 표기는 노랑 — 검토 Y1 L3)
    box = (f'<div class="ds-issue{" ds-db-ok" if amber else ""}" id="iss-open"><h3><span class="ds-chg-warn" aria-hidden="true">⚠</span>'
           f'<span>{E(lab)}</span></h3>'
           f'<div class="ds-ln"><span class="ds-k" title="{E(CODE_LABEL.get(code, code))}">{E(lab)}'
           + (f'<div class="ds-sm">{E(day)} 생김</div>' if day else "")
           + f'</span><span>{line}</span></div>'
           + (f'<p class="ds-chg-isub"><a href="/changes/{cid}">이 파일의 전/후 보기 →</a></p>' if cid else "")
           + '</div>')
    kv = [("프로젝트", E(proj)), ("대상 파일", f'<span title="{E(i["path"])}">{E(name)}</span>')]
    if day:
        kv.append(("발견", E(W._ds_when_iso(i.get("detected_at"))) + " 검사"))
    if asg:
        kv.append(("담당", E(OP.assignee_text(asg))))
    kv.append(("기록 번호", f"확인 필요 #{iid}"))
    info = ('<section class="ds-side-c" id="file-info" aria-labelledby="iss-info-h"><h3 id="iss-info-h">정보</h3><dl class="ds-dl">'
            + "".join(f"<dt>{k}</dt><dd>{v}</dd>" for k, v in kv) + '</dl></section>')
    crumb = (f'<div class="crumb ds-crumb"><a href="/changes">프로젝트</a><span class="ds-sep">›</span>'
             f'<a href="{E(C._box_href(proj))}">{E(proj)}</a><span class="ds-sep">›</span>'
             f'<a href="/changes/issues?p={quote(proj, safe="")}">확인 필요</a><span class="ds-sep">›</span>{E(name)}</div>')
    title_html = f'{E(name)}<span class="ds-rec-h1tags">{C.issue_tag(code)}</span>'
    sub = f'{E(proj)} · <span title="{E(i["path"])}">{E(i["path"])}</span>'
    body = (f'{crumb}<div class="ds-chg"><div class="ds-split ds-chg-split ds-rec-split">'
            f'<section class="ds-chg-ack ds-rec-side" aria-label="처리">{proc}</section>'
            f'<div class="ds-chg-main ds-rec-main">{box}{cm}</div>'
            f'<aside class="ds-chg-side ds-rec-side" aria-label="정보">{info}{side_extra}</aside></div></div>')
    h._send(200, h._shell(f"{name} — 확인 필요 #{iid}", body, active="/changes/issues", title_html=title_html, sub=sub))


def side_cards(h, st: State, kind: str, tid: int, project: str) -> str:
    """오른쪽 칸에 붙는 협업 카드 — 처리 권한(+관리자)이 있으면 '담당' 카드(지정·바꾸기·해제). 그 밖에는 없다(담당은 파일 정보 칸에 보인다)."""
    if not st.has_collab() or not _can(h):
        return ""
    return assign_card(h, st, kind, tid, project)


# ── 담당자 지정 (2026-11-23) — 고르는 목록은 그 프로젝트를 열람할 수 있는 정지 안 된 계정만 ─────────────────────

def eligible(store, project: str) -> list[dict]:
    """담당으로 고를 수 있는 계정 [{id, login, name, email}] — 정지되지 않았고 그 프로젝트를 볼 수 있는 계정(관리자는 늘). 아이디 순."""
    C = _C()
    views = {str(k): v for k, v in store.conn.execute("SELECT key, value FROM meta WHERE key LIKE ?", (C.ACCESS_PREFIX + "%",))}
    out = []
    for uid, login, name, role, disabled, email in store.conn.execute(
            "SELECT id, login, display_name, role, IFNULL(disabled, 0), IFNULL(email, '') FROM users ORDER BY login_key"):
        if disabled:
            continue
        if role != "admin":
            acc = C._parse_access(views.get(f"{C.ACCESS_PREFIX}{int(uid)}", ""))
            if acc is None or (acc != "all" and project not in acc):
                continue
        out.append({"id": int(uid), "login": str(login), "name": str(name or login), "email": str(email or "")})
    return out


def assign_card(h, st: State, kind: str, tid: int, project: str) -> str:
    """'담당' 카드 — 지금 담당 · [담당자 고르기(열람 범위 안의 계정만) + 담당 정하기] · 담당 기록(두 줄 이상이면)."""
    cur = st.assignee_of(kind, tid)
    people = eligible(h.server.store, project)
    now = (f'<div class="ds-state"><span class="ds-dot"></span><span>{E(OP.assignee_text(cur))}</span></div>' if cur else
           '<div class="ds-state"><span class="ds-dot off"></span><span>담당 없음</span></div>')
    opts = '<option value="">담당 없음</option>' + "".join(
        f'<option value="{p["id"]}"{" selected" if cur and cur.get("assignee_id") == p["id"] else ""}>'
        f'{E(p["name"])} ({E(p["login"])})</option>' for p in people)
    mail = ('<p class="ds-sm">담당자 메일 주소가 있으면 알림 메일이 갑니다. 파일 이름·프로젝트·링크만 싣습니다.</p>'
            if getattr(h.server, "notifier", None) is not None else "")
    form = (f'<form method="post" action="/changes/assign" class="ds-as-form">{_S()._hidden(h)}'
            f'<input type="hidden" name="kind" value="{kind}"><input type="hidden" name="id" value="{int(tid)}">'
            f'<label class="ds-lbl" for="as-uid">담당자 (이 프로젝트를 볼 수 있는 계정)</label>'
            f'<select class="ds-sel" id="as-uid" name="uid">{opts}</select>'
            f'<div class="ds-btns"><button class="ds-btn" type="submit">담당 정하기</button></div></form>')
    return (f'<section class="ds-side-c" id="assign" aria-labelledby="as-h"><h3 id="as-h">담당</h3>{now}{form}'
            + OP.log_html(st.assignment_log(kind, tid)) + mail + '</section>')


def post_assign(h) -> None:
    """담당 지정·바꾸기·해제 — 처리 권한(+관리자)만(없으면 403), 범위 밖·없는 대상은 같은 404, 열람 범위 밖 계정을 담당으로는 400.
    state.db assignments 한 줄(덧붙임만). 감사 기록 assign, 담당자에게 알림 메일 한 통(양식함 알림 길 — 파일 이름·프로젝트·링크만)."""
    C, S = _C(), _S()
    f = h._read_form()
    h._check_token(f)
    scope = C._scope(h)
    w = C._watch(h)
    s = h.sess
    store = h.server.store
    if not can_resolve(store, s.user_id):
        raise S.HttpError(403, "담당을 정할 권한이 없습니다 — 관리자에게 '확인 필요 처리'를 부탁하세요")
    kind, tid = _form_target(h, f)
    raw = S.FormsHandler._one(f, "uid").strip()
    who = None
    if raw:
        try:
            who = store.get_user(S.FormsHandler._int(raw))
        except S.HttpError:
            raise S.HttpError(400, "담당자를 목록에서 골라 주세요")
    by = lan_ack_by(s.display_name, s.login)
    try:
        with w.session() as st:
            t = target_info(st, kind, tid)
            if t is None or not C._in(scope, t["project"]):
                raise S.HttpError(404)
            back = t["href"]
            if not st.has_collab():
                h._flash("bad", OLD_DB_TEXT)
                h._redirect(back)
                return
            label, aid = "", None
            if raw:
                if not who or int(who["id"]) not in {p["id"] for p in eligible(store, t["project"])}:
                    raise S.HttpError(400, "그 계정은 이 프로젝트를 볼 수 없어 담당으로 정할 수 없습니다 — "
                                           "먼저 관리 › 계정 › 변경 열람에서 범위를 넓혀 주세요")
                label, aid = lan_ack_by(who.get("display_name") or who["login"], who["login"]), int(who["id"])
            res = st.assign(kind, tid, label, aid, by)
    except C.WatchBusy:
        h._flash("bad", C.BUSY_TEXT + " (담당은 아직 바뀌지 않았습니다)")
        h._redirect(f"/changes/{tid}" if kind == "change" else f"/changes/issue?id={tid}")
        return
    except C.WatchUnavailable as e:
        C._unavailable(h, str(e))
        return
    if res is None:
        raise S.HttpError(404)
    if res is False:
        h._flash("info", "이미 그 담당입니다. 바꾸지 않았습니다.")
        h._redirect(back + "#assign")
        return
    nm = (who.get("display_name") or who["login"]) if who else ""
    try:
        store.record_audit(s.user_id, "assign", f"{kind}:{tid}", ip=h.ip,
                           detail=f"{t['project']} · {t['name']} — " + (f"담당 {nm} ({who['login']})" if who else "담당 해제"))
    except Exception:          # noqa: BLE001
        pass
    sent = False
    n = getattr(h.server, "notifier", None)
    if who and n is not None and int(who["id"]) != int(s.user_id) and (who.get("email") or "").strip():
        try:
            n.assigned(who["email"], name=nm, project=t["project"], filename=t["name"],
                       what="변경" if kind == "change" else "확인 필요", by=s.display_name, path=back)
            sent = True
        except Exception:      # noqa: BLE001 — 알림 한 통 때문에 지정이 실패로 보이면 안 된다
            sent = False
    h._flash("ok", (f"담당을 {nm}(으)로 정했습니다." + (" 알림 메일을 보냅니다." if sent else "")) if who else "담당을 풀었습니다.")
    h._redirect(back + "#assign")


# ── 내 담당 — 나에게 맡겨진 열린 확인 필요 + 미확인 변경 (열람 범위 안만) ─────────────────────────────

def mine_items(st: State, user_id: int, scope) -> tuple[list, list]:
    """(확인 필요 줄 [(id, code, path, project, message, evidence, detected_at)…], 변경 줄 [변경 dict…]) — 지금 나에게 맡겨졌고
    확인 필요는 열려 있고 변경은 아직 아무도 [확인함]하지 않았고(확인 대상인 것만), 지금 열람 범위 안인 것. 최근 지정부터."""
    if not st.has_collab():
        return [], []
    C = _C()
    pairs = st.assigned_to(int(user_id))
    iids = [i for k, i in pairs if k == "issue"]
    cids = [i for k, i in pairs if k == "change"]
    iss: list = []
    if iids:
        got = {int(r[0]): r for r in st.conn.execute(
            "SELECT id, code, path, IFNULL(project, '미분류'), message, evidence, detected_at FROM issues "
            f"WHERE resolved_at IS NULL AND id IN ({','.join('?' * len(iids))})", iids)}
        iss = [got[i] for i in iids if i in got and C._in(scope, got[i][3])]
    chs: list = []
    if cids:
        acked = {int(r[0]) for r in st.conn.execute(
            f"SELECT DISTINCT change_id FROM acks WHERE change_id IN ({','.join('?' * len(cids))})", cids)}
        exempt = st.ack_exempt_map(cids)
        for cid in cids:
            if cid in acked or cid in exempt:
                continue
            r = C._row_of(st, cid)
            if r is not None and C._in(scope, r["project"]):
                chs.append(r)
    return iss, chs


_MINE_CACHE: dict = {}


def mine_count(h, acc) -> int | None:
    """왼쪽 메뉴·첫 화면 '내 담당 N' — 내 담당 화면과 같은 수(mine_items). state.db(·-wal)의 크기·시각과 계정·범위가 그대로면 지난 값.
    검사가 쓰기 잠금을 쥐고 있으면 기다리지 않는다(0.3초). 못 읽으면 None(수 없이)."""
    import sqlite3
    from pathlib import Path
    w = getattr(h.server, "watch_log", None)
    if w is None or acc is None:
        return None
    p = Path(w.path)
    try:
        sig = tuple((x.stat().st_mtime_ns, x.stat().st_size) if x.exists() else None for x in (p, Path(str(p) + "-wal")))
    except OSError:
        return None
    if sig[0] is None:
        return None
    key = (str(p), int(h.sess.user_id), "all" if acc == "all" else tuple(sorted(acc)))
    got = _MINE_CACHE.get(key)
    if got is not None and got[0] == sig:
        return got[1]
    try:
        conn = sqlite3.connect(p.resolve().as_uri() + "?mode=rw", uri=True, timeout=0.3, check_same_thread=False)
    except (sqlite3.Error, OSError, ValueError):
        return None
    try:
        conn.execute("PRAGMA busy_timeout=300")
        st = State.attach(conn, p)
        if not st.has_collab():                  # 옛 판 DB — 메뉴에도 첫 화면에도 없다
            n = None
        else:
            iss, chs = mine_items(st, int(h.sess.user_id), None if acc == "all" else acc)
            n = len(iss) + len(chs)
    except sqlite3.Error:
        return None
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass
    if len(_MINE_CACHE) > 500:
        _MINE_CACHE.clear()
    _MINE_CACHE[key] = (sig, n)
    return n


def mine_nav(h, acc) -> list:
    """왼쪽 메뉴 줄 — 내 담당이 있거나 담당을 정할 수 있는 계정에게만 '내 담당 N'."""
    n = mine_count(h, acc)
    if n is None or (not n and not _can(h)):
        return []
    return [("/changes/mine", "내 담당", n, f"나에게 맡겨진 열린 확인 필요·미확인 변경 {n}건")]


def mine_line(h, acc) -> str:
    """첫 화면(프로젝트 목록) 한 줄 '내 담당 N건 →' — 0건이면 없다."""
    n = mine_count(h, acc)
    if not n:
        return ""
    return (f'<div class="ds-alert info ds-mine-line" role="status"><span><b>내 담당 {n:,}건</b> '
            f'나에게 맡겨진 열린 확인 필요·미확인 변경입니다.</span><a class="ds-btn sm" href="/changes/mine">보기 →</a></div>')


def get_mine(h) -> None:
    C = _C()
    try:
        _get_mine(h)
    except C.WatchBusy as e:
        C._unavailable(h, str(e), 503)
    except C.WatchUnavailable as e:
        C._unavailable(h, str(e))


def _get_mine(h) -> None:
    C = _C()
    scope = C._scope(h)
    w = C._watch(h)
    with w.session() as st:
        old = not st.has_collab()
        iss, chs = mine_items(st, int(h.sess.user_id), scope)
        iss_html = (f'<div class="ds-scroll"><table class="ds-t ds-rec-iss">{C._issue_head(True)}'
                    f'<tbody>{C._issue_rows(st, iss, scope, show_project=True, h=h)}</tbody></table></div>') if iss else ""
        chg_html = ""
        if chs:
            g = C._gather(st, chs)
            g["summ"] = st.record_summaries([c["id"] for c in chs])
            opened = C._opened_live(st, [c["id"] for c in chs])
            trs = "".join(C._chg_row(st, c, g, opened, show_project=True) for c in chs)
            chg_html = (f'<div class="ds-scroll"><table class="ds-t ds-rec-chg">{C._chg_head(True)}'
                        f'<tbody>{trs}</tbody></table></div>')
    n = len(iss) + len(chs)
    if old:
        body = f'<div class="rec ds-rec"><section class="ds-card"><div class="ds-empty">{E(OLD_DB_TEXT)}</div></section></div>'
    else:
        body = ('<div class="rec ds-rec">'
                f'<section class="ds-card" aria-labelledby="mine-iss-h"><div class="ds-card-h"><h2 id="mine-iss-h">확인 필요</h2>'
                f'<span class="ds-s">{len(iss):,}건 · 열린 것</span></div>'
                + (iss_html or '<div class="ds-empty">나에게 맡겨진 열린 확인 필요가 없습니다</div>') + '</section>'
                f'<section class="ds-card" aria-labelledby="mine-chg-h"><div class="ds-card-h"><h2 id="mine-chg-h">미확인 변경</h2>'
                f'<span class="ds-s">{len(chs):,}건 · 아직 아무도 [확인함]을 남기지 않은 것</span></div>'
                + (chg_html or '<div class="ds-empty">나에게 맡겨진 미확인 변경이 없습니다</div>') + '</section></div>')
    sub = (f"나에게 맡겨진 열린 확인 필요 {len(iss):,}건 · 미확인 변경 {len(chs):,}건. "
           "처리하거나 [확인함]을 남기면 여기서 빠집니다.")
    title_html = f'내 담당 <span class="ds-cnt">{n:,}건</span>'
    h._send(200, h._shell("내 담당", body, active="/changes/mine", title_html=title_html, sub=E(sub)))


# ── 목록의 작은 표시 ──────────────────────────────────────────────────────────────

def marks(st: State, kind: str):
    """(의견 수 사전, 지금 담당 사전) — 옛 DB면 둘 다 빈 사전. 목록이 줄마다 '의견 N'·'담당 X'를 단다."""
    if not st.has_collab():
        return {}, {}
    return st.comment_counts(kind), st.assignees(kind)


def _can(h) -> bool:
    try:
        return h is not None and can_resolve(h.server.store, h.sess.user_id)
    except Exception:          # noqa: BLE001 — 글 하나 고르려다 화면이 죽으면 안 된다
        return False


def go_label(h) -> str:
    """확인 필요 하나 보기로 가는 링크 글 — 처리 권한이 있으면 '의견·처리 →'."""
    return "의견·처리 →" if _can(h) else "의견 →"


def issue_row_marks(h, iid: int, cm: dict, asg: dict) -> str:
    """확인 필요 목록 한 줄의 작은 줄 — '의견 N · 담당 X · [의견 →]' (하나 보기로)."""
    bits = [x for x in (OP.count_mark(cm.get(iid)), OP.assignee_mark(asg.get(iid))) if x]
    return (f'<div class="ds-sm ds-iss-cm">{" ".join(bits)}' + (" " if bits else "")
            + f'<a href="/changes/issue?id={int(iid)}">{E(go_label(h))}</a></div>')


def issues_sub(h) -> str:
    """사내망 확인 필요 목록 머리 회색 한 줄 — 누가 무엇을 어디서(처리 권한에 따라). ~~'[처리함]·숨기기는 감시 PC에서'~~ (2026-11-23)."""
    if _can(h):
        return "감시 PC의 검사가 잡은 것입니다. 고른 건의 [의견·처리 →]에서 의견을 남기고 처리합니다. 숨기기는 감시 PC에서 합니다."
    return ("감시 PC의 검사가 잡은 것입니다. 고른 건의 [의견 →]에서 의견을 남깁니다. "
            "[처리함]은 처리 권한이 있는 계정·감시 PC에서 합니다. 숨기기는 감시 PC에서 합니다.")


def issue_box_note(h, issues) -> str:
    """사내망 변경 상세 확인 필요 상자 끝 한 줄 — 확인 필요마다 하나 보기 링크 + 누가 무엇을 어디서."""
    W = _W()
    seen: dict = {}
    links = []
    for i in issues:
        lab = W._DS_ISS_SHORT.get(i["code"]) or str(i["code"])
        seen[lab] = seen.get(lab, 0) + 1
        links.append(f'<a href="/changes/issue?id={int(i["issue_id"])}">{E(lab)}'
                     + (f' {seen[lab]}' if seen[lab] > 1 else "") + ' →</a>')
    who = ("숨기기는 감시 PC에서 합니다." if _can(h) else
           "[처리함]은 처리 권한이 있는 계정·감시 PC에서 합니다. 숨기기는 감시 PC에서 합니다.")
    return (f'<p class="ds-chg-isub ds-chg-ilan">{"의견·처리" if _can(h) else "의견"}: {", ".join(links)}</p>'
            f'<p class="ds-chg-isub ds-chg-ilan ds-m">{who}</p>')


ROUTES_GET = {"/changes/issue": get_issue, "/changes/mine": get_mine}
ROUTES_POST = {"/changes/comment": post_comment, "/changes/issue/close": post_issue_close, "/changes/assign": post_assign}
