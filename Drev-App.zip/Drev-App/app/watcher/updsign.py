# -*- coding: utf-8 -*-
"""업데이트 목록(version.json) 판매자 서명 — Ed25519 (2026-10-19, 구매 평가 2차 IT 심사).

그때까지 업데이트의 무결성은 TLS + 배포 계정뿐이었다. 지문(SHA-256)이 **같은 version.json 안에**
있어, 그 파일을 바꿀 수 있는 사람(사이트·계정 탈취, 프록시 변조)은 지문까지 함께 바꿀 수 있었다 —
자기 증명이다. 여기서는 판매자 비밀키로 서명한 '서명 본문'을 version.json에 덧붙이고, 앱은 코드에
**박아 둔 공개키**로만 그것을 믿는다.

- 순수 파이썬 Ed25519(RFC 8032 §5.1, 참조 구현 §6을 따름) — 새 의존성을 넣지 않는다(포터블 libs를 늘리지
  않게). 검증 한 번 수십 ms. 서명 함수도 같은 코드(release.py가 쓴다); 상수 시간은 아니므로 서명은 배포 PC에서만.
- 서명 본문(payload)은 JSON **문자열 그대로** 싣고 그 바이트에 서명한다 — 정규화 차이로 검증이 갈리지 않게.
- 서명 본문 안에 판(version)·지문(sha256)·런타임·발행/만료 시각을 넣는다 — 지문을 바꿔치기하면 서명이 깨지고,
  옛 서명을 다시 쓰면(재사용) 만료로, 낮은 판을 내밀면(다운그레이드) 판 비교로 막힌다.
- 옛 판(≤0.57.47)은 이 칸을 모르고 무시한다 — version.json 형식은 그대로, 칸 하나만 늘었다.

이 파일은 watcher 패키지의 다른 모듈을 import하지 않는다(release.py·시험이 단독으로 쓴다).
"""
from __future__ import annotations

import base64
import hashlib
import json
import time

# ---------------------------------------------------------------- 고정 공개키
# scripts/make_update_key.py가 처음 한 번 키를 만들며 아래 줄을 채운다. 비밀키는 저장소 밖
# (%USERPROFILE%\.drev-release\update_ed25519.key)에만 있다. 키를 바꿀 때는 새 키를 **덧붙인** 판을
# 옛 키로 서명해 내보낸 뒤, 그다음 판부터 새 키로 서명한다(DECISIONS 2026-10-19).
PINNED_KEYS: tuple = (
    "2c11e40937911c884ba27be72b49a32eba3bba1ccdfc7be970587e95da4f60bd",   # 689534a3c966e67b (make_update_key.py)
    # MAKE_UPDATE_KEY_PINNED
)

DOMAIN = b"drev-update-manifest-v1\n"     # 서명 대상 앞머리 — 다른 용도의 서명과 섞이지 않게
MAX_AGE_DAYS = 400                        # 발행 + 400일 뒤 만료 (release.py가 서명할 때 정한다)

# ------------------------------------------------------------- Ed25519 (RFC 8032)
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493       # 군의 위수 L


def _inv(x: int) -> int:
    return pow(x, _p - 2, _p)


_d = -121665 * _inv(121666) % _p
_SQRT_M1 = pow(2, (_p - 1) // 4, _p)


def _sha512(b: bytes) -> bytes:
    return hashlib.sha512(b).digest()


def _sha512_modq(b: bytes) -> int:
    return int.from_bytes(_sha512(b), "little") % _q


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s: int, P):
    Q = (0, 1, 1, 0)            # 중립원
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q) -> bool:
    if (P[0] * Q[2] - Q[0] * P[2]) % _p != 0:
        return False
    return (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y: int, sign: int):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1) % _p
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _SQRT_M1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P) -> bytes:
    zi = _inv(P[2])
    x, y = P[0] * zi % _p, P[1] * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s: bytes):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _p)


def _expand(seed: bytes):
    if len(seed) != 32:
        raise ValueError("Ed25519 비밀키(seed)는 32바이트입니다")
    h = _sha512(seed)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_key(seed: bytes) -> bytes:
    a, _ = _expand(seed)
    return _compress(_mul(a, _G))


def sign(seed: bytes, msg: bytes) -> bytes:
    a, prefix = _expand(seed)
    A = _compress(_mul(a, _G))
    r = _sha512_modq(prefix + msg)
    Rs = _compress(_mul(r, _G))
    h = _sha512_modq(Rs + A + msg)
    s = (r + h * a) % _q
    return Rs + int.to_bytes(s, 32, "little")


def verify(public: bytes, msg: bytes, signature: bytes) -> bool:
    """RFC 8032 §5.1.7 검증. 형식이 틀린 입력은 예외 대신 False."""
    try:
        if len(public) != 32 or len(signature) != 64:
            return False
        A = _decompress(public)
        if A is None:
            return False
        Rs = signature[:32]
        R = _decompress(Rs)
        if R is None:
            return False
        s = int.from_bytes(signature[32:], "little")
        if s >= _q:
            return False
        h = _sha512_modq(Rs + public + msg)
        return _equal(_mul(s, _G), _add(R, _mul(h, A)))
    except (TypeError, ValueError):
        return False


def key_id(public: bytes) -> str:
    """공개키 지문(짧은 이름) — SHA-256 앞 16자. 화면·로그·version.json의 kid."""
    return hashlib.sha256(public).hexdigest()[:16]


def fingerprint(public: bytes) -> str:
    """공개키 전체 지문 — SHA-256 64자 (보안 심사 문서·DECISIONS용)."""
    return hashlib.sha256(public).hexdigest()


# --------------------------------------------------------------- 업데이트 목록
class ManifestError(ValueError):
    """서명이 없거나 틀렸거나 만료 — 사람에게 보여줄 한국어 사유."""


SIGNED_SHA_KEYS = ("portable", "app", "exe", "setup")


def make_payload(version: str, sha256: dict, runtime: str = "", exe_version: str = "",
                 issued: float | None = None, max_age_days: int = MAX_AGE_DAYS) -> str:
    """서명할 본문(JSON 문자열). 키 순서·공백을 고정해 같은 입력이면 같은 바이트."""
    now = int(time.time() if issued is None else issued)
    body = {
        "product": "drev",
        "version": str(version),
        "runtime": str(runtime or ""),
        "exe_version": str(exe_version or version),
        "sha256": {k: str((sha256 or {}).get(k) or "").lower() for k in SIGNED_SHA_KEYS},
        "issued": now,
        "expires": now + int(max_age_days) * 86400,
    }
    return json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sign_manifest(seed: bytes, payload: str) -> dict:
    """version.json에 덧붙일 'signed' 칸."""
    pub = public_key(seed)
    sig = sign(seed, DOMAIN + payload.encode("utf-8"))
    return {"alg": "ed25519", "kid": key_id(pub), "payload": payload,
            "sig": base64.b64encode(sig).decode("ascii")}


def verify_manifest(info: dict, keys=None, now: float | None = None) -> dict:
    """version.json(dict)의 'signed' 칸을 고정 공개키로 검증하고 서명 본문(dict)을 돌려준다.

    서명 본문의 판이 겉의 version과 다르면 거절한다(겉만 바꾼 바꿔치기). 지문·런타임은 부르는 쪽이
    **서명 본문의 값**을 쓴다 — 겉의 sha256은 옛 판을 위한 사본일 뿐이다."""
    keys = tuple(PINNED_KEYS if keys is None else keys)
    if not isinstance(info, dict):
        raise ManifestError("업데이트 목록 형식이 이상합니다")
    blk = info.get("signed")
    if not blk:
        raise ManifestError("업데이트 목록에 판매자 서명이 없습니다")
    if not isinstance(blk, dict) or blk.get("alg") != "ed25519":
        raise ManifestError("업데이트 목록의 서명 형식을 알 수 없습니다")
    if not keys:
        raise ManifestError("이 판에 업데이트 서명 공개키가 들어 있지 않습니다")
    payload = blk.get("payload")
    try:
        sig = base64.b64decode(str(blk.get("sig") or ""), validate=True)
    except (ValueError, TypeError):
        raise ManifestError("업데이트 목록의 서명 값이 깨졌습니다") from None
    if not isinstance(payload, str) or len(sig) != 64:
        raise ManifestError("업데이트 목록의 서명 값이 깨졌습니다")
    msg = DOMAIN + payload.encode("utf-8")
    pubs = []
    for k in keys:
        try:
            pubs.append(bytes.fromhex(k) if isinstance(k, str) else bytes(k))
        except ValueError:
            continue
    if not any(verify(pub, msg, sig) for pub in pubs if len(pub) == 32):
        raise ManifestError("업데이트 목록의 판매자 서명이 맞지 않습니다 (변조되었거나 다른 키로 서명됨)")
    try:
        body = json.loads(payload)
    except ValueError:
        raise ManifestError("서명된 업데이트 목록을 읽을 수 없습니다") from None
    if not isinstance(body, dict) or body.get("product") != "drev":
        raise ManifestError("서명된 목록이 Drev 업데이트 목록이 아닙니다")
    if str(body.get("version") or "") != str(info.get("version") or ""):
        raise ManifestError(f"서명된 판(v{body.get('version')})과 목록의 판(v{info.get('version')})이 다릅니다")
    t = time.time() if now is None else now
    try:
        exp = float(body.get("expires") or 0)
    except (TypeError, ValueError):
        exp = 0.0
    if not exp or t > exp:
        raise ManifestError("업데이트 목록의 서명이 만료되었습니다 (발행 "
                            + time.strftime("%Y-%m-%d", time.localtime(float(body.get("issued") or 0)))
                            + ") — 이 PC의 날짜·시계가 맞는지도 확인해 주세요")
    sha = body.get("sha256")
    if not isinstance(sha, dict):
        raise ManifestError("서명된 목록에 지문이 없습니다")
    return body
