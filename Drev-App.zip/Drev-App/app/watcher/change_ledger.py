# -*- coding: utf-8 -*-
"""설계 변경 대장 — 프로젝트·기간으로 고른 변경을 엑셀 한 벌로 (기능 검토 갈래 N, 2026-11-02, FORMS.md 11절).

감시 화면(127.0.0.1) 전체 이력의 [설계 변경 대장]과 양식함 사내망 '변경 확인'(열람 권한자, 자기 범위)이 같이 쓴다.
- 한 변경 = 한 줄: 변경 번호·프로젝트·도면/문서번호·판(Rev)·파일·구분·바뀐 것 요약·근거(지금 값(이전 값) · 위치)·저장자(saved_by)·
  검사 일시·확인자·확인 일시·확인 메모·사진('화면에서 #번호' — 사진 자체는 넣지 않는다).
- 첫 등록(기준선·나중에 더한 폴더·켠 확장자의 첫 검사)은 변경이 아니라 뺀다. 사람이 숨긴 오탐 항목은 근거에서 뺀다.
- 읽기만 한다(SELECT). 엑셀은 메모리에서만 — forms/ledger.build_xlsx(인라인 문자열·수식 앞붙임·_clean/_BAD_XML)를 그대로 쓴다.
"""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import PurePosixPath

from watcher.rowkey import split_row_cell
from watcher.state import KIND_LABEL, State, ack_label

LEDGER_MAX = 20_000                 # 한 벌 상한(행) — 넘으면 마지막 줄에 '잘림'
EVIDENCE_LINES = 30                 # 한 변경의 근거 줄 상한 — 넘으면 '외 N건'
EVIDENCE_CHARS = 30_000             # 근거 칸 글자 상한 — 엑셀 한 칸은 32,767자, 넘으면 forms.ledger가 말없이 자른다
# 폭 합은 A4 가로 한 쪽 폭 맞춤(인쇄)에서 글자가 너무 작아지지 않게 줄였다 — 긴 글 칸은 줄바꿈(LEDGER_WRAP)으로 아래로 늘어난다
# (검토 Y3 M1: 폭 합 302에 줄바꿈이 없어 한 줄로 붙고 옆 칸에 잘렸다). 날짜 칸 16은 'yyyy-mm-dd hh:mm'이 '####'이 되지 않는 폭
COLUMNS = (("변경 번호", 8), ("프로젝트", 12), ("도면/문서번호", 14), ("판(Rev)", 7), ("파일", 22), ("구분", 7),
           ("바뀐 것 요약", 34), ("근거 (지금 값(이전 값) · 위치)", 48), ("저장자", 10), ("검사 일시", 16), ("확인자", 18),
           ("확인 일시", 16), ("확인 메모", 22), ("사진", 14))
LEDGER_WRAP = (1, 2, 4, 6, 7, 8, 10, 12, 13)        # 줄바꿈할 칸(0부터) — 글 칸 전부(번호·Rev·구분·날짜 칸 빼고)


def parse_day(text) -> date | None:
    """'2026-11-02' → date. 비었거나 꼴이 틀리면 None."""
    s = str(text or "").strip()
    if len(s) != 10:
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _local(iso) -> datetime | None:
    """UTC ISO 시각 → 이 PC 지역 시각(분까지, 시간대 없는 값 — 엑셀 날짜 칸)."""
    s = str(iso or "")
    if not s:
        return None
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    elif "+" not in s[10:]:
        s += "+00:00"
    try:
        d = datetime.fromisoformat(s).astimezone()
    except (ValueError, OverflowError, OSError):
        return None
    return datetime(d.year, d.month, d.day, d.hour, d.minute)     # str.replace·datetime.replace는 읽기 전용 이름 검사에 걸린다


def local_day(iso) -> date | None:
    d = _local(iso)
    return d.date() if d else None


def _chunks(seq, n: int = 400):
    seq = list(seq)
    for k in range(0, len(seq), n):
        yield seq[k:k + n]


def select_changes(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
                   limit: int = LEDGER_MAX, newest_first: bool = False, unbaseline: bool = True) -> list[dict]:
    """조건에 맞는 변경 행 — {id, snapshot_id, kind, path, old_sha256, new_sha256, detected_at, project}.
    projects: None = 모두, 아니면 프로젝트 이름 모음('미분류' = 프로젝트 없음). 날짜는 이 PC 지역 날짜(포함).
    unbaseline: 첫 등록(기준선)을 뺀다."""
    where, args = [], []
    if projects is not None:
        ps = sorted({str(p) for p in projects})
        if not ps:
            return []
        where.append(f"IFNULL(c.project, '미분류') IN ({','.join('?' * len(ps))})")
        args += ps
    if date_from is not None:                 # 지역 날짜 ±1일로 SQL에서 먼저 좁힌 뒤 아래에서 정확히
        where.append("c.detected_at >= ?")
        args.append((date_from - timedelta(days=1)).isoformat())
    if date_to is not None:
        where.append("c.detected_at < ?")
        args.append((date_to + timedelta(days=2)).isoformat())
    sql = ("SELECT c.id, c.snapshot_id, c.kind, c.path, c.old_sha256, c.new_sha256, c.detected_at, "
           "IFNULL(c.project, '미분류') FROM changes c"
           + (" WHERE " + " AND ".join(where) if where else "")
           + (" ORDER BY c.id DESC" if newest_first else " ORDER BY c.id"))
    keys = ("id", "snapshot_id", "kind", "path", "old_sha256", "new_sha256", "detected_at", "project")
    first_by_root = st.first_snapshot_by_root() if unbaseline else {}
    ext_base = st.ext_baseline() if unbaseline else {}
    out = []
    for row in st.conn.execute(sql, args):
        d = dict(zip(keys, row))
        if unbaseline and State.is_first_registration(d["kind"], d["path"], d["snapshot_id"], first_by_root, ext_base):
            continue
        if date_from is not None or date_to is not None:
            day = local_day(d["detected_at"])
            if day is None or (date_from is not None and day < date_from) or (date_to is not None and day > date_to):
                continue
        out.append(d)
        if len(out) >= limit:
            break
    return out


def doc_facts(st: State, shas) -> dict:
    """내용 지문 → {dwg, rev, saved_by} — 추출 기록(extracts)에서 읽기만. 못 읽는 행은 빈 값."""
    out: dict = {}
    want = sorted({s for s in shas if s})
    sql = ("SELECT sha256, json_extract(doc_json, '$.fields.DWG_NO.value'), json_extract(doc_json, '$.fields.REV.value'), "
           "json_extract(doc_json, '$.saved_by') FROM extracts WHERE sha256 IN ({})")
    for part in _chunks(want):
        try:
            rows = st.conn.execute(sql.format(",".join("?" * len(part))), part).fetchall()
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() or "busy" in str(e).lower():
                raise
            rows = []
            for s in part:                     # 깨진 JSON 한 행이 묶음 전체를 막지 않게 하나씩
                try:
                    rows += st.conn.execute(sql.format("?"), (s,)).fetchall()
                except sqlite3.OperationalError as e2:
                    if "locked" in str(e2).lower() or "busy" in str(e2).lower():
                        raise
        for sha, dwg, rev, who in rows:
            out[sha] = {"dwg": str(dwg) if dwg not in (None, "") else "", "rev": str(rev) if rev not in (None, "") else "",
                        "saved_by": str(who) if who not in (None, "") else ""}
    return out


def details_of(st: State, ids) -> dict:
    """변경 id → {items(숨긴 오탐 뺌), photos(전/후 사진 묶음 수)}."""
    out: dict = {}
    for part in _chunks(ids):
        for cid, js, caps, dis in st.conn.execute(
                "SELECT change_id, items_json, captures_json, dismissed_json FROM change_details "
                f"WHERE change_id IN ({','.join('?' * len(part))})", part):
            try:
                items = json.loads(js or "[]")
                dismissed = json.loads(dis or "{}")
            except (ValueError, TypeError):
                items, dismissed = [], {}
            try:
                capd = json.loads(caps or "{}")
            except (ValueError, TypeError):
                capd = {}
            photos = sum(1 for v in (capd.values() if isinstance(capd, dict) else ())
                         if isinstance(v, dict) and (v.get("before") or v.get("after") or v.get("b64")))
            vis = [it for k, it in enumerate(items if isinstance(items, list) else [])
                   if isinstance(it, dict) and str(k) not in (dismissed if isinstance(dismissed, dict) else {})]
            out[int(cid)] = {"items": vis, "photos": photos}
    return out


def acks_by_change(st: State, ids) -> dict:
    """변경 id → [{by, note, at}] (오래된 것부터)."""
    out: dict = {}
    for part in _chunks(ids):
        for cid, by, note, at in st.conn.execute(
                f'SELECT change_id, "by", note, at FROM acks WHERE change_id IN ({",".join("?" * len(part))}) ORDER BY id',
                part):
            out.setdefault(int(cid), []).append({"by": by or "", "note": note or "", "at": at or ""})
    return out


def headlines(st: State, ids, was: bool = False) -> dict:
    """변경 id → '무엇이 어떻게' 한 줄 (화면·메일과 같은 State.change_headlines). was: '지금(이전 …)' 꼴 — 항목 값에서 바로 (Y2 H1)."""
    out: dict = {}
    for part in _chunks(ids, 200):
        out.update(st.change_headlines(part, was=was))
    return out


ISSUED_NOTE = "출도본으로 기록 — 이후 원본 변경은 '출도 후 변경'으로 알림"
ISSUED_NOTE_SHORT = "출도본으로 기록됨"          # 출도 폴더 설정을 모를 때(그 설정을 남긴 검사 전 기록) — 뒷절의 약속은 빼고 사실만
# 마지막 검사의 출도 폴더 설정(JSON 목록, cli._track_issued_po가 남긴다) — 설정 파일을 못 읽는 사내망이 감시 화면과 같은
# 판단을 하게 (rv0676 재검토 RS2)
ISSUED_FOLDERS_META = "issued_folders_cfg"
_MOVED_OUT = re.compile(r"\(으\)로 옮겨(?:짐|지며)")


def _issued_cfg(st: State) -> dict | None:
    try:
        v = json.loads(st.get_meta(ISSUED_FOLDERS_META) or "null")
    except (ValueError, TypeError, sqlite3.OperationalError):
        return None
    return {"issued_folders": v} if isinstance(v, list) else None


def _move_marked(js, moved_in: bool) -> bool:
    """상세 항목(JSON)에 이동 참고가 있나 — 추가 쪽 '이름·위치만 바뀜 — 이전: …'·'…에서 옮겨짐'(State._MOVED_FROM),
    삭제 쪽 '…(으)로 옮겨짐 — 파일이 없어진 것이 아닙니다'·'…(으)로 옮겨지며 내용도 바뀜' (cli._pair_moves 문구)."""
    try:
        its = json.loads(js or "[]")
    except (ValueError, TypeError):
        return False
    for i in its if isinstance(its, list) else ():
        if isinstance(i, dict) and i.get("kind") == "CHECK_SKIPPED":
            t = str(i.get("new") or "")
            if (State._MOVED_FROM.match(t) if moved_in else _MOVED_OUT.search(t)):
                return True
    return False


def added_notes(st: State, chs, cfg: dict | None = None) -> dict:
    """추가 변경의 참고 한 줄 — {변경 id: (글, 짝 삭제 기록 id 또는 None)}. 표시만 한다(판정·미확인 수는 그대로).
    감시 화면 상세·사내망 상세·대장 요약이 같은 글을 쓴다.
    - 되살아남: 같은 경로의 바로 앞 기록이 같은 바이트(내용 지문)의 삭제면 'MM-DD 삭제(#id)와 같은 내용 — 되살아남'. '이전 판이 없는
      새 파일'로만 보여 삭제와 이어지지 않았다 (rv0676 WE2). 이동 짝(그 추가가 '이름·위치만 바뀜'이거나 그 삭제가 '옮겨짐')은
      뺀다 — 이름을 바꿨다 되돌린 파일에 '되살아남'이 붙어 같은 대장의 '옮겨짐'과 어긋났다 (rv0676 재검토 RS1)
    - 출도본: 그 판이 출도본으로 기록됐고(issued.record_issued가 남긴 issued_copies) 지금도 출도 폴더 안이면
      ISSUED_NOTE. 출도 폴더 첫 복사가 '새 파일'뿐이었다 (rv0676 WE3). cfg가 없으면(사내망) 마지막 검사가 남긴 출도 폴더 설정
      (ISSUED_FOLDERS_META)으로 같은 판단을 하고, 그것도 없으면 약속 없는 ISSUED_NOTE_SHORT — 설정을 끈 집에서 사내망만
      '출도 후 변경으로 알림'이라 했다 (RS2)"""
    adds = [c for c in chs if c.get("kind") == "added" and c.get("new_sha256")]
    if not adds:
        return {}
    if cfg is None:
        cfg = _issued_cfg(st)
    paths = sorted({str(c["path"]) for c in adds})
    hist: dict = {}
    issued: set = set()
    for part in _chunks(paths):
        q = ",".join("?" * len(part))
        for cid, path, kind, osha, at in st.conn.execute(
                f"SELECT id, path, kind, old_sha256, detected_at FROM changes WHERE path IN ({q}) ORDER BY id", part):
            hist.setdefault(path, []).append((int(cid), kind, osha, at))
        try:
            issued |= {(p, s) for p, s in st.conn.execute(
                f"SELECT path, sha256 FROM issued_copies WHERE path IN ({q})", part)}
        except sqlite3.OperationalError as e:           # 옛 기록 파일에는 표가 없다
            if "locked" in str(e).lower() or "busy" in str(e).lower():
                raise
    from watcher.issued import in_issued_folder
    pairs: dict = {}
    for c in adds:
        cid, path, sha = int(c["id"]), str(c["path"]), c["new_sha256"]
        prev = [h for h in hist.get(path, ()) if h[0] < cid]
        if prev and prev[-1][1] == "removed" and prev[-1][2] == sha:
            pairs[cid] = prev[-1]
    moved: set = set()
    want = sorted(set(pairs) | {h[0] for h in pairs.values()})
    for part in _chunks(want):
        for did, js in st.conn.execute(
                f"SELECT change_id, items_json FROM change_details WHERE change_id IN ({','.join('?' * len(part))})", part):
            if _move_marked(js, int(did) in pairs):        # 추가 쪽은 '옮겨 옴', 삭제 쪽은 '옮겨 감' 참고
                moved.add(int(did))
    out: dict = {}
    for c in adds:
        cid, path, sha = int(c["id"]), str(c["path"]), c["new_sha256"]
        notes, pair = [], None
        rm = pairs.get(cid)
        if rm is not None and cid not in moved and rm[0] not in moved:
            pair = rm[0]
            d = _local(rm[3])
            notes.append(f"{d:%m-%d} 삭제(#{pair})와 같은 내용 — 되살아남" if d else f"삭제(#{pair})와 같은 내용 — 되살아남")
        if (path, sha) in issued:
            if cfg is None:
                notes.append(ISSUED_NOTE_SHORT)
            elif in_issued_folder(path, cfg):
                notes.append(ISSUED_NOTE)
        if notes:
            out[cid] = (" · ".join(notes), pair)
    return out


# ── 보고용 칸의 말 (검토 Y3 L4) — 저장 글은 그대로, 대장에 보일 때만 ─────────────────────────────────────────────
_SCREEN_HINT = re.compile(r"\s*\((?:설정|화면|도움말|메뉴) ›[^()]*\)")       # '(설정 › 고급에서 켤 수 있음)' — 화면에서 하는 일 안내
_RO_JOSA = re.compile(r"(\S+?)\(으\)로")
_DIGIT_RO = {"0": "으로", "1": "로", "2": "로", "3": "으로", "4": "로", "5": "로", "6": "으로", "7": "로", "8": "로", "9": "로"}


def josa_ro(word: str) -> str:
    """'로'/'으로' — 끝 글자의 받침으로(받침 없음·ㄹ → '로'). 영문은 읽는 소리(m·n → '으로', 그 밖 → '로' — dxf·pdf·xlsx·dwg),
    숫자도 읽는 소리(0 영·3 삼·6 육 → '으로'). 글자가 없으면 '(으)로' 그대로."""
    for ch in reversed(str(word or "")):
        if "가" <= ch <= "힣":
            jong = (ord(ch) - 0xAC00) % 28
            return "로" if jong in (0, 8) else "으로"
        if ch.isascii() and ch.isalpha():
            return "으로" if ch.lower() in "mn" else "로"
        if ch in _DIGIT_RO:
            return _DIGIT_RO[ch]
    return "(으)로"


_QUOTED = re.compile(r"('[^'\n]*')")       # 안내 글 속 값('NOTE 1'·'홍길동')은 따옴표 안 — 건드리지 않는다


def ledger_words(text) -> str:
    """대장 칸에 보일 글 — 저장 글의 '(으)로' 자리표를 앞말에 맞는 조사로, 화면 안내 괄호('(설정 › 고급에서 켤 수 있음)')는 빼고,
    옛 낱말 '검토 필요'는 '확인 필요'로. 검사가 단 안내·참고 글(시스템 문장)에만 쓴다 — 값 칸·근거 줄에는 쓰지 않고, 안내 글 속
    따옴표 값도 그대로 둔다(원칙 4)."""
    if not text:
        return text

    def _words(s: str) -> str:
        s = "확인 필요".join(_SCREEN_HINT.sub("", s).split("검토 필요"))     # 옛 저장 글의 낱말 (2026-11-18 통일)
        return _RO_JOSA.sub(lambda m: m.group(1) + josa_ro(m.group(1)), s)
    # 따옴표 안이 낱말 그 자체('검토 필요'로 올립니다)인 것만 바꾼다 — 값 속 '검토 필요 사항'은 그대로
    return "".join(("'확인 필요'" if p == "'검토 필요'" else p) if k % 2 else _words(p)
                   for k, p in enumerate(_QUOTED.split(str(text))))


_MOVE_OUT_NOTE = re.compile(r"^(?P<to>.+?)\(으\)로 (?P<how>옮겨짐|옮겨지며 내용도 바뀜)(?: — |$)")


def move_side(items) -> str:
    """이름·위치 바뀜(이동) 짝의 어느 쪽인가 — 'out'(옛 자리의 삭제 기록: '…(으)로 옮겨짐'), 'in'(새 자리의 추가 기록:
    '이름·위치만 바뀜 — 이전: …'·'…에서 옮겨짐'), 아니면 ''. 검사가 단 참고 글(cli._pair_moves)만 본다."""
    from watcher.brief import _MOVE_MARK
    for i in items or ():
        if not isinstance(i, dict) or i.get("kind") != "CHECK_SKIPPED" or i.get("key") != "참고":
            continue
        t = " ".join(str(i.get("new") or "").split())
        if _MOVE_OUT_NOTE.match(t):
            return "out"
        if t.startswith(_MOVE_MARK.strip()) or State._MOVED_FROM.match(t):
            return "in"
    return ""


def _move_summary(items, side: str) -> str:
    """이동 기록의 '바뀐 것 요약' — 참고 글 전문(한 줄 요약의 40자 자르기 없이 옮긴 곳 경로 끝까지). 바뀐 값이 있으면 ''(요약은 값)."""
    if any(isinstance(i, dict) and i.get("kind") != "CHECK_SKIPPED" for i in items or ()):
        return ""
    for i in items or ():
        if not isinstance(i, dict) or i.get("key") != "참고":
            continue
        t = " ".join(str(i.get("new") or "").split())
        m = _MOVE_OUT_NOTE.match(t)
        if side == "out" and m:
            return (f"{m['to']}(으)로 옮겨짐" if m["how"] == "옮겨짐"
                    else f"{m['to']}(으)로 옮겨지며 내용도 바뀜 (바뀐 값은 새 위치 쪽 줄에)")
        if side == "in" and t:
            return t
    return ""


def _evidence_order(it) -> int:
    """근거 줄 차례 — 글자·행 변경(진짜 바뀐 것) → 표지(발주 대조 등) → 개정표 행 → 표제란 칸 → 표제란 일자. 제출용 대장에서 표제란
    DATE·REV 줄이 앞서고 진짜 변경(M-101 5.5→7.5kW)이 넷째 줄이라 '바뀐 것 요약'과 차례가 엇갈렸다 (ux21 daily 6). 차례만 바꾼다."""
    kind = str(getattr(it, "kind", "") or "")
    if kind == "FIELD_CHANGED" or kind.startswith("FIELD_"):
        from watcher.diff import field_base
        return 4 if field_base(getattr(it, "key", "")) in ("DATE", "일자", "날짜") else 3
    if kind.startswith("REVROW_"):
        return 2
    if kind == "CHECK_SKIPPED":
        return 1
    from watcher.diff import is_title_date_text
    return 4 if is_title_date_text(it) else 0


def _now_was(old_s: str, new_s: str, blank: str = "없음") -> str:
    """엑셀 한 칸 안의 값 짝 — '지금(이전 …)' (이전/지금 2026-11-21 L: 한 줄 맥락은 화살표 대신 이 꼴). 없던·없어진 값은 '없음',
    표 칸의 빈 값은 blank='(빈칸)' — 빈칸 → 글자 '없음'이 '없음(이전 없음)'으로 같은 값처럼 보였다 (검토 Y2 M1)."""
    from watcher.summary import was_pair
    o = blank if old_s in ("", "—") else old_s
    n = blank if new_s in ("", "—") else new_s
    return was_pair(o, n)


def evidence_lines(items, limit: int = EVIDENCE_LINES) -> list[str]:
    """근거 줄 — '구분 바뀐 곳: 지금 값(이전 값) · 위치' (2026-11-21 L, 화살표 대신 메일 머리 한 줄과 같은 꼴). 사람에게 보이는 이름·
    태그 줄의 앞머리 떼기는 메일·화면과 같은 함수로(_m_text_rows). 안내 줄 속 값 짝도 보일 때만 말로(unarrow — 저장 글은 그대로)."""
    from watcher.brief import (PO_MARK_KEY, _flabel, _fmt_row_values, _m_text_rows, fmt_val, item_kind_label, notice_text,
                               plain_where, text_key_label, unarrow)
    from watcher.diff import ChangeItem
    its = []
    for d in items:
        try:
            its.append(ChangeItem(**{k: d.get(k) for k in ("kind", "key", "old", "new", "where", "label")}))
        except (TypeError, AttributeError):
            continue
    rows = []
    for it in sorted(its, key=_evidence_order):
        kind = str(it.kind or "")
        lab = item_kind_label(it)
        where = plain_where(it.where or "")
        if kind == "CHECK_SKIPPED":
            note = ledger_words(unarrow(notice_text(it, full=True)))
            # 글이 이름으로 시작하면 이름을 두 번 싣지 않는다 — '내용 비교 — 내용 비교 안 함 …' (검토 Y3 L4)
            txt = (f"{lab}: {note}" if it.key and note.startswith(str(it.key)) else f"{lab}: {it.key} — {note}").rstrip(" —")
        elif kind.startswith("ROW_"):
            if kind == "ROW_CHANGED":
                rk, _, col = split_row_cell(it.key)
                txt = f"{lab} {rk or it.key} {col}: {_now_was(fmt_val(it.old), fmt_val(it.new), '(빈칸)')}"
            elif kind == "ROW_ADDED":
                txt = f"{lab} {it.key}: {_fmt_row_values(it.new)}"
            elif kind == "ROW_REMOVED":
                txt = f"{lab} {it.key}: {_fmt_row_values(it.old)}"
            else:
                txt = f"{lab} {it.key}: {it.new or ''}"
            if it.label:
                txt += f" ({it.label})"
        else:
            g = not kind.startswith(("TEXT_", "FIELD_"))
            old_s, new_s = fmt_val(it.old, g), fmt_val(it.new, g)
            # 태그 줄은 태그를 바뀐 곳으로 한 번(앞머리 떼기), 짝 이름표('M-101: MOTOR 5.5kW → MOTOR 7.5kW')는 태그마다 — 그 짝이 이 줄의
            # 값일 때만(다른 태그의 짝이면 줄 값 그대로). 같은 값을 두 번 적지 않는다 (ux24 RD7)
            prs = _m_text_rows(it) if kind == "TEXT_CHANGED" else []
            if prs and all(str(o) in " ".join(str(it.old or "").split()) and str(n) in " ".join(str(it.new or "").split())
                           for _t, o, n in prs):
                txt = f"{lab} " + "; ".join(f"{t}: {_now_was(fmt_val(o, g), fmt_val(n, g))}" for t, o, n in prs)
            elif kind in ("TEXT_ADDED", "TEXT_REMOVED"):
                txt = f"{lab} {_m_text_rows(it)[0][0]}: {new_s if kind == 'TEXT_ADDED' else old_s}"     # 짝 이름표의 태그만
            else:
                name = text_key_label(it) if kind == "TEXT_CHANGED" else _flabel(it)
                txt = f"{lab} {name}: {_now_was(old_s, new_s, '(빈칸)' if kind.startswith('FIELD_') else '없음')}"
        if where:
            txt += f" · {where}"
        rows.append((kind == "CHECK_SKIPPED" and it.key == PO_MARK_KEY, " ".join(txt.split())[:400]))
    # 발주 후 변경 표지는 상한으로 잘라내지 않는다 — 다른 근거 줄이 자리를 내주고(표지 줄에도 이전·새 값과 위치가 있다, 원칙 4), 차례는
    # 그대로 둔다. 넘치면 엑셀 한 칸 글자 수만 지킨다 (ux25 E1)
    room = max(0, limit - sum(1 for is_mark, _ln in rows if is_mark))
    lines = []
    for is_mark, ln in rows:
        if is_mark or room:
            lines.append(ln)
            room -= 0 if is_mark else 1
    while sum(len(ln) + 1 for ln in lines) > EVIDENCE_CHARS:
        lines.pop()
    if len(rows) > len(lines):
        lines.append(f"외 {len(rows) - len(lines)}건 — 화면에서")
    return lines


ISSUE_SHEET = "확인 필요 처리"
ISSUE_COLUMNS = (("번호", 7), ("프로젝트", 12), ("종류", 16), ("파일 경로", 30), ("내용", 34), ("근거", 48),
                 ("검출 일시", 16), ("처리자", 14), ("처리 일시", 16), ("메모", 24))
ISSUE_WRAP = (1, 2, 3, 4, 5, 7, 9)
_FROZEN_DAYS = re.compile(r" · \d+일째$")


class LedgerRows(list):
    """대장 첫 시트(변경)의 값 줄 + 둘째 시트(검토 필요 처리)의 값 줄(.issues) + 셋째 시트(의견·담당, .notes — 있을 때만).
    list라 부르는 쪽(감시 화면 /export/ledger·사내망 /changes.xlsx)은 그대로 ledger_xlsx에 넘기면 시트가 함께 나간다 — 같은 범위
    (프로젝트·기간)로 뽑은 것이다."""
    issues: list = []
    notes: list = []


# 의견·담당 기록 (2026-11-23 사내망 협업) — 감사 때 '누가 무슨 의견을 냈고 누구에게 맡겼나'. 첫 시트에 칸을 더하면 A4 가로 한 쪽 폭
# (칸 폭 합 250, 검토 Y3 M1)을 넘어 따로 시트로 — 의견·담당이 하나도 없으면 시트도 없다(대장은 지금과 같다)
NOTE_SHEET = "의견·담당 기록"
NOTE_COLUMNS = (("대상", 10), ("번호", 7), ("프로젝트", 12), ("파일", 24), ("구분", 10), ("사람", 18), ("일시", 16),
                ("내용", 60))
NOTE_WRAP = (3, 5, 7)


def note_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
              limit: int = LEDGER_MAX) -> list[list]:
    """의견(처리 메모 포함)·담당 지정/해제를 일어난 차례로 — [대상, 번호, 프로젝트, 파일, 구분, 사람, 일시, 내용]. 범위: 대상의 프로젝트
    (None = 모두) · 기간(일어난 날). 표가 없는 옛 DB면 빈 목록. 읽기만 한다. 사람 글은 그대로 싣는다(수식 앞붙임은 build_xlsx가 막는다)."""
    from watcher.state import ack_origin, person_label
    if not st.has_collab():
        return []
    want = None if projects is None else {str(p) for p in projects}
    where: dict = {}

    def _tgt(kind: str, tid: int):
        k = (kind, tid)
        if k not in where:
            row = st.conn.execute(
                ("SELECT IFNULL(project, '미분류'), path FROM changes WHERE id = ?" if kind == "change" else
                 "SELECT IFNULL(project, '미분류'), path FROM issues WHERE id = ?"), (tid,)).fetchone()
            where[k] = row
        return where[k]
    ev: list = []
    for cid, kind, tid, by, body, at, ck in st.conn.execute(
            'SELECT id, target, target_id, "by", body, at, kind FROM comments ORDER BY id'):
        ev.append((str(at or ""), 0, int(cid), kind, int(tid), "처리 메모" if ck == "resolve" else "의견", by, body))
    for aid, kind, tid, who, by, at in st.conn.execute(
            'SELECT id, target, target_id, assignee, "by", at FROM assignments ORDER BY id'):
        ev.append((str(at or ""), 1, int(aid), kind, int(tid), "담당 지정" if who else "담당 해제", by,
                   f"담당: {ack_origin(who)[0]}" if who else "담당 없음"))
    ev.sort(key=lambda e: (e[0], e[1], e[2]))
    out: list = []
    for at, _t, _i, kind, tid, what, by, body in ev:
        t = _tgt(kind, tid)
        if t is None or (want is not None and t[0] not in want):
            continue                                   # 정리(숨김)·되돌린 기록이거나 범위 밖
        if date_from is not None or date_to is not None:
            d = local_day(at)
            if d is None or (date_from is not None and d < date_from) or (date_to is not None and d > date_to):
                continue
        out.append(["변경" if kind == "change" else "확인 필요", tid, t[0], PurePosixPath(t[1]).name, what,
                    person_label(by) or None, _local(at), str(body or "")[:2000] or None])
        if len(out) >= limit:
            out.append(["", "", "", f"{limit:,}줄에서 잘랐습니다 — 프로젝트나 기간을 좁혀 다시 내려받으세요"])
            break
    return out


def issue_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
               limit: int = LEDGER_MAX) -> list[list]:
    """검토 필요(issues)와 그 처리 기록 — 고객 감사에서 '불일치를 누가 언제 처리했나'를 뽑는다 (ux20 daily 6).
    범위: 프로젝트(None = 모두, '미분류' = 프로젝트 없음) · 기간(검출일 또는 처리일이 기간 안). 처리 전이면 처리 칸에 '처리 전'.
    자동 해소는 처리자 '자동(프로그램)', 메모에 사유. 읽기만 한다."""
    from watcher.brief import human_ev, post_pairs, unarrow, was_text
    from watcher.consistency import CODE_LABEL, issue_text
    where, args = [], []
    if projects is not None:
        ps = sorted({str(p) for p in projects})
        if not ps:
            return []
        where.append(f"IFNULL(project, '미분류') IN ({','.join('?' * len(ps))})")
        args += ps
    sql = ("SELECT id, IFNULL(project, '미분류'), code, path, message, evidence, detected_at, resolved_at, resolved_by "
           "FROM issues" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id")
    out: list = []
    for iid, proj, code, path, msg, ev, det_at, res_at, res_by in st.conn.execute(sql, args):
        if date_from is not None or date_to is not None:
            days = [d for d in (local_day(det_at), local_day(res_at) if res_at else None) if d is not None]
            if not any((date_from is None or d >= date_from) and (date_to is None or d <= date_to) for d in days):
                continue
        try:
            evl = json.loads(ev or "[]")
        except (ValueError, TypeError):
            evl = [ev] if ev else []
        by = str(res_by or "").strip()
        memo = None
        if res_at and by.startswith("자동 해소"):
            memo = by[len("자동 해소"):].strip(" —-:") or None
            by = "자동(프로그램)"
        elif res_at:
            by = ack_label(by) if by else "이름 없이 처리"
        # 문구·근거 줄의 값 짝은 보일 때만 '지금(이전 …)' — 저장 문구(대조 키)는 그대로 (이전/지금 2026-11-21 L). 출도 후 변경의
        # '바뀐 값'은 근거의 출도본·원본 값으로, 못 가르는 근거 줄은 원문 그대로 (검토 Y2 H2·H3·H4)
        evs = evl if isinstance(evl, list) else [evl]
        pairs = post_pairs(evs)
        # '내용'은 화면과 같은 사실 한 줄(consistency.issue_text) — 옛 긴 문장 '[P26-101] M-101: BOM 사양과 도면 기재가 다릅니다.'는
        # 프로젝트가 옆 칸과 겹쳤다 (검토 Y3 L4). 저장 문구에 굳은 'N일째'는 뺀다 — 날은 '검출 일시' 칸이 말한다
        fact = _FROZEN_DAYS.sub("", issue_text(code, msg, path, evidence=evs)[0] or str(msg or ""))
        out.append([int(iid), proj, CODE_LABEL.get(code, "확인 필요"), path, unarrow(fact, ev=False, pairs=pairs),
                    # 첫 시트와 같은 말로 — 저장 문구의 '레이어 EQUIPMENT'가 첫 시트의 '도면 층 EQUIPMENT'와 달랐다 (ux24 RD7)
                    "\n".join(was_text(human_ev(str(x)), pairs=pairs) for x in evs)[:2000] or None,
                    _local(det_at), by if res_at else "처리 전", _local(res_at) if res_at else None, memo])
        if len(out) >= limit:
            out.append(["", "", "", f"{limit:,}줄에서 잘랐습니다 — 프로젝트나 기간을 좁혀 다시 내려받으세요"])
            break
    return out


def ledger_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
                photo_note: str = "화면에서", limit: int = LEDGER_MAX, cfg: dict | None = None) -> list[list]:
    """설계 변경 대장의 값 줄들 (COLUMNS 차례). photo_note: 사진 칸의 안내('화면에서'·'사내망 화면에서').
    돌려주는 LedgerRows의 .issues에 같은 범위의 검토 필요 처리 기록(ISSUE_COLUMNS 차례)이 함께 실린다.
    cfg: 감시 설정(있으면 출도본 안내가 지금 출도 폴더 설정과 맞는지 같이 본다 — added_notes)."""
    out = LedgerRows(_change_rows(st, projects=projects, date_from=date_from, date_to=date_to,
                                  photo_note=photo_note, limit=limit, cfg=cfg))
    out.issues = issue_rows(st, projects=projects, date_from=date_from, date_to=date_to, limit=limit)
    out.notes = note_rows(st, projects=projects, date_from=date_from, date_to=date_to, limit=limit)
    return out


def _change_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
                 photo_note: str = "화면에서", limit: int = LEDGER_MAX, cfg: dict | None = None) -> list[list]:
    chs = select_changes(st, projects=projects, date_from=date_from, date_to=date_to, limit=limit + 1)
    cut = len(chs) > limit
    chs = chs[:limit]
    ids = [c["id"] for c in chs]
    det = details_of(st, ids)
    acks = acks_by_change(st, ids)
    # '바뀐 것 요약'은 항목 값에서 바로 '지금(이전 …)' — 만든 한 줄을 다시 쪼개면 바로 옆 '근거' 칸과 다른 이전 값이 됐다 (검토 Y2 H1)
    heads = headlines(st, ids, was=True)
    notes = added_notes(st, chs, cfg)          # 되살아남·출도본 기록 — 화면 상세와 같은 글 (rv0676 WE2·WE3)
    facts = doc_facts(st, [c["old_sha256"] if c["kind"] == "removed" else c["new_sha256"] for c in chs])
    rows = []
    for c in chs:
        sha = c["old_sha256"] if c["kind"] == "removed" else c["new_sha256"]
        f = facts.get(sha) or {}
        d = det.get(c["id"]) or {"items": [], "photos": 0}
        a = acks.get(c["id"]) or []
        ev = evidence_lines(d["items"])
        p = PurePosixPath(c["path"])
        # 지웠다 같은 자리에 되살린 파일은 구분 '되살림' — 저장값 '추가'는 그대로, 보일 때만 (Y1 P3b · rv0676 WE2 같은 바이트)
        from watcher.summary import kind_label
        # 폴더·이름을 옮긴 짝(옛 자리 삭제 + 새 자리 추가)은 구분 '이동' — '삭제' 4줄 + '추가' 4줄이 도면 4장을 지운 것으로 읽혔다
        # (검토 Y3 L4). 변경 하나 = 한 줄·번호는 그대로(확인 기록이 줄마다 따로다), 저장값(kind)도 그대로
        mv = move_side(d["items"]) if c["kind"] in ("added", "removed") else ""
        kl = ("되살림" if (c["kind"] == "added" and c["id"] in notes and notes[c["id"]][1]) else
              "이동" if mv else kind_label(c["kind"], d["items"]))
        who, when, memo = _ack_cells(a)
        # 화살표 없이 — 'M-101 MOTOR 7.5kW(이전 MOTOR 5.5kW)' (이전/지금 2026-11-21 L, 항목에서 바로 Y2 H1). 말 고치기(ledger_words)는
        # 검사가 단 글에만 — 이동 요약·참고 글뿐인 한 줄·덧붙임 참고. 값이 든 한 줄은 그대로(원칙 4)
        notes_only = not any(isinstance(i, dict) and i.get("kind") != "CHECK_SKIPPED" for i in d["items"])
        summ = ledger_words(_move_summary(d["items"], mv)) if mv else ""
        if not summ:
            summ = heads.get(c["id"]) or ""
            summ = ledger_words(summ) if (summ and notes_only) else summ
        summ = (summ or ("파일이 삭제됨" if c["kind"] == "removed" else ("되살림" if kl == "되살림" else "새 파일")
                         if c["kind"] == "added" else "변경 사실만 기록됨")
                + (f" · {ledger_words(notes[c['id']][0])}" if c["id"] in notes else ""))
        rows.append([
            int(c["id"]), c["project"], f.get("dwg") or None, f.get("rev") or None, p.name,
            kl, summ,
            "\n".join(ev) or None, f.get("saved_by") or None, _local(c["detected_at"]),
            who, when, memo,
            f"사진 {d['photos']}장 — {photo_note} (#{c['id']})" if d["photos"] else None])
    if cut:
        rows.append(["", "", "", "", f"{limit:,}줄에서 잘랐습니다 — 프로젝트나 기간을 좁혀 다시 내려받으세요"])
    if not rows:
        # 첫 검사 뒤 대장이 머리글만 있는 빈 표라 '고장인가' 했다 (ux21 buy 3) — 왜 비었는지 한 줄
        rows.append(["", "", "", "", EMPTY_NOTE])
    return rows


def _ack_cells(acks: list) -> tuple:
    """확인자 · 확인 일시 · 확인 메모 칸 (검토 Y3 M1). '확인 일시'는 진짜 날짜 값(정렬·기간 거르기가 '검사 일시'와 같게) — 여러 번 확인했으면
    마지막 확인의 시각, 확인자 칸은 줄마다 '이름 (yyyy-mm-dd hh:mm)'(오래된 것부터 — 누가 언제가 짝으로 남게). 한 번이면 이름만.
    메모는 메모를 남긴 확인이 둘 이상일 때만 '이름: 메모'로 — 한 사람 메모면 메모 그대로."""
    from watcher.state import ack_origin
    if not acks:
        return None, None, None
    at = [_local(x["at"]) for x in acks]
    if len(acks) == 1:
        who = ack_label(acks[0]["by"]) or None
    else:
        who = "\n".join(ack_label(x["by"]) + (f" ({t:%Y-%m-%d %H:%M})" if t else "") for x, t in zip(acks, at)) or None
    noted = [x for x in acks if x["note"]]
    memo = ("\n".join(f"{ack_origin(x['by'])[0] or '이름 없음'}: {x['note']}" for x in noted) if len(noted) > 1
            else "\n".join(x["note"] for x in noted)) or None
    return who, at[-1], memo


EMPTY_NOTE = ("이 범위에 변경이 아직 없습니다 — 기준선(처음 등록한 파일)은 변경이 아니라 싣지 않습니다. "
              "현행 파일 목록은 감시 PC 화면 [변경 이력]의 엑셀 내려받기에 있습니다")


def ledger_xlsx(rows: list, *, scope_text: str, generated_at: str | None = None) -> bytes:
    """값 줄 → xlsx 바이트 (메모리에서만)."""
    from watcher.forms.ledger import build_xlsx
    gen = generated_at or datetime.now().strftime("%Y-%m-%d %H:%M")
    n = sum(1 for r in rows if isinstance(r[0], int))
    title = f"설계 변경 대장 — 생성 {gen} · 변경 {n}건 · 범위: {scope_text}"
    # 보고용 — 긴 글 칸 줄바꿈·위 맞춤, 자동 필터, A4 가로 폭 1쪽·머리줄 반복·쪽 번호 (검토 Y3 M1)
    look = {"filter": True, "print": True, "header_right": f"생성 {gen}"}
    sheets = [("설계 변경 대장", title, COLUMNS, rows, dict(look, wrap=LEDGER_WRAP))]
    iss = getattr(rows, "issues", None)
    if iss is not None:
        m = sum(1 for r in iss if isinstance(r[0], int))
        done = sum(1 for r in iss if isinstance(r[0], int) and r[7] != "처리 전")
        sheets.append((ISSUE_SHEET, f"확인 필요 처리 기록 — 생성 {gen} · {m}건(처리 {done} · 처리 전 {m - done}) · 범위: {scope_text}",
                       ISSUE_COLUMNS, iss, dict(look, wrap=ISSUE_WRAP)))
    nts = getattr(rows, "notes", None)
    if nts:                                    # 의견·담당이 있을 때만 셋째 시트 (2026-11-23 사내망 협업)
        k = sum(1 for r in nts if isinstance(r[1], int))
        sheets.append((NOTE_SHEET, f"의견·담당 기록 — 생성 {gen} · {k}건 · 범위: {scope_text}",
                       NOTE_COLUMNS, nts, dict(look, wrap=NOTE_WRAP)))
    return build_xlsx(sheets)


def scope_text(projects, date_from: date | None, date_to: date | None) -> str:
    """대장 제목 줄의 범위 글."""
    ps = "모든 프로젝트" if projects is None else (", ".join(sorted(projects)) or "없음")
    if date_from or date_to:
        return f"{ps} · {date_from.isoformat() if date_from else '처음'} ~ {date_to.isoformat() if date_to else '오늘'}"
    return ps
