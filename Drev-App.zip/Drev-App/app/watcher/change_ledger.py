# -*- coding: utf-8 -*-
"""설계 변경 대장 — 프로젝트·기간으로 고른 변경을 엑셀 한 벌로 (기능 검토 갈래 N, 2026-11-02, FORMS.md 11절).

감시 화면(127.0.0.1) 전체 이력의 [설계 변경 대장]과 양식함 사내망 '변경 확인'(열람 권한자, 자기 범위)이 같이 쓴다.
- 한 변경 = 한 줄: 변경 번호·프로젝트·도면/문서번호·판(Rev)·파일·구분·바뀐 것 요약·근거(이전 → 새 · 위치)·저장자(saved_by)·
  검사 일시·확인자·확인 일시·확인 메모·사진('화면에서 #번호' — 사진 자체는 넣지 않는다).
- 첫 등록(기준선·나중에 더한 폴더·켠 확장자의 첫 검사)은 변경이 아니라 뺀다. 사람이 숨긴 오탐 항목은 근거에서 뺀다.
- 읽기만 한다(SELECT). 엑셀은 메모리에서만 — forms/ledger.build_xlsx(인라인 문자열·수식 앞붙임·_clean/_BAD_XML)를 그대로 쓴다.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import PurePosixPath

from watcher.state import KIND_LABEL, State, ack_label

LEDGER_MAX = 20_000                 # 한 벌 상한(행) — 넘으면 마지막 줄에 '잘림'
EVIDENCE_LINES = 30                 # 한 변경의 근거 줄 상한 — 넘으면 '외 N건'
COLUMNS = (("변경 번호", 9), ("프로젝트", 14), ("도면/문서번호", 18), ("판(Rev)", 8), ("파일", 30), ("구분", 7),
           ("바뀐 것 요약", 40), ("근거 (이전 → 새 · 위치)", 64), ("저장자", 12), ("검사 일시", 17), ("확인자", 18),
           ("확인 일시", 17), ("확인 메모", 30), ("사진", 18))


def parse_day(text) -> date | None:
    """'2026-11-02' → date. 비었거나 꼴이 틀리면 None."""
    s = str(text or "").strip()
    if len(s) != 10:
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _local(iso) -> datetime | None:
    """UTC ISO 시각 → 이 PC 지역 시각(분까지, 시간대 없는 값 — 엑셀 날짜 칸)."""
    s = str(iso or "")
    if not s:
        return None
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    elif "+" not in s[10:]:
        s += "+00:00"
    try:
        d = datetime.fromisoformat(s).astimezone()
    except (ValueError, OverflowError, OSError):
        return None
    return datetime(d.year, d.month, d.day, d.hour, d.minute)     # str.replace·datetime.replace는 읽기 전용 이름 검사에 걸린다


def local_day(iso) -> date | None:
    d = _local(iso)
    return d.date() if d else None


def _chunks(seq, n: int = 400):
    seq = list(seq)
    for k in range(0, len(seq), n):
        yield seq[k:k + n]


def select_changes(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
                   limit: int = LEDGER_MAX, newest_first: bool = False, unbaseline: bool = True) -> list[dict]:
    """조건에 맞는 변경 행 — {id, snapshot_id, kind, path, old_sha256, new_sha256, detected_at, project}.
    projects: None = 모두, 아니면 프로젝트 이름 모음('미분류' = 프로젝트 없음). 날짜는 이 PC 지역 날짜(포함).
    unbaseline: 첫 등록(기준선)을 뺀다."""
    where, args = [], []
    if projects is not None:
        ps = sorted({str(p) for p in projects})
        if not ps:
            return []
        where.append(f"IFNULL(c.project, '미분류') IN ({','.join('?' * len(ps))})")
        args += ps
    if date_from is not None:                 # 지역 날짜 ±1일로 SQL에서 먼저 좁힌 뒤 아래에서 정확히
        where.append("c.detected_at >= ?")
        args.append((date_from - timedelta(days=1)).isoformat())
    if date_to is not None:
        where.append("c.detected_at < ?")
        args.append((date_to + timedelta(days=2)).isoformat())
    sql = ("SELECT c.id, c.snapshot_id, c.kind, c.path, c.old_sha256, c.new_sha256, c.detected_at, "
           "IFNULL(c.project, '미분류') FROM changes c"
           + (" WHERE " + " AND ".join(where) if where else "")
           + (" ORDER BY c.id DESC" if newest_first else " ORDER BY c.id"))
    keys = ("id", "snapshot_id", "kind", "path", "old_sha256", "new_sha256", "detected_at", "project")
    first_by_root = st.first_snapshot_by_root() if unbaseline else {}
    ext_base = st.ext_baseline() if unbaseline else {}
    out = []
    for row in st.conn.execute(sql, args):
        d = dict(zip(keys, row))
        if unbaseline and State.is_first_registration(d["kind"], d["path"], d["snapshot_id"], first_by_root, ext_base):
            continue
        if date_from is not None or date_to is not None:
            day = local_day(d["detected_at"])
            if day is None or (date_from is not None and day < date_from) or (date_to is not None and day > date_to):
                continue
        out.append(d)
        if len(out) >= limit:
            break
    return out


def doc_facts(st: State, shas) -> dict:
    """내용 지문 → {dwg, rev, saved_by} — 추출 기록(extracts)에서 읽기만. 못 읽는 행은 빈 값."""
    out: dict = {}
    want = sorted({s for s in shas if s})
    sql = ("SELECT sha256, json_extract(doc_json, '$.fields.DWG_NO.value'), json_extract(doc_json, '$.fields.REV.value'), "
           "json_extract(doc_json, '$.saved_by') FROM extracts WHERE sha256 IN ({})")
    for part in _chunks(want):
        try:
            rows = st.conn.execute(sql.format(",".join("?" * len(part))), part).fetchall()
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() or "busy" in str(e).lower():
                raise
            rows = []
            for s in part:                     # 깨진 JSON 한 행이 묶음 전체를 막지 않게 하나씩
                try:
                    rows += st.conn.execute(sql.format("?"), (s,)).fetchall()
                except sqlite3.OperationalError as e2:
                    if "locked" in str(e2).lower() or "busy" in str(e2).lower():
                        raise
        for sha, dwg, rev, who in rows:
            out[sha] = {"dwg": str(dwg) if dwg not in (None, "") else "", "rev": str(rev) if rev not in (None, "") else "",
                        "saved_by": str(who) if who not in (None, "") else ""}
    return out


def details_of(st: State, ids) -> dict:
    """변경 id → {items(숨긴 오탐 뺌), photos(전/후 사진 묶음 수)}."""
    out: dict = {}
    for part in _chunks(ids):
        for cid, js, caps, dis in st.conn.execute(
                "SELECT change_id, items_json, captures_json, dismissed_json FROM change_details "
                f"WHERE change_id IN ({','.join('?' * len(part))})", part):
            try:
                items = json.loads(js or "[]")
                dismissed = json.loads(dis or "{}")
            except (ValueError, TypeError):
                items, dismissed = [], {}
            try:
                capd = json.loads(caps or "{}")
            except (ValueError, TypeError):
                capd = {}
            photos = sum(1 for v in (capd.values() if isinstance(capd, dict) else ())
                         if isinstance(v, dict) and (v.get("before") or v.get("after") or v.get("b64")))
            vis = [it for k, it in enumerate(items if isinstance(items, list) else [])
                   if isinstance(it, dict) and str(k) not in (dismissed if isinstance(dismissed, dict) else {})]
            out[int(cid)] = {"items": vis, "photos": photos}
    return out


def acks_by_change(st: State, ids) -> dict:
    """변경 id → [{by, note, at}] (오래된 것부터)."""
    out: dict = {}
    for part in _chunks(ids):
        for cid, by, note, at in st.conn.execute(
                f'SELECT change_id, "by", note, at FROM acks WHERE change_id IN ({",".join("?" * len(part))}) ORDER BY id',
                part):
            out.setdefault(int(cid), []).append({"by": by or "", "note": note or "", "at": at or ""})
    return out


def headlines(st: State, ids) -> dict:
    """변경 id → '무엇이 어떻게' 한 줄 (화면·메일과 같은 State.change_headlines)."""
    out: dict = {}
    for part in _chunks(ids, 200):
        out.update(st.change_headlines(part))
    return out


def _evidence_order(it) -> int:
    """근거 줄 차례 — 글자·행 변경(진짜 바뀐 것) → 표지(발주 대조 등) → 개정표 행 → 표제란 칸 → 표제란 일자. 제출용 대장에서 표제란
    DATE·REV 줄이 앞서고 진짜 변경(M-101 5.5→7.5kW)이 넷째 줄이라 '바뀐 것 요약'과 차례가 엇갈렸다 (ux21 daily 6). 차례만 바꾼다."""
    kind = str(getattr(it, "kind", "") or "")
    if kind == "FIELD_CHANGED" or kind.startswith("FIELD_"):
        from watcher.diff import field_base
        return 4 if field_base(getattr(it, "key", "")) in ("DATE", "일자", "날짜") else 3
    if kind.startswith("REVROW_"):
        return 2
    if kind == "CHECK_SKIPPED":
        return 1
    from watcher.diff import is_title_date_text
    return 4 if is_title_date_text(it) else 0


def evidence_lines(items, limit: int = EVIDENCE_LINES) -> list[str]:
    """근거 줄 — '구분 항목: 이전 → 새 (위치)'. 사람에게 보이는 이름은 메일·화면과 같은 함수로."""
    from watcher.brief import _flabel, _fmt_row_values, fmt_val, item_kind_label, notice_text, plain_where
    from watcher.diff import ChangeItem
    its = []
    for d in items:
        try:
            its.append(ChangeItem(**{k: d.get(k) for k in ("kind", "key", "old", "new", "where", "label")}))
        except (TypeError, AttributeError):
            continue
    lines = []
    for it in sorted(its, key=_evidence_order):
        kind = str(it.kind or "")
        lab = item_kind_label(it)
        where = plain_where(it.where or "")
        if kind == "CHECK_SKIPPED":
            txt = f"{lab}: {it.key} — {notice_text(it, full=True)}".rstrip(" —")
        elif kind.startswith("ROW_"):
            if kind == "ROW_CHANGED":
                rk, _, col = str(it.key).rpartition(".")
                txt = f"{lab} {rk or it.key} {col}: {fmt_val(it.old)} → {fmt_val(it.new)}"
            elif kind == "ROW_ADDED":
                txt = f"{lab} {it.key}: {_fmt_row_values(it.new)}"
            elif kind == "ROW_REMOVED":
                txt = f"{lab} {it.key}: {_fmt_row_values(it.old)}"
            else:
                txt = f"{lab} {it.key}: {it.new or ''}"
            if it.label:
                txt += f" ({it.label})"
        else:
            g = not kind.startswith(("TEXT_", "FIELD_"))
            name = _flabel(it)
            txt = f"{lab} {name}: {fmt_val(it.old, g)} → {fmt_val(it.new, g)}"
        if where:
            txt += f" · {where}"
        lines.append(" ".join(txt.split())[:400])
    if len(lines) > limit:
        lines = lines[:limit] + [f"외 {len(lines) - limit}건 — 화면에서"]
    return lines


ISSUE_SHEET = "검토 필요 처리"
ISSUE_COLUMNS = (("번호", 7), ("프로젝트", 14), ("종류", 20), ("파일 경로", 44), ("내용", 50), ("근거", 60),
                 ("검출 일시", 17), ("처리자", 16), ("처리 일시", 17), ("메모", 36))


class LedgerRows(list):
    """대장 첫 시트(변경)의 값 줄 + 둘째 시트(검토 필요 처리)의 값 줄(.issues). list라 부르는 쪽(감시 화면 /export/ledger·사내망
    /changes.xlsx)은 그대로 ledger_xlsx에 넘기면 두 시트가 함께 나간다 — 같은 범위(프로젝트·기간)로 뽑은 것이다."""
    issues: list = []


def issue_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
               limit: int = LEDGER_MAX) -> list[list]:
    """검토 필요(issues)와 그 처리 기록 — 고객 감사에서 '불일치를 누가 언제 처리했나'를 뽑는다 (ux20 daily 6).
    범위: 프로젝트(None = 모두, '미분류' = 프로젝트 없음) · 기간(검출일 또는 처리일이 기간 안). 처리 전이면 처리 칸에 '처리 전'.
    자동 해소는 처리자 '자동(프로그램)', 메모에 사유. 읽기만 한다."""
    from watcher.consistency import CODE_LABEL
    where, args = [], []
    if projects is not None:
        ps = sorted({str(p) for p in projects})
        if not ps:
            return []
        where.append(f"IFNULL(project, '미분류') IN ({','.join('?' * len(ps))})")
        args += ps
    sql = ("SELECT id, IFNULL(project, '미분류'), code, path, message, evidence, detected_at, resolved_at, resolved_by "
           "FROM issues" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id")
    out: list = []
    for iid, proj, code, path, msg, ev, det_at, res_at, res_by in st.conn.execute(sql, args):
        if date_from is not None or date_to is not None:
            days = [d for d in (local_day(det_at), local_day(res_at) if res_at else None) if d is not None]
            if not any((date_from is None or d >= date_from) and (date_to is None or d <= date_to) for d in days):
                continue
        try:
            evl = json.loads(ev or "[]")
        except (ValueError, TypeError):
            evl = [ev] if ev else []
        by = str(res_by or "").strip()
        memo = None
        if res_at and by.startswith("자동 해소"):
            memo = by[len("자동 해소"):].strip(" —-:") or None
            by = "자동(프로그램)"
        elif res_at:
            by = ack_label(by) if by else "이름 없이 처리"
        out.append([int(iid), proj, CODE_LABEL.get(code, "검토 필요"), path, msg,
                    "\n".join(str(x) for x in (evl if isinstance(evl, list) else [evl]))[:2000] or None,
                    _local(det_at), by if res_at else "처리 전", _local(res_at) if res_at else None, memo])
        if len(out) >= limit:
            out.append(["", "", "", f"{limit:,}줄에서 잘랐습니다 — 프로젝트나 기간을 좁혀 다시 내려받으세요"])
            break
    return out


def ledger_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
                photo_note: str = "화면에서", limit: int = LEDGER_MAX) -> list[list]:
    """설계 변경 대장의 값 줄들 (COLUMNS 차례). photo_note: 사진 칸의 안내('화면에서'·'사내망 화면에서').
    돌려주는 LedgerRows의 .issues에 같은 범위의 검토 필요 처리 기록(ISSUE_COLUMNS 차례)이 함께 실린다."""
    out = LedgerRows(_change_rows(st, projects=projects, date_from=date_from, date_to=date_to,
                                  photo_note=photo_note, limit=limit))
    out.issues = issue_rows(st, projects=projects, date_from=date_from, date_to=date_to, limit=limit)
    return out


def _change_rows(st: State, *, projects=None, date_from: date | None = None, date_to: date | None = None,
                 photo_note: str = "화면에서", limit: int = LEDGER_MAX) -> list[list]:
    chs = select_changes(st, projects=projects, date_from=date_from, date_to=date_to, limit=limit + 1)
    cut = len(chs) > limit
    chs = chs[:limit]
    ids = [c["id"] for c in chs]
    det = details_of(st, ids)
    acks = acks_by_change(st, ids)
    heads = headlines(st, ids)
    facts = doc_facts(st, [c["old_sha256"] if c["kind"] == "removed" else c["new_sha256"] for c in chs])
    rows = []
    for c in chs:
        sha = c["old_sha256"] if c["kind"] == "removed" else c["new_sha256"]
        f = facts.get(sha) or {}
        d = det.get(c["id"]) or {"items": [], "photos": 0}
        a = acks.get(c["id"]) or []
        ev = evidence_lines(d["items"])
        p = PurePosixPath(c["path"])
        rows.append([
            int(c["id"]), c["project"], f.get("dwg") or None, f.get("rev") or None, p.name,
            KIND_LABEL.get(c["kind"], c["kind"]),
            heads.get(c["id"]) or ("파일이 삭제됨" if c["kind"] == "removed" else
                                   "새 파일" if c["kind"] == "added" else "변경 사실만 기록됨"),
            "\n".join(ev) or None, f.get("saved_by") or None, _local(c["detected_at"]),
            "\n".join(ack_label(x["by"]) for x in a) or None,
            "\n".join(str(_local(x["at"]) or "")[:16] for x in a) or None,
            "\n".join(x["note"] for x in a if x["note"]) or None,
            f"사진 {d['photos']}장 — {photo_note} (#{c['id']})" if d["photos"] else None])
    if cut:
        rows.append(["", "", "", "", f"{limit:,}줄에서 잘랐습니다 — 프로젝트나 기간을 좁혀 다시 내려받으세요"])
    if not rows:
        # 첫 검사 뒤 대장이 머리글만 있는 빈 표라 '고장인가' 했다 (ux21 buy 3) — 왜 비었는지 한 줄
        rows.append(["", "", "", "", EMPTY_NOTE])
    return rows


EMPTY_NOTE = ("이 범위에 변경이 아직 없습니다 — 기준선(처음 등록한 파일)은 변경이 아니라 싣지 않습니다. "
              "현행 파일 목록은 감시 PC 화면 [전체 이력]의 엑셀 내려받기에 있습니다")


def ledger_xlsx(rows: list, *, scope_text: str, generated_at: str | None = None) -> bytes:
    """값 줄 → xlsx 바이트 (메모리에서만)."""
    from watcher.forms.ledger import build_xlsx
    gen = generated_at or datetime.now().strftime("%Y-%m-%d %H:%M")
    n = sum(1 for r in rows if isinstance(r[0], int))
    title = f"설계 변경 대장 — 생성 {gen} · 변경 {n}건 · 범위: {scope_text}"
    sheets = [("설계 변경 대장", title, COLUMNS, rows)]
    iss = getattr(rows, "issues", None)
    if iss is not None:
        m = sum(1 for r in iss if isinstance(r[0], int))
        done = sum(1 for r in iss if isinstance(r[0], int) and r[7] != "처리 전")
        sheets.append((ISSUE_SHEET, f"검토 필요 처리 기록 — 생성 {gen} · {m}건(처리 {done} · 처리 전 {m - done}) · 범위: {scope_text}",
                       ISSUE_COLUMNS, iss))
    return build_xlsx(sheets)


def scope_text(projects, date_from: date | None, date_to: date | None) -> str:
    """대장 제목 줄의 범위 글."""
    ps = "모든 프로젝트" if projects is None else (", ".join(sorted(projects)) or "없음")
    if date_from or date_to:
        return f"{ps} · {date_from.isoformat() if date_from else '처음'} ~ {date_to.isoformat() if date_to else '오늘'}"
    return ps
