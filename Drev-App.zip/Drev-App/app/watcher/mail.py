# -*- coding: utf-8 -*-
"""브리핑 메일: 초안(.eml) 생성 + (선택) smtplib 발송.

기본 방식은 '메일 초안 파일 생성'이다 (2026-08-25 결정) — 프로그램은 받는사람·제목·
본문·사진이 채워진 .eml을 briefs 폴더에 만들 뿐, 스스로 전송하지 않는다. 발송은
사람이 자기 메일 프로그램에서 [보내기]로 한다. 외부 전송 기본값 OFF(PRINCIPLE 1)가
구조적으로 보장되고, SMTP 서버 설정도 필요 없다.

SMTP 자동 발송은 사내 메일서버가 있는 회사용 선택지로 유지한다. 산출물 파일 자체는
어떤 경우에도 전송하지 않는다 (PRINCIPLE 1).
"""

from __future__ import annotations

import base64
import re
import smtplib
import socket
from email.message import EmailMessage
from pathlib import Path

# 브리핑 HTML 안의 내장 이미지: src="data:image/png;base64,..." 꼴
_DATA_URI = re.compile(r'src="data:(image/[a-z+.-]+);base64,([A-Za-z0-9+/=]+)"')

# 메일로 나가는 본문만 고친다 — 화면·briefs 폴더의 HTML은 그대로 (2026-10-19 구매 평가 2차 IT 심사)
# ① 감시 폴더 전체 경로(C:\…·\\서버\공유\…)가 든 title 속성: 메일에는 감시 폴더 이름과 그 아래 상대 경로만.
#    mail.show_paths: true로 켠다(기본 꺼짐)
_ABS_PATH_TITLE = re.compile(r'\s+title="(?:[A-Za-z]:[\\/]|\\\\|//)[^"]*"')
# ② 사진: '반출 금지' 계약 고객용 mail.images: false — 전/후 사진 묶음(brief.render_capture가 표식으로 감싼다)과
#    남은 내장 그림을 글 한 줄로. 기본은 켬(지금처럼)
_PHOTO_BLOCK = re.compile(r"<!--drev-photo-->.*?<!--/drev-photo-->", re.S)
_PHOTO_LEGEND = re.compile(r"<!--drev-legend-->.*?<!--/drev-legend-->", re.S)
_DATA_IMG = re.compile(r'<img\b[^>]*\bsrc="data:image/[^"]*"[^>]*>', re.S)
PHOTO_OFF_NOTE = ('<div style="color:#57606a;font-size:12.5px;margin:4px 0">사진은 감시 PC 화면에서 — 이 메일에는 '
                  '전/후 사진을 싣지 않도록 설정되어 있습니다(감시 PC 화면의 변경 상세에서 볼 수 있습니다).</div>')


def _subject(subject) -> str:
    """제목 — 줄바꿈 든 프로젝트명이 그날 메일을 멈췄다 (검토43 E 낮음 5). 양방향 제어문자는 보이는 대체 문자로 (보안 감사 2026-10-26)."""
    from watcher.brief import no_bidi
    return " ".join(no_bidi(str(subject)).split())


def _on(v, default: bool) -> bool:
    if v is None or v == "":
        return default
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("true", "1", "yes", "on", "예")


def mail_view(mail_cfg: dict, html_body: str) -> str:
    """메일로 나갈 본문 — 설정에 따라 감시 폴더 전체 경로·사진을 뺀다."""
    out = html_body or ""
    if not _on((mail_cfg or {}).get("show_paths"), False):
        out = _ABS_PATH_TITLE.sub("", out)
    if not _on((mail_cfg or {}).get("images"), True):
        out = _PHOTO_LEGEND.sub("", out)       # 메일 판 머리의 사진 설명 한 줄 (구매 평가 2차 F2)
        out = _PHOTO_BLOCK.sub(lambda m: PHOTO_OFF_NOTE, out)
        out = _DATA_IMG.sub("[사진 생략 — 감시 PC 화면에서]", out)
    return out


def plain_text_of(html_body: str, limit: int = 20000) -> str:
    """HTML 브리핑의 평문 대안 — 미리보기 창·알림·텍스트 전용 설정에서 제목 말고는
    아무 정보도 없었다 (검토19 브리핑 ⑨). 표는 줄 단위로 펴고 사진은 뺀다."""
    import html as _h
    t = re.sub(r"(?is)<(style|script|title)[^>]*>.*?</\1>", "", html_body)   # 제목은 Subject에 (검토32 A 4)
    t = re.sub(r"(?is)<img[^>]*alt=([\"'])(.*?)\1[^>]*>", r"[사진: \2]", t)
    # 셀 안의 <br>·<div>는 공백으로 — 표 한 행이 두 줄로 갈라져 '| 머리말(문단 2)'가 다음 줄에 홀로 섰다 (검토33 A 낮음 5)
    def _flatten_cell(m):
        inner = m.group(3)
        if re.search(r"(?i)<table\b", inner):
            # 중첩 표가 든 칸(참고 상자)은 손대지 않는다 — 비탐욕 짝짓기가 안쪽 </td>에서 끊겨
            # 그날 제일 중요한 문장이 표 머리글에 붙었다 (검토34 A 2)
            return m.group(0)
        return "<t%s%s>%s</t%s>" % (m.group(1), m.group(2),
                                    re.sub(r"(?i)<br\s*/?>|</?(?:div|p)\b[^>]*>", " ", inner), m.group(1))

    t = re.sub(r"(?is)<t([dh])\b([^>]*)>(.*?)</t\1>", _flatten_cell, t)
    # 제목(h2) 안의 원본 줄바꿈이 평문에서 '변경 2건' / '/ 검토 필요 3건' 두 줄로 갈랐다 (재검토 R5-8)
    t = re.sub(r"(?is)<(h[1-6])\b([^>]*)>(.*?)</\1>",
               lambda m: "<%s%s>%s</%s>" % (m.group(1), m.group(2), " ".join(m.group(3).split()), m.group(1)), t)
    # 여는 블록 태그에서도 줄을 바꾼다 — 닫는 태그에서만 바꿔 'P26-032_BOM_전장.xlsx내용이 바뀌었는데'(span 뒤 div)·
    # '오늘 확인할 것 도면 …'(strong 뒤 ul)처럼 붙었다 (재검토 R5-8). 이미 줄이 바뀐 자리에는 더하지 않는다(\x01 표식)
    t = re.sub(r"(?i)<(?:div|p|ul|ol|li|table|h[1-6])\b", lambda m: "\x01" + m.group(0), t)
    t = re.sub(r"(?i)<br\s*/?>", "\n", t)
    t = re.sub(r"(?i)</(p|div|li|tr|h[1-6]|table|tbody|ul|ol)>", "\n", t)
    # strong·b는 인라인이라 줄을 끊으면 '참고 / — 어제…'처럼 갈라진다. 다만 붙여 쓰면 앞말과 엉키므로
    # 공백 하나로 (검토34 A 2)
    t = re.sub(r"(?i)</(strong|b)>", " ", t)
    t = re.sub(r"(?i)</t[dh]>", " | ", t)
    t = re.sub(r"(?s)<[^>]+>", "", t)
    t = _h.unescape(t)
    t = re.sub(r"(^|\n)[ \t]*\x01", r"\1", t)     # 글이 시작되거나 이미 줄이 바뀐 자리의 여는 태그는 그대로
    t = re.sub("\x01", "\n", t)                # (str의 그 메서드 이름은 읽기 전용 검사가 금한다 — re로)
    lines = [" ".join(ln.split()) for ln in t.splitlines()]
    lines = [ln.rstrip(" |") for ln in lines]
    out, blank = [], 0
    for ln in lines:
        if not ln:
            blank += 1
            if blank > 1:
                continue
        else:
            blank = 0
        out.append(ln)
    text = "\n".join(out).strip()
    if len(text) > limit:
        cut = text.rfind("\n", 0, limit)          # 행 중간에서 자르지 않는다
        text = text[:cut if cut > 0 else limit] + "\n… (이하 생략 — HTML 본문을 보세요)"
    return text or "HTML 메일을 지원하는 클라이언트에서 확인해주세요."


_ADDR_BAD_CHARS = set('<>,;"()[]\\')


def check_addr(addr) -> str:
    """메일 주소 하나 검사 — 돌려줌: NFC로 고른 주소(한글 도메인은 그대로 둔다 — 보낼 때 wire_addr가 IDNA로 바꾼다).
    안 되면 ValueError(까닭, 쉬운 말). 로컬 파트(@ 앞)에 영문이 아닌 글자가 있으면 거부 — SMTPUTF8을 광고하지 않는
    보통 사내 서버(Exchange·hMailServer 등)는 받지 않는다 (검토20 r10-2)."""
    import unicodedata
    a = unicodedata.normalize("NFC", str(addr or "")).strip()
    if not a:
        raise ValueError("빈 주소")
    if any(ch.isspace() or ch in _ADDR_BAD_CHARS or ord(ch) < 32 or ord(ch) == 127 for ch in a):
        raise ValueError(f"메일 주소에 쓸 수 없는 글자(빈칸·괄호·따옴표 등)가 있습니다: {a[:60]}")
    local, at, dom = a.rpartition("@")
    if not at or not local or "@" in local or not dom.strip("."):
        raise ValueError(f"메일 주소 꼴이 아닙니다: {a[:60]} (예: kim@company.co.kr)")
    if len(local) > 64 or len(a) > 254:
        raise ValueError(f"메일 주소가 너무 깁니다: {a[:60]}")
    if not local.isascii():
        raise ValueError(f"@ 앞에 영문이 아닌 글자가 있는 주소는 보통 메일 서버가 받지 않습니다 — 영문 주소로 적어 주세요: {a[:60]}")
    _idna(dom, a)
    return a


def _idna(dom: str, shown: str = "") -> str:
    """도메인 → ASCII (한글 도메인 '회사.co.kr' → 'xn--….co.kr'). 바꿀 수 없으면 ValueError."""
    if dom.isascii():
        return dom
    try:
        return dom.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError(f"메일 주소의 도메인(@ 뒤)을 쓸 수 없습니다: {(shown or dom)[:60]}")


def wire_addr(addr: str) -> str:
    """보낼 때 쓰는 꼴 — 도메인만 IDNA(punycode)로. 머리글·봉투가 ASCII라 SMTPUTF8 없는 서버도 받는다 (검토20 r10-2)."""
    local, at, dom = str(addr).rpartition("@")
    if not at:
        return str(addr)
    try:
        return f"{local}@{_idna(dom)}"
    except ValueError:
        return str(addr)


def _segments(text: str) -> list:
    """칸 하나를 ; , 줄바꿈에서 나눈다 — 따옴표("홍, 길동")·꺾쇠(<…>) 안의 구분자는 그대로."""
    out, cur, quoted, angled = [], [], False, False
    for ch in text:
        if quoted:
            cur.append(ch)
            quoted = ch != '"'
            continue
        if angled:
            cur.append(ch)
            angled = ch != ">"
            continue
        if ch in ";,\r\n":
            out.append("".join(cur))
            cur = []
            continue
        quoted, angled = ch == '"', ch == "<"
        cur.append(ch)
    out.append("".join(cur))
    return out


def parse_addrs(values) -> tuple[list, list]:
    """받는 사람 칸들 → (쓸 주소 [...], 못 쓰는 것 [(적은 글자, 까닭)…]).
    한 칸에 'a@x; b@x'·'a@x, b@x'·줄바꿈·빈칸으로 여럿 (검토66 D3), '홍길동 <hong@x.kr>'·'"홍, 길동" <h@x.kr>'은 주소만 —
    빈칸에서 잘라 '홍길동'을 주소로 보내 그날 모든 통이 실패하던 것 (검토20 r10-1). 대소문자만 다른 같은 주소는 한 번 (검토67 D9)."""
    good: list = []
    bad: list = []
    seen: set = set()
    for v in values or []:
        for seg in _segments(str(v or "")):
            angles = re.findall(r"<([^<>]*)>", seg)
            rest = re.sub(r'"[^"]*"?|<[^<>]*>?', " ", seg)
            cands = [a.strip() for a in angles]
            for tok in rest.split():
                tok = tok.strip("<>\"'")
                if "@" in tok:
                    cands.append(tok)
                elif tok and not angles:          # '이름 <주소>'의 이름은 버리고, 주소 없이 적은 글자는 못 쓰는 것으로
                    bad.append((tok, f"메일 주소가 아닙니다: {tok[:60]}"))
            for a in cands:
                if not a:
                    continue
                try:
                    a = check_addr(a)
                except ValueError as e:
                    bad.append((a, str(e)))
                    continue
                k = wire_addr(a).lower()
                if k not in seen:
                    seen.add(k)
                    good.append(a)
    return good, bad


def split_addrs(values) -> list:
    """받는 사람 목록 — 쓸 수 있는 주소만 (parse_addrs). 못 쓰는 것은 버린다 — 저장 화면(web.save_mail)이 따로 알리고 거부한다."""
    return parse_addrs(values)[0]


def _to_header(recipients) -> str:
    """To 머리글 — 쓸 수 있는 주소만, 한글 도메인은 IDNA로 (검토20 r10-1·2)."""
    return ", ".join(wire_addr(a) for a in split_addrs(recipients))


def _from_header(sender) -> str:
    """From 머리글 — 주소만 있으면 받은 편지함에 주소로만 보였다 (재검토 R5-11). 'Drev <주소>'로.
    이름을 직접 적었으면('공무팀 <a@x>') 이름은 그대로 둔다. 한글 도메인은 IDNA로 (검토20 r10-2)."""
    from email.utils import formataddr, parseaddr
    s = str(sender or "").strip()
    name, addr = parseaddr(s)
    if not addr:
        return s
    wired = wire_addr(addr)
    if name or "<" in s:
        return formataddr((name, wired)) if wired != addr else s
    return formataddr((FROM_NAME, wired))


FROM_NAME = "Drev"


def build_message(mail_cfg: dict, subject: str, html_body: str) -> EmailMessage:
    """발송용 메시지. 전/후 사진은 cid 파트로 — data: URI 그대로 보내면 Outlook에서
    사진이 빈 칸이었다(.eml 초안만 변환하고 있었음, 2026-09-04 검토 web H3)."""
    from email.utils import formatdate, make_msgid
    html_body = mail_view(mail_cfg, html_body)
    msg = EmailMessage()
    msg["Subject"] = _subject(subject)
    msg["From"] = _from_header(mail_cfg["sender"])
    msg["To"] = _to_header(mail_cfg["recipients"])
    msg["Date"] = formatdate(localtime=True)      # 없으면 일부 서버·클라이언트가 스팸으로 (검토19 브리핑 ⑭)
    msg["Message-ID"] = make_msgid(domain="drev.local")
    msg.set_content(plain_text_of(html_body))
    _attach_html(msg, html_body)
    return msg


def _attach_html(msg: EmailMessage, html_body: str) -> None:
    html, images = _html_with_cid_images(html_body)
    msg.add_alternative(html, subtype="html")
    payload = msg.get_payload()[-1]  # 방금 넣은 HTML 파트
    for cid, mime, data in images:
        maintype, subtype = mime.split("/", 1)
        payload.add_related(data, maintype=maintype, subtype=subtype, cid=f"<{cid}>")


def _html_with_cid_images(html_body: str) -> tuple[str, list[tuple[str, str, bytes]]]:
    """data: URI 내장 이미지를 cid: 참조로 바꾼다.

    Outlook 등 상당수 메일 클라이언트가 data: URI 이미지를 차단하므로,
    메일에서는 이미지를 별도 MIME 파트(Content-ID)로 실어야 보인다.
    돌려주는 값: (치환된 HTML, [(cid, mime, bytes)])"""
    images: list[tuple[str, str, bytes]] = []

    def _swap(m: re.Match) -> str:
        cid = f"img{len(images) + 1}"
        images.append((cid, m.group(1), base64.b64decode(m.group(2))))
        return f'src="cid:{cid}"'

    return _DATA_URI.sub(_swap, html_body), images


def write_eml(mail_cfg: dict, subject: str, html_body: str, out_path: Path) -> Path:
    """보내기만 하면 되는 메일 초안(.eml)을 만든다.

    X-Unsent: 1 헤더 덕에 Outlook에서 더블클릭하면 '받은 메일'이 아니라
    받는사람·제목·본문이 채워진 **작성 중인 초안**으로 열린다."""
    from email.utils import formatdate, make_msgid
    html_body = mail_view(mail_cfg, html_body)
    msg = EmailMessage()
    msg["Subject"] = _subject(subject)
    msg["X-Unsent"] = "1"
    msg["Date"] = formatdate(localtime=True)       # Thunderbird처럼 초안을 그대로 보내는 경로용
    msg["Message-ID"] = make_msgid(domain="drev.local")
    if mail_cfg.get("recipients"):
        msg["To"] = _to_header(mail_cfg["recipients"])
    if mail_cfg.get("sender"):
        msg["From"] = _from_header(mail_cfg["sender"])
    msg.set_content(plain_text_of(html_body))
    _attach_html(msg, html_body)
    # 줄끝은 CRLF(RFC 5322) — 기본 정책은 LF만 써서 엄격한 .eml 검사(일부 보안 게이트웨이)가 거부할 수 있었다 (재검토 R5-9)
    from email import policy as _policy
    out_path.write_bytes(msg.as_bytes(policy=_policy.SMTP))
    return out_path


_NO_ANSWER = ("서버가 응답하지 않습니다 — 보안 방식(SSL/STARTTLS)과 포트(465/587)가 맞는지 확인하세요. "
              "SSL은 보통 465, STARTTLS는 587입니다. 그룹웨어(하이웍스·네이버웍스 등)는 대부분 465 + SSL입니다")
_MODE_MISMATCH = ("메일 서버와 보안 방식이 맞지 않습니다 — 보안 방식(SSL/STARTTLS)과 포트(465/587)가 맞는지 확인하세요. "
                  "SSL은 보통 465, STARTTLS는 587입니다(설정 › 메일에서 둘 중 하나만 켭니다)")


def _friendly_smtp_error(e: Exception) -> str:
    """SMTP 예외 → 어느 칸을 고쳐야 하는지 알려주는 한국어 메시지 (2026-08-25 UX 검토).
    문장 끝 마침표는 붙이지 않는다 — 부르는 쪽이 문장을 잇는다(재검토 R5-5: '확인하세요..')."""
    import ssl
    if isinstance(e, socket.gaierror):
        return "SMTP 서버 주소를 찾을 수 없습니다 — 서버 주소 칸의 오타를 확인하세요"
    if isinstance(e, (TimeoutError, socket.timeout)):
        return _NO_ANSWER
    if isinstance(e, smtplib.SMTPServerDisconnected) and "timed out" in str(e).lower():
        # smtplib가 배너 대기 타임아웃을 SMTPServerDisconnected로 감싸 'Connection unexpectedly closed: timed out'이
        # 날것으로 떴다 (재검토 R5-3) — 465(SSL) 포트에 평문으로 붙으면 이렇게 된다
        return _NO_ANSWER
    if isinstance(e, smtplib.SMTPAuthenticationError):
        return ("로그인 거부 — 계정/비밀번호를 확인하세요. 그룹웨어는 로그인 비밀번호가 "
                "아니라 '앱 비밀번호' 발급이 필요할 수 있습니다")
    if isinstance(e, smtplib.SMTPRecipientsRefused):
        # 어느 주소인지 버리고 '주소:' 뒤에 제목이 붙었다 (재검토 R5-4)
        bad = ", ".join(sorted(str(a) for a in (getattr(e, "recipients", None) or {})))
        return ("받는 사람 주소가 모두 거부되었습니다"
                + (f": {bad[:300]}" if bad else "") + " — 주소 오타를 확인하세요")
    if isinstance(e, smtplib.SMTPDataError):
        # 554(크기 제한·스팸 판정)인데 '주소를 확인하세요'로 안내했다 (재검토 R5-5)
        why = e.smtp_error.decode("utf-8", "replace") if isinstance(e.smtp_error, bytes) else str(e.smtp_error or "")
        return (f"메일 서버가 이 메일 본문을 받지 않았습니다 (코드 {e.smtp_code}"
                + (f": {' '.join(why.split())[:120]}" if why.strip() else "") + ") — 주소 문제가 아니라 메일 크기 "
                "제한이나 스팸 판정일 수 있습니다. 설정 › 메일의 [전/후 사진을 싣지 않음]으로 크기를 줄여 보거나 "
                "메일 담당자에게 문의하세요")
    if isinstance(e, ConnectionRefusedError):
        return "서버가 연결을 거부했습니다 — 포트 번호를 확인하세요"
    if isinstance(e, ssl.SSLCertVerificationError):
        return ("메일 서버의 보안 인증서를 확인하지 못했습니다 — 서버 주소가 인증서 이름과 같은지 보세요. "
                "사내 메일 서버가 자체 서명 인증서를 쓰면 config.yaml의 mail 아래에 'tls_verify: false'를 "
                "적으면 보냅니다(그 경우 전송 구간 가로채기를 막지 못합니다)")
    if isinstance(e, ssl.SSLError):
        # [SSL: WRONG_VERSION_NUMBER] wrong version number (_ssl.c:1010) — SSL을 STARTTLS·평문 포트에 켜면 (재검토 R5-3)
        return _MODE_MISMATCH
    low = str(e).lower()
    # SMTPNotSupportedError는 셋 중 하나 — 문구로 가른다. 전에는 모두 'STARTTLS 미지원'이라 엉뚱한 칸을 고치게 했다 (검토20 r10-3)
    if isinstance(e, smtplib.SMTPNotSupportedError) and "smtputf8" in low:
        return ("받는 사람이나 보내는 주소에 영문이 아닌 글자가 있어 이 메일 서버로는 보낼 수 없습니다 — @ 앞을 영문으로 적은 "
                "주소로 바꾸세요(받는 사람 칸에 이름을 적었다면 '이름 <주소>' 꼴이나 주소만)")
    if isinstance(e, smtplib.SMTPNotSupportedError) and "auth" in low:
        return ("메일 서버가 로그인(AUTH)을 받지 않습니다 — 로그인 없이 보내는 서버면 설정 › 메일의 계정 칸을 비우세요. "
                "로그인이 필요한 서버라면 보안 방식(SSL 465/STARTTLS 587)을 켜야 로그인을 받는 경우가 많습니다")
    if isinstance(e, smtplib.SMTPNotSupportedError) or (
            isinstance(e, smtplib.SMTPException) and "starttls" in low):
        return ("메일 서버가 STARTTLS를 지원하지 않습니다 — 보안 방식(SSL/STARTTLS)과 포트(465/587)가 맞는지 "
                "확인하세요")
    if isinstance(e, smtplib.SMTPServerDisconnected):
        return ("메일 서버가 연결을 끊었습니다 — 보안 방식(SSL/STARTTLS)과 포트(465/587)가 맞는지 확인하세요 "
                f"({' '.join(str(e).split())[:80]})")
    if isinstance(e, smtplib.SMTPException):
        return f"메일 서버 오류: {e}"
    return str(e)


# 직전 발송에서 서버가 거부한 주소 {주소: (코드, 사유)} — 일부만 거부돼도 '발송 완료'로 지나갔다 (검토67 D3)
LAST_REFUSED: dict = {}


def resend_eml(mail_cfg: dict, eml_path) -> bool:
    """못 보낸 날의 초안(.eml)을 그대로 다시 보낸다 — 실패한 날 통이 영영 안 갔다 (검토67 D4)."""
    import email
    from email import policy
    msg = email.message_from_bytes(Path(eml_path).read_bytes(), policy=policy.default)
    del msg["X-Unsent"]
    mc = {**mail_cfg, "recipients": split_addrs([str(msg["To"] or "")]) or mail_cfg.get("recipients")}
    return send_brief(mc, str(msg["Subject"] or ""), "", msg=msg)


def send_brief(mail_cfg: dict, subject: str, html_body: str, msg=None) -> bool:
    """발송했으면 True. enabled가 아니거나 수신자가 없으면 False (오류 아님).
    설정이 불완전하면 KeyError 대신 이유가 담긴 ValueError를 낸다."""
    global LAST_REFUSED
    LAST_REFUSED = {}
    if not mail_cfg.get("enabled"):
        return False
    if not mail_cfg.get("recipients"):
        return False
    if msg is None:
        good, bad = parse_addrs(mail_cfg["recipients"])
        if not good:            # 모두 꼴이 틀리면 서버에 가기 전에 까닭을 — 'STARTTLS 미지원'으로 보이던 것 (검토20 r10-1)
            raise ValueError("받는 사람 주소를 쓸 수 없습니다: " + "; ".join(w for _a, w in bad[:3])[:300]
                             + " — 설정 › 메일의 받는 사람 칸을 고쳐 주세요")
    missing = [k for k in ("smtp_host", "sender") if not mail_cfg.get(k)]
    if missing:
        raise ValueError(f"설정 누락: {', '.join(missing)} — 화면의 SMTP 서버/보내는 주소 칸을 채워주세요")
    if mail_cfg.get("username") and not mail_cfg.get("password"):
        raise ValueError("로그인 계정은 있는데 비밀번호가 없습니다 — 비밀번호 칸을 채워주세요")
    password = ""
    if mail_cfg.get("username"):
        from watcher.secret import SecretError, reveal
        try:
            password = reveal(mail_cfg.get("password"))
        except SecretError as e:
            raise ValueError(f"저장된 SMTP 비밀번호를 풀 수 없습니다 — 설정 › 메일에서 다시 입력하세요. "
                             f"자동 실행이 다른 Windows 계정으로 등록돼 있으면 같은 계정으로 다시 등록하세요 ({e})")
    if msg is None:
        msg = build_message(mail_cfg, subject, html_body)
    host = mail_cfg["smtp_host"]
    port = int(mail_cfg.get("smtp_port", 25))
    try:
        # 그룹웨어 표준인 암시적 SSL(465) 지원 (2026-08-25 UX 검토)
        # 인증서를 **검증한다** — 기본 문맥이 검증 없는 문맥이라 465·587 모두 가로채기에 비밀번호·브리핑이
        # 노출될 수 있었다 (검토39 P7 중간 2). 자체 서명 인증서를 쓰는 사내 메일 서버는 설정 mail.tls_verify: false
        import ssl
        ctx = ssl.create_default_context()
        if str(mail_cfg.get("tls_verify", True)).strip().lower() in ("false", "0", "no", "off", "아니오"):
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        if mail_cfg.get("ssl"):
            smtp_obj = smtplib.SMTP_SSL(host, port, timeout=60, context=ctx)
        else:
            smtp_obj = smtplib.SMTP(host, port, timeout=60)   # 큰 메일의 DATA 응답이 10초를 넘으면 서버는 받았는데 '실패'라 해 이중 발송됐다 (검토67 D7)
        with smtp_obj as smtp:
            if mail_cfg.get("starttls") and not mail_cfg.get("ssl"):
                smtp.starttls(context=ctx)
            if mail_cfg.get("username"):
                # 암호화 없는 연결에서는 로그인하지 않는다 — 비밀번호가 망에 평문으로 흐른다 (검토43 E 중간 1).
                # 꼭 필요한 사내 서버는 config.yaml mail.plain_auth: true (본인 책임)
                secured = bool(mail_cfg.get("ssl")) or bool(mail_cfg.get("starttls"))
                if not secured and str(mail_cfg.get("plain_auth", "")).strip().lower() not in ("true", "1", "yes", "on", "예"):
                    raise RuntimeError("암호화(SSL 465 또는 STARTTLS 587) 없이 비밀번호를 보내지 않습니다 — 설정 › 메일에서 "
                                       "SSL 또는 STARTTLS를 켜 주세요 (사내 서버가 암호화를 지원하지 않으면 담당자에게 문의)")
                smtp.login(mail_cfg["username"], password)
            LAST_REFUSED = dict(smtp.send_message(msg) or {})
    except Exception as e:
        raise RuntimeError(_friendly_smtp_error(e)) from e
    return True
