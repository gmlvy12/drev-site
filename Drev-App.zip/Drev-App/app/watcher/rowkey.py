# -*- coding: utf-8 -*-
"""표 변경 항목의 키 '행키.칸' 나누기 — 한 곳. 다른 watcher 모듈을 부르지 않는다(state.py도 순환 없이 쓴다)."""
from __future__ import annotations


def split_row_cell(key) -> tuple[str, str, str]:
    """'행키.칸' → (행키, 구분점, 칸). str.rpartition(".")과 같은 꼴을 돌려준다.

    칸 이름 끝의 마침표는 칸 이름이다 — 'C-1.QTY.'를 rpartition으로 자르면 칸이 빈 글이 되어 수량 변경이 금액 칸처럼 보이고 진짜 변경이
    숨었다 (ux26 PO1). 'C-1.QTY.' → ('C-1', '.', 'QTY.'). 머리글 가운데 마침표는 다루지 않는다: 'M-1.S.W.L' → ('M-1.S.W', '.', 'L').
    끝 마침표 앞에 구분점이 없으면(칸 없이 행키만인 'NO.') rpartition 그대로."""
    s = str(key or "")
    body = s.rstrip(".")
    rk, sep, col = body.rpartition(".")
    if not sep:
        return s.rpartition(".")
    return rk, sep, col + s[len(body):]
