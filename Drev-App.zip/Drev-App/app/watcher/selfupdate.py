# -*- coding: utf-8 -*-
"""포터블판 자동 업데이트 (2026-08-31).

사용자가 압축을 풀고 폴더를 덮어쓰는 과정에서 옛 판이 남아 사고가 났다
(윈도우 기본 압축 풀기가 Drev-Portable\\Drev-Portable을 만들고, 두 번째
다운로드는 "(1)"이 붙어 결국 덮어쓰기가 되지 않는다). 그 과정을 프로그램이
대신한다 — 사람이 파일을 만질 일을 없앤다.

원칙:
- **이력(state.db)·설정(config.yaml)은 건드리지 않는다.** 교체 대상은 새 zip에
  들어 있는 프로그램 파일뿐이고, 그 외에는 손대지 않는다.
- 실패하면 **원래대로 되돌린다**(교체 전 이름만 바꿔 두고, 실패 시 복구).
- 실행 중인 파일은 교체할 수 없으므로, 내려받기·검증·압축 해제까지만 앱이 하고
  **교체는 별도 프로세스**가 앱 종료를 기다렸다가 수행한 뒤 다시 띄운다.

이 파일은 그 별도 프로세스에서 **단독 스크립트로도 실행**되므로 표준 라이브러리만
쓰고 watcher 패키지의 다른 모듈을 import하지 않는다.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

# 앱이 읽는 진행 상태 (화면 표시용)
PROGRESS: dict = {"state": "", "pct": 0, "msg": "", "error": "", "at": 0.0}

WORK_DIRNAME = ".update"          # 작업 폴더 (내려받기·압축 해제)
OLD_SUFFIX = ".old-drev"          # 교체 전 임시 이름
NEW_SUFFIX = ".new-drev"          # 옆에 먼저 완성해 두는 새 판 이름 (R7-D1)
BROKEN_SUFFIX = ".broken-drev"    # 되살리기가 제자리 항목을 지우지 않고 비켜 두는 이름 (검토20 r16-2)


def portable_root() -> Path | None:
    """포터블판이면 그 루트 폴더, 아니면 None(개발 실행)."""
    exe = Path(getattr(sys, "executable", "") or "")
    if not exe.name.lower().startswith("drev"):
        return None
    root = exe.parent
    if (root / "app" / "watcher").is_dir() and (root / "python").is_dir():
        return root
    return None


def install_root() -> Path | None:
    """포터블 설치본의 루트 — 창(Drev.exe)이든 예약 검사(python\\pythonw.exe app\\entry.py run)든.

    portable_root()는 실행 파일 이름이 Drev로 시작할 때만 답해, 07:00 예약 검사에서는
    None이었다 — 그래서 무인 검사는 새 판을 알아도 교체할 길이 없었다 (2026-09-11)."""
    r = portable_root()
    if r is not None:
        return r
    exe = Path(getattr(sys, "executable", "") or "")
    if exe.name.lower() in ("python.exe", "pythonw.exe") and exe.parent.name.lower() == "python":
        base = exe.parent.parent
        if (base / "app" / "watcher").is_dir():
            return base
    return None


AUTO_MARK = "AUTO_UPDATED"        # 무인 교체가 끝났음을 다음 창 실행에 알리는 표식 파일
APPLYING_MARK = "UPDATE_APPLYING"  # 교체 프로세스가 일하는 동안의 표식(pid) — 창·정리가 건드리지 않게
FAILED_MARK = "UPDATE_FAILED"      # 무인 교체 실패 기록 "버전|시각|사유" — 같은 판을 매일 다시 받지 않게
FAILED_RETRY_DAYS = 3
ROLLBACK_MARK = "ROLLBACK_INCOMPLETE"  # 원복이 막혀 *.old-drev가 남은 교체 — 정리가 옛 판을 지우지 않게 (rvall D1: 되살리면 지운다)


def _pid_alive(pid: int) -> bool:
    if not pid:
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, int(pid))     # SYNCHRONIZE
        if not h:
            return False
        rc = k.WaitForSingleObject(h, 0)
        k.CloseHandle(h)
        return rc != 0                                     # WAIT_OBJECT_0(0)이면 끝난 것
    except Exception:
        return False


def mark_pid(text: str) -> int:
    """교체 표식(UPDATE_APPLYING)의 내용 → pid. 숫자로 못 읽으면 0(죽은 표식)으로 본다.

    정전으로 표식이 0x00으로 찬 채 남으면 int()가 실패해 '모름'으로 돌아갔고, 끊긴 교체를 영영 되살리지 못하고
    정리(cleanup)도 표식 때문에 멈췄다 (rv0678 B-4). 교체 프로세스는 숫자만 쓰니 숫자가 아니면 살아 있는 교체가 아니다."""
    try:
        return int((text or "").strip() or 0)
    except ValueError:
        return 0


RESTORE_LOCK = "UPDATE_RESTORING.lock"   # 끊긴 교체 되살리기는 한 프로세스만 (rv0678 B-1) — entry.py·drev_recover와 같은 이름
_RESTORE_HELD: set = set()               # 이 프로세스가 이미 잡은 설치본(entry.py가 잡고 부른다) — 같은 잠금을 두 번 잡지 않게
RESTORE_LOCK_WAIT = 15.0                 # 다른 실행이 되살리는 동안 기다리는 상한(초) — 되살리기는 보통 1초 안에 끝난다
_LOCK_OPEN_GRACE = 0.5                   # 잠금 파일을 열 수 없을 때(남이 잡은 것이 아님) 다시 해 보는 시간(초) — 넘으면 잠금 없이
RESTORE_BUSY = "busy"                    # restore_interrupted: 다른 실행이 되살리기 잠금을 쥐고 놓지 않는다(멈춘 프로세스)
BUSY_PID = -1                            # applying_pid: 위 경우 — 창은 '교체 중'으로 열지 않고, 정리는 손대지 않는다


def _lock_key(root) -> str:
    return os.path.normcase(os.path.abspath(str(root)))


def lock_restore(root, wait: float | None = None):
    """되살리기 잠금을 잡는다 — 잡으면 열쇠(해제에 넘길 값), 기다려도 못 잡으면 None.

    끊긴 교체(새 판 app + 옛 판 app.old-drev + 죽은 표식)에서 entry.py가 셋 이상 동시에 뜨면 서로 상대가 되살린 옛 판을
    '반쪽 새 판'으로 보고 비켜 둔 뒤, 또 다른 프로세스가 비켜 둔 것을 지워 app·app.old-drev가 둘 다 사라졌다 (rv0678 B-1).
    OS 바이트 잠금(msvcrt.locking)이라 잡은 프로세스가 죽으면 OS가 풀어 준다 — 오래된 잠금이 남지 않는다."""
    key = _lock_key(root)
    if key in _RESTORE_HELD:
        return ("held", key, None)
    try:
        import msvcrt
    except ImportError:                 # Windows 밖(개발 시험) — 잠그지 않는다
        return ("none", key, None)
    path = os.path.join(key, RESTORE_LOCK)
    t0 = time.time()
    deadline = t0 + max(0.0, RESTORE_LOCK_WAIT if wait is None else wait)
    while True:
        try:
            fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o666)
        except OSError:
            fd = None                   # 지우는 중(삭제 대기)이면 잠깐 뒤 다시
            # 잠금 파일 자체를 **열 수 없는** 것(이름이 폴더·읽기 전용·권한)은 남이 잡은 것이 아니다 — 30초를 다 기다린 뒤
            # 되살리기를 건너뛰어 검증 안 된 새 판으로 돌았다 (re_U 1). 잠깐(삭제 대기가 풀릴 만큼) 다시 해 보고 안 되면
            # 잠금 없이 고침 전처럼 한다. 남이 잡은 잠금은 열기는 되고 locking에서 막힌다
            if time.time() - t0 >= _LOCK_OPEN_GRACE:
                return ("none", key, None)
        if fd is not None:
            try:
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                _RESTORE_HELD.add(key)
                return ("fd", key, fd)
            except OSError:
                os.close(fd)
        if time.time() >= deadline:
            return None
        time.sleep(0.05)


def unlock_restore(lk) -> None:
    """lock_restore가 준 열쇠를 푼다(잠금 파일은 아무도 안 열고 있으면 지운다)."""
    if not lk or lk[0] != "fd":
        return
    _, key, fd = lk
    _RESTORE_HELD.discard(key)
    try:
        import msvcrt
        os.lseek(fd, 0, 0)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    except OSError:
        pass
    try:
        os.close(fd)
    except OSError:
        pass
    try:
        os.remove(os.path.join(key, RESTORE_LOCK))   # 다른 프로세스가 열고 기다리면 공유 위반으로 실패 — 그쪽이 잡는다
    except OSError:
        pass


def _aside_name(d: Path) -> Path:
    """비켜 둘 이름 — 프로세스마다 다르게(app.<pid>.broken-drev). 같은 이름을 쓰면 다른 프로세스(옛 판 drev_recover 등)가
    비켜 둔 것을 내가 지우거나, 지난 실행이 남긴 잡힌 조각 때문에 비켜 두기가 실패했다 (rv0678 B-1)."""
    n, aside = 0, d.parent / f"{d.name}.{os.getpid()}{BROKEN_SUFFIX}"
    while aside.exists() or aside.is_symlink():
        n += 1
        aside = d.parent / f"{d.name}.{os.getpid()}-{n}{BROKEN_SUFFIX}"
    return aside


def applying_pid(root: Path, wait: float | None = None):
    """교체 프로세스가 지금 일하고 있으면 그 pid, 아니면 None (죽은 pid의 표식은 지운다).
    끊긴 교체를 되살리려는데 다른 실행이 되살리기 잠금을 쥐고 놓지 않으면(멈춘 프로세스) BUSY_PID(-1) — 창은 검증 안 된
    새 판으로 열지 않고 '교체 중'으로 안내하고, 정리는 손대지 않는다 (re_U 1). wait는 그 잠금을 기다리는 상한(초).

    내려받기~교체 사이(수십 초~수 분)에 사람이 Drev.exe를 켜면 새 창의 cleanup()이 교체 원본
    (.update)과 되돌리기 재료(*.old-drev)를 함께 지워 app/ 자체가 사라질 수 있었다 (검토20 차단 1,
    합성 트리 재현). 표식이 살아 있는 동안 창은 열지 않고, 정리는 손대지 않는다."""
    p = Path(root) / APPLYING_MARK
    try:
        if not p.exists():
            return None
        raw = p.read_text(encoding="utf-8", errors="replace")
        age = time.time() - p.stat().st_mtime
    except OSError:
        return None
    pid = mark_pid(raw)
    # 교체 프로세스가 강제 종료되고 같은 pid를 다른 장수 프로세스가 받으면 창이 영영 안 열린다 —
    # 표식은 길어도 30분이면 거짓이다 (검토20 재검증 ②)
    if _pid_alive(pid) and age < 1800:
        return pid
    # 표식이 남은 채 교체 프로세스가 죽었다(정전·강제 종료) = 교체가 끝나지 않았다. 반쯤 복사된 app/만 남고 온전한 옛 판
    # (*.old-drev)은 다음 정리에서 지워져 예약 검사가 매일 ImportError로 죽었다 (검토66 D1) — 옛 판을 되살린다.
    # 교체가 확인(verify)까지 끝나면 swap이 표식을 먼저 지우므로, 여기 오는 것은 끝나지 않은 교체뿐이다
    r = restore_interrupted(root, wait=wait)
    if r == RESTORE_BUSY:
        return BUSY_PID
    if r is not None:
        _rm(p)
    return None


def _items_in_use(root: Path) -> set:
    """이 프로세스가 설치본(root)의 파이썬으로 돌고 있으면, 실행 중이라 바꾸면 안 되는 최상위 항목 이름(소문자)들.
    root/Drev.exe(서명된 pythonw 사본)는 root/python312.dll·python/python312.zip·libs의 .pyd를 물고 있고,
    python/pythonw.exe도 python/·libs/를 물고 있다 (검토20 r16-2)."""
    try:
        r = Path(root).resolve()
        exe = Path(getattr(sys, "executable", "") or "").resolve()
        prefix = Path(getattr(sys, "prefix", "") or "").resolve()
    except (OSError, ValueError):
        return set()

    def under(p: Path) -> bool:
        try:
            p.relative_to(r)
            return True
        except ValueError:
            return False
    if not (under(exe) or under(prefix)):
        return set()
    busy = {"python", "libs", "python312.dll", "vcruntime140.dll", "vcruntime140_1.dll"}
    if exe.parent == r:
        busy.add(exe.name.lower())
    return busy


def _log_line(root: Path, msg: str) -> None:
    try:
        with open(Path(root) / "watcher.log", "a", encoding="utf-8", errors="replace") as f:
            f.write(f"[update] {msg} · {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    except OSError:
        pass


def restore_interrupted(root: Path, wait: float | None = None) -> list:
    """끝나지 않은 교체의 옛 판(*.old-drev)을 제자리로. 되살린 이름 목록(하나라도 못 되돌리면 None).

    제자리 항목은 **지우지 않고 이름을 바꿔 비켜 둔다**(d → d.broken-drev). 전에는 rmtree(ignore_errors)로 지워,
    이 설치본의 파이썬으로 도는 프로세스(창)가 부르면 열린 DLL·.pyd만 남기고 python\·libs\를 반쯤 지워 설치본이
    아무것도 못 띄우게 됐다(검토20 r16-2). 안에 열린 파일이 있으면 이름 바꾸기가 통째로 실패해 아무것도 안 건드린다.

    이 프로세스가 쓰는 항목(python·libs·Drev.exe…)을 되돌려야 하면: 이름 바꾸기가 모두 끝난 **완성된 새 판**이면
    그대로 확정한다(표식만 지움 — 지금 이 코드가 그 새 판으로 돌고 있다). 아니면 아무것도 바꾸지 않고 사유를 남긴다.

    되살리기는 **한 프로세스만** 한다(lock_restore) — 동시에 뜬 실행들이 서로 되살린 것을 비켜 두고 지워 app이 통째로
    사라졌다 (rv0678 B-1). 잠금을 기다려도 못 잡으면 아무것도 바꾸지 않고 RESTORE_BUSY(표식을 남긴다). 잠금 파일을 열 수
    없으면(이름이 폴더·읽기 전용) 잠금 없이 고침 전처럼 되살린다 (re_U 1)."""
    root = Path(root)
    lk = lock_restore(root, wait)
    if lk is None:
        _log_line(root, "다른 실행이 끝나지 않은 업데이트 교체를 되돌리는 중이라 이번에는 건드리지 않았습니다 — 다음 실행에서 다시 봅니다")
        return RESTORE_BUSY
    mine: list = []
    try:
        return _restore_interrupted_locked(root, mine)
    finally:
        unlock_restore(lk)
        for p in mine:
            _rm(p)              # 내가 비켜 둔 반쪽 새 판 — 못 지우면 다음 정리(cleanup)가


def _restore_interrupted_locked(root: Path, mine: list) -> list:
    """restore_interrupted의 몸통 — 되살리기 잠금을 잡은 채로 부른다. 비켜 둔 이름은 mine에 모은다."""
    olds = sorted(root.glob("*" + OLD_SUFFIX))
    busy = _items_in_use(root)
    need_busy = [o.name for o in olds if o.name[:-len(OLD_SUFFIX)].lower() in busy]
    if need_busy:
        names = [o.name[:-len(OLD_SUFFIX)] for o in olds]
        complete = (all((root / n).exists() for n in names)
                    and all((root / p.name[:-len(NEW_SUFFIX)]).exists() for p in root.glob("*" + NEW_SUFFIX))
                    and (root / "app" / "entry.py").is_file()
                    and (root / "app" / "watcher" / "__init__.py").is_file()
                    and ((root / "python" / "python.exe").is_file() or "python" not in [n.lower() for n in names]))
        # 검증에 실패해 원복하다 막힌 새 판(원복 불완전)은 '완성된 새 판'이 아니다 — 확정하지 않는다 (rvall D1)
        if complete and not (root / ROLLBACK_MARK).exists():
            msg = ("끝나지 않은 업데이트 교체 — 이름 바꾸기가 모두 끝난 새 판이 완성되어 있어 그대로 확정했습니다 "
                   f"(옛 판 {', '.join(names)}은 다음 정리에서 지웁니다)")
            _log_line(root, msg)
            try:
                (root / "UPDATE_RECOVERED").write_text(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}", encoding="utf-8")
            except OSError:
                pass
            return []
        # 잡고 있는 것은 다른 창이 아니라 **이 실행 자신**(예약 검사·창이 그 python·libs로 돈다)이다 — '창·양식함을 닫으라'는
        # 안내는 틀렸다 (re_GS RG4). Drev의 어느 실행도 자기 python·libs는 되돌릴 수 없다
        _log_line(root, "끝나지 않은 업데이트 교체를 되돌리지 못했습니다 — 되돌릴 항목("
                  + ", ".join(need_busy) + ")은 지금 이 실행(Drev 자신)이 쓰고 있습니다 — Drev 스스로는 되돌릴 수 없습니다. "
                  "다운로드 페이지의 설치 파일로 덮어써 주세요 (설정·이력은 그대로)")
        return None             # 표식을 남겨 정리(cleanup)가 옛 판을 지우지 않게
    done, failed = [], []
    for old in olds:
        d = root / old.name[:-len(OLD_SUFFIX)]
        aside = None
        try:
            # 비켜 두기 직전에 옛 판이 아직 있는지 다시 본다 — 그 사이 다른 실행(옛 판의 app 밖 drev_recover)이 되살렸으면
            # 지금 제자리(d)에 있는 것이 그 옛 판이다. 그것을 '반쪽 새 판'으로 비켜 두면 안 된다 (rv0678 B-1)
            if not old.exists():
                continue
            if d.exists() or d.is_symlink():
                aside = _aside_name(d)
                d.rename(aside)         # 열린 파일이 있으면 여기서 통째로 실패 — 아무것도 안 지운다
                mine.append(aside)
            old.rename(d)
            done.append(d.name)
        except OSError:
            if aside is not None and not d.exists():
                try:
                    aside.rename(d)     # 옛 판을 못 가져왔으면 비켜 둔 것을 제자리로
                    mine.remove(aside)
                except (OSError, ValueError):
                    pass
            failed.append(old.name)
    # 비켜 둔 반쪽 새 판은 부르는 쪽(restore_interrupted)이 잠금을 푼 뒤 **내가 비켜 둔 것만** 지운다 — 남의 것(*.broken-drev
    # 전부)을 지우다 다른 실행이 막 비켜 둔 옛 판까지 지웠다 (rv0678 B-1). 남은 조각은 다음 정리(cleanup)가
    if failed:
        _log_line(root, "끝나지 않은 업데이트 교체를 일부 되돌리지 못했습니다(" + ", ".join(failed)
                  + ") — 다음 실행에서 다시 시도합니다")
        return None             # 표식을 남겨 정리(cleanup)가 옛 판을 지우지 않게 — 다음 실행에서 다시 시도
    if done:
        try:
            (root / "UPDATE_RECOVERED").write_text(
                f"{time.strftime('%Y-%m-%d %H:%M:%S')} 끝나지 않은 업데이트 교체를 되돌림: {', '.join(done)}",
                encoding="utf-8")
        except OSError:
            pass
        settle_rollback(root, ignore_mark=True)     # 원복이 막혔던 교체였으면 이제 끝났다 (rvall D1)
    return done


def settle_rollback(root: Path, ignore_mark: bool = False) -> bool:
    """'원복 불완전'(ROLLBACK_INCOMPLETE)이 남았는데 되돌리기가 이미 끝나 있으면 표식을 지우고 로그에 한 줄 남긴다.

    새 판 검증 실패 + 원복 중 백신 잠금으로 원복이 막혀도 다음 실행(app 밖 drev_recover·restore_interrupted)이
    옛 판을 되살렸는데, 표식과 마지막 '교체 실패 — 원복 불완전' 로그 줄이 남아 창이 "설치 파일로 덮어쓰라"고 계속
    안내했다 (rvall D1). 옛 판(v0.67.7 이하)의 libs\\drev_recover는 이 표식을 모르므로 app 쪽(창·entry.py)에서도 본다.

    지우는 조건은 좁게: 되돌릴 재료(*.old-drev)가 하나도 남지 않았고, 끊긴 교체 표식이 없고(ignore_mark면 무시 —
    방금 되살린 쪽이 부른다), app이 온전하다. '되돌리기 재료가 없음'으로 실패한 항목은 되살릴 길이 없으니 그대로 둔다.
    무인 교체 실패 기록(UPDATE_FAILED)은 남긴다 — 그 판은 검증에 실패했고(백신 격리·깨진 파일), 원복을 마저 끝냈다고
    그 사유가 사라지지 않는다. 지우면 다음 예약 검사부터 매일 55MB를 다시 받아 같은 실패·같은 원복 잠금을 되풀이한다
    (창의 [설치]로는 바로 다시 시도할 수 있다)."""
    root = Path(root)
    p = root / ROLLBACK_MARK
    try:
        if not p.exists():
            return False
        why = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    if "되돌리기 재료" in why:
        return False
    if any(root.glob("*" + OLD_SUFFIX)):
        return False
    if not ignore_mark and (root / APPLYING_MARK).exists():
        return False
    if not ((root / "app" / "entry.py").is_file() and (root / "app" / "watcher" / "__init__.py").is_file()):
        return False
    try:
        p.unlink()
    except OSError:
        return False
    _log_line(root, "교체 실패 — 이전 판으로 되돌렸습니다: 원복 중 잠겨 있던 항목을 다음 실행이 마저 되돌렸습니다 "
                    "(설정·이력은 그대로)")
    return True


_PS_UTF8 = "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "


def _ps_lines(ps: str, timeout: float = 25):
    """PowerShell 명령을 **UTF-8 출력**으로 돌려 줄 목록 — 실패면 None.
    mbcs(cp949)로 읽으면 cp949 밖 글자(Müller·Dřev·이모지)가 '?'·비슷한 글자로 바뀌어 설치 경로 비교가
    늘 틀렸다(검토20 r16-3) — 창이 떠 있는데 '없음'으로 보고 교체가 진행됐다."""
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS_UTF8 + ps],
                           capture_output=True, timeout=timeout, stdin=subprocess.DEVNULL,
                           creationflags=0x08000000)
    except Exception:
        return None
    if r.returncode != 0:
        return None
    out = (r.stdout or b"").decode("utf-8", "replace").splitlines()
    if out and out[0].startswith("\ufeff"):
        out[0] = out[0][1:]
    return out


def _mbcs_lossless(text: str) -> bool:
    """이 글이 콘솔 코드 페이지(mbcs)로 그대로 오가는가 — 아니면 mbcs로 읽은 출력과 견줄 수 없다."""
    if sys.platform != "win32":
        return True
    try:
        return text.encode("mbcs", "strict").decode("mbcs") == text
    except (UnicodeError, LookupError):
        return False


def window_running(root=None):
    """Drev 창(Drev.exe / Drev(문제해결용).exe)이 떠 있나 — 떠 있으면 무인 교체를 미룬다.
    창이 쓰는 파일을 밑에서 갈아끼우지 않기 위해서다; 창에는 [설치] 단추가 있다.
    root를 주면 **그 설치본의** 창만 본다 — USB 포터블·시험 사본 등 다른 폴더의 Drev.exe 때문에
    무기한 미루던 것 (검토21 운영 낮음 1). True/False, 확인 자체가 안 되면 None (부르는 쪽이
    '확인 불가'로 적는다 — "창이 떠 있어"라는 거짓 사유를 남기지 않게)."""
    if sys.platform != "win32":
        return False
    me = os.getpid()
    if root is not None:
        ps = ("Get-CimInstance Win32_Process -Filter \"Name like 'Drev%'\" | "
              "ForEach-Object { $_.ProcessId.ToString() + '|' + $_.ExecutablePath }")
        lines = _ps_lines(ps)
        if lines is not None:
            want = str(Path(root).resolve()).lower().rstrip("\\") + "\\"
            unsure = False
            for line in lines:                 # UTF-8로 받는다 — 한글·cp949 밖 글자 경로 (검토38 R8-1, 검토20 r16-3)
                pid_s, _, exe = line.strip().partition("|")
                try:
                    pid = int(pid_s)
                except ValueError:
                    continue
                if pid == me or not exe:
                    continue
                if exe.lower().startswith(want):
                    return True
                if "\ufffd" in exe:
                    unsure = True              # 경로를 못 읽었다 — '없음'이라 단정하지 않는다
            return None if unsure else False
        # PowerShell이 없거나 막힘 — 아래 전체 목록으로
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Drev*", "/FO", "CSV", "/NH"],
                           capture_output=True, timeout=15, creationflags=0x08000000)
        out = r.stdout.decode("mbcs", "replace")
    except Exception:
        return None
    for line in out.splitlines():
        if not line.startswith('"Drev'):
            continue
        cols = [c.strip('"') for c in line.split('","')]
        try:
            if int(cols[1]) != me:
                return True
        except (IndexError, ValueError):
            return True
    return False


# ── 양식함 서버(DrevForms)와 업데이트 (2026-10-28 F4) ──────────────────────────────────────────
# 양식함 서버는 python\pythonw.exe 로 상주한다 — 돌고 있으면 python\ 폴더 이름을 바꿀 수 없고(실행 중인 exe), 비교 자식도
# 같은 파이썬이다. 교체 **직전에** 멈추고 교체 뒤(성공·되돌림 모두) 다시 시작한다. 감시 작업(ProjectWatcher)은 건드리지 않는다.
FORMS_TASK = "DrevForms"


def _run_quiet(cmd: list, timeout: float = 20):
    return subprocess.run(cmd, capture_output=True, timeout=timeout, stdin=subprocess.DEVNULL,
                          creationflags=0x08000000)


def forms_task_ours(root: Path):
    """DrevForms 작업이 있고 **이 설치본**(root 아래 파일)을 실행하는가. True/False, 견줄 수 없으면 None(모름)."""
    want = str(Path(root).resolve()).lower().rstrip("\\") + "\\"
    if sys.platform == "win32":
        # 작업 동작(실행 파일·인수·시작 위치)을 UTF-8로 — schtasks 출력(mbcs)은 cp949 밖 글자를 바꿔 찍었다 (검토20 r16-3)
        lines = _ps_lines(f"$t = Get-ScheduledTask -TaskName '{FORMS_TASK}' -ErrorAction SilentlyContinue; "
                          "if ($t) { $t.Actions | ForEach-Object { 'ACT|' + $_.Execute + ' ' + $_.Arguments + ' ' "
                          "+ $_.WorkingDirectory } } else { 'NONE' }", timeout=20)
        if lines is not None:
            text = "\n".join(lines).lower()
            if "act|" not in text:
                return False
            if want in text:
                return True
            return None if "\ufffd" in text else False
    try:
        q = _run_quiet(["schtasks", "/Query", "/TN", FORMS_TASK, "/V", "/FO", "LIST"], timeout=15)
    except Exception:
        return False
    if q.returncode != 0:
        return False
    text = (q.stdout or b"").decode("mbcs" if sys.platform == "win32" else "utf-8", "replace").lower()
    if want in text:
        return True
    return False if _mbcs_lossless(want) else None     # 경로가 mbcs로 안 오가면 비교 불가 = 모름


def forms_server_pids(root: Path) -> list:
    """이 설치본의 파이썬으로 도는 `forms-serve` 프로세스 pid들 (작업으로 띄웠든 손으로 띄웠든)."""
    if sys.platform != "win32":
        return []
    ps = ("Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
          "ForEach-Object { $_.ProcessId.ToString() + '|' + $_.CommandLine }")
    lines = _ps_lines(ps)                  # UTF-8 (검토20 r16-3)
    if lines is None:
        return []
    want = str(Path(root).resolve()).lower().rstrip("\\") + "\\"
    out = []
    for line in lines:
        pid_s, _, cmdline = line.strip().partition("|")
        low = cmdline.lower()
        if "forms-serve" in low and want in low:
            try:
                pid = int(pid_s)
            except ValueError:
                continue
            if pid != os.getpid():
                out.append(pid)
    return out


def stop_forms(root: Path, say=None) -> dict:
    """교체 전에 양식함 서버를 멈춘다. 돌려줌 {task: 우리 작업이 있었나, pids: 멈춘 pid들} — start_forms가 쓴다."""
    task = forms_task_ours(root)
    # 모름(None) = 작업 정의의 경로를 견줄 수 없었다 — 우리 것으로 보고 멈췄다 다시 켠다. 작업 이름(DrevForms)은 PC에
    # 하나라 남의 것이어도 멈춤·다시 시작은 해가 없고, 안 멈추면 python 폴더 이름 바꾸기가 막혀 교체가 되돌려진다
    state = {"task": task is not False, "pids": forms_server_pids(root)}
    if not state["task"] and not state["pids"]:
        return state
    if state["task"]:
        try:
            _run_quiet(["schtasks", "/End", "/TN", FORMS_TASK], timeout=15)
        except Exception:
            pass
    left = [p for p in state["pids"] if not _wait_pid(p, 15)]
    for pid in left:                       # 작업 밖에서 띄운 서버·끝나지 않는 서버 — 자식(비교)까지 끝낸다
        try:
            _run_quiet(["taskkill", "/PID", str(int(pid)), "/T", "/F"], timeout=15)
        except Exception:
            pass
        _wait_pid(pid, 10)
    if say is not None:
        say(f"양식함 서버를 잠시 멈췄습니다 (교체 뒤 다시 시작{'' if state['task'] else ' — 작업 없이 띄운 서버는 손으로 다시 띄워야 합니다'})")
    return state


def start_forms(root: Path, state: dict, say=None) -> bool:
    """교체 뒤 양식함 서버를 다시 시작한다 — DrevForms 작업이 이 설치본의 것일 때만."""
    if not state or not state.get("task"):
        return False
    try:
        ok = _run_quiet(["schtasks", "/Run", "/TN", FORMS_TASK], timeout=15).returncode == 0
    except Exception:
        ok = False
    if say is not None:
        say("양식함 서버를 다시 시작했습니다" if ok else "양식함 서버를 다시 시작하지 못했습니다 — Drev 설정 › 양식함에서 [다시 시작]")
    return ok


def scan_lock_holder(lock_db):
    """이력 DB의 검사 잠금을 쥔 살아 있는 프로세스 pid (없으면 None). 교체 프로세스는 watcher
    패키지 없이 단독으로 돌므로 sqlite로 직접 읽는다 — 다른 검사 위에 파일을 갈지 않게 (검토20 중간 3).
    DB 경로는 부르는 쪽(cli)이 넘긴다 — 이 모듈은 설정·데이터 위치를 스스로 알지 않는다(읽기 전용 차단벽)."""
    import sqlite3
    if not lock_db:
        return None
    db = Path(lock_db)
    if not db.exists():
        return None
    try:
        con = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True, timeout=5)
        try:
            row = con.execute("SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    if not row:
        return None
    try:
        pid, at = int(str(row[0]).split(":")[0]), float(str(row[0]).split(":")[1])
    except (ValueError, IndexError):
        return None
    if time.time() - at > 6 * 3600 or not _pid_alive(pid):
        return None
    return pid


def recent_failure(root: Path, version: str, days: int = FAILED_RETRY_DAYS):
    """같은 판의 무인 교체가 최근 days일 안에 실패했으면 그 사유(문자열), 아니면 빈 문자열."""
    p = Path(root) / FAILED_MARK
    try:
        if not p.exists():
            return ""
        ver, at, why = (p.read_text(encoding="utf-8", errors="replace").split("|", 2) + ["", ""])[:3]
        if ver != version:
            return ""
        if time.time() - float(at or 0) > days * 86400:
            return ""
        return why or "사유 기록 없음"
    except (OSError, ValueError):
        return ""


def _set(state: str, pct: int = 0, msg: str = "", error: str = "") -> None:
    PROGRESS.update(state=state, pct=pct, msg=msg, error=error, at=time.time())


def busy(within: float = 600.0) -> bool:
    """지금 업데이트 진행 중인가. 중간에 멈춘 상태가 영영 남지 않도록 시간 제한을
    둔다 — 진행 표시가 계속 걸려 있으면 새 버전 알림이 가려진다 (2026-09-01)."""
    return (PROGRESS.get("state") in ("download", "verify", "extract", "apply")
            and time.time() - float(PROGRESS.get("at") or 0) < within)


# ------------------------------------------------------------------ 내려받기

# 내려받기를 허용하는 곳. 받은 파일은 풀려서 **실행**된다(verify_tree가 새 판을
# 돌린다) — 그런데 스킴·호스트 제한이 없어서 version.json의 "exe"가 평문 http나
# 사내 공유 폴더를 가리키는 file 주소여도 받아서 실행했다 (2026-09-09 업데이트 검토
# 중간 6 실증). 서명이 없는 동안 TLS + 지문이 방어 전부라, 최소한 그 둘이 걸리는
# 곳으로 좁힌다.
# release-assets.githubusercontent.com: 2026-09-13 GitHub가 릴리스 자산의 302 목적지를
# objects.→release-assets.로 바꿔, 그 전 판(≤v0.56.0)은 "허용되지 않은 주소로 넘어갔습니다"로
# 업데이트가 전부 막혔다(이 PC 실사용에서 실증). 그 판들의 구제는 App.zip을 drev.co.kr에도
# 두는 것으로(release.py step_site) — 여기 목록은 앞으로의 판을 위한 것.
ALLOWED_HOSTS = ("drev.co.kr", "www.drev.co.kr", "github.com",
                 "objects.githubusercontent.com",
                 "release-assets.githubusercontent.com", "codeload.github.com",
                 "gmlvy12.github.io")


# 이 PC 안(루프백)은 스킴을 가리지 않는다 — 사내에 직접 미러를 띄우는 경우와
# 시험용이다. 여기로 무엇을 받든 이미 이 PC에서 프로그램을 돌릴 수 있는 사람이라
# 밖에서 들어오는 경로가 새로 열리지는 않는다.
_LOOPBACK = ("127.0.0.1", "localhost", "::1")


def url_ok(url: str) -> bool:
    """https이고 허용 호스트인가 (하위 도메인은 허용하지 않는다). 루프백은 예외."""
    from urllib.parse import urlsplit
    s = str(url or "")
    # 역슬래시·사용자 정보(@)·제어문자가 든 주소는 거절 — 'https://evil\\@drev.co.kr'을 urllib은 drev로, 브라우저는 evil로
    # 읽었다 (검토43 E 낮음 1)
    if "\\" in s or any(ord(ch) < 32 or ord(ch) == 127 for ch in s):
        return False
    try:
        u = urlsplit(s)
    except ValueError:
        return False
    if "@" in (u.netloc or ""):
        return False
    host = (u.hostname or "").lower()
    if host in _LOOPBACK and u.scheme in ("http", "https"):
        return True
    return u.scheme == "https" and host in ALLOWED_HOSTS


def safe_opener():
    """리다이렉트 **전에** 목적지를 검사하는 opener — 302를 따라 허용 밖 호스트에 요청부터 보낸 뒤 거절했다
    (검토43 E 낮음 2)."""
    import urllib.request

    class _Guard(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if not url_ok(newurl):
                raise OSError(f"허용되지 않은 주소로 넘어가려 했습니다: {newurl}")
            # 바깥 배포처가 이 PC 안(루프백)으로 데려가는 것은 막는다 — 루프백 예외는 사내 미러를 **직접** 쓸 때만이다.
            # 302 한 번으로 이 PC의 임의 포트(화면 8765 포함)에 GET을 보냈다 (검토44 E 낮음 4)
            from urllib.parse import urlsplit as _us
            if (_us(newurl).hostname or "").lower() in _LOOPBACK \
                    and (_us(req.full_url).hostname or "").lower() not in _LOOPBACK:
                raise OSError(f"바깥 주소가 이 PC 안으로 넘어가려 했습니다: {newurl}")
            return super().redirect_request(req, fp, code, msg, headers, newurl)
    return urllib.request.build_opener(_Guard)


MAX_DOWNLOAD = 300 * 1024 * 1024    # 서명된 크기가 없을 때의 내려받기 상한 (지금 전체 판 ~55MB)


def download(url: str, dest: Path, on_progress=None, sha256: str = "", max_bytes: int = 0) -> Path:
    """zip을 받아 dest에 저장. 도중 실패하면 예외. sha256을 주면 받은 뒤 대조한다 —
    배포자가 올린 파일과 다르면(중간 변조·캐시 오염) 교체하지 않는다 (2026-09-02).
    max_bytes: 서명된 파일 크기(있으면) — 없으면 MAX_DOWNLOAD. Content-Length가 넘으면 받기 전에, 없거나 거짓이면
    넘는 순간 멈춘다 — 허용 호스트의 수 GB 파일로 돌려 지문 대조 전에 다 받게 하던 것 (검토20 r16-1)."""
    import urllib.request
    try:
        cap = int(max_bytes or 0)
    except (TypeError, ValueError):
        cap = 0
    if cap <= 0:
        cap = MAX_DOWNLOAD
    if not url_ok(url):
        raise OSError(f"허용되지 않은 내려받기 주소입니다 (https + 공식 배포처만): {url}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".part")
    # 고정 이름(/Drev-App.zip)을 프록시·CDN이 10분 캐시한다 — 배포 직후의 [설치]·무인 교체가 새
    # version.json + 옛 zip으로 지문 불일치가 됐다 (검토25 운영 1-2). 지문 앞자리를 캐시 버스터로
    req_url = url
    if sha256 and "github.com" not in (url or ""):
        req_url = url + ("&" if "?" in url else "?") + "v=" + sha256[:8]
    req = urllib.request.Request(req_url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    with safe_opener().open(req, timeout=30) as r:
        # 302로 허용 목록 밖 호스트에 데려가면 그대로 받아서 **실행**까지 했다
        # (2026-09-09 배포 후 검토 낮음 7 실증) — 최종 주소도 본다
        final = getattr(r, "url", None) or url
        if not url_ok(final):
            raise OSError(f"내려받기가 허용되지 않은 주소로 넘어갔습니다: {final}")
        try:
            total = int(r.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            total = 0
        if total > cap:
            raise OSError(f"받을 파일이 예상보다 큽니다({total // 1048576}MB > {cap // 1048576}MB) — 받지 않습니다")
        got = 0
        try:
            with open(tmp, "wb") as f:
                while True:
                    chunk = r.read(262144)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > cap:
                        raise OSError(f"받는 파일이 예상 크기({cap // 1048576}MB)를 넘어 멈췄습니다 — 교체하지 않습니다")
                    f.write(chunk)
                    if on_progress:
                        on_progress(got, total)
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise
    if total and tmp.stat().st_size != total:
        tmp.unlink(missing_ok=True)
        raise OSError("내려받기가 중간에 끊겼습니다")
    if sha256:
        got_sha = _sha256_of(tmp)
        if got_sha.lower() != sha256.lower():
            tmp.unlink(missing_ok=True)
            raise OSError("받은 파일이 배포 목록의 지문(SHA-256)과 다릅니다 — 교체하지 않습니다")
    tmp.replace(dest)
    return dest


def _sha256_of(path: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _version_in(text: str) -> str:
    import re
    m = re.search(r'__version__\s*=\s*"([^"]+)"', text)
    return m.group(1) if m else ""


def verify_zip(zp: Path, expect: str = "") -> str:
    """zip이 온전한 Drev 포터블판인지 확인하고 버전을 돌려준다."""
    with zipfile.ZipFile(zp) as z:
        bad = z.testzip()
        if bad:
            raise OSError(f"받은 파일이 손상되었습니다: {bad}")
        names = z.namelist()
        top = {n.split("/")[0] for n in names}
        if len(top) != 1:
            raise OSError("압축 구조가 예상과 다릅니다")
        base = top.pop()
        need = [f"{base}/app/watcher/__init__.py", f"{base}/Drev.exe",
                f"{base}/python/python.exe", f"{base}/libs/sitecustomize.py"]
        missing = [n for n in need if n not in names]
        if missing:
            raise OSError("구성 파일이 빠졌습니다: " + ", ".join(missing[:2]))
        # 포장 실수로 사용자 데이터(설정·이력·기록)가 zip에 들어가면 교체가 그것을 덮어쓴다 —
        # verify_app_zip에만 있던 검사를 여기에도. 이 모듈은 그 경로를 알면 안 되므로(읽기 전용 가드)
        # 이름이 아니라 **확장자와 폴더**로 가른다 (검토33 D M4)
        # **데이터 이름만** 거른다. 'app·python·libs 밖의 모든 폴더 금지'로 두면 앞으로 포장에 폴더
        # 하나만 늘어도(docs·locale) 이미 나간 설치본의 자동 업데이트가 전부 멈춘다 — 그 검사는 옛 판이
        # 돌기 때문에 새 판 코드로 고칠 수 없다 (검토34 B 중간 3)
        _DATA_SUFFIX = (".yaml", ".yml", ".db", ".db-wal", ".db-shm", ".log", ".eml")
        _DATA_DIRS = {"briefs", "backups", "captures", "renders"}
        stray = sorted({n.split("/")[1] for n in names
                        if n.count("/") >= 1 and n.split("/")[1]
                        and (n.split("/")[1].lower().endswith(_DATA_SUFFIX)
                             or n.split("/")[1].lower() in _DATA_DIRS)})
        if stray:
            raise OSError("zip에 설정·이력 파일이 있어 교체하지 않습니다: " + ", ".join(stray[:5]))
        ver = _version_in(
            z.read(f"{base}/app/watcher/__init__.py").decode("utf-8", "replace"))
    if not ver:
        raise OSError("버전을 확인할 수 없습니다")
    if expect and ver != expect:
        raise OSError(f"내려받은 판(v{ver})이 안내된 판(v{expect})과 다릅니다")
    return ver


def runtime_of(root: Path) -> str:
    """설치본의 런타임 세대 (없으면 빈 문자열 — 옛 판)."""
    try:
        return (root / "runtime.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def verify_app_zip(zp: Path, expect: str = "") -> str:
    """앱 소스만 담긴 zip 검증 — 구조와 버전을 확인하고 버전을 돌려준다."""
    with zipfile.ZipFile(zp) as z:
        bad = z.testzip()
        if bad:
            raise OSError(f"받은 파일이 손상되었습니다: {bad}")
        names = z.namelist()
        top = {n.split("/")[0] for n in names}
        if len(top) != 1:
            raise OSError("압축 구조가 예상과 다릅니다")
        base = top.pop()
        # app/ 밖의 항목(config.yaml·state.db 등)이 들어 있으면 swap이 사용자 설정·이력을 덮어쓴다 —
        # "이력·설정은 건드리지 않습니다"가 zip 내용에 달려 있지 않게 거른다 (검토20 낮음)
        stray = sorted({n.split("/")[1] for n in names
                        if n.count("/") >= 1
                        and n.split("/")[1] not in ("", "app", "설치안내.txt", "포터블안내.txt")})
        if stray:
            raise OSError(f"앱 zip에 app/ 밖의 항목이 있어 교체하지 않습니다: {', '.join(stray[:5])}")
        need = f"{base}/app/watcher/__init__.py"
        if need not in names:
            raise OSError("구성 파일이 빠졌습니다: app/watcher/__init__.py")
        if f"{base}/app/entry.py" not in names:
            raise OSError("구성 파일이 빠졌습니다: app/entry.py")
        ver = _version_in(z.read(need).decode("utf-8", "replace"))
    if not ver:
        raise OSError("버전을 확인할 수 없습니다")
    if expect and ver != expect:
        raise OSError(f"내려받은 판(v{ver})이 안내된 판(v{expect})과 다릅니다")
    return ver


def stage(zp: Path, work: Path) -> Path:
    """압축을 풀고 새 판의 루트 폴더를 돌려준다."""
    new = work / "new"
    if new.exists():
        shutil.rmtree(new, ignore_errors=True)
    new.mkdir(parents=True)
    with zipfile.ZipFile(zp) as z:
        z.extractall(new)
    tops = [p for p in new.iterdir() if p.is_dir()]
    if len(tops) != 1:
        raise OSError("압축 해제 결과가 예상과 다릅니다")
    return tops[0]


# -------------------------------------------------------------------- 교체

def _rm(p: Path) -> None:
    """파일이든 폴더든 없앤다 (없으면 조용히)."""
    if p.is_dir():
        shutil.rmtree(p, ignore_errors=True)
    else:
        p.unlink(missing_ok=True)


_WINERR_KO = {
    5: "접근 거부 — 백신·탐색기·다른 Drev가 파일을 잡고 있었습니다",
    32: "다른 프로그램이 파일을 사용 중이었습니다",
    33: "다른 프로그램이 파일 일부를 잠갔습니다",
    112: "디스크 공간이 부족합니다",
    2: "파일을 찾을 수 없습니다",
    3: "경로를 찾을 수 없습니다",
    1223: "작업이 취소되었습니다",
}


def _friendly_os_error(e: BaseException) -> str:
    """원복 사유가 날 WinError로 화면에 뜨던 것 — 한국어 한 줄로 (검토19 운영 ⑩)."""
    code = getattr(e, "winerror", None)
    ko = _WINERR_KO.get(code)
    if ko:
        return f"{ko} (WinError {code})"
    if isinstance(e, shutil.Error):
        # 복사 실패 목록 원문(경로 수백 개)이 사유로 떴다 — 첫 이유만 (검토66 D4)
        try:
            first = (e.args[0] or [])[0]
            why = str(first[2]) if len(first) > 2 else str(first)
        except (IndexError, TypeError):
            why = ""
        low = why.lower()
        if "112" in why or "no space" in low or "공간" in why:
            return "디스크 공간이 부족해 새 판을 복사하지 못했습니다"
        return "새 판 파일 일부를 복사하지 못했습니다" + (f" — {why[:120]}" if why else "")
    return str(e)


def _put_back(d: Path, old: Path, retries: int = 20) -> None:
    """원복 한 항목: old(*.old-drev) → d. d를 지우다 남은 조각이 있으면 비켜 두고(d → *.broken-drev) 다시 한다.

    새 판 검증이 실패한 순간 백신이 새 판의 파일을 잡고 있으면 rmtree(ignore_errors)가 그 파일을 남겨 d가 그대로
    있었고, old.rename(d)이 WinError 183(이미 있음)으로 '원복 불완전'이 됐다 (rvall D1, 임시 설치본 실측).
    restore_interrupted와 같은 기법 — 지우지 않고 비켜 둔다. 안에 잡힌 파일이 있으면 비켜 두기도 통째로 실패하므로
    잠금이 풀릴 때까지 1초씩 retries번 기다린다. d가 이미 없는데 old를 못 옮기는 것은 기다리지 않는다(예전과 같다)."""
    for i in range(max(1, retries)):
        try:
            _rm(d)                              # 잡힌 파일(파일 항목 자체가 잡혔으면 그것)만 남긴다
        except OSError:
            pass
        if not (d.exists() or d.is_symlink()):
            old.rename(d)                       # 막히면 그대로 올린다 — 부르는 쪽이 '원복 불완전'으로 적는다
            return
        try:
            aside = d.parent / (d.name + BROKEN_SUFFIX)
            n = 0
            while aside.exists() or aside.is_symlink():
                _rm(aside)
                if not (aside.exists() or aside.is_symlink()):
                    break
                n += 1                          # 전에 비켜 둔 것도 잡혀 있다 — 다른 이름으로
                aside = d.parent / (f"{d.name}.{n}" + BROKEN_SUFFIX)
            d.rename(aside)                     # 남은 조각을 비켜 둔다 (잡힌 파일이 있으면 여기서 실패)
            _rm(aside)                          # 못 지우면 다음 정리(cleanup)가
            old.rename(d)
            return
        except OSError:
            if i >= retries - 1:
                raise
            time.sleep(1)                       # 그 사이 풀린 파일은 다음 바퀴 첫머리에서 지운다


def _touch_mark(root: Path) -> None:
    """교체 표식(UPDATE_APPLYING)이 있으면 시각만 새로 — 창(applying_pid)은 30분 넘은 표식을 거짓으로 보고 되살리기를
    하므로, 잠금 대기(최대 600초)·느린 복사 뒤의 검증 중에 창이 열려 새 판을 되돌리지 않게 (re_GS RG1).
    표식이 없으면(창 [설치] 밖의 부름) 만들지 않는다."""
    p = Path(root) / APPLYING_MARK
    try:
        if p.exists():
            os.utime(p, None)
    except OSError:
        pass


def swap(root: Path, src: Path, retries: int = 20, verify=None) -> None:
    """src(새 판)의 항목만 root에 교체한다. 실패하면 전부 되돌린다.

    src에 있는 이름만 손대므로 state.db·config.yaml 등 데이터는 자동으로 남는다.

    verify를 주면 **되돌릴 수 있는 동안** 불러 새 판이 실제로 실행되는지
    확인한다. 여기서 실패하면 옛 파일이 아직 살아 있으므로 전부 원복한다
    (2026-09-02: 지금까지 트리 교체에는 이 확인이 없어, 깨진 판으로 바뀌면
    되돌릴 길이 없었다)."""
    items = sorted(p.name for p in src.iterdir())
    renamed: list[tuple[Path, Path]] = []      # (원래 이름, 임시 이름)
    copied: list[Path] = []
    staged: list[Path] = []                    # 옆 폴더에 완성해 둔 새 판(*.new-drev)

    def _rename_retry(a: Path, b: Path) -> None:
        for i in range(retries):               # 잠금(백신·탐색기)이 풀릴 때까지 잠깐 기다린다
            try:
                a.rename(b)
                return
            except OSError:
                if i == retries - 1:
                    raise
                time.sleep(1)

    try:
        # ① 새 판을 **옆 이름(*.new-drev)에 먼저 전부** 복사한다. 전에는 app→app.old-drev로 바꾼 뒤 그 자리에
        # 복사해, 복사 도중(수 초, 백신이 느리면 더) 정전·강제 종료되면 app\entry.py가 없는 채로 남았다 — 되살리기
        # 코드가 app 안에 있어 예약 검사·창 모두 죽고 복구할 길이 없었다 (재검토 2026-10-28 R7-D1).
        # 이제 오래 걸리는 복사는 옛 판이 멀쩡히 있는 동안 끝나고, app이 없는 틈은 이름 바꾸기 두 번 사이뿐이다
        for name in items:
            s, tmp = src / name, root / (name + NEW_SUFFIX)
            _rm(tmp)
            staged.append(tmp)
            if s.is_dir():
                shutil.copytree(s, tmp)
            else:
                shutil.copy2(s, tmp)
        # ② 이름만 바꾼다: 옛 것 → *.old-drev, 새 것 → 제자리
        for name in items:
            d, tmp = root / name, root / (name + NEW_SUFFIX)
            if d.exists():
                old = root / (name + OLD_SUFFIX)
                _rm(old)
                _rename_retry(d, old)
                renamed.append((d, old))
            _rename_retry(tmp, d)
            staged.remove(tmp)
            copied.append(d)
        if verify is not None:
            _touch_mark(root)                   # 검증 동안 표식이 '30분 넘은 거짓'으로 보이지 않게 (re_GS RG1)
            verify()                            # 실패하면 아래에서 전부 원복
        # 여기부터는 새 판이 확정 — 표식을 먼저 지운다. 옛 판 지우는 도중 끊겨도 다음 실행이 '끝나지 않은 교체'로 보고
        # 반쯤 지운 옛 판을 되살려 판이 섞이지 않게 (검토66 D1)
        _rm(root / APPLYING_MARK)
    except Exception:
        # 복사는 폴더 중간에서도 깨질 수 있다 — 반쯤 만들어진 것까지 치운 뒤에
        # 되돌려야 한다 (그러지 않으면 "이미 있다"며 복구를 건너뛴다. 2026-08-31
        # 회귀 테스트가 잡아낸 결함)
        restored, failed = set(), []
        for d, old in renamed:
            try:                                # 하나가 막혀도 나머지는 되돌린다
                if old.exists():
                    _put_back(d, old, retries)  # d를 지우고(남은 조각은 비켜 두고) 옛 판을 제자리로
                    restored.add(d)
                else:
                    _rm(d)
                    # 되돌리기 재료가 사라졌다(다른 프로세스의 정리 등) — 방금 d를 지웠으니
                    # 그 항목은 없어진 것이다. '되돌렸습니다'라 적으면 거짓 (검토20 차단 1)
                    failed.append(f"{d.name}: 되돌리기 재료({old.name})가 없음")
            except OSError as e:
                failed.append(f"{d.name}: {e}")
        for d in copied:                        # 이전 판에 없던 새 파일 정리
            if d not in restored:
                _rm(d)
        for tmp in staged:                      # 제자리로 못 간 새 판 사본 (R7-D1)
            _rm(tmp)
        if failed:
            # 거짓 '되돌렸습니다'를 남기지 않는다 — 무엇이 못 돌아갔는지 그대로
            raise OSError("원복 불완전 — " + "; ".join(failed)
                          + " (*.old-drev 폴더를 수동으로 되돌리거나 설치 파일로 덮어써 주세요)")
        raise
    for _, old in renamed:                      # 성공 — 옛 파일 정리
        _rm(old)


def check_copy(root: Path, src: Path) -> None:
    """src(새 판)의 파일이 root에 **전부, 같은 크기로** 있는가. 교체 검증(verify_tree)은 있는 파일만 보므로
    빠진 모듈(install·organize·folderdlg…)이나 잘린 파일(docx.py 3,000B)도 '교체 완료'였다 (검토31 D 1)."""
    missing: list[str] = []
    for s in src.rglob("*"):
        if not s.is_file() or "__pycache__" in s.parts:
            continue
        rel = s.relative_to(src)
        d = root / rel
        try:
            if not d.is_file() or d.stat().st_size != s.stat().st_size:
                missing.append(str(rel))
        except OSError:
            missing.append(str(rel))
        if len(missing) >= 5:
            break
    if missing:
        raise OSError("교체한 판에 빠지거나 잘린 파일이 있습니다: " + ", ".join(missing))


def verify_tree(root: Path) -> str:
    """교체한 트리가 실제로 실행되는지 한 번 돌려본다 (2026-09-02).

    포터블/설치판은 파일 하나가 아니라 트리(python/ + app/ + libs/)라서,
    복사가 다 끝났어도 실행이 안 될 수 있다. 창 없는 python.exe로 부른다 —
    Drev.exe(pythonw 사본)는 표준출력이 없어 확인에 쓸 수 없다."""
    py = root / "python" / "python.exe"
    entry = root / "app" / "entry.py"
    if not py.exists() or not entry.exists():
        raise OSError(f"교체 후 실행 파일이 없습니다: {py.name}/{entry.name}")
    # encoding/errors를 주지 않으면 한국어 윈도우에서 자식 출력을 cp949로 읽다가
    # UnicodeDecodeError가 리더 스레드에서 터진다 — 출력이 빈 문자열이 되고
    # returncode까지 1로 뒤집혀, **멀쩡한 새 판을 '실행되지 않습니다'로 되돌렸다**
    # (2026-09-09 업데이트 검토 중간 4). 스케줄러 쪽(cli.py)은 이미 이렇게 한다
    r = subprocess.run([str(py), str(entry), "--version"],
                       capture_output=True, text=True, timeout=120,
                       encoding="utf-8", errors="replace",
                       stdin=subprocess.DEVNULL, env=verify_env(),
                       creationflags=0x08000000)
    out = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0 or "Drev" not in out:
        raise OSError(f"교체한 판이 실행되지 않습니다 (코드 {r.returncode}): "
                      f"{out.strip()[-400:]}")        # 사유(ModuleNotFoundError)는 traceback 끝에 있다 (검토31 D 낮음)
    # --version은 cli만 읽고 끝난다 — 창·추출·그림·워커 모듈이 깨진 판도 "교체 완료"로 굳었다
    # (검토25 운영 1-1, 임시 트리 실측). 핵심 모듈을 실제로 import해 본다 (+1초)
    # 함수 안에서만 import되는 모듈(ocr·secret·webengine·selfupdate·dwg·logfile)은 위 14개를
    # 읽어도 닿지 않아, 백신이 그중 하나를 격리한 판도 "교체 완료"였다 — ocr이면 스캔 PDF 글자
    # 추출이 조용히 꺼지고 secret이면 아침 메일이 비밀번호를 못 푼다 (검토30 D 1-7, 실측).
    # 문법·부분 복사는 compileall이 33개 전부를 1초 안에 본다
    mods = ("watcher.web", "watcher.cli", "watcher.worker", "watcher.capture", "watcher.render",
            "watcher.extract.dxf", "watcher.extract.pdf", "watcher.extract.xlsx", "watcher.extract.docx",
            "watcher.brief", "watcher.mail", "watcher.consistency", "watcher.diff", "watcher.state",
            "watcher.ocr", "watcher.secret", "watcher.webengine", "watcher.selfupdate",
            "watcher.dwg", "watcher.logfile", "watcher.updsign",
            "watcher.forms.server", "watcher.forms.settings",   # 양식함(F4) — 상주 서버가 다시 뜰 때 깨지지 않게
            "watcher.forms.backup", "watcher.forms.weekly",     # 양식함 백업·복원·주간 알림 (2026-10-30)
            "watcher.forms.keep",                               # 양식함 기록 보존 만료 (2026-10-30)
            "watcher.forms.panel",                              # 설정 화면 양식함 칸 — web.py가 함수 안에서만 import (재검토 이주 4)
            "watcher.forms.changes", "watcher.change_ledger",   # 사내망 변경 확인·설계 변경 대장 (기능 검토 2026-11-02 N)
            "watcher.issued")                                   # 출도본 기록·출도 후 변경 (기능 검토 2026-11-02 J)
    r1 = subprocess.run([str(py), "-m", "compileall", "-q", str(root / "app" / "watcher")],
                        capture_output=True, text=True, timeout=180, cwd=str(root),
                        encoding="utf-8", errors="replace",
                        stdin=subprocess.DEVNULL, env=verify_env(),
                        creationflags=0x08000000)
    if r1.returncode != 0:
        raise OSError("교체한 판에 읽을 수 없는 파일이 있습니다: "
                      f"{((r1.stderr or '') + (r1.stdout or '')).strip()[-300:]}")
    r2 = subprocess.run([str(py), "-c", "import " + ", ".join(mods) + "; print('MODS_OK')"],
                        capture_output=True, text=True, timeout=180, cwd=str(root),
                        encoding="utf-8", errors="replace",
                        stdin=subprocess.DEVNULL, env=verify_env(),
                        creationflags=0x08000000)
    if r2.returncode != 0 or "MODS_OK" not in (r2.stdout or ""):
        raise OSError("교체한 판의 모듈을 읽지 못합니다: "
                      f"{((r2.stderr or '') + (r2.stdout or '')).strip()[-300:]}")
    return out.strip()


def cleanup(root: Path) -> None:
    """작업 폴더·되돌리기용 잔재 정리 (다음 실행 때 조용히)."""
    # 되살리기 잠금은 기다리지 않는다 — 창이 열 때 applying_pid가 이미 기다렸다(두 번째 15초 없앰, re_U 1)
    if applying_pid(root, wait=0) is not None or (root / APPLYING_MARK).exists():
        return                              # 교체가 진행 중이거나 끊긴 교체를 아직 못 되돌림 — 옛 판을 건드리지 않는다 (검토66 D1)
    work = root / WORK_DIRNAME
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    settle_rollback(root)                   # 옛 판의 app 밖 되살리기가 끝냈으면 표식을 거둔다 (rvall D1)
    if (root / ROLLBACK_MARK).exists():
        return                              # 원복 재료를 지우지 않는다 (사람이 되돌릴 것)
    for p in root.glob("*" + OLD_SUFFIX):
        _rm(p)
    for p in root.glob("*" + NEW_SUFFIX):  # 옆에 만들다 끊긴 새 판 사본 (R7-D1)
        _rm(p)
    for p in root.glob("*" + BROKEN_SUFFIX):   # 되살리기가 비켜 둔 반쪽 판 (검토20 r16-2)
        _rm(p)


def _wait_pid(pid: int, timeout: float = 60.0) -> bool:
    """그 프로세스가 끝날 때까지 기다린다 (실행 중 파일은 교체할 수 없으므로).

    끝났으면 True. 시간 안에 안 끝나면 False — 부르는 쪽이 판단한다."""
    if not pid:
        return True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, pid)     # SYNCHRONIZE
        if not h:
            return True                                # 이미 사라진 PID
        rc = k.WaitForSingleObject(h, int(timeout * 1000))
        k.CloseHandle(h)
        return rc == 0                                 # WAIT_OBJECT_0
    except Exception:
        time.sleep(3)
        return False


def _force_exit(pid: int) -> bool:
    """끝나지 않는 이전 판 **그 프로세스 하나만** 끝낸다 (2026-09-02).

    이름으로 싹쓸이(taskkill /IM)하지 않는다 — 같은 이름의 다른 창까지
    죽이면 사람이 보던 화면이 사라진다. 업데이트가 넘겨준 PID만 대상."""
    if not pid:
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x0001, False, pid)         # PROCESS_TERMINATE
        if not h:
            return False
        ok = bool(k.TerminateProcess(h, 0))
        k.CloseHandle(h)
        if ok:
            time.sleep(1.5)                            # 핸들이 풀릴 틈
        return ok
    except Exception:
        return False


# --------------------------------------------- 자식 프로세스 환경

def child_env() -> dict:
    """자식 프로세스용 환경 — PyInstaller 내부 변수를 걷어낸다.

    프리즌 앱이 **다른** exe를 실행하면, 자식이 부모의 `_PYI_*`/`_MEIPASS2`를
    물려받아 "부모 프로세스의 실행 파일이 다르다"며 스스로 종료한다
    (2026-09-01 실사고: 업데이트 검증 단계에서 오류 창). 물려주지 않으면 된다."""
    return {k: v for k, v in os.environ.items()
            if not k.startswith("_PYI") and k not in ("_MEIPASS2",)}


def verify_env() -> dict:
    """검증용 자식 환경 — 출력을 UTF-8로 고정해 한글이 섞여도 읽을 수 있게 한다.
    (errors='replace'가 사고는 막지만, 메시지를 사람이 읽게 하려면 이게 필요하다)"""
    # DREV_SWAP_VERIFY: 새 판의 entry.py가 '검증 전에 끊긴 교체'로 착각해 옛 판을 되살리지 않게 (re_GS RG1)
    return {**child_env(), "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "DREV_SWAP_VERIFY": "1"}


# ------------------------------------------------------- 앱 쪽 진입 (스레드)

def run_update(root: Path, url: str, expect: str = "",
               exit_after: bool = True, app_url: str = "",
               remote_runtime: str = "", app_sha: str = "",
               portable_sha: str = "", relaunch: bool = True, lock_db: str = "",
               sizes: dict | None = None) -> None:
    """내려받기 → 검증 → 압축 해제 → 교체 프로세스 실행 → 앱 종료.

    런타임(파이썬·라이브러리) 세대가 같으면 **앱 소스만 담은 작은 zip**을 받는다
    — 전체는 55MB인데 실제로 바뀌는 건 대개 538KB뿐이다 (2026-09-01 사용자:
    "40MB짜리를 그대로 다운받아야 하니까")."""
    work = root / WORK_DIRNAME
    small = bool(app_url) and remote_runtime and runtime_of(root) == remote_runtime
    try:
        _set("download", 0, "새 판을 내려받는 중…"
             + (" (가벼운 업데이트)" if small else ""))

        def prog(got, total):
            pct = int(got * 100 / total) if total else 0
            _set("download", pct, f"내려받는 중… {pct}% "
                 f"({got // 1048576}MB / {total // 1048576 if total else '?'}MB)")

        if not (app_sha if small else portable_sha):
            # 지문 없이 받아 교체하지 않는다 — 받은 파일이 올린 파일과 같은지 알 길이 없다 (2026-10-02)
            raise OSError("배포 목록에 지문(sha256)이 없어 설치하지 않습니다 — 업데이트 확인을 다시 해 주세요")
        try:
            cap = int((sizes or {}).get("app" if small else "portable") or 0)   # 둘째 서명의 크기 (검토20 r16-1)
        except (TypeError, ValueError):
            cap = 0
        zp = download(app_url if small else url,
                      work / ("Drev-App.zip" if small else "Drev-Portable.zip"),
                      prog, **({'sha256': app_sha if small else portable_sha}
                               if (app_sha if small else portable_sha) else {}),
                      **({"max_bytes": cap} if cap > 0 else {}))
        _set("verify", 100, "받은 파일을 확인하는 중…")
        ver = verify_app_zip(zp, expect) if small else verify_zip(zp, expect)
        _set("extract", 100, "압축을 푸는 중…")
        src = stage(zp, work)
        _set("apply", 100, f"v{ver}로 교체하는 중 — 프로그램이 잠시 닫혔다가 "
                           f"다시 열립니다.")
        spawn_swapper(root, src, relaunch=relaunch, lock_db=lock_db)
        if exit_after:
            time.sleep(1.5)      # 화면에 안내가 보이도록 잠깐 두고 종료
            os._exit(0)
    except Exception as e:
        print(f"[update] 실패: {type(e).__name__}: {e}")
        _set("error", 0, "", f"자동 업데이트에 실패했습니다: {e}")
        shutil.rmtree(work, ignore_errors=True)


def _parses(path: Path) -> bool:
    """파이썬 파일이 문법적으로 온전한가 (실행하지 않고 ast로만)."""
    try:
        import ast
        ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        return True
    except (OSError, SyntaxError, ValueError):
        return False


def spawn_swapper(root: Path, src: Path, relaunch: bool = True,
                  lock_db: str = "") -> subprocess.Popen:
    """교체 담당 프로세스를 띄운다 — 새 판의 파이썬으로 이 파일을 실행한다.
    relaunch=False는 예약 검사 뒤의 무인 교체 — 07시에 창을 띄우지 않는다. lock_db는 그때 교체
    직전에 다른 검사가 돌고 있는지 볼 이력 DB 경로(cli가 안다)."""
    # 앱만 받은 경우 src에는 python이 없다 — 설치본의 파이썬으로 실행한다
    # (python.exe는 교체 대상이 아니므로 실행 중이어도 안전)
    py = src / "python" / "python.exe"
    if not py.exists():
        py = root / "python" / "python.exe"
    script = src / "app" / "watcher" / "selfupdate.py"
    if not script.exists() or not _parses(script):
        # 새 판의 이 파일이 깨졌으면 교체 프로세스가 0.2초 만에 죽어 아무 줄도 안 남고, 창은
        # 이미 닫혀 다시 안 뜬다 — 설치본의 것으로 띄우면 교체 검증이 깨진 판을 되돌린다 (검토30 D 1-7)
        script = root / "app" / "watcher" / "selfupdate.py"
    cmd = [str(py), str(script), "--apply", "--root", str(root),
           "--src", str(src), "--wait-pid", str(os.getpid())]
    if relaunch:
        cmd += ["--relaunch", str(root / "Drev.exe")]
    if lock_db:
        cmd += ["--lock-db", str(lock_db)]
    flags = 0x00000008 | 0x08000000        # DETACHED_PROCESS | NO_WINDOW
    return subprocess.Popen(cmd, close_fds=True, stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            env=child_env(), creationflags=flags)


# ------------------------------------------------- 교체 프로세스(단독 실행)

def prewarm(root: Path, timeout: float = 180.0) -> float:
    """새 판을 창 없이 한 번 import해 둔다 — 첫 실행 비용을 창 뒤로 숨기지 않게.

    새 파일 수백 개의 바이트코드 생성과 보안 소프트웨어 검사가 창이 뜬 뒤에
    일어나면 "로딩"처럼 보인다 (2026-09-02). 걸린 시간을 돌려준다(로그용)."""
    py = root / "python" / "python.exe"
    if not py.exists():
        return 0.0
    t0 = time.time()
    try:
        subprocess.run([str(py), "-c", "import watcher.web, watcher.cli"],
                       cwd=str(root), capture_output=True, timeout=timeout,
                       stdin=subprocess.DEVNULL, env=child_env(),
                       creationflags=0x08000000)
    except Exception:
        pass
    return time.time() - t0


def refresh_cache(root: Path) -> None:
    """`pythonw entry.py refresh-cache`를 창 없이 따로 띄운다 (판 교체 직후)."""
    pyw = root / "python" / "pythonw.exe"
    entry = root / "app" / "entry.py"
    if not pyw.exists() or not entry.exists():
        return
    # 교체 프로세스가 DEVNULL을 물려받고 있어 자식의 표준 스트림이 None이 아니고 entry.py의 우회도 안 탄다
    # (1회차 1). 부모가 연 핸들을 넘기면 append 플래그가 상속되지 않아 그 사이 다른 프로세스가 덧붙인
    # 줄을 덮어썼다 (2회차 A5) — 자식이 스스로 append로 열게 `--to-log`
    subprocess.Popen([str(pyw), str(entry), "refresh-cache", "--to-log"], cwd=str(root),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     env=child_env(), creationflags=0x08000000 | 0x00000008)   # NO_WINDOW | DETACHED


def relaunch(exe: Path) -> str:
    """새 판을 **탐색기에게 맡겨** 켠다 — 더블클릭과 같은 부모·환경·권한.

    교체 프로세스(창 없는 python.exe)가 직접 띄우면 새 판이 이전 판의 환경과
    계보를 물려받는다. 회사 보안 소프트웨어는 그 계보를 다르게 다루고, 실제로
    자동 재실행된 창만 멎었다 (2026-09-02). 돌려주는 값은 로그용 방식 이름."""
    try:
        if "," in str(exe):               # 탐색기는 쉼표를 인자 구분자로 본다
            raise OSError("쉼표 경로")
        subprocess.Popen(["explorer.exe", str(exe)], close_fds=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=0x08000000)
        return "explorer"
    except Exception:
        os.startfile(str(exe))            # 탐색기가 없으면 예전 방식
        return "startfile"


LOCK_WAIT_S = 600                       # 교체 직전 다른 검사의 잠금을 기다리는 최대 초


def _apply_cli(argv: list[str]) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--root", required=True)
    ap.add_argument("--src", required=True)
    ap.add_argument("--wait-pid", type=int, default=0)
    ap.add_argument("--relaunch", default="")
    ap.add_argument("--lock-db", default="")    # 검사 잠금을 볼 이력 DB (무인 교체·창의 [설치] 모두, 검토20 r16-4)
    a = ap.parse_args(argv)
    root, src = Path(a.root), Path(a.src)
    log = root / "watcher.log"

    def say(m):
        try:
            with open(log, "a", encoding="utf-8", errors="replace") as f:
                f.write(f"[update] {m} · {time.strftime('%Y-%m-%d %H:%M:%S')}\n")   # 어느 날인지 (검토21 운영 3)
        except OSError:
            pass

    # 교체 중 표식을 **맨 먼저** 쓴다 — 부른 프로세스(cli)가 내려받는 동안 자기 pid로 써 둔 표식을
    # 이어받아, 창·정리가 끼어들 틈을 없앤다 (검토20 재검증 ③)
    try:
        (root / APPLYING_MARK).write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass
    if not _wait_pid(a.wait_pid):
        # 이전 판이 안 죽는다 — 그대로 두면 응답 없는 옛 창이 앞에 남아
        # "업데이트 후 멈춘 것처럼 클릭이 안 됨"이 된다 (2026-09-02 회사 실사용)
        say(f"이전 판(PID {a.wait_pid})이 종료되지 않아 강제로 끝냅니다")
        _force_exit(a.wait_pid)
    time.sleep(1.0)
    unattended = not a.relaunch
    tag = " (예약 검사 뒤 자동 업데이트)" if unattended else ""
    new_ver = ""
    try:
        new_ver = _version_in((src / "app" / "watcher" / "__init__.py")
                              .read_text(encoding="utf-8", errors="replace"))
    except OSError:
        pass
    rc = 0
    keep_mark = False                       # 원복 불완전 — 표식을 남겨 다음 실행이 '끝나지 않은 교체'로 마저 되돌리게 (rvall D1)
    forms_state = None                      # 교체 전에 멈춘 양식함 서버 — 교체가 끝나면(성공·되돌림) 다시 시작 (F4)
    try:
        if unattended:
            # 내려받는 동안 상황이 바뀌었을 수 있다 — 교체 **직전**에 다시 본다 (검토20 차단 1·중간 3)
            wr = window_running(root)
            if wr is not False:
                say("교체를 미룹니다 — " + ("창이 떠 있습니다" if wr else "창 실행 여부를 확인할 수 없습니다")
                    + ". 다음 예약 검사 때 다시 시도합니다" + tag)
                _rm(root / APPLYING_MARK)
                shutil.rmtree(root / WORK_DIRNAME, ignore_errors=True)
                return 2
        # 다른 검사가 잠금을 쥐고 있으면 끝나길 기다린다 — 창의 [설치]도 (검토20 r16-4: 누른 뒤 내려받는 사이 07:00
        # 예약 검사가 시작되면 교체가 그 검사 밑에서 app/을 갈아 그날 브리핑이 새 판 모듈과 섞였다). 창은 이미 닫혔다
        holder = scan_lock_holder(a.lock_db)
        waited = 0.0
        while holder and holder != a.wait_pid and waited < LOCK_WAIT_S:
            time.sleep(10)             # 다른 검사(수동 실행·지연 시작)가 끝나길 최대 10분 기다린다
            waited += 10
            holder = scan_lock_holder(a.lock_db)
        if holder and holder != a.wait_pid:
            say(f"교체를 미룹니다 — 다른 검사(PID {holder})가 진행 중입니다. "
                + ("다음 예약 검사 때 다시 시도합니다" if unattended else "검사가 끝난 뒤 [설치]를 다시 눌러 주세요") + tag)
            _rm(root / APPLYING_MARK)
            shutil.rmtree(root / WORK_DIRNAME, ignore_errors=True)
            if a.relaunch:                 # 창을 닫고 기다리던 사람에게 지금 판을 다시 띄운다
                try:
                    relaunch(Path(a.relaunch))
                except OSError as e:
                    say(f"다시 시작하지 못했습니다({e}) — Drev.exe를 직접 실행해주세요.")
            return 2
        try:
            forms_state = stop_forms(root, say)
        except Exception as e:              # 멈추지 못해도 교체는 해 본다 — 막히면 swap이 되돌린다
            say(f"양식함 서버 확인 실패(무시): {e}")
        _touch_mark(root)                   # 잠금 대기(최대 600초) 뒤 — 교체가 지금 시작한다 (re_GS RG1)
        swap(root, src, verify=lambda: (check_copy(root, src), verify_tree(root)))
        say("교체 완료 — 새 판 실행 확인됨" + tag)
        _rm(root / ROLLBACK_MARK)               # 지난 실패 표식은 성공으로 끝난다
        _rm(root / FAILED_MARK)
        _rm(root / AUTO_MARK)                   # 유인 교체가 옛 무인 표식을 덮어쓰지 않게 (검토21 운영 낮음 3)
        if unattended:
            # 다음에 창을 여는 사람에게 "밤사이 vX로 바뀌었다"를 한 번 알린다
            try:
                ver = _version_in((root / "app" / "watcher" / "__init__.py")
                                  .read_text(encoding="utf-8", errors="replace"))
                (root / AUTO_MARK).write_text(ver, encoding="utf-8")
            except OSError:
                pass
    except Exception as e:
        # 되돌리기는 swap 안에서 끝났다. 여기서 중요한 건 **다시 켜는 것** —
        # 예전에는 여기서 그냥 끝나서 앱이 통째로 사라졌다 (2026-09-02 실사용:
        # "없는데 먹통이야 켜져있는거 없어")
        if "원복 불완전" in str(e):
            try:
                (root / ROLLBACK_MARK).write_text(str(e), encoding="utf-8")
            except OSError:
                pass
            say(f"교체 실패 — {e}" + tag)
            # 표식을 남긴다(아래 finally에서 pid 0으로) — 다음 실행(entry.py·창·app 밖 drev_recover)이
            # 죽은 표식 + *.old-drev를 '끊긴 교체'로 보고 잠금이 풀린 뒤 옛 판을 마저 되살린다. 표식을 지우면
            # 백신이 새 판의 entry.py를 잡고 있던 경우 아무도 되살리지 않았다 (rvall D1)
            keep_mark = any(root.glob("*" + OLD_SUFFIX))
        else:
            say(f"교체 실패 — 이전 판으로 되돌렸습니다: {_friendly_os_error(e)}" + tag)
        if unattended:
            # 같은 판을 매일 다시 받아 교체·원복을 반복하지 않게 (검토20 중간 2)
            try:
                (root / FAILED_MARK).write_text(
                    f"{new_ver}|{time.time():.0f}|{str(e)[:200]}", encoding="utf-8")
            except OSError:
                pass
        rc = 1
    finally:
        if keep_mark:
            # pid 0 = 일하는 교체 프로세스 없음 — 이 뒤 다시 띄운 창([설치])이 '교체 중'으로 막히지 않고 곧바로 되살리기를 해 본다
            try:
                (root / APPLYING_MARK).write_text("0", encoding="utf-8")
            except OSError:
                pass
        else:
            _rm(root / APPLYING_MARK)
        if unattended:
            shutil.rmtree(root / WORK_DIRNAME, ignore_errors=True)   # 창이 없는 PC에선 아무도 치우지 않는다
    if forms_state:
        try:
            start_forms(root, forms_state, say)      # 새 판(또는 되돌린 옛 판)으로 다시
        except Exception as e:
            say(f"양식함 서버를 다시 시작하지 못했습니다({e}) — Drev 설정 › 양식함에서 [다시 시작]")
    warm = prewarm(root)                # 창이 뜨기 전에 첫 실행 비용을 치른다 (무인 교체도 —
    if warm:                             # 다음 날 아침 첫 실행이 느리지 않게)
        say(f"새 판 예열 {warm:.1f}s")
    if rc == 0:
        # 새 판의 추출 세대로 기록을 미리 갱신한다(스냅샷 없음) — 안 하면 세대가 오른 판의 첫 검사가
        # 그 사이 바뀐 파일의 내용 비교를 통째로 건너뛴다 (검토25 감지 6-1). 창을 기다리게 하지
        # 않도록 따로 띄우고, 검사와 같은 잠금을 쓰므로 겹치면 스스로 물러난다
        try:
            refresh_cache(root)
            say("추출 기록 갱신 시작(새 세대) — 끝나면 로그에 남습니다")
        except Exception as e:
            # 다음 검사가 실제로 이어받는다 — 검사 끝이 추출 세대를 보고 갱신한다(extract_gen_stale, 검토43 D 낮음 1)
            say(f"추출 기록 갱신을 시작하지 못했습니다({e}) — 다음 검사 끝에 이어서 합니다")
    if a.relaunch:
        try:
            how = relaunch(Path(a.relaunch))   # 성공이면 새 판, 실패면 되돌린 이전 판
            say(f"다시 시작 ({how})")
        except OSError as e:
            say(f"다시 시작하지 못했습니다({e}) — Drev.exe를 직접 실행해주세요.")
    return rc


if __name__ == "__main__":
    sys.exit(_apply_cli(sys.argv[1:]))
