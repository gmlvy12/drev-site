# -*- coding: utf-8 -*-
"""포터블판 자동 업데이트 (2026-08-31).

사용자가 압축을 풀고 폴더를 덮어쓰는 과정에서 옛 판이 남아 사고가 났다
(윈도우 기본 압축 풀기가 Drev-Portable\\Drev-Portable을 만들고, 두 번째
다운로드는 "(1)"이 붙어 결국 덮어쓰기가 되지 않는다). 그 과정을 프로그램이
대신한다 — 사람이 파일을 만질 일을 없앤다.

원칙:
- **이력(state.db)·설정(config.yaml)은 건드리지 않는다.** 교체 대상은 새 zip에
  들어 있는 프로그램 파일뿐이고, 그 외에는 손대지 않는다.
- 실패하면 **원래대로 되돌린다**(교체 전 이름만 바꿔 두고, 실패 시 복구).
- 실행 중인 파일은 교체할 수 없으므로, 내려받기·검증·압축 해제까지만 앱이 하고
  **교체는 별도 프로세스**가 앱 종료를 기다렸다가 수행한 뒤 다시 띄운다.

이 파일은 그 별도 프로세스에서 **단독 스크립트로도 실행**되므로 표준 라이브러리만
쓰고 watcher 패키지의 다른 모듈을 import하지 않는다.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

# 앱이 읽는 진행 상태 (화면 표시용)
PROGRESS: dict = {"state": "", "pct": 0, "msg": "", "error": "", "at": 0.0}

WORK_DIRNAME = ".update"          # 작업 폴더 (내려받기·압축 해제)
OLD_SUFFIX = ".old-drev"          # 교체 전 임시 이름


def portable_root() -> Path | None:
    """포터블판이면 그 루트 폴더, 아니면 None(설치판·개발 실행)."""
    if getattr(sys, "frozen", False):
        return None               # PyInstaller 단일 exe는 자기 교체 방식이 다름
    exe = Path(getattr(sys, "executable", "") or "")
    if not exe.name.lower().startswith("drev"):
        return None
    root = exe.parent
    if (root / "app" / "watcher").is_dir() and (root / "python").is_dir():
        return root
    return None


def install_root() -> Path | None:
    """포터블 설치본의 루트 — 창(Drev.exe)이든 예약 검사(python\\pythonw.exe app\\entry.py run)든.

    portable_root()는 실행 파일 이름이 Drev로 시작할 때만 답해, 07:00 예약 검사에서는
    None이었다 — 그래서 무인 검사는 새 판을 알아도 교체할 길이 없었다 (2026-09-11)."""
    r = portable_root()
    if r is not None:
        return r
    if getattr(sys, "frozen", False):
        return None
    exe = Path(getattr(sys, "executable", "") or "")
    if exe.name.lower() in ("python.exe", "pythonw.exe") and exe.parent.name.lower() == "python":
        base = exe.parent.parent
        if (base / "app" / "watcher").is_dir():
            return base
    return None


AUTO_MARK = "AUTO_UPDATED"        # 무인 교체가 끝났음을 다음 창 실행에 알리는 표식 파일
APPLYING_MARK = "UPDATE_APPLYING"  # 교체 프로세스가 일하는 동안의 표식(pid) — 창·정리가 건드리지 않게
FAILED_MARK = "UPDATE_FAILED"      # 무인 교체 실패 기록 "버전|시각|사유" — 같은 판을 매일 다시 받지 않게
FAILED_RETRY_DAYS = 3


def _pid_alive(pid: int) -> bool:
    if not pid:
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, int(pid))     # SYNCHRONIZE
        if not h:
            return False
        rc = k.WaitForSingleObject(h, 0)
        k.CloseHandle(h)
        return rc != 0                                     # WAIT_OBJECT_0(0)이면 끝난 것
    except Exception:
        return False


def applying_pid(root: Path):
    """교체 프로세스가 지금 일하고 있으면 그 pid, 아니면 None (죽은 pid의 표식은 지운다).

    내려받기~교체 사이(수십 초~수 분)에 사람이 Drev.exe를 켜면 새 창의 cleanup()이 교체 원본
    (.update)과 되돌리기 재료(*.old-drev)를 함께 지워 app/ 자체가 사라질 수 있었다 (검토20 차단 1,
    합성 트리 재현). 표식이 살아 있는 동안 창은 열지 않고, 정리는 손대지 않는다."""
    p = Path(root) / APPLYING_MARK
    try:
        if not p.exists():
            return None
        pid = int(p.read_text(encoding="utf-8", errors="replace").strip() or 0)
        age = time.time() - p.stat().st_mtime
    except (OSError, ValueError):
        return None
    # 교체 프로세스가 강제 종료되고 같은 pid를 다른 장수 프로세스가 받으면 창이 영영 안 열린다 —
    # 표식은 길어도 30분이면 거짓이다 (검토20 재검증 ②)
    if _pid_alive(pid) and age < 1800:
        return pid
    _rm(p)
    return None


def window_running(root=None):
    """Drev 창(Drev.exe / Drev(문제해결용).exe)이 떠 있나 — 떠 있으면 무인 교체를 미룬다.
    창이 쓰는 파일을 밑에서 갈아끼우지 않기 위해서다; 창에는 [설치] 단추가 있다.
    root를 주면 **그 설치본의** 창만 본다 — USB 포터블·시험 사본 등 다른 폴더의 Drev.exe 때문에
    무기한 미루던 것 (검토21 운영 낮음 1). True/False, 확인 자체가 안 되면 None (부르는 쪽이
    '확인 불가'로 적는다 — "창이 떠 있어"라는 거짓 사유를 남기지 않게)."""
    if sys.platform != "win32":
        return False
    me = os.getpid()
    if root is not None:
        try:
            ps = ("Get-CimInstance Win32_Process -Filter \"Name like 'Drev%'\" | "
                  "ForEach-Object { $_.ProcessId.ToString() + '|' + $_.ExecutablePath }")
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                               capture_output=True, timeout=25, creationflags=0x08000000)
            if r.returncode == 0:
                want = str(Path(root).resolve()).lower().rstrip("\\") + "\\"
                for line in r.stdout.decode("utf-8", "replace").splitlines():
                    pid_s, _, exe = line.strip().partition("|")
                    try:
                        pid = int(pid_s)
                    except ValueError:
                        continue
                    if pid != me and exe and exe.lower().startswith(want):
                        return True
                return False
        except Exception:
            pass                              # PowerShell이 없거나 막힘 — 아래 전체 목록으로
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Drev*", "/FO", "CSV", "/NH"],
                           capture_output=True, timeout=15, creationflags=0x08000000)
        out = r.stdout.decode("mbcs", "replace")
    except Exception:
        return None
    for line in out.splitlines():
        if not line.startswith('"Drev'):
            continue
        cols = [c.strip('"') for c in line.split('","')]
        try:
            if int(cols[1]) != me:
                return True
        except (IndexError, ValueError):
            return True
    return False


def scan_lock_holder(lock_db):
    """이력 DB의 검사 잠금을 쥔 살아 있는 프로세스 pid (없으면 None). 교체 프로세스는 watcher
    패키지 없이 단독으로 돌므로 sqlite로 직접 읽는다 — 다른 검사 위에 파일을 갈지 않게 (검토20 중간 3).
    DB 경로는 부르는 쪽(cli)이 넘긴다 — 이 모듈은 설정·데이터 위치를 스스로 알지 않는다(읽기 전용 차단벽)."""
    import sqlite3
    if not lock_db:
        return None
    db = Path(lock_db)
    if not db.exists():
        return None
    try:
        con = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True, timeout=5)
        try:
            row = con.execute("SELECT value FROM meta WHERE key = 'run_lock'").fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    if not row:
        return None
    try:
        pid, at = int(str(row[0]).split(":")[0]), float(str(row[0]).split(":")[1])
    except (ValueError, IndexError):
        return None
    if time.time() - at > 6 * 3600 or not _pid_alive(pid):
        return None
    return pid


def recent_failure(root: Path, version: str, days: int = FAILED_RETRY_DAYS):
    """같은 판의 무인 교체가 최근 days일 안에 실패했으면 그 사유(문자열), 아니면 빈 문자열."""
    p = Path(root) / FAILED_MARK
    try:
        if not p.exists():
            return ""
        ver, at, why = (p.read_text(encoding="utf-8", errors="replace").split("|", 2) + ["", ""])[:3]
        if ver != version:
            return ""
        if time.time() - float(at or 0) > days * 86400:
            return ""
        return why or "사유 기록 없음"
    except (OSError, ValueError):
        return ""


def _set(state: str, pct: int = 0, msg: str = "", error: str = "") -> None:
    PROGRESS.update(state=state, pct=pct, msg=msg, error=error, at=time.time())


def busy(within: float = 600.0) -> bool:
    """지금 업데이트 진행 중인가. 중간에 멈춘 상태가 영영 남지 않도록 시간 제한을
    둔다 — 진행 표시가 계속 걸려 있으면 새 버전 알림이 가려진다 (2026-09-01)."""
    return (PROGRESS.get("state") in ("download", "verify", "extract", "apply")
            and time.time() - float(PROGRESS.get("at") or 0) < within)


# ------------------------------------------------------------------ 내려받기

# 내려받기를 허용하는 곳. 받은 파일은 그대로 **실행**된다(verify_exe가 --version을
# 돌린다) — 그런데 스킴·호스트 제한이 없어서 version.json의 "exe"가 평문 http나
# 사내 공유 폴더를 가리키는 file 주소여도 받아서 실행했다 (2026-09-09 업데이트 검토
# 중간 6 실증). 서명이 없는 동안 TLS + 지문이 방어 전부라, 최소한 그 둘이 걸리는
# 곳으로 좁힌다.
# release-assets.githubusercontent.com: 2026-09-13 GitHub가 릴리스 자산의 302 목적지를
# objects.→release-assets.로 바꿔, 그 전 판(≤v0.56.0)은 "허용되지 않은 주소로 넘어갔습니다"로
# 업데이트가 전부 막혔다(이 PC 실사용에서 실증). 그 판들의 구제는 App.zip을 drev.co.kr에도
# 두는 것으로(release.py step_site) — 여기 목록은 앞으로의 판을 위한 것.
ALLOWED_HOSTS = ("drev.co.kr", "www.drev.co.kr", "github.com",
                 "objects.githubusercontent.com",
                 "release-assets.githubusercontent.com", "codeload.github.com",
                 "gmlvy12.github.io")


# 이 PC 안(루프백)은 스킴을 가리지 않는다 — 사내에 직접 미러를 띄우는 경우와
# 시험용이다. 여기로 무엇을 받든 이미 이 PC에서 프로그램을 돌릴 수 있는 사람이라
# 밖에서 들어오는 경로가 새로 열리지는 않는다.
_LOOPBACK = ("127.0.0.1", "localhost", "::1")


def url_ok(url: str) -> bool:
    """https이고 허용 호스트인가 (하위 도메인은 허용하지 않는다). 루프백은 예외."""
    from urllib.parse import urlsplit
    try:
        u = urlsplit(str(url or ""))
    except ValueError:
        return False
    host = (u.hostname or "").lower()
    if host in _LOOPBACK and u.scheme in ("http", "https"):
        return True
    return u.scheme == "https" and host in ALLOWED_HOSTS


def download(url: str, dest: Path, on_progress=None, sha256: str = "") -> Path:
    """zip을 받아 dest에 저장. 도중 실패하면 예외. sha256을 주면 받은 뒤 대조한다 —
    배포자가 올린 파일과 다르면(중간 변조·캐시 오염) 교체하지 않는다 (2026-09-02)."""
    import urllib.request
    if not url_ok(url):
        raise OSError(f"허용되지 않은 내려받기 주소입니다 (https + 공식 배포처만): {url}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".part")
    # 고정 이름(/Drev-App.zip)을 프록시·CDN이 10분 캐시한다 — 배포 직후의 [설치]·무인 교체가 새
    # version.json + 옛 zip으로 지문 불일치가 됐다 (검토25 운영 1-2). 지문 앞자리를 캐시 버스터로
    req_url = url
    if sha256 and "github.com" not in (url or ""):
        req_url = url + ("&" if "?" in url else "?") + "v=" + sha256[:8]
    req = urllib.request.Request(req_url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    with urllib.request.urlopen(req, timeout=30) as r:
        # 302로 허용 목록 밖 호스트에 데려가면 그대로 받아서 **실행**까지 했다
        # (2026-09-09 배포 후 검토 낮음 7 실증) — 최종 주소도 본다
        final = getattr(r, "url", None) or url
        if not url_ok(final):
            raise OSError(f"내려받기가 허용되지 않은 주소로 넘어갔습니다: {final}")
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        with open(tmp, "wb") as f:
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if on_progress:
                    on_progress(got, total)
    if total and tmp.stat().st_size != total:
        tmp.unlink(missing_ok=True)
        raise OSError("내려받기가 중간에 끊겼습니다")
    if sha256:
        got_sha = _sha256_of(tmp)
        if got_sha.lower() != sha256.lower():
            tmp.unlink(missing_ok=True)
            raise OSError("받은 파일이 배포 목록의 지문(SHA-256)과 다릅니다 — 교체하지 않습니다")
    tmp.replace(dest)
    return dest


def _sha256_of(path: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _version_in(text: str) -> str:
    import re
    m = re.search(r'__version__\s*=\s*"([^"]+)"', text)
    return m.group(1) if m else ""


def verify_zip(zp: Path, expect: str = "") -> str:
    """zip이 온전한 Drev 포터블판인지 확인하고 버전을 돌려준다."""
    with zipfile.ZipFile(zp) as z:
        bad = z.testzip()
        if bad:
            raise OSError(f"받은 파일이 손상되었습니다: {bad}")
        names = z.namelist()
        top = {n.split("/")[0] for n in names}
        if len(top) != 1:
            raise OSError("압축 구조가 예상과 다릅니다")
        base = top.pop()
        need = [f"{base}/app/watcher/__init__.py", f"{base}/Drev.exe",
                f"{base}/python/python.exe", f"{base}/libs/sitecustomize.py"]
        missing = [n for n in need if n not in names]
        if missing:
            raise OSError("구성 파일이 빠졌습니다: " + ", ".join(missing[:2]))
        ver = _version_in(
            z.read(f"{base}/app/watcher/__init__.py").decode("utf-8", "replace"))
    if not ver:
        raise OSError("버전을 확인할 수 없습니다")
    if expect and ver != expect:
        raise OSError(f"내려받은 판(v{ver})이 안내된 판(v{expect})과 다릅니다")
    return ver


def runtime_of(root: Path) -> str:
    """설치본의 런타임 세대 (없으면 빈 문자열 — 옛 판)."""
    try:
        return (root / "runtime.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def verify_app_zip(zp: Path, expect: str = "") -> str:
    """앱 소스만 담긴 zip 검증 — 구조와 버전을 확인하고 버전을 돌려준다."""
    with zipfile.ZipFile(zp) as z:
        bad = z.testzip()
        if bad:
            raise OSError(f"받은 파일이 손상되었습니다: {bad}")
        names = z.namelist()
        top = {n.split("/")[0] for n in names}
        if len(top) != 1:
            raise OSError("압축 구조가 예상과 다릅니다")
        base = top.pop()
        # app/ 밖의 항목(config.yaml·state.db 등)이 들어 있으면 swap이 사용자 설정·이력을 덮어쓴다 —
        # "이력·설정은 건드리지 않습니다"가 zip 내용에 달려 있지 않게 거른다 (검토20 낮음)
        stray = sorted({n.split("/")[1] for n in names
                        if n.count("/") >= 1
                        and n.split("/")[1] not in ("", "app", "설치안내.txt", "포터블안내.txt")})
        if stray:
            raise OSError(f"앱 zip에 app/ 밖의 항목이 있어 교체하지 않습니다: {', '.join(stray[:5])}")
        need = f"{base}/app/watcher/__init__.py"
        if need not in names:
            raise OSError("구성 파일이 빠졌습니다: app/watcher/__init__.py")
        if f"{base}/app/entry.py" not in names:
            raise OSError("구성 파일이 빠졌습니다: app/entry.py")
        ver = _version_in(z.read(need).decode("utf-8", "replace"))
    if not ver:
        raise OSError("버전을 확인할 수 없습니다")
    if expect and ver != expect:
        raise OSError(f"내려받은 판(v{ver})이 안내된 판(v{expect})과 다릅니다")
    return ver


def stage(zp: Path, work: Path) -> Path:
    """압축을 풀고 새 판의 루트 폴더를 돌려준다."""
    new = work / "new"
    if new.exists():
        shutil.rmtree(new, ignore_errors=True)
    new.mkdir(parents=True)
    with zipfile.ZipFile(zp) as z:
        z.extractall(new)
    tops = [p for p in new.iterdir() if p.is_dir()]
    if len(tops) != 1:
        raise OSError("압축 해제 결과가 예상과 다릅니다")
    return tops[0]


# -------------------------------------------------------------------- 교체

def _rm(p: Path) -> None:
    """파일이든 폴더든 없앤다 (없으면 조용히)."""
    if p.is_dir():
        shutil.rmtree(p, ignore_errors=True)
    else:
        p.unlink(missing_ok=True)


_WINERR_KO = {
    5: "접근 거부 — 백신·탐색기·다른 Drev가 파일을 잡고 있었습니다",
    32: "다른 프로그램이 파일을 사용 중이었습니다",
    33: "다른 프로그램이 파일 일부를 잠갔습니다",
    112: "디스크 공간이 부족합니다",
    2: "파일을 찾을 수 없습니다",
    3: "경로를 찾을 수 없습니다",
    1223: "작업이 취소되었습니다",
}


def _friendly_os_error(e: BaseException) -> str:
    """원복 사유가 날 WinError로 화면에 뜨던 것 — 한국어 한 줄로 (검토19 운영 ⑩)."""
    code = getattr(e, "winerror", None)
    ko = _WINERR_KO.get(code)
    if ko:
        return f"{ko} (WinError {code})"
    return str(e)


def swap(root: Path, src: Path, retries: int = 20, verify=None) -> None:
    """src(새 판)의 항목만 root에 교체한다. 실패하면 전부 되돌린다.

    src에 있는 이름만 손대므로 state.db·config.yaml 등 데이터는 자동으로 남는다.

    verify를 주면 **되돌릴 수 있는 동안** 불러 새 판이 실제로 실행되는지
    확인한다. 여기서 실패하면 옛 파일이 아직 살아 있으므로 전부 원복한다
    (2026-09-02: 지금까지 트리 교체에는 이 확인이 없어, 깨진 판으로 바뀌면
    되돌릴 길이 없었다)."""
    items = sorted(p.name for p in src.iterdir())
    renamed: list[tuple[Path, Path]] = []      # (원래 이름, 임시 이름)
    copied: list[Path] = []
    try:
        for name in items:
            s, d = src / name, root / name
            if d.exists():
                old = root / (name + OLD_SUFFIX)
                _rm(old)
                for i in range(retries):       # 잠금이 풀릴 때까지 잠깐 기다린다
                    try:
                        d.rename(old)
                        break
                    except OSError:
                        if i == retries - 1:
                            raise
                        time.sleep(1)
                renamed.append((d, old))
            if s.is_dir():
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
            copied.append(d)
        if verify is not None:
            verify()                            # 실패하면 아래에서 전부 원복
    except Exception:
        # 복사는 폴더 중간에서도 깨질 수 있다 — 반쯤 만들어진 것까지 치운 뒤에
        # 되돌려야 한다 (그러지 않으면 "이미 있다"며 복구를 건너뛴다. 2026-08-31
        # 회귀 테스트가 잡아낸 결함)
        restored, failed = set(), []
        for d, old in renamed:
            try:                                # 하나가 막혀도 나머지는 되돌린다
                _rm(d)
                if old.exists():
                    old.rename(d)
                    restored.add(d)
                else:
                    # 되돌리기 재료가 사라졌다(다른 프로세스의 정리 등) — 방금 d를 지웠으니
                    # 그 항목은 없어진 것이다. '되돌렸습니다'라 적으면 거짓 (검토20 차단 1)
                    failed.append(f"{d.name}: 되돌리기 재료({old.name})가 없음")
            except OSError as e:
                failed.append(f"{d.name}: {e}")
        for d in copied:                        # 이전 판에 없던 새 파일 정리
            if d not in restored:
                _rm(d)
        if failed:
            # 거짓 '되돌렸습니다'를 남기지 않는다 — 무엇이 못 돌아갔는지 그대로
            raise OSError("원복 불완전 — " + "; ".join(failed)
                          + " (*.old-drev 폴더를 수동으로 되돌리거나 설치 파일로 덮어써 주세요)")
        raise
    for _, old in renamed:                      # 성공 — 옛 파일 정리
        _rm(old)


def verify_tree(root: Path) -> str:
    """교체한 트리가 실제로 실행되는지 한 번 돌려본다 (2026-09-02).

    포터블/설치판은 파일 하나가 아니라 트리(python/ + app/ + libs/)라서,
    복사가 다 끝났어도 실행이 안 될 수 있다. 창 없는 python.exe로 부른다 —
    Drev.exe(pythonw 사본)는 표준출력이 없어 확인에 쓸 수 없다."""
    py = root / "python" / "python.exe"
    entry = root / "app" / "entry.py"
    if not py.exists() or not entry.exists():
        raise OSError(f"교체 후 실행 파일이 없습니다: {py.name}/{entry.name}")
    # encoding/errors를 주지 않으면 한국어 윈도우에서 자식 출력을 cp949로 읽다가
    # UnicodeDecodeError가 리더 스레드에서 터진다 — 출력이 빈 문자열이 되고
    # returncode까지 1로 뒤집혀, **멀쩡한 새 판을 '실행되지 않습니다'로 되돌렸다**
    # (2026-09-09 업데이트 검토 중간 4). 스케줄러 쪽(cli.py)은 이미 이렇게 한다
    r = subprocess.run([str(py), str(entry), "--version"],
                       capture_output=True, text=True, timeout=120,
                       encoding="utf-8", errors="replace",
                       stdin=subprocess.DEVNULL, env=verify_env(),
                       creationflags=0x08000000)
    out = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0 or "Drev" not in out:
        raise OSError(f"교체한 판이 실행되지 않습니다 (코드 {r.returncode}): "
                      f"{out.strip()[:200]}")
    # --version은 cli만 읽고 끝난다 — 창·추출·그림·워커 모듈이 깨진 판도 "교체 완료"로 굳었다
    # (검토25 운영 1-1, 임시 트리 실측). 핵심 모듈을 실제로 import해 본다 (+1초)
    # 함수 안에서만 import되는 모듈(ocr·secret·webengine·selfupdate·dwg·logfile)은 위 14개를
    # 읽어도 닿지 않아, 백신이 그중 하나를 격리한 판도 "교체 완료"였다 — ocr이면 스캔 PDF 글자
    # 추출이 조용히 꺼지고 secret이면 아침 메일이 비밀번호를 못 푼다 (검토30 D 1-7, 실측).
    # 문법·부분 복사는 compileall이 33개 전부를 1초 안에 본다
    mods = ("watcher.web", "watcher.cli", "watcher.worker", "watcher.capture", "watcher.render",
            "watcher.extract.dxf", "watcher.extract.pdf", "watcher.extract.xlsx", "watcher.extract.docx",
            "watcher.brief", "watcher.mail", "watcher.consistency", "watcher.diff", "watcher.state",
            "watcher.ocr", "watcher.secret", "watcher.webengine", "watcher.selfupdate",
            "watcher.dwg", "watcher.logfile")
    r1 = subprocess.run([str(py), "-m", "compileall", "-q", str(root / "app" / "watcher")],
                        capture_output=True, text=True, timeout=180, cwd=str(root),
                        encoding="utf-8", errors="replace",
                        stdin=subprocess.DEVNULL, env=verify_env(),
                        creationflags=0x08000000)
    if r1.returncode != 0:
        raise OSError("교체한 판에 읽을 수 없는 파일이 있습니다: "
                      f"{((r1.stderr or '') + (r1.stdout or '')).strip()[-300:]}")
    r2 = subprocess.run([str(py), "-c", "import " + ", ".join(mods) + "; print('MODS_OK')"],
                        capture_output=True, text=True, timeout=180, cwd=str(root),
                        encoding="utf-8", errors="replace",
                        stdin=subprocess.DEVNULL, env=verify_env(),
                        creationflags=0x08000000)
    if r2.returncode != 0 or "MODS_OK" not in (r2.stdout or ""):
        raise OSError("교체한 판의 모듈을 읽지 못합니다: "
                      f"{((r2.stderr or '') + (r2.stdout or '')).strip()[-300:]}")
    return out.strip()


def cleanup(root: Path) -> None:
    """작업 폴더·되돌리기용 잔재 정리 (다음 실행 때 조용히)."""
    if applying_pid(root) is not None:
        return                              # 교체가 진행 중 — 원본도 되돌리기 재료도 건드리지 않는다
    work = root / WORK_DIRNAME
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    if (root / "ROLLBACK_INCOMPLETE").exists():
        return                              # 원복 재료를 지우지 않는다 (사람이 되돌릴 것)
    for p in root.glob("*" + OLD_SUFFIX):
        _rm(p)


def _wait_pid(pid: int, timeout: float = 60.0) -> bool:
    """그 프로세스가 끝날 때까지 기다린다 (실행 중 파일은 교체할 수 없으므로).

    끝났으면 True. 시간 안에 안 끝나면 False — 부르는 쪽이 판단한다."""
    if not pid:
        return True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, pid)     # SYNCHRONIZE
        if not h:
            return True                                # 이미 사라진 PID
        rc = k.WaitForSingleObject(h, int(timeout * 1000))
        k.CloseHandle(h)
        return rc == 0                                 # WAIT_OBJECT_0
    except Exception:
        time.sleep(3)
        return False


def _force_exit(pid: int) -> bool:
    """끝나지 않는 이전 판 **그 프로세스 하나만** 끝낸다 (2026-09-02).

    이름으로 싹쓸이(taskkill /IM)하지 않는다 — 같은 이름의 다른 창까지
    죽이면 사람이 보던 화면이 사라진다. 업데이트가 넘겨준 PID만 대상."""
    if not pid:
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x0001, False, pid)         # PROCESS_TERMINATE
        if not h:
            return False
        ok = bool(k.TerminateProcess(h, 0))
        k.CloseHandle(h)
        if ok:
            time.sleep(1.5)                            # 핸들이 풀릴 틈
        return ok
    except Exception:
        return False


# --------------------------------------------- 설치판(단일 exe) 자기 교체

def child_env() -> dict:
    """자식 프로세스용 환경 — PyInstaller 내부 변수를 걷어낸다.

    프리즌 앱이 **다른** exe를 실행하면, 자식이 부모의 `_PYI_*`/`_MEIPASS2`를
    물려받아 "부모 프로세스의 실행 파일이 다르다"며 스스로 종료한다
    (2026-09-01 실사고: 업데이트 검증 단계에서 오류 창). 물려주지 않으면 된다."""
    return {k: v for k, v in os.environ.items()
            if not k.startswith("_PYI") and k not in ("_MEIPASS2",)}


def verify_env() -> dict:
    """검증용 자식 환경 — 출력을 UTF-8로 고정해 한글이 섞여도 읽을 수 있게 한다.
    (errors='replace'가 사고는 막지만, 메시지를 사람이 읽게 하려면 이게 필요하다)"""
    return {**child_env(), "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}


def installed_exe() -> Path | None:
    """설치판이면 실행 중인 exe 경로, 아니면 None.

    포터블과 달리 파일 하나라 교체가 단순하다: 윈도우는 **실행 중인 exe의 이름
    변경**을 허용하므로, 옛 파일을 옆으로 밀고 새 파일을 그 자리에 놓으면 된다."""
    if not getattr(sys, "frozen", False):
        return None
    return Path(sys.executable)


def verify_exe(path: Path, expect: str = "") -> str:
    """내려받은 실행 파일을 한 번 돌려 버전을 확인한다.

    구성 검증인 동시에 **이 PC에서 실행 가능한지**(스마트 앱 컨트롤 차단 여부)
    확인이다 — 여기서 막히면 교체하지 않고 이전 판을 그대로 둔다."""
    if path.stat().st_size < 5_000_000:
        raise OSError("받은 파일이 너무 작습니다 — 내려받기가 끊긴 것 같습니다")
    with open(path, "rb") as f:
        if f.read(2) != b"MZ":
            raise OSError("받은 파일이 실행 파일이 아닙니다")
    try:
        # stdin=DEVNULL 필수: 창 모드(콘솔 없는) 앱에서는 표준입력 핸들이 무효라
        # 이걸 빼면 하위 프로세스 생성 자체가 실패한다 (2026-08-31 실측)
        r = subprocess.run([str(path), "--version"], capture_output=True,
                           text=True, timeout=90, stdin=subprocess.DEVNULL,
                           encoding="utf-8", errors="replace",   # cp949 디코드 사고 방지
                           env=verify_env(),
                           creationflags=0x08000000)      # 창 띄우지 않음
    except Exception as e:
        # 스마트 앱 컨트롤(SAC)이 서명 없는 실행 파일을 막는 경우가 있다 —
        # 빌드마다 판정이 달라 설치판은 이 PC에서 언제든 막힐 수 있다
        # (2026-08-31 실측: 같은 코드의 두 빌드 중 하나만 차단). 이럴 땐
        # 교체하지 않고 서명된 파이썬으로 도는 포터블판을 안내한다.
        blocked = "4551" in str(e) or "애플리케이션 제어" in str(e)
        if blocked:
            raise OSError("이 PC의 보안 정책(스마트 앱 컨트롤)이 새 실행 파일을 "
                          "차단했습니다 — 이전 판을 그대로 둡니다. "
                          "포터블판을 쓰시면 이 문제가 없습니다") from e
        raise OSError(f"받은 프로그램을 실행할 수 없습니다: {e}") from e
    out = (r.stdout or r.stderr or "").strip()
    if not out.startswith("Drev "):
        detail = (out or f"종료 코드 {r.returncode}")[:200]
        raise OSError("받은 프로그램이 응답하지 않습니다 "
                      f"(백신·보안 정책 차단일 수 있습니다) — {detail}")
    ver = out.split(" ", 1)[1].strip()
    if expect and ver != expect:
        raise OSError(f"내려받은 판(v{ver})이 안내된 판(v{expect})과 다릅니다")
    return ver


def rollback_exe(cur: Path) -> bool:
    """교체를 되돌린다 — 옆으로 밀어둔 이전 실행 파일을 제자리로."""
    old = cur.with_name(cur.name + OLD_SUFFIX)
    if not old.exists():
        return False
    _rm(cur)
    old.rename(cur)
    return True


def swap_exe(cur: Path, new: Path) -> None:
    """실행 중인 exe를 옆으로 밀고 새 파일을 그 자리에 놓는다. 실패하면 원복."""
    old = cur.with_name(cur.name + OLD_SUFFIX)
    _rm(old)
    cur.rename(old)
    try:
        shutil.copy2(new, cur)
    except Exception:
        _rm(cur)
        old.rename(cur)                 # 원래 판 그대로 되돌린다
        raise


# ------------------------------------------------------- 앱 쪽 진입 (스레드)

def run_update_exe(exe: Path, url: str, expect: str = "",
                   exit_after: bool = True, exe_sha: str = "") -> None:
    """설치판 자동 교체: 내려받기 → 실행 검증 → 교체 → 새 판 실행 → 종료."""
    work = exe.parent / WORK_DIRNAME
    try:
        _set("download", 0, "새 판을 내려받는 중…")

        def prog(got, total):
            pct = int(got * 100 / total) if total else 0
            _set("download", pct, f"내려받는 중… {pct}% "
                 f"({got // 1048576}MB / {total // 1048576 if total else '?'}MB)")

        newexe = download(url, work / "Drev-new.exe", prog, **({'sha256': exe_sha} if exe_sha else {}))
        _set("verify", 100, "받은 프로그램을 확인하는 중… (한 번 실행해 봅니다)")
        ver = verify_exe(newexe, expect)
        _set("apply", 100, f"v{ver}로 교체하는 중 — 잠시 후 다시 열립니다.")
        swap_exe(exe, newexe)
        # 제자리에서도 실행되는지 확인한 뒤에 종료한다. 보안 정책(SAC)은 같은
        # 내용이라도 파일 위치·사본마다 판정이 달라, 교체 직후 실행이 막히면
        # 프로그램이 사라진 것처럼 된다 (2026-08-31 실측) → 그러면 되돌린다
        try:
            verify_exe(exe, ver)
        except Exception as e:
            rollback_exe(exe)
            raise OSError(f"새 판이 이 PC에서 실행되지 않아 되돌렸습니다 — {e}") from e
        print(f"[update] v{ver}로 교체 완료 — 새 판을 실행합니다")
        # 죽어가는 프로세스에서 os.startfile로 띄우면 새 판이 뜨지 않는 일이
        # 있었다(2026-08-31 실측) — 부모와 분리된 프로세스로 직접 띄운다
        try:
            # DREV_TAKEOVER: 설치판은 새 판을 먼저 띄우고 3초 뒤에 끝난다 — 그 3초 동안
            # 옛 판이 멀쩡히 응답하므로 새 판이 '살아 있는 판이 쓰는 중'으로 보고 옆 포트로
            # 비켜섰다. 그러면 보던 브라우저 탭이 죽은 주소에 남는다 (검토15 운영 B3)
            _env = dict(child_env() or os.environ)
            _env["DREV_TAKEOVER"] = "1"
            subprocess.Popen([str(exe)], close_fds=True,
                             stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             env=_env,
                             creationflags=0x00000008 | 0x00000200)
        except Exception as e:          # 그래도 실패하면 셸에 맡긴다
            print(f"[update] 직접 실행 실패({e}) — 셸로 시도")
            os.startfile(str(exe))
        if exit_after:
            time.sleep(3.0)             # 새 프로세스가 자리 잡을 시간
            os._exit(0)
    except Exception as e:
        print(f"[update] 실패: {type(e).__name__}: {e}")
        _set("error", 0, "", f"자동 업데이트에 실패했습니다: {e}")
        shutil.rmtree(work, ignore_errors=True)


def run_update(root: Path, url: str, expect: str = "",
               exit_after: bool = True, app_url: str = "",
               remote_runtime: str = "", app_sha: str = "",
               portable_sha: str = "", relaunch: bool = True, lock_db: str = "") -> None:
    """내려받기 → 검증 → 압축 해제 → 교체 프로세스 실행 → 앱 종료.

    런타임(파이썬·라이브러리) 세대가 같으면 **앱 소스만 담은 작은 zip**을 받는다
    — 전체는 55MB인데 실제로 바뀌는 건 대개 538KB뿐이다 (2026-09-01 사용자:
    "40MB짜리를 그대로 다운받아야 하니까")."""
    work = root / WORK_DIRNAME
    small = bool(app_url) and remote_runtime and runtime_of(root) == remote_runtime
    try:
        _set("download", 0, "새 판을 내려받는 중…"
             + (" (가벼운 업데이트)" if small else ""))

        def prog(got, total):
            pct = int(got * 100 / total) if total else 0
            _set("download", pct, f"내려받는 중… {pct}% "
                 f"({got // 1048576}MB / {total // 1048576 if total else '?'}MB)")

        if not (app_sha if small else portable_sha):
            print("[update] 배포 목록에 지문(sha256)이 없어 지문 대조 없이 진행합니다 "
                  "— 버전·구조 검증은 그대로 합니다")
        zp = download(app_url if small else url,
                      work / ("Drev-App.zip" if small else "Drev-Portable.zip"),
                      prog, **({'sha256': app_sha if small else portable_sha}
                                if (app_sha if small else portable_sha) else {}))
        _set("verify", 100, "받은 파일을 확인하는 중…")
        ver = verify_app_zip(zp, expect) if small else verify_zip(zp, expect)
        _set("extract", 100, "압축을 푸는 중…")
        src = stage(zp, work)
        _set("apply", 100, f"v{ver}로 교체하는 중 — 프로그램이 잠시 닫혔다가 "
                           f"다시 열립니다.")
        spawn_swapper(root, src, relaunch=relaunch, lock_db=lock_db)
        if exit_after:
            time.sleep(1.5)      # 화면에 안내가 보이도록 잠깐 두고 종료
            os._exit(0)
    except Exception as e:
        print(f"[update] 실패: {type(e).__name__}: {e}")
        _set("error", 0, "", f"자동 업데이트에 실패했습니다: {e}")
        shutil.rmtree(work, ignore_errors=True)


def _parses(path: Path) -> bool:
    """파이썬 파일이 문법적으로 온전한가 (실행하지 않고 ast로만)."""
    try:
        import ast
        ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        return True
    except (OSError, SyntaxError, ValueError):
        return False


def spawn_swapper(root: Path, src: Path, relaunch: bool = True,
                  lock_db: str = "") -> subprocess.Popen:
    """교체 담당 프로세스를 띄운다 — 새 판의 파이썬으로 이 파일을 실행한다.
    relaunch=False는 예약 검사 뒤의 무인 교체 — 07시에 창을 띄우지 않는다. lock_db는 그때 교체
    직전에 다른 검사가 돌고 있는지 볼 이력 DB 경로(cli가 안다)."""
    # 앱만 받은 경우 src에는 python이 없다 — 설치본의 파이썬으로 실행한다
    # (python.exe는 교체 대상이 아니므로 실행 중이어도 안전)
    py = src / "python" / "python.exe"
    if not py.exists():
        py = root / "python" / "python.exe"
    script = src / "app" / "watcher" / "selfupdate.py"
    if not script.exists() or not _parses(script):
        # 새 판의 이 파일이 깨졌으면 교체 프로세스가 0.2초 만에 죽어 아무 줄도 안 남고, 창은
        # 이미 닫혀 다시 안 뜬다 — 설치본의 것으로 띄우면 교체 검증이 깨진 판을 되돌린다 (검토30 D 1-7)
        script = root / "app" / "watcher" / "selfupdate.py"
    cmd = [str(py), str(script), "--apply", "--root", str(root),
           "--src", str(src), "--wait-pid", str(os.getpid())]
    if relaunch:
        cmd += ["--relaunch", str(root / "Drev.exe")]
    if lock_db:
        cmd += ["--lock-db", str(lock_db)]
    flags = 0x00000008 | 0x08000000        # DETACHED_PROCESS | NO_WINDOW
    return subprocess.Popen(cmd, close_fds=True, stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            env=child_env(), creationflags=flags)


# ------------------------------------------------- 교체 프로세스(단독 실행)

def prewarm(root: Path, timeout: float = 180.0) -> float:
    """새 판을 창 없이 한 번 import해 둔다 — 첫 실행 비용을 창 뒤로 숨기지 않게.

    새 파일 수백 개의 바이트코드 생성과 보안 소프트웨어 검사가 창이 뜬 뒤에
    일어나면 "로딩"처럼 보인다 (2026-09-02). 걸린 시간을 돌려준다(로그용)."""
    py = root / "python" / "python.exe"
    if not py.exists():
        return 0.0
    t0 = time.time()
    try:
        subprocess.run([str(py), "-c", "import watcher.web, watcher.cli"],
                       cwd=str(root), capture_output=True, timeout=timeout,
                       stdin=subprocess.DEVNULL, env=child_env(),
                       creationflags=0x08000000)
    except Exception:
        pass
    return time.time() - t0


def refresh_cache(root: Path) -> None:
    """`pythonw entry.py refresh-cache`를 창 없이 따로 띄운다 (판 교체 직후)."""
    pyw = root / "python" / "pythonw.exe"
    entry = root / "app" / "entry.py"
    if not pyw.exists() or not entry.exists():
        return
    # 교체 프로세스가 DEVNULL을 물려받고 있어 자식의 표준 스트림이 None이 아니고 entry.py의 우회도 안 탄다
    # (1회차 1). 부모가 연 핸들을 넘기면 append 플래그가 상속되지 않아 그 사이 다른 프로세스가 덧붙인
    # 줄을 덮어썼다 (2회차 A5) — 자식이 스스로 append로 열게 `--to-log`
    subprocess.Popen([str(pyw), str(entry), "refresh-cache", "--to-log"], cwd=str(root),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     env=child_env(), creationflags=0x08000000 | 0x00000008)   # NO_WINDOW | DETACHED


def relaunch(exe: Path) -> str:
    """새 판을 **탐색기에게 맡겨** 켠다 — 더블클릭과 같은 부모·환경·권한.

    교체 프로세스(창 없는 python.exe)가 직접 띄우면 새 판이 이전 판의 환경과
    계보를 물려받는다. 회사 보안 소프트웨어는 그 계보를 다르게 다루고, 실제로
    자동 재실행된 창만 멎었다 (2026-09-02). 돌려주는 값은 로그용 방식 이름."""
    try:
        if "," in str(exe):               # 탐색기는 쉼표를 인자 구분자로 본다
            raise OSError("쉼표 경로")
        subprocess.Popen(["explorer.exe", str(exe)], close_fds=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=0x08000000)
        return "explorer"
    except Exception:
        os.startfile(str(exe))            # 탐색기가 없으면 예전 방식
        return "startfile"


def _apply_cli(argv: list[str]) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--root", required=True)
    ap.add_argument("--src", required=True)
    ap.add_argument("--wait-pid", type=int, default=0)
    ap.add_argument("--relaunch", default="")
    ap.add_argument("--lock-db", default="")    # 검사 잠금을 볼 이력 DB (무인 교체만, cli가 넘김)
    a = ap.parse_args(argv)
    root, src = Path(a.root), Path(a.src)
    log = root / "watcher.log"

    def say(m):
        try:
            with open(log, "a", encoding="utf-8", errors="replace") as f:
                f.write(f"[update] {m} · {time.strftime('%Y-%m-%d %H:%M:%S')}\n")   # 어느 날인지 (검토21 운영 3)
        except OSError:
            pass

    # 교체 중 표식을 **맨 먼저** 쓴다 — 부른 프로세스(cli)가 내려받는 동안 자기 pid로 써 둔 표식을
    # 이어받아, 창·정리가 끼어들 틈을 없앤다 (검토20 재검증 ③)
    try:
        (root / APPLYING_MARK).write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass
    if not _wait_pid(a.wait_pid):
        # 이전 판이 안 죽는다 — 그대로 두면 응답 없는 옛 창이 앞에 남아
        # "업데이트 후 멈춘 것처럼 클릭이 안 됨"이 된다 (2026-09-02 회사 실사용)
        say(f"이전 판(PID {a.wait_pid})이 종료되지 않아 강제로 끝냅니다")
        _force_exit(a.wait_pid)
    time.sleep(1.0)
    unattended = not a.relaunch
    tag = " (예약 검사 뒤 자동 업데이트)" if unattended else ""
    new_ver = ""
    try:
        new_ver = _version_in((src / "app" / "watcher" / "__init__.py")
                              .read_text(encoding="utf-8", errors="replace"))
    except OSError:
        pass
    rc = 0
    try:
        if unattended:
            # 내려받는 동안 상황이 바뀌었을 수 있다 — 교체 **직전**에 다시 본다 (검토20 차단 1·중간 3)
            wr = window_running(root)
            if wr is not False:
                say("교체를 미룹니다 — " + ("창이 떠 있습니다" if wr else "창 실행 여부를 확인할 수 없습니다")
                    + ". 다음 예약 검사 때 다시 시도합니다" + tag)
                _rm(root / APPLYING_MARK)
                shutil.rmtree(root / WORK_DIRNAME, ignore_errors=True)
                return 2
            holder = scan_lock_holder(a.lock_db)
            waited = 0.0
            while holder and holder != a.wait_pid and waited < 600:
                time.sleep(10)             # 다른 검사(수동 실행·지연 시작)가 끝나길 최대 10분 기다린다
                waited += 10
                holder = scan_lock_holder(a.lock_db)
            if holder and holder != a.wait_pid:
                say(f"교체를 미룹니다 — 다른 검사(PID {holder})가 진행 중입니다. 다음 예약 검사 때 다시 시도합니다" + tag)
                _rm(root / APPLYING_MARK)
                shutil.rmtree(root / WORK_DIRNAME, ignore_errors=True)
                return 2
        swap(root, src, verify=lambda: verify_tree(root))
        say("교체 완료 — 새 판 실행 확인됨" + tag)
        _rm(root / "ROLLBACK_INCOMPLETE")       # 지난 실패 표식은 성공으로 끝난다
        _rm(root / FAILED_MARK)
        _rm(root / AUTO_MARK)                   # 유인 교체가 옛 무인 표식을 덮어쓰지 않게 (검토21 운영 낮음 3)
        if unattended:
            # 다음에 창을 여는 사람에게 "밤사이 vX로 바뀌었다"를 한 번 알린다
            try:
                ver = _version_in((root / "app" / "watcher" / "__init__.py")
                                  .read_text(encoding="utf-8", errors="replace"))
                (root / AUTO_MARK).write_text(ver, encoding="utf-8")
            except OSError:
                pass
    except Exception as e:
        # 되돌리기는 swap 안에서 끝났다. 여기서 중요한 건 **다시 켜는 것** —
        # 예전에는 여기서 그냥 끝나서 앱이 통째로 사라졌다 (2026-09-02 실사용:
        # "없는데 먹통이야 켜져있는거 없어")
        if "원복 불완전" in str(e):
            try:
                (root / "ROLLBACK_INCOMPLETE").write_text(str(e), encoding="utf-8")
            except OSError:
                pass
            say(f"교체 실패 — {e}" + tag)
        else:
            say(f"교체 실패 — 이전 판으로 되돌렸습니다: {_friendly_os_error(e)}" + tag)
        if unattended:
            # 같은 판을 매일 다시 받아 교체·원복을 반복하지 않게 (검토20 중간 2)
            try:
                (root / FAILED_MARK).write_text(
                    f"{new_ver}|{time.time():.0f}|{str(e)[:200]}", encoding="utf-8")
            except OSError:
                pass
        rc = 1
    finally:
        _rm(root / APPLYING_MARK)
        if unattended:
            shutil.rmtree(root / WORK_DIRNAME, ignore_errors=True)   # 창이 없는 PC에선 아무도 치우지 않는다
    warm = prewarm(root)                 # 창이 뜨기 전에 첫 실행 비용을 치른다 (무인 교체도 —
    if warm:                             # 다음 날 아침 첫 실행이 느리지 않게)
        say(f"새 판 예열 {warm:.1f}s")
    if rc == 0:
        # 새 판의 추출 세대로 기록을 미리 갱신한다(스냅샷 없음) — 안 하면 세대가 오른 판의 첫 검사가
        # 그 사이 바뀐 파일의 내용 비교를 통째로 건너뛴다 (검토25 감지 6-1). 창을 기다리게 하지
        # 않도록 따로 띄우고, 검사와 같은 잠금을 쓰므로 겹치면 스스로 물러난다
        try:
            refresh_cache(root)
            say("추출 기록 갱신 시작(새 세대) — 끝나면 로그에 남습니다")
        except Exception as e:
            say(f"추출 기록 갱신을 시작하지 못했습니다({e}) — 다음 검사가 대신 합니다")
    if a.relaunch:
        try:
            how = relaunch(Path(a.relaunch))   # 성공이면 새 판, 실패면 되돌린 이전 판
            say(f"다시 시작 ({how})")
        except OSError as e:
            say(f"다시 시작하지 못했습니다({e}) — Drev.exe를 직접 실행해주세요.")
    return rc


if __name__ == "__main__":
    sys.exit(_apply_cli(sys.argv[1:]))
