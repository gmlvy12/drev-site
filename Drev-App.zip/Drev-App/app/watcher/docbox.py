# -*- coding: utf-8 -*-
"""프로젝트 문서함 — 프로젝트 목록 요약 · 한 프로젝트의 문서 목록 · 문서 하나의 이력 (화면 3판 큰 그림, 2026-11-20).

큰 그림(DECISIONS 2026-11-20): 도면 관리가 아니라 **프로젝트별 문서 관리(현황·변경 기록)**. 감시는 여전히 읽기 전용이라
이 모듈은 state.db를 **읽기만** 한다(쓰기 0). 감시 화면(web.py)과 사내망(forms/changes.py)이 같이 쓰도록 web을 import하지 않는다 —
화면마다 다른 것(별칭 정규 이름·문서 종류 규칙·제외 폴더·7일 창)은 부르는 쪽이 함수로 넘긴다.

같은 뜻·같은 수 (화면끼리 수가 갈리지 않게):
- 귀속: 지금 파일(최신 스냅샷)마다 **가장 최근 변경 행**의 프로젝트(changes.project — 귀속을 바꾸면 이 값이 바뀐다)를 canon으로
  정규 이름에. 감시 화면의 _rc_proj_meta와 같다. 변경 행이 없는 파일(숨긴 기록)은 어느 프로젝트에도 넣지 않는다.
- 이번 주: 창(시작, 끝 — 첫 화면 '최근 변경' 7일 창과 같은 것) 안의 **진짜 변경**(첫 등록·'그 밖'이 아닌 것)이 있은 파일 수.
  지운 파일도 센다(최근 변경 표에 '삭제' 줄로 보인다). '그 밖'(이동·재저장·복사본…) 판정은 State.ack_marks 하나 —
  감시 화면·메일·사내망이 같이 쓰는 판정이다. 이동 짝(옮겨지며 내용도 바뀐 파일의 삭제 행)은 화면처럼 추가 쪽 하나로 센다.
- 확인 필요: 열린 검토 필요(issues.resolved_at IS NULL)를 canon(project)로 — /issues?p=·메뉴 수와 같다.
- Rev: 저장된 추출 결과(extracts.doc_json)의 표제란 REV 칸 — SQL json_extract로 그 칸만 읽는다. 추출을 다시 돌리지 않는다.
  추출기 묶음이 다른 기록('sha:묶음')을 고르는 규칙은 State.load_extract와 같다.

값은 모두 기록(ChangeItem·검토 필요 근거)에 있는 것 그대로다 — 새로 판단하지 않는다(원칙 5·6).
"""
from __future__ import annotations

import contextlib
import json
import sqlite3
from collections import Counter
from datetime import date, datetime, time as dtime, timedelta, timezone
from pathlib import PurePosixPath

from watcher.consistency import LABEL_TONE

WEEK_DAYS = 7          # 첫 화면 '최근 변경' 창과 같은 날 수 (web.RC_DAYS)
ADD_FOLD = 5           # 한 검사·한 프로젝트의 새 문서가 이만큼이면 '새 문서 N개' 한 줄 (web.RC_ADD_FOLD와 같은 수)
LOOK_BACK = 6          # 문서마다 '최근 변경'을 고를 때 거슬러 보는 변경 수(첫 등록 뺀) — 다시 저장만 한 날이 진짜 변경을 가리지 않게
UNASSIGNED = "미분류"

# 문서 종류 → 프로젝트 목록의 세 칸 (도면 · BOM·발주 · 그 밖)
KIND_COLS = ("도면", "BOM·발주", "그 밖")
_BOM_PO = frozenset({"BOM", "발주서"})

# 확인 필요 표시 색 — 빨강: 값이 서로 다름·Rev 거꾸로·출도 후 변경, 나머지는 노랑 (색은 consistency.LABEL_TONE 한 곳, 2026-11-20)
RED_CODES = frozenset(c for c, t in LABEL_TONE.items() if t == "red")


# ─────────────────────────── 작은 도구 ───────────────────────────

_CAD_EXTS = (".dxf", ".dwg")


def kind_col(kind: str, path: str = "") -> str:
    """문서 종류 → 프로젝트 목록의 칸 이름('도면'·'BOM·발주'·'그 밖'). 종류 이름이 도면이 아니어도 CAD 파일(.dxf·.dwg — 배선도·P&ID)은
    도면 칸에 센다: '배선/W-100.dxf'가 종류 '배선표'라 '그 밖'에 30개로 잡혀 도면이 9개뿐인 것처럼 보였다."""
    if kind in _BOM_PO:
        return "BOM·발주"
    if kind == "도면" or str(path or "").lower().endswith(_CAD_EXTS):
        return "도면"
    return "그 밖"


def issue_tone(codes) -> str:
    """열린 확인 필요 코드들 → 'red'|'amber'|'' — 하나라도 빨강 코드면 빨강."""
    codes = [str(c or "") for c in codes or ()]
    if not codes:
        return ""
    return "red" if any(c in RED_CODES for c in codes) else "amber"


def _parse_utc(iso: str) -> datetime:
    s = str(iso)
    if not ("+" in s[10:] or s.endswith("Z")):
        s = s + "+00:00"
    return datetime.fromisoformat(s)


def local_day(iso) -> str:
    """검사 시각(UTC ISO) → 이 PC 날짜 'YYYY-MM-DD'. 못 읽으면 ''."""
    if not iso:
        return ""
    try:
        return _parse_utc(str(iso)).astimezone().strftime("%Y-%m-%d")
    except ValueError:
        return ""


def _default_canon(p) -> str:
    return str(p or "").strip() or UNASSIGNED


def _default_kind(cfg):
    """경로 → 문서 종류 — 설정의 분류 규칙(정규 이름), 모르면 확장자로(summary._kind_tag). 화면의 _rc_kinder와 같은 규칙."""
    from watcher.doctype import UNKNOWN, canonical, kind_of
    from watcher.summary import _kind_tag
    memo: dict = {}

    def _k(path: str) -> str:
        k = memo.get(path)
        if k is None:
            try:
                k = canonical(kind_of(path, cfg))
            except Exception:      # noqa: BLE001 — 분류 규칙 오류로 목록이 죽지 않게
                k = ""
            if not k or k == UNKNOWN:
                k = _kind_tag(path)
            memo[path] = k
        return k
    return _k


def config_args(cfg) -> dict:
    """설정(config.yaml을 읽은 사전) → summaries·project_docs·doc_history에 넘길 {cfg, keep} — 감시 화면 WebApp._docbox_args와
    같은 해석: 문서 종류는 설정의 분류 규칙(cfg → _default_kind), 제외 폴더는 검사와 같은 cli._excludes_for + scan.is_excluded.
    정규 이름(canon)은 넘기지 않는다 — 부르는 쪽 몫(사내망은 열람 범위가 기록의 프로젝트 이름으로 정해져 DB 이름 그대로 쓴다).
    설정이 없거나 못 읽은 것(None·사전 아님)이면 기본 규칙 {cfg: None}. 무엇도 쓰지 않는다 (사내망 서버 2026-11-20 구현자 H)."""
    if not isinstance(cfg, dict):
        return {"cfg": None}
    try:
        from pathlib import Path
        from watcher.cli import _excludes_for, _root_labels
        from watcher.scan import is_excluded
        labels = _root_labels([Path(str(r)) for r in (cfg.get("roots") or [])])
        ex_by = {lb: _excludes_for(lb, labels, list(cfg.get("exclude") or [])) for lb in labels}
    except Exception:      # noqa: BLE001 — 제외 규칙을 못 만들면 거르지 않는다(다음 검사가 스냅샷에서 뺀다)
        return {"cfg": cfg, "keep": None}
    if not any(ex_by.values()):
        return {"cfg": cfg, "keep": None}

    def keep(p, _ex=ex_by, _is=is_excluded):
        lb, _s, rel = str(p).partition("/")
        return not (_ex.get(lb) and _is(rel, _ex[lb]))
    return {"cfg": cfg, "keep": keep}


def project_folder(paths, proj: str) -> tuple[str, str]:
    """프로젝트 파일들의 공통 폴더 → (폴더 경로, 화면 이름). 이름은 폴더 이름에서 프로젝트 번호를 뺀 나머지('P26-101 컨베이어'
    → '컨베이어', 번호가 없으면 폴더 이름 그대로). 감시 폴더 이름뿐이거나 공통 폴더가 없으면 이름은 ''(지어내지 않는다)."""
    common = None
    for p in paths:
        ps = PurePosixPath(str(p)).parent.parts
        if common is None:
            common = list(ps)
            continue
        k = 0
        while k < len(common) and k < len(ps) and common[k] == ps[k]:
            k += 1
        common = common[:k]
        if not common:
            break
    if not common:
        return "", ""
    # 파일이 모두 한 종류 폴더('도면'·'BOM'…)에 있으면 공통 폴더가 그 종류 폴더다 — 프로젝트 폴더는 그 위 ('P26-090 도면'이라는
    # 이름을 지어내던 것). 감시 폴더 이름(첫 마디)까지는 올라가지 않는다
    from watcher.doctype import looks_like_doctype_folder
    while len(common) >= 2 and looks_like_doctype_folder(common[-1]):
        common = common[:-1]
    folder = "/".join(common)
    if len(common) < 2:
        return folder, ""
    nm = common[-1]
    if proj and proj in nm:
        nm = " ".join(" ".join(nm.split(proj)).split()).strip(" _-·()[]")
    return folder, nm


def folder_label(path: str, base: str) -> str:
    """문서의 폴더 이름 — 프로젝트 공통 폴더(base) 아래 상대 경로('도면'·'도면/배선'). 공통 폴더 바로 아래면 그 폴더 이름."""
    par = str(PurePosixPath(str(path)).parent)
    if base and (par == base):
        return PurePosixPath(base).name or base
    if base and par.startswith(base + "/"):
        return par[len(base) + 1:]
    return par


@contextlib.contextmanager
def _state(db):
    """State 또는 DB 경로를 받는다 — 경로면 열고 닫는다."""
    from watcher.state import State
    if isinstance(db, State):
        yield db
        return
    with State(db) as st:
        yield st


def week_window(st, today: date | None = None) -> tuple[date, date]:
    """첫 화면 '최근 변경' 7일 창 (시작, 끝) — 감시 화면 WebApp._rc_window와 같은 규칙. 끝은 마친 마지막 검사 날, 기록된 가장 최근
    변경이 그 뒤면(마치지 못한 검사) 그 날까지, 오늘을 넘지 않는다."""
    today = today or date.today()
    anchor = today
    bad = st.get_meta("run_in_progress")
    bad_id = int(bad) if bad and str(bad).isdigit() else -1
    row = st.conn.execute("SELECT run_at FROM snapshots WHERE id != ? ORDER BY id DESC LIMIT 1", (bad_id,)).fetchone()
    if row and row[0]:
        d = local_day(row[0])
        if d:
            anchor = min(today, date.fromisoformat(d))
    newest = st.conn.execute("SELECT MAX(detected_at) FROM changes").fetchone()
    nd = local_day(newest[0]) if newest and newest[0] else ""
    if nd and nd > anchor.isoformat():
        anchor = min(today, date.fromisoformat(nd))
    return anchor - timedelta(days=WEEK_DAYS - 1), anchor


# ─────────────────────────── 한 번 읽기 (공통 재료) ───────────────────────────

class _Core:
    """한 번 읽은 공통 재료 — 지금 파일·귀속·창 안 변경·열린 검토 필요. 요약과 문서 목록이 같은 재료로 센다."""

    def __init__(self, st, canon=None, kind_of=None, keep=None, window=None, cfg=None, today=None):
        from watcher.state import State
        self.st = st
        self.canon = canon or _default_canon
        self.kind_of = kind_of or _default_kind(cfg)
        self.cfg = cfg
        self.window = window or week_window(st, today)
        self.first = st.first_snapshot_by_root()
        self.ext_base = st.ext_baseline()
        self._is_first = State.is_first_registration
        snap = st.conn.execute("SELECT MAX(id) FROM snapshots").fetchone()
        self.snap_id = snap[0] if snap else None
        files: dict = {}
        if self.snap_id is not None:
            for p, sha, size, mt in st.conn.execute(
                    "SELECT path, sha256, size, mtime FROM files WHERE snapshot_id = ?", (self.snap_id,)):
                if keep is not None and not keep(p):
                    continue
                files[p] = (sha, size, mt)
        # 귀속 — 경로마다 가장 최근 변경 행(한 번의 질의). 지금 없는 경로도 받아 두되 문서로는 지금 파일만
        self.proj_of: dict = {}
        for p, proj, kind in st.conn.execute(
                "SELECT c.path, c.project, c.kind FROM changes c "
                "JOIN (SELECT path, MAX(id) AS mid FROM changes GROUP BY path) m ON c.id = m.mid"):
            if p in files and kind != "removed":
                self.proj_of[p] = self.canon(proj)
        self.files = {p: v for p, v in files.items() if p in self.proj_of}
        self._win = None
        self._issues = None

    def is_first(self, kind, path, snap) -> bool:
        return self._is_first(kind, path, snap, self.first, self.ext_base)

    # 창 안 변경 — [(id, kind, path, snap, detected_at, 정규 프로젝트, 진짜?)]
    def window_rows(self) -> list:
        if self._win is not None:
            return self._win
        lo, hi = self.window
        lo_s, hi_s = lo.isoformat(), hi.isoformat()
        # 지역 날짜 경계를 UTC 글자 비교로 넉넉히(하루씩) 거른 뒤 지역 날짜로 정확히
        lo_utc = (datetime.combine(lo - timedelta(days=1), dtime.min).astimezone(timezone.utc)).isoformat()
        rows = [r for r in self.st.conn.execute(
            "SELECT id, kind, path, snapshot_id, detected_at, project FROM changes WHERE detected_at >= ? ORDER BY id DESC",
            (lo_utc,)) if lo_s <= local_day(r[4]) <= hi_s]
        cand = [r[0] for r in rows if not self.is_first(r[1], r[2], r[3])]
        exempt, notes = self.st.ack_marks(cand) if cand else ({}, {})
        added_at = {(r[2], r[3]) for r in rows if r[1] == "added"}
        out = []
        for cid, kind, path, snap, at, proj in rows:
            real = (not self.is_first(kind, path, snap)) and exempt.get(cid) != "quiet"
            if real and kind == "removed":
                # 옮겨지며 내용도 바뀐 파일의 삭제 행 — 화면(_fold_moves)은 추가 쪽 한 줄로 접는다. 같은 검사에 그 추가가 있으면 세지 않는다
                note = notes.get(cid) or ""
                if "옮겨지며 내용도 바뀜" in note:
                    tgt = note.split("(으)로 옮겨지며", 1)[0].strip()
                    if (tgt, snap) in added_at:
                        real = False
            out.append((cid, kind, path, snap, at, self.canon(proj), real))
        self._win = out
        return out

    def week_paths(self) -> dict:
        """정규 프로젝트 → 이번 주 진짜 변경이 있은 경로 묶음."""
        out: dict = {}
        for _cid, _k, path, _s, _at, proj, real in self.window_rows():
            if real:
                out.setdefault(proj, set()).add(path)
        return out

    def open_issues(self) -> list:
        """열린 검토 필요 [dict] (최신순) — evidence는 JSON 글자 그대로(필요할 때만 푼다)."""
        if self._issues is not None:
            return self._issues
        keys = ("issue_id", "code", "path", "project", "evidence", "detected_at", "snapshot_id", "message")
        self._issues = [dict(zip(keys, r)) for r in self.st.conn.execute(
            "SELECT id, code, path, project, evidence, detected_at, snapshot_id, message FROM issues "
            "WHERE resolved_at IS NULL ORDER BY id DESC")]
        for i in self._issues:
            i["proj"] = self.canon(i["project"])
        return self._issues

    def marks(self, ids) -> tuple[dict, dict]:
        ids = [i for i in ids if i is not None]
        return self.st.ack_marks(ids) if ids else ({}, {})

    def items_of(self, ids) -> dict:
        """변경 id → 보여 줄 항목(숨긴 항목 뺌) — 화면 목록과 같은 재료(State._summary_rows + visible_items)."""
        from watcher.summary import visible_items
        out: dict = {}
        if not ids:
            return out
        for r_ in self.st._summary_rows(list(ids)):
            out[r_["id"]] = visible_items(r_["items"], r_["dismissed"])
        return out

    def last_real(self, wanted: set, chunk: int = 4000) -> dict:
        """정규 프로젝트 → 마지막 진짜 변경 (id, kind, path, snap, detected_at). 최신부터 거슬러 찾고, 다 찾으면 멈춘다."""
        found: dict = {}
        if not wanted:
            return found
        last_id = None
        while len(found) < len(wanted):
            if last_id is None:
                rows = self.st.conn.execute(
                    "SELECT id, kind, path, snapshot_id, detected_at, project FROM changes ORDER BY id DESC LIMIT ?",
                    (chunk,)).fetchall()
            else:
                rows = self.st.conn.execute(
                    "SELECT id, kind, path, snapshot_id, detected_at, project FROM changes WHERE id < ? "
                    "ORDER BY id DESC LIMIT ?", (last_id, chunk)).fetchall()
            if not rows:
                break
            last_id = rows[-1][0]
            cand = [r for r in rows if self.canon(r[5]) in wanted and self.canon(r[5]) not in found
                    and not self.is_first(r[1], r[2], r[3])]
            if not cand:
                continue
            exempt, notes = self.marks([r[0] for r in cand])
            added_at = {(r[2], r[3]) for r in rows if r[1] == "added"}
            for cid, kind, path, snap, at, proj in cand:
                p = self.canon(proj)
                if p in found or exempt.get(cid) == "quiet":
                    continue
                note = notes.get(cid) or ""
                if kind == "removed" and "옮겨지며 내용도 바뀜" in note and \
                        (note.split("(으)로 옮겨지며", 1)[0].strip(), snap) in added_at:
                    continue
                found[p] = (cid, kind, path, snap, at)
        return found

    def revs(self, paths) -> dict:
        """경로 → (Rev, 도면번호) — 저장된 추출 기록의 표제란 칸만(json_extract). 기록 고르기는 State.load_extract와 같다."""
        from watcher.state import _TYPE_GROUP, extract_group
        snap = {p: self.files[p][0] for p in paths if p in self.files}
        want = {p: extract_group(p) for p in snap}
        keys = set(snap.values()) | {f"{s}:{want[p]}" for p, s in snap.items() if s and want[p]}
        keys.discard(None)
        rows: dict = {}
        ks = sorted(k for k in keys if k)
        try:
            for i in range(0, len(ks), 500):
                part = ks[i:i + 500]
                for k, dt, ek, rev, dwg in self.st.conn.execute(
                        "SELECT sha256, json_extract(doc_json, '$.doc_type'), json_extract(doc_json, '$.ext_kind'), "
                        "json_extract(doc_json, '$.fields.REV.value'), json_extract(doc_json, '$.fields.DWG_NO.value') "
                        f"FROM extracts WHERE sha256 IN ({','.join('?' * len(part))})", part):
                    rows[k] = (dt, ek, rev, dwg)
        except sqlite3.OperationalError:
            rows = None                       # JSON 함수가 없는 SQLite — 그 판 기록을 통째로 읽는다(드물다)
        out: dict = {}
        for p, sha in snap.items():
            if rows is None:
                d = self.st.load_extract(sha, p) or {}
                f = d.get("fields") or {}
                out[p] = (((f.get("REV") or {}).get("value")), ((f.get("DWG_NO") or {}).get("value")))
                continue
            r = rows.get(sha)
            if r is not None:
                g = r[1] or r[0]
                g = _TYPE_GROUP.get(g, g) if g else None
                if want[p] and g and g != want[p]:
                    r = rows.get(f"{sha}:{want[p]}")
            if r is None or r[0] is None:
                out[p] = (None, None)
                continue
            out[p] = (r[2], r[3])
        return out


def _pick_last(core: _Core, paths, look_back: int = LOOK_BACK) -> dict:
    """경로 → 그 문서의 최근 변경 {id, kind, path, at, day, real, note} — 첫 등록은 빼고, 거슬러 look_back개 안의 가장 최근 진짜 변경,
    없으면 가장 최근 변경('그 밖' — 다시 저장 등). 변경이 첫 등록뿐이면 없음."""
    paths = list(paths)
    per: dict = {}
    for i in range(0, len(paths), 400):
        part = paths[i:i + 400]
        for cid, kind, path, snap, at in core.st.conn.execute(
                "SELECT id, kind, path, snapshot_id, detected_at FROM changes "
                f"WHERE path IN ({','.join('?' * len(part))}) ORDER BY id DESC", part):
            lst = per.setdefault(path, [])
            if len(lst) < look_back and not core.is_first(kind, path, snap):
                lst.append((cid, kind, path, snap, at))
    ids = [r[0] for v in per.values() for r in v]
    exempt, notes = core.marks(ids)
    out: dict = {}
    for path, lst in per.items():
        if not lst:
            continue
        pick = next((r for r in lst if exempt.get(r[0]) != "quiet"), None)
        real = pick is not None
        pick = pick or lst[0]
        out[path] = {"id": pick[0], "kind": pick[1], "path": pick[2], "snapshot_id": pick[3], "at": pick[4],
                     "day": local_day(pick[4]), "real": real, "note": notes.get(pick[0], "")}
    return out


def change_text(kind: str, items, path: str = "", cap: int | None = None) -> str:
    """변경 하나의 짧은 글 — 'MCCB-101 SPEC 100AT → 125AT · Rev A → B'. 값은 항목(ChangeItem)의 old/new 그대로(summary.body_parts).
    바뀐 값이 없는 변경은 참고 문구(다시 저장만·옮겨짐…) 또는 '새 문서'·'삭제'. 사내망 등 HTML 밖에서 쓰는 글.
    cap: 앞 조각을 이만큼만(나머지는 '외 N곳') — 프로젝트 목록 '마지막 변경'처럼 좁은 칸 (사내망 2026-11-20)."""
    from watcher.summary import _note_short, body_parts
    items = [it for it in (items or []) if isinstance(it, dict)]
    parts, rest = body_parts(items)
    if parts and all(p.startswith(("저장 시각 ", "파일 크기 ")) for p in parts) and not rest:
        return "저장본 바뀜"                     # 내용을 비교하지 않는 문서 — 바뀐 사실만 (PILOT.md)
    if parts:
        if cap is not None and len(parts) > max(1, int(cap)):
            k = max(1, int(cap))
            rest += len(parts) - k
            parts = parts[:k]
        return " · ".join(parts) + (f" 외 {rest}곳" if rest else "")     # 감시 화면 줄과 같은 말 '외 N곳' (바뀐 곳 수)
    note = _note_short(items, path)
    if kind == "added":
        if note.startswith("되살림"):
            return note                         # 지웠다 같은 자리에 되살린 파일 — '새 문서'가 아니다 (Y1 P3b, 저장값 '추가'는 그대로)
        return "새 문서" + (f" — {note}" if note else "")
    if kind == "removed":
        return "삭제" + (f" — {note}" if note else "")
    return note or "내용 바뀜"


# ─────────────────────────── 공개 함수 ───────────────────────────

def summaries(db, *, canon=None, kind_of=None, keep=None, window=None, cfg=None, today=None,
              with_items: bool = True) -> dict:
    """프로젝트 목록 요약.

    돌려주는 것: {"projects": [프로젝트 dict…], "docs": 문서 수(귀속된 지금 파일), "week": 이번 주 바뀐 문서 수(합),
    "issues": 열린 확인 필요 수(전체 — 메뉴·/issues와 같다), "unassigned": 미분류 지금 파일 수, "window": (시작, 끝)}.
    프로젝트 dict: {project, folder, name, docs, kinds{종류: 수}, cols{'도면'|'BOM·발주'|'그 밖': 수}, week, issues,
    issue_codes[코드…], last{id, kind, path, at, day, items, batch}|None}. 미분류는 목록에 넣지 않는다(unassigned 수로).
    지금 문서·이번 주 변경·열린 확인 필요 중 하나라도 있는 프로젝트만 싣는다. 차례는 미분류 아님 → 임시·공용 아님 → 이름."""
    with _state(db) as st:
        core = _Core(st, canon, kind_of, keep, window, cfg, today)
        by_p: dict = {}
        for p, proj in core.proj_of.items():
            by_p.setdefault(proj, []).append(p)
        week = core.week_paths()
        iss = Counter(i["proj"] for i in core.open_issues())
        codes: dict = {}
        for i in core.open_issues():
            codes.setdefault(i["proj"], []).append(i["code"])
        names = (set(by_p) | set(week) | set(iss)) - {UNASSIGNED}
        last = core.last_real(names)
        items = core.items_of([v[0] for v in last.values()]) if with_items else {}
        # '새 문서 N개' — 마지막 진짜 변경이 추가이고 같은 검사·같은 프로젝트의 진짜 추가가 ADD_FOLD개 이상이면
        batch: dict = {}
        from watcher.summary import restored_adds
        for p, (cid, kind, path, snap, at) in last.items():
            if kind != "added":
                continue
            rows = [r for r in st.conn.execute(
                "SELECT id, kind, path, snapshot_id, project FROM changes WHERE snapshot_id = ? AND kind = 'added'", (snap,))
                if core.canon(r[4]) == p and not core.is_first(r[1], r[2], r[3])]
            ex, _n = core.marks([r[0] for r in rows])
            # 되살린 파일은 '새 문서 N개'에 넣지 않는다 — 최근 변경의 묶음과 같은 규칙(Z3a M2, summary.restored_adds 두 꼴)
            rs = restored_adds(st, [r[0] for r in rows], cfg) if rows else {}
            if cid in rs:
                continue
            n = sum(1 for r in rows if ex.get(r[0]) != "quiet" and r[0] not in rs)
            if n >= ADD_FOLD:
                batch[p] = n
        out = []
        for p in names:
            paths = by_p.get(p, [])
            kinds = Counter()
            cols = Counter()
            col_kinds: dict = {c: Counter() for c in KIND_COLS}     # 칸마다 종류별 수 — '도면 39 = 배선표 30 · 도면 9' (검토 W5)
            for x in paths:
                k = core.kind_of(x)
                kinds[k] += 1
                c_ = kind_col(k, x)
                cols[c_] += 1
                col_kinds[c_][k] += 1
            folder, nm = project_folder(paths, p) if paths else ("", "")
            lr = last.get(p)
            out.append({
                "project": p, "folder": folder, "name": nm, "docs": len(paths), "kinds": dict(kinds),
                "cols": {c: cols.get(c, 0) for c in KIND_COLS},
                "col_kinds": {c: col_kinds[c].most_common() for c in KIND_COLS}, "week": len(week.get(p, ())),
                "issues": iss.get(p, 0), "issue_codes": codes.get(p, []),
                "last": ({"id": lr[0], "kind": lr[1], "path": lr[2], "snapshot_id": lr[3], "at": lr[4],
                          "day": local_day(lr[4]), "items": items.get(lr[0], []), "batch": batch.get(p, 0)}
                         if lr else None),
            })
        out.sort(key=lambda d: (_quiet(d["project"]), d["project"]))
        return {"projects": out, "docs": sum(d["docs"] for d in out),
                "week": sum(d["week"] for d in out), "issues": len(core.open_issues()),
                "unassigned": len(by_p.get(UNASSIGNED, [])), "window": core.window}


def project_heads(db, names=None, *, canon=None, kind_of=None, keep=None, window=None, cfg=None, today=None) -> dict:
    """정규 프로젝트 → {docs, week, issues, last} — 프로젝트 정리(/projects) 표·변경 기록(/timeline) 머리가 첫 화면·문서함과 **같은 수·같은
    '마지막 변경'**을 쓰게(summaries와 같은 재료·같은 규칙: 문서 = 귀속된 지금 파일, week = 7일 창의 진짜 변경 문서, issues = 열린 검토 필요,
    last = 마지막 진짜 변경의 검사 시각 ISO|None — 이름만 바꾼·다시 저장만 한 변경은 치지 않는다). names: 이 이름들만(없으면 문서·7일 변경·
    확인 필요 중 하나라도 있는 모든 이름, 미분류 포함). 무엇도 쓰지 않는다 (검토 W 고침 M3 2026-11-21)."""
    with _state(db) as st:
        core = _Core(st, canon, kind_of, keep, window, cfg, today)
        docs = Counter(core.proj_of.values())
        week = core.week_paths()
        iss = Counter(i["proj"] for i in core.open_issues())
        want = set(names) if names is not None else (set(docs) | set(week) | set(iss))
        last = core.last_real(want)
        return {p: {"docs": docs.get(p, 0), "week": len(week.get(p, ())), "issues": iss.get(p, 0),
                    "last": last[p][4] if p in last else None} for p in want}


def _quiet(name: str) -> bool:
    """임시·공용·아카이브 성격의 프로젝트인가 — 검사(cli)의 규칙 하나를 쓴다. 목록 뒤로."""
    try:
        from watcher.cli import _QUIET_PROJECT
        return bool(_QUIET_PROJECT.search(name or ""))
    except Exception:      # noqa: BLE001
        return False


def project_docs(db, project: str, *, canon=None, kind_of=None, keep=None, window=None, cfg=None, today=None) -> dict:
    """한 프로젝트의 문서 목록.

    돌려주는 것: {"project", "folder", "name", "docs": [문서 dict…](폴더·이름 순), "kinds": [(종류, 수)…](많은 순),
    "week": 이번 주 바뀐 문서 수(요약과 같은 수 — 지운 파일 포함), "issues": [이 프로젝트의 열린 검토 필요 dict…],
    "last": 마지막 진짜 변경의 검사 시각(ISO)|None, "window": (시작, 끝)}.
    문서 dict: {path, name, folder(공통 폴더 아래 상대 경로), kind, rev, dwg_no, mtime, size, sha256,
    last{id, kind, at, day, real, note, items}|None(첫 등록 뒤 바뀐 적 없음), week(이번 주 진짜 변경), issues[{issue_id, code}…],
    tone('red'|'amber'|''), issued{copy, rev, path}|None}."""
    with _state(db) as st:
        core = _Core(st, canon, kind_of, keep, window, cfg, today)
        paths = sorted((p for p, pr in core.proj_of.items() if pr == project), key=lambda s: s.casefold())
        folder, nm = project_folder(paths, project) if paths else ("", "")
        week_all = core.week_paths().get(project, set())
        revs = core.revs(paths)
        lasts = _pick_last(core, paths)
        items = core.items_of([v["id"] for v in lasts.values()])
        for v in lasts.values():
            v["items"] = items.get(v["id"], [])
        iss = [i for i in core.open_issues() if i["proj"] == project]
        known = set(paths)
        per_doc: dict = {}
        from watcher.state import State
        for i in iss:
            hit = {i["path"]} | set(State._evidence_paths(i["evidence"], known))
            for p in hit & known:
                per_doc.setdefault(p, []).append({"issue_id": i["issue_id"], "code": i["code"]})
        issued = _issued_marks(st, paths, revs, project, cfg)
        docs = []
        for p in paths:
            sha, size, mt = core.files[p]
            rev, dwg = revs.get(p, (None, None))
            di = per_doc.get(p, [])
            docs.append({"path": p, "name": PurePosixPath(p).name, "folder": folder_label(p, folder),
                         "kind": core.kind_of(p), "rev": (str(rev).strip() or None) if rev is not None else None,
                         "dwg_no": dwg, "mtime": mt, "size": size, "sha256": sha,
                         "last": lasts.get(p), "week": p in week_all, "issues": di,
                         "tone": issue_tone(x["code"] for x in di), "issued": issued.get(p)})
        docs.sort(key=lambda d: (d["folder"].casefold(), d["name"].casefold()))
        kinds = Counter(d["kind"] for d in docs).most_common()
        lr = core.last_real({project}).get(project)
        for i in iss:
            try:
                i["evidence"] = json.loads(i["evidence"] or "[]")
            except (ValueError, TypeError):
                i["evidence"] = []
        return {"project": project, "folder": folder, "name": nm, "docs": docs, "kinds": kinds,
                "week": len(week_all), "issues": iss, "last": lr[4] if lr else None, "window": core.window}


def _issued_marks(st, paths, revs: dict, project: str, cfg) -> dict:
    """경로 → {copy: 출도본인가, rev: 출도본 Rev, path: 출도본 경로} — 출도 폴더 설정이 있을 때만. 원본은 같은 프로젝트의 가장
    나중 출도본(issued._pick_issued — 출도 후 변경 판정과 같은 짝)을 단다. '출도 후 변경'은 열린 검토 필요(POST_ISSUE_CHANGE)가 말한다."""
    out: dict = {}
    try:
        from watcher import issued as I
        if not I.issued_folders(cfg):
            return out
        copies = {p: (rev, key) for p, rev, key in st.conn.execute("SELECT path, rev, key FROM issued_copies")}
        latest = I._latest_issued(st)
        from watcher.scan import pair_key
        for p in paths:
            if I.in_issued_folder(p, cfg):
                c = copies.get(p)
                out[p] = {"copy": True, "rev": (c[0] if c else None) or revs.get(p, (None, None))[0], "path": p}
                continue
            dwg = revs.get(p, (None, None))[1]
            # issued.doc_key와 같은 열쇠 — 표제란 도면번호(접고 공백 뺌), 없으면 판 짝짓기의 이름 줄기
            key = ("".join(I._fold(dwg).split()) if dwg and str(dwg).strip()
                   else (pair_key(PurePosixPath(p).name) or None))
            e = I._pick_issued(latest, key, p, project) if key else None
            if e is not None:
                out[p] = {"copy": False, "rev": e[3], "path": e[1]}
    except Exception:      # noqa: BLE001 — 출도 표시 하나 때문에 문서함이 죽으면 안 된다
        return {}
    return out


def doc_history(db, path: str, *, canon=None, kind_of=None, keep=None, cfg=None) -> dict | None:
    """문서 하나의 이력 — 이름·위치를 바꾼 옛 경로까지(State.path_lineage). 기록이 없고 지금 파일도 아니면 None.

    돌려주는 것: {"path", "name", "present"(지금 감시 중인 파일인가), "project", "kind", "rev", "mtime", "size",
    "lineage": [지금 경로, 옛 경로…], "rows": [변경 dict…](최신순), "issues": [열린 검토 필요 dict…]}.
    변경 dict: {id, kind, path, snapshot_id, at, day, project, first(첫 등록), real, note, items, acks[(이름, 시각)…]}.
    옛 경로의 '삭제' 행(옮겨 간 쪽)은 빼고 새 경로의 '이름·위치만 바뀜' 한 줄로 본다."""
    path = str(path or "")
    if not path or len(path) > 2000:
        return None
    with _state(db) as st:
        core = _Core(st, canon, kind_of, keep, (date.today(), date.today()), cfg)
        present = path in core.files
        snap_has = present or st.conn.execute(
            "SELECT 1 FROM files WHERE snapshot_id = ? AND path = ?", (core.snap_id, path)).fetchone() is not None
        lineage = st.path_lineage(path)
        rows = []
        for idx, lp in enumerate(lineage):
            for cid, kind, cpath, snap, at, proj in st.conn.execute(
                    "SELECT id, kind, path, snapshot_id, detected_at, project FROM changes WHERE path = ? ORDER BY id DESC",
                    (lp,)):
                if idx > 0 and kind == "removed":
                    continue
                rows.append([cid, kind, cpath, snap, at, proj])
        if not rows and not snap_has:
            return None
        rows.sort(key=lambda r: r[0], reverse=True)
        ids = [r[0] for r in rows]
        exempt, notes = core.marks(ids)
        items = core.items_of(ids)
        acks: dict = {}
        for k in range(0, len(ids), 400):
            part = ids[k:k + 400]
            for cid, by, at in st.conn.execute(
                    f"SELECT change_id, by, at FROM acks WHERE change_id IN ({','.join('?' * len(part))}) ORDER BY id", part):
                acks.setdefault(cid, []).append((by, at))
        out_rows = []
        for cid, kind, cpath, snap, at, proj in rows:
            first = core.is_first(kind, cpath, snap)
            out_rows.append({"id": cid, "kind": kind, "path": cpath, "snapshot_id": snap, "at": at, "day": local_day(at),
                             "project": core.canon(proj), "first": first,
                             "real": (not first) and exempt.get(cid) != "quiet", "note": notes.get(cid, ""),
                             "items": items.get(cid, []), "acks": acks.get(cid, [])})
        proj = core.proj_of.get(path) or (out_rows[0]["project"] if out_rows else UNASSIGNED)
        sha, size, mt = core.files.get(path, (None, None, None))
        rev = core.revs([path]).get(path, (None, None))[0] if present else None
        from watcher.state import State
        iss = []
        for i in core.open_issues():
            if i["path"] == path or path in State._evidence_paths(i["evidence"], {path}):
                j = dict(i)
                try:
                    j["evidence"] = json.loads(i["evidence"] or "[]")
                except (ValueError, TypeError):
                    j["evidence"] = []
                iss.append(j)
        return {"path": path, "name": PurePosixPath(path).name, "present": present, "project": proj,
                "kind": core.kind_of(path), "rev": (str(rev).strip() or None) if rev is not None else None,
                "mtime": mt, "size": size, "lineage": lineage, "rows": out_rows, "issues": iss}
