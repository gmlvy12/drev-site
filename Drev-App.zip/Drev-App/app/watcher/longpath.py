# -*- coding: utf-8 -*-
"""Windows 긴 경로(260자 넘음) 도우미 — 이 한 곳에서만 확장 경로 접두(`\\\\?\\`·`\\\\?\\UNC\\`)를 붙이고 뗀다.

Windows 기본값(LongPathsEnabled=0)인 PC에서는 260자(MAX_PATH)를 넘는 경로를 열지 못한다 — 파일 목록에는 나오는데 stat·열기가
'없음(ENOENT)'으로 실패해, 나열 뒤 지워진 파일로 여겨 조용히 빠졌고 윗폴더 이름이 길어진 날에는 '삭제'로 보고됐다 (pv2 D-1,
2026-11-17). 확장 경로 접두를 붙이면 길이 제한 없이 읽힌다. 접두는 **필요할 때만**(길 때만) 붙여 260자 미만 경로는 예전과 똑같이 다루고,
경로 키·화면·메일에는 접두가 없는 꼴만 쓴다(plain)."""
from __future__ import annotations

import errno as _errno
import os
from pathlib import Path

LONG_PREFIX = "\\\\?\\"
UNC_PREFIX = "\\\\?\\UNC\\"
_DEVICE_PREFIX = "\\\\.\\"
# 폴더는 MAX_PATH-12(8.3 이름 자리, CreateDirectory 기준), 파일은 MAX_PATH-1. 폴더 목록(FindFirstFile 'dir\\*')도 이 길이에 걸리므로
# 낮은 쪽(248)부터 접두를 붙인다 — 그 아래는 손대지 않는다
LIMIT = 248
LONG_PATH_NOTE = ("경로가 너무 길어 읽지 못함 — 이전 기록을 그대로 둡니다 (폴더·파일 이름을 줄이거나 Windows 긴 경로 사용을 켜 주세요)")


def _abs(s: str) -> str:
    # 절대 경로는 normpath만 — abspath(GetFullPathName)는 이름 끝의 공백·점을 떼어 다른 파일을 가리키게 만든다
    return os.path.normpath(s) if os.path.isabs(s) else os.path.abspath(s)


def plain(p) -> str:
    """접두를 뗀 꼴(문자열) — 경로 키·화면·메일용."""
    s = os.fspath(p)
    if s.startswith(UNC_PREFIX):
        return "\\\\" + s[len(UNC_PREFIX):]
    if s.startswith(LONG_PREFIX):
        return s[len(LONG_PREFIX):]
    return s


def is_long(p) -> bool:
    """접두 없이는 Windows 기본 설정에서 못 열 수 있는 길이인가."""
    try:
        return len(_abs(plain(p))) >= LIMIT
    except (TypeError, ValueError):
        return False


def os_path(p):
    """운영체제에 넘길 경로 — 길면 확장 경로 접두를 붙이고, 아니면 그대로. str이면 str, Path면 Path로 돌려준다."""
    if os.name != "nt":
        return p
    s = os.fspath(p)
    if not s or s.startswith(LONG_PREFIX) or s.startswith(_DEVICE_PREFIX) or len(s) < LIMIT - 40 and os.path.isabs(s):
        return p                      # 빠른 길: 짧은 절대 경로는 계산 없이 그대로
    try:
        a = _abs(s)
    except (TypeError, ValueError):
        return p
    if len(a) < LIMIT:
        return p
    if a.startswith("\\\\"):
        out = UNC_PREFIX + a[2:]
    else:
        out = LONG_PREFIX + a
    return out if isinstance(p, str) else Path(out)


def too_long_error(e: OSError, p) -> bool:
    """'없음'·'이름 너무 김' 오류가 경로 길이 탓일 수 있나 — 긴 경로에서만 참."""
    if not is_long(p):
        return False
    return (getattr(e, "errno", None) in (_errno.ENOENT, _errno.ENAMETOOLONG)
            or getattr(e, "winerror", None) in (3, 206))
