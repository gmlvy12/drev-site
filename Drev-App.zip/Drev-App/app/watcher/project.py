# -*- coding: utf-8 -*-
"""프로젝트 귀속: 표제란 PROJECT > 파일명 > 폴더명 순 추정 + 별칭 사전.

부서마다 다른 프로젝트 이름("삼성3차", "2024-15")을 강제 통일하지 않고
aliases.yaml로 정규 번호로 '번역'한다 (DECISIONS 2026-08-20).
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath

import yaml

from watcher.extract.base import Document

# 프로젝트 번호 관례 패턴 (별칭 사전에 없어도 이 꼴이면 그 자체를 정규 번호로 본다)
# \b는 '_' 앞뒤에서 매칭되지 않아 파일명(P25-007_발주서)에서 놓친다 → lookaround 사용
PROJECT_NO_RE = re.compile(r"(?<![A-Z0-9])[A-Z]\d{2}-\d{3}(?!\d)")
# 폴더명 "제어반개조_한빛산업(26-033)"·"26-033_제어반개조"처럼 문자 접두 없는 번호 —
# 폴더명에서만, 낱말 경계로 (2026-09-03 검토 → 2026-09-04: 괄호 없이 앞에 붙인 폴더로
# 이름을 바꾸면 새 프로젝트가 생겨 도면과 BOM이 갈리던 것)
_PAREN_NO_RE = re.compile(r"(?<![A-Za-z0-9-])(\d{2}-\d{3})(?![A-Za-z0-9-])")
# 표제란에 자리만 채운 값 — 프로젝트가 아니다 (템플릿 도면의 "-"가 프로젝트 '-'를 만들던 것)
PLACEHOLDER_PROJECTS = {"", "-", "--", "N/A", "NA", "TEMPLATE", "없음", "미정", "TBD", "X", "XX"}

UNASSIGNED = "미분류"

# 회사 이름·부서·사람 이름이 표제란 PROJECT 칸에 들어 있는 일이 흔하다. 표제란이 1순위라
# 폴더가 옳아도 그 값이 이긴다 — 실제로 고객사명이 프로젝트가 되어 별도 브리핑이 생겼다
# (2026-09-09 귀속 검토 차단 2). 회사 형태를 나타내는 꼬리는 프로젝트 이름이 아니다.
_COMPANY_TAIL = ("(주)", "㈜", "주식회사", "유한회사", "CO.,LTD", "CO., LTD", "CO.LTD",
                 "LTD.", "INC.", "CORP.")


def looks_like_project(value: str) -> bool:
    """표제란에서 읽은 값을 프로젝트로 써도 되는가.

    거르는 것: 빈 값·자리채움, 회사 이름, 구두점만 있는 값(':' 같은 라벨 잔해),
    너무 긴 문장. 통과 기준이 아니라 **명백히 아닌 것만** 걷어낸다 — 현장 표기가
    제각각이라 좁게 잡으면 멀쩡한 프로젝트를 미분류로 떨어뜨린다."""
    v = (value or "").strip()
    if not v or v.upper() in PLACEHOLDER_PROJECTS:
        return False
    if len(v) > 60:
        return False
    if not any(ch.isalnum() for ch in v):        # ':' '-' 등 라벨 잔해
        return False
    # .replace는 읽기 전용 보호 장치(test_readonly)가 파일 이동 API로 보고 막는다 —
    # 글자 지우기는 split/join으로 한다
    up = "".join(v.upper().split())
    return not any("".join(tail.split()) in up for tail in _COMPANY_TAIL)


class ProjectResolver:
    def __init__(self, aliases: dict[str, list[str]] | None = None,
                 root_labels: tuple | list = (),
                 root_projects: dict | None = None):
        # canonical -> [alias...]. 역방향 조회용 사전을 만든다 (대소문자 무시)
        self.aliases = aliases or {}
        # 다중 감시 폴더의 라벨(경로 첫 조각) — 폴더 구조 귀속에서 건너뛴다
        self.root_labels = set(root_labels)
        # 감시 폴더 전체가 프로젝트 하나인 경우 {라벨: 프로젝트} (2026-09-02)
        self.root_projects: dict = dict(root_projects or {})
        self._lookup: dict[str, str] = {}
        for canonical, names in self.aliases.items():
            self._lookup[canonical.upper()] = canonical
            for n in names:
                self._lookup[str(n).upper()] = canonical

    @classmethod
    def load(cls, path) -> "ProjectResolver":
        try:
            with open(path, "rb") as f:
                data = yaml.safe_load(f) or {}
        except FileNotFoundError:
            data = {}
        return cls({str(k): list(v or []) for k, v in data.items()})

    def canonical(self, name: str) -> str | None:
        """정확히 일치하는 정규 번호/별칭 → 정규 번호. 패턴 일치면 그 자체."""
        hit = self._lookup.get(name.strip().upper())
        if hit:
            return hit
        m = PROJECT_NO_RE.search(name)
        return m.group() if m else None

    def _find_in(self, text: str, folder: bool = False) -> str | None:
        """문자열 안에서 정규 번호·별칭·패턴을 찾는다 (부분 문자열).
        괄호 안 번호("(26-033)")는 폴더명에서만 — 파일명의 "(01-120)"은 도면 번호일
        때가 많다 (2026-09-03 재검토)."""
        up = text.upper()
        for key, canonical in self._lookup.items():
            # 부분 문자열로 맞으면 '공용' 별칭 하나가 새 프로젝트의 '공용베이스도면.dxf'까지
            # 끌어왔다 (2026-09-09 귀속 검토 차단 3). 앞뒤가 글자·숫자면 다른 낱말로 본다
            i = up.find(key)
            while i >= 0:
                before = up[i - 1] if i else ""
                after = up[i + len(key)] if i + len(key) < len(up) else ""
                if not (before.isalnum() or after.isalnum()):
                    return canonical
                i = up.find(key, i + 1)
        m = PROJECT_NO_RE.search(text)
        if m:
            return m.group()
        if folder:
            m = _PAREN_NO_RE.search(text)
            return m.group(1) if m else None
        return None

    def root_project_for(self, label: str, root_name: str | None = None) -> str | None:
        """이 감시 폴더 전체가 어느 프로젝트인가. 지정이 있으면 그것, 없으면 폴더
        이름에 프로젝트 번호·별칭이 있을 때 그것(자동). 둘 다 아니면 None."""
        if label in self.root_projects:
            return self.root_projects[label] or None
        name = root_name or label
        return self.canonical(name) or self._find_in(name)

    def infer_single_roots(self, paths, root_names: dict, cfg: dict | None = None,
                           min_share: float = 0.6) -> dict:
        """감시 폴더 바로 아래 폴더들이 문서 종류 이름이면 그 감시 폴더를 프로젝트
        하나로 본다 (2026-09-02). 이미 지정·자동 판정된 라벨은 건드리지 않는다.
        돌려주는 값: 이번에 추정한 {라벨: 프로젝트}."""
        from watcher.doctype import looks_like_doctype_folder
        firsts: dict[str, set] = {}
        for pth in paths:
            parts = pth.split("/")
            if len(parts) >= 3 and parts[0] in self.root_labels:
                firsts.setdefault(parts[0], set()).add(parts[1])
        inferred = {}
        for label, subs in firsts.items():
            if label in self.root_projects or len(subs) < 2:
                continue
            if any(self._find_in(s) for s in subs):
                continue                      # 바로 아래에 프로젝트 번호·별칭 → 여러 프로젝트
            typed = sum(1 for s in subs if looks_like_doctype_folder(s, cfg))
            if typed / len(subs) >= min_share:
                name = root_names.get(label) or label
                inferred[label] = name
                self.root_projects[label] = name
        return inferred

    def attribute(self, rel_path: str, doc: Document | None) -> tuple[str, str]:
        """(프로젝트, 근거 출처). 출처: 감시 폴더=프로젝트 > 표제란 > 파일명 >
        폴더명(별칭) > 폴더 구조 > 미분류.

        감시 폴더 자체가 프로젝트 하나면 그 아래는 전부 그 프로젝트다 — 표제란·
        폴더명의 자잘한 표기 차이가 프로젝트를 여럿으로 갈라놓지 않게 (2026-09-02)."""
        head = rel_path.split("/", 1)[0]
        if head in self.root_labels:
            rp = self.root_project_for(head)
            if rp:
                return rp, "감시 폴더"
        if doc is not None and doc.project and looks_like_project(doc.project):
            val = doc.project.strip()
            return self.canonical(val) or val, f"표제란 '{val}'"
        p = PurePosixPath(rel_path)
        hit = self._find_in(p.name)
        if hit:
            return hit, "파일명"
        for folder in reversed(p.parent.parts):
            hit = self._find_in(folder, folder=True)
            if hit:
                return hit, "폴더명"
        # 폴더 구조 규칙: 감시 폴더 바로 아래 첫 폴더 = 프로젝트
        # (예: 지정폴더\세척기 2호기\세부PJT\도면\... → 프로젝트 "세척기 2호기")
        folders = list(p.parent.parts)
        if folders and folders[0] in self.root_labels:
            folders = folders[1:]
        if folders:
            return folders[0], "폴더 구조"
        return UNASSIGNED, "미분류"
