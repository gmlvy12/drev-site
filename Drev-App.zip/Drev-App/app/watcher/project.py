# -*- coding: utf-8 -*-
"""프로젝트 귀속: 표제란 PROJECT > 파일명 > 폴더명 순 추정 + 별칭 사전.

부서마다 다른 프로젝트 이름("삼성3차", "2024-15")을 강제 통일하지 않고
aliases.yaml로 정규 번호로 '번역'한다 (DECISIONS 2026-08-20).
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath

import yaml

from watcher.extract.base import Document

# 프로젝트 번호 관례 패턴 (별칭 사전에 없어도 이 꼴이면 그 자체를 정규 번호로 본다)
# \b는 '_' 앞뒤에서 매칭되지 않아 파일명(P25-007_발주서)에서 놓친다 → lookaround 사용
PROJECT_NO_RE = re.compile(r"(?<![A-Z0-9])[A-Z]\d{2}-\d{3}(?!\d)")
# 글자 둘·셋 접두 번호(HB25-101·KDS26-004)가 **맨 앞**에 오고 이름이 뒤따르는 값 — 문서 머리 '프로젝트: HB25-101 컨베이어 라인
# 증설'이 도면 표제란 'HB25-101'과 다른 프로젝트가 되어 메일이 6통 더 나가고 수신자가 갈렸다 (구매 평가 2차 P2). 글자 하나 접두
# (P24-031)는 위 꼴이 어디서든 찾는다 — 여러 글자 접두는 도면번호(EL01-001)와 헷갈릴 수 있어 맨 앞일 때만 번호로 본다
LEAD_NO_RE = re.compile(r"^\s*([A-Z]{2,3}\d{2}-\d{3,4})(?![\w-])")
# 폴더명 "제어반개조_한빛산업(26-033)"·"26-033_제어반개조"처럼 문자 접두 없는 번호 —
# 폴더명에서만, 낱말 경계로 (2026-09-03 검토 → 2026-09-04: 괄호 없이 앞에 붙인 폴더로
# 이름을 바꾸면 새 프로젝트가 생겨 도면과 BOM이 갈리던 것)
_PAREN_NO_RE = re.compile(r"(?<![A-Za-z0-9-])(\d{2}-\d{3})(?![A-Za-z0-9-])")
# 표제란에 자리만 채운 값 — 프로젝트가 아니다 (템플릿 도면의 "-"가 프로젝트 '-'를 만들던 것)
PLACEHOLDER_PROJECTS = {"", "-", "--", "N/A", "NA", "TEMPLATE", "없음", "미정", "TBD", "X", "XX"}

UNASSIGNED = "미분류"

# 회사 이름·부서·사람 이름이 표제란 PROJECT 칸에 들어 있는 일이 흔하다. 표제란이 1순위라
# 폴더가 옳아도 그 값이 이긴다 — 실제로 고객사명이 프로젝트가 되어 별도 브리핑이 생겼다
# (2026-09-09 귀속 검토 차단 2). 회사 형태를 나타내는 꼬리는 프로젝트 이름이 아니다.
_COMPANY_TAIL = ("(주)", "㈜", "주식회사", "유한회사", "CO.,LTD", "CO., LTD", "CO.LTD",
                 "LTD.", "INC.", "CORP.")


def looks_like_project(value: str) -> bool:
    """표제란에서 읽은 값을 프로젝트로 써도 되는가.

    거르는 것: 빈 값·자리채움, 회사 이름, 구두점만 있는 값(':' 같은 라벨 잔해),
    너무 긴 문장. 통과 기준이 아니라 **명백히 아닌 것만** 걷어낸다 — 현장 표기가
    제각각이라 좁게 잡으면 멀쩡한 프로젝트를 미분류로 떨어뜨린다."""
    v = (value or "").strip()
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in v):   # 제어문자(줄바꿈 등) — 메일 제목을 깼다 (검토43 E 낮음 5)
        return False
    if not v or v.upper() in PLACEHOLDER_PROJECTS:
        return False
    if len(v) > 60:
        return False
    if not any(ch.isalnum() for ch in v):        # ':' '-' 등 라벨 잔해
        return False
    # .replace는 읽기 전용 보호 장치(test_readonly)가 파일 이동 API로 보고 막는다 —
    # 글자 지우기는 split/join으로 한다
    up = "".join(v.upper().split())
    return not any("".join(tail.split()) in up for tail in _COMPANY_TAIL)


# 연도·수주 묶음 폴더 — "첫 폴더 = 프로젝트" 규칙이 이런 폴더를 프로젝트로 삼으면 그 아래
# 모든 프로젝트의 표제란 없는 문서(BOM·발주서·사양서)가 '2026 수주' 한 덩이가 되고,
# 도면-BOM 검사는 경고 없이 빠진다 (검토22 실용 D1). 이름 전체가 연도(+수주·프로젝트)뿐일 때만.
_GROUPING_FOLDER = re.compile(
    r"^((19|20)\d{2}|\d{2}년)[\s_\-]*(년|년도)?[\s_\-]*(수주|프로젝트|PROJECTS?|과제|사업)?$",
    re.IGNORECASE)

# 폴더 다수결 전파 기준: 그 폴더 아래 표제란 프로젝트의 60% 이상이 하나로 모이면 그 값
FOLDER_MIN_SHARE = 0.6


class ProjectResolver:
    def __init__(self, aliases: dict[str, list[str]] | None = None,
                 root_labels: tuple | list = (),
                 root_projects: dict | None = None):
        # canonical -> [alias...]. 역방향 조회용 사전을 만든다 (대소문자 무시)
        self.aliases = aliases or {}
        # 다중 감시 폴더의 라벨(경로 첫 조각) — 폴더 구조 귀속에서 건너뛴다
        self.root_labels = set(root_labels)
        # 감시 폴더 전체가 프로젝트 하나인 경우 {라벨: 프로젝트} (2026-09-02)
        self.root_projects: dict = dict(root_projects or {})
        # 폴더 → {프로젝트: 그 폴더 아래 표제란에서 읽은 문서 수}. learn()으로 채우고,
        # 표제란·파일명·폴더명이 없는 문서가 같은 폴더의 도면을 따라가게 한다 (검토22 D1)
        self.folder_votes: dict[str, dict[str, int]] = {}
        self._lookup: dict[str, str] = {}
        for canonical, names in self.aliases.items():
            self._lookup[canonical.upper()] = canonical
            for n in names:
                self._lookup[str(n).upper()] = canonical

    @classmethod
    def load(cls, path) -> "ProjectResolver":
        try:
            with open(path, "rb") as f:
                raw = f.read()
        except FileNotFoundError:
            return cls({})
        # 메모장 'ANSI'(cp949)로 저장하면 읽기 실패였다 — config.yaml처럼 한 번 더 (검토59 F3 J5)
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp949")
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError("별칭 사전은 '정규 번호: [별칭, …]' 꼴이어야 합니다")
        # 값이 목록이 아니라 글자 하나('P26-050: 삼성3라인')면 글자 단위로 쪼개져 별칭이 안 먹었다 (검토59 F3 J3)
        # 숫자 값('P26-050: 123')은 TypeError로 사전 전체를 버렸다 — 글자로 받는다 (검토63 B-S6)
        return cls({str(k): ([str(v)] if isinstance(v, (str, int, float)) else [str(x) for x in (v or [])])
                    for k, v in data.items()})

    def canonical(self, name: str) -> str | None:
        """정확히 일치하는 정규 번호/별칭 → 정규 번호. 패턴 일치면 그 자체."""
        hit = self._lookup.get(name.strip().upper())
        if hit:
            return hit
        m = PROJECT_NO_RE.search(name)
        if m:
            return m.group()
        m = LEAD_NO_RE.match(name)
        return m.group(1) if m else None

    def _find_in(self, text: str, folder: bool = False) -> str | None:
        """문자열 안에서 정규 번호·별칭·패턴을 찾는다 (부분 문자열).
        괄호 안 번호("(26-033)")는 폴더명에서만 — 파일명의 "(01-120)"은 도면 번호일
        때가 많다 (2026-09-03 재검토)."""
        up = text.upper()
        for key, canonical in self._lookup.items():
            # 부분 문자열로 맞으면 '공용' 별칭 하나가 새 프로젝트의 '공용베이스도면.dxf'까지
            # 끌어왔다 (2026-09-09 귀속 검토 차단 3). 앞뒤가 글자·숫자면 다른 낱말로 본다
            i = up.find(key)
            while i >= 0:
                before = up[i - 1] if i else ""
                after = up[i + len(key)] if i + len(key) < len(up) else ""
                if not (before.isalnum() or after.isalnum()):
                    return canonical
                i = up.find(key, i + 1)
        m = PROJECT_NO_RE.search(text)
        if m:
            return m.group()
        if folder:
            m = _PAREN_NO_RE.search(text)
            return m.group(1) if m else None
        return None

    def root_project_for(self, label: str, root_name: str | None = None) -> str | None:
        """이 감시 폴더 전체가 어느 프로젝트인가. 지정이 있으면 그것, 없으면 폴더
        이름에 프로젝트 번호·별칭이 있을 때 그것(자동). 둘 다 아니면 None."""
        if label in self.root_projects:
            return self.root_projects[label] or None
        name = root_name or label
        return self.canonical(name) or self._find_in(name)

    def infer_single_roots(self, paths, root_names: dict, cfg: dict | None = None,
                           min_share: float = 0.6) -> dict:
        """감시 폴더 바로 아래 폴더들이 문서 종류 이름이면 그 감시 폴더를 프로젝트
        하나로 본다 (2026-09-02). 이미 지정·자동 판정된 라벨은 건드리지 않는다.
        돌려주는 값: 이번에 추정한 {라벨: 프로젝트}."""
        from watcher.doctype import looks_like_doctype_folder
        firsts: dict[str, set] = {}
        for pth in paths:
            parts = pth.split("/")
            if len(parts) >= 3 and parts[0] in self.root_labels:
                firsts.setdefault(parts[0], set()).add(parts[1])
        inferred = {}
        for label, subs in firsts.items():
            if label in self.root_projects or len(subs) < 2:
                continue
            if any(self._find_in(s) for s in subs):
                continue                      # 바로 아래에 프로젝트 번호·별칭 → 여러 프로젝트
            typed = sum(1 for s in subs if looks_like_doctype_folder(s, cfg))
            if typed / len(subs) >= min_share:
                name = root_names.get(label) or label
                inferred[label] = name
                self.root_projects[label] = name
        return inferred

    def learn(self, rel_path: str, doc: Document | None) -> None:
        """표제란 프로젝트가 있는 문서로 폴더의 다수 프로젝트를 배운다.

        `2026 수주/삼성 3라인/도면/E-101.dxf`(표제란 S3-CONV)를 배우면 같은 폴더의
        `…/삼성 3라인/BOM/BOM.xlsx`(표제란 없음)가 S3-CONV로 귀속된다. 감시 폴더 라벨
        자체에는 표를 주지 않는다 — 한 감시 폴더의 다수 프로젝트가 소수 프로젝트의 BOM을
        삼키지 않게 (검토22 실용 D1)."""
        if doc is None or not doc.project or not looks_like_project(doc.project):
            return
        val = doc.project.strip()
        proj = self.canonical(val) or val
        parts = list(PurePosixPath(rel_path).parent.parts)
        floor = 2 if parts and parts[0] in self.root_labels else 1
        for i in range(len(parts), floor - 1, -1):
            key = "/".join(parts[:i])
            votes = self.folder_votes.setdefault(key, {})
            votes[proj] = votes.get(proj, 0) + 1

    def _folder_consensus(self, parent_parts) -> str | None:
        """문서 종류 폴더(도면·BOM·구매…)를 지나 처음 만나는 '프로젝트 폴더'의 다수결.

        그 위로는 올라가지 않는다 — `서버/삼성전자/3라인/도면`의 표가 `서버/삼성전자`까지
        올라가 `4라인/BOM`(도면은 DWG뿐)을 3라인 프로젝트로 삼키고 거짓 도면-BOM 불일치를
        냈다 (검토22 재검증 D1 차단). 표가 없는 프로젝트 폴더는 폴더 구조 규칙으로 돌아간다."""
        if not self.folder_votes:
            return None
        from watcher.doctype import looks_like_doctype_folder
        parts = list(parent_parts)
        floor = 2 if parts and parts[0] in self.root_labels else 1
        for i in range(len(parts), floor - 1, -1):
            name = parts[i - 1].strip()
            if _GROUPING_FOLDER.match(name):
                return None          # 연도·수주 묶음 폴더는 여러 프로젝트의 집
            votes = self.folder_votes.get("/".join(parts[:i]))
            if votes:
                total = sum(votes.values())
                best, n = max(votes.items(), key=lambda kv: kv[1])
                return best if total and n / total >= FOLDER_MIN_SHARE else None
            if not looks_like_doctype_folder(name):
                return None          # 종류 폴더가 아닌 첫 폴더 = 프로젝트 폴더. 표가 없으면 끝
        return None

    def attribute(self, rel_path: str, doc: Document | None) -> tuple[str, str]:
        """(프로젝트, 근거 출처). 출처: 감시 폴더=프로젝트 > 표제란 > 파일명 >
        폴더명(별칭) > 폴더 안 도면 표제란(다수결) > 폴더 구조 > 미분류.

        감시 폴더 자체가 프로젝트 하나면 그 아래는 전부 그 프로젝트다 — 표제란·
        폴더명의 자잘한 표기 차이가 프로젝트를 여럿으로 갈라놓지 않게 (2026-09-02)."""
        head = rel_path.split("/", 1)[0]
        if head in self.root_labels:
            rp = self.root_project_for(head)
            if rp:
                return rp, "감시 폴더"
        if doc is not None and doc.project and looks_like_project(doc.project):
            val = doc.project.strip()
            return self.canonical(val) or val, f"표제란 '{val}'"
        p = PurePosixPath(rel_path)
        hit = self._find_in(p.name)
        if hit:
            return hit, "파일명"
        for folder in reversed(p.parent.parts):
            hit = self._find_in(folder, folder=True)
            if hit:
                # 폴더 이름의 번호와 그 폴더 도면들의 표제란 다수결이 다르면 표제란을 따른다 — 프로젝트 폴더 번호만 바꾸면
                # (P66-103 → P66-153) 도면은 표제란대로 103, BOM·사양서는 폴더대로 153으로 갈려 메일이 둘이 되고
                # 도면-BOM 불일치를 놓쳤다 (검토66 B1)
                cons = self._folder_consensus(p.parent.parts)
                if cons and cons != hit:
                    return cons, f"폴더 안 도면 표제란 (폴더 이름 '{folder}'와 다름)"
                return hit, "폴더명"
        # 같은 폴더의 도면들이 표제란으로 한 프로젝트에 모이면 표제란 없는 문서도 그것을
        # 따른다 — '2026 수주/삼성 3라인/BOM'이 '2026 수주'로 뭉치던 것 (검토22 실용 D1)
        hit = self._folder_consensus(p.parent.parts)
        if hit:
            return hit, "폴더 안 도면 표제란"
        # 폴더 구조 규칙: 감시 폴더 바로 아래 첫 폴더 = 프로젝트
        # (예: 지정폴더\세척기 2호기\세부PJT\도면\... → 프로젝트 "세척기 2호기")
        folders = list(p.parent.parts)
        if folders and folders[0] in self.root_labels:
            folders = folders[1:]
        # '2026 수주'처럼 연도·수주 묶음 이름뿐인 첫 폴더는 프로젝트가 아니다 — 그 아래 폴더로
        while len(folders) > 1 and _GROUPING_FOLDER.match(folders[0].strip()):
            folders = folders[1:]
        if folders:
            return folders[0], "폴더 구조"
        return UNASSIGNED, "미분류"
