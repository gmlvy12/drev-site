# -*- coding: utf-8 -*-
"""프로젝트 귀속: 표제란 PROJECT > 파일명 > 폴더명 순 추정 + 별칭 사전.

부서마다 다른 프로젝트 이름("삼성3차", "2024-15")을 강제 통일하지 않고
aliases.yaml로 정규 번호로 '번역'한다 (DECISIONS 2026-08-20).
"""

from __future__ import annotations

import re
import sys
import unicodedata
from pathlib import PurePosixPath

import yaml

from watcher.extract.base import Document

# 프로젝트 번호 관례 패턴 (별칭 사전에 없어도 이 꼴이면 그 자체를 정규 번호로 본다)
# \b는 '_' 앞뒤에서 매칭되지 않아 파일명(P25-007_발주서)에서 놓친다 → lookaround 사용
PROJECT_NO_RE = re.compile(r"(?<![A-Z0-9])[A-Z]\d{2}-\d{3}(?!\d)")
# 글자 둘·셋 접두 번호(HB25-101·KDS26-004)가 **맨 앞**에 오고 이름이 뒤따르는 값 — 문서 머리 '프로젝트: HB25-101 컨베이어 라인
# 증설'이 도면 표제란 'HB25-101'과 다른 프로젝트가 되어 메일이 6통 더 나가고 수신자가 갈렸다 (구매 평가 2차 P2). 글자 하나 접두
# (P24-031)는 위 꼴이 어디서든 찾는다 — 여러 글자 접두는 도면번호(EL01-001)와 헷갈릴 수 있어 맨 앞일 때만 번호로 본다
LEAD_NO_RE = re.compile(r"^\s*([A-Z]{2,3}\d{2}-\d{3,4})(?![\w-])")
# 폴더명 "제어반개조_한빛산업(26-033)"·"26-033_제어반개조"처럼 문자 접두 없는 번호 —
# 폴더명에서만, 낱말 경계로 (2026-09-03 검토 → 2026-09-04: 괄호 없이 앞에 붙인 폴더로
# 이름을 바꾸면 새 프로젝트가 생겨 도면과 BOM이 갈리던 것)
# 뒤에 한글이 붙으면 번호가 아니다 — '12-500톤 프레스' 폴더가 프로젝트 '12-500'이 되어 메일이 나갔다 (검토20 r13 7)
_PAREN_NO_RE = re.compile(r"(?<![A-Za-z0-9-])(\d{2}-\d{3})(?![A-Za-z0-9가-힣-])")
# 표제란에서 배운 번호 꼴 값(PJT003·2024-15) — 파일명·폴더명에서도 번호로 본다 (검토20 r13 6). 글자·숫자·대시만, 숫자 든 4자 이상
_LEARNABLE_NO = re.compile(r"^(?=.*\d)(?=.*[A-Z-])[A-Z0-9][A-Z0-9-]{2,18}[A-Z0-9]$")
# 표기 변종 접기 — 보이지 않는 글자(제로폭·BOM·소프트하이픈)를 지우고 NFKC(전각 'Ｐ２５'·NFD 자모·호환 글자)로 푼 뒤 대시 변종
# (－ – — − ‐)을 '-' 하나로. 'P25－011'·'Ｐ２５-０１２'·'P25—017'이 번호 꼴에 안 맞아 원문 그대로 별도 프로젝트가 되고, 소문자
# 'p25-007 제어반' 폴더는 같은 폴더 BOM('P25-007_BOM')과 갈려 도면-BOM 대조가 꺼지고 메일이 두 통 나갔다 (재검토 2026-10-28
# R9-3·R6-10). 번호·태그·사양의 **비교**에만 쓰고 화면·근거에는 원문을 싣는다. 일관성 검사(consistency._fold)도 이것을 쓴다
_FOLD_DROP = "\u200b\u200c\u200d\u2060\ufeff\u00ad"
_FOLD_DASH = "\u2010\u2011\u2012\u2013\u2014\u2015\u2212"
_FOLD_TABLE = {**dict.fromkeys(map(ord, _FOLD_DROP), None), **{ord(c): "-" for c in _FOLD_DASH}}


def fold_text(s) -> str:
    """비교용 한 꼴 — 제로폭 제거 + NFKC + 대시 통일. ASCII는 그대로(빠른 길)."""
    s = str(s or "")
    if s.isascii():
        return s
    return unicodedata.normalize("NFKC", s.translate(_FOLD_TABLE)).translate(_FOLD_TABLE)


# 표제란에 자리만 채운 값 — 프로젝트가 아니다 (템플릿 도면의 "-"가 프로젝트 '-'를 만들던 것)
PLACEHOLDER_PROJECTS = {"", "-", "--", "N/A", "NA", "TEMPLATE", "없음", "미정", "TBD", "X", "XX"}

UNASSIGNED = "미분류"

# 회사 이름·부서·사람 이름이 표제란 PROJECT 칸에 들어 있는 일이 흔하다. 표제란이 1순위라
# 폴더가 옳아도 그 값이 이긴다 — 실제로 고객사명이 프로젝트가 되어 별도 브리핑이 생겼다
# (2026-09-09 귀속 검토 차단 2). 회사 형태를 나타내는 꼬리는 프로젝트 이름이 아니다.
_COMPANY_TAIL = ("(주)", "㈜", "주식회사", "유한회사", "CO.,LTD", "CO., LTD", "CO.LTD",
                 "LTD.", "INC.", "CORP.")


def looks_like_project(value: str) -> bool:
    """표제란에서 읽은 값을 프로젝트로 써도 되는가.

    거르는 것: 빈 값·자리채움, 회사 이름, 구두점만 있는 값(':' 같은 라벨 잔해),
    너무 긴 문장. 통과 기준이 아니라 **명백히 아닌 것만** 걷어낸다 — 현장 표기가
    제각각이라 좁게 잡으면 멀쩡한 프로젝트를 미분류로 떨어뜨린다."""
    v = (value or "").strip()
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in v):   # 제어문자(줄바꿈 등) — 메일 제목을 깼다 (검토43 E 낮음 5)
        return False
    if not v or v.upper() in PLACEHOLDER_PROJECTS:
        return False
    if len(v) > 60:
        return False
    if not any(ch.isalnum() for ch in v):        # ':' '-' 등 라벨 잔해
        return False
    # .replace는 읽기 전용 보호 장치(test_readonly)가 파일 이동 API로 보고 막는다 —
    # 글자 지우기는 split/join으로 한다
    up = "".join(v.upper().split())
    return not any("".join(tail.split()) in up for tail in _COMPANY_TAIL)


# 연도·수주 묶음 폴더 — "첫 폴더 = 프로젝트" 규칙이 이런 폴더를 프로젝트로 삼으면 그 아래
# 모든 프로젝트의 표제란 없는 문서(BOM·발주서·사양서)가 '2026 수주' 한 덩이가 되고,
# 도면-BOM 검사는 경고 없이 빠진다 (검토22 실용 D1). 이름 전체가 연도(+수주·프로젝트)뿐일 때만.
_GROUPING_FOLDER = re.compile(
    r"^((19|20)\d{2}|\d{2}년)[\s_\-]*(년|년도)?[\s_\-]*(수주|프로젝트|PROJECTS?|과제|사업)?$",
    re.IGNORECASE)

# 폴더 다수결 전파 기준: 그 폴더 아래 표제란 프로젝트의 60% 이상이 하나로 모이면 그 값
FOLDER_MIN_SHARE = 0.6

# 프로젝트가 아니라 보관·공용·임시 성격의 폴더 이름 — 메일 초안 대상에서 빼고(cli), 폴더 다수결의 표를 주지도 받지도
# 않는다. 이름 규칙은 여기 한 곳 (cli._QUIET_PROJECT·web이 가져다 쓴다)
# 앞에 정렬용 밑줄·번호('_보관'·'00_보관'·'Z_'는 아님)가 붙어도 — 종료 프로젝트를 '_보관/'으로 옮기는 흔한 정리가 조용한 폴더로
# 읽히지 않아 그 열린 검토 필요가 1년 내내 남았다 (재검토 2026-10-28 R2-1)
QUIET_NAME_RE = re.compile(r"^(?:\d{1,4}[\s_.\-]+|[\s_\-.~#@]+)?(임시|temp|tmp|공용|공통|양식|template|아카이브|archive|백업|backup|"
                           r"old|구버전|보관|참고자료|참고|scratch|미분류)(?![A-Za-z0-9가-힣])"
                           r"|(아카이브|archive|백업|backup)$", re.IGNORECASE)


# 프로젝트 **이름** 판정은 이름 전체가 그 낱말(+번호·구분자)일 때만 — 폴더 낱말 규칙을 그대로 쓰니 'Old Town 공사'·'참고 - P26-001'
# 프로젝트는 메일이 영영 없었다 (검토20 r13 9). 폴더 다수결·조용한 폴더 판정(is_quiet_folder)은 그대로
QUIET_PROJECT_RE = re.compile(r"^(?:\d{1,4}[\s_.\-]+|[\s_\-.~#@]+)?(임시|temp|tmp|공용|공통|양식|template|아카이브|archive|백업|"
                              r"backup|old|구버전|보관|참고자료|참고|scratch|미분류)[\s_\-.()\d년월]*$"
                              r"|(아카이브|archive|백업|backup)$", re.IGNORECASE)


def _nfc(s: str) -> str:
    """귀속값은 NFC로 — 맥에서 만든 NFD 폴더명 '한빛3차'가 같은 이름의 NFC 폴더와 다른 프로젝트가 되어 브리핑·메일이 둘씩
    나갔다 (검토20 r13 4). ASCII는 그대로(빠른 길)."""
    s = str(s or "")
    return s if s.isascii() else unicodedata.normalize("NFC", s)


def is_quiet_folder(name: str) -> bool:
    """임시·공용·백업·old 류 폴더 이름인가."""
    return bool(QUIET_NAME_RE.search((name or "").strip()))


def in_quiet_folder(rel_path: str, root_labels=()) -> bool:
    """경로의 폴더 조각(감시 폴더 라벨 제외) 가운데 임시·공용·백업·old 류가 있는가.
    그런 폴더의 도면 사본은 남의 표제란을 들고 있다 — '서버/임시/test.dxf'(P26-031 도면 사본)가 폴더 다수결로 같은 폴더의
    계산.xlsx·BOM 복사본(실은 P26-032)까지 P26-031 메일에 싣고, 도면 간 불일치 근거에 '다른 값 도면'으로 늘 남았다
    (재검토 2026-10-26 D1)."""
    parts = list(PurePosixPath(rel_path).parent.parts)
    if parts and parts[0] in set(root_labels):
        parts = parts[1:]
    return any(is_quiet_folder(x) for x in parts)


class ProjectResolver:
    def __init__(self, aliases: dict[str, list[str]] | None = None,
                 root_labels: tuple | list = (),
                 root_projects: dict | None = None):
        # canonical -> [alias...]. 역방향 조회용 사전을 만든다 (대소문자 무시)
        self.aliases = aliases or {}
        # 다중 감시 폴더의 라벨(경로 첫 조각) — 폴더 구조 귀속에서 건너뛴다
        self.root_labels = set(root_labels)
        # 감시 폴더 전체가 프로젝트 하나인 경우 {라벨: 프로젝트} (2026-09-02)
        self.root_projects: dict = dict(root_projects or {})
        # 폴더 → {프로젝트: 그 폴더 아래 표제란에서 읽은 문서 수}. learn()으로 채우고,
        # 표제란·파일명·폴더명이 없는 문서가 같은 폴더의 도면을 따라가게 한다 (검토22 D1)
        self.folder_votes: dict[str, dict[str, int]] = {}
        self._lookup: dict[str, str] = {}
        # 빈 별칭·한 글자 별칭('A')은 버린다 — 낱말 경계 검사를 통과해 'PANEL A.pdf'·'(참고) 도면'까지 그 프로젝트로 끌어왔다
        # (재검토 2026-10-28 S3). 버린 것은 load()가 알린다
        self.ignored_aliases: list[str] = []
        # 사전의 의미 오류(한 별칭이 두 번호에·정규 번호를 다른 번호의 별칭으로·순환) — 뒤 줄이 조용히 이겼다 (검토20 r13 5).
        # 동작은 그대로(뒤가 이김) 두고 load()가 알린다
        self.alias_conflicts: list[str] = []
        self.load_warnings: list[str] = []
        self.prev_projects: dict = {}      # 경로 → 지난 귀속 (폴더 다수결이 갈렸을 때 유지, 검토20 r13 3)
        self._learned_cache = (None, ())
        canon_keys = {fold_text(c).strip().upper(): c for c in self.aliases}
        owner: dict = {}
        for canonical, names in self.aliases.items():
            for n in [canonical, *names]:
                key = fold_text(n).strip().upper()
                if len(key) < 2:
                    if n != canonical:
                        self.ignored_aliases.append(str(n))
                    continue
                if n != canonical:
                    if key in canon_keys and canon_keys[key] != canonical:
                        self.alias_conflicts.append(f"'{n}'은(는) 정규 번호 '{canon_keys[key]}'인데 '{canonical}'의 별칭으로도 적혀 있습니다")
                    elif key in owner and owner[key] != canonical:
                        self.alias_conflicts.append(f"별칭 '{n}'이(가) '{owner[key]}'와 '{canonical}' 두 번호에 적혀 있습니다 — 뒤 줄('{canonical}')을 씁니다")
                    owner.setdefault(key, canonical)
                self._lookup[key] = canonical

    @classmethod
    def load(cls, path) -> "ProjectResolver":
        try:
            with open(path, "rb") as f:
                raw = f.read()
        except FileNotFoundError:
            res = cls({})
            res.load_warnings = []
            return res
        # 메모장 'ANSI'(cp949)로 저장하면 읽기 실패였다 — config.yaml처럼 한 번 더 (검토59 F3 J5)
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp949")
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError("별칭 사전은 '정규 번호: [별칭, …]' 꼴이어야 합니다")
        # 값이 목록이 아니라 글자 하나('P26-050: 삼성3라인')면 글자 단위로 쪼개져 별칭이 안 먹었다 (검토59 F3 J3)
        # 숫자 값('P26-050: 123')은 TypeError로 사전 전체를 버렸다 — 글자로 받는다 (검토63 B-S6)
        res = cls({str(k): ([str(v)] if isinstance(v, (str, int, float)) else [str(x) for x in (v or [])])
                   for k, v in data.items()})
        warns: list[str] = []
        # 같은 정규 번호 줄이 두 번이면 PyYAML은 뒤 줄만 남긴다 — 앞 줄의 별칭('한빛3차')이 조용히 사라졌다 (검토20 r13 5)
        try:
            node = yaml.compose(text)
            if isinstance(node, yaml.MappingNode):
                seen: set = set()
                for kn, _vn in node.value:
                    k = str(getattr(kn, "value", ""))
                    if k in seen:
                        warns.append(f"정규 번호 '{k}' 줄이 두 번 있습니다 — 뒤 줄만 쓰고 앞 줄의 별칭은 버려집니다")
                    seen.add(k)
        except yaml.YAMLError:
            pass
        warns += res.alias_conflicts
        if res.ignored_aliases:
            warns.append("빈 별칭·한 글자 별칭은 엉뚱한 파일을 끌어와 쓰지 않습니다: "
                         + ", ".join(repr(a) for a in res.ignored_aliases))
        res.load_warnings = warns
        for w in warns:
            print(f"경고: 별칭 사전({path}): {w}", file=sys.stderr)
        return res

    def canonical(self, name: str) -> str | None:
        """정확히 일치하는 정규 번호/별칭 → 정규 번호. 패턴 일치면 그 자체."""
        up = fold_text(name).strip().upper()          # 소문자·전각·대시 변종도 같은 번호 (재검토 2026-10-28 R9-3·R6-10)
        hit = self._lookup.get(up)
        if hit:
            return hit
        m = PROJECT_NO_RE.search(up)
        if m:
            return m.group()
        m = LEAD_NO_RE.match(up)
        return m.group(1) if m else None

    def _find_in(self, text: str, folder: bool = False) -> str | None:
        """문자열 안에서 정규 번호·별칭·패턴을 찾는다 (부분 문자열).
        괄호 안 번호("(26-033)")는 폴더명에서만 — 파일명의 "(01-120)"은 도면 번호일
        때가 많다 (2026-09-03 재검토)."""
        up = fold_text(text).upper()
        for key, canonical in self._lookup.items():
            # 부분 문자열로 맞으면 '공용' 별칭 하나가 새 프로젝트의 '공용베이스도면.dxf'까지
            # 끌어왔다 (2026-09-09 귀속 검토 차단 3). 앞뒤가 글자·숫자면 다른 낱말로 본다
            i = up.find(key)
            while i >= 0:
                before = up[i - 1] if i else ""
                after = up[i + len(key)] if i + len(key) < len(up) else ""
                if not (before.isalnum() or after.isalnum()):
                    return canonical
                i = up.find(key, i + 1)
        m = PROJECT_NO_RE.search(up)
        if m:
            return m.group()
        # 표제란에서 배운 번호(HB25-101·PJT003) — 표제란으로는 그 프로젝트가 있는데 파일명 'HB25-101_견적서.xlsx'가 부서 폴더('영업')로
        # 갔다 (검토20 r13 6). 도면번호 꼴(EL01-001)과 헷갈리지 않게 번호 꼴 자체가 아니라 **배운** 값만
        for key, orig in self._learned_numbers():
            i = up.find(key)
            while i >= 0:
                before = up[i - 1] if i else ""
                after = up[i + len(key)] if i + len(key) < len(up) else ""
                if not (before.isalnum() or after.isalnum() or after == "-" or before == "-"):
                    return orig
                i = up.find(key, i + 1)
        if folder:
            m = _PAREN_NO_RE.search(up)
            return m.group(1) if m else None
        return None

    def _learned_numbers(self) -> tuple:
        """폴더 다수결 표(표제란에서 배운 프로젝트)의 번호 꼴 값 — 긴 것부터."""
        ident = (id(self.folder_votes), len(self.folder_votes))     # learn()이 새 값을 넣으면 캐시를 비운다
        if self._learned_cache[0] == ident:
            return self._learned_cache[1]
        found: dict = {}
        for votes in self.folder_votes.values():
            for x in votes:
                v = fold_text(x).strip().upper()
                if _LEARNABLE_NO.match(v) and not PROJECT_NO_RE.fullmatch(v) and v not in self._lookup:
                    found.setdefault(v, x)
        out = tuple(sorted(found.items(), key=lambda kv: (-len(kv[0]), kv[0])))
        self._learned_cache = (ident, out)
        return out

    def root_project_for(self, label: str, root_name: str | None = None) -> str | None:
        """이 감시 폴더 전체가 어느 프로젝트인가. 지정이 있으면 그것, 없으면 폴더
        이름에 프로젝트 번호·별칭이 있을 때 그것(자동). 둘 다 아니면 None."""
        if label in self.root_projects:
            return self.root_projects[label] or None
        name = root_name or label
        return self.canonical(name) or self._find_in(name)

    def infer_single_roots(self, paths, root_names: dict, cfg: dict | None = None,
                           min_share: float = 0.6) -> dict:
        """감시 폴더 바로 아래 폴더들이 문서 종류 이름이면 그 감시 폴더를 프로젝트
        하나로 본다 (2026-09-02). 이미 지정·자동 판정된 라벨은 건드리지 않는다.
        돌려주는 값: 이번에 추정한 {라벨: 프로젝트}."""
        from watcher.doctype import looks_like_doctype_folder
        firsts: dict[str, set] = {}
        for pth in paths:
            parts = pth.split("/")
            if len(parts) >= 3 and parts[0] in self.root_labels:
                firsts.setdefault(parts[0], set()).add(parts[1])
        inferred = {}
        for label, subs in firsts.items():
            if label in self.root_projects or len(subs) < 2:
                continue
            if any(self._find_in(s) for s in subs):
                continue                      # 바로 아래에 프로젝트 번호·별칭 → 여러 프로젝트
            typed = sum(1 for s in subs if looks_like_doctype_folder(s, cfg))
            if typed / len(subs) >= min_share:
                name = root_names.get(label) or label
                inferred[label] = name
                self.root_projects[label] = name
        return inferred

    def _numbered(self, val: str) -> bool:
        """표제란 PROJECT 값이 프로젝트 **번호** 꼴인가 — 별칭 사전에 있거나 번호 꼴이거나 숫자가 든 값('삼성3차'·'2024-15').
        숫자 없는 이름('MK전기'·'Delta Engineering')은 회사·고객 이름일 때가 많다."""
        return bool(self.canonical(val) or any(ch.isdigit() for ch in val))

    def _name_defers(self, rel_path: str, val: str) -> bool:
        """번호 아닌 표제란 이름이 파일명·폴더명의 프로젝트 번호·별칭에 자리를 내주는가.
        CLAUDE.md '표제란 프로젝트 **번호** > 파일명 > 폴더명' — 회사명이 프로젝트가 되어 다른 폴더 도면과 거짓 교차가 나고
        같은 폴더 BOM(파일명·폴더 번호)과 갈려 도면-BOM 대조가 꺼졌다 (대량 시험 DXF C3, 2026-10-20)."""
        if self._numbered(val):
            return False
        p = PurePosixPath(rel_path)
        if self._find_in(p.name):
            return True
        return any(self._find_in(folder, folder=True) for folder in p.parent.parts)

    def learn(self, rel_path: str, doc: Document | None) -> None:
        """표제란 프로젝트가 있는 문서로 폴더의 다수 프로젝트를 배운다.

        `2026 수주/삼성 3라인/도면/E-101.dxf`(표제란 S3-CONV)를 배우면 같은 폴더의
        `…/삼성 3라인/BOM/BOM.xlsx`(표제란 없음)가 S3-CONV로 귀속된다. 감시 폴더 라벨
        자체에는 표를 주지 않는다 — 한 감시 폴더의 다수 프로젝트가 소수 프로젝트의 BOM을
        삼키지 않게 (검토22 실용 D1)."""
        if doc is None or not doc.project or not looks_like_project(doc.project):
            return
        val = doc.project.strip()
        if self._name_defers(rel_path, val):
            return                   # 이 도면은 파일명·폴더 번호를 따른다 — 그 폴더의 다수결에 회사명을 싣지 않는다
        if in_quiet_folder(rel_path, self.root_labels):
            return                   # 임시·공용·백업 폴더의 사본은 그 폴더가 어느 프로젝트인지의 근거가 아니다 (D1)
        proj = _nfc(self.canonical(val) or val)
        parts = list(PurePosixPath(rel_path).parent.parts)
        floor = 2 if parts and parts[0] in self.root_labels else 1
        for i in range(len(parts), floor - 1, -1):
            key = "/".join(parts[:i])
            votes = self.folder_votes.setdefault(key, {})
            if proj not in votes:
                self._learned_cache = (None, ())
            votes[proj] = votes.get(proj, 0) + 1

    def _folder_consensus(self, parent_parts) -> str | None:
        """문서 종류 폴더(도면·BOM·구매…)를 지나 처음 만나는 '프로젝트 폴더'의 다수결.

        그 위로는 올라가지 않는다 — `서버/삼성전자/3라인/도면`의 표가 `서버/삼성전자`까지
        올라가 `4라인/BOM`(도면은 DWG뿐)을 3라인 프로젝트로 삼키고 거짓 도면-BOM 불일치를
        냈다 (검토22 재검증 D1 차단). 표가 없는 프로젝트 폴더는 폴더 구조 규칙으로 돌아간다."""
        votes = self._folder_votes_at(parent_parts)
        if not votes:
            return None
        total = sum(votes.values())
        best, n = max(votes.items(), key=lambda kv: kv[1])
        return best if total and n / total >= FOLDER_MIN_SHARE else None

    def _folder_votes_at(self, parent_parts) -> dict | None:
        """_folder_consensus가 보는 프로젝트 폴더의 표 {프로젝트: 수} — 없으면 None."""
        if not self.folder_votes:
            return None
        from watcher.doctype import looks_like_doctype_folder
        parts = list(parent_parts)
        floor = 2 if parts and parts[0] in self.root_labels else 1
        for i in range(len(parts), floor - 1, -1):
            name = parts[i - 1].strip()
            if _GROUPING_FOLDER.match(name):
                return None          # 연도·수주 묶음 폴더는 여러 프로젝트의 집
            if is_quiet_folder(name):
                # 임시·공용·백업 폴더는 제 표로 남의 파일을 끌어들이지 않는다 — 그 위(프로젝트 폴더)가 있으면 그 다수결을 따르고,
                # 감시 폴더 바로 아래면 다수결 없음 → 폴더 구조('임시') → 조용한 폴더(메일 없음) (재검토 2026-10-26 D1)
                continue
            votes = self.folder_votes.get("/".join(parts[:i]))
            if votes:
                return votes
            if not looks_like_doctype_folder(name):
                return None          # 종류 폴더가 아닌 첫 폴더 = 프로젝트 폴더. 표가 없으면 끝
        return None

    def attribute(self, rel_path: str, doc: Document | None) -> tuple[str, str]:
        """(프로젝트, 근거 출처). 출처: 감시 폴더=프로젝트 > 표제란 > 파일명 >
        폴더명(별칭) > 폴더 안 도면 표제란(다수결) > 폴더 구조 > 미분류.

        감시 폴더 자체가 프로젝트 하나면 그 아래는 전부 그 프로젝트다 — 표제란·
        폴더명의 자잘한 표기 차이가 프로젝트를 여럿으로 갈라놓지 않게 (2026-09-02).
        귀속값은 NFC로 맞춘다(근거 출처 글은 원문) — 검토20 r13 4."""
        proj, src = self._attribute(rel_path, doc)
        return _nfc(proj), src

    def _attribute(self, rel_path: str, doc: Document | None) -> tuple[str, str]:
        head = rel_path.split("/", 1)[0]
        if head in self.root_labels:
            rp = self.root_project_for(head)
            if rp:
                return rp, "감시 폴더"
        if doc is not None and doc.project and looks_like_project(doc.project):
            val = doc.project.strip()
            if not self._name_defers(rel_path, val):
                return self.canonical(val) or val, f"표제란 '{val}'"
        p = PurePosixPath(rel_path)
        hit = self._find_in(p.name)
        if hit:
            return hit, "파일명"
        for folder in reversed(p.parent.parts):
            hit = self._find_in(folder, folder=True)
            if hit:
                # 폴더 이름의 번호와 그 폴더 도면들의 표제란 다수결이 다르면 표제란을 따른다 — 프로젝트 폴더 번호만 바꾸면
                # (P66-103 → P66-153) 도면은 표제란대로 103, BOM·사양서는 폴더대로 153으로 갈려 메일이 둘이 되고
                # 도면-BOM 불일치를 놓쳤다 (검토66 B1)
                cons = self._folder_consensus(p.parent.parts)
                if cons and cons != hit:
                    return cons, f"폴더 안 도면 표제란 (폴더 이름 '{folder}'와 다름)"
                return hit, "폴더명"
        # 같은 폴더의 도면들이 표제란으로 한 프로젝트에 모이면 표제란 없는 문서도 그것을
        # 따른다 — '2026 수주/삼성 3라인/BOM'이 '2026 수주'로 뭉치던 것 (검토22 실용 D1)
        hit = self._folder_consensus(p.parent.parts)
        if hit:
            return hit, "폴더 안 도면 표제란"
        # 다수결이 갈렸으면(동률·60% 미달) 지난 귀속이 그 후보 중 하나일 때 유지한다 — 도면이 한 장씩 늘어나는 현장 폴더에서 2:2가
        # 되자 표제란 없는 BOM이 부서 폴더('설계')로 뒤집히고 열린 도면-BOM 불일치가 거짓 '자동 해소'됐다 (검토20 r13 3)
        prev = self.prev_projects.get(rel_path)
        if prev:
            votes = self._folder_votes_at(p.parent.parts) or {}
            if _nfc(prev) in {_nfc(k) for k in votes}:
                return prev, "폴더 안 도면 표제란 (갈림 — 지난 귀속 유지)"
        # 폴더 구조 규칙: 감시 폴더 바로 아래 첫 폴더 = 프로젝트
        # (예: 지정폴더\세척기 2호기\세부PJT\도면\... → 프로젝트 "세척기 2호기")
        folders = list(p.parent.parts)
        if folders and folders[0] in self.root_labels:
            folders = folders[1:]
        # '2026 수주'처럼 연도·수주 묶음 이름뿐인 첫 폴더는 프로젝트가 아니다 — 그 아래 폴더로
        while len(folders) > 1 and _GROUPING_FOLDER.match(folders[0].strip()):
            folders = folders[1:]
        if folders:
            return folders[0], "폴더 구조"
        return UNASSIGNED, "미분류"
