# -*- coding: utf-8 -*-
"""DWG 파일 안의 미리보기 그림 꺼내기 — 표준 라이브러리만, 읽기 전용.

DWG는 오토데스크의 비공개 바이너리라 글자·선은 직접 못 읽는다 (변환 프로그램이
필요하다 — convert.py). 대신 저장 시점의 미리보기 그림은 파일 머리의 이미지 블록에
알려진 형식으로 들어 있어(R2000 이후) 꺼낼 수 있다. 변환 프로그램이 없는 PC의
안전망 — 저해상도지만 전/후 그림 비교는 된다. 미리보기 저장을 끈 도면에는 없다.
"""
from __future__ import annotations

import io
from pathlib import Path

# 이미지 블록 앞의 표지(sentinel) 16바이트 — ODA DWG 명세
_SENTINEL = bytes.fromhex("1F256D07D43628289D57CA3F9D44102B")
_PNG_SIG = b"\x89PNG\r\n\x1a\n"
_CODE_BMP, _CODE_PNG = 2, 6


def version(path: Path) -> str:
    """'AC1032'(R2018) 같은 형식 표지. DWG가 아니면 빈 문자열."""
    with open(path, "rb") as f:
        head = f.read(6)
    return head.decode("ascii", "replace") if head.startswith(b"AC10") else ""


def thumbnail(path: Path) -> tuple[str, bytes] | None:
    """미리보기 그림 ('png'|'bmp', 파일 바이트). 없으면 None."""
    with open(path, "rb") as f:
        data = f.read()
    if len(data) < 0x20 or not data.startswith(b"AC10"):
        return None
    seeker = int.from_bytes(data[0x0D:0x11], "little")     # 이미지 블록 위치
    if not 0 < seeker < len(data) - 21:
        return None
    if data[seeker:seeker + 16] != _SENTINEL:
        return None
    count = data[seeker + 20]
    pos = seeker + 21
    found: dict[int, bytes] = {}
    for _ in range(count):
        if pos + 9 > len(data):
            break
        code = data[pos]
        start = int.from_bytes(data[pos + 1:pos + 5], "little")
        size = int.from_bytes(data[pos + 5:pos + 9], "little")
        pos += 9
        if code in (_CODE_BMP, _CODE_PNG) and 0 < size and start + size <= len(data):
            found[code] = data[start:start + size]
    if _CODE_PNG in found and found[_CODE_PNG].startswith(_PNG_SIG):
        return "png", found[_CODE_PNG]
    if _CODE_BMP in found:
        bmp = _bmp_file(found[_CODE_BMP])
        if bmp:
            return "bmp", bmp
    return None


def _bmp_file(dib: bytes) -> bytes:
    """DWG는 BMP를 파일 머리(14바이트) 없이 DIB(정보 머리+팔레트+픽셀)만 넣는다 — 붙여 준다."""
    if len(dib) < 40:
        return b""
    hdr = int.from_bytes(dib[0:4], "little")
    bpp = int.from_bytes(dib[14:16], "little")
    clr = int.from_bytes(dib[32:36], "little")
    colors = clr or ((1 << bpp) if bpp <= 8 else 0)
    offset = 14 + hdr + colors * 4
    return (b"BM" + (14 + len(dib)).to_bytes(4, "little") + b"\0\0\0\0"
            + offset.to_bytes(4, "little") + dib)


def thumbnail_image(path: Path):
    """미리보기를 그레이 PIL 이미지로. 없거나 못 읽으면 None."""
    r = thumbnail(path)
    if r is None:
        return None
    from PIL import Image
    decode = Image.open      # 메모리 버퍼 해독 — 파일을 열지 않는다
    try:
        img = decode(io.BytesIO(r[1]))
        img.load()
        return img.convert("L")
    except Exception:
        return None
