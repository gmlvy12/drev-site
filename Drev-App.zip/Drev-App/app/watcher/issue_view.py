# -*- coding: utf-8 -*-
"""확인 필요의 개수 칸 · 목록 · 상세 — 감시 화면(web.py)과 사내망(forms/changes.py)이 함께 쓰는 모양 (2026-11-24 사용자
'B 기준인데 위에 전체 몇 개씩 확인이 필요한지'). 맨 위 개수 칸(누르면 그 종류만), 왼쪽 목록(대상 · 발견 / 문제 · 프로젝트 / 값 한 줄),
오른쪽 상세(값 두 줄 · 위치 · 근거 · 단추). 값을 짓지 않고 부르는 쪽이 만든 HTML을 놓기만 한다 (원칙 4).

고르기: 감시 화면은 줄 링크(#iss-번호) + 짧은 스크립트, 사내망은 스크립트가 막혀(CSP script-src 'none') 줄 안의 라디오 칸."""

from __future__ import annotations

import html
import re

E = html.escape
_PV_ROW = re.compile(r'<div class="ds-pv-r[^"]*"><span class="ds-pv-l">([^<]*)</span> <span class="ds-pv-v">([^<]*)</span></div>')


def one_line(l1: str) -> str:
    """근거 첫 줄 HTML(이전/지금 또는 출처 두 줄 칸) → 목록 줄의 값 한 줄 (HTML). 칸이 없는 한 줄이라 '지금(이전 …)' — 화살표 없이
    (DECISIONS 2026-11-21). 출처 견주기는 '도면 60AT, BOM 50AT'. 두 줄 칸을 모두 읽지 못하면(값 안에 다른 표시가 있는 등) 글자만
    그대로 — 값을 자르거나 짐작하지 않는다 (원칙 4). 자세한 값·위치는 상세가 두 줄 칸 그대로 보인다."""
    rows = _PV_ROW.findall(l1)
    if len(rows) >= 2 and len(rows) == l1.count('<div class="ds-pv-r'):
        if [r[0] for r in rows] == ["이전", "지금"]:
            k = re.search(r'<div class="ds-pk">([^<]*)</div>', l1)
            return (f'{k.group(1)} ' if k else "") + f'{rows[1][1]}(이전 {rows[0][1]})'
        return ", ".join(f"{lab} {v}" for lab, v in rows)
    return " ".join(re.sub(r"<[^>]+>", " ", l1).split())


def by_count(counter) -> list:
    """종류별 (코드, 건수) — 많은 것부터, 같은 수면 코드 순(감시 화면·사내망이 같은 차례)."""
    return sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))


def cards(items, label: str) -> str:
    """개수 칸 줄. items: [(주소, 이름, 건수, 색, 지금 고른 것인가, 풀이)…] — 주소·이름·풀이는 글(여기서 이스케이프)."""
    out = "".join(
        f'<a href="{E(href)}"{" class=on aria-current=true" if on else ""}{f" title={chr(34)}{E(tip)}{chr(34)}" if tip else ""}>'
        + (f'<span class="ds-iss-d {tone}"></span>' if tone else "") + f'{E(name)}<b>{int(n):,}</b></a>'
        for href, name, n, tone, on, tip in items)
    return f'<nav class="ds-iss-k" aria-label="{E(label)}">{out}</nav>' if out else ""


CSS = """
/* ── 확인 필요 개수 칸 · 목록 · 상세 (2026-11-24) — watcher/issue_view.py ── */
.ds-iss-card{overflow:clip}
.ds-iss-k{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}
.ds-iss-k a{display:block;background:var(--ds-surface);border:1px solid var(--ds-border);border-radius:12px;padding:14px 18px;
  font-size:14.5px;color:var(--ds-muted);word-break:keep-all;overflow-wrap:anywhere;text-decoration:none}
.ds-iss-k a b{display:block;font-size:26px;font-weight:800;line-height:1.25;margin-top:2px;color:var(--ds-text)}
.ds-iss-k a:hover{border-color:var(--ds-border2)}
.ds-iss-k a.on{border-color:var(--ds-primary);box-shadow:inset 0 0 0 1px var(--ds-primary);color:var(--ds-text)}
.ds-iss-d{display:inline-block;width:8px;height:8px;border-radius:50%;flex:none;background:var(--ds-faint)}
.ds-iss-d.red{background:var(--ds-red)}
.ds-iss-d.amber{background:var(--ds-amber)}
.ds-iss-d.green{background:var(--ds-green)}
.ds-iss-k a .ds-iss-d{margin-right:8px;vertical-align:1px}
.ds-iss-2{position:relative;display:grid;grid-template-columns:minmax(300px,392px) minmax(0,1fr);
  grid-template-rows:repeat(520,max-content) 1fr}
.ds-iss-2::before{content:"";position:absolute;grid-column:1/2;top:0;right:0;bottom:0;border-right:1px solid var(--ds-border);pointer-events:none}
.ds-iss-lh{grid-column:1;display:flex;align-items:center;padding:9px 20px 9px 14px;border-bottom:1px solid var(--ds-border);
  font-size:13.5px;color:var(--ds-muted)}
.ds-iss-lh label{display:inline-flex;align-items:center;gap:10px;padding:4px 6px;cursor:pointer}
.ds-iss-lh input,.ds-iss-ck input{width:18px;height:18px;margin:0;accent-color:var(--ds-primary);cursor:pointer}
.ds-iss-r{grid-column:1;display:flex;align-items:flex-start;border-bottom:1px solid var(--ds-border);scroll-margin-top:12px}
.ds-iss-r:hover{background:var(--ds-hover)}
.ds-iss-r.on{background:var(--ds-primary-weak);box-shadow:inset 3px 0 0 var(--ds-primary)}
.ds-iss-ck{flex:none;padding:9px 0 0 14px}
.ds-iss-ck label{display:flex;align-items:center;justify-content:center;width:30px;height:30px;cursor:pointer}
.ds-iss-a{flex:1;min-width:0;display:block;padding:13px 18px 13px 6px;color:var(--ds-text2);text-decoration:none}
.ds-iss-a:focus-visible{outline:2px solid var(--ds-primary);outline-offset:-2px}
.ds-iss-t1,.ds-iss-t2{display:flex;align-items:center;gap:8px;min-width:0}
.ds-iss-t1 b{font-size:15.5px;font-weight:700;color:var(--ds-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ds-iss-t1 .ds-iss-dt,.ds-iss-t2 .ds-new{margin-left:auto;flex:none;font-size:13.5px;color:var(--ds-muted);white-space:nowrap}
.ds-iss-t2 .ds-new{color:var(--ds-primary-ink);font-weight:700}
.ds-iss-t2{margin-top:3px;padding-left:16px;font-size:14px;color:var(--ds-muted);white-space:nowrap;gap:10px}
.ds-iss-t3{display:block;margin-top:3px;padding-left:16px;font-size:14.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ds-iss-a .ds-iss-cm{display:block;padding-left:16px}
.ds-iss-p{grid-column:2;grid-row:1/-1;display:none;align-self:start;position:sticky;top:0;max-height:calc(100vh - 62px);overflow-y:auto;
  padding:22px 28px 26px;font-size:15px;color:var(--ds-text2)}
.ds-iss-r.on+.ds-iss-p{display:block}
.ds-iss-2:not(.js):has(.ds-iss-r:target) .ds-iss-r.on:not(:target)+.ds-iss-p{display:none}
.ds-iss-2:not(.js) .ds-iss-r:target+.ds-iss-p{display:block}
.ds-iss-2:not(.js) .ds-iss-r:target{background:var(--ds-primary-weak);box-shadow:inset 3px 0 0 var(--ds-primary)}
.ds-iss-2:not(.js):has(.ds-iss-r:target) .ds-iss-r.on:not(:target){background:none;box-shadow:none}
@media (min-width:901px) and (max-width:1180px){.ds-iss-2{grid-template-columns:minmax(230px,36%) minmax(0,1fr)}}
.ds-iss-ph{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.ds-iss-ph h2{font-size:21px;font-weight:800;color:var(--ds-text);overflow-wrap:anywhere}
.ds-iss-ps{display:flex;flex-wrap:wrap;gap:2px 16px;margin-top:6px;font-size:14px;color:var(--ds-muted)}
.ds-iss-ps a{color:var(--ds-primary-ink);font-weight:700}
.ds-iss-p .ds-iss-l1{margin-top:18px;font-size:16px}
.ds-iss-p .ds-iss-l2{margin-top:8px;font-size:14px;color:var(--ds-muted);overflow-wrap:anywhere}
.ds-iss-p h3{font-size:14px;font-weight:700;color:var(--ds-muted);margin:22px 0 6px;padding-top:16px;border-top:1px solid var(--ds-border)}
.ds-iss-ev{margin-top:18px}
.ds-iss-ev>summary{list-style:none;cursor:pointer;font-size:14px;font-weight:700;color:var(--ds-primary-ink);width:max-content}
.ds-iss-ev>summary::-webkit-details-marker{display:none}
.ds-iss-ev>summary::after{content:" \\25BE"}
.ds-iss-ev[open]>summary::after{content:" \\25B4"}
.ds-iss-evb{margin-top:10px;padding:12px 16px;background:var(--ds-surface2);border:1px solid var(--ds-border);border-radius:10px;font-size:14.5px}
.ds-iss-do{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:22px;padding-top:18px;border-top:1px solid var(--ds-border)}
.ds-iss-do form .ds-btn{border-color:var(--ds-primary);color:var(--ds-primary-ink)}
.ds-hot-v1{color:var(--ds-text);overflow-wrap:anywhere}
.ds-hot-v2{display:flex;flex-wrap:wrap;gap:0 14px}
.ds-iss-s{position:absolute;opacity:0;width:1px;height:1px;margin:0;pointer-events:none}
label.ds-iss-a{position:relative;padding-left:20px;margin:0;font-weight:400;cursor:pointer}
.ds-iss-r:has(.ds-iss-s:checked){background:var(--ds-primary-weak);box-shadow:inset 3px 0 0 var(--ds-primary)}
.ds-iss-r:has(.ds-iss-s:checked)+.ds-iss-p{display:block}
.ds-iss-r:has(.ds-iss-s:focus-visible){outline:2px solid var(--ds-primary);outline-offset:-2px}
.ds-iss-p .ds-sm{margin-top:6px}
@media (max-width:900px){
  /* 좁은 화면: 두 칸을 세로로 — 고른 줄 바로 아래에 상세가 펼쳐진다 (DOM 순서가 줄 → 상세라 화면 읽기 순서도 같다) */
  .ds-iss-k{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:16px}
  .ds-iss-k a{padding:10px 14px}
  .ds-iss-k a b{font-size:22px}
  .ds-iss-2{display:block}
  .ds-iss-2::before{display:none}
  .ds-iss-p{position:static;max-height:none;padding:18px 20px 22px;border-bottom:1px solid var(--ds-border);background:var(--ds-surface2)}
}
/* :has()가 없는 옛 브라우저 — 고르지 못하니 상세를 모두 줄 아래에 펼쳐 둔다(숨지 않게) */
@supports not selector(:has(*)){
  .ds-iss-2{display:block}
  .ds-iss-2::before{display:none}
  .ds-iss-p{display:block;position:static;max-height:none;border-bottom:1px solid var(--ds-border)}
}
"""
